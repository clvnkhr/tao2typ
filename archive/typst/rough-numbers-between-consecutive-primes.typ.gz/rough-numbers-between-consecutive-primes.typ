// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/
// Converted to Typst by tao2typ: "2026-10-14T16:39:18.813093+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Rough numbers between consecutive primes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Rough numbers between consecutive primes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 August 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/")[#text("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("First things first: due to an abrupt suspension of NSF funding to my home university of UCLA, the Institute of Pure and Applied Mathematics (which had been preliminarily approved for a five-year NSF grant to run the institute) is ")#link("https://www.ipam.ucla.edu/news/nsf-funding-to-ipam-suspended/")[#text("currently fundraising to ensure continuity")]#text(" of operations during the suspension, with a goal of raising $500,000. Donations can be made ")#link("https://giving.ucla.edu/Campaign/Donate.aspx?SiteNum=136&Fund=61766C")[#text("at this page")]#text(". As incoming Director of Special Projects at IPAM, I am grateful for the support (both moral and financial) that we have already received in the last few days, but we are still short of our fundraising goal.")

#text("Back to math. ")#link("https://olemiss.edu/profiles/argafni")[#text("Ayla Gafni")]#text(" and I have just uploaded to the arXiv the paper “")#link("http://arxiv.org/abs/2508.06463")[#text("Rough numbers between consecutive primes")]#text("“. In this paper we resolve a ")#link("https://www.erdosproblems.com/682")[#text("question of Erdös")]#text(" concerning rough numbers between consecutive gaps, and with the assistance of modern sieve theory calculations, we in fact obtain quite precise asymptotics for the problem. (As a side note, this research was supported by my personal NSF grant which is also currently suspended; I am grateful to recent donations to my own research fund which have helped me complete this research.)")

#text("Define a ")#emph[#text("prime gap")]#text(" to be an interval ")#mi("{(p_n, p_{n+1})}")#text(" between consecutive primes. We say that a prime gap ")#emph[#text("contains a rough number")]#text(" if there is an integer ")#mi("{m \\in (p_n,p_{n+1})}")#text(" whose least prime factor is at least the length ")#mi("{p_{n+1}-p_n}")#text(" of the gap. For instance, the prime gap ")#mi("{(3,5)}")#text(" contains the rough number ")#mi("{4}")#text(", but the prime gap ")#mi("{(7,11)}")#text(" does not (all integers between ")#mi("{7}")#text(" and ")#mi("{11}")#text(" have a prime factor less than ")#mi("{4}")#text("). The first few ")#mi("{n}")#text(" for which the ")#mi("{n^\\mathrm{th}}")#text(" prime gap contains a rough number are")

#align(center)[#tao-fit-display[#mitex("2, 3, 5, 7, 10, 13, 15, 17, 20, \\dots.")]]

#text("Numerically, the proportion of ")#mi("{n}")#text(" for which the ")#mi("{n^\\mathrm{th}}")#text(" prime gap does not contain a rough number decays slowly as ")#mi("{n}")#text(" increases:")

#image("../assets/bc5adccf6797f24df4cb7a99fde47df5700e44b3051bf92ba48c12eda85a81bf-d7d7b8ba037f8c0ff724973792aa85e9db4f1105a121c41dd2728345201d62a3.png", width: 90%)

#text("Erdös initially thought that all but finitely many prime gaps should contain a rough number, but changed his mind, ")#link("https://users.renyi.hu/~p_erdos/1979-23.pdf")[#text("as per the following quote")]#text(":")

#text("…I am now sure that this is not true and I “almost” have a counterexample. Pillai and Szekeres observed that for every ")#mi("{t \\leq 16}")#text(", a set of ")#mi("{t}")#text(" consecutive integers always contains one which is relatively prime to the others. This is false for ")#mi("{t = 17}")#text(", the smallest counterexample being ")#mi("{2184, 2185, \\dots, 2200}")#text(". Consider now the two arithmetic progressions ")#mi("{2183 + d \\cdot 2 \\cdot 3 \\cdot 5 \\cdot 7 \\cdot 11 \\cdot 13}")#text(" and ")#mi("{2201 + d \\cdot 2 \\cdot 3 \\cdot 5 \\cdot 7 \\cdot 11 \\cdot 13}")#text(". There certainly will be infinitely many values of ")#mi("{d}")#text(" for which the progressions simultaneously represent primes; this follows at once from hypothesis H of Schinzel, but cannot at present be proved. These primes are consecutive and give the required counterexample. I expect that this situation is rather exceptional and that the integers ")#mi("{k}")#text(" for which there is no ")#mi("{m}")#text(" satisfying ")#mi("{p_k < m < p_{k+1}}")#text(" and ")#mi("{p(m) > p_{k+1} - p_k}")#text(" have density ")#mi("{0}")#text(".")

#text("In fact Erdös’s observation can be made simpler: any pair of ")#link("https://en.wikipedia.org/wiki/Cousin_prime")[#text("cousin primes")]#text(" ")#mi("{p_{n+1}=p_n+4}")#text(" for ")#mi("{p_n > 3}")#text(" (of which ")#mi("{(7,11)}")#text(" is the first example) will produce a prime gap that does not contain any rough numbers.")

#text("The latter question of Erdös is ")#link("https://www.erdosproblems.com/682")[#text("listed as problem #682")]#text(" on Thomas Bloom’s ")#link("https://www.erdosproblems.com/")[#text("Erdös problems website")]#text(". In this paper we answer Erdös’s question, and in fact give a rather precise bound for the number of counterexamples:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Erdos #682)")]#text(" ")#metadata(none) <tao-d13c45bb2c1a3196aba0>#text(" For ")#mi("{X>2}")#text(", let ")#mi("{N(X)}")#text(" be the number of prime gaps ")#mi("{(p_n, p_{n+1})}")#text(" with ")#mi("{p_n \\in [X,2X]}")#text(" that do not contain a rough number. Then")

#metadata(none) <tao-5f057fde1575cd4878f1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("N(X) \\ll \\frac{X}{\\log^2 X}.")]]

#text("Assuming the Dickson–Hardy–Littlewood prime tuples conjecture, we can improve this to")

#metadata(none) <tao-a6b7b3a6fa2d75c102e3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("N(X) \\sim c \\frac{X}{\\log^2 X}")]]

#text("for some (explicitly describable) constant ")#mi("{c>0}")#text(".")
]

#text("In fact we believe that ")#mi("{c \\approx 2.8}")#text(", although the formula we have to compute ")#mi("{c}")#text(" converges very slowly. This is (weakly) supported by numerical evidence:")

#image("../assets/b9b8ea04aac4ee59f1e99992d0af0f734362bc6ca8016463f6e88e2ad6a51ca2-59c5b4b10920e4215acc5e171cb78f78b9e41d4586685dfcb57582dd6fe4cad6.png", width: 90%)

#text("While many questions about prime gaps remain open, the theory of rough numbers is much better understood, thanks to modern sieve theoretic tools such as the ")#link("https://en.wikipedia.org/wiki/Fundamental_lemma_of_sieve_theory")[#text("fundamental lemma of sieve theory")]#text(". The main idea is to frame the problem in terms of counting the number of rough numbers in short intervals ")#mi("{[x,x+H]}")#text(", where ")#mi("{x}")#text(" ranges in some dyadic interval ")#mi("{[X,2X]}")#text(" and ")#mi("{H}")#text(" is a much smaller quantity, such as ")#mi("{H = \\log^\\alpha X}")#text(" for some ")#mi("{0 < \\alpha < 1}")#text(". Here, one has to tweak the definition of “rough” to mean “no prime factors less than ")#mi("{z}")#text("” for some intermediate ")#mi("{z}")#text(" (e.g., ")#mi("{z = \\exp(\\log^\\beta X)}")#text(" for some ")#mi("{0 < \\beta < \\alpha}")#text(" turns out to be a reasonable choice). These problems are very analogous to the extremely well studied problem of counting ")#emph[#text("primes")]#text(" in short intervals, but one can make more progress without needing powerful conjectures such as the Hardy–Littlewood prime tuples conjecture. In particular, because of the fundamental lemma of sieve theory, one can compute the mean and variance (i.e., the first two moments) of such counts to high accuracy, using in particular some calculations on the mean values of singular series that go back at least to the ")#link("https://zbmath.org/0209.34804")[#text("work of Montgomery from 1970")]#text(". This second moment analysis turns out to be enough (after optimizing all the parameters) to answer Erdös’s problem with a weaker bound")

#align(center)[#tao-fit-display[#mitex("N(X) \\ll \\frac{X}{\\log^{4/3-o(1)} X}.")]]

#text("To do better, we need to work with higher moments. The fundamental lemma also works in this setting; one now needs precise asymptotics for the mean value of singular series of ")#mi("{k}")#text("-tuples, but this was fortunately worked out (in more or less exactly the format we needed) ")#link("https://zbmath.org/1124.11048")[#text("by Montgomery and Soundararajan")]#text(" in 2004. Their focus was establishing a central limit theorem for the distribution of primes in short intervals (conditional on the prime tuples conjecture), but their analysis can be adapted to show (unconditionally) good concentration of measure results for rough numbers in short intervals. A direct application of their estimates improves the upper bound on ")#mi("{N(X)}")#text(" to")

#align(center)[#tao-fit-display[#mitex("N(X) \\ll \\frac{X}{\\log^{2-o(1)} X}")]]

#text("and some more careful tweaking of parameters allows one to remove the ")#mi("{o(1)}")#text(" error. This latter analysis reveals that in fact the dominant contribution to ")#mi("{N(X)}")#text(" will come with prime gaps of bounded length, of which our understanding is still relatively poor (it was only in 2014 that ")#link("https://zbmath.org/1290.11128")[#text("Yitang Zhang famously showed")]#text(" that infinitely many such gaps exist). At this point we finally have to resort to (a Dickson-type form of) the prime tuples conjecture to get the asymptotic ")#link(<tao-a6b7b3a6fa2d75c102e3>)[#text("(2)")]#text(".")

#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2229b984900b0b520d8c24e92fa34bb161f9c42ef66ae594ae1e6dad0308d3a2-95bd257c2e2657147882ed1a4dd3b375234491bb53f444fec1701f1ecf47600e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Toby Bartels")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688562")[#strong[#text("Toby Bartels")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2025")])]

#text("I’m glad to hear that IPAM intends to keep everything going. I donated a bit (not much, I’m afraid), and I wish you good luck!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688570")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2025")])]

#text("I am very sorry to hear about the suspension of your university funding. It is deeply unjust and I hope it can resume soon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688575")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2025")])]

#text("As an ordinary office worker from China, I can only make a small donation within my means. This is my encouragement, as a regular person, to the mathematical geniuses fighting on the front lines of theoretical research. I wish you to always move forward and achieve even greater things.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0d7afe723eb05746c526967dec5a55f5f55bde2ffc21e01b2470dfe56e7cdb9-55e3d1298d69e874c5978d581be37c15033d28bb9dda479cb56ef45fe252b14d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of NooneAtAll3")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688581")[#strong[#text("NooneAtAll3")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2025")])]

#text("What does << mean here? Intuitively I’d expect it to mean “much less than”, aka “asymptotically less” in this context… But then suspected exact bound not only asymptotically same – constant is larger than 1, so it’s not even smaller!")

#text("Looking through unicode, ≪ is indeed MUCH LESS-THAN, but I don’t think there’s big-O alternative… maybe ⪣?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688591")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2025")])]

#text("This is Vinogradov asymptotic notation, which is in common use in analytic number theory; see ")#link("https://en.wikipedia.org/wiki/Big_O_notation#History_(Bachmann%E2%80%93Landau,_Hardy,_and_Vinogradov_notations)")[#text("https://en.wikipedia.org/wiki/Big_O_notation#History_(Bachmann%E2%80%93Landau,_Hardy,_and_Vinogradov_notations)")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688582")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2025")])]

#text("Professor Tao,")

#text("Did Erdös pose a question regarding the density of the numbers ")#mi("k")#text(" such that there is no integer ")#mi("m")#text(" satisfying ")#mi("p_{k} < m < p_{k+1}")#text(" and whose greatest prime factor is greater than or equal to ")#mi("p_{k+1}-p_{k}")#text("?")

#text("I suppose that one such a question might yield to the lore of “smooth numbers” and that the term “rough” was introduced to suggest a certain contradisctintion to the arithmetic notion of “smoothness”. Am I dead-wrong?")

#text("Finally, is there a chance that the constant ")#mi("c")#text(" that you believe that is near to ")#mi("2.8")#text(" is not other than ")#mi("2.718281828459045...")#text("?")

#text("Thanks in advance for your reply!")

#text("J. H. S.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688592")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2025")])]

#text("I do not believe that the constant ")#mi("c")#text(" here will match up with any other existing constant in the literature.")

#text("Rough numbers are indeed the complementary concept to smooth numbers; I do not know the precise etymology, but it seems reasonable to assume that one of these notations was introduced in response to the other.")

#text("The Erdos question mentioned in this blog post is equivalent to the density you mention being equal to zero, which our paper confirms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0a843b233e16e43db809fd52c0e601152aaf348c457214e2a1d49c9581b7dc4-97c39545e606c20f62c8de8bb5e339087b9b5f503c9757987c1d939f766264da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Evan Conway")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688585")[#strong[#text("Evan Conway")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2025")])]

#text("I would be interested to hear how you’re computing ")#tao-math("\\left|\\Omega_h\\right|", block: false)#text(", since Table 1 in the paper notes that it’s fairly hard to compute. I thought about the problem a bit last night, and here’s what I came up with:")

#text("The naive approach would be to sieve the entire range for numbers coprime to ")#mi("P(h)")#text(". If ")#mi("P(h) = p_1 \\cdot \\dots \\cdot p_n")#text(", then this would be around ")#mi("O(n \\cdot p_1 \\cdot \\dots \\cdot p_n)")#text(" work. After sieving, a single pass would be sufficient to find all gaps of size ")#mi("h")#text(". Of course, this approach is not particularly viable for higher values of ")#mi("h")#text(", since ")#mi("O(n \\cdot p_1 \\cdot \\dots \\cdot p_n)")#text(" will become quite large.")

#text("One idea is to exploit the fact that smaller primorials tile within larger primorials. As an example, suppose that we are attempting to compute ")#tao-math("\\left|\\Omega_h\\right|", block: false)#text(" for ")#mi("h = 16")#text(", which has ")#mi("P(h) = 30030 = 2 \\cdot \\dots \\cdot 13")#text(". We could first precompute the coprimes of ")#mi("210 = 2 \\cdot \\dots \\cdot 7")#text(", which are ")#mi("1, 11, \\dots, 199, 209")#text(", and then check the appropriately shifted versions for each range (for example, for 199, we would check divisibility by the remaining primes 11 and 13 for ")#mi("199")#text(", ")#mi("210 + 199")#text(", ")#mi("2 \\cdot 210 + 199")#text(", and so on. This avoids the work of sieving out the first few primes. If we use the first ")#mi("k")#text(" primes in our precomputation, then our time complexity is around ")#mi("O(k \\cdot p_1 \\cdot \\dots \\cdot p_k + (n-k) \\cdot p_1 \\cdot \\dots \\cdot p_n)")#text(". This still leaves the troublesome ")#mi("p_1 \\cdot \\dots \\cdot p_n")#text(" term, which is the main cause of our slow computation.")

#text("The next thing to exploit is that we exclusively care about coprimes that differ by a certain amount (")#mi("h = 16")#text(", in this case). We can filter our precomputed coprime list for primes that are ")#mi("h")#text(" apart. In this case, we get ")#mi("(1,17), (13,29), \\dots, (193,209)")#text(" (13 pairs in total). We can check each of these pairs (after shifting by the appropriate multiple of 210) to see if they’re both coprime, which should be quite fast. However, we must also account for checking that the numbers in between are not coprime. For example, for ")#mi("(1, 17)")#text(", we need to certify that the shifted versions of 1 and 17 are coprime to ")#mi("p_1 \\cdot \\dots \\cdot p_n")#text(", but that 11 and 13 are not. This would reduce the number of checks we need to make, but would not substantially reduce the time complexity, since we still need to examine the full range up to ")#mi("p_1 \\cdot \\dots \\cdot p_n")#text(".")

#text("The last optimization is to consider that for each candidate pair and the numbers in between, we only care about the moduli under ")#mi("p_{k+1}, \\dots, p_n")#text(". For example, taking the moduli of ")#mi("1, 11, 13, 17")#text(" under 11 and 13 gives ")#mi("1, 0, 2, 6")#text(" and ")#mi("1, 11, 0, 4")#text(", respectively. In order to have a gap of ")#mi("h = 16")#text(", the shifted versions of 11 and 13 must be coprime to ")#mi("P(h)")#text(" we must have ")#mi("210 \\cdot i \\mod 11 = 0")#text(" and ")#mi("210 \\cdot i \\mod 13 = 0")#text(", or ")#mi("210 \\cdot i \\mod 11 = 9")#text(" and ")#mi("210 \\cdot i \\mod 13 = 2")#text(". Since (I believe) ")#mi("210 \\cdot i")#text(" will hit each tuple of moduli exactly once, this problem reduces to counting the number of distinct tuples of moduli for which a candidate pair is valid (2 in this case). This removes the need to iterate over the full range ")#mi("p_1 \\cdot \\dots \\cdot p_n")#text(", so the time complexity should be some multiple of ")#mi("p_1 \\cdot \\dots \\cdot p_k")#text(", ")#mi("n")#text(", and ")#mi("k")#text(". For an appropriately chosen value of ")#mi("k")#text(", this should be reasonably fast.")

#text("When I get a chance, I’ll try to write up something to run this and hopefully get a better approximation of ")#mi("c")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688593")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2025")])]

#text("I admit that I only ran a very simple brute force algorithm to compute the first few values of ")#tao-math("\\left|\\Omega_h\\right|", block: false)#text(". In fact the initial code was supplied to me by an AI; I reviewed the code and checked the output against the first few values of ")#mi("\\Omega_h")#text(" that could be computed by hand, but did not feel confident enough in the program to trust it once the memory and compute requirements became non-trivial. I can believe that the more efficient methods you propose can confirm the existing values and extend the table by several more entries, although I think no matter what one does, a precise evaluation is necessarily going to be exponential-time in ")#mi("h")#text(" (though it is possible that some deterministic or probabilistic approximation of the quantity may be faster than this).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688586")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2025")])]

#text("Is this part of the cut of STEM or part of the “hostile environment” cut by the Trump administration?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688588")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2025")])]

#text("Thank you Terry, deeply appreciate your work and your continued approach to math with an open mind. I enjoy seeing the way collaborate across disciplines and attack problems. I chipped in, hoping this helps get past this interruption to the good work you are doing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688589")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2025")])]

#text("Is there a way to see how much IPAM has currently raised?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688595")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2025")])]

#text("All the best, I am sure you can get through this period of interruption and keep working, it has happened to all of us at some point.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688599")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2025")])]

#text("What is the end goal of the administration? In game theory given goals we study actions. Usually for countries following US leadership we can state similarly. US alone is in a strange situation since at least 1945 and more prominently since 1991. We are inclined to ask given actions what is the end goal? It does not apply to any other country except the US. Where is the ship sailing?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2025")])]

#text("The President is a badly confused fool, that is where the country is going.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688601")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2025")])]

#text("No the situation is more dire than that. Unlike past great powers US is a democracy and if the election is held today he will still win. The people decide their destiny.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688606")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2025")])]

#text("It is serious because he has publicly stated in the run-up to 2016 election all amendments post 13th are questionable and still he has received majority as needed by law to win twice and he only lost 2020 because of his own arrogance about mail in votes. It is not just him it is also the people. Suspension of habeas corpus is not far out of the reach of imagination particularly if 2026 maintains status quo because threat to US or rebellion is not defined and because look at what is happening to immigrants and what is happening in CA and DC. It is a protestant country and if one powerful religious nut questions 13th the whole enmasse will follow through and there are nuts who believe putting faeces in slaves’ mouths to prevent their language and culture before slavery ended was not immoral and might be considered normal.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24a6e77567973bd548a06ba46cbbc75c7d37eb3612738fc16de4f083c6b081b6-68d6eaf1abd5bf564f2d449a44e084ca517ef40d64e2a31a86d42bb61b675ad5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ducduc2710")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688617")[#strong[#text("ducduc2710")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2025")])]

#text("What is the error between p_k and logN_k? Where N_k is the product of the first k prime numbers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688618")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2025")])]

#text("The quantity ")#mi("\\log N_k")#text(" is also expressible as ")#mi("\\theta(p_k)")#text(", where ")#mi("\\theta")#text(" is the ")#link("https://en.wikipedia.org/wiki/Chebyshev_function")[#text("Chebyshev function")]#text(", so the question basically amounts to asking for asymptotics for the Chebyshev function, which is closely tied to the prime number theorem and questions such as the Riemann hypothesis. In addition to the bounds listed at the Wikipedia page linked above, further bounds can be found at ")#link("https://ramare-olivier.github.io/TME-EMT/Articles/Art01.html")[#text("https://ramare-olivier.github.io/TME-EMT/Articles/Art01.html")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24a6e77567973bd548a06ba46cbbc75c7d37eb3612738fc16de4f083c6b081b6-68d6eaf1abd5bf564f2d449a44e084ca517ef40d64e2a31a86d42bb61b675ad5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ducduc2710")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688619")[#strong[#text("ducduc2710")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2025")])]

#text("I remember there is a formula proposed by Cipolla, is it possible to know p_k > logN_k explicitly?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688652")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2025")])]

#text("c is less than 2.6, 200000 values.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688710")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2025")])]

#strong[#text("The use of higher-moment sieve theory to push beyond the initial 4/3 exponent and reach the log² X scale (unconditionally) is particularly elegant, especially the adaptation of Montgomery-Soundararajan’s work on singular series averages for k-tuples. It’s also interesting how the dominant contributions end up coming from bounded-length gaps, tying back to longstanding challenges like Zhang’s result on bounded gaps.")]

#strong[#text("On the numerical side, the slow convergence for c makes sense given the tail behavior of c_h. To provide some additional empirical support for your c ≈ 2.8 estimate under the Dickson-Hardy-Littlewood conjecture, I ran a computation over all prime gaps up to the largest prime below 10^7 (namely 9,999,991). Out of 664,578 total gaps, 121,669 do ")]#strong[#emph[#text("not")]]#strong[#text(" contain a rough number (proportion ≈ 18.3%). This raw count is broadly consistent with the expected asymptotic accumulation of bad gaps up to Y ≈ 10^7 being on the order of c Y / (log Y)^2 ≈ 38,566 × c; for c = 2.8, that yields ≈108,000, which is reasonably close to 121,669 given lower-order terms and the moderate scale of Y here. The proportion indeed decays gradually, as expected from the 1/log p_n local density.")]

#strong[#text("For clarity on the definition: a “bad” gap here is one without any m in (p_n, p_{n+1}) where the smallest prime factor of m is at least the gap length d = p_{n+1} – p_n. The computation precomputed smallest prime factors via sieve up to 10^7 and checked each gap directly—straightforward but efficient for this range.")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688860")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2025")])]

#text("Your argument treats divisibility by small primes as nearly independent across the integers in a gap. Is there a way to express that independence quantitatively perhaps by a variance bound similar to what appears in divisor-density results such as those of F. K. Richter?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-688866")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2025")])]

#text("Yes, variance bounds for sums over small prime divisors are straightforward to obtain. One standard instantiation of this is the ")#link("https://en.wikipedia.org/wiki/Tur%C3%A1n%E2%80%93Kubilius_inequality")[#text("Turan-Kubilius inequality")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae4a95909ce546ba527d1bf0726e5d96cf562f80240201942cba7db218db8bd8-6fa1083dd2e869a6fe7226febef3e5e42f16eab10bbf16988cef8237c00b082d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack Hales")]], [#link("https://terrytao.wordpress.com/2025/08/10/rough-numbers-between-consecutive-primes/#comment-693729")[#strong[#text("Jack Hales")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2026")])]

#text("I had a go at computing ")#raw("c")#text(" and get ")#strong[#text("2.74161075")]#text(", with ")#strong[#text("c ≥ 2.741610742192")]#text(" proved by exact summation through gap size 94. That’s inside your 2.7–2.8 bracket but a little under where the post leans, so I’d be grateful if someone would check it.")

#text("Briefly on the method, in case the approach is the part worth poking at. ")#raw("|Ω_h|")#text(" looks like a search over residues mod ")#raw("P(h)")#text(", which explodes past gap size 20 or so. But the conditions decouple: by CRT the per-prime residues are independent, so it’s a product-space probability rather than a search, and a small dynamic program evaluates it. Every odd prime above half the gap length covers at most one position, each with the same probability, so those collapse into a recursion — which keeps every term an exact rational rather than a Monte Carlo estimate.")

#text("As a check on the machinery rather than the answer: my partial sum through gap size 18 comes out at 2.715392, which I think matches your Table 1.")

#text("I’ve been working on prime deltas from a data perspective since 2023 onwards for fun, and was using LLMs recently for tooling recently, and part of its mission it computed this constant. I’d LOVE if someone could review it, since I am not a mathematician!")
]
