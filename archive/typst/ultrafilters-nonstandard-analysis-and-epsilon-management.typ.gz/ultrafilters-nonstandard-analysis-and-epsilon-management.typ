// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/
// Converted to Typst by tao2typ: "2026-10-14T06:52:37.718262+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Ultrafilters, nonstandard analysis, and epsilon management", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Ultrafilters, nonstandard analysis, and epsilon management")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 June 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("This post is in some ways an antithesis of my previous postings on ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("hard and soft analysis")]#text(". In those posts, the emphasis was on taking a result in soft analysis and converting it into a hard analysis statement (making it more “quantitative” or “effective”); here we shall be focusing on the reverse procedure, in which one harnesses the power of infinitary mathematics – in particular, ultrafilters and nonstandard analysis – to facilitate the proof of finitary statements.")

#text("Arguments in hard analysis are notorious for their profusion of “epsilons and deltas”. In the more sophisticated arguments of this type, one can end up having an entire army of epsilons ")#mi("\\epsilon_1, \\epsilon_2, \\epsilon_3, \\ldots")#text(" that one needs to manage, in particular choosing each epsilon carefully to be sufficiently small compared to other parameters (including other epsilons), while of course avoiding an impossibly circular situation in which a parameter is ultimately required to be small with respect to itself, which is absurd. This art of ")#emph[#text("epsilon management")]#text(", once mastered, is not terribly difficult – it basically requires one to mentally keep track of which quantities are “small”, “very small”, “very very small”, and so forth – but when these arguments get particularly lengthy, then epsilon management can get rather tedious, and also has the effect of making these arguments unpleasant to read. In particular, any given assertion in hard analysis usually comes with a number of unsightly quantifiers (For every ")#mi("\\epsilon")#text(" there exists an N…) which can require some thought for a reader to parse. This is in contrast with soft analysis, in which most of the quantifiers (and the epsilons) can be cleanly concealed via the deployment of some very useful terminology; consider for instance how many quantifiers and epsilons are hidden within, say, the ")#link("http://en.wikipedia.org/wiki/Heine-Borel_theorem")[#text("Heine-Borel theorem")]#text(": “a subset of a Euclidean space is compact if and only if it is closed and bounded”.")

#text("For those who practice hard analysis for a living (such as myself), it is natural to wonder if one can somehow “clean up” or “automate” all the epsilon management which one is required to do, and attain levels of elegance and conceptual clarity comparable to those in soft analysis, hopefully without sacrificing too much of the “elementary” or “finitary” nature of hard analysis in the process.")

#metadata(none) <tao-9427a470592f7c21561f>#text("One important step in this direction has been the development of various types of ")#emph[#text("asymptotic notation")]#text(", such as the Hardy notation of using unspecified constants C, the ")#link("http://en.wikipedia.org/wiki/Landau_notation")[#text("Landau notation")]#text(" of using O() and o(), or the Vinogradov notation of using symbols such as ")#mi("\\ll")#text(" or ")#mi("\\lesssim")#text("; each of these symbols, when properly used, absorbs one or more of the ambient quantifiers in a hard analysis statement, thus making these statements easier to read. But, as useful as these notations are, they still fall a little short of fully capturing one’s intuition regarding orders of magnitude. For instance, we tend to think of any quantity of the form O(1) as being “bounded”, and we know that bounded objects can be combined to form more bounded objects; for instance, if x=O(1) and y=O(1), then x+y=O(1) and xy=O(1). But if we attempt to formalise this by trying to create the set ")#mi("A := \\{ x \\in {\\Bbb R}: x = O(1) \\}")#text(" of all bounded numbers, and asserting that this set is then closed under addition and multiplication, we are speaking nonsense; the O() notation cannot be used within the ")#link("http://en.wikipedia.org/wiki/Axiom_of_specification")[#text("axiom schema of specification")]#text(", and so the above definition of A is meaningless.")

#text("There is however, a way to make concepts such as “the set of all bounded numbers” precise and meaningful, by using ")#link("http://en.wikipedia.org/wiki/Non-standard_analysis")[#text("non-standard analysis")]#text(", which is the most well-known of the “pseudo-finitary” approaches to analysis, in which one adjoins additional numbers to the standard number system. Similarly for “bounded” replaced by “small”, “polynomial size”, etc.. Now, in order to set up non-standard analysis one needs a (non-principal) ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilter")]#text(" (or an equivalent gadget), which tends to deter people from wanting to hear more about the subject. Because of this, most treatments of non-standard analysis tend to gloss over the actual ")#text("construction")#text(" of non-standard number systems, and instead emphasise the various ")#text("benefits")#text(" that these systems offer, such as a rigorous supply of ")#link("http://en.wikipedia.org/wiki/Infinitesimal")[#text("infinitesimals")]#text(", and a general ")#link("http://en.wikipedia.org/wiki/Transfer_principle")[#text("transfer principle ")]#text("that allows one to convert statements in standard analysis into equivalent ones in non-standard analysis. This transfer principle (which requires the ultrafilter to prove) is usually recommended to be applied only at the very beginning and at the very end of an argument, so that the bulk of the argument is carried out purely in the non-standard universe.")

#text("I feel that one of the reasons that non-standard analysis is not embraced more widely is because the transfer principle, and the ultrafilter that powers it, is often regarded as some sort of “black box” which mysteriously bestows some certificate of rigour on non-standard arguments used to prove standard theorems, while conveying no information whatsoever on what the quantitative bounds for such theorems should be. Without a proper understanding of this black box, a mathematician may then feel uncomfortable with ")#text("any")#text(" non-standard argument, no matter how impressive and powerful the result.")

#text("The purpose of this post is to try to explain this black box from a “hard analysis” perspective, so that one can comfortably and productively transfer into the non-standard universe whenever it becomes convenient to do so (in particular, it can become cost-effective to do this whenever the burden of epsilon management becomes excessive, and one is willing to not make certain implied constants explicit).")

#text("— What is an ultrafilter? —")

#text("In order to do all this, we have to tackle head-on the notorious concept of a non-principal ultrafilter. Actually, these ultrafilters are not as impossible to understand as their reputation suggests; they are basically a consistent set of rules which allow one to always take limits (or make similar decisions) whenever necessary.")

#text("To motivate them, let us recall some of the properties of convergent sequences from undergraduate real analysis. If ")#mi("x_n")#text(" is a convergent sequence of real numbers (where n ranges in the natural numbers), then we have a limit ")#mi("\\lim x_n")#text(", which is also a real number. In addition to the usual analytical interpretations, we can also interpret the concept of a limit as a ")#link("http://en.wikipedia.org/wiki/Voting_system")[#text("voting system")]#text(", in which the natural numbers n are the voters, which are each voting for a real number ")#mi("x_n")#text(", and the limit ")#mi("\\lim x_n")#text(" is the elected “winner” emerging from all of these votes. One can also view the limit (somewhat non-rigorously) as the ")#link("http://en.wikipedia.org/wiki/Expected_value")[#text("expected value")]#text(" of ")#mi("x_n")#text(" when n is a “randomly chosen” natural number. Ignoring for now the issue that the natural numbers do not admit a uniform probability measure, it is intuitively clear that such a “randomly chosen” number is almost surely going to be larger than any fixed finite number, and so almost surely ")#mi("x_n")#text(" will be arbitrarily close to the limit ")#mi("\\lim x_n")#text(" (thus we have a sort of “")#link("http://en.wikipedia.org/wiki/Concentration_of_measure")[#text("concentration of measure")]#text("“).")

#text("These limits obey a number of laws, including")

#enum(start: 1, 
[#text("(Algebra homomorphism) If ")#mi("x_n, y_n")#text(" are convergent sequences, and c is a real number, then ")#mi("\\lim 1 = 1")#text(", ")#mi("\\lim c x_n = c \\lim x_n")#text(", ")#mi("\\lim x_n + y_n = \\lim x_n + \\lim y_n")#text(", and ")#mi("\\lim (x_n y_n) = (\\lim x_n) (\\lim y_n)")#text(". (In particular, all sequences on the left-hand side are convergent.)")],
[#text("(Boundedness) If ")#mi("x_n")#text(" is a convergent sequence, then ")#mi("\\inf x_n \\leq \\lim x_n \\leq \\sup x_n")#text(". (In particular, if ")#mi("x_n")#text(" is non-negative, then so is ")#mi("\\lim x_n")#text(".)")],
[#text("(Non-principality) If ")#mi("x_n")#text(" and ")#mi("y_n")#text(" are convergent sequences which differ at only finitely many values of n, then ")#mi("\\lim x_n = \\lim y_n")#text(". [Thus, no individual voter has any influence on the outcome of the election!]")],
[#text("(Shift invariance) If ")#mi("x_n")#text(" is a convergent sequence, then for any natural number h we have ")#mi("\\lim x_{n+h} = \\lim x_n")#text(".")]
)

#text("These properties are of course very useful in computing the limits of various convergent sequences. It is natural to wonder if it is possible to generalise the notion of a limit to cover various non-convergent sequences, such as the class ")#mi("l^\\infty({\\Bbb N})")#text(" of ")#emph[#text("bounded")]#text(" sequences. There are of course many ways to do this in the literature (e.g. if one considers series instead of sequences, one has ")#link("http://en.wikipedia.org/wiki/Cesaro_summation")[#text("Cesàro summation")]#text(", ")#link("http://en.wikipedia.org/wiki/Zeta_function_regularization")[#text("zeta function regularisation")]#text(", etc.), but (as observed by Euler) one has to give up at least one of the above four limit laws if one wants to evaluate the limit of sequences such as ")#mi("0,1,0,1,0,1,\\ldots")#text(". Indeed, if this sequence had a limit x, then the algebra homomorphism laws force ")#mi("x^2 = x")#text(" and thus x is either 0 or 1; on the other hand, the algebra homomorphism laws also show us that ")#mi("1,0,1,0,\\ldots")#text(" has a limit 1-x, and hence by shift invariance we have x = 1-x, which is inconsistent with the previous discussion. In the voting theory interpretation, the problem here is one of lack of consensus: half of the voters want 0 and the other half want 1, and how can one consistently and fairly elect a choice from this? Similarly, in the probabilistic interpretation, there is no concentration of measure; a randomly chosen ")#mi("x_n")#text(" is not close to its expected value of 1/2, but instead fluctuates randomly between 0 and 1.")

#text("So, to define more general limits, we have to give up something. We shall give up shift-invariance (property 4). In the voting theory interpretation given earlier, this means that we abandon the pretense that the election is going to be “fair”; some voters (or groups of voters) are going to be treated differently than others, due to some arbitrary choices made in designing the voting system. (This is the first hint that the ")#link("http://en.wikipedia.org/wiki/Concentration_of_measure")[#text("axiom of choice")]#text(" will be involved.) Similarly, in the probabilistic interpretation, we will give up the notion that the “random number” n we will choose has a shift-invariant distribution, thus for instance n could have a different distribution than n+1.")

#text("Suppose for the moment that we managed to have an improved concept of a limit which assigned a number, let’s call it ")#mi("p\\!-\\!\\lim x_n")#text(", to any bounded sequence, which obeyed the properties 1-3. It is then easy to see that this p-limit extends the ordinary notion of a limit, because if a sequence ")#mi("x_n")#text(" is convergent, then after modifying the sequence on finitely many elements we can keep the sequence within ")#mi("\\epsilon")#text(" of ")#mi("\\lim x_n")#text(" for any specified ")#mi("\\epsilon > 0")#text(", which implies (by properties 2, 3) that ")#mi("p\\!-\\!\\lim x_n")#text(" stays within ")#mi("\\epsilon")#text(" of ")#mi("\\lim x_n")#text(", and the claim follows.")

#text("Now suppose we consider a ")#emph[#text("Boolean sequence")]#text(" ")#mi("x_n")#text(" – one which takes only the values 0 and 1. Since ")#mi("x_n^2 = x_n")#text(" for all n, we see from property that ")#mi("(p\\!-\\!\\lim x_n)^2 = p\\!-\\!\\lim x_n")#text(", thus ")#mi("p\\!-\\!\\lim x_n")#text(" must also be either 0 or 1. From a voting perspective, the p-limit is a ")#emph[#text("voting system")]#text(": a mechanism for extracting a yes-no answer out of the yes-no preferences of an infinite number of voters.")

#text("Let p denote the collection of all subsets A of the natural numbers such that the indicator sequence of A (i.e. the boolean sequence ")#mi("x_n")#text(" which equals 1 when n lies in A and equals 0 otherwise) has a p-limit of 1; in the voting theory language, p is the collection of all voting blocs who can decide the outcome of an election by voting in unison, while in the probability theory language, p is the collection of all sets of natural numbers of measure 1. It is easy to verify that p has four properties:")

#enum(start: 1, 
[#text("(Monotonicity) If A lies in p, and B contains A, then B lies in p.")],
[#text("(Closed under intersection) If A and B lie in p, then ")#mi("A \\cap B")#text(" also lies in p.")],
[#text("(Dichotomy) If A is any set of natural numbers, either A or its complement lies in p, but not both.")],
[#text("(Non-principality) If one adds (or deletes) a finite number of elements to (or from) a set A, this does not affect whether the set A lies in p.")]
)

#text("A collection p obeying properties 1, 2 is called a ")#link("http://en.wikipedia.org/wiki/Filter_%28mathematics%29")[#text("filter")]#text("; a collection obeying 1,2,3 is called an ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilter")]#text(", and a collection obeying 1,2,3,4 is a ")#emph[#text("non-principal ultrafilter")]#text(". [In contrast, a principal ultrafilter is one which is controlled by a single index ")#mi("n_0")#text(" in the sense that ")#mi("p = \\{ A: n_0 \\in A \\}")#text(". In voting theory language, this is a scenario in which ")#mi("n_0")#text(" is a dictator; in probability language, the random variable n is now a deterministic variable taking the values of ")#mi("n_0")#text(".]")

#text("A property A(n) pertaining to a natural number n can be said to be ")#emph[#text("p-true")]#text(" if the set ")#mi("\\{ n: A(n) \\text{ true}\\}")#text(" lies in p, and ")#emph[#text("p-false")]#text(" otherwise; for instance any tautologically true statement is also p-true. Using the probabilistic interpretation, these notions are analogous to those of “")#link("http://en.wikipedia.org/wiki/Almost_surely")[#text("almost surely")]#text(" true” and “almost surely false” in probability theory. (Indeed, one can view p as being a probability measure on the natural numbers which always obeys a ")#link("http://en.wikipedia.org/wiki/Zero-one_law")[#text("zero-one law")]#text(", though one should caution that this measure is only finitely additive rather than countably additive, and so one should take some care in applying measure-theoretic technology directly to an ultrafilter.)")

#text("Properties 1-3 assert that this notion of “p-truth” obeys the usual laws of propositional logic, e.g. property 2 asserts that if A is p-true and B is p-true, then so is “A and B”, while property 3 is the familiar ")#link("http://en.wikipedia.org/wiki/Law_of_the_excluded_middle")[#text("law of the excluded middle")]#text(" and property 1 is ")#link("http://en.wikipedia.org/wiki/Modus_ponens")[#text("modus ponens")]#text(". This is actually rather remarkable: it asserts that ultrafilter voting systems cannot create ")#link("http://en.wikipedia.org/wiki/Voting_paradox")[#text("voting paradoxes")]#text(", such as those guaranteed by ")#link("http://en.wikipedia.org/wiki/Arrow%27s_theorem")[#text("Arrow’s theorem")]#text(". There is no contradiction here, because Arrow’s theorem only applies to ")#emph[#text("finite")]#text(" (hence ")#emph[#text("compact")]#text(") electorates of voters, which do not support any non-principal ultrafilters. At any rate, we now get a hint of why ultrafilters are such a useful concept in logic and model theory.")

#text("We have seen how the notion of a p-limit creates a non-principal ultrafilter p. Conversely, once one has a non-principal ultrafilter p, one can uniquely recover the p-limit operation. This is easiest to explain using the voting theory perspective. With the ultrafilter p, one can ask yes-no questions of an electorate, by getting each voter to answer yes or no and then seeing whether the resulting set of “yes” voters lies in p. To take a p-limit of a bounded sequence ")#mi("x_n")#text(", say in [0,1], what is going on is that each voter n has his or her own favourite candidate number ")#mi("x_n")#text(" between 0 and 1, and one has to elect a real number x from all these preferences. One can do this by an infinite electoral version of “")#link("http://en.wikipedia.org/wiki/Twenty_questions")[#text("Twenty Questions")]#text("“: one asks all the voters whether x should be greater than 1/2 or not, and uses p to determine what the answer should be; then, if x is to be greater than 1/2, one asks whether x should be greater than 3/4, and so on and so forth. This eventually determines x uniquely; the properties 1-4 of the ultrafilter can be used to derive properties 1-3 of the p-limit.")

#text("A modification of the above argument also lets us take p-limits of any sequence in a compact metric space (or slightly more generally, in any compact ")#link("http://en.wikipedia.org/wiki/Hausdorff_space")[#text("Hausdorff")]#text(" ")#link("http://en.wikipedia.org/wiki/First-countable_space")[#text("first-countable")]#text(" topological space). These p-limits then behave in the expected manner with respect to operations in those categories, such as composition with continuous functions or with direct sum. As for unbounded real-valued sequences, one can still extract a p-limit as long as one works in a suitable compactification of the reals, such as the ")#link("http://en.wikipedia.org/wiki/Extended_real_line")[#text("extended real line")]#text(".")

#text("The reconstruction of p-limits from the ultrafilter p is also analogous to how, in probability theory, the concept of expected value of a (say) non-negative random variable X can be reconstructed from the concept of probability via the integration formula ")#mi("{\\Bbb E}(X) = \\int_0^\\infty {\\Bbb P}(X \\geq \\lambda)\\ d\\lambda")#text(". Indeed, one can define ")#mi("p\\!-\\!\\lim x_n")#text(" to be the supremum of all numbers x such that the assertion ")#mi("x_n > x")#text(" is p-true, or the infimum of all numbers y that ")#mi("x_n < y")#text(" is p-true.")

#text("We have said all these wonderful things about non-principal ultrafilters, but we haven’t actually shown that these amazing objects actually exist. There is a good reason for this – the existence of non-principal ultrafilters requires the axiom of choice (or some slightly weaker versions of this axiom, such as the ")#link("http://en.wikipedia.org/wiki/Boolean_prime_ideal_theorem")[#text("boolean prime ideal theorem")]#text("). Let’s give two quick proofs of the existence of a non-principal ultrafilter:")

#strong[#text("Proof 1")]#text(". Let q be the set of all ")#link("http://en.wikipedia.org/wiki/Cofinite")[#text("cofinite")]#text(" subsets of the natural numbers (i.e. sets whose complement is finite). This is clearly a filter which is ")#emph[#text("proper")]#text(" (i.e. it does not contain the empty set ")#mi("\\emptyset")#text("). Since the union of any chain of proper filters is again a proper filter, we see from ")#link("http://en.wikipedia.org/wiki/Zorn%27s_lemma")[#text("Zorn’s lemma")]#text(" that q is contained in a maximal proper filter p. It is not hard to see that p must then be a non-principal ultrafilter. ")#mi("\\Box")

#strong[#text("Proof 2.")]#text(" Consider the ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93%C4%8Cech_compactification")[#text("Stone–Čech compactification")]#text(" ")#mi("\\beta {\\Bbb N}")#text(" of the natural numbers. Since ")#mi("{\\Bbb N}")#text(" is not already compact, there exists an element p of this compactification which does not lie in ")#mi("{\\Bbb N}")#text(". Now note that any bounded sequence ")#mi("x_n")#text(" on the natural numbers is a bounded continuous function on ")#mi("{\\Bbb N}")#text(" (since ")#mi("{\\Bbb N}")#text(" is discrete) and thus, by definition of ")#mi("\\beta {\\Bbb N}")#text(", extends uniquely to a bounded continuous function on ")#mi("\\beta {\\Bbb N}")#text(", in particular one can evaluate this function at p to obtain a real number ")#mi("x_p")#text(". If one then defines ")#mi("p\\!-\\!\\lim x_n := x_p")#text(" one easily verifies the properties 1-4 of a p-limit, which by the above discussion creates a non-principal ultrafilter (which by abuse of notation is also referred to as p; indeed, ")#mi("\\beta {\\Bbb N}")#text(" is canonically identifiable with the space of all ultrafilters). ")#mi("\\Box")

#text("These proofs are short, but not particularly illuminating. A more informal, but perhaps more instructive, explanation of why non-principal ultrafilters exist can be given as follows. In the voting theory language, our task is to design a complete and consistent voting system for an infinite number of voters. In the cases where there is near-consensus, in the sense that all but finitely many of the voters vote one way or another, the decision is clear – go with the option which is preferred by the infinite voting bloc. But what if an issue splits the electorate with an infinite number of voters on each side? Then what one has to do is make an arbitrary choice – pick one side to go with and completely ")#link("http://en.wikipedia.org/wiki/Disfranchisement")[#text("disenfranchise")]#text(" all the voters on the other side, so that they will have no further say in any subsequent votes. By performing this disenfranchisement, we increase the total number of issues for which our electoral system can reach a consistent decision; basically, any issue which has the consensus of all but finitely many of those voters not yet disenfranchised can now be decided upon in a consistent (though highly unfair) manner. We now continue voting until we reach another issue which splits the remaining pool of voters into two infinite groups, at which point we have to make another arbitrary choice, and disenfranchise another infinite set of voters. Very roughly speaking, if one continues this process of making arbitrary choices “ad infinitum”, then at the end of this transfinite process we eventually exhaust the (uncountable) number of issues one has to decide, and one ends up with the non-principal ultrafilter. (If at any stage of the process one decided to disenfranchise all but finitely many of the voters, then one would quickly end up with a principal ultrafilter, i.e. a dictatorship.) One should take this informal argument with a grain of salt; it turns out that after one has made an infinite number of choices, the infinite number of disenfranchised groups, while individually having no further power to influence elections, can begin having some ")#emph[#text("collective")]#text(" power, basically because property 2 of a filter only guarantees closure under finite intersections and not infinite intersections, and things begin to get rather complicated. At this point, I recommend abandoning the informal picture and returning to Zorn’s lemma :-) .")

#text("With this informal discussion, it is now rather clear why the axiom of choice (or something very much like that axiom) needs to play a role in constructing non-principal ultrafilters. However, one may wonder whether one really needs the full strength of an ultrafilter in applications; to return once again to the voting analogy, one usually does not need to vote on every single conceivable issue (of which there are uncountably many) in order to settle some problem; in practice, there are often only a countable or even finite number of tricky issues which one needs to put to the ultrafilter to decide upon. Because of this, many of the results in soft analysis which are proven using ultrafilters can instead be established using a “poor man’s non-standard analysis” (or “pre-infinitary analysis”) in which one simply does the “voter disenfranchisement” step mentioned above by hand. This step is more commonly referred to as the trick of “passing to a subsequence whenever necessary”, and is particularly popular in the soft analysis approach to PDE and calculus of variations. For instance, to minimise some functional, one might begin with a minimising sequence. This sequence might not converge in any reasonable topology, but it often lies in a sequentially compact set in some weak topology (e.g. by using the sequential version of the ")#link("http://en.wikipedia.org/wiki/Banach-Alaoglu_theorem")[#text("Banach-Alaoglu theorem")]#text("), and so by passing to a subsequence one can force the sequence to converge in this topology. One can continue passing to a subsequence whenever necessary to force more and more types of convergence, and can even diagonalise using the ")#link("http://en.wikipedia.org/wiki/Arzela-Ascoli_theorem")[#text("Arzela-Ascoli argument")]#text(" to achieve a countable number of convergences at once (this is of course the sequential Banach-Alaoglu theorem in disguise); in many cases, one gets such a strong convergence that one can then pass to the limit. Most of these types of arguments could also be equivalently performed by selecting an ultrafilter p at the very beginning, and replacing the notions of limit by p-limit throughout; roughly speaking, the ultrafilter has performed all the subsequence-selection for you in advance, and all your sequences in compact spaces will automatically converge without the need to pass to any further subsequences. (For much the same reason, ultrafilters can be used to simplify a lot of infinitary Ramsey theory, as all the pigeonholing has been done for you in advance.) On the other hand, the “by hand” approach of selecting subsequences explicitly tends to be much more constructive (for instance, it can often be performed without any appeal to the axiom of choice), and can also be more easily converted to a quantitative “hard analysis” argument (for instance, by using the finite convergence principle ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("discussed in earlier posts")]#text(").")

#text("As a concrete example from my own experience, in ")#link("http://front.math.ucdavis.edu/math.AP/0402129")[#text("one of my PDE papers")]#text(" with the “")#link("http://tosio.math.toronto.edu/wiki/index.php/I-team")[#text("I-team")]#text("” (Colliander, Keel, Staffilani, Takaoka, and myself), we had a rather severe epsilon management problem in our “hard analysis” arguments, requiring in fact seven very different small quantities ")#mi("1 \\gg \\eta_0 \\gg \\ldots \\gg \\eta_6 > 0")#text(", with each ")#mi("\\eta_i")#text(" extremely small compared with the previous one. (As a consequence of this and of our inductive argument, our eventual bounds, while quantitative, were extremely large, requiring a ")#emph[#text("nine")]#text("-fold iterated ")#link("http://en.wikipedia.org/wiki/Knuth_arrow")[#text("Knuth arrow")]#text("!) This epsilon management also led to the paper being unusually lengthy (85 pages). Subsequently, (inspired by a later paper of ")#link("http://front.math.ucdavis.edu/0610.5266")[#text("Kenig and Merle")]#text("), I learnt how the use of the above “poor man’s non-standard analysis” could conceal almost all of these epsilons (indeed, due to ")#link("http://tosio.math.toronto.edu/wiki/index.php/Concentration_compactness")[#text("concentration-compactness")]#text(" one can soon pass to a limiting object in which most of the epsilons get sent to zero). Partly because of this, a later paper of ")#link("http://arxiv.org/abs/math.AP/0609692")[#text("myself, Visan, and Zhang on a very similar topic")]#text(", which adopted this softer approach, was significantly shorter (28 pages, although to be fair this paper also relies on an ")#link("http://arxiv.org/abs/math.AP/0609690")[#text("auxiliary 30-page paper")]#text("), though to compensate for this it becomes much more difficult to extract any sort of quantitative bound from the argument.")

#text("For the purposes of non-standard analysis, one non-principal ultrafilter is much the same as any other. But it turns out that if one wants to perform additive operations on the index set n, then there is a special (and very useful) class of non-principal ultrafilters that one can use, namely the ")#emph[#text("idempotent ultrafilters")]#text(". These ultrafilters p almost recover the shift-invariance property (which, as remarked earlier, cannot be perfectly attained for ultrafilters) in the following sense: for p-almost all h, the ultrafilter p is equal to its translate p+h, or equivalently that ")#mi("p\\!-\\!\\lim_h p\\!-\\!\\lim_n x_{n+h} = p\\!-\\!\\lim_n x_n")#text(" for all bounded sequences. (In the probability theory interpretation, in which p-limits are viewed as an expectation, this is analogous to saying that the probability measure associated to p is idempotent under convolution, hence the name). Such ultrafilters can, for instance, be used to give a short proof of ")#link("http://en.wikipedia.org/wiki/IP_set")[#text("Hindman’s theorem")]#text(", which is otherwise rather unpleasant to prove. There are even more special ultrafilters known as ")#emph[#text("minimal idempotent ultrafilters")]#text(", which are quite useful in infinitary Ramsey theory, but these are now rather technical and I will refer the reader to a ")#link("http://www.math.ohio-state.edu/~vitaly/vbkatsiveli20march03.pdf")[#text("survey paper of Bergelson")]#text(" for details. I will note however one amusing feature of these objects; whereas “ordinary” non-principal ultrafilters require an application of Zorn’s lemma (or something similar) to construct them, these more special ultrafilters require ")#emph[#text("multiple")]#text(" applications of Zorn’s lemma – i.e. a nested transfinite induction! Thus these objects are truly deep in the “infinitary” end of the finitary-infinitary spectrum of mathematics.")

#text("— Non-standard models —")

#text("We have now thoroughly discussed non-principal ultrafilters, interpreting them as voting systems which can extract a consistent series of decisions out of a countable number of independent voters. With this we can now discuss non-standard models of a mathematical system. There are a number of ways to build these models, but we shall stick to the most classical (and popular) construction.")

#text("Throughout this discussion we fix a single non-principal ultrafilter p. Now we make the following general definition.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition")]#text(". Let X be any set. The ")#link("http://en.wikipedia.org/wiki/Ultrapower")[#text("ultrapower")]#text(" *X of X is defined to be the collection of all sequences ")#mi("(x_n)")#text(" with entries in X, modulo the equivalence that two sequences ")#mi("(x_n), (y_n)")#text(" are considered equal if they agree p-almost surely (i.e. the statement ")#mi("x_n=y_n")#text(" is p-true).")
]

#text("If X is a class of “standard” objects, we shall view *X as the corresponding class of “nonstandard” objects. Thus, for instance, ")#mi("{\\Bbb R}")#text(" is the class of standard real numbers, and ")#mi("{*}{\\Bbb R}")#text(" is the class of non-standard real (or ")#link("http://en.wikipedia.org/wiki/Hyperreal_number")[#text("hyperreal")]#text(") numbers, with each non-standard real number being uniquely representable (up to p-almost sure equivalence) as an arbitrary sequence of standard real numbers (not necessarily convergent or even bounded). What one has done here is “democratised” the class X; instead of declaring a single object x in X that everyone has to work with, one allows each voter n in a countable electorate to pick his or her own object ")#mi("x_n \\in X")#text(" arbitrarily, and the voting system p will then be used later to fashion a consensus as to the properties of these objects; this is why we can identify any two sets of voter choices which are p-almost surely identical. We shall abuse notation a little bit and use sequence notation ")#mi("(x_n)")#text(" to denote a non-standard element, even though strictly speaking one should deal with equivalence classes of sequences (just like how an element of an ")#link("http://en.wikipedia.org/wiki/Lp_space")[#mi("L^p")#text(" space")]#text(" is not, strictly speaking, a single function, but rather an equivalence class of functions that agree almost everywhere).")

#text("One can embed any class X of standard objects in its nonstandard counterpart *X, by identifying an element x with the constant sequence ")#mi("x_n := x")#text("; thus standard objects correspond to unanimous choices of the electorate. This identification is obviously injective. On the other hand, it is rather clear that *X is likely to be significantly larger than X itself.")

#text("Any operation or relation on a class (or several classes) of standard objects can be extended to the corresponding class(es) of nonstandard objects, simply by working pointwise on each n separately. For instance, the sum of two non-standard real numbers ")#mi("(x_n)")#text(" and ")#mi("(y_n)")#text(" is simply ")#mi("(x_n+y_n)")#text("; each voter in the electorate performs the relevant operation (in this case, addition) separately. Note that the fact that these sequences are only defined p-almost surely does not create any ambiguity. Similarly, we say that one non-standard number ")#mi("(x_n)")#text(" is less than another ")#mi("(y_n)")#text(", if the statement ")#mi("x_n < y_n")#text(" is p-true. And so forth. There is no direct interaction between different voters (which, in view of the lack of shift invariance, is a good thing); it is only through the voting system p that there is any connection at all between all of the individual voters.")

#text("For similar reasons, any property that one can define on a standard object, can also be defined on a non-standard object. For instance, a non-standard integer ")#mi("m = (m_n)")#text(" is prime iff the statement “")#mi("m_n")#text(" is prime” is p-true; a non-standard function ")#mi("f = (f_n)")#text(" is continuous iff the statement “")#mi("f_n")#text(" is continuous” is p-true; and so forth. Basically, if you want to know anything about a non-standard object, go put your question to all the voters, and then feed the answers into the ultrafilter p to get the answer to your question. The properties 1-4 (actually, just 1-3) of the ultrafilter ensure that you will always get a consistent answer out of this.")

#text("It is then intuitively obvious that any “simple” property that a class of standard objects has, will be automatically inherited by its nonstandard counterpart. For instance, since addition is associative in the standard real numbers, it will be associative in the non-standard real numbers. Since every non-zero standard real number is invertible in the standard real numbers, so is every non-zero non-standard real number (why?). Because ")#link("http://en.wikipedia.org/wiki/Fermat%27s_last_theorem")[#text("Fermat’s last theorem")]#text(" is true for standard natural numbers, it is true for non-standard natural numbers (why?). And so forth. Now, what exactly does “simple” mean? Roughly speaking, any statement in ")#link("http://en.wikipedia.org/wiki/First-order_logic")[#text("first-order logic")]#text(" will transfer over from a standard class to a non-standard class, as long as the statement does not itself use p-dependent terms such as “standard” or “non-standard” anywhere. One could state a formal version of this principle here, but I find it easier just to work through examples such as the ones given above to get a sense of why this should be the case.")

#text("Now the opposite is also true; any statement in first-order logic, avoiding p-dependent terms such as standard and non-standard, which is true for non-standard classes of objects, is automatically true for standard classes also. This follows just from applying the above principle to the ")#emph[#text("negation ")]#text("of the statement one is interested in. Suppose for instance that one has somehow managed to prove the ")#link("http://en.wikipedia.org/wiki/Twin_prime_conjecture")[#text("twin prime conjecture")]#text(" for non-standard natural numbers. To see why this then implies the twin prime conjecture for standard natural numbers, we argue by contraduction. If the statement “the twin prime conjecture failed” was true for standard natural numbers, then it would also be true for non-standard natural numbers (it is instructive to work this out explicitly), a contradiction.")

#text("That’s the ")#emph[#text("transfer principle")]#text(" in a nutshell; informally, everything which avoids p-dependent terminology and which is true in standard mathematics, is also true in non-standard mathematics, and vice versa. Thus the two models are ")#emph[#text("syntactically")]#text(" equivalent, even if they are ")#emph[#text("semantically")]#text(" rather different. So, if the two models of mathematics are equivalent, why bother working in the latter, which looks much more complicated? It is because in the non-standard model one acquires some additional useful adjectives, such as “standard”. Some of the objects in one’s classes are standard, and others are not. One can use this new adjective (and some others which we will define shortly) to perform manipulations in the non-standard universe which have no obvious counterpart in the standard universe. One can then hope to use those manipulations to eventually end up at a non-trivial new theorem in the standard world, either by arriving at a statement in the non-standard world which no longer uses adjectives such as “standard” and can thus be fed into the transfer principle, or else by using some other principles (such as the overspill principle) to convert a non-standard statement involving p-dependent adjectives into a standard statement. It’s similar to how, say, one can find a real root of a real polynomial by embedding the real numbers in the complex numbers, performing some mathematical manipulations in the complex domain, and then verifying that the complex-valued answer one gets is in fact real-valued.")

#text("Let’s give an example of a non-standard number. Let ")#mi("\\omega")#text(" be the non-standard natural number (n), i.e. the sequence ")#mi("0, 1, 2, 3, \\ldots")#text(" (up to p-almost sure equivalence, of course). This number is larger than any standard number; for instance, the standard number 5 corresponds to the sequence ")#mi("5, 5, 5, \\ldots")#text("; since n exceeds 5 for all but finitely many values of n, we see that ")#mi("n > 5")#text(" is p-true and hence ")#mi("\\omega > 5")#text(". More generally, let us say that a non-standard number is ")#emph[#text("limited")]#text(" if its magnitude is bounded by a standard number, and ")#emph[#text("unlimited")]#text(" otherwise; thus ")#mi("\\omega")#text(" is unlimited. The notion of “limited” is analogous to the notion of being O(1) discussed earlier, but unlike the O() notation, there are no implicit quantifiers that require care to manipulate (though as we shall see shortly, the difficulty has not gone away completely).")

#text("One also sees, for instance, that ")#mi("2\\omega")#text(" is larger than the sum of ")#mi("\\omega")#text(" and any limited number, that ")#mi("\\omega^2")#text(" is larger than the product of ")#mi("\\omega")#text(" with any limited number, and so forth. It is also clear that the sum or product of any two limited numbers is limited. The number ")#mi("1/\\omega")#text(" has magnitude smaller than any positive standard real number and is thus considered to be an ")#emph[#text("infinitesimal")]#text(". Using p-limits, we quickly verify that every limited number x can be uniquely expressed as the sum of a standard number st(x) and an infinitesimal number x-st(x). (The map ")#mi("x \\mapsto st(\\log_\\omega x)")#text(", by the way, is a homomorphism from the ")#link("http://en.wikipedia.org/wiki/Semiring")[#text("semiring ")]#text("of non-standard positive reals to the ")#link("http://en.wikipedia.org/wiki/Tropical_geometry")[#text("tropical semiring")]#text(" ")#mi("({\\Bbb R}, \\min, +)")#text(", and thus encodes the correspondence principle between ordinary rings and tropical rings.) The set of standard numbers, the set of limited numbers, and the set of infinitesimal numbers are all subrings of the set of all non-standard numbers. A non-zero number is infinitesimal if and only if its reciprocal is unlimited.")

#text("Now at this point one might be suspicious that one is beginning to violate some of the axioms of the natural numbers or real numbers, in contradiction to the transfer principle alluded to earlier. For instance, the existence of unlimited non-standard natural numbers seems to contradict the ")#link("http://en.wikipedia.org/wiki/Well-ordering_property")[#text("well-ordering property")]#text(": if one defines ")#mi("S \\subset {*}{\\Bbb N}")#text(" to be the set of all unlimited non-standard natural numbers, then this set is non-empty, and so the well-ordering property should then provide a minimal unlimited non-standard number ")#mi("\\inf(S) \\in {*}{\\Bbb N}")#text(". But then ")#mi("\\inf(S)-1")#text(" must be unlimited also, a contradiction. What’s the problem here?")

#text("The problem here is rather subtle: a set of non-standard natural numbers is not quite the same thing as a non-standard set of natural numbers. In symbols: if ")#mi("2^X")#text(" denotes the ")#link("http://en.wikipedia.org/wiki/Power_set")[#text("power set")]#text(" of X, then ")#mi("2^{*{\\Bbb N}} \\not \\equiv *(2^{\\Bbb N})")#text(". Let’s look more carefully. What is a non-standard set ")#mi("A \\in *(2^{\\Bbb N})")#text(" of natural numbers? This is basically a sequence ")#mi("(A_n)")#text(" of sets of natural numbers, one for each voter. Any given non-standard natural number ")#mi("m = (m_n)")#text(" may belong to A or not, depending on whether the statement ")#mi("m_n \\in A_n")#text(" is p-true or not. We can collect all the non-standard numbers m which do belong in A, and call this set ")#mi("\\tilde A")#text("; this is thus an element of ")#mi("2^{*{\\Bbb N}}")#text(". The map ")#mi("A \\mapsto \\tilde A")#text(" from ")#mi("*(2^{\\Bbb N})")#text(" to ")#mi("2^{*{\\Bbb N}}")#text(" turns out to be injective (why? this is the transferred ")#link("http://en.wikipedia.org/wiki/Axiom_of_extensionality")[#text("axiom of extensionality")]#text("), but it is not surjective; there are some sets of non-standard natural numbers which are not non-standard sets of natural numbers, and as such the well-ordering principle, when transferred over from standard mathematics, does not apply to them. This subtlety is all rather confusing at first, but a good rule of thumb is that as long as your set (or function, or whatever) is not defined using p-dependent terminology such as “standard” or “limited”, it will be a non-standard set (or a non-standard function, etc.); otherwise it will merely be a set of non-standard objects (or a function from one non-standard set to another, etc.). [The situation here is similar to that with the adjective “constructive”; not every function from the constructive numbers to the constructive numbers is itself a constructive function, and so forth.]")

#text("It is worth comparing the situation here with that with the O() notation. With O(), the axiom schema of specification is simply inapplicable; one cannot form a set using O() notation inside the definition (though I must admit that I have occasionally been guilty of abusing notation and violating the above rule in my own papers). In non-standard analysis, in contrast, one ")#emph[#text("can ")]#text("use terminology such as “limited” to create sets of non-standard objects, which then enjoy some useful structure (e.g. the set of limited numbers is a ring). It’s just that these sets are not themselves non-standard, and thus not subject to the transfer principle.")

#text("— Example: calculus via infinitesimals —")

#text("Historically, one of the original motivations of non-standard analysis was to make rigorous the manipulations of infinitesimals in calculus. While this is not the main focus of my post here, I will give just one small example of how non-standard analysis is applied in differential calculus. If x and y are two non-standard real numbers, with y positive, we write x=o(y) if x/y is infinitesimal. The key lemma is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(". Let ")#mi("f: {\\Bbb R} \\to {\\Bbb R}")#text(" be a standard function, and let x, L be standard real numbers. We identify f with a non-standard function in the usual manner. Then the following are equivalent:")

#enum(start: 1, 
[#text("f is differentiable at x with derivative f'(x) = L.")],
[#text("For any infinitesimal h, we have ")#tao-math("f(x+h) = f(x) + h L + o(\\left|h\\right|)", block: false)#text(".")]
)
]

#text("Lemma 1 looks very similar to linear Taylor expansion, but note that there are no limits involved (despite the suggestive o() notation); instead, we have the concept of an infinitesimal. The implication of (2.) from (1.) follows easily from the definition of derivative, the transfer principle, and the fact that infinitesimals are smaller in magnitude than any positive standard real number. The implication of (1.) from (2.) can be seen by contradiction; if f is ")#emph[#text("not")]#text(" differentiable at x with derivative L, then (by the axiom of choice) there exists a sequence ")#mi("h_n")#text(" of standard real numbers going to zero, such that the Newton quotient ")#mi("(f(x+h_n)-f(x))/h_n")#text(" is bounded away from L by a standard positive number. One now forms the non-standard infinitesimal ")#mi("h = (h_n)")#text(" and obtains a contradiction to (2.).")

#text("Using this equivalence, one can now readily deduce the usual laws of differential calculus, e.g. the chain rule, product rule, and mean value theorem; the proofs are algebraically almost identical to the usual proofs (especially if one rewrites those proofs in o() notation), but one does not need to deal explicitly with epsilons, deltas, and limits (the ultrafilter has in some sense already done all that for you). The epsilon management is done invisibly and automatically; one does not need to keep track of whether one has to choose epsilon first before selecting delta, or vice versa. In particular, most of the existential quantifiers (“… there exists ")#mi("\\epsilon")#text(" such that …”) have been eliminated, leaving only the more pleasant universal quantifiers (“for every infinitesimal h …”).")

#text("There is one caveat though: Lemma 1 only works when x is ")#emph[#text("standard")]#text(". For instance, consider the standard function ")#mi("f(x) := x^2 \\sin(1/x^3)")#text(", with the convention f(0)=0. This function is everywhere differentiable, and thus extending to non-standard numbers we have ")#tao-math("f(x+h) = f(x) + h f^{\\prime}(x) + o(\\left|h\\right|^2)", block: false)#text(" for all standard x and infinitesimal h. However, the same claim is not true for arbitrary non-standard x; consider for instance what happens if one sets x=-h.")

#text("One can also obtain an analogous characterisation of the Riemann integral: a standard function f is Riemann integrable on an interval [a,b] with integral A if and only if one has")

#mi("A = \\sum_{1 \\leq i < n} f(x^*_i) (x_{i+1}-x_i) + o(1)")

#text("for any non-standard sequence")

#mi("a = x_1 \\leq x_1^* \\leq x_2 \\leq \\ldots \\leq x_{n-1} \\leq x_{n-1}^* \\leq x_n = b")

#text("with ")#mi("\\sup_{1 \\leq i < n} (x_{i+1}-x_i)")#text(" infinitesimal. One can then reprove the usual basic results, such as the fundamental theorem of calculus, in this manner; basically, the proofs are the same, but the limits have disappeared, being replaced by infinitesimals.")

#text("— Big O() notation —")

#text("Big O() notation in standard mathematics can be translated easily into the non-standard setting, as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(". Let ")#mi("f: {\\Bbb N} \\to {\\Bbb C}")#text(" and ")#mi("g: {\\Bbb N} \\to {\\Bbb R}^+")#text(" be standard functions (which can be identified with non-standard functions in the usual manner). Then the following are equivalent.")

#enum(start: 1, 
[#text("f(m) = O(g(m)) in the standard sense, i.e. there exists a standard positive real constant C such that ")#tao-math("\\left|f(m)\\right| \\leq C g(m)", block: false)#text(" for all standard natural numbers n.")],
[#text("|f(m)|/g(m) is limited for every non-standard natural number m.")]
)
]

#text("This lemma is proven similarly to Lemma 1; the implication of (2.) from (1.) is obvious from the transfer principle, while to the implication of (1.) from (2.) is again by contradiction, converting a sequence of increasingly bad counterexamples to (1.) to a counterexample to (2.). Lemma 2 is also a special case of the “overspill principle” in non-standard analysis, which asserts that a non-standard set of numbers which contains arbitrarily large standard numbers, must also contain an unlimited non-standard number (thus the large standard numbers “spill over” to contain some non-standard numbers). The proof of the overspill principle is related to the (specious) argument discussed above in which one tried to derive a contradiction from the set of unlimited natural numbers, and is left as an exercise.")

#text("[In some texts, the notation f = O(g) only requires that ")#tao-math("\\left|f(m)\\right| \\leq C g(m)", block: false)#text(" for all ")#emph[#text("sufficiently large")]#text(" m. The nonstandard counterpart to this is the claim that |f(m)|/g(m)| is limited for every ")#emph[#text("unlimited")]#text(" non-standard m.]")

#text("Because of the above lemma, it is now natural to define the non-standard counterpart of the O() notation: if x, y are non-standard numbers with y positive, we say that x=O(y) if |x|/y is limited. Then the above lemma says that the standard and non-standard O() notations agree for standard functions of one variable. Note how the non-standard version of the O() notation does not have the existential quantifier (“… there exists C such that …”) and so the epsilon management is lessened. If we let ")#mi("{\\mathcal L}")#text(" denote the subring of ")#mi("{*}{\\Bbb R}")#text(" consisting of all limited numbers, then the claim x=y+O(z) can be rewritten as ")#mi("x = y \\text{ mod } z {\\mathcal L}")#text(", thus we see how the O() notation can be viewed algebraically as the operation of quotienting the (non-standard) real numbers by various dilates of the subring ")#mi("{\\mathcal L}")#text(".")

#text("One can now convert many other order-of-magnitude notions to non-standard notation. For instance, suppose one is performing some standard hard analysis involving some large parameter ")#mi("N > 1")#text(", e.g. one might be studying a set of N points in some group or Euclidean space. One often wants to distinguish between quantities which are of polynomial size in N and those which are super-polynomial in size; for instance, these N points might lie in a finite group G, where G has size much larger than N, and one’s application is such that any bound which depends on the size of G will be worthless. Intuitively, the set of quantities which are of polynomial size in N should be closed under addition and multiplication and thus form a sort of subring of the real numbers, though in the standard universe this is difficult to formalise rigorously. But in nonstandard analysis, it is not difficult: we make N non-standard (and G too, in the above example), and declare any non-standard quantity x to be of polynomial size if we have ")#mi("x = O(N^{O(1)})")#text(", or equivalently if ")#mi("\\log x / \\log N")#text(" is limited. We can then legitimately form the set P of all non-standard numbers of polynomial size, and this is in fact a subring of the non-standard real numbers; as before, though, we caution that P is not a non-standard set of reals, and in particular is not a non-standard subring of the reals. Since P ")#emph[#text("is")]#text(" a ring, one can then legitimately apply whatever results from ring theory one pleases to P, bearing in mind though that any sets of non-standard objects one generates using that theory may not necessarily be non-standard objects themselves. At the end of the day, we then use the transfer principle to go back to the original problem in which N is standard.")

#text("As a specific example of this type of thing from my own experience, in ")#link("http://front.math.ucdavis.edu/math.CO/0501313")[#text("one of my papers with Van Vu")]#text(", we had a large parameter n, and had at some point to introduce the somewhat fuzzy notion of a “highly rational number”, by which we meant a rational number a/b whose numerator and denominator were both at most ")#mi("n^{o(n)}")#text(" in magnitude. Such numbers looked like they were forming a field, since the sum, difference, product, or quotient of two highly rational numbers was again highly rational (but with a slightly different rate of decay in the o() notation). Intuitively, one should be able to do any algebraic manipulation on highly rational numbers which is legitimate for true fields (e.g. using Cramer’s rule to invert a non-singular matrix) and obtain an output which is also highly rational, as long as the number of algebraic operations one uses is O(1) rather than, say, O(n). We could not actually formalise this rigorously in our standard notation, and had to resort to informal English sentences to describe this; but one can do everything perfectly rigorously in the non-standard setting by letting n be non-standard, and defining the field F of non-standard rationals a/b where ")#mi("a, b = O(n^{o(n)})")#text("; F is genuinely a field of non-standard rationals (but not a non-standard field of rationals), and so using Cramer’s rule here (but only for matrices of standard size) would be perfectly legitimate. (We did not actually write our argument in this non-standard manner, keeping everything in the usual standard hard analysis setting, but it would not have been difficult to rewrite the argument non-standardly, and there would be some modest simplifications.)")

#text("— A hierarchy of infinitesimals —")

#text("We have seen how, by selecting an ultrafilter p, we can extend the standard real numbers ")#mi("{\\Bbb R}")#text(" to a larger system ")#mi("{*}{\\Bbb R}")#text(", in which the original number system ")#mi("{\\Bbb R}")#text(" becomes a real totally ordered subfield. (Exercise: is ")#mi("{\\Bbb R}")#text(" complete? The answer depends on how one defines one’s terms.) This gives us some new objects, such as the infinitesimal ")#mi("\\eta_0")#text(" given by the sequence ")#mi("1, 1/2, 1/4, 1/8, \\ldots")#text(". This quantity is smaller than any standard positive number, in particular it is infinitesimally smaller than any quantity depending (via standard operations) on standard constants such as 1. One may think of ")#mi("{*}{\\Bbb R}")#text(" as the non-standard extension of ")#mi("{\\Bbb R}")#text(" generated by adjoining ")#mi("\\eta_0")#text("; this is similar to the ")#link("http://en.wikipedia.org/wiki/Field_extension")[#text("field extension")]#text(" ")#mi("{\\Bbb R}(\\eta_0)")#text(", but is much larger, because field extensions are only closed under arithmetic operations, whereas non-standard extensions are closed under ")#emph[#text("all")]#text(" definable operations. For instance, ")#mi("\\exp(1/\\eta_0)")#text(" lies in ")#mi("{*}{\\Bbb R}")#text(" but not in ")#mi("{\\Bbb R}(\\eta_0)")#text(".")

#text("Now it is possible to iterate this process, by introducing an non-standard nonprincipal ultrafilter *p on the non-standard natural numbers ")#mi("{*}{\\Bbb N}")#text(" (or more precisely, an ultrafilter on ")#mi("{*}{\\Bbb N}")#text(" that extends an ultraproduct of nonprincipal ultrafilters on ")#mi("{\\Bbb N}")#text("), and then embedding the field ")#mi("{*}{\\Bbb R}")#text(" inside an even larger system ")#mi("{*}{*}{\\Bbb R}")#text(", whose elements can be identified (modulo *p-almost sure equivalence) with non-standard sequences ")#mi("(x_n)")#text(" of non-standard numbers in ")#mi("{*}{\\Bbb R}")#text(" (where n now ranges over the non-standard natural numbers ")#mi("{*}{\\Bbb N}")#text("); one could view these as “doubly non-standard numbers”. This gives us some “even smaller” infinitesimals, such as the “doubly infinitesimal” number ")#mi("\\eta_1")#text(" given by the non-standard sequence ")#mi("1, \\eta_0, \\eta_0^2, \\eta_0^3, \\ldots")#text(". This quantity is smaller than any standard or (singly) non-standard number, in particular infinitesimally smaller than any positive quantity depending (via standard or singly non-standard operations) on standard or singly non-standard constants such as 1 or ")#mi("\\eta_0")#text(". For instance, it is smaller than ")#mi("1/A(\\lfloor 1/\\eta_0\\rfloor)")#text(", where A is the ")#link("http://en.wikipedia.org/wiki/Ackermann_function")[#text("Ackermann function")]#text(", since the sequence that defines ")#mi("\\eta_1")#text(" is indexed over the non-standard natural numbers and ")#mi("\\eta_0^n")#text(" will drop below ")#mi("1/A(\\lfloor 1/\\eta_0\\rfloor)")#text(" for sufficiently large non-standard n.")

#text("One can continue in this manner, creating a triply infinitesimal quantity ")#mi("\\eta_2")#text(" which is infinitesimally smaller than anything depending on 1, ")#mi("\\eta_0")#text(", or ")#mi("\\eta_1")#text(", and so forth. Indeed one can iterate this construction an absurdly large number of times, though in most applications one only needs an explicitly finite number of elements from this hierarchy. Having this hierarchy of infinitesimals, each one of which is guaranteed to be infinitesimally small compared to ")#emph[#text("any")]#text(" quantity formed from the preceding ones, is quite useful: it lets one avoid having to explicitly write a lot of epsilon-management phrases such as “Let ")#mi("\\eta_2")#text(" be a small number (depending on ")#mi("\\eta_0")#text(" and ")#mi("\\eta_1")#text(") to be chosen later” and “… assuming ")#mi("\\eta_2")#text(" was chosen sufficiently small depending on ")#mi("\\eta_0")#text(" and ")#mi("\\eta_1")#text("“, which are very frequent in hard analysis literature, particularly for complex arguments which involve more than one very small or very large quantity. (My ")#link("http://front.math.ucdavis.edu/math.AP/0402129")[#text("I-team paper referred to earlier")]#text(" is of this type.)")

#text("— Conclusion —")

#text("I hope I have shown that non-standard analysis is not a totally “alien” piece of mathematics, and that it is basically only “one ultrafilter away” from standard analysis. Once one selects an ultrafilter, it is actually relatively easy to swap back and forth from the standard universe and the non-standard one (or to doubly non-standard universes, etc.). This allows one to rigorously manipulate things such as “the set of all small numbers”, or to rigorously say things like “")#mi("\\eta_1")#text(" is smaller than anything that involves ")#mi("\\eta_0")#text("“, while greatly reducing epsilon management issues by automatically concealing many of the quantifiers in one’s argument. One has to take care as to which objects are standard, non-standard, sets of non-standard objects, etc., especially when transferring results between the standard and non-standard worlds, but as long as one is clearly aware of the underlying mechanism used to construct the non-standard universe and transfer back and forth (i.e. as long as one understands what an ultrafilter is), one can avoid difficulty. The main drawbacks to use of non-standard notation (apart from the fact that it tends to scare away some of your audience) is that a certain amount of notational setup is required at the beginning, and that the bounds one obtains at the end are rather ineffective (though, of course, one can always, after painful effort, translate a non-standard argument back into a messy but quantitative standard argument if one desires).")

#text("I plan to discuss some specific translations of some recent hard analysis results (e.g. the sum-product theory of Bourgain) to the non-standard analysis setting some time in the future, in the spirit of other translations such as ")#link("http://www.ams.org/mathscinet-getitem?mr=751150")[#text("van der Dreis and Wilkie’s non-standard proof")]#text(" of ")#link("http://en.wikipedia.org/wiki/Gromov%27s_theorem_on_groups_of_polynomial_growth")[#text("Gromov’s theorem")]#text(" on groups of polynomial growth.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (99)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/19f86090bbdafb63e5413723967942d72d32936735e550513dad291b95f66c5f-496e402e3b1ba204923bce7da6313b07f7d06a479d6b9bdda79a4e537f99801e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jonas")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-44483")[#strong[#text("jonas")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("To wb: I suspect it might be possible to prove the existence of two non-isomorphic non-principial ultrafilters sort of “explicitly” by giving two filters explicitly and proving that they can’t be subsets of isomorphic ultrafilters.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arbeitsblatt 5: Konvergenz in topologischen Räumen « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-48139")[#strong[#text("Arbeitsblatt 5: Konvergenz in topologischen Räumen « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2010")])]

#text("[…] In diesem Abschnitt haben wir wir uns von dem Blog von Terence Tao und Chapitre II, §3 in dem Buch von Stefan Banach, Théorie des Operations Linéaires (1932) unter […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23fc7ff405d1f51d66331593f87e816b3e8404432f2f84295c000e8ed5ddf5d4-fade859661b65b3d00296728055fa6f4b03cc55b1ebc68eb945a8529bc1b7947.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Theo Buehler")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-48173")[#strong[#text("Theo Buehler")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2010")])]

#text("I like the following proof of the existence of a non-principal ultrafilter (or rather a Banach-limit) via Hahn-Banach:")

#text("Look at the subspace ")#mi("U")#text(" of ")#mi("l^{\\infty}(\\mathbb{N})")#text(" generated by the sequences of the form ")#mi("(x_{n} - x_{n+1})")#text(", where ")#mi("(x_{n}) \\in l^{\\infty}(\\mathbb{N})")#text(". The constant sequence ")#mi("(1)")#text(" has distance 1 from ")#mi("U")#text(" so that by Hahn-Banach there is a linear functional ")#mi("\\ell: l^{\\infty}(\\mathbb{N}) \\to \\mathbb{R}")#text(" of norm one such that ")#mi("\\ell((1)) = 1")#text(" and ")#mi("\\ell")#text(" vanishes on $U$.")

#text("By construction, ")#mi("\\ell")#text(" is monotone, shift-invariant and restricts to the usual limit on convergent sequences (this is because ")#mi("U")#text(" contains the space of sequences that converge to zero). Of course, ")#mi("\\ell")#text(" is not multiplicative.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-48232")[#strong[#text("Boolean rings, ultrafilters, and Stone’s representation theorem « Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2010")]

#text("[…] Tao has already written a great introduction to ultrafilters with an eye towards nonstandard analysis. I’d like to introduce them from a different […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nonstandard analysis as a completion of standard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-48283")[#strong[#text("Nonstandard analysis as a completion of standard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2010")])]

#text("[…] this post, we fix a single non-principal ultrafilter on the (standard) natural numbers . (See this previous blog post for some basic discussion of what non-principal ultrafilters are, and how they are used in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Concentration compactness via nonstandard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-48328")[#strong[#text("Concentration compactness via nonstandard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2010")])]

#text("[…] basics of nonstandard analysis are reviewed in this previous blog post (and see also this later post on ultralimit analysis, as well as the most recent post on this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-48827")[#strong[#text("Ultrafilters in topology « Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2010")]

#text("[…] his post on ultrafilters, Terence Tao also uses the closely related “voting” intuition. Here we only consider […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-51530")[#strong[#text("Non-standard analysis link round-up « Matthew’s Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2011")]

#text("[…] 3. Two posts on Terry Tao’s blog: [1] [2]. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-66643")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2011")])]

#text("CAN THE USE OF NON STANDARD ANALYSIS PROVIDE A MATHAMATICAL TOOL WHICH CAN DEVELOPE A ” GENERAL MODEL OF EVERYTHING” WHICH DOES NOT REQUIRE A MULTIPLCITY OF DIMENSIONS")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hilbert’s seventh problem, and powers of 2 and 3 « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-69262")[#strong[#text("Hilbert’s seventh problem, and powers of 2 and 3 « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2011")])]

#text("[…] to make the close to ); however, in order to simplify the exposition (and in particular, to use some nonstandard analysis terminology to reduce the epsilon management), I will establish Proposition 6 with ineffective constants […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-70770")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2011")])]

#text("Hi Terry,")

#text("In Lemma 1 condition 2, should it be f(x+h)=f(x)+hL+o(|h|) instead?")

#text("best,")#linebreak()#text(" Yuncheng")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-70840")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2011")])]

#text("Dear Professor Terry: This may be a question due to my minunderstanding of something. In the second paragraph of ‘A hierarchy of infinitesimals’, in the last sentence it is claimed that since ")#mi("\\eta_0^n")#text(" with drop below ")#mi("1/A(\\lfloor1/\\eta_0\\rfloor)")#text(" for sufficiently large non-standard ")#mi("n")#text(", therefore ")#mi("\\eta_0^n")#text(" is smaller than any standard or singly standard numbers. Does it follow from the fact that any subset of ")#mi("*\\mathbb{N}")#text(" of the form ")#mi("\\{n: n\\geq m\\}")#text(" for some ")#mi("m\\in\\*\\mathbb{R}")#text(" is ")#mi("*p")#text("-almost sure? If so, how to prove it is true?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-70849")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2011")])]

#text("Oops, I was a bit sloppy when I defined *p simply as a “nonstandard ultrafilter” on ")#mi("{*}{\\Bbb N}")#text(". More precisely, *p needs to be an ultrafilter on ")#mi("{*}{\\Bbb N}")#text(" that extends an ultraproduct of a sequence of standard nonprincipal ultrafilters on ")#mi("{\\Bbb N}")#text(". That way, since each standard nonprincipal ultrafilter contains every standard cofinite subset of ")#mi("{\\Bbb N}")#text(", *p will contain any nonstandardly cofinite subset of ")#mi("*{\\Bbb N}")#text(", and in particular will contain ")#mi("\\{n \\in *{\\Bbb N}: n \\geq m\\}")#text(" for any nonstandard natural m.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2076a72d09aeb6d2dc0a830069b2fd23d2d7432736b893d8de296f95d09bc818-43500377ee9847ce9bd2909dbbfc1c6adcb51778e02e0d8f91b31c3b5ce452cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-84489")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2011")])]

#text("I’m confused as to why ")#mi("A=\\{x\\in {\\Bbb R}: x=O(1)\\}")#text(" is meaningless. I’ve never formally studies logic, but as far as I can tell the condition for a real valued function to be O(1) can be expressed as a predicate in first order logic. What is the issue with the axiom schema of specification when using O() notation to define a set?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-84731")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2011")])]

#text("x is a single real number, not a function.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Ultraproducts as a bridge between hard analysis and soft analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-93082")[#strong[#text("254A, Notes 6: Ultraproducts as a bridge between hard analysis and soft analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2011")])]

#text("[…] Logical limits are closely tied with non-standard analysis. Indeed, by applying an ultraproduct construction to standard number systems such as the natural numbers or the reals , one can obtain nonstandard number systems such as the nonstandard natural numbers or the nonstandard real numbers (or hyperreals) . These nonstandard number systems behave very similarly to their standard counterparts, but also enjoy the advantage of containing the standard number systems as proper subsystems (e.g. is a subring of ), which allows for some convenient algebraic manipulations (such as the quotient space construction to create spaces such as ) which are not easily accessible in the purely standard universe. Nonstandard spaces also enjoy a useful completeness property, known as countable saturation, which is analogous to metric completeness (as discussed in this previous blog post) and which will be particularly useful for us in tying together the theory of approximate groups with the theory of Hilbert’s fifth problem. See this previous post for more discussion on ultrafilters and nonstandard analysis. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-129435")[#strong[#text("BI: nonstandard analysis, a small investment | Alex Sisto")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2012")]

#text("[…] nonstandard analysis in a slightly more famous blog than my own, for example you can check out this post. I guess I should explain the very effective quote “a small investment” by Isaac […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Some ingredients in Szemerédi’s proof of Szemerédi’s theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-134683")[#strong[#text("Some ingredients in Szemerédi’s proof of Szemerédi’s theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2012")])]

#text("[…] are far larger than any quantity that appears in the preceding universe, as discussed at the end of this previous blog post. This sequence of universes does end up concealing all the epsilons, but it is not so clear that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec2e562f9e0cbbea8748b9102e416a5f4aa944d2320e2dc55e604dbdd3ede6de-4e7a381651b25620449fcdacefef2f8a03e061a4ca1c3fce8c70010c4e15b92e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sıcak videolar")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-137328")[#strong[#text("sıcak videolar")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2012")])]

#text("like the following proof of the existence of a non-principal ultrafilter (or rather a Banach-limit) via Hahn-Banach:")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-185897")[#strong[#text("Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2012")])]

#text("[…] will assume some familiarity with nonstandard analysis, as covered for instance in these previous blog […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikhail Katz")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-195169")[#strong[#text("Mikhail Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2012")])]

#text("Earlier on this page there was a discussion of Connes’ critique of NSA. The latter was recently analyzed by Kanovei, Katz, and Mormann ")#link("http://dx.doi.org/10.1007/s10699-012-9316-5")[#text("in this article in Foundations of Science")]#text(" (see also [arXiv 1211.0244](")#link("http://arxiv.org/abs/1211.0244")[#text("http://arxiv.org/abs/1211.0244")]#text(")). Here is the abstract:")

#text("> We examine some of Connes’ criticisms of Robinson’s infinitesimals starting in 1995. Connes sought to exploit the Solovay model S as ammunition against non-standard analysis, but the model tends to boomerang, undercutting Connes’ own earlier work in functional analysis. Connes described the hyperreals as both a ‘virtual theory’ and a ‘chimera’, yet acknowledged that his argument relies on the transfer principle. We analyze Connes ‘dart-throwing’ thought experiment, but reach an opposite conclusion. In S, all definable sets of reals are Lebesgue measurable, suggesting that Connes views a theory as being ‘virtual’ if it is not definable in a suitable model of ZFC. If so, Connes’ claim that a theory of the hyperreals is ‘virtual’ is refuted by the existence of a definable model of the hyperreal field due to Kanovei and Shelah. Free ultrafilters aren’t definable, yet Connes exploited such ultrafilters both in his own earlier work on the classification of factors in the 1970s and 80s, and in Noncommutative Geometry, raising the question whether the latter may not be vulnerable to Connes’ criticism of virtuality.")

#text("> We analyze the philosophical underpinnings of Connes’ argument based on Goedel’s incompleteness theorem, and detect an apparent circularity in Connes’ logic. We document the reliance on non-constructive foundational material, and specifically on the Dixmier trace (featured on the front cover of Connes’ magnum opus) and the Hahn-Banach theorem, in Connes’ own framework. We also note an inaccuracy in Machover’s critique of infinitesimal-based pedagogy.")

#text("A brief review of Kanovei-Shelah is ")#link("http://www.ams.org/mathscinet-getitem?mr=2039354")[#text("here.")]#text(" This analysis of Connes’ critique is being discussed ")#link("http://infinitesimals.lms.ac.uk/?p=118")[#text("here.")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-228785")[#strong[#text("Bird’s-eye views of Structure and Randomness (Series) | Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2013")]

#text("[…] Infinities as numbers: purging the epsilons and deltas from proofs (adapted from “Ultrafilters, nonstandard analysis, and epsilon management“) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-235217")[#strong[#text("Infinities as numbers: purging the epsilons and deltas from proofs | Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")]

#text("[…] [1.5] Ultrafilters, non-standard analysis, and epsilon management […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-237439")[#strong[#text("What does Kadison-Singer have to do with Quantum Mechanics? | tcs math - some mathematics of theoretical computer science")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2013")]

#text("[…] identified with , the Stone-Cech compactification of the naturals. See Terry Tao’s notes on ultafilters and Stone-Cech […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-255862")[#strong[#text("Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2013")])]

#text("[…] has as a preferred candidate, and the ultrafilter is used as the election protocol. (See this previous post for further discussion of this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-324626")[#strong[#text("Hindman’s Theorem | Finite Playground")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2014")]

#text("[…] reading the posts on ultrafilters by Terry Tao [1,2], I find the following result […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-452746")[#strong[#text("Ultrafilters – I. the Stone-Čech compactification | the capacity to be alone")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2015")]

#text("[…] Tao’s fantastic voting analogy for ultrafilters is one of my favorite intuitions I’ve ever read. After sitting through a lecture of said […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A nonstandard analysis proof of Szemeredi’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-457534")[#strong[#text("A nonstandard analysis proof of Szemeredi’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2015")])]

#text("[…] extension” component of the argument). But the proof was still quite messy. However, as discussed in this previous blog post, messy finitary proofs can often be cleaned up using nonstandard analysis. Thus, there should be a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-461918")[#strong[#text("What is Gauge? | The Conscience of A Libertarian")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2015")]

#text("[…] infinitesimals such as dx. (There are ways to make the use of infinitesimals rigorous, such as non-standard analysis, but this is not the focus of my post […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sumfree sets in groups | What's new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-466846")[#strong[#text("Sumfree sets in groups | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2016")])]

#text("[…] of the problem in order to keep the complexity of the argument at a reasonable level (cf. my previous blog post on this topic). One drawback of doing so is that we have no effective bounds for the implied […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b2ba8e95e99e6be84d8a407be5212ffee7d3b725b84e774374cf101763563e-3bdd8ba41e6d51a006749a8c3e9485db8f0f9b43debdb44c12fe882760214feb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of saghe")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-467791")[#strong[#text("saghe")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2016")])]

#text("In this link we can see a new approach to nonstandard analysis without using the model theory.")#linebreak()#text(" ")#link("https://hal.inria.fr/hal-01248379/")[#text("https://hal.inria.fr/hal-01248379/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28b6abe6e330f945806803a4b897171d8295578e39967d8b5fdd04e9b7d42672-b6ab20e545b6a2a88585cc511b9f95d74808fa77e014eb9dc2df2f635a1d9259.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph’s conjectures on commuting probability, an ultrafinitary perspective – Random Permutations")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-505191")[#strong[#text("Joseph’s conjectures on commuting probability, an ultrafinitary perspective – Random Permutations")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2018")])]

#text("[…] the proof are simpler from an ultrafinitary perspective, basically because ultrafilters can be used to streamline epsilon management, and I gave one indication of this perspective during the talk. In this post I wish to lay out the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplemental: Weak solutions from the perspective of nonstandard analysis (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-508598")[#strong[#text("254A, Supplemental: Weak solutions from the perspective of nonstandard analysis (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2018")])]

#text("[…] induction that one usually uses to construct ultrafilters (as discussed using a voting metaphor in this post), except that there is generally no need in any given application to perform the induction for any […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A: Problem solving strategies | What's new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-511368")[#strong[#text("245A: Problem solving strategies | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2019")])]

#text("[…] but there are many others (e.g. the proof of existence of non-principal ultrafilters, discussed in this previous post). See my blog post on Zorn’s lemma for more discussion. One subtlety when applying this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-612974")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2020")])]

#text("In the standard world, one cannot “set A := \\{ x \\in {\\Bbb R}: x = O(1) \\} of all bounded numbers” as a set. Isn’t this because ")#mi("O(1)")#text(" means a family of functions and it is fundamentally different to write ")#mi("f")#text(" and ")#mi("f(x)")#text("? (So what one means by, say, “a function ")#mi("x")#text("“, is really a function ")#mi("x\\mapsto x")#text(".)")

#text("So is it correct to define a set like ")#mi("B:=\\{f:\\mathbb{R}\\to\\mathbb{R}\\mid f=O(1)\\}")#text("? Is this with the axiom schema of specification?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-613186")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2020")])]

#text("If one is careful to only apply the ")#mi("O()")#text(" notations to functions ")#mi("x \\mapsto f(x)")#text(" (as opposed to the mathematically equivalent, but philosophically slightly different, concept of a quantity ")#mi("f")#text(" that may potentially depend on a parameter ")#mi("x")#text("), then the set ")#mi("B")#text(" can indeed be constructed using the axiom schema of specification.")

#text("However if one wishes to manipulate functions instead of scalar quantities one has to be careful with abusing the transfer principle that assertions that are known to be true about scalars are also true about functions. For instance, addition of scalars is known to be associative, ")#mi("(a+b)+c=a+(b+c)")#text(", and this automatically transfers to associativity of functions, ")#mi("(f+g)+h=f+(g+h)")#text(" for all functions ")#mi("f,g,h: {\\bf R} \\to {\\bf R}")#text(". On the other hand, the only subrings of the integers ")#mi("{\\bf Z}")#text(" are the integers themselves, however the ring of functions ")#mi("f: {\\bf Z} \\to {\\bf Z}")#text(" from the integers to the integers contains many non-trivial subrings, including the ring ")#mi("\\{ f: {\\bf Z} \\to {\\bf Z}| f = O(1) \\}")#text(" of bounded functions. In nonstandard analysis one can carefully retain a valid version of the transfer principle by making sure one always distinguishes “internal” concepts from “external” ones (with the property of being bounded being in the latter category, for instance). Without something like a nonstandard formalism one should either not identify scalars with functions (e.g., distinguish the constant 27 from the constant function ")#mi("x \\mapsto 27")#text("), or else take care not to abuse the transfer principle.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-612975")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2020")])]

#text("1. For the noon-standard natural number ")#mi("\\omega=(n)")#text(" (up to p-a.s.), is ")#mi("\\omega^2:=(n^2)")#text(" and ")#mi("1/\\omega=(1/n)")#text("? How about ")#mi("\\log_\\omega x")#text("? Is it ")#mi("(\\log_n x)")#text("?")

#text("2. In undergraduate real analysis, there are serval kinds of sequences of real numbers:")

#text("(a) convergent sequences;")#linebreak()#text(" (b) bounded sequences that do not have a limit")#linebreak()#text(" (c) unbounded sequences;")

#text("Do these together form a partition of ")#mi("*\\mathbb{R}")#text(" so that the equivalent classes in ")#mi("*\\mathbb{R}")#text(" is somehow a “finer” partition?")

#text("3. According to the definition, elements in ")#mi("*\\mathbb{R}")#text(" are sequences of real numbers (modulo the p-a.s. equivalence). The notion of sequences is an “easy” one in undergraduate real analysis while that of “p-ture” is not. Can one phrase/develop the notion of “p-true”, and the notion of “non-principal ultrafilter” merely in terms of sequences of real numbers? (One then has a “cheap” yet full version of the non-standard reals ")#mi("*\\mathbb{R}")#text(" that has the notion of ultrafilter.)")

#text("4. Is it correct to say that infinitesimal (non-standard real) is the p-true equivalent class of sequences of real numbers that converge to zero?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-613188")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2020")])]

#text("1. Yes.")

#text("2. (a) and (b) determine the same subset of ")#mi("{}^* {\\bf R}")#text(", namely the bounded nonstandard reals, while (c) determines the complement. (Exercise!)")

#text("3. I do not understand the queestion, but non-principal ultrafilters cannot be (provably) constructed explicitly since there are models of set theory without choice in which non-principal ultrafilters do not exist. This pretty much rules out any attempt to interpret ultrafilter-based objects in terms of more “constructible” notions, such as convergence of sequences.")

#text("4. Yes, bearing in mind that this equivalence class also contains sequences that do not converge to zero in the classical sense, only in the ultrafilter sense.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-613229")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2020")])]

#text("I try to understand what are the possible elements in the non-principal ultrafilter p. By definition, it suffices to understand what boolean sequence ")#mi("x_n")#text(" has a p-limit of 1.")

#text("By property 3 in the limit laws, if ")#mi("x_n")#text(" has p-limit of 1, then it must have infinitely many terms equal to 1. Does this characterize the indicator sequence of ")#mi("A\\in p")#text("?")

#text("It is clear that if the limit of ")#mi("x_n")#text(" is 1, i.e., ")#mi("x_n")#text(" is eventually 1, then the p-limit of ")#mi("x_n")#text(" must 1 as well (since the p-limit extends the notion of limit for convergent sequences).")

#text("But how about the case when the indicator sequence ")#mi("x_n")#text(" has no limit but has infinitely many 1’s? For example, how can one calculate the p-limit for the sequence 1,0,1,0,…?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-613230")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2020")])]

#text("It depends on the choice of ultrafilter ")#mi("p")#text(", which is highly non-unique. Some ultrafilters contain the odd numbers (in which case the ")#mi("p")#text("-limit of ")#mi("1,0,1,0,\\dots")#text(" will be one), while the other ultrafilters contain the even numbers instead (in which case the ")#mi("p")#text("-limit of ")#mi("1,0,1,0,\\dots")#text(" will be zero). So it’s basically up to you whether you deem the odd numbers to be “large” or the even numbers; either choice is permissible in leading to a non-principal ultrafilter.")

#text("To create an non-principal ultrafilter one has to make an infinite number of arbitrary choices like this, which is why one needs (a weak version of) the axiom of choice to even be assured that such an ultrafilter exists. I like to think of an ultrafilter as a device that takes all the arbitrary choices one would potentially use in an analysis argument (e.g., when extracting a convergent subsequence from a bounded sequence) and makes them all upfront, so that one can then conduct the remainder of one’s analysis without making any further such choices.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-613348")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2020")])]

#text("How can one use ")#mi("p")#text("-limits to verify that every limited number ")#mi("x")#text(" can be uniquely expressed as the sum ")#mi("\\mathrm{st}(x)")#text(" and ")#mi("x-\\mathrm{st}(x)")#text("?")

#text("If one knows that ")#mi("x")#text(" can be represented by a convergent sequence, say ")#mi("(a_n)")#text(", then ")#mi("\\mathrm{st}(x)=\\lim a_n")#text(".")

#text("If ")#mi("x")#text(" is represented by a bounded but not convergent sequence,")#linebreak()#text(" say, ")#mi("x=(b_n)=(5,0,5,0,\\cdots)")#text(", what is ")#mi("\\mathrm{st}(x)")#text("? I guess the answer should depend on the choice of ")#mi("p")#text(". In order to be consistent with the convergent case above, one may have ")#mi("\\mathrm{st}(x)=p\\!-\\!\\lim b_n")#text(". If this is true, then uniqueness follows (?) from that of limits and transfer principle.")

#text("If one can show that ")#mi("x-p\\!-\\!\\lim b_n")#text(" is an infinitesimal, then we are done. But this boils down to showing ")#mi("(a_n)")#text(" is an infinitesmal iff its p-limit is zero.")

#text("But I don’t see a clear definition of “infinitesmal”, only the example ")#mi("1/\\omega")#text(".")

#text("Moreover, is ")#mi("p\\!-\\!\\lim a_n=0")#text(" the same as for any real number ")#mi("\\epsilon>0")#text(", ")#mi("a_n<\\epsilon")#text(" is p-true? I don't see how this follows from the axioms of ")#mi("p")#text("-limit.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-613350")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2020")])]

#text("Okay, according to the test, I believe ")#mi("(a_n)")#text(" being an infinitesmal means for any real number ")#mi("\\epsilon>0")#text(", ")#tao-math("\\left|a_n\\right|<\\epsilon", block: false)#text(" is ")#mi("p")#text("-true. But still I don't see how it relates to ")#mi("p\\mathrm{-}\\lim a_n=0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-613418")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2020")])]

#text("If ")#mi("a_n < \\varepsilon")#text(" is ")#mi("p")#text("-true, then ")#mi("p-\\lim a_n \\leq \\varepsilon")#text(". Conversely, if ")#mi("a_n < \\varepsilon")#text(" is not ")#mi("p")#text("-true, then ")#mi("a_n \\geq \\varepsilon")#text(" is ")#mi("p")#text("-true, then ")#mi("p-\\lim a_n \\geq \\varepsilon")#text(". Arguing similarly using ")#mi("-\\varepsilon")#text(" we see that ")#mi("a_n")#text(" is infinitesimal if and only if ")#mi("p-\\lim a_n = 0")#text(".")

#text("If you are interested in pursuing this topic further I would recommend reading a text on nonstandard analysis (e.g., Goldblatt’s “Lectures on the hyperreals”) rather than just working from this blog post. (One could also work through my lecture notes at ")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")]#text(" , which covers this topic in more depth than in this blog post.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-657485")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2022")])]

#text("In the third paragraph below Lemma 1, I think you meant e.g. ")#mi("f(x) := x^3 \\sin(\\frac 1 x)")#text(" instead of ")#mi("f(x): = x \\sin(\\frac 1 {x^3})")#text(" which isn’t differentiable at ")#mi("x =0")#text(".")

#emph[#text("[The function is actually ")#mi("x^2 \\sin(1/x^3)")#text(", which is differentiable at the origin. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the B+B+t theorem | What's new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-2/#comment-684805")[#strong[#text("Notes on the B+B+t theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2024")])]

#text("[…] give below the fold is my attempt to achieve this, although to avoid a complete explosion of “epsilon management” I will still use at one juncture an ergodic theory reduction from the original paper of Kra […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4c3cbf090444a96c0e85a16207ac21f97cce7a3942fbf148791c9d9ab4067f5-3d35b456b55be2b267551ded46d4b726320f478e9bb9257c8935034fea41e933.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Theo")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-3041")[#strong[#text("Theo")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2007")])]

#text("Thanks for the very nice discussion. I’ve been a fan of ultrafilters since learning about them in high school, although, not being in analysis, I haven’t particularly ever needed to use them.")

#text("You suggest that")#linebreak()#text(" ")#emph[#text("Because of this, many of the results in soft analysis which are proven using ultrafilters can instead be established using a “poor man’s non-standard analysis” (or “pre-infinitary analysis”) in which one simply does the “voter disenfranchisement” step mentioned above by hand. This step is more commonly referred to as the trick of “passing to a subsequence whenever necessary”, and is particularly popular in the soft analysis approach to PDE and calculus of variations.")]

#text("This observation should not be taken too strongly: in particular, there are sequences and ultrafilters so that the sequence has no large convergent subsequence. To wit:")

#text("Let’s work just in the closed interval [0,1], and I will use Q to mean the set of rational numbers in [0,1]. Now take a countable ordering p_j of Q (i.e. a bijection between Q and \\N = {1,2,3,…}). For each j, construct a small closed interval A_j = [ p_j – 1/3^(j+1) , p_j + 1/3^(j+1) ]. The A_j don’t quite cover the unit interval, but they do contain an open set that contains all the rational numbers, so they miss at most countable many real numbers — if r_j is the sequence of the missed numbers, then we can put another collection of intervals B_j = [ r_j – 1/3^(j+1) , r_j + 1/3^(j+1) ] around them. There, now together the A_j and the B_j cover the entire unit interval. But notice that the length of each A_j or B_j is only 2/3^(j+1), so any finite union of A_j’s and B_j’s has total length strictly less than 1. In particular, any finite union of these closed intervals necessarily misses an infinite number of rational numbers.")

#text("So let’s pick a (possibly different) sequence q_n that, like p_j, exhausts Q, and for each A_j or B_j define a set of rational numbers X_j = {n : q_n\\not\\in A_j} and Y_j = {n : q_n\\not\\in B_j}. The X_j’s and Y_j’s are such that any finite intersection is infinite, by the previous paragraph, and so generate a proper nonprinciple filter. Extending this filter, via Zorn, to an ultrafilter gives us the desired ultrafilter: q_n can have no large convergent subsequence, because any convergent subsequence must co-finitely land within some A_j or B_j.")

#text("I would also like to ask a question that, not knowing enough analysis or set theory, I’ve been curious about but not spent much time with. You observe that “For the purposes of non-standard analysis, one non-principal ultrafilter is much the same as any other.” A few years ago, after he gave a talk on surreal numbers, I had a brief discussion with John Conway about nonstandard analysis. He observed, ")#emph[#text("if my memory is correct")]#text(", that the following statements are equivalent:")#linebreak()#text(" (1) The continuum hypothesis.")#linebreak()#text(" (2) Given any two nonprinciple ultrafilters on \\N, there’s a bijection of the natural numbers that takes one of these ultrafilters to the other. (Actually, I think his claim was that continuum hypothesis is equivalent to the statement that any two ultraproduct constructions of the hyperreals are (noncanonically) isomorphic, but I believe this is equivalent?)")

#text("So, my question is two-fold. First, is this statement actually correct? Second, is there an easy proof? Neither direction seems particularly obvious to me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f86fecf4e252ff0f29b47fbb310ca0966b1f26a90b45c0d0e6ea304e64fb279-b206b145b0bd9177ec3af0c0107b740dcc04b40f3977407c375e4baa646bcce0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alejandro Rivero")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-3043")[#strong[#text("Alejandro Rivero")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2007")])]

#text("How do you compare the representation of infinitesimals via ultraproducts with more applied (more constructible?) representations such as Alain Connes’s?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-3044")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2007")])]

#text("Hi,")

#text("This is about Theo’s comment.")

#text("“the following statements are equivalent:")#linebreak()#text(" (1) The continuum hypothesis.")#linebreak()#text(" (2) Given any two nonprincipal ultrafilters on \\N, there’s a bijection of the natural numbers that takes one of these ultrafilters to the other.”")

#text("Statement (2) is false, independently of the status of CH. Perhaps Conway was quoting Keisler’s isomorphism theorem? Check Chang-Keisler’s model theory book for the statement of this result (about isomorphism of *ultrapowers* by different ultrafilters). Shelah later eliminated Keisler’s (GCH) assumption, at the cost of requiring ultrafilters on larger objects.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-3045")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2007")])]

#text("Dear Theo,")

#text("I’m not sure I understand your example. It appears to me that the union of all the A_j is Lebesgue measurable with measure at most 1/3 (if I have summed the geometric series correctly), and so the complement of that union in [0,1] is going to have positive measure and thus be uncountable. Also, if it were true that “all convergent sequences cofinitely land in one of the A_j or B_j”, this would imply that every point in [0,1] lies in the interior of one of the A_j or B_j, which would mean that these interiors are an open cover of [0,1] with no finite subcover, contradicting compactness of [0,1].")

#text("It is true though that ultrafilters and the trick of repeated passage to subsequences begin to diverge a bit from each other once one tries to pass to a subsequence an infinite number of times, due to the lack of closure of ultrafilters under countable intersections. It is somewhat of a moot point, though, since once one possesses an ultrafilter, there is no longer any need to consider subsequences at all.")

#text("I’m afraid I don’t know enough about the continuum hypothesis to say anything intelligent about Conway’s comment. (Similarly, I know very little about Connes’ approach to non-standard analysis.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-3046")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2007")]

#text("[…] Ultrafilters, nonstandard analysis, and epsilon management This post is in some ways an antithesis of my previous postings on hard and soft analysis. In those posts, the emphasis […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-3049")[#strong[#text("Filtering out the votes « The Unapologetic Mathematician")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2007")]

#text("[…] out the votes Over at his weblog, Terence Tao has an exploration of non-standard analysis in the language of ultrafilters and referring to intuitions about “voting systems”. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4c3cbf090444a96c0e85a16207ac21f97cce7a3942fbf148791c9d9ab4067f5-3d35b456b55be2b267551ded46d4b726320f478e9bb9257c8935034fea41e933.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Theo")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-3053")[#strong[#text("Theo")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2007")])]

#text("Mrph. I dashed down my so-called example in a bit of a hurry, and didn’t carefully check myself. Of course, as pointed out, it fails miserably; this is what I get for being weak on analysis (of any kind). It is true — I’ve seen a proof, four or five years ago, which looked very little like the solution I almost came up with — that there are ultrafilters and bounded sequences so that the sequence has no large convergent subsequence. For now, I guess, I’ll leave that as an exercise to the reader? I’ll certainly continue to try to remember the solution I had been shown.")

#text("andrescaicedo, thanks for the references. It’s entirely likely that that’s what Conway actually said; as with the other part of my comment, my memory of this material is poorer than I would like.")

#text("Can you provide an example (necessarily, of course, using Choice) of two nonprinciple ultrafilters that are not isomorphic (in the sense of a bijection on \\N)? Is there a counting argument?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-3082")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2007")])]

#text("“Can you provide an example (necessarily, of course, using Choice) of two nonprinciple ultrafilters that are not isomorphic (in the sense of a bijection on \\N)? Is there a counting argument?”")

#text("The simplest proof is indeed a counting argument, There are ")#mi("2^{2^{\\aleph_0}}")#text(" ultrafilters on N and only ")#mi("2^{\\aleph_0}")#text(" bijections (or even functions of any kind) from N to N. More generally, any infinite set X has ")#tao-math("2^{2^{\\left|X\\right|}}", block: false)#text(" ultrafilters. The idea of the proof is to construct a set S of ")#mi("2^{\\aleph_0}")#text(" subsets of N such that any nontrivial finite Boolean combination of them is nonempty (by “nontrivial” I mean “not forced to be empty by the axioms of Boolean algebra”, eg not something like ")#mi("A \\cap A^c")#text("). This means that for any subset T of S, ")#mi("T \\cup \\{A^c:A\\in T^c\\}")#text(" is a filter base, and extending each such set to an ultrafilter yields distinct ultrafilters for each T. Since there are ")#mi("2^{2^{\\aleph_0}}")#text(" subsets of S, there must be ")#mi("2^{2^{\\aleph_0}}")#text(" distinct ultrafilters (and it’s easy to see that there can’t be any more than that).")

#text("Re the original post: “One should take this informal argument with a grain of salt; it turns out that after one has made an infinite number of choices, the infinite number of disenfranchised groups, while individually having no further power to influence elections, can begin having some collective power, basically because property 2 of a filter only guarantees closure under finite intersections and not infinite intersections, and things begin to get rather complicated. At this point, I recommend abandoning the informal picture and returning to Zorn’s lemma :-) .”")

#text("If you just use transfinite induction instead of Zorn’s lemma, you can make the informal argument work with just a small modification: instead of only splitting up the voters that won the previous split, you one-by-one consider every possible split of the entire set of voters, and choose a winning side that is compatible with the choices you’ve made so far. This, of course, amounts to the exact same thing as the Zorn’s lemma argument, but is a good deal more illuminating.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-3091")[#strong[#text("Science After Sunclipse")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2007")]

#strong[#text("Physics Videos")]

#text("I’ve blagged before about physics videos available on the Web. I just heard about SciTalks, a site for gathering and organizing links to videos on scientific and technical topics. This was something I recall Eric and I wishing for just a few wee…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4c3cbf090444a96c0e85a16207ac21f97cce7a3942fbf148791c9d9ab4067f5-3d35b456b55be2b267551ded46d4b726320f478e9bb9257c8935034fea41e933.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Theo")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-3098")[#strong[#text("Theo")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2007")])]

#text("In any case, my original point, that an ultrafilter limit is not necessarily the limit of a large subsequence, is easy enough, when I remember how to do it.")

#text("Let me consider the following filter on ")#mi("{\\mathbb N}^2 = {\\mathbb N}_1 \\cup {\\mathbb N}_2 \\cup {\\mathbb N}_3 \\cup \\dots")#text(", where ")#mi("{\\mathbb N}_i")#text(" is a copy of the natural numbers. I’ll say that a set ")#mi("A")#text(" is large if, for cofinitely many ")#mi("i")#text(", ")#mi("A \\cap {\\mathbb N}_i")#text(" is cofinite. This generates an ultrafilter ")#mi("{\\cal F}")#text(" via Zorn, and the following two kinds of sets are definitely small in ")#mi("{\\cal F}")#text(": sets that are cofinitely contained in only one of the ")#mi("{\\mathbb N}_i")#text("; and sets that have finite intersection with every ")#mi("{\\mathbb N}_i")#text(".")#linebreak()#text(" Now partition the unit interval ")#mi("{}[0,1]")#text(" into pieces ")#mi("{}[1/2,1]")#text(", ")#mi("{}[1/4,1/2]")#text(", etc. Each of these pieces contains countably many rational numbers, so use whatever ordering of the rationals that you like to identify ")#mi("{\\mathbb N}_i")#text(" with ")#mi("{\\mathbb Q} \\cap [1/2^{i-1},1/2^i]")#text(". Putting these all together and, via whatever zig-zagging you prefer, identifying ")#mi("{\\mathbb N}^2 = {\\mathbb N}")#text(", we get an ultrafilter ")#mi("\\cal F")#text(" on ")#mi("{\\mathbb N}")#text(" and a sequence ")#mi("q_n")#text(" (dense) in ")#mi("{}[0,1]")#text(".")#linebreak()#text(" Then ")#mi("\\cal F")#text(" definitely picks a unique limit ")#mi("q \\in [0,1]")#text(", and if ")#mi("q_n")#text(" has any large convergent subsequences, then they definitely converge to ")#mi("q")#text(". There are two (and a half) possibilities:")

#text("(1) If ")#mi("q \\in (1/2^{i-1},1/2^i)")#text(" for some ")#mi("i")#text(", then any large convergent subsequence must be cofinitely in ")#mi("{\\mathbb N}_i")#text(", but all such subsequences are ")#mi("\\cal F")#text("-small.")

#text("(1.5) If ")#mi("q = 1/2^i")#text(", then any large convergent subsequence must be cofinitely within ")#mi("{\\mathbb N}_i \\cup {\\mathbb N}_{i-1}")#text(", but all such subsequences are small.")

#text("(2) If ")#mi("q = 0")#text(", then any large convergent subsequence has only finitely many points in any interval ")#mi("{}[\\epsilon, 1]")#text(" for ")#mi("\\epsilon > 0")#text(", and so certainly has only finitely many points in each and every ")#mi("{\\mathbb N}_i")#text(", and hence is also ")#mi("\\cal F")#text("-small.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-3157")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2007")])]

#text("Dear Alejandro,")

#text("By coincidence, Connes posted on his blog about infinitesimal calculus just last Friday:")#linebreak()#text(" ")#link("http://noncommutativegeometry.blogspot.com/2007/06/infinitesimal-variables.html")[#text("http://noncommutativegeometry.blogspot.com/2007/06/infinitesimal-variables.html")]

#text("From that description, Connes’ “non-standard numbers” are bounded operators on a separable Hilbert space (possibly modulo finite rank operators), and the infinitesimals are the compact operators. If one fixes the Hilbert space as ")#mi("l^2({\\Bbb N})")#text(" and then restricts to the maximal commutative subalgebra of bounded multiplier operators on that space (i.e. ")#mi("l^\\infty({\\Bbb N})")#text("), then the non-standard numbers are bounded sequences (modulo changes in finitely many entries) and the infinitesimals are sequences converging to zero. This is basically the ultrapower construction above, but with the non-principal ultrafilter replaced by the smaller filter of cofinite sets of natural numbers. So one does not need the axiom of choice for Connes’ construction. On the other hand, since one doesn’t have the full properties of an ultrafilter, not everything in standard mathematics transfers over to the non-standard setting. For instance, one cannot take the reciprocal of an infinitesimal in Connes’ framework. On the other hand, Connes’ system is naturally non-commutative. One cute thing: the Fredholm alternative then becomes the non-commutative counterpart of the assertion that the sum of a non-zero standard number and an infinitesimal is invertible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-3158")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2007")])]

#text("Dear Theo,")

#text("Thanks for the corrected example. It’s true that if the ultrafilter p (and thus the non-standard model) is fixed in advance, then there will be bounded sequences of real numbers with no p-large convergent subsequences. Of course, the entire sequence will still converge to some limit x in the p-sense, thus for each epsilon there is a p-large subsequence which stays within epsilon of x. This substitute notion of convergence works just as well as the usual notion of convergence in applications.")

#text("On the other hand, if in the course of a standard argument one needs to refine a sequence into a subsequence a couple times, then one can choose a non-principal ultrafilter p such that all the subsequences one selected in that argument were large (i.e. in p). So any standard argument involving repeated passage to subsequences can be viewed as “secretly” arising from some non-standard model.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-4189")[#strong[#text("Euler’s Nonstandard Nonsense « The Everything Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2007")]

#text("[…] however, I read and understood Terence Tao’s wonderful post on nonstandard analysis using ultrafilters. This has made me very excited about learning […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e8808b23cc01a795b4a00d7d1b3cce920f976431536bcc77d862e5c449599ce-7bd010cffc2472b94f1f447d819dfaf0e8c0da1ddffb1080971cce4d79c21421.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Greineckerer")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-4496")[#strong[#text("Michael Greineckerer")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2007")])]

#text("I think it is worthmaking explicit that the ultrafilters on a set of voters are actually equivalent to voting rules satisfying the conditions of Arrows theorem (not assuming a finite set of voters) and that any set of voters in such a ultrafilter can enforce everything they unanymously want. This was independently proven in:")

#text("1972 A.P. Kirman and D. Sondermann, “Arrow’s theorem, many agents, and invisible dictators”, Journal of Economic Theory 5 (1972), pp. 267–277")

#text("1976 B. Hansson, “The existentce of group preference functions”, Public Choice 28 (1976), pp. 89–98")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-6883")[#strong[#text("Death to triangles! (and life to ultrafilters…) « Mathemusicality")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2007")]

#text("[…] major interests is nonstandard analysis, the very concept of which I used to despise until I read this brilliant post by Terence Tao. If a Fields Medalist says it’s okay, then it must be okay! Actually, what […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-7660")[#strong[#text("Topology and ultrafilters, I « Mort aux Triangles!")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2007")]

#text("[…] topology and background nbornak 9:04 am As much as I’d like to continue the current program of rediscovering model theory in a more categorical setting, I’d like to start a second thread about topology. The final goal of this thread will be to set forth the existence (given the axiom of choice) of non-principal ultrafilters. These are both the condition for the possibility of non-standard analysis and at the same time a reason for marginalizing it, as has already been chronicled by Terence Tao in his superb blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Printer-friendly CSS, and nonfirstorderisability « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-7960")[#strong[#text("Printer-friendly CSS, and nonfirstorderisability « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2007")])]

#text("[…] quite show that (*) is not expressible in first-order logic, but I can come very close, using non-standard analysis. The […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-8073")[#strong[#text("Non-nonstandard Calculus, I « The Everything Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2007")]

#text("[…] came from taking several analysis classes at Smith College from logician Jim Henle. I learned nonstandard analysis from him one summer, but also learned what he called “non-nonstandard analysis”. The […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-14807")[#strong[#text("NSA Bibliography « Mort aux Triangles!")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2007")]

#text("[…] Terrence Tao’s epic blog post on NSA and epsilon-management. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 3: Minimal dynamical systems, recurrence, and the Stone-Cech compactification « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-24185")[#strong[#text("254A, Lecture 3: Minimal dynamical systems, recurrence, and the Stone-Cech compactification « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2008")])]

#text("[…] the underlying group that acts on topological dynamical systems. By doing so, all the epsilon management issues go away, and the subject becomes very algebraic in nature. On the other hand, some […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wb")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-25360")[#strong[#text("wb")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2008")])]

#text("“Can you provide an example (necessarily, of course, using Choice) of two nonprinciple ultrafilters that are not isomorphic (in the sense of a bijection on \\N)?")

#text("For one sense of “provide an example” the answer is")#linebreak()#text(" certainly “no”.")

#text("It is known that there is no formula phi in the language of")#linebreak()#text(" set theory such that ZFC proves that the extension of")#linebreak()#text(" phi is a non-principle ultrafilter on the set of natural numbers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-27048")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2008")])]

#text("Dear professor：")#linebreak()#text(" It’s just a great classroom on Internet! Thank you so much.")

#text("A tiny correction:")

#text("The third paragraph after the four laws of limit, the second sentence: …the ordinary notion of a limit, because “if” a sequence x_n is convergent…")

#text("yours")

#text("Liu")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-27055")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2008")])]

#text("Dear Liu: thanks for the correction!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e7e627c8e03be5b5dcad75884747f92ef8265d89852cd4592b624f5a2316516-161855625ef4c60ef7a3e2d56aab63c441cb3a4ae138c6324f8ae0271a3d4cf5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sagar")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-467995")[#strong[#text("sagar")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2016")])]

#text("Dear Sir , i want to do ph.d in non standard analysis. can you tell me some standard books on non standard analysis")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-468004")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2016")])]

#text("I found Goldblatt’s “lectures on the hyperreals” to be a good introduction.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a8ea6a30bf8725bf34cd893650380ca1787c36713659b687737d0edc1f9a881-897ffdac55e6affa8071f427e28e2aa953ace0a2ded81d6ae18a30b91dafa050.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of misha")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-27742")[#strong[#text("misha")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2008")])]

#text("A while ago I had written a short ")#link("http://en.wikipedia.org/wiki/Hyperreal_number#An_intuitive_approach_to_the_ultrapower_construction")[#text(" section")]#text(" for Wikipedia, in which I tried to explain as simply as possible the ultrafilter construction of hyperreals and the non-standard approach to differentiation. I had put an extra effort into making the notion of an ultrafilter as motivated and palatable as possible. Maybe some people will find it helpful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 15: Geometric limits of Ricci flows, and asymptotic gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-30087")[#strong[#text("285G, Lecture 15: Geometric limits of Ricci flows, and asymptotic gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2008")])]

#text("[…] 1. One could use ultrafilters here in place of subsequences, but this does not significantly affect any of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Global regularity of wave maps III. Large energy from R^{1+2} to hyperbolic spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-30173")[#strong[#text("Global regularity of wave maps III. Large energy from R^{1+2} to hyperbolic spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("[…] the 2006 paper of Kenig and Merle mentioned earlier managed to eliminate a lot of tedious “epsilon management” from the arguments of Colliander et al. (though for a slightly different problem), by using […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 美丽的数 « Liuxiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-31463")[#strong[#text("美丽的数 « Liuxiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2008")])]

#text("[…] 数的出现：就像可以想到的，定义,而相应的，.同样的，。这个数很有意思，事实上，它比任何一个正实数都小。当年牛顿在微积分中引入无穷小量，解决了物理中大量问题，可是这个方法的数学解释却不能令人容忍。后来引入的语言让数学家们足够满意，就告了一个段落。而再后来，有人重新来看牛顿的无穷小量，用方才的方法去严格加以定义，使得“非典型分析”重回历史舞台。这个方法的优点是避开了繁琐的语言，为数学论文的简化可以做出贡献（当然不能牺牲严格性）。这个过程够精彩的，陶哲轩为此还写过一篇文章。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The correspondence principle and finitary ergodic theory « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-32309")[#strong[#text("The correspondence principle and finitary ergodic theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2008")])]

#text("[…] weak sense by an infinite system. (One can make this informal statement more rigorous using nonstandard analysis and/or ultrafilters, but we will not take such an approach here.) Because of this, we obtain a correspondence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of What is a gauge? « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-32704")[#strong[#text("What is a gauge? « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2008")])]

#text("[…] infinitesimals such as dx. (There are ways to make the use of infinitesimals rigorous, such as non-standard analysis, but this is not the focus of my post […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Non-measurable sets via non-standard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-33011")[#strong[#text("Non-measurable sets via non-standard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2008")])]

#text("[…] real number, as the real numbers are not discrete. If however one employs the language of non-standard analysis, then it is possible to make the above argument rigorous, and this is the purpose of my post today. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 什么是ultrafilter « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-33673")[#strong[#text("什么是ultrafilter « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2008")])]

#text("[…] 陶哲轩在博客上的一个帖子对ultrafilter的存在性有一个更有趣的解释，而且还对两种不同的情况有个对比。他称此为“无穷选举”。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, notes 2: Amenability, the ping-pong lemma, and the Banach-Tarski paradox (optional) « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-34783")[#strong[#text("245B, notes 2: Amenability, the ping-pong lemma, and the Banach-Tarski paradox (optional) « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2009")])]

#text("[…] can even create a finitely additive probability measure, for instance by selecting a non-principal ultrafilter and a Følner sequence and defining for all […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73196101058b01a7b5178a5c0b1eb30a5a176e3bc57a7a26d1c49d8e30671304-bab8ee688d0d5fd8fe52d477c3e3eff98ad07799efeccc22e05aee131831a8eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nate Chandler")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-34819")[#strong[#text("Nate Chandler")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2009")])]

#text("One small correction: Under “algebra homomorphism” within the section describing the laws that limits behave, you wrote ")#mi("\\text{lim}{x_n y_n} = \\text{lim}{x_n y_n}")#text("; you meant ")#mi("\\text{lim}{x_n y_n} = \\text{lim}{x_n}\\text{lim}{y_n}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-34822")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2009")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 6: Duality and the Hahn-Banach theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-35264")[#strong[#text("245B, Notes 6: Duality and the Hahn-Banach theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2009")])]

#text("[…] correspondence between the space of generalised limit functionals, and the space of non-principal ultrafilters on , as defined for instance in this blog post. (This exercise may become easier once one is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 10: Compactness in topological spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-35641")[#strong[#text("245B, Notes 10: Compactness in topological spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("[…] Ultrafilters, non-standard analysis, and epsilon management […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 13: Compactification and metrisation (optional) « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-36956")[#strong[#text("245B, Notes 13: Compactification and metrisation (optional) « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2009")])]

#text("[…] with the space of ultrafilters on . (See this post for further discussion of ultrafilters, and this post for further discussion of the relationship of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor Porton")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-37217")[#strong[#text("Victor Porton")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2009")])]

#text("I have discovered an other (that non-standard analysis) approach of analysis without using epsilon-delta notion in my “Algebraic General Topology”:")#linebreak()#text(" ")#link("http://www.mathematics21.org/algebraic-general-topology.html")[#text("http://www.mathematics21.org/algebraic-general-topology.html")]

#text("Particularly I define continuity by an algebraic formula hiding epsilon-delta behind the algebra.")

#text("Recently I also invented limit of arbitrary (not necessarily continuous) function. I put a preliminary idea of this on my site along with other “Algebraic General Topology” articles.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-37568")[#strong[#text("Halmos, Non-Standard Analysis and Names « Gödel’s Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")]

#text("[…] One story that you may like concerns the notion of non-standard analysis. This is an area created by Abraham Robinson to make precise the notion of infinitesimals and infinity that Newton and others used in developing calculus. We have long changed over from this to the and precision of Karl Weierstrass. Sometimes the burden of keeping track of many and can become overwheling. See Terry Tao’s post for a modern view of this. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reading seminar: “Stable group theory and approximate subgroups”‘, by Ehud Hrushovski « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-41843")[#strong[#text("Reading seminar: “Stable group theory and approximate subgroups”‘, by Ehud Hrushovski « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2009")])]

#text("[…] instance, in the language of rings, the non-standard reals are an elementary extension of the standard reals. On the other hand, the reals are not an […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Approximate bases, sunflowers, and nonstandard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-42805")[#strong[#text("Approximate bases, sunflowers, and nonstandard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2009")])]

#text("[…] as . In this note I will show how this equivalence can be made formal using the language of non-standard analysis. This is not a particularly deep (or new) observation, but it is perhaps the simplest example I […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Banach Limites « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-43268")[#strong[#text("Banach Limites « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("[…] diesem Abschnitt lassen wir uns von dem Blog von Terence Tao und Chapitre II, §3 in dem Buch von Stefan Banach [2] unter Nutzung von [2] §36, Aufgabe 4 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-43269")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("There was a recent arXiv paper whose title and abstract looked exciting, in applying nonstandard analysis and ultraf8lters to Physics. But, alas, I don’t think the author knows enough Physics. Still, it is a good reminder not to make unstated assumptions in Physics about the Real Line being all that matters.")

#link("http://arxiv.org/abs/0911.4824")[#text("http://arxiv.org/abs/0911.4824")]#linebreak()#text(" Surprising Properties of Non-Archimedean Field Extensions of the Real Numbers")#linebreak()#text(" Authors: Elemer E. Rosinger")#linebreak()#text(" Comments: This, under the present form, is a replacement that is a two")#linebreak()#text(" part paper in which the new second part was brought together with my")#linebreak()#text(" recently posted arxiv paper, upon the suggestion of the arxiv")#linebreak()#text(" moderators")#linebreak()#text(" Subjects: General Mathematics (math.GM)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultralimit analysis, and quantitative algebraic geometry « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-43422")[#strong[#text("Ultralimit analysis, and quantitative algebraic geometry « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2010")])]

#text("[…] nonstandard analysis, ultrafilters, ultralimit analysis | by Terence Tao I have blogged a number of times in the past about the relationship between finitary (or “hard”, or […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-43865")[#strong[#text("Terry Tao on Ultrafilters, and nonstandard analysis | Models Of Reality")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2010")]

#text("[…] Back in 2007 Terry Tao (Fields medalist Mathematician at UCLA) wrote a blog article on Ultrafilters, nonstandard analysis, and epsilon management. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A computational perspective on set theory « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-43934")[#strong[#text("A computational perspective on set theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2010")])]

#text("[…] (involving only finitely many points or numbers, etc.); I have explored this theme in a number of previous blog posts. So, one may ask: what is the finitary analogue of statements such as Cantor’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c401f7e4f79898a6fb425bcf862082cc7f308c452a7125857b92765ac38d6f4-c595ccf3c86d9e8105aba7e6d050c2aeafc409e88e210556a4c7ee1574692336.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aram harrow")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-44036")[#strong[#text("aram harrow")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2010")])]

#text("I have a dumb question. Non-principle ultrafilters require the axiom of choice (almost). But arguments like “choose delta_3>0 to be a small constant depending on delta_1 and delta_2” obviously do not.")

#text("So is there some strange statement involving deltas and epsilons that you can do with ultrafilters, but not easily simply using strings of \\exists and \\forall signs?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-44039")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2010")])]

#text("It basically depends on how often one appeals to the properties of an ultrafilter. An ultrafilter ")#mi("p")#text(" has various closure and maximality properties which involve arbitrary subsets ")#mi("A")#text(" of the natural numbers – and by Cantor’s theorem, there are uncountably many such subsets. However, when one inspects any given argument using an ultrafilter ")#mi("p")#text(", one finds that one does not need the ultrafilter properties for ")#emph[#text("all")]#text(" subsets ")#mi("A")#text(" of the natural numbers, but typically just finitely many or countably many of these sets would suffice. As such, many arguments involving ultrafilters could also be run using an “incomplete ultrafilter”, which obeys the ultrafilter axioms for some of the subsets of the natural numbers but not for others. (This is similar in spirit to the disenfranchised voter model in the blog post – one does not decide whether a given set ought to belong in the ultrafilter or not until one’s hand is forced, at which point one makes an arbitrary choice.) This already allows one to reduce the amount of choice needed, to something like countable choice or dependent choice. In many cases, one can reduce the amount of choice further, because for the specific sets which one has to choose for the ultrafilter, there is some way to make a canonical choice. Once one has expunged all but finitely many choices, then one should be able to convert what remains of the ultrafilter into a finite chain of quantifiers.")

#text("But there are probably arguments that use the ultrafilter so heavily that one cannot easily disentangle the proof into a finitary, first order proof that completely avoids the axiom of choice. Arguments that use idempotent ultrafilters are probably good candidates for this, as one needs a couple further applications of Zorn’s lemma to get the idempotency. Nevertheless even these arguments can be partially finitised to some extent; there are some recent papers of Henry Towsner achieving this for Hindman’s theorem (which is most easily proven using idempotent ultrafilters).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2134f11eaff4b523bbdbbe969bd5bcd85f458f309ef81db75b8aa8214b4bb374-2db0a8ea6bef585f85534d4a03b19df0e00dc3b26c7a92b45d9e7804a2f25b81.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-491928")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2018")])]

#text("This is true in a lot of problems. For instance Blackwell and Diaconis (1996) [argument in the paper is older than this version] existence of non-measurable set in coin-toss space, assumes a free ultrafilter but uses only some implications of it.")

#text("In general for a class of subsets on natural numbers, if all properties of a free ultrafilter are met (inclusion of supersets, maximal, empty intersection of all sets, inclusion of cofinite sets) except that “closed under intersection” is replaced by “closed under intersection of A in the class and any cofinite set” must this class necessarily be a free ultrafilter? If not, are there examples of such incomplete ultrafilters that are not free ultrafilters in the standard sense.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-44049")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2010")])]

#text("I enjoy your writing. The sentence “the implication of (2.) from (1.) is obvious from the transfer principle, while to the implication of (2.) from (1.) is again by contradiction,” must be an error though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d07e26859da05550fc7ababcb112ce5ef9b83c67c1d2c36bb2c8302d5b5a558-2967ff6cd2462af093d616fa17e0df01c3b3d6282fb046788b798ae2535c9371.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Simon Hickey")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-44054")[#strong[#text("Simon Hickey")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2010")])]

#text("Dear Prof. Tao,")

#text("I am doing an essay on you for the History of Mathematics at the University of Limerick, Ireland. I was wondering would you be able to inform me of the reason behind these blogs and how successful they have been to date.")

#text("Thanking you,")#linebreak()#text(" Simon")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8fe2bfbdc7c2702a3afe4050e7e55a9060e7f4e94fad9a7e7f2702ee2e480b7d-eaa84c8d5df2be9c25972b214d03523b40a47b0867aef38d0df9ea130b0153a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alex")]], [#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/comment-page-1/#comment-44061")[#strong[#text("alex")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2010")])]

#text("I love the really vivid way you described all this stuff, I’ve been struggling to understand ultrafilters for a long time – but the ideas you’ve written about choice (as oracles that update as you query them) and voting make it seem so simple and clear! Thank you!")
]
