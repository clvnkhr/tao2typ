// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/
// Converted to Typst by tao2typ: "2026-10-14T16:36:56.933646+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The closed graph theorem in various categories", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The closed graph theorem in various categories")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 November 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/")[#text("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Given a function ")#mi("{f: X \\rightarrow Y}")#text(" between two sets ")#mi("{X, Y}")#text(", we can form the ")#link("http://en.wikipedia.org/wiki/Graph_of_a_function")[#text("graph")]

#align(center)[#tao-fit-display[#mitex("\\Sigma := \\{ (x,f(x)): x\\in X \\},")]]

#text("which is a subset of the Cartesian product ")#mi("{X \\times Y}")#text(".")

#text("There are a number of “closed graph theorems” in mathematics which relate the regularity properties of the function ")#mi("{f}")#text(" with the closure properties of the graph ")#mi("{\\Sigma}")#text(", assuming some “completeness” properties of the domain ")#mi("{X}")#text(" and range ")#mi("{Y}")#text(". The most famous of these is the ")#link("http://en.wikipedia.org/wiki/Closed_graph_theorem")[#text("closed graph theorem from functional analysis")]#text(", which I phrase as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Closed graph theorem (functional analysis))")]#text(" Let ")#mi("{X, Y}")#text(" be complete normed vector spaces over the reals (i.e. Banach spaces). Then a function ")#mi("{f: X \\rightarrow Y}")#text(" is a continuous linear transformation if and only if the graph ")#mi("{\\Sigma := \\{ (x,f(x)): x \\in X \\}}")#text(" is both linearly closed (i.e. it is a linear subspace of ")#mi("{X \\times Y}")#text(") and topologically closed (i.e. closed in the product topology of ")#mi("{X \\times Y}")#text(").")
]

#text("I like to think of this theorem as linking together qualitative and quantitative notions of regularity preservation properties of an operator ")#mi("{f}")#text("; see ")#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/")[#text("this blog post")]#text(" for further discussion.")

#text("The theorem is equivalent to the assertion that any continuous linear bijection ")#mi("{f: X \\rightarrow Y}")#text(" from one Banach space to another is necessarily an isomorphism in the sense that the inverse map is also continuous and linear. Indeed, to see that this claim implies the closed graph theorem, one applies it to the projection from ")#mi("{\\Sigma}")#text(" to ")#mi("{X}")#text(", which is a continuous linear bijection; conversely, to deduce this claim from the closed graph theorem, observe that the graph of the inverse ")#mi("{f^{-1}}")#text(" is the reflection of the graph of ")#mi("{f}")#text(". As such, the closed graph theorem is a corollary of the ")#link("http://en.wikipedia.org/wiki/Open_mapping_theorem")[#text("open mapping theorem")]#text(", which asserts that any continuous linear ")#emph[#text("surjection")]#text(" from one Banach space to another is open. (Conversely, one can deduce the open mapping theorem from the closed graph theorem by quotienting out the kernel of the continuous surjection to get a bijection.)")

#text("It turns out that there is a closed graph theorem (or equivalent reformulations of that theorem, such as an assertion that bijective morphisms between sufficiently “complete” objects are necessarily isomorphisms, or as an open mapping theorem) in many other categories in mathematics as well. Here are some easy ones:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Closed graph theorem (linear algebra))")]#text(" Let ")#mi("{X, Y}")#text(" be vector spaces over a field ")#mi("{k}")#text(". Then a function ")#mi("{f: X \\rightarrow Y}")#text(" is a linear transformation if and only if the graph ")#mi("{\\Sigma := \\{ (x,f(x)): x \\in X \\}}")#text(" is linearly closed.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Closed graph theorem (group theory))")]#text(" Let ")#mi("{X, Y}")#text(" be groups. Then a function ")#mi("{f: X \\rightarrow Y}")#text(" is a group homomorphism if and only if the graph ")#mi("{\\Sigma := \\{ (x,f(x)): x \\in X \\}}")#text(" is closed under the group operations (i.e. it is a subgroup of ")#mi("{X \\times Y}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Closed graph theorem (order theory))")]#text(" Let ")#mi("{X, Y}")#text(" be totally ordered sets. Then a function ")#mi("{f: X \\rightarrow Y}")#text(" is monotone increasing if and only if the graph ")#mi("{\\Sigma := \\{ (x,f(x)): x \\in X \\}}")#text(" is totally ordered (using the ")#link("http://en.wikipedia.org/wiki/Product_order")[#text("product order")]#text(" on ")#mi("{X \\times Y}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Similar results to the above three theorems (with similarly easy proofs) hold for other algebraic structures, such as rings (using the usual ")#link("http://en.wikipedia.org/wiki/Product_of_rings")[#text("product of rings")]#text("), ")#link("http://en.wikipedia.org/wiki/Module_(mathematics)")[#text("modules")]#text(", ")#link("http://en.wikipedia.org/wiki/Algebra_over_a_field")[#text("algebras")]#text(", or ")#link("http://en.wikipedia.org/wiki/Lie_algebra")[#text("Lie algebras")]#text(", ")#link("http://en.wikipedia.org/wiki/Groupoid")[#text("groupoids")]#text(", or even ")#link("http://en.wikipedia.org/wiki/Category")[#text("categories")]#text(" (a map between categories is a functor iff its graph is again a category). (ADDED IN VIEW OF COMMENTS: further examples include ")#link("http://en.wikipedia.org/wiki/Affine_space")[#text("affine spaces")]#text(" and ")#link("http://en.wikipedia.org/wiki/G-set")[#mi("{G}")#text("-sets")]#text(" (sets with an action of a given group ")#mi("{G}")#text(").) There are also various approximate versions of this theorem that are useful in ")#link("http://en.wikipedia.org/wiki/Arithmetic_combinatorics")[#text("arithmetic combinatorics")]#text(", that relate the property of a map ")#mi("{f}")#text(" being an “approximate homomorphism” in some sense with its graph being an “approximate group” in some sense. This is particularly useful for this subfield of mathematics because there are currently more theorems about approximate groups than about approximate homomorphisms, so that one can profitably use closed graph theorems to transfer results about the former to results about the latter.")
]

#text("A slightly more sophisticated result in the same vein:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Closed graph theorem (point set topology))")]#text(" Let ")#mi("{X, Y}")#text(" be compact Hausdorff spaces. Then a function ")#mi("{f: X \\rightarrow Y}")#text(" is continuous if and only if the graph ")#mi("{\\Sigma := \\{ (x,f(x)): x \\in X \\}}")#text(" is topologically closed.")
]

#text("Indeed, the “only if” direction is easy, while for the “if” direction, note that if ")#mi("{\\Sigma}")#text(" is a closed subset of ")#mi("{X \\times Y}")#text(", then it is compact Hausdorff, and the projection map from ")#mi("{\\Sigma}")#text(" to ")#mi("{X}")#text(" is then a bijective continuous map between compact Hausdorff spaces, which is then ")#link("http://en.wikipedia.org/wiki/Open_and_closed_maps")[#text("closed")]#text(", thus open, and hence a homeomorphism, giving the claim.")

#text("Note that the compactness hypothesis is necessary: for instance, the function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" defined by ")#mi("{f(x) := 1/x}")#text(" for ")#mi("{x \\neq 0}")#text(" and ")#mi("{f(0)=0}")#text(" for ")#mi("{x=0}")#text(" is a function which has a closed graph, but is discontinuous.")

#text("A similar result (but relying on a much deeper theorem) is available in algebraic geometry, as I learned after asking ")#link("http://mathoverflow.net/questions/113858/is-there-an-algebraic-geometry-analogue-of-the-closed-graph-theorem")[#text("this MathOverflow question")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Closed graph theorem (algebraic geometry))")]#text(" Let ")#mi("{X, Y}")#text(" be ")#link("http://en.wikipedia.org/wiki/Normal_variety")[#text("normal")]#text(" ")#link("http://en.wikipedia.org/wiki/Projective_variety")[#text("projective varieties")]#text(" over an algebraically closed field ")#mi("{k}")#text(" of characteristic zero. Then a function ")#mi("{f: X \\rightarrow Y}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Regular_map_(algebraic_geometry)")[#text("regular map")]#text(" if and only if the graph ")#mi("{\\Sigma := \\{ (x,f(x)): x \\in X \\}}")#text(" is ")#link("http://en.wikipedia.org/wiki/Zariski_topology")[#text("Zariski-closed")]#text(".")
]

#emph[#text("Proof:")]#text(" (Sketch) For the only if direction, note that the map ")#mi("{x \\mapsto (x,f(x))}")#text(" is a regular map from the projective variety ")#mi("{X}")#text(" to the projective variety ")#mi("{X \\times Y}")#text(" and is thus a ")#link("http://en.wikipedia.org/wiki/Projective_morphism")[#text("projective morphism")]#text(", hence is ")#link("http://en.wikipedia.org/wiki/Proper_morphism")[#text("proper")]#text(". In particular, the image ")#mi("{\\Sigma}")#text(" of ")#mi("{X}")#text(" under this map is Zariski-closed.")

#text("Conversely, if ")#mi("{\\Sigma}")#text(" is Zariski-closed, then it is also a projective variety, and the projection ")#mi("{(x,y) \\mapsto x}")#text(" is a projective morphism from ")#mi("{\\Sigma}")#text(" to ")#mi("{X}")#text(", which is clearly ")#link("http://en.wikipedia.org/wiki/Quasi-finite_morphism")[#text("quasi-finite")]#text("; by the characteristic zero hypothesis, it is also ")#link("http://en.wikipedia.org/wiki/Separated_morphism")[#text("separated")]#text(". Applying (Grothendieck’s form of) ")#link("http://en.wikipedia.org/wiki/Zariski%27s_main_theorem")[#text("Zariski’s main theorem")]#text(", this projection is the composition of an open immersion and a finite map. As projective varieties are ")#link("http://en.wikipedia.org/wiki/Complete_variety")[#text("complete")]#text(", the open immersion is an isomorphism, and so the projection from ")#mi("{\\Sigma}")#text(" to ")#mi("{X}")#text(" is finite. Being injective and separable, the degree of this finite map must be one, and hence ")#mi("{k(\\Sigma)}")#text(" and ")#mi("{k(X)}")#text(" are isomorphic, hence (by normality of ")#mi("{X}")#text(") ")#mi("{k[\\Sigma]}")#text(" is contained in (the image of) ")#mi("{k[X]}")#text(", which makes the map from ")#mi("{X}")#text(" to ")#mi("{\\Sigma}")#text(" regular, which makes ")#mi("{f}")#text(" regular. ")#mi("\\Box")

#text("The counterexample of the map ")#mi("{f: k \\rightarrow k}")#text(" given by ")#mi("{f(x) := 1/x}")#text(" for ")#mi("{x \\neq 0}")#text(" and ")#mi("{f(0) := 0}")#text(" demonstrates why the projective hypothesis is necessary. The necessity of the normality condition (or more precisely, a weak normality condition) is demonstrated by (the projective version of) the map ")#mi("{(t^2,t^3) \\mapsto t}")#text(" from the cusipdal curve ")#mi("{\\{ (t^2,t^3): t \\in k \\}}")#text(" to ")#mi("{k}")#text(". (If one restricts attention to smooth varieties, though, normality becomes automatic.) The necessity of characteristic zero is demonstrated by (the projective version of) the inverse of the Frobenius map ")#mi("{x \\mapsto x^p}")#text(" on a field ")#mi("{k}")#text(" of characteristic ")#mi("{p}")#text(".")

#text("There are also a number of closed graph theorems for topological groups, of which the following is typical (see Exercise 3 of ")#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/")[#text("these previous blog notes")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Closed graph theorem (topological group theory))")]#text(" Let ")#mi("{X, Y}")#text(" be ")#mi("{\\sigma}")#text("-compact, locally compact Hausdorff groups. Then a function ")#mi("{X \\rightarrow Y}")#text(" is a continuous homomorphism if and only if the graph ")#mi("{\\Sigma := \\{ (x,f(x)): x \\in X \\}}")#text(" is both group-theoretically closed and topologically closed.")
]

#text("The hypotheses of being ")#mi("{\\sigma}")#text("-compact, locally compact, and Hausdorff can be relaxed somewhat, but I doubt that they can be eliminated entirely (though I do not have a ready counterexample for this).")

#text("In several complex variables, it is a classical theorem (see e.g. Lemma 4 of ")#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/")[#text("this blog post")]#text(") that a holomorphic function from a domain in ")#mi("{{\\bf C}^n}")#text(" to ")#mi("{{\\bf C}^n}")#text(" is locally injective if and only if it is a local diffeomorphism (i.e. its derivative is everywhere non-singular). This leads to a closed graph theorem for complex manifolds:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 (Closed graph theorem (complex manifolds))")]#text(" Let ")#mi("{X, Y}")#text(" be complex manifolds. Then a function ")#mi("{f: X \\rightarrow Y}")#text(" is holomorphic if and only if the graph ")#mi("{\\Sigma := \\{ (x,f(x)): x \\in X \\}}")#text(" is a complex manifold (using the complex structure inherited from ")#mi("{X \\times Y}")#text(") of the same dimension as ")#mi("{X}")#text(".")
]

#text("Indeed, one applies the previous observation to the projection from ")#mi("{\\Sigma}")#text(" to ")#mi("{X}")#text(". The dimension requirement is needed, as can be seen from the example of the map ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" defined by ")#mi("{f(z) =1/z}")#text(" for ")#mi("{z \\neq 0}")#text(" and ")#mi("{f(0)=0}")#text(".")

#text("(ADDED LATER:) There is a real analogue to the above theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (Closed graph theorem (real manifolds))")]#text(" Let ")#mi("{X, Y}")#text(" be real manifolds. Then a function ")#mi("{f: X \\rightarrow Y}")#text(" is continuous if and only if the graph ")#mi("{\\Sigma := \\{ (x,f(x)): x \\in X \\}}")#text(" is a real manifold of the same dimension as ")#mi("{X}")#text(".")
]

#text("This theorem can be proven by applying ")#link("http://en.wikipedia.org/wiki/Invariance_of_domain")[#text("invariance of domain")]#text(" (discussed in ")#link("https://terrytao.wordpress.com/2011/06/13/brouwers-fixed-point-and-invariance-of-domain-theorems-and-hilberts-fifth-problem/")[#text("this previous post")]#text(") to the projection of ")#mi("{\\Sigma}")#text(" to ")#mi("{X}")#text(", to show that it is open if ")#mi("{\\Sigma}")#text(" has the same dimension as ")#mi("{X}")#text(".")

#text("Note though that the analogous claim for ")#emph[#text("smooth")]#text(" real manifolds fails: the function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" defined by ")#mi("{f(x) := x^{1/3}}")#text(" has a smooth graph, but is not itself smooth.")

#text("(ADDED YET LATER:) Here is an easy closed graph theorem in the symplectic category:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 10 (Closed graph theorem (symplectic geometry))")]#text(" Let ")#mi("{X = (X,\\omega_X)}")#text(" and ")#mi("{Y = (Y,\\omega_Y)}")#text(" be smooth symplectic manifolds of the same dimension. Then a smooth map ")#mi("{f: X \\rightarrow Y}")#text(" is a symplectic morphism (i.e. ")#mi("{f^* \\omega_Y = \\omega_X}")#text(") if and only if the graph ")#mi("{\\Sigma := \\{(x,f(x)): x \\in X \\}}")#text(" is a Lagrangian submanifold of ")#mi("{X \\times Y}")#text(" with the symplectic form ")#mi("{\\omega_X \\oplus -\\omega_Y}")#text(".")
]

#text("In view of the symplectic rigidity phenomenon, it is likely that the smoothness hypotheses on ")#mi("{f,X,Y}")#text(" can be relaxed substantially, but I will not try to formulate such a result here.")

#text("There are presumably many further examples of closed graph theorems (or closely related theorems, such as criteria for inverting a morphism, or open mapping type theorems) throughout mathematics; I would be interested to know of further examples.")

#mi("\\Box")

#heading(level: 1)[#text("Comments (29)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ac0f91483a48a9d93b1977df48bcd89d159e740253d523c87dcbd59fa832ee4-980fe49509e6b765c38f74227c18b5d6baa480d0f2c06444f6d190a0f7bdefc3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The closed graph theorem in various categories « Guzman's Mathematics Weblog")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-194643")[#strong[#text("The closed graph theorem in various categories « Guzman's Mathematics Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2012")])]

#text("[…] The closed graph theorem in various categories. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-194646")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2012")])]

#text("I remember that in one of Thurston’s papers that you mentioned before (I don’t remember the specific title), he listed several (coincidentally 8?) ways of thinking about the derivative (which happens to be discussed in Gowers’s new post today) when he illustrated how people understand mathematics. Can the philosophy of understanding a theorem in different categories here be regarded as kind of the same as that of understanding a concept in Thurston’s paper?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-194663")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2012")])]

#text("I think it’s more of a dual relationship. ")#link("http://arxiv.org/abs/math.HO/9404236")[#text("Thurston talks about")]#text(" using multiple fields of mathematics to gain a better understanding of a single concept. The discussion here is more like using a single concept (or more precisely, a single class of results) to try to gain a better understanding of multiple fields of mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-194652")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2012")])]

#text("In Theorem 6, do you care that Y is normal? It seems like you only use that X is.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-194655")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2012")])]

#text("I think you’re right. In general, the properties of the codomain Y seem to be less important than the properties of the domain X for these theorems (which makes sense, since one is free to enlarge Y at will without really changing anything, whereas one cannot enlarge X at will). For instance, in Theorem 4, Y does not actually need to be totally ordered; in Theorem 3, Y can be a local group (or even a local magma) rather than a global one; and so forth.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/623ccc1a3fa456ec7e05122b382182466686d64ac9f88edd78f9a27a892d3dfd-c13958df334c4b95d556e28a01e2795648da65191ebf569e62f56e7f223667e0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Gowers")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-461538")[#strong[#text("John Gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2015")])]

#text("The opposite is true in the topological case. Here, one direction (continuous implies closed graph) holds whenever ")#mi("Y")#text(" is a Hausdorff space, while the other direction (closed graph implies continuous) holds whenever ")#mi("Y")#text(" is compact. There are no conditions on ")#mi("X")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/623ccc1a3fa456ec7e05122b382182466686d64ac9f88edd78f9a27a892d3dfd-c13958df334c4b95d556e28a01e2795648da65191ebf569e62f56e7f223667e0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Gowers")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-461539")[#strong[#text("John Gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2015")])]

#text("In fact, we can characterize compact spaces an Hausdorff spaces in this way.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-194700")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2012")])]

#text("So the obvious question, is there a categorical version of the theorem, so that all the specializations fall out as corollaries?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-194858")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2012")])]

#text("Looking at the engines that power these theorems, I would be very surprised if the ")#link("http://en.wikipedia.org/wiki/Baire_category_theorem")[#text("Baire category theorem")]#text(", ")#link("http://en.wikipedia.org/wiki/Zariski%27s_main_theorem")[#text("Zariski’s main theorem")]#text(", and ")#link("http://en.wikipedia.org/wiki/Invariance_of_domain")[#text("invariance of domain")]#text(" could be deduced from a common universal result. (Also, while the same sort of counterexamples show up in many different contexts, such as the “1/x if x is nonzero and 0 if x is zero” function, or roots ")#mi("x \\mapsto x^{1/p}")#text(", it seems that very different hypotheses are needed to eliminate these potential counterexamples in different cases, and it does not look like they are easily tied together under a single category-theoretic framework.) But I think what might be realistic is to have a common category-theoretic ")#emph[#text("description")]#text(" of what a closed graph theorem is, and how it is equivalent to other related results (such as open mapping theorems, or invertibility criteria for morphisms).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e8412f888c569a9be1ea171fca277001b3529b40fd5b744477630ab233b68c-05bad328c0ff3a76596d1574691a67abec98c1884bc3f88e4c852126de63b9c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mircea petrache")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-194714")[#strong[#text("mircea petrache")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2012")])]

#text("A basic principle underlying some of the examples is that if a group G acts on spaces X,Y then f is is equivariant provided g acts on the graph by diagonal action. (This is purely formal: G being a group is unnecessary. It basically suffices that gx, gy have a fixed meaning for g in G, x in X, y in Y.) In general, it seems that the presence of a Closed Graph Theorem is a sign that in the given category morphisms and products are defined so that they fit well together.")

#emph[#text("[G-sets are a good example, and certainly linked to many of the other “algebraic” examples given; I’ve added them to the list. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8173daa61f80b674375fabf3cc300a58d8b78253834b35d8828048234180582a-915c722ea51bff490b1c5db1258d704dba6ed772e687940456cd1004f79c9692.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim Sullivan")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-194740")[#strong[#text("Tim Sullivan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2012")])]

#text("It seems that there’s a lot of switching back and forth between “f” and “T” throughout the post, even within the same sentence at times…")

#emph[#text("[Corrected, thanks. For some strange reason I didn’t notice any dissonance in having two names for the same object during proofreading… -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-194742")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2012")])]

#text("So it seems to me like a closed graph theorem for a category of sets and functions indicates that that category embeds as a natural subcategory of some category of sets and relations. For example, there is a category whose objects are groups and whose morphisms are relations between groups (that is, subgroups of their product) where composition is given by composition of relations. One might also call these categories of correspondences after the example of algebraic geometry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-194845")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2012")])]

#text("Related to theorem 2: affine spaces/affine maps obey the same principle. ")#emph[#text("[Added to the list, thanks -T.]")]

#text("Categorically, a graph of a morphism f can be constructed by taking equalizer of two morphisms ")#mi("f \\circ \\pi_1, \\pi_2 : X \\times Y \\to Y")#text(" but I’m unsure if this could lead to a categorical characterization of closed graph theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-194847")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2012")])]

#text("Typo: f: X\\to Y, with graph \\{(x,Tx)\\}. One of f or T should be edited!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-194875")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2012")])]

#text("One possible further addition to the list would be a closed graph theorem in the spirit of Theorem 6 for the category of finite etale covers of a fixed variety (without any need to assume normality or projectiveness, though I am not sure whether one can drop characteristic zero), basically because the degree argument used in the proof of Theorem 6 should also work in this category (though I am not 100% certain of this…). This should also be morally equivalent to the closed graph theorem for finite G-sets, where G is the etale fundamental group.")

#text("[ADDED LATER: it seems that in order for this to work, it is not enough for the graph of the putative morphism to be Zariski-closed; it must also be a finite etale cover of the base variety.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-194945")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2012")])]

#text("A very nice post. The closed graph theorem for Banach spaces is a good example of a theorem that is often lectured in a way I dislike: you’re told the statement and the proof and then expected to be able to apply it. As a result, I spent several years not really understanding it properly. It was OK if the question said “By using the closed graph theorem, prove that X,” but how was one to spot for oneself that the closed graph theorem might be useful? After seeing enough applications I eventually understood the answer (or more likely ")#emph[#text("an")]#text(" answer). A function ")#mi("f")#text(" is continuous if ")#mi("f(x_n)\\to f(x)")#text(" whenever ")#mi("x_n\\to x")#text(". But if the function ")#mi("f")#text(" is a linear map between Banach spaces, then the closed graph theorem allows you to get away with establishing a weaker fact: it is enough to show that if ")#mi("x_n\\to x")#text(" ")#emph[#text("and")]#text(" ")#mi("f(x_n)")#text(" ")#emph[#text("converges to something")]#text(", then that something must be ")#mi("f(x)")#text(". In other words, we want to prove that ")#mi("f(x_n)\\to f(x)")#text(" and can give ourselves a big leg up by assuming that ")#mi("f(x_n)")#text(" is a convergent sequence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cb3280d4a3ac59b59c4cf2c33043f35c9d5c9f277083c51cc4b2e3163aa25a7-6a9cd9f58b7183b2038ce7a394dc5461cc80a5a1b8a2711b65195916592b725c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo de Almeida")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-194989")[#strong[#text("Marcelo de Almeida")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2012")])]

#text("Reblogged this on ")#link("http://nucaltiado.wordpress.com/2012/11/22/365/")[#text("Being simple")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cb3280d4a3ac59b59c4cf2c33043f35c9d5c9f277083c51cc4b2e3163aa25a7-6a9cd9f58b7183b2038ce7a394dc5461cc80a5a1b8a2711b65195916592b725c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo de Almeida")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-195338")[#strong[#text("Marcelo de Almeida")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2012")])]

#text("A great post. Clarify in many ways the form of look the closed graph theorem by means of the essential structure ")#mi("{X\\times Y}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c75b16fb55a9199d36cd0cb52e126328239db57f1b3551965b59ae949156a55c-4a06b6fee8e4c3c0d0706a18fbaf8c915f242fcc00d1ef624d9983196718da64.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Milad")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-195414")[#strong[#text("Milad")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2012")])]

#text("Reblogged this on ")#link("http://miladebrahimpour.wordpress.com/2012/11/23/149/")[#text("Milad Ebrahimpour 's Blog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-197688")[#strong[#text("Closed Graph Theorem in Various Categories « Francis' Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2012")]

#text("[…] found this interesting blog post on Terence Tao’s blog about various analogs of the closed graph theorem […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Hormander « What’s new")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-198031")[#strong[#text("Lars Hormander « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2012")])]

#text("[…] symplectic form on ; this is another instantiation of the closed graph theorem, as mentioned in this previous post. This graph is known as the canonical relation for the (putative) FIO that is associated to . To […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the classification of complex Lie algebras | What's new")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-226587")[#strong[#text("Notes on the classification of complex Lie algebras | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2013")])]

#text("[…] the graph is that of a Lie algebra isomorphism by the Lie algebra closed graph theorem (see this previous blog post). Since , we see that restricts to the graph of the identity on , and the claim […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cf127bcbc9b576e470595c548d3c5da04feb729c8768bac49238f5862350924-c9ed8a94fe1dbb13f6f62432721bcb333be14cf9e830cfc9747f5a3590281026.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chien")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-255788")[#strong[#text("Chien")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2013")])]

#text("Please help me find a discontinuous linear mapping T:X→Y such that T(X)=Y and X,Y are Banach but T is not open. Thanks you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-431133")[#strong[#text("A closed graph theorem in dcpo’s | polmath")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2014")]

#text("[…] Today I will add one closed graph type theorem to the list made by Terence Tao in his post Closed graph theorem in various categories. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d8a0049a253560a8c5ec09985e3a16a5ba9efed2477e85e3506113fa985d689-6654c14eed8b5e451478326ac435779ba33f248bffa1eab63ff9f60c26bc735e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthias Hübner")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-517211")[#strong[#text("Matthias Hübner")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2019")])]

#text("A little typo after Theorem 6: should be “cuspidal”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d8a0049a253560a8c5ec09985e3a16a5ba9efed2477e85e3506113fa985d689-6654c14eed8b5e451478326ac435779ba33f248bffa1eab63ff9f60c26bc735e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthias Hübner")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-517213")[#strong[#text("Matthias Hübner")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2019")])]

#text("I appreciate John Gowers’ 1. comment: Theorem 5 (Closed graph theorem (point set topology)) is indeed valid more generally. Wikipedia ")#link("https://en.wikipedia.org/wiki/Closed_graph_theorem")[#text("https://en.wikipedia.org/wiki/Closed_graph_theorem")]#text(" has it that if X is a topological space and Y is a compact Hausdorff space, then the graph of f: X->Y is closed iff f is continuous.")#linebreak()#text(" But as John Gowers correctly points out, “continuous implies closed graph” holds if Y is Hausdorff, and for “closed graph implies continuous” compactness of Y is enough. For an indirect proof of the latter, assume f is not continuous at a certain x in X, so a net x_i in X converging to x “witnesses” the discontinuity – f(x_i) stays away from f(x). A subnet of f(x_i) converges to a y in Y (by compactness) different from f(x), so the graph of f is not closed at (x, f(x)).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-525848")[#strong[#text("The topological closed graph theorem – johngowe.rs")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2019")]

#text("[…] are a number of theorems in various settings that link continuity of a function (fcolon X to Y) to closedness of that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-689608")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2026")])]

#text("Dr Tao, why do you choose ∑ as the notation of Graph? I know this question is kind of boring but isn’t this symbol more commonly used to represent summation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/11/20/the-closed-graph-theorem-in-various-categories/#comment-689611")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2026")])]

#text("In geometry, the symbol ")#mi("\\Sigma")#text(" (which, as the upper case version of ")#mi("\\sigma")#text(" in the ")#link("https://en.wikipedia.org/wiki/Greek_alphabet")[#text("Greek alphabet")]#text(", is slightly different from the summation symbol ")#mi("\\sum")#text(") is frequently used to denote a surface (or more generally some sort of manifold or variety).")
]
]
