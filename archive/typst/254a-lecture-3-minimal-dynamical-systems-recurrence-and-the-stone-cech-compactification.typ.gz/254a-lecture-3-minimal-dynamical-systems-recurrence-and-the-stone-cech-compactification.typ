// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/
// Converted to Typst by tao2typ: "2026-10-14T16:35:08.709505+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Lecture 3: Minimal dynamical systems, recurrence, and the Stone-Čech compactification", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Lecture 3: Minimal dynamical systems, recurrence, and the Stone-Čech compactification")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 January 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("We now begin the study of ")#emph[#text("recurrence")]#text(" in topological dynamical systems ")#mi("(X, {\\mathcal F}, T)")#text(" – how often a non-empty open set U in X returns to intersect itself, or how often a point x in X returns to be close to itself. Not every set or point needs to return to itself; consider for instance what happens to the shift ")#mi("x \\mapsto x+1")#text(" on the compactified integers ")#mi("\\{-\\infty\\} \\cup {\\Bbb Z} \\cup \\{+\\infty\\}")#text(". Nevertheless, we can always show that at least one set (from any open cover) returns to itself:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(". (Simple recurrence in open covers) Let ")#mi("(X,{\\mathcal F},T)")#text(" be a topological dynamical system, and let ")#mi("(U_\\alpha)_{\\alpha \\in A}")#text(" be an ")#link("http://en.wikipedia.org/wiki/Open_cover")[#text("open cover")]#text(" of X. Then there exists an open set ")#mi("U_\\alpha")#text(" in this cover such that ")#mi("U_\\alpha \\cap T^n U_\\alpha \\neq \\emptyset")#text(" for infinitely many n.")
]

#strong[#text("Proof")]#text(". By compactness of X, we can refine the open cover to a finite subcover. Now consider an orbit ")#mi("T^{\\Bbb Z} x = \\{ T^n x: n \\in {\\Bbb Z} \\}")#text(" of some arbitrarily chosen point ")#mi("x \\in X")#text(". By the infinite ")#link("http://en.wikipedia.org/wiki/Pigeonhole_principle")[#text("pigeonhole principle")]#text(", one of the sets ")#mi("U_\\alpha")#text(" must contain an infinite number of the points ")#mi("T^n x")#text(" counting multiplicity; in other words, the recurrence set ")#mi("S := \\{ n: T^n x \\in U_\\alpha \\}")#text(" is infinite. Letting ")#mi("n_0")#text(" be an arbitrary element of S, we thus conclude that ")#mi("U_\\alpha \\cap T^{n_0-n} U_\\alpha")#text(" contains ")#mi("T^{n_0} x")#text(" for every ")#mi("n \\in S")#text(", and the claim follows. ")#mi("\\Box")

#strong[#text("Exercise 1")]#text(". Conversely, use Theorem 1 to deduce the infinite pigeonhole principle (i.e. that whenever ")#mi("{\\Bbb Z}")#text(" is coloured into finitely many colours, one of the colour classes is infinite). ")#emph[#text("Hint")]#text(": look at the orbit closure of c inside ")#mi("A^{\\Bbb Z}")#text(", where A is the set of colours and ")#mi("c: {\\Bbb Z} \\to A")#text(" is the colouring function.) ")#mi("\\diamond")

#text("Now we turn from recurrence of sets to recurrence of individual points, which is a somewhat more difficult, and highlights the role of minimal dynamical systems (as introduced in the ")#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/")[#text("previous lecture")]#text(") in the theory. We will approach the subject from two (largely equivalent) approaches, the first one being the more traditional “epsilon and delta” approach, and the second using the ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93%C4%8Cech_compactification")[#text("Stone-Čech compactification")]#text(" ")#mi("\\beta {\\Bbb Z}")#text(" of the integers (i.e. ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilters")]#text(").")

#metadata(none) <tao-5fa5e83f5e441ea81d50>

#text("Before we begin, it will be notationally convenient to place a metric d on our compact metrisable space X [though, as an exercise, the reader is encouraged to recast all the material here in a manner which does not explicitly mention a metric]. There are of course infinitely many metrics that one could place here, but they are all coarsely equivalent in the following sense: if d, d’ are two metrics on X, then for every ")#mi("\\delta > 0")#text(" there exists an ")#mi("\\varepsilon > 0")#text(" such that ")#mi("d^{\\prime}(x,y) < \\delta")#text(" whenever ")#mi("d(x,y) < \\varepsilon")#text(", and similarly with the role d and d’ reversed. This claim follows from the standard fact that continuous functions between compact metric spaces are ")#link("http://en.wikipedia.org/wiki/Uniform_continuity")[#text("uniformly continuous")]#text(". Because of this equivalence, it will not actually matter for any of our results what metric we place on our spaces. For instance, we could endow a Bernoulli system ")#mi("A^{\\Bbb Z}")#text(", where A is itself a compact metrisable space (and thus ")#mi("A^{\\Bbb Z}")#text(" is compact by ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff’s theorem")]#text("), with the metric")

#tao-math("d( (a_n)_{n \\in {\\Bbb Z}}, (b_n)_{n \\in {\\Bbb Z}} ) := \\sum_{n \\in {\\Bbb Z}} 2^{-\\left|n\\right|} d_A(a_n,b_n)", block: false)#text(" (1)")

#text("where ")#mi("d_A")#text(" is some arbitrarily selected metric on A. Note that this metric is not shift-invariant.")

#strong[#text("Exercise 2")]#text(". Show that if A contains at least two points, then the Bernoulli system ")#mi("A^{\\Bbb Z}")#text(" (with the standard shift) cannot be endowed with a shift-invariant metric. (")#emph[#text("Hint")]#text(": find two distinct points which converge to each other under the shift map.) ")#mi("\\diamond")

#text("Fix a metric d. For each n, the shift ")#mi("T^n: X \\to X")#text(" is continuous, and hence uniformly continuous since X is compact, thus for every ")#mi("\\delta > 0")#text(" there exists ")#mi("\\varepsilon > 0")#text(" depending on ")#mi("\\delta")#text(" and n such that ")#mi("d( T^n x, T^n y ) < \\delta")#text(" whenever ")#mi("d(x,y) < \\varepsilon")#text(". However, we caution that the ")#mi("T^n")#text(" need not be uniformly ")#link("http://en.wikipedia.org/wiki/Equicontinuous")[#text("equicontinuous")]#text("; the quantity ")#mi("\\varepsilon")#text(" appearing above can certainly depend on n. Indeed, they need not even be equicontinuous. For instance, this will be the case for the Bernoulli shift with the metric (1) (why?), and more generally for any system that exhibits “mixing” or other chaotic behaviour. At the other extreme, in the case of ")#emph[#text("isometric")]#text(" systems – systems in which T preserves the metric d – the shifts ")#mi("T^n")#text(" are all isometries, and thus are clearly uniformly equicontinuous.")

#text("We can now classify points x in X based on the dynamics of the orbit ")#mi("T^{\\Bbb Z} x := \\{ T^n x: n \\in {\\Bbb Z} \\}")#text(":")

#enum(start: 1, 
[#text("x is ")#emph[#text("invariant")]#text(" if ")#mi("Tx=x")#text(".")],
[#text("x is ")#emph[#text("periodic")]#text(" if ")#mi("T^n x = x")#text(" for some non-zero n.")],
[#text("x is ")#emph[#text("almost periodic")]#text(" if for every ")#mi("\\varepsilon > 0")#text(", the set ")#mi("\\{ n \\in {\\Bbb Z}: d(T^n x, x) < \\varepsilon \\}")#text(" is ")#link("http://en.wikipedia.org/wiki/Syndetic_set")[#text("syndetic")]#text(" (i.e. it has bounded gaps);")],
[#text("x is ")#emph[#text("recurrent")]#text(" if for every ")#mi("\\varepsilon > 0")#text(", the set ")#mi("\\{ n \\in {\\Bbb Z}: d(T^n x, x) < \\varepsilon \\}")#text(" is infinite. Equivalently, there exists a sequence ")#mi("n_j")#text(" of integers with ")#tao-math("\\left|n_j\\right| \\to \\infty", block: false)#text(" such that ")#mi("\\lim_{j \\to \\infty} T^{n_j} x = x")#text(".")]
)

#text("It is clear that every invariant point is periodic, that every periodic point is almost periodic, and every almost periodic point is recurrent. These inclusions are all strict. For instance, in the circle shift system ")#mi("({\\Bbb R}/{\\Bbb Z}, x \\mapsto x + \\alpha)")#text(" with ")#mi("\\alpha \\in {\\Bbb R}")#text(" irrational, it turns out that every point is almost periodic, but no point is periodic.")

#strong[#text("Exercise 3")]#text(". In the boolean Bernoulli system ")#mi("(2^{\\Bbb Z}, A \\mapsto A-1)")#text(", show that the discrete Cantor set")

#mi("x := \\bigcup_{N=1}^\\infty \\{ \\sum_{n=0}^N \\epsilon_n 10^n: \\epsilon_n \\in \\{-1,0,+1\\} \\}")#text(" (2)")

#text("is recurrent but not almost periodic. ")#mi("\\diamond")

#text("In a general topological dynamical system, it is quite possible to have points which are non-recurrent (as the example of the compactified integer shift already shows). But if we restrict to a ")#emph[#text("minimal")]#text(" dynamical system, things get much better:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(". If ")#mi("(X,{\\mathcal F},T)")#text(" is a minimal topological dynamical system, then every element of X is almost periodic (and hence recurrent).")
]

#strong[#text("Proof")]#text(". Suppose for contradiction that we can find a point x of X which is not almost periodic. This means that we can find ")#mi("\\varepsilon > 0")#text(" such that the set ")#mi("\\{ n: d(T^n x, x) < \\varepsilon \\}")#text(" is not syndetic. Thus, for any ")#mi("m > 0")#text(", we can find an ")#mi("n_m")#text(" such that ")#mi("d(T^n x,x) \\geq \\varepsilon")#text(" for all ")#mi("n \\in [n_m-m,n_m+m]")#text(" (say).")

#text("Since X is compact, the sequence ")#mi("T^{n_m} x")#text(" must have at least one limit point y. But then one verifies (using the continuity of the shift operators) that")

#mi("d( T^h y, x ) = \\lim_{m \\to \\infty} d( T^{n_m+h} x, x ) \\geq \\varepsilon")#text(" (3)")

#text("for all h. But this means that the orbit closure ")#mi("\\overline{T^{\\Bbb Z} y}")#text(" of y does not contain x, contradicting the minimality of X. The claim follows. ")#mi("\\Box")

#strong[#text("Exercise 4")]#text(". If x is a point in a topological dynamical system, show that x is almost periodic if and only if it lies in a minimal system. Because of this, almost periodic points are sometimes referred to as ")#emph[#text("minimal")]#text(" points. ")#mi("\\diamond")

#text("Combining Lemma 1 with Lemma 1 of ")#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/")[#text("the previous lecture")]#text(", we immediately obtain the")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Birkhoff recurrence theorem")]#text(". Every topological dynamical system contains at least one point x which is almost periodic (and hence recurrent).")
]

#text("Note that this is stronger than Theorem 1, as can be seen by considering the element ")#mi("U_\\alpha")#text(" of the open cover which contains the almost periodic point. Indeed, we now have obtained a stronger conclusion, namely that the set of return times ")#mi("\\{ n: T^n U_\\alpha \\cap U_\\alpha \\neq \\emptyset \\}")#text(" is not only infinite, it is syndetic.")

#strong[#text("Exercise 5")]#text(". State and prove a version of the Birkhoff recurrence theorem in which the map ")#mi("T: X \\to X")#text(" is continuous but not assumed to be invertible. (Of course, all references to ")#mi("{\\Bbb Z}")#text(" now need to be replaced with ")#mi("{\\Bbb N}")#text(".) ")#mi("\\diamond")

#text("The Birkhoff recurrence theorem does not seem particularly strong, as it only guarantees existence of a single recurrent (or almost periodic point). For general systems, this is inevitable, because it can happen that the majority of the points are non-recurrent (look at the compactified integer shift system, for instance). However, suppose the system is a group quotient ")#mi("(G/\\Gamma, x \\mapsto gx)")#text(". To make this a topological dynamical system, we need G to be a ")#link("http://en.wikipedia.org/wiki/Topological_group")[#text("topological group")]#text(", and ")#mi("\\Gamma")#text(" to be a ")#link("http://en.wikipedia.org/wiki/Cocompact")[#text("cocompact")]#text(" subgroup of G (such groups are also sometimes referred to as ")#emph[#text("uniform")]#text(" subgroups). Then we see that the system is a ")#link("http://en.wikipedia.org/wiki/Homogeneous_space")[#text("homogeneous space")]#text(": given any two points ")#mi("x, y \\in G/\\Gamma")#text(", there exists a group element ")#mi("h \\in G")#text(" such that hx=y. Thus we expect any two points in ")#mi("G/\\Gamma")#text(" to behave similarly to each other. Unfortunately, this does not quite work in general, because the action of h need not preserve the shift ")#mi("x \\mapsto gx")#text(", as there is no reason that h commutes with g. But suppose that g is a ")#link("http://en.wikipedia.org/wiki/Center_%28group_theory%29")[#text("central")]#text(" element of G (which is for instance the case if G is abelian). Then the action of h is now an isomorphism on the dynamical system ")#mi("(G/\\Gamma, x \\mapsto gx)")#text(". In particular, if hx = y, we see that x is almost periodic (or recurrent) if and only if y is. We thus conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(". (Kronecker type approximation theorem) Let ")#mi("(G/\\Gamma, x \\mapsto gx)")#text(" be a topological group quotient dynamical system such that g lies in the centre Z(G) of G. Then ")#emph[#text("every")]#text(" point in this system is almost periodic (and hence recurrent).")
]

#text("Applying this theorem to the torus shift ")#mi("(({\\Bbb R}/{\\Bbb Z})^d, x \\mapsto x+\\alpha)")#text(", where ")#mi("\\alpha = (\\alpha_1,\\ldots,\\alpha_d) \\in {\\Bbb R}^d")#text(" is a vector, we thus obtain that for any ")#mi("\\varepsilon > 0")#text(", the set")

#mi("\\{ n \\in {\\Bbb Z}: \\text{dist}( n \\alpha, {\\Bbb Z}^d ) < \\varepsilon \\}")#text(" (4)")

#text("is syndetic (and in particular, infinite). This should be compared with the classical ")#link("http://en.wikipedia.org/wiki/Kronecker's_theorem")[#text("Kronecker approximation theorem")]#text(".")

#text("It is natural to ask what happens when g is not central. If G is a ")#link("http://en.wikipedia.org/wiki/Lie_group")[#text("Lie group")]#text(" and the action of g on the ")#link("http://en.wikipedia.org/wiki/Lie_algebra")[#text("Lie algebra")]#text(" ")#mi("{\\mathfrak g}")#text(" is ")#link("http://en.wikipedia.org/wiki/Unipotent")[#text("unipotent")]#text(" rather than trivial, then Theorem 2 still holds; this follows from ")#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")[#text("Ratner’s theorem")]#text(", of which we will discuss much later in this course. But the claim is not true for all group quotients. Consider for instance the Bernoulli shift system ")#mi("(X,T) = ( ({\\Bbb Z}/2{\\Bbb Z})^{\\Bbb Z}, T)")#text(", which is isomorphic to the boolean Bernoulli shift system. As the previous examples have already shown, this system contains both recurrent and non-recurrent elements. On the other hand, it is intuitive that this system has a lot of symmetry, and indeed we can view it as a group quotient ")#mi("(G/\\Gamma, x \\mapsto gx)")#text(". Specifically, G is the ")#link("http://en.wikipedia.org/wiki/Lamplighter_group")[#text("lamplighter group")]#text(" ")#mi("G = {\\Bbb Z}/2{\\Bbb Z} \\wr {\\Bbb Z}")#text(". To describe this group, we observe that the group ")#mi("({\\Bbb Z}/2{\\Bbb Z})^{\\Bbb Z}")#text(" acts on X by addition, whilst the group ")#mi("{\\Bbb Z}")#text(" acts on X via the shift map T. The lamplighter group ")#mi("G := ({\\Bbb Z}/2{\\Bbb Z})^{\\Bbb Z} \\times {\\Bbb Z}")#text(" then acts by both addition and shift:")

#mi("(a,n): x \\mapsto T^n x + a")#text(" for all ")#mi("(a,n) \\in G")#text(". (5)")

#text("In order for this to be a group action, we endow G with the multiplication law")

#mi("(a,n) (b,m) := (a + T^n b, n+m)")#text("; (6)")

#text("one easily verifies that this really does make G into a group; if we give G the product topology, it is a topological group. G clearly acts transitively on the compact space X, and so ")#mi("X \\equiv G/\\Gamma")#text(" for some cocompact subgroup ")#mi("\\Gamma")#text(" (which turns out to be isomorphic to ")#mi("{\\Bbb Z}")#text(" – why?). By construction, the shift map T can be expressed using the group element ")#mi("(0,1) \\in G")#text(", and so we have turned the Bernoulli system into a group quotient. Since this system contains non-recurrent points (e.g. the indicator function of the natural numbers) we see that Theorem 2 does not hold for arbitrary group quotients.")

#text("— The ultrafilter approach —")

#text("Now we turn to a different approach to topological recurrence, which relies on compactifying the underlying group ")#mi("{\\Bbb Z}")#text(" that acts on topological dynamical systems. By doing so, all the ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("epsilon management")]#text(" issues go away, and the subject becomes very algebraic in nature. On the other hand, some subtleties arise also; for instance, the compactified object ")#mi("\\beta {\\Bbb Z}")#text(" is not a group, but merely a left-continuous ")#link("http://en.wikipedia.org/wiki/Semigroup")[#text("semigroup")]#text(".")

#text("This approach is based on ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilters")]#text(" or (equivalently) via the ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93%C4%8Cech_compactification")[#text("Stone-Čech compactification")]#text(". Let us recall how this compactification works:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(". (Stone-Čech compactification) Every ")#link("http://en.wikipedia.org/wiki/Locally_compact_Hausdorff")[#text("locally compact Hausdorff")]#text(" (LCH) space X can be ")#link("http://en.wikipedia.org/wiki/Embedding")[#text("embedded")]#text(" in a compact Hausdorff space ")#mi("\\beta X")#text(" in which X is an open dense set. (In particular, if X is already compact, then ")#mi("\\beta X = X")#text(".) Furthermore, any continuous function ")#mi("f: X \\to Y")#text(" between LCH spaces extends uniquely to a continuous function ")#mi("\\beta f: \\beta X \\to \\beta Y")#text(".")
]

#strong[#text("Proof.")]#text(" (Sketch) This proof uses the intuition that ")#mi("\\beta X")#text(" should be the “finest” compactification of X. Recall that a ")#link("http://en.wikipedia.org/wiki/Compactification_%28mathematics%29")[#text("compactification")]#text(" of a LCH space X is any compact Hausdorff space containing X as an open dense set. We say that one compactification Y of X is ")#emph[#text("finer")]#text(" than another Z if there is a surjective continuous map from Y to Z that is the identity on X. (Note that as X is dense in Y, and Z is Hausdorff, this surjection is unique.) For instance, the two-point compactification ")#mi("\\{-\\infty\\} \\cup {\\Bbb Z} \\cup \\{+\\infty\\}")#text(" of the integers is finer than the one-point compactification ")#mi("{\\Bbb Z} \\cup \\{\\infty\\}")#text(". This is clearly a partial ordering; also, the ")#link("http://en.wikipedia.org/wiki/Inverse_limit")[#text("inverse limit")]#text(" of any ")#link("http://en.wikipedia.org/wiki/Chain_%28order_theory%29")[#text("chain")]#text(" of compactifications can be verified (by ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff’s theorem")]#text(") to still be a compactification. Hence, by Zorn’s lemma (modulo a technical step in which one shows that the ")#link("http://en.wikipedia.org/wiki/Moduli_space")[#text("moduli space")]#text(" of compactifications of X is a set rather than a ")#link("http://en.wikipedia.org/wiki/Class_%28set_theory%29")[#text("class")]#text("), there is a maximal compactification ")#mi("\\beta X")#text(". To verify the extension property for continuous functions ")#mi("f: X \\to Y")#text(", note (by replacing Y with ")#mi("\\beta Y")#text(" if necessary) that we may take Y to be compact. Let Z be the closure of the graph ")#mi("X^{\\prime} := \\{ (x,f(x)): x \\in X \\}")#text(" in ")#mi("(\\beta X) \\times Y")#text(". X’ is clearly homeomorphic to X, and so Z is a compactification of X. Also, there is an obvious surjective continuous map from Z to ")#mi("\\beta X")#text("; thus by maximality, this map must be a homeomorphism, thus Z is the graph of a continuous function ")#mi("\\beta f: \\beta X \\to \\beta Y")#text(", and the claim follows (the uniqueness of ")#mi("\\beta f")#text(" is easily established). ")#mi("\\Box")

#strong[#text("Exercise 6")]#text(". Let X be discrete (and thus clearly LCH), and let ")#mi("\\beta X")#text(" be the Stone-Čech compactification. For any ")#mi("p \\in \\beta X")#text(", let ")#mi("{}[p] \\in 2^{2^X}")#text(" be the collection of all sets ")#mi("A \\subset X")#text(" such that ")#mi("\\beta 1_A(p) = 1")#text(". Show that [p] is an ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilter")]#text(", or in other words that it obeys the following four properties:")

#enum(start: 1, 
[#mi("\\emptyset \\not \\in [p]")#text(".")],
[#text("If ")#mi("U \\in [p]")#text(" and ")#mi("V \\in 2^X")#text(" are such that ")#mi("U \\subset V")#text(", then ")#mi("V \\in [p]")#text(".")],
[#text("If ")#mi("U, V \\in [p]")#text(", then ")#mi("U \\cap V \\in [p]")#text(".")],
[#text("If ")#mi("U, V \\in 2^X")#text(" are such that ")#mi("U \\cup V = X")#text(", then at least one of U and V lie in [p].")]
)

#text("Furthermore, show that the map ")#mi("p \\mapsto [p]")#text(" is a homeomorphism between ")#mi("\\beta X")#text(" and the space of ultrafilters, which we endow with the topology induced from the product topology on ")#mi("2^{2^X} \\equiv \\{0,1\\}^{2^X}")#text(", where we give ")#mi("\\{0,1\\}")#text(" the discrete topology (one can place some other topologies here also). Thus we see that in the discrete case, we can represent the Stone-Čech compactification explicitly via ultrafilters. ")#mi("\\diamond")

#text("It is easy to see that ")#mi("\\beta(g \\circ f) = (\\beta g) \\circ (\\beta f)")#text(" whenever ")#mi("f: X \\to Y")#text(" and ")#mi("g: Y \\to Z")#text(" are continuous maps between LCH spaces. In the language of category theory, we thus see that ")#mi("\\beta")#text(" is a covariant ")#link("http://en.wikipedia.org/wiki/Functor")[#text("functor")]#text(" from the category of LCH spaces to the category of compact Hausdorff spaces. (The above theorem does not explicitly define ")#mi("\\beta X")#text(", but it is not hard to see that this compactification is unique up to homeomorphism, so the exact form of ")#mi("\\beta X")#text(" is somewhat moot. However, it is possible to create an ultrafilter-based description of ")#mi("\\beta X")#text(" for general LCH spaces X, though we will not do so here.)")

#strong[#text("Exercise 6′.")]#text(" Let X and Y be two LCH spaces. Show that the ")#link("http://en.wikipedia.org/wiki/Disjoint_union_%28topology%29")[#text("disjoint union")]#text(" ")#mi("(\\beta X) \\uplus (\\beta Y)")#text(" of ")#mi("\\beta X")#text(" and ")#mi("\\beta Y")#text(" is isomorphic to ")#mi("\\beta (X \\uplus Y)")#text(". (Indeed, this isomorphism is a ")#link("http://en.wikipedia.org/wiki/Natural_isomorphism")[#text("natural isomorphism")]#text(".) In the language of category theory, this means that ")#mi("\\beta")#text(" preserves ")#link("http://en.wikipedia.org/wiki/Coproduct")[#text("coproducts")]#text(". (Unfortunately, ")#mi("\\beta")#text(" does not preserve ")#link("http://en.wikipedia.org/wiki/Product_%28category_theory%29")[#text("products")]#text(", which leads to various subtleties, such as the non-commutativity of the compactification of commutative groups.) ")#mi("\\diamond")

#text("Note that if ")#mi("f: X \\to Y")#text(" is continuous, then ")#mi("\\beta f: \\beta X \\to \\beta Y")#text(" is continuous also; since X is dense in ")#mi("\\beta X")#text(", we conclude that")

#mi("\\beta f(p) = \\lim_{x \\to p} f(x)")#text(" (7)")

#text("for all ")#mi("p \\in \\beta X")#text(", where x is constrained to lie in X. [Here and in the sequel, limits such as ")#mi("\\lim_{x \\to p}")#text(" are interpreted in the usual topological sense, thus (7) means that for every neighbourhood V of ")#mi("\\beta f(p)")#text(", there exists a neighbourhood U of p such that ")#mi("f(x) \\in V")#text(" for all ")#mi("x \\in U")#text(".) In particular, the limit on the right exists for any continuous ")#mi("f: X \\to Y")#text(", and thus if X is discrete, it exists for any (!) function ")#mi("f: X \\to Y")#text(". Each p can then be viewed as a recipe for taking limits of arbitrary functions in a consistent fashion (although different p’s can give different limits, of course). It is this ability to take limits without needing to check for convergence and without running into contradictions that makes the Stone-Čech compactification a useful tool here. (See also my ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("post on ultrafilters")]#text(" for further discussion.)")

#text("The integers ")#mi("{\\Bbb Z}")#text(" are discrete, and thus are clearly LCH. Thus we may form the compactification ")#mi("\\beta {\\Bbb Z}")#text(". The addition operation ")#mi("+: {\\Bbb Z} \\times {\\Bbb Z} \\to {\\Bbb Z}")#text(" can then be extended to ")#mi("\\beta {\\Bbb Z}")#text(" by the plausible-looking formula")

#mi("p + q := \\lim_{n \\to p} \\lim_{m \\to q} n+m")#text(" (8)")

#text("for all ")#mi("p, q \\in \\beta {\\Bbb Z}")#text(", where n, m range in the integers ")#mi("{\\Bbb Z}")#text(". Note that the double limit is guaranteed to exist by (7). Equivalently, we have")

#mi("\\lim_{l \\to p+q} f(l) = \\lim_{n \\to p} \\lim_{m \\to q} f(n+m)")#text(" (8′)")

#text("for all functions ")#mi("f: {\\Bbb Z} \\to X")#text(" into an LCH space X; one can derive (8′) from (8) by applying ")#mi("\\beta f: \\beta {\\Bbb Z} \\to \\beta X")#text(" to both sides of (8) and using (7) and the continuity of ")#mi("\\beta f")#text(" repeatedly.")

#text("This addition operation clearly extends that of ")#mi("{\\Bbb Z}")#text(" and is associative, thus we have turned ")#mi("\\beta {\\Bbb Z}")#text(" into a ")#link("http://en.wikipedia.org/wiki/Semigroup")[#text("semigroup")]#text(". We caution however that this semigroup is not commutative, due to the usual difficulty that double limits in (8) cannot be exchanged. (We will prove non-commutativity shortly.) For similar reasons, ")#mi("\\beta {\\Bbb Z}")#text(" is not a group; the obvious attempt to define a negation operation ")#mi("-p := \\lim_{n \\to p} -n")#text(" is well-defined, but does not actually invert addition. The operation ")#mi("(p,q) \\mapsto p+q")#text(" is continuous in p for fixed q (why?), but is not necessarily continuous in q for fixed p – again, due to the exchange of limits problem. Thus ")#mi("\\beta {\\Bbb Z}")#text(" is merely a left-continuous semigroup. If however p is an integer, then the first limit in (8) disappears, and one easily shows that ")#mi("q \\mapsto q+p")#text(" is continuous in this case (and for similar reasons one also recovers commutativity, ")#mi("q+p=p+q")#text(").")

#strong[#text("Exercise 7")]#text(". Let us endow the two-point compactification ")#mi("\\{-\\infty\\} \\cup {\\Bbb Z} \\cup \\{+\\infty\\}")#text(" with the semigroup structure + in which ")#mi("x + (+\\infty) = +\\infty")#text(" and ")#mi("x + (-\\infty) = -\\infty")#text(" for all ")#mi("x \\in \\{ -\\infty\\} \\cup {\\Bbb Z} \\cup \\{+\\infty\\}")#text(" (compare with (8)). Show that there is a unique continuous map ")#mi("\\pi: \\beta {\\Bbb Z} \\to {\\Bbb Z} \\cup \\{-\\infty\\} \\cup \\{+\\infty\\}")#text(" which is the identity on ")#mi("{\\Bbb Z}")#text(", and that this map is a surjective semigroup homomorphism. Using this homomorphism, conclude:")

#enum(start: 1, 
[#mi("\\beta{\\Bbb Z}")#text(" is not commutative. Furthermore, show that the ")#link("http://en.wikipedia.org/wiki/Center_%28group_theory%29")[#text("centre")]#text(" ")#mi("Z( \\beta{\\Bbb Z} ) := \\{ p \\in \\beta{\\Bbb Z}: p+q=q+p \\text{ for all } q \\in \\beta{\\Bbb Z} \\}")#text(" is exactly equal to ")#mi("{\\Bbb Z}")#text(".")],
[#text("Show that if ")#mi("p,q \\in \\beta {\\Bbb Z}")#text(" are such that ")#mi("p+q \\in {\\Bbb Z}")#text(", then ")#mi("p, q \\in {\\Bbb Z}")#text(". (“Once you go to infinity, you can never return.”) Conclude in particular that ")#mi("\\beta {\\Bbb Z}")#text(" is not a group. (Note that this conclusion could already be obtained using the coarser one-point compactification ")#mi("{\\Bbb Z} \\cup \\{\\infty\\}")#text(" of the integers.) ")#mi("\\diamond")]
)

#strong[#text("Remark 1.")]#text(" ")#text("More generally, we can take any LCH left-continuous semigroup S and compactify it to obtain a compact Hausdorff left-continuous semigroup ")#mi("\\beta S")#text(". Observe that if ")#mi("f: S \\to S^{\\prime}")#text(" is a homomorphism between two LCH left-continuous semigroups, then ")#mi("\\beta f: \\beta S \\to \\beta S^{\\prime}")#text(" is also a homomorphism. Thus, from the viewpoint of category theory, ")#mi("\\beta")#text(" can be viewed as a covariant functor from the category of LCH left-continuous semigroups to the category of CH left-continuous semigroups. We will see this functorial property being used a little later in this course.")#text(" (The issue turns out to be considerably more delicate than I thought, as pointed out in comments; see ")#link("http://www.ams.org/mathscinet-getitem?mr=409711")[#text("this article")]#text(" for further discussion.) ")#mi("\\diamond")

#text("The left-continuous non-commutative semigroup structure of ")#mi("\\beta {\\Bbb Z}")#text(" may appear to be terribly weak when compared against the jointly continuous commutative group structure of ")#mi("{\\Bbb Z}")#text(", but ")#mi("\\beta {\\Bbb Z}")#text(" has a decisive trump card over ")#mi("{\\Bbb Z}")#text(": it is ")#emph[#text("compact")]#text(". We will see the power of compactness a little later in this lecture.")

#text("A topological dynamical system ")#mi("(X,{\\mathcal F},T)")#text(" yields an action ")#mi("n \\mapsto T^n")#text(" of the integers ")#mi("{\\Bbb Z}")#text(". But we can automatically extend this action to an action ")#mi("p \\mapsto T^p")#text(" of the compactified integers ")#mi("\\beta {\\Bbb Z}")#text(" by the formula")

#mi("T^p x := \\lim_{n \\to p} T^n x")#text(". (9)")

#text("(Note that X is already compact, so that the limit in (9) stays in X.) One easily checks from (8′) that this is indeed an action of ")#mi("\\beta {\\Bbb Z}")#text(" (thus ")#mi("T^p T^q = T^{p+q}")#text(" for all ")#mi("p,q \\in {\\Bbb Z}")#text("). The map ")#mi("T^p x")#text(" is continuous in p by construction; however we caution that it is no longer continuous in x (it’s the exchange-of-limits problem once more!). Indeed, the map ")#mi("T^p: X \\to X")#text(" can be quite nasty from an analytic viewpoint; for instance, it is possible for this map to not be ")#link("http://en.wikipedia.org/wiki/Borel_measurable")[#text("Borel measurable")]#text(". (This is the price one pays for introducing beasts generated from the axiom of choice into one’s mathematical ecosystem.) But as we shall see, the ")#emph[#text("algebraic")]#text(" properties of ")#mi("T^p")#text(" are very good, and suffice for applications to recurrence, because once one has compactified the underlying semigroup ")#mi("\\beta {\\Bbb Z}")#text(", the need for point-set topology (and for all the epsilons that come with it) mostly disappears. For instance, we can now replace orbit closures by orbits:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(". Let ")#mi("(X,{\\mathcal F},T)")#text(" be a topological dynamical system, and let ")#mi("x \\in X")#text(". Then")

#mi("\\overline{T^{\\Bbb Z}(x)} = T^{\\beta {\\Bbb Z}} x := \\{ T^p x: p \\in \\beta {\\Bbb Z} \\}")#text(".")
]

#strong[#text("Proof")]#text(": Since ")#mi("\\beta {\\Bbb Z}")#text(" is compact, ")#mi("T^{\\beta {\\Bbb Z}} x")#text(" is compact also. Since ")#mi("{\\Bbb Z}")#text(" is dense in ")#mi("\\beta {\\Bbb Z}")#text(", ")#mi("T^{\\Bbb Z} x")#text(" is dense in ")#mi("T^{\\beta {\\Bbb Z}} x")#text(". The claim follows. ")#mi("\\Box")

#text("From (9) we see that ")#mi("T^p")#text(" is some sort of “limiting shift” operation. To get some intuition, let us consider the compactified integer shift ")#mi("(\\{-\\infty\\} \\cup {\\Bbb Z} \\cup \\{+\\infty\\}, x \\mapsto x+1)")#text(", and look at the orbit of the point 0. If one only shifts by integers ")#mi("n \\in {\\Bbb Z}")#text(", then ")#mi("T^n 0")#text(" can range across the region ")#mi("{\\Bbb Z}")#text(" in the system but cannot reach ")#mi("-\\infty")#text(" or ")#mi("+\\infty")#text(". But now let ")#mi("p \\in \\beta {\\Bbb Z} \\backslash {\\Bbb Z}")#text(" be any limit point of the positive integers ")#mi("{\\Bbb Z}^+")#text(" (note that at least one such limit point must exist, since ")#mi("{\\Bbb Z}^+")#text(" is not compact. Indeed, in the language of Exercise 7, the set of all such limit points is ")#mi("\\pi^{-1}(+\\infty)")#text(".) Then from (9) we see that ")#mi("T^p 0 = +\\infty")#text(". Similarly, if ")#mi("q \\in \\beta{\\Bbb Z} \\backslash {\\Bbb Z}")#text(" is a limit point of the negative integers ")#mi("{\\Bbb Z}^-")#text(" then ")#mi("T^q 0 = -\\infty")#text(". Now, since ")#mi("+\\infty")#text(" invariant, we have ")#mi("T^q (+\\infty) = +\\infty")#text(" by (9) again, and thus ")#mi("T^q T^p 0 = +\\infty")#text(", while ")#mi("T^p T^q 0 = -\\infty")#text(". In particular, we see that ")#mi("p+q \\neq q+p")#text(", demonstrating non-commutativity in ")#mi("\\beta {\\Bbb Z}")#text(" (again, compare with Exercise 7). Informally, the problem here is that in (8), n+m will go to ")#mi("+\\infty")#text(" if we let m go to ")#mi("+\\infty")#text(" first and then ")#mi("n \\to -\\infty")#text(" next, but if we take ")#mi("n \\to -\\infty")#text(" first and then ")#mi("m \\to +\\infty")#text(" next, n+m instead goes to ")#mi("-\\infty")#text(".")

#strong[#text("Exercise 8.")]#text(" Let ")#mi("A \\subset {\\Bbb Z}")#text(" be a set of integers.")

#enum(start: 1, 
[#text("Show that ")#mi("\\beta A")#text(" can be canonically identified with the closure of A in ")#mi("\\beta {\\Bbb Z}")#text(", in which case ")#mi("\\beta A")#text(" becomes a ")#link("http://en.wikipedia.org/wiki/Clopen_set")[#text("clopen")]#text(" subset of ")#mi("\\beta {\\Bbb Z}")#text(".")],
[#text("Show that A is infinite if and only if ")#mi("\\beta A \\not \\subset {\\Bbb Z}")#text(".")],
[#text("Show that A is syndetic if and only if ")#mi("\\beta A \\cap (\\beta{\\Bbb Z} + p) \\neq \\emptyset")#text(" for every ")#mi("p \\in \\beta {\\Bbb Z}")#text(". (Since ")#mi("\\beta A")#text(" is clopen, this condition is also equivalent to requiring ")#mi("\\beta A \\cap ({\\Bbb Z} + p) \\neq \\emptyset")#text(" for every ")#mi("p \\in \\beta {\\Bbb Z}")#text(".)")],
[#text("A set of integers A is said to be ")#emph[#text("thick")]#text(" if it contains arbitrarily long intervals [a_n,a_n+n]; thus syndetic and thick sets always intersect each other. Show that A is thick if and only if there exists ")#mi("p \\in \\beta{\\Bbb Z}")#text(" such that ")#mi("\\beta{\\Bbb Z}+p \\subset \\beta A")#text(". (Again, this condition is equivalent to requiring ")#mi("{\\Bbb Z}+p \\subset \\beta A")#text(" for some p.) ")#mi("\\diamond")]
)

#text("Recall that a system is ")#emph[#text("minimal")]#text(" if and only if it is the orbit closure of every point in that system. We thus have a purely algebraic description of minimality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1")]#text(". Let ")#mi("(X,{\\mathcal F},T)")#text(" be a topological dynamical system. Then X is minimal if and only if the action of ")#mi("\\beta {\\Bbb Z}")#text(" is transitive; thus for every ")#mi("x, y \\in X")#text(" there exists ")#mi("p \\in \\beta {\\Bbb Z}")#text(" such that ")#mi("T^p x = y")#text(".")
]

#text("One also has purely algebraic descriptions of almost periodicity and recurrence:")

#strong[#text("Exercise 9")]#text(". Let ")#mi("(X,{\\mathcal F},T)")#text(" be a topological dynamical system, and let x be a point in X.")

#enum(start: 1, 
[#text("Show that x is almost periodic if and and only if for every ")#mi("p \\in \\beta {\\Bbb Z}")#text(" there exists ")#mi("q \\in \\beta {\\Bbb Z}")#text(" such that ")#mi("T^q T^p x = x")#text(". (In particular, Lemma 1 is now an immediate consequence of Corollary 1.)")],
[#text("Show that x is recurrent if and only if there exists ")#mi("p \\in\\beta {\\Bbb Z} \\backslash {\\Bbb Z}")#text(" such that ")#mi("T^p x = x")#text(". ")#mi("\\diamond")]
)

#text("Note that ")#mi("\\beta {\\Bbb Z}")#text(" acts on itself ")#mi("\\beta {\\Bbb Z}")#text(" by addition, ")#mi("p: q \\mapsto p+q")#text(", with the action being continuous when p is an integer. Thus one can view ")#mi("\\beta {\\Bbb Z}")#text(" itself as a topological dynamical system, except with the caveat that ")#mi("\\beta {\\Bbb Z}")#text(" is not metrisable or even ")#link("http://en.wikipedia.org/wiki/First_countable")[#text("first countable")]#text(" (see Exercise 12). Nevertheless, it is still useful to think of ")#mi("\\beta {\\Bbb Z}")#text(" as behaving like a topological dynamical system. For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1")]#text(". An element ")#mi("p \\in \\beta {\\Bbb Z}")#text(" is said to be ")#emph[#text("minimal")]#text(" or ")#emph[#text("almost periodic")]#text(" if for every ")#mi("q \\in \\beta {\\Bbb Z}")#text(" there exists ")#mi("r \\in \\beta {\\Bbb Z}")#text(" such that ")#mi("r+q+p=p")#text(".")
]

#text("Equivalently, p is minimal if ")#mi("\\beta {\\Bbb Z}+p")#text(" is a minimal left-ideal of ")#mi("\\beta {\\Bbb Z}")#text(", which explains the terminology.")

#strong[#text("Exercise 10")]#text(". Show that for every ")#mi("p \\in \\beta {\\Bbb Z}")#text(" there exists ")#mi("q \\in \\beta {\\Bbb Z}")#text(" such that ")#mi("q+p")#text(" is minimal. (Hint: adapt the proof of Lemma 1 from the ")#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/")[#text("previous lecture")]#text(".) Also, show that if p is minimal, then q+p and p+q are also minimal for any ")#mi("q \\in \\beta {\\Bbb Z}")#text(". This shows that minimal elements of ")#mi("\\beta {\\Bbb Z}")#text(" exist in abundance. However, observe from Exercise 6 that no integer can be minimal. ")#mi("\\diamond")

#strong[#text("Exercise 11")]#text(". Show that if ")#mi("p \\in \\beta {\\Bbb Z}")#text(" is minimal, and x is a point in a topological dynamical system ")#mi("(X, {\\mathcal F},T)")#text(", then ")#mi("T^p x")#text(" is almost periodic. Conversely, show that x is almost periodic if and only if ")#mi("x = T^p x")#text(" for some minimal p. This gives an alternate (and more “algebraic”) proof of the Birkhoff recurrence theorem. ")#mi("\\diamond")

#strong[#text("Exercise 12.")]#text(" Show that no element of ")#mi("\\beta {\\Bbb Z} \\backslash {\\Bbb Z}")#text(" can be written as a limit of a sequence in ")#mi("{\\Bbb Z}")#text(". (")#emph[#text("Hint")]#text(": if a sequence ")#mi("n_j \\in {\\Bbb Z}")#text(" converged to a limit ")#mi("p \\in \\beta {\\Bbb Z}")#text(", one must have ")#mi("\\beta f(p) = \\lim_{j \\to \\infty} f(n_j)")#text(" for all functions ")#mi("f: {\\Bbb Z} \\to K")#text(" mapping into a compact Hausdorff space K.) Conclude in particular that ")#mi("\\beta {\\Bbb Z}")#text(" is not metrisable, ")#link("http://en.wikipedia.org/wiki/First_countable")[#text("first countable")]#text(", or ")#link("http://en.wikipedia.org/wiki/Compact_space")[#text("sequentially compact")]#text(". ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Jan 14: various corrections and reorganisation.]")

#text("[")#emph[#text("Update")]#text(", Jan 30: Some exercises added or expanded.]")

#text("[")#emph[#text("Update")]#text(", Feb 4: Hint for Exercise 12 added.]")

#text("[")#emph[#text("Update")]#text(", Mar 21: Exercise 3 repaired.]")

#heading(level: 1)[#text("Comments (59)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd38eb79dd005d5091b9b3c49f40aa47236e21b5345b6381eb83aeb04189483f-5365fee31be4687d5ae998e23aecae25e9205b8b4871e5cef48d4a499c1db808.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-2/#comment-228444")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2013")])]

#text("Dear Terry,")

#text("Putting a left-continuous semigroup structure on ")#mi("\\beta S")#text(" for general (non-discrete) topological semigroups ")#mi("S")#text(" seems not entirely straight-forward. The issue is that while one may extend the product ")#mi("x\\mapsto xy")#text(", for each fixed ")#mi("y\\in S")#text(", continuously to a map ")#mi("\\beta S\\to\\beta S")#text(", it’s not automatic that the map ")#mi("S\\to \\beta S")#text(" given by ")#mi("y\\mapsto xy")#text(" is continuous for fixed ")#mi("x\\in \\beta S")#text(". There’s more information here: ")#link("http://www.ams.org/mathscinet/search/publdoc.html?pg1=IID&s1=210043&vfpref=html&r=21&mx-pid=409711")[#text("http://www.ams.org/mathscinet/search/publdoc.html?pg1=IID&s1=210043&vfpref=html&r=21&mx-pid=409711")]

#text("I’ve always wondered vaguely why the Bohr compactification does not play a larger role in these matters. Specifically, you indicated above that it’s worth giving up most of your group structure for the sake of compactness, but the Bohr compactification gives you both, giving up only metrisability.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-2/#comment-228494")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2013")])]

#text("Thanks, I was not aware of this subtlety! Unfortunately this undermines the rationale for Remark 1 to the point where it confuses more than it elucidates, so I have decided to simply strike it out.")

#text("As for the Bohr compactification, it is the universal completion for studying the “isometric”, “almost periodic”, or “Kronecker” part of a topological dynamical system or a measure-preserving system, but is not compatible with the general dynamics beyond the Kronecker factor (basically because the relevant representations become infinite dimensional instead of finite dimensional). Within the Kronecker factor, most of the literature has focused on the actions of abelian groups (such as the integers), in which case one can already use Fourier analysis to analyse the Kronecker factor quite satisfactorily; the Bohr compactification is implicitly present in a few places in the theory (for instance, it shows up behind the scenes when showing that the Kronecker factor is associated to a translation on a compact group) but Fourier analysis on abelian groups is already so well developed that there isn’t much need for the universal compactification.")

#text("For me, one of the key things that universal objects such as Stone-Cech compactifications or ultrafilters bring to the table is that they take a bunch of arbitrary choices that one might have to take at some later parts of the argument and instead make all those choices at the beginning of the argument when the universal object is introduced. Once the arbitrary choices have been removed from the main argument, one can easily obtain a number of consistency properties on various constructions in that argument which would otherwise have required some care when selecting amongst the various arbitrary choices available. In particular, ultrafilters replace all invocations of the infinite pigeonhole principle (which requires some arbitrary choice among the various infinite colour classes available) with a limit functional ")#mi("\\lim_{n \\to p}")#text(" which automatically obeys a number of consistency properties (basically, the ultrafilter axioms) which the original pigeonhole principle only achieves after some careful choice selection. The Bohr compactification does not transfer choices in this way (note for instance that Zorn’s lemma is not required in order to construct the compactification) and so is less useful when studying a single Kronecker factor (although I could imagine it has more value when one is simultaneously studying a large family of Kronecker factors associated to many different systems, for instance when dealing with non-ergodic situations).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcd5b2eb7ca9ffc1ebc9ac577ca350d7150f7a61d2d16ba5f2fab83628212c7b-fe5747df922616191f0c65b6516a0e2082fa260ba9ab341d83fccf33aabc1671.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergey Filkin")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-2/#comment-245573")[#strong[#text("Sergey Filkin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2013")])]

#text("Dear professor Tao, thank you for your work!")#linebreak()#text(" Could you publish lectures 1,2 in the blog?")#linebreak()#text(" The link ")#link("https://terrytao.wordpress.com/2008/01/11/254a-lecture-2-three-categories-of-dynamical-systems/")[#text("https://terrytao.wordpress.com/2008/01/11/254a-lecture-2-three-categories-of-dynamical-systems/")]#text(" is broken")

#emph[#text("[Sorry about that! The correct link is ")#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/")[#text("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/")]#text(" . Also, the full list of notes is at ")#link("https://terrytao.wordpress.com/category/teaching/254a-ergodic-theory/")[#text("https://terrytao.wordpress.com/category/teaching/254a-ergodic-theory/")]#text(" -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-2/#comment-255859")[#strong[#text("Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2013")])]

#text("[…] semigroup, which is a useful fact in Ramsey theory and topological dynamics, as discussed in this previous post), but we will not discuss these structures further here. In particular, the use of ultrafilters in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 4: Multiple recurrence | What's new")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-2/#comment-503369")[#strong[#text("254A, Lecture 4: Multiple recurrence | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2018")])]

#text("[…] Indeed, the deduction of Theorem 5 from Theorem 4 is immediate from the following useful fact (cf. Lemma 1 from Lecture 3): […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-2/#comment-503782")[#strong[#text("朱乐恒")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2018")]

#text("Dear Professor,")

#text("How much is Card(\\beta Z) ? I known it is not less than R.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-2/#comment-503794")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2018")])]

#text("The cardinality is ")#mi("2^c")#text(". See e.g. ")#link("https://dantopology.wordpress.com/2012/10/01/stone-cech-compactification-of-the-integers-basic-facts/")[#text("https://dantopology.wordpress.com/2012/10/01/stone-cech-compactification-of-the-integers-basic-facts/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-2/#comment-693176")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2026")])]

#text("In corollary 1: Should be x,y in X, not x,y in Z. Right?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-24187")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2008")])]

#text("Just a comment on terminology. A “thick” subset of the integers (or the generalization of the concept to any abstract group) has also been referred to as a “replete” or a “fat” subset. I think that usage of the word replete, which I prefer, preceded the usage of the others. I just thought I would comment on this so that people do not get confused reviewing the literature in this area.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R.A.")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-24211")[#strong[#text("R.A.")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2008")])]

#text("Probably in formula (1) we should have the absolute value in the exponent")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68ed56f9a41108d668c310ed91efe421387807165e05cf3d6d570dacd7415b04-83a5f9d55eaf9f44176f2545d6840e2fd1d85646379afdebb8cc7b09b6a1118d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-24265")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2008")])]

#text("Proof 1 of Theorem 3 is incorrect. A quick way to see this is that ")#mi("2^{\\mathcal F}")#text(" is totally disconnected, so if X is connected, it cannot be embedded in such a space. More concretely, X is actually compact and infinite, say, then ")#mi("\\{X-\\{x\\}:x\\in X\\}")#text(" has the finite intersection property and thus extends to an “ultrafilter” of open sets (a point in your ")#mi("\\beta X")#text("), but such a point is not in the image of X. In order to express the Stone-Cech compactification of an arbitrary space as a set of ultrafilters, you have to use the lattice of ")#link("http://en.wikipedia.org/wiki/Zero_set")[#text("zero sets")]#text(" (or closed sets in, say, a metrizable space); on lattices of open sets (more precisely, cozero sets), one must use prime ideals rather than filters. Also, the topology on 2 in the product must have only one of the points closed in order to obtain the correct topology on ")#mi("\\beta X")#text(" (having both points clopen is essentially asserting that every open (or closed) set in X is clopen).")

#text("The hint in Exercise 8 also does not work. The set of complements of sets of rapidly increasing magnitude has the finite intersection property, so there is an ultrafilter that contains no rapidly increasing set. For a proof that does work, you can take a sequence ")#mi("(n_j)")#text(" with p as a limit point that converges to ")#mi("\\pm \\infty")#text(" and then let ")#mi("(m_i)")#text(" be any sequence converging to ")#mi("\\mp \\infty")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-24297")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2008")])]

#text("Thanks for the corrections! I think I will relegate the connection with ultrafilters to an exercise then, and emphasise the universal property of the Stone-Cech compactification instead. Also, it has now become clear to me that I was implicitly exploring the surjective semigroup homomorphism from ")#mi("\\beta {\\Bbb Z}")#text(" to ")#mi("\\{-\\infty\\} \\cup {\\Bbb Z} \\cup \\{+\\infty\\}")#text(" in much of the discussion in the original version, so I have rearranged things to emphasise that viewpoint also.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0106d1a51149435c0e7cc34d90e8026547a432e9bf1348c67b9eb9712116364-f26191209d651bb87abe0695a0206e6e25995780d590cc394681eab053fdce6f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of richard borcherds")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-24482")[#strong[#text("richard borcherds")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2008")])]

#text("I was shocked to read that the semigroup structure on ")#mi("\\beta N")#text(" is not commutative; I’m sure this sort of behavior was not tolerated when I was a grad student. It seems related to the fact that ")#mi("\\beta")#text(" is a left adjoint so preserves coproducts but not products: the natural map from ")#mi("\\beta A\\times B")#text(" to ")#mi("\\beta A\\times \\beta B")#text(" is not an isomorphism in general. From the point of view of category theory, ")#mi("\\beta N")#text(" shouldn’t really have a semigroup structure at all, which I guess is reflected in the fact that its semigroup structure is rather weird: discontinuous and nonabelian.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 4: Multiple recurrence « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-24486")[#strong[#text("254A, Lecture 4: Multiple recurrence « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2008")])]

#text("[…] – ergodic theory, math.CO, math.DS Tags: multiple recurrence, van der Waerden’s theorem In the previous lecture, we established single recurrence properties for both open sets and for sequences inside a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-24490")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2008")])]

#text("Dear Richard,")

#text("I think you’re right here. ")#mi("\\beta A \\times \\beta B")#text(" is a compactification of ")#mi("A \\times B")#text(", but it is not as fine as the Stone-Cech compactification ")#mi("\\beta(A\\times B)")#text(", which projects surjectively but not injectively into the product. Informally, this discrepancy seems to be because there are features of joint limits which cannot be detected purely using individual limits; for instance, a function f(x,y) can go to zero as ")#mi("x \\to \\infty")#text(" for fixed y, and as ")#mi("y \\to \\infty")#text(" for fixed x, without going to zero as (x,y) jointly goes to infinity.")

#text("The addition operation ")#mi("+: {\\Bbb Z} \\times {\\Bbb Z} \\to {\\Bbb Z}")#text(" does compactify to a symmetric map ")#mi("\\beta +: \\beta( {\\Bbb Z} \\times {\\Bbb Z} ) \\to \\beta {\\Bbb Z}")#text(", but this map does not create a semigroup structure due to the lack of a canonical identification of ")#mi("\\beta( {\\Bbb Z} \\times {\\Bbb Z} )")#text(" with ")#mi("(\\beta {\\Bbb Z}) \\times (\\beta {\\Bbb Z})")#text(".")

#text("Weirdly, there are two distinct ways in which one can naturally embed ")#mi("(\\beta {\\Bbb Z}) \\times (\\beta {\\Bbb Z})")#text(" into ")#mi("\\beta({\\Bbb Z} \\times {\\Bbb Z})")#text(" that partially invert the canonical projection. One is to map ")#mi("(p,q)")#text(" to ")#mi("\\lim_{n \\to p} \\lim_{m \\to q} (n,m)")#text("; the other is to map ")#mi("(p,q)")#text(" to ")#mi("\\lim_{m \\to q} \\lim_{n \\to p} (n,m)")#text(". The distinctness between these two lifts seems to be the root cause of all the pathology.")

#text("Remarkably, despite the apparent lack of good algebraic or topological structure, one can still say some non-trivial facts about compact semi-continuous semi-groups such as ")#mi("\\beta {\\Bbb Z}")#text(", in particular the Ellis-Nakamura lemma, which I will get to in a lecture or two. The moral seems to be that compactness is such a useful property it is sometimes worth sacrificing commutativity, invertibility, and full continuity in order to attain it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e3a41d2e49f99496331086313091876657e94fc1fa6eb03dd7fc7744d112706-ccb789f07279c510d7296f4fdaee60491e95a9dbe98ef733bb51533f04938f8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nilay")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-24722")[#strong[#text("Nilay")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2008")])]

#text("Sir")

#text("I was trying to prove that in the circle shift system ({\\Bbb R}/{\\Bbb Z}, x \\mapsto x + \\alpha) with \\alpha \\in {\\Bbb R}/{\\Bbb Z}, it turns out that every point is almost periodic, but no point is periodic.")#linebreak()#text(" Assume that for x = {\\Bbb Z} + \\beta. Then for this point to be almost periodic, we should be able to produce for each \\epsilon, integers n and k such that 0 < n\\alpha-k < \\epsilon. This to me means that we should be able to the r^{th} digit of \\alpha for all r. But this is possible for only countable number of irrational numbers and hence not true for every \\alpha.")#linebreak()#text(" Am I missing something?")

#text("One more question. How do you include mathematical symbols in your posts? I found a relevant web page but since there is no way to preview a comment, I could not try it out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-24742")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2008")])]

#text("Dear Nilay,")

#text("I am afraid I do not understand what you mean by “we should be able to the r^{th} digit of \\alpha for all r”. Note that for each ")#mi("\\varepsilon")#text(", n, and k, the set of irrational ")#mi("\\alpha")#text(" for which ")#mi("0 < n\\alpha-k < \\epsilon")#text(" is uncountably infinite (it is an interval).")

#text("To display LaTeX in comments, please see")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/about/")[#text("About")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e3a41d2e49f99496331086313091876657e94fc1fa6eb03dd7fc7744d112706-ccb789f07279c510d7296f4fdaee60491e95a9dbe98ef733bb51533f04938f8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nilay")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-24754")[#strong[#text("Nilay")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2008")])]

#text("Sir")

#text("I missed out on the word ‘compute’. Complete sentence would be — “we should be able to compute the ")#mi("r^{th}")#text(" digit of ")#mi("\\alpha")#text(" for all r”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-24760")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2008")])]

#text("Dear Nilay,")

#text("To compute the ")#mi("r^{th}")#text(" digit of ")#mi("\\alpha")#text(" from an approximation ")#mi("0 < n\\alpha - k < \\epsilon")#text(", one would need to know the integers n and k that correspond to a value of ")#mi("\\epsilon")#text(" that depends on r, such as ")#mi("10^{-r}")#text(". To get more digits, one would need more integers n and k. To specify all the digits, one would need to know a countable number of integers, thus allowing for an uncountable number of possibilities. (For each individual digit, of course, there are only 10 possibilities.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 5: Other topological recurrence results « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-24782")[#strong[#text("254A, Lecture 5: Other topological recurrence results « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2008")])]

#text("[…] us say that is minimal if is a minimal left-ideal of . One can show (by repeating Exercise 10 from Lecture 3) that every left ideal contains at least one minimal element; in particular, minimal elements […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e3a41d2e49f99496331086313091876657e94fc1fa6eb03dd7fc7744d112706-ccb789f07279c510d7296f4fdaee60491e95a9dbe98ef733bb51533f04938f8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nilay")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-24791")[#strong[#text("Nilay")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2008")])]

#text("Sir")

#text("I am still stuck in proving that in the circle shift system ")#mi("({\\Bbb R}/{\\Bbb Z}, x \\mapsto x + \\alpha)")#text(" with ")#mi("\\alpha \\in {\\Bbb R}/{\\Bbb Z}")#text(", it turns out that every point is almost periodic, but no point is periodic. I try to outline the approach that I have taken.")#linebreak()#text(" Consider ")#mi("x \\in {\\Bbb R}/{\\Bbb Z}")#text(". We can assume ")#mi("x = {\\Bbb Z} + \\beta")#text(", where ")#mi("\\beta")#text(" is any real number. We need to show that this point is almost periodic. I am taking ")#mi("\\alpha")#text(" both as a state (")#mi("{\\Bbb Z} +\\alpha")#text(") in the system and as a real number. I would like to point out that for a rational ")#mi("\\alpha")#text(", this system is periodic as we can find integers n and k such that ")#mi("n\\alpha = k")#text(". But for an irrational ")#mi("\\alpha")#text(", such n and k cannot exist.")#linebreak()#text(" Now we will try to show that x is recurrent i.e. ")#mi("\\{ n \\in {\\Bbb Z}: d(T^n x, x)  0")#text(". I assumed the distance metric d to be absolute value of the difference between the shifts given to the ")#mi("{\\Bbb Z}")#text(". This implies that we need to prove that for each ")#mi("\\varepsilon")#text(" and ")#mi("\\alpha")#text(" there exist p, q such that ")#mi("\\frac{p-\\varepsilon}{q} < \\alpha < \\frac{p+\\varepsilon}{q}")#text(". Because then, ")#mi("p-\\varepsilon < q\\alpha < p+\\varepsilon")#text(" which is what we want to show. But I am unable to find out such p and q.")#linebreak()#text(" Further, I reasoned that since ")#mi("\\alpha")#text(" is arbitrary, we can find one such (p,q) pair for each ")#mi("\\alpha")#text(" and a fixed ")#mi("\\varepsilon")#text(". Then, we can continue the process with the new value ")#mi("\\parallel q\\alpha-p\\parallel")#text(". This would imply that each point is recurrent. In order to show that each point is almost periodic, I tried to reason that since for each ")#mi("\\alpha")#text(", this value of q is a finite integer we can take the maximum value over the entire interval [0,1] for all possible ")#mi("\\alpha")#text(" and obtain a bound on the gap between consecutive values of n. But a friend of mine said that I cannot obtain a maximum value over an uncountable set.")#linebreak()#text(" I am sceptical about the approach I have taken. Sir, can you help in proving the original statement?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-24792")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2008")])]

#text("Dear Nilay,")

#text("The result you want is essentially the Dirichlet approximation theorem")

#link("http://en.wikipedia.org/wiki/Dirichlet%27s_approximation_theorem")[#text("http://en.wikipedia.org/wiki/Dirichlet%27s_approximation_theorem")]

#text("which can be proven by a variety of methods (continued fractions, pigeonhole principle, etc.) It is also subsumed by Theorem 2 of the notes above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 6: Isometric systems and isometric extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-24880")[#strong[#text("254A, Lecture 6: Isometric systems and isometric extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2008")])]

#text("[…] 4. Let be an isometric extension of with factor map , and let y be a recurrent point of Y (see Lecture 3 for a definition). Then every point x in the fibre is a recurrent point in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 8: The mean ergodic theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-25171")[#strong[#text("254A, Lecture 8: The mean ergodic theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2008")])]

#text("[…] (Compare with Theorem 1 of Lecture 3.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168f1cef7efb9b63b6361c91e17671a624790a5d42d5b25cdbe3ee7e431d87af-b280653332375cd7c6657c5ea2bbb12c215eed900c6102a184d8309dc648efa5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Azeem")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-25414")[#strong[#text("Azeem")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2008")])]

#text("How do you go about addressing the excercise 12 above")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-25420")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2008")])]

#text("Dear Azeem,")

#text("Given any infinite sequence ")#mi("n_j")#text(" going to infinity, one can easily find a function ")#mi("f: {\\Bbb Z} \\to \\{0,1\\}")#text(" such that ")#mi("\\lim_{j \\to \\infty} f(n_j)")#text(" doesn’t exist. One can then show that this implies that ")#mi("n_j")#text(" cannot converge to an ultrafilter limit.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 10: The Furstenberg correspondence principle « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-25933")[#strong[#text("254A, Lecture 10: The Furstenberg correspondence principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("[…] between topological dynamics and colouring Ramsey theorems in our previous lectures (in particular Lecture 3, Lecture 4, and Lecture […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 11: Compact systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-26016")[#strong[#text("254A, Lecture 11: Compact systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("[…] 1 above) if and only if it is almost periodic in the topological dynamical systems sense (see Lecture 3), i.e. if the sets are syndetic for every . (Hint: if f is almost periodic in the ergodic theory […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e3a41d2e49f99496331086313091876657e94fc1fa6eb03dd7fc7744d112706-ccb789f07279c510d7296f4fdaee60491e95a9dbe98ef733bb51533f04938f8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nilay")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-26105")[#strong[#text("Nilay")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("Sir")

#text("I am finding it tough to understand ultrafilters. Can you provide some reference, possibly online, where ultrafilters have been dealt with? I have searched for ultrafilters several times. But from the web pages I found, I have not been able to understand them clearly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-26109")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("Dear Nilay,")

#text("My own post on this topic can be found at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("Ultrafilters, nonstandard analysis, and epsilon management")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e3a41d2e49f99496331086313091876657e94fc1fa6eb03dd7fc7744d112706-ccb789f07279c510d7296f4fdaee60491e95a9dbe98ef733bb51533f04938f8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nilay")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-26291")[#strong[#text("Nilay")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("Sir")

#text("Please the meaning of ")#mi("\\beta 1_A(p) = 1")#text(" which has been used in exercise 6.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e3a41d2e49f99496331086313091876657e94fc1fa6eb03dd7fc7744d112706-ccb789f07279c510d7296f4fdaee60491e95a9dbe98ef733bb51533f04938f8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nilay")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-26299")[#strong[#text("Nilay")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("Sir")

#text("I think ")#mi("1_A(p)")#text(" gives the value 1 if ")#mi("p \\in A")#text(" and 0 otherwise. I have another question. Can we say anything about the range of ")#mi("\\beta 1_A(p)")#text("? Is it confined to {0,1} only? Or will it give some real number other than 0 and 1 for a ")#mi("p \\in \\beta X")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-26305")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("Dear Nilay,")

#text("As ")#mi("1_A")#text(" is a continuous function from X to {0,1}, and {0,1} is already compact, the compactified function ")#mi("\\beta 1_A")#text(" will be a function from ")#mi("\\beta X")#text(" to {0,1}.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liu")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-26945")[#strong[#text("Liu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2008")])]

#text("Dear professor:")#linebreak()#text(" About exercise 2:How to find two distinct points which converge to each other and what to do then?I thought a lot of time for this exercise and don’t get it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-26954")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2008")])]

#text("Dear Liu,")

#text("If, for instance, Omega is the two-element set {0,1}, so that points in the Bernoulli system are strings of 0s and 1s, you might consider looking at strings such as …0000011111…. which are all 0s on the left and all 1s on the right.")

#text("Once you have two distinct points which converge to each other, you can argue by contradiction to show that no shift-invariant metric exists.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-27019")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2008")])]

#text("Dear professor：")#linebreak()#text(" Here is a tiny correction：")#linebreak()#text(" After theorem 2， the first sentance, ")#mi("\\alpha=(\\alpha_1,\\alpha_2,...,\\alpha_d)\\in R^d")#text("，a “d” missing。")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-27024")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2008")])]

#text("Dear liuxiaochuan: Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-27194")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2008")])]

#text("Dear professor：")#linebreak()#text(" If a set X is already compact which is not quite fine, then should ")#mi("\\beta X=X")#text(", or should ")#mi("\\beta X")#text(" contains more elements?")

#text("Liu")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-27195")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2008")])]

#text("Dear Liu,")

#text("When X is compact Hausdorff, the Stone-Cech compactification of X is just X itself (indeed, this is the only possible compactification available to a compact Hausdorff space).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S.P.")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-27212")[#strong[#text("S.P.")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2008")])]

#text("Dear Prof Tao,")#linebreak()#text(" A pedantic comment: Shouldn’t ")#mi("\\alpha")#text(" be irrational in order to guarantee that no point is periodic in the circle shift system ")#mi("(\\Bbb{R}/\\Bbb{Z}, x\\mapsto x+\\alpha )")#text("? (see the paragraph before Exercise 3). Feel free to delete this comment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-27220")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2008")])]

#text("Dear S.P.: thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-27287")[#strong[#text("Sean")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2008")])]

#text("Dear Prof Tao,")#linebreak()#text(" I’ve managed to convince myself that the discrete Cantor set, as defined in (2) [Exercise 3], is not recurrent. Should the definition read")#linebreak()#text(" ")#mi("x := \\bigcup_{N=1}^\\infty \\left\\{\\sum_{n=0}^N \\epsilon_n 10^n : \\epsilon_n \\in \\{-1, 0, 1\\}\\right\\}")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-27304")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2008")])]

#text("I think including zero or not does not make any differences.")

#text("Liu")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-27488")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2008")])]

#text("Dear Sean,")

#text("You’re right, it doesn’t quite work as stated. I’ll add the 0 to fix it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-33762")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2008")])]

#text("Dear Professor Tao:")

#text("When I first read (7), I just misunderstand x as a sequence until Exercise 12. I actually got confused there once. I finally got it though. I suggest that some explanation appear earlier so that it will become easier for beginners.")

#text("Liu")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-33770")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2008")])]

#text("Thanks for the suggestion!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 陶哲轩遍历论习题解答：第三讲 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-34078")[#strong[#text("陶哲轩遍历论习题解答：第三讲 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2008")])]

#text("[…] (注：遍历论为陶哲轩教授于今年年初的一门课程，我尝试将所有习题做出来，这是第三讲的十二个习题。这里是本讲的链接。文中一个颇为重要的概念为ultrafilter，在陶哲轩博客的这里有一个帖子有专门介绍。我自己也写过一个帖子在这里。) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a7571d414f1ac630621ee964b07d9f5648bcd48ca1ee4a3ea4c6191e8f1c3e0-e09407b1f72758f940d5b74ce366d2c68bbf2f5aa0cb02de89c2aea2f75d38b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fernando")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-34852")[#strong[#text("Fernando")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2009")])]

#text("Dear Professor Tao,")#linebreak()#text(" I am Brazilian. I am a undergraduate student of math.")#linebreak()#text(" I was studying the TOPOLOGICAL DYNAMICS’ s lecture notes of of prof Bryna Kra. I loved the field and, because of it, I am doing a work about it. Although it is a good “book”, it seemed to be a incomplete work. It has many obscure passages and obscure (or incomplete) theorems.")#linebreak()#text(" I need some references. I need a book to complete my work about these notes.")

#text("Could you help me? The notes is about use topological dynamics in order to prove theorems in combinatorics and number theory (focus in Ramsey theory). Until now, I only know about one reference (Fürstenberg – Recorrence in Ergodic Theory and Combinatorial Number theory)")

#text("Do you have any book or publication about it?")

#text("Thank you very much,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 6: Duality and the Hahn-Banach theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-35270")[#strong[#text("245B, Notes 6: Duality and the Hahn-Banach theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2009")])]

#text("[…] easier once one is acquainted with the Stone-Čech compactification, as discussed for instance in this lecture, and which we will discuss later in this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-35883")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")])]

#text("Dear Professor,")

#text("In the proof of Theorem 1, I think ")#mi("T^{\\Bbb Z}x = \\{T^nx : x \\in {\\Bbb Z}\\}")#text(" should be ")#mi("T^{\\Bbb Z}x = \\{T^nx : n \\in {\\Bbb Z}\\}")#text(". ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 11: The strong and weak topologies « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-36087")[#strong[#text("245B, Notes 11: The strong and weak topologies « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2009")])]

#text("[…] Proof: The functionals in are uniformly bounded and uniformly equicontinuous on , which by hypothesis has a countable dense subset . By the sequential Tychonoff theorem, any sequence in then has a subsequence which converges pointwise on , and thus converges pointwise on by Exercise 27 of Notes 10, and thus converges in the weak* topology. But as is closed in this topology, we conclude that is sequentially compact as required. Remark 4 One can also deduce the sequential Banach-Alaoglu theorem from the general Banach-Alaoglu theorem by observing that the weak* topology on the dual of a separable space is metrisable. The sequential Banach-Alaoglu theorem can break down for non-separable spaces. For instance, the closed unit ball in is not sequentially compact in the weak* topology, basically because the space of ultrafilters is not sequentially compact (see Exercise 12 of these lecture notes). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 13: Compactification and metrisation (optional) « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-36954")[#strong[#text("245B, Notes 13: Compactification and metrisation (optional) « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2009")])]

#text("[…] The existence of the compactification can be established by Zorn’s lemma (see these lecture notes of mine from last year). We shall shortly give several other constructions of the compactification. (All constructions, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 什么是ultrafilter « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-37630")[#strong[#text("什么是ultrafilter « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("[…] 二，Stone-Čech 紧化 （相关的材料参考Tao的遍历论讲义） […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/957f46c0ea443ab14d73c2b118321e0ce6f311d556e82db6222eb1a4ba660786-b7eaef63301fe832cabd2cdc52d617a9394f3c89ea31d07101728d9ef2aa4fd1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of albert kol")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-43773")[#strong[#text("albert kol")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2010")])]

#text("There is a natural question about recurrent action, if T be a recurrent homeomorphism of")#linebreak()#text(" a compact metric space X; If the (X,T) has an oly minimal set is it possible to characterize it?")#linebreak()#text(" (is it a periodic orbit). The same question if one take the action defined by a transformation group?")#linebreak()#text(" Thank you")#linebreak()#text(" alberto")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Solutions to Ergodic Theory：Lecture Seven « Xiaochuan Liu's Weblog")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-45601")[#strong[#text("Solutions to Ergodic Theory：Lecture Seven « Xiaochuan Liu's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2010")])]

#text("[…] naturally a Ellis group of the system . The following is basically the same proof of lemma 1 from lecture 3. If , then we can choose some N such that . Suppose for contradiction that the set is not […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Ultraproducts as a bridge between hard analysis and soft analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-93084")[#strong[#text("254A, Notes 6: Ultraproducts as a bridge between hard analysis and soft analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2011")])]

#text("[…] an interesting semigroup structure, which is of importance in Ramsey theory and ergodic theory; see this previous post for more details. Exercise 5 (Ultrafilters as Banach limits) Recall that a functional from the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-154148")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2012")])]

#text("Regarding the comment: “Hence, by Zorn’s lemma (modulo a technical step in which one shows that the moduli space of compactifications of X is a set rather than a class),” in the proof of Theorem 1.")

#text("Asking from the perspective of someone not so familiar with set theory: How does one, in practice, typically go about showing that something is a set rather than a proper class? It is not at all clear to me what is the precise statement that one should even be trying to prove, nor what kinds of hypotheses or deductive steps we are allowed to make.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-154215")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2012")])]

#text("Basically, one has to take full advantage of the axioms of ZFC set theory, in particular the ")#link("http://en.wikipedia.org/wiki/Axiom_of_power_set")[#text("power set axiom")]#text(", the ")#link("http://en.wikipedia.org/wiki/Axiom_of_specification")[#text("axiom (schema) of specification")]#text(", and the ")#link("http://en.wikipedia.org/wiki/Axiom_of_replacement")[#text("axiom (schema) of replacement")]#text(". To show that some class F is a set, typically one establishes some sort of identification between elements of F and some data in a known set (e.g. the set of subsets of some other set); if the data uniquely determines that element, then the above axioms are usually sufficient to demonstrate that F (or some proxy for F) is a set.")

#text("In this case, to try to find data that determines a compactification of X up to isomorphism, one can note that a point in such a compactification can be determined by its neighbourhood base restricted to X, and that the family of all such bases as one varies over the compactification determines the compactification up to isomorphism. So one can use the collection of all families of bases that come from a compactification as a “parameterisation” of the moduli space.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An informal version of the Furstenberg correspondence principle | What's new")]], [#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/comment-page-1/#comment-221344")[#strong[#text("An informal version of the Furstenberg correspondence principle | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2013")])]

#text("[…] rise to some other important ways to extract a dynamical interpretation to a set of integers. See this blog post for some variants on this […]")
]
