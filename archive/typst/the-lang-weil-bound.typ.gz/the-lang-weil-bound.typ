// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/
// Converted to Typst by tao2typ: "2026-10-14T15:18:27.684206+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Lang-Weil bound", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Lang-Weil bound")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 August 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/")[#text("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{F}")#text(" be a finite field, with ")#link("http://en.wikipedia.org/wiki/Algebraic_closure")[#text("algebraic closure")]#text(" ")#mi("{\\overline{F}}")#text(", and let ")#mi("{V}")#text(" be an (affine) ")#link("http://en.wikipedia.org/wiki/Algebraic_variety")[#text("algebraic variety")]#text(" defined over ")#mi("{\\overline{F}}")#text(", by which I mean a set of the form")

#align(center)[#tao-fit-display[#mitex("V = \\{ x \\in \\overline{F}^d: P_1(x) = \\ldots = P_m(x) = 0 \\}")]]

#text("for some ambient dimension ")#mi("{d \\geq 0}")#text(", and some finite number of polynomials ")#mi("{P_1,\\ldots,P_m: \\overline{F}^d \\rightarrow \\overline{F}}")#text(". In order to reduce the number of subscripts later on, let us say that ")#mi("{V}")#text(" has ")#emph[#text("complexity at most ")#mi("{M}")]#text(" if ")#mi("{d}")#text(", ")#mi("{m}")#text(", and the degrees of the ")#mi("{P_1,\\ldots,P_m}")#text(" are all less than or equal to ")#mi("{M}")#text(". Note that we do not require at this stage that ")#mi("{V}")#text(" be irreducible (i.e. not the union of two strictly smaller varieties), or defined over ")#mi("{F}")#text(", though we will often specialise to these cases later in this post. (Also, everything said here can also be applied with almost no changes to projective varieties, but we will stick with affine varieties for sake of concreteness.)")

#text("One can consider two crude measures of how “big” the variety ")#mi("{V}")#text(" is. The first measure, which is algebraic geometric in nature, is the ")#emph[#text("dimension")]#text(" ")#mi("{\\text{dim}(V)}")#text(" of the variety ")#mi("{V}")#text(", which is an integer between ")#mi("{0}")#text(" and ")#mi("{d}")#text(" (or, depending on convention, ")#mi("{-\\infty}")#text(", ")#mi("{-1}")#text(", or undefined, if ")#mi("{V}")#text(" is empty) that can be ")#link("http://en.wikipedia.org/wiki/Dimension_of_an_algebraic_variety")[#text("defined in a large number of ways")]#text(" (e.g. it is the largest ")#mi("{r}")#text(" for which the generic linear projection from ")#mi("{V}")#text(" to ")#mi("{\\overline{F}^r}")#text(" is dominant, or the smallest ")#mi("{r}")#text(" for which the intersection with a generic codimension ")#mi("{r}")#text(" subspace is non-empty). The second measure, which is number-theoretic in nature, is the number ")#tao-math("{\\left|V(F)\\right| = \\left|V \\cap F^d\\right|}", block: false)#text(" of ")#mi("{F}")#text("-points of ")#mi("{V}")#text(", i.e. points ")#mi("{x = (x_1,\\ldots,x_d)}")#text(" in ")#mi("{V}")#text(" all of whose coefficients lie in the finite field, or equivalently the number of solutions to the system of equations ")#mi("{P_i(x_1,\\ldots,x_d) = 0}")#text(" for ")#mi("{i=1,\\ldots,m}")#text(" with variables ")#mi("{x_1,\\ldots,x_d}")#text(" in ")#mi("{F}")#text(".")

#text("These two measures are linked together in a number of ways. For instance, we have the basic ")#link("http://en.wikipedia.org/wiki/Schwartz%E2%80%93Zippel_lemma")[#text("Schwarz-Zippel type bound")]#text(" (which, in this qualitative form, goes back at least to Lemma 1 of the ")#link("http://www.ams.org/mathscinet-getitem?mr=65218")[#text("work of Lang and Weil")]#text(" in 1954).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Schwarz-Zippel type bound)")]#text(" ")#metadata(none) <tao-8651347d5d501956a468>#text(" Let ")#mi("{V}")#text(" be a variety of complexity at most ")#mi("{M}")#text(". Then we have ")#tao-math("{\\left|V(F)\\right| \\ll_M \\left|F\\right|^{\\text{dim}(V)}}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" (Sketch) For the purposes of exposition, we will not carefully track the dependencies of implied constants on the complexity ")#mi("{M}")#text(", instead simply assuming that all of these quantities remain controlled throughout the argument. (If one wished, one could obtain ineffective bounds on these quantities by an ultralimit argument, as discussed ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("in this previous post")]#text(", or equivalently by moving everything over to a nonstandard analysis framework; one could also obtain such uniformity using the machinery of schemes.)")

#text("We argue by induction on the ambient dimension ")#mi("{d}")#text(" of the variety ")#mi("{V}")#text(". The ")#mi("{d=0}")#text(" case is trivial, so suppose ")#mi("{d \\geq 1}")#text(" and that the claim has already been proven for ")#mi("{d-1}")#text(". By breaking up ")#mi("{V}")#text(" into irreducible components we may assume that ")#mi("{V}")#text(" is irreducible (this requires some control on the number and complexity of these components, but this is available, as ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("discussed in this previous post")]#text("). For each ")#mi("{x_1,\\ldots,x_{d-1} \\in \\overline{F}}")#text(", the fibre ")#mi("{\\{ x_d \\in \\overline{F}: (x_1,\\ldots,x_{d-1},x_d) \\in V \\}}")#text(" is either one-dimensional (and thus all of ")#mi("{\\overline{F}}")#text(") or zero-dimensional. In the latter case, one has ")#mi("{O_M(1)}")#text(" points in the fibre from the fundamental theorem of algebra (indeed one has a bound of ")#mi("{D}")#text(" in this case), and ")#mi("{(x_1,\\ldots,x_{d-1})}")#text(" lives in the projection of ")#mi("{V}")#text(" to ")#mi("{\\overline{F}^{d-1}}")#text(", which is a variety of dimension at most ")#mi("{\\text{dim}(V)}")#text(" and controlled complexity, so the contribution of this case is acceptable from the induction hypothesis. In the former case, the fibre contributes ")#tao-math("{\\left|F\\right|}", block: false)#text(" ")#mi("{F}")#text("-points, but ")#mi("{(x_1,\\ldots,x_{d-1})}")#text(" lies in a variety in ")#mi("{\\overline{F}^{d-1}}")#text(" of dimension at most ")#mi("{\\text{dim}(V)-1}")#text(" (since otherwise ")#mi("{V}")#text(" would contain a subvariety of dimension at least ")#mi("{\\text{dim}(V)+1}")#text(", which is absurd) and controlled complexity, and so the contribution of this case is also acceptable from the induction hypothesis. ")#mi("\\Box")

#text("One can improve the bound on the implied constant to be linear in the degree of ")#mi("{V}")#text(" (see e.g. Claim 7.2 of ")#link("http://arxiv.org/abs/1203.4532")[#text("this paper of Dvir, Kollar, and Lovett")]#text(", or Lemma A.3 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2604979")[#text("this paper of Ellenberg, Oberlin, and myself")]#text("), but we will not be concerned with these improvements here.")

#text("Without further hypotheses on ")#mi("{V}")#text(", the above upper bound is sharp (except for improvements in the implied constants). For instance, the variety")

#align(center)[#tao-fit-display[#mitex("V := \\{ (x_1,\\ldots,x_d) \\in \\overline{F}^d: \\prod_{j=1}^D (x_d - a_j) = 0\\},")]]

#text("where ")#mi("{a_1,\\ldots,a_D \\in F}")#text(" are distict, is the union of ")#mi("{D}")#text(" distinct hyperplanes of dimension ")#mi("{d-1}")#text(", with ")#tao-math("{\\left|V(F)\\right| = D \\left|F\\right|^{d-1}}", block: false)#text(" and complexity ")#mi("{\\max(D,d)}")#text("; similar examples can easily be concocted for other choices of ")#mi("{\\text{dim}(V)}")#text(". In the other direction, there is also no non-trivial lower bound for ")#tao-math("{\\left|V(F)\\right|}", block: false)#text(" without further hypotheses on ")#mi("{V}")#text(". For a trivial example, if ")#mi("{a}")#text(" is an element of ")#mi("{\\overline{F}}")#text(" that does not lie in ")#mi("{F}")#text(", then the hyperplane")

#align(center)[#tao-fit-display[#mitex("V := \\{ (x_1,\\ldots,x_d) \\in \\overline{F}^d: x_d - a = 0 \\}")]]

#text("clearly has no ")#mi("{F}")#text("-points whatsoever, despite being a ")#mi("{d-1}")#text("-dimensional variety in ")#mi("{\\overline{F}^d}")#text(" of complexity ")#mi("{d}")#text(". For a slightly less non-trivial example, if ")#mi("{a}")#text(" is an element of ")#mi("{F}")#text(" that is not a quadratic residue, then the variety")

#align(center)[#tao-fit-display[#mitex("V := \\{ (x_1,\\ldots,x_d) \\in \\overline{F}^d: x_d^2 - a = 0 \\},")]]

#text("which is the union of two hyperplanes, still has no ")#mi("{F}")#text("-points, even though this time the variety is defined over ")#mi("{F}")#text(" instead of ")#mi("{\\overline{F}}")#text(" (by which we mean that the defining polynomial(s) have all of their coefficients in ")#mi("{F}")#text("). There is however the important ")#link("http://www.ams.org/mathscinet-getitem?mr=65218")[#text("Lang-Weil bound")]#text(" that allows for a much better estimate as long as ")#mi("{V}")#text(" is both defined over ")#mi("{F}")#text(" ")#emph[#text("and")]#text(" irreducible:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Lang-Weil bound)")]#text(" ")#metadata(none) <tao-580a93334363ca8ef3d9>#text(" Let ")#mi("{V}")#text(" be a variety of complexity at most ")#mi("{M}")#text(". Assume that ")#mi("{V}")#text(" is defined over ")#mi("{F}")#text(", and that ")#mi("{V}")#text(" is irreducible as a variety over ")#mi("{\\overline{F}}")#text(" (i.e. ")#mi("{V}")#text(" is ")#emph[#text("geometrically irreducible")]#text(" or ")#link("http://en.wikipedia.org/wiki/Absolutely_irreducible")[#text("absolutely irreducible")]#text("). Then")

#align(center)[#tao-fit-display[#tao-math("\\left|V(F)\\right| = (1 + O_M(\\left|F\\right|^{-1/2})) \\left|F\\right|^{\\text{dim}(V)}.", block: true)]]
]

#text("Again, more explicit bounds on the implied constant here are known, but will not be the focus of this post. As the previous examples show, the hypotheses of definability over ")#mi("{F}")#text(" and geometric irreducibility are both necessary.")

#text("The Lang-Weil bound is already non-trivial in the model case ")#mi("{d=2, \\text{dim}(V)=1}")#text(" of plane curves:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Hasse-Weil bound)")]#text(" ")#metadata(none) <tao-740fc4991133b1523bc4>#text(" Let ")#mi("{P: \\overline{F}^2 \\rightarrow \\overline{F}}")#text(" be an irreducible polynomial of degree ")#mi("{D}")#text(" with coefficients in ")#mi("{F}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ (x,y) \\in F^2: P(x,y) = 0 \\}\\right| = \\left|F\\right| + O_D( \\left|F\\right|^{1/2} ).", block: true)]]
]

#text("Thus, for instance, if ")#mi("{a,b \\in F}")#text(", then the elliptic curve ")#mi("{\\{ (x,y) \\in F^2: y^2 = x^3 + ax + b \\}}")#text(" has ")#tao-math("{\\left|F\\right| + O(\\left|F\\right|^{1/2})}", block: false)#text(" ")#mi("{F}")#text("-points, a result ")#link("http://en.wikipedia.org/wiki/Hasse's_theorem_on_elliptic_curves")[#text("first established")]#text(" by Hasse. The Hasse-Weil bound is already quite non-trivial, being the analogue of the Riemann hypothesis for plane curves. For hyper-elliptic curves, an elementary proof (due to Stepanov) is discussed in ")#link("https://terrytao.wordpress.com/2009/08/18/the-least-quadratic-nonresidue-and-the-square-root-barrier/")[#text("this previous post")]#text(". For general plane curves, the first proof was ")#link("http://www.ams.org/mathscinet-getitem?mr=0029393")[#text("by Weil")]#text(" (leading to his famous ")#link("http://en.wikipedia.org/wiki/Weil_conjectures")[#text("Weil conjectures")]#text("); there is also a nice version of Stepanov’s argument ")#link("http://www.ams.org/mathscinet-getitem?mr=429903")[#text("due to Bombieri")]#text(" covering this case which is a little less elementary (relying crucially on the ")#link("http://en.wikipedia.org/wiki/Riemann%E2%80%93Roch_theorem")[#text("Riemann-Roch theorem")]#text(" for the upper bound, and a lifting trick to then get the lower bound), which I briefly summarise later in this post. The full Lang-Weil bound is deduced from the Hasse-Weil bound by an induction argument using generic hyperplane slicing, as I will also summarise later in this post.")

#text("The hypotheses of definability over ")#mi("{F}")#text(" and geometric irreducibility in the Lang-Weil can be removed after inserting a geometric factor:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4 (Lang-Weil bound, alternate form)")]#text(" ")#metadata(none) <tao-a35d72df142aa6666fc5>#text(" Let ")#mi("{V}")#text(" be a variety of complexity at most ")#mi("{M}")#text(". Then one has")

#align(center)[#tao-fit-display[#tao-math("\\left|V(F)\\right| = (c(V) + O_M(\\left|F\\right|^{-1/2})) \\left|F\\right|^{\\text{dim}(V)}", block: true)]]

#text("where ")#mi("{c(V)}")#text(" is the number of top-dimensional components of ")#mi("{V}")#text(" (i.e. geometrically irreducible components of ")#mi("{V}")#text(" of dimension ")#mi("{\\text{dim}(V)}")#text(") that are definable over ")#mi("{F}")#text(", or equivalently are invariant with respect to the ")#link("http://en.wikipedia.org/wiki/Frobenius_endomorphism")[#text("Frobenius endomorphism")]#text(" ")#tao-math("{x \\mapsto x^{\\left|F\\right|}}", block: false)#text(" that defines ")#mi("{F}")#text(".")
]

#emph[#text("Proof:")]#text(" By breaking up a general variety ")#mi("{V}")#text(" into components (and using Lemma ")#link(<tao-8651347d5d501956a468>)[#text("1")]#text(" to dispose of any lower-dimensional components), it suffices to establish this claim when ")#mi("{V}")#text(" is itself geometrically irreducible. If ")#mi("{V}")#text(" is definable over ")#mi("{F}")#text(", the claim follows from Theorem ")#link(<tao-580a93334363ca8ef3d9>)[#text("2")]#text(". If ")#mi("{V}")#text(" is not definable over ")#mi("{F}")#text(", then it is not fixed by the Frobenius endomorphism ")#mi("{Frob}")#text(" (since otherwise one could produce a set of defining polynomials that were fixed by Frobenius and thus defined over ")#mi("{F}")#text(" by using some canonical basis (such as a ")#link("http://en.wikipedia.org/wiki/Gr%C3%B6bner_basis")[#text("reduced Grobner basis")]#text(") for the associated ideal), and so ")#mi("{V \\cap Frob(V)}")#text(" has strictly smaller dimension than ")#mi("{V}")#text(". But ")#mi("{V \\cap Frob(V)}")#text(" captures all the ")#mi("{F}")#text("-points of ")#mi("{V}")#text(", so in this case the claim follows from Lemma ")#link(<tao-8651347d5d501956a468>)[#text("1")]#text(". ")#mi("\\Box")

#text("Note that if ")#mi("{V}")#text(" is reducible but is itself defined over ")#mi("{F}")#text(", then the Frobenius endomorphism preserves ")#mi("{V}")#text(" itself, but may permute the components of ")#mi("{V}")#text(" around. In this case, ")#mi("{c(V)}")#text(" is the number of fixed points of this permutation action of Frobenius on the components. In particular, ")#mi("{c(V)}")#text(" is always a natural number between ")#mi("{0}")#text(" and ")#mi("{O_M(1)}")#text("; thus we see that regardless of the geometry of ")#mi("{V}")#text(", the normalised count ")#tao-math("{\\left|V(F)\\right|/\\left|F\\right|^{\\text{dim}(V)}}", block: false)#text(" is asymptotically restricted to a bounded range of natural numbers (in the regime where the complexity stays bounded and ")#tao-math("{\\left|F\\right|}", block: false)#text(" goes to infinity).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" Consider the variety")

#align(center)[#tao-fit-display[#mitex("V := \\{ (x,y) \\in \\overline{F}^2: x^2 - ay^2 = 0 \\}")]]

#text("for some non-zero parameter ")#mi("{a \\in F}")#text(". Geometrically (by which we basically mean “when viewed over the algebraically closed field ")#mi("{\\overline{F}}")#text("“), this is the union of two lines, with slopes corresponding to the two square roots of ")#mi("{a}")#text(". If ")#mi("{a}")#text(" is a quadratic residue, then both of these lines are defined over ")#mi("{F}")#text(", and are fixed by Frobenius, and ")#mi("{c(V) = 2}")#text(" in this case. If ")#mi("{a}")#text(" is not a quadratic residue, then the lines are not defined over ")#mi("{F}")#text(", and the Frobenius automorphism permutes the two lines while preserving ")#mi("{V}")#text(" as a whole, giving ")#mi("{c(V)=0}")#text(" in this case.")
]

#text("Corollary ")#link(<tao-a35d72df142aa6666fc5>)[#text("4")]#text(" effectively computes (at least to leading order) the number-theoretic size ")#tao-math("{\\left|V(F)\\right|}", block: false)#text(" of a variety in terms of geometric information about ")#mi("{V}")#text(", namely its dimension ")#mi("{\\text{dim}(V)}")#text(" and the number ")#mi("{c(V)}")#text(" of top-dimensional components fixed by Frobenius. It turns out that with a little bit more effort, one can extend this connection to cover not just a single variety ")#mi("{V}")#text(", but a family of varieties indexed by points in some base space ")#mi("{W}")#text(". More precisely, suppose we now have two affine varieties ")#mi("{V,W}")#text(" of bounded complexity, together with a ")#link("http://en.wikipedia.org/wiki/Regular_map_(algebraic_geometry)")[#text("regular map")]#text(" ")#mi("{\\phi: V \\rightarrow W}")#text(" of bounded complexity (the definition of complexity of a regular map is a bit technical, see e.g. ")#link("http://arxiv.org/abs/1005.1881")[#text("this paper")]#text(", but one can think for instance of a polynomial or rational map of bounded degree as a good example). It will be convenient to assume that the base space ")#mi("{W}")#text(" is irreducible. If the map ")#mi("{\\phi}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Dominant_morphism")[#text("dominant map")]#text(" (i.e. the image ")#mi("{\\phi(V)}")#text(" is Zariski dense in ")#mi("{W}")#text("), then standard algebraic geometry results tell us that the fibres ")#mi("{\\phi^{-1}(\\{w\\})}")#text(" are an unramified family of ")#mi("{\\text{dim}(V)-\\text{dim}(W)}")#text("-dimensional varieties outside of an exceptional subset ")#mi("{W^{\\prime}}")#text(" of ")#mi("{W}")#text(" of dimension strictly smaller than ")#mi("{\\text{dim}(W)}")#text(" (and with ")#mi("{\\phi^{-1}(W^{\\prime})}")#text(" having dimension strictly smaller than ")#mi("{\\text{dim}(V)}")#text("); see e.g. Section I.6.3 of ")#link("http://www.ams.org/mathscinet-getitem?mr=447223")[#text("Shafarevich")]#text(".")

#text("Now suppose that ")#mi("{V}")#text(", ")#mi("{W}")#text(", and ")#mi("{\\phi}")#text(" are defined over ")#mi("{F}")#text(". Then, by Lang-Weil, ")#mi("{W(F)}")#text(" has ")#tao-math("{(1 + O(\\left|F\\right|^{-1/2})) \\left|F\\right|^{\\text{dim}(W)}}", block: false)#text(" ")#mi("{F}")#text("-points, and by Schwarz-Zippel, for all but ")#tao-math("{O( \\left|F\\right|^{\\text{dim}(W)-1})}", block: false)#text(" of these ")#mi("{F}")#text("-points ")#mi("{w}")#text(" (the ones that lie in the subvariety ")#mi("{W^{\\prime}}")#text("), the fibre ")#mi("{\\phi^{-1}(\\{w\\})}")#text(" is an algebraic variety defined over ")#mi("{F}")#text(" of dimension ")#mi("{\\text{dim}(V)-\\text{dim}(W)}")#text(". By using ultraproduct arguments (see e.g. Lemma 3.7 of ")#link("http://arxiv.org/abs/1005.1881")[#text("this paper of mine")]#text(" with Emmanuel Breuillard and Ben Green), this variety can be shown to have bounded complexity, and thus by Corollary ")#link(<tao-a35d72df142aa6666fc5>)[#text("4")]#text(", has ")#tao-math("{(c(\\phi^{-1}(\\{w\\})) + O(\\left|F\\right|^{-1/2}) \\left|F\\right|^{\\text{dim}(V)-\\text{dim}(W)}}", block: false)#text(" ")#mi("{F}")#text("-points. One can then ask how the quantity ")#mi("{c(\\phi^{-1}(\\{w\\})}")#text(" is distributed. A simple but illustrative example occurs when ")#mi("{V=W=F}")#text(" and ")#mi("{\\phi: F \\rightarrow F}")#text(" is the polynomial ")#mi("{\\phi(x) := x^2}")#text(". Then ")#mi("{c(\\phi^{-1}(\\{w\\})}")#text(" equals ")#mi("{2}")#text(" when ")#mi("{w}")#text(" is a non-zero quadratic residue and ")#mi("{0}")#text(" when ")#mi("{w}")#text(" is a non-zero quadratic non-residue (and ")#mi("{1}")#text(" when ")#mi("{w}")#text(" is zero, but this is a negligible fraction of all ")#mi("{w}")#text("). In particular, in the asymptotic limit ")#tao-math("{\\left|F\\right| \\rightarrow \\infty}", block: false)#text(", ")#mi("{c(\\phi^{-1}(\\{w\\})}")#text(" is equal to ")#mi("{2}")#text(" half of the time and ")#mi("{0}")#text(" half of the time.")

#text("Now we describe the asymptotic distribution of the ")#mi("{c(\\phi^{-1}(\\{w\\}))}")#text(". We need some additional notation. Let ")#mi("{w_0}")#text(" be an ")#mi("{F}")#text("-point in ")#mi("{W \\backslash W^{\\prime}}")#text(", and let ")#mi("{\\pi_0( \\phi^{-1}(\\{w_0\\}) )}")#text(" be the connected components of the fibre ")#mi("{\\phi^{-1}(\\{w_0\\})}")#text(". As ")#mi("{\\phi^{-1}(\\{w_0\\})}")#text(" is defined over ")#mi("{F}")#text(", this set of components is permuted by the Frobenius endomorphism ")#mi("{Frob}")#text(". But there is also an action by monodromy of the fundamental group ")#mi("{\\pi_1(W \\backslash W^{\\prime})}")#text(" (this requires a certain amount of ")#link("http://en.wikipedia.org/wiki/%C3%89tale_fundamental_group")[#text("étale machinery")]#text(" to properly set up, as we are working over a positive characteristic field rather than over the complex numbers, but I am going to ignore this rather important detail here, as I still don’t fully understand it). This fundamental group may be infinite, but (by the étale construction) is always ")#link("http://en.wikipedia.org/wiki/Profinite_group")[#text("profinite")]#text(", and in particular has a ")#emph[#text("Haar probability measure")]#text(", in which every finite index subgroup (and their cosets) are measurable. Thus we may meaningfully talk about elements drawn uniformly at random from this group, so long as we work only with the profinite ")#mi("{\\sigma}")#text("-algebra on ")#mi("{\\pi_1(W \\backslash W^{\\prime})}")#text(" that is generated by the cosets of the finite index subgroups of this group (which will be the only relevant sets we need to measure when considering the action of this group on finite sets, such as the components of a generic fibre).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Lang-Weil with parameters)")]#text(" ")#metadata(none) <tao-5951157b65b0df935bcc>#text(" Let ")#mi("{V, W}")#text(" be varieties of complexity at most ")#mi("{M}")#text(" with ")#mi("{W}")#text(" irreducible, and let ")#mi("{\\phi: V \\rightarrow W}")#text(" be a dominant map of complexity at most ")#mi("{M}")#text(". Let ")#mi("{w_0}")#text(" be an ")#mi("{F}")#text("-point of ")#mi("{W \\backslash W^{\\prime}}")#text(". Then, for any natural number ")#mi("{a}")#text(", one has ")#mi("{c(\\phi^{-1}(\\{w\\})) = a}")#text(" for ")#tao-math("{(\\mathop{\\bf P}( X = a ) + O_M(\\left|F\\right|^{-1/2})) \\left|F\\right|^{\\text{dim}(W)}}", block: false)#text(" values of ")#mi("{w \\in W(F)}")#text(", where ")#mi("{X}")#text(" is the random variable that counts the number of components of a generic fibre ")#mi("{\\phi^{-1}(w_0)}")#text(" that are invariant under ")#mi("{g \\circ Frob}")#text(", where ")#mi("{g}")#text(" is an element chosen uniformly at random from the étale fundamental group ")#mi("{\\pi_1(W \\backslash W^{\\prime})}")#text(". In particular, in the asymptotic limit ")#tao-math("{\\left|F\\right| \\rightarrow \\infty}", block: false)#text(", and with ")#mi("{w}")#text(" chosen uniformly at random from ")#mi("{W(F)}")#text(", ")#mi("{c(\\phi^{-1}(\\{w\\}))}")#text(" (or, equivalently, ")#tao-math("{\\left|\\phi^{-1}(\\{w\\})(F)\\right| / \\left|F\\right|^{\\text{dim}(V)-\\text{dim}(W)}}", block: false)#text(") and ")#mi("{X}")#text(" have the same asymptotic distribution.")
]

#text("This theorem generalises Corollary ")#link(<tao-a35d72df142aa6666fc5>)[#text("4")]#text(" (which is the case when ")#mi("{W}")#text(" is just a point, so that ")#mi("{\\phi^{-1}(\\{w\\})}")#text(" is just ")#mi("{V}")#text(" and ")#mi("{g}")#text(" is trivial). Informally, the effect of a non-trivial parameter space ")#mi("{W}")#text(" on the Lang-Weil bound is to push around the Frobenius map by monodromy for the purposes of counting invariant components, and a randomly chosen set of parameters corresponds to a randomly chosen loop on which to perform monodromy.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" Let ")#mi("{V=W=F}")#text(" and ")#mi("{\\phi(x) = x^m}")#text(" for some fixed ")#mi("{m \\geq 1}")#text("; to avoid some technical issues let us suppose that ")#mi("{m}")#text(" is coprime to ")#tao-math("{\\left|F\\right|}", block: false)#text(". Then ")#mi("{W^{\\prime}}")#text(" can be taken to be ")#mi("{\\{0\\}}")#text(", and for a base point ")#mi("{w_0 \\in W \\backslash W^{\\prime}}")#text(" we can take ")#mi("{w_0=1}")#text(". The fibre ")#mi("{\\phi^{-1}(\\{1\\})}")#text(" – the ")#mi("{m^{th}}")#text(" roots of unity – can be identified with the cyclic group ")#mi("{{\\bf Z}/m{\\bf Z}}")#text(" by using a primitive root of unity. The étale fundamental group ")#mi("{\\pi(W \\backslash W^{\\prime}) = \\pi(\\overline{F} \\backslash 0)}")#text(" is (I think) isomorphic to the profinite closure ")#mi("{\\hat {\\bf Z}}")#text(" of the integers ")#mi("{{\\bf Z}}")#text(" (excluding the part of that closure coming from the characteristic of ")#mi("{F}")#text("). Not coincidentally, the integers ")#mi("{{\\bf Z}}")#text(" are the fundamental group of the complex analogue ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(" of ")#mi("{W \\backslash W^{\\prime}}")#text(". (Brian Conrad points out to me though that for more complicated varieties, such as covers of ")#mi("{\\overline{F} \\backslash \\{0\\}}")#text(" by a power of the characteristic, the etale fundamental group is more complicated than just a profinite closure of the ordinary fundamental group, due to the presence of ")#link("http://en.wikipedia.org/wiki/Artin%E2%80%93Schreier_theory")[#text("Artin-Schreier")]#text(" covers that are only ramified at infinity.) The action of this fundamental group on the fibres ")#mi("{{\\bf Z}/m{\\bf Z}}")#text(" can given by translation. Meanwhile, the Frobenius map ")#mi("{Frob}")#text(" on ")#mi("{{\\bf Z}/m{\\bf Z}}")#text(" is given by multiplication by ")#tao-math("{\\left|F\\right|}", block: false)#text(". A random element ")#mi("{g \\circ Frob}")#text(" then becomes a random affine map ")#tao-math("{x \\mapsto \\left|F\\right|x+b}", block: false)#text(" on ")#mi("{{\\bf Z}/m{\\bf Z}}")#text(", where ")#mi("{b}")#text(" chosen uniformly at random from ")#mi("{{\\bf Z}/m{\\bf Z}}")#text(". The number of fixed points of this map is equal to the greatest common divisor ")#tao-math("{(\\left|F\\right|-1,m)}", block: false)#text(" of ")#tao-math("{\\left|F\\right|-1}", block: false)#text(" and ")#mi("{m}")#text(" when ")#mi("{b}")#text(" is divisible by ")#tao-math("{(\\left|F\\right|-1,m)}", block: false)#text(", and equal to ")#mi("{0}")#text(" otherwise. This matches up with the elementary number fact that a randomly chosen non-zero element of ")#mi("{F}")#text(" will be an ")#mi("{m^{th}}")#text(" power with probability ")#tao-math("{1/(\\left|F\\right|-1,m)}", block: false)#text(", and when this occurs, the number of ")#mi("{m^{th}}")#text(" roots in ")#mi("{F}")#text(" will be ")#tao-math("{(\\left|F\\right|-1,m)}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" (Thanks to Jordan Ellenberg for this example.) Consider a random elliptic curve ")#mi("{E = \\{ y^2 = x^3 + ax + b \\}}")#text(", where ")#mi("{a,b}")#text(" are chosen uniformly at random, and let ")#mi("{m \\geq 1}")#text(". Let ")#mi("{E[m]}")#text(" be the ")#mi("{m}")#text("-torsion points of ")#mi("{E}")#text(" (i.e. those elements ")#mi("{g \\in E}")#text(" with ")#mi("{mg = 0}")#text(" using the elliptic curve addition law); as a group, this is isomorphic to ")#mi("{{\\bf Z}/m{\\bf Z} \\times {\\bf Z}/m{\\bf Z}}")#text(" (assuming that ")#mi("{F}")#text(" has sufficiently large characteristic, for simplicity), and consider the number of ")#mi("{F}")#text(" points of ")#mi("{E[m]}")#text(", which is a random variable taking values in the natural numbers between ")#mi("{0}")#text(" and ")#mi("{m^2}")#text(". In this case, the base variety ")#mi("{W}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Modular_curve")[#text("modular curve")]#text(" ")#mi("{X(1)}")#text(", and the covering variety ")#mi("{V}")#text(" is the modular curve ")#mi("{X_1(m)}")#text(". The generic fibre here can be identified with ")#mi("{{\\bf Z}/m{\\bf Z} \\times {\\bf Z}/m{\\bf Z}}")#text(", the monodromy action projects down to the action of ")#mi("{SL_2({\\bf Z}/m{\\bf Z})}")#text(", and the action of Frobenius on this fibre can be shown to be given by a ")#mi("{2 \\times 2}")#text(" matrix with determinant ")#tao-math("{\\left|F\\right|}", block: false)#text(" (with the exact choice of matrix depending on the choice of fibre and of the identification), so the distribution of the number of ")#mi("{F}")#text("-points of ")#mi("{E[m]}")#text(" is asymptotic to the distribution of the number of fixed points ")#mi("{X}")#text(" of a random linear map of determinant ")#tao-math("{\\left|F\\right|}", block: false)#text(" on ")#mi("{{\\bf Z}/m{\\bf Z} \\times {\\bf Z}/m{\\bf Z}}")#text(".")
]

#text("Theorem ")#link(<tao-5951157b65b0df935bcc>)[#text("5")]#text(" seems to be well known “folklore” among arithmetic geometers, though I do not know of an explicit reference for it. I enjoyed deriving it for myself (though my derivation is somewhat incomplete due to my lack of understanding of ")#link("http://en.wikipedia.org/wiki/%C3%89tale_cohomology")[#text("étale cohomology")]#text(") from the ordinary Lang-Weil theorem and the moment method. I’m recording this derivation later in this post, mostly for my own benefit (as I am still in the process of learning this material), though perhaps some other readers may also be interested in it.")

#text("Caveat: not all details are fully fleshed out in this writeup, particularly those involving the finer points of algebraic geometry and étale cohomology, as my understanding of these topics is not as complete as I would like it to be.")

#text("Many thanks to Brian Conrad and Jordan Ellenberg for helpful discussions on these topics.")

#metadata(none) <tao-1396846b8ba9e132b643>

#heading(level: 1)[#strong[#text(" — 1. The Stepanov-Bombieri proof of the Hasse-Weil bound — ")]]

#text("We now give (most of) the Stepanov-Bombieri proof of Theorem ")#link(<tao-740fc4991133b1523bc4>)[#text("3")]#text(", following the ")#link("http://www.ams.org/mathscinet-getitem?mr=429903")[#text("exposition of Bombieri")]#text(" (see also ")#link("http://www.math.ethz.ch/~kowalski/exponential-sums.html")[#text("these lecture notes of Kowalski")]#text(", focusing on the model case of curves of the form ")#mi("{\\{ (x,y): y^d = P(x)\\}}")#text("). In this section all implied constants are allowed to depend on the degree ")#mi("{D}")#text(" of the polynomial ")#mi("{P(x,y)}")#text(".")

#text("Let ")#mi("{C(F)}")#text(" be the ")#mi("{F}")#text("-points of the curve ")#mi("{C := \\{ (x,y) \\in \\overline{F}^2: P(x,y) = 0\\}}")#text("; the hypothesis that ")#mi("{P}")#text(" is irreducible means that the curve ")#mi("{C}")#text(" is also irreducible. Our task is to establish the upper bound ")#metadata(none) <tao-aee610558292023758a4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|C(F)\\right| \\leq \\left|F\\right| + O( \\left|F\\right|^{1/2} )", block: true)]]

#text("and the lower bound ")#metadata(none) <tao-8c6fb1e9e37a1aea1d30>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|C(F)\\right| \\geq \\left|F\\right| - O( \\left|F\\right|^{1/2} ).", block: true)]]

#text("For technical reasons, we only prove these bounds directly when ")#tao-math("{\\left|F\\right|}", block: false)#text(" is a perfect square; the general case then follows by using the explicit formula for ")#mi("{C[F_{p^r}]}")#text(" as a function of ")#mi("{r}")#text(" and the tensor power trick, as explained in ")#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/")[#text("this previous post")]#text(".")

#text("Now we prove the upper bound. One uses Stepanov’s ")#emph[#text("polynomial method")]#text(" (discussed in ")#link("https://terrytao.wordpress.com/tag/polynomial-method/")[#text("these previous blog posts")]#text(", for a somewhat different set of applications). The basic idea here is to bound the size of a finite set ")#mi("{C(F)}")#text(" by constructing a non-trivial polynomial of controlled degree that vanishes to high order at each point of ")#mi("{C(F)}")#text(". Stepanov’s original argument projected the curve ")#mi("{C}")#text(" onto an affine line ")#mi("{\\overline{F}}")#text(" so that one could use ordinary one-dimensional polynomials, but Bombieri’s approach works directly on the curve ")#mi("{C}")#text(". For this it becomes convenient to work in the language of ")#link("http://en.wikipedia.org/wiki/Divisor_(algebraic_geometry)")[#text("divisors")]#text(" of rational functions, rather than zeroes of polynomials (and also it becomes slightly more convenient to work projectively rather than affinely, though I will gloss over this minor detail). Given a rational function ")#mi("{f}")#text(" on the curve ")#mi("{C}")#text(" (with coefficients in ")#mi("{\\overline{F}}")#text(") that is not identically zero or identically infinite on ")#mi("{C}")#text(", one can define the divisor ")#mi("{(f)}")#text(" to be the formal sum ")#mi("{\\sum_Q m_Q Q}")#text(" of the zeroes and poles ")#mi("{Q}")#text(" of ")#mi("{f}")#text(" on ")#mi("{C}")#text(", weighted by the multiplicity ")#mi("{m_Q}")#text(" of the zero or pole (with poles being viewed as having negative multiplicity; one has to be a little careful defining multiplicity at singular points of ")#mi("{C}")#text(", but this can be done by using a sufficiently algebraic formalism). The irreducibility of ")#mi("{C}")#text(" (which, of course, must be used at some juncture to prove the Hasse-Weil bound) ensures that this formal sum only has finitely many non-zero terms. One can show that the total signed multiplicities of zeroes and poles of ")#mi("{(f)}")#text(" always add up to zero: ")#mi("{\\sum_Q m_Q = 0}")#text(". (This generalises the fundamental theorem of algebra, which is the case when ")#mi("{C}")#text(" is a projective line.)")

#text("Fix a point ")#mi("{P_\\infty}")#text(" of ")#mi("{C}")#text(" (which one can think of as being at infinity), and for each degree ")#mi("{M}")#text(", let ")#mi("{L(M P_\\infty)}")#text(" be the space of those rational functions ")#mi("{f}")#text(" which are either zero, or have ")#mi("{(f) \\geq -M P_\\infty}")#text(", i.e. ")#mi("{f}")#text(" has a pole of order ")#mi("{M}")#text(" at ")#mi("{P_\\infty}")#text(" but no other poles; this generalises the space of polynomials of degree at most ")#mi("{M}")#text(", which corresponds to the case when ")#mi("{C}")#text(" is a projective line and ")#mi("{P_\\infty}")#text(" is the point at infinity. It is easy to see that ")#mi("{L(M P_\\infty)}")#text(" is a vector space (over ")#mi("{\\overline{F}}")#text("), which is non-decreasing in ")#mi("{M}")#text(". In the case when ")#mi("{C}")#text(" is a line, this space clearly has dimension ")#mi("{M+1}")#text(". The ")#link("http://en.wikipedia.org/wiki/Riemann%E2%80%93Roch_theorem")[#text("Riemann-Roch theorem")]#text(" is the generalisation of this to the case of a general curve. In its most precise form, it asserts the identity")

#align(center)[#tao-fit-display[#mitex("\\text{dim} L(M P_\\infty) + \\text{dim} L(K - M P_\\infty) = M - g + 1")]]

#text("where ")#mi("{g}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Genus_(mathematics)")[#text("genus")]#text(" of ")#mi("{C}")#text(", and ")#mi("{K}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Canonical_divisor")[#text("canonical divisor")]#text(" of ")#mi("{C}")#text(" (i.e. the divisor of the canonical line bundle of ")#mi("{C}")#text("). For our application, we will need two specific corollaries of the Riemann-Roch theorem, coming from the non-negativity and monotonicity properties of ")#mi("{L}")#text(". The first is the ")#emph[#text("Riemann inequality")]

#align(center)[#tao-fit-display[#mitex("M-g+1 \\leq \\text{dim} L(M P_\\infty) \\leq M+1")]]

#text("(so in particular ")#mi("{\\text{dim} L(M P_\\infty) = M+O(1)}")#text("), and the second is the inequality")

#align(center)[#tao-fit-display[#mitex("\\text{dim} L(M P_\\infty) \\leq \\text{dim} L((M+1) P_\\infty) \\leq \\text{dim} L(M P_\\infty) + 1")]]

#text("for all ")#mi("{M}")#text(". In particular, if we set ")#mi("{{\\mathcal N}}")#text(" to be the set of all degrees ")#mi("{M}")#text(" such that ")#mi("{\\text{dim} L(M P_\\infty) =\\text{dim} L((M-1) P_\\infty) + 1}")#text(", then ")#mi("{{\\mathcal N}}")#text(" consists of all but at most ")#mi("{g}")#text(" elements of the natural numbers, and we can find a sequence ")#mi("{\\{ e_M: M \\in {\\mathcal N}\\}}")#text(" of rational functions on ")#mi("{C}")#text(" with ")#mi("{e_M \\in \\text{dim}(M P_\\infty) \\backslash \\text{dim}((M-1) P_\\infty)}")#text(" (i.e. ")#mi("{e_M}")#text(" has a pole of order exactly ")#mi("{M}")#text(" at ")#mi("{P_\\infty}")#text(" and no other poles), with each ")#mi("{L(M P_\\infty)}")#text(" being spanned by the ")#mi("{f_{M^{\\prime}}}")#text(" with ")#mi("{M^{\\prime} \\leq M}")#text(". The ")#mi("{e_M}")#text(" can be viewed as a generalisation of the standard monomial basis ")#mi("{1,x,x^2,\\ldots}")#text(" of the polynomials of one variable. A key point here is that the degrees of this basis are all distinct; this will be crucial later on for ensuring that the polynomial we will be using for Stepanov’s method does not vanish identically.")

#text("We will not prove the Riemann-Roch theorem here, and simply assume it (and its consequences) as a black box. Next, we consider the Frobenius map ")#mi("{Frob: \\overline{F}^2 \\rightarrow \\overline{F}^2}")#text(" defined by ")#tao-math("{Frob(x,y) := (x^{\\left|F\\right|}, y^{\\left|F\\right|})}", block: false)#text(". As ")#mi("{C}")#text(" is defined over ")#mi("{F}")#text(", this map preserves ")#mi("{C}")#text(", and the fixed points of this map are precisely the ")#mi("{F}")#text("-points of ")#mi("{C}")#text(".")

#text("The plan is now to find a non-trivial element ")#mi("{f \\in L(M_* P_\\infty)}")#text(" for some controlled ")#mi("{M_*}")#text(" that vanishes to order at least ")#mi("{m}")#text(" at each fixed point of ")#mi("{Frob}")#text(" on ")#mi("{C}")#text(" for some ")#mi("{m}")#text(". As the total number of zeroes and poles of ")#mi("{f}")#text(" must agree, this forces")

#align(center)[#tao-fit-display[#tao-math("m \\left|C(F)\\right| \\leq M_*", block: true)]]

#text("and by optimising the parameters ")#mi("{m,M_*}")#text(" this should lead to ")#link(<tao-aee610558292023758a4>)[#text("(1)")]#text(".")

#text("The trick is to pick rational functions ")#mi("{f}")#text(" of a specific form, namely ")#metadata(none) <tao-599f7703547e9c8e980f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("f(x,y) = \\sum_{M \\in {\\mathcal N}: M \\leq M_0} f_M(x,y)^m e_M( Frob( x, y) )")]]

#text("where ")#mi("{M_0}")#text(" is a parameter to be optimised later, and for each ")#mi("{M}")#text(", ")#mi("{f_M}")#text(" lies in ")#mi("{L( M_1 P_\\infty )}")#text(" for another parameter ")#mi("{M_1}")#text(" to be optimised in later. We also pick ")#mi("{m}")#text(" to divide ")#tao-math("{\\left|F\\right|}", block: false)#text(", thus ")#mi("{m}")#text(" is a power of the characteristic ")#mi("{p}")#text(" of ")#mi("{F}")#text(" that is less than or equal to ")#tao-math("{\\left|F\\right|}", block: false)#text(". There are several reasons to working with polynomials of this form. The first is that because of the Frobenius endomorphism identity ")#tao-math("{e_M( Frob( x, y) ) = e_M(x,y)^{\\left|F\\right|}}", block: false)#text(", and ")#mi("{m}")#text(" divides ")#tao-math("{\\left|F\\right|}", block: false)#text(" by hypothesis, each term in ")#mi("{f(x,y)}")#text(" is an ")#mi("{m^{th}}")#text(" power, and hence (since ")#mi("{a^m+b^m = (a+b)^m}")#text(" in characteristic ")#mi("{p}")#text(") ")#mi("{f}")#text(" is itself the ")#mi("{m^{th}}")#text(" power of some rational function. As such, whenever ")#mi("{f}")#text(" vanishes at a point, it automatically vanishes to order at least ")#mi("{m}")#text(".")

#text("Secondly, in order for ")#mi("{f}")#text(" to vanish at every fixed point of the Frobenius map on ")#mi("{C}")#text(" (and thus vanish to order ")#mi("{m}")#text(" at each such point, by the above discussion), it is of course necessary and sufficient that the rational function ")#metadata(none) <tao-1143da2bc54c495c4be3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{M \\in {\\mathcal N}: M \\leq M_0} f_M(x,y)^m e_M( x, y ) = 0.")]]

#text("This is a constraint on the ")#mi("{f_M}")#text(" which is linear over ")#mi("{F_p}")#text(" (because the map ")#mi("{x \\mapsto x^m}")#text(" is linear over ")#mi("{F_p}")#text(", though not over ")#mi("{F}")#text("), and so we can try to enforce this constraint by linear algebra. Note that if each ")#mi("{f_M}")#text(" lies in ")#mi("{L(M_1 P_\\infty)}")#text(", then the rational function on the left-hand side of of ")#link(<tao-1143da2bc54c495c4be3>)[#text("(4)")]#text(" lies in ")#mi("{L( (mM_1 + M_0) P_\\infty)}")#text(", so the vanishing ")#link(<tao-1143da2bc54c495c4be3>)[#text("(4)")]#text(" imposes ")#mi("{r \\text{dim}( L((mM_1 + M_0) P_\\infty) ) = r(mM_1 + M_0 + O(1))}")#text(" homogeneous linear constraints (possibly dependent) over ")#mi("{F_p}")#text(" on the ")#mi("{f_M}")#text(", where ")#tao-math("{\\left|F\\right| =: p^r}", block: false)#text(". On the other hand, the dimension (over ")#mi("{F_p}")#text(") of the space of all possible ")#mi("{f_M}")#text(" is")

#align(center)[#tao-fit-display[#mitex("r |\\{ M \\in {\\mathcal N}: M \\leq M_0\\}| \\text{dim}( M_1 P_\\infty ) = r (M_0 + O(1)) (M_1 + O(1)).")]]

#text("Thus, by linear algebra, we can find a collection of ")#mi("{f_M \\in L(M_1 P_\\infty)}")#text(", not all zero, obeying ")#link(<tao-1143da2bc54c495c4be3>)[#text("(4)")]#text(" as long as we have ")#metadata(none) <tao-22b1f82e804e2c285b47>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("(M_0 - C)_+ (M_1 - C)_+ > m M_1 + M_0 + C")]]

#text("We are not done yet, because even if the ")#mi("{f_M}")#text(" are are not all zero, it is conceivable that the combined function ")#link(<tao-599f7703547e9c8e980f>)[#text("(3)")]#text(" could still vanish. But observe that if ")#mi("{M}")#text(" is the largest index for which ")#mi("{f_M}")#text(" is non-zero, then the rational function ")#mi("{f_M(x,y)^m e_M( Frob( x, y) )}")#text(" has a pole of order at least ")#tao-math("{M\\left|F\\right|}", block: false)#text(" at ")#mi("{P_\\infty}")#text(", and all the other terms have a pole of order at most ")#tao-math("{(M-1)\\left|F\\right| + m M_1}", block: false)#text(" (here it is crucial that the ")#mi("{e_M}")#text(" have poles of different orders at ")#mi("{P_\\infty}")#text(", thanks to Riemann-Roch). So as long as we have ")#metadata(none) <tao-29f201c40d7391e4fd22>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("m M_1 < \\left|F\\right|,", block: true)]]

#text("we have that ")#mi("{f}")#text(" does not vanish identically. As it vanishes to degree at least ")#mi("{m}")#text(" at every point of ")#mi("{C(F)}")#text(", and lies in ")#tao-math("{L( (mM_1 + \\left|F\\right| M_0) P_\\infty )}", block: false)#text(", and so we obtain the upper bound")

#align(center)[#tao-fit-display[#tao-math("\\left|C(F)\\right| \\leq \\frac{mM_1 + \\left|F\\right| M_0}{m}.", block: true)]]

#text("Now we optimise in the parameters ")#mi("{m, M_0, M_1}")#text(" subject to the constraints ")#link(<tao-22b1f82e804e2c285b47>)[#text("(5)")]#text(", ")#link(<tao-29f201c40d7391e4fd22>)[#text("(6)")]#text(". As ")#tao-math("{\\left|F\\right|}", block: false)#text(" is assumed to be a perfect square and is sufficiently large, then a little work shows that one can satisfy the constraints with ")#tao-math("{m := \\left|F\\right|^{1/2}}", block: false)#text(", ")#tao-math("{M_1 := \\left|F\\right|^{1/2}-1}", block: false)#text(", and ")#tao-math("{M_0 := \\left|F\\right|^{1/2}+C^{\\prime}}", block: false)#text(" for some sufficiently large ")#mi("{C^{\\prime}}")#text(", leading to the desired bound ")#link(<tao-aee610558292023758a4>)[#text("(1)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" When ")#tao-math("{\\left|F\\right|}", block: false)#text(" is not a perfect square, but is not a prime, one can still choose other values of ")#mi("{m}")#text(" and obtain a weaker version of ")#link(<tao-aee610558292023758a4>)[#text("(1)")]#text(" that is still non-trivial. But it is curious that Bombieri’s version of Stepanov’s argument breaks down completely when ")#mi("{F}")#text(" has prime order. As mentioned previously, one can still recover this case ")#emph[#text("a posteriori")]#text(" by the tensor product trick, but this requires the explicit formula for ")#tao-math("{\\left|C[F_{p^r}]\\right|}", block: false)#text(" which is not exactly trivial. On the other hand, other versions of Stepanov’s argument (such as the one given in ")#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/")[#text("this previous blog post")]#text(") do work in the prime order case, so this obstruction may be purely artificial in nature.")
]

#text("Now we need to pass from the upper bound ")#link(<tao-aee610558292023758a4>)[#text("(1)")]#text(" to the lower bound ")#link(<tao-8c6fb1e9e37a1aea1d30>)[#text("(2)")]#text(". In model cases, such as curves of the form ")#mi("{C = \\{ (x,y): y^d= P(x) \\}}")#text(" with ")#mi("{d-1}")#text(" not divisible by the characteristic of ")#mi("{F}")#text(", one can proceed by observing that the multiplicative group ")#mi("{F^\\times}")#text(" foliates into ")#mi("{d}")#text(" cosets ")#mi("{g_1 H,\\ldots, g_d H}")#text(" of the subgroup ")#mi("{H := \\{ x^d: x \\in F^\\times\\}}")#text(" of ")#mi("{d^{th}}")#text(" powers. Because of this, we see that the union ")#mi("{C^{\\prime} := C_1 \\cup \\ldots \\cup C_d}")#text(" of the curves ")#mi("{C_i := \\{ (x,y): g_i y^d = P(x) \\}}")#text(" contains exactly ")#mi("{d}")#text(" ")#mi("{F}")#text("-points on all but ")#mi("{O(1)}")#text(" vertical lines ")#mi("{\\{ x = a \\}}")#text(", ")#mi("{a \\in F}")#text(", and hence the union has cardinality ")#tao-math("{d\\left|F\\right|+O(1)}", block: false)#text(" ")#mi("{F}")#text("-points. (In other words, the projection ")#mi("{(x,y) \\mapsto x}")#text(" from ")#mi("{C^{\\prime}}")#text(" to ")#mi("{\\overline{F}}")#text(" is generically ")#mi("{d}")#text("-to-one. Also, as the ")#mi("{C_i}")#text(" are all dilations of ")#mi("{C}")#text(", they will be irreducible if ")#mi("{C}")#text(" is, and thus by ")#link(<tao-aee610558292023758a4>)[#text("(1)")]#text(" they each have at most ")#tao-math("{\\left|F\\right| + O(\\left|F\\right|^{1/2})}", block: false)#text(" ")#mi("{F}")#text("-points; from subtracting all but one of the curves from ")#mi("{C_1 \\cup \\ldots C_d}")#text(" we then see that each of the ")#mi("{C_i}")#text(" has at least ")#tao-math("{\\left|F\\right| - O(\\left|F\\right|^{1/2})}", block: false)#text(" ")#mi("{F}")#text("-points also. As we can take one of the ")#mi("{g_i}")#text(" to be the identity, the claim ")#link(<tao-8c6fb1e9e37a1aea1d30>)[#text("(2)")]#text(" follows in this case. The general case follows in a similar fashion, using Galois theory to lifting a general curve ")#mi("{C}")#text(" to another curve ")#mi("{C^{\\prime}}")#text(" whose projection to some coordinate line ")#mi("{\\overline{F}}")#text(" has fixed multiplicity (basically by ensuring that the function field of the former is a Galois extension of the function field of the latter); see ")#link("http://www.ams.org/mathscinet-getitem?mr=429903")[#text("Bombieri’s paper")]#text(" for details.")

#heading(level: 1)[#strong[#text(" — 2. The proof of the Lang-Weil bound — ")]]

#text("Now we prove the Lang-Weil bound. We allow all implied constants to depend on the complexity bound ")#mi("{M}")#text(", and will ignore the issues of how to control the complexity of the various algebraic objects that arise in our analysis (as before, one can obtain such bounds more or less “for free” from an ultraproduct argument, if desired).")

#text("The proof proceeds by induction on the dimension ")#mi("{\\text{dim}(V)}")#text(" of the variety ")#mi("{V}")#text(". The first non-trivial case occurs at dimension one. If ")#mi("{V}")#text(" is a plane curve (so ")#mi("{\\text{dim}(V)=1}")#text(", and the ambient dimension is ")#mi("{2}")#text("), then the claim follows directly from the Hasse-Weil bound. If ")#mi("{V}")#text(" is a higher-dimensional curve, we can use ")#link("http://en.wikipedia.org/wiki/Resultant")[#text("resultants")]#text(" to eliminate all but two of the variables (or, alternatively, one can apply the ")#link("http://en.wikipedia.org/wiki/Primitive_element_theorem")[#text("primitive element theorem")]#text(" to the ")#link("http://en.wikipedia.org/wiki/Function_field_of_an_algebraic_variety")[#text("function field")]#text(" of the curve), and convert the curve to a ")#link("http://en.wikipedia.org/wiki/Birational_geometry")[#text("birationally equivalent")]#text(" (over ")#mi("{F}")#text(") plane curve, to reduce to the plane curve case (noting that the singular points of the birational transformation only influence the number of ")#mi("{F}")#text("-points by ")#mi("{O(1)}")#text(" at most).")

#text("Now suppose inductively that ")#mi("{\\text{dim}(V) \\geq 2}")#text(", and that the claim has already been proven for irreducible varieties of dimension ")#mi("{\\text{dim}(V)-1}")#text(". The induction step is then based on the following two parallel facts about hyperplane slicing, the first in the algebraic geometric category, and the second in the combinatorial category:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Bertini’s theorem)")]#text(" Let ")#mi("{V}")#text(" be an irreducible variety in ")#mi("{\\overline{F}^d}")#text(" of dimension at least two. Then, for a generic affine hyperplane ")#mi("{H}")#text(" (over ")#mi("{\\overline{F}}")#text("), the slice ")#mi("{V \\cap H}")#text(" is an irreducible variety of dimension ")#mi("{\\text{dim}(V)-1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7 (Random sampling)")]#text(" ")#metadata(none) <tao-044dcfaf9b32a30847a1>#text(" Let ")#mi("{E}")#text(" be a subset of ")#mi("{F^d}")#text(" for some ")#mi("{d=O(1)}")#text(". Then, for a affine hyperplane ")#mi("{H}")#text(" (defined over ")#mi("{F}")#text(") chosen uniformly at random, the random variable ")#tao-math("{\\left|E \\cap H\\right|}", block: false)#text(" has mean ")#tao-math("{\\left|E\\right|/\\left|F\\right|}", block: false)#text(" and variance ")#tao-math("{O(\\left|E\\right|/\\left|F\\right|)}", block: false)#text(". In particular, by Chebyshev’s inequality, the median value of ")#tao-math("{\\left|E \\cap H\\right|}", block: false)#text(" is ")#tao-math("{\\left|E\\right|/\\left|F\\right| + O( (\\left|E\\right|/\\left|F\\right|)^{1/2} )}", block: false)#text(".")
]

#text("Let us see how the two lemmas conclude the induction. There are ")#tao-math("{\\left|F\\right| \\frac{\\left|F\\right|^d-1}{\\left|F\\right|-1} = (1 + O(\\left|F\\right|^{-1})) \\left|F\\right|^d}", block: false)#text(" different affine hyperplanes ")#mi("{H}")#text(" over ")#mi("{F}")#text(". The set of hyperplanes ")#mi("{H}")#text(" over ")#mi("{\\overline{F}}")#text(" for which ")#mi("{V \\cap H}")#text(" fails to be an irreducible variety of dimension ")#mi("{\\text{dim}(V)}")#text(" is, by Bertini’s theorem, a proper algebraic variety in the Grassmannian space, which one can show to have bounded complexity; and so by Lemma ")#link(<tao-8651347d5d501956a468>)[#text("1")]#text(", only ")#tao-math("{O(1/\\left|F\\right|)}", block: false)#text(" of all such hyperplanes over ")#mi("{F}")#text(" fall into this variety. For the remaining ")#tao-math("{1-O(1/\\left|F\\right|)}", block: false)#text(" such hyperplanes, we may apply the induction hypothesis and conclude that ")#tao-math("{\\left|V(F) \\cap H\\right| = (1 + O(\\left|F\\right|^{-1/2})) \\left|F\\right|^{\\text{dim}(V)-1}}", block: false)#text(". In particular, if ")#mi("{H}")#text(" is an affine hyperplane chosen uniformly at random, then the median value of ")#tao-math("{\\left|V(F) \\cap H\\right|}", block: false)#text(" is ")#tao-math("{(1 + O(\\left|F\\right|^{-1/2})) \\left|F\\right|^{\\text{dim}(V)-1}}", block: false)#text(". But this is consistent with Lemma ")#link(<tao-044dcfaf9b32a30847a1>)[#text("7")]#text(" only when ")#tao-math("{\\left|V(F)\\right| = (1 + O(\\left|F\\right|^{-1/2})) \\left|F\\right|^{\\text{dim}(V)}}", block: false)#text(", closing the induction.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can also proceed without the variance bound in Lemma ")#link(<tao-044dcfaf9b32a30847a1>)[#text("7")]#text(" by using Lemma ")#link(<tao-8651347d5d501956a468>)[#text("1")]#text(" as a crude estimate for ")#tao-math("{\\left|V(F) \\cap H\\right|}", block: false)#text(" for the exceptional ")#mi("{H}")#text(", after first making an easy reduction to the case where ")#mi("{V(F)}")#text(" is not already contained inside a single hyperplane. However, I think the variance bound is illuminating, as it illustrates the concentration of measure that occurs when ")#tao-math("{\\left|E\\right|}", block: false)#text(" becomes much larger than ")#tao-math("{\\left|F\\right|}", block: false)#text(", which only occurs in dimensions two and higher. In contrast, if one attempts to slice a curve by a hyperplane, one typically gets zero or multiple points, so there is no concentration of measure and irreducibility usually fails. So the slicing method can reduce the dimension of ")#mi("{V}")#text(" down to one, but not to zero, so the need to invoke Hasse-Weil cannot be avoided by this method.")
]

#text("We first show Lemma ")#link(<tao-044dcfaf9b32a30847a1>)[#text("7")]#text(", which is a routine first and second moment calculation. Any given point ")#mi("{x}")#text(" in ")#mi("{F^n}")#text(" lies in precisely ")#tao-math("{1/\\left|F\\right|}", block: false)#text(" of the hyperplanes ")#mi("{H}")#text(", so summing in ")#mi("{x}")#text(" we obtain ")#tao-math("{\\mathop{\\bf E} \\left|E \\cap H\\right| = \\left|E\\right|/\\left|F\\right|}", block: false)#text(". Next, any two distinct points ")#mi("{x,y}")#text(" in ")#mi("{F^n}")#text(" lie in ")#tao-math("{\\frac{1}{\\left|F\\right|} \\frac{\\left|F\\right|^{d-1}-1}{\\left|F\\right|^d-1} = \\frac{1}{\\left|F\\right|^2} + O( \\left|F\\right|^{-d-1} )}", block: false)#text(" of the hyperplanes ")#mi("{H}")#text(", and so")

#tao-aligned(keep: true)[


#tao-math("\\mathop{\\bf E} \\left|E \\cap H\\right|^2  & = \\left|E\\right|/\\left|F\\right| + \\left|E\\right| (\\left|E\\right|-1) (\\frac{1}{\\left|F\\right|^2} + O( \\left|F\\right|^{-d-1} ))", block: true)



#tao-math(" & = (\\mathop{\\bf E} \\left|E \\cap H\\right|)^2 + O( \\left|E\\right|/\\left|F\\right| )", block: true)
]

#text("giving the variance bound.")

#text("Now we show ")#link("http://en.wikipedia.org/wiki/Theorem_of_Bertini")[#text("Bertini’s theorem")]#text(". A dimension count shows that the space of pairs ")#mi("{(p,H)}")#text(" where ")#mi("{H}")#text(" is a hyperplane and ")#mi("{p}")#text(" is a singular point of ")#mi("{V}")#text(" in ")#mi("{H}")#text(" has dimension at most ")#mi("{\\text{dim}(V)-1+d-1}")#text(", and so for a generic hyperplane, the space of singular points of ")#mi("{V}")#text(" in ")#mi("{H}")#text(" is contained in a variety of dimension at most ")#mi("{\\text{dim}(V)-2}")#text(". Similarly, the space of pairs ")#mi("{(p,H)}")#text(" where ")#mi("{p}")#text(" is a smooth point of ")#mi("{V}")#text(" and ")#mi("{H}")#text(" is a hyperplane containing the tangent space to ")#mi("{V}")#text(" at ")#mi("{p}")#text(" is at most ")#mi("{\\text{dim}(V)+d-\\text{dim}(V)-1}")#text(", and so the space of smooth points of ")#mi("{V}")#text(" in ")#mi("{H}")#text(" whose tangent space is not transverse to a generic ")#mi("{H}")#text(" also has dimension at most ")#mi("{\\text{dim}(V)-2}")#text(". Thus, for generic ")#mi("{H}")#text(", the slice ")#mi("{V \\cap H}")#text(" is a ")#mi("{\\text{dim}(V)-1}")#text("-dimensional variety, which is generically comes from smooth points of ")#mi("{V}")#text(" whose tangent space is transverse to ")#mi("{H}")#text(". The remaining task is to establish irreducibility for generic ")#mi("{H}")#text(". As irreducibility is an algebraic condition, ")#mi("{V \\cap H}")#text(" is either generically irreducible or generically reducible. Suppose for contradiction that ")#mi("{V \\cap H}")#text(" is generically reducible. Consider the set ")#mi("{S}")#text(" of triples ")#mi("{(p,q,H)}")#text(" where ")#mi("{p,q}")#text(" are distinct smooth points of ")#mi("{V}")#text(", and ")#mi("{H}")#text(" is a hyperplane through ")#mi("{p,q}")#text(" that is transverse to the tangent spaces of both ")#mi("{p}")#text(" and ")#mi("{q}")#text(", with ")#mi("{H \\cap V}")#text(" reducible. This is a quasiprojective variety of dimension ")#mi("{d + (\\text{dim}(V)-1) + (\\text{dim}(V)-1)}")#text(". It can be decomposed into two top-dimensional components: one where ")#mi("{p,q}")#text(" lie in the same component of ")#mi("{V \\cap H}")#text(", and one where they lie in distinct components. (The hypothesis ")#mi("{\\text{dim}(V) \\geq 2}")#text(" is crucial to ensure that the first component is non-empty.) As such, ")#mi("{S}")#text(" is disconnected in the Zariski topology. On the other hand, for fixed ")#mi("{p,q}")#text(", the set of all ")#mi("{H}")#text(" contributing to ")#mi("{S}")#text(" is connected, while the set of all distinct smooth pairs ")#mi("{p,q}")#text(" is also connected, and so ")#mi("{S}")#text(" (and hence is closure) is also connected, a contradiction.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" See also page 174 of ")#link("http://www.ams.org/mathscinet-getitem?mr=1288523")[#text("Griffiths-Harris")]#text(" for a slight variant of this argument (thanks to Jordan Ellenberg for pointing this out). In that reference, it is also noted that the claim can also be derived from the ")#link("http://en.wikipedia.org/wiki/Lefschetz_hyperplane_theorem")[#text("Lefschetz hyperplane theorem")]#text(" in the case that ")#mi("{V}")#text(" is smooth.")
]

#heading(level: 1)[#strong[#text(" — 3. Lang-Weil with parameters — ")]]

#text("Now we prove Theorem ")#link(<tao-5951157b65b0df935bcc>)[#text("5")]#text(". Again we allow all implied constants to depend on the complexity parameter ")#mi("{M}")#text(", and gloss over the task of making sure that all algebraic objects have complexity ")#mi("{O_M(1)}")#text(".")

#text("We will proceed by the moment method. Observe that ")#mi("{c(w)}")#text(" is a bounded natural number random variable, so to show that ")#mi("{c(w)}")#text(" has the asymptotic distribution of ")#mi("{X}")#text(" up to errors of ")#tao-math("{1+O(\\left|F\\right|^{-1/2})}", block: false)#text(", it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{w \\in W(F) \\backslash W^{\\prime}(F)} c(w)^k = \\mathop{\\bf E} X^k + O(\\left|F\\right|^{-1/2})", block: true)]]

#text("for any fixed natural number ")#mi("{k=O(1)}")#text(", or equivalently (by the Lang-Weil bound for ")#mi("{W(F)}")#text(" and for the fibres ")#mi("{\\phi^{-1}(\\{w\\})}")#text(") ")#metadata(none) <tao-7887a64fa3becc911350>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\sum_{w \\in W(F) \\backslash W^{\\prime}(F)} \\left|\\phi^{-1}(\\{w\\})(F)\\right|^k = (\\mathop{\\bf E} X^k + O(\\left|F\\right|^{-1/2}))", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\times \\left|F\\right|^{\\text{dim}(W) + k (\\text{dim}(V)-\\text{dim}(W))}.", block: true)]]

#text("Fix ")#mi("{k}")#text(". We form the ")#mi("{k}")#text("-fold fibre product ")#mi("{V_k}")#text(" of ")#mi("{V}")#text(" over ")#mi("{W \\backslash W^{\\prime}}")#text(", consisting of all ")#mi("{k}")#text("-tuples ")#mi("{(v_1,\\ldots,v_k) \\in V^k}")#text(" such that ")#mi("{\\phi(v_1)=\\ldots=\\phi(v_k)}")#text(" lies in ")#mi("{W \\backslash W^{\\prime}}")#text(". This fibre product is a quasiprojective variety of dimension ")#mi("{\\text{dim}(W) + k (\\text{dim}(V)-\\text{dim}(W))}")#text(", is defined over ")#mi("{F}")#text(", and the left-hand side of ")#link(<tao-7887a64fa3becc911350>)[#text("(7)")]#text(" is precisely equal to the number of ")#mi("{F}")#text("-points of ")#mi("{V_k}")#text(". Thus, by the Lang-Weil bound for ")#mi("{V_k}")#text(", it suffices to show that")

#align(center)[#tao-fit-display[#mitex("c( V_k ) = \\mathop{\\bf E} X^k,")]]

#text("i.e. that ")#mi("{V_k}")#text(" has precisely ")#mi("{\\mathop{\\bf E} X^k}")#text(" top-dimensional components which are Frobenius-invariant.")

#text("We will in fact prove a more general statement: if ")#mi("{\\phi: U \\rightarrow W}")#text(" is any dominant map which has smooth unramified fibres on ")#mi("{W \\backslash W^{\\prime}}")#text(", then the number ")#mi("{c(U)}")#text(" of top-dimensional components of ")#mi("{U}")#text(" that are Frobenius-invariant is equal to the expected number of top-dimensional components of ")#mi("{g \\circ Frob}")#text(" on a generic fibre ")#mi("{\\phi^{-1}(\\{w_0\\})}")#text(", where ")#mi("{g}")#text(" is selected uniformly at random from ")#mi("{\\pi_1(W \\backslash W^{\\prime})}")#text(". Specialising this to the fibre product ")#mi("{V_k}")#text(" (noting that the generic fibre of ")#mi("{V_k}")#text(" is just the ")#mi("{k}")#text("-fold Cartesian power of the generic fibre of ")#mi("{k}")#text(", and similarly for the action of Frobenius and the fundamental group), we obtain the claim.")

#text("Now we prove this more general statement. By decomposing into irreducible components, we may certainly assume that ")#mi("{U}")#text(" is irreducible. If ")#mi("{U}")#text(" is not Frobenius-invariant, then ")#mi("{Frob(U)}")#text(" is generically disjoint from ")#mi("{U}")#text(" and so there certainly can be no components of ")#mi("{\\phi^{-1}(\\{w_0\\})}")#text(" that are fixed by ")#mi("{g \\circ Frob}")#text(". Thus we may assume that ")#mi("{U}")#text(" is Frobenius-invariant (i.e. defined over ")#mi("{F}")#text("). Then the situation becomes very close to that of ")#link("http://en.wikipedia.org/wiki/Burnside%27s_lemma")[#text("Burnside’s lemma")]#text(". If there are ")#mi("{K}")#text(" components ")#mi("{S_1,\\ldots,S_K}")#text(" of ")#mi("{\\phi^{-1}(\\{w_0\\})}")#text(", the connectedness of ")#mi("{U}")#text(" implies that the fundamental group ")#mi("{\\pi_1(W \\backslash W^{\\prime})}")#text(" acts transitively on these components, and so for any single component ")#mi("{S_i}")#text(" and uniformly chosen ")#mi("{g \\in \\pi_1(W \\backslash W^{\\prime})}")#text(", ")#mi("{g S_i}")#text(" will be uniformly distributed amongst the ")#mi("{S_1,\\ldots,S_K}")#text(", as will ")#mi("{g(Frob(S_i))}")#text(". In particular, each ")#mi("{S_i}")#text(" has a ")#mi("{1/K}")#text(" chance of being a fixed point of ")#mi("{g \\circ Frob}")#text(", so the expected number of fixed points of ")#mi("{g \\circ Frob}")#text(" is ")#mi("{1}")#text(" as requred.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" ")#metadata(none) <tao-077b497938bd917c824f>#text(" Obtain the following extension of Corollary ")#link(<tao-5951157b65b0df935bcc>)[#text("5")]#text(": if one has ")#mi("{k = O(1)}")#text(" different dominant maps ")#mi("{\\phi_i: V_i \\rightarrow W}")#text(" of varieties ")#mi("{V_i,W}")#text(" of complexity ")#mi("{O(1)}")#text(", with unramified, non-singular fibres on ")#mi("{W \\backslash W^{\\prime}}")#text(", then the joint distribution of ")#mi("{c(\\phi_1^{-1}(\\{w\\})), \\ldots, c(\\phi_k^{-1}(\\{w\\}))}")#text(" converges in distribution to the joint distribution of ")#mi("{X_1,\\ldots,X_k}")#text(", where each ")#mi("{X_i}")#text(" is the number of fixed points of ")#mi("{g \\circ Frob}")#text(" on the components of a generic fibre, where ")#mi("{g}")#text(" is independent of ")#mi("{i}")#text(" and drawn uniformly from ")#mi("{\\pi_1(W \\backslash W^{\\prime})}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" While the moment computation is simple and cute, I would be interested in seeing either a heuristic or rigorous explanation of Theorem ")#link(<tao-5951157b65b0df935bcc>)[#text("5")]#text(" (or Exercise ")#link(<tao-077b497938bd917c824f>)[#text("1")]#text(") that did not proceed through moments. The theorem seems to be asserting a statement roughly of the following form (ignoring for now the fact that paths do not actually make much sense in positive characteristic): if one takes a random path ")#mi("{\\gamma}")#text(" in ")#mi("{W}")#text(" connecting two random ")#mi("{F}")#text("-points, then the loop ")#mi("{Frob(\\gamma) - \\gamma}")#text(" behaves as if it is distributed uniformly in the fundamental group of ")#mi("{\\pi_1(W)}")#text(" (or ")#mi("{\\pi_1(W \\backslash W^{\\prime})}")#text(", for any lower-dimensional set ")#mi("{W^{\\prime}}")#text("). But I do not know how to make this heuristic precise.")
]

#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Definable subsets over (nonstandard) finite fields, and almost quantifier elimination « What’s new")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-169852")[#strong[#text("Definable subsets over (nonstandard) finite fields, and almost quantifier elimination « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2012")])]

#text("[…] the small characteristic case); for instance, in conjunction with the Lang-Weil bound discussed in this recent blog post, it shows that any non-empty definable subset of a nonstandard finite field has a nonstandard […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Expanding polynomials over finite fields of large characteristic, and a regularity lemma for definable sets « What’s new")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-192673")[#strong[#text("Expanding polynomials over finite fields of large characteristic, and a regularity lemma for definable sets « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2012")])]

#text("[…] in particular the Lang-Weil bound on counting points in varieties over a finite field (discussed in this previous blog post), and also the theory of the etale fundamental group. Let me try to briefly explain why this is the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Estimation of the Type I and Type II sums | What's new")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-234232")[#strong[#text("Estimation of the Type I and Type II sums | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("[…] can show (e.g. using Stepanov’s method, cf. this previous post) that the number of this points on this curve is equal to , leading to the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Algebraic combinatorial geometry: the polynomial method in arithmetic combinatorics, incidence combinatorics, and number theory | What's new")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-249018")[#strong[#text("Algebraic combinatorial geometry: the polynomial method in arithmetic combinatorics, incidence combinatorics, and number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2013")])]

#text("[…] for instance, it plays a key role in the proof of Baker’s theorem in transcendence theory, or Stepanov’s method in giving an elementary proof of the Riemann hypothesis for finite fields ov…; in combinatorics, the nullstellenatz of Alon is also another relatively early use of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A spectral theory proof of the algebraic regularity lemma | What's new")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-249424")[#strong[#text("A spectral theory proof of the algebraic regularity lemma | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2013")])]

#text("[…] using the Lang-Weil bound and some facts about the étale fundamental group. It was the reliance on the latter which […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cab1fda2c6f9e25076d65616e1c2c31b3d89d9ce77d455d9fa45522a9995caf4-6dd8b0a5fae487c3cc184abc1bdd715d360c5653ce7c29c65e45fa9c0861f00c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mrinmoy Datta")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-269245")[#strong[#text("Mrinmoy Datta")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("I would like to ask you if the Lang Weil, or Hasse Weil bounds are attained by some variety.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-269286")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("The Hasse-Weil bound can come arbitrarily close to being sharp, thanks to the ")#link("http://en.wikipedia.org/wiki/Sato%E2%80%93Tate_conjecture")[#text("Sato-Tate conjecture")]#text(", which has now been verified for large families of elliptic curves. The situation with Lang-Weil in higher dimensions is more delicate: in principle, the theorems of Deligne give much more precise error terms (full square root cancellation), but this requires some algebraic geometry vanishing conditions (certain cohomology groups have to vanish) which I don’t understand very well.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Bombieri-Stepanov proof of the Hasse-Weil bound | What's new")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-321491")[#strong[#text("The Bombieri-Stepanov proof of the Hasse-Weil bound | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2014")])]

#text("[…] discussed Bombieri’s proof of Theorem 2 in this previous post (in the special case of hyperelliptic curves), but now wish to present the full proof, with some […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-452267")[#strong[#text("First Bourbaki seminar of 2015 (I): Harari’s talk | Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2015")]

#text("[…] bad fibers. The reason for this fact is that if is split, then one can show (with the aid of the Lang-Weil estimate and Hensel’s lemma) that for almost all places […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/559864c71ba4fac628dc978012c5a50310ba03dc96ca0bffe02e42d46ba210fc-4af8d30013a39ffcdcbcf90277d6ce06e4be4885b84ff04d0d087f6f4207282e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gilleslachaud")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-455469")[#strong[#text("gilleslachaud")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2015")])]

#text("It may be worthwhile to specify that there are precise values (for affine or projective algebraic sets) of the implied constants in Lemma 1, see")#linebreak()#text(" arXiv:1405.3027v2 and the references therein.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75a7f7ea5e8c1e2ae94d73c80133f113244da3402d20374ab42e89f28a0007d8-69af76fda1ecb5b019dd09a9852822ac1e6a80afba05383fdf5c4bae2a5ddce5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nonononoas")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-469766")[#strong[#text("nonononoas")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2016")])]

#text("Dear Terry, I was wondering if you have any idea on how the function ")#mi("C_p(V)")#text(" distributes as ")#mi("p")#text(" ranges over all large primes. For example, if ")#mi("V:F=0")#text(" is an affine hypersurface, with ")#mi("F \\in x_0,\\ldots,x_n")#text(" irreducible over ")#mi("\\mathbb{C}")#text(", then does the limit ")#mi("\\frac{1}{\\log \\log x}\\sum_{p \\leq x}\\frac{\\#V(\\mathbb{F}_p)}{p^{n+1}}")#text(" exist ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-469787")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2016")])]

#text("In the one-dimensional case at least I believe the Chebotarev density theorem is supposed to answer these questions, though I am not an expert on this topic. The higher dimensional case might also be treatable by this theorem or a variant thereof. The general heuristic here is that the action of the Frobenius map should be as “equidistributed” as possible subject to whatever algebraic constraints that map has to obey.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75a7f7ea5e8c1e2ae94d73c80133f113244da3402d20374ab42e89f28a0007d8-69af76fda1ecb5b019dd09a9852822ac1e6a80afba05383fdf5c4bae2a5ddce5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nonononoas")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-469788")[#strong[#text("nonononoas")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2016")])]

#text("Thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ff32e3d9aef31d79b5d656aa9bbf90e3d4d6574dd1287d9f18d4dac92fc86749-912e62269460ddf18037e735cd690b2b81161f8fdf3b24c122209a02373c1f51.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-527735")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2019")])]

#text("Dear Terry,")

#text("I have a question about one application of the above bounds. (e.g. Lang Weil)")

#text("Suppose you want to count the number of integer solutions of a polynomial equation e.g. f(x,y) = 0, where |x|< H, |y|<H. Then, one attempt is to first consider mod p to first count the number of solutions in F_p by using the bounds in your post, and then apply large Sieve.")

#text("However, the upper bound you can get in this way may not be good. One issue is that in Lang Weil bound, the degree of the polynomial f(x,y) is not important, it goes to the 'complexity'. However, the degree might be important when you are counting over integers.")

#text("Do you know any tools, in general, to deal with this issue?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-528569")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2019")])]

#text("Well, counting integer points to polynomial equations is a hugely difficult problem in general, thanks to Matiyasevich’s theorem. While sieving can give some bounds, other methods such as the ")#link("https://en.wikipedia.org/wiki/Determinant_method")[#text("determinant method")]#text(" are often more effective in practice. If the equations have additive structure then the circle method and its variants can give good bounds; there are many further techniques in arithmetic geometry and Diophantine geometry that can also be useful here, though I am not an expert on these matters.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0544d0b67bc459608ec80e0f7de411281ed22919577c1cf61d514ccefaebf566-3898535e314160f234e4390c5db3211fda25b22d9a068183663aaa31d47ac7d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-542320")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2020")])]

#text("About the Lang-Weil estimate, I would like to know how the Lang-Weil constant depends on the degree of varieties. More precisely, I proposed such a question: ")#link("https://mathoverflow.net/questions/352053/density-of-rational-points-over-finite-fields-an-estimate-of-lang-weil-constant")[#text("https://mathoverflow.net/questions/352053/density-of-rational-points-over-finite-fields-an-estimate-of-lang-weil-constant")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a25812a3bcd4243d416e55aab07a49f6c1e60a8fc75f44765bc418c722a8405-26e889967f78eb4b92a0f018a5176da8b8352f9daa4c3a59d1b90a77f8a3d8c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Love")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-639907")[#strong[#text("Jonathan Love")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2022")])]

#text("Thank you for this very interesting and helpful write-up! I have a question about one of the steps:")

#text("“The set of hyperplanes {H} over {\\overline{F}} for which {V \\cap H} fails to be an irreducible variety of dimension {\\hbox{dim}(V)} is, by Bertini’s theorem, a proper algebraic variety in the Grassmannian space, which one can show to have bounded complexity”")

#text("How can one show that this variety has bounded complexity? I’ve seen some very tight bounds on the dimension (for instance Poonen and Slavov’s 2020 paper using the statistical methods described in this post) but I don’t see a natural way to bound, for example, the degree. Even just a rough sketch or pointer would be very helpful.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-639947")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2022")])]

#text("As the degree of ")#mi("V \\cap H")#text(" is bounded, there are only a bounded number of ways in which ")#mi("V \\cap H")#text(" can be reducible (e.g., it could split into the union of a degree five and a degree seven subvariety), and each of these can be described via a bounded complexity system of equations. Alternatively, one can get an ineffective bound using ultraproducts, as in ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a25812a3bcd4243d416e55aab07a49f6c1e60a8fc75f44765bc418c722a8405-26e889967f78eb4b92a0f018a5176da8b8352f9daa4c3a59d1b90a77f8a3d8c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Love")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-639953")[#strong[#text("Jonathan Love")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2022")])]

#text("Ah that makes sense, thank you!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of New Nikodym set constructions over finite fields | What's new")]], [#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/#comment-689057")[#strong[#text("New Nikodym set constructions over finite fields | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2025")])]

#text("[…] through , at least one will avoid the removed surfaces, thus giving (most of) a Nikodym set. The Lang-Weil estimate predicts that each surface has cardinality about , so this should give a Nikodym set of size about […]")
]
