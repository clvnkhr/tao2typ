// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/03/05/furstenberg-limits-of-the-liouville-function/
// Converted to Typst by tao2typ: "2026-10-14T16:38:06.570895+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Furstenberg limits of the Liouville function", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Furstenberg limits of the Liouville function")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 March 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/03/05/furstenberg-limits-of-the-liouville-function/")[#text("https://terrytao.wordpress.com/2017/03/05/furstenberg-limits-of-the-liouville-function/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Given a function ")#mi("{f: {\\bf N} \\rightarrow \\{-1,+1\\}}")#text(" on the natural numbers taking values in ")#mi("{+1, -1}")#text(", one can invoke the ")#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/")[#text("Furstenberg correspondence principle")]#text(" to locate a measure preserving system ")#mi("{T \\circlearrowright (X, \\mu)}")#text(" – a probability space ")#mi("{(X,\\mu)}")#text(" together with a measure-preserving shift ")#mi("{T: X \\rightarrow X}")#text(" (or equivalently, a measure-preserving ")#mi("{{\\bf Z}}")#text("-action on ")#mi("{(X,\\mu)}")#text(") – together with a measurable function (or “observable”) ")#mi("{F: X \\rightarrow \\{-1,+1\\}}")#text(" that has essentially the same statistics as ")#mi("{f}")#text(" in the sense that")

#align(center)[#tao-fit-display[#mitex("\\lim \\inf_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N f(n+h_1) \\dots f(n+h_k)")]]

#tao-aligned(keep: true)[


#tao-math(" & \\leq \\int_X F(T^{h_1} x) \\dots F(T^{h_k} x)\\ d\\mu(x)", block: true)



#tao-math(" & \\leq \\lim \\sup_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N f(n+h_1) \\dots f(n+h_k)", block: true)
]

#text("for any integers ")#mi("{h_1,\\dots,h_k}")#text(". In particular, one has ")#metadata(none) <tao-eceba22a3c154598ba86>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\int_X F(T^{h_1} x) \\dots F(T^{h_k} x)\\ d\\mu(x) = \\lim_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N f(n+h_1) \\dots f(n+h_k)")]]



#text(" whenever the limit on the right-hand side exists. We will refer to the system ")#mi("{T \\circlearrowright (X,\\mu)}")#text(" together with the designated function ")#mi("{F}")#text(" as a ")#emph[#text("Furstenberg limit")]#text(" ot the sequence ")#mi("{f}")#text(". These Furstenberg limits capture some, but not all, of the asymptotic behaviour of ")#mi("{f}")#text("; roughly speaking, they control the typical “local” behaviour of ")#mi("{f}")#text(", involving correlations such as ")#mi("{\\frac{1}{N} \\sum_{n=1}^N f(n+h_1) \\dots f(n+h_k)}")#text(" in the regime where ")#mi("{h_1,\\dots,h_k}")#text(" are much smaller than ")#mi("{N}")#text(". However, the control on error terms here is usually only qualitative at best, and one usually does not obtain non-trivial control on correlations in which the ")#mi("{h_1,\\dots,h_k}")#text(" are allowed to grow at some significant rate with ")#mi("{N}")#text(" (e.g. like some power ")#mi("{N^\\theta}")#text(" of ")#mi("{N}")#text(").")

#text("The correspondence principle is discussed in ")#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/")[#text("these")]#text(" ")#link("https://terrytao.wordpress.com/2013/03/27/an-informal-version-of-the-furstenberg-correspondence-principle/")[#text("previous")]#text(" ")#link("https://terrytao.wordpress.com/2009/05/08/szemeredis-regularity-lemma-via-the-correspondence-principle/")[#text("blog")]#text(" ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("posts")]#text(". One way to establish the principle is by introducing a ")#link("https://en.wikipedia.org/wiki/Banach_limit")[#text("Banach limit")]#text(" ")#mi("{p\\!-\\!\\lim: \\ell^\\infty({\\bf N}) \\rightarrow {\\bf R}}")#text(" that extends the usual limit functional on the subspace of ")#mi("{\\ell^\\infty({\\bf N})}")#text(" consisting of convergent sequences while still having operator norm one. Such functionals cannot be constructed explicitly, but can be proven to exist (non-constructively and non-uniquely) using the ")#link("https://en.wikipedia.org/wiki/Hahn%E2%80%93Banach_theorem")[#text("Hahn-Banach theorem")]#text("; one can also use a non-principal ")#link("https://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilter")]#text(" here if desired. One can then seek to construct a system ")#mi("{T \\circlearrowright (X,\\mu)}")#text(" and a measurable function ")#mi("{F: X \\rightarrow \\{-1,+1\\}}")#text(" for which one has the statistics ")#metadata(none) <tao-9cd17481eb5958f7133e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\int_X F(T^{h_1} x) \\dots F(T^{h_k} x)\\ d\\mu(x) = p\\!-\\!\\lim_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N f(n+h_1) \\dots f(n+h_k)")]]



#text(" for all ")#mi("{h_1,\\dots,h_k}")#text(". One can explicitly construct such a system as follows. One can take ")#mi("{X}")#text(" to be the ")#link("https://en.wikipedia.org/wiki/Cantor_space")[#text("Cantor space")]#text(" ")#mi("{\\{-1,+1\\}^{\\bf Z}}")#text(" with the product ")#mi("{\\sigma}")#text("-algebra and the shift")

#align(center)[#tao-fit-display[#mitex("T ( (x_n)_{n \\in {\\bf Z}} ) := (x_{n+1})_{n \\in {\\bf Z}}")]]

#text("with the function ")#mi("{F: X \\rightarrow \\{-1,+1\\}}")#text(" being the coordinate function at zero:")

#align(center)[#tao-fit-display[#mitex("F( (x_n)_{n \\in {\\bf Z}} ) := x_0")]]

#text("(so in particular ")#mi("{F( T^h (x_n)_{n \\in {\\bf Z}} ) = x_h}")#text(" for any ")#mi("{h \\in {\\bf Z}}")#text("). The only thing remaining is to construct the invariant measure ")#mi("{\\mu}")#text(". In order to be consistent with ")#link(<tao-9cd17481eb5958f7133e>)[#text("(2)")]#text(", one must have")

#align(center)[#tao-fit-display[#mitex("\\mu( \\{ (x_n)_{n \\in {\\bf Z}}: x_{h_j} = \\epsilon_j \\forall 1 \\leq j \\leq k \\} )")]]

#align(center)[#tao-fit-display[#mitex("= p\\!-\\!\\lim_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N 1_{f(n+h_1)=\\epsilon_1} \\dots 1_{f(n+h_k)=\\epsilon_k}")]]

#text("for any distinct integers ")#mi("{h_1,\\dots,h_k}")#text(" and signs ")#mi("{\\epsilon_1,\\dots,\\epsilon_k}")#text(". One can check that this defines a ")#link("https://en.wikipedia.org/wiki/Pre-measure")[#text("premeasure")]#text(" on the Boolean algebra of ")#mi("{\\{-1,+1\\}^{\\bf Z}}")#text(" defined by ")#link("https://en.wikipedia.org/wiki/Cylinder_set")[#text("cylinder sets")]#text(", and the existence of ")#mi("{\\mu}")#text(" then follows from the ")#link("https://en.wikipedia.org/wiki/Hahn%E2%80%93Kolmogorov_theorem")[#text("Hahn-Kolmogorov extension theorem")]#text(" (or the closely related ")#link("https://en.wikipedia.org/wiki/Kolmogorov_extension_theorem")[#text("Kolmogorov extension theorem")]#text("). One can then check that the correspondence ")#link(<tao-9cd17481eb5958f7133e>)[#text("(2)")]#text(" holds, and that ")#mi("{\\mu}")#text(" is translation-invariant; the latter comes from the translation invariance of the (Banach-)")#link("https://en.wikipedia.org/wiki/Ces%C3%A0ro_mean")[#text("Césaro averaging operation")]#text(" ")#mi("{f \\mapsto p\\!-\\!\\lim_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N f(n)}")#text(". A variant of this construction shows that the Furstenberg limit is unique up to equivalence if and only if all the limits appearing in ")#link(<tao-eceba22a3c154598ba86>)[#text("(1)")]#text(" actually exist.")

#text("One can obtain a slightly tighter correspondence by using a smoother average than the Césaro average. For instance, one can use the logarithmic Césaro averages ")#mi("{\\lim_{N \\rightarrow \\infty} \\frac{1}{\\log N}\\sum_{n=1}^N \\frac{f(n)}{n}}")#text(" in place of the Césaro average ")#mi("{\\sum_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N f(n)}")#text(", thus one replaces ")#link(<tao-9cd17481eb5958f7133e>)[#text("(2)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\int_X F(T^{h_1} x) \\dots F(T^{h_k} x)\\ d\\mu(x)")]]

#align(center)[#tao-fit-display[#mitex("= p\\!-\\!\\lim_{N \\rightarrow \\infty} \\frac{1}{\\log N} \\sum_{n=1}^N \\frac{f(n+h_1) \\dots f(n+h_k)}{n}.")]]

#text("Whenever the Césaro average of a bounded sequence ")#mi("{f: {\\bf N} \\rightarrow {\\bf R}}")#text(" exists, then the logarithmic Césaro average exists and is equal to the Césaro average. Thus, a Furstenberg limit constructed using logarithmic Banach-Césaro averaging still obeys ")#link(<tao-eceba22a3c154598ba86>)[#text("(1)")]#text(" for all ")#mi("{h_1,\\dots,h_k}")#text(" when the right-hand side limit exists, but also obeys the more general assertion")

#align(center)[#tao-fit-display[#mitex("\\int_X F(T^{h_1} x) \\dots F(T^{h_k} x)\\ d\\mu(x)")]]

#align(center)[#tao-fit-display[#mitex("= \\lim_{N \\rightarrow \\infty} \\frac{1}{\\log N} \\sum_{n=1}^N \\frac{f(n+h_1) \\dots f(n+h_k)}{n}")]]

#text("whenever the limit of the right-hand side exists.")

#text("In a ")#link("https://arxiv.org/abs/1611.09338")[#text("recent paper of Frantizinakis")]#text(", the Furstenberg limits of the Liouville function ")#mi("{\\lambda}")#text(" (with logarithmic averaging) were studied. Some (but not all) of the known facts and conjectures about the Liouville function can be interpreted in the Furstenberg limit. For instance, in a ")#link("http://www.ams.org/mathscinet-getitem?mr=3488742")[#text("recent breakthrough result of Matomaki and Radziwill")]#text(" (discussed previously ")#link("https://terrytao.wordpress.com/2015/02/24/254a-supplement-6-a-cheap-version-of-the-theorems-of-halasz-and-matomaki-radziwill/")[#text("here")]#text("), it was shown that the Liouville function exhibited cancellation on short intervals in the sense that")

#align(center)[#tao-fit-display[#mitex("\\lim_{H \\rightarrow \\infty} \\limsup_{X \\rightarrow \\infty} \\frac{1}{X} \\int_X^{2X} \\frac{1}{H} |\\sum_{x \\leq n \\leq x+H} \\lambda(n)|\\ dx = 0.")]]

#text("In terms of Furstenberg limits of the Liouville function, this assertion is equivalent to the assertion that")

#align(center)[#tao-fit-display[#mitex("\\lim_{H \\rightarrow \\infty} \\int_X |\\frac{1}{H} \\sum_{h=1}^H F(T^h x)|\\ d\\mu(x) = 0")]]

#text("for all Furstenberg limits ")#mi("{T \\circlearrowright (X,\\mu), F}")#text(" of Liouville (including those without logarithmic averaging). Invoking the mean ergodic theorem (discussed in ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("this previous post")]#text("), this assertion is in turn equivalent to the observable ")#mi("{F}")#text(" that corresponds to the Liouville function being orthogonal to the invariant factor ")#mi("{L^\\infty(X,\\mu)^{\\bf Z} = \\{ g \\in L^\\infty(X,\\mu): g \\circ T = g \\}}")#text(" of ")#mi("{X}")#text("; equivalently, the first Gowers-Host-Kra seminorm ")#tao-math("{\\left\\|F\\right\\|_{U^1(X)}}", block: false)#text(" of ")#mi("{F}")#text(" (as defined for instance in ")#link("https://terrytao.wordpress.com/2010/05/19/higher-order-hilbert-spaces/")[#text("this previous post")]#text(") vanishes. The ")#link("http://www.ams.org/mathscinet-getitem?mr=177943")[#text("Chowla conjecture")]#text(", which asserts that")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N \\lambda(n+h_1) \\dots \\lambda(n+h_k) = 0")]]

#text("for all distinct integers ")#mi("{h_1,\\dots,h_k}")#text(", is equivalent to the assertion that all the Furstenberg limits of Liouville are equivalent to the Bernoulli system (")#mi("{\\{-1,+1\\}^{\\bf Z}}")#text(" with the product measure arising from the uniform distribution on ")#mi("{\\{-1,+1\\}}")#text(", with the shift ")#mi("{T}")#text(" and observable ")#mi("{F}")#text(" as before). Similarly, the logarithmically averaged Chowla conjecture")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} \\frac{1}{\\log N} \\sum_{n=1}^N \\frac{\\lambda(n+h_1) \\dots \\lambda(n+h_k)}{n} = 0")]]

#text("is equivalent to the assertion that all the Furstenberg limits of Liouville with logarithmic averaging are equivalent to the Bernoulli system. Recently, I was ")#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/")[#text("able to prove")]#text(" the two-point version ")#metadata(none) <tao-1d22f9d56b97bde70e1b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\lim_{N \\rightarrow \\infty} \\frac{1}{\\log N} \\sum_{n=1}^N \\frac{\\lambda(n) \\lambda(n+h)}{n} = 0")]]



#text(" of the logarithmically averaged Chowla conjecture, for any non-zero integer ")#mi("{h}")#text("; this is equivalent to the perfect strong mixing property")

#align(center)[#tao-fit-display[#mitex("\\int_X F(x) F(T^h x)\\ d\\mu(x) = 0")]]

#text("for any Furstenberg limit of Liouville with logarithmic averaging, and any ")#mi("{h \\neq 0}")#text(".")

#text("The situation is more delicate with regards to the ")#link("https://publications.ias.edu/sites/default/files/Mahler%20Colloquium%20Lecture%204%20-Mobius%20randomness%20and%20dynamics.pdf")[#text("Sarnak conjecture")]#text(", which is equivalent to the assertion that")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N \\lambda(n) f(n) = 0")]]

#text("for any zero-entropy sequence ")#mi("{f: {\\bf N} \\rightarrow {\\bf R}}")#text(" (see this ")#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/")[#text("previous blog post")]#text(" for more discussion). Morally speaking, this conjecture should be equivalent to the assertion that any Furstenberg limit of Liouville is disjoint from any zero entropy system, but I was not able to formally establish an implication in either direction due to some technical issues regarding the fact that the Furstenberg limit does not directly control long-range correlations, only short-range ones. (There are however ergodic theoretic interpretations of the Sarnak conjecture that involve the notion of generic points; see ")#link("https://arxiv.org/abs/1410.1673")[#text("this paper of El Abdalaoui, Lemancyk, and de la Rue")]#text(".) But the situation is currently better with the logarithmically averaged Sarnak conjecture")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} \\frac{1}{\\log N} \\sum_{n=1}^N \\frac{\\lambda(n) f(n)}{n} = 0,")]]

#text("as ")#link("https://terrytao.wordpress.com/2016/05/16/equivalence-of-the-logarithmically-averaged-chowla-and-sarnak-conjectures/")[#text("I was able to show")]#text(" that this conjecture was equivalent to the logarithmically averaged Chowla conjecture, and hence to all Furstenberg limits of Liouville with logarithmic averaging being Bernoulli; I also showed the conjecture was equivalent to local Gowers uniformity of the Liouville function, which is in turn equivalent to the function ")#mi("{F}")#text(" having all Gowers-Host-Kra seminorms vanishing in every Furstenberg limit with logarithmic averaging. In ")#link("https://arxiv.org/abs/1611.09338")[#text("this recent paper of Frantzikinakis")]#text(", this analysis was taken further, showing that the logarithmically averaged Chowla and Sarnak conjectures were in fact equivalent to the much milder seeming assertion that all Furstenberg limits with logarithmic averaging were ergodic.")

#text("Actually, the logarithmically averaged Furstenberg limits have more structure than just a ")#mi("{{\\bf Z}}")#text("-action on a measure preserving system ")#mi("{(X,\\mu)}")#text(" with a single observable ")#mi("{F}")#text(". Let ")#mi("{Aff_+({\\bf Z})}")#text(" denote the semigroup of affine maps ")#mi("{n \\mapsto an+b}")#text(" on the integers with ")#mi("{a,b \\in {\\bf Z}}")#text(" and ")#mi("{a}")#text(" positive. Also, let ")#mi("{\\hat {\\bf Z}}")#text(" denote the ")#link("https://en.wikipedia.org/wiki/Profinite_integer")[#text("profinite integers")]#text(" (the inverse limit of the cyclic groups ")#mi("{{\\bf Z}/q{\\bf Z}}")#text("). Observe that ")#mi("{Aff_+({\\bf Z})}")#text(" acts on ")#mi("{\\hat {\\bf Z}}")#text(" by taking the inverse limit of the obvious actions of ")#mi("{Aff_+({\\bf Z})}")#text(" on ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Enriched logarithmically averaged Furstenberg limit of Liouville)")]#text(" ")#metadata(none) <tao-2cd6f936b05db9d3e874>#text(" Let ")#mi("{p\\!-\\!\\lim}")#text(" be a Banach limit. Then there exists a probability space ")#mi("{(X,\\mu)}")#text(" with an action ")#mi("{\\phi \\mapsto T^\\phi}")#text(" of the affine semigroup ")#mi("{Aff_+({\\bf Z})}")#text(", as well as measurable functions ")#mi("{F: X \\rightarrow \\{-1,+1\\}}")#text(" and ")#mi("{M: X \\rightarrow \\hat {\\bf Z}}")#text(", with the following properties:")

#list(
[#text("(i) (Affine Furstenberg limit) For any ")#mi("{\\phi_1,\\dots,\\phi_k \\in Aff_+({\\bf Z})}")#text(", and any congruence class ")#mi("{a\\ (q)}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("p\\!-\\!\\lim_{N \\rightarrow \\infty} \\frac{1}{\\log N} \\sum_{n=1}^N \\frac{\\lambda(\\phi_1(n)) \\dots \\lambda(\\phi_k(n)) 1_{n = a\\ (q)}}{n}")]]

#align(center)[#tao-fit-display[#mitex("= \\int_X F( T^{\\phi_1}(x) ) \\dots F( T^{\\phi_k}(x) ) 1_{M(x) = a\\ (q)}\\ d\\mu(x).")]]],
[#text("(ii) (Equivariance of ")#mi("{M}")#text(") For any ")#mi("{\\phi \\in Aff_+({\\bf Z})}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("M( T^\\phi(x) ) = \\phi( M(x) )")]]

#text("for ")#mi("{\\mu}")#text("-almost every ")#mi("{x \\in X}")#text(".")],
[#text("(iii) (Multiplicativity at fixed primes) For any prime ")#mi("{p}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("F( T^{p\\cdot} x ) = - F(x)")]]

#text("for ")#mi("{\\mu}")#text("-almost every ")#mi("{x \\in X}")#text(", where ")#mi("{p \\cdot \\in Aff_+({\\bf Z})}")#text(" is the dilation map ")#mi("{n \\mapsto pn}")#text(".")],
[#text("(iv) (Measure pushforward) If ")#mi("{\\phi \\in Aff_+({\\bf Z})}")#text(" is of the form ")#mi("{\\phi(n) = an+b}")#text(" and ")#mi("{S_\\phi \\subset X}")#text(" is the set ")#mi("{S_\\phi = \\{ x \\in X: M(x) \\in \\phi(\\hat {\\bf Z}) \\}}")#text(", then the pushforward ")#mi("{T^\\phi_* \\mu}")#text(" of ")#mi("{\\mu}")#text(" by ")#mi("{\\phi}")#text(" is equal to ")#mi("{a \\mu\\downharpoonright_{S_\\phi}}")#text(", that is to say one has")

#align(center)[#tao-fit-display[#mitex("\\mu( (T^\\phi)^{-1}(E) ) = a \\mu( E \\cap S_\\phi )")]]

#text("for every measurable ")#mi("{E \\subset X}")#text(".")]
)
]

#text("Note that ")#mi("{{\\bf Z}}")#text(" can be viewed as the subgroup of ")#mi("{Aff_+({\\bf Z})}")#text(" consisting of the translations ")#mi("{n \\mapsto n + b}")#text(". If one only keeps the ")#mi("{{\\bf Z}}")#text("-portion of the ")#mi("{Aff_+({\\bf Z})}")#text(" action and forgets the rest (as well as the function ")#mi("{M}")#text(") then the action becomes measure-preserving, and we recover an ordinary Furstenberg limit with logarithmic averaging. However, the additional structure here can be quite useful; for instance, one can transfer the proof of ")#link(<tao-1d22f9d56b97bde70e1b>)[#text("(3)")]#text(" to this setting, which we sketch below the fold, after proving the proposition.")

#text("The observable ")#mi("{M}")#text(", roughly speaking, means that points ")#mi("{x}")#text(" in the Furstenberg limit ")#mi("{X}")#text(" constructed by this proposition are still “virtual integers” in the sense that one can meaningfully compute the residue class of ")#mi("{x}")#text(" modulo any natural number modulus ")#mi("{q}")#text(", by first applying ")#mi("{M}")#text(" and then reducing mod ")#mi("{q}")#text(". The action of ")#mi("{Aff_+({\\bf Z})}")#text(" means that one can also meaningfully multiply ")#mi("{x}")#text(" by any natural number, and translate it by any integer. As with other applications of the correspondence principle, the main advantage of moving to this more “virtual” setting is that one now acquires a probability measure ")#mi("{\\mu}")#text(", so that the tools of ergodic theory can be readily applied.")

#metadata(none) <tao-d707d2a91d8c6d572032>

#heading(level: 1)[#strong[#text(" — 1. Proof of proposition — ")]]

#text("We adapt the previous construction of the Furstenberg limit. The space ")#mi("{X}")#text(" will no longer be the Cantor space ")#mi("{\\{-1,+1\\}^{\\bf Z}}")#text(", but will instead be taken to be the space")

#align(center)[#tao-fit-display[#mitex("X := \\{-1,+1\\}^{Aff_+({\\bf Z})} \\times \\hat {\\bf Z}.")]]

#text("The action of ")#mi("{Aff_+({\\bf Z})}")#text(" here is given by")

#align(center)[#tao-fit-display[#mitex("T^\\phi ( (x_\\psi)_{\\psi \\in Aff_+({\\bf Z})}, m ) := ( (x_{\\psi \\phi})_{\\psi \\in Aff_+({\\bf Z})}, \\phi(m) );")]]

#text("this can easily be seen to be a semigroup action. The observables ")#mi("{F: X \\rightarrow \\{-1,+1\\}}")#text(" and ")#mi("{M: X \\rightarrow \\hat {\\bf Z}}")#text(" are defined as")

#align(center)[#tao-fit-display[#mitex("F( (x_\\psi)_{\\psi \\in Aff_+({\\bf Z})}, m ) := x_{id}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("M( (x_\\psi)_{\\psi \\in Aff_+({\\bf Z})}, m ) := m")]]

#text("where ")#mi("{id}")#text(" is the identity element of ")#mi("{Aff_+({\\bf Z})}")#text(". Property (ii) is now clear. Now we have to construct the measure ")#mi("{\\mu}")#text(". In order to be consistent with property (i), the measure of the set ")#metadata(none) <tao-0b8b952db0b44a724321>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\{ ((x_\\phi)_{\\phi \\in Aff_+({\\bf Z})}, m): x_{\\phi_j} = \\epsilon_j \\forall 1 \\leq j \\leq k; m = a\\ (q) \\}")]]



#text(" for any distinct ")#mi("{\\phi_1,\\dots,\\phi_k \\in Aff_+({\\bf Z})}")#text(", signs ")#mi("{\\epsilon_1,\\dots,\\epsilon_k \\in \\{-1,+1\\}}")#text(", and congruence class ")#mi("{a\\ (q)}")#text(", must be equal to")

#align(center)[#tao-fit-display[#mitex("p\\!-\\!\\lim_{N \\rightarrow \\infty} \\frac{1}{\\log N} \\sum_{n=1}^N \\frac{1_{\\lambda(\\phi_j(n)) = \\epsilon_j \\forall 1 \\leq j \\leq k; m = a\\ (q)}}{n}.")]]

#text("One can check that this requirement uniquely defines a premeasure on the Boolean algebra on ")#mi("{X}")#text(" generated by the sets ")#link(<tao-0b8b952db0b44a724321>)[#text("(4)")]#text(", and ")#mi("{\\mu}")#text(" can then be constructed from the Hahn-Kolmogorov theorem as before. Property (i) follows from construction. Specialising to the case ")#mi("{\\phi_1(n) = n}")#text(", ")#mi("{\\phi_2(n) = pn}")#text(" for a prime ")#mi("{p}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("p\\!-\\!\\lim_{N \\rightarrow \\infty} \\frac{1}{\\log N} \\sum_{n=1}^N \\frac{\\lambda(n) \\lambda(pn)}{n}")]]

#align(center)[#tao-fit-display[#mitex("= \\int_X F( x ) F( T^{p \\cdot}(x) ) \\ d\\mu(x);")]]

#text("the left-hand side is ")#mi("{-1}")#text(", which gives (iii).")

#text("It remains to establish (iv). It will suffice to do so for sets ")#mi("{E}")#text(" of the form ")#link(<tao-0b8b952db0b44a724321>)[#text("(4)")]#text(". The claim then follows from the dilation invariance property")

#align(center)[#tao-fit-display[#mitex("p\\!-\\!\\lim_{N \\rightarrow \\infty} \\frac{1}{\\log N} \\sum_{n=1}^N \\frac{f(an+b)}{n} = a p\\!-\\!\\lim_{N \\rightarrow \\infty} \\frac{1}{\\log N} \\sum_{n=1}^N \\frac{f(n)}{n} 1_{n = b\\ (a)}")]]

#text("for any bounded function ")#mi("{f}")#text(", which is easily verified (here is where it is essential that we are using logarithmically averaged Césaro means rather than ordinary Césaro means).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can embed this ")#mi("{Aff_+({\\bf Z})}")#text("-system ")#mi("{X}")#text(" as a subsystem of a ")#mi("{Aff_+({\\bf Q})}")#text("-system ")#mi("{Aff_+({\\bf Q}) \\otimes_{Aff_+({\\bf Z})} X}")#text(", however this larger system is only ")#mi("{\\sigma}")#text("-finite rather than a probability space, and also the observable ")#mi("{M}")#text(" now takes values in the larger space ")#mi("{{\\bf Q} \\otimes_{\\bf Z} \\hat {\\bf Z}}")#text(". This recovers a group action rather than a semigroup action, but I am not sure if the added complexity of infinite measure is worth it.")
]

#heading(level: 1)[#strong[#text(" — 2. Two-point logarithmic Chowla — ")]]

#text("We now sketch how the proof of ")#link(<tao-1d22f9d56b97bde70e1b>)[#text("(3)")]#text(" in ")#link("https://arxiv.org/abs/1509.05422")[#text("this paper")]#text(" can be translated to the ergodic theory setting. For sake of notation let us just prove ")#link(<tao-1d22f9d56b97bde70e1b>)[#text("(3)")]#text(" when ")#mi("{h=1}")#text(". We will assume familiarity with ergodic theory concepts in this sketch. By taking a suitable Banach limit, it will suffice to establish that")

#align(center)[#tao-fit-display[#mitex("\\int_X F(x) F( T^{\\cdot+1} x)\\ d\\mu(x) = 0")]]

#text("for any Furstenberg limit produced by Proposition ")#link(<tao-2cd6f936b05db9d3e874>)[#text("1")]#text(", where ")#mi("{\\cdot+h}")#text(" denotes the operation of translation by ")#mi("{h}")#text(". By property (iii) of that proposition, we can the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\int_X F(T^{p\\cdot} x) F( T^{p\\cdot+p} x)\\ d\\mu(x)")]]

#text("for any prime ")#mi("{p}")#text(", and then by property (iv) we can write this in turn as")

#align(center)[#tao-fit-display[#mitex("\\int_X F(x) F( T^{p} x) p 1_{M(x) = 0\\ (p)}\\ d\\mu(x).")]]

#text("Averaging, we thus have")

#align(center)[#tao-fit-display[#tao-math("\\int_X F(x) F( T^{\\cdot+1} x)\\ d\\mu(x) = \\frac{1}{\\left|\\mathcal P\\right|} \\sum_{p \\in {\\mathcal P}_P} \\int_X F(x) F( T^{p} x) p 1_{M(x) = 0\\ (p)}\\ d\\mu(x)", block: true)]]

#text("for any ")#mi("{P>1}")#text(", where ")#mi("{{\\mathcal P}_P}")#text(" denotes the primes between ")#mi("{P/2}")#text(" and ")#mi("{P}")#text(".")

#text("On the other hand, the Matomaki-Radziwill theorem (twisted by Dirichlet characters) tells us that for any congruence class ")#mi("{q \\geq 1}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\lim_{H \\rightarrow \\infty} \\lim\\sup_{N \\rightarrow \\infty} \\frac{1}{\\log N} \\sum_{n \\leq N} \\left|\\frac{1}{H} \\sum_{h=1}^H \\lambda(n+qh)\\right| = 0", block: true)]]

#text("which on passing to the Furstenberg limit gives")

#align(center)[#tao-fit-display[#mitex("\\lim_{H \\rightarrow \\infty} \\int_X |\\frac{1}{H} \\sum_{h=1}^H F( T^{\\cdot+qh} x)|\\ d\\mu(x) = 0.")]]

#text("Applying the mean ergodic theorem, we conclude that ")#mi("{F}")#text(" is orthogonal to the ")#emph[#text("profinite factor")]#text(" of the ")#mi("{{\\bf Z}}")#text("-action, by which we mean the factor generated by the functions that are periodic (")#mi("{T^{\\cdot+q}}")#text("-invariant for some ")#mi("{q \\geq 1}")#text("). One can show from Fourier analysis that the profinite factor is characteristic for averaging along primes, and in particular that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|{\\mathcal P}_P\\right|} \\sum_{p \\in {\\mathcal P}_P} \\int_X F(x) F( T^{\\cdot + p} x)\\ d\\mu \\rightarrow 0", block: true)]]

#text("as ")#mi("{P \\rightarrow \\infty}")#text(". (This is not too difficult given the usual Vinogradov estimates for exponential sums over primes, but I don’t know of a good reference for this fact. ")#link("http://www.ams.org/mathscinet-getitem?mr=2361086")[#text("This paper of Frantzikinakis, Host, and Kra")]#text(" establishes the analogous claim that the Kronecker factor is characteristic for triple averages ")#tao-math("{\\frac{1}{\\left|\\mathcal P\\right|} \\sum_{p \\in {\\mathcal P}_P} \\int_X F(x) F( T^{p} x)\\ d\\mu}", block: false)#text(", and their argument would also apply here, but this is something of an overkill.) Thus, if we define the quantities")

#align(center)[#tao-fit-display[#tao-math("Q_P := \\frac{1}{\\left|{\\mathcal P}_P\\right|} \\sum_{p \\in {\\mathcal P}_P} \\int_X F(x) F( T^{\\cdot + p} x) (p 1_{M(x) = 0\\ (p)}-1)\\ d\\mu(x)", block: true)]]

#text("it will suffice to show that ")#tao-math("{\\liminf_{P \\rightarrow \\infty} \\left|Q_P\\right| = 0}", block: false)#text(".")

#text("Suppose for contradiction that ")#tao-math("{\\left|Q_P\\right| \\geq \\varepsilon}", block: false)#text(" for all sufficiently large ")#mi("{P}")#text(". We can write ")#mi("{Q_P}")#text(" as an expectation")

#align(center)[#tao-fit-display[#mitex("Q_P = {\\bf E} F_P( X_P, Y_P )")]]

#text("where ")#mi("{X_P}")#text(" is the ")#mi("{\\{-1,+1\\}^P}")#text("-valued random variable")

#align(center)[#tao-fit-display[#mitex("X_P := ( F( T^{\\cdot + k} x ) )_{0 \\leq k < P}")]]

#text("with ")#mi("{x}")#text(" drawn from ")#mi("{X}")#text(" with law ")#mi("{\\mu}")#text(", ")#mi("{Y_P}")#text(" is the ")#mi("{\\prod_{p \\in {\\mathcal P}_P} {\\bf Z}/p{\\bf Z}}")#text("-valued random variable")

#align(center)[#tao-fit-display[#mitex("Y_P := ( M(x)\\ (p) )_{p \\in {\\mathcal P}_P}")]]

#text("with ")#mi("{x}")#text(" as before, and ")#mi("{F_P}")#text(" is the function")

#align(center)[#tao-fit-display[#tao-math("F_P( (\\epsilon_k)_{0 \\leq k < P}, (a_p)_{p \\in {\\mathcal P}_P} ) := \\frac{1}{\\left|{\\mathcal P}_P\\right|} \\sum_{p \\in {\\mathcal P}_P} \\epsilon_0 \\epsilon_p (p 1_{a_p = 0\\ (p)} - 1).", block: true)]]

#text("As ")#tao-math("{\\left|Q_P\\right| \\geq \\varepsilon}", block: false)#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|F_P(X_P, Y_P)\\right| \\geq \\varepsilon/2", block: true)]]

#text("with probability at least ")#mi("{\\varepsilon/2}")#text(". On the other hand, an application of ")#link("https://en.wikipedia.org/wiki/Hoeffding's_inequality")[#text("Hoeffding’s inequality")]#text(" and the prime number theorem shows that if ")#mi("{U_P}")#text(" is drawn uniformly from ")#mi("{\\prod_{p \\in {\\mathcal P}_P} {\\bf Z}/p{\\bf Z}}")#text(" and independently of ")#mi("{X_P}")#text(", that one has the concentration of measure bound")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf P}( \\left|F_P(X_P, U_P)\\right| > \\varepsilon/2 ) \\leq 2 \\exp( - c_\\varepsilon P / \\log P )", block: true)]]

#text("for some ")#mi("{c_\\varepsilon > 0}")#text(". Using the Pinsker-type inequality from ")#link("https://terrytao.wordpress.com/2015/09/20/entropy-and-rare-events/")[#text("this previous blog post")]#text(", we conclude the lower bound")

#align(center)[#tao-fit-display[#mitex("I( X_P : Y_P ) \\gg_\\varepsilon \\frac{P}{\\log P}")]]

#text("on the mutual information between ")#mi("{X_P}")#text(" and ")#mi("{Y_P}")#text(". Using Shannon entropy inequalities as in my paper, this implies the entropy decrement")

#align(center)[#tao-fit-display[#mitex("\\frac{H(X_{kP})}{kP} \\leq \\frac{H(X_P)}{P} - \\frac{c_\\varepsilon}{\\log P} + O( \\frac{1}{k} )")]]

#text("for any natural number ")#mi("{k}")#text(", which on iterating (and using the divergence of ")#mi("{\\sum_{j=1}^\\infty \\frac{1}{j \\log j}}")#text(") shows that ")#mi("{\\frac{H(X_P)}{P}}")#text(" eventually becomes negative for sufficiently large ")#mi("{P}")#text(", which is absurd. (See also ")#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/")[#text("this previous blog post")]#text(" for a sketch of a slightly different way to conclude the argument from entropy inequalities.)")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb8119d9fc276b780d97d3f6f156c7a9da50962420966a10aea3c41230e4f967-fc350d449d4da6aa900eae30a9512458446b47a9f4eb944ecf588db9c5df17a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2017/03/05/furstenberg-limits-of-the-liouville-function/#comment-478893")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("One could ask whether there exist dynamical systems satisfying (2), (3), (4), and a weaker version of axiom (1) other than the obvious ones. Obviously a full understanding of the “obvious ones” requires some deep number theory, but it might still be possible to reach a conjectural understanding.")

#text("In particular, can we construct any “exotic” dynamical systems satisfying (2), (3), (4) at all?")

#text("PS You left some extra dots in Equation (3), where they are unneeded.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/03/05/furstenberg-limits-of-the-liouville-function/#comment-478913")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("Thanks for the correction! Yes, there are additional dynamical systems obeying (2), (3), (4). Here is one. Consider the space ")#mi("{\\bf R} \\oplus_{\\bf Z} \\hat {\\bf Z}")#text(" formed by quotienting ")#mi("{\\bf R} \\times \\hat {\\bf Z}")#text(" by the diagonal copy of the integers; this is also the inverse limit of ")#mi("{\\bf R}/q{\\bf Z}")#text(" for natural numbers ")#mi("q")#text(". This is a compact abelian group that is also a vector space over ")#mi("{\\bf Q}")#text(" (multiplication by ")#mi("1/a")#text(" comes from taking inverse limits of the scaling maps from ")#mi("{\\bf Z}/aq{\\bf Z}")#text(" to ")#mi("{\\bf Z}/q{\\bf Z}")#text("). One can take ")#mi("X")#text(" to be the compact abelian group ")#mi("({\\bf R} \\oplus_{\\bf Z} \\hat {\\bf Z}) \\times {\\hat {\\bf Z}} \\times ({\\bf R}/{\\bf Z})")#text(" with Haar measure, with an affine map ")#mi("\\phi(n) = an+b")#text(" acting on this space by ")#mi("(\\alpha, \\beta, m) \\mapsto (\\frac{\\alpha}{a}, \\beta + \\frac{b}{a} \\alpha + \\frac{\\Omega(a)}{2}, am+b)")#text(" where ")#mi("\\Omega(a)")#text(" is the number of prime factors of ")#mi("a")#text(" counting multiplicity), with ")#mi("F(\\alpha,\\beta,m) := 1_{[0,1/2)}(\\beta) - 1_{[1/2,1)}(\\beta)")#text(" and ")#mi("M(\\alpha,\\beta,m) = m")#text(". (This is basically the system that is blocking us from establishing local Fourier uniformity of the Liouville function.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/05/furstenberg-limits-of-the-liouville-function/#comment-478903")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("Is it possible to extend (3) to other completely multiplicative functions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/03/05/furstenberg-limits-of-the-liouville-function/#comment-478914")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("Yes; one replaces the minus sign here by the value of the multiplicative function at the given prime.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7d967a9f27533fb4a238f317bc48ac1457d58c2fad379aba1bbfde01df9517ab-2f6d7d0d03263f8dd58d78d7c25da7026c933cdac6922f136d1ee9542a128f9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lucas A Brown")]], [#link("https://terrytao.wordpress.com/2017/03/05/furstenberg-limits-of-the-liouville-function/#comment-478905")[#strong[#text("Lucas A Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("In your second paragraph, you dropped a word right after “capture”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aula")]], [#link("https://terrytao.wordpress.com/2017/03/05/furstenberg-limits-of-the-liouville-function/#comment-478944")[#strong[#text("Aula")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2017")])]

#text("Two typesetting comments. First, you shouldn’t use \\dots in math mode; in the rare contexts where you really need the dots down on the baseline (eg. comma-separated lists) you should use \\ldots, but in most cases \\cdots is better. Second, typing Aff in math mode results in two separate f glyphs that are too far apart; instead you should use {\\it Aff} to get a proper double-f ligature.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/05/furstenberg-limits-of-the-liouville-function/#comment-478951")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2017")])]

#text("Well, you should indeed use \\dots and not \\ldots or \\cdots. (TeX takes care of the correct placement of the ellipses.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/05/furstenberg-limits-of-the-liouville-function/#comment-479400")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2017")])]

#text("No one cares")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e579fa60f06b2b355ef3edabbae6dec6d9e7a0eed71c6645929e8f327d820eed-ba4a4594e7b47094d4631d6c89616486cc2038fed96e37cd81c7d89edceb3a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2017/03/05/furstenberg-limits-of-the-liouville-function/#comment-478954")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2017")])]

#text("Is n missing from the denominators of two displayed equations just after (4)?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/280eb763735af9573fe0d6e75160fdf49201f7fc4518e12e9dcfa711d060e39c-18f8b145e6dd0013890319f91ec2381fab0403832c045f9c7cb662b5103fceab.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Romain Viguier")]], [#link("https://terrytao.wordpress.com/2017/03/05/furstenberg-limits-of-the-liouville-function/#comment-479014")[#strong[#text("Romain Viguier")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2017")])]

#text("First mathematical article from prof Tao i read, very very high level, specially when you have not the required background.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3205d8eeb9c554b4dd0cc3d073ee0fccb7caa8f5245405e7db9ef43dfd7e2b5-a4d99c4307912feff11c653ffa27243560eff8a237c725adfd34835995912cc1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tao’s Proof of (logarithmically averaged) Chowla’s conjecture for two point correlations | I Can't Believe It's Not Random!")]], [#link("https://terrytao.wordpress.com/2017/03/05/furstenberg-limits-of-the-liouville-function/#comment-506806")[#strong[#text("Tao’s Proof of (logarithmically averaged) Chowla’s conjecture for two point correlations | I Can't Believe It's Not Random!")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2018")])]

#text("[…] systems to, among other things, simplify the notation. This approach was also carried out by Tao in his blog, and the main motivation for me to write this post was to try to use an easier construction of a […]")
]
