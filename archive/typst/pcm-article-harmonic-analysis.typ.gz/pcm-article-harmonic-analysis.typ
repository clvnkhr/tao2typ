// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/
// Converted to Typst by tao2typ: "2026-10-14T16:35:01.586981+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "PCM article: Harmonic analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("PCM article: Harmonic analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 September 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/")[#text("https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’d like to begin today by welcoming ")#link("http://en.wikipedia.org/wiki/Timothy_Gowers")[#text("Timothy Gowers")]#text(" to the mathematics blogging community; ")#link("http://gowers.wordpress.com/")[#text("Tim’s blog")]#text(" will also double as the “official” blog for the ")#link("http://press.princeton.edu/titles/8350.html")[#text("Princeton Companion to Mathematics")]#text(", as indicated by his ")#link("http://gowers.wordpress.com/2007/09/06/hello-world/")[#text("first post")]#linebreak()#text(" which also contains links to further material (such as sample articles) on the Companion. Tim is already thinking beyond the blog medium, though, as you can see in his ")#link("http://gowers.wordpress.com/2007/09/11/what-might-an-expository-mathematical-wiki-be-like/")[#text("second post")]#text("…")

#text("Anyway, this gives me an excuse to continue ")#link("https://terrytao.wordpress.com/category/paper/companion/")[#text("my own series")]#text(" of PCM articles. Some years back, Tim asked me to write a longer article on ")#link("http://en.wikipedia.org/wiki/Harmonic_analysis")[#text("harmonic analysis")]#text(" – the quantitative study of oscillation, transforms, and other features of functions and sets on domains. At the time I did not fully understand the theme of the Companion, and wrote a rather detailed and ")#link("http://www.math.ucla.edu/~tao/preprints/Expository/harmonic_survey.pdf")[#text("technical survey of the subject")]#text(", which turned out to be totally unsuitable for the Companion. I then went back and rewrote the article from scratch, leading to ")#link("http://www.math.ucla.edu/~tao/247a.1.06f/notes0.pdf")[#text("this article")]#text(", which (modulo some further editing) is close to what will actually appear. (These two articles were already available on my web site, but not in a particularly prominent manner.) So, as you can see, the articles in the Companion are not exactly at the same level as the expository survey articles one sees published in journals.")

#text("I should also mention that some other authors for the Companion have put their articles on-line. For instance, ")#link("http://en.wikipedia.org/wiki/Alain_Connes")[#text("Alain Connes")]#text("‘ PCM article “")#text("Advice for the beginner")#text("“, aimed at graduate students just starting out in research mathematics, was in fact already linked to on ")#link("https://terrytao.wordpress.com/career-advice/")[#text("one of the pages of this blog")]#text(". I’ll try to point out links to other PCM articles in future posts in this series.")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/#comment-9055")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2007")])]

#text("Dear Terry,")#linebreak()#text(" I have a question regarding the write-up on page 4 of “this article.”")#linebreak()#text(" Were by any chance solutions (harmonics) of models studied by physicists and engineers (e.g., the Laplace equation) the main motivation for the")#linebreak()#text(" theory of Fourier series?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/#comment-9056")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2007")])]

#text("Dear Adam,")

#text("If I recall correctly, Fourier introduced the theory of Fourier series in order to solve the heat equation; the applications to wave equations came a little later. At the time, the rigorous analytical aspects of the theory were not well understood; for instance, there was much skepticism over Fourier’s claims that one could represent a discontinuous function (such as a square wave) as a convergent sum of continuous functions (sine and cosine waves), because the distinction between uniform convergence and pointwise convergence was not fully appreciated back then. The rigorous theory had to wait until the later work of Dirichlet, Fejer, and Riemann; their work can be considered the starting point for modern harmonic analysis. The connection between rigorous harmonic analysis and the physics of waves and harmonics took a while to develop though (except in the special case of constant coefficient linear equations, which could be solved exactly via the Fourier transform); only in the 1950s or so did the rigorous theory of PDEs develop to the point in which harmonic analysis tools could be systematically applied (although important precursors, such as the Sobolev embedding theorem, started emerging a few years earlier).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/#comment-9059")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2007")])]

#text("Dear Terry,")#linebreak()#text(" From what Wikipedia is writing about Laplace, it would seem that")#linebreak()#text(" the idea of spherical harmonics goes back to Legendre (1783) and")#linebreak()#text(" Laplace (1784). Fourier was probably aware of these works.")#linebreak()#text(" It is just that in applied mathematics people respect most the")#linebreak()#text(" original idea.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9dc9e27b5bad26fa28af07145a70a7255b2b140e7b6c2c168948562820d9d3b-86a47e99d5ff734c56638abcff8e5d49b9eee3326826f31181d452a18264f3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ralph Hartley")]], [#link("https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/#comment-9064")[#strong[#text("Ralph Hartley")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2007")])]

#text("Are the “Dirichlet summation operators” S_N on page 4 the same as the “Dirichlet operators” D_N on page 5?")

#text("If so, shouldn’t you use the same letter for both? If not, you need to define the latter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/#comment-9065")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2007")])]

#text("Dear Ralph,")

#text("You are correct, they should be the same. Hopefully I’ve fixed it now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f45b42b0639e3e86e647533dd2ad038a6987a373ad82e14ec81b024b242768dd-3df4711a29dbaefca53f9921e61de92ba27ef9eeb6b7b85a24f358b7c243cbaf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhijeet")]], [#link("https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/#comment-9332")[#strong[#text("Abhijeet")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2007")])]

#text("Dear Dr Tao,")#linebreak()#text(" Its so wonderful to read your blog. I am a graduate student taking my first steps out in the world of mathematics and I appreciate the work that you put in to explain complex concepts in simplified terms on your blog. All your articles are immensely informative. Its an added bonus to have Dr Gowers start his own blog as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tal Yasur")]], [#link("https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/#comment-9544")[#strong[#text("Tal Yasur")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2007")])]

#text("Dear Prof. Tao,")#linebreak()#text(" A question regarding nomenclature:")#linebreak()#text(" It is intereting that you call “Harmonic Analysis” what I (and most mathematicians I know I guess) would simply call “Analysis”, or, if you press me to the wall, “Real Analysis”.")#linebreak()#text(" Is this a common usage among your colleagues? If so, do you know how, historically, did “Harmonic” take over?")#linebreak()#text(" Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/#comment-9564")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2007")])]

#text("Dear Tal,")

#text("It is a fairly universal term within the community of harmonic analysts. For instance, one of the standard texts in the subject, by my advisor Elias Stein, is titled “Harmonic Analysis: Real-variable methods, orthogonality, and oscillatory integrals”, which is a fairly accurate description of the topic.")

#text("As with other major branches of mathematics (e.g. algebra, geometry, topology, logic, number theory, applied mathematics), analysis has split over the last century or so into quite distinct (but adjacent) subfields, of which harmonic analysis is only one component. For instance, there is complex analysis (the analysis of holomorphic functions of one variable), several complex variables, functional analysis (the analysis of function spaces), numerical analysis (the analysis of numerical algorithms), geometric analysis (a rather broad term, but still fairly self-explanatory), and so forth. Real analysis – the study of real-valued functions or subsets of ")#mi("{\\Bbb R}")#text(" or ")#mi("{\\Bbb R}^n")#text(", has itself split into various loosely connected subfields, ranging from harmonic analysis at its more quantitative end to descriptive set theory at its more qualitative end, as well as geometric measure theory somewhere in between. Harmonic analysis itself has subfields: applied and computational harmonic analysis (focusing on such things as the FFT and wavelets) has a very different focus than “pure” harmonic analysis (of which the topics of Stein’s book are a good example).")

#text("To make matters more confusing, there is an independent field of mathematics called “abstract harmonic analysis”, which is concerned with the study of the Fourier transform from a representation-theoretic perspective; what I call harmonic analysis is sometimes clarified to “real-variable harmonic analysis” to distinguish the two. While both types of harmonic analysis use the Fourier transform (and related concepts, such as harmonics), their objectives and techniques are rather different.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/#comment-9614")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2007")])]

#text("Tal,")

#text("To expand on Terry’s response, I would note that graduate textbooks titled “Real Analysis” or similarly are likely to cover the basics of some subset of the following fields: measure theory, point-set topology, functional analysis, harmonic analysis, and possibly some PDE, probability, or operator theory (which one may or may not consider a subfield of functional analysis).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/#comment-9625")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2007")])]

#text("Hi Terence,")

#text("The post ‘PCM “deleted scene”: Wave maps‘ seems to be more consistent with mechanics.")

#text("The post ‘PCM article: Harmonic analysis’ when viewed as harmonic maps seems more consistent with electromagnetism.")

#text("This letter, Donghui Xu, ‘Hannay angle in an LCR circuit with time-dependent inductance inductance, capacity and resistance’, demonstrates the transformation from electromagnetic to Newtonian then Hamiltonian mechanics.")#linebreak()#text(" [J Physics A: Math Gen, 35 (2002) L455-L457]")

#link("http://www.iop.org/EJ/article/0305-4470/35/29/104/a229l4.pdf?request-id=wpJTyl1l3BGbNMHx2wi7Kg")[#text("http://www.iop.org/EJ/article/0305-4470/35/29/104/a229l4.pdf?request-id=wpJTyl1l3BGbNMHx2wi7Kg")]

#text("Question:")

#text("Rather than transform from EM to mechanics [or gravity], would it not be easier to transform from mechanics [or gravity] to EM?")

#text("Reasoning:")

#text("QM and GR [celestial] trajectories appear to be [unseen] harmonic helical waves.")

#text("This type of wave may be a partial or virtual solenoid [that is, an unwired helical path, perhaps with a vacuum rather than with air or iron]?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/93fb26ec0795d2f4c84825063418b1de4f7aa1d6772003aca2a0d9a070e75c40-3bf5a49ffb4af024981d964c7b63103f409f1b918dc75d53cee8286ceee87d1d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jose Brox")]], [#link("https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/#comment-27159")[#strong[#text("Jose Brox")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2008")])]

#text("Dear Prof. Tao:")

#text("What is the exact mathematical meaning of the sentence “Functions tend to have infinitely many degrees of freedom” as stated in your article “Harmonic Analysis”? In which sense are these “degrees of freedom” defined?")

#text("Thanks and regards! Jose Brox")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/#comment-27171")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2008")])]

#text("Dear Jose,")

#text("Generally speaking, a function space on a domain which is an infinite set (e.g. ")#mi("L^p({\\Bbb R})")#text(") will be infinite-dimensional, which is one formalisation of what it means to have infinitely many degrees of freedom. (Even if one restricts to the class of analytic functions, which is a relatively small class of functions in the grand scheme of things, one still has infinitely many degrees of freedom, as one can see from the coefficients in the Taylor expansion, which need to obey some growth conditions (in order to have a non-zero radius of convergence) but are otherwise unconstrained.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/#comment-30305")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2008")])]

#text("I was a bit intrigued by the following open problem you referenced in your original technical article (bottom of page 25) — however there is no citation. Do you know of any references either to the origin of the conjecture or progress towards it?")

#text("From Bessel’s inequality it is easy to see that ")#mi("\\sum c_n e^{2 \\pi i n^2 x}  \\in L^2(R/Z)")#text(" whenever c_n is square summable. It is conjectured but not known that these functions are not only in L^2, but are in fact in L^p for all ")#mi("2 \\leq p < 4")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/#comment-30346")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2008")])]

#text("Dear anonymous,")

#text("I believe the conjecture originates with Walter Rudin:")

#text("Rudin, Walter")#linebreak()#text(" Trigonometric series with gaps.")#linebreak()#text(" J. Math. Mech. 9 1960 203–227.")#linebreak()#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=116177")[#text("http://www.ams.org/mathscinet-getitem?mr=116177")]

#text("There is a brief mention of it in Ben Green’s guest post here at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/")[#text("(Ben Green) The Polynomial Freiman-Ruzsa conjecture")]
]

#text("I am not sure as to the most recent literature on the problem, though a citation search from Rudin’s paper leads to dozens of references.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e867149d493a7150ab468a9a18def5708e9a34e3daffea9e77fbd0c5b527493-c4d479d2f4ed77509b0d1c303fd1a48de36baaca9f793217e845cbd5a158163b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rajeshd007")]], [#link("https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/#comment-448973")[#strong[#text("rajeshd007")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2015")])]

#text("Dear Prof Tao,")

#text("Can you comment on this concept, which links jump discontinuties to the Fourier transform? : ")#link("http://mathoverflow.net/q/165038/14414")[#text("http://mathoverflow.net/q/165038/14414")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7372863f1c5025505c2f0e372bc199488ae50a5b564ba938f96378b1e5c3c9f-201989625023f416037f6f9558889b2717dcd99ac36fd4269049bb986d79e922.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxisjaisi")]], [#link("https://terrytao.wordpress.com/2007/09/11/pcm-article-harmonic-analysis/#comment-473358")[#strong[#text("maxisjaisi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2016")])]

#text("Dear Terry, I hope it isn’t too much of a subject change, but what led you to harmonic analysis in the first place? You mentioned that you were already reading a book on singular integrals as an undergraduate at Flinders, but it’s a little bit odd (at least to me) that an undergraduate would be interested in harmonic analysis, considering the fact that most of the “cool” ideas presented to students are usually taken from fields like low dimensional topology, analysis of one complex variable, Galois theory, algebraic geometry, etc.. Also, quality introductory (and less technical) books on harmonic analysis are much harder to find. Was it your advisor, or a book, or a theorem that revealed to you harmonic analysis’s beauty?")
]
