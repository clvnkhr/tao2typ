// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/05/18/failure-of-the-l1-pointwise-and-maximal-ergodic-theorems-for-the-free-group/
// Converted to Typst by tao2typ: "2026-10-14T10:24:45.339779+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Failure of the L^1 pointwise and maximal ergodic theorems for the free group", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Failure of the L^1 pointwise and maximal ergodic theorems for the free group")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 May 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/05/18/failure-of-the-l1-pointwise-and-maximal-ergodic-theorems-for-the-free-group/")[#text("https://terrytao.wordpress.com/2015/05/18/failure-of-the-l1-pointwise-and-maximal-ergodic-theorems-for-the-free-group/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("http://arxiv.org/abs/1505.04725")[#text("Failure of the ")#mi("{L^1}")#text(" pointwise and maximal ergodic theorems for the free group")]#text("“, submitted to ")#link("http://journals.cambridge.org/action/displayJournal?jid=FMS")[#text("Forum of Mathematics, Sigma")]#text(". This paper concerns a variant of the ")#link("http://en.wikipedia.org/wiki/Ergodic_theory#Probabilistic_formulation:_Birkhoff.E2.80.93Khinchin_theorem")[#text("pointwise ergodic theorem")]#text(" of Birkhoff, which asserts that if one has a measure-preserving shift map ")#mi("{T: X \\rightarrow X}")#text(" on a probability space ")#mi("{X = (X,\\mu)}")#text(", then for any ")#mi("{f \\in L^1(X)}")#text(", the averages ")#mi("{\\frac{1}{N} \\sum_{n=1}^N f \\circ T^{-n}}")#text(" converge pointwise almost everywhere. (In the important case when the shift map ")#mi("{T}")#text(" is ergodic, the pointwise limit is simply the mean ")#mi("{\\int_X f\\ d\\mu}")#text(" of the original function ")#mi("{f}")#text(".)")

#text("The pointwise ergodic theorem can be extended to measure-preserving actions of other amenable groups, if one uses a suitably “tempered” Folner sequence of averages; see ")#link("http://www.ams.org/mathscinet-getitem?mr=1865397")[#text("this paper of Lindenstrauss")]#text(" for more details. (I also wrote up some notes on that paper ")#link("http://www.math.ucla.edu/~tao/preprints/Expository/elon.dvi")[#text("here")]#text(", back in 2006 before I had started this blog.) But the arguments used to handle the amenable case break down completely for non-amenable groups, and in particular for the free non-abelian group ")#mi("{F_2}")#text(" on two generators.")

#link("http://www.ams.org/mathscinet-getitem?mr=1294672")[#text("Nevo and Stein")]#text(" studied this problem and obtained a number of pointwise ergodic theorems for ")#mi("{F_2}")#text("-actions ")#mi("{(T_g)_{g \\in F_2}}")#text(" on probability spaces ")#mi("{(X,\\mu)}")#text(". For instance, for the spherical averaging operators")

#align(center)[#tao-fit-display[#tao-math("{\\mathcal A}_n f := \\frac{1}{4 \\times 3^{n-1}} \\sum_{g \\in F_2: \\left|g\\right| = n} f \\circ T_g^{-1}", block: true)]]

#text("(where ")#tao-math("{\\left|g\\right|}", block: false)#text(" denotes the length of the reduced word that forms ")#mi("{g}")#text("), they showed that ")#mi("{{\\mathcal A}_{2n} f}")#text(" converged pointwise almost everywhere provided that ")#mi("{f}")#text(" was in ")#mi("{L^p(X)}")#text(" for some ")#mi("{p>1}")#text(". (The need to restrict to spheres of even radius can be seen by considering the action of ")#mi("{F_2}")#text(" on the two-element set ")#mi("{\\{0,1\\}}")#text(" in which both generators of ")#mi("{F_2}")#text(" act by interchanging the elements, in which case ")#mi("{{\\mathcal A}_n}")#text(" is determined by the parity of ")#mi("{n}")#text(".) This result was reproven with a different and simpler proof ")#link("http://www.ams.org/mathscinet-getitem?mr=1923970")[#text("by Bufetov")]#text(", who also managed to relax the condition ")#mi("{f \\in L^p(X)}")#text(" to the weaker condition ")#mi("{f \\in L \\log L(X)}")#text(".")

#text("The question remained open as to whether the pointwise ergodic theorem for ")#mi("{F_2}")#text("-actions held if one only assumed that ")#mi("{f}")#text(" was in ")#mi("{L^1(X)}")#text(". Nevo and Stein were able to establish this for the Cesáro averages ")#mi("{\\frac{1}{N} \\sum_{n=1}^N {\\mathcal A}_n}")#text(", but not for ")#mi("{{\\mathcal A}_n}")#text(" itself. About six years ago, Assaf Naor and I ")#link("https://terrytao.wordpress.com/2009/12/07/random-martingales-and-localization-of-maximal-inequalities/")[#text("tried our hand at this problem")]#text(", and was able to show an associated maximal inequality on ")#mi("{\\ell^1(F_2)}")#text(", but due to the non-amenability of ")#mi("{F_2}")#text(", this inequality did not transfer to ")#mi("{L^1(X)}")#text(" and did not have any direct impact on this question, despite a fair amount of effort on our part to attack it.")

#text("Inspired by some recent conversations with Lewis Bowen, I returned to this problem. This time around, I tried to construct a counterexample to the ")#mi("{L^1}")#text(" pointwise ergodic theorem – something Assaf and I had not seriously attempted to do (perhaps due to being a bit too enamoured of our ")#mi("{\\ell^1(F_2)}")#text(" maximal inequality). I knew of an ")#link("http://www.ams.org/mathscinet-getitem?mr=236354")[#text("existing counterexample of Ornstein")]#text(" regarding a failure of an ")#mi("{L^1}")#text(" ergodic theorem for iterates ")#mi("{P^n}")#text(" of a self-adjoint Markov operator – in fact, I had written ")#link("http://www.math.ucla.edu/~tao/preprints/Expository/ornstein.dvi")[#text("some notes on this example")]#text(" back in 2007. Upon revisiting my notes, I soon discovered that the Ornstein construction was adaptable to the ")#mi("{F_2}")#text(" setting, thus settling the problem in the negative:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Failure of ")#mi("{L^1}")#text(" pointwise ergodic theorem)")]#text(" There exists a measure-preserving ")#mi("{F_2}")#text("-action on a probability space ")#mi("{X}")#text(" and a non-negative function ")#mi("{f \\in L^1(X)}")#text(" such that ")#mi("{\\sup_n {\\mathcal A}_{2n} f(x) = +\\infty}")#text(" for almost every ")#mi("{x}")#text(".")
]

#text("To describe the proof of this theorem, let me first briefly sketch the main ideas of Ornstein’s construction, which gave an example of a self-adjoint Markov operator ")#mi("{P}")#text(" on a probability space ")#mi("{X}")#text(" and a non-negative ")#mi("{f \\in L^1(X)}")#text(" such that ")#mi("{\\sup_n P^n f(x) = +\\infty}")#text(" for almost every ")#mi("{x}")#text(". By some standard manipulations, it suffices to show that for any given ")#mi("{\\alpha > 0}")#text(" and ")#mi("{\\varepsilon>0}")#text(", there exists a self-adjoint Markov operator ")#mi("{P}")#text(" on a probability space ")#mi("{X}")#text(" and a non-negative ")#mi("{f \\in L^1(X)}")#text(" with ")#tao-math("{\\left\\|f\\right\\|_{L^1(X)} \\leq \\alpha}", block: false)#text(", such that ")#mi("{\\sup_n P^n f \\geq 1-\\varepsilon}")#text(" on a set of measure at least ")#mi("{1-\\varepsilon}")#text(". Actually, it will be convenient to replace the Markov chain ")#mi("{(P^n f)_{n \\geq 0}}")#text(" with an ")#emph[#text("ancient Markov chain")]#text(" ")#mi("{(f_n)_{n \\in {\\bf Z}}}")#text(" – that is to say, a sequence of non-negative functions ")#mi("{f_n}")#text(" for both positive and negative ")#mi("{f}")#text(", such that ")#mi("{f_{n+1} = P f_n}")#text(" for all ")#mi("{n \\in {\\bf Z}}")#text(". The purpose of requiring the Markov chain to be ancient (that is, to extend infinitely far back in time) is to allow for the Markov chain to be shifted arbitrarily in time, which is key to Ornstein’s construction. (Technically, Ornstein’s original argument only uses functions that go back to a large negative time, rather than being infinitely ancient, but I will gloss over this point for sake of discussion, as it turns out that the ")#mi("{F_2}")#text(" version of the argument can be run using infinitely ancient chains.)")

#text("For any ")#mi("{\\alpha>0}")#text(", let ")#mi("{P(\\alpha)}")#text(" denote the claim that for any ")#mi("{\\varepsilon>0}")#text(", there exists an ancient Markov chain ")#mi("{(f_n)_{n \\in {\\bf Z}}}")#text(" with ")#tao-math("{\\left\\|f_n\\right\\|_{L^1(X)} = \\alpha}", block: false)#text(" such that ")#mi("{\\sup_{n \\in {\\bf Z}} f_n \\geq 1-\\varepsilon}")#text(" on a set of measure at least ")#mi("{1-\\varepsilon}")#text(". Clearly ")#mi("{P(1)}")#text(" holds since we can just take ")#mi("{f_n=1}")#text(" for all ")#mi("{n}")#text(". Our objective is to show that ")#mi("{P(\\alpha)}")#text(" holds for arbitrarily small ")#mi("{\\alpha}")#text(". The heart of Ornstein’s argument is then the implication ")#metadata(none) <tao-9513229d435978263d82>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("P(\\alpha) \\implies P( \\alpha (1 - \\frac{\\alpha}{4}) )")]]

#text("for any ")#mi("{0 < \\alpha \\leq 1}")#text(", which upon iteration quickly gives the desired claim.")

#text("Let’s see informally how ")#link(<tao-9513229d435978263d82>)[#text("(1)")]#text(" works. By hypothesis, and ignoring epsilons, we can find an ancient Markov chain ")#mi("{(f_n)_{n \\in {\\bf Z}}}")#text(" on some probability space ")#mi("{X}")#text(" of total mass ")#tao-math("{\\left\\|f_n\\right\\|_{L^1(X)} = \\alpha}", block: false)#text(", such that ")#mi("{\\sup_n f_n}")#text(" attains the value of ")#mi("{1}")#text(" or greater almost everywhere. Assuming that the Markov process is irreducible, the ")#mi("{f_n}")#text(" will eventually converge as ")#mi("{n \\rightarrow \\infty}")#text(" to the constant value of ")#tao-math("{\\left\\|f_n\\right\\|_{L^1(X)}}", block: false)#text(", in particular its final state will essentially stay above ")#mi("{\\alpha}")#text(" (up to small errors).")

#text("Now suppose we duplicate the Markov process by replacing ")#mi("{X}")#text(" with a double copy ")#mi("{X \\times \\{1,2\\}}")#text(" (giving ")#mi("{\\{1,2\\}}")#text(" the uniform probability measure), and using the disjoint sum of the Markov operators on ")#mi("{X \\times \\{1\\}}")#text(" and ")#mi("{X \\times \\{2\\}}")#text(" as the propagator, so that there is no interaction between the two components of this new system. Then the functions ")#mi("{f^{\\prime}_n(x,i) := f_n(x) 1_{i=1}}")#text(" form an ancient Markov chain of mass at most ")#mi("{\\alpha/2}")#text(" that lives solely in the first half ")#mi("{X \\times \\{1\\}}")#text(" of this copy, and ")#mi("{\\sup_n f^{\\prime}_n}")#text(" attains the value of ")#mi("{1}")#text(" or greater on almost all of the first half ")#mi("{X \\times \\{1\\}}")#text(", but is zero on the second half. The final state of ")#mi("{f^{\\prime}_n}")#text(" will be to stay above ")#mi("{\\alpha}")#text(" in the first half ")#mi("{X \\times \\{1\\}}")#text(", but be zero on the second half.")

#text("Now we modify the above example by allowing an infinitesimal amount of interaction between the two halves ")#mi("{X \\times \\{1\\}}")#text(", ")#mi("{X \\times \\{2\\}}")#text(" of the system (I mentally think of ")#mi("{X \\times \\{1\\}}")#text(" and ")#mi("{X \\times \\{2\\}}")#text(" as two identical boxes that a particle can bounce around in, and now we wish to connect the boxes by a tiny tube). The precise way in which this interaction is inserted is not terribly important so long as the new Markov process is irreducible. Once one does so, then the ancient Markov chain ")#mi("{(f^{\\prime}_n)_{n \\in {\\bf Z}}}")#text(" in the previous example gets replaced by a slightly different ancient Markov chain ")#mi("{(f^{\\prime\\prime}_n)_{n \\in {\\bf Z}}}")#text(" which is more or less identical with ")#mi("{f^{\\prime}_n}")#text(" for negative times ")#mi("{n}")#text(", or for bounded positive times ")#mi("{n}")#text(", but for very large values of ")#mi("{n}")#text(" the final state is now constant across the entire state space ")#mi("{X \\times \\{1,2\\}}")#text(", and will stay above ")#mi("{\\alpha/2}")#text(" on this space.")

#text("Finally, we consider an ancient Markov chain ")#mi("{F_n}")#text(" which is basically of the form")

#align(center)[#tao-fit-display[#mitex("F_n(x,i) \\approx f^{\\prime\\prime}_n(x,i) + (1 - \\frac{\\alpha}{2}) f_{n-M}(x) 1_{i=2}")]]

#text("for some large parameter ")#mi("{M}")#text(" and for all ")#mi("{n \\leq M}")#text(" (the approximation becomes increasingly inaccurate for ")#mi("{n}")#text(" much larger than ")#mi("{M}")#text(", but never mind this for now). This is basically two copies of the original Markov process in separate, barely interacting state spaces ")#mi("{X \\times \\{1\\}, X \\times \\{2\\}}")#text(", but with the second copy delayed by a large time delay ")#mi("{M}")#text(", and also attenuated in amplitude by a factor of ")#mi("{1-\\frac{\\alpha}{2}}")#text(". The total mass of this process is now ")#mi("{\\frac{\\alpha}{2} + \\frac{\\alpha}{2} (1 -\\frac{\\alpha}{2}) = \\alpha (1 - \\alpha/4)}")#text(". Because of the ")#mi("{f^{\\prime\\prime}_n}")#text(" component of ")#mi("{F_n}")#text(", we see that ")#mi("{\\sup_n F_n}")#text(" basically attains the value of ")#mi("{1}")#text(" or greater on the first half ")#mi("{X \\times \\{1\\}}")#text(". On the second half ")#mi("{X \\times \\{2\\}}")#text(", we work with times ")#mi("{n}")#text(" close to ")#mi("{M}")#text(". If ")#mi("{M}")#text(" is large enough, ")#mi("{f^{\\prime\\prime}_n}")#text(" would have averaged out to about ")#mi("{\\alpha/2}")#text(" at such times, but the ")#mi("{(1 - \\frac{\\alpha}{2}) f_{n-M}(x)}")#text(" component can get as large as ")#mi("{1-\\alpha/2}")#text(" here. Summing (and continuing to ignore various epsilon losses), we see that ")#mi("{\\sup_n F_n}")#text(" can get as large as ")#mi("{1}")#text(" on almost all of the second half of ")#mi("{X \\times \\{2\\}}")#text(". This concludes the rough sketch of how one establishes the implication ")#link(<tao-9513229d435978263d82>)[#text("(1)")]#text(".")

#text("It was observed ")#link("http://www.ams.org/mathscinet-getitem?mr=1923970")[#text("by Bufetov")]#text(" that the spherical averages ")#mi("{{\\mathcal A}_n}")#text(" for a free group action can be lifted up to become powers ")#mi("{P^n}")#text(" of a Markov operator, basically by randomly assigning a “velocity vector” ")#mi("{s \\in \\{a,b,a^{-1},b^{-1}\\}}")#text(" to one’s base point ")#mi("{x}")#text(" and then applying the Markov process that moves ")#mi("{x}")#text(" along that velocity vector (and then randomly changing the velocity vector at each time step to the “reduced word” condition that the velocity never flips from ")#mi("{s}")#text(" to ")#mi("{s^{-1}}")#text("). Thus the spherical average problem has a Markov operator interpretation, which opens the door to adapting the Ornstein construction to the setting of ")#mi("{F_2}")#text(" systems. This turns out to be doable after a certain amount of technical artifice; the main thing is to work with ")#mi("{F_2}")#text("-measure preserving systems that admit ancient Markov chains that are initially supported in a very small region in the “interior” of the state space, so that one can couple such systems to each other “at the boundary” in the fashion needed to establish the analogue of ")#link(<tao-9513229d435978263d82>)[#text("(1)")]#text(" without disrupting the ancient dynamics of such chains. The initial such system (used to establish the base case ")#mi("{P(1)}")#text(") comes from basically considering the action of ")#mi("{F_2}")#text(" on a (suitably renormalised) “infinitely large ball” in the Cayley graph, after suitably gluing together the boundary of this ball to complete the action. The ancient Markov chain associated to this system starts at the centre of this infinitely large ball at infinite negative time ")#mi("{n=-\\infty}")#text(", and only reaches the boundary of this ball at the time ")#mi("{n=0}")#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/18/failure-of-the-l1-pointwise-and-maximal-ergodic-theorems-for-the-free-group/#comment-455952")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2015")])]

#text("“I also wrote up some notes on that paper here, back in 2006 before I had started this blog.”")#linebreak()#text(" Shouldn’t the tenses be reversed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a382183d3ed7cf33b841b9044414e6aa0b91df1f4ea991fed59aa4ff2caf406-aa091041e3d91f48464237b83b2439f11d347b3a9aaa0c27dc2e4ef3724cb570.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of g")]], [#link("https://terrytao.wordpress.com/2015/05/18/failure-of-the-l1-pointwise-and-maximal-ergodic-theorems-for-the-free-group/#comment-455955")[#strong[#text("g")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2015")])]

#text("The tenses look fine to me as they are, for what it’s worth.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/05/18/failure-of-the-l1-pointwise-and-maximal-ergodic-theorems-for-the-free-group/#comment-455966")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2015")])]

#text("Line 5 of final paragraph: I don’t yet get the math but my English parser breaks on “…stage, time step…”. Do you perhaps mean “…time step, subject…”?")

#emph[#text("[Corrected, thanks – T.]")]
]
