// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/
// Converted to Typst by tao2typ: "2026-10-14T16:38:07.513445+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Yves Meyer wins the 2017 Abel Prize", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Yves Meyer wins the 2017 Abel Prize")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 March 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/")[#text("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a short post to note that Norwegian Academy of Science and Letters has just announced that the 2017 Abel prize ")#link("http://www.abelprize.no/c69461/seksjon/vis.html?tid=69535&strukt_tid=69461")[#text("has been awarded to Yves Meyer")]#text(", “for his pivotal role in the development of the mathematical theory of wavelets”. The actual prize ceremony will be at Oslo in May.")

#text("I am actually in Oslo myself currently, having just presented Meyer’s work at ")#link("https://www.youtube.com/watch?v=wTzo4VV_T9U")[#text("the announcement ceremony")]#text(" (and also having written a ")#link("http://www.abelprize.no/c69461/binfil/download.php?tid=69542")[#text("brief description of some of his work")]#text("). The Abel prize has a somewhat unintuitive (and occasionally misunderstood) arrangement in which the presenter of the work of the prize is selected independently of the winner of the prize (I think in part so that the choice of presenter gives no clues as to the identity of the laureate). In particular, like other presenters before me (which in recent years have included Timothy Gowers, Jordan Ellenberg, and Alex Bellos), I agreed to present the laureate’s work before knowing who the laureate was! But in this case the task was very easy, because Meyer’s areas of (both pure and applied) harmonic analysis and PDE fell rather squarely within my own area of expertise. (I had previously written about some other work of Meyer in ")#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/")[#text("this blog post")]#text(".) Indeed I had learned about Meyer’s wavelet constructions as a graduate student while taking a course from ")#link("https://en.wikipedia.org/wiki/Ingrid_Daubechies")[#text("Ingrid Daubechies")]#text(". Daubechies also made extremely important contributions to the theory of wavelets, but due to a conflict of interest (as per ")#link("http://www.abelprisen.no/binfil/download.php?tid=69605")[#text("the guidelines for the prize committee")]#text(") arising from Daubechies’ presidency of the International Mathematical Union (which ")#link("http://www.mathunion.org/general/prizes")[#text("nominates")]#text(" ")#link("http://www.abelprisen.no/binfil/download.php?tid=69605")[#text("the majority of")]#text(" the members of the ")#link("http://www.abelprize.no/c53678/artikkel/vis.html?tid=53708")[#text("Abel prize committee")]#text(", who then serve for two years) from 2011 to 2014 (and ")#link("http://www.mathunion.org/organization/ec/ec-2015-2018/")[#text("her continuing service ")#emph[#text("ex officio")]#text(" on the IMU executive committee")]#text(" from 2015 to 2018), she will not be eligible for the prize until 2021 at the earliest, and so I do not think this prize should be necessarily construed as a judgement on the relative contributions of Meyer and Daubechies to this field. (In any case I fully agree with the Abel prize committee’s citation of Meyer’s pivotal role in the development of the theory of wavelets.)")

#emph[#text("[Update, Mar 28: link to prize committee guidelines and clarification of the extent of Daubechies’ conflict of interest added. -T]")]

#heading(level: 1)[#text("Comments (39)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikhail Katz")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479251")[#strong[#text("Mikhail Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2017")])]

#text("There is a problematic double negation in the last sentence before the parenthetical remark. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479254")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2017")])]

#text("Considering the efficient representation of irregular signals by wavelets methods, is it possible to extend the Fourier analytic methods in analytic number theory (applied to irregular sequences such as the primes) to some (perhaps more efficient) “wavelets analytic” methods ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d15e4d6ee106b2f62d77f2d81cef7ac04701c7a2d558b7c802fe5cea3e82073a-253df07dd421747028c33c5d047973674e18c26556202603a19326aeb2bac817.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matilde Marcolli")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479263")[#strong[#text("Matilde Marcolli")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2017")])]

#text("if really Daubechies was not eligible this year due to a conflict with the IMU presidency, then assigning a prize that recognizes the very important topic of wavelets could have easily waited until a time when it could have been shared between Mayer (who certainly deserves the recognition for his major contributions) and Daubechies who is after all the most prominent figure in the field. This decision sends a very clear and loud message to the mathematical community that even when a woman is the most visible and prominent figure in a certain field of mathematics and that field is singled out for a major recognition the prize will inevitably go to the next available dude. With all due respect to Mayer, whose work I greatly admire, and whose books I loved to read, and who certainly deserved to be given a prominent recognition, I think the decision to go ahead with a prize in this field at a time when Daubechies would not be eligible casts a very dark shadow on the mathematical community as a whole.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Séguin")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479269")[#strong[#text("Richard Séguin")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2017")])]

#text("When I first heard of the prize being awarded to Meyer for this, I recalled that years ago when I became aware of wavelets, it was a woman’s name that was prominent. So, I was a little surprised by Meyer, who I did not recognize at all, and I wondered if my memory was faulty, or if some injustice could have taken place. Thanks to Tao for recalling Daubechies’ name for me, which did look familiar when I saw it. I’m definitely not an expert in this area though, so I’m not going to comment on who did what.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479280")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2017")])]

#text("Agreed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479283")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2017")])]

#text("Actually this is not the first time this particular conflict of interest has arisen: the ")#link("https://en.wikipedia.org/wiki/Carl_Friedrich_Gauss_Prize")[#text("2010 Gauss prize")]#text(" was also awarded by the IMU (and the German Mathematical Society) to Meyer, and I believe Daubechies (then incoming president of the IMU) may also have been ineligible for that prize at that time. (On the other hand, the ")#link("https://en.wikipedia.org/wiki/Nemmers_Prize_in_Mathematics")[#text("2012 Nemmers prize")]#text(", whose list of previous awardees include two Abel laureates and three Fields Medalists, and for which the IMU plays no institutional role, was awarded to Daubechies rather than Meyer. I should disclose that I was on the committee for that particular award.) I do know that the Norwegian Academy of Sciences and Letters (which administers the Abel prize) takes its conflict of interest rules rather seriously; for instance all recent prize committee members (including myself) will be ineligible for the prize for a certain period of time (until five years after the end of committee service, if I recall correctly). I do not know the precise time restriction however for the president and other executive committee members of the IMU. [Daubechies actually also herself served on the Abel prize committee from ")#link("http://www.abelprize.no/c53678/artikkel/vis.html?tid=56485")[#text("2004")]#text(" to ")#link("http://www.abelprize.no/c53678/artikkel/vis.html?tid=56488")[#text("2006")]#text(", though I think this was long enough ago that the conflict of interest rules are not triggered by that fact.]")

#text("Without having access to the (confidential) discussions of the committee and the many (also confidential) letters of recommendation of the nominees that they solicit, one cannot say for certain how the committee arrived at their final decision, though I am sure the possibility of not awarding a prize in the area of applied mathematics this year was discussed extensively. (But, as the committee rotates its non-chair members every two years, and the chair every four years, with each committee starting afresh without specific instruction from previous committees, it is not clear how soon the committee would return to serious consideration of applied mathematics, especially given how the overwhelming majority of Abel prizes have been awarded primarily for work in pure mathematics, and the fields of mathematics to concentrate attention on are not determined ahead of time.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/be64ac943810387c5ef3cac1312eb53c4f4e1e6dd1e0ecbe4e31e1044ddc4cbc-b27b5c2e3ffc9bbca0ab9ec3368c79b649de69e0dbd0649969a8d26e1207d31e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Norman Shenkhopf")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479328")[#strong[#text("Norman Shenkhopf")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2017")])]

#text("Being the most visible and prominent is not the same as being the most mathematically influential. Also, wavelets are not part of your area of expertise, so it is inappropriate for you to make such a serious accusation here. It is possible that Yves Meyer is considered to be the best choice for the award by the people working in the field, without regard to gender.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5416bb4b7b2da1137c74aa5ef543c80d38873c40e1c2af9672c3b44808dbb7f2-3e3cb609823b8808ced51ea97b7e8553362a942b58112d843e196e06861130e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479511")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2017")])]

#text("“Also, wavelets are not part of your area of expertise, so it is inappropriate for you to make such a serious accusation here.”")

#text("Let’s make the working assumption that wavelets are also not your area of expertise. Lets also make the assumption that Matilde is a far more qualified mathematician than you are. Until you reveal yourself we will have no way to know. Your first sentence is a platitude not an argument, the second sentence an appeal to authority and the third a vague hypothesis. Is this what you count as effectual argumentation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac12bdb701952daa6c8af0b4522175200a7fa8bb644ef4b18260e8637530a761-34c0132da311683969929b458c37d1fcc1f8642a9414a80912a208850415f3ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479515")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2017")])]

#text("This is an ode to nonsense. He doesn’t need to prove anything, the one making the ridiculous accusation does. There is a person who makes preposterous assumptions and “derives” some pretty unbelievable conclusions. If anything women are favored nowadays over men, if you were a mathematician you would know, if you had ever been part of a committee deciding an award or a hire you would know. It may just be that the person has to defend himself(or herself) in anonymity precisely because of the very real possibility of retaliation for not supporting gender equality. In fact, I could also make the case that many people complaining may be occupying a position for which a male was more qualified, it is just that they don’t have a problem with that. Awards are political, so injustice is not new, and women are not the most neglected group either. Grow up.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479385")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2017")])]

#text("I applaud your courage to say this with your own name, Matilde Marcolli. I disagree about this “dark shadow”. Actually, I’ve seen that male professors encourage women students/mathematicians more than they encourage male students. They really cheer for their success. This is my personal experience. There are few women who want to devote their lifes to mathematics, like the male Andrew Wiles did. Women are more in need of social links, they have children, their preferences for life are different from that of men. This is my experience. There are extremely bright women, just like there are that many men who won the Abel Prize, but I’ve seen that they are not so competitive as men, they want other things than to become famous in mathematics, so they don’t devote as much time as the men who are addicted to mathematics (this is my personal experience). Women are much less vulnerable to addiction to certain things. This is true for video-games, chess, and mathematics.")

#text("IMO, the prize should have been awarded to BOTH Yves Meyer and Ingrid Daubechies. There is still time to fix this, if people make a public petition, and show that there is no conflict of interest, that the community of mathematicians really consider Daubechies worth of the Abel Prize. Another solution is she should be nominated to the Wolf Prize, which is as prestigious as the Fields or the Abel.")

#text("Cheers from a sincere Brazilian student who is too coward to show his name when opining about topics such as feminism (in fear of retaliation).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d15e4d6ee106b2f62d77f2d81cef7ac04701c7a2d558b7c802fe5cea3e82073a-253df07dd421747028c33c5d047973674e18c26556202603a19326aeb2bac817.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479433")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2017")])]

#text("Dear Anonymous, the idea that “there are few women who want to devote their lives to mathematics” is a completely delusional belief, which is a very convenient excuse to avoid addressing the widespread culture of violence and bullying that is rampant within the mathematical community.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479465")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2017")])]

#text("Look. I am a man and I agree with the reinvindications (I don’t know the word in English, it’s not my native language you know…) of feminism: for the establishment of equal pay, equal opportunities, no harassment, etc. The problem in that we men see in University Campuses the “radical feminism” or “feminazi”, they keep saying that all men are evil, that we are “ambulant penises”, etc. The nice boy finally creates courage to give a flower to the girl, she in return throws it to the garbage or spit in his face… And then you don’t know why guys like Trump become president… Here in Brazil we have our local Trump, it’s called “Bolsonaro”, and he says things that come close to misogynism, etc… And there is a VERY HIGH chance that this crazy man will become president of Brazil… Look, I dislike Trump, but two things he has: courage and persistence, and this inspires respect in men, even with all his faults. Men are tired of this politically correct fake speeches. There is not freedom of speech anymore. Radical feminists want to fix men with a hammer and instead of talking without overflue of emotions, they make all type of retaliations for those who say what the think. You MAY be right about this “culture of violence and bullying that is rampant within the mathematical community.”, I don’t know, I’m not a woman, and every time I asked them about this they said things that men can’t possible understand how they feel, etc… All the best for you. And I really do want that a woman wins the Abel someday. I like woman, they are in general less prone to physical violence (except feminazis), they are more altruistic, and they are beautiful. Men and women are not the same, and this is good and makes the world better. Please orient the feminazi to stop with this unbearable living hell they are making for men, calling them the source of all evil of this world. And long live for free speech (and thank to our blog hoster for allowing anonymous comments). And long live to the good feminism, of nice and intelligent girls, that argue instead of threatening and ruining the careers of those who say what they think (I’m not talking about you, I think that you are nice person). By the way, I’ve made the test, and most women have heard of some male geniuses, but no one told them about the geniuses Emmy Noether, Marie Curie, and many more, that are there to prove that women can do whatever they want in the sciences and arts, natural or formal, etc… Cheers. All the best. Math is beautiful. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous7")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479514")[#strong[#text("Anonymous7")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2017")])]

#text("What “violence” within the mathematical community is being referred to here? I haven’t heard of any cases of violence within the mathematical community.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479264")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2017")])]

#text("Very good choice.")

#text("For the next year I bet on Stephen Smale.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70d68edaf1b08f310886b89f27f77459c80d00e7e66f95d1d949724f6aed20f4-169737cd43f66f0dc8e17d4cc5f25a93edc6616f77e278f9a1f0943afd7ac9ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul D.")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479282")[#strong[#text("Paul D.")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2017")])]

#text("Following one of those links back, I noticed you have that post with “Daniel Spielman” as a tag, and another (the Kadison-Singer one) with “Dan Spielman” as a tag.")

#emph[#text("[Tags synchronized, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a55fa8399e2269a45e253365ac44408318dd04ed5a4d64504443e3b3824a23f0-085a229ea07122a195cbf76167de16cb175aba6c0e2bb968cbd28145c1db93c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thegregmartin")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479285")[#strong[#text("thegregmartin")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2017")])]

#text("I agree with you, Matilde, 100%. There is ample equity research* that shows that institutions (prize committees, for example, or our own departments’ hiring committees) are more likely to cite the need to stick to the rules when the candidate is a woman or a visible minority, but more likely to spend energy on making an exception happen when the candidate is (white and) male. I have no doubt that Meyer and the other Abel Prize winners have done great mathematics. However, we should consider the Abel Prize to currently be a prize for the best male mathematician, since it has never been awarded to anyone but.")

#text("* See for example “The Equity Myth”, a book coming out in a couple of months from UBC press; or my “Annotated Bibliography …” on underrepresentation in mathematics, which can be found on my web site.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479303")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2017")])]

#text("Technically, the Abel prize committee ")#link("http://www.abelprize.no/c53675/artikkel/vis.html?tid=53706")[#text("does not have the final say")]#text(" on the choice of laureate: it merely sends a recommendation to the Norwegian Academy of Science and Letters, who is responsible for the final decision. As far as I know, the Academy has always followed the committee in the past, but if the committee decided to make an exception to the rules and nominate someone who violated the Academy’s conflict of interest policies (which, by the way, are almost the first thing presented to the committee by an Academy representative when they convene), I think at the very least they would summon the committee back to explain their decision thoroughly. Even if the non-eligible candidate managed to, say, prove the Riemann hypothesis in a manner widely accepted by experts and published in a top journal, I think at best the Academy, in order to retain its rules, would approve some ")#emph[#text("ad hoc")]#text(" alternate recognition, similar to the silver plaque bestowed by the IMU on Andrew Wiles for his proof of Fermat’s Last Theorem, while being technically ineligible for the Fields Medal (despite being both white and male). But in this particular case I think the optics of bestowing a “consolation” Abel prize to Daubechies and the “real” Abel prize to Meyer would be even worse than any of the other options (and would probably be rather insulting to Ingrid personally).")

#text("Also, though it is hardly of relevance, Meyer, while male, was actually born in Tunisia. (Technically, this makes him the first Abel laureate to originate from the African continent.)")

#text("At the end of the day, the prize has to be awarded to a mathematician who actually exists, rather than an idealised mathematician obeying a large set of desirable criteria. If this year there was a female Tunisian applied logician who proved the Riemann hypothesis and violated none of the eligibility requirements for the prize, I am sure she would have received the award. But I believe no such mathematician was nominated.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f2ecd81e01f75b4f21e6512316c1b40c14dc258cdb2bf62636fad967d9dfd87-4a45087ab52424ab9855f8ec61fdf6a34f5a45292f622779896855a2c9eb8f33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hugecardnal")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479306")[#strong[#text("hugecardnal")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2017")])]

#text("” If this year there was a female Tunisian applied logician who proved the Riemann hypothesis and violated none of the eligibility requirements for the prize, I am sure she would have received the award. But I believe no such mathematician was nominated.”")

#text("The only problem with this argument is that Meyer (who is definitely an impressive mathematician) didn’t prove the Riemann hypothesis. In other words, he is not an obvious choice for the prize (of course, it doesn’t mean that he doesn’t deserve the prize).")#linebreak()#text(" As there are obvious choices for the prize among logicians (i.e. Shelah) and among female mathematicians (i.e. Daubechies), giving the prize to the less obvious choice requires further explanation and justification.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d15e4d6ee106b2f62d77f2d81cef7ac04701c7a2d558b7c802fe5cea3e82073a-253df07dd421747028c33c5d047973674e18c26556202603a19326aeb2bac817.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matilde Marcolli")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479434")[#strong[#text("Matilde Marcolli")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2017")])]

#text("If in 2004 either Atiyah or Singer had been president of the IMU hence ineligible for the Abel prize, would the Abel Committee have forged ahead with a prize awarded for the Index Theorem and given to only the other one of them? No, we all know they would not have done that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/269b9c9ed56c2e9753143d00db2f65811c076538e60c08952599e9756fdad125-55c235cfca6151c6ce936aeba089db3d0ebacb890448ec18833f03c12d0abd3a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Norman Shenkhopf")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479443")[#strong[#text("Norman Shenkhopf")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2017")])]

#text("The two situations aren’t comparable, since Atiyah and Singer’s results were joint work, while the same is not true for Meyer and Daubechies.")

#text("Even their work was joint, there are precedents for giving just one person a major award based on a technicality. Recall that Werner won a Fields Medal for joint work, and many people think that Schramm was prevented from winning the Fields Medal simply because he was just over the age limit.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479516")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2017")])]

#text("Schramm was 3 weeks too old to be considered for the Fields medal in 2002 (40 year old rule was made official not that long ago), while Werner won in 2006, so there were 4 years in between to carefully consider this situation.")

#text("Exports in the fields that I talked to consider Meyer’s contribution to be more impressive overall than that of Daubechies. Ironically, the reason Daubechies is a much bigger celebrity has something to do with the fact that she is a woman. On the other hand, everyone knows how wonderful a person Daubechies is, and it is very probable that she had a lot to do with Meyer winning this prize.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479287")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2017")])]

#text("I totally agree the choice of Pro.Tao as well as Abel committee.There are two things that Meyer better than Daubechies.They are very simple:you do not need much time to think or headache.Meyer is older than her(he is nearly 80;he is coming to go to the another world)and second reson that he is the pioneer in wave field.If considering of quanity and quality of work as well as speed of doing maths .I find all people have got Abel prize(from 2003 to now) no one can compare to Pro.Tao.But Pro.Tao can not receive Abel prize;because he is very young")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f2ecd81e01f75b4f21e6512316c1b40c14dc258cdb2bf62636fad967d9dfd87-4a45087ab52424ab9855f8ec61fdf6a34f5a45292f622779896855a2c9eb8f33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hugecardinal")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479290")[#strong[#text("hugecardinal")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2017")])]

#text("And as always, no logician won the prize (surprise, surprise). :-/")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/292fda6ac9459d7a8a4f7c490b82e4f418c3e8246ce244e9010a98ec719adb88-b4db950f7c928805652bb80e9093dc555947b783c037f0b278f06a383eae08e9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lol.")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479294")[#strong[#text("lol.")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2017")])]

#text("what on earth are we talking here. The man who runs the free world has been chosen by the American people in spite of conflict of interest. Here we are talking of an one time opportunity to put a lady on same pedestal as a man. May be prez Trump should have decided this one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/292fda6ac9459d7a8a4f7c490b82e4f418c3e8246ce244e9010a98ec719adb88-b4db950f7c928805652bb80e9093dc555947b783c037f0b278f06a383eae08e9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lol.")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479304")[#strong[#text("lol.")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2017")])]

#text("was only joking here… but may be a joint prize could have mollified issues? A prize has at least two intended beneficiaries – to the individual and to the community typically the individual is associated with. In light of the latter I think it is rather silly to have left out Daubechies.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479359")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2017")])]

#text("Some Europeans I spoke with a couple nights ago told me from their viewpoint, the current leader of the free world is a woman (Merkel).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e447122d170966968624a61fcb8ca45cd719f679c78087ff270d220475404740-8c974e3466e458e540ddcd57d1a62fc7244ba244cf3cc62d09870c1efaef0de0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479295")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2017")])]

#link("https://www.theguardian.com/science/alexs-adventures-in-numberland/2017/mar/21/abel-prize-2017-yves-meyer-wins-maths-nobel-for-work-on-wavelets")[#text("https://www.theguardian.com/science/alexs-adventures-in-numberland/2017/mar/21/abel-prize-2017-yves-meyer-wins-maths-nobel-for-work-on-wavelets")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479316")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2017")])]

#text("Just a question: is there any chance Eli Stein might be recognized by the Abel committee? — A (possibly biased) harmonic analyst…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479317")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2017")])]

#text("In your interview with Meyer, he mentions the work of Grossmann as the first work on wavelets. Does this means that the physicists discovered wavelets before mathematicians? Was their idea the real breakthrough in terms of ideas by comparison with what Meyer did afterwards? If you are familiar with this, can you elaborate on this part of the interview? Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479637")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2017")])]

#text("I can recommend Daubechies’ history of the subject at ")#link("http://perso.ens-lyon.fr/paulo.goncalves/pub/WaveletsHistoryByDaubechies.pdf")[#text("http://perso.ens-lyon.fr/paulo.goncalves/pub/WaveletsHistoryByDaubechies.pdf")]#text(" . My understanding is that while individual examples of wavelets (or wavelet-like) objects had been discovered and used in various disciplines in both pure and applied mathematics and in the sciences, it was only with the work of Meyer (and coauthors like Mallat) that they were all unified under a systematic framework that enabled one to readily construct “customised” wavelets that were tailored to a given application. The original wavelets used by Morlet and Grossman were a continuous family rather than a discrete orthonormal one, which made the task of accurately computing the wavelet transform and its inverse to be rather slow numerically; with the multiresolution analysis framework of Meyer and Mallat one could start to build wavelets that had a number of desirable properties such as discreteness, regularity, vanishing moments, and good localisation. For instance, Daubechies famously used this framework to construct compactly supported wavelets with an optimal number of vanishing moments, which led to particularly fast convergence rates in the wavelet series.")

#text("I think Meyer was also instrumental in promoting (and supporting through theoretical results) the basic insight that many functions and operators that occurred in either pure mathematics or in applications had a sparse or compressible wavelet representation. By the time I was exposed to the subject in the mid-90s, this had become the conventional wisdom, but I think it was not as self-evident in the early days of wavelet theory. But it is absolutely essential in many subsequent applications of wavelets (e.g. compressed sensing on the applied side, or in theoretical results such as the ")#mi("T(1)")#text(" or ")#mi("T(b)")#text(" theorems in harmonic analysis).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b9d58379ee2917a78e1424a8ceec49900ed7c209a658e343d687ffa76ae5e59-5dc336638d75c706ca7c0131f7c252f05d11ed42bc47dc437d544ac5bd8d6865.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jan-Olov Strömberg")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479435")[#strong[#text("Jan-Olov Strömberg")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2017")])]

#text("It might be appropriate to mention that a construction of a smooth wavelets with exponential decay was presented by already 1981, by Jan-Olov Strömberg, at the Conference on Harmonic Analysis in Honor of A. Zygmund. This presentation was submitted, the same year, to the Conference Proceedings, which appeared 1983. Y. Meyer , who participated at the same conference, was by that time involved in solving a problem in Harmonic Analysis estimating the Calderon-Zygmund operator on domains with Lipschitz boundaries. By that time, he did not – nor did anybody else – make the connection that")#linebreak()#text(" wavelets (this name given later) could be used as a tool to simplify the solution of this Calder-Zygmund problem.")#linebreak()#text(" When Y. Meyer a few years later rediscovered the wavelets, with their properties, he did an excellent work to make a general theory about wavelets and their properties in a large mathematical context .")#linebreak()#text(" At the time of Zygmund conference, Strömberg was Teaching Assistant at Princeton University /")#linebreak()#text(" Research Assistant at Stockholm University and later at the time of publication, Professor at the University of Tromsø, Norway (1982-1998) and after that Professor at the Royal Institute of Technology (KTH) at Stockholm, Sweden.")#linebreak()#text(" See also Wikipedia: Strömberg wavelet")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479524")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2017")])]

#text("If there is preference for women,I do not need mention.Daubechies is worth.But,if saying about equality,Daubechies is not worthing,for her age and she does not still have Wolf prize.Look at the list of people having Abel prize,before they had Wolf prize,and also they do not still have Wolf prize,their age is above 70.If Abel committee violates law,this year Daubechies win.I have also right voting Terry Tao next year ,he win Abel prize.But,I know that he will decline.Maybe his whole work(300 works) not worth to win!!!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479568")[#strong[#text("Yves Meyer logra el Premio Abel 2017 | Ciencia | La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2017")]

#text("[…] El anuncio oficial, la nota de prensa y la documentación detallada. Por cierto, presentar0n su trabajo en Oslo el genial Terry Tao, “The work of Yves Meyer,” PDF, y Arne B. Sletsjøe, “If it were true, it would be known,” PDF, y “Orthogonal function systems,” PDF. También recomiendo Terry Tao, “Yves Meyer wins the 2017 Abel Prize,” What’s New, 22 Mar 2017. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7493d310c35a30265f2b63241b2307e66190037d80a632c5f7747e493a74fdca-a44cd6e00f7de599619b420ff2317c77ed6b6362fce41c5e08c0bb1a4e791e8c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Haddil")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479633")[#strong[#text("Daniel Haddil")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2017")])]

#text("I don’t think it is acceptable to make accusations of sexism without the shadow of a proof. What would Ms. Marcolli say if somebody accused her of being enraged at Meyer’s Abel Prize because, despite her hypocritical compliments for his work, she actually hates Jews? And added that the presence of such racists casts a very dark shadow on the mathematical community at Caltech?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf439e996e29d20cb552d68ffe9f964d8919f4f9773b9c41c886fb326a5a9695-66573747b7b50dc2532a1c1acd7e23c9482f9aeb4a00f437399c08ade2278ee3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aquazorcarson")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479856")[#strong[#text("aquazorcarson")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2017")])]

#text("How did your comment get exactly 54 up votes and 54 down votes? Did every voter just click on both?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479857")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2017")])]

#text("It seems to be a kind of “race” between opposing sides.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf439e996e29d20cb552d68ffe9f964d8919f4f9773b9c41c886fb326a5a9695-66573747b7b50dc2532a1c1acd7e23c9482f9aeb4a00f437399c08ade2278ee3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aquazorcarson")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479865")[#strong[#text("aquazorcarson")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2017")])]

#text("Interesting game theoretic equilibrium. Reminds me of electronics prices on amazon.com and walmart.com.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479932")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2017")])]

#text("I think there is prejudice on both sides. I believe many women now occupy positions in prominent universities because they are women. In the name of “diversity” some women are hired even when they are less accomplished than men. This is specially true in America and american universities where the call for EEO (equal employment opportunity) is sometimes seen as “we need to show we hire women”")

#text("It is also interesting to note that Matilda writes a lot in her website/articles about how she has had so many frustrating mathematical experiences. How she was singled out and expelled from MIT’s math department, then she was rejected by a few other mathematical groups. Her writing about her own experience is in the same tone of the post that she wrote above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5dd54b2b2a36b0efa3be83c8fcf33c14f12dd4dcf8cbb6c1ef062c7af18ed41-be0a31a4129efdeb6183b9059935e199258a543208378954f353dd430c95e248.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jorge Losada")]], [#link("https://terrytao.wordpress.com/2017/03/22/yves-meyer-wins-the-2017-abel-prize/#comment-479979")[#strong[#text("Jorge Losada")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2017")])]

#text("Dear Prof. Tao, thanks for your excellent work and for sharing with us such information. I am particularly interested in the link about the work of Yves Meyer.")

#text("In usual calculus, exponential function plays a central role and this is due to (I believe) it links in a really beautiful way sums and (usual) products.")

#text("I have tried reading the suggested book “Tools for PDE” by M.E. Taylor, but I found it really hard for me. So, what can we say about functions with similar properties than exponential function considering paraproducts instead of usual products?")

#text("Please, if someone has any idea I would really appreciate her (or his) help. Thanks!! I have some conjectures…")

#text("You can find my e-mail on this website")#linebreak()#text(" ")#link("http://www.usc.es/es/centros/matematicas/profesor.html?Num_Puesto=16662&Num_Persona=198874&ano=66")[#text("http://www.usc.es/es/centros/matematicas/profesor.html?Num_Puesto=16662&Num_Persona=198874&ano=66")]

#text("I have tried reading the suggested book “Tools for PDE” but I found it really hard for me.")
]
