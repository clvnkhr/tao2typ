// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/
// Converted to Typst by tao2typ: "2026-10-14T15:20:51.297726+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Special relativity and Middle-Earth", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Special relativity and Middle-Earth")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 December 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/")[#text("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This post is an unofficial sequel to one of my first blog posts from 2007, which was entitled “")#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/")[#text("Quantum mechanics and Tomb Raider")]#text("“.")

#text("One of the oldest and most famous allegories is ")#text("Plato’s allegory of the cave")#text(". This allegory centers around a group of people chained to a wall in a cave that cannot see themselves or each other, but only the two-dimensional shadows of themselves cast on the wall in front of them by some light source they cannot directly see. Because of this, they identify reality with this two-dimensional representation, and have significant conceptual difficulties in trying to view themselves (or the world as a whole) as three-dimensional, until they are freed from the cave and able to venture into the sunlight.")

#text("There is a similar conceptual difficulty when trying to understand ")#link("https://en.wikipedia.org/wiki/Special_relativity")[#text("Einstein’s theory of special relativity")]#text(" (and more so for ")#link("https://en.wikipedia.org/wiki/General_relativity")[#text("general relativity")]#text(", but let us focus on special relativity for now). We are very much accustomed to thinking of reality as a three-dimensional space endowed with a Euclidean geometry that we traverse through in time, but in order to have the clearest view of the universe of special relativity it is better to think of reality instead as a four-dimensional ")#link("https://en.wikipedia.org/wiki/Spacetime")[#text("spacetime")]#text(" that is endowed instead with a ")#link("https://en.wikipedia.org/wiki/Minkowski_space")[#text("Minkowski geometry")]#text(", which mathematically is similar to a (four-dimensional) Euclidean space but with a crucial change of sign in the underlying metric. Indeed, whereas the distance ")#mi("{ds}")#text(" between two points in Euclidean space ")#mi("{{\\bf R}^3}")#text(" is given by the three-dimensional Pythagorean theorem")

#align(center)[#tao-fit-display[#mitex("ds^2 = dx^2 + dy^2 + dz^2")]]

#text("under some standard Cartesian coordinate system ")#mi("{(x,y,z)}")#text(" of that space, and the distance ")#mi("{ds}")#text(" in a four-dimensional Euclidean space ")#mi("{{\\bf R}^4}")#text(" would be similarly given by")

#align(center)[#tao-fit-display[#mitex("ds^2 = dx^2 + dy^2 + dz^2 + du^2")]]

#text("under a standard four-dimensional Cartesian coordinate system ")#mi("{(x,y,z,u)}")#text(", the ")#link("https://en.wikipedia.org/wiki/Spacetime")[#text("spacetime interval")]#text(" ")#mi("{ds}")#text(" in Minkowski space is given by")

#align(center)[#tao-fit-display[#mitex("ds^2 = dx^2 + dy^2 + dz^2 - c^2 dt^2")]]

#text("(though in many texts the opposite sign convention ")#mi("{ds^2 = -dx^2 -dy^2 - dz^2 + c^2dt^2}")#text(" is preferred) in spacetime coordinates ")#mi("{(x,y,z,t)}")#text(", where ")#mi("{c}")#text(" is the speed of light. The geometry of Minkowski space is then quite similar algebraically to the geometry of Euclidean space (with the sign change replacing the traditional trigonometric functions ")#mi("{\\sin, \\cos, \\tan}")#text(", etc. by their hyperbolic counterparts ")#mi("{\\sinh, \\cosh, \\tanh}")#text(", and with various factors involving “")#mi("{c}")#text("” inserted in the formulae), but also has some qualitative differences to Euclidean space, most notably a causality structure connected to light cones that has no obvious counterpart in Euclidean space.")

#text("That said, the analogy between Minkowski space and four-dimensional Euclidean space is strong enough that it serves as a useful conceptual aid when first learning special relativity; for instance the excellent introductory text “")#link("https://www.eftaylor.com/spacetimephysics/")[#text("Spacetime physics")]#text("” by Taylor and Wheeler very much adopts this view. On the other hand, this analogy doesn’t directly address the conceptual problem mentioned earlier of viewing reality as a four-dimensional spacetime in the first place, rather than as a three-dimensional space that objects move around in as time progresses. Of course, part of the issue is that we aren’t good at directly visualizing four dimensions in the first place. This latter problem can at least be easily addressed by removing one or two spatial dimensions from this framework – and indeed many relativity texts start with the simplified setting of only having one spatial dimension, so that spacetime becomes two-dimensional and can be depicted with relative ease by ")#link("https://en.wikipedia.org/wiki/Spacetime_diagram")[#text("spacetime diagrams")]#text(" – but still there is conceptual resistance to the idea of treating time as another spatial dimension, since we clearly cannot “move around” in time as freely as we can in space, nor do we seem able to easily “rotate” between the spatial and temporal axes, the way that we can between the three coordinate axes of Euclidean space.")

#text("With this in mind, I thought it might be worth attempting a Plato-type allegory to reconcile the spatial and spacetime views of reality, in a way that can be used to describe (analogues of) some of the less intuitive features of relativity, such as ")#link("https://en.wikipedia.org/wiki/Time_dilation")[#text("time dilation")]#text(", ")#link("https://en.wikipedia.org/wiki/Length_contraction")[#text("length contraction")]#text(", and the ")#link("https://en.wikipedia.org/wiki/Relativity_of_simultaneity")[#text("relativity of simultaneity")]#text(". I have (somewhat whimsically) decided to place this allegory in a Tolkienesque fantasy world (similarly to how ")#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/")[#text("my previous allegory to describe quantum mechanics")]#text(" was phrased in a world based on the computer game “Tomb Raider”). This is something of an experiment, and (like any other analogy) the allegory will not be able to perfectly capture every aspect of the phenomenon it is trying to represent, so any feedback to improve the allegory would be appreciated.")

#metadata(none) <tao-eaa372e52465afd3f1f0>

#heading(level: 1)[#strong[#text(" — 1. Treefolk — ")]]

#text("Tolkien’s ")#link("https://en.wikipedia.org/wiki/Middle-earth")[#text("Middle-Earth")]#text(" contains, in addition to humans, many fantastical creatures. Tolkien’s book “")#link("https://en.wikipedia.org/wiki/The_Hobbit")[#text("The Hobbit")]#text("” introduces the ")#link("https://en.wikipedia.org/wiki/Trolls_in_Middle-earth")[#text("trolls")]#text(", who can move around freely at night but become petrified into stone during the day; and his book “")#link("https://en.wikipedia.org/wiki/The_Two_Towers")[#text("The Two Towers")]#text("” (the second of his three-volume work “")#link("https://en.wikipedia.org/wiki/The_Lord_of_the_Rings")[#text("The Lord of the Rings")]#text("“) introduces the ")#link("https://en.wikipedia.org/wiki/Ent")[#text("Ents")]#text(", who are large walking sentient tree-like creatures.")

#text("In this Tolkienesque fantasy world of our allegory (readers, by the way, are welcome to suggest a name for this world), there are two intelligent species. On the one hand one has the humans, who can move around during the day much as humans in our world do, but must sleep at night without exception (one can invent whatever reason one likes for this, but it is not relevant to the rest of the allegory). On the other hand, inspired by the trolls and Ents of Tolkien, in this world we will have the ")#emph[#text("treefolk")]#text(", who in this world are intelligent creatures resembling a tree trunk (possibly with some additional branches or additional appendages, but these will not play a central role in the allegory). They are rooted to a fixed location in space, but during the night they have some limited ability to (slowly) twist their trunk around. On the other hand, during the day, they turn into non-sentient stone columns, frozen in whatever shape they last twisted themselves into. Thus the humans never see the treefolk during their active period, and vice versa; but we will assume that they are still somehow able to communicate asynchronously with each other through a common written language (more on this later).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" In Middle-Earth there are also the ")#emph[#text("Huorns")]#text(", who are briefly mentioned in “The Two Towers” as intelligent trees kin to the Ents, but are not described in much detail. Being something of a blank slate, these would have been a convenient name to give these fantasy creatures; however, given that the works of Tolkien will not be public domain for a few more decades, I’ll refrain from using the Huorns explicitly, and instead use the more generic term “treefolk”.")
]

#text("When a treefolk makes its trunk vertical (or at least straight), it is roughly cylindrical in shape, and has horizontal “rings” on its exterior at intervals of precisely one inch apart; so for instance one can easily calculate the height of a treefolk in inches by counting how many rings it has. One could think of a treefolk’s trunk geometrically as a sequence of horizontal disks stacked on top of each other, with each disk being an inch in height and basically of constant radius horizontally, and separated by the aforementioned rings. Because my artistic abilities are close to non-existent, I will draw a treefolk schematically (and two-dimensionally), as a vertical rectangle, with the rings drawn as horizontal lines (and the disks being the thin horizontal rectangles between the rings):")

#image("../assets/c3e75095d316d497b5d677abac143ac26b66e6398f20402ff4778d3737601ff9-b05b05eac3b9e53b4f51b568c592afcc6524ebbb23bcf29642d82b3318ffeda7.png", width: 90%)

#text("But treefolks can tilt their trunk at an angle; for instance, if a treefolk tilts its trunk to be at a 30 degree angle from the vertical, then now the top of each ring is only ")#mi("{\\cos 30^\\circ = \\frac{\\sqrt{3}}{2} \\approx 0.866}")#text(" inches higher than the top of the preceding ring, rather than a full inch higher, though it is also displaced in space by a distance of ")#mi("{\\sin 30^\\circ = \\frac{1}{2}}")#text(" inches, all in accordance with the laws of trigonometry. It is also possible for treefolks to (slowly) twist their trunk into more crooked shapes, for instance in the picture below the treefolk has its trunk vertical in its bottom half, but at a ")#mi("{30^\\circ}")#text(" angle in its top half. (This will necessarily cause some compression or stretching of the rings at the turnaround point, so that those rings might no longer be exactly one inch apart; we will ignore this issue as we will only be analyzing the treefolk’s rings at “inertial” locations where the trunk is locally straight and it is possible for the rings to stay perfectly “rigid”. Curvature of the trunk in this allegory is the analogue of acceleration in our spacetime universe.)")

#image("../assets/552f36ef6b24da5d6512fcde73f428283562df358c9f11379611a7e2736dd1bf-485ab0d032d0a6dcfd9e12a70f3661cc3e80d5ebaa4ee9b84fa4e9eaa706099a.png", width: 90%)

#text("treefolks prefer to stay very close to being vertical, and only tilt at significant deviations from the vertical in rare circumstances; it is only in recent years that they have started experimenting with more extreme angles of tilt. ")#strike[#text("Let us say that there is a hard limit of ")#mi("{45^\\circ}")#text(" as to how far a treefolk can tilt its trunk; thus for instance it is not possible for a treefolk to place its trunk at a 60 degree angle from the vertical. (This is analogous to how matter is not able to travel faster than the speed of light in our world.)")]#text(" ")#emph[#text("[Removed this hypothesis as being unnatural for the underlying Euclidean geometry – T.]")]

#text("Now we turn to the nature of the treefolk’s sentience, which is rather unusual. Namely – only one disk of the treefolk is conscious at any given time! As soon as the sun sets, a treefolk returns from stone to a living creature, and the lowest disk of that treefolk awakens and is able to sense its environment, as well as move the trunk above it. However, every minute, with the regularity of clockwork, the treefolk’s consciousness and memories transfer themselves to the next higher disk; the previous disk becomes petrifed into stone and no longer mobile or receiving sensory input (somewhat analogous to the rare human disease of ")#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/Fibrodysplasia ossificans progressiva")[#text("fibrodysplasia ossificans progressiva")]#text(", in which the body becomes increasingly ossified and unable to move). As the night progresses, the locus of the treefolk’s consciousness moves steadily upwards and more and more of the treefolk turns to stone, until it reaches the end of its trunk, at which point the treefolk turns completely into a stone column until the next night, at which point the process starts again. (In particular, no treefolk has ever been tall enough to retain its consciousness all the way to the next sunrise.) Treefolk are aware of this process, and in particular can count intervals of time by keeping track of how many times its consciousness has had to jump from one disk to the next; they use rings as a measure of time. For instance, if a treefolk experiences ten shifts of consciousness between one event and the next, the treefolk will know that ten minutes have elapsed between the two events; in their language, they would say that the second event occurred ten rings after the first.")

#text("The second unusual feature of the treefolk’s sentience is that at any given time, the treefolk can sense the portions of all nearby objects that are in the same plane as the disk, but not portions that are above or below this plane; in particular, some objects may be completely “invisible” to the treefolk if they are completely above or completely below the treefolk’s current plane of “vision”. Exactly how the treefolk senses its environment is not of central importance, but one could imagine either some sort of visual organ on each disk that is activated during the minute in which that disk is conscious, but which has a limited field of view (similar one that a knight might experience when wearing a helmet with only a narrow horizontal slit in their visor to see through), or perhaps some sort of horizontal echolocation ability. (Or, since we are in a fantasy setting, we can simply attribute this sensory ability to “magic”.) For instance, the picture below that (very crudely) depicts a treefolk standing vertically in an environment, fifty minutes after it first awakens, so that the disk that is fifty inches off the ground is currently sentient. The treefolk can sense any other object that is also fifty inches from the ground; for instance, it can “see” a slice of a bush to the left, and a slice of a boulder to the right, but cannot see the sign at all. (Let’s assume that this somewhat magical “vision” can penetrate through objects to some extent (much as “x-ray vision” would work in comic books), so it can get some idea for instance that the section of boulder it sees is somewhat wider than the slice of bush that it sees.) As the minutes pass and the treefolk’s consciousness moves to higher and higher rungs, the bush will fluctuate in size and then disappear from the treefolk’s point of “view”, and the boulder will also gradually shrink in size until disappearing several rings after the bush disappeared.")

#image("../assets/fc2463ab677c3d4187c62ec15ee1ecbc937780167d33008ebaeb958722ef4861-65f0860b0165c1bcd70912c4c3b1c2c24dedc067e8d5112d3d993dc207acbc6e.png", width: 90%)

#text("If the treefolk’s trunk is tilted at an angle, then its visual plane of view tilts similarly, and so the objects that it can see, and their relative positions and sizes, change somewhat. For instance, in the picture below, the bush, boulder, and sign remain in the same location, but the treefolk’s trunk has tilted; as such, it now senses a small slice of the sign (that will shortly disappear), and a (now smaller) slice of the boulder (that will grow for a couple rings before ultimately shrinking away to nothingness), but the bush has already vanished from view several rings previously.")

#image("../assets/1da5e07f39f2201c61f5114af95c5a94d7f84ee569547afab044755247a630c7-b36cbf89907eca4901d52cc759a1d2dbc2e851db45406251770ff27f9811c492.png", width: 90%)

#text("At any given time, the treefolk only senses a two-dimensional slice of its surroundings, much like how the prisoners in Plato’s cave only see the two-dimensional shadows on the cave wall. As such, treefolks do not view the world around them as three-dimensional; to them, it is a two-dimensional world that slowly changes once every ring even if the three-dimensional world is completely static, similarly to how flipping the pages of an otherwise static ")#link("https://en.wikipedia.org/wiki/Flip_book")[#text("flip book")]#text(" can give the illusion of movement. In particular, they do not have a concept in their language for “height”, but only for horizontal notions of spatial measurement, such as width; for instance, if a tall treefolk is next to a shorter treefolk that is 100 inches tall, with both treefolk vertical, it will think of that shorter treefolk as “living for 100 rings” rather than being 100 inches in height, since from the tall treefolk’s perspective, the shorter treefolk would be visible for 100 rings, and then disappear. These treefolk would also see that their rings line up: every time a ring passes for one treefolk, the portion of the other treefolk that is in view also advances by one ring. So treefolk, who usually stay close to vertical for most of their lives, have come to view rings as being universal measurements of time. They also do not view themselves as three-dimensional objects; somewhat like the characters in Edwin Abbott classic book “")#link("https://en.wikipedia.org/wiki/Flatland")[#text("Flatland")]#text("“, they think of themselves as two-dimensional disks, with each ring slightly changing the nature of that disk, much as humans feel their bodies changing slightly with each birthday. While they can twist the portion of their trunk above their currently conscious disk at various angles, they do not think of this twisting in three-dimensional terms; they think of it as willing their two-dimensional disk-shaped self into motion in a horizontal direction of their choosing.")

#text("Treefolk cannot communicate directly with other treefolk (and in particular one treefolk is not aware of which ring of another treefolk is currently conscious); but they can modify the appearance of their exterior on their currently conscious ring (or on rings above that ring, but not on the petrified rings below) for other treefolk to read. Two treefolks standing vertically side by side will then be able to communicate with each other by a kind of transient text messaging system, since they awaken at the same time, and at any given later moment, their conscious rings will be at the same height and each treefolk be able to read the messages that the other treefolk leaves for them, although a message that one treefolk leaves for another for one ring will vanish when these treefolk both shift their consciousnesses to the next ring. A human coming across these treefolks the following day would be able to view these messages (similar to how one can review a chat log in a text messaging app, though with the oldest messages at the bottom); they could also leave messages for the treefolk by placing text on some sort of sign that the treefolk can then read one line at a time (from bottom to top) on a subsequent night as their consciousness ascends through its rings. (Here we will assume that at some point in the past the humans have somehow learned the treefolk’s written language.) But from the point of view of the treefolk, their messages seem as impermanent to them as spoken words are to us: they last for a minute and then they are gone.")

#image("../assets/fe2bb5040a06a54d67c6f86400d209126ee6a88a806c9a1be4a9f60ca890899a-57280b026a8f2db3846947bac6d4220c84aa4b55c5860385f399fc118eee725e.png", width: 90%)

#heading(level: 1)[#strong[#text(" — 2. Time contraction and width dilation — ")]]

#text("In recent years, treefolk scientists (or scholars/sages/wise ones, if one wishes to adhere as much as possible to the fantasy setting), studying the effect of significant tilting on other treefolk, discovered a strange phenomenon which they might term “time contraction” (similar to ")#link("https://en.wikipedia.org/wiki/Time_dilation")[#text("time dilation")]#text(" in special relativity, but with the opposite sign): if a treefolk test subject tilts at a significant angle, then it begins to “age” more rapidly in the sense that test subject will be seen to pass by more rings than the observer treefolk that remains vertical. For instance, with the test subject tilted at a ")#mi("{30^\\circ}")#text(" angle, as 100 rings pass by for the vertical observer, ")#mi("{100 / \\cos 30^\\circ \\approx 115}")#text(" rings can be counted on the tilted treefolk. This is obvious to human observers, who can readily explain the situation when they come across it during the day, in terms of trigonometry:")

#image("../assets/68e50541106fc736d958a679c202b3d9174edc3316a5e5ef29eaac919435f3e0-e3bb8743db9e83abc9aa2f54bf3fa05372900bc34c43d417f4274a0f515dec9f.png", width: 90%)

#text("This leads to the following “")#link("https://en.wikipedia.org/wiki/Twin_paradox")[#text("twin paradox")]#text("“: if two identical treefolk awaken at the same time, but one stays vertical while the other tilts away and then returns, then when they rejoin their rings will become out of sync, with the twisted treefolk being conscious at a given height several minutes after the vertical treefolk was conscious at that height. As such, communication now comes with a lag: a message left by the vertical treefolk at a given ring will take several minutes to be seen by the twisted treefolk, and the twisted treefolk would similarly have to leave its messages on a higher ring than it is currently conscious at in order to be seen by the vertical treefolk. Again, a human who comes across this situation in the day can readily explain the phenomenon geometrically, as the twisted treefolk takes longer (in terms of rings) to reach the same location as the vertical treefolk):")

#image("../assets/1c9d40c2ce026477c234c064be7e43d6d2b3fa3643bfe5c400ed33c0c2ef0375-aa76075f349e1ce4f1fc05d25a875fbdd119f6cfc7d3f4e5bdf9fb9aad0ef343.png", width: 90%)

#text("These treefolk scientists also observe a companion to the time contraction phenomenon, namely that of width dilation (the analogue of ")#link("https://en.wikipedia.org/wiki/Length_contraction")[#text("length contraction")]#text("; a treefolk who is tilted at an angle will be seen by other (vertical) treefolk observers as having their shape distorted from a disk to an ellipse, with the width in the direction of the tilt being elongated (much like the slices of a carrot become longer and less circular when sliced diagonally). For instance, in the picture at the beginning of this section, the width of the tilted treefolk has increased by a factor of ")#mi("{1 / \\cos 30^\\circ \\approx 1.15}")#text(", or about fifteen percent. Once again, this is a phenomenon that humans, with their ability to visualize horizontal and vertical dimensions simultaneously, can readily explain via trigonometry (suppressing the rings on the tilted treefolk to reduce clutter):")

#image("../assets/7ccaf1d331c2f2175b138977bd507bb154b9af7e93ef370bf03da709152a29b9-a68c449f410eb5aa9bcd46afe2f8a64aedc000ea8dbcf14e746be93cb2b8da85.png", width: 90%)

#text("The treefolk scientists were able to measure these effects more quantitatively. As they cannot directly sense any non-horizontal notions of space, they cannot directly compute the angle at which a given treefolk deviates from the vertical; but they can measure how much a treefolk “moves” in their two-dimensional plane of vision. Let’s say that the humans use the metric system of length measurement and have taught it (through some well-placed horizontal rulers perhaps) to the treefolk, who are able to use this system to measure horizontal displacements in units of centimeters. (They are unable to directly observe the inch-long height of their rings, as that is a purely vertical measurement, and so cannot use inches to directly measure horizontal displacements.) A treefolk that is tilted at an angle will then be seen to be “moving” at some number of centimeters per ring; with each ring that the vertical observer passes through, the tilted treefolk would appear to have shifted its position by that number of centimeters. After many experiments, the treefolk scientists eventually hit upon the following empirical law: if a treefolk is “moving” at ")#mi("{v}")#text(" centimeters per ring, then it will experience a time contraction of ")#mi("{\\sqrt{1+\\frac{v^2}{c^2}}}")#text(" and a width dilation of ")#mi("{\\sqrt{1+\\frac{v^2}{c^2}}}")#text(", where ")#mi("{c}")#text(" is a physical constant that they compute to be about ")#mi("{2.54}")#text(" centimeters per ring. (Compare with special relativity, in which an object moving at ")#mi("{v}")#text(" meters per second experiences a time dilation of ")#mi("{1/\\sqrt{1-\\frac{v^2}{c^2}}}")#text(" and a length contraction of ")#mi("{1/\\sqrt{1-\\frac{v^2}{c^2}}}")#text(", where the physical constant ")#mi("{c}")#text(" is now about ")#mi("{3.0 \\times 10^8}")#text(" meters per second.) However, they are unable to come up with a satisfactory explanation for this arbitrary-seeming law; it bears some resemblance to the Pythagorean theorem, which they would be familiar with from horizontal plane geometry, but until they view rings as a third spatial dimension rather than as a unit of time, they would struggle to describe this empirically observed time contraction and width dilation in purely geometric terms. But again, the analysis is simple to a human observer, who notices that the tilted treefolk is spatially displaced by ")#mi("{tv}")#text(" centimeters whenever the vertical tree advances by ")#mi("{t}")#text(" rings (or inches), at which point the computation is straightforward from Pythagoras (and the mysterious constant ")#mi("{c}")#text(" is explained as being the number of centimeters in an inch):")

#image("../assets/45167977948520f8e1788f5c3b58c4e7d171241aa017458979df221e06dd8306-649e7031372ecf0040e81f656148f756761d110171e9165bce771c8bbea94eb1.png", width: 90%)

#text("At some point, these scientists might discover (either through actual experiment, or thought-experiment) what we would call the ")#link("https://en.wikipedia.org/wiki/Principle_of_relativity")[#text("principle of relativity")]#text(": the laws of geometry for a tilted treefolk are identical to that of a vertical treefolk. For instance, as mentioned previously, if a tilted treefolk appears to be moving at ")#mi("{v}")#text(" centimeters per second from the vantage point of a vertical treefolk, then the vertical treefolk will observe the tilted treefolk as experiencing a time contraction of ")#mi("{\\sqrt{1+\\frac{v^2}{c^2}}}")#text(" and a width dilation of ")#mi("{\\sqrt{1+\\frac{v^2}{c^2}}}")#text(", but from the tilted treefolk’s point of view, it is the vertical treefolk which is moving at ")#mi("{v}")#text(" centimeters per second (in the opposite direction), and it will be the vertical treefolk that experiences the time contraction of ")#mi("{\\sqrt{1+\\frac{v^2}{c^2}}}")#text(" and width dilation of ")#mi("{\\sqrt{1+\\frac{v^2}{c^2}}}")#text(". In particular, both treefolk will think that the other one is aging more rapidly, as each treefolk will see slightly more than one ring of the other pass by every time they pass a ring of their own. However, this is not a paradox, due to the ")#emph[#text("relativity of horizontality")]#text(" (the analogue in this allegory to ")#link("https://en.wikipedia.org/wiki/Relativity_of_simultaneity")[#text("relativity of simultaneity")]#text(" in special relativity); two locations in space that are simultaneously visible to one treefolk (due to them lying on the same plane as one of the disks of that treefolk) need not be simultaneously visible to the other, if they are tilted at different angles. Again, this would be obvious to humans who can see the higher-dimensional picture: compare the planes of sight of the tilted treefolk in the figure below with the planes of sight of the vertical treefolk as depicted in the first figure of this section.")

#image("../assets/3380e064ab815504d95fda2ab83afef78c9d3aeede023a9077ed3e29a9b0c891-0d1917f800ccf10e9bea3a8d16a58de00b4eb35ea00a65a3ae5f4dfb32f52938.png", width: 90%)

#text("Similarly, the twin paradox discussed earlier continues to hold even when the “inertial” treefolk is not vertical:")

#image("../assets/475a237513df6b0694b4b1a9b7a6e08e440e6fa2368d7af4cc213e7cd6d594cd-f398f4cc09f31a3925be25678c8a0449ac40812274e8c8b114a3324b143e3aae.png", width: 90%)

#text("[Strictly speaking one would need to move the treefolk to start at the exact same location, rather than merely being very close to each other, to deal with the slight synchronization discrepancy at the very bottom of the two twins in this image.]")

#text("Given two locations in ")#mi("{A}")#text(" and ")#mi("{B}")#text(" in (three-dimensional space), therefore, one treefolk may view the second location ")#mi("{B}")#text(" as displaced in space from the first location ")#mi("{A}")#text(" by ")#mi("{dx}")#text(" centimeters in one direction (say east-west) and ")#mi("{dy}")#text(" centimeters in an orthogonal direction (say north-south), while also being displaced by time by ")#mi("{dt}")#text(" rings; but a treefolk tilted at a different angle may come up with different measures ")#mi("{dx^{\\prime}, dy^{\\prime}}")#text(" of the spatial displacement as well as a different measure ")#mi("{dt^{\\prime}}")#text(" of the ring displacement, due to the effects of time contraction, width dilation, non-relativity of horizontality, and the relative “motion” between the two treefolk. However, to an external human observer, it is clear from two applications of Pythagoras’s theorem that there is an invariant")

#align(center)[#tao-fit-display[#mitex("dx^2 + dy^2 + c^2 dt^2 = (dx^{\\prime})^2 + (dy^{\\prime})^2 + c^2 (dt^{\\prime})^2:")]]

#text("See the figure below, where the ")#mi("{y}")#text(" dimension has been suppressed for simplicity.")

#image("../assets/3512891dc411a6f741a8943fc8a0d1fffa263fbcf517ec83d83adec7f254abca-1d3eeeb288319c8f86c99dc6513f4649b1f6b47de2730f4dc957ab2da3a3b1bd.png", width: 90%)

#text("From the principle of relativity, this invariance strongly suggests the laws of geometry should be invariant under transformations that preserve the interval ")#mi("{dx^2 + dy^2 + c^2 dt^2}")#text(". Humans would refer to such transformations as three-dimensional ")#link("https://en.wikipedia.org/wiki/Rigid_transformation")[#text("rigid motions")]#text(", and the invariance of geometry under these motions would be an obvious fact to them; but it would be a highly unintuitive hypothesis for a treefolk used to viewing their environment as two dimensional space evolving one ring at a time.")

#text("Humans could also explain to the treefolk that their calculations would be simplified if they used the same unit of measurement for both horizontal length and vertical length, for instance using the inch to measure horizontal distances as well as the vertical height of their rings. This would normalize ")#mi("{c}")#text(" to be one, and is somewhat analogous to the use of ")#link("https://en.wikipedia.org/wiki/Planck_units")[#text("Planck units")]#text(" in physics.")

#heading(level: 1)[#strong[#text(" — 3. The analogy with relativity — ")]]

#text("In this allegory, the treefolk are extremely limited in their ability to sense and interact with their environment, in comparison to the humans who can move (and look) rather freely in all three spatial dimensions, and who can easily explain the empirical scientific efforts of the treefolk to understand their environment in terms of three-dimensional geometry. But in the real four-dimensional spacetime that we live in, it is us who are the treefolk; we inhabit a ")#link("https://en.wikipedia.org/wiki/World_line")[#text("worldline")]#text(" tracing through this spacetime, similar to the trunk of a treefolk, but at any given moment our consciousness only occupies a slice of that worldline, transferred from one slice to the next as we pass from moment to moment; the slices that we have already experienced are frozen in place, and it is only the present and future slices that we have some ability to still control. Thus, we experience the world as a three-dimensional body moving in time, as opposed to a “static” four-dimensional object. We can still map out these experiences in terms of four-dimensional spacetime diagrams (or diagrams in fewer dimensions, if we are able to omit some spatial directions for simplicity); this is analogous to how the humans in this world are easily able to map out the experiences of these treefolk using three-dimensional spatial diagrams (or the two-dimensional versions of them depicted here in which we suppress one of the two horizontal dimensions for simplicity). Even so, it takes a non-trivial amount of conceptual effort to identify these diagrams with reality, since we are so accustomed to the dynamic three-dimensional perspective. But one can try to adopt the perhaps this allegory can help in some cases to make this conceptual leap, and be able to think more like humans than like treefolk.")

#heading(level: 1)[#text("Comments (67)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6219491055e67bd5294375790ad4a5afdc61c837f9f3474cd80007af64df6c3-f9dc9020a6fc07edc020653b63e6d25d72137a54eea469514786ffd30bb80b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of flyingtext")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670543")[#strong[#text("flyingtext")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2022")])]

#text("Good and thought provoking article. :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-671232")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2022")])]

#text("Dear pro.Tao,")#linebreak()#text(" I wish you a new health and happiness year, a new successful year . I am waiting for you . The historical time has come to you .")#linebreak()#text(" “Ah hah, the whole world only 2 people understand. After you read my sentences, you can delete them if you want. They are enough for me . Because from the third man in the world, they think that I am crazy and deny me. But all of them never, never, never, never know and understand. They themselves think that they are very smart, but????!!!”")#linebreak()#text(" ” A golden sentence for man that I respect the best ” You try hard more. The greatest success is waiting for you in the early 2023″. A tresure is opening for you. You believe yourself.”")#linebreak()#text(" Bye,")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69c0f98eb4601b2d4869b911a8c970ecd05b289f74d6400f0ad98681bf24211b-61f7455a67c716c5c0e4c6c0d8f6b6b06aca346e6a0582f11fdbf31add522db0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tobias Fritz")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670553")[#strong[#text("Tobias Fritz")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2022")])]

#text("Is there a good way to design the internal physics of this world such that the maximal treefolk trunk tilt of 45° is explained naturally? Since purely from the perspective of the Riemannian geometry, it would seem more natural to forego this analogy with special relativity and allow the trunks to tilt arbitrarily much, even downwards. That gives a nice setting to contemplate time travel paradoxes. This kind of world features in Greg Egan’s series of novels [Orthogonal](")#link("https://www.gregegan.net/ORTHOGONAL/00/PM.html")[#text("https://www.gregegan.net/ORTHOGONAL/00/PM.html")]#text("). His website explains the physics of a Riemannian block universe in a lot of detail, and the time contraction phenomenon even plays a central role in the plot: “Only one solution seems tenable: if a spacecraft can be sent on a journey at sufficiently high speed, its trip will last many generations for those on board, but it will return after just a few years have passed at home. The travellers will have a chance to discover the science their planet urgently needs, and bring it back in time to avert disaster.”")

#text("In any case, I think I will have treefolk in mind now every time I draw worldlines in a spacetime diagram :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670588")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2022")])]

#text("Hmm, you’re right that the 45 degree tilt has no particular significance in this Euclidean spacetime, as opposed to Minkowski spacetime where this tilt is an invariant of the geometry (the second postulate of special relativity). Geometrically it comes down to the fact that the hyperbola/hyperboloid is a conic section with asymptotes, whereas the circle/sphere is a conic section without asymptotes. So there is a tension here in trying to make the allegory faithful to Euclidean spacetime geometry and making it replicate the features of Minkowski spacetime. As you say though, if one doesn’t impose a limit on the tilt then the geometry can become quite acausal and it becomes less valuable as a source of intuition, so this is the best compromise I could think of to reconcile the two competing aims here.")

#emph[#text("[UPDATE: On further reflection I have decided to drop the 45 degree restriction, replacing it instead with the looser statement that treefolk mostly prefer to stay close to vertical, and it is only in recent years that they have started experimenting with more extreme tilts.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670598")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2022")])]

#text("I decided to code up some quick-and-dirty javascript to illustrate how the rotations of a Euclidean spacetime can continuously deform into rotations of Minkowski spacetime: ")#link("https://www.math.ucla.edu/~tao/relativity/")[#text("https://www.math.ucla.edu/~tao/relativity/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6219491055e67bd5294375790ad4a5afdc61c837f9f3474cd80007af64df6c3-f9dc9020a6fc07edc020653b63e6d25d72137a54eea469514786ffd30bb80b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of flyingtext")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670601")[#strong[#text("flyingtext")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2022")])]

#text("I want to cite your code and result of website in order to give more apparent understanding in my work. Could I ask your permission?")

#emph[#text("[Yes, this is fine – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc594d47ca4330484cc840cbfdc1df276cb20e19a366f18a355e09c1db1e75bf-95590f2cba7fcb0b145332bcb1e4de4e13557a19a821004af70eaf0ab3c515b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Chindove")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-676820")[#strong[#text("Peter Chindove")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2023")])]

#text("Prof Tao, if we exclude the external human observer then I think that observations of length and time between the Treefolk takes on additional transformations to the Lorentz transformations. And that the Lorentz transformations always require a global observer in this human form.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabian")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670570")[#strong[#text("Fabian")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2022")])]

#text("I think your allegory perfectly explains what spacetime is, but is there any explanation as to why that is the case?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670589")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2022")])]

#text("I think it’s still an open question in physics why we ended up with a spacetime with a 3+1 signature at physically observable scales; one could in principle lay out a theory of relativity with any signature, so one cannot answer this question purely from relativistic first principles. Perhaps a future theory of quantum gravity may shed some light on this. (I believe string theory had some proposals in this direction, though there does not appear to be a consensus among physicists as to how plausible they are.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670642")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2022")])]

#text("What if we would live on 2-sphere? Then there would be no preferred geodesics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670646")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2022")])]

#text("Another interesting aspect of our spacetime is the number of its independent physical units – there are four independent basic Planck units (length, time, mass and charge) which are determined by four independent absolute constants (c, G, h, ")#mi("\\epsilon_0")#text(") – is it somehow related to the fact that our spacetime is four dimensional?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670648")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2022")])]

#text("I would chalk this up to the ")#link("https://en.wikipedia.org/wiki/Law_of_small_numbers")[#text("law of small numbers")]#text(". As noted in the Wikipedia article, the number of normalizing constants in the Planck system depends in part on what physical quantities one wants to measure. If for instance one wishes to measure thermodynamic quantities such as temperature, then Boltzmann’s constant ")#mi("k")#text(" must also be added as a fifth normalizing constant.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-693601")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("The dimensionful constants are c, h, and l_P. ")#linebreak()#text("G only shows up in Newton’s gravity (which is a limit of GR).")#linebreak()#text("G = (c^3(l_P)^2)/h.")

#text("So, G is weird. There it is at the beginning of the universe (if you assume c, h, and l_P were there too), but it shows up nowhere except in Newton’s approximation of gravity.")

#text("Thats because G is the exchange rate between two separately coarse-grained things:")

#enum(start: 1, 
[#text("Mass: bound bandwidth (b trapped in a self-sustaining loop). That’s the matter coarse-graining: “mass” is already an emergent, coarse-grained reading of the substrate, not a substrate primitive.")],
[#text("Curvature: the emergent metric (g ~ 1/b). That’s the geometry coarse-graining: the metric is read off the graph’s connectivity, also a shadow.")]
)

#text("G’s whole job is converting one into the other — mass into curvature, a = GM/R². So it doesn’t live in either coarse-graining; it lives at the seam between the two, a conversion factor between two shadows.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670926")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2022")])]

#text("It is interesting that the dimension 4 of our spacetime has some very special properties:")#linebreak()#text(" 1. The manifold $latex \\mathbb R^n} has infinitely many differential structures only for n=4.")#linebreak()#text(" 2. The cross-product operationamong spatial vectors can be defined only for 3D vectors (in 4-1 dimensional “spatial slices”)")#linebreak()#text(" 3. Every associative, non-commutative finite dimensional algebra over the reals is (by Frobenius theorem) isomorphic to the quaternions (which are 4D with indication to the 3+1 signature!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670927")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2022")])]

#text("Correction: in the third property above “algebra” should be “division algebra”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f884d06362aaed2d5506f4898856efe379db50739b1ef2391aecf1922ec6050-e20f66de5df9cc2b34f163cc4a3cc9a2d5e2b29665b28b4994481a696762be12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Murat")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-674621")[#strong[#text("Murat")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2023")])]

#text("This paper from Max Tegmark has some hints in regards to the speciality of 3 space and 1 time dimension:")#linebreak()#text(" ")#link("https://arxiv.org/pdf/gr-qc/9702052")[#text("https://arxiv.org/pdf/gr-qc/9702052")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670573")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2022")])]

#text("Could the treefolk be foxtail palms?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09f5e42236f84baa161d4fb1e1e9244d4cb35e302851782309faff583966b430-11002f0e725618ae2423a91c1c45314a122ea65c45e8746a0fb5a1a392084072.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jan Decat (@deepconvonet)")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670579")[#strong[#text("Jan Decat (@deepconvonet)")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2022")])]

#text("I can’t help but ask: what fantasy books do you like?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7f1d3ad8dfa9deb3c5f71a2978a3f46411feb178f6a88d29ed889f43c64d79d-324f0e901579f755bbe71b95f8cfff5da855307fe6b4954c7bbca043ca618a1d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James T. Biscuit")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670594")[#strong[#text("James T. Biscuit")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2022")])]

#text("Now consider the case where at the dawn of time, there were two treefold. One ring tall each. They wink at each other and create a new treefolk who is the sum of the heights of the parents. This new treefolk is 2 rings tall. The treefolk winks again and suddenly another treefolk appears at 3 rings tall. And again! 5 rings tall. And so on. Scholars referred to this at the Tribonacci epoch.")

#text("In an alternative universe the winks followed prime rules, but the treefolk could never work how high they could go, or the relationship between their relatives. Scholars referred to this as the Primeval epoch.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670597")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2022")])]

#text("The “twin paradox” for treefolkassumes a static 3D reference frame (needed to define the “static” vertical treefalk – while in special relativity there is no such “static” reference frame.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670599")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2022")])]

#text("It’s not necessary in the treefolk twin paradox for the “inertial” twin to be vertical; it just needs to be straight. One could rotate the twin paradox picture by any angle and have the same “paradox”; no preferred orientation is required.")

#emph[#text("[Update: added an additional picture and some text to the post to emphasize this point.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670637")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2022")])]

#text("Does not tilting cause accerelation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670647")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2022")])]

#text("The analogue of acceleration in this allegory is curvature (and the analogue of inertial motion is being straight). In both Euclidean and Minkowski spacetimes, if two twins start at the same spacetime location, diverge from each other, and then reunite, at least one of the twins will have to experience non-inertial motion, and if only one of them did, the non-inertial twin will have aged faster (in Euclidean spacetime) or slower (in Minkowski spacetime) than their inertial sibling (this is basically the triangle inequality in either geometry). Since the property of being inertial is invariant under the symmetries of the geometry, it is unaffected by the choice of reference frame, and so the twin paradox does not contradict the principle of relativity.")

#text("If one works in a (spatially) periodic spacetime, then it is possible for two inertial twins to separate and reunite, with one twin aging slower or faster than the other, but again this does not contradict the principle of relativity, because one does not have a _global_ symmetry of periodic spacetime that interchanges the roles of the two twins; one only has _local_ symmetries in this case.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670649")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2022")])]

#text("Ok. There are many ways to treat special relativity, I guess. Anyway, the euclidean case is usually that when the transformations are Galilean, that do not contain a twin paradox.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670640")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2022")])]

#text("Twin paradox is not a true paradox in special relativity, because it handles only inertial frames. The point in the solution of the twin paradox is that at least other twin must move to a nonintertail reference frame. In three folk geometry, there is centrifugal force thus accerelation for those rotations, so your examples are not in anyway intertial.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7bb33598185214f54eb37110dae217e4bf79c642fcc0c0f046410eb80719ecd4-2dc92e7d42ea90184a37f0bc34826cb67557d9349c02b3715ed44e77eca0f5c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dmad")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670680")[#strong[#text("dmad")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2022")])]

#text("Re the additional photo: I think you could address the simultaneity issue by having the treefolk naturally living on a hill.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18c2fb626708f2ca3c7c4884683098fde16337ce08d416442796c92248a8f98a-43030ecada9921786396d4b88f6d6df8a0bc43b57ae337b653888d2a9a276c66.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zenorogue")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670606")[#strong[#text("zenorogue")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2022")])]

#text("In Relative Hell (a game in 2+1d dS/AdS spacetime) the run can be replayed and the 2+1d spacetime visualized in 3D (using perspective for the timelike dimension)… so quite a similar idea to this treefolk visualization, first you see how treefolks see it, and then you see how humans see it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670651")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2022")])]

#text("“mysterious constant t” should be “mysterious constant c”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d80d5f93e90a0d08290f3bc68630ef75896fbeb8225ded1a23d4edb2887da8e-8036e4e818f72f26d5326a98f6fe237ca177248c9b3ef327975c1ca0552c5469.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mjdv")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670676")[#strong[#text("mjdv")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2022")])]

#text("Suppose two tree folk are close together, messaging (as in the log above). Then one of them tilts severely away from the other, changing its field of vision to see “higher up” discs of its friend. Then it tilts back to straight, and repeats the message it saw on its friend.")

#text("Then its friend now knows what it will do in the future (leading to all sorts of grandfather’s paradoxes, etc.). Did I misunderstand, and if so, what? Or does the analogy not stretch that far?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6219491055e67bd5294375790ad4a5afdc61c837f9f3474cd80007af64df6c3-f9dc9020a6fc07edc020653b63e6d25d72137a54eea469514786ffd30bb80b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of flyingtext")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670678")[#strong[#text("flyingtext")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2022")])]

#text("Maybe the one who repeats the message must give an adequate explanation about the situation. Or, at least give reference(e.g. citation) for the source.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670779")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2022")])]

#text("Yes, this is a defect of the analogy. In our Minkowski world, we do not get to instantaneously “see” everything in our hyperplane of simultaneity; the events that occur in that hyperplane only become known to us later in the worldline. Instead, we can only perceive what happens in the backwards lightcone of our current location in spacetime. In the Euclidean spacetime model, there isn’t a perfect analogue of the backwards lightcone (as discussed in previous comments), but one partial approximation to the Minkowski situation would be to change the angle of vision of the treefolk to always point downward at a 45 degree angle from the horizontal regardless of the orientation of the treefolk. Thus, the further away two treefolk are, the more of a “lag” there would be in communication because a message emitted at a given height would only be seen at a somewhat larger height. On the other hand, this rule is somewhat strange in the Euclidean spacetime setting since the orientation of “45 degree angle from horizontal” is not preserved by Euclidean rotations, as opposed to Minkowski spacetime where this orientation is invariant under Lorentz transformations (Minkowski rotations). So I decided not to implement this rule and instead work with the conceptually simpler rule of horizontal vision, even if it does lead to the ability to see into the “future” in some sense.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ec4da3ccbbd10a041240eddfb034ec26c6204eb1eb384cbe1db6d01d3b0cd7a-2f39bba04959f02cf6b040c66bde84f9cf8189c0b50bcb602d9d92a30e333234.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jackson Jules")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670679")[#strong[#text("Jackson Jules")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2022")])]

#text("This was great. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670683")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2022")])]

#text("Amazing post! The allegory really cleared my thoughts on relativity and the exposition was well done.")

#text("Regarding the concept of time (especially in the last section), do I understand correctly that you are advocating something alike the [B-theory of time](")#link("https://en.wikipedia.org/wiki/B-theory_of_time")[#text("https://en.wikipedia.org/wiki/B-theory_of_time")]#text(")? (In particular, that “the flow of time is only a subjective illusion of human consciousness”.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670780")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2022")])]

#text("My view is that one can interpret spacetime either in a “treefolk” sense of a three-dimensional space evolving with respect to a subjectively experienced spacetime, or in a “human” sense of a four-dimensional spacetime, but it is difficult to try to both simultaneously (in particular, it is hard to interpret the spacetime around us four-dimensionally “in real time”, since if we are still in the middle of experiencing it, the future state of the spacetime is not yet determined). This was my motivation towards only allowing the treefolk to be active during the night and the humans to be active during the day.")

#text("An analogy might be with film. One can view a movie statically as a solid “object” – a film reel, a DVD, or perhaps a string of zeroes and ones on an internet server. Or one can “play” the movie dynamically as a sequences of images and sound evolving with time. But it is hard to adopt both views simultaneously (although ")#link("https://www.youtube.com/watch?v=TWmVlgIR2HA")[#text("this scene")]#text(" from the old parody movie “Spaceballs” makes a valiant attempt, as does ")#link("https://www.youtube.com/watch?v=ZZRhj03MZD4")[#text("this more recent scene")]#text(" from the British science fiction series “Doctor Who”).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7bb33598185214f54eb37110dae217e4bf79c642fcc0c0f046410eb80719ecd4-2dc92e7d42ea90184a37f0bc34826cb67557d9349c02b3715ed44e77eca0f5c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dylan")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670684")[#strong[#text("Dylan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2022")])]

#text("Your diagrams were great and got the point across; but just for fun- I tried feeding in some prompts into Stable Diffusion and Lexica. I’ll be excited when we can actually produce useful diagrams.")

#text("Not sure if I can share links, but this was my favourite:")#linebreak()#text(" – ")#link("https://lexica.art/history?prompt=7e016108-e753-433c-a705-253614aa3fd1")[#text("https://lexica.art/history?prompt=7e016108-e753-433c-a705-253614aa3fd1")]

#text("I guess in this case consciousness would pass from branches over rings? But obviously this is getting more in the weeds of the analogy and less useful (:")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670720")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2022")])]

#text("By interpreting proper time as a positive measure over “world lines” (smooth timelike curves in spacetime), it seems that the “twin paradox” is equivalent to the fact that two “world lines” with the same end points do not have (in general) the same proper time measure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670721")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2022")])]

#text("There is a very interesting Wikipedia article on circular motion with special relativity. It’s impossible to synchronize clocks with circular motion in SR. ")#link("https://en.wikipedia.org/wiki/Ehrenfest_paradox")[#text("https://en.wikipedia.org/wiki/Ehrenfest_paradox")]#linebreak()#text(" You could say that non-inertial motion is not part of SR.")#linebreak()#text(" Anyway, the regularity of the motion, like smoothness seems important. In SR you could aproximate a smooth curve with a zigzag-path by using a “local turning” with boosts and end up with a continuous and finite lenght motion, that would lead to a twin paradox. The motion has no curvatur. But because the path is not smooth enough, it’s out of the scope of SR.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670781")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2022")])]

#text("Non-inertial coordinate systems can be adequately described using the formalism of general relativity, which allows for arbitrary coordinate systems (including non-smooth ones, if one is careful enough) that do not necessarily obey the ")#link("https://en.wikipedia.org/wiki/Einstein_synchronisation")[#text("Einstein synchronization convention")]#text(", and which may have a non-constant (though still zero-curvature) spacetime metric (which would manifest in the appearance of ")#link("https://en.wikipedia.org/wiki/Fictitious_force")[#text("non-inertial forces")]#text(", such as centrifugal force). When the metric has zero Riemann curvature, this formalism is still mathematically equivalent (at least locally) to the traditional Minkowski space formalism of special relativity, so it is mostly a semantic quibble as to whether special relativity “allows” for non-inertial frames or not. But one thing that is true though (as the Ehrenfest paradox and similar paradoxes, such as the ")#link("https://en.wikipedia.org/wiki/Ladder_paradox")[#text("pole-and-barn paradox")]#text(", show) is that infinitely rigid macroscopic objects cannot move non-inertially in special relativity; to allow for non-inertial motion one must give physical objects a finite modulus of elasticity, which makes their behavior under non-inertial motion somewhat complicated (there will be stress waves propagating from one end of the object to another, at speeds less than or equal to than the speed of light).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670800")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2022")])]

#text("I was talking about that SR seems to allow non-smooth _motion_ (for points also) doing Lorentz boost and then ordinary tilting turn. So the Lorenzt group does not seem to preserve inertiality. I was thinking which transformations preserve inertiality and come with this ")#link("https://en.wikipedia.org/wiki/Gyrovector_space")[#text("https://en.wikipedia.org/wiki/Gyrovector_space")]#text(" I was thinking about the same thing that you that maybe the rigirous way is to restrict from GRE. In this extended sense, when non-inertial frames are consired is relevant also from the historitical perspective how much SR is just Einstein’s theory. ")#link("https://en.wikipedia.org/wiki/Acceleration_(special_relativity)")[#text("https://en.wikipedia.org/wiki/Acceleration_(special_relativity)")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670841")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2022")])]

#text("The Lorentz transforms are linear spacetime transformations, and so they transform an inertial worldline into another inertial worldline. Accelerating an object halfway through its worldline is sometimes informally referred to as applying a “Lorentz boost” to that object, but that’s not quite the correct terminology; more precisely, such an accelerated object will agree with one inertial worldline in the first half of its existence, and with an (actively) Lorentz transformed version of that inertial worldline in the second half of its existence. (This is analogous to how, if one bends a straight line at one point, then it is no longer straight, but it still agrees with a straight line for the first half of its spatial extent, and agrees with a rotated version of that line for the second half.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670858")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2022")])]

#text("But the Lorenz _group_ contains also the spatial rotations. Lorenz-transformations by themselves do not for a group. It seems to me that together with ordinary spatial rotations those worldlines can form sharp angles, if the Lie Group is not acting in a restricted way.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670885")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2022")])]

#text("Possibly we are talking at cross purposes, but: every element of the Lorentz group is linear, and thus preserves inertiality: straight worldlines map to straight wordlines. Wigner rotations are a reflection of the fact that the Lorentz group is non-abelian, but non-abelianness does not imply non-linearity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670863")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2022")])]

#text("What we are talking is ")#link("https://en.wikipedia.org/wiki/Wigner_rotation")[#text("https://en.wikipedia.org/wiki/Wigner_rotation")]#text(". But applying those successively you can approximate curved paths. So the Lorentz _group_does not preserve inertiality, because you can make a twin paradox with just transformations from the Lorentz group.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670910")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2022")])]

#text("Yes, that is true, by definition. However, the transformed particles own wordline is not inertial.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670809")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2022")])]

#text("“When the metric has zero Riemann curvature, this formalism is still mathematically equivalent (at least locally) to the traditional Minkowski space formalism of special relativity, so it is mostly a semantic quibble as to whether special relativity “allows” for non-inertial frames or not”")

#text("When you wan’t to learn this stuff well, I see that there is a lot of confusing information, especially in the Internet. But there is no need to scare a freshman physics student! But now I think you actually need the learn about (always smooth) Lie group actions etc.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670769")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2022")])]

#text("Tao，when you see this content，I will be in another world ，maybe，and you won’t find any message renew about me…said I would not write again，so，please tell Scholze for me，I love him.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ecedf5379ad63a8d43f857bf368fb2cc1115300678c93a9c3ea54404975cdfe-95b0d229c7fd8804b8bafc840fcd7c268b8c4a37d683b90a593394f768abcba5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fi-le")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670838")[#strong[#text("fi-le")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2022")])]

#text("Thanks for the post! I wonder how it changes the analogy’s connection to reality that the treefolk’s time is quantized. Would the fact that they can change their surroundings within an hour but also switch to another plane between hours lead to them experiencing something like two-dimensional time?")

#text("Also, a proposal for a physics-themed middle-earth location: “Helmholtz’s Deep”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670845")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2022")])]

#text("The discretization of time was mostly in order to simplify the description of the universe to avoid having to solve “")#link("https://en.wikipedia.org/wiki/Related_rates")[#text("related rates")]#text("” type word problems in order to quantify phenomena such as time contraction or length dilation; having a consciousness continuously flowing up the trunk would give essentially the same theory. As mentioned in another comment, the ability of treefolk to “see into the future” in some sense is a defect of this analogy; it can be fixed as mentioned before by tilting the treefolk’s vision downwards (or alternatively by imposing some delay on when the objects that the treefolk sees are actually registered by the treefolk consciousness, with more distant objects taking longer to register for some reason). But this makes the analogy more complicated and hence probably less useful as a conceptual tool, so some sort of compromise has to be made here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670878")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2022")])]

#text("This problem of indistinguishable directions is due to the Euclidean metric which has no distinguished “time axis” (which is used to make the “spatial slices”) – this shows why Minkowski metric (with its distinguished “time axis” – or “time’s arrow”) is needed!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670879")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2022")])]

#text("Well, in the pictures the time seems to be always orthogonal to those trees, so OP’s rotations are always spatial? In Minkowski-diagrams with Lorentz boosts the line angles describe different velocities. The distinct time coordinate does not change. And the projections of line points to the space with different times are those spatial coordinates. The Lorentz boost is a good name, because it changes only the velocities (with instant accelerations).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/097a4d5133f182db0e69d4c8b545f1e04ffe71834194bb0c5514993838312913-be24c73e8383858c44fd3f54eca00b77b675548c40c6fb0e21384600734295e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YahyaAA1")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670850")[#strong[#text("YahyaAA1")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2022")])]

#text("Oh dear! You’re giving away our secret, again, Terry; namely, this: (Mathematicians have ALL the fun!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a360380f33e9277f71d9012338baf8742b26086660159baa715b36a7e93a62b1-31b82e96606bc41fb8083c701a1f660cab5f1abca4c00551b20d4966dcc066bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-670954")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2022")])]

#text("merry boxing day")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c3382473d0d02cec307bf04208042f0834d66183f16fb8c4d652320611f411ef-a7060d5878f4ca1ef48b936bbdc39e4a0033a5f4ee76ddee07335f1b536b727f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Not even a joke")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-671211")[#strong[#text("Not even a joke")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2022")])]

#text("If you could pull off such original stunts in the domain of artificial intelligence much applause would be given. Have you given thought to agi?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 61")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-671217")[#strong[#text("61")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2022")])]

#text("Happy new year，Tao：-）")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-671265")[#strong[#text("Summary for 2022 — Physics - Lyu Physics")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2022")]

#text("[…] next! BTW, Terry Tao, the genius mathematician, also mentioned this excellent textbook in his December post about special relativity this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e91a7685c12890953acae4c13ebd29ec40d5183d9ed96c0b740c48d94749db36-af95f44698aa239e319d3b5e86cbda087d987388e07b5ebf710db83a20c8a79a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Special relativity and Middle-Earth – Marxist Philosophy of Science")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-671351")[#strong[#text("Special relativity and Middle-Earth – Marxist Philosophy of Science")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2023")])]

#text("[…] Special relativity and Middle-Earth […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-671428")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2023")])]

#text("The link to “Plato’s allegory of the cave” leads to an Error 404.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57cc2294faa462ff84f8cef41e31f9da83bb79fc25da22f21000f9914bbf428c-b7a3089d0d4347b569a3c844338a735ab261876b5b0ababf1ce166dbe688e42d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hector")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-671566")[#strong[#text("Hector")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2023")])]

#text("Dr Tao: Here’s a challenge for you, I know you enjoy that, use the same Plato’s allegory but this time for Prime Numbers. Perhaps, we humans, are only able to see the shadows of the structure of primes, while the body\\structure of primes is in a higher dimension. {R,C,H,O}. Any thoughts?")#linebreak()#text(" Happy new year!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61c073125eb7205ad6d3cb63c837a7cb2272fb58c7a5a8733b9faaae30f10d5a-3d7e39d0b4450ddfeb22529d9d1edeed124e87672acd7a13032b0984350f7c2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PJSak")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-671725")[#strong[#text("PJSak")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2023")])]

#text("The hyperlink to “Plato’s allegory of the cave” is broken. I think you meant to link it ")#link("https://en.wikipedia.org/wiki/Allegory_of_the_cave")[#text("https://en.wikipedia.org/wiki/Allegory_of_the_cave")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/facde9293129e2fc7cd1d7f68029bebb08cae323354c460cd926523ac70186e7-58ed111715d5737c1c5fed43ef0bd35e705ea0ce258ad3096d13a16f4019f66e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of njwildberger: tangential thoughts")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-672014")[#strong[#text("njwildberger: tangential thoughts")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2023")])]

#text("For a somewhat related take on SR, you can have a look at my YouTube video “Bats, echolocation and a Newtonian view of Einstein’s special relativity” at ")#link("https://www.youtube.com/watch?v=n27_QneBkqE&t=5s")[#text("https://www.youtube.com/watch?v=n27_QneBkqE&t=5s")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/672ea0831674f819f08ec51428ed703e9c3de74efa99b030129469b27ae074ca-9a70adc17cbb275c29f73afa4897f4ed52901d3de38bae56c092c16f76577910.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hervé S.")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-676819")[#strong[#text("Hervé S.")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2023")])]

#text("very interesting. Came here from the paper in the french news Le Monde…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/590c34ecf4142cb37e42e7c2bc1d54c40a7721e7c41e87478f16919303a92673-e0dbe01f76033281680cf365abd9f421fb730b202f391df45f60a09e121687f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A. F")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-677006")[#strong[#text("A. F")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2023")])]

#text("Good morning Prof. Tao,")#linebreak()#text(" Interesting that you put this topic on here. I went to read some of the debates between Bergson and Einstein in the 1920s, when this special theory got back more intense (Einstein’s train experience seemed to have been suggested more than 150year ago by Descartes, using boat instead). Maybe a couple of points for which I would appreciate your views (and others in this forum):")#linebreak()#text(" 1. The spacetime metric is somehow an “engineering” and a pragmatic metric on the “events” space. An event (e.g. collision) can happen only if we have same location and same time.")#linebreak()#text(" 2. In that respect, I would still expect that the “causality” argument put on the time may not necessarily be valid, as time (like space) can be reversed.")#linebreak()#text(" 3. Maybe a more fundamental question I would have, and this is maybe going back Bergson thinking, is the following: can we, in absolute terms, have/define time without movement? This might be a somehow philosophical question, but it could reconcile some discussions.")#linebreak()#text(" Thanks and regards")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erik")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-678700")[#strong[#text("Erik")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2023")])]

#text("There’s a typo in this line: “to the treefolk of they are completely above or completely below the treefolk’s current plane”.")

#text("“of” should be “if”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/93c52fe67d4cc608bb61e7f0c59312fac9f1f649eb41732610fa9f7b526acbbb-434820cddc93802abaaa982a7dfeece679951a222ad8b15c3a9b8dcd29bfbb79.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benjamin Andersson")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-680247")[#strong[#text("Benjamin Andersson")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2023")])]

#text("I did not understand why, when the tilted treefolk “rejoins” with the vertical treefolks, the vertical treefolks are on a higher disk than the vertical ones, since you said that the tilted treefolks “age quicker”, i.e. traverses more disks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/93c52fe67d4cc608bb61e7f0c59312fac9f1f649eb41732610fa9f7b526acbbb-434820cddc93802abaaa982a7dfeece679951a222ad8b15c3a9b8dcd29bfbb79.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benjamin Andersson")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-680248")[#strong[#text("Benjamin Andersson")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2023")])]

#text("Correction: … the vertical treefolks are on a higher disk than the *tilted* ones…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-680776")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2023")])]

#text("One should distinguish between the subjective internal experience of time by the treefolk, and the external objective time that the planet as a whole experiences. If for instance the tilted treefolk takes 102 disks to reach the same location that a vertical treefolk can reach in 100 disks, then while the tilted treefolk does “age faster” subjectively, the vertical treefolk will reach that location 100 minutes after sunset, whilst the tilted one will only reach it 102 minutes after sunset, at which point the vertical treefolk is two disks ahead.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/12/18/special-relativity-and-middle-earth/#comment-693599")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("Something I noticed about the allegory’s internal structure that I think it may be a feature rather than a defect. The static Euclidean block alone wasn’t enough to run the story: to make the treefolk’s experience work, three ingredients had to be added on top of the geometry. 1. a locus of consciousness that marches strictly upward (an arrow), 2. the petrification of the disks below it (an irreversible fixing of the past), and 3. a still-twistable trunk above (an open future). That’s not quite a block universe; it’s a growing block with a commitment process, which seems consonant with your reply above that “the future state of the spacetime is not yet determined.”")

#text("Even the defects discussed in the comments point the same way: what the Euclidean picture lacks (an invariant cone, one-way vision) is exactly what a directed process would supply.")

#text("So a question: do you view the consciousness-march and the petrification as removable narrative conveniences, or do they point at something the static 4D picture genuinely doesn’t contain?")
]
