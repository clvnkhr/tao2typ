// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/06/09/mini-polymath-3-2011-imo-question/
// Converted to Typst by tao2typ: "2026-10-14T09:11:33.441923+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mini-polymath 3: 2011 IMO question", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mini-polymath 3: 2011 IMO question")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 June 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/06/09/mini-polymath-3-2011-imo-question/")[#text("https://terrytao.wordpress.com/2011/06/09/mini-polymath-3-2011-imo-question/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In the last ")#link("http://en.wordpress.com/tag/mini-polymath1/")[#text("two")]#text(" ")#link("http://en.wordpress.com/tag/mini-polymath2/")[#text("years")]#text(", I ran a “mini-polymath” project to solve one of the problems of that year’s ")#link("http://www.imo-official.org/")[#text("International Mathematical Olympiad")]#text(" (IMO). This year, the IMO is being ")#link("https://www.imo2011.nl/")[#text("held in the Netherlands,")]#text(" with the problems being released on July 18 and 19, and I am planning to once again select a question (most likely the last question Q6, but I’ll exercise my discretion on which problem to select once I see all of them).")

#text("The format of the last year’s mini-polymath project seemed to work well, so I am inclined to simply repeat that format without much modification this time around, in order to collect a consistent set of data about these projects. Thus, unles the plan changes, the project will start at a pre-arranged time and date, with plenty of advance notice, and be run simultaneously on three different sites: a “research thread” over at the ")#link("http://polymathprojects.org/")[#text("polymath blog")]#text(" for the problem solving process, a “discussion thread” over at this blog for any meta-discussion about the project, and a ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2010")[#text("wiki page")]#text(" at the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("polymath wiki")]#text(" to record the progress already made at the research thread. (Incidentally, there is a ")#link("http://michaelnielsen.org/polymath1/index.php?title=Logo")[#text("current discussion")]#text(" at the wiki about the logo for that site; please feel free to chip in your opinion on the various proposed icons.) The project will follow ")#link("http://polymathprojects.org/general-polymath-rules/")[#text("the usual polymath rules")]#text(" (as summarised for instance in the ")#link("http://polymathprojects.org/2010/07/08/minipolymath2-project-imo-2010-q5/")[#text("2010 mini-polymath thread")]#text(").")

#text("There are some kinks with our format that still need to be worked out, unfortunately; the two main ones that keep recurring in previous feedback are (a) there is no way to edit or preview comments without the intervention of one of the blog maintainers, and (b) even with comment threading, it is difficult to keep track of all the multiple discussions going on at once. It is conceivable that we could use a different forum than the WordPress-based blogs we have been using for previous projects for this mini-polymath to experiment with other software that may help ameliorate (a) and (b) (though any alternative site should definitely have the ability to support some sort of TeX, and should be easily accessible by polymath participants, without the need for a cumbersome registration process); if there are any suggestions for such alternatives, I would be happy to hear about them in the comments to this post. (Of course, any other comments germane to the polymath or mini-polymath projects would also be appropriate for the comment thread.)")

#text("The other thing to do at this early stage is set up a poll for the start time for the project (and also to gauge interest in participation). For ease of comparison I am going to use the same four-hour time slots as for the ")#link("https://terrytao.wordpress.com/2010/06/21/organising-mini-polymath2/")[#text("2010 poll")]#text(". All times are in Coordinated Universal Time (UTC), which is essentially the same as GMT; conversions between UTC and local time zones can for instance be found on this web site. For instance, the Netherlands are at UTC+2, and so July 19 4m UTC (say) would be July 19 6pm in ")#link("http://www.timeanddate.com/worldclock/converter.html")[#text("Netherlands local time")]#text(". (I myself will be at UTC-7.)")

#metadata(none) <tao-572128898587a52d5471>

#metadata(none) <tao-b39f7f8c623ff4e07570>

#metadata(none) <tao-be8b0bc99a441de8ae4b>

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c24d0a8a1cf5a72f8707144dbce6fde9fc54933061d618a491237a6fdaca011d-e8fe1828db4aba7b1061d7dd8906bae0b4870d188948a163c9e5031e29dddd7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marco")]], [#link("https://terrytao.wordpress.com/2011/06/09/mini-polymath-3-2011-imo-question/#comment-54066")[#strong[#text("Marco")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2011")])]

#text("About issue (a): take a look at ")#link("http://wordpress.org/extend/plugins/wp-ajax-edit-comments")[#text("WP Ajax Edit Comments Plugin")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1d42168f0d29b83519498d6b15cefab628ea4102e81dfab59d17660cf095f12-e51bf28cb5cd6ba395b6e395f3dd9ac80cd20f708c7203de4e889ab0fa7d8a33.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Stacey")]], [#link("https://terrytao.wordpress.com/2011/06/09/mini-polymath-3-2011-imo-question/#comment-54135")[#strong[#text("Andrew Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2011")])]

#text("An alternative to the WordPress comments for discussions would be to use the same software as that underlying the nForum (the forum adjunct to the nLab). It has decent mathematics support and is highly configurable with regard to what users can and can’t do. It is possible to have non-registered comments, but then to allow registered participants greater freedoms (such as the ability to edit their comments).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mini-polymath 3 time and date « What’s new")]], [#link("https://terrytao.wordpress.com/2011/06/09/mini-polymath-3-2011-imo-question/#comment-54576")[#strong[#text("Mini-polymath 3 time and date « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2011")])]

#text("[…] the results from the recent poll on this blog, the mini-polymath3 project (which will focus on one of the problems from the 2011 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/06/09/mini-polymath-3-2011-imo-question/#comment-54812")[#strong[#text("Mini-Polymath 3 « Euclidean Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2011")]

#text("[…] Mini-Polymath 3 By kristalcantwell There will be a mini-polymath project around July 19th. There is a poll on the possible starting time here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2440d6a669b266b1e0ded0cf262bd8572dc362e7aa000fb14c6782e94a6cbf7-545719ca34e8c1d255335ce8638b341f6cc5ba0edfe9ede6f49618c2d9c7de51.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of International Mathematical Olympiad IMO2011 Amsterdam | problemas | teoremas")]], [#link("https://terrytao.wordpress.com/2011/06/09/mini-polymath-3-2011-imo-question/#comment-58327")[#strong[#text("International Mathematical Olympiad IMO2011 Amsterdam | problemas | teoremas")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2011")])]

#text("[…] Mini-polymath 3: 2011 IMO question begins on July 19, 8pm UTC. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/06/09/mini-polymath-3-2011-imo-question/#comment-688503")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2025")])]

#text("Can IMO problems be solved on a SAT solver? These are high school level problems. Do we need AI or may be if we train talented high school contestants who is also a programmer with tricks to convert these mathematical questions to SAT solving and provide contestants with access to SAT solvers can the participants looking at the problems frame them to SAT solvers and extract automated solutions or extract hints and solve the problems before the AI or other participants? We can also frame the questions so that converted SAT solutions can be directly converted to English or any other human readable language? Is AI progress on this a right metric for their progress?")
]
