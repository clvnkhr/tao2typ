// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/
// Converted to Typst by tao2typ: "2026-10-14T06:52:48.332913+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Another advice page, and an open thread", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Another advice page, and an open thread")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 September 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/")[#text("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I have added another essay to ")#link("https://terrytao.wordpress.com/career-advice/")[#text("my career advice page")]#text(", inspired partly by some earlier blog discussion, entitled “")#link("https://terrytao.wordpress.com/career-advice/continually-aim-just-beyond-your-current-range/")[#text("Continually aim just beyond one’s current range")]#text("“.")

#text("Also, there seems to be some demand for discussion here on topics not directly related to any of the posts. So I will experiment a little here and turn this post into an “open thread”, in which discussion on any topic is permitted (though, of course, I would continue to ask that all comments remain polite and constructive). If this experiment turns out well, I will try to initiate some further open threads at periodic intervals on this blog.")

#text("[Update, Sep 22: As you might have noticed, I am experimenting with ")#link("http://wordpress.com/blog/2007/09/22/tags-and-categories/")[#text("wordpress tags")]#text(", which have recently been ")#link("http://faq.wordpress.com/2007/09/21/the-difference-between-tags-and-categories/")[#text("decoupled from wordpress categories")]#text(". I am still not sure exactly what the best way to use tags and categories are, and whether there should be any attempt at standardisation amongst the maths blogs; suggestions are of course welcome.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (96)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-30347")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2008")])]

#text("Dear Beetle B.,")

#text("According to the wordpress.com FAQ entry at")

#link("http://faq.wordpress.com/2005/09/26/category-atom-feeds/")[#text("http://faq.wordpress.com/2005/09/26/category-atom-feeds/")]

#text("it seems that RSS feeds are available for each category by adding “/feed/” at the end of the URL for that category.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Restriction question")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-35312")[#strong[#text("Restriction question")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2009")])]

#text("Hello,")

#text("I have a question about your (Park City) survey on the restriction conjecture (this is the most appropriate thread I could find). In these notes you talk about the Restriction problem for the cone, sphere, and paraboloid. You endow each of these surfaces with what you call the canonical measure. In the case of the sphere its the surface measure, in the case of the paraboloid it is the Lebesgue measure under a pullback, yet in the case of the cone its the Lebesgue measure under pullback with an additional factor. In the case of the cone, you have a brief comment/exercise justifying this particular choice (because it preserves certain symmetries of the cone with respect to linear transformations). Also, these choices of measures seem to be the right ones for applications to the related (wave, Schrodinger, and Helmholtz) PDEs.")

#text("That said, however, I can’t see why these choices are canonical to the particular surfaces. For example, if I were to consider the restriction problem for an arbitrary surface in R^n is there a canonical choice of measure?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-35316")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2009")])]

#text("Not every surface has a canonical measure (other than surface measure, of course, although this measure depends on the inner product structure of the ambient space and so can be argued to not be totally canonical either). What distinguishes the sphere, paraboloid, and cone from other surfaces is that they are homogeneous spaces, i.e. they have the transitive action of a Lie group (the rotation group, Galilean group, and Lorentz group respectively), and thus come with a Haar measure which is well-defined up to constants.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cbdebedefe6721daa00281c9a160a2e45e97ad3c720640fb1ee640c9db46ea7-5ae3f0533a6f8efd8c27b82a0d3b34d2c4470bf49fe1af42d3130a83bb89803d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-35323")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2009")])]

#text("What about using results whose proofs you don’t know/don’t understand?")

#text("Sometimes in, say, analytic number theory, people borrow results that some algebraic geometer promised is true, and it would take a lifetime to go and verify the proof. That’s very scary.")

#text("Why do we do mathematics? Is it:")#linebreak()#text(" 1. to know: ie to have answers to any questions about the things you study")#linebreak()#text(" 2. to understand: ie to be able to prove whatever you want about the things you study.")

#text("I guess most of us do math to gain a deep understanding of the mathematical objects we study; because we care about *those particular objects* (otherwise it becomes an exercise in logical deductions). But some of the most crucial facts about our favourite objects are ridiculously hard to prove, and it may take decades to properly understand them.")

#text("Of course, I like knowing the answers too. But all my life I always thought that whenever you make any mathematical statement, if someone tortures you enough, you should be able to write down the proof from first principles.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32d20b607dd4a46a31b50b296721fa38971f66b82bd92d1f5d175ddc5ec77357-f8e58c684383cc0d9d017fe9cb7460cd650cf256c49ebdc234eea265f863d13a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rcourant")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-35324")[#strong[#text("rcourant")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2009")])]

#text("Dear Terry,")

#text("What do you mean when you say you put things in a “black box?” For example in your most recent Analysis notes you said that it would be okay to put a particular concept in a “black box.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d69a9dfa1da181ed90e5563814730006573d1826352d5ddd836528d22bdbfcd-ce709d661e0f70fdc33e9210797d44a04ec480a1e4bd1dddc2922147885a19ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of superman")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-35325")[#strong[#text("superman")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2009")])]

#text("Is it possible that every 100-term AP in the primes is contained in a 101-term AP in the primes? The quantitative/density bounds aren’t enough for this, but perhaps there is a direct argument?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-35328")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2009")])]

#text("Dear rcourant, a “black box” result is one for which the hypotheses and conclusion is known, but the proof is not (in analogy with ")#link("http://en.wikipedia.org/wiki/Black_box")[#text("black box systems")]#text("). It relates to a’s question about whether one should feel comfortable using results for which one does not know the proof. As a temporary measure, there is nothing wrong with this, especially if the proof comes from a very different area of mathematics than the one that one is focusing on, but of course one would ideally like to understand all the mathematical results that go into a proof one is trying to give, in order to be more certain about the proof, and to avoid errors caused by misunderstanding a result that was being applied as a black box.")

#text("Of course, given how vast mathematics is, it is often not feasible to read the proof of every result one needs line-by-line, but if one can get to the point where one has a heuristic understanding of why the result is true, at least (e.g. one works out some key examples, or reasons by analogy with simpler results of a similar nature, etc.), this is often good enough. In many cases, one does not need the full strength of a difficult result in one’s applications, and a simpler special case of it can often be worked out more directly by hand, which is also a good exercise to help one understand the full result.")

#text("Dear superman: my theorem with Ben implies that the number of progressions of primes less than N of length 100 is asymptotically larger than ")#mi("c N^2 / \\log^{100} N")#text(" for some absolute constant c, whereas standard sieve theory methods show that the number of progressions if length 101 is less than ")#mi("C N^2 / \\log^{101} N")#text(" for some other constant C. Letting N be large enough, we can conclude that not every prime 100-AP is part of a prime 101-AP.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e368eee5a14c4e8825e4ef070a0f1968c967775975f43bb870f98f3c0456bb1-460be13454d28a1bc8ede2d89e01d2b779359975107e240d6416b1226217ab17.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stuart Anderson")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-35627")[#strong[#text("Stuart Anderson")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("I have been reading some of your comments on Perelman’s proof, and if I have understood correctly, among other things, he has made some progress in statistical mechanics. This called to mind an old problem I had read recently;")

#text("In a paper ‘An Introduction To Probability And Random Processes’ by Kenneth Baclawski and Gian-Carlo Rota (1979) ")#link("http://www.ellerman.org/Davids-Stuff/Maths/Rota-Baclawski-Prob-Theory-79.pdf")[#text("http://www.ellerman.org/Davids-Stuff/Maths/Rota-Baclawski-Prob-Theory-79.pdf")]#text(", the authors posed a problem;")

#text("“We have a rectangular carpet and an indefinite supply of perfect pennies. What is the probability that if we drop the pennies on the carpet at random no two of them will overlap? This problem is one of the most important problems in statistical mechanics. If we could answer it we would know, for example, why water boils at 100C, on the basis of purely atomic computations. Nothing is known about this problem.”")

#text("I’ve tried using my undergraduate calculus but didnt get far, perhaps reducing the problem to simpler one and using combinatoric arguments might work?")

#text("Do you or anyone else know if this has been solved, or if progress has been made on it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1126ff6652aebb27930419daff3216bc46c4d4d8cead00084a3f0100966a3b2f-7fe60ebf51704413ee16eccf96d6bbaecf73e2a85baf0b8597a74e5e13e40d65.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of janiceenberg")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-39480")[#strong[#text("janiceenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2009")])]

#text("I’m new here on the forum, found it by searching google. I look forward to chatting about various topics with all of you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-39673")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2009")])]

#text("Could you give a reference for the reoccurring statement (on your blog) that the restriction conjecture implies the Kakeya conjecture? thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-39691")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2009")])]

#text("Dear Anonymous,")

#text("One can find a proof in Wolff’s survey article “recent progress on the Kakeya problem”. I believe the first formal appearance of this claim is in a paper by Beckner, Carbery, Semmes, and Soria, though the idea really goes back to Fefferman’s famous disk multiplier problem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AP Question")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-39724")[#strong[#text("AP Question")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2009")])]

#text("I have two (related) questions regarding your work with Green on Primes in AP.")

#text("First, in the original paper as well as subsequent work (as well as on this blog and a note on your website) you have addressed numerous quantitative questions related to the theorem such as (1) how big can the first k term AP (in the primes) be and (2) how many k term AP’s are there less then N (which is sharp up to the constant!). However, as far as I have seen, you didn’t explicitly give bounds of the form, “any subset of P \\cap [N] with density greater than F_k(N) must contain a k-term AP”, although maybe I just missed this. I did notice that Green obtained a bound of this form in his initial work on 3-term AP’s. Can bounds of this form be extracted from these methods or is it (perhaps) a casualty of moving to a more ergodic point of view?")

#text("Secondly, related to this last point, I was hopefuly you would say something about why you took the ergodic approach. Was this a matter of convenience, or is there a fundamental obstacle to taking a more Fourier analytic approach, consistent with Green’s original paper?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-39741")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2009")])]

#text("The arguments in my paper with Ben are quantitative (we use finitary analogues of ergodic theory rather than infinitary ones) do in principle give an effective bound for this quantity ")#mi("F_k(N)")#text(". My guess is that it will look something like ")#mi("(\\log_5 N)^{-1/2^{2^{k+C}}}")#text(" where ")#mi("\\log_5")#text(" is the 5-fold iterated logarithm.")

#text("The Fourier analytic approach eventually works (modulo the inverse conjecture for the Gowers norm, which is not yet fully resolved), and is the topic of several further papers of myself with Ben. The approach actually gives more precise information (in particular, it gives the right constant for the number of k-term progressions asymptotically), but is substantially lengthier.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/492e7f8b831538b3aa195c8da2ba059ce02b5fe2c43f798034e002ba43dd2d6a-f421de642dd48fe683e47cec39d9140b59e7f2986a513dc29386f7b9838750a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ardninam Lawarga")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-42211")[#strong[#text("Ardninam Lawarga")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2009")])]

#text("Hi Professor Tao and To Whom It May Concern:")

#text("I program for fun in various languages, mostly in C# language using WPF, Silverlight, ADO, ASP as the front end. Saw this blog on Forbes magazine and was curious to anybody reading this thread if they could suggest some cool math related programs to write. I have a few ideas but could use some more input.")

#text("I did see the suggestion by Prof. Tao for turning math classifications into a sort of periodic table. This is quite easy to do in ADO.NET as a database but the difficulty would be in having nice graphics… that is the gating factor in writing such an app. If anybody would supply me with the graphics I can write this type program fairly easily.")

#text("Here are some thoughts I have for programs that are math related, but I could use more input.")

#text("1) The Game of Life as expresed by British mathematician John Horton Conway in 1970. I wrote this already actually, and I mention it here as the class of idea I am interested in finding from anybody reading this.")

#text("2) Gambler’s Ruin problem–where you flip a coin from a given level and count how many iterations N it takes to go to zero, with 50% chance of going up one unit and 50% chance of going down– I wrote this as well in console mode (non-graphical output), and now I am going to work on expressing the output in Silverlight or WPF (which has outstanding graphics capabilities). What’s interesting is that ‘survivors’ of Gambler’s Ruin (candidates that did not touch zero in period M) for any period M (M > N) of iterations appear to be a sort of Poisson distribution. The longer you make M, at any given level, the more survivors you but it’s a nonlinear relationship it seems, like Poisson’s distribution perhaps. It’s also cool to graph the output and see how many candidates die in any interval despite reaching a very high level. This is sort of like the laws of entropy–you can actually defeat falling to zero for a very long time.")

#text("3) A Polya urn problem (")#link("http://en.wikipedia.org/wiki/Urn_problem")[#text("http://en.wikipedia.org/wiki/Urn_problem")]#text(") but for ants. I saw this in the book “Butterfly Economics” and it involves the following: given some ants who have the opportunity to visit two food sources, A and B (you can generalize this to any number though), and given three different outcomes (ant visits previous food source it visited, ant visits the food source of the first ant it meets returning from a food source, and ant visits randomly one of the two food sources), you graph the percentage of ants that are at any given food source at any time. The graph is nonlinear and depending on how you tweak the coefficients you can get jumps in the percentage of ants visiting any given pile–feed-forward behavior as they say in systems engineering, no pun intended.")

#text("Anyway I have a few other ideas such as graphing the output of various distributions like the broken stick distribution and the Galton–Watson process but the point of this was to underscore what kind of projects I’m looking for.")

#text("No time limit, any replies appreciated, as I just do this outside of my day job for fun.")

#text("Sincerely,")

#text("Ardninam Lawarga")#linebreak()#text(" email: ")#link("mailto:yamun31781@mypacks.net")[#text("yamun31781@mypacks.net")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-42312")[#strong[#text("Two new science & physics sites for asking questions « episodic thoughts")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2009")]

#text("[…] that rule, but at least there’s a great potential here! I hope influencial bloggers like Terry Tao, and Peter Woit (who asked if such site existed), can mention them: that would boost the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/480780358f59f9802a914eca36cf590326d2894f210361f5ea967832a79a2216-8d2f1f22f8948a9187e31d0ffe49cd3e8f35ad8d3a2674c4efd2cd1db79cc7e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of marthafines")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-42907")[#strong[#text("marthafines")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2009")])]

#text("Merry Christmas to all… and to all a good night.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d9f7522cb39bfc18a1a8d13e0e6de4497bf08512721551bab51be9631785bf3-c292c60c42fb552df86075b211e46ca0b64a07051e322beb806d380e8efb0da5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wayne Lewis")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-44281")[#strong[#text("Wayne Lewis")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2010")])]

#text("Professor Tao,")

#text("I have what may be silly question, but I have given up trying to figure it out and trying to find analysts who know the answer. Is Gamma(z) ever a negative real number if z is not a negative real number?")

#text("Aloha,")

#text("Wayne")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-44285")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2010")])]

#text("Yes; this can be seen from Stirling’s approximation and the argument principle.")

#text("More generally, for these sorts of questions, I recommend Math Overflow,")

#link("http://mathoverflow.net/")[#text("http://mathoverflow.net/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/07fbef603d82c14a8b70d14e0ba1d703394c4715247de3c617fbe6283dcb6ab8-b150e9b56646c5b0742ef44d90a5605a445890816e69ff3d1d37fa2c1e69a351.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HONG")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-47293")[#strong[#text("HONG")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2010")])]

#text("Dear Professor Tao,")

#text("I am not sure this is the right place to ask the question about your paper “CALESON MEASURES, TREEES, EXTRAPOLATION, AND T(b) THEOREMS”. In Lemma 4.1(or Lemma 4.2)(Calderon-Zygmund decomposition for size), I can not check that your induction hypothesis can give the right estimation, i.e. your induction on the size of a tree can give the estimation on the corresponding maximal size for the same tree. I wonder maybe we can go back to the method in “Chopping big trees into little trees”.")

#text("Thank you very much for all the wonderful works, thought I am not sure you have the time to answer my question.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-47294")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2010")])]

#text("I am sorry, I do not understand the question. No induction argument appears in the proofs of Lemmas 4.1 and 4.2 in our paper. To bound the maximal size of a on a tree, we can upper bound it by 2^n because we are assuming that a has maximal size at most 2^n on the larger collection P_n, and we can of course lower bound the maximal size by the size, which is at least 2^{n-1} by construction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HONG")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-47310")[#strong[#text("HONG")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2010")])]

#text("In Lemma 4.1 we select a tree T such that the size of a on the tree bigger than 2^{n-1} maximal with respect to set inclusion, but this can not ensure that the size of a on any convex subtree of T is bigger than 2^{n-1}, even if we are assuming the upper-bound for the size of a on any convex tree is 2^n. For instance, a tree T consisted of two tiles is selected most due to its top, the size of a on another tile can be very small.")

#text("Maybe, I’m making some dumb mistakes!")#linebreak()#text(" Thanks anyway!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-47311")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2010")])]

#text("To ensure a lower bound on the maximal size of a tree T, it suffices to lower bound just a single sub-tree of T; one does not need to lower bound _all_ subtrees of T. (This is because we are lower-bounding a sup, rather than an inf.)")

#text("In this particular case, the entire tree T has size at least 2^{n-1}, and so the maximal size of T is also at least 2^{n-1}.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/267dcae481090e3a4d01a3e68216624fe6a08cfeb134ece4a4f9b8d2c615e2b2-2b2b9d918269dbb6ed40b874cc14a6286415fbbee04b5d7a0321ba7a3e9a50fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ken")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-53011")[#strong[#text("Ken")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2011")])]

#text("Dear Terence,")

#text("I have been fascinated with the greatest integer function for the past decade. I have read journal and internet articles on it, read books on number-theory, and did a lot of research on my own. Although I have accumulated a lot of material over ten years, good literature on the greatest integer function (aside from its basic properties and applications) is very scarce. My purpose for posting this entry is not to promote my research here, but to inquire about advanced properties and applications for the greatest integer function that I have missed. I have put this question to other professors, but none of them seemed to know very much about the greatest integer function.")

#text("Then again, I cannot ask you what I missed unless I show you what I have done. The Full Text page on my site has a short summary listing chapter objectives just below the link to the pdf. In addition to addressing topics that I missed, by reading the summary, you could also give me ideas for what chapter objectives could be pursued further. Thank you.")

#text("Your fan,")

#text("Kenneth Beitler")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4565de0bbfa51a8c0f39f4c1723067425a19061d74591012223652fed3fcd1b-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony Morris")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-181359")[#strong[#text("Anthony Morris")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2012")])]

#text("Hello there. I would greatly appreciate a comment on this original take on prime numbers – ")#link("http://archive.org/details/PrimeNumbers_986")[#text("http://archive.org/details/PrimeNumbers_986")]#linebreak()#text(" Thanks Ant")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d35e61c2848bffd552b315a544788250364c631a1eba761945c51554b7e32f7-45891a5d781af3ff6b9bc9821fc908ab283526bc6ff6a3dc0cffb2d830c18ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ahmed Roman")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-191810")[#strong[#text("Ahmed Roman")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2012")])]

#text("Dr. Tao,")#linebreak()#text(" I and a few of my colleagues have been thinking about the following problem and are not making much progress. The question is made up by one of us and we think it is rather interesting. Here is the question:")#linebreak()#text(" 1) Find a function from the real line to itself such that the function sends the rational numbers to the rational numbers and such that the derivative of the function at q is not rational for some rational number q.")#linebreak()#text(" 2) After thinking about problem 1, one might ask the following question:")#linebreak()#text(" Is every continuous function from the real line to itself which sends the rational numbers to the rational numbers locally rational i.e. can one approximate the function on any small neighborhood by some rational function(different neighborhoods requiring different rational functions of-course).")#linebreak()#text(" Any intuition or hints would be appreciated.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad2222c70a89e3bb673ca296270fde6b5390cf092f69cb8f788c9aba4b1f6702-890a865ba3675ac6ecb3c3f2f74ccc1eb8364d961c8cea6347ad3fad67148bea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-197690")[#strong[#text("Jeremy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2012")])]

#text("Terry, I accidentally posted my email address in my name field (and vice versa) with this post: ")#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/#comment-197446")[#text("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/#comment-197446")]#text(". Would you please fix this for me? Or just delete the post? I reposted with the correct information just after I noticed my mistake, so if you can fix the first post (preferable, since it has replies already) then you can delete the second. Otherwise, vice-versa.")

#text("Thanks!")

#emph[#text("[Done – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3cb2edb352a2cc19b539e29dcc1c1c9d0b3cfd1dde18a34edc5e0f20373e710-56171540f803a7ea4b2e632ea3d14a784690526b7e2d656e570072188af3b7b7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roland")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-214827")[#strong[#text("Roland")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2013")])]

#text("Hi there.")#linebreak()#text(" This is an open challenge for any mathematically-apt mind looking for entertainment. Presented in a math olympiad 25 years ago:")

#text("Some Pythagorean triangles (a²+b²=c²), coincidentally, have integer lengths. For example 3²+4²=5².")#linebreak()#text(" Prove that for any integer Pythagorean triangle, one of the side lengths is")#linebreak()#text(" always a multiple of 5.")#linebreak()#text(" The original challenge consists of answering this in less than 1 hour,")#linebreak()#text(" with an 8th grader’s toolset.")

#text("Needless to say: i lamely excused myself in the original situation and got zero points. 25 years later, i have studied something other than mathematics. But my hard drive still rattling…")

#text("Any idea, any one ???")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d9debcf9ca2f3015909a33d228816b623cb471c3ba19b5bee50f7032adc4be4-64a5e40fa571db42cbbe17b2d80ae95861f1bd1dde4b1fab2e7f3a19d02a5e8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of matti")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-271834")[#strong[#text("matti")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2014")])]

#text("This fan site has spelt your name wrong")

#link("http://retrokiwi.spreadshirt.com/terry-teo-mens-t-shirt-colour-changeable-A1157786/customize/color/2")[#text("http://retrokiwi.spreadshirt.com/terry-teo-mens-t-shirt-colour-changeable-A1157786/customize/color/2")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-438584")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2014")])]

#text("Hi! I just wanted to share that I am an undergraduate student who has been reading through your blog this year (mostly not understanding, striving for understanding)… suffice to say that I really do not know who is who in math. I vaguely know that the Fields Medal existed but that’s all. Some friends and I were watching the Colbert Report this week and when your name came on the screen, I screamed, “I READ THAT GUY’S BLOG!!” I really appreciate that despite what I imagine must be an insanely busy teaching and research schedule, fame, etc that you still keep this blog full of interesting and exciting things–interesting even for those of us who are undergraduates and don’t understand very much quite yet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2143743597522d291a7f119b64a6405d5b9e745d90c702f1ce695f67a33eecc0-00f00821f227f55b11714d9d26826fcc7a8b4cc22ceaae6b5f894bfed678a0f1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Babak Farhang")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-487031")[#strong[#text("Babak Farhang")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2017")])]

#text("I “discovered” the other day that any equation that is symmetric in 2 variables defines a function that is its own inverse (an involution). Thus, for example")

#text("f(x) = (b – x) / (ax + 1)")

#text("is an involutory function for any constants a, b because that solves")

#text("y + axy + x = b.")

#text("So I can see it’s easy to define such functions using “symmetric” equations, but it might not be always easy to construct a simpler expression for it. For example")

#text("sin(y) + sin(x) + a sin(xy) + b = 0")

#text("is harder. And it’s not always clear to me whether the y = f(x) form is a bijection (and perhaps other issues related to constructing a proper inverse.)")

#text("My question: Is there theory about or a general approach to involutory functions defined this way?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a23f015c12d5ba72d6be20463a085d18237b6a580c533af160dc93f6dbc4907a-4cba85d28ba476bfcba9ee69a6e1909d08c5bac5e06ca3b83698a53f07fa0c71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roshan Jayaraman")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-489189")[#strong[#text("Roshan Jayaraman")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2017")])]

#text("Dear Terry!")#linebreak()#text(" I’m a junior in high school and really enjoy math.")#linebreak()#text(" I’ve been going to math competitions from middle school, and aspire to do well in the AMC competitions and possibly purse math in university.")#linebreak()#text(" I love the beauty and artistry of math; the idea that from a set of axioms you can create this whole world of craziness is just fascinating to me!")#linebreak()#text(" From time to time, however, I face the following problem:")#linebreak()#text(" When I attempt a challenging math problem, don’t make much progress, and then go read the solution, a part of me feels discouraged.")#linebreak()#text(" The solution looks so clean and beautiful, and I feel that the answer should have been obvious to me in the first place (this especially happens in geometry lol).")#linebreak()#text(" After a while, I tend to fall into the thought pattern of ‘Do these problems come naturally to other mathletes? Why isn’t this coming naturally to me? Maybe I’m not good enough…’")#linebreak()#text(" So this leads up to my question:")#linebreak()#text(" As a seasoned mathematician, I reckon you’ve made mistakes in your career. How have you learned to deal with mistakes? Was there a time in your life where you would be angry with yourself for making little progress on a challenging problem, and if so how did you cope with that situation? And now at 42, do you still get frustrated when you make little progress on a challenging problem?")#linebreak()#text(" Hearing your perspective could really help me. When I’m struggling with a crazy Euclidian Geometry in Math Olympiads problem and am making 0 headway, maybe instead of getting frustrated, I’ll think ‘Terry Tao makes mistakes too. I shouldn’t be too hard on myself’ :).")#linebreak()#text(" Cheers, and hope you had a happy thanksgiving!")#linebreak()#text(" Thanks, Roshan")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e073e11a70b2ace97602e5a1c14f7d7623a6c00e2c2e0d3204e2f476bf9e39a2-45ee0b3525d740f207d6e6a41336207dd249315aba76ec7294ce798c34bee597.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Krause")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-489199")[#strong[#text("Andrew Krause")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2017")])]

#text("This is actually something *all* mathematicians do. Theorems, proofs, and calculations as written in papers or problem sets are often quite cleaned up from their initial conceptualizations. Unless you have worked in a particular field for some time (e.g. typically years), almost nothing will come naturally. One of the most famous 20th century mathematicians, John von Neumann, one told a graduate student, “Young man, you don’t understand mathematics; you just get used to it.” Terry has several posts discussing the importance of struggling in order to really understand mathematics, and working hard, even to understand things which look easy to others, or after the solution is revealed.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/career-advice/work-hard/")[#text("Work hard")]
]

#link("https://terrytao.wordpress.com/career-advice/ask-yourself-dumb-questions-%E2%80%93-and-answer-them/")[#text("https://terrytao.wordpress.com/career-advice/ask-yourself-dumb-questions-%E2%80%93-and-answer-them/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b4a386aceaf1d79e8539b9920b0db0abff280b0f088651cfe7388beef357c70-569fc5d98fb47591abb2ffc7ccb23a43c2cb65e767482cb77ec710a45c069c16.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carlos M")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-505198")[#strong[#text("Carlos M")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2018")])]

#text("New Paradigm of Science")

#text("⁂")

#text("A simple way to explain E=mc² is: energy is matter times the square of the lightspeed. Time is space, and the relationship between both is that the effects of time are inversely proportional to the space; in a smaller space, the events have (relatively) more velocity. This shows us, that the reality beyond the limits of the known Universe extends itself endlessly, outwards the Cosmos and inwards the particles. With a fractal shape unfolded in several dimensions, and an pattern that allows astronomical objects/particles to desintegrate and replenish themselves in continuous cycles.")

#text("It’s like a spiral that extends itself from a centre towards the extremes endlessly where, alternating matter and energy in the space-time, gives place to endless realities with countless possibilities.")#linebreak()#text(" Events from our reality, like a drop of dew falling from a flower petal into the ground, affect not just the farthest star, but also at microcosmic levels, since they’re galactic groups interacting.")

#text("Reality is a fractal, without an apparent start or end. Looking close and very slowly at any type of molecule, we can see something similar to our galaxies. In turn, the suns and their planets, orbiting repeatedly with a fourdimensional effect, when seen from a remote point of view, give place to the atoms with their particles in the next level of reality, and so on, consecutive and endlessly.")#linebreak()#text(" In what it lasts one breath ours, in subatomic worlds occurs numerous events, and while our worlds existence passes, in the macrocosm instants only happen.")

#text("Reality")

#text("When zooming inside any type of matter and pausing the scene as necessary, it’s confirmed atoms and their subatomic particles are, actually, astronomical objects (among other things) orbiting continuously with great velocity (depending on the observer’s point of view), driving an effect that gives the matter its aspect. And those stars and planets are made of matter, and the atoms that make them are also sideral bodies in movement, made of more matter, etc., and this way reality keeps on perpetually.")

#text("And when zooming out towards the outer space, the celestial bodies and their planets continually orbiting across the time, they form the atoms and their subatomic particles that make a fraction of the macrocosm, and in turn this macrouniverse has astronomical objects that, when orbiting across the time, from another point of view gives place to atoms that make a fragment of another level of reality, etc. And this way the reality goes on, extending itself without interruptions.")

#text("The energy/mass across the space/time in any of its proportions, gives place to reality, a fractal of incalculable strands always moving itself (in continuous creation and destruction), extending itself incessantly outwards and inwards any point. With practically endless possibilities – within their respective rules – where innumerous imaginable possibilities and situations outside our thoughts fit. This Universe is a fragment in more than one infinity of infinities of infinite realities; it’s part of a bigger fragment, in an even larger one, in another even larger, etc. and the inverse. Unfolding itself in dimensions and planes, largely intangible for us.")#linebreak()#text(" The space/time is inversely proportional to itself, when the space is shrunk the (relative) speed of the events in this increase, and when the spaces is enlarged, the course of the matter in this [space] happens in longer periods of time.")

#text(":::")

#text("The planetary systems, galaxies, clusters and all other astronomical bodies, when they complete their trajectory towards the time – like a long-exposure photo – look like pictures made in a 3D spirograph. Deppending on the pattern type, the next level of matter they make has particular characteristics.")#linebreak()#text(" …")

#text("When moving the energy/matter in the space/time causes events, and realizing those events aren’t distinct outcomes, even then it’s probable that there are alternatives in other realities for any situation. Every action that exists is part of a whole and it is contemplated like that. The successes are now and always in the reality, forever happen – and stop happening-. There’s no past or future, just eternity.")#linebreak()#text(" …")

#text("There are other universes symmetrical to ours; since reality has a fractal nature, it has self-similarity, property where every little portion of the fractal can be seen as a smaller replica of the whole. In other words, in other scales there are parallel universes to ours, among many different ones.")

#link("https://rox1012101.tumblr.com/")[#text("https://rox1012101.tumblr.com/")]

#link("https://discord.gg/hRa8g3")[#text("https://discord.gg/hRa8g3")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3cb2edb352a2cc19b539e29dcc1c1c9d0b3cfd1dde18a34edc5e0f20373e710-56171540f803a7ea4b2e632ea3d14a784690526b7e2d656e570072188af3b7b7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of roland5999")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-505215")[#strong[#text("roland5999")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2018")])]

#text("Thanks Carlos, quite poetic :) Anything tangible follows from this? Any bottom line w.r.t. math or physics – like suggestion to turn attention anywhere in particular, any new tricks or experiments for sake of a new tangible result or so? Otherwise, poetic clauses and thats all, but thanks anyway. cheers, r.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3cb2edb352a2cc19b539e29dcc1c1c9d0b3cfd1dde18a34edc5e0f20373e710-56171540f803a7ea4b2e632ea3d14a784690526b7e2d656e570072188af3b7b7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of roland5999")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-505219")[#strong[#text("roland5999")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2018")])]

#text("Sorry Carlos, not wanted to sound")#linebreak()#text(" any harshness or judgement. I hear music by is there any libretto?? cheers, r.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed2a74bba646c6dbcdbb906e0ba6efc055ab36450a20f1a23503219d9a3c1830-9dd1060314b6fb99f385dcb38e71cb76fcb7d3507c4b0469853fc408f9c8d0b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TonyP")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-512859")[#strong[#text("TonyP")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2019")])]

#text("home page code or articles need fixing to many on the page")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed2a74bba646c6dbcdbb906e0ba6efc055ab36450a20f1a23503219d9a3c1830-9dd1060314b6fb99f385dcb38e71cb76fcb7d3507c4b0469853fc408f9c8d0b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TonyP")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-512860")[#strong[#text("TonyP")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2019")])]

#text("on previous post html tags p /a /p")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2490c48480962afcafeaffa6ffe777edd85c7a8280821daece2f2113e5feb12f-8b27df22d327813b299b189be8c5a4630aaedcbd6682bbc0b42a23223dac3420.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of But Maybe...")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-566223")[#strong[#text("But Maybe...")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2020")])]

#text("This open thread looks very old, so I’m unsure if you still check it. That said, I had a bizarre thought that I was hoping you’d be willing to entertain.")

#text("Is there any chance you’d someday write a blog post or two containing advice for the highly academically intelligent but socially less so? Possibly – dear God, forgive me – even romantic advice? I have Asperger’s, and I seem to get my heart torn out of my chest every other time I turn around, whether due to difficulty connecting with others generally, even including intelligent peers, or women specifically. I’d like to believe that the same faculties which can be applied to problem solving in general can also be applied to personal matters. You’re married. How the hell did you do it, man? What’s the one weird trick I need to adapt my general problem solving skills into social ones, and how has it possibly eluded me for so long?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/066ac933cb0e2c0835062bdcefc55f99806d96b68d5ea926bd9dcd4d1b3ce532-e53e02a31deef6a75d444f1a7ab5b8ac6118f7dbd5edacfbca32ddbbc2474896.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of High")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-568477")[#strong[#text("High")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2020")])]

#text("Hi all,")#linebreak()#text(" I would like to find a reference that discusses, in certain generality, the properties of solutions of systems of first order linear pde with non-constant coefficients. I am essentially trying to find a way to “predict” the properties of solutions of systems of first order linear pde with non-constant coefficients from the coefficient matrix, if such an endeavour actually makes any sense (forgive me if it doesn’t).")#linebreak()#text(" I am actually studying the particular case of the steady, two-dimensional adjoint Euler equations, ")#mi("A_x^T \\partial_x \\Psi + A_y^T \\partial_y \\Psi = 0")#text(", where ")#mi("A_x = \\partial F_x/\\partial U")#text(" and ")#mi("A_y= \\partial F_y/\\partial U")#text(" are the Flux Jacobians and ")#mi("\\Psi = (\\psi_1,\\psi_2,\\psi_3,\\psi_4)^T")#text(" is the adjoint state. ")#mi("F_x=(\\rho v_x,\\rho v_x^2+p,\\rho v_x v_y, \\rho v_x H)^T")#text(" and ")#mi("F_y=(\\rho v_y,\\rho v_x v_y, \\rho v_y^2+p, \\rho v_y H)^T")#text(". For external flows (flow around an airfoil, for example) ")#mi("\\Psi")#text(" obeys dual characteristic b.c. at the far-field (whereby the outgoing characteristic components of the adjoint field are set to zero), while at solid walls the b.c. is of the form ")#mi("(\\psi_2,\\psi_3)\\cdot (n_x,n_y)=f(p)")#text(" where ")#mi("(n_x,n_y)")#text(" is the normal vector to the surface and ")#mi("f(p)")#text(" is a function that depends on the choice of cost function. Depending on the choice of flow regime and cost function, the adjoint field can have singularities at airfoil/wing trailing edges, along stagnation streamlines, along supersonic characteristics, etc, and I would like to try to find a systematic way to understand the structure of singularities in relation to the fluxJacobians ")#mi("(A_x, A_y)")#text(" and boundary conditions. For example, funny things may be expected at points where the Jacobians become singular, or where the flow velocity goes to zero, or at discontinuities of the flow. The final goal is to understand why the numerical solution of the above equations is strongly grid-dependent (and even divergent) near solid walls, and why such grid-dependence seems to be strongly correlated with the presence of singularities at the forward stagnation streamline and at the trailing edge / rear stagnation point. Be assured that mesh dependence of numerical solutions in the vicinity of singularities is to be expected. Here I am speaking of global mesh dependence of the numerical adjoint solution across the entire wing airfoil surface as described here:")

#link("https://www.eucass.eu/doi/EUCASS2019-0291.pdf")[#text("Click to access EUCASS2019-0291.pdf")]

#text("Cheers!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30e1d200202903eebcd39b07969db311a51b291687937ff4d9f6363f31c94de5-fe4a67b515a797e429a79735828f187c22df9ae211df2391f2202fe771f88075.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asemic horizon")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-579473")[#strong[#text("asemic horizon")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2020")])]

#text("Do you have advice for people who have had *some* mathematical education (I dropped out with a Master’s degree) and want to keep learning?")

#text("I don’t think I was ever “mathematician material” but I want to keep growing anyway. I imagine most failed mathematicians like me have an “intuition overreach” problem in tackling proofs correctly enough that proofs become a first-class object. But I’ve seen a proof articulate the structure of an entire field (Darboux’s theorem and Hamiltonian mechanics); I know there’s more to learn like this.")

#text("I know I do better where there are numerous head-cracking counterexamples that challenge intuition enough that definitions must be revisited again and again until the unwritten point comes out. More generally I learn better from exposition that doesn’t appeal to intuition (ex. lattices from meets and joins and absorption laws, rather than from partial orders) because it gives my excess imagination a harder kernel to chew. But those materials tend also to be more advanced re: prerequisites.")

#text("It’s very likely you’ve had students like me; or that other comment box denizens have had them (or *are* somewhat like me).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fbfcf63d7cef8308f41421f3cf51d857c2fad67dd19b4f9d971e29fa0d802fe-447ab3d0d0a4f10ca37c99ad31be1779d360a75381588db1413311744009f1b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Collatz conjecture")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-605814")[#strong[#text("Collatz conjecture")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2020")])]

#text("Hey, Terry, I think I have a solution to 3n+1, or, at least, a chunk of the puzzle.")

#text("Let’s just say:")#linebreak()#text(" After I found it, I had a feeling “welp, that’s it then”.")#linebreak()#text(" It scratched the “itch”, I’m free from the desire to solve it further. Take it for what it’s worth.")

#text("I don’t have any credentials, but I solved “Einstein’s puzzle about five houses” without writing anything down. Weird flex, I know, I hope it’s ok.")

#text("I don’t have time to check if this solution exists, because time is food where I live. I think it’s fair, though, to spend some time to offer you a choice, since you are a renown Collatz solver :D")

#text("Also, if it is the solution, I would’t want to spoil the “fun” for everyone, and just drop it on 4chan or reddit.")#linebreak()#text(" Or, maybe, I should, so that at least some people can be finally free from this 3n+1 “mind bug”?")

#text("What do you think Terry? What should I do?")#linebreak()#text(" Is this problem a curse, or a fun challenge for you?")#linebreak()#text(" Is the solution more important than the process of solving, or does it open new paths?")

#text("I certainly used “unconventional” methods in solving this. I reject “conventions”, made by people, who insist that “one is not prime” to have shorter proofs. Rules may have exceptions, Laws may not. I’m a bit sorry for this rant, but that’s how I feel.")

#text("If you are interested, email me. I’ll check this inbox periodically.")

#text("Also, as my email is hidden, writing to it about Collatz is a strong bayesian proof only of “someone has access to blog back end and can see comment emails”. Think of something, or we can think of something together, if you like such games. I’ll make no promises on when I’ll get back to you, feeding my family comes first.")

#text("This is a message only for Terry Tao. I shall not respond to this thread.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-605819")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2020")])]

#text("He’s obviously not going to read it. Probably you should check it carefully and find the error.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-606711")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2020")])]

#text("Indeed, mr. Anonymous. Good point.")

#text("If OP is at least half as smart, as they claim to be, they would, probably:")

#text("– Find the error, and then remove all, some or none of their claim.")#linebreak()#text(" – Know the answers to their questions, and leave Terry Tao to be Terry Tao, who, probably, has other things to think about, than “of something”.")#linebreak()#text(" – Know that “fun”, “mind bug”, “curse” and “challenge” are not mutually exclusive terms.")#linebreak()#text(" – Have a shower when they have “the itch”, just in case :P")

#text("Who knows? Maybe they did it regardless, for their own reasons.")#linebreak()#text(" I mean, I didn’t see the solution posted anywhere…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/007989c3e4ee98108e69df7e74c422e818a1759ab6ba8e326ab3dead38b024f3-5b5e61bd91294a508c89a3b8ef0b030ed27cf343d6ed4f0a9dd02f6800092ee4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Adler")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-642797")[#strong[#text("Scott Adler")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2022")])]

#text("A mundane observation. In your Masterclass presentation you discussed what is the best time to tie the shoelace when rushing to catch a plane and used the example of 2 identical twins. One stopped just as before getting on the moving walkway and the other who stopped on the moving walkway with the latter then getting ahead of the other. The conclusion was reached that stopping while on the moving walkway was best. However if one stopped on the moving walkway while the other twin continued to walk and then stopped after getting off, he would be ahead and then the other twin would catch up to him, therefore there is really no best time. T =time not on the walkway , W=time on the walkway, L= time tying laces;")#linebreak()#text(" T+(W+L)+T is the total time for stopping before the walkway")#linebreak()#text(" T+W+ (T+L) is for tying after the walkway. The time is the same.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/007989c3e4ee98108e69df7e74c422e818a1759ab6ba8e326ab3dead38b024f3-5b5e61bd91294a508c89a3b8ef0b030ed27cf343d6ed4f0a9dd02f6800092ee4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Adler")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-642798")[#strong[#text("Scott Adler")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2022")])]

#text("Clarification W is the same in both cases so it is really (T+L)+W+T and T+W+(T+L).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-2/#comment-682861")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2024")])]

#text("This is a very basic question regarding the inverse of a function.")#linebreak()#text(" If I look at ")#mi("f(x)=x^2")#text(" it is clear that this is not a one-to-one function; therefore unless we restrict the domain we cannot construct the inverse. But there is also another condition: if we try to construct the inverse at the neighbourhood of a point ")#mi("x_0")#text(" we must ensure that ")#mi("f^{\\prime}(x_0)\\neq 0")#text(". So, for ")#mi("x=0")#text(" since ")#mi("f^{\\prime}(0)=0")#text(" we cannot write down the inverse function. Is this the same as saying “the inverse of ")#mi("x^2")#text(" is not analytic at ")#mi("x=0")#text("?")

#emph[#text("[Analyticity of the inverse does imply non-vanishing of the derivative (if the function is differentiable). On the other hand, it is possible to have a (non-analytic) inverse even when the derivative vanishes; consider for instance the function ")#mi("f(x) = x^3")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gaspard")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-9934")[#strong[#text("Gaspard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2007")])]

#text("Dear Terry, it appears you are planning courses in the winter “topics in ergodic theory” and in the spring “Perelman’s proof of the Poincaré conjecture”. I was simply wondering if by any chance you were planning to have them filmed and posted on youtube or google video (that is, in the event such a thing is indeed allowed by your university)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91841f5e59201923e09be98a5cf5917591fef164a2a040b79e78d927874dd4bf-c2c4379bfc95793e545279b1b6a44f80c80394352dfb8cc2ea2a9f97264ce0e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Cook")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-9955")[#strong[#text("James Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2007")])]

#text("Dear Terry,")

#text("I know it isn’t technically within your field of expertise, but nonetheless I can’t help wondering whether you’ve ever thought about the ")#link("http://en.wikipedia.org/wiki/Invariant_subspace_problem")[#text("invariant subspace problem")]#text(". This has always struck me as a very basic (and easy to understand) question in analysis — one which has, however, been stubbornly resistant to resolution (though lots of partial progress has been made).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ravinder")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-9984")[#strong[#text("Ravinder")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2007")])]

#text("Yes Gaspard thats the amazing idea.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-9986")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2007")])]

#text("Dear Gaspard: UCLA does not currently have a systematic program to videotape classes. But I am planning to intertwine this blog with those courses heavily when I teach them (posting lecture notes, encouraging discussion by students, and so forth); indeed, I expect my postings on non-class related topics to decrease markedly during those two quarters. It will of course be something of an experiment, and we’ll see how it goes.")

#text("Dear James: I haven’t looked at this problem since graduate school (and almost every graduate student secretly tries his or her hand at a famous unsolved problem or two). I never got anywhere myself; I would be much more comfortable with the problem if there was an obvious finite-dimensional or otherwise “discretised” or “quantitative” analogue to investigate, since that would bring things much closer to things that I actually have some experience in. [The conjecture is of course true for finite-dimensional spaces, but this does not seem to be the “right” finitisation, as it does not come close to implying the infinite-dimensional version in the limit.] But I think Timothy Gowers (who is much closer to this area) has looked a bit more at the problem, though I recall he told me once that it didn’t look amenable to the type of Banach geometry methods that he is expert in.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-9999")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2007")])]

#text("Dear Terry,")#linebreak()#text(" Thanks a lot for setting up this post!")#linebreak()#text(" I would like to write some thoughts about the Perelman situation.")#linebreak()#text(" In applied mathematics, we have the concept of a formal proof, where")#linebreak()#text(" a plan is laid out for a construction, and that of a rigorous proof, where")#linebreak()#text(" the formal proof is made rigorous. Usually both these works are respected")#linebreak()#text(" by our community, as often it is hard for anyone to be versatile enough")#linebreak()#text(" to both set up an interesting problem and prove all the intricate technical details.")#linebreak()#text(" About the general feeling that Perelman’s proof is or can be made")#linebreak()#text(" rigorous: Terry has written about part of the proof, and stated that")#linebreak()#text(" some of the geometric formulas seem miraculous. I don’t know whether")#linebreak()#text(" he checked all the analytical details, or whether anybody with serious credentials can vouch for the completeness of the proof, like was the")#linebreak()#text(" case with FLT. I think that Perelman’s antics have put mathematics in uncharted waters, and as a community we should be careful what to")#linebreak()#text(" do with it, to avoid a possible future embarrassment.")#linebreak()#text(" To show why I am uneasy, let me give an example of a soft analysis amplification problem, which was long considered to be obvious, yet")#linebreak()#text(" turned out not to be so. It is the Dirichlet principle, as a method of")#linebreak()#text(" solving Laplace’s equation. Riemann thought that for the underlying functional to attain a minimum it is enough that it is bounded below,")#linebreak()#text(" until Weierstrass gave a counterexample. Since in this problem one")#linebreak()#text(" has somehow to get around the lack of compactness, a common construction of the minimum is to amplify the space on which the")#linebreak()#text(" functional is defined to H^1, use its structure to get a weak solution,")#linebreak()#text(" and then bootstrap to show it is a classical one. Many new objects and ideas come out of this application: Sobolev spaces, functional analysis,")#linebreak()#text(" etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10074")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2007")])]

#text("Dear Adam,")

#text("Actually, Perelman’s argument for the Poincare conjecture is perhaps one of the most intensively checked proofs in recent memory; the proof is amazing, but definitely within the reach of certification by experts (there is no computer-assisted component, for instance). In particular, the book by Morgan and Tian, just published by the Clay Institute, is very thorough with the details. Thanks to all the recent literature on Perelman’s argument, many key steps now have multiple proofs, which also adds confidence (though the variations from Perelman’s original argument are fairly minor). Finally, while Perelman’s work has many highly original ingredients, much of the actual technical execution of his ideas follows well-trodden lines, for instance building on the work of Hamilton, or on the comparison geometry of Bishop and Gromov. This reliance on (or at least similarity with) existing technology also lends confidence; to use your example, any modern paper which exploited the Dirichlet principle using modern techniques (starting with weak solutions and bootstrapping the regularity, etc.) would not arouse suspicion, given that the subtleties here have been intensively studied and it is now well understood what the pitfalls are.")

#text("I do indeed view Perelman’s entropy monotonicity formula as miraculous, but he does motivate them from a statistical mechanics perspective (and I believe some alternate derivations of this formula, related to the Yamabe invariant, have since been established). I might try to understand these derivations better when I start my class on the topic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Attila Smith")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10099")[#strong[#text("Attila Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2007")])]

#text("Dear Terry,")#linebreak()#text(" since you allow us to ramble, let me ask if you know families of non-compact differentiable manifolds X such that a submersion with fibre X is a locally trivial bundle (i.e. locally downstairs the submersion is a product) .")#linebreak()#text(" This is true for compact X (Ehresmann) and for X=R^n ( I have no reference).")

#text("More importantly, let me thank you for your wonderful blog: you are living proof that one can be a sparkling mathematician and a gentleman. (I put Deligne in the same small category , where “small” does not only mean that I’m talking about sets …).")#linebreak()#text(" With all my gratitude,")#linebreak()#text(" Attila")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb7109d2b62e95bac2fbe04a9bea8803f40f5c2e9cb41a2bfce7689178a0cc0f-6560b3b52073c9b6e73cd78a96a64a2bee82ad156ae84553258a1859a54a206d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of robert")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10117")[#strong[#text("robert")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2007")])]

#text("Terry")

#text("I am wholly blown away by what you and Tim Gowers are doing to bring maths to those much younger and more able than myself. You really do do the business. At a time when western civilization seems to be eschewing several centuries of enlightenment, you guys keep shining on. And it’s a much belated education for old boys like myself.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10130")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2007")])]

#text("Dear Terry,")#linebreak()#text(" To me, Perelman’s style of writing is that of a theoretical physicist,")#linebreak()#text(" and may not be to everyone’s liking. On the other hand, the Cao-Zhu")#linebreak()#text(" write-up has a soft analysis style, so that a casual reader doesn’t get")#linebreak()#text(" mad at nasty gaps.")#linebreak()#text(" The functional \\int (Ru^2 + u’^2) that Perelman introduced comes up")#linebreak()#text(" in one of the few basic and sound physical theories, as is explained")#linebreak()#text(" below. What is miraculous to me, is that he doesn’t seem to know")#linebreak()#text(" how to provide a coherent physical explanation for its origin.")#linebreak()#text(" So, statistical mechanics, a play with fancy definitions, is a theory")#linebreak()#text(" which assumes a thermodynamical process is reversible, which is")#linebreak()#text(" usually not the case. In 1893, a theory for irreversible phase")#linebreak()#text(" transitions was proposed by van der Waals, which is based on")#linebreak()#text(" a free energy functional, defined on the space of phase fields")#linebreak()#text(" (e.g., density, quantum order parameter, etc.). Usually, it is")#linebreak()#text(" known in the scientific community only in rediscovered and")#linebreak()#text(" incomplete forms, e.g., Ginzburg-Landau superconductivity, Higgs")#linebreak()#text(" symmetry breaking mechanism, Cahn-Hilliard, Ball-James nonlinear elasticity, etc. Very briefly, the original functional takes the form")#linebreak()#text(" (in which I skip all irrelevant constants):")#linebreak()#text(" – \\int \\int K(x,y)u(x)u(y) +")#linebreak()#text(" \\int (-u^2 + Tk [(1-u)ln(1-u)+(1+u)ln(1+u)] ), (*)")#linebreak()#text(" where T is the absolute temperature, k is Boltzmann’s constant,")#linebreak()#text(" and the double integral is recognized as Ising’s model, introduced")#linebreak()#text(" later. Statistical mechanics and this model are distinct extensions")#linebreak()#text(" of thermodynamics, unlike some recent physics textbooks claim.")#linebreak()#text(" To derive (*), one has to assume that (*) is a Helmholtz free")#linebreak()#text(" energy with a certain interplay between molecular interactions")#linebreak()#text(" (1st law of thermodynamics) and entropy (2nd law).")#linebreak()#text(" The controversy surrounding (*) is obvious: amplifying, it is defined,")#linebreak()#text(" say, on L^2, which is a space in which critical points are not smooth,")#linebreak()#text(" as below a certain critical T, call it T_c, the integrand in the single")#linebreak()#text(" integral is a double-well function (exercise). Therefore, the")#linebreak()#text(" investigation of the model is not accessible to crude analysis,")#linebreak()#text(" and one is tempted to use an approximation. However, then we get")#linebreak()#text(" a theory (I call it incomplete) which is incompatible with phase")#linebreak()#text(" transitions (defined, by the way, as two different densities coexisting")#linebreak()#text(" at the same pressure). For large T, since critical points become")#linebreak()#text(" smooth, the following approximation is qualitatively sound: expand")#linebreak()#text(" both the double and single integral in Taylor series, and take")#linebreak()#text(" first terms in the expansions. We get \\int (u’^2 + u^2). Since")#linebreak()#text(" we are in the gas phase, entropy effects are dominating, and it is")#linebreak()#text(" correct to say that the functional used by Perelman is an entropy one.")#linebreak()#text(" ps The van der Waals paper was translated into English just")#linebreak()#text(" recently: J. Stat. Phys. 20 (1979), 197-244. Since its introduction,")#linebreak()#text(" uses of (*) have been mired in misunderstanding and high emotions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10140")[#strong[#text("Sunday evening links! « Entertaining Research")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2007")]

#text("[…] evening links! 1] Terry Tao has added another essay titled Continually aim just beyond one’s current range to hi…; the title reminded me of the lines from James Elroy Flecker’s Hassan: We are the Pilgrims, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10150")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2007")])]

#text("Dear Terry,")

#text("I was just wondering what your hobbies are besides math? What are your favorite tv shows, books, movies etc..")

#text("What is your favorite food?")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10222")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2007")])]

#text("Food for thought: in the nineties, the name Richard Hamilton was well known in the variational phase transitions community. That certain equations are gradient flows of functionals was also well known, e.g.,")#linebreak()#text(" the semilinear heat equation is the L^2 gradient flow of the gradient squared version of the van der Waals free energy (\\int (u’^2 + W(u))) without a mass constraint, and the Cahn-Hilliard equation is the H^-1 gradient flow of this functional with a mass constraint. An interesting reference is:")#linebreak()#text(" P.C. Fife, Models for phase separation and their mathematics, Electronic")#linebreak()#text(" Journal of Differential equations, Vol. 2000(2000), No. 48, 1-26.")#linebreak()#text(" Abstract: The gradient flow approach to the Cahn-Hilliard and phase")#linebreak()#text(" field models is developed …")#linebreak()#text(" As the author explains, this paper was submitted for the proceedings")#linebreak()#text(" of a workshop in 1991, however did not get published (I don’t know")#linebreak()#text(" why). It might be worth adding that it was widely and freely circulated.")#linebreak()#text(" It is well known that in analysis progress is done in small steps by")#linebreak()#text(" many previous contributors, and I hope these facts shed some light")#linebreak()#text(" on Terry’s comment that a part of the proof looks miraculous.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roland")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10297")[#strong[#text("Roland")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2007")])]

#text("From what I understand, Dr Perelman has abandoned mathematics and he has a heavy heart.")

#text("Can anything be done to help him?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10315")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2007")])]

#text("I think he said in one of his interviews in glossy magazines")#linebreak()#text(" that he had a problem with a lack of ethics in mathematics,")#linebreak()#text(" so maybe we could start to write things more honestly?")#linebreak()#text(" By the way, he is not the first one to abandon mathematics.")#linebreak()#text(" Grothendieck, a founder of modern algebraic geometry, did")#linebreak()#text(" so in a similar way.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10490")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2007")])]

#text("Dear All,")#linebreak()#text(" I would like to thank everybody for the amazingly deep posts")#linebreak()#text(" and comments about so many areas of mathematics. Having")#linebreak()#text(" this opportunity, I would like to ask for some advice on a well")#linebreak()#text(" known problem many scientists have struggled with, e.g.,")#linebreak()#text(" Stephen Wolfram. It has to do with the prediction of pattern")#linebreak()#text(" formation in nature, e.g., hexagonal ones in superconductors.")#linebreak()#text(" Our understanding of such phenomena may lead to better")#linebreak()#text(" communication, e.g., fast trains.")#linebreak()#text(" The question is: What area of pure mathematics would be best")#linebreak()#text(" suited for such research?")#linebreak()#text(" An example of what I have in mind is a very fast one in a recent")#linebreak()#text(" issue of ARMA:")#linebreak()#text(" Xinfu Chen and Y. Oshita, An application of the modular function")#linebreak()#text(" in nonlocal variational problems, Arch. Ration. Mech. Anal. 186")#linebreak()#text(" (2007), 109-132. Abstract: Using the modular function and its")#linebreak()#text(" invariance under the action of a modular group and an heuristic")#linebreak()#text(" reduction of a mathematical model, we present a mathematical")#linebreak()#text(" account of a hexagonal pattern selection observed in di-block")#linebreak()#text(" copolymer melts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tauber")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10585")[#strong[#text("Tauber")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2007")])]

#text("Some metaphysicists wrote a book about these issues:")#linebreak()#text(" R. Nadeau and M. Kafatos, The Non-Local Universe: The New")#linebreak()#text(" Physics and Matters of the Mind, Oxford University Press, 2001.")#linebreak()#text(" ps Blogs are wonderful, here is an interesting link:")#linebreak()#text(" ")#link("http://www.cnn.com/2007/WORLD/asiapcf/09/27/myanmar.dissidents/index.html")[#text("http://www.cnn.com/2007/WORLD/asiapcf/09/27/myanmar.dissidents/index.html")]#linebreak()#text(" about Ko Htike’s one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maud")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10633")[#strong[#text("Maud")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2007")])]

#text("Since this is both an open thread and a career advice thread, let me pose what I think is one of the hardest problems a beginning graduate student in math is faced with: How should one go about choosing an advisor? What factors are most important?")

#text("While everyone’s situation will be different, I’d bet that the general considerations are quite common. The student has a general idea of the area he/she would like to work in however is flexible/unsure within this area. Subject to this constraint he/she has a small list of faculty members, each in somewhat distinct areas of the field and each with his/her own basket of mixed qualities (big name but very busy, very approachable but hasn’t published a paper in several year, notoriously harsh on students but has a track record for training excellent students, track record as a good advisor but research in a related but different area, etc).")

#text("Obviously there is no formula and ‘the right thing to do’ will be dependent on the specific characteristics (of both the the potential advisers and student), which isn’t easily addressed in a generic blog entry. However, generally speaking, what considerations should one weigh most heavily?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of them-wmn")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10661")[#strong[#text("them-wmn")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2007")])]

#text("Dear Maud: I think a good advice is to first learn two languages")#linebreak()#text(" well, so that one’s name is not insultive to the community.")#linebreak()#text(" I had this experience with Cambridge – they rejected my application")#linebreak()#text(" for a participation in a workshop, even though I was a Marie Curie")#linebreak()#text(" Fellow in Britain at the time. An Australian expert thought that my")#linebreak()#text(" last name sounded Indian.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a7dbf0fc4f87d9dd7d9265b8d742254449560def99ea67f4a0bdffbedeff30-6357b353d4083e451e5adfb16009055f7689e1058db5dc6c29d9cb3641abf55b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Baez")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10750")[#strong[#text("John Baez")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2007")])]

#text("Dear Maud – I wrote ")#link("http://math.ucr.edu/home/baez/advice.html")[#text("some advice")]#text(" for young scientists, including how to choose an advisor. But, I’m sure Terry would have some interesting things to add.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Barute")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10762")[#strong[#text("Barute")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2007")])]

#text("Dear John Baez,")#linebreak()#text(" Your long advice has lots of interesting viewpoints, e.g., a quotation from")#linebreak()#text(" Grothendieck. However, to me an advisor is chosen for the purpose")#linebreak()#text(" of getting oneself into a specific research area. E.g., if I wanted to")#linebreak()#text(" work on the incompressible 3-D Euler equations, I would choose")#linebreak()#text(" a singular integrals expert. For an attack on the Riemann hypothesis,")#linebreak()#text(" I would learn functional analysis in graduate school. But such choices")#linebreak()#text(" are often a reflection of one’s past in high school. E.g., my favourite")#linebreak()#text(" pastime was doing a few integrals, rather than arithmetic and geometric problems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10775")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2007")])]

#text("Dear Maud,")

#text("Choosing an advisor depends on quite a lot of factors, including how compatible your personality and work habits are with your advisor’s. Subject area and expertise is important, of course, but I would recommend keeping an open mind about this; just because you came into grad school wanting to work on problem X doesn’t mean that you shouldn’t also look into other problems in adjacent fields, or even in very different fields. Taking graduate courses given by a potential advisor is a good way to gauge whether that advisor would be a good fit (and also has the benefit of introducing yourself to that advisor). If there are regular graduate student seminars in your fields of interest in which faculty and graduate students interact (e.g. the graduate students present papers) I would strongly recommend you participate in them. Looking up some papers or other research of potential advisors, and otherwise “doing your homework” (e.g. looking at how other students of that advisor have fared) would also be recommended.")

#text("On my own advice page, I have two brief essays on these topics – one is to make sure that your advisor is someone who you can really talk to on a regular basis. (In some cases, you will be talking more with an informal advisor than with your formal advisor, which is fine also; the point is that you should be able to talk about research and career issues to ")#emph[#text("someone")]#text(" more senior than yourself.) The other is that you should also be independently taking the initiative on these matters (e.g. looking for papers to read, conferences to attend, questions to ask, places to visit or apply to, etc.), though of course you should keep your advisor informed of your decisions in this regard.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10841")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2007")])]

#text("Dear Terry,")#linebreak()#text(" Due to the continuing vandalising of your blog, I suggest you")#linebreak()#text(" issue passes to people with academic employment, so that")#linebreak()#text(" they can post nonanonymously anytime. The rest could be")#linebreak()#text(" screened by you first. This method works quite well in interesting")#linebreak()#text(" news (from all over the world) discussions, in some countries.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Botong")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10929")[#strong[#text("Botong")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2007")])]

#text("Dear Terry,")

#text("I am a second year graduate student in math. When I was talking with professors and senior students about how to start my own research, I got different opinions. One is we should get well prepared before we go into a real problem — we need to be familiar with the basic language and tools in the area first. The other one is to find a problem first, and try to solve it, perhaps work together with adviser, and learn all the useful language and tools while attacking the problem. Both of them sound reasonable to me, I was wondering how to find a balance between them.")

#text("Can you give me some advice on this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-10934")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2007")])]

#text("Dear Botong,")

#text("To me, it seems that the best approach is to keep some big problems in mind as long-term goals, but focus in the short-term on easier model problems (or “dumb questions”) which lie just outside the range of what you currently know, and which therefore force you to learn more theory in order to tackle them. As you solve these “toy” problems and acquire more knowledge of your field, you will be able to better judge how feasible (or how interesting) your long-term research goals are, and to calibrate them.")

#text("I have several essays on ")#link("https://terrytao.wordpress.com/career-advice/")[#text("my career page")]#text(" about these topics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-11058")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2007")])]

#text("Dear All,")#linebreak()#text(" The proof of Riemann Hypothesis is of major interest to many")#linebreak()#text(" branches of science. At the current rate of progress, it may take")#linebreak()#text(" years to complete. Has anyone thought about establishing some")#linebreak()#text(" kind of collaborative effort, akin to the Manhattan Project?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chess")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-11084")[#strong[#text("Chess")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2007")])]

#text("I would like to congratulate Ben Green, our frequent contributor:")#linebreak()#text(" ")#link("http://www.ams.org/dynamic_archive/home-news.html#sastra-2007")[#text("http://www.ams.org/dynamic_archive/home-news.html#sastra-2007")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-11118")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2007")])]

#text("Dear Adam,")

#text("I think there is not enough of an overall plan of attack to make a concerted effort on the Riemann hypothesis an efficient use of mathematical talent. (This is in contrast to, say, the classification of finite simple groups, which did have a coherent vision that was able to successfully coordinate the effort of a hundred or so mathematicians.) On the other hand, I could imagine that the Langlands program could one day require a sustained collaborative effort.")

#text("My guess (based on very little data) is that any new breakthrough on RH would first require a breakthrough in some tangentially related problem (e.g., to pick an example at random, some breakthrough in our understanding of eigenfunctions on arithmetic surfaces), in order to introduce a new method or idea which may eventually impact RH. So a direct assault may not be the right way to proceed at this point.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-11119")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2007")])]

#text("Dear Terry,")#linebreak()#text(" I agree, though I heard that only one famous mathematician")#linebreak()#text(" is attacking the Langlands program seriously.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-11124")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2007")])]

#text("There was some mention about quarternions earlier today.")#linebreak()#text(" Curiously, Maxwell’s equations were originally written in")#linebreak()#text(" quarternion form, before they were modified by Oliver")#linebreak()#text(" Heaviside and William Gibbs into today’s most used")#linebreak()#text(" notation with vectors.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-11128")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2007")])]

#text("Dear Terry,")#linebreak()#text(" Now that the academic year started, I getting interested in")#linebreak()#text(" your work with Ben Green, however, I would like to ask:")#linebreak()#text(" where was van der Corput’s result on length 3 progressions")#linebreak()#text(" published, because in:")#linebreak()#text(" Green, Ben, Annals of Mathematics, 161 (2005), 1609-1636,")#linebreak()#text(" this work is not referenced.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-11163")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2007")])]

#text("Adam: please do not use ")#link("http://en.wikipedia.org/wiki/Sockpuppet_%28Internet%29")[#text("sockpuppets")]#text(" to create the illusion of dialogue. If you wish to discuss your own topics extensively, I suggest that you use your own personal web site or blog for this purpose.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam Chmaj")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-11164")[#strong[#text("Adam Chmaj")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2007")])]

#text("Dear Adam,")#linebreak()#text(" There are 3 fine books and some others giving an apprioprate")#linebreak()#text(" introduction to the quaternions. On amazon.com, this one was written")#linebreak()#text(" first, has five stars and is the cheapest:")#linebreak()#text(" Quaternions and Rotation Sequences: A Primer with Applications")#linebreak()#text(" to Orbits, Aerospace and Virtual Reality (Paperback), by J. B. Kuipers,")#linebreak()#text(" Princeton University Press (August 19, 2002).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam Chmaj")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-11187")[#strong[#text("Adam Chmaj")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2007")])]

#text("Dear All,")#linebreak()#text(" Going back to giving advice to young students, I think it is")#linebreak()#text(" best not to use any sophisticated doping, apart from coffee,")#linebreak()#text(" as to produce something truly original sometimes takes a lot of")#linebreak()#text(" time.")#linebreak()#text(" Dear Terry,")#linebreak()#text(" Going back to discussions about Perelman’s preprints, what do")#linebreak()#text(" you think about line (1.5.6) in “A complete proof of the Poincare")#linebreak()#text(" …”, Asian J. Math. Vol. 10, No.2 pp. 165-492, June 2006?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2efb0c48c300ac85418a28e50769f4acb7e7dbd355bd024980d8c38856df329e-b2f8eee0632622ac0a89a3caf17a4cc7a442777cf157044c8f5b381f83097de3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Evren")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-11224")[#strong[#text("Evren")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2007")])]

#text("Hello Terry,")

#text("I have a question about your answer to Botong, which was basically about making research in mathematics (learning theory by itself or get ourselves forced to learn theory to tackle a problem). If we wanted to learn theory as we tackle with toy problems, where should we find such toy problems? I mean, the problems in math journals are already too specialized to be understood by a beginner. By toy problems, did you mean that some hard problems in respected grad textbooks? If so, should we just open the exercises section of the book try out some problems than read the relevant text to solve the problem? Do you think that taking a text book reading it and solving the problems at the end of each section is a good way of learning?")

#text("THANKS!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-11265")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2007")])]

#text("Dear Evren,")

#text("I talk a bit about this in my essays “")#link("https://terrytao.wordpress.com/career-advice/ask-yourself-dumb-questions-%E2%80%93-and-answer-them/")[#text("asking yourself dumb questions")]#text("” and “")#link("https://terrytao.wordpress.com/career-advice/learn-and-relearn-your-field/")[#text("learn and relearn your field")]#text("“. Your advisor should also know what the good “toy” versions of various interesting problems are. And, of course, doing the exercises in textbooks is certainly an important aspect to learning a subject, which really can’t be substituted for.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3dd69011b3a595ce8f454297e61a9c3a44fc6ec7499e5d70efd8f93747baa9b2-2318dc883947966fc181563ec656bc618ed64b8a5b28c7bd72e4da97c0a46eec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ganesh Raghavan")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-11319")[#strong[#text("Ganesh Raghavan")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2007")])]

#text("Dear Dr Terry Tao-")

#text("I have an intuitive proof of Goldbach Conjecture that Iam pasting here. Can you provide your comments on this?")

#text("Thanks,")#linebreak()#text(" Ganesh Raghavan")

#text("“Let us consider an even number N. N is greater than 2. The following is the construct that goes to prove that an even number can be written as a sum of 2 primes.")

#text("1. From N, go back through (N-1), (N-2), etc till a prime number is encountered.")#linebreak()#text(" 2. The prime number encountered can be called P1 and is at a distance of (N-P1) from N. i.e P1=> (N-P1)")#linebreak()#text(" 3. The prime number P1 is at a distance P1 from 0")#linebreak()#text(" 4. From P1, go back till half of the number N is reached.")

#text("We now can have 2 cases")

#text("Case (i) Half of the number is even or odd but not prime")

#text("1. Find the difference between (N/2) and P1 and call it ∆")#linebreak()#text(" 2. ∆ = (N/2) – (N-P1) —– (1)")#linebreak()#text(" 3. With ∆ as radius from (N/2), draw a circle.")#linebreak()#text(" 4. If there is another prime at the same distance ∆ from (N/2), call it P2")#linebreak()#text(" 5. P2 = (P1-2∆) ——- (2)")#linebreak()#text(" 6. Equation (1) can be written in terms of N as")#linebreak()#text(" N = 2 (P1-∆) = P1-2∆+P1 ——- (3)")#linebreak()#text(" 7. Substituting (2) in (3) we get N.")#linebreak()#text(" N = P2 + P1")

#text("This means an even number can be written as a sum of 2 primes")

#text("If there is no prime at the same distance ∆ from (N/2), we do not consider P1 as prime but go back till we reach another prime number. Then we iterate steps 1 to 7 in Case (i)")

#text("Case (ii) Half of the number is prime")

#text("8. Find a prime number greater than half of the even number N")#linebreak()#text(" 9. Repeat steps 1 through 7 from Case (i)")#linebreak()#text(" 10. If there is no prime at the same distance ∆ from (N/2) which is smaller than (N/2), stop at (N/2) and call it as prime number P1")#linebreak()#text(" 11. From Equation (1) in Step 2, ∆ = 0")#linebreak()#text(" 12. From Equation (2) in Step 5, P2=P1=(N/2)")#linebreak()#text(" 13. Equation (3) says, the number N is then a sum of 2 same prime numbers (N/2)")

#text("Thus combining Case (i) and Case (ii), any even number, N > 2, can always be written as a sum of 2 primes”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-11362")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2007")])]

#text("I’m not Terrence Tao, but I don’t think there is any reason case (i) should terminate, i.e. it seems possible that you could go through all the primes and never be able to find your P2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3dd69011b3a595ce8f454297e61a9c3a44fc6ec7499e5d70efd8f93747baa9b2-2318dc883947966fc181563ec656bc618ed64b8a5b28c7bd72e4da97c0a46eec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ganesh Raghavan")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-11474")[#strong[#text("Ganesh Raghavan")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2007")])]

#text("Ben Green, together with Terence Tao have proved that, given any number n, there are infinitely many sequences consisting of exactly n evenly spaced primes. This can be invoked to prove that we will always be able to find P2")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-11504")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2007")])]

#text("Dear Ganesh,")

#text("Unfortunately my theorem with Ben is not a magic wand; we do provide infinitely many arithmetic progressions of primes, but these progressions need not be placed where one would desire them to be. Sometimes, even having infinitely many of a given object is not enough. (For instance, there are infinitely many even numbers, but one still cannot write an odd number as the sum of two even numbers, because the even numbers are placed in an unfavourable location for this task.)")

#text("However, if one applies the heuristic that the primes are distributed “randomly”, then (as was first done by Hardy and Littlewood), one can use probabilistic arguments to provide a fairly convincing case (though definitely not a rigorous proof) that the Goldbach conjecture should be true for all sufficiently large even integers (see e.g. ")#link("http://en.wikipedia.org/wiki/Goldbach_conjecture")[#text("the Wikipedia page on the conjecture")]#text(" for a discussion). Unfortunately we do not have enough control on the (pseudo)-randomness of the primes to make this heuristic argument precise yet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of freshman")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-11655")[#strong[#text("freshman")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2007")])]

#text("My teachers told me that the concepts of the maths are important.But I don’t accept this teaching method.The college students may have a new way of studying.Would you like to give me some advice?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf445dd3ded972a5d1b62126dac2900bf47db6c85c39b95626f92b945e4f092-821d2a67ec2aa6fd2150e7112d80a9cf9bad4da7b90b8dab1f324d9a6a89f5c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-11843")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2007")])]

#text("Conversely:")

#text("A131741 a(n) is least prime (not already in list) such that no 3-term subset forms an arithmetic progression.")

#text("2, 3, 5, 11, 13, 29, 31, 37, 41, 67, 73, 83, 89, 101, 107, 127, 139, 157, 179, 193, 227, 233, 263, 271, 281, 307, 331, 337, 379, 389, 397, 401, 409, 431, 433, 467, 491, 499, 509, 563, 571, 613, 641, 647, 743, 769, 809, 823, 883, 887, 907, 937, 983, 1009, 1021")

#text("COMMENT")#linebreak()#text(" a(n) is the smallest prime such that there is no i < j < n with a(n) – a(j) = a(j) – a(i).")

#text("EXAMPLE")

#text("Table showing derivation of first 10 values.")

#text("n a(n) comment")

#text("1 2")

#text("2 3")

#text("3 5")

#text("4 11 a(4) can’t be 7 because (3,5,7) is in arithmetic progression.")

#text("5 13")

#text("6 29 can’t be 17 because (5,11,17); can’t be 19 because (3,11,19); can’t be 23 because (3,13,23)")

#text("7 31")

#text("8 37")

#text("9 41")

#text("10 67 not 43 as (31,37,43); not 47 as (11,29,47); not 53 as (29,41,53); not 59 as (13,31,59); not 61 as (13,37,61)")

#text("MATHEMATICA")#linebreak()#text(" f[l_List] := Block[{c, f = 0}, c = If[l == {}, 0, l[[ -1]]]; While[f == 0, c = NextPrime[c]; If[Intersection[l, l – (c – l)] == {}, f = 1]; ]; Append[l, c] ]; Nest[f, {}, 100]")

#text("CROSSREFS")#linebreak()#text(" Cf. A000040, A065825.")

#text("KEYWORD")#linebreak()#text(" easy,nonn,new")

#text("AUTHOR")#linebreak()#text(" Jonathan Vos Post (jvospost2(AT)yahoo.com), Oct 04 2007")

#text("EXTENSIONS")#linebreak()#text(" More terms and program from Ray Chandler .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gordon")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-20678")[#strong[#text("Gordon")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2007")])]

#text("Dear Adam,")#linebreak()#text(" Quaternions could be helpful in the proof of the RH")#linebreak()#text(" – this is the approach Louis de Branges is counting on")#linebreak()#text(" (see the Apologies and other preprints on his website).")#linebreak()#text(" However, Brian Conrey doesn’t think much of this approach:")#linebreak()#text(" ")#link("http://www.lrb.co.uk/v26/n14/sabb01_.html")[#text("http://www.lrb.co.uk/v26/n14/sabb01_.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-20808")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2007")])]

#text("Dear Gordon,")#linebreak()#text(" Lehmer’s phenomenon is a typical lack of structural stability.")#linebreak()#text(" There are nonlinear toy models which behave this way – they")#linebreak()#text(" were successfully handled not only by complex embedding,")#linebreak()#text(" but also by combinatorial argumentation – this is what Conrey")#linebreak()#text(" suggested for the proof of the RH. The calculation would surely")#linebreak()#text(" have to be massive.")#linebreak()#text(" ps “If I were to awaken after having slept for a thousand")#linebreak()#text(" years, my first question would be: has the Riemann hypothesis")#linebreak()#text(" been proven?” – David Hilbert.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30f5f5b708869d51a70100074fec26fa0586b19945e0ebcf14303897137b39cf-c4afe6ef2df290e6c8248924761c87a0e9f374230c23329fcdeca914eb0b289e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miltos")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-25738")[#strong[#text("Miltos")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Cool…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91841f5e59201923e09be98a5cf5917591fef164a2a040b79e78d927874dd4bf-c2c4379bfc95793e545279b1b6a44f80c80394352dfb8cc2ea2a9f97264ce0e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of puzzled")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-27546")[#strong[#text("puzzled")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2008")])]

#text("Okay, I give up on ")#link("http://www.math.ucla.edu/%7Etao/resource/general/131ah.1.03w/missing.gif")[#text("this")]#text(".")

#text("It’s already paradoxical if you look at only one of the triangles, e.g. the top one: if you calculate the area using the formula A=(1/2)bh, you get 32.5; whereas if you add the areas of the subregions you get 32.")

#text("What in the world am I missing?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-27549")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2008")])]

#text("puzzled, the problem is that the triangles don’t quite have the same slope. The greenish one has a slope of 2/5, while the red one has a slope of 3/8.")

#text("Since 3/8 is just slightly lower than 2/5, the upper “triangle” actually has a very slight dent in its hypotenuse, while the lower one has a very slight bulge. The difference between the dent and the bulge amounts to exactly one square.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b73aa9c4d78a8073b2fc2a70e1a0fb54b9278db943cc11ebaa85b64db92fd73-4756c5eed22126a3e8ffb00f136624d0e19401c6ef769df9809395af1f522629.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dick Boland")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-27770")[#strong[#text("Dick Boland")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2008")])]

#text("Dear Terry,")

#text("I have read your advice blogs on writing and submitting papers and I take them to heart. I have been working on a paper and went back and wrote a detailed introduction and I can see that the structure needs some work – thank you. I have read the career advice on your site with great interest. I saw somewhere, a comment from somebody giving you kudos for a comment you apparently made regarding ‘the dangers of self-study’ or the like. I am certainly interested in anything you have to say about this, but could not find the referenced comment.")

#text("I also wanted to ask for your thoughts on a situation which is best described as hypothetical, though the veil is extremely thin. Assume there is an amateur mathematician who only discovered his gifts and passions for math latently. But, he is a working stiff with no resources, friends or contact with the mathematical community or academia. Early on, in his self discovery and road to mathematical maturity, he makes some mistakes and a couple of claims, which he does retract – the point being, he learns and matures via the only option open to him, that being self-study. He stumbles, but never becomes a flamer or a crank, and in fact becomes afraid to say anything at all. Fast-forward a few years and here is this guy who doesn’t know much except how much he doesn’t know, but he has kept on spear-heading into his areas of interest because he his helplessly compelled to do so, related in part to a disability which also affects his abilities for ‘human social communication’, something like Asperger’s Syndrome say. Now say, again hypothetically, this guy makes a couple of breakthroughs and wants to publish and seek to find a way to go back to school and pursue a proper education and career as a research mathematician.")

#text("If such a person actually exists and actually ‘has the stuff’ and the motivation, and now has results that prove that contention, what is the best way to proceed toward the goal of breaking through? It seems obvious that he should publish, but let’s say the results could be taken much farther in the hands of a ‘pro’, turning a remarkable amateur paper into a seminal paper for the times. So, perhaps he wants to make friends with a ‘pro’ for co-authoring, or a transmitted by, or at least a reality check. Part of the appeal of this approach is that there are some pieces of advice on writing papers that are impossible for this fellow to follow, such as referencing all the current work and giving the proper acknowledgments, not to mention an inability to produce a paper that doesn’t have ‘amateur’ written all over it. He can submit what he has on his own, and it is good, let’s say, but still incomplete in many regards and he fears, whether accepted or not, he will be left in the dust anyway.")

#text("He also fears that all amateur papers are summarily dismissed and that no one in the mathematical community actually believes his existence is possible. Due to his status and communication problems, and despite the warm-hearted, welcoming, outreaching, forgiving, friendly hand of hope, encouragement and universal love that every mathematician is famous for, he can’t seem to make enough of a connection to simply get advice on the best way to proceed, much less anyone to have a look, much less anyone to help, yet he has learned enough to know that what he has discovered is original and important, a claim which only increases the ‘scoff’ factor. What advice would you have for this poor, tortured, hypothetical soul?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-27806")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2008")])]

#text("Dear Dick,")

#text("Pretty much the only way to get the level of experience and familiarity with modern mathematics (and its attendant literature, folklore, culture, etc.) needed to publish quality mathematical research is to go through graduate school (or at least an honours undergraduate program). It is not unheard of to have mature students attend and complete a Ph.D. in mathematics; I know of one person, for instance, who left graduate school to pursue a business career, but then return two decades later to finish the Ph.D.")

#text("I should note, though, that writing papers is only one aspect of mathematical research; for instance, a large portion of one’s research time as a graduate student tends to be devoted to hunting down and reading books and papers (or listening to talks and seminars) and working out countless minor technical issues with what one learns from these sources. It can be a fair amount of work at times, and not particularly glamorous, but it is rather essential to getting a full and deep understanding of one’s field.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b73aa9c4d78a8073b2fc2a70e1a0fb54b9278db943cc11ebaa85b64db92fd73-4756c5eed22126a3e8ffb00f136624d0e19401c6ef769df9809395af1f522629.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dick Boland")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-27819")[#strong[#text("Dick Boland")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2008")])]

#text("Thanks Terry,")

#text("I appreciate your blog and taking the time to pen your thoughts. I do believe our mature friend understands what you have said implicitly. If he has important results that should be on the books irrespective of his formal education and wants them to serve as demonstration of merit toward justifying financial support to acquire a formal education (because it is the only conceivably feasible option to acquire said financing), but he can’t publish without the formal education, what should he do with the results?")

#text("Regards,")

#text("Dick Boland")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80a682ba444ce31d22048eda216bc051719be0745d10ddae25e6f9c90da1898a-9edb2b0f4e46c49a11ac8e62667add541392e540496fdc854dce650bbc5aa33b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Beetle B.")]], [#link("https://terrytao.wordpress.com/2007/09/21/another-advice-page-and-an-open-thread/comment-page-1/#comment-30283")[#strong[#text("Beetle B.")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2008")])]

#text("Hi Terry,")

#text("I was just wondering if it would be possible for you to have per-category (or per-tag) feeds. I know this is possible with the WordPress software – either in the Settings or via a plugin – not sure about wordpress.com.")

#text("It would be immensely useful. Some people may only want to read just your opinion, expository and/or non-technical posts…")

#text("Thanks.")
]
