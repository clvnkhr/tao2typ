// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/01/11/distinguished-lecture-series-ii-avi-wigderson-expander-graphs-constructions-and-applications/
// Converted to Typst by tao2typ: "2026-10-14T11:26:15.668992+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Distinguished Lecture Series II: Avi Wigderson, “Expander graphs – constructions and applications”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Distinguished Lecture Series II: Avi Wigderson, “Expander graphs – constructions and applications”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 January 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/01/11/distinguished-lecture-series-ii-avi-wigderson-expander-graphs-constructions-and-applications/")[#text("https://terrytao.wordpress.com/2008/01/11/distinguished-lecture-series-ii-avi-wigderson-expander-graphs-constructions-and-applications/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("On Thursday, ")#link("http://en.wikipedia.org/wiki/Avi_Wigderson")[#text("Avi Wigderson")]#text(" continued his ")#link("http://www.math.ucla.edu/dls/index.html")[#text("Distinguished Lecture Series")]#text(" here at UCLA on ")#link("http://www.math.ucla.edu/dls/2008/aw.html")[#text("computational complexity")]#text(" with his second lecture “")#link("http://www.math.ucla.edu/dls/2008/absaw2.html")[#text("Expander Graphs – Constructions and Applications")]#text("“. As in the ")#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/")[#text("previous lecture")]#text(", he spent some additional time after the talk on an “encore”, which in this case was how lossless ")#link("http://en.wikipedia.org/wiki/Expander_graph")[#text("expanders")]#text(" could be used to obtain rapidly decodable ")#link("http://en.wikipedia.org/wiki/Error_detection_and_correction")[#text("error-correcting codes")]#text(".")

#text("The talk was largely based on ")#link("http://www.math.ucla.edu/dls/2008/zigzag.pdf")[#text("these slides")]#text(". Avi also has a ")#link("http://www.math.ias.edu/~avi/BOOKS/expanderbookr1.pdf")[#text("recent monograph")]#text(" with Hoory and Linial on these topics. (For a brief introduction to expanders, I can also recommend Peter Sarnak’s ")#link("http://www.ams.org/notices/200407/what-is.pdf")[#text("Notices article")]#text(". I also mention expanders to some extent in my ")#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/")[#text("third Milliman lecture")]#text(".)")

#metadata(none) <tao-68d00fce3e9406b991cb>

#heading(level: 1)[#text("— What is an expander? —")]

#link("http://en.wikipedia.org/wiki/Expander_graph")[#text("Expander graph")]#text(" are ")#link("http://en.wikipedia.org/wiki/Sparse_graph")[#text("sparse graphs")]#text(" with an additional special property. This property can be described in several equivalent ways (combinatorial, probabilistic, or algebraic):")

#enum(start: 1, 
[#strong[#text("Connectivity")]#text(". Expander graphs are ")#link("http://en.wikipedia.org/wiki/Sparse_graph")[#text("sparse")]#text(" but highly ")#link("http://en.wikipedia.org/wiki/Connectivity_%28graph_theory%29")[#text("connected")]#text("; any two disjoint sets of vertices cannot be disconnected from each other without removing a lot of edges (i.e. the ")#link("http://en.wikipedia.org/wiki/Cut_(graph_theory)")[#text("sparsest cut")]#text(" between the sets is quite large). Equivalently, any proper subset A of vertices is going to have a large boundary ")#mi("\\partial A")#text(", defined as the vertices which are not in A but are adjacent to a vertex in A.")],
[#strong[#text("Mixing")]#text(". A ")#link("http://en.wikipedia.org/wiki/Random_walk")[#text("random walk")]#text(" on an expander graph converges very rapidly to the ")#link("http://en.wikipedia.org/wiki/Uniform_distribution_%28discrete%29")[#text("uniform distribution")]#text(".")],
[#strong[#text("Spectral gap")]#text(". The second ")#link("http://en.wikipedia.org/wiki/Eigenvalue")[#text("eigenvalue")]#text(" of the ")#link("http://en.wikipedia.org/wiki/Adjacency_matrix")[#text("adjacency matrix")]#text(" is significantly smaller than the (typical) ")#link("http://en.wikipedia.org/wiki/Degree_%28graph_theory%29")[#text("degree")]#text(" of the graph.")]
)

#text("For sake of concreteness, Avi used the spectral gap formulation of expansion:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition")]#text(". A ")#mi("{}[n,d]")#emph[#text("-graph")]#text(" is a graph G on n vertices which is d-")#link("http://en.wikipedia.org/wiki/Regular_graph")[#text("regular")]#text(", i.e. every vertex has d edges connected to it. A ")#emph[#mi("{}[n,d,\\alpha]")#text("-graph")]#text(" is an ")#mi("{}[n,d]")#text("-graph which has the additional property")

#align(center)[#tao-fit-display[#tao-math("\\left\\| A(G) v \\right\\| \\leq d \\alpha \\left\\|v\\right\\|", block: true)]]

#text("for all non-zero vectors ")#mi("v \\in {\\Bbb R}^n")#text(" whose coordinates sum to zero, where A(G) is the ")#link("http://en.wikipedia.org/wiki/Adjacency_matrix")[#text("adjacency matrix")]#text(" of G and ")#tao-math("\\left\\|v\\right\\|", block: false)#text(" is the ")#link("http://en.wikipedia.org/wiki/Euclidean_space")[#text("Euclidean norm")]#text(" of v.")

#text("A family of graphs ")#mi("G_1, G_2, G_3, \\ldots")#text(" of d-regular graphs (thus each ")#mi("G_i")#text(" is an ")#mi("{}[n_i,d]")#text("-graph for some ")#mi("n_i")#text(") forms an ")#emph[#text("expander family")]#text(" if each ")#mi("G_i")#text(" is a ")#mi("{}[n_i,d,\\alpha]")#text(" graph for some ")#mi("0 < \\alpha < 1")#text(".")
]

#text("The above definition was a bit technical, but it can be clarified a bit by considering an example of a graph which is definitely not an expander. Consider an ")#mi("{}[n,d]")#text("-graph G which is disconnected, with the n vertices divided into two disjoint sets A and B of n/2 vertices each, with no edge between A and B. Then if one lets v be the vector which is +1 on A and -1 on B (so that the total sum of coefficients is zero), one can check that ")#tao-math("\\left\\|Av\\right\\| = d \\left\\|v\\right\\|", block: false)#text(", so G is not an ")#mi("{}[n,d,\\alpha]")#text("-graph for any ")#mi("\\alpha < 1")#text(". More generally, it is an instructive exercise to show that an ")#mi("{}[n,d]")#text("-graph is always a ")#mi("{}[n,d,1]")#text("-graph, but is only an ")#mi("{}[n,d,\\alpha]")#text("-graph for some ")#mi("\\alpha < 1")#text(" if and only if it is connected. Thus the notion of an expander family can be viewed as a quantitative variant of connectivity.")

#text("[A technical point: strictly speaking, the adjective “expander” applies in a meaningful manner to families of graphs, rather than to individual graphs, much as the adjective “bounded” is meaningful when applied to sequences of numbers, but not to individual numbers. Applying the expander notion to a single graph is a bit silly since a single graph forms an expander family if and only if it is connected. Nevertheless, it is common when discussing expanders to refer to an “expander graph” in the singular, especially when considering a graph whose number of vertices n is quite large and depends implicitly on some other parameter (e.g. a large prime p). Amusingly, one could avoid any abuse of notation by resorting to ")#link("http://en.wikipedia.org/wiki/Non-standard_analysis")[#text("non-standard analysis")]#text(", redefining an expander graph to be a graph with a non-standard number of vertices n, but which is an ")#mi("{}[n,d,\\alpha]")#text("-graph for some standard d and ")#mi("\\alpha < 1")#text(", but this does not seem to significantly simplify or clarify the theory.]")

#text("Expanders have various important combinatorial and probabilistic properties. For instance, if G is an ")#mi("{}[n,d,\\alpha]")#text("-graph, and the n vertices of G are partitioned into two sets A and B, then the number of edges e(A,B) connecting A to B can be easily seen to be bounded below by the inequality")

#align(center)[#tao-math("e(A,B) \\geq \\frac{1-\\alpha}{2} d \\min( \\left|A\\right|, \\left|B\\right| )", block: false)#text(".")]

#text("Conversely, the ")#emph[#text("discrete Cheeger inequality")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1003059")[#text("of Jerrum and Sinclair")]#text(" asserts that if a ")#mi("{}[n,d]")#text("-graph is such that")

#align(center)[#tao-fit-display[#tao-math("e(A,B) \\geq \\sqrt{2(1-\\alpha)} d \\min(\\left|A\\right|, \\left|B\\right| )", block: true)]]

#text("for all partitions A, B, then the graph is an ")#mi("{}[n,d,\\alpha]")#text("-graph. (Another closely related result is the ")#link("http://en.wikipedia.org/wiki/Expander_mixing_lemma")[#text("expander mixing lemma")]#text(".)")

#text("One can also show that a random walk on k steps in a ")#mi("{}[n,d,\\alpha]")#text("-graph (starting at an arbitrary base point) converges exponentially fast in k to the uniform distribution (with constants depending on d and ")#mi("\\alpha")#text(" but not n); informally, the random walk becomes very close to uniform after about ")#mi("O(\\log n)")#text(" steps; a more precise statement can be ")#link("http://en.wikipedia.org/wiki/Expander_walk_sampling")[#text("found here")]#text(". [You may have heard of the famous ")#link("http://www.ams.org/mathscinet-getitem?mr=1161056")[#text("result of Bayer and Diaconis")]#text(" that a deck of cards can be perfectly shuffled after just seven riffle shuffles; to oversimplify a bit, that claim is equivalent to asserting an expander property of the ")#link("http://en.wikipedia.org/wiki/Cayley_graph")[#text("Cayley graph")]#text(" whose vertices are deck configurations, with two vertices connected if one is a riffle shuffle of another.]")

#text("Expanders have many applications, most obviously in graph theory, but also in computer science, number theory, group theory, and even to such apparently unrelated topics as the ")#link("http://en.wikipedia.org/wiki/Baum%E2%80%93Connes_conjecture")[#text("Baum-Connes conjecture")]#text(" in K-theory, which also has connections to topology, though Avi focused primarily on the computer science applications in this talk. Just to give one simple example of such an application, he discussed deterministic amplification of probabilistic algorithms. Suppose one had an algorithm ")#mi("A(i, r)")#text(" which took some input i and some n-bit stream (or “coin flips”) ")#mi("r \\in \\{0,1\\}^n")#text(" and returned an output A(i,r), which is a single bit (yes or no). Suppose that for a given input i, this algorithm was correct for (say) 2/3 of the possible bit streams r; thus if we select the n bits of r randomly the algorithm has at most a 1/3 probability of failure.")

#text("As discussed in the ")#link("https://terrytao.wordpress.com/2008/01/10/distinguished-lecture-series-i-avi-wigderson-the-power-and-weakness-of-randomness-in-computation/")[#text("previous lecture")]#text(", one can reduce the failure probability by iteration. If one selects k independent random bit streams ")#mi("r_1,\\ldots,r_k \\in \\{0,1\\}^n")#text(", and runs the algorithm A once for each such stream, and then takes the majority vote of the k different outcomes, then a simple application of the ")#link("http://en.wikipedia.org/wiki/Chernoff_bound")[#text("Chernoff bound")]#text(" shows that the resulting algorithm has a failure probability which is exponentially small (")#mi("O( \\exp(-ck) )")#text(" for some absolute constant c > 0). But this iterated algorithm requires one to generate kn independent random bits. In some applications, high-quality random bits are an expensive resource, and so it is natural to ask whether one can obtain an algorithm with similar performance but requiring many fewer random bits. It turns out that one can, simply by selecting ")#mi("r_1,\\ldots,r_k")#text(" not independently, but by selecting ")#mi("r_1,r_2, r_3, \\ldots, r_k")#text(" in turn by a random walk along a bounded-degree expander graph on ")#mi("\\{0,1\\}^n")#text(" beginning at a random vertex, and then performing a majority vote. The mixing properties of random walk can be used to give the same type of exponentially small failure probability as before, but now only ")#mi("n + O(k)")#text(" random bits are needed (each step of the random walk requires O(1) random bits, to decide which edge to go down.)")

#text("In order for the above algorithm to work properly, one needs to construct expanders explicitly – so explicitly that given any vertex in the expander, one can quickly compute all the neighbours. This was Avi’s next topic.")

#heading(level: 1)[#text("— Constructions of expanders —")]

#text("A simple counting argument of ")#link("http://en.wikipedia.org/wiki/Mark_Semenovich_Pinsker")[#text("Pinsker")]#text(" shows that expanders exist in abundance; indeed, a random sequence of [n,d]-graphs (with ")#mi("d \\geq 3")#text(" fixed and n going to infinity) is almost surely going to be an expander family. But for many applications, one needs more deterministic expanders.")

#text("The first explicit expander families arose from group theory (as given by ")#link("http://www.ams.org/mathscinet-getitem?mr=484767")[#text("Margulis")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=633542")[#text("Gabber-Galil")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=782626")[#text("Alon-Milman")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=963118")[#text("Lubotsky-Phillips-Sarnak")]#text(", and others); a typical example of such a family are the ")#link("http://en.wikipedia.org/wiki/Cayley_graph")[#text("Cayley graphs")]#text(" whose vertices are the special linear group ")#mi("SL_2({\\Bbb F}_p)")#text(" over a large field of prime order p, with the edges given by the set of generators")

#align(center)[#tao-fit-display[#mitex("S := \\{\\begin{pmatrix} 1 & 1 \\\\ 0 & 1 \\end{pmatrix},\\begin{pmatrix} 1 & 0 \\\\ 1 & 1 \\end{pmatrix} \\}")]]

#text("(thus two matrices in ")#mi("SL_2({\\Bbb F}_p)")#text(" are connected by a graph if their quotient is either in S, or is an inverse of an element in S.) The expansion of these algebraic graph families is deeply connected to some non-trivial results in group theory and analytic number theory; in this case, the key property is ")#link("http://www.ams.org/mathscinet-getitem?mr=182610")[#text("Selberg’s famous 3/16 theorem")]#text(" on the least eigenvalue of the ")#link("http://en.wikipedia.org/wiki/Laplace_operator")[#text("Laplacian")]#text(" on ")#link("http://en.wikipedia.org/wiki/Modular_curve")[#text("modular curves")]#text(".")

#text("These algebraic constructions can be made extremely tight in the sense that the spectral gap parameter ")#mi("\\alpha")#text(" can be made optimally small. More precisely, there is the ")#link("http://www.ams.org/mathscinet-getitem?mr=905147")[#text("Alon-Boppana")]#text(" bound, which asserts that an ")#mi("{}[n,d,\\alpha]")#text("-graph can only exist if ")#mi("d\\alpha \\geq 2\\sqrt{d-1}")#text(". Graphs which attain this bound are known as ")#link("http://en.wikipedia.org/wiki/Ramanujan_graph")[#text("Ramanujan graphs")]#text(", and were first constructed by Lubotsky-Phillips-Sarnak and Margulis by algebraic methods. (Random graphs come quite close to being Ramanujan, but are off by a slight amount.)")

#text("More recently, starting with the ")#link("http://www.ams.org/mathscinet-getitem?mr=1888797")[#text("work of Reingold, Vadhan, and Wigderson")]#text(", more explicitly combinatorial constructions of expanders have been given. A fundamental building block in such constructions is the ")#emph[#text("zigzag product")]#text(" ")#mi("G \\text{ⓩ} H")#text(" of a ")#mi("{}[n,m]")#text("-graph G and a ")#mi("{}[m,d]")#text("-graph H (thus H is small compared with G – the number of vertices of H equals the degree of G). The zigzag product is to graphs as the ")#link("http://en.wikipedia.org/wiki/Semidirect_product")[#text("semi-direct product")]#text(" is to groups (and in fact, this connection can be made very precise, as the semi-direct product can be viewed as the specialisation of the zigzag product to Cayley graphs). Roughly speaking, the zigzag product is defined by “blowing up” each vertex of G into a copy of H, and then decoupling the edges in G to become disjoint. A bit more formally, if we let V and W be the vertex sets of G and H respectively, then we let ")#mi("G \\text{ⓩ} H")#text(" be the ")#mi("{}[nm, d+1]")#text("-graph with vertex sets V, and whose edge set consists of the “local” edges of form (a,x) and (a,y) where a lies in V and x,y form an edge in W, together with one “global” edge of the form (a,x), (b,y) for each edge (a,b) in G, where x and y depend on a and b and are chosen so that all the global edges are disjoint from each other (this can be done for instance by the greedy algorithm). [Note that there is a little bit of freedom in this construction, so that the zigzag product is not quite unique, but this is not a concern in applications, as all the zigzag products of two graphs have much the same expansion properties.]")

#text("The key fact about zigzag products is that they preserve expansion: the zigzag product ")#mi("G_i \\text{ⓩ} H_i")#text(" of two expander families ")#mi("G_i")#text(" and ")#mi("H_i")#text(" is another expander family. (With a slight variant of the zigzag product, one can give a simple and explicit relation between the various spectral parameters here.) On the other hand, zigzag products also keep the degree d of the graph quite small, even if the first factor G has large degree. Because of this, it is possible to iterate the zigzag product (particularly in conjunction with the exponentiation operation ")#mi("G^r")#text(", which replaces a graph G with a new graph (or ")#link("http://en.wikipedia.org/wiki/Multigraph")[#text("multigraph")]#text(") on the same vertex set whose adjacency matrix ")#mi("A(G^r) = A(G)^r")#text(" is the ")#mi("r^{th}")#text(" power of the original adjacency matrix A(G)) to create many new families of explicit expanders, with good expansion properties compared to their degree; I’ll omit the details here but they are covered in detail in ")#link("http://www.math.ias.edu/~avi/TALKS/comb+algebra.ppt")[#text("Avi’s slides")]#text(".")

#text("The zigzag construction is very flexible and robust, and can be tweaked in a large number of ways to create expander graphs with certain additional combinatorial properties – which are often not attainable with the earlier algebraic constructions, or even for the Ramanujan graphs (which are optimal with respect to the spectral parameter ")#mi("\\alpha")#text(", but not necessarily with respect to more combinatorial parameters). For example, suppose one wants to find an [n,d] graph with the connectivity property that every pair of vertex sets of size at least n/a are connected by at least one edge, where a is a fixed large constant. This is easy to do for large d; the challenge is to get d as small as possible. For Ramanujan graphs, d needs to be as large as ")#mi("a^2")#text(" or so to obtain this property; in contrast, for random [n,d]-graphs, d can be as small as about ")#mi("a \\log a")#text(". It is not known how to achieve this deterministically, but using zigzag products (not on expanders ")#emph[#text("per se")]#text(", but on a related object known as an ")#link("http://en.wikipedia.org/wiki/Extractor")[#text("extractor")]#text(") one can get within a few logarithmic factors of this bound.")

#text("One can also combine the zigzag construction with algebraic constructions, for instance to create expander Cayley graphs in very general classes of finite groups, though Avi didn’t go into details on this point.")

#text("Another place where zigzag constructions have been useful is in lossless expanders. Observe that in an [n,d] graph, the neighbourhood of a k-vertex set can have size at most dk. A lossless expander is an [n,d]-graph (or more precisely, a expander family of such graphs) with the property that for any ")#mi("\\varepsilon > 0")#text(" there exists an a such that every k-vertex set with ")#mi("k \\leq n/a")#text(" has a neighbourhood of size at least ")#mi("(1-\\varepsilon) dk")#text("; thus small sets expand nearly as much as possible. Ramanujan graphs don’t always have this property; no matter how large one makes a, one can find such graphs in which the neighbourhood of a k-element set is only about dk/2 or so. But by using the zigzag construction (this time to a type of graph known as a ")#emph[#text("randomness conductor")]#text(") one can create lossless expanders.")

#text("One particularly striking recent application of the zig-zag product construction (")#link("http://www.wisdom.weizmann.ac.il/~reingold/publications/sl.ps")[#text("by Reingold")]#text(") is to create a ")#emph[#text("deterministic")]#text(" algorithm to solve the maze exploration problem mentioned in the previous lecture (getting from A to B in some large connected graph) in polynomial time and logarithmic space. Roughly speaking, the idea is to first observe that ")#emph[#text("any ")]#text("connected graph G (let’s take it to be an [n,d]-graph for simplicity) has a very weak expansion property; it is an ")#mi("{}[n,d,\\alpha]")#text("-graph for some ")#mi("\\alpha")#text(" a little bit less than 1 (e.g. ")#mi("\\alpha = 1-1/n^3")#text(" will do). This is not enough expansion by itself to do much of anything, but by taking graph powers and zigzag products of G with itself (and with a small expander), one can soon create a polynomially larger graph G’ which has a very good expansion constant, so much so that one can get from any point in G’ to any other by traversing a path of logarithmic length (and one can simply exhaust over all such paths in polynomial time and logarithmic memory). Finally, because the zigzag product is so combinatorially simple and explicit, it is possible to use the solution to the G’ exploration problem to obtain a solution to the G exploration problem with comparable time and memory costs.")

#text("— Lossless expanders and error-correcting codes —")

#text("Avi then talked about how lossless expanders can be used to produce quickly decodable ")#link("http://en.wikipedia.org/wiki/Forward_error_correction")[#text("error-correcting codes")]#text(" (and it is crucial here that the expander is lossless; graphs that only expand from k to dk/2 will not work for this application). Mathematically, a ")#link("http://en.wikipedia.org/wiki/Block_code")[#text("code")]#text(" for the purposes of this talk is a function ")#mi("C: \\{0,1\\}^k \\to \\{0,1\\}^n")#text(" that makes k-bit strings into larger n-bit strings in an injective manner. Actually, for the purposes of this analysis, the actual function is not important; what is important is the list of codewords ")#mi("C(\\{0,1\\}^k)")#text(" (which is often identified with C in this subject, by abuse of notation). There are many important statistics of codes, but two particularly key ones are the ")#emph[#text("rate")]#text(" k/n, and the ")#emph[#text("distance")]#text(", defined as the minimal separation (in the ")#link("http://en.wikipedia.org/wiki/Hamming_distance")[#text("Hamming metric")]#text(") between two codewords. Note that an error correcting code can (in principle) absorb a number of errors equal to half the distance, although in practice it may be computationally expensive to perform this correction.")

#text("Let us informally say that a code is ")#emph[#text("good")]#text(" if the rate is comparable to 1, and if the distance is comparable to n. It was shown by Shannon that good codes exist, indeed a randomly selected code is likely to be rather good. On the other hand, it is not possible to perform error correction on a random code quickly.")

#text("One particularly popular type of code is a ")#link("http://en.wikipedia.org/wiki/Linear_code")[#text("linear code")]#text(", in which C is a linear function (identifying ")#mi("\\{0,1\\} \\equiv {\\Bbb F}_2")#text(" with the field of two elements). The image ")#mi("C(\\{0,1\\}^k)")#text(" of such a code is thus a linear subspace in ")#mi("\\{0,1\\}^n \\equiv {\\Bbb F}_2^n")#text(", and thus can be defined as the simultaneous ")#link("http://en.wikipedia.org/wiki/Kernel_%28matrix%29")[#text("null space")]#text(" of n-k ")#link("http://en.wikipedia.org/wiki/Linear_functional")[#text("linear functionals")]#text(" on this space, which can be viewed as ")#link("http://en.wikipedia.org/wiki/Checksum")[#text("checksums")]#text(" or ")#link("http://en.wikipedia.org/wiki/Parity_bit")[#text("parity bits")]#text(" that need to vanish in order for a given word to lie in the code. Over ")#mi("{\\Bbb F}_2")#text(", a linear functional on the Hamming cube ")#mi("\\{0,1\\}^n \\equiv {\\Bbb F}_2^n")#text(" is nothing more than the sum of some collection of the coordinate functions on that cube. Thus one can describe the code C (or more precisely, its image ")#mi("C(\\{0,1\\}^n)")#text(") by a ")#link("http://en.wikipedia.org/wiki/Bipartite_graph")[#text("bipartite")]#text(" graph connecting the n coordinates with the n-k parity bits, with each parity bit being formed as the sum of the coordinates it is connected to.")

#text("With linear codes, encoding is a relatively quick process; the challenge is in decoding in the presence of errors. Remarkably, if one selects the graph defining the code to be a bipartite lossless expander (so that each of the n coordinates is connected to d parity bits for some bounded d, and any m coordinates (with m less than a small multiple of n) is connected to close to dm parity bits), then not only is the code good (high rate and high distance), one can decode very quickly (linear time in n) by the following ")#link("http://en.wikipedia.org/wiki/Belief_propagation")[#text("belief propagation")]#text(" algorithm:")

#enum(start: 1, 
[#text("Start with the corrupted word, and compute all the parity bits. If they all vanish, then we have a codeword and we stop.")],
[#text("Otherwise, we go through each coordinate and see how many of the d parity bits connected to that coordinate are non-vanishing (i.e. they take the value 1). If a majority of these bits return 1, then we flip the bit of the coordinate; otherwise, we keep the bit unchanged. (Intuitively, we are reducing the number of non-vanishing parity bits as much as possible.)")],
[#text("Repeat 2 until all parity bits vanish.")]
)

#text("Intuitively, the reason why this algorithm should work (if the number m of corrupted bits is small enough) is that in a lossless expander, the parity bits associated to each of the corrupted coordinates are mostly disjoint. Thus, every corrupted coordinates should see that most of the parity bits connected to it are taking the value of 1, giving a strong signal that those bits should change. Conversely, the uncorrupted bits should mostly see only a small minority of parity bits connected to it reporting the value 1. Indeed, one can show that each iteration of Step 2 cuts down the number m of corrupted bits by a constant factor (if m was small enough that the lossless property can be used, with some suitably small ")#mi("\\varepsilon")#text("). Also it is not hard to analyse the run-time of this algorithm and show that it is linear in the length n of the code.")

#text("[")#emph[#text("Update")]#text(", Jan 14: memory requirement for Reingold’s graph exploration algorithm corrected. Connections to Baum-Connes conjecture reworded.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/11/distinguished-lecture-series-ii-avi-wigderson-expander-graphs-constructions-and-applications/#comment-23933")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2008")])]

#text("There appears to be a typo in your definition of the set S of generators of SL_2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2008/01/11/distinguished-lecture-series-ii-avi-wigderson-expander-graphs-constructions-and-applications/#comment-23982")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2008")])]

#text("I once spent quite some time to locate (for reference purpose) a complete proof of the link from Selberg’s 3/16 theorem to the expanding properties of Cayley graphs as you described; the books I know on the subject (e.g., Sarnak’s “Some applications of modular forms”, Lubotzky’s “Discrete groups, expanding graphs and invariant measures”) do not give full details — they treat the case of compact surfaces and not finite-volume ones, which is of course fine for understanding what’s going on, but is not a complete argument.")

#text("So maybe it will be useful to give the references I found: the result (for finite-volume, non-compact surfaces) seems to be due to R. Brooks, in “On the angles between certain arithmetically defined subspaces of ")#mi("\\mathbf{C}^n")#text("“, in Annales de l’institut Fourier, tome 37, no 1 (1987), p. 175-185 (available on numdam.org), see Corollary, p. 182. Here the argument of Brooks is _very_ condensed, but there is a complete write-up in lecture notes of his entitled “The spectral geometry of Riemann surfaces”, Section 2 (those notes are available as Chapter 12 of “Topology in Molecular Biology”, published by Springer, or ")#link("http://www.math.technion.ac.il/~rbrooks/riems.ps")[#text("here")]#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/11/distinguished-lecture-series-ii-avi-wigderson-expander-graphs-constructions-and-applications/#comment-24278")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2008")])]

#text("Correction: Reingold’s algorithm for connectivity runs in logarithmic space and not polylogarithmic as you wrote (a log^2 space algorithm is easy to get).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/11/distinguished-lecture-series-ii-avi-wigderson-expander-graphs-constructions-and-applications/#comment-24314")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2008")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f563bddef1ea6c900459b818043ae43f59604042e090bc80cd98e994ab2ad2d-855eee57d6ce545af19e1c1d482f30e9f9ca47a674424b7182685751495a71c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Fisher")]], [#link("https://terrytao.wordpress.com/2008/01/11/distinguished-lecture-series-ii-avi-wigderson-expander-graphs-constructions-and-applications/#comment-24352")[#strong[#text("David Fisher")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2008")])]

#text("I want to clarify the relation between expanders,")#linebreak()#text(" Baum-Connes and topology. Saying this connection yields an “application of expanders to topology” is a bit of a stretch.")

#text("The Baum-Connes conjecture is a conjecture")#linebreak()#text(" concerning K-theory of group C^* algebras. It conjectures that a certain map is an isomorphism between two different K groups.")

#text("The injectivity of this Baum-Connes map implies the Novikov conjecture which is a conjecture about topological invariance of certain higher signatures. This implication is robust in that knowing Baum-Connes for a particular group implies Novikov for manifolds with that group as fundamental group.")

#text("There is, however, no reverse implication. So if")#linebreak()#text(" Baum-Connes is false for a group, we still have")#linebreak()#text(" no idea about Novikov.")

#text("By a theorem of Guoliang Yu, if a group admits a uniform embedding in a Hilbert space, the Baum-Connes map is injective and so the Novikov conjecture is true. There are other variants on")#linebreak()#text(" Yu’s result, but this is the result relevant here.")

#text("Gromov pointed out that if one could embed a")#linebreak()#text(" family of expander graphs into the Cayley graph")#linebreak()#text(" of the group, then the group would not admit a")#linebreak()#text(" uniform embedding in a Hilbert space. And proposed a method for constructing such a group.")#linebreak()#text(" (Actually the expander graphs are only embedded")#linebreak()#text(" quasi-isometrically, but this is enough.) To the best of my knowledge a complete and formal account justifying the existence of these groups is not yet in available. But I think a complete account is likely to be available soon, quite possibly multiple complete accounts.")

#text("Currently, no one knows if these groups actually provide a counter-example to Baum-Connes or not.")#linebreak()#text(" They do provide, indirectly, counterexamples to")#linebreak()#text(" some generalizations of the original Baum-Connes")#linebreak()#text(" conjecture. This is work of Higson, Lafforgue and Skandalis that has been in print since 2002. Though I am not an expert in this particular domain, I think")#linebreak()#text(" it is fair to say that serious effort has been devoted to seeing if Gromov’s groups are actually counterexamples to Baum-Connes. They might be,")#linebreak()#text(" but new ideas are almost certainly needed.")

#text("So currently expanders really only allow us to build some groups that obstruct one method of proving a big conjecture about group C^* algebras. Therefore obstructing one method of proving a big")#linebreak()#text(" conjecture about topology.")

#text("These conjectures are all hard and important so it")#linebreak()#text(" is worthwhile knowing how not to try to prove them. But, at the moment, there is no result about")#linebreak()#text(" topology, positive or negative, that comes out of this story.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/11/distinguished-lecture-series-ii-avi-wigderson-expander-graphs-constructions-and-applications/#comment-24359")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2008")])]

#text("Dear David,")

#text("Thanks for the detailed clarification! It sounds like a topic which I will have to learn more about at some point. For now, I’ve reworded the text slightly (which, incidentally, was not a direct quote from Avi).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f563bddef1ea6c900459b818043ae43f59604042e090bc80cd98e994ab2ad2d-855eee57d6ce545af19e1c1d482f30e9f9ca47a674424b7182685751495a71c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Fisher")]], [#link("https://terrytao.wordpress.com/2008/01/11/distinguished-lecture-series-ii-avi-wigderson-expander-graphs-constructions-and-applications/#comment-24446")[#strong[#text("David Fisher")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2008")])]

#text("Dear Terry,")

#text("A couple of additional remarks that I always forget, but that get to the heart of the matter.")

#text("First, in the positive direction, the work on")#linebreak()#text(" Baum-Connes does have topological implications.")#linebreak()#text(" E.g. Guoliang Yu’s work can be used to prove the Novikov conjecture for hyperbolic groups. I think")#linebreak()#text(" my earlier post may give the wrong impression on this point.")

#text("But on the negative side the connections just")#linebreak()#text(" aren’t so good. In particular, the Novikov")#linebreak()#text(" conjecture passes to direct limits of groups.")#linebreak()#text(" The construction of groups containing expander graphs constructs them as direct limits of hyperbolic groups. So these groups which might not satisfy")#linebreak()#text(" Baum-Connes are already known to satisfy Novikov.")

#text("Best,")

#text("David")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/11/distinguished-lecture-series-ii-avi-wigderson-expander-graphs-constructions-and-applications/#comment-27250")[#strong[#text("Big Boned · A talk at Zachos' class")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2008")]

#text("[…] Expander introduction and show how to use it. A great introduction (but need a lot of knowledge which I didn’t have yet) of Expander graph is mentioned in Tao’s blog. […]")
]
