// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/
// Converted to Typst by tao2typ: "2026-10-14T15:20:29.377046+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "247B, Notes 2: Decoupling theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("247B, Notes 2: Decoupling theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 April 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/")[#text("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#emph[#text("square root cancellation heuristic")]#text(", briefly mentioned in the ")#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/")[#text("preceding set of notes")]#text(", predicts that if a collection ")#mi("{z_1,\\dots,z_n}")#text(" of complex numbers have phases that are sufficiently “independent” of each other, then")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{j=1}^n z_j\\right| \\approx (\\sum_{j=1}^n \\left|z_j\\right|^2)^{1/2};", block: true)]]

#text("similarly, if ")#mi("{f_1,\\dots,f_n}")#text(" are a collection of functions in a Lebesgue space ")#mi("{L^p(X,\\mu)}")#text(" that oscillate “independently” of each other, then we expect")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{j=1}^n f_j \\right\\|_{L^p(X,\\mu)} \\approx \\left\\| (\\sum_{j=1}^n \\left|f_j\\right|^2)^{1/2} \\right\\|_{L^p(X,\\mu)}.", block: true)]]

#text("We have already seen one instance in which this heuristic can be made precise, namely when the phases of ")#mi("{z_j,f_j}")#text(" are randomised by a random sign, so that Khintchine’s inequality (Lemma 4 from ")#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/")[#text("Notes 1")]#text(") can be applied. There are other contexts in which a ")#emph[#text("square function estimate")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_{j=1}^n \\left|f_j\\right|^2)^{1/2} \\right\\|_{L^p(X,\\mu)} \\lesssim \\left\\| \\sum_{j=1}^n f_j \\right\\|_{L^p(X,\\mu)}", block: true)]]

#text("or a ")#emph[#text("reverse square function estimate")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{j=1}^n f_j \\right\\|_{L^p(X,\\mu)} \\lesssim \\left\\| (\\sum_{j=1}^n \\left|f_j\\right|^2)^{1/2} \\right\\|_{L^p(X,\\mu)}", block: true)]]

#text("(or both) are known or conjectured to hold. For instance, the useful ")#emph[#text("Littlewood-Paley inequality")]#text(" implies (among other things) that for any ")#mi("{1 < p < \\infty}")#text(", we have the reverse square function estimate ")#metadata(none) <tao-bb353ddaa8ec07f956f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| \\sum_{j=1}^n f_j \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{p,d} \\left\\| (\\sum_{j=1}^n \\left|f_j\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R}^d)},", block: true)]]

#text(" whenever the Fourier transforms ")#mi("{\\hat f_j}")#text(" of the ")#mi("{f_j}")#text(" are supported on disjoint annuli ")#tao-math("{\\{ \\xi \\in {\\bf R}^d: 2^{k_j} \\leq \\left|\\xi\\right| < 2^{k_j+1} \\}}", block: false)#text(", and we also have the matching square function estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_{j=1}^n \\left|f_j\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{p,d} \\left\\| \\sum_{j=1}^n f_j \\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("if there is some separation between the annuli (for instance if the ")#mi("{k_j}")#text(" are ")#mi("{2}")#text("-separated). We recall the proofs of these facts below the fold. In the ")#mi("{p=2}")#text(" case, we of course have Pythagoras’ theorem, which tells us that if the ")#mi("{f_j}")#text(" are all orthogonal elements of ")#mi("{L^2(X,\\mu)}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{j=1}^n f_j \\right\\|_{L^2(X,\\mu)} = (\\sum_{j=1}^n \\left\\| f_j \\right\\|_{L^2(X,\\mu)}^2)^{1/2} = \\left\\| (\\sum_{j=1}^n \\left|f_j\\right|^2)^{1/2} \\right\\|_{L^2(X,\\mu)}.", block: true)]]

#text("In particular, this identity holds if the ")#mi("{f_j \\in L^2({\\bf R}^d)}")#text(" have ")#emph[#text("disjoint Fourier supports")]#text(" in the sense that their Fourier transforms ")#mi("{\\hat f_j}")#text(" are supported on disjoint sets. For ")#mi("{p=4}")#text(", the technique of ")#emph[#text("bi-orthogonality")]#text(" can also give square function and reverse square function estimates in some cases, as we shall also see below the fold.")#linebreak()#text(" In recent years, it has begun to be realised that in the regime ")#mi("{p > 2}")#text(", a variant of reverse square function estimates such as ")#link(<tao-bb353ddaa8ec07f956f0>)[#text("(1)")]#text(" is also useful, namely ")#emph[#text("decoupling estimates")]#text(" such as ")#metadata(none) <tao-26393915c6fe3163d5c1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| \\sum_{j=1}^n f_j \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{p,d} (\\sum_{j=1}^n \\left\\|f_j\\right\\|_{L^p({\\bf R}^d)}^2)^{1/2}", block: true)]]

#text(" (actually in practice we often permit small losses such as ")#mi("{n^\\varepsilon}")#text(" on the right-hand side). An estimate such as ")#link(<tao-26393915c6fe3163d5c1>)[#text("(2)")]#text(" is weaker than ")#link(<tao-bb353ddaa8ec07f956f0>)[#text("(1)")]#text(" when ")#mi("{p\\geq 2}")#text(" (or equal when ")#mi("{p=2}")#text("), as can be seen by starting with the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{j=1}^n \\left|f_j\\right|^2 \\right\\|_{L^{p/2}({\\bf R}^d)} \\leq \\sum_{j=1}^n \\left\\| \\left|f_j\\right|^2 \\right\\|_{L^{p/2}({\\bf R}^d)},", block: true)]]

#text("and taking the square root of both side to conclude that ")#metadata(none) <tao-d1e909483b98bf9e8b8c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| (\\sum_{j=1}^n \\left|f_j\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R}^d)} \\leq (\\sum_{j=1}^n \\left\\|f_j\\right\\|_{L^p({\\bf R}^d)}^2)^{1/2}.", block: true)]]

#text(" However, the flip side of this weakness is that ")#link(<tao-26393915c6fe3163d5c1>)[#text("(2)")]#text(" can be easier to prove. One key reason for this is the ability to ")#emph[#text("iterate")]#text(" decoupling estimates such as ")#link(<tao-26393915c6fe3163d5c1>)[#text("(2)")]#text(", in a way that does not seem to be possible with reverse square function estimates such as ")#link(<tao-bb353ddaa8ec07f956f0>)[#text("(1)")]#text(". For instance, suppose that one has a decoupling inequality such as ")#link(<tao-26393915c6fe3163d5c1>)[#text("(2)")]#text(", and furthermore each ")#mi("{f_j}")#text(" can be split further into components ")#mi("{f_j= \\sum_{k=1}^m f_{j,k}}")#text(" for which one has the decoupling inequalities")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{k=1}^m f_{j,k} \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{p,d} (\\sum_{k=1}^m \\left\\|f_{j,k}\\right\\|_{L^p({\\bf R}^d)}^2)^{1/2}.", block: true)]]

#text("Then by inserting these bounds back into ")#link(<tao-26393915c6fe3163d5c1>)[#text("(2)")]#text(" we see that we have the combined decoupling inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{j=1}^n\\sum_{k=1}^m f_{j,k} \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{p,d} (\\sum_{j=1}^n \\sum_{k=1}^m \\left\\|f_{j,k}\\right\\|_{L^p({\\bf R}^d)}^2)^{1/2}.", block: true)]]

#text("This iterative feature of decoupling inequalities means that such inequalities work well with the method of ")#emph[#text("induction on scales")]#text(", that we introduced in the previous set of notes.")#linebreak()#text(" In fact, decoupling estimates share many features in common with restriction theorems; in addition to induction on scales, there are several other techniques that first emerged in the restriction theory literature, such as wave packet decompositions, rescaling, and bilinear or multilinear reductions, that turned out to also be well suited to proving decoupling estimates. As with restriction, the ")#emph[#text("curvature")]#text(" or ")#emph[#text("transversality")]#text(" of the different Fourier supports of the ")#mi("{f_j}")#text(" will be crucial in obtaining non-trivial estimates.")#linebreak()#text(" Strikingly, in many important model cases, the optimal decoupling inequalities (except possibly for epsilon losses in the exponents) are now known. These estimates have in turn had a number of important applications, such as establishing certain discrete analogues of the restriction conjecture, or the first proof of the main conjecture for Vinogradov mean value theorems in analytic number theory.")#linebreak()#text(" These notes only serve as a brief introduction to decoupling. A systematic exploration of this topic can be found in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3971577")[#text("this recent text of Demeter")]#text(".")#linebreak()#text(" ")#metadata(none) <tao-0b68a7f959433fb0305c>

#heading(level: 1)[#strong[#text(" — 1. Square function and reverse square function estimates — ")]]

#text("We begin with a form of the Littlewood-Paley inequalities. Given a region ")#mi("{\\Omega \\in {\\bf R}^d}")#text(", we say that a tempered distribution ")#mi("{f}")#text(" on ")#mi("{{\\bf R}^d}")#text(" has ")#emph[#text("Fourier support in ")#mi("{\\Omega}")]#text(" if its distributional Fourier transform ")#mi("{\\hat f}")#text(" is supported in (the closure of) ")#mi("{\\Omega}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Littlewood-Paley inequalities)")]#text(" ")#metadata(none) <tao-ca99faeb73c8015fc554>#text(" Let ")#mi("{d \\geq 1}")#text(", let ")#mi("{k_1,\\dots,k_n}")#text(" be distinct integers, let ")#mi("{1 < p < \\infty}")#text(", and for each ")#mi("{1 \\leq j \\leq n}")#text(" let ")#mi("{f_j \\in L^p({\\bf R}^d)}")#text(" be a function with Fourier support in the annulus ")#tao-math("{\\{ \\xi \\in {\\bf R}^d: 2^{k_j} \\leq \\left|\\xi\\right| \\leq 2^{k_j+1}\\}}", block: false)#text(".")

#list(
[#text("(i) (Reverse square function inequality) One has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{j=1}^n f_j \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{p,d} \\left\\| (\\sum_{j=1}^n \\left|f_j\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R}^d)}.", block: true)]]],
[#text("(ii) (Square function inequality) If the ")#mi("{k_j}")#text(" are ")#mi("{2}")#text("-separated (thus ")#tao-math("{\\left|k_j-k_{j^{\\prime}}\\right| \\geq 2}", block: false)#text(" for any ")#mi("{1 \\leq j < j^{\\prime} \\leq n}")#text(") then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_{j=1}^n \\left|f_j\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{p,d} \\left\\| \\sum_{j=1}^n f_j \\right\\|_{L^p({\\bf R}^d)}.", block: true)]]]
)
]

#emph[#text("Proof:")]#text(" We begin with (ii). We use a randomisation argument. Let ")#mi("{\\psi \\in C^\\infty_c({\\bf R}^d)}")#text(" be a bump function supported on the annulus ")#tao-math("{\\{ \\xi: 0.9 \\leq \\left|\\xi\\right| \\leq 2.1\\}}", block: false)#text(" that equals one on ")#tao-math("{\\{ \\xi: 1 \\leq \\left|\\xi\\right| \\leq 2 \\}}", block: false)#text(", and for each ")#mi("{j=1,\\dots,n}")#text(" let ")#mi("{P_{k_j}}")#text(" be the Fourier multiplier defined by")

#align(center)[#tao-fit-display[#mitex("\\widehat{P_{k_j} f}(\\xi) := \\psi(\\xi/2^{k_j}) \\hat f(\\xi),")]]

#text("at least for functions ")#mi("{f}")#text(" in the Schwartz class. Clearly the operator ")#mi("{P_{k_j}}")#text(" is given by convolution with a (")#mi("{k_j}")#text("-dependent) Schwartz function, so this multiplier is bounded on every ")#mi("{L^p}")#text(" space. Writing ")#mi("{f := \\sum_{j=1}^n f_j}")#text(", we see from the separation property of the ")#mi("{k_j}")#text(" that we have the reproducing formula")

#align(center)[#tao-fit-display[#mitex("f_j = P_{k_j} f.")]]

#text("Now let ")#mi("{\\epsilon_1,\\dots,\\epsilon_n \\in \\{-1,+1\\}}")#text(" be random signs drawn uniformly and independently at random, thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^n \\epsilon_j f_j = (\\sum_{j=1}^n \\epsilon_j P_{k_j}) f.")]]

#text("The operator ")#mi("{\\sum_{j=1}^n \\epsilon_j P_{k_j}}")#text(" is a Fourier multiplier with symbol ")#mi("{\\sum_{j=1}^n \\epsilon_j \\psi(\\xi/2^{k_j})}")#text(". This symbol obeys the hypotheses of the ")#link("https://en.wikipedia.org/wiki/Multiplier_(Fourier_analysis)#Mikhlin_multiplier_theorem")[#text("Hörmander-Miklin multiplier theorem")]#text(", uniformly in the choice of signs; since we are in the non-endpoint case ")#mi("{1 < p < \\infty}")#text(", we thus have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{j=1}^n \\epsilon_j f_j \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{p,d} \\left\\| \\sum_{j=1}^n f_j \\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("uniformly in the ")#mi("{\\epsilon_j}")#text(". Taking ")#mi("{p^{th}}")#text(" power means of this estimate using Khintchine’s inequality (Lemma 4 from ")#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/")[#text("Notes 1")]#text("), we obtain (ii) as desired.")#linebreak()#text(" Now we turn to (i). By treating the ")#mi("{k_j}")#text(" even and ")#mi("{k_j}")#text(" odd cases separately and using the triangle inequality, we may assume without loss of generality that the ")#mi("{k_j}")#text(" all have the same parity, so in particular are ")#mi("{2}")#text("-separated. (Why are we permitted to use this reduction for part (i) but not for part (ii)?) Now we use the projections ")#mi("{P_{k_j}}")#text(" from before in a slightly different way, noting that")

#align(center)[#tao-fit-display[#mitex("f_j = \\epsilon_j P_{k_j} \\sum_{j^{\\prime}=1}^n \\epsilon_{j^{\\prime}} f_{j^{\\prime}},")]]

#text("for any ")#mi("{j=1,\\dots,n}")#text(", and hence")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^n f_j = (\\sum_{j=1}^n \\epsilon_j P_{k_j}) \\sum_{j^{\\prime}=1}^n \\epsilon_{j^{\\prime}} f_{j^{\\prime}}.")]]

#text("Applying the Hörmander-Mikhlin theorem as before, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{j=1}^n f_j \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{p,d} \\left\\| \\sum_{j=1}^n \\epsilon_j f_j \\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("and on taking ")#mi("{p^{th}}")#text(" power means and using Khintchine’s inequality as before we conclude (i). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2 (Smooth Littlewood-Paley estimate)")]#text(" ")#metadata(none) <tao-e112cdfe5d614a7ce060>#text(" Let ")#mi("{d \\geq 1}")#text(" and ")#mi("{1 < p < \\infty}")#text(", and let ")#mi("{\\phi\\in C^\\infty_c({\\bf R}^d)}")#text(" be a bump function supported on ")#mi("{B(0,1)}")#text(" that equals ")#mi("{1}")#text(" on ")#mi("{B(0,1/2)}")#text(". For any integer ")#mi("{j}")#text(", let ")#mi("{P_j}")#text(" denote the Fourier multiplier, defined on Schwartz functions ")#mi("{f}")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\widehat{P_j f}(\\xi) := (\\phi(\\xi/2^j) - \\phi(\\xi/2^{j-1})) \\hat f(\\xi)")]]

#text("and extended to ")#mi("{L^p({\\bf R}^d)}")#text(" functions by continuity. Show that for any ")#mi("{f \\in L^p({\\bf R}^d)}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_{j \\in {\\bf Z}} \\left|P_j f\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R}^d)} \\sim_{p,d} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("(in particular, the left-hand side is finite).")
]

#text("We remark that when ")#mi("{d=1}")#text(", the condition that the ")#mi("{k_j}")#text(" be ")#mi("{2}")#text("-separated can be removed from Theorem ")#link(<tao-ca99faeb73c8015fc554>)[#text("1")]#text("(ii), by using ")#link("https://en.wikipedia.org/wiki/Multiplier_(Fourier_analysis)#Marcinkiewicz_multiplier_theorem")[#text("the Marcinkiewicz multiplier theorem")]#text(" in place of the Hörmander-Mikhlin multiplier theorem. But, perhaps surprisingly, the condition cannot be removed in higher dimensions, as a consequence of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=296602")[#text("Fefferman’s surprising result")]#text(" on the unboundedness of the disk multiplier.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Unboundedness of the disc multiplier)")]#text(" Let ")#mi("{D}")#text(" denote either the disk ")#tao-math("{\\{ \\xi: \\left|\\xi\\right| \\leq 1 \\}}", block: false)#text(" or the annulus ")#tao-math("{\\{ \\xi: 1 \\leq \\left|\\xi\\right| \\leq 2 \\}}", block: false)#text(". Let ")#mi("{P_\\Omega}")#text(" denote the Fourier multiplier defined on Schwartz functions ")#mi("{f \\in {\\mathcal S}({\\bf R}^2)}")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\widehat{P_\\Omega f}(\\xi) = 1_\\Omega(\\xi) \\hat f(\\xi).")]]

#text("Suppose that ")#mi("{1 < p < \\infty}")#text(" is such that ")#metadata(none) <tao-1044dec7206e8d7c9fbb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\| P_D f \\right\\|_{L^p({\\bf R}^2)} \\lesssim_p \\left\\| f \\right\\|_{L^p({\\bf R}^2)}", block: true)]]

#text(" for all ")#mi("{f \\in {\\mathcal S}({\\bf R}^2)}")#text(".")

#list(
[#text("(i) Show that for any collection ")#mi("{H_1,\\dots,H_n}")#text(" of half-planes in ")#mi("{{\\bf R}^2}")#text(", and any functions ")#mi("{f_1,\\dots,f_n \\in {\\mathcal S}({\\bf R}^2)}")#text(", that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_{j=1}^n \\left|P_{H_j} f_j\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R}^2)} \\lesssim_p \\left\\| (\\sum_{j=1}^n \\left|f_j\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R}^2)}.", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" first rescale the set ")#mi("{D}")#text(" by a large scaling factor ")#mi("{R}")#text(", apply the Marcinkiewicz-Zygmund theorem (Exercise 7 from ")#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/")[#text("Notes 1")]#text("), exploit the symmetries of the Fourier transform, then take a limit as ")#mi("{R \\rightarrow \\infty}")#text(".)")],
[#text("(ii) Let ")#mi("{R_1,\\dots,R_n}")#text(" be a collection of ")#mi("{\\delta \\times 1}")#text(" rectangles for some ")#mi("{\\delta < 1}")#text(", and for each ")#mi("{j=1,\\dots,n}")#text(", let ")#mi("{\\tilde R_j}")#text(" be a rectangle formed from ")#mi("{R_j}")#text(" by translating by a distance ")#mi("{2}")#text(" in the direction of the long axis of ")#mi("{R_j}")#text(". Use (i) to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{j=1}^n 1_{\\tilde R_j} \\right\\|_{L^{p/2}({\\bf R}^2)} \\sim_p \\left\\| \\sum_{j=1}^n 1_{R_j} \\right\\|_{L^{p/2}({\\bf R}^2)}.", block: true)]]

#text("(Hint: a direct application of (i) will give just one side of this estimate, but then one can use symmetry to obtain the other side.)")],
[#text("(iii) In ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=296602")[#text("Fefferman’s paper")]#text(", modifying a classic construction of a Besicovitch set, it was shown that for any ")#mi("{\\varepsilon>0}")#text(", there exists a collection of ")#mi("{1 \\times \\delta}")#text(" rectangles ")#mi("{R_1,\\dots,R_n}")#text(" for some ")#mi("{0 < \\delta < 1}")#text(" with ")#mi("{n \\sim 1/\\delta}")#text(" such that all the rectangles ")#mi("{\\tilde R_j}")#text(" are disjoint, but such that ")#mi("{\\bigcup_{j=1}^n R_j}")#text(" has measure ")#mi("{O(\\varepsilon)}")#text(". Assuming this fact, conclude that the multiplier estimate ")#link(<tao-1044dec7206e8d7c9fbb>)[#text("(4)")]#text(" fails unless ")#mi("{p=2}")#text(".")],
[#text("(iv) Show that Theorem ")#link(<tao-ca99faeb73c8015fc554>)[#text("1")]#text("(ii) fails when ")#mi("{d=2}")#text(" and the requirement that the ")#mi("{k_j}")#text(" be ")#mi("{2}")#text("-separated is removed.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" ")#metadata(none) <tao-8fa311052866613a2a32>#text(" Let ")#mi("{\\varphi \\in C^\\infty_c({\\bf R})}")#text(" be a bump function supported on ")#mi("{[-1,2]}")#text(" that equals one on ")#mi("{[0,1]}")#text(". For each integer ")#mi("{n}")#text(", let ")#mi("{\\tilde P_n}")#text(" be the Fourier multiplier defined for ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\widehat{\\tilde P_n f}(\\xi) := \\varphi(\\xi - n) \\hat f(\\xi)")]]

#text("and also define")

#align(center)[#tao-fit-display[#mitex("\\widehat{P_{[n,n+1]} f}(\\xi) := 1_{[n,n+1]}(\\xi) \\hat f(\\xi).")]]

#list(
[#text("(i) For any ")#mi("{2 \\leq p \\leq \\infty}")#text(", establish the square function estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_{n \\in {\\bf Z}} \\left|\\tilde P_n f\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R})} \\lesssim \\left\\|f\\right\\|_{L^p({\\bf R})}", block: true)]]

#text("for ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(". (")#emph[#text("Hint:")]#text(" interpolate between the ")#mi("{p=2,p=\\infty}")#text(" cases, and for the latter use Plancherel’s theorem for Fourier series.)")],
[#text("(ii) For any ")#mi("{2 \\leq p < \\infty}")#text(", establish the square function estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_{n \\in {\\bf Z}} \\left|P_{[n,n+1]} f\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R})} \\lesssim_p \\left\\|f\\right\\|_{L^p({\\bf R})}", block: true)]]

#text("for ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(". (")#emph[#text("Hint:")]#text(" from the boundedness of the Hilbert transform, ")#mi("{P_{[0,1]}}")#text(" is bounded in ")#mi("{L^p}")#text(". Combine this with the Marcinkiewicz-Zygmund theorem (Exercise 7 from ")#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/")[#text("Notes 1")]#text("), then use the symmetries of the Fourier transform, part (i), and the identity ")#mi("{P_{[n,n+1]} = P_{[n,n+1]} \\tilde P_n}")#text(".)")],
[#text("(iii) For any ")#mi("{1 < p \\leq 2}")#text(", establish the reverse square function estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^p({\\bf R})} \\lesssim_p \\left\\| (\\sum_{n \\in {\\bf Z}} \\left|P_{[n,n+1]} f\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R})}", block: true)]]

#text("for ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(". (")#emph[#text("Hint:")]#text(" use duality as in the solution to Exercise ")#link(<tao-e112cdfe5d614a7ce060>)[#text("2")]#text(" in this set of notes, or Exercise 11 in ")#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/")[#text("Notes 1")]#text(", and part (ii).)")],
[#text("(iv) Show that the estimate (ii) fails for ")#mi("{1<p<2}")#text(", and similarly the estimate (iii) fails for ")#mi("{2<p<\\infty}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" The inequalities in Exercise ")#link(<tao-8fa311052866613a2a32>)[#text("4")]#text(" have been generalised by replacing the partition ")#mi("{{\\bf R} = \\bigcup_n [n,n+1]}")#text(" with an arbitrary partition of the real line into intervals; see ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=850681")[#text("this paper of Rubio de Francia")]#text(".")
]

#text("If ")#mi("{f_1,\\dots,f_n \\in {\\mathcal S}({\\bf R}^d)}")#text(" are functions with disjoint Fourier supports, then as mentioned in the introduction, we have from Pythagoras’ theorem that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{j=1}^n f_j \\right\\|_{L^2({\\bf R}^d)} = \\left\\| (\\sum_{j=1}^n \\left|f_j\\right|^2)^{1/2} \\right\\|_{L^2({\\bf R}^d)}.", block: true)]]

#text("We have the following variants of this claim:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (")#mi("{L^2}")#text(" and ")#mi("{L^4}")#text(" reverse square function estimates)")]#text(" ")#metadata(none) <tao-05320182634464334694>#text(" Let ")#mi("{f_1,\\dots,f_n \\in {\\mathcal S}({\\bf R}^d)}")#text(" have Fourier transforms supported on the sets ")#mi("{\\Omega_1,\\dots,\\Omega_n \\subset {\\bf R}^d}")#text(" respectively.")

#list(
[#text("(i) (Almost orthogonality) If the sets ")#mi("{\\Omega_1,\\dots,\\Omega_n}")#text(" have overlap at most ")#mi("{A_2}")#text(" (i.e., every ")#mi("{\\xi \\in {\\bf R}^d}")#text(" lies in at most ")#mi("{A_2}")#text(" of the ")#mi("{\\Omega_i}")#text(") for some ")#mi("{A_2>0}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{j=1}^n f_j \\right\\|_{L^2({\\bf R}^d)} \\leq A_2^{1/2} \\left\\| (\\sum_{j=1}^n \\left|f_j\\right|^2)^{1/2} \\right\\|_{L^2({\\bf R}^d)}.", block: true)]]],
[#text("(ii) (Almost bi-orthogonality) If the sets ")#mi("{\\Omega_i+\\Omega_j := \\{ \\xi_i + \\xi_j: \\xi_i \\in \\Omega_i, \\xi_j \\in \\Omega_j\\}}")#text(" with ")#mi("{1 \\leq i,j \\leq n}")#text(" have overlap at most ")#mi("{A_4}")#text(" for some ")#mi("{A_4>0}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{j=1}^n f_j \\right\\|_{L^4({\\bf R}^d)} \\leq A_4^{1/4} \\left\\| (\\sum_{j=1}^n \\left|f_j\\right|^2)^{1/2} \\right\\|_{L^4({\\bf R}^d)}.", block: true)]]]
)
]

#emph[#text("Proof:")]#text(" For (i), observe from Plancherel’s theorem that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{j=1}^n f_j \\right\\|_{L^2({\\bf R}^d)} = \\left\\| \\sum_{j=1}^n \\hat f_j \\right\\|_{L^2({\\bf R}^d)}.", block: true)]]

#text("By hypothesis, for each frequency ")#mi("{\\xi \\in {\\bf R}^d}")#text(" at most ")#mi("{A_2}")#text(" of the ")#mi("{\\hat f_j(\\xi)}")#text(" are non-zero, thus by Cauchy-Schwarz we have the pointwise estimate")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{j=1}^n \\hat f_j(\\xi)\\right| \\leq A_2^{1/2} (\\sum_{j=1}^n \\left|\\hat f_j(\\xi)\\right|^2)^{1/2}", block: true)]]

#text("and hence by Fubini’s theorem")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{j=1}^n f_j \\right\\|_{L^2({\\bf R}^d)} \\leq A_2^{1/2} (\\sum_{j=1}^n \\left\\|\\hat f_j \\right\\|_{L^2({\\bf R}^d)}^2)^{1/2}.", block: true)]]

#text("The claim then follows by a further application of Plancherel’s theorem and Fubini’s theorem. For (ii), we observe that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{j=1}^n f_j \\right\\|_{L^4({\\bf R}^d)}^2 = \\left\\| \\sum_{i=1}^n \\sum_{j=1}^n f_i f_j \\right\\|_{L^2({\\bf R}^2)}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_{j=1}^n \\left|f_j\\right|^2)^{1/2} \\right\\|_{L^4({\\bf R}^d)}^2 = \\left\\| (\\sum_{i=1}^n \\sum_{j=1}^n \\left|f_i f_j\\right|^2)^{1/2} \\right\\|_{L^2({\\bf R}^2)}.", block: true)]]

#text("Since ")#mi("{f_i f_j}")#text(" has Fourier support in ")#mi("{\\Omega_i + \\Omega_j}")#text(", the claim (ii) now follows from (i). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" By using ")#mi("{f_i \\overline{f_j}}")#text(" in place of ")#mi("{f_i f_j}")#text(", one can also establish a variant of Lemma ")#link(<tao-05320182634464334694>)[#text("6")]#text("(ii) in which the sum set ")#mi("{\\Omega_i + \\Omega_j}")#text(" is replaced by the difference set ")#mi("{\\Omega_i - \\Omega_j := \\{ \\xi_i - \\xi_j: \\xi_i \\in \\Omega_i, \\xi_j \\in \\Omega_j \\}}")#text(". It is also clear how to extend the lemma to other even exponent Lebesgue spaces such as ")#mi("{L^6}")#text("; see for instance ")#link("https://arxiv.org/abs/1906.05877")[#text("this recent paper of Gressman, Guo, Pierce, Roos, and Yung")]#text(". However, we will not use these variants here.")
]

#text("We can use this lemma to establish the following ")#mi("{L^4}")#text(" reverse square function estimate for the circle:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8 (Square function estimate for circle and parabola)")]#text(" ")#metadata(none) <tao-b33f19e0b6632651b414>#text(" Let ")#mi("{0 < \\delta \\leq 1}")#text(", let ")#mi("{\\Omega}")#text(" be a ")#mi("{\\gtrsim \\delta}")#text("-separated subset of the unit circle ")#mi("{S^1}")#text(", and for each ")#mi("{\\omega \\in \\Omega}")#text(", let ")#mi("{f_\\omega \\in {\\mathcal S}({\\bf R}^2)}")#text(" have Fourier support in the rectangle")

#align(center)[#tao-fit-display[#tao-math("R_\\omega := \\{ \\xi \\in {\\bf R}^2: \\left|\\xi \\cdot \\omega - 1\\right| < \\delta^2; \\left|\\xi - (\\xi \\cdot \\omega) \\omega\\right| < \\delta \\}.", block: true)]]

#list(
[#text("(i) Use Lemma ")#link(<tao-05320182634464334694>)[#text("6")]#text("(ii) to establish the reverse square function estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\sum_{\\omega \\in \\Omega} f_\\omega \\right\\|_{L^4({\\bf R}^2)} \\lesssim \\left\\| (\\sum_{\\omega \\in \\Omega} \\left|f_\\omega\\right|^2)^{1/2} \\right\\|_{L^4({\\bf R}^2)}.", block: true)]]],
[#text("(ii) If the elements of ")#mi("{\\Omega}")#text(" are ")#mi("{C\\delta}")#text("-separated for a sufficiently large absolute constant ")#mi("{C}")#text(", establish the matching square function estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\sum_{\\omega \\in \\Omega} f_\\omega \\right\\|_{L^4({\\bf R}^2)} \\gtrsim \\left\\| (\\sum_{\\omega \\in \\Omega} \\left|f_\\omega\\right|^2)^{1/2} \\right\\|_{L^4({\\bf R}^2)}.", block: true)]]],
[#text("(iii) Obtain analogous claims to (i), (ii) in which ")#mi("{\\Omega = \\phi(\\Sigma)}")#text(" for some ")#mi("{\\delta}")#text("-separated subset ")#mi("{\\Sigma}")#text(" of ")#mi("{[-1,1]}")#text(", where ")#mi("{\\phi: {\\bf R} \\rightarrow {\\bf R}^2}")#text(" is the graphing function ")#mi("{\\phi(\\xi) :=(\\xi,\\xi^2): \\xi = O(1) \\}}")#text(", and to each ")#mi("{\\omega = (\\omega_1,\\omega_1^2) \\in \\Omega}")#text(" one uses the parallelogram")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\tilde R_\\omega := \\{ (\\xi_1,\\xi_2) \\in {\\bf R}^2: \\left|\\xi_1 - \\omega_1\\right| < \\delta;", block: true)]]

#metadata(none) <tao-b12a14d5098cc6f372d4>

#align(center)[#tao-fit-display[#tao-math("\\left|\\xi_2 - \\omega_1^2 - 2\\omega_1(\\xi_1-\\omega_1)\\right| < \\delta^2 \\}", block: true)]]

#text("in place of ")#mi("{R_\\omega}")#text(".")],
[#text("(iv) (Optional, as it was added after this exercise was first assigned as homework) Show that in (i) one cannot replace the ")#mi("{L^4}")#text(" norms on both sides by ")#mi("{L^p}")#text(" for any given ")#mi("{4 < p < \\infty}")#text(". (")#emph[#text("Hint:")]#text(" use a Knapp type example for each ")#mi("{f_\\omega}")#text(" and ensure that there is enough constructive interference in ")#mi("{\\sum_{\\omega \\in \\Omega} f_\\omega}")#text(" near the origin.) On the other hand, using Exercise ")#link(<tao-8fa311052866613a2a32>)[#text("4")]#text(" show that the ")#mi("{L^4}")#text(" norm in (ii) can be replaced by an ")#mi("{L^p}")#text(" norm for any ")#mi("{2 \\leq p \\leq \\infty}")#text(".")]
)
]

#text("For a more sophisticated estimate along these lines, using sectors of the plane rather than rectangles near the unit circle, see ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=688026")[#text("this paper of Cordóba")]#text(". An analogous reverse square function estimate is also conjectured in higher dimensions (with ")#mi("{L^4}")#text(" replaced by the endpoint restriction exponent ")#mi("{L^{2d/(d-1)}}")#text("), but this remains open, and in fact is at least as hard as the restriction and Kakeya conjectures; see ")#link("https://arxiv.org/abs/1507.02515")[#text("this paper of Carbery")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. Decoupling estimates — ")]]

#text("We now turn to decoupling estimates. We begin with a general definition.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 9 (Decoupling constant)")]#text(" Let ")#mi("{{\\mathcal U} = \\{U_1,\\dots,U_n\\}}")#text(" be a finite collection of non-empty open subsets of ")#mi("{{\\bf R}^d}")#text(" for some ")#mi("{n \\geq 1}")#text(" (we permit repetitions, so ")#mi("{{\\mathcal U}}")#text(" may be a multi-set rather than a set), and let ")#mi("{1 \\leq p \\leq \\infty}")#text(". We define the ")#emph[#text("decoupling constant")]#text(" ")#mi("{\\mathrm{Dec}_p({\\mathcal U})}")#text(" to be the smallest constant for which one has the inequality ")#metadata(none) <tao-fbe44a5fae52a92ad8c0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left\\| \\sum_{j=1}^n f_j \\right\\|_{L^p({\\bf R}^d)} \\leq \\mathrm{Dec}_p({\\mathcal U}) (\\sum_{j=1}^n \\left\\|f_j\\right\\|_{L^p({\\bf R}^d)}^2)^{1/2}", block: true)]]

#text(" whenever ")#mi("{f_j \\in {\\mathcal S}({\\bf R}^d)}")#text(" has Fourier support in ")#mi("{U_j}")#text(" for ")#mi("{j=1,\\dots,n}")#text(".")
]

#text("We have the trivial upper and lower bounds ")#metadata(none) <tao-4a2326c64ab2287ead87>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("1 \\leq \\mathrm{Dec}_p({\\mathcal U}) \\leq n^{1/2},")]]

#text(" with the lower bound arising from restricting to the case when all but one of the ")#mi("{f_j}")#text(" vanish, and the upper bound following from the triangle inequality and Cauchy-Schwarz. In the literature, decoupling inequalities are also considered with the ")#mi("{\\ell^2}")#text(" summation of the ")#tao-math("{\\left\\|f_j\\right\\|_{L^p({\\bf R}^d)}}", block: false)#text(" norms replaced by other summations (for instance, the original decoupling inequality ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1800068")[#text("of Wolff")]#text(" used ")#mi("{\\ell^p}")#text(" norms) but we will focus only on ")#mi("{\\ell^2}")#text(" decoupling estimates in this post. In the literature it is common to restrict attention to the case when the sets ")#mi("{U_1,\\dots,U_n}")#text(" are disjoint, but for minor technical reasons we will not impose this extra condition in our definition.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Elementary properties of decoupling constants)")]#text(" ")#metadata(none) <tao-7ddcdc0ab8180b8893fa>#text(" Let ")#mi("{1 \\leq p \\leq \\infty}")#text(" and ")#mi("{d \\geq 1}")#text(".")

#list(
[#text("(i) (Monotonicity) Show that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_p( \\{ U_1,\\dots,U_n\\}) \\leq \\mathrm{Dec}_p( \\{ U^{\\prime}_1,\\dots,U^{\\prime}_n\\})")]]

#text("whenever ")#mi("{U_j,U^{\\prime}_j}")#text(" are non-empty open subsets of ")#mi("{{\\bf R}^d}")#text(" with ")#mi("{U_j \\subset U^{\\prime}_j}")#text(" for ")#mi("{j=1,\\dots,n}")#text(".")],
[#text("(ii) (Triangle inequality) Show that")

#tao-aligned(keep: true)[


#tao-math("\\mathrm{Dec}_p( {\\mathcal U} ), \\mathrm{Dec}_p( {\\mathcal U}^{\\prime} )  & \\leq \\mathrm{Dec}_p( {\\mathcal U} \\cup {\\mathcal U}^{\\prime} )", block: true)



#tao-math(" & \\leq (\\mathrm{Dec}_p( {\\mathcal U} )^2 + \\mathrm{Dec}_p( {\\mathcal U}^{\\prime} )^2)^{1/2}", block: true)
]

#text("for any finite non-empty collections ")#mi("{{\\mathcal U}, {\\mathcal U}^{\\prime}}")#text(" of open non-empty subsets of ")#mi("{{\\bf R}^d}")#text(".")],
[#text("(iii) (Affine invariance) Show that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_p( \\{ LU_1,\\dots,LU_n\\}) = \\mathrm{Dec}_p( \\{ U_1,\\dots,U_n\\})")]]

#text("whenever ")#mi("{U_1,\\dots,U_n \\subset {\\bf R}^d}")#text(" are open non-empty and ")#mi("{L: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" is an invertible affine transformation.")],
[#text("(iv) (Interpolation) Suppose that ")#mi("{\\frac{1}{p} = \\frac{1-\\theta}{p_0} + \\frac{\\theta}{p_1}}")#text(" for some ")#mi("{1 \\leq p_0 \\leq p \\leq p_1 \\leq \\infty}")#text(" and ")#mi("{0 \\leq \\theta \\leq 1}")#text(", and suppose also that ")#mi("{{\\mathcal U} = \\{U_1,\\dots,U_n\\}}")#text(" is a non-empty collection of open non-empty subsets of ")#mi("{{\\bf R}^d}")#text(" for which one has the projection bounds")

#align(center)[#tao-fit-display[#tao-math("\\left\\| P_{U_j} f \\right\\|_{L^{p_i}({\\bf R}^d)} \\lesssim_{p_i,d} \\left\\|f\\right\\|_{L^{p_i}({\\bf R}^d)}", block: true)]]

#text("for all ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(", ")#mi("{i=0,1}")#text(", and ")#mi("{j=1,\\dots,n}")#text(", where the Fourier multiplier ")#mi("{P_{U_j}}")#text(" is defined by")

#align(center)[#tao-fit-display[#mitex("\\widehat{P_{U_j} f}(\\xi) = 1_{U_j}(\\xi) \\hat f(\\xi).")]]

#text("Show that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_p({\\mathcal U}) \\lesssim_{p_0,p_1,d,\\theta} \\mathrm{Dec}_{p_0}({\\mathcal U})^{1-\\theta} \\mathrm{Dec}_{p_1}({\\mathcal U})^{\\theta}.")]]],
[#text("(v) (Multiplicativity) Suppose that ")#mi("{{\\mathcal U} = \\{ U_1,\\dots,U_n\\}}")#text(" is a family of open non-empty subsets of ")#mi("{{\\bf R}^d}")#text(", with each ")#mi("{U_j, j=1,\\dots,n}")#text(" containing further open non-empty subsets ")#mi("{U_{j,i}}")#text(" for ")#mi("{i=1,\\dots,m}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_p( \\{ U_{j,i}: 1 \\leq j \\leq n, 1 \\leq i \\leq m \\} ) \\leq \\mathrm{Dec}_p({\\mathcal U})")]]

#align(center)[#tao-fit-display[#mitex("\\times \\sup_{1 \\leq j \\leq n} \\mathrm{Dec}_p( \\{ U_{j,1},\\dots,U_{j,m}\\}).")]]],
[#text("(vi) (Adding dimensions) Suppose that ")#mi("{\\{ U_1,\\dots,U_n\\}}")#text(" is a family of disjoint open non-empty subsets of ")#mi("{{\\bf R}^d}")#text(" and that ")#mi("{p \\geq 2}")#text(". Show that for any ")#mi("{d^{\\prime} \\geq 1}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_p( \\{ U_1,\\dots,U_n\\} ) = \\mathrm{Dec}_p( \\{ U_1 \\times {\\bf R}^{d^{\\prime}},\\dots,U_n \\times {\\bf R}^{d^{\\prime}}\\} )")]]

#text("where the right-hand side is a decoupling constant in ")#mi("{{\\bf R}^d \\times {\\bf R}^{d^{\\prime}} = {\\bf R}^{d+d^{\\prime}}}")#text(".")]
)
]

#text("The most useful decoupling inequalites in practice turn out to be those where the decoupling constant ")#mi("{\\mathrm{Dec}_p({\\mathcal U})}")#text(" is close to the lower bound of ")#mi("{1}")#text(", for instance if one has the sub-polynomial bounds")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_p({\\mathcal U}) \\lesssim_{p,d,\\varepsilon} n^\\varepsilon")]]

#text("for every ")#mi("{\\varepsilon>0}")#text(". We informally say that the collection ")#mi("{{\\mathcal U}}")#text(" of sets ")#emph[#text("exhibits decoupling in ")#mi("{L^p}")]#text(" when this is the case.")#linebreak()#text(" For ")#mi("{p=2,4}")#text(", Lemma ")#link(<tao-05320182634464334694>)[#text("6")]#text(" (and ")#link(<tao-d1e909483b98bf9e8b8c>)[#text("(3)")]#text(") already gives some decoupling estimates: one has ")#metadata(none) <tao-2c3a4249d77070058649>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\mathrm{Dec}_2({\\mathcal U}) \\leq A_2^{1/2}")]]

#text(" if the sets ")#mi("{U_1,\\dots,U_n}")#text(" have an overlap of at most ")#mi("{A_2}")#text(", and similarly")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_4({\\mathcal U}) \\leq A_4^{1/4}")]]

#text("when the sets ")#mi("{U_i+U_j}")#text(", ")#mi("{1 \\leq i,j \\leq n}")#text(" have an overlap of at most ")#mi("{A_4}")#text(".")#linebreak()#text(" For ")#mi("{p<2}")#text(", it is not possible to exhibit decoupling in the limit ")#mi("{n \\rightarrow \\infty}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" If ")#mi("{{\\mathcal U} = \\{U_1,\\dots,U_n\\}}")#text(" is a collection of non-empty open subsets of ")#mi("{{\\bf R}^d}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_p({\\mathcal U}) \\gtrsim_{p,d} n^{\\frac{1}{p}-\\frac{1}{2}}")]]

#text("for any ")#mi("{1 \\leq p \\leq 2}")#text(". (")#emph[#text("Hint:")]#text(" select the ")#mi("{f_1,\\dots,f_n}")#text(" to be concentrated in widely separated large balls.)")
]

#text("Henceforth we now focus on the regime ")#mi("{p \\geq 2}")#text(". By ")#link(<tao-2c3a4249d77070058649>)[#text("(8)")]#text(", ")#mi("{L^2}")#text(" decoupling is easily obtained if the regions ")#mi("{U_j}")#text(" are of bounded overlap. For ")#mi("{p}")#text(" larger than ")#mi("{2}")#text(", bounded overlap is insufficient by itself; the arrangement of the regions ")#mi("{U_j}")#text(" must also exhibit some “curvature”, as the following example shows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" If ")#mi("{{\\mathcal U} = \\{ (i,i+1): 0 \\leq i < n \\}}")#text(", and ")#mi("{2 \\leq p \\leq \\infty}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_p({\\mathcal U}) \\sim_p n^{\\frac{1}{2} - \\frac{1}{p}}.")]]

#text("(")#emph[#text("Hint:")]#text(" for the upper bound, use a variant of Exercise 24(ii) from ")#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/")[#text("Notes 1")]#text(", or adapt the interpolation arguemnt used to establish that exercise.)")
]

#text("Now we establish a significantly more non-trivial decoupling theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 13 (Decoupling for the parabola)")]#text(" ")#metadata(none) <tao-d617af7a922bffeca014>#text(" Let ")#mi("{0 < \\delta \\leq 1}")#text(", let ")#mi("{\\Omega = \\phi(\\Sigma)}")#text(" for some ")#mi("{\\delta}")#text("-separated subset ")#mi("{\\Sigma}")#text(" of ")#mi("{[-1,1]}")#text(", where ")#mi("{\\phi(\\xi) := (\\xi,\\xi^2)}")#text(", and to each ")#mi("{\\omega \\in \\Omega}")#text(" let ")#mi("{\\tilde R_{\\omega,\\delta} = \\tilde R_{\\omega}}")#text(" be the parallelogram ")#link(<tao-b12a14d5098cc6f372d4>)[#text("(5)")]#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_6( \\{ \\tilde R_{\\omega,\\delta}: \\omega \\in \\Omega \\} ) \\lesssim_\\varepsilon \\delta^{-\\varepsilon}")]]

#text("for any ")#mi("{\\varepsilon>0}")#text(".")
]

#text("This result was first established ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3374964")[#text("by Bourgain and Demeter")]#text("; our arguments here will loosely follow an argument ")#link("https://arxiv.org/abs/1805.10551")[#text("of Li")]#text(", that is based in turn on the efficient congruencing methods ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3938716")[#text("of Wooley")]#text(", as recounted for instance in this exposition ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3939285")[#text("of Pierce")]#text(".")#linebreak()#text(" We first explain the significance of the exponent ")#mi("{6}")#text(" in Theorem ")#link(<tao-d617af7a922bffeca014>)[#text("13")]#text(". Let ")#mi("{\\Sigma}")#text(" be a maximal ")#mi("{\\delta}")#text("-separated subset ")#mi("{[-1,1]}")#text(" for some small ")#mi("{0 < \\delta < 1}")#text(", so that ")#mi("{\\Sigma}")#text(" has cardinality ")#mi("{\\sim \\delta^{-1}}")#text(". For each ")#mi("{\\omega \\in \\phi(\\Sigma)}")#text(", choose ")#mi("{f_\\omega}")#text(" so that ")#mi("{\\hat f_\\omega}")#text(" is a non-negative bump function (not identically zero) adapted to the parallelogram ")#mi("{\\tilde R_{\\omega,\\delta}}")#text(", which is comparable to a ")#mi("{\\delta \\times \\delta^2}")#text(" rectangle. From the Fourier inversion formula, ")#mi("{f_\\omega}")#text(" will then have magnitude ")#mi("{O(\\delta^3)}")#text(" on a dual rectangle of dimensions comparable to ")#mi("{1/\\delta \\times 1/\\delta^2}")#text(", and is rapidly decreasing away from that rectangle, so we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f_\\omega\\right\\|_{L^p({\\bf R}^2)} \\lesssim_p \\delta^3 \\delta^{-3/p}", block: true)]]

#text("for all ")#mi("{1 \\leq p \\leq \\infty}")#text(" and ")#mi("{\\omega \\in \\phi(\\Sigma)}")#text(". In particular")

#align(center)[#tao-fit-display[#tao-math("( \\sum_{\\omega \\in \\phi(\\Sigma)} \\left\\|f_\\omega\\right\\|_{L^p({\\bf R}^2)}^2)^{1/2} \\sim_p \\delta^{\\frac{5}{2} - \\frac{3}{p}}.", block: true)]]

#text("On the other hand, we have ")#mi("{\\mathrm{Re} f_\\omega(x) \\gtrsim \\delta^3}")#text(" for ")#tao-math("{\\left|x\\right| \\leq c}", block: false)#text(" if ")#mi("{c>0}")#text(" is a sufficiently small absolute constant, hence")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\sum_{\\omega \\in \\phi(\\Sigma)} f_\\omega\\right\\|_{L^p({\\bf R}^2)} \\gtrsim_p \\delta^2.", block: true)]]

#text("Comparing this with ")#link(<tao-fbe44a5fae52a92ad8c0>)[#text("(6)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_p( \\{ \\tilde R_\\omega: \\omega \\in \\phi(\\Sigma) \\} ) \\gtrsim_p \\delta^{\\frac{3}{p} - \\frac{1}{2}}")]]

#text("so Theorem ")#link(<tao-d617af7a922bffeca014>)[#text("13")]#text(" cannot hold if the exponent ")#mi("{6}")#text(" is replaced by any larger exponent. On the other direction, by using Exercise ")#link(<tao-7ddcdc0ab8180b8893fa>)[#text("10")]#text("(iv) and the trivial ")#mi("{p=2}")#text(" decoupling from ")#link(<tao-2c3a4249d77070058649>)[#text("(8)")]#text(", we see that we also have decoupling in ")#mi("{L^p}")#text(" for any ")#mi("{2 \\leq p \\leq 6}")#text(". (Note from the boundedness of the Hilbert transform that a Fourier projection to any polygon of boundedly many sides will be bounded in ")#mi("{L^p}")#text(" for any ")#mi("{1 < p < \\infty}")#text(" with norm ")#mi("{O_p(1)}")#text(".) Note that reverse square function estimates in Exercise ")#link(<tao-b33f19e0b6632651b414>)[#text("8")]#text(" only give decoupling in the smaller range ")#mi("{2 \\leq p \\leq 4}")#text("; the ")#mi("{L^6}")#text(" version of Lemma ")#link(<tao-05320182634464334694>)[#text("6")]#text(" is not strong enough to extend the decoupling estimates to larger ranges because the triple sums ")#mi("{\\tilde R_{\\omega_1} + \\tilde R_{\\omega_2} + \\tilde R_{\\omega_3}}")#text(" have too much overlap.")#linebreak()#text(" For any ")#mi("{0 < \\delta \\leq 1}")#text(", let ")#mi("{D(\\delta)}")#text(" denote the supremum of the decoupling constants ")#mi("{\\mathrm{Dec}_6( \\{ \\tilde R_{\\omega,\\delta}: \\omega \\in \\phi(\\Sigma) \\} )}")#text(" over all ")#mi("{\\delta}")#text("-separated subsets ")#mi("{\\Sigma}")#text(" of ")#mi("{[-1,1]}")#text(". From ")#link(<tao-4a2326c64ab2287ead87>)[#text("(7)")]#text(" we have the trivial bound")

#align(center)[#tao-fit-display[#mitex("1 \\leq D(\\delta) \\lesssim \\delta^{-1/2}")]]

#text("and our task is to show that ")#metadata(none) <tao-f93464a48a2b9281080b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("D(\\delta) \\lesssim_\\varepsilon \\delta^{-\\varepsilon}")]]

#text(" for any ")#mi("{\\varepsilon>0}")#text(".")#linebreak()#text(" We first make a minor observation on the stability of ")#mi("{D}")#text(" that is not absolutely essential for the arguments, but is convenient for cleaning up the notation slightly (otherwise we would have to replace various scales ")#mi("{\\delta}")#text(" that appear in later arguments by comparable scales ")#mi("{\\delta^{\\prime} \\sim \\delta}")#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 14 (Stability of ")#mi("{D}")#text(")")]#text(" ")#metadata(none) <tao-bdba154e242c57ecd619>#text(" If ")#mi("{0 < \\delta,\\delta^{\\prime} \\leq 1}")#text(" are such that ")#mi("{\\delta \\sim \\delta^{\\prime}}")#text(" then ")#mi("{D(\\delta) \\sim D(\\delta^{\\prime})}")#text(".")
]

#emph[#text("Proof:")]#text(" Without loss of generality we may assume that ")#mi("{\\delta^{\\prime} \\geq \\delta}")#text(". We first show that ")#mi("{D(\\delta) \\lesssim D(\\delta^{\\prime})}")#text(". We need to show that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_6( \\{ \\tilde R_{\\omega,\\delta}: \\omega \\in \\phi(\\Sigma)\\} ) \\lesssim D(\\delta^{\\prime})")]]

#text("whenever ")#mi("{\\Sigma}")#text(" is a ")#mi("{\\delta}")#text("-separated subset of the ")#mi("{[-1,1]}")#text(". By partitioning ")#mi("{\\Sigma}")#text(" into ")#mi("{O(1)}")#text(" pieces and using Exercise ")#link(<tao-7ddcdc0ab8180b8893fa>)[#text("10")]#text("(ii) we may assume without loss of generality that ")#mi("{\\Sigma}")#text(" is in fact ")#mi("{\\delta^{\\prime}}")#text("-separated. In particular")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_6( \\{ \\tilde R_{\\omega,\\delta^{\\prime}}: \\omega \\in \\phi(\\Sigma) \\} ) \\leq D(\\delta^{\\prime}).")]]

#text("The claim now follows from Exercise ")#link(<tao-7ddcdc0ab8180b8893fa>)[#text("10")]#text("(i) and the inclusion")

#align(center)[#tao-fit-display[#mitex("\\tilde R_{\\omega,\\delta} \\subset \\tilde R_{\\omega,\\delta^{\\prime}}.")]]

#text("Conversely, we need to show that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_6( \\{ \\tilde R_{\\omega^{\\prime},\\delta^{\\prime}}: \\omega^{\\prime} \\in \\phi(\\Sigma^{\\prime}) \\} ) \\lesssim D(\\delta)")]]

#text("whenever ")#mi("{\\Sigma^{\\prime} \\subset [-1,1]}")#text(" is ")#mi("{\\delta^{\\prime}}")#text("-separated, or equivalently that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{\\omega^{\\prime} \\in \\phi(\\Sigma^{\\prime})} f_{\\omega^{\\prime}} \\right\\|_{L^6({\\bf R}^2)} \\lesssim D(\\delta) (\\sum_{\\omega^{\\prime} \\in \\phi(\\Sigma^{\\prime})} \\left\\|f_{\\omega^{\\prime}}\\right\\|_{L^6({\\bf R}^2)}^2)^{1/2}", block: true)]]

#text("when ")#mi("{f_{\\omega^{\\prime}} \\in L^6({\\bf R}^2)}")#text(" (we can extend from ")#mi("{{\\mathcal S}({\\bf R}^2)}")#text(" to all of ")#mi("{L^6({\\bf R}^2)}")#text(" by a limiting argument). From elementary geometry we see that for each ")#mi("{\\xi^{\\prime} \\in \\Sigma^{\\prime}}")#text(" we can find a subset ")#mi("{\\Sigma_{\\xi^{\\prime}}}")#text(" of ")#mi("{[\\xi^{\\prime}-\\delta^{\\prime},\\xi^{\\prime}+\\delta^{\\prime}]}")#text(" of cardinality ")#mi("{O(1)}")#text(", such that the parallelograms ")#mi("{\\tilde R_{\\phi(\\xi),\\delta} + (0, jc\\delta^2)}")#text(" with ")#mi("{j=O(1)}")#text(" an integer, ")#mi("{\\xi \\in \\Sigma_{\\xi^{\\prime}}}")#text(", and ")#mi("{c>0}")#text(" a sufficiently small absolute constant, cover ")#mi("{R_{\\phi(\\xi^{\\prime}),\\delta^{\\prime}}}")#text(". In particular, using Fourier projections to polygons with ")#mi("{O(1)}")#text(" sides, one can split ")#metadata(none) <tao-b194fb14c9a90964b4bd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("f_{\\phi(\\xi^{\\prime})} = \\sum_{\\xi \\in \\Sigma_{\\xi^{\\prime}}} \\sum_{j=O(1)} g_{\\phi(\\xi),j},")]]

#text(" where each ")#mi("{g_{\\phi(\\xi),j} \\in L^6({\\bf R}^2)}")#text(" has Fourier support in ")#mi("{\\tilde R_{\\phi(\\xi),\\delta} + (0,jc\\delta^2)}")#text(" and ")#metadata(none) <tao-6cd65fa632f1d4292f5b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left\\|g_{\\phi(\\xi),j} \\right\\|_{L^6({\\bf R}^2)} \\lesssim \\left\\|f_{\\phi(\\xi^{\\prime})} \\right\\|_{L^6({\\bf R}^2)}.", block: true)]]

#text(" Now the collection ")#mi("{\\bigcup_{\\xi^{\\prime} \\in \\Sigma^{\\prime}} \\Sigma_{\\xi^{\\prime}}}")#text(" can be partitioned into ")#mi("{O(1)}")#text(" subcollections, each of which is ")#mi("{\\delta}")#text("-separated. From this and Exercise ")#link(<tao-7ddcdc0ab8180b8893fa>)[#text("10")]#text("(ii), (iii) we see that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_6( \\{ \\tilde R_{\\phi(\\xi),\\delta} + (0, jc\\delta^2): \\xi \\in \\bigcup_{\\xi^{\\prime} \\in \\Sigma^{\\prime}} \\Sigma_{\\xi^{\\prime}}; j = O(1) \\} ) \\lesssim D(\\delta)")]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{\\xi^{\\prime} \\in\\Sigma^{\\prime}} \\sum_{\\xi \\in \\Sigma_{\\xi^{\\prime}}} \\sum_{j = O(1)} g_{\\phi(\\xi),j} \\right\\|_{L^6({\\bf R}^2)} \\lesssim D(\\delta) (\\sum_{\\xi^{\\prime} \\in \\Sigma^{\\prime}} \\sum_{\\xi \\in \\Sigma_{\\xi^{\\prime}}} \\sum_{j=O(1)} \\left\\|g_{\\phi(\\xi),j}\\right\\|_{L^6({\\bf R}^2)}^2)^{1/2}.", block: true)]]

#text("Applying ")#link(<tao-b194fb14c9a90964b4bd>)[#text("(10)")]#text(", ")#link(<tao-6cd65fa632f1d4292f5b>)[#text("(11)")]#text(" we obtain the claim. ")#mi("\\Box")#linebreak()#text(" More importantly, we can use the symmetries of the parabola to control decoupling constants for parallelograms ")#mi("{R_{\\omega,\\delta}}")#text(" in a set of diameter ")#mi("{O(\\delta_0)}")#text(" in terms of a coarser scale decoupling constant ")#mi("{D(\\delta/\\delta_0)}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 15 (Parabolic rescaling)")]#text(" ")#metadata(none) <tao-354b7e73ab60e1a1bb6c>#text(" Let ")#mi("{0 < \\delta \\leq \\delta_0 \\leq 1}")#text(", and let ")#mi("{\\Sigma}")#text(" be a ")#mi("{\\delta}")#text("-separated subset of an interval ")#mi("{I \\subset [-1,1]}")#text(" of length ")#mi("{2\\delta_0}")#text(". Then ")#metadata(none) <tao-79b98f273c175489f40b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\mathrm{Dec}_6( \\{ \\tilde R_{\\omega,\\delta}: \\omega \\in \\phi(\\Sigma) \\} ) \\lesssim D(\\delta/\\delta_0).")]]


]

#emph[#text("Proof:")]#text(" We can assume that ")#mi("{\\delta_0<c}")#text(" for a small absolute constant ")#mi("{c}")#text(", since when ")#mi("{c \\leq \\delta_0 \\leq 1}")#text(" the claim follows from Lemma ")#link(<tao-bdba154e242c57ecd619>)[#text("14")]#text(". Write ")#mi("{I = [\\xi_0-\\delta_0,\\xi_0+\\delta_0]}")#text(". Applying the Galilean transform")

#align(center)[#tao-fit-display[#mitex("G: (\\xi_1, \\xi_2) \\mapsto (\\xi_1 - \\xi_{0}, \\xi_2 - 2 \\xi_{0} \\xi_1 + \\xi_{0}^2)")]]

#text("(which preserves the parabola, and maps parallelograms ")#mi("{\\tilde R_{\\omega,\\delta}}")#text(" to ")#mi("{\\tilde R_{G(\\omega),\\delta}}")#text(") and Exercise ")#link(<tao-7ddcdc0ab8180b8893fa>)[#text("10")]#text("(iii), we may normalise ")#mi("{\\xi_0=0}")#text(", so ")#mi("{\\Sigma \\subset [-\\delta_0,\\delta_0]}")#text(".")#linebreak()#text(" Now let ")#mi("{T: {\\bf R}^2 \\rightarrow {\\bf R}^2}")#text(" be the parabolic rescaling map")

#align(center)[#tao-fit-display[#mitex("T: (\\xi_1,\\xi_2) \\mapsto (\\xi_1/\\delta_0, \\xi_2/\\delta^2_0).")]]

#text("Observe that ")#mi("{T}")#text(" maps ")#mi("{\\tilde R_{\\phi(\\xi),\\delta}}")#text(" to ")#mi("{\\tilde R_{\\phi(\\xi/\\delta_0),\\delta/\\delta_0}}")#text(" for any ")#mi("{\\xi}")#text(". From Exercise ")#link(<tao-7ddcdc0ab8180b8893fa>)[#text("10")]#text("(iii) again, we can write the left-hand side of ")#link(<tao-79b98f273c175489f40b>)[#text("(12)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_6( \\{ \\tilde R_{\\omega,\\delta/\\delta}: \\omega \\in \\phi(\\Sigma/\\delta_0)\\} );")]]

#text("since ")#mi("{\\Sigma/\\delta_0}")#text(" is ")#mi("{\\delta_0}")#text("-separated, the claim then follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16 (Multiplicativity)")]#text(" ")#metadata(none) <tao-c0c75a8e79ad011929e6>#text(" Show that ")#mi("{D(\\delta_1 \\delta_2) \\lesssim D(\\delta_1) D(\\delta_2)}")#text(" for all ")#mi("{0 < \\delta_1,\\delta_2 \\leq 1}")#text(".")
]

#text("The multiplicativity property in Exercise ")#link(<tao-c0c75a8e79ad011929e6>)[#text("16")]#text(" suggests that an induction on scales approach could be fruitful to establish ")#link(<tao-f93464a48a2b9281080b>)[#text("(9)")]#text(". Interestingly, it does not seem possible to induct directly on ")#mi("{D(\\delta)}")#text("; all the known proofs of this decoupling estimate proceed by introducing some auxiliary variant of ")#mi("{D(\\delta)}")#text(" that looks more complicated (in particular, involving additional scale parameters than just the base scale ")#mi("{\\delta}")#text("), but which obey some inequalities somewhat reminiscent of the one in Exercise ")#link(<tao-c0c75a8e79ad011929e6>)[#text("16")]#text(" for which an induction on scale argument can be profitably executed. It is yet not well understood exactly what choices of auxiliary quantity work best, but we will use the following choice ")#link("https://arxiv.org/abs/1805.10551")[#text("of Li")]#text(" of a certain “asymmetric bilinear” variant of the decoupling constant:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 17 (Bilinear decoupling constant)")]#text(" Let ")#mi("{0 \\leq \\delta \\leq \\rho_1,\\rho_2 \\leq \\nu \\leq 1}")#text(". Define ")#mi("{M_{2,4}(\\delta,\\nu, \\rho_1,\\rho_2)}")#text(" to be the best constant for which one has the estimate ")#metadata(none) <tao-47dfae9288abf3d5d225>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\int_{{\\bf R}^2} \\left|\\sum_{\\omega_1 \\in \\phi(\\Sigma_1)} f_{\\omega_1}\\right|^2 \\left|\\sum_{\\omega_2 \\in \\phi(\\Sigma_2)} g_{\\omega_2}\\right|^4 \\leq M_{2,4}(\\delta,\\nu,\\rho_1,\\rho_2)^6", block: true)]]



#align(center)[#tao-fit-display[#tao-math("\\times (\\sum_{\\omega_1 \\in \\phi(\\Sigma_1)} \\left\\|f_{\\omega_1}\\right\\|_{L^6({\\bf R}^2)}^2) (\\sum_{\\omega_2 \\in \\phi(\\Sigma_2)} \\left\\|g_{\\omega_2}\\right\\|_{L^6({\\bf R}^2)}^2)^2", block: true)]]

#text("whenever ")#mi("{\\Sigma_1,\\Sigma_2}")#text(" are ")#mi("{\\delta}")#text("-separated subsets of intervals ")#mi("{I_1, I_2 \\subset [0,1]}")#text(" of length ")#mi("{\\rho_1, \\rho_2}")#text(" respectively with ")#mi("{\\mathrm{dist}(I_1,I_2) \\geq \\nu}")#text(", and for each ")#mi("{\\omega_1 \\in \\phi(\\Omega_1)}")#text(", ")#mi("{f_{\\omega_1} \\in {\\mathcal S}({\\bf R})}")#text(" has Fourier support in ")#mi("{\\tilde R_{\\omega_1,\\delta}}")#text(", and similarly for each ")#mi("{\\omega_2 \\in \\phi(\\Omega_2)}")#text(", ")#mi("{g_{\\omega_2} \\in {\\mathcal S}({\\bf R})}")#text(" has Fourier support in ")#mi("{\\tilde R_{\\omega_2,\\delta}}")#text(".")
]

#text("The scale ")#mi("{\\nu}")#text(" is present for technical reasons and the reader may wish to think of it as essentially being comparable to ")#mi("{1}")#text(". Rather than inducting in ")#mi("{\\delta}")#text(", we shall mostly keep ")#mi("{\\delta}")#text(" fixed and primarily induct instead on ")#mi("{\\rho_1,\\rho_2}")#text(". As we shall see later, the asymmetric splitting of the sixth power exponent as ")#mi("{6=2+4}")#text(" is in order to exploit ")#mi("{L^2}")#text(" orthogonality in the first factor.")#linebreak()#text(" From Hölder’s inequality, the left-hand side of ")#link(<tao-47dfae9288abf3d5d225>)[#text("(13)")]#text(" is bounded by")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{\\omega_1 \\in \\phi(\\Sigma_1)} f_{\\omega_1}\\right\\|_{L^6({\\bf R}^2)}^2 \\left\\| \\sum_{\\omega_1 \\in \\phi(\\Sigma_1)} g_{\\omega_1}\\right\\|_{L^6({\\bf R}^2)}^4", block: true)]]

#text("from which we conclude the bound ")#metadata(none) <tao-079cdc52e64462dfac51>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("M_{2,4}(\\delta,\\nu,\\rho_1,\\rho_2) \\leq D(\\delta).")]]

#linebreak()#text(" When ")#mi("{\\rho_1,\\rho_2}")#text(" are at their maximal size ")#mi("{\\rho_1=\\rho_2=\\nu}")#text(" we can use these bilinear decoupling constants ")#mi("{M_{2,4}(\\delta,\\nu,\\rho_1,\\rho_2)}")#text(" to recover control on the decoupling constants ")#mi("{D(\\delta)}")#text(", thanks to parabolic rescaling:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 18 (Bilinear reduction)")]#text(" ")#metadata(none) <tao-bb3be5d12d4e85f6a02c>#text(" If ")#mi("{0 \\leq \\delta \\leq \\nu \\leq 1}")#text(", then")

#align(center)[#tao-fit-display[#mitex("D(\\delta) \\lesssim \\nu^{-O(1)} M_{2,4}(\\delta, \\nu, \\nu, \\nu) + D(\\delta/\\nu).")]]
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\Sigma}")#text(" be a ")#mi("{\\delta}")#text("-separated subset of ")#mi("{[-1,1]}")#text(", and for each ")#mi("{\\omega \\in \\phi(\\Sigma)}")#text(" let ")#mi("{f_\\omega \\in L^6({\\bf R}^2)}")#text(" be Fourier supported in ")#mi("{\\tilde R_{\\omega,\\delta}}")#text(". We may normalise ")#tao-math("{\\sum_{\\omega \\in \\phi(\\Sigma)} \\left\\| f_\\omega\\right\\|_{L^6({\\bf R}^2)}^2 = 1}", block: false)#text(". It will then suffice to show that ")#metadata(none) <tao-73d1b1b1bc1dabfb97f2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\int_{{\\bf R}^2} \\left|\\sum_{\\omega \\in \\phi(\\Sigma)} f_\\omega\\right|^6 \\lesssim \\nu^{-O(1)} M_{2,4}(\\delta, \\nu, \\nu, \\nu)^6 + D(\\delta/\\nu)^6.", block: true)]]

#text(" We partition ")#mi("{\\Sigma}")#text(" into disjoint components ")#mi("{\\Sigma_I}")#text(", each of which is supported in a subinterval ")#mi("{I}")#text(" of ")#mi("{[-1,1]}")#text(" of length ")#mi("{\\nu}")#text(", with the family ")#mi("{{\\mathcal I}}")#text(" of intervals ")#mi("{I}")#text(" having bounded overlap, so in particular ")#mi("{{\\mathcal I}}")#text(" has cardinality ")#mi("{O(\\nu^{-1})}")#text(". Then for any ")#mi("{x \\in {\\bf R}^2}")#text(", we of course have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{\\omega \\in \\phi(\\Sigma)} f_\\omega(x)\\right| \\leq \\sum_{I \\in {\\mathcal I}} |\\sum_{\\omega \\in \\phi(\\Sigma_I)} f_\\omega(x)|.", block: true)]]

#text("From the pigeonhole principle, this implies at least one of the following statements needs to hold for each given ")#mi("{x}")#text(":")

#list(
[#text("(i) (Narrow case) There exists ")#mi("{I \\in {\\mathcal I}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{\\omega \\in \\phi(\\Sigma)} f_\\omega(x)\\right| \\lesssim \\left|\\sum_{\\omega \\in \\phi(\\Sigma_I)} f_\\omega(x)\\right|.", block: true)]]],
[#text("(ii) (Broad case) There exist distinct intervals ")#mi("{I,J \\in {\\mathcal I}}")#text(" with ")#mi("{\\mathrm{dist}(I,J) \\geq \\nu}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{\\omega \\in \\phi(\\Sigma)} f_\\omega(x)\\right| \\lesssim \\nu^{-O(1)} \\left|\\sum_{\\omega \\in \\phi(\\Sigma_I)} f_\\omega(x)\\right|, \\nu^{-O(1)} |\\sum_{\\omega \\in \\phi(\\Sigma_J)} f_\\omega(x)|.", block: true)]]]
)

#text("(The reason for this is as follows. Write ")#tao-math("{A := \\left|\\sum_{\\omega \\in \\phi(\\Sigma)} f_\\omega(x)\\right|}", block: false)#text(" and ")#tao-math("{A_I := \\left|\\sum_{\\omega \\in \\phi(\\Sigma_I)} f_\\omega(x)\\right|}", block: false)#text(", then ")#mi("{A \\leq \\sum_I A_I}")#text(". Let ")#mi("{N = O(\\nu^{-1})}")#text(" be the number of intervals ")#mi("{I}")#text(", then ")#mi("{\\sum_{I: A_I \\leq A/2N} A_I \\leq A/2}")#text(", hence ")#mi("{\\sum_{I: A_I > A/2N} A_I > A/2}")#text(". If there are only ")#mi("{O(1)}")#text(" intervals ")#mi("{I}")#text(" for which ")#mi("{A_I > A/2N}")#text(", then by the pigeonhole principle we have ")#mi("{A_I \\gtrsim A}")#text(" for one of these ")#mi("{I}")#text(" and we are in the narrow case (i); otherwise, if there are sufficiently many ")#mi("{I}")#text(" for which ")#mi("{A_I > A/2N}")#text(", one can find two such ")#mi("{I,J}")#text(" with ")#mi("{\\mathrm{dist}(I,J) \\geq \\nu}")#text(", and we are in the broad case (ii).) This implies the pointwise bound")

#tao-aligned(keep: true)[


#tao-math("\\left|\\sum_{\\omega \\in \\phi(\\Sigma)} f_\\omega\\right|^6  & \\lesssim \\nu^{-O(1)} \\sum_{I,J \\in {\\mathcal I}: \\mathrm{dist}(I,J) \\geq \\nu} \\left|\\sum_{\\omega \\in \\phi(\\Sigma_I)} f_\\omega\\right|^2 \\left|\\sum_{\\omega \\in \\phi(\\Sigma_J)} f_\\omega\\right|^4", block: true)



#tao-math(" & + \\sum_{I \\in {\\mathcal I}} \\left|\\sum_{\\omega \\in \\phi(\\Sigma_I)} f_\\omega\\right|^6.", block: true)
]

#text("(We remark that more advanced versions of this “narrow-broad decomposition” in higher dimensions, taking into account more of the geometry of the various frequencies ")#mi("{\\omega}")#text(" that arise in such sums, are useful in both restriction and decoupling theory; see this ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3877019")[#text("paper of Guth")]#text(" for more discussion.) From ")#link(<tao-47dfae9288abf3d5d225>)[#text("(13)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^2} \\left|\\sum_{\\omega \\in \\phi(\\Sigma_I)} f_\\omega\\right|^2 \\left|\\sum_{\\omega \\in \\phi(\\Sigma_J)} f_\\omega\\right|^4 \\lesssim M_{2,4}(\\delta,\\nu,\\nu,\\nu)^6", block: true)]]

#text("while from Proposition ")#link(<tao-354b7e73ab60e1a1bb6c>)[#text("15")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^2} \\left|\\sum_{\\omega \\in \\phi(\\Sigma_I)} f_\\omega\\right|^6 \\lesssim D(\\delta/\\nu)^6 (\\sum_{\\omega \\in \\phi(\\Sigma_I)} \\left\\| f_\\omega\\right\\|_{L^6({\\bf R}^2)}^2)^3", block: true)]]

#text("and hence")

#tao-aligned(keep: true)[


#tao-math("\\sum_{I \\in {\\mathcal I}} \\int_{{\\bf R}^2} \\left|\\sum_{\\omega \\in \\phi(\\Sigma_I)} f_\\omega\\right|^6  & \\lesssim D(\\delta/\\nu)^6 (\\sum_{\\omega \\in \\phi(\\Sigma)} \\left\\| f_\\omega\\right\\|_{L^6({\\bf R}^2)}^2)^3", block: true)



#tao-math(" & = D(\\delta/\\nu)^6.", block: true)
]

#text("Combining all these estimates, we obtain the claim. ")#mi("\\Box")#linebreak()#text(" In practice the ")#mi("{D(\\delta/\\nu)}")#text(" term here will be negligible as long as ")#mi("{\\nu}")#text(" is just slightly smaller than ")#mi("{1}")#text(" (e.g. ")#mi("{\\nu = \\delta^\\varepsilon}")#text(" for some small ")#mi("{\\varepsilon>0}")#text("). Thus, the above bilinear reduction is asserting that up to powers of ")#mi("{\\nu}")#text(" (which will be an acceptable loss in practice), the quantity ")#mi("{D(\\delta)}")#text(" is basically comparable to ")#mi("{M_{2,4}(\\delta,\\nu,\\nu,\\nu)}")#text(".")#linebreak()#text(" If we immediately apply insert ")#link(<tao-079cdc52e64462dfac51>)[#text("(14)")]#text(" into the above lemma, we obtain a useless inequality due to the loss of ")#mi("{\\nu^{-O(1)})}")#text(" in the main term on the right-hand side. To get an improved estimate, we will need a recursive inequality that allows one to slowly gain additional powers of ")#mi("{\\nu}")#text(" at the cost of decreasing the size of ")#mi("{\\rho_1,\\rho_2}")#text(" factors (but as long as ")#mi("{\\nu}")#text(" is much larger than ")#mi("{\\delta}")#text(", we will have enough “room” to iterate this inequality repeatedly). The key tool for doing this (and the main reason why we make the rather odd choice of splitting the exponents as ")#mi("{6=2+4}")#text(") is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 19 (Key estimate)")]#text(" ")#metadata(none) <tao-2c70e12b7a0646f92279>#text(" If ")#mi("{0 \\leq \\delta \\leq \\rho^{\\prime}_1,\\rho_1,\\rho_2 \\leq \\nu \\leq 1}")#text(" with ")#mi("{\\rho_2^2 \\leq \\rho^{\\prime}_1 \\leq \\rho_1}")#text(" then")

#align(center)[#tao-fit-display[#mitex("M_{2,4}(\\delta,\\nu,\\rho_1,\\rho_2) \\lesssim \\nu^{-O(1)} M_{2,4}(\\delta,\\nu,\\rho^{\\prime}_1,\\rho_2).")]]
]

#emph[#text("Proof:")]#text(" It will suffice to show that ")#metadata(none) <tao-a9f615c4e7d33cf9a6a2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\int_{{\\bf R}^2} \\left|\\sum_{\\omega_1 \\in \\phi(\\Sigma_1)} f_{\\omega_1}\\right|^2 \\left|\\sum_{\\omega_2 \\in \\phi(\\Sigma_2)} g_{\\omega_2}\\right|^4 \\lesssim \\nu^{-O(1)} M_{2,4}(\\delta,\\nu,\\rho^{\\prime}_1,\\rho_2)^6", block: true)]]

#text(" whenever ")#mi("{\\Sigma_1, \\Sigma_2}")#text(" are ")#mi("{\\delta}")#text("-separated subsets of intervals ")#mi("{I, J \\subset [-1,1]}")#text(" of length ")#mi("{\\rho_1, \\rho_2}")#text(" respectively with ")#mi("{\\mathrm{dist}(I,J) \\geq \\nu}")#text(", and ")#mi("{f_{\\omega_1}, g_{\\omega_2}}")#text(" have Fourier support on ")#mi("{\\tilde R_{\\omega_1,\\delta}, \\tilde R_{\\omega_2,\\delta}}")#text(" respectvely for ")#mi("{\\omega_1 \\in \\phi(\\Sigma_1), \\omega_2 \\in \\phi(\\Sigma_2)}")#text(", and we have the normalisation")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\omega_1 \\in \\phi(\\Sigma_1)} \\left\\|f_{\\omega_1}\\right\\|_{L^6({\\bf R}^2)}^2 = \\sum_{\\omega_2 \\in \\phi(\\Sigma_2)} \\left\\|g_{\\omega_2}\\right\\|_{L^6({\\bf R}^2)}^2 = 1.", block: true)]]

#text("We can partition ")#mi("{\\Sigma_1}")#text(" as ")#mi("{\\Sigma_1 = \\biguplus_{I^{\\prime} \\in {\\mathcal I}^{\\prime}} \\Sigma_{1,I^{\\prime}}}")#text(", where ")#mi("{{\\mathcal I}^{\\prime}}")#text(" is a collection of intervals ")#mi("{I^{\\prime} \\subset I}")#text(" of length ")#mi("{\\rho^{\\prime}_1}")#text(" that have bounded overlap, and ")#mi("{\\Sigma_{1,I^{\\prime}}}")#text(" is a ")#mi("{\\delta}")#text("-separated subset of ")#mi("{I^{\\prime}}")#text(". We can then rewrite the left-hand side of ")#link(<tao-a9f615c4e7d33cf9a6a2>)[#text("(16)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{I^{\\prime} \\in {\\mathcal I}^{\\prime}} F_{I^{\\prime}} G^2 \\right\\|_{L^2({\\bf R}^2)}^2", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("F_{I^{\\prime}} := \\sum_{\\omega_1 \\in \\phi(\\Sigma_{1,I^{\\prime}})} f_{\\omega_1}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("G := \\sum_{\\omega_2 \\in \\phi(\\Sigma_2)} g_{\\omega_2}.")]]

#text("From ")#link(<tao-47dfae9288abf3d5d225>)[#text("(13)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F_{I^{\\prime}} G^2 \\right\\|_{L^2({\\bf R}^2)}^2 \\leq M_{2,4}(\\delta,\\nu,\\rho^{\\prime}_1,\\rho_2)^6 \\sum_{\\omega_1 \\in \\phi(\\Sigma_{1,I^{\\prime}})} \\left\\|f_{\\omega_1}\\right\\|_{L^6({\\bf R}^2)}^2", block: true)]]

#text("so it will suffice to prove the almost orthogonality estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{I^{\\prime} \\in {\\mathcal I}^{\\prime}} F_{I^{\\prime}} G^2 \\right\\|_{L^2({\\bf R}^2)}^2 \\lesssim \\nu^{-O(1)} \\sum_{I^{\\prime} \\in {\\mathcal I}^{\\prime}} \\left\\| F_{I^{\\prime}} G^2 \\right\\|_{L^2({\\bf R}^2)}^2.", block: true)]]

#text("By Lemma ")#link(<tao-05320182634464334694>)[#text("6")]#text("(i), it suffices to show that the Fourier supports of ")#mi("{F_{I^{\\prime}} G^2}")#text(" have overlap ")#mi("{O(\\nu^{-O(1)})}")#text(".")#linebreak()#text(" Applying a Galilean transformation, we may normalise the interval ")#mi("{J}")#text(" to be centered at the origin, thus ")#mi("{J = [-\\rho_2/2,\\rho_2/2]}")#text(", and ")#mi("{I}")#text(" is now at a distance ")#mi("{\\gtrsim \\nu}")#text(" from the origin. (Strictly speaking this may push ")#mi("{I, I^{\\prime}}")#text(" out to now lie in ")#mi("{[-2,2]}")#text(" rather than ")#mi("{[-1,1]}")#text(", but this will not make a significant impact to the arguments.) In particular, all the rectangles ")#mi("{\\tilde R_{\\omega_2,\\delta}}")#text(", ")#mi("{\\omega_2 \\in \\Sigma_2}")#text(", now lie in a rectangle of the form ")#mi("{\\{ (\\xi_1,\\xi_2): \\xi_1 = O(\\rho_2), \\xi_2 = O(\\rho_2^2 + \\delta) \\}}")#text(", and hence ")#mi("{G}")#text(" and ")#mi("{G^2}")#text(" have Fourier support in such a rectangle also (after enlarging the implied constants in the ")#mi("{O()}")#text(" notation appropriately). Meanwhile, if ")#mi("{I^{\\prime} \\in {\\mathcal I}}")#text(" is centered at ")#mi("{\\xi_{I^{\\prime}}}")#text(", then (since the map ")#mi("{\\xi \\mapsto \\xi^2}")#text(" has Lipschitz constant ")#mi("{O(1)}")#text(" when ")#mi("{\\xi \\in [-2,2]}")#text(" and ")#mi("{\\delta \\leq \\rho^{\\prime}_1}")#text(") the parallelogram ")#mi("{\\tilde R_{\\omega_1,\\delta}}")#text(" is supported in the strip ")#mi("{\\{ (\\xi_1,\\xi_2): \\xi_2 = \\xi_{I^{\\prime}}^2 + O( \\rho^{\\prime}_1 ) \\}}")#text(" for any ")#mi("{\\omega_1 \\in \\Sigma_{1,I^{\\prime}}}")#text(", hence ")#mi("{F_{I^{\\prime}}}")#text(" will also be supported in such a strip. Since ")#mi("{\\rho^{\\prime}_1 \\geq \\rho_2^2, \\delta}")#text(", ")#mi("{F_{I^{\\prime}} G^2}")#text(" is supported in a similar strip (with slightly different implied constants in the ")#mi("{O()}")#text(" notation). Thus, if ")#mi("{F_{I^{\\prime}} G^2}")#text(" and ")#mi("{F_{J^{\\prime}} G^2}")#text(" have overlapping Fourier supports for ")#mi("{I^{\\prime},J^{\\prime} \\in {\\mathcal I}^{\\prime}}")#text(", then ")#mi("{\\xi_{I^{\\prime}}^2 = \\xi_{J^{\\prime}}^2 + O(\\rho^{\\prime}_1)}")#text(", hence (since ")#tao-math("{\\left|\\xi_{I^{\\prime}}\\right| \\gtrsim \\nu}", block: false)#text(") ")#mi("{\\xi_{I^{\\prime}} = \\pm \\xi_{J^{\\prime}} + O(\\nu^{-O(1)} \\rho^{\\prime}_1)}")#text(". Since the intervals ")#mi("{J^{\\prime}}")#text(" have length ")#mi("{\\rho^{\\prime}_1}")#text(" and bounded overlap, we thus see that each ")#mi("{I^{\\prime}}")#text(" has at most ")#mi("{O(\\nu^{-O(1)})}")#text(" intervals ")#mi("{J^{\\prime}}")#text(" for which ")#mi("{F_{I^{\\prime}} G^2}")#text(" and ")#mi("{F_{J^{\\prime}} G^2}")#text(" have overlapping Fourier supports, and the claim follows. ")#mi("\\Box")#linebreak()#text(" The final ingredient needed is a simple application of Hölder’s inequality to allow one to (partially) swap ")#mi("{\\rho_1}")#text(" and ")#mi("{\\rho_2}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" ")#metadata(none) <tao-d773c6ef7075afce5167>#text(" For any ")#mi("{0 \\leq \\delta \\leq \\rho_1 \\leq \\rho_2 \\leq \\nu \\leq 1}")#text(", establish the inequality")

#align(center)[#tao-fit-display[#mitex("M_{2,4}(\\delta,\\nu,\\rho_1,\\rho_2) \\lesssim M_{2,4}(\\delta,\\nu,\\rho_2,\\rho_1)^{1/2} D(\\delta/\\rho_2)^{1/2}.")]]
]

#text("Now we have enough inequalities to establish the claim ")#link(<tao-f93464a48a2b9281080b>)[#text("(9)")]#text(". Let ")#mi("{\\alpha}")#text(" be the least exponent for which we have the bound")

#align(center)[#tao-fit-display[#mitex("D(\\delta) \\lesssim_\\varepsilon \\delta^{-\\alpha-\\varepsilon}")]]

#text("for all ")#mi("{0 < \\delta \\leq 1}")#text(" and ")#mi("{\\varepsilon>0}")#text("; equivalently, we have")

#align(center)[#tao-fit-display[#mitex("\\alpha = \\limsup_{\\delta \\rightarrow 0} \\frac{\\log D(\\delta)}{\\log 1/\\delta}.")]]

#text("Another equivalent formulation is that ")#mi("{\\alpha}")#text(" is the least exponent for which we have the bound ")#metadata(none) <tao-6fe8ecbc1deafa51c2ec>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("D(\\delta) \\leq \\delta^{-\\alpha-o(1)}")]]

#text(" as ")#mi("{\\delta \\rightarrow 0}")#text(" where ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{\\delta \\rightarrow 0}")#text(". Clearly ")#mi("{\\alpha \\geq 0}")#text("; our task is to show that ")#mi("{\\alpha=0}")#text(".")#linebreak()#text(" Suppose for contradiction that ")#mi("{\\alpha > 0}")#text(". We will establish the bound ")#metadata(none) <tao-c2ba348d1ffd70736f32>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("D(\\delta) \\leq \\delta^{-\\alpha^{\\prime}-o(1)}")]]

#text(" as ")#mi("{\\delta \\rightarrow 0}")#text(" for some ")#mi("{\\alpha^{\\prime} < \\alpha}")#text(", which will give the desired contradiction.")#linebreak()#text(" Let ")#mi("{\\nu = \\delta^\\varepsilon}")#text(" for some small exponent ")#mi("{\\varepsilon>0}")#text(" (independent of ")#mi("{\\delta}")#text(", but depending on ")#mi("{\\alpha}")#text(") to be chosen later. From Proposition ")#link(<tao-bb3be5d12d4e85f6a02c>)[#text("18")]#text(" and ")#link(<tao-6fe8ecbc1deafa51c2ec>)[#text("(17)")]#text(" we have ")#metadata(none) <tao-9b7ecc6eeb83abf9ade1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("D(\\delta) \\lesssim \\delta^{-O(\\varepsilon)} M_{2,4}(\\delta,\\nu,\\nu,\\nu) + \\delta^{-(1-\\varepsilon)\\alpha-o(1)}.")]]

#text(" Since ")#mi("{\\alpha>0}")#text(", the second term on the right-hand side is already of the desired form; it remains to get a sufficiently good bound on the first term. Note that a direct application of ")#link(<tao-079cdc52e64462dfac51>)[#text("(14)")]#text(", ")#link(<tao-6fe8ecbc1deafa51c2ec>)[#text("(17)")]#text(" bounds this term by ")#mi("{\\delta^{\\alpha + O(\\varepsilon) + o(1)}}")#text("; we need to improve this bound by a large multiple of ")#mi("{\\varepsilon}")#text(" to conclude. To obtain this improvement we will repeatedly use Proposition ")#link(<tao-2c70e12b7a0646f92279>)[#text("19")]#text(" and Exercise ")#link(<tao-d773c6ef7075afce5167>)[#text("20")]#text(". Firstly, from Proposition ")#link(<tao-2c70e12b7a0646f92279>)[#text("19")]#text(" we have ")#metadata(none) <tao-3eaf7db172bf7b71dbb8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("M_{2,4}(\\delta,\\nu,\\nu,\\nu) \\lesssim \\nu^{-O(1)} M_{2,4}(\\delta,\\nu,\\nu^2,\\nu)")]]

#text(" if ")#mi("{\\varepsilon}")#text(" is small enough. To control the right-hand side, we more generally consider expressions of the form")

#align(center)[#tao-fit-display[#mitex("M_{2,4}(\\delta,\\nu,\\nu^{2a},\\nu^{a})")]]

#text("for various ")#mi("{a \\geq 1}")#text("; this quantity is well-defined if ")#mi("{\\varepsilon}")#text(" is small enough depending on ")#mi("{a}")#text(". From Exercise ")#link(<tao-d773c6ef7075afce5167>)[#text("20")]#text(" and ")#link(<tao-6fe8ecbc1deafa51c2ec>)[#text("(17)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("M_{2,4}(\\delta,\\nu,\\nu^{2a},\\nu^a) \\lesssim M_{2,4}(\\delta,\\nu,\\nu^{a},\\nu^{2a})^{1/2} \\delta^{-\\alpha/2-o(1)} \\delta^{\\alpha a \\varepsilon/2}")]]

#text("and then by Proposition ")#link(<tao-2c70e12b7a0646f92279>)[#text("19")]#text(" ")#metadata(none) <tao-dbde6e431edd7f4672f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("M_{2,4}(\\delta,\\nu,\\nu^{2a},\\nu^a) \\lesssim \\nu^{-O(1)} M_{2,4}(\\delta,\\nu,\\nu^{4a},\\nu^{2a})^{1/2} \\delta^{-\\alpha/2-o(1)} \\delta^{\\alpha a \\varepsilon/2}")]]

#text(" if ")#mi("{\\varepsilon}")#text(" is small enough depending on ")#mi("{a}")#text(". We rearrange this as")

#align(center)[#tao-fit-display[#mitex("(\\delta^{\\alpha} M_{2,4}(\\delta,\\nu,\\nu^{2a},\\nu^a))^{1/a} \\lesssim (\\delta^{\\alpha} M_{2,4}(\\delta,\\nu,\\nu^{4a},\\nu^{2a}))^{1/2a} \\delta^{\\alpha \\varepsilon/2 - O(\\varepsilon/a) - o(1)}.")]]

#text("The crucial fact here is that we gain a small power of ")#mi("{\\delta^\\varepsilon}")#text(" on the right-hand side when ")#mi("{a}")#text(" is large. Iterating this inequality ")#mi("{k}")#text(" times, we see that")

#align(center)[#tao-fit-display[#mitex("\\delta^{\\alpha} M_{2,4}(\\delta,\\nu,\\nu^{2},\\nu) \\lesssim_k (\\delta^{\\alpha} M_{2,4}(\\delta,\\nu,\\nu^{2^{k+1}},\\nu^{2^k}))^{1/2^k} \\delta^{k\\alpha \\varepsilon/2-O(\\varepsilon) - o_k(1)}")]]

#text("for any given ")#mi("{k}")#text(", if ")#mi("{\\varepsilon}")#text(" is small enough depending on ")#mi("{k}")#text(", and ")#mi("{o_k(1)}")#text(" denotes a quantity that goes to zero in the limit ")#mi("{\\delta \\rightarrow 0}")#text(" holding ")#mi("{k,\\varepsilon}")#text(" fixed. Now we can afford to apply ")#link(<tao-079cdc52e64462dfac51>)[#text("(14)")]#text(", ")#link(<tao-6fe8ecbc1deafa51c2ec>)[#text("(17)")]#text(" and conclude that")

#align(center)[#tao-fit-display[#mitex("\\delta^{\\alpha} M_{2,4}(\\delta,\\nu,\\nu^{2},\\nu) \\lesssim \\delta^{k\\alpha \\varepsilon/2-O(\\varepsilon) - o(1)}")]]

#text("which when inserted back into ")#link(<tao-3eaf7db172bf7b71dbb8>)[#text("(20)")]#text(", ")#link(<tao-9b7ecc6eeb83abf9ade1>)[#text("(19)")]#text(" gives")

#align(center)[#tao-fit-display[#mitex("D(\\delta) \\lesssim \\delta^{-\\alpha + k\\alpha \\varepsilon/2 - O(\\varepsilon) + o(1)} + \\delta^{-\\alpha + \\varepsilon \\alpha + o(1)}.")]]

#text("If we then choose ")#mi("{k}")#text(" large enough depending on ")#mi("{\\alpha}")#text(", and ")#mi("{\\varepsilon}")#text(" small enough depending on ")#mi("{k}")#text(", we obtain the desired improved bound ")#link(<tao-c2ba348d1ffd70736f32>)[#text("(18)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 21")]#text(" An alternate arrangement of the above argument is as follows. For any exponent ")#mi("{\\theta}")#text(", let ")#mi("{P(\\theta)}")#text(" denote the claim that ")#metadata(none) <tao-b8eb9bede31921daba6c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("M_{2,4}(\\delta,\\nu,\\nu^{2a},\\nu^{a}) \\lesssim_\\theta \\delta^{-\\alpha + o(1)} \\nu^{a\\theta + O_\\theta(1)}")]]

#text(" whenever ")#mi("{a \\geq 1}")#text(", ")#mi("{\\nu = \\delta^\\varepsilon}")#text(" with ")#mi("{\\varepsilon}")#text(" sufficiently small depending on ")#mi("{a}")#text(", and ")#mi("{\\delta}")#text(" is sent to zero holding ")#mi("{a,\\varepsilon}")#text(" fixed. The bounds ")#link(<tao-079cdc52e64462dfac51>)[#text("(14)")]#text(", ")#link(<tao-6fe8ecbc1deafa51c2ec>)[#text("(17)")]#text(" give the claim ")#mi("{P(0)}")#text(". On the other hand, the bound ")#link(<tao-dbde6e431edd7f4672f0>)[#text("(21)")]#text(" shows that ")#mi("{P(\\theta)}")#text(" implies ")#mi("{P(\\theta+\\alpha/2)}")#text(" for any given ")#mi("{\\theta}")#text(". Thus if ")#mi("{\\alpha>0}")#text(", we can establish ")#mi("{P(\\theta)}")#text(" for arbitrarily large ")#mi("{\\theta}")#text(", and for ")#mi("{\\theta}")#text(" large enough we can insert the bound ")#link(<tao-b8eb9bede31921daba6c>)[#text("(22)")]#text(" (with ")#mi("{a}")#text(" sufficiently large depending on ")#mi("{\\theta}")#text(") into ")#link(<tao-9b7ecc6eeb83abf9ade1>)[#text("(19)")]#text(", ")#link(<tao-3eaf7db172bf7b71dbb8>)[#text("(20)")]#text(" to obtain the required claim ")#link(<tao-c2ba348d1ffd70736f32>)[#text("(18)")]#text(". See ")#link("https://terrytao.wordpress.com/2019/06/14/abstracting-induction-on-scales-arguments/")[#text("this blog post")]#text(" for a further elaboration of this approach, which allows one to systematically determine the optimal exponents one can conclude from a system of inequalities of the type one sees in Proposition ")#link(<tao-2c70e12b7a0646f92279>)[#text("19")]#text(" or Exercise ")#link(<tao-d773c6ef7075afce5167>)[#text("20")]#text(" (it boils down to computing the Perron-Frobenius eigenvalue of certain matrices).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" By carefully unpacking the above iterative arguments, establish a bound of the form")

#align(center)[#tao-fit-display[#mitex("D(\\delta) \\lesssim \\exp( O( \\frac{\\log 1/\\delta}{\\log\\log 1/\\delta} ) )")]]

#text("for all sufficiently small ")#mi("{\\delta>0}")#text(". (This bound was first established ")#link("https://arxiv.org/abs/1805.10551")[#text("by Li")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23 (Localised decoupling)")]#text(" Let ")#mi("{0 < \\delta < 1}")#text(", and let ")#mi("{{\\mathcal I}}")#text(" be a family of boundedly overlapping intervals ")#mi("{I}")#text(" in ")#mi("{[-1,1]}")#text(" of length ")#mi("{\\delta}")#text(". For each ")#mi("{I \\in {\\mathcal I}}")#text(", let ")#mi("{g_I \\in L^1({\\bf R})}")#text(" be an integrable function supported on ")#mi("{I}")#text(", and let ")#mi("{{\\mathcal E} g_I}")#text(" denote the extension operator")

#align(center)[#tao-fit-display[#mitex("{\\mathcal E} g_I(x_1,x_2) := \\int_{\\bf R} g_I(\\xi) e^{2\\pi i (\\xi x_1 + \\xi^2 x_2)}\\ d\\xi.")]]

#text("For any ball ")#mi("{B = B(x_0, \\delta^{-2})}")#text(" of radius ")#mi("{\\delta^{-2}}")#text(", use Theorem ")#link(<tao-d617af7a922bffeca014>)[#text("13")]#text(" to establish the local decoupling inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{I \\in {\\mathcal I}} {\\mathcal E} g_I \\right\\|_{L^6(B)} \\lesssim_\\varepsilon \\delta^{-\\varepsilon} (\\sum_{I \\in {\\mathcal I}} \\left\\|{\\mathcal E} g_I\\right\\|_{L^6({\\bf R}^2, w_B\\ dx)}^2)^{1/2}", block: true)]]

#text("for any ")#mi("{\\varepsilon>0}")#text(", where ")#mi("{w_B}")#text(" is the weight function")

#align(center)[#tao-fit-display[#mitex("w_B(x) := \\langle \\frac{x-x_0}{\\delta^{-2}} \\rangle^{-100}.")]]
]

#text("The decoupling theorem for the parabola has been extended in a number of directions. ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3374964")[#text("Bourgain and Demeter obtained")]#text(" the analogous decoupling theorem for the paraboloid:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 24 (Decoupling for the paraboloid)")]#text(" ")#metadata(none) <tao-d7027ad774bcc048dabb>#text(" Let ")#mi("{d \\geq 2}")#text(", let ")#mi("{0 < \\delta < 1}")#text(", let ")#mi("{\\Omega = \\phi(\\Sigma)}")#text(" for some ")#mi("{\\delta}")#text("-separated subset ")#mi("{\\Sigma}")#text(" of ")#mi("{[-1,1]^{d-1}}")#text(", where ")#mi("{\\phi: {\\bf R}^{d-1} \\rightarrow {\\bf R}^d}")#text(" is the map ")#tao-math("{\\phi(\\xi) := (\\xi, \\left|\\xi\\right|^2)}", block: false)#text(", and to each ")#mi("{\\omega = \\phi(\\xi) \\in \\Omega}")#text(" let ")#mi("{D_\\omega}")#text(" be the disk")

#align(center)[#tao-fit-display[#tao-math("D_\\omega := \\{ (\\xi^{\\prime}, \\xi_d): \\left|\\xi^{\\prime} - \\xi\\right| \\leq \\delta; \\left|\\xi_d - \\left|\\xi\\right|^2 - 2 \\xi \\cdot (\\xi^{\\prime}-\\xi)\\right| \\leq \\delta^2 \\}.", block: true)]]

#text("Then one has")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_{\\frac{2(d+1)}{d-1}}( \\{ D_{\\omega}: \\omega \\in \\Omega \\} ) \\lesssim_{d,\\varepsilon} \\delta^{-\\varepsilon}")]]

#text("for any ")#mi("{\\varepsilon>0}")#text(".")
]

#text("Clearly Theorem ")#link(<tao-d617af7a922bffeca014>)[#text("13")]#text(" is the ")#mi("{d=2}")#text(" case of Theorem ")#link(<tao-d7027ad774bcc048dabb>)[#text("24")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" Show that the exponent ")#mi("{\\frac{2(d+1)}{d-1}}")#text(" in Theorem ")#link(<tao-d7027ad774bcc048dabb>)[#text("24")]#text(" cannot be replaced by any larger exponent.")
]

#text("We will not prove Theorem ")#link(<tao-d7027ad774bcc048dabb>)[#text("24")]#text(" here; the proof in Bourgain-Demeter shares some features in common with the one given above (for instance, it focuses on a ")#mi("{d}")#text("-linear formulation of the decoupling problem, though not one that corresponds precisely to the bilinear formulation given above), but also involves some additional ingredients, such as the wave packet decomposition and the multilinear restriction theorem from ")#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/")[#text("Notes 1")]#text(".")#linebreak()#text(" Somewhat analogously to how the multilinear Kakeya conjecture could be used in ")#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/")[#text("Notes 1")]#text(" to establish the multilinear restriction conjecture (up to some epsilon losses) by an induction on scales argument, the decoupling theorem for the paraboloid can be used to establish decoupling theorems for other surfaces, such as the sphere:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26 (Decoupling for the sphere)")]#text(" ")#metadata(none) <tao-8aea2f615bcb645ef75b>#text(" Let ")#mi("{d \\geq 2}")#text(", let ")#mi("{0 < \\delta < 1}")#text(", and let ")#mi("{\\Omega}")#text(" be a ")#mi("{\\delta}")#text("-separated subset of the sphere ")#mi("{S^{d-1}}")#text(". To each ")#mi("{\\omega \\in \\Omega}")#text(", let ")#mi("{\\tilde D_\\omega}")#text(" be the disk")

#align(center)[#tao-fit-display[#tao-math("\\tilde D_\\omega := \\{ \\xi: \\left|\\xi \\cdot \\omega - 1\\right| \\leq \\delta; \\left|\\xi - (\\xi \\cdot \\omega) \\omega\\right| \\leq \\delta^2\\}.", block: true)]]

#text("Assuming Theorem ")#link(<tao-d7027ad774bcc048dabb>)[#text("24")]#text(", establish the bound ")#metadata(none) <tao-69374da4f93bff9b8959>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\mathrm{Dec}_{\\frac{2(d+1)}{d-1}}( \\{ \\tilde D_{\\omega}: \\omega \\in \\Omega \\} ) \\lesssim_{d,\\varepsilon} \\delta^{-\\varepsilon}")]]

#text(" for any ")#mi("{\\varepsilon>0}")#text(". (")#emph[#text("Hint:")]#text(" if one lets ")#mi("{\\tilde D(\\delta)}")#text(" denote the supremum over all expressions of the form of the left-hand side of ")#link(<tao-69374da4f93bff9b8959>)[#text("(23)")]#text(", use Exercise ")#link(<tao-7ddcdc0ab8180b8893fa>)[#text("10")]#text(" and Theorem ")#link(<tao-d7027ad774bcc048dabb>)[#text("24")]#text(" to establish a bound of the form ")#mi("{\\tilde D(\\delta) \\lesssim_{d,\\varepsilon} \\delta^{-\\varepsilon} \\tilde D(\\sqrt{\\delta})}")#text(", taking advantage of the fact that a sphere resembles a paraboloid at small scales. This argument can also be found in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3374964")[#text("the above-mentioned paper of Bourgain and Demeter")]#text(".)")
]

#text("An induction on scales argument (somewhat similar to the one used to establish the multilinear Kakeya estimate in ")#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/")[#text("Notes 1")]#text(") can similarly be used to establish decoupling theorems for the cone")

#align(center)[#tao-fit-display[#mitex("\\{ (\\xi_1,\\xi_2,\\xi_3): \\xi_1^2 + \\xi_2^2 = \\xi_3^2\\}")]]

#text("from the decoupling theorem for the parabola (Theorem ")#link(<tao-d617af7a922bffeca014>)[#text("13")]#text("). It will be convenient to rewrite the equation for the cone as ")#mi("{\\xi_1^2 = (\\xi_2+\\xi_3) (\\xi_3-\\xi_2)}")#text(", then perform a linear change of variables to work with the tilted cone")

#align(center)[#tao-fit-display[#mitex("\\{ (\\xi_1,\\xi_2,\\xi_3): \\xi_1^2 = \\xi_2 \\xi_3 \\}")]]

#text("which can be viewed as a projective version of the parabola ")#mi("{\\{ (\\xi_1,\\xi_2): \\xi_1^2 = \\xi_2 \\}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27 (Decoupling for the cone)")]#text(" For ")#mi("{0 < \\delta \\leq 1}")#text(", let ")#mi("{D_C(\\delta)}")#text(" denote the supremum of the decoupling constants")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_6( \\{ S_{\\theta,\\delta}: \\theta \\in \\Sigma \\} )")]]

#text("where ")#mi("{\\Sigma}")#text(" ranges over ")#mi("{\\delta}")#text("-separated subsets of ")#mi("{[-1,1]}")#text(", and ")#mi("{S_{\\theta,\\delta}}")#text(" denotes the sector")

#align(center)[#tao-fit-display[#tao-math("\\{ (\\xi_1,\\xi_2,\\xi_3): \\left|\\frac{\\xi_1}{\\xi_3} - \\theta\\right| \\leq \\delta; \\left|\\frac{\\xi_2}{\\xi_3} - \\frac{\\xi_1^2}{\\xi^2_3}\\right| \\leq \\delta^2; 1 \\leq \\xi_3 \\leq 2 \\}.", block: true)]]

#text("More generally, if ")#mi("{0 < \\nu \\leq 1}")#text(", let ")#mi("{D_C(\\delta,\\nu)}")#text(" denote the supremum of the decoupling constants")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_6( \\{ S_{\\theta,\\delta,\\nu}: \\theta \\in \\Sigma \\} )")]]

#text("where ")#mi("{\\Sigma}")#text(" ranges over ")#mi("{\\delta}")#text("-separated subsets of ")#mi("{[-1,1]}")#text(", and ")#mi("{S_{\\theta,\\delta,\\nu}}")#text(" denotes the shortened sector")

#align(center)[#tao-fit-display[#tao-math("\\{ (\\xi_1,\\xi_2,\\xi_3): \\left|\\frac{\\xi_1}{\\xi_3} - \\theta\\right| \\leq \\delta; \\left|\\frac{\\xi_2}{\\xi_3} - \\frac{\\xi_1^2}{\\xi^2_3}\\right| \\leq \\delta^2; 1 \\leq \\xi_3 \\leq 1+\\nu \\}.", block: true)]]

#list(
[#text("(i) For any ")#mi("{0 < \\delta,\\nu \\leq 1}")#text(", show that ")#mi("{D_C(\\delta) \\lesssim \\nu^{-O(1)} D_C(\\delta,\\nu)}")#text(".")],
[#text("(ii) For any ")#mi("{0 < \\nu \\leq 1}")#text(", show that ")#mi("{D_C(\\nu^2, \\nu) \\lesssim_\\varepsilon \\nu^{-\\varepsilon}}")#text(" for any ")#mi("{\\varepsilon>0}")#text(". (Hint: use Theorem ")#link(<tao-d617af7a922bffeca014>)[#text("13")]#text(" and various parts of Exercise ")#link(<tao-7ddcdc0ab8180b8893fa>)[#text("10")]#text(", exploiting the geometric fact that thin slices of the tilted cone resemble the Cartesian product of a parabola and a short interval.)")],
[#text("(iii) For any ")#mi("{0 < \\delta_1, \\delta_2, \\nu \\leq 1}")#text(", show that ")#mi("{D_C(\\delta_1 \\delta_2, \\nu) \\lesssim D_C(\\delta_1, \\nu) D_C(\\delta_2,\\nu)}")#text(". (")#emph[#text("Hint:")]#text(" adapt the argument used to establish Exercise ")#link(<tao-c0c75a8e79ad011929e6>)[#text("16")]#text(", taking advantage of the invariance of the tilted light cone under projective parabolic rescaling ")#mi("{(\\xi_1,\\xi_2,\\xi_3) \\mapsto (\\lambda \\xi_1, \\lambda^2 \\xi_2, \\xi_3)}")#text(" and projective Galilean transformations ")#mi("{(\\xi_1,\\xi_2,\\xi_3) \\mapsto (\\xi_1 + \\eta \\xi_3, \\xi_2 + 2 \\eta \\xi_1 + \\eta^2 \\xi_3, \\xi_3)}")#text("; these maps can also be viewed as tilted (conformal) Lorentz transformations ).")],
[#text("(iv) Show that ")#mi("{D_C(\\delta) \\lesssim_\\varepsilon \\delta^{-\\varepsilon}}")#text(" for any ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{0 < \\delta \\leq 1}")#text(".")],
[#text("(v) State and prove a generalisation of (iv) to higher dimensions, using Theorem ")#link(<tao-d7027ad774bcc048dabb>)[#text("24")]#text(" in place of Theorem ")#link(<tao-d617af7a922bffeca014>)[#text("13")]#text(".")]
)

#text("This argument can also be found in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3374964")[#text("the above-mentioned paper of Bourgain and Demeter")]#text(".")
]

#text("A separate generalization of Theorem ")#link(<tao-d617af7a922bffeca014>)[#text("13")]#text(", to the ")#emph[#text("moment curve")]

#align(center)[#tao-fit-display[#mitex("\\{ (t, t^2, \\dots, t^d): t \\in {\\bf R}\\}")]]

#text("was obtained ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3548534")[#text("by Bourgain, Demeter, and Guth")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 28 (Decoupling for the moment curve)")]#text(" ")#metadata(none) <tao-72110207b6499adb0ff6>#text(" Let ")#mi("{d \\geq 2}")#text(", let ")#mi("{0 < \\delta \\leq 1}")#text(", and let ")#mi("{\\Sigma}")#text(" be a ")#mi("{\\delta}")#text("-separated subset of ")#mi("{[-1,1]}")#text(". For each ")#mi("{t \\in \\Sigma}")#text(", let ")#mi("{R_{t,\\delta} \\subset {\\bf R}^d}")#text(" denote the region")

#align(center)[#tao-fit-display[#tao-math("R_{t,\\delta} := \\{ \\xi \\in {\\bf R}^d: \\left|\\xi - \\phi(t^{\\prime})\\right| \\leq \\delta^d \\text{ for some } t^{\\prime} \\in [t-\\delta,t+\\delta] \\}", block: true)]]

#text("where ")#mi("{\\phi: {\\bf R} \\rightarrow {\\bf R}^d}")#text(" is the map")

#align(center)[#tao-fit-display[#mitex("\\phi(t) := (t,t^2,\\dots,t^d).")]]

#text("Then")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Dec}_{d(d+1)}( \\{ R_{t,\\delta}: t \\in \\Sigma \\} ) \\lesssim_{d,\\varepsilon} \\delta^{-\\varepsilon}")]]

#text("for any ")#mi("{\\varepsilon>0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" Show that the exponent ")#mi("{d(d+1)}")#text(" in Theorem ")#link(<tao-72110207b6499adb0ff6>)[#text("28")]#text(" cannot be replaced by any higher exponent.")
]

#text("It is not difficult to use Exercise ")#link(<tao-7ddcdc0ab8180b8893fa>)[#text("10")]#text(" to deduce Theorem ")#link(<tao-d617af7a922bffeca014>)[#text("13")]#text(" from the ")#mi("{d=2}")#text(" case of Theorem ")#link(<tao-72110207b6499adb0ff6>)[#text("28")]#text(" (the only issue being that the regions ")#mi("{R_{t,\\delta}}")#text(" are not quite the same the parallelograms ")#mi("{\\tilde R_{(t,t^2),\\delta}}")#text(" appearing in Theorem ")#link(<tao-d617af7a922bffeca014>)[#text("13")]#text(").")#linebreak()#text(" The original proof of Theorem ")#link(<tao-72110207b6499adb0ff6>)[#text("28")]#text(" by Bourgain-Demeter-Guth was rather intricate, using for instance a version of the multilinear Kakeya estimate from ")#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/")[#text("Notes 1")]#text(". A shorter proof, similar to the one used to prove Theorem ")#link(<tao-d617af7a922bffeca014>)[#text("13")]#text(" in these notes, was recently given ")#link("https://arxiv.org/abs/1912.09798")[#text("by Guo, Li, Yung, and Zorin-Kranich")]#text(", adapting the “nested efficient congruencing” method ")#link("https://arxiv.org/abs/1708.01220")[#text("of Wooley")]#text(", which we will not discuss here, save to say that this method can be viewed as a ")#mi("{p}")#text("-adic counterpart to decoupling techniques. See also ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3658168")[#text("this paper of Wooley")]#text(" for an alternate approach to (a slightly specialised version of) Theorem ")#link(<tao-72110207b6499adb0ff6>)[#text("28")]#text(".")#linebreak()#text(" Perhaps the most striking application of Theorem ")#link(<tao-72110207b6499adb0ff6>)[#text("28")]#text(" is the following conjecture of Vinogradov:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30 (Main conjecture for the Vinogradov mean value theorem)")]#text(" Let ")#mi("{d \\geq 2}")#text(". For any ")#mi("{s \\geq 1}")#text(" and any ")#mi("{N \\geq 1}")#text(", let ")#mi("{J_{s,d}(N)}")#text(" denote the quantity")

#align(center)[#tao-fit-display[#tao-math("J_{s,d}(N) := \\int_{[0,1]^d} \\left|\\sum_{n=1}^N e( x_1 n + x_2 n^2 + \\dots + x_d n^d )\\right|^{2s}\\ dx_1 \\dots dx_n", block: true)]]

#list(
[#list(

)]
)

#list(
[#text("(i) If ")#mi("{s}")#text(" is a natural number, show that ")#mi("{J_{s,d}(N)}")#text(" is equal to the number of tuples ")#mi("{(X_1,\\dots,X_{2s}) \\in \\{1,\\dots,N\\}^{2s}}")#text(" of natural numbers between ")#mi("{1}")#text(" and ")#mi("{N}")#text(" obeying the system of equations")

#align(center)[#tao-fit-display[#mitex("X_1^i + \\dots + X_s^i = X_{s+1}^i + \\dots + X_{2s}^i")]]

#text("for ")#mi("{i=1,\\dots,d}")#text(".")],
[#text("(ii) Using Theorem ")#link(<tao-72110207b6499adb0ff6>)[#text("28")]#text(", establish the bound")

#align(center)[#tao-fit-display[#mitex("J_{d(d+1)/2,d}(N) \\lesssim_{d,\\varepsilon} N^{d(d+1)+\\varepsilon}")]]

#text("for all ")#mi("{\\varepsilon >0}")#text(". (")#emph[#text("Hint:")]#text(" set ")#mi("{\\delta = 1/N}")#text(" and ")#mi("{\\Sigma = \\{i/N: i=1,\\dots,N\\}}")#text(", and apply the decoupling inequality to functions ")#mi("{f_t}")#text(" that are adapted to a small ball around ")#mi("{\\phi(t)}")#text(".)")],
[#text("(iii) More generally, establish the bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("J_{s,d}(N) \\lesssim_{d,s,\\varepsilon} N^{s+\\varepsilon} + N^{2s - \\frac{d(d+1)}{2} + \\varepsilon}")]]

#metadata(none) <tao-beabfc4aacb48ace97c3>#text(" for any ")#mi("{s \\geq 1}")#text(" and ")#mi("{\\varepsilon>0}")#text(". Show that this bound is best possible up to the implied constant and the loss of ")#mi("{N^\\varepsilon}")#text(" factors.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 31")]#text(" Estimates of the form ")#link(<tao-beabfc4aacb48ace97c3>)[#text("(24)")]#text(" are known as ")#emph[#text("mean value theorems")]#text(", and were first established by Vinogradov in 1937 in the case when ")#mi("{s}")#text(" was sufficiently large (and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=29416")[#text("by Hua")]#text(" when ")#mi("{s}")#text(" was sufficiently small). These estimates in turn had several applications in analytic number theory, most notably the Waring problem and in establishing zero-free regions for the Riemann zeta function; see ")#link("https://terrytao.wordpress.com/2015/02/07/254a-notes-5-bounding-exponential-sums-and-the-zeta-function/")[#text("these previous lecture notes")]#text(" for more discussion. The ranges of ")#mi("{d,s}")#text(" for which ")#link(<tao-beabfc4aacb48ace97c3>)[#text("(24)")]#text(" was established was improved over the years, with much recent progress by Wooley using his method of efficient congruencing; see ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3939285")[#text("this survey of Pierce")]#text(" for a detailed history. In particular, these methods can supply an alternate proof of ")#link(<tao-beabfc4aacb48ace97c3>)[#text("(24)")]#text("; see ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3658168")[#text("this paper of Wooley")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32 (Discrete restriction)")]#text(" Let ")#mi("{0 < \\delta < 1}")#text(" and ")#mi("{d \\geq 2}")#text(", and let ")#mi("{\\Omega}")#text(" be a ")#mi("{\\delta}")#text("-separated subset of either the unit sphere ")#mi("{S^{d-1}}")#text(" or the paraboloid ")#tao-math("{\\{ (\\xi^{\\prime}, \\left|\\xi^{\\prime}\\right|^2): \\xi^{\\prime} \\in [-1,1]^{d-1} \\}}", block: false)#text(". Using Theorem ")#link(<tao-d7027ad774bcc048dabb>)[#text("24")]#text(" and Exercise ")#link(<tao-8aea2f615bcb645ef75b>)[#text("26")]#text(", show that for any radius ")#mi("{R \\geq \\delta^{-2}}")#text(" and any complex numbers ")#mi("{a_\\omega, \\omega \\in \\Omega}")#text(", one has the discrete restriction estimate")

#align(center)[#tao-fit-display[#tao-math("(\\frac{1}{\\left|B(0,R)\\right|} \\int_{B(0,R)} \\left|\\sum_{\\omega \\in \\Omega} a_\\omega e^{2\\pi i x \\cdot \\omega}\\right|^{\\frac{2(d+1)}{d-1}}\\ dx)^{\\frac{d-1}{2(d+1)}}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\lesssim_\\varepsilon \\delta^{-\\varepsilon} (\\sum_{\\omega \\in \\Omega} \\left|a_\\omega\\right|^2)^{1/2}.", block: true)]]

#text("Explain why the exponent ")#mi("{\\frac{2(d+1)}{d-1}}")#text(" here cannot be replaced by any larger exponent, and also explain why the exponent ")#mi("{2}")#text(" in the condition ")#mi("{R \\geq \\delta^{-2}}")#text(" cannot be lowered.")
]

#text("For further applications of decoupling estimates, such as restriction and Strichartz estimates on tori, and application to combinatorial incidence geometry, see ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3971577")[#text("the text of Demeter")]#text(".")#linebreak()#text(" [These exercises will be moved to a more appropriate location at the end of the course, but are placed here for now so as not to affect numbering of existing exercises.]")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" Show that the inequality in ")#link(<tao-2c3a4249d77070058649>)[#text("(8)")]#text(" is actually an equality, if ")#tao-math("{A_2 = \\left\\| \\sum_{j=1}^n 1_{U_j} \\right\\|_{L^\\infty({\\bf R}^d)}}", block: false)#text(" is the maximal overlap of the ")#mi("{U_j}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34")]#text(" Show that ")#mi("{D(\\delta^{\\prime}) \\lesssim D(\\delta)}")#text(" whenever ")#mi("{0 < \\delta \\leq \\delta^{\\prime} \\leq 1}")#text(". (Hint: despite superficial similarity, this is not related to Lemma ")#link(<tao-bdba154e242c57ecd619>)[#text("14")]#text(". Instead, adapt the parabolic rescaling argument used to establish Proposition ")#link(<tao-354b7e73ab60e1a1bb6c>)[#text("15")]#text(".)")
]

#heading(level: 1)[#text("Comments (95)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5648b5976608ef078e9a7e9112011198f5ed2a1131a0e34958fed579194231c-a38583de06848c67b2633cfcf229172d7aa51a43fea5d849da01fea42b69326c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dmitrii")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-2/#comment-636807")[#strong[#text("Dmitrii")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2021")])]

#text("Do I understand correctly that Proposition 19 is the only part where the proof breaks for a line (which does not exhibit strong decoupling ofc)?")

#text("Also I wonder if in general the number of solutions to ")#mi("\\eta_1 + \\eta_2 + \\eta_3 = \\eta_4 + \\eta_5 + \\eta_6")#text(" where ")#mi("\\eta_i")#text(" lie on a parabola should be dominated by the diagonal term even if the points are not well-separated?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-2/#comment-636832")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2021")])]

#text("Yes, this is the key proposition that crucially exploits the curvature of the parabola.")

#text("It is tentatively conjectured that L^6 decoupling for the parabola should hold for arbitrary collections of N disjoint arcs (not necessarily adjacent and of equal size), with losses of ")#mi("N^\\varepsilon")#text(" type, which would imply a positive answer to your last question (again with ")#mi("N^\\varepsilon")#text(" type losses), but this has not yet been established.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5648b5976608ef078e9a7e9112011198f5ed2a1131a0e34958fed579194231c-a38583de06848c67b2633cfcf229172d7aa51a43fea5d849da01fea42b69326c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dmitrii")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-2/#comment-639240")[#strong[#text("Dmitrii")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2022")])]

#text("Thanks. A related question: can one similarly prove “one-dimensional” L_4 decoupling for the y-axis projections and thus show that the set of squares ")#mi("\\{1^2, 2^2, \\ldots, N^2 \\}")#text(" has additive energy ")#mi("N^{2+o(1)}")#text(" without resorting to the divisor bound? Curious if any such a proof is known.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-2/#comment-639565")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2022")])]

#text("I don’t know of any decoupling-based proof of this fact. But any such argument would probably have to use some number theory in addition to pure decoupling, as decoupling estimates alone wouldn’t be able to detect if one replaced the set of squares with some perturbation of that set, and I would imagine that there are perturbations in which the additive energy becomes significantly larger than ")#mi("N^{2+o(1)}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bdc748623c99a92052a6e780b20858e321b37c2d7251b9146703991980ef2445-3c7af01e11b115e6a345261b1ff2a6a173fe66f6c9f3ab4c991cab314286b717.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-2/#comment-677547")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2023")])]

#text("In equation before equation 14, should it be $\\| \\sum_{\\omega_2 \\in \\phi(\\Sigma_2)} g_{\\omega_2}\\|_{L^6(\\mathbb{R}^2)}$ instead of $\\| \\sum_{\\omega_1 \\in \\phi(\\Sigma_1)} g_{\\omega_1}\\|_{L^6(\\mathbb{R}^2)}$?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/acd906c63267127586e5b4e4a1c8bbf7f5a43833592a4e337bf0221a7199cad4-a5fe91d6cbc1826c1720cb292f7178d0e13e98ac1b27eab5e177894fa3b8dff9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mohsen")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-552468")[#strong[#text("mohsen")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("Hello professor.")#linebreak()#text(" A PURPOSE!")#linebreak()#text(" Please put your pdf version of your notes on this website too!")#linebreak()#text(" thanks alot!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-552480")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("This has been asked many times. See for instance this thread: ")#link("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/#comment-549677")[#text("https://terrytao.wordpress.com/2020/03/29/247b-notes-1-restriction-theory/#comment-549677")]

#text("If you print a blog post to PDF it should be fairly readable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59a55408d26b13e212198b0774c823b811caf27aec4aeb44ae20f5d7944aca64-68fad027bd214c09756241c77e2cc6676463ebece9338fc53fad8e10dcf3167f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Irkutsk")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-552485")[#strong[#text("Irkutsk")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("There should be an absolute value on the LHS of the first displayed formula.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shapiro")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-552495")[#strong[#text("shapiro")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("In Exercise 4 (iv), what kind of counterexamples should I be looking at? I tried a family of dilated bump functions but it is really tough to compute the projections on frequency. I do not even know if this is the right family of function to test. Do you have any hint?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shapiro")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-552505")[#strong[#text("shapiro")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("Well, it seems that after writing this comment I finally found an answer: condering a function f such that P_[k,k+1] (f)= the same bump function works just fine!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ad7f67078798607ba89d13b1a2fab5f62c91ac7b00f41d43e0bd8d07b1eb217-4fdbf649a465203cef3a8f16db7b0463e77ddbabd3d74a52bc6d98f0aca4709c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trevor Wooley")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-552502")[#strong[#text("Trevor Wooley")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("Just a note on nomenclature: in Exercise 30 you refer to the “Vinogradov main conjecture”, which seems to have entered usage in the literature in the past few years in the harmonic analysis community. In the number theory community the name has been different, partly owing to the fact that there are many conjectures associated with the name I. M. Vinogradov, including for example his famous conjecture concerning non-trivial cancellation in short character sums. The phrase “Vinogradov’s mean value theorem” was used to describe any non-trivial estimate (optimal or not) for the mean value of exponential sums (or moment estimate) in question, and the estimate in Exercise 30 was often referred to as the “optimal estimate in Vinogradov’s mean value theorem”, or by me and others over the past decade as the “main conjecture in Vinogradov’s mean value theorem”.")

#text("For what it is worth, the “nested efficient congruencing method” can be seen as a p-adic decoupling method, which leads to some unification of all the ideas currently in play.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-552531")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("Thanks for this! I realise that I have indeed mentally contracted “main conjecture for the Vinogradov mean value theorem” as “Vinogradov main conjecture”, and have now corrected this in the text. Also I realise that in my rush to push out these notes I had omitted the historical remarks on this conjecture, which I have now also added.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-555701")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2020")])]

#text("Could you describe what a p-adic decoupling method is (even if the term isn’t strictly defined)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-557124")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2020")])]

#text("Dear Professor Tao, you are also welcome to answer this if you wish.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-552508")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("In the line after equation (1), it is the ")#mi("\\hat{f}_j")#text(" that are supported on the annuli, right? (I guess you follow the physics convention where the variable name specifies the coordinate system).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-552510")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("In the equation after you mention Hormander–Miklin there is a missing ")#mi("\\Vert")#text(" on the LHS and the subscript didn’t come out.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-552631")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("Note:the same small issue also appears at end of proof of Thm1")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-552511")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("In exercise 2 you need to swap the two balls (so the bump function is supported on the ball of radius 2, equal to 1 on the ball of radius 1).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b64abe43412dc7f11e3ee247ad175b71fde999420e1b399c19ea8c6c464376a-c662b882fe24a1718eb7f2117e0b1baa53af593586a47d2de533176114846933.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of extremal010101")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-552570")[#strong[#text("extremal010101")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("proof of theorem 1, part (i): why ")#mi("f_{j} = P_{k_{j}}f")#text("? I assume ")#mi("f = \\sum_{k} f_{k}")#text(". The bump function ")#mi("\\psi")#text(" is supported on ")#tao-math("\\{ 0.9\\leq \\left|\\xi\\right| \\leq 2.1\\}", block: false)#text(", and the frequencies of ")#mi("f_{j}")#text(" are not “2-separated”, then ")#mi("P_{k_{j}}(\\sum_{\\ell=1}^{n}f_{\\ell})")#text(" may have frequencies not in ")#mi("f_{j}")#text(", or am I missing something?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-552578")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2020")])]

#text("In this part of the argument we are proving (ii), not (i).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dn1214")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-553227")[#strong[#text("dn1214")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2020")])]

#text("In Exercise 4 (i), how do you use Parseval for series to get the ")#mi("L^{\\infty}")#text(" case? If I introduce the function ")#mi("G(t):=\\sum e^{2i\\pi tn}\\tilde{P}_nf(x)")#text(" then I can not compute easily the ")#mi("L^2")#text(" norm of this function and I’m stuck.")

#text("The proof I know goes roughly as follows: for any ")#mi("(a_n)\\in \\ell^2")#text(" we write ")#mi("\\sum_n x_n\\tilde{P}_nf(x)= \\int f(x-y)\\varphi^{\\vee}(y)F(y)dx")#text(" where ")#tao-math("\\left\\|F\\right\\|_{L^2} = \\left\\|(a_n)\\right\\|_{\\ell^2}", block: false)#text(" and then we use the decay of ")#mi("\\phi^{\\vee}(y)")#text(" to conclude.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-553284")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2020")])]

#text("The function ")#mi("G(t) = G_x(t)")#text(" can be expressed in terms of ")#mi("f")#text(" in a tractable form using either the Poisson summation formula or the Fourier inversion formula for periodic functions, after a certain amount of standard manipulation using the usual Fourier identities. The duality method you indicate would also work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bacc9b43fbce0909b2191aa3ffba7d82debf596cb10ff7edb188fea21a9255b-a12d68cccc87239fb4fd25fea9224dd6eb021608ba6b35491c0a496eb071a0e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hhy177")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-555626")[#strong[#text("hhy177")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2020")])]

#text("To apply the Poisson summation formula here, don’t we need ")#mi("\\tilde P_n f(x)")#text(" to be Schwartz in ")#mi("n")#text("? Writing ")#mi("\\tilde P_n f(x) = \\int f(x-y) \\varphi^\\vee(y) e^{2\\pi i n y} dy")#text(", it seems like ")#mi("\\tilde P_n f(x)")#text(" is smooth with not enough decay in ")#mi("n")#text(". After I proceed formally with this calculation (such as taking inverse Fourier transform of 1 in the process), I seem to get something looking more tractable, from which I could derive the boundedness of the square estimate in 4.(i) when ")#mi("p = \\infty")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-555637")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2020")])]

#text("To convert your formal computations to a rigorous argument, one can either (a) try to work in the language of (tempered) distributions, (b) using some sort of limiting argument, or (c) take the final expression for ")#mi("\\tilde P_n f(x)")#text(" that you obtained and try to prove it by a different (and fully rigorous) method (e.g., by first establishing a “Fourier transform” of your identity and then applying the Fourier inversion formula).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dn1214")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-553695")[#strong[#text("dn1214")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2020")])]

#text("I have two questions about exercise 3:")#linebreak()#text(" – In (ii) I am not able to prove the result; since the result is false if ")#mi("(T_i)")#text(" and ")#mi("(\\tilde{T}_i)")#text(" are two fully independent collections of rectangles (pick one collection of disjoint rectangles, and the other to be all the same rectangle), I am wondering how to use that the ")#mi("\\tilde{T}_i")#text(" are translations of ")#mi("T_i")#text("? Does it require to use the boundedness of the disc multiplier?")#linebreak()#text(" – I was surprised that without using (ii), one can solve (iv) only using (i) (taking ")#mi("f_j=1_{T_j}")#text("), is it normal?")

#text("There is also a minor typo: ")#mi("\\Omega = D")#text(" at the begining of the exercise, I guess.")

#text("Thank you a lot.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-553764")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2020")])]

#text("Yes, one should use part (i) to establish part (ii).")

#text("The definition of ")#mi("P_\\Omega")#text(" encompasses both ")#mi("P_D")#text(" and ")#mi("P_{H_j}")#text(", which is why I used a different symbol from either here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dn1214")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-554210")[#strong[#text("dn1214")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2020")])]

#text("Thank you for the clarification!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-554085")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2020")])]

#text("I’m curious if one should expect to be able to replace the ball of integration on the left in the local decoupling estimates with an integral over a smaller more tubular region?")

#text("It seems that when you ultimately rescale and plug in lattice points to prove Vinogrodov-type estimates, there ends up being redundancy in the integral, and that an estimate over a more tubular region would more naturally lead to a the the exact Vinogrodov integral (and be a stronger estimate).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-554178")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2020")])]

#text("Good question. There are counterexamples that show that the balls on which decoupling occurs cannot be replaced by smaller balls without significant increase in the decoupling constants, but there may be some possibility of additional useful decoupling estimates involving more eccentric domains than balls. For instance if one is trying to decouple arcs in Fourier space contained in a narrow arc of the paraboloid, then by applying a suitable Galilean transformation and parabolic rescaling, followed by Exercise 23, one obtains a local decoupling estimate involving a certain rectangular region that is a little bit smaller in one dimension than the ball one would get from direct application of Exercise 23. So perhaps there is some “time-frequency” version of decoupling that is a little bit smarter about the spatial localisation, and as you say the redundancy in the Vinogradov integral also points to some possibility of improvement in this direction also.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dn1214")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-554302")[#strong[#text("dn1214")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2020")])]

#text("Aren’t there typos in the proof of Lemma 14? e.g. “assuming that ")#mi("\\delta ^{\\prime} \\ge 10\\delta")#text("“, since we have ")#mi("\\delta ^{\\prime} \\sim \\delta")#text(", I would expect a ")#mi("\\leq")#text(" sign. And in the proof you write “since ")#mi("\\tilde{R}_{\\omega, \\delta^{\\prime}}")#text(" contains ")#mi("\\tilde{R}_{\\omega, \\delta^{\\prime}}")#text("“: one of the ")#mi("\\delta^{\\prime}")#text(" should be a ")#mi("\\delta")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-554411")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2020")])]

#text("The additional restriction ")#mi("\\delta^{\\prime} \\geq 10 \\delta")#text(" is intentional; if one can prove the claim in the special case ")#mi("10 \\delta \\leq \\delta^{\\prime} \\lesssim \\delta")#text(" then by transitivity one then obtains the general case ")#mi("\\delta \\lesssim \\delta^{\\prime} \\lesssim \\delta")#text(" as a corollary, because in the latter case one can find a third scale ")#mi("\\delta^{\\prime\\prime}")#text(" for which ")#mi("10 \\delta, 10 \\delta^{\\prime} \\leq \\delta^{\\prime\\prime} \\lesssim \\delta, \\delta^{\\prime}")#text(".")

#text("The statement “")#mi("\\tilde R_{\\omega,\\delta^{\\prime}}")#text(" contains ")#mi("\\tilde R_{\\omega,\\delta}")#text("” is stated correctly, but there is an unfortunate placement of a comma immediately afterwards.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-555499")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2020")])]

#text("It might be helpful to add a white space just before the comma, so that it doesn’t get confused with a prime. I was also disoriented for a moment by this.")

#emph[#text("[Reworded -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-554908")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2020")])]

#text("In the proof of Theorem 1, how does one get that ")#mi("f_j = P_{k_j}f")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-554920")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2020")])]

#text("Multiplier equals 1 on the fourier support of f_j and 0 for all the others")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-554926")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2020")])]

#text("By computing Fourier transforms one can see that ")#mi("P_{k_j} f_{j^{\\prime}}")#text(" is equal to ")#mi("f_j")#text(" when ")#mi("j^{\\prime}=j")#text(" and vanishes when ")#mi("j^{\\prime} \\neq j")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-554909")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2020")])]

#text("Can one say that “decoupling” is sort of “partition of unity” in the Fourier space? (I may have a very wrong impression.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-554928")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2020")])]

#text("Decoupling is a property of ")#emph[#text("some")]#text(" partitions of unity in Fourier space, but not all partitions of Fourier space have good decoupling estimates (and some partitions only have good decoupling for some exponents ")#mi("L^p")#text(" and not others). The presence of an ")#mi("L^p")#text(" decoupling estimate can be viewed as saying that the ")#mi("L^p")#text(" geometry of that partition behaves somewhat like a Hilbert space geometry in the sense that a (weak) version of the Pythagorean theorem remains valid in this setting.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-554948")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2020")])]

#text("In high dimension, if we use a dyadic cubic projection ")#mi("P_{k_j}")#text(" rather than the dyadic ball projection in the note, can the condition that the ")#mi("{k_j}")#text(" being 2-separated be removed from Theorem 1(ii)? This would at least avoid encountering the disk multiplier.")

#emph[#text("[Yes – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-555063")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2020")])]

#text("In exercise 10.ii (triangle inequality), one of the mathcal Us in the statement of the inequality is missing a ‘")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-555209")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2020")])]

#text("Does this blog entry load correctly for the other people? I am getting something very messy with “formula does not parse”, visible “”, “”, etc. everywhere starting about 10 hours ago. Everything was fine before then. No other blog entries seem to have this issue.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-555222")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2020")])]

#text("Minor omission: in the proof of lemma 6, the A in “By hypothesis, for each frequency {\\xi} at most {A} of the {\\hat f_j(\\xi)} are non-zero, thus by Cauchy-Schwarz” is missing a subscript.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca354f380cf6bceadef554945e8fa4278f6f859eca4f1ae5e34e2edb58cd6b0d-ce023afdc9ead2b89b577606f85acaedbe3a1ceb293cab5ec4037409b2444fa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiao-Chuan Liu")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-555312")[#strong[#text("Xiao-Chuan Liu")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2020")])]

#text("For Exercise 3, I can compute and obtain that ")#mi("T_H\\chi_{R}")#text(" will take uniform positive value restricted to ")#mi("\\chi_{R^{\\prime}}")#text(". Is there some easy way to see this should be true (without computing it)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-555352")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2020")])]

#text("Not really: lower bounds generally are more delicate than upper bounds and usually require some calculation to ensure that one does not have some unexpected cancellation. (In some cases, the function will obey some sort of PDE and one can use tools from the theory of unique continuation to obtain some lower bounds. It’s possible that one could pull off this trick here using the connection between the Hilbert transform and harmonic conjugates, but it is simpler to just directly calculate in this case.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-555323")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2020")])]

#text("The formula")

#text("“")#tao-math("\\displaystyle  \\left\\| \\sum_{\\omega \\in \\phi(\\Sigma)} \\right\\|f_\\omega\\|_{L^p({\\bf R}^2)}^2)^{1/2} \\sim_p \\delta^{\\frac{5}{2} - \\frac{3}{p}}", block: false)#text(".”")

#text("under Theorem 13 has a \\Vert on the left and a parenthesis on the right.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bacc9b43fbce0909b2191aa3ffba7d82debf596cb10ff7edb188fea21a9255b-a12d68cccc87239fb4fd25fea9224dd6eb021608ba6b35491c0a496eb071a0e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hhy177")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-555627")[#strong[#text("hhy177")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2020")])]

#text("For Ex 4 (ii), how do one see the boundedness of ")#mi("P_{[0,1]}")#text(" on ")#mi("L^p")#text(" from the boundedness of the Hilbert transform? Since both operator is equal (up to a factor of ")#mi("-i")#text(") on Schwartz functions with Fourier support in ")#mi("[0,1]")#text(", I can conclude ")#mi("P_{[0,1]}")#text(" is bounded on on Schwartz functions with Fourier support in ")#mi("[0,1]")#text(". How do I see it for arbitrary functions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-555638")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2020")])]

#text("Express ")#mi("P_{[0,1]}")#text(" as the difference of ")#mi("P_{[0,+\\infty)}")#text(" and ")#mi("P_{[1,+\\infty)}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-555706")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2020")])]

#text("Dear Pro Tao,")#linebreak()#text(" Whether you want it or not, Twin prime conjecture is certainly solved in 2020. By any rate, you must succeed. The historic seconds is coming, you have no choice. An only way for you, you can not come back, only go aheah! I think Sir will understand my imply. As you win , it will be useful for many people.")#linebreak()#text(" Lovely Pro.Tao,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-555834")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2020")])]

#text("What’s this about?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-555651")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2020")])]

#text("Dear Professor Tao, in the proof of the Key estimate (Proposition 19), you said “")#mi("\\xi^2_{I^{\\prime}} = \\xi^2_{J^{\\prime}} + O(\\rho_1^{\\prime})")#text(", hence ")#mi("\\xi_{I^{\\prime}} = \\pm \\xi_{J^{\\prime}} + O(\\rho_1^{\\prime})")#text("“. I think one needs ")#tao-math("\\left|\\xi_{I^{\\prime}}\\right|+\\left|\\xi_{J^{\\prime}}\\right| \\sim 1", block: false)#text(" in order to do so. Otherwise, could you please give me some hints on how it works? Thank you very much.")

#emph[#text("[Oops, there are some losses of ")#mi("\\nu^{-O(1)}")#text(" here that I forgot to take into account; however, these turn out to be acceptable losses for this argument, which is now reworded accordingly. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-555860")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2020")])]

#text("In the proof of lemma 14:")

#text("“(we can extend from {C^\\infty_c({\\bf R}^2)} to all of {L^6({\\bf R}^2)} by a limiting argument).”")

#text("I assume that this should be changed to Schwartz functions?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-556060")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2020")])]

#text("For the triangle inequality of decoupling constants, I got the inequality the other way around. I basically used the monotonicity for U and U’ (i.e. ")#mi("Dec_p(U)\\leq Dec_p(U\\bigcup U^{\\prime})")#text("), square both sides then add them, and take square root, I got")#linebreak()#text(" ")#mi("(Dec_p(U)^2+Dec_p(U^{\\prime})^2)^{1/2}\\leq\\sqrt{(}2) Dec_p(U\\bigcup U^{\\prime})")#linebreak()#text(" How to get the inequality the other way around?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-556085")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2020")])]

#text("Apply the 2d C–S inequality to the dot product ")#tao-math("\\left(\\mathrm{Dec}_p(\\mathcal{U}),\\mathrm{Dec}_p(\\mathcal{U}^{\\prime})\\right) \\cdot \\left((\\sum_i \\left\\| f_i \\right\\|_p^2)^{1/2},(\\sum_{i^{\\prime}} \\left\\| f^{\\prime}_{i^{\\prime}} \\right\\|_p^2)^{1/2}\\right)", block: false)#text(" where ")#mi("f_i")#text(" (resp. ")#mi("f^{\\prime}_{i^{\\prime}}")#text(") have Fourier support in ")#mi("U_i \\in \\cal{U}")#text(" (resp. ")#mi("U^{\\prime}_{i^{\\prime}}\\in \\cal{U}^{\\prime}")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-556091")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2020")])]

#text("One trick that can help conceptually with trying to prove estimates of the form ")#mi("X \\leq Y")#text(" or ")#mi("X \\lesssim Y")#text(" is to deconstruct the degenerate version of these inequalities, namely that “If ")#mi("Y")#text(" vanishes (or is very small), then ")#mi("X")#text(" must also vanish (or is very small)”. Suppose you know that ")#mi("(\\mathrm{Dec}_p(U)^2 + \\mathrm{Dec}_p(U^{\\prime})^2)^{1/2}")#text(" vanishes (or is very small). What does this tell you about ")#mi("\\mathrm{Dec}_p(U \\cup U^{\\prime})")#text("? If one approaches this question literally it is vacuous due to the fact that decoupling constants are necessarily bounded from below by 1, but try to ignore this fact for the purposes of performing a mental exercise. Your answer to this exercise will help suggest how to actually approach the inequality at hand.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-556086")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2020")])]

#text("Question about Ex. 10(v): where do we use the disjointness? It seems to me that the argument works whenever ")#mi("U_j,U_{j,i}")#text(" are any sets such that (up to sets of measure zero) ")#mi("\\bigcup_i U_{j,i} \\subset U_j")#text(".")

#emph[#text("[Good point; I’ve reworded the exercise accordingly. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-556098")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2020")])]

#text("In the explanation of significance of ")#mi("p\\leq 6")#text(", how do you get the factor of ")#mi("\\delta^{-1/2}")#text(" for the ")#mi("l^2")#text(" norm of ")#tao-math("\\left|\\left|f_w\\right|\\right|_p", block: false)#text(", ie.")#linebreak()#text(" ")#tao-math("\\delta^{5/2-3/p} = \\delta^{-1/2}\\cdot\\left|\\left|f_w\\right|\\right|_p", block: false)#text(" (the 2nd equation after Theorem 13)? Also, I am not sure how do you get ")#mi("\\delta^2")#text(" in the 3rd equation after we restrict ")#mi("f")#text(" to a small ball of radius ")#mi("c")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-556119")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2020")])]

#text("Both of these follow from the previously mentioned fact that ")#mi("\\Sigma")#text(" has cardinality ")#mi("\\sim \\delta^{-1}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-556474")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("In proof of Prop 18:")

#text("“(ii) (Broad case) There exist distinct intervals {I,J \\in {\\mathcal I}} with {\\mathrm{dist}(I,J) \\geq \\nu} such that")#linebreak()#text(" \\displaystyle |\\sum_{\\omega \\in \\phi(\\Sigma)} f_\\omega(x)| \\lesssim \\nu^{-O(1)} |\\sum_{\\omega \\in \\phi(\\Sigma_I)} f_\\omega(x)|, \\nu^{-O(1)} |\\sum_{\\omega \\in \\phi(\\Sigma_I)} f_\\omega(x)|.”")

#text("One of the subscripts should be a _J instead of a _I, I assume.")

#text("Could you say more about how this pigeonhole argument works? I’m not seeing why the broad case should follow if the narrow case doesn’t hold.")

#emph[#text("[More details added – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-556500")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("More in the same proof:")

#text("“From (13) we have")

#text("\\displaystyle \\int_{{\\bf R}^2} |\\sum_{\\omega \\in \\phi(\\Sigma_I)} f_\\omega|^2 |\\sum_{\\omega \\in \\phi(\\Sigma_I)} f_\\omega|^4 \\lesssim M_{2,4}(\\delta,\\nu,\\nu,\\nu)")

#text("while”")

#text("Another subscript here should be _J, and the constant M should be M^6")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-556536")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("In the same proof:")

#text("“If we immediately apply insert (14) into the above lemma, we obtain a useless inequality due to the loss of {\\nu^{-O(1)})} in the main term on the…”")

#text("has an extra parenthesis.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-556487")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("Is the subset ")#mi("\\Sigma_{\\xi^{\\prime}}")#text(" really supposed to be a subset of ")#mi("[\\xi^{\\prime} - 10\\delta, \\xi^{\\prime} + 10\\delta]")#text(" and of cardinality O(1)? Shouldn’t it be ")#mi("[\\xi^{\\prime} - \\delta^{\\prime}, \\xi^{\\prime} + \\delta^{\\prime}]")#text(" and the cardinality isn’t used in the rest of the proof.")

#emph[#text("[Corrected, thanks. The cardinality bound is needed for a minor reason, namely to ensure that the polygons formed by taking various boolean combinations of the parallelograms involved only have ")#mi("O(1)")#text(" sides. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-556530")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("Should the RHS of eq.(13) in the definition of bilinear decoupling constant be ")#tao-math("\\sum\\left|\\left|g_{\\omega}\\right|\\right|_{L_6}^4", block: false)#text(" instead of ")#tao-math("(\\sum\\left|\\left|g_{\\omega}\\right|\\right|_{L_6}^2)^2", block: false)#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-556533")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("Sorry, it is right.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-556550")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("In the proof of Lemma 14, why do you assume ")#mi("\\delta^{\\prime} \\geq 10 \\delta")#text(" instead of just ")#mi("\\delta^{\\prime} \\geq \\delta")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-556745")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2020")])]

#text("Huh, I think that was a relic from an earlier version of the argument. You are right, the extra safety margin of ")#mi("10")#text(" is not needed here.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-556579")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("In the second equation after (21), I would replace ")#mi("\\lesssim, o(1)")#text(" with ")#mi("\\lesssim_k, o_k(1)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-556906")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2020")])]

#text("In the proof of Prop 19:")

#text("“we have the normalisation")

#text("\\displaystyle \\sum_{\\omega_1 \\in \\phi(\\Sigma_1)} \\|f_{\\omega_1}\\|_{L^6({\\bf R}^2)} = \\sum_{\\omega_2 \\in \\phi(\\Sigma_2)} \\|g_{\\omega_2}\\|_{L^6({\\bf R}^2)}^2 = 1.")

#text("We can partition {\\Sigma_1} as {\\sum_{I’ \\in {\\mathcal I}’} \\Sigma_{1,I’}}, where {{\\mathcal I}’} is a collection of intervals”")

#text("The left side of the displayed formula is missing an exponent of 2 (sum of squares of norms rather than norms).")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-557044")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2020")])]

#text("In the same proof:")

#text("“We can partition {\\Sigma_1} as {\\sum_{I’ \\in {\\mathcal I}’} \\Sigma_{1,I’}}, where {{\\mathcal I}’} is a collection of intervals {I’ \\subset [-1,1]} of length {\\rho’_1} that have bounded overlap,”")

#text("I think here you mean to write union rather than sum over the I’.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-557045")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2020")])]

#text("(or better yet, \\coprod since this is a disjoint union)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-557053")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2020")])]

#text("Also")

#text("“here")

#text("\\displaystyle F_{I’} := \\sum_{\\omega_1 \\in \\phi(\\Sigma_{1,I})} f_{\\omega_1}")

#text("and”")

#text("has a missing ‘ in the subscript")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-556987")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2020")])]

#text("In the Knapp-type example to show that decoupling cannot hold for ")#mi("p > 6")#text(", is there a good way to understand why Khintchine cannot be used to obtain a good lower bound for ")#tao-math("\\left\\| \\sum f_\\omega \\right\\|_p", block: false)#text("?")

#text("In the notes, we used the following pointwise bound: ")#tao-math("\\left| \\sum f_\\omega \\right| \\gtrsim \\delta^3 \\cdot \\delta^{-1}", block: false)#text(" on a ball of radius ")#mi("\\approx 1")

#text("However, by randomization, we could instead try to use the following pointwise bound: ")#tao-math("(\\sum \\left|f_\\omega\\right|^2 )^{1/2} \\gtrsim \\delta^3\\cdot \\delta^{-1/2}", block: false)#text(" on a ball of radius ")#mi("\\approx \\delta^{-1}")#text(".")

#text("To me, it is not clear at first which of these two estimates will do better. After some computations, I see that the random estimate doesn’t give anything useful about ")#mi("p")#text(" (since all the ")#mi("p")#text("s cancel out), but is there a way to see this in advance?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-557001")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2020")])]

#text("Khintchine tells us that random sums always decouple on the average (for ")#mi("p \\geq 2")#text("):")

#tao-math("\\displaystyle ({\\bf E} \\left\\| \\sum_\\omega \\epsilon_\\omega f_\\omega \\right\\|_{p}^p)^{1/p} \\lesssim_p \\left\\| (\\sum_\\omega \\left|f_\\omega\\right|^2)^{1/2} \\right\\|_p \\leq (\\sum_\\omega \\left\\|f_\\omega\\right\\|_p^2)^{1/2}.", block: false)

#text("So if one wants to create a good counterexample to decoupling one has to produce constructive interference (in which ")#mi("\\sum_\\omega f_\\omega")#text(" is significantly larger in magnitude than the square function ")#tao-math("(\\sum_\\omega \\left|f_\\omega\\right|^2)^{1/2}", block: false)#text(" on some non-empty region of space) rather than random-type interference.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-557079")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2020")])]

#text("What is an example of ")#mi("n")#text(" “independent” phases ? ")#mi("z = \\frac{a+bi}{c+di}")#text(" is a complex number. The relation ")#tao-math("\\left|z_1 + z_2 \\right| = \\left|z_1\\right|^2 + \\left|z_2\\right|^2", block: false)#text(" could possibly be replaced with ")#tao-math("\\left|z_1 + z_2 \\right| \\leq \\left|z_1\\right|^2 + \\left|z_2\\right|^2", block: false)#text(" or ")#tao-math("\\left|z_1 + z_2 \\right| \\approx \\left|z_1\\right|^2 + \\left|z_2\\right|^2", block: false)#text(" …")

#text("Also is there any way to visualize Fourier series with disjoint annuli? In position space or momentum space.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-557123")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2020")])]

#text("In the centered equation preceding (21), should ")#mi("\\delta^{-\\alpha a \\varepsilon}")#text(" be ")#mi("\\delta^{\\alpha a \\varepsilon}")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-557288")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2020")])]

#text("Actually, now I think that in the displayed equation preceding (21), the ")#mi("\\alpha a \\varepsilon")#text(" should be ")#mi("\\alpha a \\varepsilon/2")#text(" and that this change should propogate down through the displayed equations that follow.")

#text("Also, two displayed equations after (21), ")#mi("2^{k+1}a")#text(" should be ")#mi("2^{k+1}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-557322")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2020")])]

#text("To prove Prop.18, why is it sufficient to prove equation (14)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-557586")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2020")])]

#text("I assume you mean (15) instead of (14). From (15) and the definition of ")#mi("D(\\delta)")#text(" we conclude that")

#mi("\\displaystyle D(\\delta)^6 \\lesssim \\nu^{-O(1)} M_{2,4}(\\delta,\\nu,\\nu,\\nu)^6 + D(\\delta/\\nu)^6")

#text("(noting that in the definition of decoupling constants we are free to normalise ")#tao-math("\\sum_\\omega \\left\\| f_\\omega\\right\\|_6^2=1", block: false)#text(" without loss of generality), which then gives Proposition 18.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-557355")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2020")])]

#text("In the counter-example after the statement of Thm 13 (significance of the exponent 6) shouldn’t ")#mi("R_{\\omega,\\delta}")#text(" be ")#mi("\\tilde{R}_{\\omega,\\delta}")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-557606")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2020")])]

#text("What is Exercise 27(ii) supposed to say? I think it’s incomplete as stated. There’s also a typo in the third line after Exercise 20 “for all 00”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-557695")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2020")])]

#text("In the centered equation above “so it will suffice to prove the almost orthogonality estimate,” the M_{2,4} constant should be raised to the 6th power.")

#text("Also, in the last paragraph of that proof, “(with slightly different implied constants in the O() notation” is missing a closing parenthesis.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc91e377d91b4633c6fcd96dfe4b6116f72d1223c70f98669b8a05960ece7ed0-bf826328ee45997edd10312b4570a792f0dfcb348c7ae7b7d580536a5b47388f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Garo")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-557889")[#strong[#text("Garo")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2020")])]

#text("What are some of the heuristic explanations for the gap between the best possible ")#mi("L^p")#text(" decoupling results for curves with torsion and the conjectured bounds on exponential sums? For example, we get decoupling on ")#mi("t \\mapsto (t,t^3)")#text(" for ")#mi("2 \\leq p \\leq 6")#text(" but expect the estimate to hold for exponential sums up to ")#mi("p=8")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4bb03849d1ff41902951083c00fa40571a11ef5050bdaf31aefaa511606e3ef1-5c9d014cb9cc4fa0f28c66f2bf4cf3d92930f1161bbef1b44c52bc2c3e691519.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-558112")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2020")])]

#text("One direct explanation is the lack of self-similarity in the phase, or the lack of a ‘Galilean’ invariance symmetry. For the parabola notice that an affine change of variables of the form ")#mi("t \\rightarrow (t+a)")#text(" preserves the parabola extension operator after a simple change of variables; this is no longer true if the phase is changed to ")#mi("t^3")#text(". This self-similarity plays an important role in the proof of decoupling inequalities via parabolic rescaling.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-558354")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2020")])]

#text("I think an easier way to do the upper bound in Exercise 12 is to interpolate the p = 2 bound from Plancherel with the trivial ")#mi("L^{\\infty}")#text(" bound.")

#emph[#text("[Hint reworded – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-558642")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2020")])]

#text("In the proof of Proposition 19, I see four instances of L^2(R^d) which should be L^2(R^2).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-564233")[#strong[#text("MATH 247B: Modern Real-Variable Harmonic Analysis – Countable Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2020")]

#text("[…] Decoupling Estimates […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-564880")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2020")])]

#text("A small comment (please don’t take my words for granted):")

#text("For the Littlewood-Paley inequalities, once")

#tao-math("\\left\\|\\sum_{j=1}^n \\epsilon_j f_j\\right\\|_{L^p(\\mathbf{R}^d)} \\lesssim_{p,d} \\left\\|\\sum_{j=1}^n f_j\\right\\|_{L^p(\\mathbf{R}^d)}", block: false)

#text("is shown, it follows (by choosing optimizing values for ")#mi("\\epsilon_j")#text(") that the minimum and maximum (over all sign choices) of the expression")

#tao-math("\\left\\|\\sum_{j=1}^n \\epsilon_j f_j\\right\\|_{L^p(\\mathbf{R}^d)}", block: false)

#text("are comparable, and therefore we in fact have")

#tao-math("\\left\\|\\sum_{j=1}^n \\epsilon_j f_j\\right\\|_{L^p(\\mathbf{R}^d)} \\sim_{p,d} \\left\\|\\sum_{j=1}^n f_j\\right\\|_{L^p(\\mathbf{R}^d)}.", block: false)

#text("After that, Khintchine will yield both directions of the proof.")

#text("This may help clarify the second bit of the proof; it is the same idea expressed differently, i.e. one may also prove")

#tao-math("\\left\\|\\sum_{j=1}^n \\epsilon_j f_j\\right\\|_{L^p(\\mathbf{R}^d)} \\lesssim_{p,d} \\left\\|\\sum_{j=1}^n \\epsilon^{\\prime}_j f_j\\right\\|_{L^p(\\mathbf{R}^d)}", block: false)

#text("and then use Khintchine on either side.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-565494")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2020")])]

#text("I have two questions about Remark 21.")

#text("1. “On the other hand, the bound (21) shows that ")#mi("{P(\\theta)}")#text(" implies ")#mi("{P(\\theta+\\alpha)}")#text(" for any given ")#mi("{\\theta}")#text(".”")

#text("In the sentence quoted above, should ")#mi("\\alpha")#text(" be ")#mi("\\alpha/2")#text("?")

#text("2. “Thus if ")#mi("{\\alpha>0}")#text(", we can establish ")#mi("{P(\\theta)}")#text(" for arbitrarily large ")#mi("{\\theta}")#text(", and for ")#mi("{\\theta}")#text(" large enough we can insert the bound (22) (with {a=1}) into (19), (20) to obtain the required claim (18).”")

#text("From (22) with a = 1, we gain a factor ")#mi("\\delta^{\\epsilon(\\theta - O_\\theta(1))}")#text(", but this is not necessarily an improvement, since the constant in the exponent can depend on theta. It seems like we need the ")#mi("O_\\theta(1)")#text(" to actually be ")#mi("O(1)")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-565688")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2020")])]

#text("Oops, it isn’t enough to take ")#mi("a=1")#text(", one has to take ")#mi("a")#text(" sufficiently large depending on ")#mi("\\theta")#text(" in order to overcome both the ")#mi("O_\\theta(1)")#text(" losses, and the ")#mi("O(a)")#text(" losses when one converts the estimate back to control on ")#mi("D(\\delta)")#text(".")

#text("Thanks for the corrections!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-565698")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2020")])]

#text("Thanks!")

#text("What do you mean by “convert the estimate back to control on ")#mi("D(\\delta)")#text("“? If we don’t take ")#mi("a=1")#text(" in (22), how do we use (19) and (20)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-565733")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2020")])]

#text("There is an easy triangle inequality argument that shows that ")#mi("M_{2,4}(\\delta,\\nu,\\nu\\,nu) \\lesssim \\nu^{-O(a)} M_{2,4}(\\delta,\\nu,\\nu^{2a}, \\nu^a)")#text(". Granted, this makes this version of the argument slightly different from the one in the notes, which required more precise bookkeeping of what in this formulation is the ")#mi("O_\\theta(1)")#text(" error, but it hopefully illustrates that that bookkeeping is not an essential part of the argument.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c6668e7d973cab84c16c3f5c09f99f7655fcf5c6643444dadc11baf3547513f-38930093825bac006c6d7cec9c8ee0ac4ed1ba940f8a233a75c9f0c691bb6ae2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zorich")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-592186")[#strong[#text("zorich")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2020")])]

#text("Dear Tao ,")

#text("I have a small question, you said:")

#text("“Note from the boundedness of the Hilbert transform that a Fourier projection to any polygon of bounded many sides will be bounded in ")#mi("L^{p},1<p\\leq\\infty")#text(".\"")

#text("But I think polygons can be used to construct the same counter-example as balls.")

#text("Use the same construction in Fefferman's example, if ")#mi("P_{U}")#text("(U is the polygon) is bounded in ")#mi("L^{p}")#text(",then for any dilation and rigid motion L ")#mi("P_{LU}")#text(" is also bounded with the same norm.Then rescale U based on a point on its edges (but not vertices) to exhaust the whole half plane.By Fatou's lemma, it implies the boundness of projection to half plane…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-592601")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2020")])]

#text("The square function over any bounded number of half-planes is still bounded. Only the square function over an unbounded number of half-planes becomes unbounded. Similarly, the multiplier to a polygon with boundedly many sides remains bounded in ")#mi("L^p")#text(", but as the number of sides goes to infinity, the ")#mi("L^p")#text(" operator norm will also go to infinity (assuming the orientations of the sides are suitably well distributed in space).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c6668e7d973cab84c16c3f5c09f99f7655fcf5c6643444dadc11baf3547513f-38930093825bac006c6d7cec9c8ee0ac4ed1ba940f8a233a75c9f0c691bb6ae2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zorich")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-593351")[#strong[#text("zorich")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2020")])]

#text("Thanks a lot! For polygons, to get half plane pointing different directions, we must use rotations, but ")#tao-math("{(\\Sigma_{a\\in A}\\left|f_{a}(O_{a}x)\\right|^{2})^{\\frac{1}{2}}}", block: false)#text(" can’t be controlled by ")#tao-math("{(\\Sigma_{a\\in A}\\left|f_{a}(x)\\right|^{2})^{\\frac{1}{2}}}", block: false)#text(" If ")#mi("O_{a},a\\in A")#text(" is different rotations.but for spheres, we only need to use translation(multiplied by a phase) and dilation")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee4baa13a3d61e77b3e03173fa57ae78ac5c60dbdc4256a41dc6e7bbb6d9e4d3-3e9ff1394ba7d3ea041c3d02b4895dd26c6c919c4d2b6c4bb683b6bd7c9377ae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Small typo")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-621913")[#strong[#text("Small typo")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2021")])]

#text("Small typo on the index of the random signs:")#linebreak()#text(" “…with symbol {\\sum_{j=1}^n \\epsilon_n \\psi(\\xi/2^{k_j})}.”, should be “…with symbol {\\sum_{j=1}^n \\epsilon_j\\psi(\\xi/2^{k_j})}.”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of B")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-631967")[#strong[#text("B")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2021")])]

#text("I’m a little confused as to how to make use of the boundedness of the Fourier projection operators in Exercise 10(iv); any advice? I’m guessing it must be needed to get some sort of “reverse interpolation inequality”, but I’m not sure how to make this precise.")

#emph[#text("[In order to apply an interpolation theorem, such as Riesz-Thorin, the estimates one is interpolating must be allowed to range freely the entirety of an ")#mi("L^p")#text(" space; one cannot automatically impose a restriction on these functions, such as a requirement that the functions have specified Fourier support, and still expect to have an interpolation theorem. However, one can get around this for this particular problem by inserting Fourier projections into the decoupling inequality to be proven, which permit the functions involved to now have arbitrary Fourier support. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/04/13/247b-notes-2-decoupling-theory/comment-page-1/#comment-634211")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2021")])]

#text("In the statememt of Ex 3, $\\Omega$ should be $D$ right? Or am I missing smth?")

#emph[#text("[I am defining the projections ")#mi("P_\\Omega")#text(" here for arbitrary sets ")#mi("\\Omega")#text(", such as the half-planes ")#mi("H_j")#text(" in part (i). -T.]")]
]
