// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/
// Converted to Typst by tao2typ: "2026-10-14T15:17:00.828754+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245B, Notes 6: Duality and the Hahn-Banach theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245B, Notes 6: Duality and the Hahn-Banach theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 January 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/")[#text("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("When studying a mathematical space X (e.g. a vector space, a topological space, a manifold, a group, an algebraic variety etc.), there are two fundamentally basic ways to try to understand the space:")

#enum(start: 1, 
[#text("By looking at subobjects ")#emph[#text("in")]#text(" X, or more generally maps ")#mi("f: Y \\to X")#text(" from some other space Y into X. For instance, a point in a space X can be viewed as a map from ")#mi("pt")#text(" to X; a curve in a space X could be thought of as a map from ")#mi("{}[0,1]")#text(" to X; a group G can be studied via its subgroups K, and so forth.")],
[#text("By looking at objects ")#emph[#text("on")]#text(" X, or more precisely maps ")#mi("f: X \\to Y")#text(" from X into some other space Y. For instance, one can study a topological space X via the real- or complex-valued continuous functions ")#mi("f \\in C(X)")#text(" on X; one can study a group G via its quotient groups ")#mi("\\pi: G \\to G/H")#text("; one can study an algebraic variety V by studying the polynomials on V (and in particular, the ideal of polynomials that vanish identically on V); and so forth.")]
)

#text("(There are also more sophisticated ways to study an object via its maps, e.g. by studying extensions, joinings, splittings, universal lifts, etc. The general study of objects via the maps between them is formalised abstractly in modern mathematics as ")#link("http://en.wikipedia.org/wiki/Category_theory")[#text("category theory")]#text(", and is also closely related to ")#link("http://en.wikipedia.org/wiki/Homological_algebra")[#text("homological algebra")]#text(".)")

#text("A remarkable phenomenon in many areas of mathematics is that of ")#link("http://en.wikipedia.org/wiki/Duality_(mathematics)#Contravariant_dualities")[#text("(contravariant) ")#emph[#text("duality")]]#text(": that the maps into and out of one type of mathematical object X can be naturally associated to the maps ")#emph[#text("out of")]#text(" and ")#emph[#text("into")]#text(" a dual object ")#mi("X^*")#text(" (note the reversal of arrows here!). In some cases, the dual object ")#mi("X^*")#text(" looks quite different from the original object X. (For instance, in ")#link("http://en.wikipedia.org/wiki/Stone_duality")[#text("Stone duality")]#text(", discussed in ")#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/")[#text("Notes 4")]#text(", X would be a Boolean algebra (or some other partially ordered set) and ")#mi("X^*")#text(" would be a compact totally disconnected Hausdorff space (or some other topological space).) In other cases, most notably with Hilbert spaces as discussed in ")#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/")[#text("Notes 5")]#text(", the dual object ")#mi("X^*")#text(" is essentially identical to X itself.")

#text("In these notes we discuss a third important case of duality, namely duality of ")#link("http://en.wikipedia.org/wiki/Normed_vector_space")[#text("normed vector spaces")]#text(", which is of an intermediate nature to the previous two examples: the dual ")#mi("X^*")#text(" of a normed vector space turns out to be another normed vector space, but generally one which is not equivalent to X itself (except in the important special case when X is a Hilbert space, as mentioned above). On the other hand, the double dual ")#mi("(X^*)^*")#text(" turns out to be closely related to X, and in several (but not all) important cases, is essentially identical to X. One of the most important uses of dual spaces in functional analysis is that it allows one to define the ")#link("http://en.wikipedia.org/wiki/Transpose")[#text("transpose")]#text(" ")#mi("T^*: Y^* \\to X^*")#text(" of a continuous linear operator ")#mi("T: X \\to Y")#text(".")

#text("A fundamental tool in understanding duality of normed vector spaces will be the ")#link("http://en.wikipedia.org/wiki/Hahn-Banach_theorem")[#text("Hahn-Banach theorem")]#text(", which is an indispensable tool for exploring the dual of a vector space. (Indeed, without this theorem, it is not clear at all that the dual of a non-trivial normed vector space is non-trivial!) Thus, we shall study this theorem in detail in these notes concurrently with our discussion of duality.")

#heading(level: 1)[#metadata(none) <tao-83d84090e9a940cddd41>#text("— Duality —")]

#text("In the category of normed vector spaces, the natural notion of a “map” (or morphism) between two such spaces is that of a ")#emph[#text("continuous linear transformation")]#text(" ")#mi("T: X \\to Y")#text(" between two normed vector spaces X, Y. By Lemma 1 from ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("Notes 3")]#text(", any such linear transformation is bounded, in the sense that there exists a constant C such that ")#tao-math("\\left\\|Tx\\right\\|_Y \\leq C\\left\\|x\\right\\|_X", block: false)#text(" for all ")#mi("x \\in X")#text(". The least such constant C is known as the ")#link("http://en.wikipedia.org/wiki/Operator_norm")[#text("operator norm")]#text(" of T, and is denoted ")#tao-math("\\left\\|T\\right\\|_{op}", block: false)#text(" or simply ")#tao-math("\\left\\|T\\right\\|", block: false)#text(".")

#text("Two normed vector spaces ")#mi("X, Y")#text(" are ")#emph[#text("equivalent")]#text(" if there is an invertible continuous linear transformation ")#mi("T: X \\to Y")#text(" from X to Y, thus T is bijective and there exist constants ")#mi("C, c > 0")#text(" such that ")#tao-math("c\\left\\|x\\right\\|_X \\leq \\left\\|Tx\\right\\|_Y \\leq C\\left\\|x\\right\\|_X", block: false)#text(" for all ")#mi("x \\in X")#text(". If one can take C=c=1, then T is an ")#emph[#text("isometry")]#text(", and X and Y are called ")#emph[#text("isomorphic")]#text(". When one has two norms ")#mi("\\|\\|_1, \\| \\|_2")#text(" on the same vector space X, we say that the norms are equivalent if the identity from ")#mi("(X, \\| \\|_1)")#text(" to ")#mi("(X, \\| \\|_2)")#text(" is an invertible continuous transformation, i.e. that there exist constants ")#mi("C, c > 0")#text(" such that ")#tao-math("c\\left\\|x\\right\\|_1 \\leq\\left\\|x\\right\\|_2 \\leq C \\left\\|x\\right\\|_1", block: false)#text(" for all ")#mi("x \\in X")#text(".")

#strong[#text("Exercise 1.")]#text(" Show that all linear transformations from a finite-dimensional space to a normed vector space are continuous. Conclude that all norms on a finite-dimensional space are equivalent. ")#mi("\\diamond")

#text("Let ")#mi("B(X \\to Y)")#text(" denote the space of all continuous linear transformations from X to Y. (This space is also denoted by many other names, e.g. ")#mi("{\\mathcal L}(X,Y)")#text(", ")#mi("\\text{Hom}(X \\to Y)")#text(", etc.) This has the structure of a vector space: the sum ")#mi("S+T: x \\mapsto Sx+Tx")#text(" of two continuous linear transformations is another continuous linear transformation, as is the scalar multiple ")#mi("cT: x \\mapsto cTx")#text(" of a linear transformation.")

#strong[#text("Exercise 2.")]#text(" Show that ")#mi("B(X \\to Y)")#text(" with the operator norm is a normed vector space. If Y is complete (i.e. is a ")#link("http://en.wikipedia.org/wiki/Banach_space")[#text("Banach space")]#text("), show that ")#mi("B(X \\to Y)")#text(" is also complete (i.e. is also a Banach space). ")#mi("\\diamond")

#strong[#text("Exercise 3.")]#text(" Let X, Y, Z be Banach spaces. Show that if ")#mi("T \\in B(X \\to Y)")#text(" and ")#mi("S \\in B(Y \\to Z)")#text(", then the composition ")#mi("ST: X \\to Z")#text(" lies in ")#mi("B(X \\to Z)")#text(" and ")#tao-math("\\left\\|ST\\right\\|_{op} \\leq \\left\\|S\\right\\|_{op} \\left\\|T\\right\\|_{op}", block: false)#text(". (As a consequence of this inequality, we see that ")#mi("B(X \\to X)")#text(" is a ")#link("http://en.wikipedia.org/wiki/Banach_algebra")[#text("Banach algebra")]#text(".) ")#mi("\\diamond")

#text("Now we can define the notion of a dual space.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1. ")]#text(" (")#link("http://en.wikipedia.org/wiki/Dual_space")[#text("Dual space")]#text(") Let X be a normed vector space. The ")#emph[#text("(continuous) dual space")]#text(" ")#mi("X^*")#text(" of X is defined to be ")#mi("X^* := B( X \\to {\\Bbb R} )")#text(" if X is a real vector space, and ")#mi("X^* := B(X \\to {\\Bbb C})")#text(" if X is a complex vector space. Elements of ")#mi("X^*")#text(" are known as continuous linear functionals (or bounded linear functionals) on X.")
]

#strong[#text("Remark 1.")]#text(" If one drops the requirement that the linear functionals be continuous, we obtain the ")#emph[#text("algebraic dual space")]#text(" of linear functionals on X. This space does not play a significant role in functional analysis, though. ")#mi("\\diamond")

#text("From Exercise 2, we see that the dual of any normed vector space is a Banach space, and so duality is arguably a Banach space notion rather than a normed vector space notion. The following exercise reinforces this:")

#strong[#text("Exercise 4.")]#text(" We say that a normed vector space X has a completion ")#mi("\\overline{X}")#text(" if ")#mi("\\overline{X}")#text(" is a Banach space and X can be identified with a dense subspace of ")#mi("\\overline{X}")#text(" (cf. Exercise 8 of ")#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/")[#text("Notes 5")]#text(").")

#enum(start: 1, 
[#text("Show that every normed vector space X has at least one completion ")#mi("\\overline{X}")#text(", and that any two completions ")#mi("\\overline{X}, \\overline{X}^{\\prime}")#text(" are isomorphic in the sense that there exists an isomorphism from ")#mi("\\overline{X}")#text(" to ")#mi("\\overline{X}^{\\prime}")#text(" which is the identity on X.")],
[#text("Show that the dual spaces ")#mi("X^*")#text(" and ")#mi("(\\overline{X})^*")#text(" are isomorphic to each other. ")#mi("\\diamond")]
)

#text("The next few exercises are designed to give some intuition as to how dual spaces work.")

#strong[#text("Exercise 5.")]#text(" Let ")#mi("{\\Bbb R}^n")#text(" be given the Euclidean metric. Show that ")#mi("({\\Bbb R}^n)^*")#text(" is isomorphic to ")#mi("{\\Bbb R}^n")#text(". Establish the corresponding result for the complex spaces ")#mi("{\\Bbb C}^n")#text(". ")#mi("\\diamond")

#strong[#text("Exercise 6.")]#text(" Let ")#mi("c_c({\\Bbb N})")#text(" be the vector space of sequences ")#mi("(a_n)_{n \\in {\\Bbb N}}")#text(" of real or complex numbers which are compactly supported (i.e. at most finitely many of the ")#mi("a_n")#text(" are non-zero). We give ")#mi("c_c")#text(" the uniform norm ")#mi("\\| \\|_{\\ell^\\infty}")#text(".")

#enum(start: 1, 
[#text("Show that the dual space ")#mi("c_c({\\Bbb N})^*")#text(" is isomorphic to ")#mi("\\ell^1({\\Bbb N})")#text(".")],
[#text("Show that the completion of ")#mi("c_c({\\Bbb N})")#text(" is isomorphic to ")#mi("c_0({\\Bbb N})")#text(", the space of sequences on ")#mi("{\\Bbb N}")#text(" that go to zero at infinity (again with the uniform norm); thus, by Exercise 4, the dual space of ")#mi("c_0({\\Bbb N})")#text(" is isomorphic to ")#mi("\\ell^1({\\Bbb N})")#text(" also.")],
[#text("On the other hand, show that the dual of ")#mi("\\ell^1({\\Bbb N})")#text(" is isomorphic to ")#mi("\\ell^\\infty({\\Bbb N})")#text(", a space which is strictly larger than ")#mi("c_c({\\Bbb N})")#text(" or ")#mi("c_0({\\Bbb N})")#text(". Thus we see that the double dual of a Banach space can be strictly larger than the space itself. ")#mi("\\diamond")]
)

#strong[#text("Exercise 7. ")]#text("Let H be a real or complex Hilbert space. Using the Riesz representation theorem for Hilbert spaces (Theorem 1 from ")#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/")[#text("Notes 5")]#text("), show that the dual space ")#mi("H^*")#text(" is isomorphic (as a normed vector space) to the conjugate space ")#mi("\\overline{H}")#text(" (see Example 8 from ")#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/")[#text("Notes 5")]#text("), with an element ")#mi("g \\in \\overline{H}")#text(" being identified with the linear functional ")#mi("f \\mapsto \\langle f, g \\rangle")#text(". Thus we see that Hilbert spaces are essentially self-dual (if we ignore the pesky conjugation sign). ")#mi("\\diamond")

#strong[#text("Exercise 8.")]#text(" Let ")#mi("(X,{\\mathcal X},\\mu)")#text(" be a ")#mi("\\sigma")#text("-finite measure space, and let ")#mi("1 \\leq p < \\infty")#text(". Using Theorem 1 from ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("Notes 3")]#text(", show that the dual space of ")#mi("L^p(X, {\\mathcal X},\\mu)")#text(" is isomorphic to ")#mi("L^{p^{\\prime}}(X, {\\mathcal X}, \\mu)")#text(", with an element ")#mi("g \\in L^{p^{\\prime}}(X,{\\mathcal X},\\mu)")#text(" being identified with the linear functional ")#mi("f \\mapsto \\int_X f g \\ d\\mu")#text(". (The one tricky thing to verify is that the identification is an isometry, but this can be seen by a closer inspection of the proof of Theorem 1 from Notes 3. The ")#mi("\\sigma")#text("-finite hypothesis can be dropped when ")#mi("p>1")#text(", though we will not need this fact.) ")#mi("\\diamond")

#text("One of the key purposes of introducing the notion of a dual space is that it allows one to define the notion of a transpose.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2.")]#text(" (")#link("http://en.wikipedia.org/wiki/Transpose")[#text("Transpose")]#text(") Let ")#mi("T: X \\to Y")#text(" be a continuous linear transformation from one normed vector space X to another Y. The ")#emph[#text("transpose ")]#mi("T^*: Y^* \\to X^*")#text(" of T is defined to be the map that sends any continuous linear functional ")#mi("\\lambda \\in Y^*")#text(" to the linear functional ")#mi("T^* \\lambda := \\lambda \\circ T \\in X^*")#text(", thus ")#mi("(T^* \\lambda)( x ) = \\lambda(Tx)")#text(" for all ")#mi("x \\in X")#text(".")
]

#strong[#text("Exercise 9.")]#text(" Show that the transpose ")#mi("T^*")#text(" of a continuous linear transformation T between normed vector spaces is again a continuous linear transformation with ")#tao-math("\\left\\|T^*\\right\\|_{op} \\leq \\left\\|T\\right\\|_{op}", block: false)#text(", thus the transpose operation is itself a linear map from ")#mi("B(X \\to Y)")#text(" to ")#mi("B(Y^* \\to X^*)")#text(". (We will improve this result in Theorem 3 below.) ")#mi("\\diamond")

#strong[#text("Exercise 10.")]#text(" An ")#mi("n \\times m")#text(" matrix A with complex entries can be identified with a linear transformation ")#mi("L_A: {\\Bbb C}^n \\to {\\Bbb C}^m")#text(". Identifying the dual space of ")#mi("{\\Bbb C}^n")#text(" with itself as in Exercise 5, show that the transpose ")#mi("L_A^*: {\\Bbb C}^m \\to {\\Bbb C}^n")#text(" is equal to ")#mi("L_{A^t}")#text(", where ")#mi("A^t")#text(" is the transpose matrix of A. ")#mi("\\diamond")

#strong[#text("Exercise 11.")]#text(" Show that the transpose of a surjective continuous linear transformation between normed vector spaces is injective. Show that the condition of surjectivity can be relaxed to that of having a dense image. ")#mi("\\diamond")

#strong[#text("Remark 3.")]#text(" Observe that if ")#mi("T: X \\to Y")#text(" and ")#mi("S: Y \\to Z")#text(" are continuous linear transformations between normed vector spaces, then ")#mi("(ST)^* = T^* S^*")#text(". In the language of category theory, this means that duality ")#mi("X \\mapsto X^*")#text(" of normed vector spaces, and transpose ")#mi("T \\mapsto T^*")#text(" of continuous linear transformations, form a contravariant ")#link("http://en.wikipedia.org/wiki/Functor")[#text("functor")]#text(" from the category of normed vector spaces (or Banach spaces) to itself. ")#mi("\\diamond")

#strong[#text("Remark 4.")]#text(" The transpose ")#mi("T^*: \\overline{H^{\\prime}} \\to \\overline{H}")#text(" of a continuous linear transformation ")#mi("T: H \\to H^{\\prime}")#text(" between complex Hilbert spaces is closely related to the adjoint ")#mi("T^\\dagger: H^{\\prime} \\to H")#text(" of that transformation, as defined in Exercise 15 of ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("Notes 5")]#text(", by using the obvious (")#link("http://en.wikipedia.org/wiki/Antilinear")[#text("antilinear")]#text(") identifications between H and ")#mi("\\overline{H}")#text(", and between H’ and ")#mi("\\overline{H^{\\prime}}")#text(". This is analogous to the linear algebra fact that the adjoint matrix is the complex conjugate of the transpose matrix. One should note that in the literature, the transpose operator ")#mi("T^*")#text(" is also (somewhat confusingly) referred to as the adjoint of T. Of course, for real vector spaces, there is no distinction between transpose and adjoint. ")#mi("\\diamond")

#heading(level: 1)[#text("— The Hahn-Banach theorem —")]

#text("Thus far, we have defined the dual space ")#mi("X^*")#text(", but apart from some concrete special cases (Hilbert spaces, ")#mi("L^p")#text(" spaces, etc.) we have not been able to say much about what ")#mi("X^*")#text(" consists of – it is not even clear yet that if X is non-trivial (i.e. not just ")#mi("\\{0\\}")#text("), that ")#mi("X^*")#text(" is also non-trivial – for all one knows, there could be no non-trivial continuous linear functionals on X at all! The Hahn-Banach theorem is used to resolve this, by providing a powerful means to construct continuous linear functionals as needed.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (")#link("http://en.wikipedia.org/wiki/Hahn-Banach_theorem")[#text("Hahn-Banach theorem")]#text(") Let X be a normed vector space, and let Y be a subspace of X. Then any continuous linear functional ")#mi("\\lambda \\in Y^*")#text(" on Y can be extended to a continuous linear functional ")#mi("\\tilde \\lambda \\in X^*")#text(" on X with the same operator norm; thus ")#mi("\\tilde \\lambda")#text(" agrees with ")#mi("\\lambda")#text(" on Y and ")#tao-math("\\left\\| \\tilde \\lambda \\right\\|_{X^*} = \\left\\| \\lambda \\right\\|_{Y^*}", block: false)#text(". (Note: the extension ")#mi("\\tilde \\lambda")#text(" is, in general, not unique.)")
]

#text("We prove this important theorem in stages. We first handle the codimension one real case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" The Hahn-Banach theorem is true when X, Y are real vector spaces, and X is spanned by Y and an additional vector v.")
]

#strong[#text("Proof.")]#text(" We can assume that v lies outside Y, since the claim is trivial otherwise. We can also normalise ")#tao-math("\\left\\|\\lambda \\right\\|_{Y^*} = 1", block: false)#text(" (the claim is of course trivial if ")#tao-math("\\left\\|\\lambda \\right\\|_{Y^*}", block: false)#text(" vanishes). To specify the extension ")#mi("\\tilde \\lambda")#text(" of ")#mi("\\lambda")#text(", it suffices by linearity to specify the value of ")#mi("\\tilde \\lambda(v)")#text(". In order for the extension ")#mi("\\tilde \\lambda")#text(" to continue to have operator norm 1, we require that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\tilde \\lambda( y + tv )\\right| \\leq \\left\\| y + tv \\right\\|_X", block: true)]]

#text("for all ")#mi("t \\in {\\Bbb R}")#text(" and ")#mi("y \\in Y")#text(". This is automatic for t=0, so by homogeneity it suffices to attain this bound for ")#mi("t=1")#text(". We rearrange this a bit as")

#align(center)[#tao-math("\\sup_{y^{\\prime} \\in Y} -\\lambda(y^{\\prime}) - \\left\\|y^{\\prime}+v\\right\\|_X \\leq \\tilde \\lambda(v) \\leq \\inf_{y \\in Y} \\left\\| y+v \\right\\|_X - \\lambda(y)", block: false)#text(".")]

#text("But as ")#mi("\\lambda")#text(" has operator norm 1, an application of the triangle inequality shows that the inf on the RHS is at least as large as the sup on the LHS, and so one can choose ")#mi("\\tilde \\lambda(v)")#text(" obeying the required properties. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1.")]#text(" The Hahn-Banach theorem is true when X, Y are real normed vector spaces.")
]

#strong[#text("Proof.")]#text(" This is a standard “")#link("http://en.wikipedia.org/wiki/Zorn%27s_lemma")[#text("Zorn’s lemma")]#text("” argument. Fix Y, X, ")#mi("\\lambda")#text(". Define a ")#emph[#text("partial extension")]#text(" of ")#mi("\\lambda")#text(" to be a pair ")#mi("(Y^{\\prime}, \\lambda^{\\prime})")#text(", where Y’ is an intermediate subspace between Y and X, and ")#mi("\\lambda^{\\prime}")#text(" is an extension of ")#mi("\\lambda")#text(" with the same operator norm as ")#mi("\\lambda")#text(". The set of all partial extensions is partially ordered by declaring ")#mi("(Y^{\\prime\\prime},\\lambda^{\\prime\\prime}) \\geq (Y^{\\prime},\\lambda^{\\prime})")#text(" if ")#mi("Y^{\\prime\\prime}")#text(" contains ")#mi("Y^{\\prime}")#text(" and ")#mi("\\lambda^{\\prime\\prime}")#text(" extends ")#mi("\\lambda^{\\prime}")#text(". It is easy to see that every chain of partial extensions has an upper bound; hence, by Zorn’s lemma, there must be a maximal partial extension ")#mi("(Y_*,\\lambda_*)")#text(". If ")#mi("Y_*=X")#text(", we are done; otherwise, one can find ")#mi("v \\in X \\backslash Y_*")#text(". By Proposition 1, we can then extend ")#mi("\\lambda_*")#text(" further to the larger space spanned by ")#mi("Y_*")#text(" and v, a contradiction; and the claim follows. ")#mi("\\Box")

#strong[#text("Remark 5.")]#text(" Of course, this proof of the Hahn-Banach theorem relied on the axiom of choice (via Zorn’s lemma) and is thus non-constructive. It turns out that this is, to some extent, necessary: it is not possible to prove the Hahn-Banach theorem if one deletes the axiom of choice from the axioms of set theory (although it is possible to deduce the theorem from slightly weaker versions of this axiom, such as the ")#link("http://en.wikipedia.org/wiki/Ultrafilter_lemma")[#text("ultrafilter lemma")]#text("). ")#mi("\\diamond")

#text("Finally, we establish the complex case by leveraging the real case.")

#strong[#text("Proof of Hahn-Banach theorem (complex case).")]#text(" Let ")#mi("\\lambda: Y \\to {\\Bbb C}")#text(" be a continuous complex-linear functional, which we can normalise to have operator norm 1. Then the real part ")#mi("\\rho := \\text{Re}(\\lambda): Y \\to {\\Bbb R}")#text(" is a continuous real-linear functional on Y (now viewed as a real normed vector space rather than a complex one), which has operator norm at most 1 (in fact, it is equal to 1, though we will not need this). Applying Corollary 1, we can extend this real-linear functional ")#mi("\\rho")#text(" to a continuous real-linear functional ")#mi("\\tilde \\rho: X \\to {\\Bbb R}")#text(" on X (again viewed now just as a real normed vector space) of norm at most 1.")

#text("To finish the job, we have to somehow complexify ")#mi("\\tilde \\rho")#text(" to a complex-linear functional ")#mi("\\tilde \\lambda: X \\to {\\Bbb C}")#text(" of norm at most 1 that agrees with ")#mi("\\lambda")#text(" on Y. It is reasonable to expect that ")#mi("\\text{Re} \\tilde \\lambda = \\tilde \\rho")#text("; a bit of playing around with complex linearity then forces")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\tilde \\lambda(x) := \\tilde \\rho(x) - i \\tilde \\rho(ix).")]]

#text("Accordingly, we shall use (1) to ")#emph[#text("define")]#text(" ")#mi("\\tilde \\lambda")#text(". It is easy to see that ")#mi("\\tilde \\lambda")#text(" is a continuous complex-linear functional agreeing with ")#mi("\\lambda")#text(" on Y. Since ")#mi("\\tilde \\rho")#text(" has norm at most 1, we have ")#tao-math("\\left|\\text{Re} \\tilde \\lambda(x)\\right| \\leq \\left\\|x\\right\\|_X", block: false)#text(" for all ")#mi("x \\in X")#text(". We can ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("amplify")]#text(" this by exploiting phase rotation symmetry, thus ")#tao-math("\\left|\\text{Re} \\tilde \\lambda(e^{i\\theta} x)\\right| \\leq \\left\\|x\\right\\|_X", block: false)#text(" for all ")#mi("\\theta \\in {\\Bbb R}")#text(". Optimising in ")#mi("\\theta")#text(" we see that ")#mi("\\tilde \\lambda")#text(" has norm at most 1, as required. ")#mi("\\Box")

#strong[#text("Exercise 12.")]#text(" In the special case when X is a Hilbert space, give an alternate proof of the Hahn-Banach theorem using the material from ")#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/")[#text("Notes 5")]#text(" that avoids Zorn’s lemma or the axiom of choice. ")#mi("\\diamond")

#text("Now we put this Hahn-Banach theorem to work in the study of duality and transposes.")

#strong[#text("Exercise 13.")]#text(" Let ")#mi("T: X \\to Y")#text(" be a continuous linear transformation which is bounded from below (i.e. there exists ")#mi("c > 0")#text(" such that ")#tao-math("\\left\\|Tx\\right\\| \\geq c\\left\\|x\\right\\|", block: false)#text(" for all ")#mi("x \\in X")#text("); note that this ensures that X is equivalent to some subspace of Y. Show that the transpose ")#mi("T^*: Y^* \\to X^*")#text(" is surjective. Give an example to show that the claim fails if T is merely assumed to be injective rather than bounded from below. (Hint: consider the map ")#mi("(a_n)_{n=1}^\\infty \\to (a_n/n)_{n=1}^\\infty")#text(" on some suitable space of sequences.) This should be compared with Exercise 11. ")#mi("\\diamond")

#strong[#text("Exercise 14.")]#text(" Let x be an element of a normed vector space X. Show that there exists ")#mi("\\lambda \\in X^*")#text(" such that ")#tao-math("\\left\\|\\lambda\\right\\|_{X^*}=1", block: false)#text(" and ")#tao-math("\\lambda(x) = \\left\\|x\\right\\|_X", block: false)#text(". Conclude in particular that the dual of a non-trivial normed vector space is again non-trivial. ")#mi("\\diamond")

#text("Given a normed vector space X, we can form its double dual ")#mi("(X^*)^*")#text(": the space of continuous linear functionals on ")#mi("X^*")#text(". There is a very natural map ")#mi("\\iota: X \\to (X^*)^*")#text(", defined as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\iota(x) (\\lambda) := \\lambda(x)")]]

#text("for all ")#mi("x \\in X")#text(" and ")#mi("\\lambda \\in X^*")#text(". (This map is closely related to the ")#link("http://en.wikipedia.org/wiki/Gelfand_representation")[#text("Gelfand transform")]#text(" in the theory of operator algebras.) It is easy to see that ")#mi("\\iota")#text(" is a continuous linear transformation, with operator norm at most 1. But the Hahn-Banach theorem gives a stronger statement:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2.")]#text(" ")#mi("\\iota")#text(" is an isometry.")
]

#strong[#text("Proof.")]#text(" We need to show that ")#tao-math("\\left\\|\\iota(x)\\right\\|_{X^{**}} = \\left\\|x\\right\\|", block: false)#text(" for all ")#mi("x \\in X")#text(". The upper bound is clear; the lower bound follows from Exercise 14. ")#mi("\\Box")

#strong[#text("Exercise 15.")]#text(" Let Y be a subspace of a normed vector space X. Define the ")#emph[#text("complement")]#text(" ")#mi("Y^\\perp")#text(" of Y to be the space of all ")#mi("\\lambda \\in X^*")#text(" which vanish on Y.")

#enum(start: 1, 
[#text("Show that ")#mi("Y^\\perp")#text(" is a closed subspace of ")#mi("X^*")#text(", and that ")#mi("\\overline{Y} := \\{ x \\in X: \\lambda(x)=0 \\text{ for all } \\lambda \\in Y^\\perp \\}")#text("; (Compare with Exercise 13 from ")#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/")[#text("Notes 5")]#text(".) In other words, ")#mi("\\iota(\\overline{Y}) = \\iota(X) \\cap Y^{\\perp \\perp}")#text(".")],
[#text("Show that ")#mi("Y^\\perp")#text(" is trivial if and only if Y is dense, and ")#mi("Y^\\perp = X^*")#text(" if and only if Y is trivial.")],
[#text("Show that ")#mi("Y^\\perp")#text(" is isomorphic to the dual of the quotient space ")#mi("X/\\overline{Y}")#text(" (which has the norm ")#tao-math("\\left\\|x+\\overline{Y}\\right\\|_{X/\\overline{Y}} := \\inf_{y \\in \\overline{Y}} \\left\\|x+y\\right\\|_{X}", block: false)#text(").")],
[#text("Show that ")#mi("Y^*")#text(" is isomorphic to ")#mi("X^*/Y^\\perp")#text(". ")#mi("\\diamond")]
)

#text("From Theorem 2, every normed vector space can be identified with a subspace of its double dual (and every Banach space is identified with a ")#emph[#text("closed")]#text(" subspace of its double dual). If ")#mi("\\iota")#text(" is surjective, then we have an isomorphism ")#mi("X \\equiv X^{**}")#text(", and we say that X is ")#link("http://en.wikipedia.org/wiki/Reflexive_space")[#emph[#text("reflexive")]]#text(" in this case; since ")#mi("X^{**}")#text(" is a Banach space, we conclude that only Banach spaces can be reflexive. From linear algebra we see in particular that any finite-dimensional normed vector space is reflexive; from Exercises 7, 8 we see that any Hilbert space and any ")#mi("L^p")#text(" space with ")#mi("1 < p < \\infty")#text(" on a ")#mi("\\sigma")#text("-finite space is also reflexive (and the hypothesis of ")#mi("\\sigma")#text("-finiteness can in fact be dropped). On the other hand, from Exercise 6 we see that the Banach space ")#mi("c_0({\\Bbb N})")#text(" is not reflexive.")

#text("An important fact is that ")#mi("l^1({\\Bbb N})")#text(" is also not reflexive: the dual of ")#mi("l^1({\\Bbb N})")#text(" is equivalent to ")#mi("l^\\infty({\\Bbb N})")#text(", but the dual of ")#mi("l^\\infty({\\Bbb N})")#text(" is strictly larger than that of ")#mi("l^1({\\Bbb N})")#text(". Indeed, consider the subspace ")#mi("c({\\Bbb N})")#text(" of ")#mi("l^\\infty({\\Bbb N})")#text(" consisting of bounded convergent sequences (equivalently, this is the space spanned by ")#mi("c_0({\\Bbb N})")#text(" and the constant sequence ")#mi("(1)_{n \\in {\\Bbb N}}")#text("). The limit functional ")#mi("(a_n)_{n=1}^\\infty \\mapsto \\lim_{n \\to \\infty} a_n")#text(" is a bounded linear functional on ")#mi("c({\\Bbb N})")#text(", with operator norm 1, and thus by the Hahn-Banach theorem can be extended to a generalised limit functional ")#mi("\\lambda: l^\\infty({\\Bbb N}) \\to{\\Bbb C}")#text(" which is a continuous linear functional of operator norm 1. As such generalised limit functionals annihilate all of ")#mi("c_0({\\Bbb N})")#text(" but are still non-trivial, they do not correspond to any element of ")#mi("\\ell^1({\\Bbb N}) \\equiv c_0({\\Bbb N})^*")#text(".")

#strong[#text("Exercise 16.")]#text(" Let ")#mi("\\lambda: l^\\infty({\\Bbb N}) \\to {\\Bbb C}")#text(" be a generalised limit functional (i.e. an extension of the limit functional of ")#mi("c({\\Bbb N})")#text(" of operator norm 1) which is also an algebra homomorphism, i.e. ")#mi("\\lambda( (x_n y_n)_{n=1}^\\infty ) = \\lambda( (x_n)_{n=1}^\\infty ) \\lambda( (y_n)_{n=1}^\\infty )")#text(" for all sequences ")#mi("(x_n)_{n=1}^\\infty, (y_n)_{n=1}^\\infty \\in \\ell^\\infty({\\Bbb N})")#text(". Show that there exists a unique non-principal ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("ultrafilter")]#text(" ")#mi("p \\in \\beta {\\Bbb N}\\backslash {\\Bbb N}")#text(" (as defined for instance in ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("this blog post")]#text(") such that ")#mi("\\lambda( (x_n)_{n=1}^\\infty ) = \\lim_{n \\to p} x_n")#text(" for all sequences ")#mi("(x_n)_{n=1}^\\infty \\in \\ell^\\infty({\\Bbb N})")#text(". Conversely, show that every non-principal ultrafilter generates a generalised limit functional that is also an algebra homomorphism. (This exercise may become easier once one is acquainted with the ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93%C4%8Cech_compactification")[#text("Stone-Čech compactification")]#text(", as discussed for instance in ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("this lecture")]#text(", and which we will discuss later in this course. If the algebra homomorphism property is dropped, one has to consider probability measures on the space of non-principal ultrafilters instead.) ")#mi("\\diamond")

#strong[#text("Exercise 17. ")]#text(" Show that any closed subspace of a reflexive space is again reflexive. Also show that a Banach space X is reflexive if and only if its dual is reflexive. Conclude that if ")#mi("(X,{\\mathcal X}, \\mu)")#text(" is a measure space which contains a countably infinite sequence of disjoint sets of positive finite measure, then ")#mi("L^1(X,{\\mathcal X},\\mu)")#text(" and ")#mi("L^\\infty(X,{\\mathcal X},\\mu)")#text(" are not reflexive. (")#emph[#text("Hint")]#text(": Reduce to the ")#mi("\\sigma")#text("-finite case. ")#mi("L^\\infty")#text(" will contain an isometric copy of ")#mi("\\ell^\\infty({\\Bbb N})")#text(".) ")#mi("\\diamond")

#text("Theorem 2 gives a classification of sorts for normed vector spaces:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1.")]#text(" Every normed vector space X is isomorphic to a subspace of BC(Y), the space of bounded continuous functions on some bounded complete metric space Y, with the uniform norm.")
]

#strong[#text("Proof.")]#text(" Take Y to be the unit ball in ")#mi("X^*")#text(", then the map ")#mi("\\iota")#text(" identifies X with a subspace of BC(Y). ")#mi("\\Box")

#strong[#text("Remark 6.")]#text(" If X is separable, it is known that one can take Y to just be the unit interval [0,1]; this is the ")#link("http://en.wikipedia.org/wiki/Banach-Mazur_theorem")[#text("Banach-Mazur theorem")]#text(", which we will not prove here. ")#mi("\\diamond")

#text("Next, we apply the Hahn-Banach theorem to the transpose operation, improving Exercise 9.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3.")]#text(" Let ")#mi("T: X \\to Y")#text(" be a continuous linear transformation between normed vector spaces. Then ")#tao-math("\\left\\|T^*\\right\\|_{op} = \\left\\|T\\right\\|_{op}", block: false)#text("; thus the transpose operation is an isometric embedding of ")#mi("B(X \\to Y)")#text(" into ")#mi("B(Y^* \\to X^*)")#text(".")
]

#strong[#text("Proof. ")]#text(" By Exercise 9, it suffices to show that ")#tao-math("\\left\\|T^*\\right\\|_{op} \\geq \\left\\|T\\right\\|_{op}", block: false)#text(". Accordingly, let ")#mi("\\alpha")#text(" be any number strictly less than ")#tao-math("\\left\\|T\\right\\|_{op}", block: false)#text(", then we can find ")#mi("x \\in X")#text(" such that ")#tao-math("\\left\\|Tx\\right\\|_Y \\geq \\alpha \\left\\|x\\right\\|", block: false)#text(". By Exercise 14 we can then find ")#mi("\\lambda \\in Y^*")#text(" such that ")#tao-math("\\left\\|\\lambda\\right\\|_{Y^*}=1", block: false)#text(" and ")#tao-math("\\lambda(Tx) = T^*\\lambda(x) = \\left\\|Tx\\right\\|_Y \\geq \\alpha \\left\\|x\\right\\|", block: false)#text(", and thus ")#tao-math("\\left\\|T^* \\lambda \\right\\|_{X^*} \\geq \\alpha", block: false)#text(". This implies that ")#tao-math("\\left\\|T^*\\right\\|_{op} \\geq \\alpha", block: false)#text("; taking suprema over all ")#mi("\\alpha")#text(" strictly less than ")#tao-math("\\left\\|T\\right\\|_{op}", block: false)#text(" we obtain the claim. ")#mi("\\Box")

#text("If we identify X and Y with subspaces of ")#mi("X^{**}")#text(" and ")#mi("Y^{**}")#text(" respectively, we thus see that ")#mi("T^{**}: X^{**} \\to Y^{**}")#text(" is an extension of ")#mi("T: X \\to Y")#text(" with the same operator norm. In particular, if X and Y are reflexive, we see that ")#mi("T^{**}")#text(" can be identified with T itself (exactly as in the finite-dimensional linear algebra setting).")

#heading(level: 1)[#text("— Variants of the Hahn-Banach theorem (optional) —")]

#text("The Hahn-Banach theorem has a number of essentially equivalent variants, which also are of interest for the geometry of normed vector spaces.")

#strong[#text("Exercise 18.")]#text(" (generalised Hahn-Banach theorem) Let Y be a subspace of a real or complex vector space X, let ")#mi("\\rho: X \\to {\\Bbb R}")#text(" be a sublinear functional on X (thus ")#mi("\\rho(cx) = c \\rho(x)")#text(" for all non-negative c and all ")#mi("x \\in X")#text(", and ")#mi("\\rho(x+y) \\leq \\rho(x)+\\rho(y)")#text(" for all ")#mi("x, y \\in X")#text("), and let ")#mi("\\lambda: Y \\to {\\Bbb R}")#text(" be a linear functional on Y such that ")#mi("\\lambda(y) \\leq \\rho(y)")#text(" for all ")#mi("y \\in Y")#text(". Show that ")#mi("\\lambda")#text(" can be extended to a linear functional ")#mi("\\tilde \\lambda")#text(" on X such that ")#mi("\\tilde \\lambda(x) \\leq \\rho(x)")#text(" for all ")#mi("x \\in X")#text(". Show that this statement implies the usual Hahn-Banach theorem. (")#emph[#text("Hint")]#text(": adapt the proof of the Hahn-Banach theorem.) ")#mi("\\diamond")

#text("Call a subset A of a real vector space V ")#emph[#text("algebraically open")]#text(" if the sets ")#mi("\\{t: x+tv \\in A \\}")#text(" are open in ")#mi("{\\Bbb R}")#text(" for all ")#mi("x,v \\in V")#text("; note that every open set in a normed vector space is algebraically open.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4.")]#text(" (Geometric Hahn-Banach theorem) Let A, B be convex subsets of a real vector space V, with A algebraically open. Then the following are equivalent:")

#enum(start: 1, 
[#text("A and B are disjoint.")],
[#text("There exists a linear functional ")#mi("\\lambda: V \\to {\\Bbb R}")#text(" and a constant c such that ")#mi("\\lambda < c")#text(" on A, and ")#mi("\\lambda \\geq c")#text(" on B. (Equivalently, there is a hyperplane separating A and B, with A avoiding the hyperplane entirely.)")]
)

#text("If A and B are convex cones (i.e. ")#mi("tx \\in A")#text(" whenever ")#mi("x \\in A")#text(" and ")#mi("t > 0")#text(", and similarly for B), we may take c=0.")
]

#strong[#text("Remark 7.")]#text(" In finite dimensions, it is not difficult to drop the algebraic openness hypothesis on ")#mi("A")#text(" as long as one now replaces the condition ")#mi("\\lambda < c")#text(" by ")#mi("\\lambda \\leq c")#text(". However in infinite dimensions one cannot do this. Indeed, if we take ")#mi("V = c_c({\\Bbb N})")#text(", let A be the set of sequences whose last non-zero element is strictly positive, and ")#mi("B = -A")#text(" consist of those sequences whose last non-zero element is strictly negative, then one can verify that there is no hyperplane separating ")#mi("A")#text(" from ")#mi("B")#text(". ")#mi("\\diamond")

#strong[#text("Proof. ")]#text(" Clearly 2 implies 1; now we show that 1 implies 2. We first handle the case when A and B are convex cones.")

#text("Define a good pair to be a pair (A,B) where A and B are disjoint convex cones, with A algebraically open, thus (A,B) is a good pair by hypothesis. We can order ")#mi("(A,B) \\leq (A^{\\prime},B^{\\prime})")#text(" if A’ contains A and B’ contains B. A standard application of Zorn’s lemma reveals that any good pair (A,B) is contained in a maximal good pair, and so without loss of generality we may assume that (A,B) is a maximal good pair.")

#text("We can of course assume that neither ")#mi("A")#text(" nor ")#mi("B")#text(" is empty.")#linebreak()#text(" We now claim that ")#mi("B")#text(" is the complement of ")#mi("A")#text(". For if not, then there exists ")#mi("v \\in V")#text(" which does not lie in either ")#mi("A")#text(" or ")#mi("B")#text(". By the maximality of ")#mi("(A,B)")#text(", the convex cone generated by ")#mi("B \\cup \\{v\\}")#text(" must intersect ")#mi("A")#text(" at some point, say ")#mi("w")#text(". By dilating ")#mi("w")#text(" if necessary we may assume that ")#mi("w")#text(" lies on a line segment between ")#mi("v")#text(" and some point ")#mi("b")#text(" in ")#mi("B")#text(". By using the convexity and disjointness of ")#mi("A")#text(" and ")#mi("B")#text(" one can then deduce that for any ")#mi("a \\in A")#text(", the ray ")#mi("\\{a + t(w-b): t > 0 \\}")#text(" is disjoint from ")#mi("B")#text(". Thus one can enlarge ")#mi("A")#text(" to the convex cone generated by ")#mi("A")#text(" and ")#mi("w-b")#text(", which is still algebraically open and now strictly larger than ")#mi("A")#text(" (because it contains ")#mi("v")#text("), a contradiction. Thus ")#mi("B")#text(" is the complement of ")#mi("A")#text(".")

#text("Let us call a line in ")#mi("V")#text(" \\emph{monochromatic} if it is entirely contained in ")#mi("A")#text(" or entirely contained in ")#mi("B")#text(". Note that if a line is not monochromatic, then (because ")#mi("A")#text(" and ")#mi("B")#text(" are convex and partition the line, and ")#mi("A")#text(" is algebraically open), the line splits into an open ray contained in ")#mi("A")#text(", and a closed ray contained in ")#mi("B")#text(". From this we can conclude that if a line is monochromatic, then all parallel lines must also be monochromatic, because otherwise we look at the ray in the parallel line which contains ")#mi("A")#text(" and use convexity of both ")#mi("A")#text(" and ")#mi("B")#text(" to show that this ray is adjacent to a halfplane contained in ")#mi("B")#text(", contradicting algebraic openness. Now let ")#mi("W")#text(" be the space of all vectors ")#mi("w")#text(" for which there exists a monochromatic line in the direction ")#mi("w")#text(" (including 0). Then ")#mi("W")#text(" is easily seen to be a vector space;")#linebreak()#text(" since ")#mi("A,B")#text(" are non-empty, ")#mi("W")#text(" is a proper subspace of ")#mi("V")#text(". On the other hand, if ")#mi("w")#text(" and ")#mi("w^{\\prime}")#text(" are not in ")#mi("W")#text(", some playing around with the property that ")#mi("A")#text(" and ")#mi("B")#text(" are convex sets partitioning ")#mi("V")#text(" shows that the plane spanned by ")#mi("w")#text(" and ")#mi("w^{\\prime}")#text(" contains a monochromatic line, and hence some non-trivial linear combination of ")#mi("w")#text(" and ")#mi("w^{\\prime}")#text(" lies in ")#mi("W")#text(". Thus ")#mi("V/W")#text(" is precisely one-dimensional. Since every line with direction in ")#mi("w")#text(" is monochromatic, ")#mi("A")#text(" and ")#mi("B")#text(" also have well-defined quotients ")#mi("A/W")#text(" and ")#mi("B/W")#text(" on this one-dimensional subspace, which remain convex (with ")#mi("A/W")#text(" still algebraically open). But then it is clear that ")#mi("A/W")#text(" and ")#mi("B/W")#text(" are an open and closed ray from the origin in ")#mi("V/W")#text(" respectively. It is then a routine matter to construct a linear functional ")#mi("\\lambda: V \\to {\\Bbb R}")#text(" (with null space ")#mi("W")#text(") such that ")#mi("A = \\{\\lambda 0, x \\in A \\}")#text(", ")#mi("B^{\\prime} := \\{ (t,tx): t > 0, x \\in B \\}")#text("; we leave the verification that this works as an exercise. ")#mi("\\Box")

#strong[#text("Exercise 19.")]#text(" Use the geometric Hahn-Banach theorem to reprove Exercise 18, thus providing a slightly different proof of the Hahn-Banach theorem. (It is possible to reverse these implications and deduce the geometric Hahn-Banach theorem from the usual Hahn-Banach theorem, but this is somewhat trickier, requiring one to fashion a norm out of the difference A-B of two convex cones.) ")#mi("\\diamond")

#strong[#text("Exercise 20. ")]#text(" (Algebraic Hahn-Banach theorem) Let V be a vector space over a field F, let W be a subspace of V, and let ")#mi("\\lambda: W \\to F")#text(" be a linear map. Show that there exists a linear map ")#mi("\\tilde \\lambda: V \\to F")#text(" which extends ")#mi("\\lambda")#text(". ")#mi("\\diamond")

#text("Some further discussion of variants of the Hahn-Banach theorem (in the finite-dimensional setting) can be found at ")#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/")[#text("this blog post of mine")]#text(".")

#heading(level: 1)[#text("Comments (60)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fd32a954b1244811372165c66d2e0e7d3c49c287250df20a64cd1df138b92d7-2340eda464d7cc2f368520668bbf2e77862f4ef07e72737648a4d4a011ec4584.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-35267")[#strong[#text("James")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2009")])]

#text("This is off, well not quite ‘off’, topic, but certainly out of the main focus…")

#text("I just watched my ex-college win convincingy on a UK quiz show called – not very suprisingly – ‘University Challenge’. (They trounced (365 to 20) the other team – hurah!) But one question they had was to name (I forget the exact words) but the name of the guy who created the most common integral used in most physics and engineering problems (to my dismay they didn’t know it was Riemann) then followed a question about which measure makes the Lesbesgue integral the same as the Riemann one (the answer apparently ‘Jordan’ – this I am not familiar with (and they also got it wrong))")

#text("However, my question is about the pronunciation of ‘Lesbesgue’, which was given by the quiz master as ‘le-bes-ke’ rather than the ‘le-bay-ge’ which I had always assumed – any official advice?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/626e53d46c710500df401cd08527c0d77bc41c025132055eb6b1eff8f8e41115-d87af44ed68cc76739d63ca4c13478d58612e8f3dab93013de42dffa7899abb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-35278")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2009")])]

#text("There are two Exercise 16s and the first one isn’t quite right. If by “generalized limit functional” you mean a norm 1 extension of the limit functional to all of ")#mi("\\ell^\\infty")#text(", then these are given just by elements of ")#mi("\\beta{\\mathbb N}\\backslash {\\mathbb N}")#text(" but by probability measures on it. Indeed, the full dual of ")#mi("\\ell^\\infty")#text(" is the space of regular complex measures on ")#mi("\\beta\\mathbb N")#text(" and functionals vanishing on ")#mi("c_0")#text(" are measures supported on ")#mi("\\beta{\\mathbb N}\\backslash {\\mathbb N}")#text(". However, if we restrict to functionals that are also multiplicative homomorphisms, we get only the point measures.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-35279")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2009")])]

#text("Oops! Thanks for the correction.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-35355")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2009")])]

#text("proof of Proposition 1: y’ -> y ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 9: The Baire category theorem and its Banach space consequences « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-35460")[#strong[#text("245B, Notes 9: The Baire category theorem and its Banach space consequences « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2009")])]

#text("[…] was first proven by using the duality of the Hardy space and BMO (and by using Exercise 13 from Notes 6), and by using the fact that a function f is in if and only if f and Hf both lie in . From the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-35542")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("Dear Professor Tao:")

#text("I don’t quite get the last two conslusions of Exercise 15, are there any typos there?")

#text("Xiaochuan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-35562")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("Oops, there were several typos there. I’ve hopefully corrected them now…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-35621")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("Dear Professor Tao:")

#text("I have a question about the last exercise (Exercise 20). I want to know if I can simply define the extension ")#mi("\\tilde \\lambda")#text(" as ")#mi("\\tilde \\lambda (v) =\\lambda (w)")#text(" where w is the element in W such that ")#mi("v-w")#text(" minimises the distance of v and W.")

#text("Xiaochuan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-35622")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2009")])]

#text("Dear Xiaochuan,")

#text("You can do this if V is a real Hilbert space and W is a closed subspace of V, but the hypotheses of the exercise are significantly more general than this. (In particular, the field F does not need to be real or complex.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 10: Compactness in topological spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-35639")[#strong[#text("245B, Notes 10: Compactness in topological spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("[…] Recent Comments 245B, Notes 10: Comp… on 245B, Notes 9: The Baire categ…Raja on 254A, Lecture 8: The mean ergo…Boris on Upper and lower bounds for the…Jason Dyer on Upper and lower bounds for the…Jason Dyer on Upper and lower bounds for the…Gil on Upper and lower bounds for the…Michael Peake on Upper and lower bounds for the…Anonymous on Upper and lower bounds for the…Terence Tao on Random matrices: Universality …Stuart Anderson on Another advice page, and an op…Rajan on Proposed stimulus amendment el…Kristal Cantwell on Upper and lower bounds for the…Kristal Cantwell on Upper and lower bounds for the…Anonymous on Random matrices: Universality …Terence Tao on 245B, Notes 6: Duality and the… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 实分析0-10 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-35899")[#strong[#text("实分析0-10 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("[…] 第六节讲的是对偶关系和Hahn-Banach定理。该定理的重要程度没法再强调了，在数学论文中，可以不用写参考文献直接使用。没有人不知道的。而关于对偶关系，前边我在帖子中写过一个利用弱*拓扑和Alaoglu定理来证明StoneCech紧化的帖子，跟ultrafilter有很大关系，取自John.B.Conway的书。本节中几个重点的例子也蛮重要的。还有就是最后一部分中Hahn-Banach定理的各种加强版。在这方面我手头最好的教材就是上面说的这本书了：A course in functional analysis GTM96. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of -PRM-")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-36280")[#strong[#text("-PRM-")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2009")])]

#text("Dear Pr. Tao,")

#text("As you wrote, a Banach space is reflexive iff the injective mapping ")#mi("\\iota: X \\to (X^*)^*")#text(" is in fact an isomorphism. However, there exist Banach spaces X which are isometric to X” without being reflexive. I have run into an example but it was really complicated (the definition of the space itself took almost two pages !). Do you know any simple examples ?")

#text("Thanks")

#text("To Eric : Lebesgue, the s (yes, there’s only one !) isn’t pronounced, and it indeed sounds like “Luh – Bayg” ; if you wanna hear it in French, I think there’s an online video course by Pr. Jacques Vauthier about “mesure de Lebesgue” :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-36304")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("Dear Prof. Tao,")

#text("I was a little confused on the second part of exercise 17. Do we need the disjoint sets sequence have measures uniformly bounded from below by some positive number?")

#text("If ")#mi("\\mu")#text(" is a finite measure, is ")#mi("L^{\\infty}(X,\\mathcal{X}, \\mu)")#text(" dual to ")#mi("L^{1}(X,\\mathcal{X}, \\mu)")#text("? I tried to find the answer in Yosida’s book ‘Functional Analysis’, but it seems not to give it.")

#text("Thanks a lot in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-36307")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("Dear PDEbeginner,")

#text("No, this is not necessary in order for ")#mi("L^\\infty(X,{\\mathcal X},\\mu)")#text(" to contain an isometric copy of ")#mi("l^\\infty({\\Bbb N})")#text(".")

#text("L^infty is indeed the dual of L^1 on finite measure spaces (or even sigma-finite spaces). This is essentially done in Theorem 1 of Notes 2 (though a little more work is needed to show that the identification of ")#mi("L^\\infty")#text(" with ")#mi("(L^1)^*")#text(" is an isomorphism). It’s also in Folland’s book on real analysis.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-36316")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("Dear Prof. Tao,")

#text("Thanks for your answer!")

#text("In my last question, I actually made a mistake. What I really want to ask is")

#text("If ")#mi("\\mu")#text(" is finite, is ")#mi("L^1(X, \\mathcal{X}, \\mu)")#text(" dual to ")#mi("L^{\\infty}(X, \\mathcal{X}, \\mu)")#text("?")

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-36317")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("Dear PDEbeginner,")

#text("This is true when X is finite, but is false in general, because ")#mi("L^\\infty")#text(" is often inseparable, while ")#mi("L^1")#text(" is often separable, and separable spaces cannot be the dual of inseparable spaces (Remark 6 of Notes 11). One can also often construct “explicit” elements of ")#mi("(L^\\infty)^*")#text(" outside of ")#mi("L^1")#text(" using ultrafilters or Hahn-Banach.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-36318")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("Dear Prof. Tao,")

#text("I was still confused on the second part of excercise 17. It will imply that ")#mi("(L^{\\infty}([0,1], Leb))^{*} \\neq L^1([0,1], Leb)")#text(", but I have some problem to apply the arguments below Exercise 15 to prove it: Let us consider ")#mi("L^{\\infty}([0,1], Leb)")#text(", take the disjoint sets as ")#mi("(0,1/2), (1/2,3/4),(3/4,7/8), \\ldots")#text(". Applying the similar arguments as in the ")#mi("l^{\\infty}")#text(" case, firstly construct the linear functional in some subspace of ")#mi("L^{\\infty}([0,1], Leb)")#text(" (kind of step fundtion space, I think), then apply Hahn-Banach thm to extend this linear functional to ")#mi("L^{1}([0,1], Leb)")#text(". But then the arguments seem not to be applied due to the finiteness of the measure.")

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of -PRM-")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-36321")[#strong[#text("-PRM-")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("First possibility : the family (g_t)_{0 \\leq t \\leq 1}) where g_t=1_{[0,t]}, is uncountable, and d(g_t,g_s) is bounded from below, hence L^{\\infty} is separable.")

#text("Second possibiility : define the linear functional \\phi on C^0([0,1]) by \\phi(f)=f(0), extend it to L^{\\infty} with H.-B. and prove that the linear functional you obtained can’t be represented by a function in L^1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The uncertainty principle « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-45719")[#strong[#text("The uncertainty principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2010")])]

#text("[…] linear functionals; and so forth.) A fundamental connection between the two is given by the Hahn-Banach theorem (and its […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yucao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-50220")[#strong[#text("yucao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2011")])]

#text("typo above exercise 1:")#linebreak()#text(" When one has two norms \\|\\|1 …")

#text("and the formula in exercise 1 is not showed")#linebreak()#text(" S+T: x \\mapsto Sx+Tx")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yucao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-50221")[#strong[#text("yucao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2011")])]

#text("Dear Prof. Tao,")

#text("I’m a little confused with the concept “isomorphic” here. Many books mentioned this concept only in a particular chapter instead of showing a big picture. It seems that “isomorphism” is a kind of “bijection” but it preserves many useful properties (generally what kind of properties?)with respect to the underlying mathematical structure. When talking about the dual space, some people use the concept “isometrically isomorphic”. So how do we know what kind of “bijection” is when we talk about “isomorphism” between two space or mathematical structure?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-50226")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2011")])]

#text("In general, an isomorphism is a morphism ")#mi("\\phi: X \\to Y")#text(" from one space X to another Y which has an inverse ")#mi("\\phi^{-1}: Y \\to X")#text(" which is also a morphism. A morphism is a map which preserves all the structures of the space. For instance, if we are treating X and Y as groups, then a morphism is a group homomorphism; if we are treating them as rings, then a morphism is a ring homomorphism; if we are treating them as topological spaces, then a morphism is a continuous map; if we are treating them as topological groups, then a morphism is a continuous homomorphism, and so forth. Generally speaking, the “category” of spaces one is working in (e.g. vector spaces, groups, metric spaces, topological spaces, etc.) is clear from context; otherwise, one can specify the type of isomorphism being used more explicitly (e.g. Hilbert space isomorphism (i.e. unitary transformation), topological isomorphism (i.e. homeomorphism), etc.).")

#text("At a more abstract level, one can use the language of category theory to understand morphisms, isomorphisms, and related objects (e.g. functors, universal objects, direct sums and direct products) in a unified fashion, though it is probably best to first get a grip on concrete examples of categories (e.g. groups, vector spaces, etc.) before turning to abstract ones.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yucao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-50231")[#strong[#text("yucao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2011")])]

#text("I noticed that when the base field is complex, ")#mi("H^*")#text(" is isomorphic to ")#mi("\\overline{H}")#text(" instead of ")#mi("H")#text(" where ")#mi("H")#text(" is a Hilbert space. Is this because ")#mi("\\phi(\\lambda x)=\\overline{\\lambda}\\phi(x)")#text(" (")#mi("x\\in H")#text(") instead of ")#mi("\\phi(\\lambda x)=\\lambda\\phi(x)")#text("? Why the morphism between two complex vector space has to be defined in this way instead of being defined exactly as the morphism between the real ones, say ")#mi("\\phi(\\lambda x)=\\lambda\\phi(x)")#text("? Is there any problem to do that?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-50232")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2011")])]

#text("A morphism between complex vector spaces is indeed required to obey the homogeneity requirement ")#mi("\\phi(\\lambda x) = \\lambda \\phi(x)")#text(". The canonical identification ")#mi("\\phi")#text(" between ")#mi("H^*")#text(" and ")#mi("H")#text(" provided by the Riesz representation theorem however obeys the condition ")#mi("\\phi(\\lambda x) = \\overline{\\lambda} \\phi(x)")#text(", so is an isomorphism between ")#mi("H^*")#text(" and ")#mi("\\overline{H}")#text(", rather than an isomorphism between ")#mi("H^*")#text(" and ")#mi("H")#text(".")

#text("The spaces ")#mi("\\overline{H}")#text(" and ")#mi("H")#text(" end up being isomorphic also (and so ")#mi("H^*")#text(" is also isomorphic to ")#mi("H")#text("), but the isomorphism is non-unique and non-canonical (it is not the one provided by the Riesz representation theorem).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-50672")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2011")])]

#text("When the underlying space is Hilbert space, is it possible to prove Theorem 3 in a simpler way?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-50674")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2011")])]

#text("Well, Exercise 14 has a simple proof in this case (just set ")#tao-math("\\lambda(y) := \\langle y, \\frac{x}{\\left\\|x\\right\\|} \\rangle", block: false)#text(" if ")#mi("x")#text(" is non-zero, and ")#mi("\\lambda(y) := 0")#text(" otherwise), so one can just insert this in place of Exercise 14 in the current proof of Theorem 3.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-50678")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2011")])]

#text("When considering the “transpose” instead of “adjoint” operator, it seems that one can then use the Cauchy-Schwarz inequality:")

#tao-math("\\langle Ax,Ax\\rangle=\\langle x,A*Ax\\rangle\\leq\\left\\|x\\right\\|^2\\left\\|A\\right\\|\\left\\|A^*\\right\\|", block: false)#text(" which implies that ")#tao-math("\\left\\|A^*\\right\\|\\leq\\left\\|A\\right\\|", block: false)#text(". But as you said in this note, “transpose” and “adjoint” are not quite the same. In the Hilbert space case, is it possible to prove the properties of “adjoint” via “transpose”(e.g. ")#tao-math("\\left\\|A\\right\\|=\\left\\|A^*\\right\\|", block: false)#text(", where ")#mi("A")#text(" is a bounded linear operator on the complex Hilbert space)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-50679")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2011")])]

#text("One can certainly do this if one wishes, since the adjoint and transpose are essentially intertwined by the conjugation map from ")#mi("H")#text(" to ")#mi("\\overline{H}")#text(", which preserves norms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-50916")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2011")])]

#text("I have difficulty in following the proof in proposition 1. How does one get the LHS of the formula after “we rearrange this a bit as”, i.e.")#linebreak()#text(" ")#tao-math("\\sup_{y^{\\prime}\\in Y}\\{\\lambda(y^{\\prime})-\\left\\|y^{\\prime}+v\\right\\|_{X}\\}\\leq \\tilde{\\lambda}(v)", block: false)#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-50917")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2011")])]

#text("I think the left hand side should be")#linebreak()#text(" ")#tao-math("\\sup_{y^{\\prime}\\in Y}\\{\\lambda(y^{\\prime})-\\left\\|y^{\\prime}-v\\right\\|_{X}\\}\\leq \\tilde{\\lambda}(v)", block: false)#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-50920")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2011")])]

#text("Actually, I intended ")#tao-math("- \\lambda(y^{\\prime})  - \\left\\|y^{\\prime}+v\\right\\|_X", block: false)#text(" inside the infimum, although your expression would also work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-50922")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2011")])]

#text("Oops, I didn’t notice the errata of the book. (It should be in page 64 in the book I got, I don’t know why it is in page 56 in the errata webpage.) By ")#tao-math("\\left|\\tilde{\\lambda}(y+v)\\right|\\leq\\left\\|y+v\\right\\|_{X}", block: false)#text(" and ")#mi("\\tilde{\\lambda}(y+v)=\\tilde{\\lambda}(v)+\\lambda (y)")#text(" one gets ")#tao-math("-\\lambda(y)-\\left\\|y+v\\right\\|_{X}\\leq \\tilde{\\lambda}(v)\\leq\\left\\|y+v\\right\\|_{X}-\\lambda(y)", block: false)#text(". Then I think one may take the inf and sup one after another. Why the triangle inequality is needed here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-50923")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2011")])]

#text("Taking an inf and a sup consecutively only gives the desired inequality if one allows ")#mi("y")#text(" and ")#mi("y^{\\prime}")#text(" to vary independently of each other, in which case one needs to use the triangle inequality.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c06a371c768d421221c05b73607e2f5a30ec5077616afb3adef701b6d5a1229-f78db36754ba897be1298b43b5977470d5c7c966508e926cfd5a8e6ba408d43a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nathan Dypus")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-51694")[#strong[#text("Nathan Dypus")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("I wasn’t sure where to write this, but are the notes #5 and lower available anywhere?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-51703")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#link("https://terrytao.wordpress.com/category/teaching/245b-real-analysis/")[#text("https://terrytao.wordpress.com/category/teaching/245b-real-analysis/")]

#text("(click on “previous entries” at the bottom of the page).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-129364")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2012")])]

#text("Concerning Exercise 1:")

#text("(A) Show that all linear transformations from a finite-dimensional space to a normed vector space are continuous.")#linebreak()#text(" (B) Conclude that all norms on a finite-dimensional space are equivalent.")

#text("While I can prove both parts individually, it is not clear to me how (A) can be used to derive (B).")

#text("Suppose V is our finite-dimensional vector space. As stated, no norm is specified for V, so one has to assume that the topology referenced in (A) is the standard Euclidean one.")

#text("Now suppose we are given two norms n, n’ on V and consider the map T: (V,n) —> (V,n’) given by the identity on the underlying set.")

#text("We would like to apply (A) here to conclude that T is continuous, but we can only do so if we assume that the topology on V arising from n is precisely the standard Euclidean topology, But I imagine this assumption is not permissible, since it essentially amounts to assuming (B).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-129407")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2012")])]

#text("In (A), the intent is that the finite-dimensional space is equipped with an arbitrary norm.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7614a2c4691cdcfcd7b12d0ff115050a27f7dba3df90c51443dbb8fab68672c9-0c2aa5e669f13dca4e240098892a37c40183381a9f3b978580a99c8cfa52209b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of André Caldas")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-417009")[#strong[#text("André Caldas")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2014")])]

#text("Dear Professor Tao,")

#text("In the proof of the Geometric Hahn-Banach theorem, you take the “convex cone” generated by ")#mi("B \\cup \\{v\\}")#text(". Wouldn’t it be enough to take the generated “convex set”? Then you could avoid “dilating” the point ")#mi("w")#text(".")

#text("By the way, I didn’t really understood the part:")#linebreak()#text(" “by dilating ")#mi("w")#text(" we may assume it lies on a line segment beween ")#mi("v")#text(" and some ")#mi("b \\in B")#text("“.")

#text("Thank you very much for your time! :-)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7614a2c4691cdcfcd7b12d0ff115050a27f7dba3df90c51443dbb8fab68672c9-0c2aa5e669f13dca4e240098892a37c40183381a9f3b978580a99c8cfa52209b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of André Caldas")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-417010")[#strong[#text("André Caldas")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2014")])]

#text("Sorry, I missed the correct definition of “good pairs”. :-(")#linebreak()#text(" They have to be convex cones to begin with. Otherwise, maximality will not make one the complement of the other.")

#text("Just ignore my last message.")

#text("Thank you!!!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-453402")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2015")])]

#emph[#text("To finish the job, we have to somehow complexify ")#mi("\\tilde \\rho")#text(" to a complex-linear functional ")#mi("\\tilde \\lambda: X \\to {\\Bbb R}")#text(" of norm at most 1")]

#text("I think you mean ")#mi("\\tilde \\lambda: X \\to {\\Bbb C}")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-453406")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2015")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Since ")#mi("\\tilde \\rho")#text(" has norm at most 1, we have ")#tao-math("\\left|\\text{Re} \\tilde \\lambda(x)\\right| \\leq \\left\\|x\\right\\|_X", block: false)#text(" for all ")#mi("x \\in X")#text(". We can amplify this by exploiting phase rotation symmetry, thus ")#tao-math("\\left|\\text{Re} \\tilde \\lambda(e^{i\\theta} x)\\right| \\leq \\left\\|x\\right\\|_X", block: false)#text(" for all ")#mi("\\theta \\in {\\Bbb R}")#text(". Optimising in ")#mi("\\theta")#text(" we see that ")#mi("\\tilde \\lambda")#text(" has norm at most 1, as required.")
]

#text("I don’t understand the last step of the proof of the complex Hahn-Banach Theorem. The goal is to show that ")#tao-math("\\left\\|\\tilde\\lambda\\right\\|_{X^*}=1=\\left\\|\\lambda\\right\\|_{Y^*}", block: false)#text(". How do we see that ")#text(" ")#mi("\\tilde \\lambda")#text(" has norm at most 1")#text(" by ")#text("optimising in ")#mi("\\theta")#text("?")

#tao-math("\\left|\\text{Re} \\tilde \\lambda(e^{i\\theta} x)\\right| \\leq \\left\\|x\\right\\|_X", block: false)#text(" for all ")#mi("\\theta \\in {\\Bbb R}")#text(" follows from ")#tao-math("\\left|\\text{Re} \\tilde \\lambda(x)\\right| \\leq \\left\\|x\\right\\|_X", block: false)#text(" since ")#tao-math("\\left|e^{i\\theta}\\right|=1", block: false)#text(". But how does this imply the desired inequality ")#tao-math("\\left|\\tilde \\lambda(x)\\right| \\leq \\left\\|x\\right\\|_X", block: false)#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-453408")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2015")])]

#tao-math("\\left|\\tilde \\lambda(x)\\right| = \\sup_\\theta \\left|\\text{Re} e^{i\\theta} \\tilde \\lambda( x)\\right| = \\sup_\\theta \\left|\\text{Re} \\tilde \\lambda(e^{i\\theta} x)\\right|", block: false)#text(".")

#text("See also the previous blog post ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")]#text(" for more examples of the amplification trick.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-453407")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2015")])]

#text("Is the completeness assumption also needed in Exercise 14 in order to use the Hahn-Banach Theorem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-453409")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2015")])]

#text("The Hahn-Banach theorem does not require completeness.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-453411")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2015")])]

#text("Ah, I see. Some books (e.g. ")#emph[#text("Banach Algebra Techniques in Operator Theory")]#text(" by Douglas) put the extra assumption of completeness by assuming that ")#mi("X")#text(" is a Banach")#text(" space in the statement. It turns out that it is not needed at all.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-460151")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2015")])]

#text("In this (")#link("http://mathoverflow.net/questions/80567/what-is-an-isomorphism-of-banach-spaces")[#text("http://mathoverflow.net/questions/80567/what-is-an-isomorphism-of-banach-spaces")]#text(") question from MO, there are two definitions for isomorphism between two Banach spaces X and Y. Why in this note, the “isometry” one instead of the “linear homeomorphism” one is preferable?")

#emph[#text("[Both equivalence (i.e. linear homeomorphism) and isometry are used in this set of notes; the choice of reserving the latter rather than the former for “isomorphic” was largely a matter of personal preference. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-460169")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2015")])]

#text("When people talk about dual spaces, say, ")#mi("(L^p)^*=L^q")#text(", it seems that isometry is used instead of linear homeomorphism. Are these two equivalence somehow the “same” when one wants to ")#emph[#text("identify")]#text(" the dual space for some normed space?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-460172")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2015")])]

#text("It depends on the application. In many situations one is willing to lose a constant factor in the estimates and so identifying a space up to linear homeomorphism suffices. (For instance, this is usually what is done to identify the dual of a Sobolev space ")#mi("W^{s,p}")#text(" with ")#mi("W^{-s,p^{\\prime}}")#text(".) But if the stronger notion of an isometric identification is available (as is the case with ")#mi("(L^p)^*")#text(" and ")#mi("L^q")#text("), one may as well take advantage of it.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-460369")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2015")])]

#text("We know from the exercises that ")#mi("c_0(\\mathbb{N})^*=\\ell^1(\\mathbb{N})")#text(" and ")#mi("\\ell^1(\\mathbb{N})^*=\\ell^\\infty(\\mathbb{N})")#text(". Do you have a hint about what is ")#mi("\\ell^\\infty(\\mathbb{N})^*")#text("?")

#emph[#text("[It’s pretty nasty; see Exercise 16. I think there is some description of this space in terms of something like finite measures on the Stone-Cech compactification of the natural numbers, but I forget the details. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-466668")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2016")])]

#text("In the definition of double dual, why can ")#mi("(X^*)^*")#text(" be defined as the algebraic dual of ")#mi("X^*")#text(" instead of the continuous dual (after putting a weak topology on ")#mi("X^*")#text(")?")

#emph[#text("[This is a typo, now corrected. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-466682")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2016")])]

#text("By definition, ")#mi("X^{**}=L(X^*\\to\\mathbb{R})")#text(", the set of all the linear functionals from ")#mi("X^*")#text(" to ")#mi("\\mathbb{R}")#text(", not ")#mi("X^{**}=B(X^*\\to\\mathbb{R})")#text(". In the proof of Theorem 2, what is the definition of ")#mi("\\|\\cdot\\|_{X^{**}}")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-466688")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2016")])]

#text("Ah, I was a little confused since the weak-* topology on ")#mi("X^*")#text(" is not mentioned until much later on notes 11 hence I don’t see what it means by ")#mi("B(X^*\\to \\mathbb{C})")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-466719")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2016")])]

#mi("X^*")#text(" here is given the strong topology induced by the norm ")#mi("\\| \\|_{X^*}")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-473763")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2016")])]

#text("in exercise 6, what do you mean by “strictly larger”? i think they have the same cardinality. or you mean the “properly include”?")

#emph[#text("[I mean larger in the sense of proper set containment, yes. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A: Problem solving strategies | What's new")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-511367")[#strong[#text("245A: Problem solving strategies | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2019")])]

#text("[…] entire proof is basically “Apply Zorn’s lemma in the obvious fashion.” The Hahn-Banach theorem is a well known example of this, but there are many others (e.g. the proof of existence of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0a8d1e4d28fe57b5b45b9db2d311a1b3876207c1f46c710ba79fd12a503a76a-81131da8859f471d3abac6d78c542e07387503703f11ab2fe1f1cdda745ae3e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thibaut")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-512983")[#strong[#text("Thibaut")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2019")])]

#text("Does the axiom-of-choice-avoiding construction in exercise 12 (Hahn-Banach extension theorem in Hilbert-space, putting the Riesz representation theorem to good use) have a generalization to the version of the extension theorem where the sought-for linear functional has to remain below a sub-linear or convex function? (as in exercise 18)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-688466")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2025")])]

#text("There is a typo in the first line: dWhen —> When")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-688484")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2025")])]

#text("Whoops, I missed a similar typo, still near the top of the page:")

#text("In the second sentence of 1. at the top of the page,")

#text("iTnstance—> instance.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-692130")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2026")])]

#text("In Remark 1, you mention that continuity, in the notes, is what makes the dual space meaningful in functional analysis. In some other approaches, one instead works with positive linear functionals on spaces without an a priori topology. Is there a sense in which positivity can serve as an alternative structural constraint to select a well-behaved subclass of the algebraic dual, or is continuity fundamentally indispensable for the types of analysis developed in your notes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/#comment-692135")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2026")])]

#text("I am ")#link("https://claude.ai/share/7e27c6d4-d71f-48f0-823b-4747c7480868")[#text("outsourcing this question to an AI")]#text(".")
]
]
