// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/04/on-classical-solutions-and-singularity-formation-in-incompressible-fluids/
// Converted to Typst by tao2typ: "2026-10-16T11:41:36.897029+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On classical solutions and singularity formation in incompressible fluids", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On classical solutions and singularity formation in incompressible fluids")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/04/on-classical-solutions-and-singularity-formation-in-incompressible-fluids/")[#text("https://terrytao.wordpress.com/2026/10/04/on-classical-solutions-and-singularity-formation-in-incompressible-fluids/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-16 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#emph[#text("[This is a guest post by ")#link("https://www.icmat.es/miembros/dcordoba/")[#text("Diego Córdoba")]#text(" and ")#link("https://www.cunef.edu/en/faculty-and-research/martinez-zoroa-luis/")[#text("Luis Martínez-Zoroa")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("Euler formulated the equations for an inviscid incompressible fluid more than 250 years ago. Published in ")#link("https://scholarlycommons.pacific.edu/euler-works/226/")[#text("his 1757 memoir")]#text(", they belong to the earliest systems of partial differential equations in mathematical physics, following d’Alembert’s work on the wave equation. Understanding the evolution they describe has required the work of many generations of mathematicians. One of the central questions is whether an initially regular fluid flow can develop a singularity in finite time. The recent work on Euler and Navier–Stokes obtained with the aid of large language models has brought renewed attention to this question. These exciting developments build on decades of mathematical research, including works from recent years, when the field has continued to be specially active. In this post we describe some contributions to that body of knowledge, including our own. We will go over some of that recent mathematical literature, and discuss the ideas of constructing blow-ups through a cascade of vortex layers.")

#text("Partial differential equations provide a common language for problems ranging from wave propagation and fluid motion to geometry and general relativity. For an evolution equation, the Cauchy problem asks us to determine the future from prescribed initial data. A local existence theorem gives a solution for a short time; the next question is whether it continues for all time or develops a singularity at a finite time. This distinction between global existence and finite-time blow-up is already visible in the elementary Riccati equation")

#align(center)[#tao-fit-display[#mitex("y^{\\prime}(t) = y(t)^2, \\quad y(0) = y_0 > 0, \\quad y(t) = \\frac{y_0}{1 - y_0 t}.")]]

#text("The solution starts from a finite value and remains smooth until ")#mi("{T = 1/y_0}")#text(", when it becomes unbounded. The quadratic nonlinearity in three-dimensional Euler suggests a similar possibility, but the fluid problem also involves transport, geometry and a pressure determined nonlocally by the entire flow. The challenge is to understand whether the full equation can sustain the amplification suggested by this simple ODE.")

#text("The central aim of our research has been to construct classical solutions of incompressible fluid equations that develop singularities in finite time, starting within a regime of local existence and uniqueness. We want the initial data to determine a unique regular evolution for a positive interval of time, followed by a singularity at a positive, finite time. In the smooth-data setting, this means a solution that is initially smooth and stays smooth until the singular time. More generally, the local theory also applies to classical solutions with finitely many derivatives. This programme includes the incompressible porous media (IPM) equation, the generalized surface quasi-geostrophic (gSQG) equations, the Boussinesq system and the two-dimensional non-homogeneous Euler equations, with particular emphasis on the three-dimensional incompressible Euler equations.")

#text("Our approach developed through increasingly demanding constructions. We first sought mechanisms for rapid growth of regularity norms, then used them to produce instantaneous loss of regularity in critical and supercritical spaces. We subsequently arranged for singularity formation after an interval during which the local theory guarantees regular evolution. The distinction between these phenomena is an important part of the story.")

#strong[#text("Classical solutions and local existence")]

#text("The incompressible Euler equations are")

#align(center)[#tao-fit-display[#mitex("\\partial_t u + (u \\cdot \\nabla) u + \\nabla p = f, \\quad \\nabla \\cdot u = 0,")]]

#text("where ")#mi("{u}")#text(" is velocity, ")#mi("{p}")#text(" is pressure, and ")#mi("{f}")#text(" is an external force, which may be zero. The condition ")#mi("{\\nabla \\cdot u = 0}")#text(" expresses incompressibility. A classical solution has enough differentiability for the equation to hold pointwise. This does not require infinitely many derivatives, nor does local differentiability imply that every global regularity norm is finite.")

#text("For unforced Euler in dimension ")#mi("{d = 2,3}")#text(", the classical local theory gives existence, uniqueness and persistence of regularity for initial velocity in ")#mi("{C^{k,\\alpha}}")#text(", with ")#mi("{k \\geq 1}")#text(" and ")#mi("{0 < \\alpha < 1}")#text(", together with suitable control at infinity, such as finite energy. Here ")#mi("{C^{k,\\alpha}}")#text(" means that derivatives up to order ")#mi("{k}")#text(" are bounded and continuous, and the derivatives of order ")#mi("{k}")#text(" are Hölder continuous with exponent ")#mi("{\\alpha}")#text(". In Sobolev spaces, which measure square-integrable derivatives, local well-posedness, including continuous dependence in the same norm, holds in")

#align(center)[#tao-fit-display[#mitex("H^s(\\mathbb{R}^d), \\quad s > 1 + \\frac{d}{2}.")]]

#text("The properties relevant here are existence, uniqueness and persistence of regularity. With a time-dependent force, a sufficient assumption in the finite-energy Hölder setting is ")#mi("{f \\in L^1_{\\mathrm{loc}}([0,\\infty); C^{k,\\alpha} \\cap L^2)}")#text("; in the Sobolev setting it is ")#mi("{f \\in L^1_{\\mathrm{loc}}([0,\\infty); H^s)}")#text(". The notation ")#mi("{L^1}")#text(" in time means that the indicated spatial norm of the force is integrable on every finite time interval under consideration.")

#text("Higher regularity is propagated as long as the solution remains controlled in the continuation class and the force has the corresponding regularity. For unforced Euler in two dimensions, these regular solutions exist globally. In three dimensions, the possibility of finite-time breakdown is tied to vortex stretching.")

#text("Writing ")#mi("{\\omega = \\nabla \\times u}")#text(", the three-dimensional equation becomes")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\omega + (u \\cdot \\nabla) \\omega = (\\omega \\cdot \\nabla) u + \\nabla \\times f.")]]

#text("Vorticity measures local rotation. The velocity transports it and, through the stretching term ")#mi("{(\\omega \\cdot \\nabla) u}")#text(", can also amplify it. This deformation is generated by the vorticity itself through the nonlocal Biot–Savart law. This is the feedback that makes the Riccati analogy suggestive. A singularity construction must organize it while retaining control of transport and of the interactions between different regions.")

#text("For unforced three-dimensional Euler, the ")#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/")[#text("Beale–Kato–Majda continuation criterion")]#text(" states that breakdown of a sufficiently regular solution at a finite time ")#mi("{T}")#text(" requires")

#align(center)[#tao-fit-display[#tao-math("\\int_0^T \\left\\| \\omega(t) \\right\\|_{L^\\infty} \\, dt = \\infty.", block: true)]]

#text("The same criterion has a forced version, provided the force remains regular in the appropriate time-integrated sense. For a velocity in ")#mi("{H^{s+1}(\\mathbb{R}^3)}")#text(" with ")#mi("{s > 3/2}")#text(", one convenient sufficient assumption is")

#align(center)[#tao-fit-display[#mitex("\\nabla \\times f \\in L^1(0,T; H^s(\\mathbb{R}^3)), \\quad f \\in L^1(0,T; L^2(\\mathbb{R}^3)).")]]

#text("The second condition controls low frequencies. After absorbing the gradient part of the force into the pressure, these assumptions control the effective force in ")#mi("{L^1(0,T; H^{s+1})}")#text(", and the usual BKM estimates apply. Thus, the threshold is ")#mi("{s > 3/2}")#text(" for the curl of the force, corresponding to one additional derivative on velocity. A similar criterion applies in the setting of Holder spaces. The point is to rule out a breakdown caused simply by an inadmissible force. Our goal is to realize the required vorticity growth dynamically from a local well-posedness regime.")

#strong[#text("Instantaneous loss of regularity")]

#text("A first warning is that local regularity propagation can fail at the borderline of the classical theory. The assumptions above cannot simply be replaced by their endpoints. ")#link("https://arxiv.org/abs/1307.7090")[#text("Bourgain and Li")]#text(" established strong ill-posedness at the critical Sobolev regularity ")#mi("{H^{1+d/2}}")#text(": ")#mi("{H^2}")#text(" for velocity in two dimensions and ")#mi("{H^{5/2}}")#text(" in three. Their constructions exhibit instantaneous loss of the critical norm. They also proved ")#link("https://arxiv.org/abs/1405.2847")[#text("instant loss of regularity in the integer spaces ")#mi("{C^k}")]#text(", ")#mi("{k \\geq 1}")#text(". ")#link("https://arxiv.org/abs/1405.2478")[#text("Elgindi and Masmoudi")]#text(" independently developed another approach to ill-posedness in these integer regularity classes.")

#text("These results show that the borderline spaces need not support the regularity propagation available immediately above them. Having one continuous derivative does not provide the same control as a first derivative that is Hölder continuous with a positive exponent. For higher integer ")#mi("{k}")#text(", instantaneous loss of the ")#mi("{C^k}")#text(" norm can also coexist with classical differentiability at lower orders.")

#text("An especially striking phenomenon is an instantaneous ")#emph[#text("gap")]#text(" loss of Sobolev regularity. In ")#link("https://arxiv.org/abs/2210.17458v3")[#text("our work with Wojciech S. Ożański")]#text(", we construct global classical solutions of the two-dimensional Euler equations with finite energy for which, given any ")#mi("{0 < s < 1}")#text(",")

#align(center)[#tao-fit-display[#mitex("\\omega_0 \\in H^s(\\mathbb{R}^2), \\quad \\omega(t) \\notin H^{s^{\\prime}}(\\mathbb{R}^2)")]]

#text("for every ")#mi("{t > 0}")#text(" and every ")#mi("{s^{\\prime} > s(2-s)/(2-s^2)}")#text(".")

#text("The number on the right is strictly smaller than ")#mi("{s}")#text(". Thus, the solution does not merely leave its initial Sobolev space: it immediately loses an entire positive interval of regularity. In velocity variables, the initial regularity is ")#mi("{H^{1+s}}")#text(", below the critical space ")#mi("{H^2}")#text(". This is a result in the supercritical Sobolev regime.")

#text("There is no contradiction between this loss of a global norm and the persistence of local classical differentiability. Definition 3 in that paper makes the distinction precise. On each finite time interval, the vorticity belongs to ")#mi("{L^\\infty_t(L^1 \\cap L^p)}")#text(" for some ")#mi("{p > 2}")#text(" and is ")#mi("{C^1}")#text(" in space and time on every compact cylinder. It satisfies")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\omega + u[\\omega] \\cdot \\nabla \\omega = 0")]]

#text("pointwise, with the prescribed initial data. The constructed solution is unique within this specified class. Its local differentiability persists even though its global Sobolev norms become infinite.")

#text("The proof first constructs smooth solutions with arbitrarily large Sobolev norm growth. A nearly radial background rotates an oscillatory perturbation at different rates at different radii, creating finer scales. Carefully rescaled copies of these building blocks are then placed increasingly far apart. A gluing argument controls their nonlocal interactions and produces one exact solution with instantaneous gap loss. Spatial separation permits local classical regularity to coexist with the failure of global Sobolev control.")

#text("We have also investigated instantaneous loss of regularity for SQG and its generalizations, establishing strong ill-posedness in ")#link("https://arxiv.org/abs/2107.07463")[#text("integer ")#mi("{C^k}")#text(" and Sobolev spaces")]#text(", ")#link("https://arxiv.org/abs/2207.14385")[#text("Hölder spaces")]#text(", and, jointly with José Antonio Lucas-Manchón, ")#link("https://arxiv.org/abs/2502.06357")[#text("supercritical Sobolev spaces for gSQG")]#text(". These investigations include the construction of ")#link("https://arxiv.org/abs/2303.07178")[#text("global unique solutions exhibiting instantaneous loss of regularity in the presence of supercritical fractional diffusion")]#text(", and, with Wojciech S. Ożański, ")#link("https://arxiv.org/abs/2409.18900")[#text("classical SQG solutions whose Sobolev regularity decreases continuously from the initial time")]#text(". For IPM, our joint work with Roberta Bianchini establishes ")#link("https://arxiv.org/abs/2410.01297")[#text("strong ill-posedness in ")#mi("{H^2}")#text(" for arbitrarily small perturbations of a linearly stable stratification")]#text(", showing how the nonlinear dynamics can overcome the stabilizing effect of the background profile.")

#text("These examples make clear that instantaneous loss of regularity concerns failure of propagation in a chosen function space and can coexist with classical differentiability. The next challenge is to construct a singularity after a positive lifespan during which the relevant regularity is guaranteed to persist.")

#strong[#text("Singularity formation after regular evolution")]

#link("https://arxiv.org/abs/1904.04795")[#text("Elgindi’s construction")]#text(" was a breakthrough in precisely this direction. It produced finite-time singularities for three-dimensional Euler in ")#mi("{C^{1,\\alpha}}")#text(", for sufficiently small positive ")#mi("{\\alpha}")#text(", using axisymmetric flows without swirl. The original exact self-similar profiles had infinite energy. ")#link("https://arxiv.org/abs/1910.14071")[#text("Elgindi, Ghoul and Masmoudi")]#text(" subsequently used stability and localization to construct finite-energy singular solutions without forcing.")

#text("The initial velocity in these constructions belongs to a class in which the local theory guarantees a unique regular evolution. It is ")#mi("{C^{1,\\alpha}}")#text(" but not smooth everywhere. Axisymmetry means invariance under rotations around an axis, and “without swirl” means that the velocity has no component in the angular direction. Smooth flows in this class admit a global regularity theory under the usual decay assumptions, so the distinction between finite Hölder regularity and full smoothness is essential.")

#text("Recent work has clarified how close one can come to the boundary of this global theory. For the homogeneous, unforced axisymmetric Euler equations without swirl, global regularity is known for ")#mi("{C^{1,\\alpha}}")#text(" initial velocity with ")#mi("{\\alpha > 1/3}")#text(", under the corresponding finite-energy and decay hypotheses. Three recent approaches construct singularities below this threshold, for ")#mi("{0 < \\alpha < 1/3}")#text(". ")#link("https://arxiv.org/abs/2603.10945")[#text("Shkoller’s preprint")]#text(" uses a Lagrangian clock-and-driver framework, coupling the collapse of a flow Jacobian to the compressive axial strain. ")#link("https://arxiv.org/abs/2605.15130")[#text("Chen’s work")]#text(" constructs asymptotically self-similar blow-up from finite-energy initial velocity, using ")#link("https://arxiv.org/abs/2605.15149")[#text("computer-assisted estimates for a one-dimensional profile")]#text(" and an analytical construction and stability argument for the three-dimensional flow. ")#link("https://arxiv.org/abs/2605.19716")[#text("Shao, Wei, Zhang and Zhang")]#text(" construct exact self-similar profiles with infinite energy and prove stability after controlling finitely many unstable directions. Their current manuscript also uses this stability to localize the profiles and obtain finite-energy, asymptotically self-similar singularities. These different methods reveal a sharp regularity threshold within a class that still has classical local existence and uniqueness.")

#link("https://arxiv.org/abs/2310.19780")[#text("Elgindi and Pasqualotto")]#text(" constructed singularities for Boussinesq and axisymmetric Euler with swirl, exploiting instabilities related to Rayleigh–Bénard convection and Taylor–Couette flow. Their argument uses a self-similar framework and includes a computer-assisted step in the proof of invertibility of a linear operator.")

#text("There has also been major progress for smooth initial data in domains with a boundary. Following the numerical scenario of Luo and Hou, ")#link("https://arxiv.org/abs/2210.07191")[#text("Chen and Hou")]#text(" combined analysis with ")#link("https://arxiv.org/abs/2305.05660")[#text("rigorous numerics")]#text(" to establish nearly self-similar finite-time blow-up in that setting.")

#text("Our work with Fan Zheng introduced a different route to singularity formation in the whole space: ")#link("https://arxiv.org/abs/2308.12197")[#text("non-self-similar blow-up for unforced Euler")]#text(", with finite-energy velocity in ")#mi("{C^{1,\\alpha}}")#text(" for small positive ")#mi("{\\alpha}")#text(", smooth away from the origin. The solution is assembled from interacting vorticity regions at successively smaller scales, organizing the singularity through a hierarchy of amplification events.")

#strong[#text("A cascade of vortex layers")]

#text("The basic idea is to arrange vorticity on a sequence of widely separated spatial scales. An outer layer generates a deformation that amplifies a more concentrated inner layer. Once amplified, that inner layer provides a stronger deformation for the next one. The time required for each stage decreases, and the sum of these time intervals is finite. In this way, infinitely many amplification stages can accumulate at a single finite time, while the solution remains regular on every shorter time interval.")

#text("Scale separation makes this interaction tractable. Across the small support of an inner layer, the velocity generated by the outer layers can be approximated by a simpler field. In the Euler constructions, this field has a hyperbolic structure, stretching one direction and compressing another. Aligning the vorticity with the stretching direction produces amplification.")

#text("The hard part is to realize this process in the full equation. The inner layers also affect the outer ones; each layer interacts with itself; and transport changes the geometry and frequency of the oscillations. We choose the layers so that crucial self-interactions cancel at leading order, while scale separation and oscillatory cancellation control the remaining interactions.")

#text("In the unforced construction with Zheng, we analyze finite collections of vorticity regions and pass to a limit of exact Euler evolutions. The full infinite hierarchy is already present in the initial data; the cascade describes the successive amplification of its layers. The construction is compatible with ")#mi("{C^{1,\\alpha}}")#text(" regularity and finite energy, though not with smoothness at the point where the scales accumulate.")

#text("The forced version gives further flexibility. We construct an approximate evolution and define the external force through its residual. The main difficulty is to arrange that this force remains in the required regularity class up to the singular time, even as the solution itself loses regularity. This requires precise control of the cancellations and of the errors at every stage of the cascade.")

#text("In ")#link("https://arxiv.org/abs/2309.08495")[#text("our forced Euler construction")]#text(", the velocity lies in ")#mi("{C^{3,1/2} \\cap L^2}")#text(" before blow-up, and the force remains uniformly controlled in ")#mi("{C^{1,1/2-\\varepsilon} \\cap L^2}")#text(". The flows are non-axisymmetric. Thus the method reaches considerably higher velocity regularity while retaining a force in a classical local well-posedness class.")

#text("This is a useful way to view the programme: construct an amplification mechanism, then improve the accuracy with which it can be implemented in the equation. The quality of the error estimates determines the regularity of the force.")

#strong[#text("Adding dissipation")]

#text("A particularly important test of the method is whether it survives the addition of dissipation. With Fan Zheng, we addressed this for the fractional Navier–Stokes equations")

#align(center)[#tao-fit-display[#mitex("\\partial_t u + (u \\cdot \\nabla) u + \\nabla p + \\nu (-\\Delta)^{\\alpha/2} u = f, \\quad \\nabla \\cdot u = 0,")]]

#text("where ")#mi("{\\nu > 0}")#text(". Ordinary Navier–Stokes corresponds to ")#mi("{\\alpha = 2}")#text("; the range ")#mi("{0 < \\alpha < 2}")#text(" is hypodissipative. Classical results of J.-L. Lions 1969 establish global regularity when ")#mi("{\\alpha \\geq 5/2}")#text(", starting from smooth, divergence-free initial data with suitable decay. ")#link("https://arxiv.org/abs/0906.3070")[#text("Tao subsequently extended this theory")]#text(" slightly into the supercritical regime, proving that global regularity persists when the critical dissipation is weakened by a suitable logarithmic factor.")

#text("Our ")#link("https://arxiv.org/abs/2407.06776v2")[#text("theorem")]#text(" constructs finite-time singularities for")

#align(center)[#tao-fit-display[#mitex("0 < \\alpha < \\alpha_0, \\quad \\alpha_0 = \\frac{22 - 8\\sqrt{7}}{9} \\approx 0.093,")]]

#text("with force")

#align(center)[#tao-fit-display[#mitex("f \\in L^1_t C^{1,\\varepsilon}_x \\cap L^\\infty_t L^2_x")]]

#text("for some ")#mi("{\\varepsilon > 0}")#text(". The velocity is smooth in space before the singular time, and both its speed and its energy remain bounded. Nevertheless, after normalizing the singular time to 1,")

#align(center)[#tao-fit-display[#tao-math("\\lim_{t \\uparrow 1} \\int_0^t \\left\\| \\nabla u(s) \\right\\|_{L^\\infty} \\, ds = \\infty.", block: true)]]

#text("The force has the time integrability and spatial regularity required by the local theory, so the singularity is not caused by a loss of admissibility of the forcing.")

#text("Dissipation cannot simply be added to the old construction and ignored. For an oscillation at frequency ")#mi("{\\lambda}")#text(", the fractional dissipation term has size comparable to ")#mi("{\\nu \\lambda^\\alpha}")#text(" times its amplitude, so its damping time scale is approximately ")#mi("{(\\nu \\lambda^\\alpha)^{-1}}")#text(". The strain generated by the preceding layer has to overcome this damping. Increasing the frequency helps some approximation estimates, but simultaneously strengthens dissipation. The parameters must satisfy both requirements.")

#text("Section 1.2 of the paper explains why the earlier Euler choice of frequency separation fails in the presence of any positive-order diffusion. We have to redesign the relation between amplitudes, frequencies, support sizes and activation times. We also need an accurate approximation of the fractional Laplacian that preserves the structure used to analyze each layer. Cancellations in the nonlinear self-interactions remain essential to keeping the force in the required class.")

#text("This theorem shows that the cascade can survive a mechanism that actively suppresses the growth it is designed to create. Our result concerns small fractional powers of the Laplacian, not ordinary Navier–Stokes. The gap between this range of ")#mi("{\\alpha}")#text(" and ")#mi("{\\alpha = 2}")#text(" is substantial; the ordinary Laplacian cannot be reached by simply rescaling this construction.")

#strong[#text("Smooth forcing and recent developments")]

#text("The same programme can be applied to other incompressible models. ")#link("https://arxiv.org/abs/2410.22920v3")[#text("Our IPM construction")]#text(" starts from smooth, compactly supported initial density and produces finite-time blow-up with a source uniformly smooth in space. The solution remains smooth before the singular time, while its ")#mi("{C^1}")#text(" norm tends to infinity as that time is approached.")

#text("Keeping the source uniformly ")#mi("{C^\\infty}")#text(" in space requires increasingly accurate approximations of the velocity. As we introduce layers with higher frequencies, we use approximations of progressively higher order, with the approximation order tending to infinity along the cascade. In this sense, we need an approximation “of infinite order” to control the errors absorbed by the source in every spatial ")#mi("{C^k}")#text(" norm. The assumption ")#mi("{F \\in L^\\infty_t C^\\infty_x}")#text(" was chosen to simplify the construction. As noted in the paper, smoother time cutoffs and a more careful analysis of the errors give ")#mi("{C^1_t C^\\infty_x}")#text(" regularity with additional work; we also anticipated that full smoothness in both space and time should be attainable.")

#text("Further developments include our ")#link("https://arxiv.org/abs/2505.20988")[#text("Boussinesq construction with Andrés Laín-Sanclemente")]#text(", based on multi-layer degenerate pendula, and its extension to ")#link("https://arxiv.org/abs/2605.29866")[#text("variable-density Euler with source terms")]#text(". Our ")#link("https://arxiv.org/abs/2608.17192")[#text("work with Óscar Domínguez and José Antonio Lucas-Manchón on forced generalized SQG")]#text(" establishes finite-time blow-up in a Sobolev local well-posedness regime, for the parameter range ")#mi("{0 < \\gamma < 1}")#text(".")

#text("Recent work of Alpöge, Buckmaster and Coiculescu ")#link("https://arxiv.org/abs/2609.16470")[#text("extends the IPM construction")]#text(" to a source smooth in both space and time on the torus. The ")#link("https://cims.nyu.edu/~tristanb/boussinesq.pdf")[#text("Boussinesq")]#text(" and ")#link("https://cims.nyu.edu/~tristanb/euler.pdf")[#text("Euler")]#text(" manuscripts of Alpöge and Buckmaster likewise state blow-up from smooth initial data with smooth forcing. These works explicitly build on amplification through successive layers. Their additional regularity requirement is to control every mixed space-time derivative of the forcing uniformly through the singular time.")

#link("https://openai.com/index/navier-stokes-solution/")[#text("OpenAI’s September 8, 2026 announcement")]#text(" concerns two separate claims: blow-up for ordinary Navier–Stokes with smooth forcing, and blow-up for unforced Euler from smooth initial data. The first, if verified under the stated hypotheses, would establish an allowed breakdown alternative in the ")#link("https://www.claymath.org/wp-content/uploads/2022/06/navierstokes.pdf")[#text("Millennium Problem formulation")]#text(". It is distinct from unforced Navier–Stokes blow-up. At this moment we are not in a position to say anything substantive about a comparison between OpenAI’s constructions and our cascade methods. Assessing the announced proofs and their relationship to earlier work requires a detailed mathematical analysis.")

#text("The cascade leaves us with concrete mathematical questions. Which geometric features and cancellations let one layer amplify the next while controlling the full nonlinear interactions? How do they determine the regularity attainable for the force, and which parts of the mechanism survive stronger dissipation? Its application to several incompressible models gives us a way to investigate these questions within regimes of classical local existence.")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fef18b64e3c3e30d972da5f4bd52acf323c7757b2e7ab37bbeac98935500bad1-ef0595a9eeaf8f279cb56b36ecaf96415d9eb80a862862d9104f9506ad946a3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of starstruckmiracle2bb5c19aa5")]], [#link("https://terrytao.wordpress.com/2026/10/04/on-classical-solutions-and-singularity-formation-in-incompressible-fluids/comment-page-1/#comment-696784")[#strong[#text("starstruckmiracle2bb5c19aa5")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("muchas gracias por poner contexto y explicar lo que está en boca de todos, pero de lo que hasta este momento no comprendía el alcance. Ahora al menos tengo una base cierta.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/04/on-classical-solutions-and-singularity-formation-in-incompressible-fluids/comment-page-1/#comment-696789")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("you guys are heroes whose work was stolen by not one but two malicious forces.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/04/on-classical-solutions-and-singularity-formation-in-incompressible-fluids/comment-page-1/#comment-696821")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("All this shows is that a smooth external force was the wrong criteria and people should have been asking about a real analytic external force instead for the Euler equations. External forces in the real world are real analytic and real analyticity would disqualify these unphysical smooth but not analytic external forces constructed by Cordoba and Martinez-Zoroa.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75466c58a1d44368f62680173e0db2daac71b4602786cab257de2d23ab498b37-88faf38c0286a8da84d461505a72f2f41337b413cb821b50265c4232d0ec2961.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brianbeverly1")]], [#link("https://terrytao.wordpress.com/2026/10/04/on-classical-solutions-and-singularity-formation-in-incompressible-fluids/comment-page-1/#comment-696833")[#strong[#text("brianbeverly1")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("When AI claimed to have proven finite-time blowup, I hoped the little insights would help me understand it better, but instead it is somehow worse than the overly formal, impenetrable Bourbaki-style proofs. But it makes sense that the humans who wrote the stolen proof aren’t eager to help flesh it out.")

#text("I have always been bothered that the physics community overlooks the Navier-Stokes equations in favor of other differential equations.")

#text("The solutions to Einstein’s field equations are nonlinear, like the advective nonlinear term of Navier-Stokes. The insight from GR is that inertial mass, as in F=mA, is equivalent to gravitational mass from the Gauss’ law-style gravitational force F=GmM/R^2. Mass and energy density determine the spacetime curvature.")

#text("In quantum theory, forces are described with Lagrangians, and the Euler-Lagrange equation generates the system’s equations of motion. The theory is built on continuous fields, like in general relativity.")

#text("In quantum theory, linear partial differential equations like the Schrödinger and Dirac equations are used. Still, the collapse of the wavefunction is not modeled linearly because measurement-induced entropy grows nonlinearly, or other universes of something. Before a measurement, the position uncertainty spreads out. However, we should still think of the particle as being everywhere at once within the probability density until measurement; that mass density is a lot like the squared wavefunction’s probability density. The mass is constant, but the mass density changes, and those changes evolve linearly but change nonlinearly during a measurement. The probability current used in quantum mechanics satisfies the continuity equation. The Higgs mechanism in QFT yields an equation equivalent to F = mA. Quantum mechanics also has complications, such as its nonlocal nature.")

#text("Physics has problems with singularities and how to handle them. I hope someone will prove that the Navier-Stokes equations do not contain singularities, or, if they do, then handle them elegantly.")

#text("Few partial differential equations of the form F = mA balance linear and nonlinear evolution. I have a hunch that the Navier-Stokes equations are incredibly important, and I am glad Tao and other *checks notes* um… mathematicians haven’t given up on them, even after the barbarians plundered the temple.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/04/on-classical-solutions-and-singularity-formation-in-incompressible-fluids/comment-page-1/#comment-696846")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("Mathematicians studying the Navier-Stokes equations say that the AI solution doesn’t help them because it is physically unrealistic.")

#link("https://www.scientificamerican.com/article/did-openai-solve-the-wrong-navier-stokes-problem/")[#text("https://www.scientificamerican.com/article/did-openai-solve-the-wrong-navier-stokes-problem/")]

#text("‘Generated by an internal large language model (LLM), OpenAI’s proof relies on an approach that many experts find unnatural. It solves a variant of the problem that mathematicians say is disconnected from reality and thus less interesting. In a sense, the LLM found and exploited a loophole in the framing of the question.")

#text("“The most important problem is unsolved,” says Luis Silvestre, a mathematician at the University of Chicago. “The Clay problem is settled, but the main problem for the Navier-Stokes equations is not.”’")
]
]
