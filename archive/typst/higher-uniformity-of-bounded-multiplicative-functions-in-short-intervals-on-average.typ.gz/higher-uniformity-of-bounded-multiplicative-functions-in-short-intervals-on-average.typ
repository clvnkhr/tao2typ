// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/07/30/higher-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/
// Converted to Typst by tao2typ: "2026-10-14T11:00:10.831036+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Higher uniformity of bounded multiplicative functions in short intervals on average", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Higher uniformity of bounded multiplicative functions in short intervals on average")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 July 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/07/30/higher-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/")[#text("https://terrytao.wordpress.com/2020/07/30/higher-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://en.wikipedia.org/wiki/Kaisa_Matom%C3%A4ki")[#text("Kaisa Matomäki")]#text(", ")#link("https://en.wikipedia.org/wiki/Maksym_Radziwill")[#text("Maksym Radziwill")]#text(", ")#link("https://www.maths.ox.ac.uk/people/joni.teravainen")[#text("Joni Teräväinen")]#text(", ")#link("https://en.wikipedia.org/wiki/Tamar_Ziegler")[#text("Tamar Ziegler")]#text(" and I have uploaded to the arXiv our paper ")#link("https://arxiv.org/abs/2007.15644")[#text("Higher uniformity of bounded multiplicative functions in short intervals on average")]#text(". This paper (which originated from a working group at an ")#link("https://aimath.org/workshops/upcoming/sarnakconjecture/")[#text("AIM workshop on Sarnak’s conjecture")]#text(") focuses on the ")#emph[#text("local Fourier uniformity conjecture")]#text(" for bounded multiplicative functions such as the ")#link("https://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(" ")#mi("{\\lambda}")#text(". One form of this conjecture is the assertion that ")#metadata(none) <tao-49612e3d865a70661f99>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\int_0^X \\left\\| \\lambda \\right\\|_{U^k([x,x+H])}\\ dx = o(X)", block: true)]]

#text(" ")#text(" as ")#mi("{X \\rightarrow \\infty}")#text(" for any fixed ")#mi("{k \\geq 0}")#text(" and any ")#mi("{H = H(X) \\leq X}")#text(" that goes to infinity as ")#mi("{X \\rightarrow \\infty}")#text(", where ")#mi("{U^k([x,x+H])}")#text(" is the (normalized) ")#link("https://en.wikipedia.org/wiki/Gowers_norm")[#text("Gowers uniformity norm")]#text(". Among other things this conjecture implies (logarithmically averaged version of) the Chowla and Sarnak conjectures for the Liouville function (or the Möbius function), see ")#link("https://terrytao.wordpress.com/2016/05/16/equivalence-of-the-logarithmically-averaged-chowla-and-sarnak-conjectures/")[#text("this previous blog post")]#text(".")

#text("The conjecture gets more difficult as ")#mi("{k}")#text(" increases, and also becomes more difficult the more slowly ")#mi("{H}")#text(" grows with ")#mi("{X}")#text(". The ")#mi("{k=0}")#text(" conjecture is equivalent to the assertion")

#align(center)[#tao-fit-display[#mitex("\\int_0^X |\\sum_{x \\leq n \\leq x+H} \\lambda(n)| \\ dx = o(HX)")]]

#text("which was proven (for arbitrarily slowly growing ")#mi("{H}")#text(") in a landmark paper of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3488742")[#text("Matomäki and Radziwill")]#text(", discussed for instance in ")#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/")[#text("this blog post")]#text(".")

#text("For ")#mi("{k=1}")#text(", the conjecture is equivalent to the assertion ")#metadata(none) <tao-1dd14ffc3c3045741a5e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\int_0^X \\sup_\\alpha \\left|\\sum_{x \\leq n \\leq x+H} \\lambda(n) e(-\\alpha n)\\right| \\ dx = o(HX).", block: true)]]

#text(" ")#text(" This remains open for sufficiently slowly growing ")#mi("{H}")#text(" (and it would be a major breakthrough in particular if one could obtain this bound for ")#mi("{H}")#text(" as small as ")#mi("{\\log^\\varepsilon X}")#text(" for any fixed ")#mi("{\\varepsilon>0}")#text(", particularly if applicable to more general bounded multiplicative functions than ")#mi("{\\lambda}")#text(", as this would have new implications for a generalization of the Chowla conjecture known as the Elliott conjecture). Recently, ")#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/")[#text("Kaisa, Maks and myself were able to establish this conjecture")]#text(" in the range ")#mi("{H \\geq X^\\varepsilon}")#text(" (in fact we have since worked out in the current paper that we can get ")#mi("{H}")#text(" as small as ")#mi("{\\exp(\\log^{5/8+\\varepsilon} X)}")#text("). In our current paper we establish Fourier uniformity conjecture for higher ")#mi("{k}")#text(" for the same range of ")#mi("{H}")#text(". This in particular implies local orthogonality to polynomial phases,")

#metadata(none) <tao-4180890d013f984ddca3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\int_0^X \\sup_{P \\in \\mathrm{Poly}_{\\leq k-1}({\\bf R} \\rightarrow {\\bf R})} \\left|\\sum_{x \\leq n \\leq x+H} \\lambda(n) e(-P(n))\\right| \\ dx = o(HX)", block: true)]]

#text("where ")#mi("{\\mathrm{Poly}_{\\leq k-1}({\\bf R} \\rightarrow {\\bf R})}")#text(" denotes the polynomials of degree at most ")#mi("{k-1}")#text(", but the full conjecture is a bit stronger than this, establishing the more general statement")

#metadata(none) <tao-1efd6b157f9532aaa699>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\int_0^X \\sup_{g \\in \\mathrm{Poly}({\\bf R} \\rightarrow G)} \\left|\\sum_{x \\leq n \\leq x+H} \\lambda(n) \\overline{F}(g(n) \\Gamma)\\right| \\ dx = o(HX)", block: true)]]

#text("for any degree ")#mi("{k}")#text(" filtered nilmanifold ")#mi("{G/\\Gamma}")#text(" and Lipschitz function ")#mi("{F: G/\\Gamma \\rightarrow {\\bf C}}")#text(", where ")#mi("{g}")#text(" now ranges over polynomial maps from ")#mi("{{\\bf R}}")#text(" to ")#mi("{G}")#text(". The method of proof follows the same general strategy as in ")#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/")[#text("the previous paper with Kaisa and Maks")]#text(". (The equivalence of ")#link(<tao-1efd6b157f9532aaa699>)[#text("(4)")]#text(" and ")#link(<tao-49612e3d865a70661f99>)[#text("(1)")]#text(" follows from the inverse conjecture for the Gowers norms, proven in ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("this paper")]#text(".) We quickly sketch first the proof of ")#link(<tao-4180890d013f984ddca3>)[#text("(3)")]#text(", using very informal language to avoid many technicalities regarding the precise quantitative form of various estimates. If the estimate ")#link(<tao-4180890d013f984ddca3>)[#text("(3)")]#text(" fails, then we have the correlation estimate")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{x \\leq n \\leq x+H} \\lambda(n) e(-P_x(n))\\right| \\gg H", block: true)]]

#text("for many ")#mi("{x \\sim X}")#text(" and some polynomial ")#mi("{P_x}")#text(" depending on ")#mi("{x}")#text(". The difficulty here is to understand how ")#mi("{P_x}")#text(" can depend on ")#mi("{x}")#text(". We write the above correlation estimate more suggestively as")

#align(center)[#tao-fit-display[#mitex("\\lambda(n) \\sim_{[x,x+H]} e(P_x(n)).")]]

#text("Because of the multiplicativity ")#mi("{\\lambda(np) = -\\lambda(p)}")#text(" at small primes ")#mi("{p}")#text(", one expects to have a relation of the form")

#metadata(none) <tao-dfc36f8d5ef7545d99d1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("e(P_{x^{\\prime}}(p^{\\prime}n)) \\sim_{[x/p,x/p+H/p]} e(P_x(pn))")]]

#text("for many ")#mi("{x,x^{\\prime}}")#text(" for which ")#mi("{x/p \\approx x^{\\prime}/p^{\\prime}}")#text(" for some small primes ")#mi("{p,p^{\\prime}}")#text(". (This can be formalised using an inequality of Elliott related to the Turan-Kubilius theorem.) This gives a relationship between ")#mi("{P_x}")#text(" and ")#mi("{P_{x^{\\prime}}}")#text(" for “edges” ")#mi("{x,x^{\\prime}}")#text(" in a rather sparse “graph” connecting the elements of say ")#mi("{[X/2,X]}")#text(". Using some graph theory one can locate some non-trivial “cycles” in this graph that eventually lead (in conjunction to a certain technical but important “Chinese remainder theorem” step to modify the ")#mi("{P_x}")#text(" to eliminate a rather serious “aliasing” issue that was already ")#link("https://terrytao.wordpress.com/2018/12/05/fourier-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/")[#text("discussed in this previous post")]#text(") to obtain functional equations of the form")

#align(center)[#tao-fit-display[#mitex("P_x(a_x \\cdot) \\approx P_x(b_x \\cdot)")]]

#text("for some large and close (but not identical) integers ")#mi("{a_x,b_x}")#text(", where ")#mi("{\\approx}")#text(" should be viewed as a first approximation (ignoring a certain “profinite” or “major arc” term for simplicity) as “differing by a slowly varying polynomial” and the polynomials ")#mi("{P_x}")#text(" should now be viewed as taking values on the reals rather than the integers. This functional equation can be solved to obtain a relation of the form")

#align(center)[#tao-fit-display[#mitex("P_x(t) \\approx T_x \\log t")]]

#text("for some real number ")#mi("{T_x}")#text(" of polynomial size, and with further analysis of the relation ")#link(<tao-dfc36f8d5ef7545d99d1>)[#text("(5)")]#text(" one can make ")#mi("{T_x}")#text(" basically independent of ")#mi("{x}")#text(". This simplifies ")#link(<tao-4180890d013f984ddca3>)[#text("(3)")]#text(" to something like")

#align(center)[#tao-fit-display[#tao-math("\\int_0^X \\sup_{P \\in \\mathrm{Poly}_{\\leq k-1}({\\bf R} \\rightarrow {\\bf R})} \\left|\\sum_{x \\leq n \\leq x+H} \\lambda(n) n^{-iT}\\right| \\ dx = o(HX)", block: true)]]

#text("and this is now of a form that can be treated by the theorem of Matomäki and Radziwill (because ")#mi("{n \\mapsto \\lambda(n) n^{-iT}}")#text(" is a bounded multiplicative function). (Actually because of the profinite term mentioned previously, one also has to insert a Dirichlet character of bounded conductor into this latter conclusion, but we will ignore this technicality.)")

#text("Now we apply the same strategy to ")#link(<tao-1efd6b157f9532aaa699>)[#text("(4)")]#text(". For abelian ")#mi("{G}")#text(" the claim follows easily from ")#link(<tao-4180890d013f984ddca3>)[#text("(3)")]#text(", so we focus on the non-abelian case. One now has a polynomial sequence ")#mi("{g_x \\in \\mathrm{Poly}({\\bf R} \\rightarrow G)}")#text(" attached to many ")#mi("{x \\sim X}")#text(", and after a somewhat complicated adaptation of the above arguments one again ends up with an approximate functional equation ")#metadata(none) <tao-a19269ce586e8cfeb337>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("g_x(a_x \\cdot) \\Gamma \\approx g_x(b_x \\cdot) \\Gamma")]]

#text(" ")#text(" where the relation ")#mi("{\\approx}")#text(" is rather technical and will not be detailed here. A new difficulty arises in that there are some unwanted solutions to this equation, such as")

#align(center)[#tao-fit-display[#mitex("g_x(t) = \\gamma^{\\frac{\\log(a_x t)}{\\log(a_x/b_x)}}")]]

#text("for some ")#mi("{\\gamma \\in \\Gamma}")#text(", which do not necessarily lead to multiplicative characters like ")#mi("{n^{-iT}}")#text(" as in the polynomial case, but instead to some unfriendly looking “generalized multiplicative characters” (think of ")#mi("{e(\\lfloor \\alpha \\log n \\rfloor \\beta \\log n)}")#text(" as a rough caricature). To avoid this problem, we rework the graph theory portion of the argument to produce not just one functional equation of the form ")#link(<tao-a19269ce586e8cfeb337>)[#text("(6)")]#text("for each ")#mi("{x}")#text(", but ")#emph[#text("many")]#text(", leading to dilation invariances")

#align(center)[#tao-fit-display[#mitex("g_x((1+\\theta) t) \\Gamma \\approx g_x(t) \\Gamma")]]

#text("for a “dense” set of ")#mi("{\\theta}")#text(". From a certain amount of Lie algebra theory (ultimately arising from an understanding of the behaviour of the exponential map on nilpotent matrices, and exploiting the hypothesis that ")#mi("{G}")#text(" is non-abelian) one can conclude that (after some initial preparations to avoid degenerate cases) ")#mi("{g_x(t)}")#text(" must behave like ")#mi("{\\gamma_x^{\\log t}}")#text(" for some ")#emph[#text("central")]#text(" element ")#mi("{\\gamma_x}")#text(" of ")#mi("{G}")#text(". This eventually brings one back to the multiplicative characters ")#mi("{n^{-iT}}")#text(" that arose in the polynomial case, and the arguments now proceed as before.")

#text("We give two applications of this higher order Fourier uniformity. One regards the growth of the number")

#align(center)[#tao-fit-display[#tao-math("s(k) := \\left|\\{ (\\lambda(n+1),\\dots,\\lambda(n+k)): n \\in {\\bf N} \\}\\right|", block: true)]]

#text("of length ")#mi("{k}")#text(" sign patterns in the Liouville function. The Chowla conjecture implies that ")#mi("{s(k) = 2^k}")#text(", but even the weaker conjecture of Sarnak that ")#mi("{s(k) \\gg (1+\\varepsilon)^k}")#text(" for some ")#mi("{\\varepsilon>0}")#text(" remains open. Until recently, the best asymptotic lower bound on ")#mi("{s(k)}")#text(" was ")#mi("{s(k) \\gg k^2}")#text(", ")#link("https://arxiv.org/abs/1901.06460")[#text("due to McNamara")]#text("; with our result, we can now show ")#mi("{s(k) \\gg_A k^A}")#text(" for any ")#mi("{A}")#text(" (in fact we can get ")#mi("{s(k) \\gg_\\varepsilon \\exp(\\log^{8/5-\\varepsilon} k)}")#text(" for any ")#mi("{\\varepsilon>0}")#text("). The idea is to repeat the now-standard argument to exploit multiplicativity at small primes to deduce Chowla-type conjectures from Fourier uniformity conjectures, noting that the Chowla conjecture would give all the sign patterns one could hope for. The usual argument here uses the “entropy decrement argument” to eliminate a certain error term (involving the large but mean zero factor ")#mi("{p 1_{p|n}-1}")#text("). However the observation is that if there are extremely few sign patterns of length ")#mi("{k}")#text(", then the entropy decrement argument is unnecessary (there isn’t much entropy to begin with), and a more low-tech moment method argument (similar to the derivation of Chowla’s conjecture from Sarnak’s conjecture, as discussed for instance in ")#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/")[#text("this post")]#text(") gives enough of Chowla’s conjecture to produce plenty of length ")#mi("{k}")#text(" sign patterns. If there are not extremely few sign patterns of length ")#mi("{k}")#text(" then we are done anyway. One quirk of this argument is that the sign patterns it produces may only appear exactly once; in contrast with preceding arguments, we were not able to produce a large number of sign patterns that each occur infinitely often.")

#text("The second application is to obtain cancellation for various polynomial averages involving the Liouville function ")#mi("{\\lambda}")#text(" or von Mangoldt function ")#mi("{\\Lambda}")#text(", such as")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{n \\leq X} {\\bf E}_{m \\leq X^{1/d}} \\lambda(n+P_1(m)) \\lambda(n+P_2(m)) \\dots \\lambda(n+P_k(m))")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{n \\leq X} {\\bf E}_{m \\leq X^{1/d}} \\lambda(n+P_1(m)) \\Lambda(n+P_2(m)) \\dots \\Lambda(n+P_k(m))")]]

#text("where ")#mi("{P_1,\\dots,P_k}")#text(" are polynomials of degree at most ")#mi("{d}")#text(", no two of which differ by a constant (the latter is essential to avoid having to establish the Chowla or Hardy-Littlewood conjectures, which of course remain open). Results of this type were previously obtained ")#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/")[#text("by Tamar Ziegler and myself")]#text(" in the “true complexity zero” case when the polynomials ")#mi("{P}")#text(" had distinct degrees, in which one could use the ")#mi("{k=0}")#text(" theory of Matomäki and Radziwill; now that higher ")#mi("{k}")#text(" is available at the scale ")#mi("{H=X^{1/d}}")#text(" we can now remove this restriction.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebfc592b1dfe7fbc6b3db328a99edb83965e209243aac288de1eab2dfbe8d3f1-16dafef2e9965161b0fbab76d6686363904d5e3a458785859ad5a274d999afb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian Finn")]], [#link("https://terrytao.wordpress.com/2020/07/30/higher-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-578503")[#strong[#text("Ian Finn")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2020")])]

#text("Do you mean to have the “and” here?")

#text("This paper (which originated from a working group at an AIM workshop on Sarnak’s conjecture), and focuses on")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/07/30/higher-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-579081")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2020")])]

#text("Is it possible by these methods to improve the exponent 5/8 (in the current best upper bound on H) ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/07/30/higher-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-579137")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2020")])]

#text("Conjecturally the local uniformity statement should hold for any ")#mi("H")#text(" going to infinity, but this was the best we could accomplish with the tools we had.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a47d47e95fcd24a3f41dfbff1015ccb0d0936409c31ad8a95de463d8e71cca86-537a73a0ee4ae2704991ef894a45295132a107125042924a108fb86d88bcfd11.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allan van Hulst")]], [#link("https://terrytao.wordpress.com/2020/07/30/higher-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-579391")[#strong[#text("Allan van Hulst")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2020")])]

#text("Found a couple small mistakes in the paper on arxiv:")

#text("pag. 9 => Lioiville,")#linebreak()#text(" pag. 18 => Corllary,")#linebreak()#text(" pag. 40 => filtrtaion,")#linebreak()#text(" pag. 45 => nilmanfiold,")#linebreak()#text(" pag. 91 => bouned")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gimothy Towers")]], [#link("https://terrytao.wordpress.com/2020/07/30/higher-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-579489")[#strong[#text("Gimothy Towers")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2020")])]

#text("Even though I am pretty ignorant on the topic, I am surprised you guys only showed there are >>_A k^A sign patterns that appear at least once and not that there are >>_A k^A sign patterns that appear infinitely often. Would you say there is a genuine obstruction or you guys were just lazy/[not smart enough]?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/954c89ac51490390c0ab6fb8042bf2c2c94ebc5c78be9a64eef1fcff402644fa-7d256077272876bd29345bf3fd0d4489f8812a902ca3000ffcd05893c98d68f5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PAF")]], [#link("https://terrytao.wordpress.com/2020/07/30/higher-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-579863")[#strong[#text("PAF")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2020")])]

#text("Dear Professor")#linebreak()#text(" A little mistake to be corrected only on your blog (and not on the ArXiv version because this occurrence was not found there): “unwanted solutions” instead of “unwanted solutoins”.")#linebreak()#text(" Yours sincerely")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/954c89ac51490390c0ab6fb8042bf2c2c94ebc5c78be9a64eef1fcff402644fa-7d256077272876bd29345bf3fd0d4489f8812a902ca3000ffcd05893c98d68f5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/07/30/higher-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-580626")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2020")])]

#text("Yet another very minor formal mistake founded in the last sentence of the current page on your blog: theory of Matomaki => theory of Matoma:ki (if we want to respect the exact name of the first author of this paper).")#linebreak()#text(" Best regards")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Higher uniformity of arithmetic functions in short intervals II. Almost all intervals | What's new")]], [#link("https://terrytao.wordpress.com/2020/07/30/higher-uniformity-of-bounded-multiplicative-functions-in-short-intervals-on-average/#comment-686737")[#strong[#text("Higher uniformity of arithmetic functions in short intervals II. Almost all intervals | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2024")])]

#text("[…] the Möbius function, we can get , recovering our previous result with Tamar Ziegler, but now with type savings in the exceptional set (though not in the pointwise bound outside of […]")
]
