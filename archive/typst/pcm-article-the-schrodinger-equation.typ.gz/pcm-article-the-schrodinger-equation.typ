// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/
// Converted to Typst by tao2typ: "2026-10-14T15:16:30.019153+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "PCM article: The Schrodinger equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("PCM article: The Schrodinger equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 October 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/")[#text("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’m continuing my ")#link("https://terrytao.wordpress.com/category/paper/companion/")[#text("series of articles")]#text(" for the ")#link("http://gowers.wordpress.com/2007/09/06/hello-world/")[#text("Princeton Companion to Mathematics")]#text(" with my ")#link("http://www.math.ucla.edu/%7Etao/preprints/schrodinger.pdf")[#text("article on the Schrödinger equation")]#text(" – the fundamental equation of motion of quantum particles, possibly in the presence of an external field. My focus here is on the relationship between the ")#link("http://en.wikipedia.org/wiki/Schrodinger_equation")[#text("Schrödinger equation of motion")]#text(" for wave functions (and the closely related ")#link("http://en.wikipedia.org/wiki/Heisenberg_equation")[#text("Heisenberg equation of motion")]#text(" for quantum observables), and ")#link("http://en.wikipedia.org/wiki/Hamilton%27s_equations")[#text("Hamilton’s equations of motion")]#text(" for classical particles (and the closely related ")#link("http://en.wikipedia.org/wiki/Poisson_bracket#Equations_of_motion")[#text("Poisson equation of motion")]#text(" for classical observables). There is also some brief material on semiclassical analysis, scattering theory, and spectral theory, though with only a little more than 5 pages to work with in all, I could not devote much detail to these topics. (In particular, ")#link("http://tosio.math.toronto.edu/wiki/index.php/Schrodinger_equations")[#text("nonlinear Schrödinger equations")]#text(", a favourite topic of mine, are not covered at all.)")

#text("As I said before, I will try to link to at least one other PCM article in every post in this series. Today I would like to highlight ")#link("http://people.csail.mit.edu/madhu/")[#text("Madhu Sudan")]#text("‘s delightful article on information and coding theory, “")#link("http://people.csail.mit.edu/madhu/papers/pcm.pdf")[#text("Reliable transmission of information")]#text("“.")

#text("[")#emph[#text("Update")]#text(", Oct 3: typos corrected.]")

#text("[")#emph[#text("Update")]#text(", Oct 9: more typos corrected.]")

#heading(level: 1)[#text("Comments (27)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-10886")[#strong[#text("Infinite Reflections » Blog Archive » http://gowers.wordpress.com/")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2007")]

#text("[…] Terry’s PCM article: The Schrodinger […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bessel")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-10892")[#strong[#text("Bessel")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2007")])]

#text("Dear Terry,")#linebreak()#text(" What do you think about the very popular discrete Schrodinger")#linebreak()#text(" version? It is very interesting and related to the discrete")#linebreak()#text(" linear wave equation, which is dissipative, i.e., the solution")#linebreak()#text(" of the initial value problem with a delta function initial position")#linebreak()#text(" and no acceleration has the solution J_2n (2t), n \\in Z. Such")#linebreak()#text(" a solution is then a superposition of different wave shapes which")#linebreak()#text(" move with different characteristic speeds. It is actually quite")#linebreak()#text(" unusual to have all wave shapes move with exactly the same")#linebreak()#text(" speed as in the wave equation, since wave propagation in most")#linebreak()#text(" ohysical systems is dispersive.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-10895")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2007")])]

#text("Dear Bessel,")

#text("There is certainly plenty of good mathematics associated to the discrete Schrodinger equation. On the one hand, it serves as a model of electrons traveling through crystals, and can be used to explain the phenomenon of ")#link("http://en.wikipedia.org/wiki/Anderson_localization")[#text("Anderson localisation")]#text(". It also is connected to the theory of Jacobi matrices, which are in turn intimately connected with orthogonal polynomials. It can also be viewed as a toy model for the continuous Schrodinger equation, in which all high-frequency effects are removed.")

#text("The finite speed of propagation of the wave equation is closely connected to the Lorentz invariance of that equation, which is of course not present in the discrete model. Actually, I plan to discuss this connection in a later blog post…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-10912")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2007")])]

#text("This is a very nice article! I noticed two typos:")

#text("* The “=1” on the left-hand side of line -6 of page 2 seems to be a mistake.")

#text("* Also on page 5, “on” is missing in line -16 in “depends (in a non-linear fashion) _on_ the potential $V$”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Attila Smith")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-10918")[#strong[#text("Attila Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2007")])]

#text("Dear Sir,")#linebreak()#text(" on page 2, line -8 of your beautiful article on the Schrödinger equation there seems to be a typographical error: the target of psi(t) should be C, not R.")#linebreak()#text(" Your most devoted,")#linebreak()#text(" Attila.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87dc3d3277d5e4ab14817697984631540cd905a8ecb030bbc33be406ac686b88-7b7acb63482ef391c1a0aa5d5016ce427bbc46dd8613fae7921772986b32a225.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Hunting")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-10932")[#strong[#text("Will Hunting")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2007")])]

#text("A typo in this article : it is Ma")#emph[#text("dh")]#text("u Sudan.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-10933")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2007")])]

#text("Thanks for all the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gordon")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-10944")[#strong[#text("Gordon")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2007")])]

#text("Dear Terry,")#linebreak()#text(" I know it is a little off-topic, but I was wondering: how is the")#linebreak()#text(" cubic Schrodinger related to the phi-to-the-fourth model?")#linebreak()#text(" In Wikipedia they mention this connection in passing.")#linebreak()#text(" I mean the derivation and all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-10945")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2007")])]

#text("Dear Gordon,")

#text("The ")#mi("\\phi^4")#text(" model in quantum field theory is the quantum analogue of the (classical, relativistic) cubic nonlinear Klein-Gordon equation ")#mi("\\partial^\\alpha \\partial_\\alpha \\phi = m^2 \\phi + \\phi^3")#text(" (I’m ignoring factors of ")#mi("\\hbar")#text(" and c here). Indeed, both models are derived from the same Lagrangian ")#mi("\\int_{{\\Bbb R}^{1+3}} \\frac{1}{2} \\partial_\\alpha \\phi \\partial^\\alpha \\phi + \\frac{1}{2} m^2 \\phi^2 + \\frac{1}{4} \\phi^4")#text(", though of course the former model is quantum and the latter is classical. The cubic Schrodinger equation then emerges as the ")#link("http://tosio.math.toronto.edu/wiki/index.php/Non-relativistic_limit")[#text("non-relativistic limit")]#text(" of the cubic Klein-Gordon equation (in particular, we are viewing this equation here, somewhat confusingly, as a ")#emph[#text("classical")]#text(" non-relativistic equation rather than a quantum one). So, in short, cubic Schrodinger is the classical non-relativistic analogue of the quantum relativistic ")#mi("\\phi^4")#text(" model, and so I presume the former is expected to model the latter in the case of macroscopic, slow-moving fields.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thurs")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-10947")[#strong[#text("Thurs")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2007")])]

#text("Dear Gordon,")#linebreak()#text(" A similar issue was already discussed on Terry’s blog a short while")#linebreak()#text(" ago, in connection with Perelman’s preprints. First, notice from:")#linebreak()#text(" ")#link("http://en.wikipedia.org/wiki/Klein-Gordon")[#text("http://en.wikipedia.org/wiki/Klein-Gordon")]#linebreak()#text(" that the Schrodinger equation does not take into account")#linebreak()#text(" special relativity. Using a natural generalization, we get")#linebreak()#text(" the Klein-Gordon equation, which coincides with the action")#linebreak()#text(" functional before the Big Bang. To construct an after Big-Bang")#linebreak()#text(" theory, you need to use a proper version of this action,")#linebreak()#text(" which has a nonlocal part and a phi-to-the-fouth double-well.")#linebreak()#text(" However, due to enlargement of the underlying space of")#linebreak()#text(" the action after the Big Bang, it is not clear how to construct")#linebreak()#text(" a well-posed evolution: it is well-known that instabilities")#linebreak()#text(" can occur only on non-differentiable paths (literature).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-10961")[#strong[#text("This week in the arXivs… « It’s Equal, but It’s Different…")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2007")]

#text("[…] PCM article: The Schrodinger equation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-11080")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2007")])]

#text("Hi Terence,")

#text("My fascination with John von Neumann continues:")

#text("“By the Stone-von Neumann theorem, the Heisenberg picture and the Schrödinger picture are unitarily equivalent.”")

#link("http://en.wikipedia.org/wiki/Heisenberg_picture")[#text("http://en.wikipedia.org/wiki/Heisenberg_picture")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hint")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-11082")[#strong[#text("Hint")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2007")])]

#text("Dear Doug: Can this statement be shown by using quaternions?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-11258")[#strong[#text("Princeton Companion to Mathematics « Nerd Wisdom")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2007")]

#text("[…] Companion to Mathematics From Terence Tao’s excellent blog, I learned about the upcoming Princeton Companion to Mathematics (PCM), a roughly 1000-page survey […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of V")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-11430")[#strong[#text("V")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2007")])]

#text("Hi,")

#text("In page five, second paragraph it says “The time-dependent Schrodinger equation H psi = E psi”. I think it should be “time-independent”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-11444")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2007")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a1cc5b4a001e5d38af760a1052f93800aba6961d71c125a71a8a21d594959f55-cf376cc72abc07b6933af427dcd705d9bccf7e99e7eab78356a8878b9934cfbc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jerry")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-11472")[#strong[#text("Jerry")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2007")])]

#text("Dear Terry,")

#text("I liked your PCM article on the Schr\\”odinger equation very much! That so much elegant mathematics and physics can be packed into one short, ")#emph[#text("readable")]#text(" expository article is a feat. As everyone else is calling attention to various typos here, I’ll mention one I noticed too: page 5, second paragraph, in the sentence “Indeed, ")#mi("H")#text(" can have eigenvalues ")#mi("\\psi")#text(" which lie in the doman ")#mi("L^2(\\mathbf{R}^n)")#text("…,” the term ")#emph[#text("eigenfunctions")]#text(" or ")#emph[#text("eigenstates")]#text(" is obviously meant. Later in that paragraph, you define the spectrum of ")#mi("H")#text(" to be “the set of energies ")#mi("E")#text(" for which the operator ")#mi("H-E")#text(" fals to be invertible.” To be entirely precise, one should say “…for which the operator ")#mi("H-E")#text(" fails to have ")#emph[#text("bounded")]#text(" inverse.” As you know, ")#mi("H-E")#text(" being injective (i.e. invertible) simply means that ")#mi("E")#text(" is not an eigenvalue.")

#text("Yours,")#linebreak()#text(" Jerry Gagelman")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-11503")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2007")])]

#text("Thanks for the additional corrections! (It seems that extensive proofreading is one of the perks of mathematical blogging. :-) )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-11992")[#strong[#text("Not Even Wrong » Blog Archive » Accumulated Links")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2007")]

#text("[…] and articles, often of a general expository nature. For some recent examples, see one about the Schrodinger Equation, and another about Jordan normal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf445dd3ded972a5d1b62126dac2900bf47db6c85c39b95626f92b945e4f092-821d2a67ec2aa6fd2150e7112d80a9cf9bad4da7b90b8dab1f324d9a6a89f5c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-12250")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2007")])]

#text("Yes, John von Neumann 80 years ago axiomatized Hilbert space, proved the commutant theorem for strong operator closed self-adjoint algebras of bounded linear operators acting on that space, nicely timed to be almost simultaneous with Heisenberg’s matrix mechanics and the equivalent Schrodinger wave mechanics, as seen in his famous monograph “Mathematical Foundations of Quantum Mechnics.”")

#text("But there is a limit to generalizing this. Fifteen years later Gelfand and Naimark showed that, while a von Neumann algebra (abstractly as a *-algebra) has essentially a unique Hilbert space representation (i.e. canonical, multiplicity 1, any other representation determined just by multiplicity), a self-adjoint algebra of Hilbert space operators only assumed to be norm closed (now called concrete C*-algebra) in general has many very different Hilbert space representations. That cannot happen when there are a finite number of degrees of freedom in a quantum mechanical system.")

#text("Then around when I was born at the start of the 1950s, Garding and Wightman showed that the C*-algebra with infinitely many degrees of freedom has infinitely many inequivalent irreducible representations.")

#text("The classification questions this raised were mostly solved by Connes et al, and George Elliott’s generalization of Glimm’s 1959 classification of infinite tensor products of matrix algebras, to AF (approximately finite) algebras, and deep connections to K-theory, Connes-Takesaki flow of weights, Jones knot polynomials, Feynman diagram renormalization, the Wigner semi-circle law, quantum groups, and other stuff somewhat beyond my grasp.")

#text("Good summary of all the above in the lead article of FieldNotes, Vol.8, Sep 2007.")

#text("I’m still wrestling with a paper I’ve gotten to almost 100 pages (too long) on *-algebras for Vasiliev’s “Imaginary Logics.”")

#text("Is our universe noncommutative? We could hardly even ask the question, were it not for von Neumann and the other giants mentioned above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-12484")[#strong[#text("Terrence Tao and Schrodinger Equation « Thinking in Sveccha")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2007")]

#text("[…] ")#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/")[#text("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asub")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-12616")[#strong[#text("asub")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2007")])]

#text("I really enjoyed the article and would like to learn more on the mathematical aspects of quantum mechanics. Except for von Neumann, which is quite old, I don’t know of any good book on this subject. Can you please provide some references on this subject?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-13488")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2007")])]

#text("Hi Terence,")

#text("I have noticed that electrical engineers tend to deal with Fourier Transform Pairs [FTP]:")

#text("The Scientist and Engineer’s Guide to Digital Signal Processing")#linebreak()#text(" By Steven W Smith, PhD")#linebreak()#text(" Chapter 11: Fourier Transform Pairs")#linebreak()#text(" “For every time domain waveform there is a corresponding frequency domain waveform, and vice versa. For example, a rectangular pulse in the time domain coincides with a sinc function [i.e., sin(x)/x] in the frequency domain. Duality provides that the reverse is also true; a rectangular pulse in the frequency domain matches a sinc function in the time domain. Waveforms that correspond to each other in this manner are called Fourier transform pairs. Several common pairs are presented in this chapter.”")#linebreak()#text(" ")#link("http://www.dspguide.com/ch11.htm")[#text("http://www.dspguide.com/ch11.htm")]

#text("Both theoretical mathematicians and many physicists appear to ignore these FTP pairs.")

#text("Yet there are both 1) Time Dependent and 2) Time Independent versions of the Schrodinger Equation that appear to be consistent with Fourier Transform Pairs?")#linebreak()#text(" HyperPhysics GSU-US")#linebreak()#text(" ")#link("http://hyperphysics.phy-astr.gsu.edu/hbase/quantum/scheq.html")[#text("http://hyperphysics.phy-astr.gsu.edu/hbase/quantum/scheq.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orr")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-15949")[#strong[#text("Orr")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2007")])]

#text("I’m sorry for the perhaps silly question, but how does one reach this article?")#linebreak()#text(" Is the file linked there?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-15951")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2007")])]

#text("Oops! I had removed the link by accident. It’s restored now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/774a4c2a4ba087a90ea74eae78dddbf54d068e28e8129b0da792bd01684bf4a7-6c27be513573d2de7a286b51594ad03e508ac58dfc0db5083dbf76cfa20c208d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of m.hassan")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-27266")[#strong[#text("m.hassan")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2008")])]

#text("how does schrodinger equation help to solve classical mechanics?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c49c2c852da49ceb80b60cb758114e49d59ecb741248dea656e5dbcba4958876-8b5fdf11bc681200f18714e9dd2d12fa79a05f6538d5faff496eec60e9cc7de9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of moses")]], [#link("https://terrytao.wordpress.com/2007/10/02/pcm-article-the-schrodinger-equation/#comment-33977")[#strong[#text("moses")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("hi,")#linebreak()#text(" i was just wondering which basic physical phenomenon connects the schrondinger equation to de Broglie’s hypothesis?")
]
