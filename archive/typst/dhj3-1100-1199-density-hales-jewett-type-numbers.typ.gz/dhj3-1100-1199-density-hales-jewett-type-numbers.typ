// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/
// Converted to Typst by tao2typ: "2026-10-14T16:35:38.999708+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "DHJ(3): 1100-1199 (Density Hales-Jewett type numbers)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("DHJ(3): 1100-1199 (Density Hales-Jewett type numbers)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 March 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/")[#text("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is a continuation of the ")#link("https://terrytao.wordpress.com/2009/03/04/dhj3-900-999-density-hales-jewett-type-numbers")[#text("900-999 thread")]#text(" of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("polymath1")]#text(" project, which is now full. We’ve made quite a bit of progress so far on our original mission of bounding density Hales-Jewett numbers. In particular, we have shown")

#list(
[#mi("c_6=450")#text(": Any subset of ")#mi("[3]^6")#text(" with 451 points contains a ")#link("http://michaelnielsen.org/polymath1/index.php?title=Line")[#text("combinatorial line")]#text("; and there is exactly one example with 450 points with no combinatorial line. (We have two proofs, one by a large integer program, and the other being purely human-verifiable; the latter can be ")#link("http://michaelnielsen.org/polymath1/index.php?title=Upper_and_lower_bounds")[#text("found here")]#text(".)")],
[#mi("c^{\\prime}_5=124")#text(": Any subset of ")#mi("[3]^5")#text(" with 125 points contains a ")#link("http://michaelnielsen.org/polymath1/index.php?title=Line")[#text("geometric line")]#text("; and we have several examples with 124 points with no geometric line. (The proof is partly computer-assisted; ")#link("http://michaelnielsen.org/polymath1/index.php?title=Moser%27s_cube_problem")[#text("details are here")]#text(".)")],
[#mi("353 \\leq c^{\\prime}_6 \\leq 361")#text(": A genetic algorithm has constructed 353-point solutions in ")#mi("[3]^6")#text(" with no geometric line; in the other direction, ")#link("http://michaelnielsen.org/polymath1/index.php?title=Maple_calculations")[#text("linear and integer programming methods have shown")]#text(" that any set with 362 points must have a geometric line.")],
[#mi("\\overline{c}^\\mu_{12} = 40")#text(": In the triangular grid ")#mi("\\{(a,b,c) \\in {\\Bbb N}^3:a+b+c=12\\}")#text(", any set of 41 points contains an upwards-pointing equilateral triangle ")#mi("(a+r,b,c),(a,b+r,c),(a,b,c+r)")#text(" with ")#mi("r>0")#text("; and we have 40-point examples without such triangles. This was conducted by an integer program.")]
)

#text("This ")#link("http://michaelnielsen.org/polymath1/index.php?title=Timeline")[#text("timeline")]#text(" shows the history of these and other developments in the project.")

#text("There are still several numbers that look feasible to compute. For instance, the bounds on ")#mi("c^{\\prime}_6")#text(" should be able to be narrowed further. Work is slowly progressing also on the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Hyper-optimistic_conjecture")[#text("equal-slices Hales-Jewett numbers")]#text(" ")#mi("c^\\mu_n")#text(", which are ")#link("http://michaelnielsen.org/polymath1/index.php?title=Hyper-optimistic_conjecture")[#text("hyper-optimistically conjectured")]#text(" to equal the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Fujimura%27s_problem")[#text("Fujimura numbers")]#text(" ")#mi("\\overline{c}^\\mu_n")#text("; this has been verified by hand up to n=3 and by integer programming up to n=5. We are also looking at trying to reduce the dependence on computer assistance in establishing the ")#mi("c^{\\prime}_5 = 124")#text(" result; the best human result so far is ")#mi("124 \\leq c^{\\prime}_5 \\leq 125")#text(".")

#text("Some progress has recently been made on some other related questions. For instance, we now have a precise description of the lower bound on ")#mi("c_n")#text(" coming from the Behrend-Elkin construction, namely")

#align(center)[#tao-fit-display[#mitex("c_n > C 3^{n - 4\\sqrt{\\log 2}\\sqrt{\\log n}+\\frac 12 \\log \\log n}")]]

#text("for some absolute constant c.")

#text("Also, it is probably a good time to transport some of the discussion in earlier threads to ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("the wiki")]#text(" and make it easier for outsiders to catch up. (Incidentally, we need a logo for that wiki; any suggestions would be welcome!)")

#text("Comments on this thread should be numbered starting at 1100.")

#heading(level: 1)[#text("Comments (118)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-3/#comment-37576")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1189. Regarding ")#mi("c_{4,k}")

#text("There is another possible solution to the linear inequalities")#linebreak()#text(" * k(k-1)(k-5) missing xyzw points")#linebreak()#text(" * 6k(k-1) missing xxyz points")#linebreak()#text(" * k missing xxxx points")

#text("and probably other solutions with values intermediate between this post and the previous post. The difference between the new and old solutions is")#linebreak()#text(" * 6(k-1) fewer xyzw points")#linebreak()#text(" * 12(k-1) extra xxyz points")#linebreak()#text(" * 3(k-1) fewer xxyy points")#linebreak()#text(" * 4(k-1) fewer xxxy points")#linebreak()#text(" * k-1 extra xxxx points")

#text("which hints at k different solutions altogether.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-3/#comment-37583")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1190. H(4,2) is greater than 11")

#text("We take the slices of the eleven dimensional hypercube")#linebreak()#text(" of side four in the following way:")#linebreak()#text(" We start with the Van der Warden number W(4,2) for which")#linebreak()#text(" we have an exact value:")#linebreak()#text(" W(4,2) =35")#linebreak()#text(" from the Ramsey theory book by Graham Rothschild and Spencer")#linebreak()#text(" second addition")#linebreak()#text(" We give the slice (a,b,c,d) the color associated")#linebreak()#text(" with a + 2b + 3b+1 then the maximum value is 34")#linebreak()#text(" We add one because the coloring in W(4,2) starts with one")#linebreak()#text(" and we have zero values in our slices.")#linebreak()#text(" Then we will not have a monochromatic combinatorial line")#linebreak()#text(" because it would correspond to a monochromatic upward")#linebreak()#text(" tetrahedron (a+r,b,c,d) (a,b+r,c,d) etc. so we are done.")#linebreak()#text(" This is an improvement in the old value of HJ(4,2) is greater than 6.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-3/#comment-37584")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1191. H(3,3) is greater than 13")

#text("We take the slices of the eleven dimensional hypercube")#linebreak()#text(" of side four in the following way:")#linebreak()#text(" We start with the Van der Warden number W(3,3) for which")#linebreak()#text(" we have an exact value:")#linebreak()#text(" W(3,3) =27")#linebreak()#text(" same source as 1190")#linebreak()#text(" We give the slice (a,b,c,) the color associated")#linebreak()#text(" with a + 2b +1 then the maximum value is 27")#linebreak()#text(" We add one because the coloring in W(3,3) starts with one")#linebreak()#text(" and we have zero values in our slices.")#linebreak()#text(" Then we will not have a monochromatic combinatorial line")#linebreak()#text(" because it would correspond to a monochromatic upward")#linebreak()#text(" triangle and a monochromatic upward triangle would lead to")#linebreak()#text(" an arithmetic progression of lenght three but we have forbidden such a progression by our choice of coloring so we are done.")#linebreak()#text(" This is an improvement in the old value of HJ(3,3) is my value of 7 before that there was a computer generated value of 6 in the paper I cited in 1175.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-3/#comment-37585")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1192. H(4,2) is greater than 11 redo")

#text("I am redoing this because I omitted part of the proof:")#linebreak()#text(" We take the slices of the eleven dimensional hypercube")#linebreak()#text(" of side four in the following way:")#linebreak()#text(" We start with the Van der Warden number W(4,2) for which")#linebreak()#text(" we have an exact value:")#linebreak()#text(" W(4,2) =35")#linebreak()#text(" from the Ramsey theory book by Graham Rothschild and Spencer")#linebreak()#text(" second addition")#linebreak()#text(" We give the slice (a,b,c,d) the color associated")#linebreak()#text(" with a + 2b + 3b+1 then the maximum value is 34")#linebreak()#text(" We add one because the coloring in W(4,2) starts with one")#linebreak()#text(" and we have zero values in our slices.")#linebreak()#text(" Then we will not have a monochromatic combinatorial line")#linebreak()#text(" because it would correspond to a monochromatic upward")#linebreak()#text(" tetrahedron (a+r,b,c,d) (a,b+r,c,d) etc. and a monochromatic upward tetrahedron would lead to")#linebreak()#text(" an arithmetic progression of length four but we have forbidden such a progression by our choice of coloring so we are done.")#linebreak()#text(" This is an improvement in the old value of HJ(4,2) is greater than 6.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-3/#comment-37586")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1193. H(5,2) is greater than 59")

#text("We color the slices of the 59 dimensional hypercube")#linebreak()#text(" of side four in the following way:")#linebreak()#text(" We start with the Van der Warden number W(5,2) for which")#linebreak()#text(" we have an exact value:")#linebreak()#text(" W(5,2) =178")#linebreak()#text(" from the Ramsey theory book by Graham Rothschild and Spencer")#linebreak()#text(" second addition")#linebreak()#text(" We give the slice (a,b,c,d) the color associated")#linebreak()#text(" with a + 2b + 3b+1 then the maximum value is 178")#linebreak()#text(" We add one because the coloring in W(5,2) starts with one")#linebreak()#text(" and we have zero values in our slices.")#linebreak()#text(" Then we will not have a monochromatic combinatorial line")#linebreak()#text(" because it would correspond to a monochromatic upward")#linebreak()#text(" tetrahedron (a+r,b,c,d) (a,b+r,c,d) etc. and a monochromatic upward tetrahedron would lead to")#linebreak()#text(" an arithmetic progression of length four but we have forbidden such a progression by our choice of coloring so we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-3/#comment-37587")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1194. H(3,4) is greater than 37")

#text("We color the slices of the 37 dimensional hypercube")#linebreak()#text(" of side three in the following way:")#linebreak()#text(" We start with the Van der Warden number W(3,4) for which")#linebreak()#text(" we have an exact value:")#linebreak()#text(" W(3,4) =76")#linebreak()#text(" from the Ramsey theory book by Graham Rothschild and Spencer")#linebreak()#text(" second addition")#linebreak()#text(" We give the slice (a,b,c,d) the color associated")#linebreak()#text(" with a + 2b + 1 then the maximum value is 75")#linebreak()#text(" We add one because the coloring in W(5,2) starts with one")#linebreak()#text(" and we have zero values in our slices.")#linebreak()#text(" Then we will not have a monochromatic combinatorial line")#linebreak()#text(" because it would correspond to a monochromatic upward")#linebreak()#text(" triangle and a monochromatic upward triangle would lead to")#linebreak()#text(" an arithmetic progression of length three but we have forbidden such a progression by our choice of coloring so we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-3/#comment-37588")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1195. HOC k=4")

#text("After finding the example for HOC k=4 I decided to modify my program to work for this case too. The example is optimal and I get the values.")

#text("d=2 weight 7.5 points 12 solutions 8")#linebreak()#text(" d=3 weight 14.5 points 45 solutions 112")#linebreak()#text(" d=4 weight 25 points 180 solutions 24")

#text("The solutions are here")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/Data/HJ/HOC/")[#text("http://abel.math.umu.se/~klasm/Data/HJ/HOC/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-3/#comment-37589")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1195. H(n,2)")

#text("We start with the fact W(p+1, 2) is greater than or equal to p*2^p")#linebreak()#text(" From the book mentioned above")#linebreak()#text(" then for any n we an find a prime p less than n greater than n-n^.525")#linebreak()#text(" then we get a sequence of length p*2^p free of progressions of length")#linebreak()#text(" p and hence of length progressions of length n we look at the largest integer")#linebreak()#text(" less than or equal to p*2p/n-1 then subtract one from it that will be the dimension of our slice space we give each slice the coloring associated with")#linebreak()#text(" the p*2^p for a + 2b+ 3c .. continued for n terms the maximum value will be less than or equal to p*2^p we will not have an upward n-1 dimensional simplex hence avoid combinatorial lines because if we did we would have a monochromatic arithmetic progression of length p which we have forbidden thus we get a bound H(n,2) is greater than ((n-n^5.35)*2^(n-n.535)/n-1)-2 (the two comes from possible rounding in taking the greatest integer and th subtraction of one).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-3/#comment-37591")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1196. H(n,r)")

#text("We start with the bound W(n,r) is greater than r^n/erk(1+o(1))")#linebreak()#text(" which is from the website")

#link("http://mathworld.wolfram.com/vanderWaerdenNumber.html")[#text("http://mathworld.wolfram.com/vanderWaerdenNumber.html")]

#text("which gives the reference")#linebreak()#text(" Heule, M. J. H. “Improving the Odds: New Lower Bounds for Van der Waerden Numbers.” March 4, 2008. ")#link("http://www.st.ewi.tudelft.nl/sat/slides/waerden.pdf")[#text("http://www.st.ewi.tudelft.nl/sat/slides/waerden.pdf")]#text(".")

#text("then we take that coloring and give it to a +2b+.. continued n-1 times")#linebreak()#text(" we can do this if the dimension is less than ((n^r/ern(1+o(1)))/n-1) -2")#linebreak()#text(" we then will get no n-1 dimensional upward simplex as then we would")#linebreak()#text(" have a monochromatic arithmetic progression which we have forbidden but since we have no monochromatic upward n-1 dimensional simplex we will have no combinatorial lines and so we are done and we have")

#text("H(n,r) is greater than ((n^r/ern(1+o(1)))/n-1) -2")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-3/#comment-37594")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1196. HJ(n,r)")

#text("I should have written that not H(n,r) in 1190-1194 and in 1195-6 thus the above should be:")

#text("HJ(n,r) is greater than ((n^r/ern(1+o(1)))/n-1) -2")

#text("HJ(n,2) is greater than ((n-n^5.35)*2^(n-n.535)/n-1)-2")

#text("HJ(3,4) is greater than 37")

#text("HJ(5,2) is greater than 59")

#text("HJ(3,4) is greater than 37")

#text("HJ(4,2) is greater than 11")

#text("HJ(3,3) is greater than 13")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-3/#comment-37595")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1197. Fujimura k=3 n= 13")

#text("The computation for k=3 n=13 has finished. The optimal size is 46 and I have added the solutions to my table page.")

#text("This required some spare time from a linux cluster to be possible so I will not try to extend Fujimura for k=3 unless it turns out to be needed for something specific.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-3/#comment-37596")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1198. ")#mi("c_n")#text(" and generalization beyond 3")

#text("We have HJ(3,r) is greater than ((3^r/er3(1+o(1)))/2) -2")#linebreak()#text(" so we c_n greater than 3^n/r for n is less than ((3^r/er3(1+o(1)))/2) -2")#linebreak()#text(" and we get c_n is is greater than 3^n/(logn-log (log n) -log 3e(1+(o)1))")#linebreak()#text(" similarly we get in general the maximal number of points in a combinatorial line free cube of side m and dimension n is m^n/(logn-log (log n) -log (me(1+o1))")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-3/#comment-37597")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1198. correction")

#text("imilarly we get in general the maximal number of points in a combinatorial line free cube of side m and dimension n is m^n/(logn-log (log n) -log (me(1+o1)) should be")

#text("imilarly we get in general the maximal number of points in a combinatorial line free cube of side m and dimension n is greater than m^n/(logn-log (log n) -log (me(1+o1))")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DHJ(k): 1200-1299 (Density Hales-Jewett type numbers) « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-3/#comment-37598")[#strong[#text("DHJ(k): 1200-1299 (Density Hales-Jewett type numbers) « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("[…] March, 2009 in math.CO | Tags: polymath1 | by Terence Tao This is a continuation of the 1100-1199 thread of the polymath1 project, which is now full. The focus has now mostly shifted on generalisations […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-3/#comment-37599")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1199. More HJ numbers")

#text("We have from")#linebreak()#text(" ")#link("http://www.st.ewi.tudelft.nl/sat/waerden.php")[#text("http://www.st.ewi.tudelft.nl/sat/waerden.php")]#linebreak()#text(" W(3,5) is greater than 170 from this we get")#linebreak()#text(" using methods similar to the above HJ(3,5) is")#linebreak()#text(" greater than 84 this actually makes a difference for values of")#linebreak()#text(" 82,83 and 84 for c_n in the table at ")#link("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DsU-uZ1tK7VEg")[#text("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DsU-uZ1tK7VEg")]#text(" as the maximal density must be greater than")#linebreak()#text(" .2")

#text("We have from")#linebreak()#text(" the same source")#linebreak()#text(" W(3,6) is greater than 207")#linebreak()#text(" so by similar method as above we have")#linebreak()#text(" HJ(3,6) is greater than 103 again this makes a difference in")#linebreak()#text(" the table starting at 82 and continuing through 98 as the maximal density must be greater than 1/6")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-3/#comment-37616")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("Looks like the thread has been wrapped up just in time! Of course, we start afresh at the new thread:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2009/03/30/dhjk-1200-1299-density-hales-jewett-type-numbers/")[#text("DHJ(k): 1200-1299 (Density Hales-Jewett type numbers)")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-3/#comment-38158")[#strong[#text("The Twofold Gaze")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2009")]

#text("[…] should say that if anyone is wondering when I will return to the genetic algorithm solutions to the Hales-Jewett related problems, I am sorry to say that it might be a month or two. However, if there is a specific aspect of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37279")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("1144. Implication of Behrend/Elkin for ")#mi("c_n^{\\mu}")#text(".")

#text("If ")#mi("n")#text(" is sufficiently large, then ")#mi("c_n^\\mu > n^2 2^{-4\\sqrt{2}\\sqrt{\\log n}+1/2 \\log \\log n -2}")#text(", where the ")#mi("log")#text("‘s are base 2.")

#text("I’ve posted the details to the wiki under “Hyper-optimistic conjecture” (")#link("http://michaelnielsen.org/polymath1/index.php?title=Hyper-optimistic_conjecture")[#text("http://michaelnielsen.org/polymath1/index.php?title=Hyper-optimistic_conjecture")]#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37280")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("1145. Gaps between primes")

#text("If I recall correctly, then the Riemann hypothesis implies that there is always a prime between ")#mi("n")#text(" and ")#mi("n^{1/2+\\epsilon}")#text(" (provided of course that ")#mi("n")#text(" is large enough, while the truth is believed to be that there is a prime between ")#mi("n")#text(" and ")#mi("n + C (\\log n)^2")#text(", and some people have guessed ")#mi("C=1")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37283")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("1146. Hyper-optimistic conjecture extended beyond 3")

#text("If the Hyper-optimistic conjecture is extended to 4, 5 etc I can prove it for some specific values.")

#text("Specifically I think I can prove it Hyper-optimistic conjecture for all the values k greater than d where k is prime as in 1140, the key is every incidence is exactly one and every incidence is of minimum weight on the lines consisting of x repeated d times x followed by d-1 a’s not divisible by the prime k, x followed by d-2 a’s not divisible by the prime k etc these lines will have to be blocked somehow and this can only be done at greater or equal cost. So for the extension of this conjecture beyond 3 we have that it holds true for primes p for values less than or equal to p.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37284")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("1147. Hyper-optimistic conjecture extended beyond 3")

#text("The previous anonymous comment was by me, I forgot to include my information.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37300")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("1148. Extending Hyper-optimistic conjecture")

#text("To extend this conjecture we need to define a weight beyond 3")#linebreak()#text(" we do this by letting the weight of a point with a ones b twos c threes")#linebreak()#text(" and d fours to be a!b!c!d!/a+b+c+d! Similarly we can add e for 5 f for6")#linebreak()#text(" the general pattern should be clear.")#linebreak()#text(" We also need to extend slices thus in the case of k=4 we add a d which is the number of 4’s in the slice similarly we add an e in the case of k=5. The extension of the conjecture would that the maximal weight is realized by a set of slices.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37301")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("1149.")

#text("Klas,")

#text("I will look into it. I did not have much time last week but things are opening up now.")

#text("Kareem")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37302")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("1148. Extending Hyper-optimistic conjecture")

#text("I am going to try to prove part of the result I tried to prove in 1146, there is at least one mistake.")

#text("I want to prove that if p is a prime and d is a dimension less than p and the Hyper-optimistic conjecture is extended as in 1148 for p then for the specific values of d")#linebreak()#text(" less than p the Hyper-optimistic conjecture is true.")

#text("To try to prove this try we remove all points whose sum is divisible by p, then since permuting the coordinates will not change the sum this is a set of slices we only need to prove it is minimal in weight and it covers all combinatorial lines. So I have it is a set of slices.")

#text("It covers all combinatorial lines because the line since d is less than p must increase by a number less than p hence all values modulo p will be realized including p and we are done. So I have it covers all combinatorial lines.")

#text("I still need to prove the weight is minimal though to get the result I want.")#linebreak()#text(" I thought I could do this in 1146 but what I wrote did not work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37310")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("1149. Gaps between primes.")

#text("There is a later improvement of the gap result.")

#text("Baker, R. C.(1-BYU); Harman, G.(4-LNDHB); Pintz, J.(H-AOS)")#linebreak()#text(" The difference between consecutive primes. II.")#linebreak()#text(" Proc. London Math. Soc. (3) 83 (2001), no. 3, 532–562.")

#text("Here they find a prime in [x-x^{0.525},x]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37327")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2009")])]

#text("1150. Dimension 2, any k")

#text("The number of optimal solutions is ")#link("http://www.research.att.com/~njas/sequences/A002467")[#text("this sequence")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37343")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2009")])]

#text("1151. Bounds on c_n from Fujmura.")

#text("Has anyone calculated which lower bounds for c_n we get from the optimal solutions to Fujimura’s problem I constructed a while ago?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37392")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2009")])]

#text("1152. Bounds on c_n from Fujmura.")

#text("I have gone back to the posts 923 through 927 where you gave some of these solutions. I didn’t find any improvement to our current bounds. I think to go over some of these solutions the process will have to be automated since there are a lot of solutions in some cases. Possibly we might be able to improve some of the bounds at higher levels by going through all the cases.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37394")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2009")])]

#text("1153. Bounds on c_n from Fujmura.")

#text("Yes for the smaller n we might actually already have the optimal values, but for higher n we could possibly get better bounds than we get from the bounds for general n.")

#text("Does anyone want to volunteer to automate this?")

#text("I can probably find the full set of optimal solutions to Fujimura’s problem for a few more values of n too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37395")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2009")])]

#text("1154.")

#text("Do we have any “hand made” values for small n for the quadruple version of Fujimura’s problem Kristal suggested?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37400")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2009")])]

#text("1156. Higher-dimensional Fujimura")

#text("for k=4:")

#text("When n=2, the largest triangle-free set is trivially 2 (remove for example 1000 and 0100).")

#text("When n=3, the largest triangle-free set is 6 (remove 0200, 1010, 1001, 0011). Proof: One of 2000, 0200, 0020 must be removed — say it is 0200, and note by symmetry the logic that follows will apply if 2000 or 0020 is removed. There are three disjoint triangles (1010-0110-0020, 2000-1100-1001, 0002-0101-0011) which must all have at least one removal, so the minimal number of removals is 4, so we have proven our solution to be optimal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37401")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2009")])]

#text("1157. Higher-dimensional Fujimura")

#text("Oops, my n=3 is wrong. Higher dimensions are tricky: I left 2000-0020-0002 open. Let me fiddle and come back.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37402")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2009")])]

#text("1158. Higher-dimensional Fujimura")

#text("Do over!")

#text("When n=3, the largest triangle-free set is 6 (remove 2000, 0200, 0020, 0002). Proof: One of 2000, 0200, 0020 must be removed — say it is 0200, and note by symmetry the logic that follows will apply if 2000 or 0020 is removed. There are three disjoint triangles (1010-0110-0020, 2000-1100-1001, 0002-0101-0011) which must all have at least one removal, so the minimal number of removals is 4, so we have proven our solution to be optimal.")

#text("Note this not only leaves “upside down” triangles but “lateral” triangles like 1100-1010-0010, but none seem to form a combinatoric line.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37410")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2009")])]

#text("1159. Higher-dimensional Fujimura")

#text("My n are one off from our convention, I of course mean:")

#text("When k=4 and n=1, the largest triangle-free set is 2.")#linebreak()#text(" When k=4 and n=2, the largest triangle-free set is 6.")

#text("I believe that when k=4 and n=3, the largest triangle free set is 12, but I do not have a proof yet.")

#text("The lower bound is 6(n-1), using the exact same pattern on each face of the tetrahedron as general n bound with the k=3 case.")

#text("We also need a symbol to represent the problem. It’s tempting to use ")#mi("\\overline{\\overline{c}}^\\mu_n")#text(" for k=4 but we might be working with larger k (making the stack rather large).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37411")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2009")])]

#text("1160. Lower bounds on line-free sets")

#text("There are ")#mi("k^{n-1}")#text(" disjoint lines *abcd..m, so the density of removed points must be at least 1/k, and retained points at most (k-1)/k.")#linebreak()#text(" If ")#mi("n \\le p \\le k")#text(" then one can get a density of (p-1)/p by deleting points whose coordinates sum to a multiple of p.")#linebreak()#text(" The lower bound (p-1)/p approaches (k-1)/k as ")#mi("k\\rightarrow \\infty")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37414")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2009")])]

#text("1161. Tetrahedron geometry")

#text("In the k = 3 case of Fujimura things get tricky when n >= 3 because the internal points in the tetrahedral lattice must be considered. I believe my early lower bound was too hasty.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37424")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2009")])]

#text("1162. k=4 Fujimura")

#text("Now I see where my problem has been, we need the tetrahedron-free set to match combinatoric lines, not the triangle-free set.")

#text("So n=1 would just be one removal and a set size of 3.")#linebreak()#text(" and n=2 would be two removals (say, 1100 and 0002) and a set size of 8.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37425")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2009")])]

#text("1162. Higher-dimensional Fujimura")

#text("Jason, are you considering triangles or squares? I’m just wondering if you are looking at the problem Kristal posted at Tim’s blog or a different version?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37426")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2009")])]

#text("It seems you answered my question while I was writing it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37438")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2009")])]

#text("1163. Fixing k=4 Fujimura")

#text("Just in case I make any more mistakes I will putting current progress for now ")#link("http://michaelnielsen.org/polymath1/index.php?title=Talk:Fujimura%27s_problem")[#text("on the talk page of the Wiki")]#text(".")

#text("The current values I have now (barring any further mistakes *cough*) are:")

#text("n = 0, largest set of 1")#linebreak()#text(" n = 1, largest set of 3")#linebreak()#text(" n = 2, largest set of 7")

#text("I’m using ")#mi("\\overline{\\overline{c}}^\\mu_n")#text(" for now (until we decide on a better notation).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37439")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2009")])]

#text("1164. HJ(3,3) is greater than 7")

#text("For a fixed r and k, the least n needed for the Hales-Jewett theorem to apply is denoted HJ(k,r).")#linebreak()#text(" See ")#link("http://michaelnielsen.org/polymath1/index.php?title=Coloring_Hales-Jewett_theorem")[#text("http://michaelnielsen.org/polymath1/index.php?title=Coloring_Hales-Jewett_theorem")]#linebreak()#text(" Currently we have:")

#text("HJ(3,1) = 1")#linebreak()#text(" HJ(3,2) = 4")#linebreak()#text(" HJ(3,3) > 6")

#text("We start with the set formed by removing (0,1,6), (1,0,6), (0,5,2), (5,0,2) , (1,5,1), (5,1,1),(1,6,0), (6,1,0) from D_7.")#linebreak()#text(" Note that none of (0,1,6), (1,0,6), (0,5,2), (5,0,2) , (1,5,1), (5,1,1),(1,6,0), (6,1,0)contains a point whose coordinate sum is divisible by three we give it color 1")#linebreak()#text(" where (a,b,c) is shorthand for the slice Γ_a,b,c.")#linebreak()#text(" It is combinatorial line free from the n=7 section of the upper and lower bounds wiki at")#linebreak()#text(" ")#link("http://michaelnielsen.org/polymath1/index.php?title=Upper_and_lower_bounds#n.3D7")[#text("http://michaelnielsen.org/polymath1/index.php?title=Upper_and_lower_bounds#n.3D7")]

#text("then we divide the remaining points into all points whose coordinate sum is not equal to 0 mod 9 and")#linebreak()#text(" all points of (0,1,6), (1,0,6), (0,5,2), (5,0,2) , (1,5,1), (5,1,1),(1,6,0), (6,1,0)whose coordinate sum is equal to 1 mod 3 We give these color 2")

#text("then we take all points of (0,1,6), (1,0,6), (0,5,2), (5,0,2) , (1,5,1), (5,1,1),(1,6,0), (6,1,0)whose coordinate sum equal to 2 mod 3 and those points")#linebreak()#text(" whose sum is equal to 0 mod 9. We give these color 3.")

#text("Then with this coloring there are nor monochromatic lines. If there are any monochromatic")#linebreak()#text(" Lines with number of moving coordinates not divisible by three in color 2 they must contain point whose coordinate sum is equal to 2 mod three")#linebreak()#text(" But there are no such points with color 2. If there are any monochromatic lines whose coordinate sum is divisible by three")#linebreak()#text(" Than they must contain points whose coordinate sum is 0 mod 9 but there are no such points with color 2. So there")#linebreak()#text(" Are no monochromatic combinatorial lines with color 2.")

#text("If there are any monochromatic")#linebreak()#text(" Lines with number of moving coordinates not divisible by three in color 3 they must contain point whose coordinate sum is equal to 1 mod three")#linebreak()#text(" But there are no such points with color 3. If there are any monochromatic lines whose coordinate sum is divisible by three")#linebreak()#text(" Than they must contain points whose coordinate sum is not 0 mod 9 but there are no such points with color 3.")

#text("As already noted color 1 is combinatorial line free and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37440")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2009")])]

#text("1165. Bounds on c_n from Fujmura.")

#text("I have been looking at the upper bounds that we have and I think some of them come from lower bounds from Fujimura problem so I think that improvements to this problem could give better bounds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37467")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2009")])]

#text("1166. Higher-dimensional Fujimura")

#text("Jason, how about using ")#mi("\\bar{c}^{\\mu}_{n,k}")#text(" where k is the size of the tuples, or the dimension of the Z^k used?")#linebreak()#text(" The original Fujimura problem would correpspond to ")#mi("\\bar{c}^{\\mu}_{n,3}")#text(" and the quadruple version to ")#mi("\\bar{c}^{\\mu}_{n,4}")

#text("You get a non-constructive quadratic lower bound for the quadruple problem by taking a random subset of size ")#mi("c n^2")#text(". If c is not too large the linearity of expectation shows that the expected number of tetrahedrons in such a set is less than one, and so there must be a set of that size with no tetrahedrons.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37470")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2009")])]

#text("1167. ")#mi("\\overline{c}^\\mu_{n,4}")

#text("Klas, I have adopted your notation and added your non-constructive bound ")#link("http://michaelnielsen.org/polymath1/index.php?title=Talk:Fujimura's_problem")[#text("to the talk page")]#text(".")

#text("Should this be merged into the regular page or should we be making a separate one for the k > 3 cases?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37481")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2009")])]

#text("1168. ")#mi("\\overline{c}^\\mu_{n,4}")

#text("if the coordinates of points (a,b,c,d), then a+2b+3c is a four-term arithmetic progression for any of these tetrahedrons.")#linebreak()#text(" We include slices a+2b+3c = constant.")#linebreak()#text(" ")#link("http://arxiv.org/PS_cache/arxiv/pdf/0811/0811.3057v2.pdf")[#text("http://arxiv.org/PS_cache/arxiv/pdf/0811/0811.3057v2.pdf")]#text(" this paper shows that the proportion of slices included can be at least")#linebreak()#text(" ")#mi("C\\frac{(log N)^{1/4}}{2^{2\\sqrt{2 log N}}}")#text(" for some constant C.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37482")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2009")])]

#text("1169. ")#mi("\\overline{c}^{\\mu}_{n,k}")

#text("Michael, this should give a lower bound for general k as well.")#linebreak()#text(" Likewise the counting argument gives an upper bound for general k too.")

#text("It is also possible to use a triangle-free set to build a tetrahedron-free set for a larger value of n, but I’m not sure how efficient such constructions can be made.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37485")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2009")])]

#text("1170. ")#mi("\\overline{c}^{\\mu}_{n,k}")

#text("In general for ")#mi("\\overline{c}^{\\mu}_{n,k}")#text(" the series a + 2b + 3c+…")#linebreak()#text(" continued to k-1 terms will be a k-term arithmetic progression for")#linebreak()#text(" the points of any configuration (a+r, b,..), (a,b+r .. which is the generalization")#linebreak()#text(" of an upward triangle, an upward k-1 dimensional simplex. So as in 1160")#linebreak()#text(" for the case k=4")#linebreak()#text(" we can get a formula in this case the general formula from the paper")

#link("http://arxiv.org/PS_cache/arxiv/pdf/0811/0811.3057v2.pdf")[#text("Click to access 0811.3057v2.pdf")]

#text("and we get if k is greater than 2^n +1")#linebreak()#text(" ")#mi("C\\frac{\\sqrt[2n]{log N}}{2^{n2^{(n-1)/2}\\sqrt[2n]{log N}}}")#linebreak()#text(" This is actually a set of formulas as n will have to be chosen given k")#linebreak()#text(" it is the greatest integer less than log base 2 of k-1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37521")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("1171. 4D Moser")

#text("If a Moser set has 4 points with 3 2’s and its size is 41")#linebreak()#text(" or more then it must not have two sets of two points with three twos with")#linebreak()#text(" the same c statistic.")

#text("To prove this assume that it is true then we must have two")#linebreak()#text(" points without lost of generality of the form x222 then")#linebreak()#text(" one must have one in the first position the other must")#linebreak()#text(" have 3 we can then cut at the first coordinate and get")#linebreak()#text(" the side slices must have 13 or less points which means")#linebreak()#text(" that the center slice must have 15 or more points and")#linebreak()#text(" the remaining two points of the form say 2×22 are in the")#linebreak()#text(" center cube so we can slice and the side squares have")#linebreak()#text(" The center spot occupied that means that total number")#linebreak()#text(" of points in the center cube with one coordinate equal")#linebreak()#text(" to 2 in the cube and two in the configuration must be")#linebreak()#text(" At most 8 two each from the side squares since the center")#linebreak()#text(" spot is occupied and possibly all 4 from the center square.")

#text("Then form the Pareto optimal statistics in section n=3")#linebreak()#text(" of the Moser wiki")#linebreak()#text(" and the fact the center cube has 15 points and has c=2")#linebreak()#text(" we have the statistics of the center")#linebreak()#text(" slice must be (4,9,2,0) but from the above we have")#linebreak()#text(" At most 8 points with one coordinate equal to 2 so we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37527")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("1172. ")#mi("c_{n,k}")

#text("I suppose it is reasonable to call ")#mi("c_{n,k}")#text(" the size of the largest line-free subset of ")#mi("[k]^n")#text(". Thus ")#mi("c_n = c_{n,3}")#text(".")

#text("Sperner’s theorem tells us that ")#mi("c_{n,2} = \\binom{n}{\\lfloor n/2\\rfloor}")#text(". We have ")#mi("c_{n,1}=0")#text(" so let’s forget about the k=1 case.")

#text("Dyer.1137, Markstrom.1139 show that ")#mi("c_{n,k} = (k-1) k^{n-1}")#text(" for n=1,2,3 (one needs k at least 3 when n=3), while Peake.1140 shows that this is also the case for n up to k if k is prime. Kristal has various modifications of this in the non-prime case.")

#text("Here is a naive conjecture: the above are the ")#emph[#text("only")]#text(" values of (n,k) for which one has ")#mi("c_{n,k} = (k-1) k^{n-1}")#text(" (i.e. exactly one point deleted from each row or column), thus if n is at least 4 and k is composite then ")#mi("c_{n,k}")#text(" has to be strictly less than ")#mi("(k-1) k^{n-1}")#text(". Actually it suffices to check this claim for n=4 since ")#mi("c_{n+1,k} \\leq k c_{n,k}")#text(".")

#text("Klas’s tables at ")#link("http://abel.math.umu.se/~klasm/Data/HJ/")[#text("http://abel.math.umu.se/~klasm/Data/HJ/")]#text(" indeed show that ")#mi("c_{4,k} < (k-1) k^3")#text(" for k=4,6.")

#text("When k=3 we obtained this inequality by exploiting the fact that there was a unique 3D line-free set with ")#mi("(k-1) k^2")#text(" points. Unfortunately, as Klas’s tables show, this is no longer the case in higher D, but perhaps we can still understand the 3D extremisers well enough to settle this conjecture (e.g. do they all correspond to Latin squares as in Markstrom.1139?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37528")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("1173. HJ(k,r)")

#text("Kristal, that’s a nice lower bound construction for HJ(3,3), which is better than the existing bound in the literature; I put it on the wiki. One may hope to get some better asymptotic bounds for HJ(n,k) too, by leveraging Behrend sets or something. There is a way to use the Behrend construction to colour [n] with relatively few colours in such a way that there are no monochromatic arithmetic progressions, which should then lift to HJ by the same sorts of methods as in, say, 1170. There should also be some existing lower bounds on HJ(n,k) in the literature, though I don’t have them on hand right now…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37534")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("1174. ")#mi("c_{n,k}")

#text("In between baby holdings, so I don’t have time to check the lemma on this, but:")

#text("For proving the n=4 case you cite for all k, wouldn’t it suffice to form some sort of controlled exchange between coordinate positions such that the number of combinatorial lines is never increased? Therefore any configuration hopeful of finding ")#mi("c_{4,k} = (k-1)k^3")#text(" can be shuffled to the diagonal, which is clearly not a line-free set?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37535")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("1175. HJ(k,r)")

#text("I found this pre-print:")

#link("http://www.math.ucsd.edu/~etressle/hj32.pdf")[#text("Click to access hj32.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37536")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("1176. ")#mi("c_{n,k}")

#text("Wait, can’t we just immediately shift all the points to the diagonal and claim that for each point the number of intersecting combinatorial lines has to either stay the same or increase? The maximal intersections are clearly where you have a maximal number of possible wildcards, that is, the largest number of identical coordinates that can be substituted by the * wildcard. Shifting everything immediately to the diagonal does not necessarily cause an increase of intersections in a particular point (since now the blocking of the diagonal is duplicated in every point) but it can’t cause a decrease, either, since the highest possible duplication for each point is 1 line.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37537")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("1175. k=4 Fujimura")

#text("I think this is 12. Taking all slices for which a +2b+3b is one of three different values mod 5 gives this as any arithmetic progression a +kr in this set must have r less than 4, so the four values in the arithmetic progression will have four different values mod 5 so this set of slices will not contain any tetrahedrons and 3/5 of 20 is 12 so we have 12 works.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37538")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("Metacomment.")

#text("I have made a new page for ")#link("http://michaelnielsen.org/polymath1/index.php?title=Higher-dimensional_Fujimura")[#text("higher-dimensional Fujimura")]#text(" and moved the content from the talk page (although not deleted it yet).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37539")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("1177. k=4 Fujimura")

#text("I think this is 12 for k=4, n=3. I didn’t give the value of n in the previous post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37540")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("1178. HJ(p,2)")

#text("Let p be prime then HJ(p,2) is greater than p-1.")#linebreak()#text(" We take p-1 values mod p and let them be one color")#linebreak()#text(" and let the remaining value take the other color, then")#linebreak()#text(" each combinatorial line with less than p moving coordinates")#linebreak()#text(" will run through all values mod p and hence will not be monochromatic")#linebreak()#text(" so we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37541")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("1179. HJ(n,2)")

#text("From post 1149 we get this reference")#linebreak()#text(" Baker, R. C.(1-BYU); Harman, G.(4-LNDHB); Pintz, J.(H-AOS)")#linebreak()#text(" The difference between consecutive primes. II.")#linebreak()#text(" Proc. London Math. Soc. (3) 83 (2001), no. 3, 532–562.")

#text("Here they find a prime in [x-x^{0.525},x]")#linebreak()#text(" so HJ(n,2) will be greater than n-n^.525-1 as we can find a prime and")#linebreak()#text(" use the above argument namely take p-1 values of the prime in color")#linebreak()#text(" and the remaining value in a second color and as long as the number")#linebreak()#text(" of moving coordinates in the combinatorial line is less than p all values")#linebreak()#text(" will be realized mod p and we will have the combinatorial line not monochromatic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37542")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("1180. HJ(n,2)")

#text("HJ(n,2) is greater than 2n-(2n)^{0.525}.")

#text("We can find a prime less than 2n greater than 2n-(2n)^{0.525}")#linebreak()#text(" as in the previous post")#linebreak()#text(" then we divide the classes modulo this prime into two nearly equal classes")#linebreak()#text(" there may be a disparity of one between them both classes will have")#linebreak()#text(" cardinality less than n we give color 1 to one class and two to the other, the combinatorial lines smaller than or equal to 2n-(2n)^{0.525}")#linebreak()#text(" will realize different values modulo that prime for each point there are n points in a combinatorial line so we must have members of both classes and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37544")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("1181. HJ(n,m)")

#text("HJ(n,m) is greater than mn-(mn)^{0.525}")

#text("We can find a prime less than mn greater than mn-(mn)^{0.525}")#linebreak()#text(" as in 1179")#linebreak()#text(" then we divide the classes modulo this prime into m nearly equal classes")#linebreak()#text(" there may be a disparity of one between them All classes will have")#linebreak()#text(" cardinality less than n we give one color to each class, the combinatorial lines smaller than or equal to mn-(mn)^{0.525}")#linebreak()#text(" will realize different values modulo that prime for each point, there are n points in a combinatorial line so we must have members of more than one class and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37547")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("1182. ")#mi("c_{n,k} = (k-1) k^{n-1}")

#text("For n= 35 ")#mi("c_{35,4} = 34 \\times 35^{3}")#linebreak()#text(" To see this select one value modulo 35 and eliminate it.")#linebreak()#text(" Combinatorial lines with one, two, three or four moving coordinates will")#linebreak()#text(" realize all values modulo 35 as one, two, three, or four are units modulo 35.")#linebreak()#text(" This generalizes in the following way:")#linebreak()#text(" ")#mi("c_{n,k} = (k-1) k^{n-1}")#linebreak()#text(" if k is less than all divisors of n.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37548")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("1183. ")#mi("c_{n,k} = (k-1) k^{n-1}")

#text("That should be for n= 35 c_{35,4} = 34*35^{3} ")#emph[#text(" [Corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37556")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("1182. Fujimura k=4")

#text("I’ve had my program running during the weekend and it reports the following values for Fujimura’s problem with k=4")

#text("d=2 size 7")#linebreak()#text(" d=3 size 14")#linebreak()#text(" d=4 size 24")#linebreak()#text(" d=5 size 37")#linebreak()#text(" d=6 size 55")#linebreak()#text(" Right now it has a lower bound of 78 for d=7")

#text("I’ll update my table page and put the solutions there too.")

#text("Jason, congratulations on your baby!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37557")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1185. HOC k=4")

#text("Unless I have messed something up this is a line free set with weight 7.5 in the n=2, k=4 version of the HOC")

#text("{{1, 1}, {1, 2}, {1, 3}, {2, 1}, {2, 3}, {2, 4}, {3, 2}, {3, 3}, {3,")#linebreak()#text(" 4}, {4, 1}, {4, 2}, {4, 4}}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57785d9b4bc8e25821f692ee3d435bb796adfed7394ad4ed0e523e2ca28c2248-7fa311f9e8852af89c8f8bbee0f6630fd2a26ed5a470dbfc0120dfbb7d2d752e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ks")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37560")[#strong[#text("ks")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1186 HOC: ")#mi("c_{n,k} \\ge \\bar{c}_{n,k}")

#text("I agree with 1185. One can still considers the alternate HOC. In the")#linebreak()#text(" original ")#mi("k=3")#text(" case, let ")#mi("\\bar{c}_n")#text(" be the maximal")#linebreak()#text(" weighted triangle-free subset of ")#mi("\\Delta_{n}")#text(" with ")#mi("(a,b,c)")#text(" weighted by ")#mi("n!/(a!b!c!)")#text(". Then we have ")#mi("c_n \\ge \\bar{c}_n")#text(" and equality holds for ")#mi("n \\le 6")#text(" (when ")#mi("c_n")#text(" is known). The more natural HOC is perhaps ")#mi("c_n=\\bar{c}_n")#text(" i.e. the optimal line free sets are union of slices")#linebreak()#text(" (both sides are integers now). For ")#mi("k=4")#text(", by 1182,1185 we have")#linebreak()#text(" ")#mi("c^\\mu_{2,4}=7.5> \\bar{c}^\\mu_{2,4}=7")#text(" but we still have")#linebreak()#text(" ")#mi("c_{2,4}=\\bar{c}_{2,4}=12")#text(" by Klas’s example in 1185 and")#linebreak()#text(" Jason’s example ")#mi("\\Delta_n-\\{0002,0020,1100\\}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37561")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1187. ")#mi("c_{n,k}")

#text("Well, so much for the naive conjecture… but it does make me curious now to figure out exactly what pairs of n,k admit “saturated” configurations, i.e. line-free sets of size ")#mi("(k-1) k^n")#text(". Right now the set of such “saturated” pairs includes")

#text("* (n,1) for all n [this is trivial]")#linebreak()#text(" * (1,k) for all k >= 1")#linebreak()#text(" * (2,k) for all k >= 1")#linebreak()#text(" * (3,k) for all k >= 3")#linebreak()#text(" * (n,k) whenever n is less than all divisors of k [note there is a notational mismatch in 1182]")#linebreak()#text(" * not (4,4) or (4,6)")

#text("So I guess the first unknown cases are (4,8) and then (4,9).")

#text("I’ve moved the higher-d DHJ numbers data to their own page on the wiki at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Higher-dimensional_DHJ_numbers")[#text("http://michaelnielsen.org/polymath1/index.php?title=Higher-dimensional_DHJ_numbers")]

#text("it could still do with some editing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-2/#comment-37566")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("1188. Regarding ")#mi("c_{4,k}")

#text("I split the ")#mi("k^4")#text(" points into five sorts of points: xyzw, xxyz, xxyy, xxxy and xxxx, where different letters represent different digits.")

#text("Then there are seven sorts of lines: *xyz, *xxy,*xxx, **xy, **xx, ***x, ****.")

#text("Linear inequalities connect the number of each type of point to each type of line. For example, each xxyz point covers two *xyz lines, two *xxy lines and one **xy line. The maximum number of *xyz lines removed is 4*number of xyzw points + 2*number of xxyz points.")

#text("If there is a solution with ")#mi("k^3")#text(" missing points, there must be")#linebreak()#text(" *(k-1)(k-2)(k-3) missing xyzw points")#linebreak()#text(" *6(k-1)(k-2) missing xxyz points")#linebreak()#text(" *3(k-1) missing xxyy points")#linebreak()#text(" *4(k-1) missing xxxy points")#linebreak()#text(" *1 missing xxxx point.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36708")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2009")])]

#text("1100. Moser & Elkin")

#text("Michael, thanks for the corrected inequalities at 993. I plugged them into the linear program, of course, but unfortunately the bounds did not budge, only the extremisers, which means that we chipped away a little bit but not as much as before. I can imagine that there is a law of diminishing returns in play here.")

#text("Kevin: thanks very much for the precise computation! I put it on the wiki at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Upper_and_lower_bounds#Asymptotics")[#text("http://michaelnielsen.org/polymath1/index.php?title=Upper_and_lower_bounds#Asymptotics")]

#text("but I suppose it could be cleaned up more. (Actually, the same holds for just about everything else on the wiki.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36709")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2009")])]

#text("1101. Hyper-optimistic conjecture")

#text("Kristal and Jason: looks like we’re off to a good start with the human proof of ")#mi("c^\\mu_3=6")#text(". I copied Kristal’s text to the wiki at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Hyper-optimistic_conjecture")[#text("http://michaelnielsen.org/polymath1/index.php?title=Hyper-optimistic_conjecture")]

#text("but presumably we could develop it further.")

#text("Given how successful the linear programming method based on sphere densities has been for Moser, I think it is worth a shot at working out linear inequalities for slice densities for the HOC; indeed one can view Kristal’s argument as implicitly using these slice densities.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36710")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2009")])]

#text("1102. Genetic algorithm")

#text("Kareem, I put some of the description of your GA on the wiki at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Genetic_algorithm")[#text("http://michaelnielsen.org/polymath1/index.php?title=Genetic_algorithm")]

#text("If you had any further commentary (e.g. on the performance of the algorithm, and links to data) that would be great. Do you still think that verification of the line-free property is the bottleneck? One thought I had on this was to break up the lookup table into pieces, and only apply a piece of the table to each organism. The problem with this though is that it may allow organisms with one or two lines to survive for a bit longer than they should.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36711")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2009")])]

#text("1103. Kakeya")

#text("Seva, this is a great suggestion! I transcribed your post to the wiki at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Kakeya_problem")[#text("http://michaelnielsen.org/polymath1/index.php?title=Kakeya_problem")]

#text("A recent result of Dvir, Kopparty, Saraf, and Sudan show that a Kakeya set in ")#mi("F_q^n")#text(" has size at least ")#mi("q^n/2^n")#text(", while an earlier example of Dvir (and reproduced in an appendix of a paper by Saraf and Sudan) constructs a Kakeya set of size ")#mi("2^{n-1} q^n + O(q^{n-1})")#text(". These are asymptotically tight to within a factor of 2 when q is large, but it doesn’t look like it works all that well for small q.")

#text("So, we have a new low-dimensional problem to chew on: is ")#mi("k_4=27")#text(" (i.e. is it impossible to have a 26-point set in [3]^4 that contains a line in every direction)? I guess a starting point would be to get a human proof of ")#mi("k_3=13")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36713")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2009")])]

#text("1104.")

#text("Thanks Terry. I don’t have a lot of time right now but I will add any extra commentary in a few days.")

#text("I am not completely sure that the line-free property is the bottleneck with respect to the speed of the program but it is probably a big contributor. I will have to do some experimenting. The line-free property causes limitations in several senses. It grows exponentially with n. The largest lookup table I have made is about half a gigabyte. It takes a long time to read into memory. If I only take part of it then I do think that could speed things up tremendously. One could squeeze some more speed up out of this idea by picking a random selection of lines in the lookup table and evaluating a whole generation with the same lines. This reduces cache misses. If it’s not the same group of lines each time then maybe this won’t hurt us too much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36714")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2009")])]

#text("1105. c^{\\mu}_3=6")

#text("I have made some changes to one of the cases, that case is")#linebreak()#text(" where there is one point removed of the form aaa")

#text("c^{\\mu}_3=6")#linebreak()#text(" If we have all")#linebreak()#text(" Three points of the form xxx removed")#linebreak()#text(" Then the remaining points have value 7 and")#linebreak()#text(" We have covered all lines any set of moving coordinates")#linebreak()#text(" And all constant points equal to one value this leaves")#linebreak()#text(" The lines xab a,b not equal. Each point of the set")#linebreak()#text(" abc covers three of these lines the entire set covers each of these lines")#linebreak()#text(" there is no duplication the only alternative is to remove a point")#linebreak()#text(" abc and cover the lines with points of the form aab which have")#linebreak()#text(" a higher weight and only cover one line each this would lower the weight")#linebreak()#text(" so the maximum weight occurs when all of abc is omitted along with")#linebreak()#text(" the three points xxx and the weight is 6")

#text("If we have only two points removed of the form xxx then")#linebreak()#text(" The weight is at most 8 say the point not removed is 222")#linebreak()#text(" Then we must cover the lines xx2 and x22 we have three six such")#linebreak()#text(" Lines and all the xx2 must be covered one at a time by either 112")#linebreak()#text(" Or 332 the x22 must be covered one at a time by 322 or 122")#linebreak()#text(" These points must be removed and the that lowers the weight")#linebreak()#text(" To 8 – 3*(2/6) – 3*(2/6) = 6 again we have c^{\\mu} must be less than 6")

#text("If 111 is removed")#linebreak()#text(" then we must cover all lines of")#linebreak()#text(" the form xx2 xx3 and x22 and x33")

#text("Look at the pairs of lines such as xx2 and 33x")#linebreak()#text(" one with moving coordinates in two positions and")#linebreak()#text(" a fixed coordinate equal to 2 or 3 say 2")#linebreak()#text(" the other with fixed coordinates equal to the other")#linebreak()#text(" value which in this case is 2 so if the fixed coordinate(s)")#linebreak()#text(" in one point of the pair is 2 in the other they or it will")#linebreak()#text(" Then we must have one of the points 222")#linebreak()#text(" 112 332 removed to block the first line of the pair")#linebreak()#text(" and for the second line we can use 333")#linebreak()#text(" 332 331. However we do not have the points")#linebreak()#text(" 222 or 333 removed in this case so we must have")#linebreak()#text(" either 332 or the pair 112 or 331.")#linebreak()#text(" For every one of the six point 332 or 223")#linebreak()#text(" we will have a similar choice forcing either")#linebreak()#text(" the removal of the point itself or the associated")#linebreak()#text(" pair. After these choices have been made more points")#linebreak()#text(" of the form aab can be added but there must be")#linebreak()#text(" a subset corresponding to one set of the above six choices")#linebreak()#text(" since in each case there are only two ways to cover the lines noted.")#linebreak()#text(" If we start with the configuration 111 removed all six points with")#linebreak()#text(" two 2’s and one three and two 3’s and one two removed and all points of")#linebreak()#text(" the form abc removed then this configuration has weight 6")#linebreak()#text(" then we can perform a series of steps which will")#linebreak()#text(" reach all combinatorial line free configurations.")

#text("These steps are as follows:")

#text("1 Making choices as above and allowing the addition")#linebreak()#text(" Of all possible abcs")

#text("2.Removal of points of the form aab and addition of all possible abc’s")

#text("3.Removal of abc")

#text("It will be shown that with each step the weight decreases or remains the same")#linebreak()#text(" so the weight is 6 or less")#linebreak()#text(" This will give all line free configurations as we must have sub configuration")#linebreak()#text(" corresponding to one of the six choices and all we can do is add points")#linebreak()#text(" of the form aab and take the resulting set with the most possible")#linebreak()#text(" Abc’s and them remove any arbitrary abcs that we wish to remove.")

#text("Are the making of the six choices noted above and the addition of")#linebreak()#text(" any points of the form abc where possible without forming a combinatorial line.")#linebreak()#text(" At the start each point of the form abc cannot be added because it has")#linebreak()#text(" two lines which are some permutations of x12 and x13 now")#linebreak()#text(" look at the points possibly blocking x12 they are 112 212 and 312 initially")#linebreak()#text(" point 312 which is removed could not be added because the two points")#linebreak()#text(" 112 and 212 are not removed as each choice is moved then each of the")#linebreak()#text(" removed lines of type 113 covers two lines of the form permutations of x13")#linebreak()#text(" similarly lines of type 133 covers two lines of the form permutations of x13")#linebreak()#text(" now each choice to replace a line of the form 332 increase the number of")#linebreak()#text(" points removed with two coordinates the same by one thus lowers the weight")#linebreak()#text(" by one third and blocks four lines of the form x13 or x12 thus after")#linebreak()#text(" n such choices we have reduced the weight by n/3 and covered 4n such")#linebreak()#text(" lines since every point of the of the form permutations of 123")#linebreak()#text(" starts out with 2 such lines which it is blocking and can only be added")#linebreak()#text(" when they are filled we can only add at most 2n such points which")#linebreak()#text(" since they have weight 1/6 at the end of n such steps the weight")#linebreak()#text(" is unchanged now afterwards if we remove more points of the form")#linebreak()#text(" aab they cover at most two lines of the form xab and thus allow")#linebreak()#text(" at most two points of the form abc to be added thus the change in weight")#linebreak()#text(" is at most -1/3 +1/6 +1/6=0 finally afterwards we can remove points")#linebreak()#text(" of the form abc but that will only lower the weight.")

#text("Finally we have no points of the form xxx removed but then we will")#linebreak()#text(" have a line of the form xxx")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36717")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2009")])]

#text("Metacomment: Logo")

#link("http://www.atariage.com/2600/boxes/b_3DTicTacToe_Color_front.jpg")[#text("A tongue-in-cheek suggestion.")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seva")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36719")[#strong[#text("Seva")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2009")])]

#text("1106. Here is a sketch of what, hopefully, can be developed into a human proof of ")#mi("k_3\\ge 13")#text(". The argument depends heavily on the fact that, applying a non-degenerate affine transformation to a Kakeya set, we get a Kakeya set. Let ")#mi("e_1=(1,0,0),e_2=(0,1,0),e_3=(0,0,1)")#text(" be the standard basis of ")#mi("{\\mathbb F}_3^3")#text(".")

#text("Suppose that ")#mi("K\\subset{\\mathbb F}_3^3")#text(" is a Kakeya set with ")#tao-math("\\left|K\\right|=12", block: false)#text(". For each of the ")#mi("(3^3-1)/2=13")#text(" directions in ")#mi("{\\mathbb F}_3^3")#text(" fix a line in this direction inside ")#mi("K")#text(". We thus have ")#mi("13")#text(" lines, with ")#mi("3")#text(" points on each line, resulting in ")#mi("39")#text(" point-line incidences — and just ")#mi("12")#text(" points; therefore, there is a point in ")#mi("K")#text(", incident with (at least) four lines. Shifting ")#mi("K")#text(" suitably, we assume that ")#mi("0\\in K")#text(" and ")#mi("K")#text(" contains four lines through ")#mi("0")#text(".")

#text("If all lines through ")#mi("0")#text(" in ")#mi("K")#text(" are contained in a subspace of dimension ")#mi("2")#text(", then ")#mi("K")#text(" actually contains this subspace, and without loss of generality we can assume that the subspace is ")#mi("{\\rm Sp}\\{e_1,e_2\\}")#text(". Fix a vector in ")#mi("K")#text(" outside this subspace; WLOG, this vector is ")#mi("e_3")#text(". Thus, ")#mi("K")#text(" consists of ")#mi("{\\rm Sp}\\{e_1,e_2\\}")#text(", ")#mi("e_3")#text(", and two more vectors, and the proof is easy to complete in this case showing that such a set cannot contain a line in every direction.")

#text("Therefore, the four lines through ")#mi("0")#text(" are not contained in a proper subspace. Hence, applying a suitable linear transformation, we can assume that the directions, determined by these lines, are ")#mi("e_1,e_2,e_3")#text(", and ")#mi("b")#text(", with some vector ")#mi("b\\in{\\mathbb F}_3^3")#text(" of weight at least ")#mi("2")#text(". (The weight of a vector for this purpose is the number of non-zero coordinates in its expansion in the standard basis.) That is, ")#mi("\\{0,\\pm e_1,\\pm e_2,\\pm e_3,\\pm b\\}\\subset K")#text(". If the weight of ")#mi("b")#text(" is ")#mi("3")#text(", then, changing the signs of the vectors of the standard basis as needed (which is a linear transformation, of course), we can assume ")#mi("b=e_1+e_2+e_3")#text("; similarly, if the weight of ")#mi("b")#text(" is ")#mi("2")#text(", then we can assume ")#mi("b=e_1+e_2")#text(".")

#text("We thus are left with two cases to consider, as follows. Case (A): ")#mi("K")#text(" consists of ")#mi("0,\\pm e_1,\\pm e_2,\\pm e_3, \\pm(e_1+e_2+e_3)")#text(", and three more vectors. Case (B): ")#mi("K")#text(" consists of ")#mi("0,\\pm e_1,\\pm e_2,\\pm e_3,\\pm(e_1+e_2)")#text(", and three more vectors. Hopefully, both these cases can be completed with some moderate effort.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36726")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2009")])]

#text("1107. Kakeya")

#text("I realised that I can import some existing arguments in the literature to get some better lower bounds on Kakeya in this low characteristic, high dimensional regime than the (3/2)^n bound from Dvir-Kopparty-Saraf-Sudan.")

#text("For instance, we can use the “bush” argument. There are ")#mi("N := (3^n-1)/2")#text(" different directions. Take a line in every direction, let E be the union of these lines, and let ")#mi("\\mu")#text(" be the maximum multiplicity of these lines (i.e. the largest number of lines that are concurrent at a point). On the one hand, from double counting we see that E has cardinality at least ")#mi("3N/\\mu")#text(". On the other hand, by considering the “bush” of lines emanating from a point with multiplicity ")#mi("\\mu")#text(", we see that E has cardinality at least ")#mi("2\\mu+1")#text(". If we minimise ")#mi("\\max(3N/\\mu, 2\\mu+1)")#text(" over all possible values of ")#mi("\\mu")#text(" one obtains approximately ")#mi("\\sqrt{6N} \\approx 3^{(n+1)/2}")#text(" as a lower bound of |E|, which is asymptotically better than ")#mi("(3/2)^n")#text(".")

#text("Or, we can use the “slices” argument. Let ")#mi("A, B, C \\subset ({\\Bbb Z}/3{\\Bbb Z})^{n-1}")#text(" be the three slices of a Kakeya set E. We can form a graph G between A and B by connecting A and B by an edge if there is a line in E joining A and B. The restricted sumset ")#mi("\\{a+b: (a,b) \\in G \\}")#text(" is essentially C, while the difference set ")#mi("\\{a-b: (a-b) \\in G \\}")#text(" is all of ")#mi("({\\Bbb Z}/3{\\Bbb Z})^{n-1}")#text(". Using an estimate from ")#link("http://front.math.ucdavis.edu/math.CO/9906097")[#text("my paper with Nets Katz")]#text(", we conclude that ")#tao-math("3^{n-1} \\leq \\max(\\left|A\\right|,\\left|B\\right|,\\left|C\\right|)^{11/6}", block: false)#text(", leading to the bound ")#tao-math("\\left|E\\right| \\geq 3^{6(n-1)/11}", block: false)#text(", which is asymptotically better still.")

#text("For an upper bound, I can invert the “slices” idea and use a construction of Imre Ruzsa. Let ")#mi("A, B \\subset [3]^n")#text(" be the set of strings with ")#mi("n/3+O(\\sqrt{n})")#text(" 1’s, ")#mi("2n/3+O(\\sqrt{n})")#text(" 0’s, and no 2’s; let ")#mi("C \\subset [3]^n")#text(" be the set of strings with ")#mi("2n/3+O(\\sqrt{n})")#text(" 2’s, ")#mi("n/3+O(\\sqrt{n})")#text(" 0’s, and no 1’s, and let ")#mi("E = \\{0\\} \\times A \\cup \\{1\\} \\times B \\cup \\{2\\} \\times C")#text(". From Stirling’s formula we have ")#tao-math("\\left|E\\right| = (27/4 + o(1))^{n/3}", block: false)#text(". Now I claim that for most ")#mi("t \\in [3]^{n-1}")#text(", there exists an algebraic line in the direction (1,t). Indeed, typically t will have ")#mi("n/3+O(\\sqrt{n})")#text(" 0s, ")#mi("n/3+O(\\sqrt{n})")#text(" 1s, and ")#mi("n/3+O(\\sqrt{n})")#text(" 2s, thus ")#mi("t = e + 2f")#text(" where e and f are strings with ")#mi("n/3 + O(\\sqrt{n})")#text(" 1s and no 2s, with the 1-sets of e and f being disjoint. One then checks that the line ")#mi("(0,f), (1,e), (2,2e+2f)")#text(" lies in E.")

#text("This is already a positive fraction of directions in E. One can use the random rotations trick to get the rest of the directions in E (losing a polynomial factor in n).")

#text("Putting all this together, I think we have")

#mi("(3^{6/11} + o(1))^n \\leq k_n \\leq ( (27/4)^{1/3} + o(1))^n")

#text("or")

#mi("(1.8207\\ldots+o(1))^n \\leq k_n \\leq (1.88988+o(1))^n")

#text("This seems consistent with your conjecture ")#mi("k_{n+1} \\leq 2k_n + 1")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seva")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36756")[#strong[#text("Seva")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2009")])]

#text("1108. Kakeya in ")#mi("F_3^r")

#text("Dear Terry,")

#text("As I see it, your 1107 post essentially solves the problem: the gap between the lower and upper bounds is not that large now, and narrowing it further may be both pointless and tedious (while finding a sharp asymptotic may be hopeless). I would also say that the values of ")#mi("k_r")#text(" for small ")#mi("r")#text(" are not of much interest now that ")#mi("\\limsup(\\ln k_r)/r<2")#text(" is known to hold.")

#text("A couple of minor remarks.")

#text("The “bush argument” gives the very same estimate as that indicated in my original post. Since this estimates supersedes the Dvir-Kopparty-Saraf-Sudan bound, I have not mentioned the latter.")

#text("For the estimate ")#mi("k_r\\gg 3^{0.51r}")#text(" mentioned in my post I used restricted addition and Balog-Szemeredi; so, the “slices argument” is kind of an improvement of what I did.")

#text("Also, for the slices argument: I don’t quite see why “the restricted sumset is essentially ")#mi("C")#text("“, but it is contained in ")#mi("-C")#text(", which is just fine for our purposes; correct?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36763")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2009")])]

#text("1109. Kakeya in ")#mi("F_3^r")

#text("Fair enough. It may still be interesting to know the dependence on the field size though. For each prime power q, let ")#mi("k_{q,r}")#text(" be the minimal size of a Kakeya set in ")#mi("F_q^r")#text(", then we know from submultiplicativity ")#mi("k_{q,r+s} \\leq k_{q,r} k_{q,s}")#text(" that ")#mi("k_{q,r}^{1/r}")#text(" converges to a limit ")#mi("\\kappa_q")#text(". For instance I think one can show that ")#mi("\\kappa_q = \\sqrt{2}")#text(", and we now know that ")#mi("1.82\\ldots \\leq \\kappa_3 \\leq 1.88\\ldots")#text(". What happens for other values of q? Dvir et al. show that ")#mi("\\kappa_q \\geq q/2")#text(" for all q, and of course ")#mi("\\kappa_q \\leq q")#text(". I don’t know which bound is closer to the truth.")

#text("Your Balog-Szemeredi argument, by the way, sounds very similar to the original slices argument of Bourgain in which my paper with Nets was based (and the Bourgain paper was in turn inspired by Tim Gowers’ paper on Szemeredi’s theorem, and in particular on his version of the Balog-Szemeredi lemma):")

#link("http://www.ams.org/mathscinet-getitem?mr=1692486")[#text("http://www.ams.org/mathscinet-getitem?mr=1692486")]

#text("In our language, the Bourgain argument would give ")#mi("k_r \\gg 3^{13r/25} = 3^{0.52 r}")#text(".")

#text("p.s. Yes, “contained in -C” is what I meant by “essentially C”. I got lazy and didn’t want to work out the exact relationship :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seva")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36767")[#strong[#text("Seva")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2009")])]

#text("1110. Kakeya in ${\\mathbb F}_3^r$ (in reply to 1109)")

#text("> Your Balog-Szemeredi argument, by the way, sounds")#linebreak()#text(" > very similar to the original slices argument of Bourgain")

#text("Not surprising: the idea to use this approach was actually suggested to me by Bourgain!")

#text("Also, upon some thinking. It seems that Ruzsa’s argument that you mention is not really about slices; it is about a clever modification of the construction from my initial post. Namely, instead of the set ")#mi("K")#text(" of all vectors in ")#mi("{\\mathbb F}_3^r")#text(" with either ")#mi("1")#text(", or ")#mi("2")#text(" missing among their coordinates, consider its subset ")#mi("K_0:=A\\cup B")#text(", where ")#mi("A")#text(" is the set of all those vectors with ")#mi("r/3+O(\\sqrt {r})")#text(" coordinates equal to ")#mi("1")#text(" and the rest equal to ")#mi("0")#text(", and ")#mi("B")#text(" is the set of all those vectors with ")#mi("2r/3+O(\\sqrt {r})")#text(" coordinates equal to ")#mi("2")#text(" and the rest equal to ")#mi("0")#text(". Then ")#mi("K_0")#text(", being of size just about ")#mi("(27/4)^{r/3}")#text(", contains lines in positive proportion of directions. No slices!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36774")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2009")])]

#text("1111. Moser sets n=4")

#text("If a Moser set for n=4 has 5 or more points with three 2’s it must have less than 41 points it must have the following statistics:")#linebreak()#text(" (7, 15, 14, 5,0), (6, 15, 15, 5,0)")

#text("I have already proved the case with 6 or more points cannot occur so all I need to do here is get the case n=5. We note that there cannot be a point with four 2’s as then we would have 39 points. We have 5 points with exactly three 2’s and one coordinate not equal to 2. That gives 5 values not equal to 2 and four coordinates one coordinate must have the coordinate value not equal to 2 from 2 of the five points. One value must be three the other one. We slice at this point and get two cubes with the center point filled which by the n=3 section of the wiki on Moser sets must have 13 points or less. Since there are 5 points with three 2’s the center slice must have the remaining three. Now if we have 41 or more points it must have a center slice equal to 15 points or more. However by the Pareto-optimal statistics in the section n=3 of the wiki we see that a cube with c greater than three can have value at most 15. Further it must have the statistics (3,9,3,0) The two side cubes must have statistics 3,6,3,1) or (4,6,2,1) this gives three possible combinations which give the following possible sets of statsitcs:")

#text("(8, 15, 13, 5,0), (7, 15, 14, 5,0), (6, 15, 15, 5,0)")#linebreak()#text(" Now the statistics (8, 15, 13, 5,0) violate the following inequality from the section n=4 of the wiki")#linebreak()#text(" 4a + b + c + d is less than or equal to 64 as it equals 65. So we are left with:")#linebreak()#text(" (7, 15, 14, 5,0), (6, 15, 15, 5,0) and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36777")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2009")])]

#text("1112. Terry suggested that these types of visualizations might be more useful. I have made a few.")

#link("http://twofoldgaze.wordpress.com/2009/03/15/visualizing-solutions-i/")[#text("http://twofoldgaze.wordpress.com/2009/03/15/visualizing-solutions-i/")]

#link("http://twofoldgaze.wordpress.com/2009/03/15/visualizing-solutions-ii/")[#text("http://twofoldgaze.wordpress.com/2009/03/15/visualizing-solutions-ii/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36779")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2009")])]

#text("1113. 4D Moser")

#text("Kristal, I played around with Michael’s linear inequalities using maple and I think I can rule out d=5 completely for the 41+ point sets using them via a purely human proof (which was found, of course, using maple). On the 3D section of the Wiki, we have the inequalities")

#mi("4\\alpha_0+4\\alpha_1+3\\alpha_2+\\alpha_3 \\leq 6")#text(" (1)")

#mi("7\\alpha_0+3\\alpha_1+3\\alpha_2+\\alpha_3 \\leq 7")#text(" (2)")

#text("which when averaged on middle slices gives the 4D inequalities")

#mi("b/8 + c/6 + 3d/8 + e \\leq 6")#text(" (3)")

#mi("7b/32 + c/8 + 3d/8 + e \\leq 7")#text(". (4)")

#text("Averaging (1) on side slices similarly gives")

#mi("a/4 + b/8 + c/8 + d/8 \\leq 6")#text(". (5)")

#text("Computing 9/4 *(3) + (4) + 4*(5) gives")

#mi("a+b+c+d+e \\leq 89/2 - 23 d / 32 - 9 e / 4")

#text("and so if ")#mi("a+b+c+d+e \\geq 41")#text(" then we must have ")#mi("d \\leq 4")#text(".")

#text("I got maple to find the integer solutions to ")#mi("d=4, a+b+c+d+e \\geq 41")#text(" that were consistent with all known inequalities. They are: (6,16,15,4,0,0), (7,16,14,4,0,0), (7,17,13,4,0,0), and (7,18,12,4,0,0).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36782")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2009")])]

#text("1114. An animation of extremals of type c’_5:")

#link("http://twofoldgaze.wordpress.com/2009/03/16/visualizations-iii/")[#text("http://twofoldgaze.wordpress.com/2009/03/16/visualizations-iii/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36800")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2009")])]

#text("1115.")

#text("I found a new largest solution for c’_7:")

#text("(Text)")#linebreak()#text(" ")#link("http://twofoldgaze.wordpress.com/2009/03/16/solution-of-size-989-text/")[#text("http://twofoldgaze.wordpress.com/2009/03/16/solution-of-size-989-text/")]

#text("(Image)")#linebreak()#text(" ")#link("http://twofoldgaze.wordpress.com/2009/03/16/solution-of-size-989-image/")[#text("http://twofoldgaze.wordpress.com/2009/03/16/solution-of-size-989-image/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6aee136dbc4c0bc79c68cbcf7d17f526cce6319a8e6e98ec412127af7d47f3a8-376867c974a73315b8452903740c9fc3635e43fe0fc86f758644077298bb8a0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Elsholtz")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36809")[#strong[#text("Christian Elsholtz")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2009")])]

#text("1116. Kareem’s 989 Moser-example in dimension 7.")

#text("here is an analysis which perhaps helps improving your programme:")#linebreak()#text(" I do not exactly know how your programme works, so the analysis is how a programme could have found the 989 set from the 988 set.")

#text("The 988 solution and the new 989 solution do not differ very much.")#linebreak()#text(" Start with the 988 solution.")#linebreak()#text(" Delete {1112223, 1311231}")#linebreak()#text(" and add {1111233, 1112333, 2312231}")#linebreak()#text(" and you have the 989 solution.")

#text("While a complete search to find such an exchange might need about")#linebreak()#text(" 988 times 987/2 steps for the deletion, multiplied with")#linebreak()#text(" (2187-988)times (2187-989) times (2187-990)/6 steps for the")#linebreak()#text(" addition, the following speeds it up considerably:")

#text("Start with a progression-free set.")#linebreak()#text(" Take a loop over one element to be added. (Here say 988 steps).")#linebreak()#text(" Write down all clashes. (those must include of course the new element, so the search may be efficient).")#linebreak()#text(" If there are many forget about this case,")#linebreak()#text(" if there are very few, delete some of them.")#linebreak()#text(" Check if all clashes are avoided, and for any pair of two")#linebreak()#text(" elements list those elements that extend the two to a progression.")

#text("In this example this works extremely well.")

#text("Start with the 988 set.")#linebreak()#text(" add {1111233}, giving 989 elements.")#linebreak()#text(" The set of clashes is built by the five elements.")#linebreak()#text(" {1111233, 1112223, 1113213, 1211232, 1311231}")

#text("Choose subsets of 2 of the 4 elements. (of course avoid 1111233 which we")#linebreak()#text(" just added).")

#text("If in this way you delete for example {1112223,1311231}, and check for elements which")#linebreak()#text(" are now not the last point of an arithmetic progression, then you find")#linebreak()#text(" {1112333, 2312231}.")

#text("(Well, I may have been lucky with this choice, but the point is that there are not so many cases.)")

#text("More generally, it seems one can iterate this:")#linebreak()#text(" instead of deleting k and adding k+1 elements, which seems to produce many")#linebreak()#text(" cases, proceed in the above balanced way:")#linebreak()#text(" add one, and only use those cases with very few clashes.")#linebreak()#text(" Choose from these few clashes two (or more) elements to delete,")#linebreak()#text(" and check which elements can then be added etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36811")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2009")])]

#text("1117. Christian’s idea sounds like a great idea for a mutation operator. The current one is somewhat dumb, it adds one where it can and doesn’t do any global considerations of the whole solution. I ruled out any kind of global examination of the solution as too slow but now that more computations aren’t yielding dramatically better results, a slow operator doesn’t seem as expensive as it did before.")

#text("I had been intending to solicit advice on small tricks that people have found useful in generating new solutions. (If Christian or any one else has any ideas please let me know.)")

#text("Thanks for the idea, Christian. There are an ever growing list of things that need to be done with this project but I will implement this one as soon as I can.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0104a39c8899d222b2bbc57859b2386a900992da4cc938e4b647724423f85ff-5065b977e4b432e2b42e11f47f3d52df2324adde2ada6b2b39090c7b5b4cd87a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Micahael Bacon")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36812")[#strong[#text("Micahael Bacon")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2009")])]

#text("I can’t contribute directly to these types of developments, but I would be interested in Mr. Tao’s thoughts regarding what I think is the amazing ability of web-based approaches to these and many other math and physics issues. Does this new rapid and multi-personal addressing of issues offer hope that much more rapid progress will be made?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36813")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2009")])]

#text("1118. 4D Moser extremals")

#text("The 3D Moser extremals that Michael found (by computer exhaustion of the 2^{27} cases, though I would imagine that we could also verify the resulting linear inequalities by hand if needed) have been very useful in higher D. It would thus be nice to obtain a list of 4D Moser extremals. Even just knowing the e=1 extremals would presumably improve our inequalities somewhat.")

#text("Unfortunately, direct exhaustion requires 2^{81} cases to check, which is too huge. There is a symmetry group of size ")#mi("4! \\times 2^4 \\approx 2^9")#text(" to cut things down a little bit, and we can of course close off any branch of the exhaustion that contains a line, but this is still not feasible.")

#text("On the other hand, by collapsing the 81 points of ")#mi("[3]^4")#text(" into the five classes a,b,c,d,e (with 16, 32, 24, 8, 1 points in each) we get a much more tractable integer program, and we can already get quite far just from using the linear inequalities inherited from 3 and lower dimensions. But it doesn’t quite give us everything we need, e.g. it gives an upper bound of 44 off the bat, and additional work is needed to get 43, and we still can’t rule out d=4 41-point sets other than via Klas’s data.")

#text("So I propose an intermediate regime, in which we identify 1s and 3s but leave the 2s intact. Let’s use x to denote letters that are either 1 or 3, then the 81 points get split up into 16 groups: 2222 (1 point), 222x, 22×2, 2×22, x222 (two points each), 22xx, 2x2x, x22x, 2xx2, x2x2, xx22 (four points each), 2xxx, x2xx, xx2x, xxx2 (eight points each), xxxx (sixteen points). Let c(w) denote the number of points inside a group w, e.g. c(xx22) is the number of points of the form xx22 inside the set, and is thus an integer from 0 to 4.")

#text("Every combinatorial line in ")#mi("\\{2,x\\}^4")#text(" gives rise to an inequality between the corresponding c’s. For instance, the line ")#mi("\\{222x, 2xxx\\}")#text(" gives rise to the inequality ")#mi("c(222x)/2 + c(2xxx)/4 \\leq 2")#text(" (as can be seen by considering the four lines connecting a 222x point to two 2xxxx points) and more generally we have ")#mi("c(u)/2^a + c(v)/2^{b-1} \\leq 2")#text(" whenever ")#mi("\\{u,v\\}")#text(" is a line where u has a 2’s and v has b 2’s with ")#mi("b > a")#text(".")

#text("This is an integer program on 16 variables and 80 line inequalities (plus the upper bound ")#mi("c(2222) \\leq 1")#text(" and the 16 inequalities asserting that all c(w) are non-negative), which looks tractable. One should be able to get a list of Pareto-optimal and extremal c-statistics either by integer-programming or by brute force. (The total number of possible c-statistics is ")#mi("2 \\times 3^4 \\times 5^6 \\times 9^4 \\times 17 \\approx 2.8 \\times 10^{11}")#text(", which is at the edge of what brute force can deal with, but presumably one can use symmetries to cut things down a bit (e.g. assuming ")#mi("c(2xxx) \\leq c(x2xx) \\leq c(xx2x) \\leq c(xxx2)")#text(" cuts things down by a factor of 13 or so; also, c(xxxx) can be easily maximised after making all the other choices, potentially saving a factor of 17). The e=1 case (when c(2222)=1) should be particularly doable (the total number of possibilities here is now ")#mi("2^4 \\times 3^6 \\times 5^4 \\times 9 \\approx 6.5 \\times 10^8")#text(", and after using symmetries this should be quite manageable). Once the possible c-statistics are known, the (a,b,c,d,e) statistics can then be recovered (for instance, we may be able to improve the current upper bound of 39 for the size of e=1 4D Moser sets). (Also, the c-statistics also reveal the (a,b,c,d,e) statistics of 4D diagonal cubes in higher dimensions, e.g. xxyyzw, which could lead to further improvement in the 6D and 7D bounds.)")

#text("Of course, just as the a,b,c,d,e inequalities didn’t fully recover all possible statistics of Moser sets, it could be that the c-inequalities (which are only “averaged” versions of the property of having no combinatorial lines) don’t quite capture the full truth of the situation. But they should do better than the (a,b,c,d,e) inequalities method, and seem within range of a reasonable computer search.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36814")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2009")])]

#text("1119. I thought this analysis of the solutions of c_7 might be of interest:")

#link("http://twofoldgaze.wordpress.com/2009/03/16/the-structure-of-the-extremal-1302/")[#text("http://twofoldgaze.wordpress.com/2009/03/16/the-structure-of-the-extremal-1302/")]

#link("http://twofoldgaze.wordpress.com/2009/03/16/the-structure-of-the-extremals-of-1302-ii/")[#text("http://twofoldgaze.wordpress.com/2009/03/16/the-structure-of-the-extremals-of-1302-ii/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36815")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2009")])]

#text("1120. c-statistics")

#text("I should say that perhaps it would be wise to first see if this method can already recover the known extremals in 3D. I can at least do 2D by hand: here we have four integers ")#mi("0 \\leq c(22) \\leq 1")#text(", ")#mi("0 \\leq c(2x), c(x2) \\leq 2")#text(", ")#mi("0 \\leq c(xx) \\leq 4")#text(" obeying the inequalities")

#mi("c(22) + c(2x), c(22) + c(x2) \\leq 2; c(2x)+c(xx), c(x2)+c(xx) \\leq 4; 2c(22) + c(xx) \\leq 4")#text(".")

#text("By symmetry we may also impose (say) ")#mi("c(2x) \\leq c(x2)")#text(". The extremals for ")#mi("(c(22), c(2x), c(x2), c(xx))")#text(" are then (0,0,0,4), (0,2,2,2), (1,1,1,2), which correspond exactly to the (a,b,c) extremals (0,0,4), (0,4,2), (1,2,2).")

#text("Also, every linear c-inequality at a given dimension implies further linear c-inequalities at higher dimensions by suitable averaging over cubes (but we don’t average as much as in the (a,b,c,d,e) case, we only average over permutations of 1 and 3). One could imagine iteratively building up the c-inequalities much as we have been doing for the coarser (a,b,c,d,e) type inequalities. For instance the above 2D extremals show that ")#mi("c(22) + c(2x) + c(xx), c(22)+c(x2)+c(xx) \\leq 4")#text(", which can be leveraged to higher dimensions (e.g. the first inequality implies that ")#mi("c(222)+c(2x2)+c(xx2) \\leq 4")#text(" and ")#mi("c(22x)/2+c(2xx)/2+c(xxx)/2 \\leq 4")#text(", and also ")#mi("c(22)+c(22x)+c(xxx)/2 \\leq 4")#text(", by looking at yz2, yzx, and yyz cubes respectively, where the wildcard x is understood to be 1 or 3 but the other wildcards are unrestricted.)")

#text("Dear Micahael: these issues are being discussed over at Gowers’ blog at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://gowers.wordpress.com/2009/03/10/polymath1-and-open-collaborative-mathematics/")[#text("Polymath1 and open collaborative mathematics")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36822")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2009")])]

#text("1121. Alternative to c-statistics")

#text("One alternative is breaking up points according to their number of 1’s, 2’s and 3’s this would grow as ")#mi("n^3")#text(" as opposed to c-statistics which might be exponential. Also both could be combined in order to get more information.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36864")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2009")])]

#text("1122. Alternative to c-statistics")

#text("Kristal, isn’t that just the ")#mi("\\Gamma")#text(" slices we have been using? It only grows as ")#mi("n^2")#text(" because the total number of 1s, 2s and 3s is constant.")

#text("I am running Terry’s idea for ")#mi("{}[3]^4")#text(" at home, and it looks like it will take a day or two.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36865")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2009")])]

#text("1123. Alternative to c-statistics")

#text("Yes I think these are the slices we have been using and I agree they are quadratic, ")#mi("(n^2 + n)/2")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36875")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2009")])]

#text("1124. The next installment in my new series ‘Better know an extremal …’:")

#link("http://twofoldgaze.wordpress.com/2009/03/17/the-structure-of-the-extremals-of-1302-iii/")[#text("http://twofoldgaze.wordpress.com/2009/03/17/the-structure-of-the-extremals-of-1302-iii/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36898")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2009")])]

#text("1125. c-statistics")

#text("I ran a search for the sixteen c-statistics (2×22, 22×2, etc)")#linebreak()#text(" I could only find 65 rules, from the 65 combinatorial lines.")

#text("My results limit the total possible points for 4D Moser below 73, which is higher than 43. Either I have a bug, or there was too little connection between the various c statistics.")

#text("For the record, the Pareto extremals it found were")#linebreak()#text(" 16,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0")#linebreak()#text(" 8,8,8,8,8,4,4,4,4,4,4,2,2,2,2,1")#linebreak()#text(" 12,4,4,4,4,2,2,2,2,2,2,1,1,1,1,0")#linebreak()#text(" 14,2,2,2,2,1,1,1,1,1,1,0,0,0,0,0")#linebreak()#text(" 10,6,6,6,6,3,3,3,3,3,3,1,1,1,1,0")#linebreak()#text(" 15,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0")#linebreak()#text(" 13,3,3,3,3,1,1,1,1,1,1,0,0,0,0,0")#linebreak()#text(" 11,5,5,5,5,2,2,2,2,2,2,1,1,1,1,0")#linebreak()#text(" 9,7,7,7,7,3,3,3,3,3,3,1,1,1,1,0")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36899")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2009")])]

#text("1126. c-statistics")

#text("I ran through the 2^27 subsets of the 3D cube, looking for Moser sets. I classified them with the c-statistics. I collected Pareto optimal points. Then, from the extremal points I found a set of twenty linear inequalities satisfied by all Moser sets. They are the same linear inequalities found earlier for the ‘xxxxyyz diagonals’. They are on Sheet 8 of a spreadsheet in the Moser section of the wiki.")

#text("I don’t yet know their effects in 4D")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36932")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2009")])]

#text("1127. Progress on ")#mi("\\overline{c}^\\mu_6 = 15")

#text("What I have typed so far is at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Talk:Fujimura%27s_problem")[#text("the talk page about Fujimura’s on the wiki")]#text(". My time is limited (my wife is close to giving birth to our first child) so it may be a while before I can finish all the cases.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36933")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2009")])]

#text("1128. Progress on \\overline{c}^\\mu_6 = 15")

#text("“My time is limited (my wife is close to giving birth to our first child)”")

#text("Congratulations!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36934")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2009")])]

#text("1129. c^{\\mu}_4=9")

#text("If c^{\\mu}_4 is greater than 9 then the counterexample must occur")#linebreak()#text(" when there is exactly one point of the form aaaa removed. The other three cases are below.")

#text("If we have all")#linebreak()#text(" three points of the form aaaa removed")#linebreak()#text(" then the remaining points have value 12 and")#linebreak()#text(" we have covered all lines any set of moving coordinates")#linebreak()#text(" with all constant points equal to one value this leaves")#linebreak()#text(" the lines xxab, xabc and xaab. let us also remove the three sets of the form aabc, a, b, c not equal. These block the remaining lines and the size is now 9.")

#text("Now suppose we try to replace the removed points of the form aabc by points of the form aaab or aabb. Now we must cover the lines of the form xaab each point of the form aabc covers two and has a weight 1/12 each point of the form aabb covers 4 and has a weight 1/6 each point of the form aaab covers three and has a weight of 1/3 and since each element of the form covers two elements of the form xaab that no other element of the set aabc covers and as noted above all lines of the form xaab are covered by the the elements of the three sets of the form aabc we cannot improve on the weight as we can only cover the xaab’s by the same or higher weight lowering the total from 9 so for this case the value is 9.")

#text("If we have two points removed of the form aaaa then")#linebreak()#text(" the weight is at most 13 say the point not removed is 2222")#linebreak()#text(" then we must cover the lines xxx2 and x222 we have eight such")#linebreak()#text(" lines and all six xx22 must be covered one at a time by either 1122")#linebreak()#text(" or 3322 the four x222 must be covered one at a time by 3222 or 1222")#linebreak()#text(" the four xxx2 must be covered by 3332 or 1112")#linebreak()#text(" these points must be removed and the that lowers the weight")#linebreak()#text(" To 13 – 4*(6/24) – 6*(1/6) – 4(6/24) = 10.")#linebreak()#text(" We also have 24 lines of the form xabc which can only be covered")#linebreak()#text(" two at a time by the aabc which have weight 1/12 so we need to cover")#linebreak()#text(" these with at least 12 of these which we can do by choosing all points which are permutations of")#linebreak()#text(" 1123 this reduces the number to 9 and")#linebreak()#text(" again we have c^{\\mu} must be 9.")

#text("Finally we have no points of the form aaaa removed but then we will")#linebreak()#text(" have a line of the form xxxx.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36995")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2009")])]

#text("1130 ")#mi("\\overline{c}^\\mu_6 = 15")

#mi("\\overline{c}^\\mu_6 \\geq 15")#text(" from the bound for general n.")

#text("Note that there are ten extremal solutions to ")#mi("\\overline{c}^\\mu_3")#text(":")

#text("Solution I: remove 300, 020, 111, 003")#linebreak()#text(" Solution II (and 2 rotations): remove 030, 111, 201, 102")#linebreak()#text(" Solution III (and 2 rotations): remove 030, 021, 210, 102")#linebreak()#text(" Solution III’ (and 2 rotations): remove 030, 120, 012, 201")

#text("Also consider the same triangular lattice with the point 020 removed, making a trapezoid. Solutions based on I-III are:")

#text("Solution IV: remove 300, 111, 003")#linebreak()#text(" Solution V: remove 201, 111, 102")#linebreak()#text(" Solution VI: remove 210, 021, 102")#linebreak()#text(" Solution VI’: remove 120, 012, 201")

#text("The on the 7x7x7 triangular lattice triangle 141-411-114 must have at least one point removed. Remove 141, noting by symmetry any logic that follows will also work for either of the other two points.")

#text("Suppose we can remove all equilateral triangles on our 7×7×7 triangular lattice with only 12 removals.")

#text("Here, “top triangle” means the top four rows of the lattice (with 060 at top) and “bottom trapezoid” means the bottom three rows.")

#text("At least 4 of those removals must come from the top triangle (the solutions of ")#mi("\\overline{c}^\\mu_3")#text(" mentioned above).")

#text("The bottom trapezoid includes the overlapping trapezoids 600-420-321-303 and 303-123-024-006. If the solutions of these trapezoids come from V, VI, or VI’, then 6 points have been removed. Suppose the trapezoid 600-420-321-303 uses the solution IV (by symmetry the same logic will work with the other trapezoid). Then there are 3 disjoint triangles 402-222-204, 213-123-114, and 105-015-006. Then 6 points have been removed. Therefore at least six removals must come from the bottom trapezoid.")

#text("To make a total of 12 removals there must be either:")#linebreak()#text(" Case A: 4 removals from the top triangle and 8 from the bottom trapezoid.")#linebreak()#text(" Case B: 5 removals from the top triangle and 7 from the bottom trapezoid.")#linebreak()#text(" Case C: 6 removals from the top triangle and 6 from the bottom trapezoid.")

#text("* Suppose case A is true.")

#text("Because 141 is already removed, the solution to the upper triangle must remove either solution I (remove 060, 330, 033), solution II (remove 060, 231, 132), solution IIb (remove 033, 150, 240) or solution IIc (remove 330, 051, 042)")

#text("Suppose I is the solution for the upper triangle.")

#text("Suppose 222 is open. Then 420, 321, 123, and 024 must all be removed. This leaves five disjoint triangles which require removals in the bottom trapezoid (150-600-105, 051-501-006, 222-402-204, 231-411-213, 132-312-114); therefore the bottom trapezoid needs at least 9 removals, but we can only make 8, therefore 222 is closed.")

#text("Suppose 411 is open. Then 213 and 015 must be removed. This leaves five disjoint triangles such that each triangle must have exactly one removal (420-150-123, 321-051,024, 600-510-501, 402-312-303, 204-114-105), so the remaining point (006) must be open, forcing 501 to be removed. This makes 600 and 510 open, and based on the triangles 600-240-204 and 510-150-114 both 204 and 114 must both be removed, but 204 and 114 are on the same disjoint triangle, contradicting the statement that each triangle must have exactly one removal. So 411 is closed.")

#text("This leaves six disjoint triangles each which must have at least one removal (420-123-150, 321-024-051, 510-213-240, 312-015-042, 501-204-231, 402-105-132). This forces 600 and 006 to be open. Based on the triangles 006-501-051 and 600-204-240, this forces 501 and 204 to be open. But then there are no removals from the triangle 501-204-231, which is a contradiction. Therefore the solution of the upper triangle cannot be I.")

#text("Suppose II is the solution for the upper triangle.")

#text("There are seven disjoint triangles (150-600-105, 051-501-006, 222-402-204, 240-510-213, 042-312-015, 330-420-321, 033-123-024), therefore of the three points remaining in the bottom trapezoid (411, 303, 114) exactly one must be removed.")

#text("Suppose 411 is removed. Then 114 and 303 are open; 114 open forces 510 to be removed, forcing 213 to be open. 114 and 213 open force 123 to be closed, forcing 024 to be open. 024 open forces 222 to be closed, which forces 204 to be open, which leaves the triangle 213-303-204 open so we have a contradiction.")

#text("By symmetry 114 also can’t be removed. Therefore we must remove 303. This leaves 411 and 114 open, forcing 510 and 015 closed. 510 and 015 closed forces 312 and 213 open, forcing 222 closed. 222 closed forces 402 and 204 open. 402 and 204 open force 501 and 105 closed. 510 and 105 closed force 600 and 006 open, leaving equilateral triangles 600-204-240 and 402-006-042 open. Therefore 303 can’t be removed, and so the solution of the upper triangle can’t be II.")

#text("Suppose IIb is the solution for the upper triangle.")

#text("Suppose 024 is open. This forces 420, 321, and 222 closed. Five disjoint triangles remain (510-600-501, 231-411-213, 132-312-114, 123-303-105, 024-204-006) so each must have exactly one point removed, and the remaining points in the lower trapezoid (402, 015) must be open. This forces 312, 411, 510, and 006 closed, which then force the the other points in their disjoint triangles open (600, 501, 231, 213, 132, 114, 204). The triangle 501-231-204 is therefore open, so we have a contradiction, therefore 024 is closed.")

#text("Suppose 006 is open. This forces 600, 501 and 402 to be closed, and leaves five disjoint triangles (510-420-411, 321-231-222, 312-132-114, 303-213-204, 105-015-006) and so 123 must be open. This forces 222 closed, which forces 321 open, which forces 420 closed, which forced 510 and 411 open, which forces 213 closed, which forces 303 and 204 open, which forces 105 closed, which forces 015 and 006 to be open, leaving an open triangle at 411-015-051. Therefore we have a contradiction, so 006 is closed.")

#text("Given 024 and 006 closed, now note there are six disjoint triangles (600-510-501, 402-312-303, 204-114-105, 420-330-321, 222-132-123, 411-231-213). Therefore the remaining point in the lower trapezoid 015 must be open, forcing 510, 411, and 312 to be closed. Using the disjoint triangles this forces 600, 501, 402, 303 and 213 to be open, which then forces 420 and 321 to be closed. Both 420 and 321 are on the same disjoint triangle, therefore we have a contradiction, so IIb can’t be solution.")

#text("Note by symmetry, the same logic for IIb will apply for IIc. Therefore case A isn’t true.")

#text("* Suppose case B is true.")

#text("The row 330-231-132-033 has ten possible solutions (excluding reflections, which by symmetry will be handled by the same logic):")

#text("Case Q: open-open-open-open")#linebreak()#text(" Case R: closed-closed-closed-closed")#linebreak()#text(" Case S: closed-open-open-open")#linebreak()#text(" Case T: closed-open-closed-closed")#linebreak()#text(" Case U: open-closed-closed-closed")#linebreak()#text(" Case V: closed-open-closed-closed")#linebreak()#text(" Case W: closed-closed-open-open")#linebreak()#text(" Case X: closed-open-closed-open")#linebreak()#text(" Case Y: open-closed-closed-open")#linebreak()#text(" Case Z: closed-open-open-closed")

#text("Consider all 10 cases. Note in all these cases we are still assuming 141 is removed.")

#text("(Case Q) 330, 231, 132, 033 open forces 060, 150, 051, 240, 141, 042 closed, but the upper triangle only allows 5 removals, so case Q forms a contradiction.")

#text("(Case R) 060-240-042 is left open, so case R forms a contradiction.")

#text("(Case S) 231, 132, and 033 open force 031 and 042 removed, which means from 240, 150, 061 there must be exactly one removal.")

#text("Suppose 213 is open. Then 411 and 015 are closed, and five disjoint triangles are left where each triangle must have exactly one removal (600-420-402, 501-321-303, 312-222-213, 204-105-114, 123-024-033). So the two remaining points in the lower trapezoid (510 and 006) must be open. 510 and 006 open force 303 closed, which forces 321 and 501 open, which forces 204 closed, which forces 114 and 103 open, which forces 402 and 312 closed, forcing 222 open, leaving 321-231-222 as an open triangle, so we have a contradiction.")

#text("Therefore 213 is closed. This leaves six disjoint triangles (600-420-402, 501-231-204, 303-033-006, 411-321-312, 222-132-123, 114-024-015) which each have exactly one removal. Therefore 510 from the lower trapezoid is open. Note since one of 150 and 060 must be open, then one of 114 or 015 must be closed; therefore 024 is open. This forces 123 closed, forcing 222 to be open, forcing 321 to be closed, forcing 411 and 312 open, forcing 421 closed, forcing 600 and 402 open, forcing 303 closed, forcing 006 open, forcing 204 closed, forcing 501 open, leaving the triangle 600-510-501 open and a contradiction.")

#text("(Case T) 231 is closed, and 330, 132, and 033 open force 060, 150, and 042 closed. Since 141 is already closed we have five removals from the top triangle, so 240 and 051 are open.")

#text("Suppose 024 is open. This forces 321 and 123 closed, leaving five disjoint triangles (600-510-501, 402-312-303, 204-114-105, 420-240-222, 213-033-015). Therefore 006 and 411 remaining in the lower trapezoid are open, forcing 501, 303 and 015 closed, forcing 600, 510, 312, 402, and 213 open, forcing 222 closed, forcing 420 open, leaving the open triangle 420-510-411, so we have a contradiction.")

#text("Therefore 024 is closed. There are now six disjoint triangles (510-600-501, 330-420-321, 312-402-303, 132-222-123, 033-213-015, 114-204-105). This leaves 411 and 006 open, which forces 015 and 501 closed, which forces 510 and 213 open, leaving the triangle 240-510-213 open, so we have a contradiction.")

#text("(Case U) Given the removals 231, 132, 033, and 141, the only possible removal to not leave any equilateral triangles in the upper triangle is 060. So 330, 240, 150, 051, and 042 are open.")

#text("Suppose 420 is open. This forces 321, 222, and 123 closed. This leaves five disjoint triangles (600-330-303, 510-420-411, 204-105-114, 501-051-006, and 312-042-015), so we have a contradiction.")

#text("Therefore 420 is closed. This leaves six disjoint triangles (600-330-303, 501-051-006, 204-114-105, 510-240-213, 411-321-312, 222-042-024). 015 in the lower trapezoid is therefore open, forcing 312 and 411 closed, but 312 and 411 are on the same disjoint triangle, so we have a contradiction.")

#text("(Case V) Given the removals 330, 132, and 033, the only possible removal to not leave any equilateral triangles in the upper triangle is 060. So 150, 051, 240, 042, and 231 are open.")

#text("Suppose 420 is open. Then 222 and 123 are closed, and we are left with 6 disjoint triangles (150-600-105, 240-510-213, 231-501-204, 024-114-015, 042-402-006, 411-321-312). This exceeds our limit of 7 removals in the bottom trapezoid, so we have a contradiction.")

#text("Therefore 420 is closed. Again we are left with the same 6 disjoint triangles (150-600-105, 240-510-213, 231-501-204, 024-114-015, 042-402-006, 411-321-312). Therefore 222, 123, and 303 are open. This forces 321, 024, and 105 to be closed, which then forces 411 and 015 to be open, forming an open triangle at 051-411-015, so we have a contradiction.")

#text("(Case W) Given the removals 330 and 231 with 132 and 033 open, 132 and 033 open force 042 closed. Given 141 is already closed, that leaves one more removal on the upper triangle, which must be one of 060-150-051, so 240 must be open.")

#text("Suppose 024 is open. This forces 123 to be closed, and leaves 6 disjoint triangles (600-510-501, 420-240-222, 411-321-312, 402-132-105, 213-033-015, 204-024-006). So 303 and 114 in the lower trapezoid are left open, forcing 312 and 005 to be closed, forcing 204 and 321 to be open, forcing 600 and 501 to be closed. 600 and 501 are on the same disjoint triangle so we have a contradiction.")

#text("Therefore 024 is closed. Suppose 312 is open. This forces 114 to be closed, and leaevs 5 disjoint triangles (600-510-501, 411-321-312, 303-213-204, 222-132-123, 105-015-006). Therefore 402 in the lower trapezoid is open, which forces 105 to be closed, which forces 015 and 006 to be open, which forces 213 and 303 to be closed, which are on the same disjoint triangle, so we have a contradiction.")

#text("Therefore 312 is closed. This leaves five disjoint triangles (510-240-213, 501-411-402, 222-132-123, 204-114-105, 303-033-006), and leaves 600, 420, 321, and 015 in the lower trapezoid open. This forces 402 and 213 to be closed, which forces 510 and 411 to be open, leaving an open triangle at 510-420-411, so we have a contradiction.")

#text("(Case X) 330 and 132 closed and 231 and 033 open imply 051 is closed, and since 141 is closed and we have only one more removal in the upper triangle it must be one of 240, 042, or 060. This leaves 150 open.")

#text("Suppose 321 is open. This forces 222 to be closed and leaves six disjoint triangles (600-420-402, 510-150-114, 411-321-312, 303-213-204, 105-015-006, 123-033-024), leaving 501 in the lower trapezoid open. This forces 204 to be closed, which forces 303 to be open, leaving an open triangle at 501-321-303.")

#text("So 321 is closed. This leaves six disjoint triangles (600-420-402, 510-150-114, 501-231-204, 312-222-213, 123-033-024, 105-015-006) and leaves 303 and 411 in the lower trapezoid open. This forces 213 and 006 to be closed, and forces 312, 222, 105, and 015 to be open. This forces 600 to be closed and 402 to be open, leaving an open triangle at 402-312-303. So we have a contradiction.")

#text("(Case Y) 330 and 033 are open, 330 and 033 open force 060 to be closed. With 141 closed there can be only one more removal, so suppose 150 is open (and note that if 150 was closed, we can use symmetry considering 051 to be open).")

#text("Suppose 600 is open. This forces 303 to be closed, and leaves six disjoint triangles (510-150-114, 420-330-321, 411-501-402, 222-312-213, 033-123-024, 015-105-006). So 204 in the lower trapezoid is left open. 600 and 150 open implies 105 is closed, forcing 015 and 006 to be open, forcing 024 and 213 to be closed, forcing 312, 222, and 123 to be open, forcing 042 in the upper triangle to be closed (so 051 and 240 are open). 051 and 015 open force 411 to be closed, which forces 501 to be open and leaves the open triangle 051-501-006.")

#text("So 600 is closed. This leaves six disjoint triangles (510-150-114, 420-330-321, 411-501-402, 222-312-213, 033-123-024, 015-105-006). 015 is the lower trapezoid is then left open, forcing 312 and 411 to be closed. However, 312 and 411 are on the same disjoint triangle, so we have a contradiction.")

#text("(Case Z) 330, 141, and 033 are closed, and 231 and 132 are open. Suppose 051 is open (note that if this forms a contradiction, by symmetrical argument we can say both 150 and 051 are closed).")

#text("Suppose 114 is closed. This leaves six disjoint triangles (600-510-501, 402-312-303, 105-015-006, 411-231-213, 222-132-123, 321-051-024) and so 420 and 204 are open. This forces 501 to be closed, which forces 510 and 600 to be open, which forces 411 and 402 to be closed, which forces 213 and 303 to be open, leaving an open triangle at 213-303-204.")

#text("So 114 is open. Suppose 213 is closed. This leaves five disjoint triangles (600-420-402, 501-321-303, 411-051-015, 222-132-123, 204-024-006) and in the lower trapezoid 510 and 105 are open. This forces 204 to be closed, forcing 024 and 006 to be open, forcing 015 to be closed, forcing 411 to be open, forcing 420 to be closed, forcing 402 to be open, leaving the open triangle 402-132-105.")

#text("So both 114 and 213 are open. Therefore 411 and 312 are closed. This leaves five disjoint triangles (600-510-501, 303-213-204, 105-015-006, 222-132-123, 321-051-024). The remaining points in the lower trapezoid (420, 402) are then open, forcing 105 to be closed, forcing 015 and 006 to be open, forcing 024 to be closed. Also note 114 and 213 open force 123 to be closed, which forces 222 to be open, which forces 321 to be closed. 321 and 024 are on the same disjoint triangle, so we have a contradiction.")

#text("So 150 and 051 are both closed. However, this leaves the triangle 240-042-060 open, so case Z is impossible.")

#text("Since all ten solutions have been eliminated, case B is impossible.")

#text("* Suppose case C is true.")

#text("Suppose the trapezoid 600-420-321-303 used solution IV. There are three disjoint triangles 402-222-204, 213-123-114, and 105-015-006. The remainder of the points in the lower trapezoid (420, 321, 510, 501, 402, 312, 024) must be left open. 024 being open forces either 114 or 015 to be removed.")

#text("Suppose 114 is removed. Then 213 is open, and with 312 open that forces 222 to be removed. Then 204 is open, and with 024 that forces 006 to be removed. So the bottom trapezoid is a removal configuration of 600-411-303-222-114-006, and the rest of the points in the bottom trapezoid are open. All 10 points in the upper triangle form equilateral triangles with bottom trapezoid points, hence 10 removals in the upper triangle would be needed (more than the 6 allowed), so 114 being removed doesn’t work.")

#text("Suppose 015 is removed. Then 006-024 forces 204 to be removed. Regardless of where the removal in 123-213-114, the points 420, 321, 222, 024, 510, 312, 501, 402, 105, and 006 must be open. This forces upper triangle removals at 330, 231, 042, 060, 051, 132, our remaining 6 removals on the top triangle. However, we have already removed 141, forcing one removal too many, so the trapezoid 600-420-321-303 doesn’t use solution IV.")

#text("Suppose the trapezoid 600-420-321-303 uses solution VI. The trapezoid 303-123-024-006 can’t be IV (already eliminated by symmetry) or VI’ (leaves the triangle 402-222-204). Suppose the trapezoid 303-123-024-006 is solution VI. The removals from the lower trapezoid are then 420, 501, 312, 123, 204, and 015, leaving the remaining points in the lower trapezoid open. The remaining open points is forces 10 upper triangle removals, so the trapezoid 600-420-321-303 doesn’t use solution VI. Therefore the trapezoid 303-123-024-006 is solution V. The removals from the lower trapezoid are then 420, 510, 312, 204, 114, and 105. The remaining points in the lower trapezoid are open, and force 9 upper triangle removals, hence the trapezoid 303-123-024-006 can’t be V, and the solution for 600-420-321-303 can’t be VI.")

#text("The solution VI’ for the trapezoid 600-420-321-303 can be eliminated by the same logic by symmetry.")

#text("Therefore it is impossible for the bottom trapezoid to use only 6 removals.")

#text("We have determined cases A, B, and C to be impossible, therefore it impossible to form a triangle free configuration on the 7x7x7 lattice with only 12 removals. Therefore ")#mi("\\overline{c}^\\mu_6 = 15")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-36996")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2009")])]

#text("1130. ")#mi("\\overline{c}^\\mu_6 = 15")

#text("The proof is ")#link("http://michaelnielsen.org/polymath1/index.php?title=Talk:Fujimura%27s_problem")[#text("complete")]#text(".")

#text("I tried to post it here but I guess it was too large and got caught by the spam filter? It’s definitely a level of complexity over latex \\overline{c}^\\mu_5$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-37019")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2009")])]

#text("1131 c-statistics")

#text("The 3D cube has 14 ways to fit in the 4D cube: 4 side-slices 2yzw, 4 middle slices xyzw, and six diagonal slices wwyz. So twenty inequalities for the cube become 280 inequalities for the 4D cube. There is some repetition, so there are only 239 different inequalities. One solution of these inequalities has 44 points: ")#mi("cxxxx = cxxx2 = cxx22 = 4")#text(" and permutations.")

#text("There were 2150 inequalities for the 5D cube with c-statistics; I have not yet found the maximum for that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-37021")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2009")])]

#text("1132. Commentary on ")#mi("\\overline{c}^\\mu_6 = 15")#text(".")

#text("The basic proof strategy was to set up removals such that there would be enough disjoint triangles to say that each triangle needed to have one removal. Then any points not in the union of disjoint triangles were forced to be in ")#mi("\\overline{c}^\\mu_6")#text(", and those points could be used to force a chain of removals leading to an impossibility.")

#text("Unfortunately the process was not very mechanical, so it’d be hard to come up with a mathematical generalization. Each case was like its own individual puzzle, and I often had to go through multiple bad attempts before I found a set that broke things open.")

#text("However, there was a technique I used in making solution sketches which may have some useful general properties — look for all the possible disjoint triangle sets on a possible configuration, then pick the “overlay pattern” that was the most useful (possibly switching patterns mid-problem).")

#text("For example, here’s a simple mathematical property:")

#text("Suppose some set of points ")#mi("Q")#text(" on the triangular lattice that has a maximal number of disjoint triangles ")#mi("m")#text(" where ")#mi("m")#text(" removals are also sufficient to produce a triangle-free set. Let ")#mi("F_1,\\dots,F_j")#text(" be the triangle-free sets of ")#mi("Q")#text(" (if the solution is unique, ")#mi("j = 1")#text(").")

#text("Consider all sets ")#mi("T_1,\\dots,T_k")#text(" where ")#mi("k")#text(" is the number of possible configurations of ")#mi("m")#text(" disjoint triangles in the set ")#mi("Q")#text(".")

#text("Then for each ")#mi("1 \\leq i \\leq k")#text(", ")#mi("Q \\setminus T_i")#text(" must be a subset of ")#mi("F_1\\cap\\dots\\cap F_j")#text(".")

#text("(In other words, any points remaining after locating disjoint triangles must be open, considering all of the possible disjoint triangle configurations.)")

#text("It’s also possible to set up a graph representing where the disjoint triangles overlap.")

#text("Let me take the case of ")#mi("\\overline{c}^\\mu_3")#text(". There are two disjoint triangle configurations: A = 030-120-021, B = 210-300-201, C = 012, 102, 003 and D = 030-210-012, E = 120-300-102, F=021-201-003. Any removal from A has to remove also remove from either D, E, or F; any removal from B has to remove from either D, E, or F, and any removal from C has to remove from either D, E, or F. This can be represented as a complete bipartite graph between A, B, C and D, E, F.")

#text("I’m not sure if anything in this will be useful for solving general n, but it might be possible to scrounge some tools to work on low-n cases.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-37100")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2009")])]

#text("1132 Kakeya k_3 > 12")

#text("We try to find a set A containing twelve points in F_3^3 that form a Kakeya set.")

#text("Seva showed in 1106 that we can assume A contains four lines through the origin, including the three axes. (000),(001),(002),(010),(020),(100),(200)")

#text("Case A: The fourth line is in the xy plane z=0. Then seven points are in this plane, leaving five points in the two planes z=1, z=2. There are nine directions not parallel to the xy plane; each direction must contain two of the five points, one in the z=1 plane and one in the z=2 plane. This is impossible.")

#text("Case B: The fourth line is (000),(111),(222)")#linebreak()#text(" If there is a sixth point in the z=0 plane, there are only six points left in z=1 and z=2. To form nine directions out of the xy plane, we need three points in z=1 and three in z=2. We also need none of the nine directions parallel to each other. But (002)-(111) is parallel to (222)-(001), so we can’t get nine non-parallel directions out of the plane.")

#text("So the z=0 plane only contains points along the axes. Likewise the x=0 and y=0 planes. There are three points left to place, and they all lie in the cube [1,2]^3.")

#text("To form a (120) line, we need to include (121) and (211). Then, to form a (110) line, we need to include either (112) or (221)")

#text("Case B1: the extra three points are (121),(211),(112). There is no (112) line.")

#text("Case B2: the extra three points are (121),(211),(221). There is no (102) or (012) line.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-37112")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2009")])]

#text("1133. c^{\\mu}_4=9")

#text("This is the final case of the partial proof in 1129.")

#text("If one point of the form aaaa is removed say 1111")#linebreak()#text(" then we must cover all lines of")#linebreak()#text(" the form xxx2 xxx3 and xx22 and xx33 and x222 and x333")#linebreak()#text(" Look at the pairs of lines such as xxx2 and 333x")#linebreak()#text(" one with moving coordinates in three positions and")#linebreak()#text(" a fixed coordinate equal to 2 or 3 say 2")#linebreak()#text(" the other with fixed coordinates equal to the other")#linebreak()#text(" value which in this case is 3.")

#text("Then we must have one of the points 2222")#linebreak()#text(" 1112 3332 removed to block the first line of the pair")#linebreak()#text(" and for the second line we can use 3333")#linebreak()#text(" 3332 3331. However we do not have the points")#linebreak()#text(" 2222 or 3333 removed in this case so we must have")#linebreak()#text(" either 3332 or the pair 1112 or 3331.")#linebreak()#text(" For every one of the eight points 3332 or 2223")#linebreak()#text(" we will have a similar choice forcing either")#linebreak()#text(" the removal of the point itself or the associated")#linebreak()#text(" pair. After these choices have been made more points")#linebreak()#text(" of the form aaab can be added but there must be")#linebreak()#text(" a subset corresponding to one set of the above eight choices")#linebreak()#text(" since in each case there are only two ways to cover the lines noted.")#linebreak()#text(" Look at the pairs of lines such as 22xx and xx33")#linebreak()#text(" one with moving coordinates in two positions and")#linebreak()#text(" a two fixed coordinates equal to 2 or 3 say 2")#linebreak()#text(" the other with two fixed coordinates equal to the other")#linebreak()#text(" value which in this case is 2 so if the fixed coordinate(s)")#linebreak()#text(" in one point of the pair is 2 in the other they or it will")#linebreak()#text(" Then we must have one of the points 2211")#linebreak()#text(" 2222 2233 removed to block the first line of the pair")#linebreak()#text(" and for the second line we can use 3333")#linebreak()#text(" 2233 1133. However we do not have the points")#linebreak()#text(" 2222 or 3333 removed in this case so we must have")#linebreak()#text(" either 2233 or the pair 1133 or 2211.")#linebreak()#text(" For every one of the six points with two threes and two twos")#linebreak()#text(" we will have a similar choice forcing either")#linebreak()#text(" the removal of the point itself or the associated")#linebreak()#text(" pair. After these choices have been made more points")#linebreak()#text(" of the form aabb can be added but there must be")#linebreak()#text(" a subset corresponding to one set of the above six choices")

#text("If we start with the configuration 1111 removed all eight points with three 2’s and one three and three 3’s and one two removed and all points with two 3’s and two 2’s removed and all points of the form aabc removed then this configuration has weight 8")#linebreak()#text(" then we can perform a series of steps in order which will")#linebreak()#text(" reach all combinatorial line free configurations.")#linebreak()#text(" These steps are as follows:")

#text("1 Making choices as above for elements of the form aaab and allowing the addition")#linebreak()#text(" of all possible aabc’ss.")

#text("2 Making choices as above for elements of the form aabb and allowing the addition")#linebreak()#text(" of all possible aabc’ss.")

#text("3.Removal of points of the form aabb or aaab and addition of all possible aabc’s.")

#text("4.Removal of aabc’s.")

#text("At present none of the aabc can be added")#linebreak()#text(" there are lines of the form xx12 and xx13 and x113 and x112")#linebreak()#text(" which each have to blocked to allow their addition")

#text("What we are going to do is perform the previous steps in order.")#linebreak()#text(" we will show that each step eliminates twice as much in weight")#linebreak()#text(" of elements of the form aabc as it adds of all other forms. To facilitate the proof")#linebreak()#text(" we will have to perform the operations in the order listed. However we will")#linebreak()#text(" be able to reach every possible configuration. We must have a subconfiguration")#linebreak()#text(" corresponding to one set of choices above then we can delete various elements")#linebreak()#text(" of the form aabb and aaab to get all possible line free sets of the elements of")#linebreak()#text(" the form aabb and aaab and then for each set we add the maximum possible number")#linebreak()#text(" of elements of the form aabc.")

#text("The point is doing this is that we can only add two units in weight")#linebreak()#text(" of the form aabc as the lines of the form xabc must be covered and they")#linebreak()#text(" Can only be covered by one unit in weight of elements of the form abc")#linebreak()#text(" So if we have the two to one ratio or better and have to stop at two we will")#linebreak()#text(" End up with a net change of 2-1 which will raise the weight to 9 or less")#linebreak()#text(" And we still have the maximum weight of is 9.")

#text("When we make a choice deleting a pair and adding say")#linebreak()#text(" 2223 which will give 1113 and 2221 we block three lines")#linebreak()#text(" of the form xx13 and three of the form xx12 thus allowing")#linebreak()#text(" the addition of 6 points of weight 1/12 which give a total")#linebreak()#text(" change of weight 1/2 which is exactly twice the net change in")#linebreak()#text(" weight caused by the addition of 2223 and the removal of 1113")#linebreak()#text(" of 2221")

#text("Now with each substitution there will also be the blocking of lines")#linebreak()#text(" of the form x113 or x112 however to allow the point say 2113")#linebreak()#text(" To be added we must block both x113 and 211x and to do this")#linebreak()#text(" We must make choices adding both 2223 and 2333 which unblocks")#linebreak()#text(" The line 2xx1 and forbids the addition of the point 2113 thus the increase in")#linebreak()#text(" material of the form aabc is twice the net change in weight of the other types")

#text("1122 can block the 11×2 two at a time but their")#linebreak()#text(" weight is 1/6 so even if they block two of the 11×2")#linebreak()#text(" and allow the addition of two 1132’s the weight will")#linebreak()#text(" remain the same and since each replacement of 2233")#linebreak()#text(" by 1133 and 2211 has only one element of the form")#linebreak()#text(" 2211 we are done with step one.")

#text("For the choices of elements")#linebreak()#text(" of the form aabb if we replace an element of the form")#linebreak()#text(" 2223 by 1113 and 2221 we will be able to block three lines")#linebreak()#text(" of the form x113 which gets rid of 3 elements of the form")#linebreak()#text(" 2113 but the weight of the addional aaab element created is 1/4 and the weight of the removed elements is the same. So step")#linebreak()#text(" two can not improve the weight. So we are done with the choices mentioned above and move on two steps 3 and 4 deleting individual elements.")

#text("If we add an element of the form 2233 and delete 1133 and 2211 then it can unblock two lines of the form x113 and two of the form x112 thus allowing the addition of at most 4 points of the form")#linebreak()#text(" 3112 thus giving a net change of -1/4 +4/12 and again the ratio is 2 to one.")

#text("Then after all the above choices have been made we can delete elements of the form 2223 which will block at most three lines")#linebreak()#text(" Of the form 2xx3 if created by the above choices")#linebreak()#text(" And the ratio of points added to points deleted is at most one")#linebreak()#text(" And so is less than 1/2 and we are done. The case 3332")#linebreak()#text(" is handled the same way.")

#text("If we delete an element of the form 1112 we unblock three lines")#linebreak()#text(" Of the form xx12 and three of x112 we free at most 6 points with")#linebreak()#text(" Weight 1/12 giving a total weight of 1/2 the point removed is weight 1/4 so the ratio is 2 to 1 and we are done the case of")#linebreak()#text(" 1113 is similar.")

#text("If we delete an element of the form 3331 it can unblock three lines")#linebreak()#text(" of the form xx31 and we free three points for possible addition")#linebreak()#text(" The have total weight equal to the weight of 3331 so the ratio is")#linebreak()#text(" less than 2 to 1. The case of an element of the form 2221 is similar.")

#text("If we delete a point of the form 2233")#linebreak()#text(" We don’t unblock any lines so we can’t")#linebreak()#text(" Add any points of the form aabc.")

#text("If we delete a point of the form 1133 we unblock two lines")#linebreak()#text(" Of the form xx13 and two of x113 and so can add four points")#linebreak()#text(" With weight 1/12 which has total 1/3 which is twice the weight")#linebreak()#text(" Of the point 1133 so the ratio is less than or equal to 2 and we are")#linebreak()#text(" Done. The case of deleting a point of the form 1122 is handled similarly.")#linebreak()#text(" So we are done with step three.")

#text("If we delete a point of the form aabc the weight is less. So we have gone through all steps and the ratio in them 2 or less and thus in this case the weight is 9 or less and we are done. Since this is the final case we have proved the theorem and the weight is 9.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-37113")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2009")])]

#text("1133. c^{\\mu}_4=9")

#text("This is the final case of the partial proof in 1129. It is divided")#linebreak()#text(" into two parts. Here is part one:")

#text("If one point of the form aaaa is removed say 1111")#linebreak()#text(" then we must cover all lines of")#linebreak()#text(" the form xxx2 xxx3 and xx22 and xx33 and x222 and x333")#linebreak()#text(" Look at the pairs of lines such as xxx2 and 333x")#linebreak()#text(" one with moving coordinates in three positions and")#linebreak()#text(" a fixed coordinate equal to 2 or 3 say 2")#linebreak()#text(" the other with fixed coordinates equal to the other")#linebreak()#text(" value which in this case is 3.")

#text("Then we must have one of the points 2222")#linebreak()#text(" 1112 3332 removed to block the first line of the pair")#linebreak()#text(" and for the second line we can use 3333")#linebreak()#text(" 3332 3331. However we do not have the points")#linebreak()#text(" 2222 or 3333 removed in this case so we must have")#linebreak()#text(" either 3332 or the pair 1112 or 3331.")#linebreak()#text(" For every one of the eight points 3332 or 2223")#linebreak()#text(" we will have a similar choice forcing either")#linebreak()#text(" the removal of the point itself or the associated")#linebreak()#text(" pair. After these choices have been made more points")#linebreak()#text(" of the form aaab can be added but there must be")#linebreak()#text(" a subset corresponding to one set of the above eight choices")#linebreak()#text(" since in each case there are only two ways to cover the lines noted.")#linebreak()#text(" Look at the pairs of lines such as 22xx and xx33")#linebreak()#text(" one with moving coordinates in two positions and")#linebreak()#text(" a two fixed coordinates equal to 2 or 3 say 2")#linebreak()#text(" the other with two fixed coordinates equal to the other")#linebreak()#text(" value which in this case is 2 so if the fixed coordinate(s)")#linebreak()#text(" in one point of the pair is 2 in the other they or it will")#linebreak()#text(" Then we must have one of the points 2211")#linebreak()#text(" 2222 2233 removed to block the first line of the pair")#linebreak()#text(" and for the second line we can use 3333")#linebreak()#text(" 2233 1133. However we do not have the points")#linebreak()#text(" 2222 or 3333 removed in this case so we must have")#linebreak()#text(" either 2233 or the pair 1133 or 2211.")#linebreak()#text(" For every one of the six points with two threes and two twos")#linebreak()#text(" we will have a similar choice forcing either")#linebreak()#text(" the removal of the point itself or the associated")#linebreak()#text(" pair. After these choices have been made more points")#linebreak()#text(" of the form aabb can be added but there must be")#linebreak()#text(" a subset corresponding to one set of the above six choices")

#text("If we start with the configuration 1111 removed all eight points with three 2’s and one three and three 3’s and one two removed and all points with two 3’s and two 2’s removed and all points of the form aabc removed then this configuration has weight 8")#linebreak()#text(" then we can perform a series of steps in order which will")#linebreak()#text(" reach all combinatorial line free configurations.")#linebreak()#text(" These steps are as follows:")

#text("1 Making choices as above for elements of the form aaab and allowing the addition")#linebreak()#text(" of all possible aabc’ss.")

#text("2 Making choices as above for elements of the form aabb and allowing the addition")#linebreak()#text(" of all possible aabc’ss.")

#text("3.Removal of points of the form aabb or aaab and addition of all possible aabc’s.")

#text("4.Removal of aabc’s.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-37114")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2009")])]

#text("1134. c^{\\mu}_4=9")

#text("Part 2 continued form 1133:")

#text("At present none of the aabc can be added")#linebreak()#text(" there are lines of the form xx12 and xx13 and x113 and x112")#linebreak()#text(" which each have to blocked to allow their addition")

#text("What we are going to do is perform the previous steps in order.")#linebreak()#text(" we will show that each step eliminates twice as much in weight")#linebreak()#text(" of elements of the form aabc as it adds of all other forms. To facilitate the proof")#linebreak()#text(" we will have to perform the operations in the order listed. However we will")#linebreak()#text(" be able to reach every possible configuration. We must have a subconfiguration")#linebreak()#text(" corresponding to one set of choices above then we can delete various elements")#linebreak()#text(" of the form aabb and aaab to get all possible line free sets of the elements of")#linebreak()#text(" the form aabb and aaab and then for each set we add the maximum possible number")#linebreak()#text(" of elements of the form aabc.")

#text("The point is doing this is that we can only add two units in weight")#linebreak()#text(" of the form aabc as the lines of the form xabc must be covered and they")#linebreak()#text(" Can only be covered by one unit in weight of elements of the form abc")#linebreak()#text(" So if we have the two to one ratio or better and have to stop at two we will")#linebreak()#text(" End up with a net change of 2-1 which will raise the weight to 9 or less")#linebreak()#text(" And we still have the maximum weight of is 9.")

#text("When we make a choice deleting a pair and adding say")#linebreak()#text(" 2223 which will give 1113 and 2221 we block three lines")#linebreak()#text(" of the form xx13 and three of the form xx12 thus allowing")#linebreak()#text(" the addition of 6 points of weight 1/12 which give a total")#linebreak()#text(" change of weight 1/2 which is exactly twice the net change in")#linebreak()#text(" weight caused by the addition of 2223 and the removal of 1113")#linebreak()#text(" of 2221")

#text("Now with each substitution there will also be the blocking of lines")#linebreak()#text(" of the form x113 or x112 however to allow the point say 2113")#linebreak()#text(" To be added we must block both x113 and 211x and to do this")#linebreak()#text(" We must make choices adding both 2223 and 2333 which unblocks")#linebreak()#text(" The line 2xx1 and forbids the addition of the point 2113 thus the increase in")#linebreak()#text(" Material of the form aabc is twice the net change in weight of the other types")

#text("1122 can block the 11×2 two at a time but their")#linebreak()#text(" weight is 1/6 so even if they block two of the 11×2")#linebreak()#text(" and allow the addition of two 1132’s the weight will")#linebreak()#text(" remain the same and since each replacement of 2233")#linebreak()#text(" by 1133 and 2211 has only one element of the form")#linebreak()#text(" 2211 we are done.")

#text("For the choices of elements")#linebreak()#text(" of the form aabb if we replace an element of the form")#linebreak()#text(" 2223 by 1113 and 2221 we will be able to block three lines")#linebreak()#text(" of the form x113 which gets rid of 3 elements of the form")#linebreak()#text(" 2113 but the weight of the addional aaab element created is 1/4 and the weight of the removed elements is the same. So step")#linebreak()#text(" two can not improve the weight. So we are done with step 2 and move on to step three")

#text("If we add an element of the form 2233 and delete 1133 and 2211 then it can unblock two lines of the form x113 and two of the form x112 thus allowing the addition of at most 4 points of the form")#linebreak()#text(" 3112 thus giving a net change of -1/4 +4/12 and again the ratio is 2 to one.")

#text("Then after all the above choices have been made we can delete elements of the form 2223 which will block at most three lines")#linebreak()#text(" Of the form 2xx3 if created by the above choices")#linebreak()#text(" And the ratio of points added to points deleted is at most one")#linebreak()#text(" And so is less than 1/2 and we are done. The case 3332")#linebreak()#text(" is handled the same way.")

#text("If we delete an element of the form 1112 we unblock three lines")#linebreak()#text(" Of the form xx12 and three of x112 we free at most 6 points with")#linebreak()#text(" Weight 1/12 giving a total weight of 1/2 the point removed is weight 1/4 so the ratio is 2 to 1 and we are done the case of")#linebreak()#text(" 1113 is similar.")

#text("If we delete an element of the form 3331 it can unblock three lines")#linebreak()#text(" of the form xx31 and we free three points for possible addition")#linebreak()#text(" The have total weight equal to the weight of 3331 so the ratio is")#linebreak()#text(" less than 2 to 1. The case of an element of the form 2221 is similar.")

#text("If we delete a point of the form 2233")#linebreak()#text(" We don’t unblock any lines so we can’t")#linebreak()#text(" Add any points of the form aabc.")

#text("If we delete a point of the form 1133 we unblock two lines")#linebreak()#text(" Of the form xx13 and two of x113 and so can add four points")#linebreak()#text(" With weight 1/12 which has total 1/3 which is twice the weight")#linebreak()#text(" Of the point 1133 so the ratio is less than or equal to 2 and we are")#linebreak()#text(" Done. The case of deleting a point of the form 1122 is handled similarly. So Step 3 is finished.")

#text("If we delete a point of the form aabc the weight is less. So we have gone through all steps and the ratio in them 2 or less and thus in this case the weight is 9 or less and we are done. Since this is the final case we have proved the theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-37205")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2009")])]

#text("1135. Other values of k")#linebreak()#text(" I have been busy the last few days, with both work and more everyday things like having a cold, but I decided to let the computers to do some new work by expandingto new values of k.")

#text("Here")#linebreak()#text(" ")#link("http://abel.math.umu.se/~klasm/Data/HJ/")[#text("http://abel.math.umu.se/~klasm/Data/HJ/")]#linebreak()#text(" is a table with the optimum sizes for subsets of [k]^n without combinatorial lines, and the optimal solutions for some cases. (Anyone who can edit the wiki is welcome to add it there)")

#text("One natural question here is; For which values of n and k is the optimum size (k-1)k^n ?")

#text("Kareem, maybe your program can improve the lower bounds for the values my program could not determine?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-37211")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2009")])]

#text("1136. c^{\\mu}_4=9")

#text("Sorry about the duplication I put the proof for the final case in and it did not go through then I split it in half and it went through later the original finally went through. I have put the cases 3 and 4 in the wiki at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Hyper-optimistic_conjecture")[#text("http://michaelnielsen.org/polymath1/index.php?title=Hyper-optimistic_conjecture")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-37233")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2009")])]

#text("1137. Dimension 2, any k")

#text("Regarding the data in Markström.1135, it is simple to show when restricting to dimension two the maximal set size has to be k(k-1). This can be done by removing the diagonal values 11, 22, 33, …, kk. Since they are in disjoint lines this removal is minimal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-37239")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2009")])]

#text("1138. Dimension 2, any k")

#text("The k missing points are one per line and one per column.")#linebreak()#text(" So their y-coordinates are a shuffle of their x-coordinates.")#linebreak()#text(" There are k! rearrangements of the numbers 1 to k.")#linebreak()#text(" The k points include a point on the diagonal, so this shuffle is not a derangement. There are k!/e derangements of the numbers 1 to k, so k!(1-1/e) optimal solutions")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-37244")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("1139. Dimension 3, k at least 3")#linebreak()#text(" Let S be a latin square of side k on the symbols 1…k, with colour i in position (i,i) ( This is not possible for k=2 )")

#text("Let axis one in S correspond to coordinate 1 in [k]^3, axis two to coordinate 2 and interpret the colour in position (i,j) as the third coordinate. Delete the points so defined.")

#text("The line with three wild cards has now been removed.")#linebreak()#text(" A line with two wildcards will be missing the point corresponding to the diagonal in S.")#linebreak()#text(" A line with a single wildcard will be missing a point corresponding to an off diagonal point in S.")

#text("Something similar should work in higher dimensions if one can find latin cubes etc with the right diagonal properties.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-37249")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("1140. ")#mi("k \\ge d")#text(", k prime")

#text("Delete those points whose coordinates add up to a multiple of k.")#linebreak()#text(" Every combinatorial line has one point deleted, except for the major diagonal of d=k, which has all points deleted.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-37252")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("1141. Values near primes")

#text("Could we extend 1140 to values near primes with only a slight loss? For instance for 100 we delete all values equal to zero mod 101 and 1 mod 101 then all combinatorial lines with d less than 101 will have 100 different values mod 101 and hence will have one deleted value. So we will have a line free set for d equal to 101 or less with density 99/101 or more.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-37253")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("1142. All values")

#text("I am looking for a further extension of 1141 according to")

#text("R. C. Baker and G. Harman, “The difference between consecutive primes,” Proc. Lond. Math. Soc., series 3, 72 (1996) 261–280. MR 96k:11111")

#text("Abstract: The main result of the paper is that for all large x, the interval A=[x-x^0.535,x] contains prime numbers.")

#text("This is from the abstract at")

#link("http://primes.utm.edu/references/refs.cgi?long=BH96")[#text("http://primes.utm.edu/references/refs.cgi?long=BH96")]

#text("I found it using:")

#link("http://primes.utm.edu/notes/gaps.html")[#text("http://primes.utm.edu/notes/gaps.html")]

#text("So for any number n there is a nearby prime p whose difference from")#linebreak()#text(" n is x^.535 so then we remove x^.535 +1 values mod p and for those values the density will be (p-x^.535-1)/p")#linebreak()#text(" of d less than p we will have no combinatorial lines.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-37254")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("1142. lower bounds on line free sets")

#text("I think the results of 1141 can be used to get lower bounds on lines free sets for large n for all values of k. For any k and any n we can find a prime prelatively close to k^n then we remove the first k+1 values mod p then we pick a value then we remove the must k+1 so we only have k+2, 2k+3, etch")#linebreak()#text(" the idea is to prevent any two values on a line because two points on a combinatorial line increase by at most k. This has density 1/k so we have")#linebreak()#text(" a line free density of 1/(k+1).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-37265")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("1143. I think the bound in 1142 could possibly be improved. First by getting most of the set concentrated around the point with equal numbers of ones twos and threes or the point with values closes to equality the standard deviation should be something like the square root of n. Then we could apply the near prime with sets c(k^.5 + 1) and get a density of roughly c/k^.5")#linebreak()#text(" which I think will be better than the Behrend-Elkin construction as e^-x will eventually be less than 1/x as x increases without limit and the square root of k will increase without limit.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/14/dhj3-1100-1199-density-hales-jewett-type-numbers/comment-page-1/#comment-37272")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("Just a quick note to say that I’m traveling at present and have not been able to reply to all the interesting progress made in the last week or so, but it looks like the project is humming along nicely without my assistance anyway! I’ll try to say something more constructive when I return next week.")
]
]
