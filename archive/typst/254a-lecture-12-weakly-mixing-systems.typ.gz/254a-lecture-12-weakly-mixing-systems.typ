// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/
// Converted to Typst by tao2typ: "2026-10-14T06:53:18.169823+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Lecture 12: Weakly mixing systems", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Lecture 12: Weakly mixing systems")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 February 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/")[#text("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the ")#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/")[#text("previous lecture")]#text(", we studied the recurrence properties of compact systems, which are systems in which all measurable functions exhibit almost periodicity – they almost return completely to themselves after repeated shifting. Now, we consider the opposite extreme of ")#emph[#text("mixing systems")]#text(" – those in which all measurable functions (of mean zero) exhibit ")#emph[#text("mixing")]#text(" – they become orthogonal to themselves after repeated shifting. (Actually, there are two different types of mixing, ")#emph[#text("strong mixing")]#text(" and ")#emph[#text("weak mixing")]#text(", depending on whether the orthogonality occurs individually or on the average; it is the latter concept which is of more importance to the task of establishing the Furstenberg recurrence theorem.)")

#text("We shall see that for weakly mixing systems, averages such as ")#mi("\\frac{1}{N} \\sum_{n=0}^{N-1} T^n f \\ldots T^{(k-1)n} f")#text(" can be computed very explicitly (in fact, this average converges to the constant ")#mi("(\\int_X f\\ d\\mu)^{k-1}")#text("). More generally, we shall see that weakly mixing components of a system tend to average themselves out and thus become irrelevant when studying many types of ergodic averages. Our main tool here will be the humble ")#link("http://en.wikipedia.org/wiki/Cauchy%E2%80%93Schwarz_inequality")[#text("Cauchy-Schwarz inequality")]#text(", and in particular a certain consequence of it, known as the ")#emph[#text("van der Corput lemma")]#text(".")

#text("As one application of this theory, we will be able to establish ")#link("http://www.ams.org/mathscinet-getitem?mr=51853")[#text("Roth’s theorem ")]#text("(the k=3 case of ")#link("http://en.wikipedia.org/wiki/Szemeredi%27s_theorem")[#text("Szemerédi’s theorem")]#text(").")

#heading(level: 1)[#metadata(none) <tao-584f4e6863efc9af73a8>#text(" — Mixing functions —")]

#text("Much as compact systems were characterised by their abundance of almost periodic functions, we will characterise mixing systems by their abundance of mixing functions (this is not standard terminology). To define and motivate this concept, it will be convenient to introduce a weak notion of convergence (this notation is also not standard):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1.")]#text(" (")#link("http://en.wikipedia.org/wiki/Ces%C3%A0ro_summation")[#text("Cesàro convergence")]#text(") A sequence ")#mi("c_n")#text(" in a normed vector space is said to ")#emph[#text("converge in the Cesàro sense")]#text(" to a limit c if the averages ")#mi("\\frac{1}{N} \\sum_{n=0}^{N-1} c_n")#text(" converge strongly to c, in which case we write ")#mi("C\\!-\\!\\lim_{n \\to \\infty} c_n = c")#text(". We also write ")#tao-math("C\\!-\\!\\sup_{n \\to \\infty} c_n := \\limsup_{N \\to \\infty} \\left\\|\\frac{1}{N} \\sum_{n=0}^{N-1} c_n\\right\\|", block: false)#text(" (thus ")#mi("C\\!-\\!\\lim_{n \\to \\infty} c_n = 0")#text(" if and only if ")#mi("C\\!-\\!\\sup_{n \\to \\infty} c_n = 0")#text(").")
]

#strong[#text("Example 1.")]#text(" The sequence ")#mi("0,1,0,1,\\ldots")#text(" has a Cesàro limit of 1/2. ")#mi("\\diamond")

#strong[#text("Exercise 1.")]#text(" Let ")#mi("c_n")#text(" be a bounded sequence of ")#emph[#text("non-negative ")]#text("numbers. Show that the following three statements are equivalent:")

#enum(start: 1, 
[#mi("C\\!-\\!\\lim_{n \\to \\infty} c_n = 0")#text(".")],
[#tao-math("C\\!-\\!\\lim_{n \\to \\infty} \\left|c_n\\right|^2 = 0", block: false)#text(".")],
[#mi("c_n")#text(" converges to zero in density. [We say ")#mi("c_n")#text(" ")#emph[#text("converges in density")]#text(" to c if for any ")#mi("\\varepsilon > 0")#text(", the set ")#tao-math("\\{n \\in {\\Bbb N}: \\left|c_n-c\\right| > \\varepsilon\\}", block: false)#text(" has upper density zero.]")]
)

#text("Which of the implications between 1, 2, 3 remain valid if ")#mi("c_n")#text(" is not bounded? ")#mi("\\diamond")#text("Let ")#mi("(X,{\\mathcal X},\\mu,T)")#text(" be a measure-preserving system, and let ")#mi("f \\in L^2(X,{\\mathcal X},\\mu)")#text(" be a function. We consider the ")#emph[#text("correlation coefficients")]#text(" ")#mi("\\langle T^n f, f \\rangle := \\int_X T^n f \\overline{f}\\ d\\mu")#text(" as n goes to infinity. Note that we have the symmetry ")#mi("\\langle T^n f, f \\rangle = \\overline{\\langle T^{-n} f, f \\rangle}")#text(", so we only need to consider the case when n is positive. The mean ergodic theorem (Corollary 2 from ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("Lecture 8")]#text(") tells us the Cesàro behaviour of these coefficients. Indeed, we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("C\\!-\\!\\lim_{n \\to \\infty} \\langle T^n f, f \\rangle = \\langle {\\Bbb E}(f|{\\mathcal X}^T), f \\rangle = \\left\\| {\\Bbb E}(f|{\\mathcal X}^T) \\right\\|_{L^2(X, {\\mathcal X}, \\mu)}^2", block: true)]]

#text("where ")#mi("{\\mathcal X}^T")#text(" is the ")#mi("\\sigma")#text("-algebra of essentially shift-invariant sets. In particular, if the system is ergodic, and f has mean zero (i.e. ")#mi("\\int_X f\\ d\\mu = 0")#text("), then we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("C\\!-\\!\\lim_{n \\to \\infty} \\langle T^n f, f \\rangle = 0,")]]

#text("thus the correlation coefficients go to zero in the Cesàro sense. However, this does not necessarily imply that these coefficients go to zero pointwise. For instance, consider a circle shift system ")#mi("({\\Bbb R}/{\\Bbb Z}, x \\mapsto x+\\alpha)")#text(" with ")#mi("\\alpha")#text(" irrational (and with uniform measure), thus this system is ergodic by Exercise 5 from ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("Lecture 9")]#text(". Then the function ")#mi("f(x) := e^{2\\pi i x}")#text(" has mean zero, but one easily computes that ")#mi("\\langle T^n f, f \\rangle = e^{2\\pi i n \\alpha}")#text(". The coefficients ")#mi("e^{2\\pi i n \\alpha}")#text(" converge in the Cesàro sense to zero, but have magnitude 1 and thus do not converge to zero pointwise.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2. ")]#text("(Mixing) Let ")#mi("(X,{\\mathcal X},\\mu,T)")#text(" be a measure-preserving system. A function ")#mi("f \\in L^2(X,{\\mathcal X},\\mu)")#text(" is ")#emph[#text("strongly mixing")]#text(" if ")#mi("\\lim_{n \\to \\infty} \\langle T^n f, f \\rangle = 0")#text(", and ")#emph[#text("weakly mixing")]#text(" if ")#tao-math("C\\!-\\!\\lim_{n \\to \\infty} \\left|\\langle T^n f, f \\rangle\\right| = 0", block: false)#text(".")
]

#strong[#text("Remark 1.")]#text(" Clearly strong mixing implies weak mixing. From (1) we also see that if f is weakly mixing, then ")#mi("{\\Bbb E}(f|{\\mathcal X}^T)")#text(" must vanish a.e. ")#mi("\\diamond")

#strong[#text("Exercise 2.")]#text(" Show that if f is both almost periodic and weakly mixing, then it must be 0 almost everywhere. In particular, in a compact system, the only weakly mixing function is 0 (up to a.e. equivalence). ")#mi("\\diamond")

#strong[#text("Exercise 3.")]#text(" In any Bernoulli system ")#mi("\\Omega^{\\Bbb Z}")#text(" with the product ")#mi("\\sigma")#text("-algebra and a product measure, and the standard shift, show that any function of mean zero is strongly mixing. (")#emph[#text("Hint")]#text(": first do this for functions that depend on only finitely many of the variables.) ")#mi("\\diamond")

#strong[#text("Exercise 4.")]#text(" Consider a skew shift system ")#mi("( ({\\Bbb R}/{\\Bbb Z})^2, (x,y) \\mapsto (x+\\alpha,y+x) )")#text(" with the usual Lebesgue measure and Borel ")#mi("\\sigma")#text("-algebra, and with ")#mi("\\alpha")#text(" irrational. Show that the function ")#mi("f(x,y) := e^{2\\pi i x}")#text(" is neither strongly mixing nor weakly mixing, but that the function ")#mi("g(x,y) := e^{2\\pi i y}")#text(" is both strongly mixing and weakly mixing. ")#mi("\\diamond")

#strong[#text("Exercise 5.")]#text(" Let ")#mi("X := {\\Bbb C}^{\\Bbb Z}")#text(" be given the product Borel ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal X}")#text(" and the shift ")#mi("T: (z_n)_{n \\in {\\Bbb Z}} \\to (z_{n+1})_{n \\in {\\Bbb Z}}")#text(". For each ")#mi("d \\geq 1")#text(", let ")#mi("\\mu_d")#text(" be the probability distribution in X of the random sequence ")#mi("(z_n)_{n \\in {\\Bbb Z}}")#text(" given by the rule")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("z_n := \\frac{1}{2^{d/2}} \\sum_{\\omega_1,\\ldots,\\omega_d \\in \\{0,1\\}} w_{\\omega_1,\\ldots,\\omega_d} e^{2\\pi i \\sum_{j=1}^d \\omega_j n / 100^j},")]]

#text("where the ")#mi("w_{\\omega_1,\\ldots,\\omega_d}")#text(" are iid standard complex Gaussians (thus each w has probability distribution ")#tao-math("e^{-\\pi \\left|w\\right|^2}\\ dw", block: false)#text("). Show that each ")#mi("\\mu_d")#text(" is shift invariant. If ")#mi("\\mu")#text(" is a vague limit point of the sequence ")#mi("\\mu_d")#text(", and ")#mi("f: X \\to {\\Bbb C}")#text(" is the function defined as ")#mi("f( (z_n)_{n \\in {\\Bbb Z}} ) := \\text{sgn}( \\text{Re} z_0 )")#text(", show that f is weakly mixing but not strongly mixing (and more specifically, that ")#mi("\\langle T^{100^j} f, f \\rangle")#text(" stays bounded away from zero) with respect to the system ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(". ")#mi("\\diamond")

#strong[#text("Remark 2. ")]#text(" Exercise 5 illustrates an important point, namely that ")#link("http://en.wikipedia.org/wiki/Stationary_process")[#text("stationary processes")]#text(" yield a rich source of measure-preserving systems (indeed the two notions are almost equivalent in some sense, especially after one distinguishes a specific function f on the measure-preserving system). However, we will not adopt this more probabilistic perspective to ergodic theory here. ")#mi("\\diamond")

#strong[#text("Remark 3.")]#text(" We briefly discuss the finitary analogue of the weak mixing concept in the context of functions ")#mi("f: {\\Bbb Z}/N{\\Bbb Z} \\to {\\Bbb C}")#text(" on a large cyclic group ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(" with the usual shift ")#mi("x \\mapsto x+1")#text(". Then one can compute")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("C\\!-\\!\\lim_{n \\to \\infty} \\left|\\langle T^n f, f \\rangle\\right|^2 = \\sum_{\\xi \\in {\\Bbb Z}/N{\\Bbb Z}} \\left|\\hat f(\\xi)\\right|^4", block: true)]]

#text("where ")#mi("\\hat f(\\xi) := \\frac{1}{N} \\sum_{x \\in {\\Bbb Z}/N{\\Bbb Z}} f(x) e^{-2\\pi i x \\xi/N}")#text(" are the Fourier coefficients of f. Comparing this against the Plancherel identity ")#tao-math("\\left\\| f \\right\\|_{L^2}^2 = \\sum_{\\xi \\in {\\Bbb Z}/N{\\Bbb Z}} \\left|\\hat f(\\xi)\\right|^2", block: false)#text(" we thus see that a function f bounded in ")#mi("L^2")#text(" norm should be considered “weakly mixing” if it has no large Fourier coefficients. Contrast this with Remark 7 from ")#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/")[#text("Lecture 11")]#text(". ")#mi("\\diamond")

#text("Now let us see some consequences of the weak mixing property. We need the following lemma, which gives a useful criterion as to whether a sequence of bounded vectors in a Hilbert space converges in the Cesàro sense to zero.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (van der Corput lemma)")]#text(". Let ")#mi("v_1, v_2, v_3, \\ldots")#text(" be a bounded sequence of vectors in a Hilbert space H. If")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("C\\!-\\!\\lim_{h\\to \\infty} C\\!-\\!\\sup_{n \\to \\infty} \\langle v_n, v_{n+h} \\rangle = 0")]]

#text("then ")#mi("C\\!-\\!\\lim_{n \\to \\infty} v_n = 0")#text(".")
]

#text("Informally, this lemma asserts that if each vector in a bounded sequence tends to be orthogonal to nearby elements in that sequence, then the vectors will converge to zero in the Cesàro sense. This formulation of the lemma is essentially the version in this ")#link("http://www.ams.org/mathscinet-getitem?mr=912373")[#text("paper by Bergelson")]#text(", except that we have made the minor change of replacing one of the Cesàro limits with a Cesàro supremum.")

#strong[#text("Proof.")]#text(" We can normalise so that ")#tao-math("\\left\\|v_n\\right\\| \\leq 1", block: false)#text(" for all n. In particular, we have ")#mi("v_n = O(1)")#text(", where O(1) denotes a vector of bounded magnitude. For any h and ")#mi("N \\geq 1")#text(", we thus have the telescoping identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\frac{1}{N} \\sum_{n=0}^{N-1} v_{n+h} = \\frac{1}{N} \\sum_{n=0}^{N-1} v_n + O( \\left|h\\right| / N );", block: true)]]

#text("averaging this over all h from 0 to H-1 for some ")#mi("H \\geq 1")#text(", we obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\frac{1}{N} \\sum_{n=0}^{N-1} \\frac{1}{H} \\sum_{h=0}^{H-1} v_{n+h} = \\frac{1}{N} \\sum_{n=0}^{N-1} v_n + O( H / N );")]]

#text("by the triangle inequality we thus have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\| \\frac{1}{N} \\sum_{n=0}^{N-1} v_n \\right\\| \\leq \\frac{1}{N} \\sum_{n=0}^{N-1} \\left\\| \\frac{1}{H} \\sum_{h=0}^{H-1} v_{n+h} \\right\\| + O( H/N )", block: true)]]

#text("where the O() terms are now scalars rather than vectors. We square this (using the crude inequality ")#mi("(a+b)^2 \\leq 2a^2 + 2b^2")#text(") and apply Cauchy-Schwarz to obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left\\| \\frac{1}{N} \\sum_{n=0}^{N-1} v_n \\right\\|^2 \\leq O( \\frac{1}{N} \\sum_{n=0}^{N-1} \\left\\| \\frac{1}{H} \\sum_{h=0}^{H-1} v_{n+h} \\right\\|^2 ) + O( H^2/N^2 )", block: true)]]

#text("which we rearrange as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left\\| \\frac{1}{N} \\sum_{n=0}^{N-1} v_n \\right\\|^2 \\leq O( \\frac{1}{H^2} \\sum_{0 \\leq h,h^{\\prime} < H} \\frac{1}{N} \\sum_{n=0}^{N-1} \\langle v_{n+h}, v_{n+h^{\\prime}} \\rangle ) + O( H^2/N^2 ).", block: true)]]

#text("We take limits as ")#mi("N \\to \\infty")#text(" (keeping H fixed for now) to conclude")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{N \\to \\infty} \\left\\| \\frac{1}{N} \\sum_{n=0}^{N-1} v_n \\right\\|^2", block: true)]]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\leq O( \\frac{1}{H^2} \\sum_{0 \\leq h,h^{\\prime} < H} C\\!-\\!\\sup_{n \\to \\infty} \\langle v_{n+h}, v_{n+h^{\\prime}} \\rangle ).")]]

#text("Another telescoping argument (and symmetry) gives us")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("C\\!-\\!\\sup_{n \\to \\infty} \\langle v_{n+h}, v_{n+h^{\\prime}} \\rangle = C\\!-\\!\\sup_{n \\to \\infty} \\langle v_{n+\\left|h-h^{\\prime}\\right|}, v_n \\rangle", block: true)]]

#text("and so")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\limsup_{N \\to \\infty} \\left\\| \\frac{1}{N} \\sum_{n=0}^{N-1} v_n \\right\\|^2 \\leq O( \\frac{1}{H} \\sum_{0 \\leq h < H} C\\!-\\!\\sup_{n \\to \\infty} \\langle v_{n+h}, v_{n} \\rangle ).", block: true)]]

#text("Taking limits as ")#mi("H \\to \\infty")#text(" and using (5) we obtain the claim. ")#mi("\\Box")

#strong[#text("Exercise 6.")]#text(" Let ")#mi("P: {\\Bbb Z} \\to {\\Bbb R}/{\\Bbb Z}")#text(" be a polynomial with at least one irrational non-constant coefficient. Using Lemma 1 (in the scalar case ")#mi("H = {\\Bbb C}")#text(") and an induction on degree, show that ")#mi("C\\!-\\!\\lim_{n \\to \\infty} e^{2\\pi i P(n)} = 0")#text(". Conclude that the sequence ")#mi("(P(n))_{n \\in {\\Bbb N}}")#text(" is uniformly distributed with respect to uniform measure (see ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("Lecture 9")]#text(" for a definition of uniform distribution). ")#mi("\\diamond")

#strong[#text("Exercise 7.")]#text(" Using Exercise 6, give another proof of Theorem 1 from ")#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/")[#text("Lecture 6")]#text(". ")#mi("\\diamond")

#text("We now apply the van der Corput lemma to weakly mixing functions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1. ")]#text("Let ")#mi("(X,{\\mathcal X},\\mu,T)")#text(" be a measure-preserving system, and let ")#mi("f \\in L^2(X, {\\mathcal X},\\mu)")#text(" be weakly mixing. Then for any ")#mi("g \\in L^2(X, {\\mathcal X},\\mu)")#text(" we have ")#tao-math("C\\!-\\!\\lim_{n \\to \\infty} \\left|\\langle T^n f, g \\rangle\\right| = 0", block: false)#text(" and ")#tao-math("C\\!-\\!\\lim_{n \\to \\infty} \\left|\\langle f, T^n g \\rangle\\right| = 0", block: false)#text(".")
]

#strong[#text("Proof.")]#text(" We just prove the first claim, as the second claim is similar. By Exercise 1, it suffices to show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\frac{1}{N} \\sum_{n=0}^{N-1} \\left|\\langle T^n f, g \\rangle\\right|^2 \\to 0", block: true)]]

#text("as ")#mi("N \\to \\infty")#text(". The left-hand side can be rewritten as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\langle \\frac{1}{N} \\sum_{n=0}^{N-1} \\langle g, T^n f \\rangle T^n f, g \\rangle")]]

#text("so by Cauchy-Schwarz it suffices to show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("C\\!-\\!\\lim_{N \\to \\infty} \\langle g, T^n f \\rangle T^n f = 0.")]]

#text("Applying the van der Corput lemma and discarding the bounded coefficients ")#mi("\\langle g, T^n f \\rangle")#text(", it suffices to show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("C\\!-\\!\\lim_{H \\to \\infty} C\\!-\\!\\sup_{n \\to \\infty} \\left|\\langle T^{n+h} f, T^n f \\rangle\\right| = 0.", block: true)]]

#text("But ")#mi("\\langle T^{n+h} f, T^n f \\rangle = \\langle T^h f, f \\rangle")#text(", and the claim now follows from the weakly mixing nature of f. ")#mi("\\Box")

#heading(level: 1)[#text("— Weakly mixing systems —")]

#text("Now we consider systems which are full of mixing functions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3. ")]#text("(Mixing systems) A measure-preserving system ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" is ")#emph[#text("weakly mixing")]#text(" (resp. ")#emph[#text("strongly mixing")]#text(") if every function ")#mi("f \\in L^2(X, {\\mathcal X}, \\mu)")#text(" with mean zero is weakly mixing (resp. strongly mixing).")
]

#strong[#text("Example 2.")]#text(" From Exercise 2, we know that any system with a non-trivial Kronecker factor is not weakly mixing (and thus not strongly mixing). On the other hand, from Exercise 3, we know that any Bernoulli system is strongly mixing (and thus weakly mixing also). From Remark 1 we see that any strongly or weakly mixing system must be ergodic. ")#mi("\\diamond")

#strong[#text("Exercise 8. ")]#text(" Show that the system in Exercise 5 is weakly mixing but not strongly mixing. ")#mi("\\diamond")

#text("Here is another characterisation of weak mixing:")

#strong[#text("Exercise 9.")]#text(" Let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be a measure preserving system. Show that the following are equivalent:")

#enum(start: 1, 
[#mi("(X, {\\mathcal X}, \\mu, T)")#text(" is weakly mixing.")],
[#text("For every ")#mi("f, g \\in L^2(X, {\\mathcal X}, \\mu)")#text(", ")#mi("\\langle T^n f, g \\rangle")#text(" converges in density to ")#mi("(\\int_X f\\ d\\mu) (\\int_X \\overline{g}\\ d\\mu)")#text(". (See Exercise 1 for a definition of convergence in density.)")],
[#text("For any measurable ")#mi("E, F")#text(", ")#mi("\\mu( T^n E \\cap F )")#text(" converges in density to ")#mi("\\mu(E) \\mu(F)")#text(".")],
[#text("The product system ")#mi("(X \\times X, {\\mathcal X} \\times {\\mathcal X}, \\mu \\times \\mu, T \\times T)")#text(" is ergodic.")]
)

#text("[Hints: To equate 1 and 2, use the decomposition ")#mi("f = (f-\\int_X f\\ d\\mu) + \\int_X f\\ d\\mu")#text(" of a function into its mean and mean-free components. To equate 2 and 4, use the fact that the space ")#mi("L^2( X \\times X, {\\mathcal X} \\times {\\mathcal X}, \\mu \\times \\mu)")#text(" is spanned (in the topological vector space sense) by tensor products ")#mi("(x,y) \\mapsto f(x) g(y)")#text(" with ")#mi("f, g \\in L^2(X, {\\mathcal X}, \\mu)")#text(".] ")#mi("\\diamond")

#strong[#text("Exercise 10. ")]#text("Show that the equivalences between 1, 2, 3 in Exercise 9 remain if “weak mixing” and “converges in density” are replaced by “strong mixing” and “converges” respectively. ")#mi("\\diamond")

#strong[#text("Exercise 11.")]#text(" Let ")#mi("(X, {\\mathcal F}, T)")#text(" be any minimal topological system with Borel ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal B}")#text(", and let ")#mi("\\mu")#text(" be a shift invariant Borel probability measure. Show that if ")#mi("(X, {\\mathcal B},\\mu, T)")#text(" is weakly mixing (resp. strongly mixing), then ")#mi("(X, {\\mathcal F}, T)")#text(" is topologically weakly mixing (resp. topologically mixing), as defined in Definition 3 and Exercise 12 of ")#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/")[#text("Lecture 7")]#text(". ")#mi("\\diamond")

#strong[#text("Exercise 12. ")]#text("If ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" is weakly mixing, show that ")#mi("(X, {\\mathcal X}, \\mu, T^n)")#text(" is weakly mixing for any non-zero n. ")#mi("\\diamond")

#strong[#text("Exercise 13. ")]#text(" Let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be a measure preserving system. Show that the following are equivalent:")

#enum(start: 1, 
[#mi("(X, {\\mathcal X}, \\mu, T)")#text(" is weakly mixing.")],
[#text("Whenever ")#mi("(Y, {\\mathcal Y}, \\nu, S)")#text(" is ergodic, the product system ")#mi("(X \\times Y, {\\mathcal X} \\times {\\mathcal Y}, \\mu \\times \\nu, T \\times S)")#text(" is ergodic.")]
)

#text("(Hint: To obtain 1 from 2, use Exercise 9. To obtain 2 from 1, repeat the ")#emph[#text("methods")]#text(" used to prove Exercise 9.) ")#mi("\\diamond")

#strong[#text("Exercise 14. ")]#text("Show that the product of two weakly mixing systems is again weakly mixing. (Hint: use Exercises 9 and 13.) ")#mi("\\diamond")

#text("Now we come to an important type of observation for the purposes of establishing the Furstenberg recurrence theorem: in weakly mixing systems, functions of mean zero are negligible as far as multiple averages are concerned.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" Let ")#mi("a_1, \\ldots, a_k \\in {\\Bbb Z}")#text(" be distinct non-zero integers for some ")#mi("k \\geq 1")#text(". Let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be weakly mixing, and let ")#mi("f_1, \\ldots, f_k \\in L^\\infty(X, {\\mathcal X}, \\mu)")#text(" be such that at least one of ")#mi("f_1,\\ldots,f_k")#text(" has mean zero. Then we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("C\\!-\\!\\lim_{n \\to \\infty} T^{a_1 n} f_1 \\ldots T^{a_k n} f_k = 0")]]

#text("in ")#mi("L^2(X, {\\mathcal X}, \\mu)")#text(".")
]

#strong[#text("Proof.")]#text(" We induct on k. When k=1 the claim follows from the mean ergodic theorem and Exercise 12 (recall from Example 2 that all weakly mixing systems are ergodic).")

#text("Now let ")#mi("k \\geq 2")#text(" and suppose that the claim has already been proven for k-1. Without loss of generality we may assume that it is ")#mi("f_1")#text(" which has mean zero. Applying the van der Corput lemma (Lemma 1), it suffices to show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("C\\!-\\!\\sup_{n \\to \\infty} \\langle T^{a_1 (n+h)} f_1 \\ldots T^{a_k (n+h)} f_k, T^{a_1 n} f_1 \\ldots T^{a_k n} f_k \\rangle")]]

#text("converges in density to zero as ")#mi("h \\to \\infty")#text(". But the left-hand side can be rearranged as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("C\\!-\\!\\sup_{n \\to \\infty} \\int_X T^{(a_1-a_k)n} f_{1,h} \\ldots T^{(a_{k-1}-a_k)n} f_{k-1,h} f_{k,h}\\ d\\mu")]]

#text("where ")#mi("f_{j,h} := T^{a_j h} f_j \\overline{f_j}")#text(". Applying Cauchy-Schwarz, it suffices to show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("C\\!-\\!\\sup_{n \\to \\infty} T^{(a_1-a_k)n} f_{1,h} \\ldots T^{(a_{k-1}-a_k)n} f_{k-1,h}")]]

#text("converges in density to zero as ")#mi("h \\to \\infty")#text(".")

#text("Since ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" is weakly mixing, the mean-zero function ")#mi("f_1")#text(" is weakly mixing, and so the mean of ")#mi("f_{1,h}")#text(" goes to zero in density as ")#mi("h \\to \\infty")#text(". As all functions are assumed to be bounded, we can thus subtract the mean from ")#mi("f_{1,h}")#text(" in (21) without affecting the desired conclusion, leaving behind the mean-zero component ")#mi("f_{1,h} - \\int_X f_{1,h}\\ d\\mu")#text(". But then the contribution of this expression to (21) vanishes by the induction hypothesis. ")#mi("\\Box")

#strong[#text("Remark 4. ")]#text(" The key point here was that functions f of mean zero were weakly mixing and thus had the property that ")#mi("T^h f \\overline{f}")#text(" almost had mean zero, and were thus almost weakly mixing. One could iterate this further to investigate the behaviour of “higher derivatives” of f such as ")#mi("T^{h+h^{\\prime}} f \\overline{T^h f} \\overline{T^{h^{\\prime}} f} f")#text(". Pursuing this analysis further leads to the ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("Gowers-Host-Kra seminorms")]#text(", which are closely related to the ")#link("http://www.ams.org/mathscinet-getitem?mr=1844079")[#text("Gowers uniformity norms")]#text(" in additive combinatorics. ")#mi("\\diamond")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2.")]#text(" Let ")#mi("a_1, \\ldots, a_k \\in {\\Bbb Z}")#text(" be distinct integers for some ")#mi("k \\geq 1")#text(", let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be a weakly mixing system, and let ")#mi("f_1,\\ldots,f_k \\in L^\\infty(X, {\\mathcal X}, \\mu)")#text(". Then ")#mi("\\int_X T^{a_1 n} f_1 \\ldots T^{a_k n} f_k\\ d\\mu")#text(" converges in the Cesáro sense to ")#mi("(\\int_X f_1\\ d\\mu) \\ldots (\\int_X f_k\\ d\\mu)")#text(".")
]

#text("Note in particular that this establishes the Furstenberg recurrence theorem (Theorem 1 from ")#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/")[#text("Lecture 11")]#text(") in the case of weakly mixing systems.")

#strong[#text("Proof.")]#text(" We again induct on k. The k=1 case is trivial, so suppose ")#mi("k > 1")#text(" and the claim has already been proven for k-1. If any of the functions ")#mi("f_j")#text(" is constant then the claim follows from the induction hypothesis, so we may subtract off the mean from each function and suppose that all functions have mean zero. By shift-invariance we may also fix ")#mi("a_k")#text(" (say) to be zero. The claim now follows from Proposition 1 and Cauchy-Schwarz. ")#mi("\\Box")

#strong[#text("Exercise 15.")]#text(" Show that the Cesáro convergence in Corollary 2 can be strengthened to convergence in density. (Hint: first reduce to the mean zero case, then apply Exercise 14 to work with the product system instead.) ")#mi("\\diamond")

#strong[#text("Exercise 16.")]#text(" Let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be a weakly mixing system, and let ")#mi("f \\in L^\\infty(X, {\\mathcal X}, \\mu)")#text(" have mean zero. Show that ")#mi("T^{n^2} f")#text(" converges in the Cesáro sense in ")#mi("L^2(X, {\\mathcal X}, \\mu)")#text(" to zero. (Hint: use van der Corput and Proposition 1 or Corollary 2.) ")#mi("\\diamond")

#strong[#text("Exercise 17.")]#text(" Show that Corollary 2 continues to hold if the linear polynomials ")#mi("a_1 n, \\ldots, a_k n")#text(" are replaced by arbitrary polynomials ")#mi("P_1(n),\\ldots,P_k(n)")#text(" from the integers to the integers, so long as the difference between any two of these polynomials is non-constant. (Hint: you will need the “PET induction” machinery from Exercise 3 of ")#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/")[#text("Lecture 5")]#text(". This result was first established ")#link("http://www.ams.org/mathscinet-getitem?mr=912373")[#text("by Bergelson")]#text(".) ")#mi("\\diamond")

#heading(level: 1)[#text("— Hilbert-Schmidt operators —")]

#text("We have now established the Furstenberg recurrence theorem for two distinct types of systems: compact systems and weakly mixing systems. From Example 2 we know that these systems are indeed quite distinct from each other. Here is another indication of “distinctness”:")

#strong[#text("Exercise 18. ")]#text(" In any measure-preserving system ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(", show that almost periodic functions and weakly mixing functions are always orthogonal to each other. ")#mi("\\diamond")

#text("On the other hand, there are certainly systems which are neither weakly mixing nor compact (e.g. the skew shift). But we have the following important dichotomy (cf. Theorem 3 from Lecture 7):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" Suppose that ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" is a measure-preserving system. Then exactly one of the following statements is true:")

#enum(start: 1, 
[#text("(Structure) ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" has a non-trivial compact factor.")],
[#text("(Randomness) ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" is weakly mixing.")]
)
]

#text("[Note: in ergodic theory, a ")#emph[#text("factor")]#text(" of a measure-preserving system is simply a morphism from that system to some other measure-preserving system. Unlike the case with topological dynamics, we do not need to assume surjectivity of the morphism, since in the measure-theoretic setting, the image of a morphism always has full (outer) measure.]")

#text("In Example 2 we have already shown that 1 and 2 cannot be both true; the tricky part is to show that lack of weak mixing implies a non-trivial compact factor.")

#text("In order to prove this result, we recall some standard results about ")#link("http://en.wikipedia.org/wiki/Hilbert-Schmidt_operator")[#text("Hilbert-Schmidt operators")]#text(" on a separable Hilbert space. (As usual, the hypothesis of separability is not absolutely essential, but is convenient to assume throughout; for instance, it assures that orthonormal bases always exist and are at most countable.) We begin by recalling the notion of a ")#link("http://en.wikipedia.org/wiki/Tensor_product_of_Hilbert_spaces")[#text("tensor product of two Hilbert spaces")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2.")]#text(" Let ")#mi("H, H^{\\prime}")#text(" be two separable Hilbert spaces. Then there exists another separable Hilbert space ")#mi("H \\otimes H^{\\prime}")#text(" and a bilinear tensor product map ")#mi("\\otimes: H \\times H^{\\prime} \\to H \\otimes H^{\\prime}")#text(" such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\langle v \\otimes v^{\\prime}, w \\otimes w^{\\prime} \\rangle_{H \\otimes H^{\\prime}} = \\langle v, w \\rangle_H \\langle v^{\\prime}, w^{\\prime} \\rangle_{H^{\\prime}}")]]

#text("for all ")#mi("v, w \\in H")#text(" and ")#mi("v^{\\prime}, w^{\\prime} \\in H^{\\prime}")#text(". Furthermore, the tensor products ")#mi("(e_n \\otimes e^{\\prime}_{n^{\\prime}})_{n \\in A, n^{\\prime} \\in A^{\\prime}}")#text(" between any ")#link("http://en.wikipedia.org/wiki/Orthonormal_basis")[#text("orthonormal bases")]#text(" ")#mi("(e_n)_{n \\in A}")#text(", ")#mi("(e^{\\prime}_{n^{\\prime}})_{n^{\\prime} \\in A^{\\prime}}")#text(" of H and H’ respectively, form an orthonormal basis of ")#mi("H \\otimes H^{\\prime}")#text(".")
]

#text("It is easy to see that ")#mi("H \\otimes H^{\\prime}")#text(" is unique up to isomorphism, and so we shall abuse notation slightly and refer to ")#mi("H \\otimes H^{\\prime}")#text(" as ")#strong[#text("the")]#text(" tensor product of H and H’.")

#strong[#text("Example 3. ")]#text(" The tensor product of ")#mi("L^2(X,{\\mathcal X},\\mu)")#text(" and ")#mi("L^2(Y, {\\mathcal Y},\\nu)")#text(" is ")#mi("L^2(X \\times Y, {\\mathcal X} \\times {\\mathcal Y}, \\mu \\times \\nu)")#text(", with the tensor product operation ")#mi("f \\otimes g(x,y) := f(x) g(y)")#text(". The tensor product of ")#mi("{}{\\Bbb C}^m")#text(" and ")#mi("{\\Bbb C}^n")#text(" is ")#mi("{\\Bbb C}^{n \\times m}")#text(", which can be thought of as the Hilbert space of ")#mi("n \\times m")#text(" (or ")#mi("m \\times n")#text(") matrices, with the inner product ")#mi("\\langle A, B \\rangle := \\text{tr}(A B^\\dagger) = \\text{tr}(A^\\dagger B)")#text(". ")#mi("\\diamond")

#strong[#text("Proof.")]#text(" Take any orthonormal bases ")#mi("(e_n)_{n \\in A}")#text(" and ")#mi("(e^{\\prime}_{n^{\\prime}})_{n^{\\prime} \\in A^{\\prime}}")#text(" of H and H’ respectively, and let ")#mi("H \\otimes H^{\\prime}")#text(" be the Hilbert space generated by declaring the formal quantities ")#mi("e_n \\otimes e^{\\prime}_{n^{\\prime}}")#text(" to be an orthonormal basis. If one then defines")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("(\\sum_n c_n e_n) \\otimes (\\sum_{n^{\\prime}} c^{\\prime}_{n^{\\prime}} e_{n^{\\prime}}) := \\sum_n \\sum_{n^{\\prime}} c_n c^{\\prime}_{n^{\\prime}} e_n \\otimes e_{n^{\\prime}}")]]

#text("for all square-summable sequences ")#mi("c_n")#text(" and ")#mi("c^{\\prime}_{n^{\\prime}}")#text(", one easily verifies that ")#mi("\\otimes")#text(" is indeed a bilinear map that obeys (22). in particular, if ")#mi("(f_m)_{m \\in B}")#text(" and ")#mi("(f^{\\prime}_{m^{\\prime}})_{m^{\\prime} \\in B^{\\prime}}")#text(" are some other orthonormal bases of ")#mi("H, H^{\\prime}")#text(" respectively, then from (22) ")#mi("(f_m \\otimes f^{\\prime}_{m^{\\prime}})_{m \\in B, m^{\\prime} \\in B^{\\prime}}")#text(" is an orthonormal set, and one can approximate any element ")#mi("e_n \\otimes e^{\\prime}_{n^{\\prime}}")#text(" in the original orthonormal basis to arbitrary accuracy by linear combinations from this orthonormal set, and so this set is in fact an orthonormal basis as required. ")#mi("\\Box")

#text("Given a Hilbert space H, define its ")#emph[#text("complex conjugate")]#text(" ")#mi("\\overline{H}")#text(" to be the set of formal conjugates ")#mi("\\overline{H} = \\{ \\overline{v}: v \\in H \\}")#text(" of elements of ")#mi("H")#text(", with the addition structure ")#mi("\\overline{v} + \\overline{w} := \\overline{v + w}")#text(", the conjugated scalar multiplication structure ")#mi("\\overline{z \\overline{v}} := \\overline{\\overline{z} v}")#text(" and the conjugated inner product ")#mi("\\langle \\overline{z},\\overline{w} \\rangle_{\\overline H} := \\overline{\\langle z, w \\rangle_H} = \\langle w, z \\rangle_H")#text(". This is also a Hilbert space. (Of course, for real Hilbert spaces rather than complex, the notion of complex conjugation is trivial.)")

#strong[#text("Example 4. ")]#text("The conjugation map ")#mi("f \\mapsto \\overline{f}")#text(" is a Hilbert space isometry between the Hilbert space ")#mi("L^2(X, {\\mathcal X}, \\mu)")#text(" and its complex conjugate. ")#mi("\\diamond")

#text("Every element ")#mi("K \\in \\overline{H} \\otimes H^{\\prime}")#text(" induces a bounded linear operator ")#mi("T_K: H \\to H^{\\prime}")#text(", defined via duality by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\langle T_K v, v^{\\prime} \\rangle_{H^{\\prime}} := \\langle K, \\overline{v} \\otimes v^{\\prime} \\rangle_{\\overline{H} \\otimes H}")]]

#text("for all ")#mi("v \\in H, v^{\\prime} \\in H^{\\prime}")#text(". We refer to K as the ")#emph[#text("kernel")]#text(" of ")#mi("T_K")#text(". Any operator ")#mi("T = T_K")#text(" that arises in this manner is called a ")#emph[#text("Hilbert-Schmidt operator")]#text(" from H to H’. The Hilbert space structure on the space ")#mi("\\overline{H} \\otimes H^{\\prime}")#text(" of kernels induces an analogous Hilbert space structure on the Hilbert-Schmidt operators, leading to the Hilbert-Schmidt norm ")#tao-math("\\left\\|T\\right\\|_{HS}", block: false)#text(" and inner product ")#mi("\\langle S, T \\rangle_{HS}")#text(" for such operators. Here are some other characterisations of this concept:")

#strong[#text("Exercise 19.")]#text(" Let ")#mi("H, H^{\\prime}")#text(" be Hilbert spaces with orthonormal bases ")#mi("(e_n)_{n \\in A}")#text(" and ")#mi("(e^{\\prime}_{n^{\\prime}})_{n^{\\prime} \\in A^{\\prime}}")#text(" respectively, and let ")#mi("T: H \\to H^{\\prime}")#text(" be a bounded linear operator. Show that the following are equivalent:")

#enum(start: 1, 
[#text("T is a Hilbert-Schmidt operator.")],
[#tao-math("\\sum_{n \\in A} \\left\\| T e_n \\right\\|_{H^{\\prime}}^2 < \\infty", block: false)#text(".")],
[#tao-math("\\sum_{n \\in A} \\sum_{n^{\\prime} \\in A^{\\prime}} \\left|\\langle T e_n, e^{\\prime}_{n^{\\prime}} \\rangle_{H^{\\prime}}\\right|^2 < \\infty", block: false)#text(".")]
)

#text("Also, show that if ")#mi("T, S: H \\to H^{\\prime}")#text(" are Hilbert-Schmidt operators, then")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\langle T, S \\rangle_{HS} = \\sum_{n \\in A} \\langle T e_n, S e_n \\rangle_{H^{\\prime}}")]]

#text("and")

#align(center)[#tao-math("\\left\\|T\\right\\|_{HS}^2 = \\sum_{n \\in A} \\left\\|T e_n\\right\\|_{H^{\\prime}}^2 = \\sum_{n \\in A} \\sum_{n^{\\prime} \\in A^{\\prime}} \\left|\\langle T e_n, e^{\\prime}_{n^{\\prime}} \\rangle_{H^{\\prime}}\\right|^2", block: false)#text(". (26) ")#mi("\\diamond")]

#text("As one consequence of the above exercise, we see that the Hilbert-Schmidt norm controls the operator norm, thus ")#tao-math("\\left\\|Tv\\right\\| \\leq \\left\\| T\\right\\|_{HS} \\left\\|v\\right\\|", block: false)#text(" for all vectors v.")

#strong[#text("Remark 5. ")]#text("From this exercise and ")#link("http://en.wikipedia.org/wiki/Fatou%27s_lemma")[#text("Fatou’s lemma")]#text(", we see in particular that the limit (in either the ")#link("http://en.wikipedia.org/wiki/Operator_norm")[#text("norm")]#text(", ")#link("http://en.wikipedia.org/wiki/Strong_operator_topology")[#text("strong")]#text(" or ")#link("http://en.wikipedia.org/wiki/Weak_operator_topology")[#text("weak operator topologies")]#text(") of a sequence of Hilbert-Schmidt operators with uniformly bounded Hilbert-Schmidt norm, is still Hilbert-Schmidt. We also see that the composition of a Hilbert-Schmidt operator with a bounded operator is still Hilbert-Schmidt (thus the Hilbert-Schmidt operators can be viewed as a closed two-sided ideal in the space of bounded operators). ")#mi("\\diamond")

#strong[#text("Example 5. ")]#text("An operator ")#mi("T: L^2(X, {\\mathcal X}, \\mu) \\to L^2(Y, {\\mathcal Y},\\nu)")#text(" is Hilbert-Schmidt if and only if it takes the form ")#mi("Tf(y) := \\int_X K(x,y) f(x)\\ d\\mu(x)")#text(" for some kernel ")#mi("K \\in L^2(X \\times Y, {\\mathcal X} \\times {\\mathcal Y}, \\mu \\times \\nu)")#text(", in which case the Hilbert-Schmidt norm is ")#tao-math("\\left\\| K \\right\\|_{L^2(X \\times Y, {\\mathcal X} \\times {\\mathcal Y}, \\mu \\times \\nu)}", block: false)#text(". The Hilbert-Schmidt inner product is defined similarly. ")#mi("\\diamond")

#strong[#text("Example 6. ")]#text("The identity operator on an infinite-dimensional Hilbert space is never Hilbert-Schmidt, despite being bounded. On the other hand, every ")#link("http://en.wikipedia.org/wiki/Finite_rank_operator")[#text("finite rank operator")]#text(" is Hilbert-Schmidt. ")#mi("\\diamond")

#text("One of the key properties of Hilbert-Schmidt operators which will be relevant to us is the following.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2.")]#text(" If ")#mi("T: H \\to H^{\\prime}")#text(" is Hilbert-Schmidt, then it is ")#link("http://en.wikipedia.org/wiki/Compact_operator")[#text("compact")]#text(" (i.e. the image of any bounded set is ")#link("http://en.wikipedia.org/wiki/Relatively_compact")[#text("precompact")]#text(").")
]

#strong[#text("Proof.")]#text(" Let ")#mi("\\varepsilon > 0")#text(" be arbitrary. By Exercise 19 and monotone convergence, we can find a finite orthonormal set ")#mi("e_1,\\ldots,e_N")#text(" such that ")#tao-math("\\sum_{n=1}^N \\left\\| Te_n\\right\\|_{H^{\\prime}}^2 \\geq \\left\\|T\\right\\|_{HS}^2 - \\varepsilon^2", block: false)#text(", and in particular that ")#tao-math("\\left\\|Te_{n+1}\\right\\|_{H^{\\prime}} \\leq \\varepsilon", block: false)#text(" for any ")#mi("e_{n+1}")#text(" orthogonal to ")#mi("e_1,\\ldots,e_n")#text(". As a consequence, the image of the unit ball of H under T lies within ")#mi("\\varepsilon")#text(" of the image of the unit ball of the finite-dimensional space ")#mi("\\text{span}(e_1,\\ldots,e_N)")#text(". This image is therefore ")#link("http://en.wikipedia.org/wiki/Totally_bounded")[#text("totally bounded")]#text(" and thus precompact. ")#mi("\\Box")

#text("The following exercise may help illuminate the distinction between bounded operators, Hilbert-Schmidt operators, and compact operators:")

#strong[#text("Exercise 20. ")]#text("Let ")#mi("\\lambda_n")#text(" be a sequence of complex numbers, and consider the diagonal operator ")#mi("T: (z_n)_{n \\in {\\Bbb N}} \\mapsto (\\lambda_n z_n)_{n \\in {\\Bbb N}}")#text(" on ")#mi("l^2({\\Bbb N})")#text(".")

#enum(start: 1, 
[#text("Show that T is a well-defined bounded linear operator on ")#mi("l^2({\\Bbb N})")#text(" if and only if the sequence ")#mi("(\\lambda_n)")#text(" is bounded.")],
[#text("Show that T is Hilbert-Schmidt if and only if the sequence ")#mi("(\\lambda_n)")#text(" is square-summable.")],
[#text("Show that T is compact if and only if the sequence ")#mi("(\\lambda_n)")#text(" goes to zero as ")#mi("n \\to \\infty")#text(". ")#mi("\\diamond")]
)

#text("Now we apply the above theory to establish Theorem 1. Let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be a measure-preserving system, and let ")#mi("f \\in L^2(X, {\\mathcal X}, \\mu)")#text(". The rank one operators ")#mi("g \\mapsto \\langle g, T^n f \\rangle T^n f")#text(" can easily be verified to have a Hilbert-Schmidt norm of ")#tao-math("\\left\\|f\\right\\|_{L^2}^2", block: false)#text(", and so by the triangle inequality, their averages ")#mi("S_{f,N}: g \\mapsto \\frac{1}{N} \\sum_{n=0}^{N-1} \\langle g, T^n f \\rangle T^n f")#text(" have a Hilbert-Schmidt norm of at most ")#tao-math("\\left\\|f\\right\\|_{L^2}^2", block: false)#text(". On the other hand, from the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\langle S_{f,N} g, h \\rangle = \\frac{1}{N} \\sum_{n=0}^{N-1} \\langle g \\otimes \\overline{h}, (T \\otimes T)^n (f \\otimes \\overline{f}) \\rangle")]]

#text("and the mean ergodic theorem (applied to the product space) we see that ")#mi("S_{f,N}")#text(" converges in the weak operator norm to some limit ")#mi("S_f")#text(", which is then also Hilbert-Schmidt by Remark 5, and thus compact by Lemma 2. (Actually, ")#mi("S_{f,N}")#text(" converges to ")#mi("S_f")#text(" in the Hilbert-Schmidt norm, and thus also in the operator norm and in the strong topology: this is another application of the mean ergodic theorem, which we leave as an exercise. Since each of the ")#mi("S_{f,N}")#text(" is clearly finite rank, this gives a direct proof of the compactness of ")#mi("S_f")#text(".) Also, it is easy to see that ")#mi("S_f")#text(" is self-adjoint and commutes with T. As a consequence, we conclude that for any ")#mi("g \\in L^2(X, {\\mathcal X}, \\mu)")#text(", the image ")#mi("S_f g")#text(" is almost periodic (since ")#mi("\\{ T^n S_f g: n \\in {\\Bbb Z} \\} = S_f \\{ T^n g: n \\in {\\Bbb Z} \\}")#text(" is the image of a bounded set by the compact operator ")#mi("S_f")#text(" and therefore precompact).")

#text("On the other hand, observe that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#tao-math("\\langle S_f f, f \\rangle = C\\!-\\!\\lim_{n \\to \\infty} \\left|\\langle T^n f, f \\rangle\\right|^2.", block: true)]]

#text("Thus by Definition 2 (and Exercise 1), we see that ")#mi("\\langle S_f f, f \\rangle \\neq 0")#text(" whenever f is not weakly mixing. In particular, f is not orthogonal to the almost periodic function ")#mi("S_f f")#text(". From this and Exercise 18, we have thus shown")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3. ")]#text("(Dichotomy between structure and randomness) Let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be a measure-preserving system. A function ")#mi("f \\in L^2(X, {\\mathcal X}, \\mu)")#text(" is weakly mixing if and only if it is orthogonal to all almost periodic functions (or equivalently, orthogonal to all eigenfunctions).")
]

#strong[#text("Remark 6.")]#text(" Interestingly, essentially the same result appears in the spectral and scattering theory of linear Schrödinger equations, which in that context is known as the “RAGE theorem” (after ")#link("http://www.ams.org/mathscinet-getitem?mr=246603")[#text("Ruelle")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=363267")[#text("Amrein-Georgescu")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=523013")[#text("Enss")]#text("). ")#mi("\\diamond")

#strong[#text("Remark 7")]#text(". The finitary analogue of the expression ")#mi("S_f f")#text(" is the ")#emph[#text("dual function")]#text(" (of order 2) of f (the dual function of order 1 was briefly discussed in ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("Lecture 8")]#text("). If we are working on ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(" with the usual shift, then ")#mi("S_f")#text(" can be viewed as a ")#link("http://en.wikipedia.org/wiki/Multiplier_%28Fourier_analysis%29")[#text("Fourier multiplier")]#text(" which multiplies the Fourier coefficient at ")#mi("\\xi")#text(" by ")#tao-math("\\left|\\hat f(\\xi)\\right|^2", block: false)#text("; informally, ")#mi("S_f")#text(" filters out all the low amplitude frequencies of f, leaving only a handful of high-amplitude frequencies. ")#mi("\\diamond")

#text("Recall from Proposition 2 and Exercise 5 of Lecture 11 that a function ")#mi("f \\in L^2(X, {\\mathcal X}, \\mu)")#text(" is almost periodic if and only if it is ")#mi("{\\mathcal Z}_1")#text("-measurable, or if it lies in the pure point component ")#mi("{\\Bbb H}_{pp}")#text(" of the shift operator T. We thus have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3.")]#text(" (Koopman-von Neumann theorem) Let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be a measure-preserving system, and let ")#mi("f \\in L^2(X, {\\mathcal X}, \\mu)")#text(". Let ")#mi("{\\mathcal Z}_1")#text(" be the ")#mi("\\sigma")#text("-algebra generated by the eigenfunctions of T.")

#enum(start: 1, 
[#text("f is almost periodic if and only if ")#mi("f \\in L^2(X, {\\mathcal Z}_1, \\mu)")#text(" if and only if ")#mi("f \\in {\\Bbb H}_{pp}")#text(".")],
[#text("f is weakly mixing if and only if ")#mi("{\\Bbb E}(f|{\\mathcal Z}_1) = 0")#text(" a.e. if and only if ")#mi("f \\in {\\Bbb H}_c = {\\Bbb H}_{sc} + {\\Bbb H}_{ac}")#text(" (corresponding to the continuous spectrum of T).")],
[#text("In general, f has a unique decomposition ")#mi("f = f_{U^\\perp} + f_U")#text(" into an almost periodic function ")#mi("f_{U^\\perp}")#text(" and a weakly mixing function ")#mi("f_U")#text(". Indeed, ")#mi("f_{U^\\perp} = {\\Bbb E}(f|{\\mathcal Z}_1)")#text(" and ")#mi("f_U = f - {\\Bbb E}(f|{\\mathcal Z}_1)")#text(".")]
)
]

#text("Theorem 1 follows immediately from this Corollary. Indeed, if a system is not weakly mixing, then by the above Corollary we see that ")#mi("{\\mathcal Z}_1")#text(" is non-trivial, and the identity map from ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" to ")#mi("(X, {\\mathcal Z}_1, \\mu, T)")#text(" yields a non-trivial compact factor.")

#heading(level: 1)[#text("— Roth’s theorem —")]

#text("As a quick application of the above machinery we give a proof of Roth’s theorem. We first need a variant of Corollary 2, which is proven by much the same means:")

#strong[#text("Exercise 21. ")]#text(" Let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be an ergodic measure-preserving system, let ")#mi("a_1, a_2, a_3")#text(" be distinct integers, and let ")#mi("f_1, f_2, f_3 \\in L^\\infty(X, {\\mathcal X}, \\mu)")#text(" with at least one of ")#mi("f_1, f_2, f_3")#text(" weakly mixing. Show that ")#mi("C\\!-\\!\\lim_{n \\to \\infty} \\int_X T^{a_1 n} f_1 T^{a_2 n} f_2 T^{a_3 n} f_3\\ d\\mu = 0")#text(". ")#mi("\\diamond")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" (Roth’s theorem). Let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be an ergodic measure-preserving system, and let ")#mi("f \\in L^\\infty(X, {\\mathcal X}, \\mu)")#text(" be non-negative with ")#mi("\\int_X f\\ d\\mu > 0")#text(". Then")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("\\liminf_{N \\to \\infty} \\frac{1}{N} \\sum_{n=0}^{N-1} \\int_X f T^n f T^{2n} f\\ d\\mu > 0.")]]
]

#strong[#text("Proof.")]#text(" We decompose ")#mi("f = f_{U^\\perp} + f_U")#text(" as in Corollary 3. The contribution of ")#mi("f_U")#text(" is negligible by Exercise 21, so it suffices to show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\liminf_{N \\to \\infty} \\frac{1}{N} \\sum_{n=0}^{N-1} \\int_X f_{U^\\perp} T^n f_{U^\\perp} T^{2n} f_{U^\\perp}\\ d\\mu > 0.")]]

#text("But as ")#mi("f_{U^\\perp}")#text(" is almost periodic, the claim follows from Proposition 1 of ")#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/")[#text("Lecture 11.")]#text(" ")#mi("\\Box")

#text("One can then immediately establish the k=3 case of Furstenberg’s theorem (Theorem 2 from ")#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/")[#text("Lecture 10")]#text(") by combining the above result with the ergodic decomposition (Proposition 4 from ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("Lecture 9")]#text("). The k=3 case of Szemerèdi’s theorem (i.e. Roth’s theorem) then follows from the Furstenberg correspondence principle (see ")#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/")[#text("Lecture 10")]#text(").")

#strong[#text("Exercise 22. ")]#text("Let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be a measure-preserving system, and let ")#mi("f \\in L^2(X, {\\mathcal X}, \\mu)")#text(" be non-negative. Show that for every ")#mi("\\varepsilon > 0")#text(", one has ")#mi("\\langle T^n f, f \\rangle \\geq \\int_X (f\\ d\\mu)^2 - \\varepsilon")#text(" for infinitely many n. (Hint: first show this when f is almost periodic, and then use Corollary 1 and Corollary 3 to prove the general case.) This is a simplified version of the ")#emph[#text("Khintchine recurrence theorem")]#text(", which asserts that the set of such n is not only infinite, but is also syndetic. Analogues of the Khintchine recurrence theorem hold for double recurrence but not for triple recurrence; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2138068")[#text("this paper of Bergelson, Host, and Kra")]#text(" for details. ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Mar 3: Added the observation that as ")#mi("S_{f,N}")#text(" converges to ")#mi("S_f")#text(" in the operator norm, ")#mi("S_f")#text(" is the limit of finite rank operators and thus clearly compact. Thanks to Guatam Zubin for this remark.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (32)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-26555")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("I am not sure I see how Theorem 1 follows from corollary 3. The obvious conclusion from cor. 3 is that, if your dynamical system is not weakly mixing, then there is a nonconstant almost periodic function. We have to use this to build a compact factor. Looking at Theorem 3 in Lecture 7, I think the chain of reasoning is the following:")

#text("Since X is not weakly mixing, X \\times X is also not weakly mixing so")#linebreak()#text(" there is a nonconstant almost periodic function f on X \\times X. View f as a function g:X –> L^2(X), then g commutes with the translation T. Moreover, f is continuous (why?) and g(X) is compact (why?). It’s not even clear to me which of these two points uses the fact that f is almost periodic (although I am betting on the second.)")

#text("Any hints are appreciated!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-26556")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("Dear David,")

#text("In this setting, factor refers to the measure-theoretic notion of a factor rather than the topological one (despite the adjective “compact” – sorry for the confusion!). In this case, the non-trivial factor of ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" can be taken to be simply ")#mi("(X, {\\mathcal Z}_1, \\mu, T)")#text(", with the factor map being the identity. I’ll write a little bit more in the notes to clarify this.")

#emph[#text("A posteriori")]#text(", one can identify the compact factor with a topological dynamical system (and in fact, with a Kronecker system), in the ergodic case at least, using Theorem 2 from Lecture 11, but it is not necessary to do so here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-26584")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2008")])]

#text("Thanks, I get it now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 14: Weakly mixing extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-26835")[#strong[#text("254A, Lecture 14: Weakly mixing extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2008")])]

#text("[…] versions of compact systems, weakly mixing extensions are “relative” versions of weakly mixing systems, in which the underlying algebra of scalars is replaced by . As in the case of unconditionally […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-34260")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2008")])]

#text("Dear Professor Tao:")

#text("About Remark 3, I computed (4) and got that the right-hand side (if I am right) is")

#tao-math("\\frac{1}{N}\\sum_{\\xi \\in {\\Bbb Z}/N{\\Bbb Z}} \\left|\\hat f(\\xi)\\right|^4", block: false)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-34272")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2008")])]

#text("Dear Liuxiaochuan,")

#text("I think the formula is correct as it stands (note that the inner product ")#mi("\\langle, \\rangle")#text(" is with respect to normalised counting measure on ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(" rather than counting measure, thus ")#mi("\\langle f, g \\rangle = \\frac{1}{N} \\sum_{n=1}^N f(n) \\overline{g(n)}")#text(").")

#text("A simple way to double-check things like powers of N is to plug in a simple example, e.g. ")#mi("f \\equiv 1")#text(" (in which case ")#mi("\\hat f(0)=1")#text(" and all other Fourier coefficients vanish).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-34314")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2008")])]

#text("Dear Professor Tao:")

#text("Merry Christmas! Thanks for the method!")

#text("After (20), I think ( and hope I am not wrong this time) it should be ")#mi("f_{j,h}=T^{(a_j-a_k)h}f_j T^{-a_kn}\\overline{f_j}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-34321")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2008")])]

#text("Actually, I think the formula is again correct as stated; here we are using the unitarity ")#mi("\\langle T^n f, T^n g \\rangle = \\langle f, g\\rangle")#text(" of the shift map to cancel the dependence on n. (Again, one can work with a simple example, such as ")#mi("k=1")#text(" or ")#mi("h=0")#text(", first.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-34350")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2008")])]

#text("Dear Professor Tao:")

#text("I still have doubts about (20), I think your example is too simple. What if ")#mi("k=1")#text(" and ")#mi("h=1")#text(", then the integrand would be ")#mi("f_1T^{-a_1h} \\overline{f_1}")#text(".")

#text("My previous correction is also not thre. I think it should be ")#mi("f_{j,h}=T^{(a_j-a_k)h}f_j T^{-a_kh}\\overline{f_j}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-34356")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2008")])]

#text("Ah, I see the issue now. Thanks for the correction! (Actually, it is slightly more convenient to take ")#mi("f_{j,h} = T^{a_j h} f_j \\overline{f_j}")#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-34391")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2008")])]

#text("Dear Professor Tao:")

#text("Another small correction: after (27), “then also Hilbert-Schmidt by Remark 4”, where I think should be “Example 4”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-34394")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2008")])]

#text("Thanks! (Actually, it should be Remark 5.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-34663")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2009")])]

#text("Dear Pressor Tao:")

#text("About the proof of Proposition 1, in the case ")#mi("k=1")#text(", I didn’t see a direct way to get it just from the mean ergodic theorem. I am tying to prove it using the exercises.")

#text("In 2 of exercise 9, is the inner product ")#mi("\\langle f,g\\rangle")#text(" be ")#mi("\\int_Xf\\overline{g}d\\mu")#text(" or just ")#mi("\\int_Xf gd\\mu")#text("? If it is the former, I think the conclusion should become ")#mi("\\int_Xfd\\mu\\int_X\\overline{g} d\\mu")#text(". I got confused a little.")

#text("About exercise 12, I didn’t find a direct way to prove it, except using both exercise 9 and exercise 13, chould you give me a hint?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-34666")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2009")])]

#text("The k=1 case of Proposition 1 follows from the mean ergodic theorem combined with Exercise 12 (to ensure that ")#mi("T^{a_1}")#text(" is ergodic).")

#text("Yes, there should be a conjugate for the g’s in the inner product and in Exercise 9.")

#text("Exercise 12 can be proven using Exercise 9.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf5b8cd57695d2b4409af2bef2d49e0791083d7389200cac76586525a8f321f9-360a7b2d3c734e82d208e935e21e77ba1b8ff8fbbb610a1519203676cb3288d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martino")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-43683")[#strong[#text("Martino")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2010")])]

#text("Dear Professor Tao:")

#text("I cannot see how to solve exercise 21. Could you give me a hint?")

#text("Also, do you know if a proof of Roth’s theorem, similar to the one given here, can be given using the characterization of weakly mixing and almost periodic functions in terms of essential idempotent ultrafilters? (a function f is almost periodic iff p-lim T^n f = f for some, or equivalently every, idempotent ultrafilter p every whose element has positive Banach density, and is weakly mixing iff for some, or equivalently every, idempotent ultrafilter p as above, p-lim T^n f = 0 weakly)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-43685")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2010")])]

#text("Try the model case when a_1=0, a_2=1, a_3=2, and f_3 is weakly mixing. In this case one can pull f_1 out of the average, and it would suffice to show that the Cesaro averages of ")#mi("T^n f_2 T^{2n} f_3")#text(" go to zero in ")#mi("L^2")#text(" norm. To establish this, apply the van der Corput lemma.")

#text("As for your second question, there is a paper of Bergelson and McCutcheon which follows this approach, see")

#link("http://muse.jhu.edu/journals/american_journal_of_mathematics/v129/129.5bergelson.pdf")[#text("Click to access 129.5bergelson.pdf")]

#text("although the Roth-type theorem they obtain is slightly different from the formulation given here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c620300871938edc7f2479f0b0ba17f6903f20059bdfee397e078d5f2e3fd338-45a5bbb177a9bc377bcb72337273c93904f6fd03f53e7444ff36d00194d60ff8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek Khetan")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-511930")[#strong[#text("Abhishek Khetan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2019")])]

#text("Dear Professor Tao,")

#text("I tried your hint for Exercise 21 but I am still stuck. With ")#mi("a_1=0, a_2=1, a_3=2")#text(", and ")#mi("f_3")#text(" weakly-mixing, we have the average")#linebreak()#text(" ")#mi("\\lim_{N\\to \\infty} \\frac{1}{N}\\int_{X} f_1 (T^nf_2) (T^{2n}f_3)\\ d\\mu")#text(".")

#text("I am unable to see how ")#mi("f_1")#text(" can be pulled out of the average.")

#text("(I thought of using the ergodicity of ")#mi("T")#text(" but even with that the Birkhoff ergodic theorem does not give the desired. Or may be I am missing something.)")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-511934")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2019")])]

#text("The average is actually ")#mi("\\lim_{N \\to \\infty} \\int_X f_1 \\frac{1}{N} \\sum_{n=1}^N (T^n f_2) (T^{2n} f_3)\\ d\\mu")#text(" (one can pull the ")#mi("f_1")#text(" out of the averaging in ")#mi("n")#text("). So it’s enugh to have ")#mi("\\frac{1}{N} \\sum_{n=1}^N (T^n f_2) (T^{2n} f_3)")#text(" converge strongly in ")#mi("L^2(X)")#text(" to zero, and this can be established using the van der Corput lemma (Lemma 1).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c620300871938edc7f2479f0b0ba17f6903f20059bdfee397e078d5f2e3fd338-45a5bbb177a9bc377bcb72337273c93904f6fd03f53e7444ff36d00194d60ff8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek Khetan")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-511981")[#strong[#text("Abhishek Khetan")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2019")])]

#text("(Sorry for missing the summation in my previous comment, and thank you for elaborating on the hint, which really helps).")

#text("To apply the van der Corput lemma, we set ")#mi("c_n= (T^nf_2)(T^{2n}f_3)")#text(". Then using the fact that $T$ is measure preserving we have that ")#mi("\\langle c_n, c_{n+h}\\rangle")#text(" is equal to ")#mi("\\int_X (f_2T^h f_2) T^n(f_3T^{2h}f_3)\\ d\\mu")#text(". Therefore, by the Birkhoff ergodic theorem we have ")#mi("\\frac{1}{N}\\sum_{n=0}^{N-1}\\langle c_n, c_{n+h}\\rangle")#text(" converges in ")#mi("L^2")#text(" to ")#mi("\\int_X (f_2T^{h}f_2)(f_3T^{2h}f_3)\\ d\\mu")#text(". Therefore ")#mi("\\text{Csup}_{n\\to \\infty}\\langle c_n, c_{n+h}\\rangle")#text(" is equal to ")#tao-math("\\left|\\int_X (f_2T^{h}f_2)(f_3T^{2h}f_3)\\ d\\mu\\right|", block: false)#text(". From here I am able to finish the proof by noting that ")#mi("f_3")#text(" is weakly-mixing with respect to ")#mi("T^2")#text(", since it is weakly-mixing with respect to ")#mi("T")#text(".")

#text("I am still stuck because of this: Suppose we take ")#mi("a=0, b=1, c=3")#text(". Then for the van der Corput step we set ")#mi("c_n=(T^nf_2)(T^{3n}f_3)")#text(" and we get ")#mi("\\langle c_n, c_{n+h}\\rangle")#text(" is ")#mi("\\int_X (f_2T^h f_2) T^{2n}(f_3T^{3h}f_3)\\ d\\mu")#text(". And from here I am not able to invoke the Birkhoff ergodic theorem as I was able to previously. Can you please help.")

#text("Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-511994")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2019")])]

#text("Apply the Birkhoff ergodic theorem (or a suitable induction hypothesis) to the shift ")#mi("T^2")#text(" (which is weakly mixing and hence ergodic).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-45284")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2010")])]

#text("Dear Martino:")#linebreak()#text(" I got stuck at exercise 21 at first, too. I overlooked the condition that the system is ergodic.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-45286")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2010")])]

#text("Dear Professor Tao:")#linebreak()#text(" There is a small typo, in exercise 15 and before exercise 21, you actually mean Corollary 2, right?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-45433")[#strong[#text("ERT12: Kronecker factor – coexistence of compact and weak mixing behaviour « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2010")]

#text("[…] interested reader is invited to read this post of Terence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Solutions to Ergodic Theory：Lecture twelve « Xiaochuan Liu's Weblog")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-45561")[#strong[#text("Solutions to Ergodic Theory：Lecture twelve « Xiaochuan Liu's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2010")])]

#text("[…] note:：Professor Terence Tao Began posting his lecture notes about the course “ergodic theory” early in 2008. I try doing all the exercises. This is the Twenty-two exercises in lecture twelve. Here is the the page of this course，and here is the page of this lecture. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-55450")[#strong[#text("Lyapunov spectrum of the Kontsevich-Zorich cocycle on the Hodge bundle over square-tiled cyclic covers IV « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2011")]

#text("[…] and almost every vertical translation flow (on genus translation surfaces) are weakly mixing. Here, we say that an i.e.t. corresponds to a rotation if its combinatorial data has the form […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-184256")[#strong[#text("Lyapunov spectrum of the Kontsevich-Zorich cocycle on the Hodge bundle over square-tiled cyclic covers V « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2012")]

#text("[…] that a dynamical system preserving a probability is weak mixing […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/724a5f80344d8c833d5f96098156b6474d7241d0645221f832a2cf430c495e55-d0c51b33bad4c6bd68b860e2c692845dc25308fcf7971962b7e0162cc488bbfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hc")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-486411")[#strong[#text("hc")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2017")])]

#text("Is there any reason that Cesaro mean plays a special role here? I can see this arise historically (e.g. in von Neumann’s ergodic theorem), but does other kind of summability (such as Abel summation, or Riesz mean) play a role in ergodic theory as well? Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-486414")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2017")])]

#text("Many other ergodic theorems rely in one form or another on the classic ergodic theorems (mean, pointwise, or maximal), which all use Cesaro type averaging. Once one can control Cesaro means one can also control many other averages (such as Abel or Riesz) by summation by parts, so there is not much benefit in moving to these smoothing means. But there is certainly a lot of literature on working with ergodic theorems involving more exotic and difficult notions of averaging (e.g. averaging over primes, values of a polynomial, etc.).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c620300871938edc7f2479f0b0ba17f6903f20059bdfee397e078d5f2e3fd338-45a5bbb177a9bc377bcb72337273c93904f6fd03f53e7444ff36d00194d60ff8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek Khetan")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-509207")[#strong[#text("Abhishek Khetan")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2018")])]

#text("Dear Professor Tao,")

#text("The note just after Theorem 1 mentions that “in ergodic theory, a factor of a measure-preserving system is simply a morphism from that system to some other measure-preserving system. … we do not need to assume surjectivity of the morphism, since in the measure-theoretic setting, the image of a morphism always has full measure.”")

#text("I do not fully follow the last line since it is not clear why should the image of a factor map be a measurable set.")

#text("Can you please address this.")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-509224")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2018")])]

#text("Hmm, I guess you are right (though in practice the factors one works with will have measurable image, as it takes a fair amount of deliberate effort to create non-measurable sets). A more accurate statement would be that the image of the factor map always has full outer measure (the measurable sets that enclose it must have full measure).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-514168")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2019")])]

#text("There must be a bar in eqn. 24, because we are taking the scalar product of ")#mi("\\overline H \\otimes H^{\\prime}")#text(" instead of the one of ")#mi("H \\otimes H^{\\prime}")#text(". Indeed, ")#mi("K")#text(" is an element of the former space.")

#emph[#text("[Corrected thanks. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/#comment-572837")[#strong[#text("Math Genius: Is there a von Neumann type theorem for the $sigma$-algebra generated by the set of all the eigenfunctions? - TECHPRPR")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2020")]

#text("[…] Lecture 12 of 254A, after Exercise 20, Tao defines a map as […]")
]
