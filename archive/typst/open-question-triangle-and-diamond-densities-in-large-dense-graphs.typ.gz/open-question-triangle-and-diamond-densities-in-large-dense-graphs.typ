// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/
// Converted to Typst by tao2typ: "2026-10-14T15:16:19.884601+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Open question: triangle and diamond densities in large dense graphs", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Open question: triangle and diamond densities in large dense graphs")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 April 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/")[#text("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The question in extremal graph theory I wish to discuss here originates from ")#link("http://www.cs.berkeley.edu/~luca/")[#text("Luca Trevisan")]#text("; it shows that we still don’t know everything that we should about the “local” properties of large dense graphs.")

#text("Let ")#mi("G = (V,E)")#text(" be a large (undirected) graph, thus V is the vertex set with some large number n of vertices, and E is the collection of edges {x,y} connecting two vertices in the graph. We can allow the graph to have loops {x,x} if one wishes; it’s not terribly important for this question (since the number of loops is so small compared to the total number of edges), so let’s say there are no loops. We define three quantities of the graph G:")

#list(
[#text("The ")#emph[#text("edge density")]#text(" ")#mi("0 \\leq \\alpha \\leq 1")#text(", defined as the number of edges in G, divided by the total number of possible edges, i.e. ")#mi("n(n-1)/2")#text(";")],
[#text("The ")#emph[#text("triangle density")]#text(" ")#mi("0 \\leq \\beta \\leq 1")#text(", defined as the number of triangles in G (i.e. unordered triplets {x,y,z} such that {x,y},{y,z}, {z,x} all lie in G), divided by the total number of possible triangles, namely ")#mi("n(n-1)(n-2)/6")#text(";")],
[#text("The ")#emph[#text("diamond density")]#text(" ")#mi("0 \\leq \\gamma \\leq 1")#text(", defined as the number of diamonds in G (i.e. unordered pairs { {x,y,z}, {x,y,w} } of triangles in G which share a common edge), divided by the total number of possible diamonds, namely ")#mi("n(n-1)(n-2)(n-3)/4")#text(".")]
)

#metadata(none) <tao-6c4cf982357495b129c1>#text("Up to insignificant errors of o(1) (i.e. anything which goes to zero as the number of vertices goes to infinity), these densities can also be interpreted probabilistically as follows: if x,y,z,w are randomly selected vertices in V, then")

#list(
[#mi("{\\Bbb P}( \\{x, y\\} \\in E ) = \\alpha + o(1)")#text(";")],
[#mi("{\\Bbb P}( \\{x, y\\},\\{y,z\\}, \\{z,x\\} \\in E ) = \\beta + o(1)")#text(";")],
[#mi("{\\Bbb P}( \\{x, y\\}, \\{y,z\\}, \\{z,x\\}, \\{y,w\\}, \\{w,x\\} \\in E ) = \\gamma + o(1)")#text(".")]
)

#text("(The errors of o(1) arise because the vertices x,y,z,w may occasionally collide with each other, though this probability becomes very small when n is large.) Thus we see that these densities are “local” qualities of the graph, as we only need to statistically sample the graph at a small number of randomly chosen vertices in order to estimate them.")

#text("A general question is to determine all the constraints relating ")#mi("\\alpha, \\beta, \\gamma")#text(" in the limit ")#mi("n \\to \\infty")#text(". (It is known from the work of ")#link("http://www.ams.org/mathscinet-getitem?mr=2274085")[#text("Lovász and Szegedy")]#text(" that the relationships between local graph densities such as these stabilise in this limit; indeed, given any error tolerance ")#mi("\\epsilon > 0")#text(" and any large graph G with densities ")#mi("\\alpha,\\beta,\\gamma")#text(", there exists a graph with “only” ")#mi("O_\\epsilon(1)")#text(" vertices whose densities ")#mi("\\alpha^{\\prime}, \\beta^{\\prime}, \\gamma^{\\prime}")#text(" differ from those of G by at most ")#mi("\\epsilon")#text(", although the best known bounds for ")#mi("O_\\epsilon(1)")#text(" are far too poor at present to be able to get any useful information on the asymptotic constraint set by direct exhaustion by computer of small graphs.)")

#text("Let us forget about diamonds for now and only look at the edge and triangle densities ")#mi("\\alpha, \\beta")#text(". Then the story is already rather non-trivial. The main concern is to figure out, for each fixed ")#mi("\\alpha")#text(", what the best possible upper and lower bounds on ")#mi("\\beta")#text(" are (up to o(1) errors); since the collection of graphs with a given edge density is “path-connected” in some sense, it is not hard to see that every value of ")#mi("\\beta")#text(" between the upper and lower bounds is feasible modulo o(1) errors.")

#text("The best possible upper bound is easy: ")#mi("\\beta \\leq \\alpha^{3/2} + o(1)")#text(". This can be established by either the ")#link("http://en.wikipedia.org/wiki/Kruskal%E2%80%93Katona_theorem")[#text("Kruskal-Katona theorem")]#text(", the ")#link("http://www.ams.org/mathscinet-getitem?mr=31538")[#text("Loomis-Whitney inequality")]#text(" (or the closely related ")#link("http://www.ams.org/mathscinet-getitem?mr=1338683")[#text("box theorem")]#text("), or just two applications of ")#link("http://en.wikipedia.org/wiki/Holder%27s_inequality")[#text("Hölder’s inequality")]#text("; we leave this as an exercise. The bound is sharp, as can be seen by looking at a complete subgraph on ")#mi("(\\alpha^{1/2}+o(1))n")#text(" vertices. (We thank ")#link("http://www.math.ucla.edu/~timaustin/")[#text("Tim Austin")]#text(" and ")#link("http://en.wikipedia.org/wiki/Imre_Leader")[#text("Imre Leader")]#text(" for these observations and references, as well as those in the paragraph below.) [")#emph[#text("Update")]#text(", Apr 21: There is some literature on refining the o(1) factor; see ")#link("http://arxiv.org/abs/math/0608199")[#text("this paper")]#text(" for a survey.]")

#text("The lower bound is trickier. The complete bipartite graph example shows that the trivial lower bound ")#mi("\\beta \\geq 0")#text(" is attainable when ")#mi("\\alpha \\leq 1/2 - o(1)")#text(", and ")#link("http://en.wikipedia.org/wiki/Tur%C3%A1n%27s_theorem")[#text("Turán’s theorem")]#text(" shows that this is sharp. For ")#mi("\\alpha \\geq 1/2")#text(", a classical ")#link("http://www.ams.org/mathscinet-getitem?mr=107610")[#text("theorem of Goodman")]#text(" (see also ")#link("http://www.ams.org/mathscinet-getitem?mr=151957")[#text("Nordhaus and Stewart")]#text(") shows that ")#mi("\\beta \\geq \\alpha(2\\alpha-1)-o(1)")#text(". When ")#mi("\\alpha = 1 - 1/k")#text(" for some integer k, this inequality is sharp, as can be seen by looking at the complete k-partite graph.")

#text("Goodman’s result is thus sharp at infinitely many values of ")#mi("\\alpha")#text(", but it turns out that it is not quite the best bound. After several partial results, the optimal bound was obtained recently ")#link("http://www.mi.ras.ru/~razborov/triangles.pdf")[#text("by Razborov")]#text(", who established for ")#mi("1-1/k < \\alpha < 1-1/(k+1)")#text(" that")

#align(center)[#tao-fit-display[#mitex("\\beta \\geq \\frac{(k-1) \\left(k-2\\sqrt{k(k-\\alpha(k+1))}\\right) \\left(k + \\sqrt{k(k-\\alpha(k+1))} \\right)}{k^2 (k+1)^2}- o(1)")]]

#text("and that this is sharp (!) except for the o(1) error. [Update, Apr 21: For some work on understanding the o(1) error, see ")#link("http://www.ams.org/mathscinet-getitem?mr=1010583")[#text("this paper of Fisher")]#text(".]")

#text("Now we consider the full problem of relating edge densities, triangle densities, and diamond densities. Given that the relationships between ")#mi("\\alpha, \\beta")#text(" were already so complex, a full characterisation of the constraints connecting ")#mi("\\alpha, \\beta, \\gamma")#text(" is probably impossible at this time (though it might be possible to prove that they can be decidable via some (impractical) computer algorithm, and it also looks feasible to determine the exact constraints between just ")#mi("\\alpha")#text(" and ")#mi("\\gamma")#text("). The question of Luca however focuses on a specific regime in the configuration space, in which ")#mi("\\beta")#text(" is exceptionally small.")

#text("From the Cauchy-Schwarz inequality and the observation that a diamond is nothing more than a pair of triangles with a common edge, we obtain the inequality")

#align(center)[#mi("\\gamma \\geq \\frac{\\beta^2}{\\alpha} - o(1).")#text(" (*)")]

#text("Because we understand very well when equality holds in the Cauchy-Schwarz inequality, we know that (*) would only be sharp when the triangles are distributed “evenly” among the edges, so that almost every edge is incident to the roughly expected number of triangles (which is roughly ")#mi("\\beta n / \\alpha")#text(").")

#text("However, it is a remarkable fact that this type of equidistribution is known to be impossible when ")#mi("\\beta")#text(" is very small. Indeed, the ")#link("http://www.ams.org/mathscinet-getitem?mr=519318")[#text("triangle removal lemma of Ruzsa and Szemerédi")]#text(" asserts that if ")#mi("\\beta")#text(" is small, then one can in fact make ")#mi("\\beta")#text(" vanish (i.e. delete all triangles) by removing at most ")#mi("c(\\beta) n^2")#text(" edges, where ")#mi("c(\\beta) \\to 0")#text(" in the limit ")#mi("\\beta \\to 0")#text(". This shows that among all the roughly ")#mi("\\alpha n^2/2")#text(" edges in the graph, at most ")#mi("c(\\beta) n^2")#text(" of them will already be incident to all the triangles in the graph. This, and Cauchy-Schwarz, gives a bound of the form")

#align(center)[#mi("\\gamma \\geq \\frac{\\beta^2}{c(\\beta)} - o(1)")#text(", (**)")]

#text("which is a better bound than (*) when ")#mi("\\beta")#text(" is small compared with ")#mi("\\alpha")#text(".")

#text("Luca’s question is: can one replace ")#mi("c(\\beta)")#text(" in (**) by any more civilised function of ")#mi("\\beta")#text("? To explain what “civilised” means, let me show you the best bound that we know of today. Let ")#mi("2 \\uparrow \\uparrow n")#text(" be the tower-exponential of height n, defined recursively by")

#align(center)[#tao-fit-display[#mitex("2 \\uparrow \\uparrow 1 := 2; \\quad 2\\uparrow \\uparrow(n+1) := 2^{2\\uparrow \\uparrow n};")]]

#text("this is a very rapidly growing function, faster than exponential, double exponential, or any other finite iterated exponential. We invert this function and define the inverse tower function ")#mi("\\log_* n")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\log_* n := \\inf \\{ m: 2 \\uparrow \\uparrow m \\geq n \\}.")]]

#text("This function goes to infinity as ")#mi("n \\to \\infty")#text(", but ")#emph[#text("very")]#text(" slowly – slower than ")#mi("\\log n")#text(" or even ")#mi("\\log \\log n")#text(" (which, as famously stated by ")#link("http://www.math.dartmouth.edu/~carlp/")[#text("Carl Pomerance")]#text(", “is proven to go to infinity, but has never been observed to do so”).")

#text("The best bound on ")#mi("c(\\beta)")#text(" known is of the form")

#align(center)[#tao-fit-display[#mitex("c(\\beta) \\ll (\\log_* \\frac{1}{\\beta})^{-\\epsilon}")]]

#text("for some absolute constant ")#mi("\\epsilon > 0")#text(" (e.g. 1/10 would work here). This bound is so poor because the proof goes via the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(", which is known ")#link("http://www.ams.org/mathscinet-getitem?mr=1445389")[#text("by the work of Gowers")]#text(" to necessarily have tower-type dependencies in the constants.")

#text("The open question is whether one can obtain a bound of the form (**) in which ")#mi("1/c(\\beta)")#text(" is replaced by a quantity which grows better in ")#mi("\\beta")#text(", e.g. one which grows logarithmically or double logarithmically rather than inverse-tower-exponential. Such a bound would perhaps lead the way to improving the bounds on the triangle removal lemma; we now have many proofs of this lemma, but they all rely on one form or another of the regularity lemma and so inevitably have the tower-exponential type bounds present. The triangle removal lemma is also connected to many other problems, including property testing for graphs and ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("Szemerédi’s theorem on arithmetic progressions")]#text(" (indeed, the triangle removal lemma implies the length three special case of Szemerédi’s theorem, i.e. Roth’s theorem), so progress on improving (**) may well lead to much better bounds in many other problems, as well as furnishing another tool beyond the regularity lemma with which to attack these problems.")

#text("Curiously, the work of ")#link("http://www.ams.org/mathscinet-getitem?mr=2274085")[#text("Lovász and Szegedy")]#text(" implies that the question can be rephrased in a purely analytic fashion, without recourse to graphs. Let ")#mi("W: [0,1]^2 \\to [0,1]")#text(" be a measurable symmetric function on the unit square, and consider the quantities")

#align(center)[#tao-fit-display[#mitex("\\beta := \\int_0^1 \\int_0^1 \\int_0^1 W(x,y) W(y,z) W(z,x)\\ dx dy dz")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\gamma := \\int_0^1 \\int_0^1 \\int_0^1 \\int_0^1 W(x,y) W(y,z) W(z,x) W(y,w) W(w,x) \\ dx dy dz dw.")]]

#text("Any bound connecting ")#mi("\\beta")#text(" and ")#mi("\\gamma")#text(" here is known to imply the same bound for triangle and diamond densities (with an error of o(1)), and vice versa. Thus, the question is now to establish the inequality ")#mi("\\gamma \\geq \\beta^2/c^{\\prime}(\\beta)")#text(" for some civilised value of ")#mi("c;(\\beta)")#text(", which at present is only known to decay to zero as ")#mi("\\beta \\to 0")#text(" like an inverse tower-exponential function.")

#text("[")#emph[#text("Update")]#text(", Apr 4: wording changed to remove ambiguity about different meanings of ")#mi("c(\\beta)")#text(".][")#emph[#text("Update")]#text(", Apr 21: Thanks to ")#link("https://umdrive.memphis.edu/vnikifrv/public/vlado.html")[#text("Vlado Nikiforov")]#text(" for pointing out some additional references and related questions.]")

#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-273")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2007")])]

#text("Hi Terry,")

#text("Didn’t you use c(\\beta) to denote two different things? You started with defining c(\\beta) as the triangle-removal-lemma constant, but later say that a better bound for c(\\beta) may imporve the triangle removal lemma.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-283")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2007")])]

#text("You’re right; I’ve changed the wording in the post to try to clarify the point. The hope is that this problem is easier than improving the triangle removal lemma bound directly, but perhaps a solution to this problem will then lead the way to find a new way to prove triangle removal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-513")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2007")])]

#text("A small update: Yuval Peres has pointed out to me that there is a ")#link("http://www.ams.org/mathscinet-getitem?mr=1319175")[#text("conjecture of Sidorenko")]#text(" which has a somewhat similar flavour. It asserts that given bipartite graphs ")#mi("G = (V_G, W_G, E_G)")#text(" and ")#mi("H = (V_H, W_H, E_H)")#text(" (one should think of G as large and H as small), the number of copies of H inside G (mapping ")#mi("V_G")#text(" to ")#mi("W_G")#text(", ")#mi("V_H")#text(" to ")#mi("W_H")#text(", and allowing repeated vertices) is at least ")#tao-math("\\left|V_G\\right|^{\\left|V_H\\right|} \\left|W_G\\right|^{\\left|W_H\\right|} (\\left|E_G\\right|/\\left|V_G\\right| \\left|W_G\\right|)^{\\left|E_H\\right|}", block: false)#text(", which is the value attained asymptotically when G is a large random graph. This conjecture is known to be true for instance when H is a cycle, a path, a star, and for a couple other graphs. It also has an analytic formulation similar to the one given above for the triangle-diamond problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04c37d853459282ffe256951223c76fef1ef8c693447c8a516a8d7ba68a8a48e-82a3aeb2b2107d0a6365b8f6dd71c293997670cf6543e95a800917d80976ebf5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Hillman")]], [#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-514")[#strong[#text("Chris Hillman")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2007")])]

#text("Changing topics (but perhaps not leaving the subject of sharp inequalities), I am curious to know whether other fans of “counting with categories” a la ")#link("http://arxiv.org/abs/math/0004133")[#text("Baez and Dolan")]#text(", who are aware of ")#link("http://www.maths.qmul.ac.uk/~pjc/")[#text("Cameron’s conjectures")]#text(", have seen ")#link("http://arxiv.org/abs/0704.1548")[#text("a recent article of Pouzet")]#text(".")

#text("(For those who have no idea what I am talking about: I claim one can rewrite Wilf, Generatingfunctionology in terms of “structors” or combinatorial species, a kind of “categorification” of generating functions, along the lines one would guess after reading Baez and Dolan’s paper. This is “merely” a change of perspective but I think it suggests interesting new questions. See the undergraduate text by Cameron, Permutation Groups, Cambridge University Press, LMS student texts vol. 45, 1999, for a generalization of Polya enumeration which lies at the heart of this program, plus a very nice introduction to random graphs. It would be interesting to know more about the “density of p-cycles in a random Schreier digraphs”, if one can make sense of that notion. Schreier digraphs generalize Cayley graphs to general actions by a finite group.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-518")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2007")])]

#text("Dear Chris,")

#text("This is quite interesting. Certainly categorification is useful in enumerative combinatorics (being a souped up version of bijective proofs, as Baez and Dolan note), but as far as I am aware it has not really played much of a role in extremal combinatorics. In particular, the Cauchy-Schwarz inequality, arguably the most basic of the fundamental inequalities in the subject, does not appear to have a categorified version. A more concrete problem: suppose ")#mi("f: X \\to Y")#text(" is a map from one finite set to another. Then the relative product ")#mi("X \\times_f X := \\{ (x_1,x_2): f(x_1) = f(x_2) \\}")#text(" is known to have cardinality at least ")#tao-math("\\left|X\\right|^2/\\left|Y\\right|", block: false)#text(", by Cauchy-Schwarz. In other words, ")#mi("(X \\times_f X) \\times Y")#text(" is at least as large as ")#mi("X \\times X")#text(". Is there a categorical proof of this fact (which, incidentally, is basically equivalent to Sidorenko’s conjecture for paths of length 2)? See also ")#link("http://www.dpmms.cam.ac.uk/~wtg10/csineq.html")[#text("Tim Gowers’ discussion of the Cauchy-Schwarz inequality")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-521")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2007")])]

#text("It may not count as categorification, but I can think of an example in extremal combinatorics where it pays to enhance bijections, rather than to erase them as in the example of the fibered Cartesian square of a set. Namely, Peter McMullen conjectured the optimal inequalities for the f-vector (vector of face numbers) of a simple polytope; the conjecture was that the associated h-vector is unimodal. Richard Stanley proved this conjecture by building homology groups (the homology of a toric variety) whose dimension sequence is the h-vector, and then showing that the homology groups form a representation of the Lie algebra sl(2). Thus, the h-vector is unimodal because it is a weight diagram.")

#text("Another example of proof by enhancement of combinatorics is Lovasz’s celebrated proof of the Kneser conjecture, using a topological method to bound the chromatic numbers of graphs.")

#text("Perhaps what can be said about these examples is that they are fairly exacting bounds. Most, or perhaps all, of the inequalities become elementary if you relax them moderately. This is unlike Ramsey theory, where in a sense the inequalities cut far deeper than any elementary bound. On the other hand, I am not sure whether this is really a robust distinction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-523")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2007")])]

#text("Dear Greg,")

#text("These are good examples, which I wasn’t previously aware of; I concede that there are several important non-analytic (and non-algorithmic) techniques in extremal combinatorics, at least some of which should be categorifiable :-) . Certainly algebraic or geometric tools are good for proving monotonicity or positivity properties, which are of course an important approach to extremal combinatorics problems. There is also the “polynomial method” in extremal combinatorics, which is based on various generalisations of the basic fact “a polynomial of one variable of degree n can have at most n zeroes”; a particularly useful such generalisation is the ")#link("http://www.math.tau.ac.il/~nogaa/PDFS/null2.pdf")[#text("combinatorial Nullstellensatz")]#text(" of Alon.")

#text("I hadn’t seen Lovasz’s argument before – it is very beautiful – but topological arguments have appeared in extremal combinatorics in some other contexts. For instance, the ")#link("http://en.wikipedia.org/wiki/Crossing_number")[#text("crossing number inequality")]#text(" is really useful in incidence geometry and in arithmetic combinatorics, and is ultimately proven by a combination of Euler’s formula and the probabilistic method.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04c37d853459282ffe256951223c76fef1ef8c693447c8a516a8d7ba68a8a48e-82a3aeb2b2107d0a6365b8f6dd71c293997670cf6543e95a800917d80976ebf5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Hillman")]], [#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-532")[#strong[#text("Chris Hillman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2007")])]

#text("Well, I seem to have committed the cardinal sin of posting before lurking, so I don’t know if you (plural) have said this here before! I hope you’ll all bear with me while I try to catch up. (Also, I haven’t tried to use pseudolatex in wordpress before, but I’ll take a guess and hope for the best.)")

#text("IIRC, what Terry called “relative product” and Greg called “fibered Cartesian square of a set” is called “kernel congruence” in Mac Lane, Categories for the Working Mathematician, Springer, 1971, and it is a special case of a “pullback square”. As a relation on X, the kernel congruence ")#mi("X \\times_{f,f} X = \\{ (x_1,x_2): x_1 \\in X, \\, x_2 \\in X: f(x_1)=f(x_2) \\}")#text(" does indeed correspond to the kernel when f is a group epimorphism, say, in which case the preimages all have the same size and equality holds.")

#text("More generally, drawing a picture of the kernel congruence for a mapping from a finite set X to a finite set Y as an |X| by |X| by |Y| “box” made up of unit cubes in which the ordered pairs in the kernel congruence are darkened, and where the elements of X are listed in the order first preimage, second preimage, and so on, the cubes in kernel form square “briefcases” one layer thick and the number of these cubes is seen to the sum over the image of f of the squares of the preimages. So in the CS inequality")#linebreak()#text(" ")#mi("\\left( \\sum_j a_j b_j \\right)^2 \\leq \\left( \\sum_j a_j^2 \\right) \\; \\left( \\sum_j b_j^2 \\right)")#linebreak()#text(" let a_j be the sizes of the primages and let all the b_j = 1. This gives ")#tao-math("((\\text{ker} f) \\cdot \\left|Y\\right|  \\geq ((\\text{ker} f) \\cdot \\left|\\text{im} f\\right| \\geq \\left|X\\right|^2", block: false)#text(" with equality iff (a_j) and (b_j) are linearly dependent, i.e. iff the preimages all have the same size, where the last bit is I take it the interesting part. That’s what you have in mind by “the CS argument”, right?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-535")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2007")])]

#text("Dear Chris,")

#text("Sorry about the latex issues; it seems that the wordpress site doesn’t let one preview comments. But I can manually repair the latex (in this case, the editor didn’t like the use of primes, x’, or of \\operatorname{}). Worst case, just type in pseudolatex and I can clean it up as best I can.")

#text("That is indeed the Cauchy-Schwarz argument I had in mind; the question is whether there is a “categorical” version of this proof, in which the numbers a_j, b_j are replaced by richer objects such as sets. Incidentally, there is now a parallel discussion of this topic over at the ")#link("http://golem.ph.utexas.edu/category/2007/04/the_two_cultures_of_mathematic.html#comments")[#text("n-category cafe")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04c37d853459282ffe256951223c76fef1ef8c693447c8a516a8d7ba68a8a48e-82a3aeb2b2107d0a6365b8f6dd71c293997670cf6543e95a800917d80976ebf5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Hillman")]], [#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-537")[#strong[#text("Chris Hillman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2007")])]

#text("Thanks for fixing my markup! And for the link to n-category cafe, although unfortunately, I don’t have MathML functionality so I can hardly ever read anything there. Your blog seems to work much better for me.")

#text("I just read your ICM talk and am feeling suitably inspired. Or distracted— I seem to be getting farther OT with every word! A few comments/queries:")

#text("1. “Solutions to highly nonlinear systems should behave randomly after accounting for conservation laws, etc.” Would it be fair to guess that the KdV would be “modestly nonlinear” in this sense? (“Too many” conservation laws?)")

#text("What about the BKL conjecture in general relativity? (I don’t know of an adequate exposition— the Wikipedia article is seriously misleading— but one version says something to the effect that curvature singularities in generic vacuum solutions of the Einstein field equation resemble the strong spacelike curvature singularity which occurs in the so-called Mixmaster universe. The kicker here is that approach to the Mixmaster singularity is “regulated” by a simple continued fraction expansion!")

#text("BTW, I recommend the article by Lagarias in The Unreasonable Effectiveness of Number Theory, ed. by Stefan A. Burr, AMS, 1992 as a wonderful survey of how number theory is relevant to dynamical systems.)")

#text("2. The difficulty of “assessing” (much less “navigating”) large function spaces, such as solution spaces of nonlinear PDEs: I have found the paper by C.T.C. Siklos, “Counting solutions of Einstein’s equations”, Class. Quantum Grav. 13 (1996): 1931-1948 to be very intriguing— and perfectly maddening. If I can ever say something sensible about this I plan to post it in ")#link("http://www.arsmathematica.net/")[#text("http://www.arsmathematica.net/")]#text(" …")

#text("3. I just came across ")#link("http://tosio.math.toronto.edu/wiki/index.php/Main_Page")[#text("http://tosio.math.toronto.edu/wiki/index.php/Main_Page")]#text(" and I want one of those! (A pywiki.) I have felt for some time that the future of wikis is this: authorship tools for research groups or even single authors. So I am very glad to see this well-disciplined example of an “open notebook”!")

#text("I guess you know the website ")#link("http://eqworld.ipmnet.ru/")[#text("http://eqworld.ipmnet.ru/")]#text(" ? As it happens, I have computed the point symmetry group of a whole bunch of PDEs, including many mentioned in these places, and AFAIK there is no website collecting this information.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-554")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2007")])]

#text("Dear Chris,")

#text("Thanks for the comments. I have only very fuzzy answers to some of your questions, but yes, I would consider KdV as being very close to linear in behaviour (indeed, with regard to suitable action-angle coordinates, or via the inverse scattering transform) the evolution is (formally) ")#emph[#text("perfectly")]#text(" linear. In particular one doesn’t see turbulent behaviour, such as cascades of energy into increasingly higher frequency scales, which seems to plague other very nonlinear equations and which seems to generate a lot of “mixing” in the dynamics.")

#text("For perturbations of integrable systems one of course has KAM theory on one hand, so that there is a positive measure subset of phase space in which the dynamics continues to behave like an integrable system, and Arnold diffusion on the other, where one spreads out to cover most of the energy surface. I suppose this is some sort of intermediate regime between integrable and strongly nonlinear.")

#text("I am not an expert on mathematical relativity, though I can confidently say that the rigorous understanding of singularity formulation for the vacuum Einstein equations, while it is making good progress, is still very far away from the point where we can say or even conjecture any really good structural properties of a typical blowup. If one makes some strong symmetry reductions then one might be able to say something more (cf. Christodoulou’s proof of the cosmic censorship conjecture assuming spherical symmetry) but then it is arguable whether one is now considering “generic” behaviour. It is cute to see that number theory plays a role in these special solutions, though in some other contexts (e.g. periodic dispersive equations) it seems that many of these number-theoretic structures are fragile (e.g. they go away if a torus is replaced by a slightly perturbed domain).")

#text("Thanks for the link to eqworld, which I hadn’t seen before. It is good to see many different types of experiments regarding how to make good mathematical use of the Web; I feel that this is still an under-utilised medium in our subject, though it is not entirely clear how to systematically exploit it more effectively.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-677")[#strong[#text("Ars Mathematica » Blog Archive » Combinatorial Nullstellensatz")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2007")]

#text("[…] this thread on his weblog, Terry Tao mentioned an exciting paper by Noga Alon. The paper explains a result that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/374a174b6ac0b9a0197b5c263eb1702dffcc305abf2e759035a517cea5e76f70-d9d9c7c1c1a1594061b8d82d1463102d93fb95bffc4f82bf55fe636696aa178c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vlado Nikiforov")]], [#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-691")[#strong[#text("Vlado Nikiforov")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2007")])]

#text("Dear Teri,")

#text("In another tradition diamonds are called “books of size 2”. In general, a “book of size k” is a set of k triangles sharing a common edge. The size of the maximal book in a graph is called its booksize.")#linebreak()#text(" Since 1962 Erdős has asked many questions about the booksize of graphs. Some of them are answered in arXiv.org:math/0405080.")#linebreak()#text(" More up to the point is the following open question of Erdős and Rothschild (e.g., Chung and Graham “Erdős on graphs”, p. 48):")

#text("What is the minimal booksize of a graph of order n with edge density c>0 if every edge is in a triangle?")

#text("Using the Regularity Lemma, Szemerédi showed that this value goes to infinity with n. The upper bound due to Erdős and to Alon and Trotter is proportional to the square root of n.")#linebreak()#text(" To see the importance of graphs with every edge in a triangle note that the following statement, together with the Solymósi projection, implies the existence of a three term arithmetic progression in dense subsets of integers:")

#text("Let a graph of order n has edge density c>0 and every edge is in a triangle. Then, if n is sufficiently large, the graph contains a diamond.")

#text("This statement seems weaker than the triangle removal lemma. Is this really so?")#linebreak()#text(" Also it seems that the functions involved in the problems of Trevisan and of Erdős-Rothschild are related. Is there any clear relationship between them?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf445dd3ded972a5d1b62126dac2900bf47db6c85c39b95626f92b945e4f092-821d2a67ec2aa6fd2150e7112d80a9cf9bad4da7b90b8dab1f324d9a6a89f5c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-694")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2007")])]

#text("One can fit 5 unit-edge regular tetrahedra in R^3 sharing a common edge, but no more. This might be called a 3-book of size 5. In hyperbolic space, one can have more tetrahedra share an edge on polytetrahedra.")

#text("Polytetrahedra relate loosely to tetrahedralization, and tightly to the structure of proteins and glasses. Some results are known for the Euclidean geometry, usefully in projecting from R^4 to R^3. But are the equivalent results for 3-books known as for books as previously defined, in the graph-theory sense (where the “steric hinderence” of R^3 is not a constraint)?")

#text("Search on the term “polytetrahedra” at the Online Encyclopedia of Integer Sequences for an extremely elementary and yet novel combinatorial enumeration problem I’ve posed and only scratched the surface of answering.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The correspondence principle and finitary ergodic theory « What’s new")]], [#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-32331")[#strong[#text("The correspondence principle and finitary ergodic theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2008")])]

#text("[…] in passing that it actually implies the k=3 case of Szemerédi’s theorem. (See also my previous blog posts on related topics.) It turns out that this result can be deduced from some […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-38744")[#strong[#text("The Triangle Removal Lemma « in theory")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2009")]

#text("[…] wrote a fascinating post putting this question in the broad context of extremal questions about “local patterns” […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mathinfant")]], [#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-38985")[#strong[#text("Mathinfant")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2009")])]

#text("Dear Professor Tao:")

#text("I have some confuse in the triangle upper bound. Let ")#mi("X")#text(" denote the number of triangle, then ")#mi("E(X)~n^3\\alpha^3")#text(". It seems that average number of triangle is “larger” than above upper bound. Is anyone can answer me what’s wrong in my estimate?")

#text("Due to I have no any mathmatical backround, excuse for my too stupid question.")

#text("Thank you for your response.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mathinfant")]], [#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-38986")[#strong[#text("Mathinfant")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2009")])]

#text("Sorry for above typing errors. I don’t understand how to delete above comment. So, I rewrite here.")#linebreak()#text(" The expection is ")#mi("E(X)\\sim n^3\\alpha^3")#text(", then one can get the average density is about ")#mi("\\alpha^3")#text(". It seems larger than ")#mi("\\alpha^{3/2}")#text(".")

#text("Thank you all again.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-38991")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2009")])]

#text("Dear Mathinfant,")

#mi("\\alpha^3")#text(" is smaller than ")#mi("\\alpha^{3/2}")#text(" for ")#mi("0 < \\alpha < 1")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-39108")[#strong[#text("Structure and Randomness: Pages from Year One of a Mathematical Blog « Abner’s Postgraduate Days")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2009")]

#text("[…] Open question: triangle and diamond densities in large dense graphs […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/01/open-question-triangle-and-diamond-densities-in-large-dense-graphs/#comment-447277")[#strong[#text("Determinant of a pullback diagram | CL-UAT")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2014")]

#text("[…] Terence Tao observes in one the comments on his weblog that the product of |PB| and |Y| is always greater than or equal to |X|2. (This is an application of the Cauchy-Schwarz inequality.) This fact may be rephrased as follows: If we ignore in the above diagram all arrows and replace the sets by their cardinalities we obtain a 2×2 matrix with a non-negative determinant. […]")
]
