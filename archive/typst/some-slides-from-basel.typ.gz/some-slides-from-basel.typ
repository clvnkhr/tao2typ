// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/
// Converted to Typst by tao2typ: "2026-10-14T16:38:41.625997+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Some slides from Basel", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Some slides from Basel")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 February 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/")[#text("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I have just returned from Basel, Switzerland, on the occasion of the awarding of the ")#link("https://en.wikipedia.org/wiki/Ostrowski_Prize")[#text("2019 Ostrowski prize")]#text(" to ")#link("https://en.wikipedia.org/wiki/Assaf_Naor")[#text("Assaf Naor")]#text(". I was invited to give the laudatio for Assaf’s work, which I have uploaded ")#link("https://terrytao.wordpress.com/wp-content/uploads/2020/02/assaf.pdf")[#text("here")]#text(". I also ")#link("https://www.unibas.ch/en/News-Events/News/Uni-Agenda/Fields-medalist-Terence-Tao--Lecture-in-Basel.html")[#text("gave a public lecture")]#text(" (intended at the high school student level) at the University of Basel entitled “The Notorious Collatz conjecture”; I have uploaded the slides for that ")#link("https://terrytao.wordpress.com/wp-content/uploads/2020/02/collatz.pdf")[#text("here")]#text(". (Note that the slides here are somewhat unpolished as I was not initially planning to make them public until I was recently requested to do so. In particular I do not have full attribution for some of the images used in the slides.)")

#text("Basel has historically been home to a number of very prominent mathematicians, most notably ")#link("https://en.wikipedia.org/wiki/Jacob_Bernoulli")[#text("Jacob Bernoulli")]#text(", whose headstone I saw at the ")#link("https://en.wikipedia.org/wiki/Basel_Minster")[#text("Basel Minster,")]

#image("../assets/ddd33b131305151caf50d4eb49ef2177a67fafc67d7a99d24dd1ff4cef8ddac2-ed0632edffe6502b0c6b64d8ce85da175cae7fc6e3ea4203909849778c9fc9ca.jpg", width: 90%)

#text("and also ")#link("https://en.wikipedia.org/wiki/Leonhard_Euler")[#text("Leonhard Euler")]#text(", for which I could not find a formal memorial, but I did at least see a hotel bearing his name:")

#image("../assets/9b5667b78c2a508441831971ed264c24df96a6005d0a058872a2cbd403f0d486-5c77dcd0ccde070b4f0e79d5b4ffae4546c5123cea8266274115d294ce47f7c9.jpg", width: 90%)

#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9d2b471a95950cf9ab900a2a956433a802e53dd7dce19b8f99e969eecbfb6d-928b219cdc034ba412fab685a5c24ece80537934e15e706cc872bf337f74deba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-540732")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2020")])]

#text("I don’t know about memorials, but Euler’s actual grave is in St. Petersburg.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rabe")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-540744")[#strong[#text("Rabe")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2020")])]

#text("Did you find Hotel Hilbert as well? Thank you for sharing this!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-540928")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2020")])]

#text("Is that the one in the song? “Since my baby left me, I’ve had a new place to dwell; Its floors go to infinity, it’s the… Hilbert Hotel”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-540749")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2020")])]

#text("Euler is also known as the solver of the Basel problem")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Basel_problem")[#text("https://en.wikipedia.org/wiki/Basel_problem")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63ddb2932f75fce714a4ee7d91dae89a8bd85d72e3a60b5795d6a2434f5e71af-a788db6748036dabecc6eaea2fb41740c9f05215f2630ece0f1a46929cc5c196.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JosephSugar")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-540755")[#strong[#text("JosephSugar")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2020")])]

#text("The “eadem mutata resurgo” is interesting. Wonder if he simply refers to the spiral or it was his philosophical take on life, nature, the universe, in general. The problem is that mutata is both feminine singular and neuter plural.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-540762")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2020")])]

#text("Congratulation to Assaf!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5f02c7347a4e573f77b482157b09a9a490cf59f7460d5c188f5fbfa02601a90-2b8fe8e966be9de09f4a2498b6585f2963fbed7ab88cee0a3e660282cdc211ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-540766")[#strong[#text("Max")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2020")])]

#text("Thanks for one more inspiring post! But you should please correct repeated instances of “Radamacher” to (Hans) *Rademacher* (in the Assaf laudatio at least, didn’t check whether it appears in the other lecture or in your arxiv.org/1909.03562). (I could imagine the Swiss already made that remark – it really hurts the eyes of a German-speaking reader!)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13adaff32d54f3bdf4caf53abe3d7d7661f47307b45be7dfe4a21eeb122bc96c-30478c564e1d0b5eb16035de2a3eae50d90ef7462ef80bb9d6ab9ae482bb19a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Radu Zaharopol")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-540880")[#strong[#text("Radu Zaharopol")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2020")])]

#text("Dear Professor Tao,")

#text("Many thanks for your message. Sincerely yours, Radu Zaharopol")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcc8946f803e2fd7a6157d43b3a347a85dfdccc1a772a4fe526012aa745e91ff-b32507acb466766f9be1685d880c057ea5d929c88b1bbb6a4e287c2627f485ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Fry")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-540893")[#strong[#text("David Fry")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2020")])]

#text("Dear Terry,")

#text("What an amazing academic trip regarding Switzerland.Â But the burning question here is, HOW WAS THE CHOCOLATE? Thanks, David")

#text("Very Sincerely,")

#text("David W. Fry")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5162cf9bfb600aae7b0dc75c9f8954e80ab40e82e0a8fce12c188ea5c394ffa1-a5f3ee3445e76a613b7f243e63de1aa8fa020a569c47d4983450280115329df4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michel Eve")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-541015")[#strong[#text("Michel Eve")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2020")])]

#text("Dear Prof Tao")

#text("I have a naive question regarding the Collatz conjecture. As I am just an amateur, I waited to have a low level presentation of your results to understand the progress made .I have therefore a question on your excellent slides on the subject.")#linebreak()#text(" You mention the work of Terras which shows that almost all initial values n iterate eventually to a value less than n and you make the point that, if it had been “all” initial values then the conjecture would have been proven. This seems to say that the conjecture is proven for all initial values except for a small subset S of initial values for which one cannot say anything.")#linebreak()#text(" Then you present you latest result which is tighter but still applies to “almost all” initial values but you claim that this is the closest one can get short of a full proof of the conjecture.")#linebreak()#text(" My question is : Do you share the same definition of “almost all” with Terras ? ie: is your subset S the same as Terras’s ? If it is the same then it is a step forward but if it is larger ..")#linebreak()#text(" I am sure that I must be wrong somewhere ,I would very much appreciate your comment.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5162cf9bfb600aae7b0dc75c9f8954e80ab40e82e0a8fce12c188ea5c394ffa1-a5f3ee3445e76a613b7f243e63de1aa8fa020a569c47d4983450280115329df4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michel Eve")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-541016")[#strong[#text("Michel Eve")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2020")])]

#text("Sorry I see now that my statement “the conjecture is proven for the subset N-S is wrong as some values less than n may lie in S…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-541022")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2020")])]

#text("Hotel Euler is not named after Leonhard. Abraham Euler established a taverna in 1867 which later became the hotel. But of course maybe Abraham was (far) family of Leonhard, born 1707.")#linebreak()#text(" I always enjoy reading about the Collatz Conjecture. Some 25 years ago I tried to solve it as well and created pictures of triangles representing the binary digits of the numbers. Was reminded of this when I read your new “almost all” paper.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6177de1b157421feabe311888b515f06cc12782b0989502ef21804e4a8cf2a09-331e79ac95d6791d17471deb1dc0d5bc41868ef2b6f58b3c4efb84d0ca44e790.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Howe")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-541307")[#strong[#text("Andrew Howe")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2020")])]

#text("Superb Collatz slides thanks – very accessible for aspiring mathematicians. I will be forwarding to a pre-university friend")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b5fcb88c9ab5b0793fe7c14e056ae27817b078a8afce60204d515de6ef4d809-f599d4173b17f9eb4328d7a652e280c44df05fd53449e3cfe876363cd260b3bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Moriarty")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-541613")[#strong[#text("James Moriarty")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2020")])]

#text("So you are using the Samsung Galaxy S9 SM-G960U. Well, I suppose it’s got a reasonably safe operating system – except towards Google Inc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8a746666689e06841df8a45e5267e5592442e58571767fe34dbb453b008501dc-697d6eb77c17f7d0f509cc18fabf10e5849973afb4f076b5640955b5040b10bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Islem Ghaffor")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-541797")[#strong[#text("Islem Ghaffor")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2020")])]

#text("An Equivalent Problem to the Collatz Conjecture")

#link("https://paulhus.math.grinnell.edu/ants2018/PosterSlides/Ghaffor.pdf")[#text("Click to access Ghaffor.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-542466")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2020")])]

#text("This is a nice idea to represent the Collatz iteration (originally given in terms of one variable) by using two (or more) variables, since the original (one dimensional) formulation of the iteration as a (deterministic) discrete-time Markov chain may have several equivalent representations using finitely many “state variables” – which may be easier to analyze than the original formulation (which is based on a single “state variable”) – the idea to use the Syracuse iteration (in order to simplify the analysis) is similar, but perhaps there are even better (perhaps multidimensional iterations) equivalent formulations which may have additional “nice properties” (to simplify the analysis) than the Syracuse iteration.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c4e6eedfb5a83ec41e37056f0d97f3d3ca44e4fbab5e7916bc6f537ce7758fc-6f6d9683c4eea1a2cc9006791c56eaf659f1f426fa2df727faa455f5abb46bb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Silverman")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-542483")[#strong[#text("Robert Silverman")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2020")])]

#text("I reply here because I do not know how to start a new thread.")

#text("I am astonished that there has been no mention of Peter Montgomery’s")#linebreak()#text(" passing:")

#link("https://fataldeaths.com/2020/Peter-Montgomery-(mathematician)")[#text("https://fataldeaths.com/2020/Peter-Montgomery-(mathematician)")]

#text("Peter was a good friend and I am deeply saddened by his death.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b71017f3ba0f543c5044556f27512e72972ffa9e69a8bf9184eadd8f7695b8bf-bea05fabd012afb0eff4e8714fccbbf0a0ed5d4690e1d374727fd01c1f9ac003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael R")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-542560")[#strong[#text("Michael R")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2020")])]

#link("https://iacr.org/people/PeterMontgomery.html")[#text("https://iacr.org/people/PeterMontgomery.html")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b71017f3ba0f543c5044556f27512e72972ffa9e69a8bf9184eadd8f7695b8bf-bea05fabd012afb0eff4e8714fccbbf0a0ed5d4690e1d374727fd01c1f9ac003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael R")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-542561")[#strong[#text("Michael R")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2020")])]

#text("This is the only obit I found via google search.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61115be3303f3c205803299e0f7bf10b3305a7a5b3b99af57971a12009f46491-63729fdb74bb55e8200d8e15acc0ea84e12cf455832076b37fe44337571b35fe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Lotz")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-542833")[#strong[#text("Martin Lotz")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2020")])]

#text("There is a memorial to Euler at the place of his birth, in Riehen (a suburb of Basel): ")#link("https://images.app.goo.gl/W7x696Z9ieEx4Aj67")[#text("https://images.app.goo.gl/W7x696Z9ieEx4Aj67")]#linebreak()#text(" This is very close to where my parents live, used to go past this place regularly :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50d4b0970b1402c51937c1a4fda630d40091563398ee9290fe43d42f8dd41cfa-7ebf57886f030776ec0fe0d49faf42741e8dd098246943bc3d9b8eafbf34ccdf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-543053")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2020")])]

#text("Fed cut 0.5 points. Does the fed know something we don’t? Is it trying assimilate ‘common knowledge’ in your parlance?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-591949")[#strong[#text("collatz standing on shoulders of giants (not!) | Turing Machine")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2020")]

#text("[…] the quanta writeup. he also has an excellent “high school” level slideshow refd on his blog, my favorite slide is the squirrel at the end that also seems to ref Creation of Adam by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f92d53457c5803b9cca394f6955658a241ecb3fe5e6fd369db3efe9dd965f0f-7fd5ea2993cb2f0216e06c205ee5e47db928e8ae83216d4ea358dcaa9974ea05.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of john ronand")]], [#link("https://terrytao.wordpress.com/2020/02/16/some-slides-from-basel/#comment-605088")[#strong[#text("john ronand")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2020")])]

#text("not sure if we can proof Collatz this way")#linebreak()#text(" ")#link("https://photos.app.goo.gl/w4gGNmocgPBqPziu6")[#text("https://photos.app.goo.gl/w4gGNmocgPBqPziu6")]
]
