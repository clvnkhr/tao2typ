// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/06/21/salem-prize-now-accepting-nominations/
// Converted to Typst by tao2typ: "2026-10-14T16:39:07.676549+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Salem Prize now accepting nominations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Salem Prize now accepting nominations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 June 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/06/21/salem-prize-now-accepting-nominations/")[#text("https://terrytao.wordpress.com/2023/06/21/salem-prize-now-accepting-nominations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The ")#link("https://en.wikipedia.org/wiki/Salem_Prize")[#text("Salem prize")]#text(" was established in 1968 and named in honor of Raphaël Salem (1898-1963), a mathematician famous notably for his deep study of the links between Fourier series and number theory and for pioneering applications of probabilistic methods to these fields. It was largely administered by Jean Bourgain until his untimely death in 2018; due to this and the COVID-19 pandemic, no prize was awarded for the years of 2019-2022. A list of past winners may be ")#link("https://lmrs.univ-rouen.fr/fr/content/prix-salem")[#text("found here")]#text(".")

#text("However, I am happy to report that the prize has been reactivated, and is now formally ")#link("https://www.ias.edu/math/activities/salem-prize")[#text("hosted by the Institute for Advanced Study")]#text(", with Akshay Venkatesh overseeing the administration of the prize, and is ")#link("https://www.mathprograms.org/db/programs/1474")[#text("accepting nominations for the 2023 Salem Prize")]#text(" until September 1st. Nominations should include a CV of the nominee and a nomination letter explaining the significance of the nominee’s work. Supplementary documentation, such as supporting letters of recommendation or key publications, can additionally be provided, but are not required.")

#text("Nominees may be individuals from any country or institution. Preference will be given to nominees who have received their PhD in the last ten years, although this rule may be relaxed if there are mitigating personal circumstances, or if there have been few Salem prize winners in recent years. Self-nominations will not be considered, nor are past Prize winners or Scientific Committee members eligible.")

#text("The prize does not come with a direct monetary award, but winners will be invited to visit the IAS and to give a lecture associated with the award of the prize.")

#text("I will be chairing the Scientific Committee to evaluate the nominations and recommend a prize winner; Guy David and Mikhail Sodin have also agreed to serve. Special thanks also to Peter Sarnak for his tireless efforts to ensure the continuation of the prize after Jean’s passing.")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/21/salem-prize-now-accepting-nominations/#comment-678874")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2023")])]

#text("I can do some calculus but don´t speak english :-)")

#text("If someone can be the first name : ")#link("https://arxiv.org/abs/2204.07643")[#text("https://arxiv.org/abs/2204.07643")]

#text("We can do the job.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24a6e77567973bd548a06ba46cbbc75c7d37eb3612738fc16de4f083c6b081b6-68d6eaf1abd5bf564f2d449a44e084ca517ef40d64e2a31a86d42bb61b675ad5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ducduc2710")]], [#link("https://terrytao.wordpress.com/2023/06/21/salem-prize-now-accepting-nominations/#comment-678895")[#strong[#text("ducduc2710")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2023")])]

#link("https://www.researchgate.net/publication/371275600_Extend_Bertrand's_postulate_to_sums_of_any_primes")[#text("https://www.researchgate.net/publication/371275600_Extend_Bertrand's_postulate_to_sums_of_any_primes")]#text(" 1 quantum state. If the distribution of both sides of primes has the same parity, then 1 is infinity, and 2 is equal. The other 2 state is an expansion in the number of primes represented as n increases. It’s spooky and magical. State 2 is an extension of the Goldbach conjecture")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/21/salem-prize-now-accepting-nominations/#comment-678897")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2023")])]

#text("Concerning links between analytic functions in the unit disk and their Taylor coefficients, is it true that almost any random sequence of Taylor coefficients from the set {-1, 1} (with equal probabilities) converge to an analytic function in the unit disk with the unit circle as its natural boundary?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/21/salem-prize-now-accepting-nominations/#comment-678930")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2023")])]

#text("Yes. It seems this result dates back to a ")#link("https://mathscinet.ams.org/mathscinet/article?mr=0054882")[#text("1953 paper of Ryll-Nardzewski")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/21/salem-prize-now-accepting-nominations/#comment-678934")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2023")])]

#text("Thank you!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/21/salem-prize-now-accepting-nominations/#comment-681948")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2023")])]

#text("I am pleased to report that the 2023 Salem Prize has been awarded to Sarah Peluse and Julian Sahasrabudhe. ")#link("https://www.ias.edu/math/activities/salem-prize")[#text("https://www.ias.edu/math/activities/salem-prize")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Salem prize now accepting nominations for 2024 | What's new")]], [#link("https://terrytao.wordpress.com/2023/06/21/salem-prize-now-accepting-nominations/#comment-685257")[#strong[#text("Salem prize now accepting nominations for 2024 | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2024")])]

#text("[…] also the previous year’s announcement of the Salem prize nomination […]")
]
