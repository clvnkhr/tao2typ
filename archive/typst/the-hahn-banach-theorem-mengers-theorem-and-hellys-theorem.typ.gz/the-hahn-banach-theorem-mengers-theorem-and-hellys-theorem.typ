// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/
// Converted to Typst by tao2typ: "2026-10-14T06:52:57.928311+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Hahn-Banach theorem, Menger’s theorem, and Helly’s theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Hahn-Banach theorem, Menger’s theorem, and Helly’s theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 November 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/")[#text("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the ")#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/")[#text("previous post")]#text(", I discussed how an induction on dimension approach could establish ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_Nullstellensatz")[#text("Hilbert’s nullstellensatz")]#text(", which we interpreted as a result describing all the obstructions to solving a system of polynomial equations and ")#link("http://en.wikipedia.org/wiki/Inequation")[#text("inequations")]#text(" over an ")#link("http://en.wikipedia.org/wiki/Algebraically_closed_field")[#text("algebraically closed field")]#text(". Today, I want to point out that exactly the same approach also gives the ")#link("http://en.wikipedia.org/wiki/Hahn-Banach_theorem")[#text("Hahn-Banach theorem")]#text(" (at least in finite dimensions), which we interpret as a result describing all the obstructions to solving a system of linear inequalities over the reals (or in other words, a ")#link("http://en.wikipedia.org/wiki/Linear_programming")[#text("linear programming")]#text(" problem); this formulation of the Hahn-Banach theorem is sometimes known as ")#link("http://en.wikipedia.org/wiki/Farkas%27_lemma")[#text("Farkas’ lemma")]#text(". Then I would like to discuss some standard applications of the Hahn-Banach theorem, such as the ")#link("http://en.wikipedia.org/wiki/Hahn-Banach_theorem#Hahn-Banach_separation_theorem")[#text("separation theorem")]#text(" of Dieudonné, the ")#link("http://en.wikipedia.org/wiki/Minimax_theorem")[#text("minimax theorem")]#text(" of von Neumann, ")#link("http://en.wikipedia.org/wiki/Menger%27s_theorem")[#text("Menger’s theorem")]#text(", and ")#link("http://en.wikipedia.org/wiki/Helly%27s_theorem")[#text("Helly’s theorem")]#text(" (which was mentioned recently in an ")#link("https://terrytao.wordpress.com/2007/11/16/distinguished-lecture-series-iii-charles-fefferman-interpolation-of-functions-on-rn/")[#text("earlier post")]#text(").")

#metadata(none) <tao-c2f7409b258f6fa164b8>

#text("To simplify the exposition we shall only work in finite dimensions and with finite complexity objects, such as finite systems of linear inequalities, or convex polytopes with only finitely many sides. The results can be extended to the infinite complexity setting but this requires a bit of care, and can distract from the main ideas, so I am ignoring all of these extensions here.")

#text("Let us first phrase a formulation of the Hahn-Banach theorem – namely, Farkas’ lemma – which is deliberately chosen to mimic that of the nullstellensatz in the preceding post. We consider systems of linear inequalities of the form")

#align(center)[#tao-fit-display[#mitex("P_1(x), \\ldots, P_m(x) \\geq 0")]]

#text("where ")#mi("x \\in {\\Bbb R}^d")#text(" lies in a finite-dimensional real vector space, and ")#mi("P_1,\\ldots,P_m: {\\Bbb R}^d \\to {\\Bbb R}")#text(" are ")#link("http://en.wikipedia.org/wiki/Affine_transformation")[#text("affine")]#text("-linear functionals. We are interested in the classic linear programming problem of whether such a system admits a solution. One obvious obstruction would be if the above system of inequalities are inconsistent in the sense that they imply ")#mi("-1 \\geq 0")#text(". More precisely, if we can find non-negative reals ")#mi("q_1,\\ldots,q_m \\geq 0")#text(" such that ")#mi("q_1 P_1 + \\ldots + q_m P_m = -1")#text(", then the above system is not solvable. Farkas’ lemma asserts that this is in fact the only obstruction:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Farkas’ lemma")]#text(". Let ")#mi("P_1,\\ldots,P_m: {\\Bbb R}^d \\to {\\Bbb R}")#text(" be affine-linear functionals. Then exactly one of the following statements holds:")

#enum(start: 1, 
[#text("The system of inequalities ")#mi("P_1(x), \\ldots, P_m(x) \\geq 0")#text(" has a solution ")#mi("x \\in {\\Bbb R}^d")#text(".")],
[#text("There exist non-negative reals ")#mi("q_1,\\ldots,q_m \\geq 0")#text(" such that ")#mi("q_1 P_1 + \\ldots + q_m P_m = -1")#text(".")]
)
]

#text("As in the previous post, we prove this by induction on d. The trivial case d=0 could be used as the base case, but again it is instructive to look at the d=1 case first before starting the induction.")

#text("If d=1, then each inequality ")#mi("P_j(x) \\geq 0")#text(" can be rescaled into one of three forms: ")#mi("x-a_j \\geq 0")#text(", ")#mi("b_j-x \\geq 0")#text(", or ")#mi("c_j \\geq 0")#text(", where ")#mi("a_j")#text(", ")#mi("b_j")#text(", or ")#mi("c_j")#text(" is a real number. The latter inequalities are either trivially true or trivially false, and can be discarded in either case. As for the inequalities of the first and second type, they can be solved so long as all of the ")#mi("a_j")#text(" which appear here are less than equal to all of the ")#mi("b_j")#text(" which appear. If this is not the case, then we have ")#mi("b_j < a_k")#text(" for some ")#mi("j,k")#text(", which allows us to fashion -1 as a non-negative linear combination of ")#mi("(x-a_k)")#text(" and ")#mi("(b_j-x)")#text(", and the claim follows.")

#text("Now suppose that ")#mi("d \\geq 2")#text(" and the claim has already been proven for ")#mi("d-1")#text(". As in the previous post, we now split ")#mi("x = (x^{\\prime},t)")#text(" for ")#mi("x^{\\prime} \\in {\\Bbb R}^{d-1}")#text(" and ")#mi("t \\in {\\Bbb R}")#text(". Each linear inequality ")#mi("P_j(x^{\\prime},t) \\geq 0")#text(" can now be rescaled into one of three forms: ")#mi("t - a_j(x^{\\prime}) \\geq 0")#text(", ")#mi("b_j(x^{\\prime}) - t \\geq 0")#text(", and ")#mi("c_j(x^{\\prime}) \\geq 0")#text(".")

#text("We fix x’ and ask what properties x’ must obey in order for the above system to be solvable in t. By the one-dimensional analysis, we know that the necessary and sufficient conditions are that ")#mi("c_j(x^{\\prime}) \\geq 0")#text(" for all ")#mi("c_j")#text(", and that ")#mi("a_j(x^{\\prime}) \\leq b_k(x^{\\prime})")#text(" for all ")#mi("a_j")#text(" and ")#mi("b_k")#text(". If we can find an x’ obeying these inequalities, then we are in conclusion (1) and we are done. Otherwise, we apply the induction hypothesis and conclude that we can fashion -1 as a non-negative linear combination of the ")#mi("c_j(x^{\\prime})")#text(" and of the ")#mi("b_k(x^{\\prime}) - a_j(x^{\\prime})")#text(". But the ")#mi("b_k(x^{\\prime}) - a_j(x^{\\prime})")#text(" can in turn be expressed as a non-negative linear combination of ")#mi("t - a_j(x^{\\prime})")#text(" and ")#mi("b_k(x^{\\prime})-t")#text(", and so we are in conclusion (2) as desired.")

#text("Exercise: use Farkas’ lemma to derive the ")#link("http://en.wikipedia.org/wiki/Linear_programming#Duality")[#text("duality theorem in linear programming")]#text(".")

#heading(level: 1)[#text("— Applications —")]

#text("Now we connect the above lemma to results which are closer to the Hahn-Banach theorem in its traditional form. We begin with")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Separation theorem")]#text(". Let A, B be disjoint convex polytopes in ")#mi("{\\Bbb R}^d")#text(". Then there exists an affine-linear functional ")#mi("P: {\\Bbb R}^d \\to {\\Bbb R}")#text(" such that ")#mi("P(x) \\geq 1")#text(" for ")#mi("x\\in A")#text(" and ")#mi("P(x) \\leq -1")#text(" for ")#mi("x\\in B")#text(".")
]

#strong[#text("Proof")]#text(". We can view the system of inequalities ")#mi("P(x) - 1\\geq 0")#text(" for ")#mi("x \\in A")#text(" and ")#mi("-1-P(x) \\geq 0")#text(" for ")#mi("x \\in B")#text(" as a system of linear equations on P (or, if you wish, on the coefficients of P). If this system is solvable then we are done, so suppose the system is not solvable. Applying Farkas’ lemma, we conclude that there exists ")#mi("x_1,\\ldots,x_m \\in A")#text(" and ")#mi("y_1,\\ldots,y_n \\in B")#text(" and non-negative constants ")#mi("q_1,\\ldots,q_m, r_1,\\ldots,r_n")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^m q_i (P(x_i)-1) + \\sum_{j=1}^n r_j (-1-P(y_j)) = -1")]]

#text("for all P. Setting P to be an arbitrary constant, we conclude")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^m q_i = \\sum_{j=1}^n r_j = 1/2,")]]

#text("and so by the affine nature of P, we can rearrange the above identity as")

#align(center)[#tao-fit-display[#mitex("P(\\sum_{i=1}^m 2q_i x_i) = P( \\sum_{j=1}^n 2r_i y_j)")]]

#text("for all P; since affine functions separate points, we conclude that")

#align(center)[#mi("\\sum_{i=1}^m 2q_i x_i = \\sum_{j=1}^n 2r_i y_j")#text(".")]

#text("But by convexity the left-hand side is in A and the right-hand side in B, a contradiction. ")#mi("\\Box")#text(".")

#text("The above theorem asserts that any two disjoint convex polytopes can be separated by a hyperplane. One can establish more generally that any two disjoint convex bodies can be separated by a hyperplane; in particular, this implies that if a convex function always exceeds a concave function, then there is an affine linear function separating the two. From this it is a short step to the Hahn-Banach theorem, at least in the setting of finite-dimensional spaces; if one wants to find a linear functional ")#mi("\\lambda: {\\Bbb R}^n \\to {\\Bbb R}")#text(" which has prescribed values on some subspace W, and lies between some convex and concave sets (e.g. ")#tao-math("-\\left\\|x\\right\\| \\leq \\lambda(x) \\leq \\left\\|x\\right\\|", block: false)#text(" for some semi-norm ")#tao-math("\\left\\|x\\right\\|", block: false)#text("), then by quotienting out W we can reduce to the previous problem.")

#text("We turn now to the minimax theorem. Consider a zero-sum game between two players, Alice and Bob. Alice can pick any one of ")#mi("n")#text(" strategies using a probability distribution ")#mi("p = (p_1,\\ldots,p_n)")#text(" of her choosing; simultaneously, Bob can pick any one of m strategies using a probability distribution ")#mi("q = (q_1,\\ldots,q_m)")#text(" of his choosing. Alice’s expected payoff F then takes the form ")#mi("F(p,q) := \\sum_{i=1}^n \\sum_{j=1}^m c_{i,j} p_i q_j")#text(" for some fixed real coefficients ")#mi("c_{i,j}")#text("; Bob’s expected payoff in this zero-sum game is then ")#mi("-F(p,q)")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Minimax theorem")]#text(". Given any coefficients ")#mi("c_{i,j}")#text(", there exists a unique optimal payoff ")#mi("\\alpha")#text(" such that")

#enum(start: 1, 
[#text("(Alice can expect to win at least ")#mi("\\alpha")#text(") There exists an ")#emph[#text("optimal strategy")]#text(" ")#mi("p_*")#text(" for Alice such that ")#mi("F( p_*, q) \\geq \\alpha")#linebreak()#text(" for all q;")],
[#text("(Bob can expect to lose at most ")#mi("\\alpha")#text(") There exists an ")#emph[#text("optimal strategy")]#text(" ")#mi("q_*")#text(" for Bob such that ")#mi("F(p,q_*) \\leq \\alpha")#text(" for all p.")]
)
]

#strong[#text("Proof")]#text(". By playing Alice’s optimal strategy off against Bob’s, we see that the supremum of the set of ")#mi("\\alpha")#text(" which obeys (1) is clearly finite, and less than or equal to the infimum of the set of ")#mi("\\alpha")#text(" which obey (2), which is also finite. To finish the proof, it suffices to show that these two numbers are equal. If they were not equal, then we could find an ")#mi("\\alpha")#text(" for which ")#emph[#text("neither")]#text(" of (1) and (2) were true.")

#text("If (1) could not be satisfied, this means that the system of linear equations")

#align(center)[#tao-fit-display[#mitex("p_1,\\ldots,p_n \\geq 0; p_1+\\ldots+p_n \\leq 1; F(p,q) \\geq \\alpha \\text{ for all } q")]]

#text("has no solution. From the convexity of F(p,q) in q, we can replace this system with")

#align(center)[#mi("p_1,\\ldots,p_n \\geq 0; p_1+\\ldots+p_n \\leq 1; \\sum_{i=1}^n c_{i,j} p_i \\geq \\alpha \\text{ for all } j")#text(".")]

#text("Applying Farkas’ lemma, we conclude that some non-negative combination of ")#mi("p_1,\\ldots,p_n")#text(", ")#mi("1-p_1-\\ldots-p_n")#text(", and ")#mi("\\sum_{i=1}^n c_{i,j} p_i - \\alpha")#text(" for ")#mi("1 \\leq j \\leq m")#text(" are identically -1. A little bit of algebra shows that there must therefore exist a strategy q for Bob such that -1 can be expressed as a non-negative combination of ")#mi("p_1,\\ldots,p_n")#text(", ")#mi("1-p_1-\\ldots-p_n")#text(", and ")#mi("F(p,q)-\\alpha")#text(". In particular, ")#mi("F(p,q)-\\alpha")#text(" must be negative for all strategies p for Alice, and so (2) is true, a contradiction. ")#mi("\\Box")#text(".")

#text("The minimax theorem can be used to give game-theoretic proofs of various theorems of Hahn-Banach type. Here is one example:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Menger’s theorem")]#text(". Let G be a directed graph, and let v and w be non-adjacent vertices in G. Then the maxflow from v to w in G (the largest number of disjoint paths one can find in G from v to w) is equal to the min-cut (the least number of vertices (other than v or w) one needs to delete from G to disconnect v from w).")
]

#text("The proof we give here is definitely not the shortest proof of Menger’s theorem, but it does illustrate how game-theoretic techniques can be used to prove combinatorial theorems.")

#strong[#text("Proof")]#text(". Consider the following game. Bob picks a path from v to w, and Alice picks a vertex (other than v or w). If Bob’s path hits Alice’s vertex, then Alice wins 1 (and Bob wins -1); otherwise Alice wins 0 (and Bob wins 0 as well). Let ")#mi("\\alpha")#text(" be Alice’s optimal payoff. Observe that we can prove ")#mi("\\alpha \\leq 1/maxflow")#text(" by letting Bob picks one of some maximal collection of disjoint paths from v to w at random as his strategy; conversely, we can prove ")#mi("\\alpha \\geq 1/mincut")#text(" by letting Alice pick a vertex from some minimal cut set at random as her strategy. To finish the proof we need to show that in fact ")#mi("1/\\alpha \\geq mincut")#text(" and ")#mi("1/\\alpha \\leq maxflow")#text(".")

#text("Let’s first show that ")#mi("1/\\alpha \\geq mincut")#text(". Let’s assume that Alice and Bob are both playing optimal strategies, to get the optimal payoff ")#mi("\\alpha")#text(" for Alice. Then it is not hard to use the optimality to show that every path that Bob might play must be hit by Alice with probability exactly ")#mi("\\alpha")#text(" (and any other path will be hit by Alice with probability at least ")#mi("\\alpha")#text("), and conversely every vertex that Alice might pick will be hit by Bob with probability ")#mi("\\alpha")#text(" (and any other vertex will be hit by Bob with probability at most ")#mi("\\alpha")#text(").")

#text("Now suppose that two of Bob’s paths intersect at some intermediate vertex u. One can show that the two resulting sub-paths from v to u must have an equal chance of being hit by Alice, otherwise by swapping those two sub-paths one can create a path which Alice hits with probability strictly less than ")#mi("\\alpha")#text(", a contradiction. Similarly, the two sub-paths from u to w must have equal chance of being hit by Alice.")

#text("Now consider all the vertices u that Alice can pick for which there exists a path of Bob which hits u before it hits any other vertex of Alice. Let U be the set of such u. Every path from v to w must hit U, because if it is possible to avoid U and instead hit another vertex of Alice, it will again be possible to crate a path that Alice hits with probability strictly less than ")#mi("\\alpha")#text(", by the above discussion. Thus, U is a cut set. Any given path of Bob hits exactly one vertex in U (again by the above discussion). Since each u in U has a probability ")#mi("\\alpha")#text(" of being hit by Bob, we thus see that this cut set has size exactly ")#mi("1/\\alpha")#text(". Thus ")#mi("1/\\alpha \\geq mincut")#text(" as desired.")

#text("Now we show that ")#mi("1/\\alpha \\leq maxflow")#text(". Define an ")#emph[#mi("\\alpha")#text("-flow")]#text(" to be a collection of non-negative weights on the directed edges of G such that")

#enum(start: 1, 
[#text("the net flow at v (the total inflow minus total outflow) is -1, and the net flow at w is +1;")],
[#text("for any other vertex u, the net flow at u is zero, and total inflow or outflow at u is at most ")#mi("\\alpha")#text(".")]
)

#text("We first observe that at least one ")#mi("\\alpha")#text("-flow exists. Indeed, if we pick one of Bob’s optimal strategies, and weight each edge by the probability that Bob’s path passes through that edge, one easily verifies that this gives a ")#mi("\\alpha")#text("-flow.")

#text("Given an ")#mi("\\alpha")#text("-flow, consider the directed graph G consisting of directed edges on which the weight of the ")#mi("\\alpha")#text("-flow is strictly between 0 and ")#mi("\\alpha")#text(". Observe that if an edge in G terminates at a vertex with net inflow less than ")#mi("\\alpha")#text(", then there must be a edge in G exiting this vertex also; conversely, if an edge in G terminates at a vertex with net inflow at least ")#mi("\\alpha")#text(", then there must be another edge in G coming into this vertex also. Similarly, if an edge in G originates in a vertex with net outflow less than ")#mi("\\alpha")#text(", there must be an edge in G entering this vertex; and if it originates in a vertex with net outflow at least ")#mi("\\alpha")#text(", then there must be another edge in G exiting this vertex. Thus, if G is not empty, then one can chase an edge backwards and forwards and end up with a simple oriented cycle consisting of edges in G and reversals of edges in G, such that at any vertex with net inflow at least ")#mi("\\alpha")#text(", every edge in G entering this vertex in the cycle is immediately followed by a reversed edge in G exiting the vertex, and similarly at any vertex with net outflow at least ")#mi("\\alpha")#text(", every reversed edge in G entering the vertex is immediately followed by an edge in G exiting the vertex. Given such a cycle, then one can modify the ")#mi("\\alpha")#text("-flow on this cycle by an epsilon, increasing the flow weight by ")#mi("\\epsilon")#text(" on edges on the cycle that go with the flow, and reducing them by the same ")#mi("\\epsilon")#text(" on edges that go against the flow; note that this preserves the property of being an ")#mi("\\alpha")#text("-flow. Increasing ")#mi("\\epsilon")#text(", we eventually reduce one of the weights to zero, thus reducing the number of edges on which the flow is supported. We can repeat this procedure indefinitely until one arrives at an ")#mi("\\alpha")#text("-flow whose graph G is empty, thus every edge has weight either zero or ")#mi("\\alpha")#text(". Now, as v has outflow at least +1 and every vertex adjacent to v can have inflow at most ")#mi("\\alpha")#text(" (recall that v is not adjacent to w), the flow must propagate from v to at least ")#mi("1/\\alpha")#text(" other vertices. Each of these vertices must eventually flow to w (which is the only vertex with positive flow) by at least one path; by the above discussion, these paths need to be disjoint. Thus we have ")#mi("1/\\alpha \\leq maxflow")#text(" as desired. ")#mi("\\Box")#text(".")

#text("The above argument can also be generalised to prove the ")#link("http://en.wikipedia.org/wiki/Max-flow_min-cut_theorem")[#text("max-flow min-cut theorem")]#text(", but we will not do so here.")

#text("Exercise: use Menger’s theorem to prove ")#link("http://en.wikipedia.org/wiki/Hall%27s_marriage_theorem")[#text("Hall’s marriage theorem")]#text(".")

#text("Now we turn to ")#link("http://en.wikipedia.org/wiki/Helly%27s_theorem")[#text("Helly’s theorem")]#text(". One formulation of this theorem is the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Helly’s theorem")]#text(". Let ")#mi("B_1,\\ldots,B_m")#text(" be a collection of convex bodies in ")#mi("{\\Bbb R}^d")#text(" with ")#mi("m > d")#text(". If every d+1 of these convex bodies have a point in common, then all m of these convex bodies have a point in common.")
]

#text("The reader is invited to verify Helly’s theorem in the ")#mi("d=1")#text(" case, to get a flavour as to what is going on.")

#text("For simplicity we shall just consider the case when each of the ")#mi("B_1,\\ldots,B_m")#text(" are convex polytopes.")

#strong[#text("Proof")]#text(". A convex polytope is the intersection of finitely many half-spaces. From this, one quickly sees that to prove Helly’s theorem for convex polytopes, it suffices to do so for half-spaces. Each half-space can be expressed as the form ")#mi("\\{ x: P(x) \\geq c \\}")#text(" for some linear functional ")#mi("P: {\\Bbb R}^n \\to {\\Bbb R}")#text(" and ")#mi("c \\in {\\Bbb R}")#text(". Note that by duality, one can view ")#mi("(P,c)")#text(" as living in an d+1-dimensional vector space ")#mi("({\\Bbb R}^d)^* \\times {\\Bbb R}")#text(".")

#text("Let say that there are m half-spaces involved, and let ")#mi("(P_1,c_1),\\ldots, (P_m,c_m)")#text(" be the corresponding linear functionals. It suffices to show that if the system ")#mi("P_1(x) \\geq c_1,\\ldots,P_m(x) \\geq c_m")#text(" has no solution, then there is some sub-collection ")#mi("P_{i_1},\\ldots,P_{i_j}")#text(" with ")#mi("j \\leq d+1")#text(" such that ")#mi("P_{i_1}(x) \\geq c_{i_1},\\ldots,P_{i_j}(x) \\geq c_{i_j}")#text(" also has no solution.")

#text("By Farkas’ lemma, we know that the system ")#mi("P_1(x) \\geq c_1,\\ldots,P_m(x) \\geq c_m")#text(" has no solution if and only if (0,-1) is a convex combination of the ")#mi("(P_1,c_1),\\ldots,(P_m,c_m)")#text(". So everything reduces to establishing")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Dual Helly theorem")]#text(". Suppose that a vector v in a d+1-dimensional space can be expressed as a non-negative linear combination of a collection of vectors ")#mi("v_1,\\ldots,v_m")#text(". Then v is also a non-negative combination of at most d+1 vectors from that collection.")
]

#text("To prove this theorem, we use an argument a little reminiscent to that used to prove ")#mi("1/\\alpha \\leq maxflow")#text(" in the proof of Menger’s theorem. Suppose we can express v as a convex combination of some of the ")#mi("v_i")#text(". If at most d+1 of the vectors have non-zero coefficients attached to them then we are done. Now suppose instead that at least ")#mi("d+2")#text(" vectors have non-zero coefficients, say ")#mi("v_1,\\ldots,v_{d+2}")#text(" have non-zero coefficients. Then there is a linear dependency among these vectors, which allows us to find coefficients ")#mi("c_1,\\ldots,c_{d+2}")#text(", not all zero, such that ")#mi("c_1 v_1 + \\ldots + c_{d+2} v_{d+2} = 0")#text(". We can then perturb our preceding non-negative combination by an epsilon multiple of this equation to obtain a new representation of 0 as a non-negative combination of vectors. If we increase epsilon, we must eventually send one of the coefficients to zero, decreasing the total number of vectors with non-zero coefficients. Iterating this procedure we eventually obtain the dual Helly theorem and hence the original version of Helly’s theorem.")#mi("\\Box")

#text("[")#emph[#text("Update")]#text(", Apr 30: Proof of Helly’s theorem fixed.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (27)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Francois")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-18237")[#strong[#text("Francois")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2007")])]

#text("Thank you for this expository note.")

#text("You might be interested in the following discrete variant of Farkas’ Lemma, where inequalities of the type “")#mi("\\ge 0")#text("” are replaced by “is an integer”:")

#text("Let ")#mi("A")#text(" a full row-rank integer matrix and ")#mi("b")#text(" an integer vector.")#linebreak()#text(" Exactly one of the following two systems has solutions:")#linebreak()#text(" 1. ")#mi("Ax=b")#text(" and ")#mi("x")#text(" is an integer vector")#linebreak()#text(" 2. ")#mi("A^T y")#text(" is an integer vector and ")#mi("b^T y")#text(" is not integer")

#text("(the continuous Farkas Lemma you described being equivalent to")#linebreak()#text(" Exactly one of the following two systems has solutions:")#linebreak()#text(" 1. ")#mi("Ax=b")#text(" and ")#mi("x")#text(" is ")#mi("\\ge 0")#linebreak()#text(" 2. ")#mi("A^T y")#text(" is ")#mi("\\ge 0")#text(" and ")#mi("b^T y")#text(" is not ")#mi("\\ge 0")#text(" )")

#text("I wonder to which other sets (besides ")#mi("\\mathbb{R}_+")#text(" and ")#mi("\\mathbb{Z}")#text(" this can be generalized.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-18458")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2007")])]

#text("a doubt about the induction in the proof of hahn-banach:")

#text("you had written:")#linebreak()#text(" “If we can find an x’ obeying these inequalities, then we are in conclusion (1) and we are done. Otherwise, we apply the induction hypothesis and conclude that we can fashion -1 as a non-negative linear combination of the c_j(x’) and of the b_k(x’) – a_j(x’). But the b_k(x’) – a_j(x’) can in turn be expressed as a non-negative linear combination of t – a_j(x’) and b_k(x’)-t, and so we are in conclusion (2) as desired.”")

#text("But in the application of the induction hypothesis, each x’ may use a different linear combination of the c_j(x’) and b_k(x’)- a_j(x’) to get -1. what we want")#linebreak()#text(" is a linear combination of the formal linear polynomials c_j(X) and b_k(X) -a_j(X) to get -1 as formal linear polynomials (where X is an indeterminate).")#linebreak()#text(" Is this right?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-18727")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2007")])]

#text("Dear Francois: Thank you for pointing out the integer version of the Farkas lemma, which I was not aware of. It seems like one could adapt the proof in my post (i.e. induct on dimension, using a careful analysis of the one-dimensional case) to establish this version also, although the one-dimensional analysis is somewhat different (in particular, it seems to use the Chinese remainder theorem). I don’t know how general the phenomenon is, but one obvious thing to do is to replace the integers by other integral domains, e.g. the ring of terminating base p decimals for some fixed p.")

#text("Dear Anonymous: We only apply the induction hypothesis once. If we are not in the first case (in which there exists at least one x’ obeying the inequalities ")#mi("c_j(x^{\\prime}) \\geq 0")#text(" and ")#mi("a_j(x^{\\prime}) \\leq b_k(x^{\\prime})")#text("), then there do not exist any x’ which obey these inequalities. The induction hypothesis then asserts that there must be a single non-negative linear combination of the affine-linear forms ")#mi("c_j")#text(" and ")#mi("b_k - a_j")#text(" which sum to -1 (for any value of x’).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e4439687c17407ed3decdd294711e75be80dd977af548a6d78528a449c5fcc2-4816b806a4d9e668868d67b962f977f8e7614d41068f303b8bc9daa7949aeb47.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthias Aschenbrenner")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-18985")[#strong[#text("Matthias Aschenbrenner")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2007")])]

#text("Generalizations of Farkas’ Lemma to other kinds of systems of (in-) equalities have been recently considered by Philip Scowcroft, Nonnegative solvability of linear equations in certain ordered rings, Trans. Amer. Math. Soc. 358 (2006), no. 8, 3535–3570, MR2218988 (2007k:03102). For example, he gives a Farkas-type condition of the existence of a non-negative integer solution x\\in N^n to a system Ax=b where A, b have integer entries; also, for solutions in dense subrings of the reals, etc.")

#text("The equivalence between an existential statement (“there exists a solution …”) and a universal statement (“for all non-negative reals …”) as in your statement of Farkas’ Lemma hints, for a model-theorist, at the presence of a general quantifier-elimination result lurking in the background. (In this case, this is the quantifier elimination for the theory of ordered R-linear spaces, a.k.a. “extended Fourier-Motzkin elimination”.)")

#text("The integer version of Farkas’ Lemma mentioned by Francois is due to Kronecker (1884). One can also prove a “mixed real-integer” version by requiring only some of the coordinates in the solution to be integer. (Again, this can be deduced from a more general elimination result.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-19172")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2007")])]

#text("Dear Matthias,")

#text("Thanks for the references (and a belated welcome to UCLA)!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arseny Akopyan")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-29441")[#strong[#text("Arseny Akopyan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2008")])]

#text("Dear Terry,")#linebreak()#text(" I do not understand the proof of the Helly theorem. Why may we suppose that half-spaces do not contain the origin? Say, if two of them are {x_n>-1} and {x_n<1}, then any point is contained in at least one of these two.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-29443")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2008")])]

#text("Hmm, you’re right; one can’t normalise all the coefficients to equal 1. Fortunately, the proof can be modified to handle this case; I’ve made the appropriate corrections. (And I should adjust the version in the book as well…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-32065")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2008")])]

#text("“Now we show that ")#mi("\\alpha \\leq maxflow")#text("” Don’t you mean ")#mi("1/\\alpha \\leq maxflow")#text(" ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-32073")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2008")])]

#text("Dear Sune: Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Anonymous")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-32771")[#strong[#text("The Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2008")])]

#text("Does anybody know of a simple, “pivoting-type” algorithm allowing one to determine whether the system of linear inequalities ")#mi("P_1(x),...,P_m(x) \\ge 0")#text(" has a solution? Of course, one can reduce this system to one which is considered standard, but this requires more variables and inequalities to be brought into consideration; besides, the above system looks simpler and more appealing than the “standard” one, hence one can expect a nicer algorithm for handing it to exist.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 6: Duality and the Hahn-Banach theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-35271")[#strong[#text("245B, Notes 6: Duality and the Hahn-Banach theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2009")])]

#text("[…] of variants of the Hahn-Banach theorem (in the finite-dimensional setting) can be found at this blog post of mine. Possibly related posts: (automatically generated)Dual SpacesBasic Theory of Banach […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-39101")[#strong[#text("Structure and Randomness: Pages from Year One of a Mathematical Blog « Abner’s Postgraduate Days")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2009")]

#text("[…] The Hahn-Banach theorem, Menger’s theorem, and Helly’s theorem The Hahn-Banach theorem is a theorem in mathematical analysis. The definition on wikipedia is too abstract for me to image what the usage of this ‘tool’ is, however, this article in fact discuss the famous lemma — Farkas’ lemma which is sometimes known as Hahn-Banach theorem. (T. Tao said that) Farkas’ lemma. Let be affine-linear functionals. Then exactly one of the following statements holds: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-39251")[#strong[#text("Predavanje RAG.4 → (poglavje 1) « igor’s math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2009")]

#text("[…] lema, separacija konveksnih množic, Hilbertov Nullstellensatz. Izhodišče tega razdelka je bil prispevek T. Tao (UCLA), kjer je predstavil zanimiv dokaz Farkaseve leme s pomočjo indukcije. Na […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Lecture Notes 7: The transference principle, and linear equations in primes « What’s new")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-45347")[#strong[#text("254B, Lecture Notes 7: The transference principle, and linear equations in primes « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2010")])]

#text("[…] theorem is applicable. (One could also use closely related results, such as the Farkas lemma: see this earlier blog post for more discussion.) Indeed, suppose that there was some for which and were disjoint. Then, by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The uncertainty principle « What’s new")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-45720")[#strong[#text("The uncertainty principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2010")])]

#text("[…] Convex duality More generally, a (closed, bounded) convex body in a vector space can be described either by listing a set of (extreme) points whose convex hull is , or else by listing a set of (irreducible) linear inequalities that cut out . The fundamental connection between the two is given by the Farkas lemma. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jay")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-108864")[#strong[#text("Jay")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2011")])]

#text("Dear Terence!")#linebreak()#text(" Could you please elaborate a little more on the proof of Helly’s theorem. Unfortunately for me it wasn’t obvious what’s the dual problem? According to the definition of Linear Programming, which objective function should be used? And please, few more words as conclusion why exactly the theorem is right.")#linebreak()#text(" Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5d712ad6f5a78a749b10dcdbda5168b68f6d5ff12e664d7855e70552b1c0a71-59b6006e9bb2847d088bda33144700abbac588df66fab6affdfe638646317ddf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Shamov")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-192423")[#strong[#text("Alexander Shamov")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2012")])]

#text("Dear Prof. Tao,")

#text("It seems that in your proof of Farkas’ lemma we obtain a linear combination for every fixed ")#mi("x^\\prime")#text(", so that ")#mi("-1 = \\sum_i q_i(x^\\prime) P_i(x)")#text(", where ")#mi("q_i")#text("‘s depend on ")#mi("x^\\prime")#text(" in a way that we do not control, whereas we want them to be constant…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-192441")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2012")])]

#text("When we apply the induction hypothesis to the system ")#mi("c_j(x^{\\prime}) \\geq 0")#text(", ")#mi("a_j(x^{\\prime}) \\leq b_j(x^{\\prime})")#text(", the coefficients ")#mi("q_i")#text(" generated by conclusion 2 of Farkas’s lemma applied in dimension d-1 do not depend on the underlying variables ")#mi("x^{\\prime}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5d712ad6f5a78a749b10dcdbda5168b68f6d5ff12e664d7855e70552b1c0a71-59b6006e9bb2847d088bda33144700abbac588df66fab6affdfe638646317ddf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Shamov")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-192443")[#strong[#text("Alexander Shamov")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2012")])]

#text("Ah, I see, thank you.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27781d5f9f1cf309d2c329dbf6557cd2df23148c92092930998ea479fa2916d7-cac8d40de9451c0568a412d2bbe715c9180e9857e2bedf8ffaea49ab3538a06c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HUMBERTO")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-192447")[#strong[#text("HUMBERTO")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2012")])]

#text("ES INTERESANTE LA FORMA COMO SE INTERACTUA CON EL CONOCIMIENTO Y SOBRE TODO EN ESTE CAMPO DE LA MATEMÁTICAS")#linebreak()#text(" MI PREGUNTA ES")#linebreak()#text(" ¿ SE RESTRINGE ESTE TIPO DE ANÁLISIS O EXTENSIÓN EN LA TEORÍA DE REPRESENTACIÓN DE CONJUNTOS PARCIALMENTE ORDENADOS EN EL CASO DE POSET CRÍTICOS ( KLEINER O NAZAROVA) O SE GENERA UN PUENTE NETAMENTE ALGEBRAICO?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 4: Some sieve theory | What's new")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-452120")[#strong[#text("254A, Notes 4: Some sieve theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2015")])]

#text("[…] theorem; one can also proceed using one of the other duality results mentioned above. (See this previous blog post for some discussion of the connections between these various forms of linear duality.) Consider the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a7dbf0fc4f87d9dd7d9265b8d742254449560def99ea67f4a0bdffbedeff30-6357b353d4083e451e5adfb16009055f7689e1058db5dc6c29d9cb3641abf55b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Baez")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-492902")[#strong[#text("John Baez")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2018")])]

#text("“Alice can pick any one of $n$ strategies.”")

#text("You need one of those darn “latex” commands here.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6bee38a54cd2271be89034454fa2ba8ff424bf6591e45bc91dda1f9cac5fa17-8f4d488bc24daa25daf62c14b64c16d6318202346fc3b9765214d6fd1010b1f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Shakan")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-514148")[#strong[#text("George Shakan")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2019")])]

#text("I am curious what intuitive crutches you use for thinking of high dimensional problems involving convexity. You do have a nice post on math overflow outlining some ideas for thinking in high dimensions in general..but the only example from that post that I can see to have a natural interpretation in terms of convexity is the two-player game.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-514200")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2019")])]

#text("I’ve actually asked other people (such as Keith Ball) about this, since I do not have much native experience with high-dimensional convex bodies. But the viewpoint of Vitali Milman that was pointed out by Gil Kalai in the same math overflow post ( ")#link("https://mathoverflow.net/a/26010/766")[#text("https://mathoverflow.net/a/26010/766")]#text(" ) is, I think, a good one: convex bodies in high dimensions are largely ellipsoidal but also can contain a number of “spikes” that are small in volume but which can protrude well beyond the main ellipsoid of the convex body. Foundational results in high dimensional convex geometry such as Dvoretsky’s theorem, the Bourgain-Tzafriri theorem, or the Johnson-Lindenstrauss lemma are broadly in line with this intuitive picture. (For low dimensions one has instead John’s ellipsoid theorem, which basically says that one just has the ellipsoid and no spikes.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84c064e9efeb690acfc65ef15f1d58ff7bca05d6dc715dfdb59a6345116e947b-b90fdec528a0d8d66af1d0a172e6fe9a3fc26d0d1cdd7838ecfe4c21c4beb4e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Bob")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-602322")[#strong[#text("Peter Bob")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2020")])]

#text("“Then it is not hard to use the optimality to show that every path that Bob might play must be hit by Alice with probability exactly \\alpha”")

#text("Would anybody be able to give a hint as to why this is true?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-602763")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2020")])]

#text("Oops, there was a typo in this paragraph; it is assumed that Alice and Bob are both playing optimal strategies (not just Alice). Since Alice is guaranteed a payoff of ")#mi("\\alpha")#text(" no matter what strategy Bob plays, every possible path has to be hit with probability at least ")#mi("\\alpha")#text("; but the optimal strategy that Bob actually is playing gives a payoff of exactly ")#mi("\\alpha")#text(", so all the paths that Bob uses also has to be hit with probability exactly ")#mi("\\alpha")#text(" (otherwise if one of these paths was hit with a larger probability, the payoff would be strictly larger than ")#mi("\\alpha")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/11/30/the-hahn-banach-theorem-mengers-theorem-and-hellys-theorem/#comment-603045")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2020")])]

#text("I see. Thank you very much for the answers and the exposition. The game-theoretic proof of Menger’s theorem is fascinating.")
]
]
]
