// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/27/the-quasi-riemann-hypothesis/
// Converted to Typst by tao2typ: "2026-11-28T15:43:34.424820+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The quasi-Riemann hypothesis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The quasi-Riemann hypothesis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/27/the-quasi-riemann-hypothesis/")[#text("https://terrytao.wordpress.com/2026/10/27/the-quasi-riemann-hypothesis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-28 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a short note that Maksym Radziwill will be ")#link("https://math.nyu.edu/dynamic/calendars/seminars/mathematics-in-the-age-of-ai/4570/")[#text("giving a hybrid talk on the quasi-Riemann hypothesis at Courant tomorrow")]#text(".")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43c6e8a8da64cd8d8330e0a17b568edb712ad8e78efffeac790325f83615fb0a-4dfb49c86896fc83cb3dd6340ed6fef67136274d82d04398453780f35237e326.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Fine")]], [#link("https://terrytao.wordpress.com/2026/10/27/the-quasi-riemann-hypothesis/#comment-698880")[#strong[#text("Jonathan Fine")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("This Thursday at 11am New York time there’s ")#link("https://www.ntwebseminar.org/home#h.1vxtfyrhx8")[#text("a talk on the same topic by Valentin Bloomer")]#text(".")

#text("I found it via ")#link("https://researchseminars.org/")[#text("https://researchseminars.org/")]#text(" (which sadly does not list Radziwill’s talk).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43c6e8a8da64cd8d8330e0a17b568edb712ad8e78efffeac790325f83615fb0a-4dfb49c86896fc83cb3dd6340ed6fef67136274d82d04398453780f35237e326.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Fine")]], [#link("https://terrytao.wordpress.com/2026/10/27/the-quasi-riemann-hypothesis/#comment-698900")[#strong[#text("Jonathan Fine")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("My mistake. Bloomer’s talk is Thursday 5 November (and not tomorrow). Apologies.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/27/the-quasi-riemann-hypothesis/#comment-698936")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2026")])]

#text("Is the talk posted online somewhere?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef56db71d958f5047139912a0c9b31b770236c367cfa407466708f3d3ed9626e-8536151e32c141f00c22d3db8a7c045b3e045c1ab1cdb6157c04c755d0e6b6c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nestor")]], [#link("https://terrytao.wordpress.com/2026/10/27/the-quasi-riemann-hypothesis/#comment-699067")[#strong[#text("Nestor")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("PSA Maksym’s talk is now posted on Courant’s Youtube channel:")

#link("https://www.youtube.com/watch?v=kYCOOyYkit8")[#text("https://www.youtube.com/watch?v=kYCOOyYkit8")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/27/the-quasi-riemann-hypothesis/#comment-699073")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("CC is entertaining. “Oiler and Obvious functions” (Euler and Mobius)")
]
]
