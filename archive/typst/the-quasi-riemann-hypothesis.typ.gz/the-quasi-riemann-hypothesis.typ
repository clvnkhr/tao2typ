// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/27/the-quasi-riemann-hypothesis/
// Converted to Typst by tao2typ: "2026-10-30T13:14:33.771833+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The quasi-Riemann hypothesis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The quasi-Riemann hypothesis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/27/the-quasi-riemann-hypothesis/")[#text("https://terrytao.wordpress.com/2026/10/27/the-quasi-riemann-hypothesis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-30 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a short note that Maksym Radziwill will be ")#link("https://math.nyu.edu/dynamic/calendars/seminars/mathematics-in-the-age-of-ai/4570/")[#text("giving a hybrid talk on the quasi-Riemann hypothesis at Courant tomorrow")]#text(".")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69c936effe32b1c8f4c15a3f2a2c57c6363ddb9a69cfb7465ec67d59d44b9075-aa9f83fb5941ebfa2af356976e7af2279952d390d20bc802c63fbc9d106cab40.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Fine")]], [#link("https://terrytao.wordpress.com/2026/10/27/the-quasi-riemann-hypothesis/comment-page-1/#comment-698880")[#strong[#text("Jonathan Fine")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("This Thursday at 11am New York time there’s ")#link("https://www.ntwebseminar.org/home#h.1vxtfyrhx8")[#text("a talk on the same topic by Valentin Bloomer")]#text(".")

#text("I found it via ")#link("https://researchseminars.org/")[#text("https://researchseminars.org/")]#text(" (which sadly does not list Radziwill’s talk).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69c936effe32b1c8f4c15a3f2a2c57c6363ddb9a69cfb7465ec67d59d44b9075-aa9f83fb5941ebfa2af356976e7af2279952d390d20bc802c63fbc9d106cab40.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Fine")]], [#link("https://terrytao.wordpress.com/2026/10/27/the-quasi-riemann-hypothesis/comment-page-1/#comment-698900")[#strong[#text("Jonathan Fine")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("My mistake. Bloomer’s talk is Thursday 5 November (and not tomorrow). Apologies.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/27/the-quasi-riemann-hypothesis/comment-page-1/#comment-698936")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2026")])]

#text("Is the talk posted online somewhere?")
]
