// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/
// Converted to Typst by tao2typ: "2026-10-14T15:17:02.142100+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245B, Notes 9: The Baire category theorem and its Banach space consequences", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245B, Notes 9: The Baire category theorem and its Banach space consequences")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 February 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/")[#text("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("The notion of what it means for a subset E of a space X to be “small” varies from context to context. For instance, in measure theory, when ")#mi("X = (X, {\\mathcal X}, \\mu)")#text(" is a measure space, one useful notion of a “small” set is that of a null set: a set E of measure zero (or at least contained in a set of measure zero). By countable additivity, countable unions of null sets are null. Taking contrapositives, we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1. ")]#text("(Pigeonhole principle for measure spaces) Let ")#mi("E_1, E_2, \\ldots")#text(" be an at most countable sequence of measurable subsets of a measure space X. If ")#mi("\\bigcup_n E_n")#text(" has positive measure, then at least one of the ")#mi("E_n")#text(" has positive measure.")
]

#text("Now suppose that X was a Euclidean space ")#mi("{\\Bbb R}^d")#text(" with Lebesgue measure m. The ")#link("http://en.wikipedia.org/wiki/Lebesgue_differentiation_theorem")[#text("Lebesgue differentiation theorem")]#text(" easily implies that having positive measure is equivalent to being “dense” in certain balls:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" Let ")#mi("E")#text(" be a measurable subset of ")#mi("{\\Bbb R}^d")#text(". Then the following are equivalent:")

#enum(start: 1, 
[#text("E has positive measure.")],
[#text("For any ")#mi("\\varepsilon > 0")#text(", there exists a ball B such that ")#mi("m( E \\cap B ) \\geq (1-\\varepsilon) m(B)")#text(".")]
)
]

#text("Thus one can think of a null set as a set which is “nowhere dense” in some measure-theoretic sense.")

#text("It turns out that there are analogues of these results when the measure space ")#mi("X = (X, {\\mathcal X}, \\mu)")#text(" is replaced instead by a ")#link("http://en.wikipedia.org/wiki/Complete_metric_space")[#text("complete metric space")]#text(" ")#mi("X = (X,d)")#text(". Here, the appropriate notion of a “small” set is not a null set, but rather that of a ")#link("http://en.wikipedia.org/wiki/Nowhere_dense_set")[#text("nowhere dense set")]#text(": a set E which is not ")#link("http://en.wikipedia.org/wiki/Dense_set")[#text("dense")]#text(" in any ball, or equivalently a set whose closure has empty interior. (A good example of a nowhere dense set would be a proper subspace, or smooth submanifold, of ")#mi("{\\Bbb R}^d")#text(", or a Cantor set; on the other hand, the rationals are a dense subset of ")#mi("{\\Bbb R}")#text(" and thus clearly not nowhere dense.) We then have the following important result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (")#link("http://en.wikipedia.org/wiki/Baire_category_theorem")[#text("Baire category theorem")]#text("). Let ")#mi("E_1, E_2, \\ldots")#text(" be an at most countable sequence of subsets of a complete metric space X. If ")#mi("\\bigcup_n E_n")#text(" contains a ball B, then at least one of the ")#mi("E_n")#text(" is dense in a sub-ball B’ of B (and in particular is not nowhere dense). To put it in the contrapositive: the countable union of nowhere dense sets cannot contain a ball.")
]

#strong[#text("Exercise 1.")]#text(" Show that the Baire category theorem is equivalent to the claim that in a complete metric space, the countable intersection of open dense sets remain dense. ")#mi("\\diamond")

#strong[#text("Exercise 2. ")]#text("Using the Baire category theorem, show that any non-empty complete metric space without isolated points is uncountable. (In particular, this shows that Baire category theorem can fail for incomplete metric spaces such as the rationals ")#mi("{\\Bbb Q}")#text(".) ")#mi("\\diamond")

#text("To quickly illustrate an application of the Baire category theorem, observe that it implies that one cannot cover a finite-dimensional real or complex vector space ")#mi("{\\Bbb R}^n, {\\Bbb C}^n")#text(" by a countable number of proper subspaces. One can of course also establish this fact by using Lebesgue measure on this space. However, the advantage of the Baire category approach is that it also works well in infinite dimensional complete normed vector spaces, i.e. ")#link("http://en.wikipedia.org/wiki/Banach_space")[#text("Banach spaces")]#text(", whereas the measure-theoretic approach runs into significant difficulties in infinite dimensions. This leads to three fundamental equivalences between the ")#emph[#text("qualitative")]#text(" theory of continuous linear operators on Banach spaces (e.g. finiteness, surjectivity, etc.) to the ")#emph[#text("quantitative")]#text(" theory (i.e. estimates):")

#enum(start: 1, 
[#text("The ")#link("http://en.wikipedia.org/wiki/Uniform_boundedness_principle")[#text("uniform boundedness principle")]#text(", that equates the qualitative boundedness (or convergence) of a family of continuous operators with their quantitative boundedness.")],
[#text("The ")#link("http://en.wikipedia.org/wiki/Open_mapping_theorem_(functional_analysis)")[#text("open mapping theorem")]#text(", that equates the qualitative solvability of a linear problem Lu = f with the quantitative solvability.")],
[#text("The ")#link("http://en.wikipedia.org/wiki/Closed_graph_theorem")[#text("closed graph theorem")]#text(", that equates the qualitative regularity of a (weakly continuous) operator T with the quantitative regularity of that operator.")]
)

#text("Strictly speaking, these theorems are not used much directly in practice, because one usually works in the reverse direction (i.e. first proving quantitative bounds, and then deriving qualitative corollaries); but the above three theorems help explain ")#emph[#text("why")]#text(" we usually approach qualitative problems in functional analysis via their quantitative counterparts.")

#heading(level: 1)[#metadata(none) <tao-3cfd1a2599ec629da389>#text("— Proof of Baire category theorem —")]

#text("Assume that the Baire category theorem failed; then it would be possible to cover a ball ")#mi("B(x_0,r_0)")#text(" in a complete metric space by a countable family ")#mi("E_1, E_2, E_3, \\ldots")#text(" of nowhere dense sets.")

#text("We now invoke the following easy observation: if E is nowhere dense, then every ball B contains a subball B’ which is disjoint from E. Indeed, this follows immediately from the definition of a nowhere dense set.")

#text("Invoking this observation, we can find a ball ")#mi("B(x_1,r_1)")#text(" in ")#mi("B(x_0,r_0/10)")#text(" (say) which is disjoint from ")#mi("E_1")#text("; we may also assume that ")#mi("r_1 \\leq r_0/10")#text(" by shrinking ")#mi("r_1")#text(" as necessary. Then, inside ")#mi("B(x_1,r_1/10)")#text(", we can find a ball ")#mi("B(x_2,r_2)")#text(" which is also disjoint from ")#mi("E_2")#text(", with ")#mi("r_2 \\leq r_1/10")#text(". Continuing this process, we end up with a nested sequence of balls ")#mi("B(x_n,r_n)")#text(", each of which are disjoint from ")#mi("E_1,\\ldots,E_n")#text(", and such that ")#mi("B(x_n,r_n) \\subset B(x_{n-1},r_{n-1}/10)")#text(" and ")#mi("r_n \\leq r_{n-1}/10")#text(" for all ")#mi("n=1,2,\\ldots")#text(".")

#text("From the triangle inequality we have ")#mi("d(x_n,x_{n-1}) \\leq 2 r_{n-1} / 10 \\leq 2 \\times 10^{-n} r_0")#text(", and so the sequence ")#mi("x_n")#text(" is a Cauchy sequence. As X is complete, ")#mi("x_n")#text(" converges to a limit x. Summing the geometric series, one verifies that ")#mi("x \\in B(x_{n-1},r_{n-1})")#text(" for all ")#mi("n=1,2,\\ldots")#text(", and in particular ")#mi("x")#text(" is an element of ")#mi("B(x_0,r_0)")#text(" which avoids all of ")#mi("E_1, E_2, E_3, \\ldots")#text(", a contradiction. ")#mi("\\Box")

#text("We can illustrate the analogy between the Baire category theorem and the measure-theoretic analogs by introducing some further definitions. Call a set E ")#emph[#link("http://en.wikipedia.org/wiki/Meagre_set")[#text("meager")]]#text(" or ")#emph[#text("of the first category")]#text(" if it can be expressed (or covered) by a countable union of nowhere dense sets, and ")#emph[#text("of the second category")]#text(" if it is not meager. Thus, the Baire category theorem shows that any subset of a complete metric space with non-empty interior is of the second category, which may help explain the name for the property. Call a set ")#emph[#text("co-meager")]#text(" or ")#emph[#text("residual")]#text(" if its complement is meager, and call a set ")#link("http://en.wikipedia.org/wiki/Property_of_Baire")[#emph[#text("Baire")]]#text(" or ")#emph[#text("almost open")]#text(" if it differs from an open set by a meager set (note that a Baire set is unrelated to the Baire ")#mi("\\sigma")#text("-algebra). Then we have the following analogy between complete metric space topology, and measure theory:")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Complete non-empty metric space X")],
table.cell(colspan: 1, rowspan: 1)[#text("Measure space X of positive measure")],
table.cell(colspan: 1, rowspan: 1)[#text("first category (meager)")],
table.cell(colspan: 1, rowspan: 1)[#text("zero measure (null )")],
table.cell(colspan: 1, rowspan: 1)[#text("second category")],
table.cell(colspan: 1, rowspan: 1)[#text("positive measure")],
table.cell(colspan: 1, rowspan: 1)[#text("residual (co-meager)")],
table.cell(colspan: 1, rowspan: 1)[#text("full measure (co-null)")],
table.cell(colspan: 1, rowspan: 1)[#text("Baire")],
table.cell(colspan: 1, rowspan: 1)[#text("measurable")]
)

#text("Nowhere dense sets are meager, and meager sets have empty interior. Contrapositively, sets with dense interior")#linebreak()#text(" are residual, and residual sets are somewhere dense. Taking complements instead of contrapositives, we see that open dense sets are co-meager,and co-meager sets are dense.")

#text("While there are certainly many analogies between meager sets and null sets (for instance, both classes are closed under countable unions, or under intersections with arbitrary sets), the two concepts can differ in practice. For instance, in the real line ")#mi("{\\Bbb R}")#text(" with the standard metric and measure space structures, the set")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\bigcup_{n=1}^\\infty (q_n - 2^{-n}, q_n + 2^{-n}),")]]

#text("where ")#mi("q_1, q_2, \\ldots")#text(" is an enumeration of the rationals, is open and dense, but has Lebesgue measure at most 2; thus its complement has infinite measure in ")#mi("{\\Bbb R}")#text(" but is nowhere dense (hence meager). As a variant of this, the set")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\bigcap_{m=1}^\\infty \\bigcup_{n=1}^\\infty (q_n - 2^{-n}/m, q_n + 2^{-n}/m),")]]

#text("is a null set, but is the intersection of countably many open dense sets and is thus co-meager.")

#strong[#text("Exercise 3. ")]#text(" A real number x is ")#emph[#text("Diophantine")]#text(" if for every ")#mi("\\varepsilon > 0")#text(" there exists ")#mi("c_\\varepsilon > 0")#text(" such that ")#tao-math("\\left|x - \\frac{a}{q}\\right| \\geq \\frac{c_\\varepsilon}{\\left|q\\right|^{2+\\varepsilon}}", block: false)#text(" for every rational number ")#mi("\\frac{a}{q}")#text(". Show that the set of Diophantine real numbers has full measure but is meager. ")#mi("\\diamond")

#strong[#text("Remark 1.")]#text(" If one assumes some additional axioms of set theory (e.g. the ")#link("http://en.wikipedia.org/wiki/Continuum_hypothesis")[#text("continuum hypothesis")]#text("), it is possible to show that the collection of meager subsets of ")#mi("{\\Bbb R}")#text(" and the collection of null subsets of ")#mi("{\\Bbb R}")#text(" (viewed as ")#link("http://en.wikipedia.org/wiki/Sigma-ideal")[#mi("\\sigma")#text("-ideals")]#text(" of the collection of all subsets of ")#mi("{\\Bbb R}")#text(") are isomorphic; this is the ")#link("http://www.ams.org/mathscinet-getitem?mr=9614")[#text("Sierpinski-Erdös theorem")]#text(", which we will not prove here. Roughly speaking, this theorem tells us that any “effective” first-order statement which is true about meager sets will also be true about null sets, and conversely. ")#mi("\\diamond")

#heading(level: 1)[#text("— The uniform boundedness principle —")]

#text("As mentioned in the introduction, the Baire category theorem implies various equivalences between qualitative and quantitative properties of linear transformations between Banach spaces. (Lemma 1 of ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("Notes 3")]#text(" already gives a prototypical such equivalence between a qualitative property (continuity) and a quantitative one (boundedness).)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2.")]#text(" (")#link("http://en.wikipedia.org/wiki/Uniform_boundedness_principle")[#text("Uniform boundedness principle")]#text(") Let X be a Banach space, let Y be a normed vector space, and let ")#mi("(T_\\alpha)_{\\alpha \\in A}")#text(" be a family of continuous linear operators ")#mi("T_\\alpha: X \\to Y")#text(". Then the following are equivalent:")

#enum(start: 1, 
[#text("(Pointwise boundedness) For every ")#mi("x \\in X")#text(", the set ")#mi("\\{ T_\\alpha x: \\alpha \\in A \\}")#text(" is bounded.")],
[#text("(Uniform boundedness) The operator norms ")#tao-math("\\{ \\left\\|T_\\alpha \\right\\|_{op}: \\alpha \\in A \\}", block: false)#text(" are bounded.")]
)
]

#text("The uniform boundedness principle is also known as the ")#emph[#text("Banach-Steinhaus theorem")]#text(".")

#strong[#text("Proof.")]#text(" It is clear that 2. implies 1.; now assume 1 holds and let us obtain 2.")

#text("For each ")#mi("n = 1, 2, \\ldots")#text(", let ")#mi("E_n")#text(" be the set")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("E_n := \\{ x \\in X: \\left\\| T_\\alpha x \\right\\|_Y \\leq n \\text{ for all } \\alpha \\in A \\}.", block: true)]]

#text("The hypothesis 1 is nothing more than the assertion that the ")#mi("E_n")#text(" cover X, and thus by the Baire category theorem one of the ")#mi("E_n")#text(" must be dense in a ball. Since the ")#mi("T_\\alpha")#text(" are continuous, the ")#mi("E_n")#text(" are closed, and so one of the ")#mi("E_n")#text(" contains a ball. Since ")#mi("E_n - E_n \\subset E_{2n}")#text(", we see that one of the ")#mi("E_n")#text(" contains a ball centred at the origin. Dilating n as necessary, we see that one of the ")#mi("E_n")#text(" contains the unit ball ")#mi("B(0,1)")#text(". But then all the ")#tao-math("\\left\\|T_\\alpha\\right\\|_{op}", block: false)#text(" are bounded by n, and the claim follows. ")#mi("\\Box")

#strong[#text("Exercise 4.")]#text(" Give counterexamples to show that the uniform boundedness principle fails if one relaxes the assumptions in any of the following ways:")

#enum(start: 1, 
[#text("X is merely a normed vector space rather than a Banach space (i.e. completeness is dropped).")],
[#text("The ")#mi("T_\\alpha")#text(" are not assumed to be continuous.")],
[#text("The ")#mi("T_\\alpha")#text(" are allowed to be nonlinear rather than linear.")]
)

#text("Thus completeness, continuity, and linearity are all essential for the uniform boundedness principle to apply. ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" It is instructive to establish the uniform boundedness principle more “constructively” without the Baire category theorem (though the ")#emph[#text("proof")]#text(" of the Baire category theorem is still implicitly present), as follows. Suppose that 2 fails, then ")#tao-math("\\left\\|T_\\alpha\\right\\|_{op}", block: false)#text(" is unbounded. We can then find a sequence ")#mi("\\alpha_n \\in A")#text(" such that ")#tao-math("\\left\\| T_{\\alpha_{n+1}} \\right\\|_{op} > 100^n \\left\\| T_{\\alpha_n} \\right\\|_{op}", block: false)#text(" (say) for all n. We can then find unit vectors ")#mi("x_n")#text(" such that ")#tao-math("\\left\\| T_{\\alpha_n} x_n \\right\\|_Y \\geq \\frac{1}{2} \\left\\| T_{\\alpha_n} \\right\\|_{op}", block: false)#text(".")

#text("We can then form the absolutely convergent (and hence conditionally convergent, by completeness) sum ")#mi("x = \\sum_{n=1}^\\infty \\epsilon_n 10^{-n} x_n")#text(" for some choice of signs ")#mi("\\epsilon_n = \\pm 1")#text(" recursively as follows: once ")#mi("\\epsilon_1,\\ldots,\\epsilon_{n-1}")#text(" have been chosen, choose the sign ")#mi("\\epsilon_n")#text(" so that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\|\\sum_{m=1}^n \\epsilon_m 10^{-m} T_{\\alpha_n} x_m \\right\\|_Y \\geq \\left\\| 10^{-n} T_{\\alpha_n} x_n \\right\\|_Y \\geq \\frac{1}{2} 10^{-n} \\left\\| T_{\\alpha_n} \\right\\|_{op}.", block: true)]]

#text("From the triangle inequality we soon conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| T_{\\alpha_n} x \\right\\|_Y \\geq \\frac{1}{4} 10^{-n} \\left\\| T_{\\alpha_n} \\right\\|_{op}.", block: true)]]

#text("But by hypothesis, the RHS is unbounded in n, contradicting 1. ")#mi("\\Box")

#text("A common way to apply the uniform boundedness principle is via the following corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1.")]#text(" (Uniform boundedness principle for norm convergence) Let ")#mi("X")#text(" and ")#mi("Y")#text(" be Banach spaces, and let ")#mi("(T_n)_{n=1}^\\infty")#text(" be a family of continuous linear operators ")#mi("T_n: X \\to Y")#text(". Then the following are equivalent:")

#enum(start: 1, 
[#text("(Pointwise convergence) For every ")#mi("x \\in X")#text(", ")#mi("T_n x")#text(" converges strongly in ")#mi("Y")#text(" as ")#mi("n \\to \\infty")#text(".")],
[#text("(Pointwise convergence to a continuous limit) There exists a continuous linear ")#mi("T: X \\to Y")#text(" such that for every ")#mi("x \\in X")#text(", ")#mi("T_n x")#text(" converges strongly in ")#mi("Y")#text(" to ")#mi("Tx")#text(" as ")#mi("n \\to \\infty")#text(".")],
[#text("(Uniform boundedness + dense subclass convergence) The operator norms ")#tao-math("\\{ \\left\\|T_n\\right\\|: n = 1,2,\\ldots \\}", block: false)#text(" are bounded, and for a dense set of ")#mi("x")#text(" in ")#mi("X")#text(", ")#mi("T_n x")#text(" converges strongly in ")#mi("Y")#text(" as ")#mi("n \\to \\infty")#text(".")]
)
]

#strong[#text("Proof. ")]#text("Clearly 2. implies 1., and as convergent sequences are bounded, we see from Theorem 2 that 1. implies 3. The implication of 2 from 3 follows by a standard limiting argument and is left as an exercise. ")#mi("\\Box")

#strong[#text("Remark 3.")]#text(" The same equivalences hold if one replaces the sequence ")#mi("(T_n)_{n=1}^\\infty")#text(" by a ")#link("http://en.wikipedia.org/wiki/Net_(mathematics)")[#text("net")]#text(" ")#mi("(T_\\alpha)_{\\alpha \\in A}")#text(". ")#mi("\\diamond")

#strong[#text("Example 1")]#text(" (Fourier inversion formula). For any ")#mi("f \\in L^2({\\Bbb R})")#text(" and N > 0, define the Dirichlet summation operator")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("S_N f(x) := \\int_{-N}^N \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi")]]

#text("where ")#mi("\\hat f")#text(" is the Fourier transform of f, defined on smooth compactly supported functions ")#mi("f \\in C^\\infty_0({\\Bbb R})")#text(" by the formula ")#mi("\\hat f(\\xi) := \\int_{-\\infty}^\\infty f(x) e^{-2\\pi i x \\xi}\\ dx")#text(" and then extended to ")#mi("L^2")#text(" by the ")#link("http://en.wikipedia.org/wiki/Plancherel%27s_theorem")[#text("Plancherel theorem")]#text(". Using the Plancherel identity, we can verify that the operator norms ")#tao-math("\\left\\|S_N\\right\\|_{op}", block: false)#text(" are uniformly bounded (indeed, they are all 1); also, one can check that for ")#mi("f \\in C^\\infty_0({\\Bbb R})")#text(", that ")#mi("S_N f")#text(" converges in ")#mi("L^2")#text(" norm to f as ")#mi("N \\to \\infty")#text(". As ")#mi("C^\\infty_0({\\Bbb R})")#text(" is known to be dense in ")#mi("L^2({\\Bbb R)}")#text(", this implies that ")#mi("S_N f")#text(" converges in ")#mi("L^2")#text(" norm to f for every ")#mi("f \\in L^2({\\Bbb R})")#text(".")

#text("This argument only used the “easy” implication of Corollary 1, namely the deduction of 2. from 3. The “hard” implication using the Baire category theorem was not directly utilised. However, from a metamathematical standpoint, that implication is important because it tells us that the above strategy to prove convergence in norm of the Fourier inversion formula on ")#mi("L^2")#text(" – i.e. to obtain uniform operator norms on the partial sums, and to establish convergence on a dense subclass of “nice” functions – is in some sense the ")#emph[#text("only")]#text(" strategy available to prove such a result. ")#mi("\\diamond")

#strong[#text("Remark 4.")]#text(" There is a partial analogue of Corollary 1 for the question of pointwise almost everywhere convergence rather than norm convergence, known as ")#link("http://www.ams.org/mathscinet-getitem?mr=125392")[#text("Stein’s maximal principle")]#text(" (discussed for instance in ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("this previous blog post of mine")]#text("). For instance, it reduces ")#link("http://en.wikipedia.org/wiki/Convergence_of_Fourier_series#Convergence_almost_everywhere")[#text("Carleson’s theorem on the pointwise almost everywhere convergence of Fourier series")]#text(" to the boundedness of a certain maximal function (the ")#emph[#text("Carleson maximal operator")]#text(") related to Fourier summation, although the latter task is again quite non-trivial. (As in Example 1, the role of the maximal principle is meta-mathematical rather than direct.) ")#mi("\\diamond")

#text("Of course, if we omit some of the hypotheses, it is no longer true that pointwise boundedness and uniform boundedness are the same. For instance, if we let ")#mi("c_0({\\Bbb N})")#text(" be the space of complex sequences with only finitely many non-zero entries and with the uniform topology, and let ")#mi("\\lambda_n: c_0({\\Bbb N}) \\to {\\Bbb C}")#text(" be the map ")#mi("(a_m)_{m=1}^\\infty \\to n a_n")#text(", then the ")#mi("\\lambda_n")#text(" are pointwise bounded but not uniformly bounded; thus completeness of X is important. Also, even in the one-dimensional case ")#mi("X=Y={\\Bbb R}")#text(", the uniform boundedness principle can easily be seen to fail if the ")#mi("T_\\alpha")#text(" are non-linear transformations rather than linear ones. ")#mi("\\diamond")

#heading(level: 1)[#text("— The open mapping theorem —")]

#text("A map ")#mi("f: X \\to Y")#text(" between topological spaces X and Y is said to be ")#link("http://en.wikipedia.org/wiki/Open_map")[#text("open")]#text(" if it maps open sets to open sets. This is similar to, but slightly different, from the more familiar property of being ")#emph[#text("continuous")]#text(", which is equivalent to the ")#emph[#text("inverse")]#text(" image of open sets being open. For instance, the map ")#mi("f: {\\Bbb R} \\to {\\Bbb R}")#text(" defined by ")#mi("f(x) := x^2")#text(" is continuous but not open; conversely, the function ")#mi("g: {\\Bbb R}^2 \\to {\\Bbb R}")#text(" defined by ")#mi("g(x,y) := \\text{sgn}(y)+x")#text(" is discontinuous but open.")

#text("We have seen that it is quite possible for non-linear continuous maps to fail to be open. But for linear maps between Banach spaces, the situation is much better:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3.")]#text(" (")#link("http://en.wikipedia.org/wiki/Open_mapping_theorem_%28functional_analysis%29")[#text("Open mapping theorem")]#text(") Let ")#mi("L: X \\to Y")#text(" be a continuous linear transformation between two Banach spaces X and Y. Then the following are equivalent:")

#enum(start: 1, 
[#text("L is surjective.")],
[#text("L is open.")],
[#text("(Qualitative solvability) For every ")#mi("f \\in Y")#text(" there exists a solution ")#mi("u \\in X")#text(" to the equation ")#mi("Lu = f")#text(".")],
[#text("(Quantitative solvability) There exists a constant ")#mi("C > 0")#text(" such that for every ")#mi("f \\in Y")#text(" there exists a solution ")#mi("u \\in X")#text(" to the equation ")#mi("Lu = f")#text(", which obeys the bound ")#tao-math("\\left\\|u\\right\\|_X \\leq C \\left\\|f\\right\\|_Y", block: false)#text(".")],
[#text("(Quantitative solvability for a dense subclass) There exists a constant ")#mi("C > 0")#text(" such that for a dense set of f in Y, there exists a solution ")#mi("u \\in X")#text(" to the equation ")#mi("Lu = f")#text(", which obeys the bound ")#tao-math("\\left\\|u\\right\\|_X \\leq C \\left\\|f\\right\\|_Y", block: false)#text(".")]
)
]

#strong[#text("Proof. ")]#text(" Clearly 4. implies 3., which is equivalent to 1., and it is easy to see from linearity that 2. and 4. are equivalent (cf. the proof of Lemma 2 from ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("Notes 3")]#text("). 4. trivially implies 5., while to obtain 4. from 5., observe that if E is any dense subset of the Banach space Y, then any f in Y can be expressed as an absolutely convergent series ")#mi("f = \\sum_n f_n")#text(" of elements in E (since one can iteratively approximate the residual ")#mi("f - \\sum_{n=1}^{N-1} f_n")#text(" to arbitrary accuracy by an element of E for ")#mi("N=1,2,3,\\ldots")#text("), and the claim easily follows. So it suffices to show that 3. implies 4.")

#text("For each n, let ")#mi("E_n \\subset Y")#text(" be the set of all ")#mi("f \\in Y")#text(" for which there exists a solution to Lu=f with ")#tao-math("\\left\\|u\\right\\|_X \\leq n \\left\\|f\\right\\|_Y", block: false)#text(". From the hypothesis 3, we see that ")#mi("\\bigcup_n E_n = Y")#text(". Since Y is complete, the Baire category theorem implies that there is some ")#mi("E_n")#text(" which is dense in some ball ")#mi("B(f_0,r)")#text(" in Y. In other words, the problem Lu=f is ")#emph[#text("approximately quantitatively solvable")]#text(" in the ball ")#mi("B(f_0,r)")#text(" in the sense that")

#list(
[#text("For every ")#mi("\\varepsilon > 0")#text(" and every ")#mi("f \\in B(f_0,r)")#text(", there exists an approximate solution u with ")#tao-math("\\left\\| Lu - f \\right\\|_Y \\leq \\varepsilon", block: false)#text(" and ")#tao-math("\\left\\|u\\right\\|_X \\leq n \\left\\|Lu \\right\\|_Y", block: false)#text(", and thus ")#tao-math("\\left\\|u\\right\\|_X \\leq n r + n \\varepsilon", block: false)#text(".")]
)

#text("By subtracting two such approximate solutions, we conclude that")

#list(
[#text("For any ")#mi("f \\in B(0,2r)")#text(" and any ")#mi("\\varepsilon > 0")#text(", there exists ")#mi("u \\in X")#text(" with ")#tao-math("\\left\\|Lu - f \\right\\|_Y \\leq 2\\varepsilon", block: false)#text(" and ")#tao-math("\\left\\|u\\right\\|_X \\leq 2nr + 2 n \\varepsilon", block: false)#text(".")]
)

#text("Since L is homogeneous, we can rescale and conclude that")

#list(
[#text("For any ")#mi("f \\in Y")#text(" and any ")#mi("\\varepsilon > 0")#text(" there exists ")#mi("u \\in X")#text(" with ")#tao-math("\\left\\|Lu - f \\right\\|_Y \\leq 2 \\varepsilon", block: false)#text(" and ")#tao-math("\\left\\|u\\right\\|_X \\leq 2n \\left\\|f\\right\\|_Y + 2n \\varepsilon", block: false)#text(".")]
)

#text("In particular, setting ")#tao-math("\\varepsilon = \\frac{1}{4} \\left\\|f\\right\\|_Y", block: false)#text(" (treating the case f=0 separately), we conclude that")

#list(
[#text("For any ")#mi("f \\in Y")#text(", we may write ")#mi("f = Lu + f^{\\prime}")#text(", where ")#tao-math("\\left\\| f^{\\prime}\\right\\|_Y \\leq \\frac{1}{2} \\left\\|f\\right\\|_Y", block: false)#text(" and ")#tao-math("\\left\\|u\\right\\|_X \\leq \\frac{5}{2} n \\left\\|f\\right\\|_Y", block: false)#text(".")]
)

#text("We can iterate this procedure and then take limits (now using the completeness of X rather than Y) to obtain a solution to Lu=f for every ")#mi("f \\in Y")#text(" with ")#tao-math("\\left\\|u\\right\\|_X \\leq 5 n \\left\\|f\\right\\|_Y", block: false)#text(", and the claim follows. ")#mi("\\Box")

#strong[#text("Remark 5. ")]#text("The open mapping theorem provides metamathematical justification for the method of ")#emph[#text("a priori estimates")]#text(" for solving linear equations such as ")#mi("Lu = f")#text(" for a given datum ")#mi("f \\in Y")#text(" and for an unknown ")#mi("u \\in X")#text(", which is of course a familiar problem in linear PDE. The a priori method assumes that f is in some dense class of nice functions (e.g. smooth functions) in which solvability of Lu=f is presumably easy, and then proceeds to obtain the a priori estimate ")#tao-math("\\left\\|u\\right\\|_X \\leq C \\left\\|f\\right\\|_Y", block: false)#text(" for some constant C. Theorem 3 then assures that Lu=f is solvable for all f in Y (with a similar bound). As before, this implication does not directly use the Baire category theorem, but that theorem helps explain why this method is “not wasteful”. ")#mi("\\diamond")

#text("A pleasant corollary of the open mapping theorem is that, as with ordinary linear algebra or with arbitrary functions, invertibility is the same thing as bijectivity:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2.")]#text(" Let ")#mi("T: X \\to Y")#text(" be a continuous linear operator between two Banach spaces X, Y. Then the following are equivalent:")

#enum(start: 1, 
[#text("(Qualitative invertibility) T is bijective.")],
[#text("(Quantitative invertibility) T is bijective, and ")#mi("T^{-1}: Y \\to X")#text(" is a continuous (hence bounded) linear transformation.")]
)
]

#strong[#text("Remark 6. ")]#text("The claim fails without the completeness hypotheses on X and Y. For instance, consider the operator ")#mi("T: c_c({\\Bbb N}) \\to c_c({\\Bbb N})")#text(" defined by ")#mi("T (a_n)_{n=1}^\\infty := (\\frac{a_n}{n})_{n=1}^\\infty")#text(", where we give ")#mi("c_c({\\Bbb N})")#text(" the uniform norm. Then T is continuous and bijective, but ")#mi("T^{-1}")#text(" is unbounded. ")#mi("\\diamond")

#strong[#text("Exercise 5. ")]#text("Show that Corollary 2 can still fail if we drop the completeness hypothesis on just X, or just Y. ")#mi("\\diamond")

#strong[#text("Exercise 6.")]#text(" Suppose that ")#mi("L: X \\to Y")#text(" is a surjective continuous linear transformation between Banach spaces. By using the open mapping theorem, show that the transpose map ")#mi("L^*: Y^* \\to X^*")#text(" is bounded from below, i.e. there exists ")#mi("c > 0")#text(" such that ")#tao-math("\\left\\| L^* \\lambda \\right\\|_{X^*} \\geq c \\left\\|\\lambda \\right\\|_{Y^*}", block: false)#text(" for all ")#mi("\\lambda \\in Y^*")#text(". Conclude that ")#mi("L^*")#text(" is an isomorphism between ")#mi("Y^*")#text(" and ")#mi("L^*(Y^*)")#text(". ")#mi("\\diamond")

#text("Let L be as in Theorem 3, so that the problem Lu=f is both qualitatively and quantitatively solvable. A standard application of Zorn’s lemma (similar to that used to prove the Hahn-Banach theorem) shows that the problem Lu=f is also qualitatively ")#emph[#text("linearly ")]#text("solvable, in the sense that there exists a linear transformation ")#mi("S: Y \\to X")#text(" such that ")#mi("LSf = f")#text(" for all ")#mi("f \\in Y")#text(" (i.e. S is a ")#link("http://en.wikipedia.org/wiki/Inverse_element")[#text("right-inverse")]#text(" of L). In view of the open mapping theorem, it is then tempting to conjecture that L must also be ")#emph[#text("quantitatively")]#text(" linearly solvable, in the sense that there exists a ")#emph[#text("continuous")]#text(" linear transformation ")#mi("S: Y \\to X")#text(" such that ")#mi("LSf = f")#text(" for all ")#mi("f \\in Y")#text(". By Corollary 2, we see that this conjecture is true when the problem Lu=f is determined, i.e. there is exactly one solution u for each datum f. Unfortunately, the conjecture can fail when Lu=f is ")#emph[#text("underdetermined")]#text(" (more than one solution u for each f); we discuss this in the appendix to these notes. On the other hand, the situation is much better for Hilbert spaces:")

#strong[#text("Exercise 7.")]#text(" Suppose that ")#mi("L: H \\to H^{\\prime}")#text(" is a surjective continuous linear transformation between ")#emph[#text("Hilbert")]#text(" spaces. Show that there exists a continuous linear transformation ")#mi("S: H^{\\prime} \\to H")#text(" such that ")#mi("LS = I")#text(". Furthermore, we can ensure that the range of S is orthogonal to the kernel of L, and that this condition determines S uniquely. ")#mi("\\diamond")

#strong[#text("Remark 7.")]#text(" In fact, Hilbert spaces are essentially the ")#emph[#text("only")]#text(" type of Banach space for which we have this nice property, due to the ")#link("http://www.ams.org/mathscinet-getitem?mr=276734")[#text("Lindenstrauss-Tzafriri solution of the complemented subspaces problem")]#text(". ")#mi("\\diamond")

#strong[#text("Exercise 8.")]#text(" Let M and N be closed subspaces of a Banach space X. Show that the following statements are equivalent:")

#enum(start: 1, 
[#text("(Qualitative complementation) Every x in X can be expressed in the form m+n for ")#mi("m \\in M, n \\in N")#text(" in exactly one way.")],
[#text("(Quantitative complementation) Every x in X can be expressed in the form m+n for ")#mi("m \\in M, n \\in N")#text(" in exactly one way. Furthermore there exists C > 0 such that ")#tao-math("\\left\\|m\\right\\|_X, \\left\\|n\\right\\|_X \\leq C \\left\\|x\\right\\|_X", block: false)#text(" all x.")]
)

#text("When either of these two properties hold, we say that M (or N) is a")#emph[#text(" complemented")]#text(" subspace, and that N is a ")#emph[#text("complement")]#text(" of M (or vice versa). ")#mi("\\diamond")

#text("The property of being complemented is closely related to that of quantitative linear solvability:")

#strong[#text("Exercise 9.")]#text(" Let ")#mi("L: X \\to Y")#text(" be a surjective bounded linear map between Banach spaces. Show that there exists a bounded linear map ")#mi("S: Y \\to X")#text(" such that ")#mi("LSf = f")#text(" for all ")#mi("f \\in Y")#text(" if and only if the kernel ")#mi("\\{ u \\in X: Lu=0\\}")#text(" is a complemented subspace of X. ")#mi("\\diamond")

#strong[#text("Exercise 10.")]#text(" Show that any finite-dimensional or closed finite co-dimensional subspace of a Banach space is complemented. ")#mi("\\diamond")

#strong[#text("Remark 8.")]#text(" The problem of determining whether a given closed subspace of a Banach space is complemented or not is, in general, quite difficult. However, non-complemented subspaces do exist in abundance; some example are given in the apendix, and ")#link("http://www.ams.org/mathscinet-getitem?mr=276734")[#text("the Lindenstrauss-Tzafriri theorem")]#text(" referred to in in Remark 7 asserts that any Banach space not isomorphic to a Hilbert space contains at least one non-complemented subspace. There is also ")#link("http://www.ams.org/mathscinet-getitem?mr=1201238")[#text("a remarkable construction of Gowers and Maurey")]#text(" of a Banach space such that ")#emph[#text("every")]#text(" subspace, other than those ruled out by Exercise 10, are uncomplemented. ")#mi("\\diamond")

#heading(level: 1)[#text("— The closed graph theorem —")]

#text("Recall that a map ")#mi("T: X \\to Y")#text(" between two metric spaces is ")#emph[#text("continuous")]#text(" if and only if, whenever ")#mi("x_n")#text(" converges to x in X, ")#mi("Tx_n")#text(" converges to Tx in Y. We can also define the weaker property of being ")#link("http://en.wikipedia.org/wiki/Closed_operator")[#text("closed")]#text(": an map ")#mi("T: X \\to Y")#text(" is closed if and only if whenever ")#mi("x_n")#text(" converges to x in X, ")#emph[#text("and")]#text(" ")#mi("Tx_n")#text(" converges to a limit y in Y, then y is equal to Tx; equivalently, T is closed if its graph ")#mi("\\{ (x,Tx): x \\in X \\}")#text(" is a closed subset of ")#mi("X \\times Y")#text(". This is weaker than continuity because it has the additional requirement that the sequence ")#mi("Tx_n")#text(" is already convergent. (Despite the name, closed operators are not directly related to open operators.)")

#strong[#text("Example 2.")]#text(" Let ")#mi("T: c_c({\\Bbb N}) \\to c_c({\\Bbb N})")#text(" be the transformation ")#mi("T( a_m )_{m=1}^\\infty := (ma_m)_{m=1}^\\infty")#text(". This transformation is unbounded and hence discontinuous, but one easily verifies that it is closed. ")#mi("\\diamond")

#text("As Example 2 shows, being closed is often a weaker property than being continuous. However, the remarkable ")#link("http://en.wikipedia.org/wiki/Closed_graph_theorem")[#text("closed graph theorem")]#text(" shows that as long as the domain and range of the operator are both Banach spaces, the two statements are equivalent:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4. ")]#text(" (Closed graph theorem) Let ")#mi("T: X \\to Y")#text(" be a linear transformation between two Banach spaces. Then the following are equivalent:")

#enum(start: 1, 
[#text("T is continuous.")],
[#text("T is closed.")],
[#text("(Weak continuity) There exists some ")#link("http://en.wikipedia.org/wiki/Topological_space")[#text("topology")]#text(" ")#mi("{\\mathcal F}")#text(" on Y, weaker than the norm topology (i.e. containing fewer open sets) but still ")#link("http://en.wikipedia.org/wiki/Hausdorff_space")[#text("Hausdorff")]#text(", for which ")#mi("T: X \\to (Y, {\\mathcal F})")#text(" is continuous.")]
)
]

#strong[#text("Proof. ")]#text(" It is clear that 1 implies 3 (just take ")#mi("{\\mathcal F}")#text(" to equal the norm topology). To see why 3 implies 2, observe that if ")#mi("x_n \\to x")#text(" in X and ")#mi("Tx_n \\to y")#text(" in norm, then ")#mi("Tx_n \\to y")#text(" in the weaker topology ")#mi("{\\mathcal F}")#text(" as well; but by weak continuity ")#mi("Tx_n \\to Tx")#text(" in ")#mi("{\\mathcal F}")#text(". Since Hausdorff topological spaces have unique limits, we have Tx=y and so T is closed.")

#text("Now we show that 2 implies 1. If T is closed, then the graph ")#mi("\\Gamma := \\{ (x,Tx): x \\in X \\}")#text(" is a closed linear subspace of the Banach space ")#mi("X \\times Y")#text(" and is thus also a Banach space. On the other hand, the projection map ")#mi("\\pi: (x,Tx) \\mapsto x")#text(" from ")#mi("\\Gamma")#text(" to X is clearly a continuous linear bijection. By Corollary 2, its inverse ")#mi("x \\mapsto (x,Tx)")#text(" is also continuous, and so T is continuous as desired. ")#mi("\\Box")

#text("We can reformulate the closed graph theorem in the following fashion:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3.")]#text(" Let X, Y be Banach spaces, and suppose we have some continuous inclusion ")#mi("Y \\subset Z")#text(" of Y into a Hausdorff ")#link("http://en.wikipedia.org/wiki/Topological_vector_space")[#text("topological vector space")]#text(" Z. Let ")#mi("T: X \\to Z")#text(" be a continuous linear transformation. Then the following are equivalent.")

#enum(start: 1, 
[#text("(Qualitative regularity) For all ")#mi("x \\in X")#text(", ")#mi("Tx \\in Y")#text(".")],
[#text("(Quantitative regularity) For all ")#mi("x \\in X")#text(", ")#mi("Tx \\in Y")#text(", and furthermore ")#tao-math("\\left\\|Tx\\right\\|_Y \\leq C \\left\\|x\\right\\|_X", block: false)#text(" for some ")#mi("C > 0")#text(" independent of x.")],
[#text("(Quantitative regularity on a dense subclass) For all x in a dense subset of X, ")#mi("Tx \\in Y")#text(", and furthermore ")#tao-math("\\left\\|Tx\\right\\|_Y \\leq C \\left\\|x\\right\\|_X", block: false)#text(" for some ")#mi("C > 0")#text(" independent of x.")]
)
]

#strong[#text("Proof.")]#text(" Clearly 2. implies 3. or 1. If we have 3., then T extends uniquely to a bounded linear map from X to Y, which must agree with the original continuous map from X to Z since limits in the Hausdorff space Z are unique, and so 3. implies 2. Finally, if 1. holds, then we can view T as a map from X to Y, which by Theorem 4 is continuous, and the claim now follows from Lemma 2 from ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("Notes 3")]#text(". ")#mi("\\Box")

#text("In practice, one should think of Z as some sort of “low regularity” space with a weak topology, and Y as a “high regularity” subspace with a stronger topology. Corollary 3 motivates the method of ")#emph[#text("a priori estimates")]#text(" to establish the Y-regularity of some linear transform Tx of an arbitrary element x in a Banach space X, by first establishing the a priori estimate ")#tao-math("\\left\\|Tx\\right\\|_Y \\leq C \\left\\|x\\right\\|_X", block: false)#text(" for a dense subclass of “nice” elements of X, and then using the above corollary (and some weak continuity of T in a low regularity space) to conclude. The closed graph theorem provides the metamathematical explanation as to why this approach is at least as powerful as any other approach to proving regularity.")

#strong[#text("Example 3.")]#text(" Let ")#mi("1 \\leq p \\leq 2")#text(", and let p’ be the dual exponent of p. To prove that the ")#link("http://en.wikipedia.org/wiki/Fourier_transform")[#text("Fourier transform")]#text(" ")#mi("\\hat f")#text(" of a function ")#mi("f \\in L^p({\\Bbb R})")#text(" necessarily lies in ")#mi("L^{p^{\\prime}}({\\Bbb R})")#text(", it suffices to prove the ")#emph[#link("http://en.wikipedia.org/wiki/Hausdorff-Young_inequality#Hausdorff.E2.88.92Young_inequality")[#text("Hausdorff-Young inequality")]]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| \\hat f \\right\\|_{L^{p^{\\prime}}({\\Bbb R})} \\leq C_p \\left\\|f\\right\\|_{L^p({\\Bbb R})}", block: true)]]

#text("for some constant ")#mi("C_p")#text(" and all f in some suitable dense subclass of ")#mi("L^p({\\Bbb R})")#text(" (e.g. the space ")#mi("C^\\infty_0({\\Bbb R})")#text(" of smooth functions of compact support), together with the “soft” observation that the Fourier transform is continuous from ")#mi("L^p({\\Bbb R})")#text(" to the space of ")#link("http://en.wikipedia.org/wiki/Tempered_distribution")[#text("tempered distributions")]#text(", which is a Hausdorff space into which ")#mi("L^{p^{\\prime}}({\\Bbb R})")#text(" embeds continuously. One can replace the Hausdorff-Young inequality here by countless other estimates in ")#link("http://en.wikipedia.org/wiki/Harmonic_analysis")[#text("harmonic analysis")]#text(" to obtain similar qualitative regularity conclusions. ")#mi("\\diamond")

#heading(level: 1)[#text("— Appendix: Nonlinear solvability (optional) —")]

#text("In this appendix we give an example of a linear equations Lu=f which can only be quantitatively solved in a nonlinear fashion. We will use a number of basic tools which we will only cover later in this course, and so this material is optional reading.")

#text("Let ")#mi("X = \\{0,1\\}^{\\Bbb N}")#text(" be the infinite discrete cube with the product topology; by ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff’s theorem")]#text(", this is a compact Hausdorff space. The Borel ")#mi("\\sigma")#text("-algebra is generated by the cylinder sets")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("E_n := \\{ (x_m)_{m=1}^\\infty \\in \\{0,1\\}^{\\Bbb N}: x_n = 1 \\}.")]]

#text("(From a probabilistic view point, one can think of X as the event space for flipping a countably infinite number of coins, and ")#mi("E_n")#text(" as the event that the ")#mi("n^{th}")#text(" coin lands as heads.)")

#text("Let ")#mi("M(X)")#text(" be the space of finite Borel measures on X; this can be verified to be a Banach space. There is a map ")#mi("L: M(X) \\to \\ell^\\infty({\\Bbb N})")#text(" defined by")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("L( \\mu ) := ( \\mu(E_n) )_{n=1}^\\infty.")]]

#text("This is a continuous linear transformation. The equation ")#mi("Lu=f")#text(" is quantitatively solvable for every ")#mi("f \\in \\ell^\\infty({\\Bbb N})")#text(". Indeed, if f is an indicator function ")#mi("f = 1_A")#text(", then ")#mi("f = L \\delta_{x_A}")#text(", where ")#mi("x_A \\in \\{0,1\\}^{\\Bbb N}")#text(" is the sequence that equals 1 on A and 0 outside of A, and ")#mi("\\delta_{x_A}")#text(" is the Dirac mass at A. The general case then follows by expressing a bounded sequence as an integral of indicator functions (e.g. if f takes values in [0,1], we can write ")#mi("f = \\int_0^1 1_{\\{f > t\\}}\\ dt")#text("). Note however that this is a nonlinear operation, since the indicator ")#mi("1_{\\{f>t\\}}")#text(" depends nonlinearly on f.")

#text("We now claim that the equation ")#mi("Lu=f")#text(" is not quantitatively linearly solvable, i.e. there is no bounded linear map ")#mi("S: \\ell^\\infty({\\Bbb N}) \\to M(X)")#text(" such that LSf = f for all ")#mi("f \\in \\ell^\\infty({\\Bbb N})")#text(". This fact was first observed by Banach and Mazur; we shall give two proofs, one of a “soft analysis” flavour and one of a “hard analysis” flavour.")

#text("We begin with the “soft analysis” proof, starting with a measure-theoretic result which is of independent interest.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5.")]#text(" (Nikodym convergence theorem) Let ")#mi("(X, {\\mathcal B})")#text(" be a measurable space, and let ")#mi("\\sigma_n: {\\mathcal B} \\to {\\Bbb R}")#text(" be a sequence of signed finite measures which is ")#emph[#text("weakly convergent")]#text(" in the sense that ")#mi("\\sigma_n(E)")#text(" converges to some limit ")#mi("\\sigma(E)")#text(" for each ")#mi("E \\in {\\mathcal B}")#text(". Then:")

#enum(start: 1, 
[#text("The ")#mi("\\sigma_n")#text(" are uniformly countably additive, which means that for any sequence ")#mi("E_1, E_2, \\ldots")#text(" of disjoint measurable sets, the series ")#tao-math("\\sum_{m=1}^\\infty \\left|\\sigma_n(E_m)\\right|", block: false)#text(" converges uniformly in n.")],
[#mi("\\sigma")#text(" is a signed finite measure.")]
)
]

#strong[#text("Proof.")]#text(" It suffices to prove the first part, since this easily implies that ")#mi("\\sigma")#text(" is also countably additive, and is thence a signed finite measure. Suppose for contradiction that the claim failed, then one could find disjoint ")#mi("E_1, E_2, \\ldots")#text(" and ")#mi("\\varepsilon > 0")#text(" such that one has ")#tao-math("\\limsup_{n \\to \\infty} \\sum_{m=M}^\\infty \\left|\\sigma_n(E_m)\\right| > \\varepsilon", block: false)#text(" for all M. We now construct disjoint sets ")#mi("A_1, A_2, \\ldots")#text(", each consisting of the union of a finite collection of the ")#mi("E_j")#text(", and an increasing sequence ")#mi("n_1, n_2, \\ldots")#text(" of positive integers, by the following recursive procedure:")

#enum(start: 1, 
[#text("Initialise ")#mi("k=0")#text(".")],
[#text("Suppose recursively that ")#mi("n_1 < \\ldots < n_{2k}")#text(" and ")#mi("A_1,\\ldots,A_k")#text(" has already been constructed for some ")#mi("k \\geq 0")#text(".")],
[#text("Choose ")#mi("n_{2k+1} > n_{2k}")#text(" so large that for all ")#mi("n \\geq n_{2k+1}")#text(", ")#mi("\\sigma_n(A_1 \\cup \\ldots \\cup A_k)")#text(" differs from ")#mi("\\sigma(A_1 \\cup \\ldots \\cup A_k)")#text(" by at most ")#mi("\\varepsilon/10")#text(".")],
[#text("Choose ")#mi("M_k")#text(" so large that ")#mi("M_k")#text(" is larger than j for any ")#mi("E_j \\subset A_1 \\cup \\ldots \\cup A_k")#text(", and such that ")#tao-math("\\sum_{m=M_k}^\\infty \\left|\\sigma_{n_j}(E_m)\\right| \\leq \\varepsilon / 100^{k+1}", block: false)#text(" for all ")#mi("1 \\leq j \\leq 2k+1")#text(".")],
[#text("Choose ")#mi("n_{2k+2} > n_{2k+1}")#text(" so that ")#tao-math("\\sum_{m=M_k}^\\infty \\left|\\sigma_{n_{2k+2}}(E_m)\\right| > \\varepsilon", block: false)#text(".")],
[#text("Pick ")#mi("A_{k+1}")#text(" to be a finite union of the ")#mi("E_j")#text(" with ")#mi("j \\geq M_k")#text(" such that ")#tao-math("\\left|\\sigma_{n_{2k+2}}(A_{k+1})\\right| > \\varepsilon/2", block: false)#text(".")],
[#text("Increment k to k+1 and then return to Step 2.")]
)

#text("It is then a routine matter to show that if ")#mi("A := \\bigcup_{j=1}^\\infty A_j")#text(", then ")#tao-math("\\left|\\sigma_{n_{2k+2}}(A) - \\sigma_{n_{2k+1}}(A)\\right| \\geq \\varepsilon/10", block: false)#text(" for all j, contradicting the hypothesis that ")#mi("\\sigma_j")#text(" is weakly convergent to ")#mi("\\sigma")#text(". ")#mi("\\Box")

#strong[#text("Exercise 11.")]#text(" (")#link("http://en.wikipedia.org/wiki/Schur%27s_property")[#text("Schur’s property")]#text(" for ")#mi("\\ell^1")#text(") Show that if a sequence in ")#mi("\\ell^1({\\Bbb N})")#text(" is convergent in the weak topology, then it is convergent in the strong topology. ")#mi("\\diamond")

#text("We return now to the map ")#mi("S: \\ell^\\infty({\\Bbb N}) \\to M(X)")#text(". Consider the sequence ")#mi("a_n \\in c_0({\\Bbb N}) \\subset \\ell^\\infty")#text(" defined by ")#mi("a_n := (1_{m \\leq n})_{m=1}^\\infty")#text(", i.e. each ")#mi("a_n")#text(" is the sequence consisting of n 1’s followed by an infinite number of 0’s. As the dual of ")#mi("c_0({\\Bbb N})")#text(" is isomorphic to ")#mi("\\ell^1({\\Bbb N})")#text(", we see from the dominated convergence theorem that ")#mi("a_n")#text(" is a weakly Cauchy sequence in ")#mi("c_0({\\Bbb N})")#text(", in the sense that ")#mi("\\lambda(a_n)")#text(" is Cauchy for any ")#mi("\\lambda \\in c_0({\\Bbb N})^*")#text(". Applying S, we conclude that ")#mi("S(a_n)")#text(" is weakly Cauchy in ")#mi("M(X)")#text(". In particular, using the bounded linear functionals ")#mi("\\mu \\mapsto \\mu(E)")#text(" on M(X), we see that ")#mi("S(a_n)(E)")#text(" converges to some limit ")#mi("\\mu(E)")#text(" for all measurable sets E. Applying the Nikodym convergence theorem we see that ")#mi("\\mu")#text(" is also a signed finite measure. We then see that ")#mi("S(a_n)")#text(" converges in the weak topology to ")#mi("\\mu")#text(". (One way to see this is to define ")#tao-math("\\nu := \\sum_{n=1}^\\infty 2^{-n} \\left|S(a_n)\\right| + \\left|\\mu\\right|", block: false)#text(", then ")#mi("\\nu")#text(" is finite and ")#mi("S(a_n), \\mu")#text(" are all absolutely continuous with respect to ")#mi("\\nu")#text("; now use the ")#link("http://en.wikipedia.org/wiki/Radon-Nikodym_derivative")[#text("Radon-Nikodym theorem")]#text(" (see ")#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/")[#text("Notes 1")]#text(") and the fact that ")#mi("L^1(\\nu)^* \\equiv L^\\infty(\\nu)")#text(".) On the other hand, as ")#mi("LS=I")#text(" and L and S are both bounded, S is a Banach space isomorphism between ")#mi("c_0")#text(" and ")#mi("S(c_0)")#text(". Thus ")#mi("S(c_0)")#text(" is complete, hence closed, hence weakly closed (by Hahn-Banach), and so ")#mi("\\mu = S(a)")#text(" for some ")#mi("a \\in c_0")#text(". By Hahn-Banach again, this implies that ")#mi("a_n")#text(" converges weakly to ")#mi("a \\in c_0")#text(". But this is easily seen to be impossible, since the constant sequence ")#mi("(1)_{m=1}^\\infty")#text(" does not lie in ")#mi("c_0")#text(", and the claim follows.")

#text("Now we give the “hard analysis” proof. Let ")#mi("e_1, e_2, \\ldots")#text(" be the standard basis for ")#mi("\\ell^\\infty({\\Bbb N})")#text(", let N be a large number, and consider the random sums")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("S( \\varepsilon_1 e_1 + \\ldots + \\varepsilon_N e_N )")]]

#text("where ")#mi("\\varepsilon_n \\in \\{-1,1\\}")#text(" are ")#link("http://en.wikipedia.org/wiki/Independent_and_identically-distributed_random_variables")[#text("iid")]#text(" random signs. Since the ")#mi("\\ell^\\infty")#text(" norm of ")#mi("\\varepsilon_1 e_1 + \\ldots + \\varepsilon_N e_N")#text(" is 1, we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left\\| S( \\varepsilon_1 e_1 + \\ldots + \\varepsilon_N e_N ) \\right\\|_{M(X)} \\leq C", block: true)]]

#text("for some constant C independent of N. On the other hand, we can write ")#mi("S(e_n) = f_n \\nu")#text(" for some finite measure ")#mi("\\nu")#text(" and some ")#mi("f_n \\in L^1(\\nu)")#text(" using Radon-Nikodym as in the previous proof, and then")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left\\| \\varepsilon_1 f_1 + \\ldots + \\varepsilon_N f_N \\right\\|_{L^1(\\nu)} \\leq C.", block: true)]]

#text("Taking expectations and applying ")#link("http://en.wikipedia.org/wiki/Khintchine_inequality")[#text("Khintchine’s inequality")]#text(" we conclude")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left\\| (\\sum_{n=1}^N \\left|f_n\\right|^2)^{1/2} \\right\\|_{L^1(\\nu)} \\leq C^{\\prime}", block: true)]]

#text("for some constant C’ independent of N. By ")#link("http://en.wikipedia.org/wiki/Cauchy%E2%80%93Schwarz_inequality")[#text("Cauchy-Schwarz")]#text(" this implies that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left\\| \\sum_{n=1}^N \\left|f_n\\right| \\right\\|_{L^1(\\nu)} \\leq C^{\\prime} \\sqrt{N}", block: true)]]

#text("But as ")#tao-math("\\left\\|f_n\\right\\|_{L^1(\\nu)} = \\left\\|S(e_n)\\right\\|_{M(X)} \\geq c", block: false)#text(" for some constant c > 0 independent of N, we obtain a contradiction for N large enough, and the claim follows.")

#strong[#text("Remark 9.")]#text(" The phenomenon of nonlinear quantitative solvability actually comes up in many applications of interest. For instance, consider the ")#link("http://www.ams.org/mathscinet-getitem?mr=447953")[#text("Fefferman-Stein decomposition theorem")]#text(", which asserts that any ")#mi("f \\in BMO({\\Bbb R})")#text(" of ")#link("http://en.wikipedia.org/wiki/Bounded_mean_oscillation")[#text("bounded mean oscillation")]#text(" can be decomposed as ")#mi("f = g + Hh")#text(" for some ")#mi("g, h \\in L^\\infty({\\Bbb R})")#text(", where H is the ")#link("http://en.wikipedia.org/wiki/Hilbert_transform")[#text("Hilbert transform")]#text(". This theorem was first proven by using the duality of the ")#link("http://en.wikipedia.org/wiki/Hardy_space")[#text("Hardy space")]#text(" ")#mi("H^1({\\Bbb R})")#text(" and BMO (and by using Exercise 13 from ")#link("https://terrytao.wordpress.com/2009/01/26/245b-notes-6-duality-and-the-hahn-banach-theorem/")[#text("Notes 6")]#text("), and by using the fact that a function f is in ")#mi("H^1({\\Bbb R})")#text(" if and only if f and Hf both lie in ")#mi("L^1({\\Bbb R})")#text(". From the open mapping theorem we know that we can pick g, h so that the ")#mi("L^\\infty")#text(" norms of g, h are bounded by a multiple of the BMO norm of f. But it turns out not to be possible to pick g and h in a bounded linear manner in terms of f, although this is a little tricky to prove. (")#link("http://www.ams.org/mathscinet-getitem?mr=666111")[#text("Uchiyama famously gave")]#text(" an explicit construction of g, h in terms of f, but the construction was highly nonlinear; see my ")#link("https://terrytao.wordpress.com/2007/02/23/uchiyamas-constructive-proof-of-the-fefferman-stein-decomposition/")[#text("blog post on the topic")]#text(".)")

#text("An example in a similar spirit was given more recently ")#link("http://www.ams.org/mathscinet-getitem?mr=1949165")[#text("by Bourgain and Brezis")]#text(", who considered the problem of solving the equation ")#mi("\\text{div} u = f")#text(" on the d-dimensional torus ")#mi("{\\Bbb T}^d")#text(" for some function ")#mi("f: {\\Bbb T}^d \\to {\\Bbb C}")#text(" on the torus with mean zero, and with some unknown vector field ")#mi("u: {\\Bbb T}^d \\to {\\Bbb C}^d")#text(", where the derivatives are interpreted in the weak sense. They showed that if ")#mi("d \\geq 2")#text(" and ")#mi("f \\in L^d({\\Bbb T}^d)")#text(", then there existed a solution u to this problem with ")#mi("u \\in W^{1,d} \\cap C^0")#text(", despite the failure of ")#link("http://en.wikipedia.org/wiki/Sobolev_inequality")[#text("Sobolev embedding")]#text(" at this endpoint. Again, the open mapping theorem allows one to choose u with norm bounded by a multiple of the norm of f, but Bourgain and Brezis also show that one cannot select u in a bounded linear fashion depending on f. ")#mi("\\diamond")

#strong[#text("Question. ")]#text(" All of the above constructions of non-complemented closed subspaces, or of linear problems that can only be quantitatively solved nonlinearly, were quite involved. Is there a “soft” or “elementary” way to see that closed subspaces of Banach spaces exist which are not complemented, or (equivalently) that surjective continuous linear maps between Banach spaces do not always enjoy a continuous linear right-inverse? I do not have a good answer to this question. ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Feb 4: definition of “residual” corrected.]")

#heading(level: 1)[#text("Comments (72)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-2/#comment-688796")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2025")])]

#emph[#text("Lemma 1 from ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("Notes 3")]]#text(" is mentioned several times in this post, but it should be Lemma 2.")

#text("According to ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/comment-page-2/#comment-671790")[#text("a comment under Notes 3")]#text(", the label “Lemma 1” had been used twice for two different theorems, and got corrected later.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-35408")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2009")])]

#text("Dear Terence,")#linebreak()#text(" you write")#linebreak()#text(" “There is also a remarkable construction of Gowers and Maurey of a Banach space such that every subspace, other than those ruled out by Exercise 10, are complemented. ”")#linebreak()#text(" Shouldn’t the sentence read : “There is also a remarkable construction of Gowers and Maurey of a Banach space such that every subspace, other than those ruled out by Exercise 10, is UNcomplemented” ?")

#text("Achille Talon")

#emph[#text("[Oops – corrected, thanks!]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c716037da6d3e5a796a496189a2d27fc9258994545dcebfb2a86384e4b566d1-f2cfae85492ac8e9379a982c61ec38351520bfeb8e4b04791d47d73405b918ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Combinations and Permutations")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-35433")[#strong[#text("Combinations and Permutations")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2009")])]

#text("I know this is a bit off subject but I am a graduate student at UNLV as well as a weekly math based podcast called ")#link("http://combinationsandpermutations.blogspot.com")[#text("Combinations and Permutations")]#text(" where we start with a mathematical topic and spin off onto as many tangents as we can. You can follow the previous link to the blog page of our podcast, search for us on iTunes, or take a trip over to our host site ")#link("http://cppodcast.libsyn.com")[#text("http://cppodcast.libsyn.com")]#text(". Give us a try I do think that you will enjoy what you hear.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-35458")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2009")])]

#text("Dr. Tao,")

#text("The term “residual” has been defined in two different ways here. Is this a mistake or an unfortunate terminology ambiguity?")

#emph[#text("[Oops – that was a mistake, now fixed, hopefully. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9600342ea6c4a9d9b3c467fc166a1c600cb8a5a49b7acc1a145414977e095f9a-e44c4910e771211e44bed0cc8479a2c89f24a6b6a9c6908e32ecf8da5d7ecfcb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ulrich")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-35501")[#strong[#text("Ulrich")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("Dear Terence, in your post “Remark 3”, Baire Category you mentioned, that the theorem of Banach-Steinaus (Corollary 3) is also valid for a net. But this can’t be true in general: E.g. if one takes ")#mi("A =  \\mathbb{Z}")#text(" and set")#linebreak()#text(" ")#mi("T_{n} = I")#text(" for ")#mi("n > 0")#text(" and equal ")#mi("nI")#text(" otherwise where")#linebreak()#text(" ")#mi("I")#text(" is the identity operator on an infinite dimensional Banach space. Then the net converges but is not bounded (I hope I entered the LaTeX code correctly)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-35507")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("Ah, right: convergent nets are not necessarily bounded, only bounded for sufficiently large indices. One might hope to salvage Banach-Steinhaus replacing bounded by “bounded for sufficiently large”, but the ")#mi("E_n")#text(" cease to be closed now, and my guess is that the statement fails, though I can’t immediately think of a counterexample. In any case, I’ll remove the comment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 10: Compactness in topological spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-35638")[#strong[#text("245B, Notes 10: Compactness in topological spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("[…] & PDE conferences pageBooksOn writingDoes one have to be a genius to do maths?About245B, Notes 9: The Baire category theorem and its Banach space consequencesWhy global regularity for Navier-Stokes is hard […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-35806")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("Dear Professor Tao:")

#text("In the following paragraph of Exercise 11, why is ")#mi("S(c_0)")#text(" closed?")

#text("By the way, in Theorem 5, the measures ")#mi("\\sigma")#text(" becomes ")#mi("\\mu")#text(" in the proof.")

#text("Xiaochuan")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-35810")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("Dear Xiaochuan,")

#text("Thanks for the correction!")

#text("The identity LS=I (and the boundedness of both L and S) shows that S is a Banach space isomorphism between ")#mi("c_0")#text(" and ")#mi("S(c_0)")#text(". Thus ")#mi("S(c_0)")#text(" is complete and therefore closed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-35833")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("Professor, why is ")#mi("c_0")#text(" complete, since ")#mi("a_n\\to a")#text(" and a doesnot lie in ")#mi("c_0")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-35834")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("Dear Liuxiaochuan, that is the contradiction that establishes that S does not exist. (The completeness of ")#mi("c_0")#text(" is nothing more than the assertion that the uniform limit of any sequence of sequences converging to zero, also converges to zero.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 实分析0-10 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-35902")[#strong[#text("实分析0-10 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("[…] 第九节探讨Baire纲定理以及由此引发的几个大定理：一致有界原理，开映射定理，闭图像定理。把这些神奇的定理复习了一遍，加深了理解。要说Banach的工作，最著名的就就是这么几个定理，当真是刺激的数学好长时间的发展。Banach空间上的几何是非常奇特的，应该有很多人在做专门的研究。Tim Gowers在20几岁的时候就提出过有趣的Banach空间做反例，本节有提到。最后一个部分有一个非线性的应用。非线性偏微分方程我上学期花过一个多月下功夫，可是依然半途而废，好不遗憾，我认真的把这部分看完了，希望今后能够捡起来。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 11: The strong and weak topologies « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-36088")[#strong[#text("245B, Notes 11: The strong and weak topologies « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2009")])]

#text("[…] can rephrase the uniform boundedness principle for convergence (Corollary 1 from Notes 9) as follows: Proposition 7 (Uniform boundedness principle) Let be a sequence of bounded linear […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/758f78bdc69374a138e14ceeda93836fe67ee98b33063997a5d1536e927a6a7b-f32ad8715309a76f5b93bdfcc1fd214f5cf8e03a4e7bdbab14e6aeaa778ef957.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samir")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-36535")[#strong[#text("Samir")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2009")])]

#text("Dear Professor Tao,")

#text("I’m not sure I see how, in Theorem 3 (the Open Mapping Theorem), that L is open implies quantitative solvability (i.e. 2 => 4). How does this follow from linearity? Any help would be greatly appreciated!")

#text("Samir")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-36543")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2009")])]

#text("Dear Samir,")

#text("If L is open, then the image of the unit ball is open, and thus contains some open ball centred at the origin of some radius r. This means that if f has norm less than r, then there exists u of norm less than 1 such that Lu=f. By linearity, this means that if f has any norm, then there exists a solution to Lu=f such that u has norm at most ")#tao-math("\\left\\|f\\right\\|/r", block: false)#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/758f78bdc69374a138e14ceeda93836fe67ee98b33063997a5d1536e927a6a7b-f32ad8715309a76f5b93bdfcc1fd214f5cf8e03a4e7bdbab14e6aeaa778ef957.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samir")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-36569")[#strong[#text("Samir")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2009")])]

#text("Dear Professor Tao,")

#text("In hindsight, the equivalence is simple, as you’d said. I wish I’d seen it myself earlier. Thanks for your help, as always!")

#text("Samir")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-37437")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2009")])]

#text("Another notion of residual sets still occurs in the paragraph following the table comparing complete metric spaces and measurable spaces. ")#emph[#text("[Corrected, thanks – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b80186b23ecd7183baf3997fea0be9728242b29992242075d680bd57d5ecaf5e-c01d0095c1e1fd68ce186085beae7f7aa8012003d8a49df53762ddeb97b4ffff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phi. Isett")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-41222")[#strong[#text("Phi. Isett")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2009")])]

#text("Dear Professor Tao,")

#text("Some tiny things: Remark 1.. “(viewed as … ” has no end parentheses.")

#text("Proof of theorem 3: “that if E is any sense” should be “dense”. I think you also meant “of elements in E” instead of “of elements in Y” during the same proof.")

#text("Should Y be a Banach space in corollary 3?")

#text("Is there a standard quantitative way by which to prove injectivity of a linear map (when an estimate of the form ")#tao-math("\\left\\| x \\right\\| \\leq C \\left\\| Tx \\right\\|", block: false)#text(" is unavailable)? I know the Fourier transform does not quite work this way (but it seems like having an inversion formula available is a bit special). It might be slightly related to your question in a dual sense..")

#text("For example, if you take an inclusion map ")#mi("i : X \\to Y")#text(" of a subspace, the transpose between the dual spaces is surjective, but this fact requires the Hahn Bahnach theorem. It somehow seems completely silly that ")#mi("i^t")#text(" would have a nice right-inverse. Maybe this helps?")

#text("Thank you for the very helpful entry!")#linebreak()#text(" ~Phil")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-41229")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2009")])]

#text("Thanks for the corrections!")

#text("Injectivity does not seem to have any good quantitative counterpart, as far as I know; the bound ")#tao-math("\\left\\|x\\right\\| \\leq C \\left\\|Tx\\right\\|", block: false)#text(" certainly implies injectivity but is substantially stronger than it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The double Duhamel trick and the in/out decomposition « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-42878")[#strong[#text("The double Duhamel trick and the in/out decomposition « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2009")])]

#text("[…] equivalent to the non-complemented nature of a certain subspace of a Banach space; see these lecture notes of mine and this old blog post for some discussion.) So one could imagine a sophisticated nonlinear […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Groß oder klein – dies ist manchmal die Frage – « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-43592")[#strong[#text("Groß oder klein – dies ist manchmal die Frage – « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2010")])]

#text("[…] Zusammenfassung, die man in diesem Zusammenhang einfach durcharbeiten muss findet sich auf dem Blog von Terence Tao. Dieser Blog enthält viele Beispiele und Anwendungen der verschiedenen Prinzipien, die wir […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-44778")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2010")])]

#text("This question might be silly or unanswerable but I will ask it anyway.")

#text("In the above you explain that in the linear case one can approach qualitative statements through quantitative means and in using this approach ones doesn’t lose anything. In the limited reading I have done it seems that in the non-linear case (e.g. non-linear PDE) people expend effort in showing that qualitative properties of solutions are in fact equivalent to some quantitative property.")

#text("Of course I can see the appeal of the quantitative approach becuase not only do you get the qualitative result you also obtain estimates. My questions are:")

#text("1. Why do people fall back on the quantitative approach? Is it ‘easier’ to prove the quantitative statement than the qualitative one (even though it seems it should be the other way around since you are asking for more i.e. estimates)?")

#text("2. If it is easier then why is it easier?")

#text("Thanks in advance for your time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-44779")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2010")])]

#text("I should clarify something in my above question.")

#text("When I say “Why do people fall back on the quantitative approach?” what I really mean to ask is why do you hardly see people tackling the qualitative formulation directly as opposed to first reformulating it in a quantitative fashion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-44780")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2010")])]

#text("In my opinion, the reason that the quantitative framework is more powerful is that it is more expressive, and so one can take advantage of more precise tools. Suppose for instance that one has two sequences ")#mi("x_n, y_n")#text(" of real numbers, with ")#mi("x_n \\to 0")#text(" and ")#mi("y_n \\to \\infty")#text(" as ")#mi("n \\to \\infty")#text(". What happens to ")#mi("x_n y_n")#text("? With a qualitative approach, one does not know – it could go to zero, to infinity, to something else, or not converge at all. But if one proceeds quantitatively instead, by establishing upper and lower bounds on ")#mi("x_n")#text(" and ")#mi("y_n")#text(", then one can often get good enough bounds on ")#mi("x_n y_n")#text(" to settle the question.")

#text("More generally, there are any number of deep estimates whose proof involves a large number of delicate quantitative steps that do not have an obvious qualitative analogue, for instance by carefully comparing different upper and lower bounds to show that various error terms are dominated by a main term. In some cases one can encapsulate these arguments in a clean qualitative form (e.g. by asserting that some operation is continuous or bounded) but often one is not so lucky, and so one has to get one’s hands dirty.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82e1b386e902885d97ea288c91542f3c6923379c3d093e709ff15775063b000b-94f7b243bec7ad017d8d84cf49ddd297bfe5b5f6046280fe8361a2385758bd0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kestutis Cesnavicius")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-45850")[#strong[#text("Kestutis Cesnavicius")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("Several typos:")

#text("1. In the second sentence after the table “non-empty interior” should be “dense interior”.")#linebreak()#text(" 2. In Exercise 3 the first appearance of ")#mi("c")#text(" should be ")#mi("c_{\\epsilon}")#text(".")#linebreak()#text(" 3. In the first sentence of Exercise 4 the word “if” is missing.")#linebreak()#text(" 4. In display (4) a bunch of indices ")#mi("n")#text(" should be ")#mi("m")#text(".")#linebreak()#text(" 5. In Remark 5 “some constant Y” should be “some constant C”.")#linebreak()#text(" 6. In Exercise 9 I guess ")#mi("L")#text(" should be bounded linear.")#linebreak()#text(" 7. In Exercise 10 “finite co-dimensional” should be “closed finite co-dimensional”.")#linebreak()#text(" 8. In the end of the opening paragraph of “The closed graph theorem” an opening parenthesis is missing.")#linebreak()#text(" 9. Shortly after display (7) the set Z of integers in the exponent should be the set N of natural numbers.")#linebreak()#text(" 10. In the last line of the proof of Theorem 5 I believe that the indices ")#mi("2k + 2")#text(" and ")#mi("2k + 1")#text(" were meant to be ")#mi("n_{2k + 2}")#text(" and ")#mi("n_{2k + 1}")#text(".")

#text("Thank you for a great set of notes!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yucao")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-49815")[#strong[#text("yucao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2011")])]

#text("Prof. Tao,")

#text("In the Baire Category Theorem, “at least one of the ")#mi("E_n")#text(" is dense in a sub-ball B’ of B “, do you mean ")#mi("\\overline{E_n} contains sub-ball B^{\\prime}")#text(" or ")#mi("\\overline{E_n}=B^{\\prime}")#text("? The term seems strange here. Is it a custom to use “dense” in this way? On the other hand, is the ball closed or open? Or it does not matter here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yucao")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-49820")[#strong[#text("yucao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2011")])]

#text("I think you have already explain this in Remark 5,")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("245A, Notes 1: Lebesgue measure")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yucao")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-49818")[#strong[#text("yucao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2011")])]

#text("In the proof of “uniform boundedness, “The hypothesis 1 is nothing more than the assertion that the ")#mi("E_n")#text(" cover X” should be “The hypothesis 1 is nothing more than the assertion that the ")#mi("\\cup_nE_n")#text(" cover X,”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yucao")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-49819")[#strong[#text("yucao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2011")])]

#text("Sorry for the stupid question. “the ")#mi("E_n")#text(" cover X” means “")#mi("U_n E_n")#text(" covers X.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-68657")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2011")])]

#text("Prof. Tao,")

#text("For exercise 1, do we have to use the proposition that a set ")#mi("E")#text(" is nowhere dense if and only if ")#mi("\\overline{E}^c")#text(" is open and dense? This is what I learned from your topology 121 notes(")#link("http://www.math.ucla.edu/~tao/resource/general/121.1.00s/compact.pdf")[#text("http://www.math.ucla.edu/~tao/resource/general/121.1.00s/compact.pdf")]#text(").")

#text("It seems that De Morgan will not help anything here.")

#text("Besides, it’s a little surprising that the opposite of “nowhere dense” is “dense” but not “somewhere dense” according to your lecture notes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-68665")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2011")])]

#text("Yes, one can use that proposition to establish Exercise 1.")

#text("I think you may be conflating two different notions of “opposite”, namely “")#link("http://en.wikipedia.org/wiki/Logical_negation")[#text("logical negation")]#text("” and “")#link("http://en.wikipedia.org/wiki/Set_complement")[#text("set complement")]#text("“. The negation of “E is nowhere dense” is “E is somewhere dense”. But the complement of a nowhere dense set is an everywhere dense set. This is similar to how the complement of a closed set is an open set, but how the negation of “E is closed” is _not_ “E is open” (since there exist sets that are neither open nor closed, and there also exist sets that are both open and closed).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-69043")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2011")])]

#text("Hmm. In your notes, you use that proposition to prove that a countable number of nowhere dense sets cannot cover a complete metric space. But in Exercise 1, one needs to show that “a countable number of nowhere dense sets cannot cover a ball”, which seems a stronger conclusion. I am wondering if one needs some special technique here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-69045")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2011")])]

#text("A closed ball in a complete metric space is still complete.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-69157")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2011")])]

#text("Hmm, the complement of a nowhere dense set is an everywhere dense set. But the complement of everywhere dense set is not necessarily nowhere dense set, right? So the relationship is not the exact the same as that of closed and open sets.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: Building Lie structure from representations and metrics « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-75272")[#strong[#text("254A, Notes 2: Building Lie structure from representations and metrics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2011")])]

#text("[…] (Hint: mimic the proof of the open mapping theorem for Banach spaces, as discussed for instance in these notes. In particular, take advantage of the Baire category […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/189645cfb9f987222d0b04916d637c0d7d22cb0862a5c0332a675455da60310a-25f80fcdd5dcf840dec644ed463dfe8ca0b1ce04ea6ad905ac886aee64ed7685.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dirk")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-90256")[#strong[#text("Dirk")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2011")])]

#text("In the proof of the Nikodym convergence theorem the notation changes from ")#mi("\\sigma_n")#text(" to ")#mi("\\mu_n")#text(". Unfortunately this typo is also present in the book where I noticed it…")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-90262")[#strong[#text("An elementry proof of Schur’s Theorem « regularize")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2011")]

#text("[…] this alternative proof with Exercise 11 (right after Theorem 5 [Nikodym convergence theorem]) in this blog post by Terry where one shall take a similar path to proof Schur’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-130280")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2012")])]

#text("As a pedagogical question, how many in-class lectures does it usually require for you to cover the content of one of your blog posts such as this one? Surely it is not possible to pack such an immense amount of material into a single 90-minute lecture.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The closed graph theorem in various categories « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-194633")[#strong[#text("The closed graph theorem in various categories « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2012")])]

#text("[…] qualitative and quantitative notions of regularity preservation properties of an operator ; see this blog post for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca8d2c55395a8252ff3f0548f523e3e9b9a10b44a4e13140c5bf3a0ce4a9810b-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvester Eriksson-Bique")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-243489")[#strong[#text("Sylvester Eriksson-Bique")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("I could be wrong, but Corollary 1 seems to be incorrect as stated. Particularly the implication 3-> 2. As stated in 3, the operators T_n:X->Y converge on a dense set, but don’t necessarily “patch up” in the limit to anything. That is, one should assume that T_n->T on a dense subset and that the norms are bounded. Then 2 follows from 3. OR, one can assume Y a Banach space, in which case uniform boundedness and dense convergence implies that there exists such an operator T. The problem is if Y is not complete.")

#text("Example: X=L^1 and \\phi_n \\to \\delta_0 (as n\\to \\infty) is a compactly supported, positive, smooth approximation of unity (as in ")#link("http://en.wikipedia.org/wiki/Mollifier")[#text("http://en.wikipedia.org/wiki/Mollifier")]#text("). Furthermore let Y=C(R,L^1), the continuous real valued functions on \\R with bounded L^1 norm. This space is normed by L^1, and as it’s completion is L^1 it is not Banach. Now consider the operators: T_n: f\\to f * \\phi_n. By Young’s inequality and since \\int \\phi_n = 1, \\phi_n>=0, then ||T_n(f)||_{L^1}=||f*\\phi_n||_L_1<= ||f||_{L_1}||\\phi_n||_L_1=||f||_L_1. In particular ||T_n||2 would be the only part requiring this. Another fix: Adjust the assumptions and assume in addition to convergence that there is some a priori limiting operator. Say if we assume that T_n \\to T on a dense set and $T: X\\to Y$ is some bounded linear operator, then the problem also disappears. In the above example e.g. take T_n f = f*\\phi_n – f*\\phi_{n+1}, then $T_n(y)\\to 0$ on a dense set and in fact T_n(x)\\to 0 everywhere.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca8d2c55395a8252ff3f0548f523e3e9b9a10b44a4e13140c5bf3a0ce4a9810b-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvester Eriksson-Bique")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-243490")[#strong[#text("Sylvester Eriksson-Bique")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("Sorry, copied my comment incorrectly:")

#text("Example: X=L^1 and \\phi_n \\to \\delta_0 (as n\\to \\infty) is a compactly supported, positive, smooth approximation of unity (as in ")#link("http://en.wikipedia.org/wiki/Mollifier")[#text("http://en.wikipedia.org/wiki/Mollifier")]#text("). Furthermore let Y=C(R,L^1), the continuous real valued functions on \\R with bounded L^1 norm. This space is normed by L^1, and as it’s completion is L^1 it is not Banach. Now consider the operators: T_n: f\\to f * \\phi_n. By Young’s inequality and since \\int \\phi_n = 1, \\phi_n>=0, then ||T_n(f)||_{L^1}=||f*\\phi_n||_L_1<= ||f||_{L_1}||\\phi_n||_L_1=||f||_L_1. In particular ||T_n||2 would be the only part requiring this. Another fix: Adjust the assumptions and assume in addition to convergence that there is some a priori limiting operator. Say if we assume that T_n \\to T on a dense set and $T: X\\to Y$ is some bounded linear operator, then the problem also disappears. In the above example e.g. take T_n f = f*\\phi_n – f*\\phi_{n+1}, then $T_n(y)\\to 0$ on a dense set and in fact $T_n(x)\\to 0$ everywhere.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d932b269f6721e1b4ba47e5048a4af8e7e0cebf00fbb883565c50142f8957597-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvester Eriksson-Bique")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-243491")[#strong[#text("Sylvester Eriksson-Bique")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("Bloody HTML:")

#text("Example: X=L^1 and \\phi_n \\to \\delta_0 (as n\\to \\infty) is a compactly supported, positive, smooth approximation of unity (as in ")#link("http://en.wikipedia.org/wiki/Mollifier")[#text("http://en.wikipedia.org/wiki/Mollifier")]#text("). Furthermore let Y=C(R,L^1), the continuous real valued functions on \\R with bounded L^1 norm. This space is normed by L^1, and as it’s completion is L^1 it is not Banach. Now consider the operators: T_n: f\\to f * \\phi_n. By Young’s inequality and since \\int \\phi_n = 1, \\phi_n>=0, then ||T_n(f)||_{L^1}=||f*\\phi_n||_L_1 \\leq ||f||_{L_1}||\\phi_n||_L_1=||f||_L_1. In particular ||T_n|| \\leq 1, and we have uniform boundedness. Moreover for any continuous function $f$ (which are dense in X), we have by standard results for mollifiers that T_n(f)=f*\\phi_n \\to f in L^1, and since the entire sequence is in C(R), then the convergence is strong in Y. Thus we have dense convergence. But now let $f=\\xhi(0,1)$, the characteristic function of the unit interval. Clearly f \\nin Y, but f \\in X. Also, T_n(f)\\to f in L^1, and hence the limiting function is “not in” Y, and there is no limit for the operators T_n:X\\to Y.")

#text("Fixes: Obviously if you replace Y with a banach space L^1, then T_n\\to Id (Identity). 3\\to2 would be the only part requiring this. Another fix: Adjust the assumptions and assume in addition to convergence that there is some a priori limiting operator. Say if we assume that T_n \\to T on a dense set and $T: X\\to Y$ is some bounded linear operator, then the problem also disappears. In the above example e.g. take T_n f = f*\\phi_n – f*\\phi_{n+1}, then $T_n(y)\\to 0$ on a dense set and in fact $T_n(x)\\to 0$ everywhere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-243525")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("Thanks, I have corrected the corollary accordingly (by requiring the range Y to be a Banach space).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-447084")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2014")])]

#text("“We now invoke the following easy observation: if E is nowhere dense, then every ball B contains a subball B’ which is disjoint from E. Indeed, this follows immediately from the definition of a nowhere dense set.”")

#text("By “disjoint”, do you mean the intersection is empty or the distance is positive?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-447086")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2014")])]

#text("I don’t see why “this follows immediately from the definition of a nowhere dense set”…")

#text("Suppose there is a ball ")#mi("B")#text(" such that every subball ")#mi("B^{\\prime}")#text(" of ")#mi("B")#text(" is such that ")#mi("B^{\\prime}\\cap E\\not=\\emptyset")#text(". How would this contradicts the definition of ")#mi("E")#text("?")

#text("Following the definition, one can see that ")#mi("\\overline{E}^c")#text(" is a nonempty open set, and thus there exists a ball ")#mi("B")#text(" which is disjoint from ")#mi("E")#text(". It seems that the quoted observation above is stronger.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-447089")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2014")])]

#text("If ")#mi("B")#text(" has the above property, then every element of ")#mi("B")#text(" is an adherent point of ")#mi("E")#text(", and thus ")#mi("\\overline{E}")#text(" contains the ball ")#mi("B")#text(", contradicting the nowhere dense nature of ")#mi("E")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-460577")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2015")])]

#text("In the proof of Theorem 2:")

#text("The hypothesis 1 is nothing more than the assertion that the ")#mi("E_n")#text(" cover ")#mi("X")#text(", and ")#emph[#text("thus by the Baire category theorem must be dense in a ball")]#text(".")

#text("Do you mean that one of the ")#mi("E_n")#text(" (instead “all of them”) must be dense in some ball? Or do you mean (trivially) that the union of them is dense in a ball?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-460586")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2015")])]

#text("In the statement of theorem 5, “then” is missing.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c50e5f1f8109cc87a6a3394a68e11c763b6092dcb32a39c8ede2899c1d295ac7-43b5289b51f93c075c052b51197fc2a7f761321fdc8daaea8bbb8d7f7c9c8bdf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sunting")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-473841")[#strong[#text("Sunting")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2016")])]

#text("dear prof tao. i don’t know how to use the triangle inequality to get (4) to get(5) in Remark 2. i think the “Tam” in the left side of (4) should be “Tan” instead(then it is possible to use the triangle inequality). but i am not sure.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c50e5f1f8109cc87a6a3394a68e11c763b6092dcb32a39c8ede2899c1d295ac7-43b5289b51f93c075c052b51197fc2a7f761321fdc8daaea8bbb8d7f7c9c8bdf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sunting")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-473870")[#strong[#text("Sunting")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2016")])]

#text("in example 2. c0(N) is interpreted as sequence (a_n) and a_n goes to 0 as n is going to infinity. so i don’t think T is well-defined. since T(an) may not be in c0(N)?! we pick (an)=(1,1/2,1/3,…), then T(an)=(1,1,…) which is not in c0(N)")

#emph[#text("[")#mi("c_0")#text(" here should have been ")#mi("c_c")#text(" – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c06b5c608061b3433364d7a08c276448981d7dbe3ec5a42a3c2cf5097f6a6116-b2064c0da56b72183b36a8e311c8403011196cba9557b86b4ddceb8d838b15a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-474220")[#strong[#text("Ian")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2016")])]

#text("Professor Tao:")

#text("What is the Hahn-Banach Theorem used for in Exercise 6?")

#emph[#text("[It is not used, and the reference to it has been removed – T.] ")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-476379")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2017")])]

#text("If a measure space also has the metric space structure, are there any relations between null sets and nowhere dense sets?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-476382")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2017")])]

#text("Oh, this is a stupid question. Examples have been given in the notes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-476380")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2017")])]

#text("In Theorem 1: Is “the countable union of nowhere dense sets cannot contain a ball” the same as “the countable union of nowhere dense sets is nowhere dense”? (Just like the countable union of null sets is null sets.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-476383")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2017")])]

#text("At the end of the proof of Baire category theorem, I think you mean “in particular ")#mi("x")#text(" is an element of ")#mi("B(x_0,r_0)")#text("” instead of B.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68525eeef0b8be390448accbdb835d01053a5e170bda43ff21390d4eb333f5f0-2724c66ddcf5d64e021a65fe20d899b7c415447b4cd14da303fcad5f18bcc4fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CA")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-478453")[#strong[#text("CA")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2017")])]

#text("1) It seems to me that the remark 3 contains a mistake. Convergent nets need not be bounded in general. We only have the (very useful) 3) ->2)->1). The implication 1) -> 3) seems problematic.")

#text("2) In the proof of Corollary, it is “Theorem 2” instead of “Theorem 1”.")

#text("3) In Corollary 1, a “Tx” is not in mathematical mode.")

#emph[#text("[Corrected, thanks. I do not see a quick way to recover the implication of 1 from 3, so it is probably best to just delete the remark. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jochen Wengenroth")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-479621")[#strong[#text("Jochen Wengenroth")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2017")])]

#text("There is another interesting aspect of the open mapping theorem: It is enough to require “quantitative approximate solutions”: There are ")#mi("a \\in [0,1)")#text(" and ")#mi("b\\in[0,\\infty)")#text(" such that for each ")#mi("y \\in Y")#text(" there is ")#mi("x \\in X")#text(" with ")#tao-math("\\left\\|y-L(x)\\right\\| \\le a \\left\\|y\\right\\|", block: false)#text(" and ")#tao-math("\\left\\|x\\right\\| \\le b \\left\\|y\\right\\|", block: false)#text(". Then you get quantitative solvability with ")#mi("C=b/(1-a)")#text(".")

#text("For example, the Tietze-Urysohn theorem can be proved with this condition for ")#mi("a=2/3")#text(" and ")#mi("b=1/3")#text(". There are also non-linear versions for complete metric spaces of this principle (Schauder lemma).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-498087")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2018")])]

#text("In Example 1, it is said that")

#text("“As ")#mi("C^\\infty_0({\\Bbb R})")#text(" is known to be dense in ")#mi("L^2({\\Bbb R)}")#text("“.")

#text("I can’t find this result in the previous notes. Would you elaborate?")

#text("(As I go through the 245ABC series of notes, I find that results used are not necessarily in a strictly logical order, which is emphasized strongly in your two volumes of Analysis books. Is it intentional?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-498192")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2018")])]

#text("See Exercise 1 of ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")]#text(" (this should also help answer your other question). I do eventually plan to revise the book form of these notes, in which I will change the order in which certain topics are introduced. (One reason for the discrepancy is that I actually taught and wrote notes for 245BC before I taught 245A.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/437582f5fcc47c60e8443dd7e43e82007954e55065d9ca0274c8ed6770b8a47c-ab8e61d1ee7b7041f95b5d1a6a21f59612ca92156bb4e39f550c703e6be452f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Debajyoti Choudhuri")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-503821")[#strong[#text("Debajyoti Choudhuri")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2018")])]

#text("Dear Prof Tao,")

#text("I am not sure but I cannot see why there has to exist at least one $E_n$ such that it is dense in a subball $B’$.")

#text("Thank you")#linebreak()#text(" DJ")

#emph[#text("[Take contrapositives (or argue by contradiction) – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/437582f5fcc47c60e8443dd7e43e82007954e55065d9ca0274c8ed6770b8a47c-ab8e61d1ee7b7041f95b5d1a6a21f59612ca92156bb4e39f550c703e6be452f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Debajyoti Choudhuri")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-503830")[#strong[#text("Debajyoti Choudhuri")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2018")])]

#text("I am sorry for this naive question but then shouldn’t it be the other way, i.e. there exists a subball B’ which is sitting in some E_n as a dense subset?.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/437582f5fcc47c60e8443dd7e43e82007954e55065d9ca0274c8ed6770b8a47c-ab8e61d1ee7b7041f95b5d1a6a21f59612ca92156bb4e39f550c703e6be452f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Debajyoti Choudhuri")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-503848")[#strong[#text("Debajyoti Choudhuri")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2018")])]

#text("or should it be “Let E_1, E_2, \\ldots be an at most countable sequence of nowhere dense subsets…” instead of “Let E_1, E_2, \\ldots be an at most countable sequence of subsets…”?.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-503866")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2018")])]

#text("Depends on whether you are using the first form of the Baire Category theorem or the second (they are essentially contrapositives of each other). The proof given in the blog post is for the second form, but this quickly implies the first form also.")

#text("First form: Let ")#mi("E_1,E_2,\\dots")#text(" be an at most countable sequence of subsets of a complete metric space ")#mi("X")#text(". If ")#mi("\\bigcup_n E_n")#text(" contains a ball ")#mi("B")#text(", then one of the ")#mi("E_n")#text(" is dense in a sub-ball ")#mi("B^{\\prime}")#text(" of ")#mi("B")#text(".")

#text("Second form: Let ")#mi("E_1,E_2,\\dots")#text(" be an at most countable sequence of nowhere dense subsets of a complete metric space ")#mi("X")#text(". Then ")#mi("\\bigcup_n E_n")#text(" cannot contain a ball.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/437582f5fcc47c60e8443dd7e43e82007954e55065d9ca0274c8ed6770b8a47c-ab8e61d1ee7b7041f95b5d1a6a21f59612ca92156bb4e39f550c703e6be452f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Debajyoti Choudhuri")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-503871")[#strong[#text("Debajyoti Choudhuri")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2018")])]

#text("Thank you very much.:)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/437582f5fcc47c60e8443dd7e43e82007954e55065d9ca0274c8ed6770b8a47c-ab8e61d1ee7b7041f95b5d1a6a21f59612ca92156bb4e39f550c703e6be452f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Debajyoti Choudhuri")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-503822")[#strong[#text("Debajyoti Choudhuri")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2018")])]

#text("PS: My question is for the Theorem 1 (Baire category theorem).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-516879")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2019")])]

#text("how do we prove that a metric space X is of 2nd Baire category. Like what is it that we are suppose to show")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 247B, Notes 4: almost everywhere convergence of Fourier series | What's new")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-559714")[#strong[#text("247B, Notes 4: almost everywhere convergence of Fourier series | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2020")])]

#text("[…] Calderón) is similar in spirit to the uniform boundedness principle (see e.g. Corollary 1 of this previous blog post). The restriction is needed for just one implication (from (iii) to (ii)) in the arguments below, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a4e862e411af35c4243c9a9f9a79daefa671006463291d79788ac05b2913bf-988f1beec5199d6bf39fff81e0b3f82338377e1459b63d9eb92e510cfdf0d3a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-606910")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2020")])]

#text("Sir, in the proof of open mapping theorem I am not getting the following point :-")#linebreak()#text(" By subtracting two such approximate solutions, we conclude that")#linebreak()#text(" For any f \\in B(0,2r) and any \\varepsilon > 0, there exists u \\in X with \\|Lu – f \\|_Y \\leq 2\\varepsilon and \\|u\\|_X \\leq 2nr + 2 n \\varepsilon.")#linebreak()#text(" Can you help me littile bit to understand this conclusion.")#linebreak()#text(" Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-607226")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2020")])]

#text("Any ")#mi("f \\in B(0,2r)")#text(" can be written as the difference ")#mi("f = f_1 - f_2")#text(" of two elements ")#mi("f_1,f_2")#text(" of ")#mi("B(f_0,r)")#text(". Apply the hypothesis to find approximate solutions ")#mi("u_1, u_2")#text(" to ")#mi("Lu_1 \\approx f_1, Lu_2 \\approx f_2")#text(" respectively and then subtract.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b488df94717a94de73656e78f48c2637cf97a3d7c6ce7400d1d37a6fe76a84a7-eff86ee9a4f347d3383f5ac80499c7f10f3a5c1106cef5b23be9cc9a6568adf5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mayoorathy Vishagan")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-677392")[#strong[#text("Mayoorathy Vishagan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2023")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Can you please explain a bit what you mean in “general” and in this case by the term “regularity”. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d82ab8c75ff4179180ccadfc7f735800f7e3f98ed6ef9b700ccd05f8d7c9881-77e96c15c4becc0d855771548a4e6e1c7e9ac00e02aac04e2558c70cbc1eadf5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vi")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-677423")[#strong[#text("Vi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2023")])]

#text("In remark (2), I don’t see how you can choose the signs such that the inequality holds? Are we using some property of conditional sums?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/01/245b-notes-9-the-baire-category-theorem-and-its-banach-space-consequences/comment-page-1/#comment-677504")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2023")])]

#text("This is a vector-valued version of the pigeonhole principle, and can be proven by contradiction and the triangle inequality.")
]
]
