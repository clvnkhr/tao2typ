// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/
// Converted to Typst by tao2typ: "2026-10-14T15:18:01.540128+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The shallow water wave equation and tsunami propagation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The shallow water wave equation and tsunami propagation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 March 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/")[#text("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("As we are all now very much aware, ")#link("http://en.wikipedia.org/wiki/Tsunami")[#text("tsunamis")]#text(" are water waves that start in the deep ocean, usually because of an underwater earthquake (though tsunamis can also be caused by underwater landslides or volcanoes), and then propagate towards shore. Initially, tsunamis have relatively small amplitude (a metre or so is typical), which would seem to render them as harmless as ")#link("http://en.wikipedia.org/wiki/Wind_wave")[#text("wind waves")]#text(". And indeed, tsunamis often pass by ships in deep ocean without anyone on board even noticing.")

#text("However, being generated by an event as large as an earthquake, the ")#emph[#text("wavelength")]#text(" of the tsunami is huge – 200 kilometres is typical (in contrast with wind waves, whose wavelengths are typically closer to 100 metres). In particular, the wavelength of the tsunami is far greater than the depth of the ocean (which is typically 2-3 kilometres). As such, even in the deep ocean, the dynamics of tsunamis are essentially governed by the ")#link("http://en.wikipedia.org/wiki/Shallow_water_equations")[#text("shallow water equations")]#text(". One consequence of these equations is that the speed of propagation ")#mi("{v}")#text(" of a tsunami can be approximated by the formula ")#metadata(none) <tao-47a17b8be1ef95baa3a9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("v \\approx \\sqrt{g b}")]]

#text("where ")#mi("{b}")#text(" is the depth of the ocean, and ")#mi("{g \\approx 9.8 ms^{-2}}")#text(" is the force of gravity. As such, tsunamis in deep water move ")#emph[#text("very")]#text(" fast – speeds such as 500 kilometres per hour (300 miles per hour) are quite typical; enough to travel from Japan to the US, for instance, in less than a day. Ultimately, this is due to the incompressibility of water (and conservation of mass); the massive net pressure (or more precisely, spatial variations in this pressure) of a very broad and deep wave of water forces the profile of the wave to move horizontally at vast speeds. (Note though that this is the ")#link("http://en.wikipedia.org/wiki/Phase_velocity")[#text("phase velocity")]#text(" of the tsunami wave, and not the velocity of the water molecues themselves, which are far slower.)")

#text("As the tsunami approaches shore, the depth ")#mi("{b}")#text(" of course decreases, causing the tsunami to slow down, at a rate proportional to the square root of the depth, as per ")#link(<tao-47a17b8be1ef95baa3a9>)[#text("(1)")]#text(". Unfortunately, ")#link("http://en.wikipedia.org/wiki/Wave_shoaling")[#text("wave shoaling")]#text(" then forces the amplitude ")#mi("{A}")#text(" to increase at an inverse rate governed by ")#emph[#text("Green’s law")]#text(", ")#metadata(none) <tao-ee6474aa634fa43e3c65>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("A \\propto \\frac{1}{b^{1/4}}")]]

#text("at least until the amplitude becomes comparable to the water depth (at which point the assumptions that underlie the above approximate results break down; also, in two (horizontal) spatial dimensions there will be some decay of amplitude as the tsunami spreads outwards). If one starts with a tsunami whose initial amplitude was ")#mi("{A_0}")#text(" at depth ")#mi("{b_0}")#text(" and computes the point at which the amplitude ")#mi("{A}")#text(" and depth ")#mi("{b}")#text(" become comparable using the proportionality relationship ")#link(<tao-ee6474aa634fa43e3c65>)[#text("(2)")]#text(", some high school algebra then reveals that at this point, amplitude of a tsunami (and the depth of the water) is about ")#mi("{A_0^{4/5} b_0^{1/5}}")#text(". Thus, for instance, a tsunami with initial amplitude of one metre at a depth of 2 kilometres can end up with a final amplitude of about 5 metres near shore, while still traveling at about ten metres per second (35 kilometres per hour, or 22 miles per hour), and we have all now seen the impact that can have when it hits shore.")

#text("While tsunamis are far too massive of an event to be able to control (at least in the deep ocean), we can at least model them mathematically, allowing one to predict their impact at various places along the coast with high accuracy. (For instance, ")#link("http://nctr.pmel.noaa.gov/honshu20110311/")[#text("here is a video")]#text(" of the NOAA’s model of the March 11 tsunami, which has matched up very well with subsequent measurements.) The full equations and numerical methods used to perform such models are somewhat sophisticated, but by making a large number of simplifying assumptions, it is relatively easy to come up with a rough model that already predicts the basic features of tsunami propagation, such as the velocity formula ")#link(<tao-47a17b8be1ef95baa3a9>)[#text("(1)")]#text(" and the amplitude proportionality law ")#link(<tao-ee6474aa634fa43e3c65>)[#text("(2)")]#text(". I give this (standard) derivation below the fold. The argument will largely be heuristic in nature; there are very interesting analytic issues in actually justifying many of the steps below rigorously, but I will not discuss these matters here.")

#metadata(none) <tao-d7f2f5c1316fe9937131>

#heading(level: 1)[#strong[#text(" — 1. The shallow water wave equation — ")]]

#text("The ocean is, of course, a three-dimensional fluid, but to simplify the analysis we will consider a two-dimensional model in which the only spatial variables are the horizontal variable ")#mi("{x}")#text(" and the vertical variable ")#mi("{z}")#text(", with ")#mi("{z=0}")#text(" being equilibrium sea level. We model the ocean floor by a curve")

#align(center)[#tao-fit-display[#mitex("z = - b(x),")]]

#text("thus ")#mi("{b}")#text(" measures the depth of the ocean at position ")#mi("{x}")#text(". At any time ")#mi("{t}")#text(" and position ")#mi("{x}")#text(", the height of the water (compared to sea level ")#mi("{z=0}")#text(") will be given by an unknown height function ")#mi("{h(t,x)}")#text("; thus, at any time ")#mi("{t}")#text(", the ocean occupies the region")

#align(center)[#tao-fit-display[#mitex("\\Omega_t := \\{ (x,z): -b(x) < z < h(t,x) \\}.")]]

#text("Now we model the motion of water inside the ocean by assigning at each time ")#mi("{t}")#text(" and each point ")#mi("{(x,z) \\in \\Omega_t}")#text(" in the ocean, a velocity vector")

#align(center)[#tao-fit-display[#mitex("\\vec u(t,x,z) = (u_x(t,x,z), u_z(t,x,z)).")]]

#text("We make the basic assumption of ")#emph[#text("incompressibility")]#text(", so that the density ")#mi("{\\rho}")#text(" of water is constant throughout ")#mi("{\\Omega_t}")#text(".")

#text("The velocity changes over time according to Newton’s second law ")#mi("{F=ma}")#text(". To apply this law to fluids, we consider an infinitesimal amount of water as it flows along the velocity field ")#mi("{\\vec u}")#text(". Thus, at time ")#mi("{t}")#text(", we assume that this amount of water occupies some infinitesimal area ")#mi("{dA}")#text(" and some position ")#mi("{\\vec x(t) = (x(t), z(t))}")#text(", where we have")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} \\vec x(t) = \\vec u( t, \\vec x(t) ).")]]

#text("Because of incompressibility, the area ")#mi("{dA}")#text(" stays constant, and the mass of this infinitesimal portion of water is ")#mi("{m = \\rho dA}")#text(". There will be two forces on this body of water; the force of gravity, which is ")#mi("{(0, -mg) = (0, -\\rho) dA}")#text(", and the force of the pressure field ")#mi("{p(t,x,z)}")#text(", which is given by ")#mi("{-\\nabla p dA}")#text(". At the length and time scales of a tsunami, we can neglect the effect of other forces such as viscosity or surface tension. Newton’s law ")#mi("{m \\frac{du}{dt} = F}")#text(" then gives")

#align(center)[#tao-fit-display[#mitex("m \\frac{d}{dt} \\vec u(t, \\vec x(t) ) = - \\nabla p dA + (0,-mg)")]]

#text("which simplifies to the ")#link("http://en.wikipedia.org/wiki/Euler_equations_(fluid_dynamics)")[#text("incompressible Euler equation")]

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial t} \\vec u + (\\vec u \\cdot \\nabla) \\vec u = - \\frac{1}{\\rho} \\nabla p + (0,-g).")]]

#text("At present, the pressure is not given. However, we can simplify things by making the assumption of ")#link("http://en.wikipedia.org/wiki/Hydrostatic_equilibrium")[#text("(vertical) hydrostatic equilibrium")]#text(", i.e. the vertical effect ")#mi("{ - \\frac{1}{\\rho} \\frac{\\partial}{\\partial z} p}")#text(" of pressure cancels out the effect ")#mi("{-g}")#text(" of gravity. We also assume that the pressure is zero on the surface ")#mi("{z=h(t,x)}")#text(" of the water. Together, these two assumptions force the pressure to be the ")#link("http://en.wikipedia.org/wiki/Hydrostatic_pressure#Hydrostatic_pressure")[#text("hydrostatic pressure")]#text(" ")#metadata(none) <tao-cd97f89119a014115f39>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("p = \\rho g ( h(t,x) - z ).")]]

#text("This reflects the intuitively plausible fact that the pressure at a point under the ocean should be determined by the weight of the water above that point.")

#text("The incompressible Euler equation now simplifies to ")#metadata(none) <tao-5afab9a620f6f1128450>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\frac{\\partial}{\\partial t} \\vec u + (\\vec u \\cdot \\nabla) \\vec u = - g (\\frac{\\partial}{\\partial x} h, 0).")]]

#text("We next make the ")#link("http://en.wikipedia.org/wiki/Shallow_water_equations")[#text("shallow water")]#text(" approximation that the wavelength of the water is far greater than the depth of the water. In particular, we do not expect significant changes in the velocity field in the ")#mi("{z}")#text(" variable, and thus make the ansatz ")#metadata(none) <tao-b944fc0984e689314e11>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\vec u(t,x,z) \\approx \\vec u(t,x).")]]

#text("(This ansatz should be taken with a grain of salt, particularly when applied to the ")#mi("{z}")#text(" component ")#mi("{u_z}")#text(" of the velocity, which does actually have to fluctuate a little bit to accomodate changes in ocean depth and in the height function. However, the primary component of the velocity is the horizontal component ")#mi("{u_x}")#text(", and this does behave in a fairly vertically insensitive fashion in actual tsunamis.)")

#text("Taking the ")#mi("{x}")#text(" component of ")#link(<tao-5afab9a620f6f1128450>)[#text("(4)")]#text(", and abbreviating ")#mi("{u_x}")#text(" as ")#mi("{u}")#text(", we obtain the first shallow water wave equation ")#metadata(none) <tao-91d80a4942da5b036e4a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\frac{\\partial}{\\partial t} u + u \\frac{\\partial}{\\partial x} u = - g \\frac{\\partial}{\\partial x} h.")]]

#text("The next step is to play off the incompressibility of water against the finite depth of the ocean. Consider an infinitesimal slice")

#align(center)[#tao-fit-display[#mitex("\\{ (x,z) \\in \\Omega_t: x_0 \\leq x \\leq x_0+dx \\}")]]

#text("of the ocean at some time ")#mi("{t}")#text(" and position ")#mi("{x_0}")#text(". The total mass of this slice is roughly")

#align(center)[#tao-fit-display[#mitex("\\rho (h(t,x_0) + b(x_0)) dx")]]

#text("and so the rate of change of mass of this slice over time is")

#align(center)[#tao-fit-display[#mitex("\\rho \\frac{\\partial h}{\\partial t}(t,x_0) dx.")]]

#text("On the other hand, the rate of mass entering this slice on the left ")#mi("{x=x_0}")#text(" is")

#align(center)[#tao-fit-display[#mitex("\\rho u(t,x_0) (h(t,x_0) + b(x_0))")]]

#text("and the rate of mass exiting on the right ")#mi("{x=x_0+dx}")#text(" is")

#align(center)[#tao-fit-display[#mitex("\\rho u(t,x_0+dx) (h(t,x_0+dx) + b(x_0+dx)).")]]

#text("Putting these three facts together, we obtain the equation")

#tao-aligned(keep: true)[


#tao-math("\\rho \\frac{\\partial h}{\\partial t}(t,x_0) dx  & = \\rho u(t,x_0) (h(t,x_0) + b(x_0))", block: true)



#tao-math(" & - \\rho u(t,x_0+dx) (h(t,x_0+dx) + b(x_0+dx))", block: true)
]

#text("which simplifies after Taylor expansion to the second shallow water wave equation ")#metadata(none) <tao-ab887a84dd24e7eb98ee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\frac{\\partial}{\\partial t} h + \\frac{\\partial}{\\partial x}( u (h+b) ) = 0.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Another way to derive ")#link(<tao-ab887a84dd24e7eb98ee>)[#text("(7)")]#text(" is to use a more familiar form of the incompressibility, namely the divergence-free equation ")#metadata(none) <tao-cd35a2426062b7d58fd4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\frac{\\partial}{\\partial x} u_x + \\frac{\\partial}{\\partial z} u_z = 0.")]]

#text("(Here we will refrain from applying ")#link(<tao-b944fc0984e689314e11>)[#text("(5)")]#text(" to the vertical component of the velocity ")#mi("{u_z}")#text(", as the approximation ")#link(<tao-b944fc0984e689314e11>)[#text("(5)")]#text(" is not particularly accurate for this component.) Also, by considering the trajectory of a particle ")#mi("{(x(t),h(t,x(t)))}")#text(" at the surface of the ocean, we have the formulae")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} x(t) = u_x(x(t),h(t,x(t)))")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} h(t,x(t)) = u_z(x(t),h(t,x(t)))")]]

#text("which after application of the chain rule gives the equation ")#metadata(none) <tao-28720365c5e7476a011e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\frac{\\partial}{\\partial t} h(t,x) + (\\frac{\\partial}{\\partial x} h( x )) u_x( x, h(t,x) ) = u_z( x, h(t,x) ).")]]

#text("A similar analysis at the ocean floor (which does not vary in time) gives ")#metadata(none) <tao-be9b7607e070383c083b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("-\\frac{\\partial}{\\partial x} b( x ) u_x( x, -b(x) ) = u_z( x, -b(x) ).")]]

#text("We apply these equations to the evaluation of the expression")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial x} \\int_{-b(x)}^{h(t,x)} u_x( t, x, z )\\ dz.")]]

#text("which is the spatial rate of change of the velocity flux through a vertical slice of the ocean. On the one hand, using the ansatz ")#link(<tao-b944fc0984e689314e11>)[#text("(5)")]#text(", we expect this expression to be approximately")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial x} ( u (h+b) ).")]]

#text("On the other hand, by differentiation under the integral sign, we can evaluate this expression instead as")

#align(center)[#tao-fit-display[#mitex("\\int_{-b(x)}^{h(t,x)} \\frac{\\partial}{\\partial x} u_x( t, x, z)\\ dz")]]

#align(center)[#tao-fit-display[#mitex("+ (\\frac{\\partial}{\\partial x} h(t,x)) u_x(x, h(t,x))")]]

#align(center)[#tao-fit-display[#mitex("+ (\\frac{\\partial}{\\partial x} b(x)) u_x(x, -b(x)).")]]

#text("If we then substitute in ")#link(<tao-cd35a2426062b7d58fd4>)[#text("(8)")]#text(", ")#link(<tao-28720365c5e7476a011e>)[#text("(9)")]#text(", ")#link(<tao-be9b7607e070383c083b>)[#text("(10)")]#text(" and apply the fundamental theorem of calculus, one ends up with ")#mi("{-\\frac{\\partial}{\\partial t}h(t,x)}")#text(", and the claim ")#link(<tao-ab887a84dd24e7eb98ee>)[#text("(7)")]#text(" follows.")
]

#text("The equations ")#link(<tao-91d80a4942da5b036e4a>)[#text("(6)")]#text(", ")#link(<tao-ab887a84dd24e7eb98ee>)[#text("(7)")]#text(" are nonlinear in the unknowns ")#mi("{u, h}")#text(". However, one can approximately linearise them by making the hypothesis that the amplitude of the wave is small compared to the depth of the water: ")#metadata(none) <tao-6e533337bd970a97d7ac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left|h\\right| \\ll b.", block: true)]]

#text("This hypothesis is fairly accurate for tsunamis in the deep ocean, and even for medium depths, but of course is not reasonable once the tsunami has reached shore (where the dynamics are far more difficult to model).")

#text("The hypothesis ")#link(<tao-6e533337bd970a97d7ac>)[#text("(11)")]#text(" already simplifies ")#link(<tao-ab887a84dd24e7eb98ee>)[#text("(7)")]#text(" to (approximately) ")#metadata(none) <tao-5ba6eeb729b286b57f28>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\frac{\\partial}{\\partial t} h + \\frac{\\partial}{\\partial x}( u b ) = 0.")]]

#text("As for ")#link(<tao-91d80a4942da5b036e4a>)[#text("(6)")]#text(", we argue that the second term on the left-hand side is negligible, leading to ")#metadata(none) <tao-89a9f8c1515bcf25cd4d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\frac{\\partial}{\\partial t} u = - g \\frac{\\partial}{\\partial x} h.")]]

#text("To explain heuristically why we expect this to be the case, let us make the ansatz that ")#mi("{h}")#text(" and ")#mi("{u}")#text(" have amplitude ")#mi("{A}")#text(", ")#mi("{V}")#text(" respectively, and propagate at some ")#link("http://en.wikipedia.org/wiki/Phase_velocity")[#text("phase velocity")]#text(" ")#mi("{v}")#text(" and wavelength ")#mi("{\\lambda}")#text("; let us also make the (reasonable) assumption that ")#mi("{b}")#text(" varies much slower in space than ")#mi("{u}")#text(" does (i.e. that ")#mi("{b}")#text(" is roughly constant at the scale of the wavelength ")#mi("{\\lambda}")#text("), so we may (for a first approximation) replace ")#mi("{\\frac{\\partial}{\\partial x}(ub)}")#text(" by ")#mi("{b \\frac{\\partial}{\\partial x} u}")#text(". Heuristically, we then have")

#tao-aligned(keep: true)[


#tao-math("\\frac{\\partial}{\\partial x} u  & = O(V/\\lambda)", block: true)



#tao-math("\\frac{\\partial}{\\partial x} h  & = O(A/\\lambda)", block: true)



#tao-math("\\frac{\\partial}{\\partial t} u  & = O(vV/\\lambda)", block: true)



#tao-math("\\frac{\\partial}{\\partial t} h  & = O(vA/\\lambda)", block: true)
]

#text("and equation ")#link(<tao-5ba6eeb729b286b57f28>)[#text("(12)")]#text(" then suggests ")#metadata(none) <tao-97dfc65f74283f60c606>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("vA/\\lambda \\approx V b/\\lambda.")]]

#text("From ")#link(<tao-6e533337bd970a97d7ac>)[#text("(11)")]#text(" we expect ")#mi("{A \\ll b}")#text(", and thus ")#mi("{v \\gg V}")#text("; the wave propagates much faster than the velocity of the fluid. In particular, we expect ")#mi("{u \\frac{\\partial}{\\partial x} u = O(V^2 / \\lambda)}")#text(" to be much smaller than ")#mi("{\\frac{\\partial}{\\partial t} u = O( v V/\\lambda)}")#text(", which explains why we expect to drop the second term in ")#link(<tao-91d80a4942da5b036e4a>)[#text("(6)")]#text(" to obtain ")#link(<tao-89a9f8c1515bcf25cd4d>)[#text("(13)")]#text(".")

#text("If we now insert the above ansatz into ")#link(<tao-89a9f8c1515bcf25cd4d>)[#text("(13)")]#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("v V/\\lambda \\approx g A / \\lambda;")]]

#text("combining this with ")#link(<tao-97dfc65f74283f60c606>)[#text("(14)")]#text(", we already get the velocity relationship ")#link(<tao-47a17b8be1ef95baa3a9>)[#text("(1)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can also obtain ")#link(<tao-47a17b8be1ef95baa3a9>)[#text("(1)")]#text(" more quickly (up to a loss of a constant factor) by ")#link("http://en.wikipedia.org/wiki/Dimensional_analysis")[#text("dimensional analysis")]#text(", together with some additional physical arguments. Indeed, it is clear from a superficial scan of the above discussion that the velocity ")#mi("{v}")#text(" is only going to depend on the quantities ")#mi("{\\rho, g, b, A, V, \\lambda}")#text(". As the density ")#mi("{\\rho}")#text(" is the only input that involves mass in its units, dimensional analysis already rules out any role for ")#mi("{\\rho}")#text(". As we are in the small amplitude regime ")#link(<tao-6e533337bd970a97d7ac>)[#text("(11)")]#text(", we expect the dynamics to be linearised, and thus not dependent on amplitude; this rules out ")#mi("{A}")#text(" (and similarly ")#mi("{V}")#text(", which is the amplitude of the velocity field, and which is negligible when compared against the phase velocity ")#mi("{v}")#text("). Finally, in the long wavelength regime ")#mi("{\\lambda \\gg b}")#text(", we expect the wavelength to be physically undetectable at local scales (it requires not only knowledge of the slope of the height function at one’s location, but also the second derivative of that function (i.e. the curvature of the ocean surface), which is lower order). So we rule out dependence on ")#mi("{\\lambda}")#text(" also, leaving only ")#mi("{g}")#text(" and ")#mi("{b}")#text(", and at this point dimensional analysis forces the relationship ")#link(<tao-47a17b8be1ef95baa3a9>)[#text("(1)")]#text(" up to constants. (Unfortunately, I do not know of an analogous dimensional analysis argument that gives ")#link(<tao-ee6474aa634fa43e3c65>)[#text("(2)")]#text(".)")
]

#text("To get the relation ")#link(<tao-ee6474aa634fa43e3c65>)[#text("(2)")]#text(", we have to analyse the ansatz a bit more carefully. First, we combine ")#link(<tao-89a9f8c1515bcf25cd4d>)[#text("(13)")]#text(" and ")#link(<tao-5ba6eeb729b286b57f28>)[#text("(12)")]#text(" into a single equation for the height function ")#mi("{h}")#text(". Indeed, differentiating ")#link(<tao-5ba6eeb729b286b57f28>)[#text("(12)")]#text(" in time and then substituting in ")#link(<tao-89a9f8c1515bcf25cd4d>)[#text("(13)")]#text(" and ")#link(<tao-47a17b8be1ef95baa3a9>)[#text("(1)")]#text(" gives")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial^2}{\\partial t^2} h - \\frac{\\partial}{\\partial x}( v^{2} \\frac{\\partial}{\\partial x} h ) = 0.")]]

#text("To solve this wave equation, we use a standard sinusoidal ansatz")

#align(center)[#tao-fit-display[#mitex("h(t,x) = A(t,x) \\sin( \\phi( t, x ) / \\epsilon )")]]

#text("where ")#mi("{A, \\phi}")#text(" are slowly varying functions, and ")#mi("{\\epsilon > 0}")#text(" is a small parameter. Inserting this ansatz and extracting the top order terms in ")#mi("{\\epsilon}")#text(", we conclude the eikonal equation")

#align(center)[#tao-fit-display[#mitex("\\phi_t^2 - v^{2} \\phi_x^2 = 0")]]

#text("and the Hamilton-Jacobi equation")

#align(center)[#tao-fit-display[#mitex("2 A_t \\phi_t + A \\phi_{tt} - v^2 (2A_x \\phi_x + A \\phi_{xx}) - 2vv_x A \\phi_x = 0.")]]

#text("From the eikonal equation we see that ")#mi("{\\phi}")#text(" propagates at speed ")#mi("{v}")#text(". Assuming rightward propagation, we thus have ")#metadata(none) <tao-76f2793073ed4fecc757>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\phi_t = -v \\phi_x.")]]

#text("As for the Hamilton-Jacobi equation, we solve it using the method of characteristics. Multiplying the equation by ")#mi("{A}")#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("(A^2 \\phi_t)_t - v^2 (A^2 \\phi_x)_x - 2vv_x A^2 \\phi_x = 0.")]]

#text("Inserting ")#link(<tao-76f2793073ed4fecc757>)[#text("(15)")]#text(" and writing ")#mi("{F := A^2 \\phi_x}")#text(", one obtains")

#align(center)[#tao-fit-display[#mitex("- v F_t - v^2 F_x - 2 v v_x F = 0")]]

#text("which simplifies to")

#align(center)[#tao-fit-display[#mitex("(\\partial_t + v \\partial_x) (v^2 F) = 0.")]]

#text("Thus we see that ")#mi("{v^2 F}")#text(" is constant along characteristics. On the other hand, differentiating ")#link(<tao-76f2793073ed4fecc757>)[#text("(15)")]#text(" in ")#mi("{x}")#text(" we see (after some rearranging) that")

#align(center)[#tao-fit-display[#mitex("(\\partial_t + v \\partial_x) ( v \\phi_x ) = 0")]]

#text("so ")#mi("{v \\phi_x}")#text(" is also constant along characteristics. Dividing, we see that ")#mi("{A^2 v}")#text(" is constant along characteristics, leading to the proportionality relationship")

#align(center)[#tao-fit-display[#mitex("A \\propto \\frac{1}{\\sqrt{v}}")]]

#text("which gives ")#link(<tao-ee6474aa634fa43e3c65>)[#text("(2)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" It becomes difficult to retain the sinusoidal ansatz once the amplitude exceeds the depth, as it leads to the absurd conclusion that the troughs of the wave lie below the ocean floor. However, a remnant of this effect can actually be seen in real-life tsunamis, namely that if the tsunami starts with a trough rather than a crest, then the water at the shore draws back at first (sometimes for hundreds of metres), before the crest of the tsunami hits. As such, the sudden withdrawal of water of a shore is an important warning sign of an immediate tsunami.")
]

#heading(level: 1)[#text("Comments (35)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/680171dc78c80bd8820dc89c6589ab936e646fe12cbe1b0adf01f5612fa70a88-14f626dfd791b19f757cff15bafa94be9184aea65306a62e5aa4da22acc50a2e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pencil")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-50719")[#strong[#text("Pencil")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2011")])]

#text("Thanks for the article. Good night!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of daf")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-50720")[#strong[#text("daf")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2011")])]

#text("This is nothing original. Go and predict an earthquake if you can.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efc2dfbb382eff6c6f866094a70c96103698f06894193d33d09e7ae96f096236-c6bfb64896dc3aaeacbee133696f5c24de5d6b6fca53974cb13bfe1614d22f96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shortstop")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-50734")[#strong[#text("shortstop")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2011")])]

#text("Yes, one finds shallow water equation and its application from fluid mechanics textbooks. I believe he puts here just for educational purposes and meanwhile He never said that’s an original work. You needn’t so offensive. Just be polite, please. BTW, he tried to describe tsunami and you mentioned earthquake which is totally different natural phenomena though the latter can cause the former.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-50773")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2011")])]

#text("it’s obvious where the down vote came from:)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/797b4d91cf8119211cd9368798285c98dbc1c4cadff0b98e72f2b17183d9a0d1-c17e9826217301c663a1d56992efb001e43a87b9a618d4e5e5ac1eeac02e7787.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rod Carvalho")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-50723")[#strong[#text("Rod Carvalho")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2011")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("thus ")#mi("d")#text(" measures the depth of the ocean at position ")#mi("x")
]

#text("Shouldn’t it be ")#mi("b")#text(" instead of ")#mi("d")#text("?")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e028e3544347e32ccff5c46770a132e1543d5946cdacf7db27efed070a525df-1a710a8a6a7c2d24ddbb58200e5e1e3bcae55aca7913c4b6c89dd40f29dd9a27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of math dictionary")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-50728")[#strong[#text("math dictionary")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2011")])]

#text("Nice.")#linebreak()#text(" Even the tsunami have so much details of mathematics.")#linebreak()#text(" I hope one day math and science will be able to predict tsunami before it comes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/679cf7d10da7e78738599f5f482af30611abe584111e2bc4944eb2e79ff34972-3df4d0ea9b92b29552fe9c7719ff274a9e940f606ef8e190635325858d16011d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Laurence")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-237594")[#strong[#text("Laurence")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2013")])]

#text("The Occurrence of Tsunami is hard to predict but since the cause can be determined, it can be known when the waves will arrive at the shore. I can make a better paper than this. You wait… his article is too nerdy but can be appreciated. I look in my book when I was just a kid, I saw ocean mapping being done by scientist. With development of certain technology we may know when the waves will come to the shoreline and when we can counter it. The force of water can be displaced…This is certain. So displacing the initial force that would cause a great wave to the shore is crucial.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85c53e1de514a7c82121a7a49fda776a2102ad137171e79bc18356c9bd327244-ce182f34a5864a0e115aabcf2b9bd224ab9572438f1b3c44cef12d5066b9a865.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathematicsnonentity")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-50737")[#strong[#text("mathematicsnonentity")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2011")])]

#text("Now here is what I want to know:Are Tsunamis solitons…quasi solitons ..if there is such a thing?")

#text("If the answer to the above is yes, does any of the mathematics in professors Tao’s post relate-in a nontrivial way to the KDV-equations and the hierarchy equations in general.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-50738")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2011")])]

#text("Well, solitons are large-amplitude (and thus nonlinear) phenomena, whereas tsunami propagation (in deep water, at least) is governed by low-amplitude (and thus essentially linear) equations. Typically, linear waves disperse due to the fact that the group velocity is usually sensitive to the wavelength; but in the tsunami regime, the group velocity is driven by pressure effects that relate to the depth of the ocean rather than the wavelength of the wave, and as such there is essentially no dispersion, thus creating traveling waves that have some superficial resemblance to solitons, but arise through a different mechanism.")

#text("It is true, though, that KdV also arises from a shallow water wave approximation. The main distinction seems to be that the shallow water equation comes from assuming that the pressure behaves like the hydrostatic pressure, whereas KdV arises if one assumes instead that the velocity is irrotational (which is definitely not the case for tsunami waves).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a5ee6500366cc7114b56eb2e701bb0c70d771386c77f6f93ad74aeca2428bad-bf9d7248570844f114387817137f0d07bf43fb74c1b1daea68924efa6f353acf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony Roberts")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-51077")[#strong[#text("Tony Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2011")])]

#text("I suspect that this answer may mislead. First, are tsunamis solitons? the answer depends how rigorous you want to be. Theoretically we do not know whether real tsunamis are true solitons. However, some of the video footage of the tsunami approaching Japan’s shore certainly show waves that I would like to call solitons. Further, classic approximate models like KdV or shallow water models also give soliton-like solutions. Might as well call them solitons then. Except it also depends upon initial conditions and the shoaling of the waves.")

#text("Do they arise through different mechanisms? I would not say so either. In classic scattering theory, solitons emerge from general compact disturbances (such as the local earthquake), but work also shows they emerge in shoaling, so the appearance of soliton-like waves on Japan’s shore looks like standard mechanisms at work.")

#text("On the distinction between KdV and shallow water waves: the classic derivation of the KdV for water waves is to take the shallow water wave equation and assume waves are only propagating in one direction. Thus the KdV is simply a restriction of shallow water wave equation and shares all its approximations, plus one more.")

#text("Finally, on a related but different issue: it strikes me as incongruous that our modelling for floods, tides, and tsunamis is based upon smooth, inviscid, irrotational flow when one can plainly see viscous turbulence in the flows. I have tried intermittently to base shallow water models on turbulent models, but it is difficult.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85c53e1de514a7c82121a7a49fda776a2102ad137171e79bc18356c9bd327244-ce182f34a5864a0e115aabcf2b9bd224ab9572438f1b3c44cef12d5066b9a865.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathematicsnonentity")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-50739")[#strong[#text("mathematicsnonentity")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2011")])]

#text("Professor Tao")

#text("Historical note:Korteweg and deVries famous equation was published a few months before the 1896 Tsunami that struck Japan killing thirty thousand Japanese.")

#text("The speed of propagation equation of a Tsunami is the same as the average speed of a Soliton…I think?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ViceRoy")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-50749")[#strong[#text("ViceRoy")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2011")])]

#text("Thx for information.")#linebreak()#text(" I’m studying Physical Oceanography in South Korea – near by Japan.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-50756")[#strong[#text("ETH Alumni Math • Phys » Mathematics and Tsunami Propagation")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2011")]

#text("[…] Nach den tragischen Ereignissen in Japan hat Terence Tao, Empfänger der Fields-Medaille 2006, einen Blogeintrag zur Fortbewegung von Tsunami-Wellen veröffentlicht. Die Mathematik und Physik der zerstörerischen Welle werden hauptsächlich durch hyperbolische partielle Differentialgleichungen, die sogenannten “shallow water equations”, und “wave shoaling” beschrieben. Den ausführlichen Eintrag findet ihr hier. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-50764")[#strong[#text("MSRI Workshop Day 2 (a week later!): Free boundary problems involving thin films «")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2011")]

#text("[…] Bertozzi. Incidentally, Terry Tao discussed the closely related shallow water wave equation in a blog plost […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b54f595ab93faa8e825a4e72bb1d19237bf4c5ce106520177301d7366c28efd0-5070deceffaa192d9d42c6dc32ecc0d371db282334fbb236a5bb5e05f9e04c4e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Helal")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-50794")[#strong[#text("Helal")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2011")])]

#text("It is a nice article, and thanks to professor Tao.")#linebreak()#text(" As we know, the KdV under some initial conditions leads to the solitons. But the accurate mathematical model that describe the Tsunamis need more and more justifications. What do you think?!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tsunami « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-50844")[#strong[#text("Tsunami « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2011")])]

#text("[…] Tsunami-Welle ist schon viel berichtet worden. Wer es genau wissen will, den möchte ich auf den Artikel auf dem Blog von Terence Tao hinweisen. Wer ist nicht so genau wissen will, aber dennoch sein Allgemeinwissen bereichern […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-50902")[#strong[#text("State of Technology Last Week -#3 « Dr Data's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2011")]

#text("[…] Serious Reading – Math of Tsunami vs. shallow wave propagation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-50951")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2011")])]

#text("Wonderful article. Never imagine there is so much math behind waves. Now I am wondering if there are any deep math theories behind earthquakes?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-50992")[#strong[#text("Second Xamuel.com Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2011")]

#text("[…] Terence Tao: Bezout’s inequality, The shallow water wave equation and tsunami propagation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-50995")[#strong[#text("Happenings – 2011 Mar 26 « Rip’s Applied Mathematics Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2011")]

#text("[…] has a derivation of the tsunami wave equation – that is, of the equation we use for tsunamis until they get close to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-86092")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2011")])]

#text("I had forgotten about this interesting article, but recently attended a very interesting lecture by a noted engineer who studied under Japanese researchers and who studies tsunamis. His presentation included some excellent graphics (photos and plenty of video) from this year’s disastrous tsunami in Japan, and also made frequent reference to the mid-2000s tsunami disaster.")

#text("I gather the tsunami, once it crashes on shore, no longer behaves like a wave at all, but rather changes to a moving bore of turbulent flow. In the presentation, the speaker emphasized that modern models tend to be wildly inaccurate at predicting the run-up height of tsunamis. Models applied to the Japan tsunami tended to be off by up to about 15 m between actual and predicted run-up height.")

#text("I don’t recall much about fluid dynamics, but I think I understood the turbulent flow is a mathematically intractable problem, and I also recall that this was one of the early problems Mandelbrot applied his new fractal geometry to. Can anyone point me to successful applications of fractal-based analysis of this or similar chaotic physical problems?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dlw")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-113322")[#strong[#text("dlw")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2011")])]

#text("(2) is erroneous. It should be:")

#text("Wave amplitude A is proportional to 1/sqrt(sqrt(b)), where b is the water depth.")

#text("This is the so-called Green’s Law, derived by George Green in 1837.")#linebreak()#text(" (Green, Cambridge Trans. VI, 457, 1837).")

#text("Here is a heuristic proof via energy conservation:")

#text("The wave energy E within a wavelength is proportional to A^2 * L,")#linebreak()#text(" where A is the wave amplitude, L the wave length (Lambda in the blog), which is proportional to the wave speed v, which in turn, is proportional to sqrt(b). Thus the energy E is proportional to A^2*sqrt(b). Energy conservation (as the wave propagates) dictates:")

#text("A^2*sqrt(b) = C, where C is a constant")

#text("Thus,")

#text("A = C/sqrt(sqrt(b)) (G)")

#text("This is the so-called Green’s Law")

#text("The increase of wave amplitude as the waves approach the shore is still dramatic")#linebreak()#text(" but as not as dramatic as described by (2).")

#text("According to (2): 1-m wave in 5000 m deep water would be 22 m in 10 m water. According to the Green’s law (G), 1-m wave in 5000 m deep water would be about 5 m")#linebreak()#text(" in 10 m water.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-113348")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2011")])]

#text("Thanks for pointing out the error! It took me a while to track down what happened; eventually I found that I had assumed in the sinusoidal ansatz that the velocity and height functions were perfectly in phase, which is of course incorrect. I’ve repaired the calculation now (working with a single second-order wave equation for the height, rather than a coupled first-order system for velocity and height, as I seem to make fewer mistakes with scalar equations than with systems).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2b5bfcd0874d4e9cc44391bb88a9613158ca4f3a351062dd3dc9c518340ddb9-8226b1375445d0fe20f9c1f8a44bccc5c91a89eef6f9d5e96d61c7d691292761.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R J Green")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-133210")[#strong[#text("R J Green")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2012")])]

#text("“The sweep of long water waves across the Pacific”")#linebreak()#text(" Australian Journal of Physics., 14, 120-128, 1960.")#linebreak()#text(" provides a readable account of velocities of ‘ripples’ and ‘tuunamis’ , and the method of predicting the arrival time of the Tsuname; Chile to Sudney (Aust).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-154716")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2012")])]

#text("Hello, I do not understand any of this, as I am a high school student. I am doing a project on the application of trigonometry in tsunami wave analysis. i am aiming to find out the impact of waves on the coastline so tsunami waves can be predicted. I am in need of formulas to help me in this. Pls help me find some relevant formulas…anyone willing to help?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/679cf7d10da7e78738599f5f482af30611abe584111e2bc4944eb2e79ff34972-3df4d0ea9b92b29552fe9c7719ff274a9e940f606ef8e190635325858d16011d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Laurence Edgardo A. del Puerto")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-231705")[#strong[#text("Laurence Edgardo A. del Puerto")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2013")])]

#text("no need to predict it… it is already a regular occasion. try focusing your mind on how to minimize its effects one its cause will trigger the tragedy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a6c0c5915fd354dcd7c6c4377e72802ccd880d5553d0c39899d744ec253bf2c-b603a3285c5bde7d5e0afcd143006a4d7a088f63707df6c735cc39bb4f3157d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trinity Curtis")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-474857")[#strong[#text("Trinity Curtis")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2016")])]

#text("I’m in 8th grade, and am doing a project similar to this, and I do have one equation that I believe would work quite well for determining the impact of a wave.")

#text("dM/dt=−14ρgA squared")

#text("While p represents water density, g is gravity, A is the height of the wave (middle to crest),and d represents the average water depth")

#text("this is the formula for momentum flux, with a negative downwards based on gravity.")

#text("wow this comment is from 2012. hope had a nice graduation")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/262afe22b00d1d05188443356a735e5aef05dd9d4d4bb5323c8447c96de02125-390e2129be8dcbeafb56414019c2e5647f9999c83e25264141f398eb2e841075.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pete Cadmus")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-217782")[#strong[#text("Pete Cadmus")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2013")])]

#text("Great article. Thanks for taking the time to post all this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-227155")[#strong[#text("ocean | sea | Annotary")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2013")]

#text("[…] Ferreira: physics complexity sustainability & energy biology Sort Share terrytao.wordpress.com 4 minutes […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/679cf7d10da7e78738599f5f482af30611abe584111e2bc4944eb2e79ff34972-3df4d0ea9b92b29552fe9c7719ff274a9e940f606ef8e190635325858d16011d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Laurence Edgardo A. del Puerto")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-231704")[#strong[#text("Laurence Edgardo A. del Puerto")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2013")])]

#text("Have you at least simulated a tsunami effect in an aquarium before you made this article? I would have if only some one will fund my project and ultimately can find a way to counter it. I bet my life on it that I could figure a way to at least minimize its effects if not on the first or second wave… then maybe on the third wave.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-420731")[#strong[#text("My great WordPress blog – Econlinks: The applied maths edition")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2014")]

#text("[…] wave equation and tsunami propagation: a concise exposition by Terry Tao. Brings back nice memories of my maths classes at Utrecht […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-459591")[#strong[#text("Everything You Need to Know to Survive a Tsunami - FunaGram")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2015")]

#text("[…] floor. In some ways, this is fantastic: the fluid dynamics of shallow-water waves make it extremely easy to predict tsunami travel times[7], and thus when the waves will start arriving on distant shores. On the down side, it’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-476850")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2017")])]

#text("I’m doing a science fair project about how wave depth affects wave velocity on tsunamis. I have to cite it but I don’t see a citations pg. By any chance you could put one next time. Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-483871")[#strong[#text("Tsunamier: Store bølger med katastrofale følger – Ekte data")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2017")]

#text("[…] ")#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#p&#8230")[#text("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#p&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/03/13/the-shallow-water-wave-equation-and-tsunami-propagation/#comment-682752")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2024")])]

#text("A small typo – In Remark 2, “and which is negligible when compared against the phase velocity V”, V should be v.")

#emph[#text("[Corrected, thanks – T.]")]
]
