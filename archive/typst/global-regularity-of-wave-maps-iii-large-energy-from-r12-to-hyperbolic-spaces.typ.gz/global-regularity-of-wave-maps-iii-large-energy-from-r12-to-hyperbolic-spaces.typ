// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/06/02/global-regularity-of-wave-maps-iii-large-energy-from-r12-to-hyperbolic-spaces/
// Converted to Typst by tao2typ: "2026-10-14T15:16:47.981334+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Global regularity of wave maps III.  Large energy from R^{1+2} to hyperbolic spaces", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Global regularity of wave maps III.  Large energy from R^{1+2} to hyperbolic spaces")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 June 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/06/02/global-regularity-of-wave-maps-iii-large-energy-from-r12-to-hyperbolic-spaces/")[#text("https://terrytao.wordpress.com/2008/06/02/global-regularity-of-wave-maps-iii-large-energy-from-r12-to-hyperbolic-spaces/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("I’ve just uploaded to the arXiv a new paper, “")#link("http://arxiv.org/abs/0805.4666")[#text("Global regularity of wave maps III. Large energy from ")#mi("{\\Bbb R}^{1+2}")#text(" to hyperbolic spaces")]#text("“, to be submitted when three other companion papers (“Global regularity of wave maps” IV, V, and VI) are finished. This project (which I had called “Heatwave”, due to the use of a heat flow to renormalise a wave equation) has a somewhat lengthy history to it, which I will now attempt to explain.")

#text("For the last nine years or so, I have been working on and off on the global regularity problem for ")#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/")[#text("wave maps")]#text(" ")#mi("\\phi: {\\Bbb R}^{1+d} \\to M")#text(". The wave map equation ")#mi("(\\phi^* \\nabla)^\\alpha \\partial_\\alpha \\phi=0")#text(" is a nonlinear generalisation of the ")#link("http://en.wikipedia.org/wiki/Wave_equation")[#text("wave equation")]#text(" ")#mi("\\partial^\\alpha \\partial_\\alpha \\phi = 0")#text(" in which the unknown field ")#mi("\\phi")#text(" takes values in a Riemannian manifold ")#mi("M = (M,h)")#text(" rather than in a vector space (much as the concept of a ")#link("http://en.wikipedia.org/wiki/Harmonic_map")[#text("harmonic map")]#text(" is a nonlinear generalisation of a ")#link("http://en.wikipedia.org/wiki/Harmonic_function")[#text("harmonic function")]#text("). This equation (also known as the ")#link("http://en.wikipedia.org/wiki/Non-linear_sigma_model")[#text("nonlinear ")#mi("\\sigma")#text(" model")]#text(") is one of the simplest examples of a geometric nonlinear wave equation, and is also arises as a simplified model of the ")#link("http://en.wikipedia.org/wiki/Einstein_equations")[#text("Einstein equations ")]#text("(after making a U(1) symmetry assumption). The global regularity problem seeks to determine when smooth initial data for a wave map (i.e. an initial position ")#mi("\\phi_0: {\\Bbb R}^d \\to M")#text(" and an initial velocity ")#mi("\\phi_1: {\\Bbb R}^d \\to TM")#text(" tangent to the position) necessarily leads to a smooth global solution.")

#text("The problem is particularly interesting in the ")#emph[#text("energy-critical")]#text(" dimension d=2, in which the conserved energy ")#tao-math("E(\\phi) := \\int_{{\\Bbb R}^d} \\frac{1}{2} \\left|\\partial_t \\phi\\right|_{h(\\phi)}^2 + \\frac{1}{2} \\left|\\nabla_x \\phi\\right|_{h(\\phi)}^2\\ dx", block: false)#text(" becomes invariant under the scaling symmetry ")#mi("\\phi(t,x) \\mapsto \\phi(t/\\lambda,x/\\lambda)")#text(". (In the subcritical dimension d=1, global regularity is fairly easy to establish, and was first done ")#link("http://www.ams.org/mathscinet-getitem?mr=596432")[#text("by Gu")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=643976")[#text("by Ladyzhenskaya-Shubov")]#text("; in supercritical dimensions ")#mi("d \\geq 3")#text(", examples of singularity formation are known, starting with the self-similar examples ")#link("http://www.ams.org/mathscinet-getitem?mr=933231")[#text("of Shatah")]#text(".)")

#text("It is generally believed that in two dimensions, singularities can form when M is positively curved but that global regularity should persist when M is negatively curved, in analogy with known results (in particular, the landmark ")#link("http://www.ams.org/mathscinet-getitem?mr=164306")[#text("paper of Eells and Sampson")]#text(") for the harmonic map heat flow (a parabolic cousin of the wave map equation). In particular, one should always have global regularity when the target is a ")#link("http://en.wikipedia.org/wiki/Hyperbolic_space")[#text("hyperbolic space")]#text(". There has been a large number of results supporting this conjecture; for instance, when the target is the sphere, examples of singularity formation have recently been constructed ")#link("http://arxiv.org/abs/math/0605023")[#text("by Rodnianski-Sterbenz")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2372807")[#text("by Krieger-Schlag-Tataru")]#text(", while for suitably negatively curved manifolds such as hyperbolic space, global regularity was established assuming equivariant symmetry ")#link("http://www.ams.org/mathscinet-getitem?mr=1168115")[#text("by Shatah and Tahvildar-Zadeh")]#text(", and assuming spherical symmetry ")#link("http://www.ams.org/mathscinet-getitem?mr=1223662")[#text("by Christodoulou and Tahvildar-Zadeh")]#text(". I will not attempt to mention all the other results on this problem here, but see for instance ")#link("http://www.math.princeton.edu/~seri/homepage/papers/telaviv.pdf")[#text("one")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1901147")[#text("of")]#text(" ")#link("http://www.math.harvard.edu/~jkrieger/papers/WMsurvey.pdf")[#text("these")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2359050")[#text("survey")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1404012")[#text("articles")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2043751")[#text("or")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1674843")[#text("books")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2233925")[#text("for")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2039994")[#text("further")]#text(" discussion.")

#metadata(none) <tao-3bb393b69a998f368587>

#text("Back in 2001, I ")#link("http://www.ams.org/mathscinet-getitem?mr=1869874")[#text("managed to show")]#text(" that one has global regularity for this problem when the target is a sphere and the energy was sufficiently small (building on an ")#link("http://www.ams.org/mathscinet-getitem?mr=1820329")[#text("earlier result of mine")]#text(" in higher dimensions, and on a Besov space variant of the result ")#link("http://www.ams.org/mathscinet-getitem?mr=1827277")[#text("by Tataru")]#text("). The main new innovation here was a “microlocal gauge transform” that made the equation slightly less nonlinear, enough so that perturbative techniques become effective. (This work was recognised with the ")#link("http://www.ams.org/notices/200204/comm-bocherprz.pdf")[#text("2002 Bôcher Prize")]#text(".) A simpler and more geometric gauge transform (the Coulomb gauge) was then introduced ")#link("http://www.ams.org/mathscinet-getitem?mr=1890048")[#text("by Shatah-Struwe")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2016196")[#text("by Nahmod-Stefanov-Uhlenbeck")]#text(", and the results extended to a wide variety of other manifolds by these authors (and ")#link("http://www.ams.org/mathscinet-getitem?mr=1843256")[#text("by Klainerman-Rodnianski")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2094472")[#text("Krieger")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=2130618")[#text("Tataru")]#text(").")

#text("In recent years, there have been a number of methods that can extend small energy regularity results to large energy in the case when the energy is scale-invariant. For instance, for the ")#link("http://tosio.math.toronto.edu/wiki/index.php/Quintic_NLW/NLKG_on_R3")[#text("energy-critical wave equation")]#text(", an energy non-concentration argument based primarily on Morawetz-type inequalities (which in turn arise from an analysis of the ")#link("http://en.wikipedia.org/wiki/Stress-energy_tensor")[#text("stress-energy tensor")]#text("), combined with the local (or small energy) theory (based primarily on Strichartz estimates), was able to handle the large-energy case, as worked out some time ago ")#link("http://www.ams.org/mathscinet-getitem?mr=1162370")[#text("by Grillakis")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1283026")[#text("Shatah-Struwe")]#text(", and others. These methods could handle the wave maps equation under additional symmetry assumptions, but the available Morawetz inequalities appeared to be giving the “wrong” sort of control on the solution to handle the general case (just as control of a function in one function space norm does not automatically imply control in other norms).")

#text("However, in 1999, ")#link("http://www.ams.org/mathscinet-getitem?mr=1626257")[#text("Bourgain introduced")]#text(" a new tool (the ")#emph[#text("induction on energy")]#text(" method) which allowed one to convert one type of control on a solution to another to obtain global regularity results for critical PDE. This method was clarified by a number of subsequent papers, including one ")#link("http://arxiv.org/abs/math/0402129")[#text("by Colliander, Keel, Staffilani, Takaoka, and myself")]#text(", and one ")#link("http://arxiv.org/abs/math/0610266")[#text("by Kenig and Merle")]#text(", as identifying the “minimal energy blowup solution” for any given PDE for which singularities can develop, using large data perturbation theory to show that such a solution is necessarily almost periodic (modulo the symmetries of the equation), and then using global methods such as Morawetz estimates to rule out the existence of such solutions.")

#text("These new tools were applied to scalar models such as ")#link("http://tosio.math.toronto.edu/wiki/index.php/NLS_equation")[#text("NLS")]#text(" or ")#link("http://tosio.math.toronto.edu/wiki/index.php/Semilinear_NLW")[#text("NLW")]#text(" and were not immediately applicable to the wave maps equation. Nevertheless, a potential strategy to the large data global regularity wave map became visible: firstly, one had to extend my small energy regularity theory to a large energy perturbation theory; secondly, one had to locate a Morawetz-type estimate to control minimal energy blowup solutions; and thirdly one had to adapt the induction-on-energy method to the wave map setting.")

#text("By 2004, I had ")#link("http://www.ams.org/mathscinet-getitem?mr=2135366")[#text("managed to locate")]#text(" a promising new gauge to renormalise the wave maps equation based on the harmonic map heat flow, which I called the “caloric gauge”, and which (in contrast to previous gauges) was able to handle large energy solutions in the case of negatively curved targets thanks to the work of ")#link("http://www.ams.org/mathscinet-getitem?mr=164306")[#text("Eells and Sampson")]#text(" mentioned earlier. In principle, by splicing this gauge into my earlier paper I would be able to obtain the large energy perturbation theory needed for the above program. In my 2004 paper, I was also able to find a Morawetz estimate (extending some earlier such estimates in the symmetric setting; a similar estimate had also been obtained ")#link("http://www.ams.org/mathscinet-getitem?mr=2055841")[#text("by Grillakis")]#text(") that suggested that wave maps became asymptotically self-similar as one approached any given singularity. Since it had been established ")#link("http://www.ams.org/mathscinet-getitem?mr=1674843")[#text("by Shatah and Struwe")]#text(" that no genuinely self-similar wave maps existed, this in principle provided the second ingredient in the program.")

#text("Also about this time, I managed to convince myself that the induction on energy argument could be adapted to the wave map setting. A major new complication here is that the unknown fields are no longer scalar fields, but instead take values in a manifold (or, if one takes derivatives, they become vector fields but then need to obey a number of additional constraint equations that make the system rather rigid). Because of this, some of the fundamental tools in the induction on energy strategy, such as the use of cutoffs in space or frequency to decompose a field into localised components, as well as the use of the humble addition operation to superimpose such components back together to reconstitute the solution, had to be reworked from scratch. By appealing again to the harmonic map heat flow, I was able to find substitutes for all of these operations, which in principle gave the third ingredient in the program.")

#text("However, it was clear that putting all of this together would be an enormous task. For comparison, my ")#link("http://www.ams.org/mathscinet-getitem?mr=1869874")[#text("small-energy paper")]#text(" (the prototype for the first step in the program) was 102 pages long, and my paper with ")#link("http://front.math.ucdavis.edu/math.AP/0402129")[#text("Colliander et al.")]#text(" (my initial prototype for the third step) was 100 pages long. (The second step was not nearly as fearsome, though still nontrivial: my ")#link("http://www.ams.org/mathscinet-getitem?mr=2135366")[#text("caloric gauge paper")]#text(" was 32 pages long, and the argument that rules out self-similar wave maps can be written in a handful of pages.) To make matters worse, the task of combining the arguments was more multiplicative in nature than additive, as the basic building blocks of each argument had to be reworked to accomodate the complications of the other. I was beginning to estimate the total length of the paper to run at perhaps 500 pages. I spent some months writing nearly a hundred pages of (unpublished) notes towards this goal, but eventually got exhausted (as well as distracted by many other things) and essentially shelved the project for several years (though I did once get a remarkable offer to run a workshop specifically designed to finally execute the various components of this program!).")

#text("As it turns out, though, this procrastination was the right thing to do, because several new conceptual advances and simplifications in the field occurred in the meantime. For instance, the ")#link("http://arxiv.org/abs/math/0610266")[#text("2006 paper of Kenig and Merle")]#text(" mentioned earlier managed to eliminate a lot of tedious “")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("epsilon management")]#text("” from the arguments of ")#link("http://www.ams.org/mathscinet-getitem?mr=1869874")[#text("Colliander et al.")]#text(" (though for a slightly different problem), by using dispersive analogues of the theory of concentration compactness, and in particular the use of linear profile decompositions. When I ")#link("http://arxiv.org/abs/math.AP/0609690")[#text("started")]#text(" ")#link("http://arxiv.org/abs/0707.3188")[#text("working")]#text(" with Killip, Visan, and Zhang on applying the Kenig-Merle methods to the mass-critical NLS, we realised that the method allowed for the global regularity problem to be cleanly “factored” into two non-interacting components: a reduction to almost periodic solutions using the large data perturbation theory, and a Morawetz inequality-based argument ruling out the existence of non-trivial almost periodic solutions. (This philosophy had already been adopted for some time by Merle and his co-authors for some slightly different dispersive models.) From this, I estimated that my previously planned 500 page paper could now be replaced with two papers of 100-200 pages in length each – still not exactly a pleasant prospect, but a significant amount of progress nevertheless, especially given that I had done very little direct work on the project for some years.")

#text("Still, the amount of work required was sufficiently daunting that I continued to postpone the actual writing process, in favour of shorter projects that offered a more immediate payoff. This quarter, however, as I was teaching ")#link("https://terrytao.wordpress.com/category/teaching/285g-poincare-conjecture/")[#text("my class on Perelman’s proof of the Poincaré conjecture")]#text(", I realised that Perelman’s three-tier approach of understanding singularities of Ricci flow – by passing from general Ricci flows to ancient ")#mi("\\kappa")#text("-solutions and then to asymptotic gradient shrinking solitons – could be adapted to the problem of studying almost periodic wave maps, passing from such wave maps to ancient wave maps and then to self-similar, stationary, or travelling wave maps, and reducing matters to ruling out the existence of the latter type of wave map in the energy class. Furthermore, the argument was rather abstract: the large data perturbation theory that I needed for it could be encapsulated into a cleanly formulated hypothesis (which was highly plausible based on known results of this type for other dispersive models). This removed a psychological block from my task of writing down the whole argument, because the large data perturbation theory is one of the lengthiest components of the proof (being based on my 102 page ")#link("http://www.ams.org/mathscinet-getitem?mr=1869874")[#text("small-energy paper")]#text(", which unfortunately has not really been simplified too much despite a number of generalisations and refinements) and had discouraged me from even beginning the process.")

#text("Accordingly, in the ")#link("http://arxiv.org/abs/0805.4666")[#text("paper I have now uploaded to the arXiv")]#text(" (a “mere” 35 pages long), I have written down the “high-level” component of the argument, which shows how global regularity for large energy wave maps in the model case when the target manifold is ")#link("http://en.wikipedia.org/wiki/Hyperbolic_space")[#text("hyperbolic space")]#text(" follows from five simpler claims, which roughly speaking are as follows:")

#enum(start: 1, 
[#text("A construction of a suitable energy space (a nonlinear analogue of the Sobolev space ")#mi("H^1({\\Bbb R^2})")#text(") with some reasonable properties;")],
[#text("A large data local well-posedness result in this energy space;")],
[#text("The conclusion of the induction-on-energy argument, namely that lack of global regularity implies existence of a non-trivial almost periodic solution;")],
[#text("The non-existence of self-similar, stationary, or travelling wave maps in the energy class; and")],
[#text("The non-existence of a energy class function which splits into the tensor product of a function of one lower dimension and a constant.")]
)

#text("With these claims, and repeated use of compactness arguments (in the spirit of Perelman) and the conservation of the stress-energy tensor (in particular using the Morawetz estimate from my ")#link("http://www.ams.org/mathscinet-getitem?mr=2135366")[#text("caloric gauge paper")]#text(" to create asymptotic self-similarity of the ancient solution), the current paper establishes the global regularity for wave maps into hyperbolic space. The basic strategy, once one has the above five ingredients, follows the Perelman approach (but is greatly simplified by the lack of singularities, which of course are the major obstacle in understanding Ricci flow):")

#list(
[#text("Assume for contradiction that global regularity fails; then (by 3.) there is a non-trivial almost periodic solution.")],
[#text("By rescaling this solution and taking limits (using 2.), one can extract an ancient almost periodic solution.")],
[#text("By using the Morawetz estimate, show that this ancient solution becomes asymptotically self similar as one moves backwards in time.")],
[#text("Rescaling and taking limits again, obtain either a self-similar solution, a stationary solution, or a travelling solution, which travels either below or at the speed of light.")],
[#text("The first three cases can be eliminated by 4. In the last case of a solution travelling at the speed of light, it turns out that Lorentz contraction forces the solution to split into a solution of one lower dimension and a constant, which can then be eliminated by 5.")]
)

#text("In the near future I plan to complete three more papers on this topic, devoted to the claims 1-5 above; I estimate each of the papers to be 30-100 pages long. Hopefully, by dividing the project up into more manageable chunks, it should be completed at a much faster rate than previously.")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/298f12b2d9036dc5cc3d25eac2898753c5a7d785053730b9c30aa262ba8cbda4-22f286e4671c4581bcf9afb2d5881d1d25499213125f4ec03c31248621fcc3ff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tom")]], [#link("https://terrytao.wordpress.com/2008/06/02/global-regularity-of-wave-maps-iii-large-energy-from-r12-to-hyperbolic-spaces/#comment-30182")[#strong[#text("tom")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("Dear Terry, this is a wonderful post: very informative, very inspiring, and a great example of scientific perseverence.")

#text("May I humbly ask (you don’t have to answer of course) was that the longest you’ve ever been working on a given problem or do you have even older projects in the making?")

#text("Also, what is your personal opinion in the light of the similarily between Perelman’s approach and your new strategy: do you think there are a few key ideas in maths that could help solve many problems, or do you think topics are too diverse to be united by a few high-level ideas? And in any case how to efficiently communicate such high-level strategies to others?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90c02f41607c68dc2bed941e13427d5caa05ebbef2fbcce8749d6ba70055a4a2-ba58d5187ecfe093fa29070570e91eae9d0d8a98aca2cf6ce452f53fa4647938.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2008/06/02/global-regularity-of-wave-maps-iii-large-energy-from-r12-to-hyperbolic-spaces/#comment-30193")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("pg. 2, paragraph 2 – “let” is not capitalized as it presumably should be.")

#text("Terence, out of total curiousity, why have you never published a paper in Inventiones?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/534a088b01edf6b7d8352850394f5b883eaee6f56dc3d5840d5ca485d243e049-79dea0dd669964f53df59194f5dbdf16abe3ad98b61ae8a962027c4a1e6e01bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave")]], [#link("https://terrytao.wordpress.com/2008/06/02/global-regularity-of-wave-maps-iii-large-energy-from-r12-to-hyperbolic-spaces/#comment-30194")[#strong[#text("Dave")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("Yuri Manin quote")

#text("Mathematization can-and therein lays its success- making existing rationality transparent; mathematization cannot introduce rationality to a system where it is absent..or compensate for a deficit of knowledge.” Manin recalls the notion of Kolmogorov complexity of a piece of information ..classical laws of physics-such as phantastic laws as Newton’s law of gravity and Einstein’s equations-are extremely short programmes to generate a lot of descriptions of real physical world situations. I am not sure at all that Kolmogorov’s complexity of data that were uncovered in the human genome project, or even modern cosmology data…is sufficiently small that they can really be grasped by the human mind.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aef5952340bb6bff3731f98d2d3c1dd9678b3cf7a31e8adaa413d5a449849a63-2282b8795059a7dc66cca6eef5758b61dc6bc6914983ed58ca5a96044d3d7376.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of McGuigan")]], [#link("https://terrytao.wordpress.com/2008/06/02/global-regularity-of-wave-maps-iii-large-energy-from-r12-to-hyperbolic-spaces/#comment-30208")[#strong[#text("McGuigan")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2008")])]

#text("The relation you mention of wave maps to Einstein’s equation with U(1) symmetry is intriguing.")#linebreak()#text(" Is there a notion of quantized wave maps and if so are these related to quantization of gravity with U(1) symmetry?")#linebreak()#text(" For sigma models Monte Carlo simulations can be used to define a path integral quantization . This works fine on a lattice Z^{d+1} and exhibits critical behavior for targets which are spheres. However the continuum limit is ill defined unless d=1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony")]], [#link("https://terrytao.wordpress.com/2008/06/02/global-regularity-of-wave-maps-iii-large-energy-from-r12-to-hyperbolic-spaces/#comment-30211")[#strong[#text("Tony")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2008")])]

#text("Dear Terry,")

#text("small typo: in paragraph 11 (i think) the link to “my paper with Colliander et al.” provides the same link as the one for “my small-energy paper” in the previous line, i.e. ")#link("http://www.ams.org/mathscinet-getitem?mr=1869874")[#text("http://www.ams.org/mathscinet-getitem?mr=1869874")]#text(".")

#text("regards, Tony")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/02/global-regularity-of-wave-maps-iii-large-energy-from-r12-to-hyperbolic-spaces/#comment-30215")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2008")])]

#text("Thanks for the corrections!")

#text("Dear McGuigan: I am not an expert on quantum field theory, but the U(1) reduction of the Einstein equations yields a wave map (or nonlinear sigma model) coupled with an evolution equation for the background metric, see e.g.")

#link("http://www.ams.org/mathscinet-getitem?mr=95m:83005")[#text("http://www.ams.org/mathscinet-getitem?mr=95m:83005")]

#text("I would imagine that the wave map portion can be quantized much as any other nonlinear field equation can be, but the background metric evolution would still offer basically the same problems that otherwise exist in quantum gravity (though with the symmetry reduction, the spacetime is now effectively 2+1 dimensional rather than 3+1, so perhaps there is some hope).")

#text("Dear David: by random coincidence, there is a paper in preparation by my coauthors and I which we have thought about submitting to Inventiones when it is ready, though it will still be a few weeks at least before this is the case.")

#text("Dear Tom: In fields such as nonlinear PDE (which Perelman’s result can broadly be included in), individual theorems tend not to be directly applicable much beyond their original intended use, but general ideas, strategies, tricks, and paradigms are often far broader. A similar point (using combinatorics as the primary example) is discussed in Gowers’ “two cultures” paper")

#link("http://www.dpmms.cam.ac.uk/~wtg10/2cultures.pdf")[#text("Click to access 2cultures.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Global regularity of wave maps IV. Absence of stationary or self-similar solutions in the energy class « What’s new")]], [#link("https://terrytao.wordpress.com/2008/06/02/global-regularity-of-wave-maps-iii-large-energy-from-r12-to-hyperbolic-spaces/#comment-30586")[#strong[#text("Global regularity of wave maps IV. Absence of stationary or self-similar solutions in the energy class « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2008")])]

#text("[…] maps IV. Absence of stationary or self-similar solutions in the energy class“. In the first installment of this project, I was able to establish the global existence of smooth wave maps from 2+1-dimensional spacetime […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/02/global-regularity-of-wave-maps-iii-large-energy-from-r12-to-hyperbolic-spaces/#comment-38335")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2009")])]

#text("I’m a bit late, but there is a small typo in the post:")

#text("A major new complication here i that the unknown fields are no longer scalar fields, but instead take values in a manifold")

#emph[#text("[Corrected, thanks – T]")]
]
