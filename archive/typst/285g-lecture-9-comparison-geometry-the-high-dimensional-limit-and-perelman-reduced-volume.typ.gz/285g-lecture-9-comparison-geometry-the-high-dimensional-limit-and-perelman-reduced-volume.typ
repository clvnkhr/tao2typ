// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/
// Converted to Typst by tao2typ: "2026-10-14T16:35:18.309841+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 9: Comparison geometry, the high-dimensional limit, and Perelman reduced volume", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 9: Comparison geometry, the high-dimensional limit, and Perelman reduced volume")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 April 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("We now turn to Perelman’s second scale-invariant monotone quantity for Ricci flow, now known as the ")#emph[#text("Perelman reduced volume")]#text(". We saw in the previous lecture that the monotonicity for Perelman entropy was ultimately derived (after some twists and turns) from the monotonicity of a potential under gradient flow. In this lecture, we will show (at a heuristic level only) how the monotonicity of Perelman’s reduced volume can also be “derived”, in a formal sense, from another source of monotonicity, namely the relative ")#link("http://en.wikipedia.org/wiki/Bishop-Gromov_inequality")[#text("Bishop-Gromov inequality")]#text(" in comparison geometry (which has already been alluded to in previous lectures). Interestingly, in order to obtain this connection, one must first reinterpret parabolic flows such as Ricci flow as the limit of a certain high-dimensional Riemannian manifold as the dimension becomes infinite; this is part of a more general philosophy that parabolic theory is in some sense an infinite-dimensional limit of elliptic theory. Our treatment here is a (liberally reinterpreted) version of Section 6 of ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s paper")]#text(".")

#text("In the next few lectures we shall give a rigorous proof of this monotonicity, without using the infinite-dimensional limit and instead using results related to the Li-Yau-Hamilton Harnack inequality. (There are several other approaches to understanding Perelman’s reduced volume, such as ")#link("http://arxiv.org/abs/0804.0343")[#text("Lott’s formulation")]#text(" based on optimal transport, but we will restrict attention in this course to the methods that are in ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s original paper")]#text(".)")

#metadata(none) <tao-9c2f8931519f1df046d0>

#heading(level: 1)[#text("— The Bishop-Gromov inequality —")]

#text("Let p be a point in a complete d-dimensional Riemannian manifold ")#mi("(M,g)")#text(". As noted in ")#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("Lecture 7")]#text(", we can use the exponential map to pull back M and g to the tangent space ")#mi("T_p M")#text(", which is also equipped with the radial variable r and the radial vector field ")#mi("\\partial_r = \\text{grad}(r)")#text(". From Exercise 7 of ")#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("Lecture 7")]#text(", we have the transport equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\mathcal L}_{\\partial_r} d\\mu = (\\Delta r)\\ d\\mu")]]

#text("for the volume measure ")#mi("d\\mu")#text(", and a transport inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\nabla_{\\partial_r} \\Delta r + \\frac{1}{d-1} (\\Delta r)^2 \\leq \\nabla_{\\partial_r} \\Delta r + \\left|\\text{Hess}(r)\\right|^2 = - \\text{Ric}(\\partial_r, \\partial_r)", block: true)]]

#text("for the Laplcian ")#mi("\\Delta r")#text(" which appears in (1). In particular, if we assume the lower bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\text{Ric} \\geq (d-1) K g")]]

#text("for Ricci curvature in a ball ")#mi("B(p,r_0)")#text(" for some real number ")#mi("K")#text(", then from the Gauss lemma (Lemma 1 of ")#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("Lecture 7")]#text(") we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\nabla_{\\partial_r} \\Delta r + \\frac{1}{d-1} (\\Delta r)^2 \\leq -(d-1) K.")]]

#text("Also, from an expansion around the origin (see e.g. (13) or (15) from ")#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("Lecture 7")]#text(") we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\Delta r = \\frac{d-1}{r} + O(r)")]]

#text("for small r. In principle, (4) and (5) lead to upper bounds on ")#mi("\\Delta r")#text(", which when combined with (1) lead to upper bounds on ")#mi("d\\mu")#text(", which in turn lead to upper bounds on ")#mi("B(p,r_0)")#text(". One can of course just go ahead and compute these bounds, but one computation-free way to proceed is to introduce the model geometry ")#mi("(M_K, g_K)")#text(", defined as")

#enum(start: 1, 
[#text("the standard round sphere ")#mi("\\sqrt{K} \\cdot S^d")#text(" of radius ")#mi("\\sqrt{K}")#text(" (and thus constant sectional curvature K) if ")#mi("K > 0")#text(" (Example 1 from Lecture 7);")],
[#text("the standard hyperbolic space ")#mi("\\sqrt{-K} \\cdot H^d")#text(" of constant sectional curvature K if ")#mi("K < 0")#text(" (Example 2 from Lecture 7); or")],
[#text("the standard Euclidean space ")#mi("{\\Bbb R}^d")#text(" if K=0.")]
)

#text("As all of these spaces are ")#link("http://en.wikipedia.org/wiki/Homogeneous_space")[#text("homogeneous")]#text(" (in fact, they are ")#link("http://en.wikipedia.org/wiki/Riemannian_symmetric_space")[#text("symmetric spaces")]#text("), the choice of origin p in this model geometry is irrelevant. Observe that the orthogonal group ")#mi("O(d)")#text(" acts isometrically on each of these spaces, with the orbits being the spheres centred at p. This implies that at any point q not equal to p, ")#mi("\\text{Hess}(r)")#text(" is invariant under conjugation by the stabiliser of that group on q, which easily implies that it is diagonal on the tangent space to the sphere (i.e. to the orthogonal complement of ")#mi("\\partial_r")#text("). From this we see that for this model geometry, the inequality in (2) is in fact an equality. Since the model geometry also has constant sectional curvature K (which implies equality in (3)), we thus see that one has equality in (4) for this model geometry as well. From this we can conclude:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1. ")]#text(" (Relative Bishop-Gromov inequality) With the assumptions as above, the volume ratio ")#mi("\\text{Vol}_{M,g}(B_{M,g}(p,r)) / \\text{Vol}_{M_K,g_K}(B_{M_K,g_K}(p,r))")#text(" is a non-increasing function of r as ")#mi("0 < r < r_0")#text(".")
]

#strong[#text("Exercise 1. ")]#text(" Prove Lemma 1. (Hints: One can avoid all issues with non-injectivity by working inside the ")#link("http://en.wikipedia.org/wiki/Cut_locus_%28Riemannian_manifold%29")[#text("cut locus")]#text(" of p, which determines a ")#link("http://en.wikipedia.org/wiki/Star_domain")[#text("star-shaped")]#text(" region in ")#mi("T_p M")#text(". In the positive curvature case K > 0, the model geometry ")#mi("M_K")#text(" has a finite radius of injectivity, but observe that we may without loss of generality reduce to the case when ")#mi("r_0")#text(" is less than or equal to that radius (or one can invoke ")#link("http://en.wikipedia.org/wiki/Myers_theorem")[#text("Myers’ theorem")]#text(", see Exercise 2 below). To prove the monotonicity of ratios of volumes of balls, it may be convenient to first achieve the analogous claim for ratios of volumes of spheres, and then use the Gauss lemma and the fundamental theorem of calculus to pass from spheres to balls.) ")#mi("\\diamond")

#strong[#text("Exercise 2.")]#text(" Prove ")#link("http://en.wikipedia.org/wiki/Myers_theorem")[#text("Myers’ theorem")]#text(": if a Riemannian manifold obeys (3) everywhere for some ")#mi("K > 0")#text(", then the diameter of the manifold is at most ")#mi("\\pi/\\sqrt{K}")#text(". (Hint: in the model geometry, the sphere of radius r collapses to a point when r approaches ")#mi("\\pi/\\sqrt{K}")#text(".) ")#mi("\\diamond")

#strong[#text("Remark 1.")]#text(" This Lemma implies the volume comparison result ")#mi("\\text{vol}(B(p,r))/\\text{vol}(B(p,r/2)) = O(1)")#text(" whenever one has bounded normalised curvature, which was used in the ")#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/")[#text("previous lecture")]#text("; indeed, thanks to the above inequality, it suffices to prove the claim for model geometries. ")#mi("\\diamond")

#text("Setting K=0, we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1.")]#text(" Let ")#mi("(M,g)")#text(" be a complete d-dimensional Riemannian manifold of non-negative Ricci curvature, and let p be a point in M. Then ")#mi("\\text{Vol}(B(p,r))/r^d")#text(" is a non-increasing function of r.")
]

#text("Let us refer to the quantity ")#mi("\\text{Vol}(B(p,r))/r^d")#text(" as the ")#emph[#text("Bishop-Gromov reduced volume")]#text(" at the point p and the scale r; thus we see that this quantity is dimensionless (i.e. invariant under scaling of the manifold and of r), and non-increasing in r when one has non-negative Ricci curvature (and in particular, for Ricci-flat manifolds).")

#strong[#text("Exercise 3.")]#text(" Use the Bishop-Gromov inequality to state and prove a rigorous version of the following informal claim: if a Riemannian manifold is non-collapsed at a point p at one scale ")#mi("r_0 > 0")#text(" (as defined in ")#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("Lecture 7")]#text("), then it is also non-collapsed at all larger scales ")#mi("r_1 > r_0")#text(". ")#mi("\\diamond")

#heading(level: 1)[#text("— Parabolic theory as infinite-dimensional elliptic theory —")]

#text("We now come to an interesting (but still mostly heuristic) correspondence principle between elliptic theory and parabolic theory, with the latter being viewed as an infinite-dimensional limit of the former, in a manner somewhat analogous to that of the ")#link("http://en.wikipedia.org/wiki/Central_limit_theorem")[#text("central limit theorem")]#text(" in probability. To get some idea of what I mean by this correspondence, consider the following (extremely incomplete, non-rigorous, inaccurate, and imprecise) dictionary:")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Elliptic")],
table.cell(colspan: 1, rowspan: 1)[#text("Parabolic")],
table.cell(colspan: 1, rowspan: 1)[#text("Riemannian manifold (M,g)")],
table.cell(colspan: 1, rowspan: 1)[#text("Riemannian flow ")#mi("t \\mapsto (M,g(t))")],
table.cell(colspan: 1, rowspan: 1)[#text("Complete manifold")],
table.cell(colspan: 1, rowspan: 1)[#text("Ancient flow of complete manifolds")],
table.cell(colspan: 1, rowspan: 1)[#text("Spatial origin 0")],
table.cell(colspan: 1, rowspan: 1)[#text("Spacetime origin ")#mi("(0,0)")],
table.cell(colspan: 1, rowspan: 1)[#text("Elliptic scaling ")#mi("x \\mapsto \\lambda x")],
table.cell(colspan: 1, rowspan: 1)[#text("Parabolic scaling ")#mi("(t,x) \\mapsto (\\lambda^2 t, \\lambda x)")],
table.cell(colspan: 1, rowspan: 1)[#text("Laplace equation ")#mi("\\Delta u = 0")],
table.cell(colspan: 1, rowspan: 1)[#text("Heat equation ")#mi("-\\partial_t u + \\Delta u = 0")],
table.cell(colspan: 1, rowspan: 1)[#text("Ricci flat manifold ")#mi("\\text{Ric} = 0")],
table.cell(colspan: 1, rowspan: 1)[#text("Ricci flow ")#mi("\\partial_t g = - 2 \\text{Ric}")],
table.cell(colspan: 1, rowspan: 1)[#text("Mean value principle ")#mi("u(0) = \\int_{S^{d-1}} u(r\\omega)\\ d\\mu(\\omega)")],
table.cell(colspan: 1, rowspan: 1)[#text("Fundamental solution ")#tao-math("u(0,0) = \\frac{1}{(4\\pi\\tau)^{d/2}} \\int_{{\\Bbb R}^d} e^{-\\left|x\\right|^2/4\\tau} u(-\\tau,x)\\ dx", block: false)],
table.cell(colspan: 1, rowspan: 1)[#text("Normalised measure on the sphere ")#mi("r \\cdot S^{d-1}")],
table.cell(colspan: 1, rowspan: 1)[#text("Heat kernel ")#tao-math("\\frac{1}{(4\\pi\\tau)^{d/2}} e^{-\\left|x\\right|^2/4\\tau}\\ dx", block: false)],
table.cell(colspan: 1, rowspan: 1)[#text("Maximum principle")],
table.cell(colspan: 1, rowspan: 1)[#text("Maximum principle")],
table.cell(colspan: 1, rowspan: 1)[#text("Ball of radius O(r) around spatial origin")],
table.cell(colspan: 1, rowspan: 1)[#text("Cylinder of radius O(r) and height ")#mi("O(r^2)")#text(" extending backwards in time from spacetime origin")],
table.cell(colspan: 1, rowspan: 1)[#text("Radial variable r=|x|")],
table.cell(colspan: 1, rowspan: 1)[#text("|x| or ")#mi("\\sqrt{-t} = \\sqrt{\\tau}")],
table.cell(colspan: 1, rowspan: 1)[#text("Bishop-Gromov reduced volume")],
table.cell(colspan: 1, rowspan: 1)[#text("Perelman reduced volume")]
)

#strong[#text("Remark 2. ")]#text("Of course, we have not defined Perelman reduced volume yet, but the point is that the monotonicity of Perelman reduced volume for Ricci flow is supposed to be the parabolic analogue of the monotonicity of Bishop-Gromov reduced volume for Ricci-flat manifolds. Note that one has two competing notions of the parabolic radial variable, |x| and ")#mi("\\sqrt{\\tau}")#text(", where ")#mi("\\tau := -t")#text(" is the backwards time variable; the ratio between these two competitors is essentially the ")#emph[#text("Perelman reduced length")]#text(", which does not really have a good analogue in the elliptic theory (except perhaps in the “latitude” variable one gets when decomposing a sphere into cylindrical coordinates). ")#mi("\\diamond")

#text("It is well known that elliptic theory can be viewed as the static (i.e. steady state) special case of parabolic theory, but here we want to discuss a rather different connection between the two theories that goes in the opposite direction, in which we view parabolic theory as a limiting case of elliptic theory as the dimension d goes to infinity.")

#text("To motivate how this works, let us begin with a smooth ancient solution ")#mi("u: (-\\infty,0] \\times {\\Bbb R}^d \\to {\\Bbb R}")#text(" to the Euclidean heat equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("-\\partial_t u + \\Delta_x u = 0")]]

#text("and ask how to convert it to a high-dimensional solution to the Laplace equation. At first glance this looks unreasonable: the Laplacian only contains second order derivative terms, but we have to somehow generate the first-order derivative ")#mi("\\partial_t")#text(" out of this. The trick is to use polar coordinates. Recall that if we parameterise a Euclidean variable ")#mi("y \\in {\\Bbb R}^N")#text(" away from the origin as ")#mi("y = r \\omega")#text(" for ")#mi("r > 0")#text(" and ")#mi("\\omega \\in S^{N-1}")#text(", then the Laplacian ")#mi("\\Delta_y f")#text(" of a function ")#mi("f: {\\Bbb R}^N \\to {\\Bbb R}")#text(" can be expressed by the classical formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\Delta_y f = \\partial_{rr} f + \\frac{N-1}{r} \\partial_r f + \\frac{1}{r^2} \\Delta_\\omega f")]]

#text("where ")#mi("\\Delta_{\\omega}")#text(" is the Laplace-Beltrami operator on the sphere. In particular, if f is a radial or spherically symmetric function (so by abuse of notation we write ")#mi("f(y) = f(r)")#text("), we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\Delta_y f = \\partial_{rr} f + \\frac{N-1}{r} \\partial_r f.")]]

#text("Now if we look at the high-dimensional limit ")#mi("N \\to \\infty")#text(" (noting that f, being radial, is well defined in every dimension), we see that the first order term ")#mi("\\frac{N-1}{r} \\partial_r f")#text(" dominates, despite the fact that ")#mi("\\Delta_y")#text(" is a second order operator. To clarify this domination (and to bring into view the operator ")#mi("-\\partial_t")#text(" appearing in (6)), let us make the change of variables")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("t = -\\tau = - \\frac{r^2}{2N} = -\\frac{y_1^2 + \\ldots + y_N^2}{2N}")]]

#text("(thus ")#mi("\\tau = -t")#text(" is the average of the squared coordinates ")#mi("y_1^2,\\ldots,y_N^2")#text("). A quick application of the chain rule then yields")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\Delta_y f = -\\frac{2t}{N} \\partial_{tt} f - \\partial_t f")]]

#text("(one can also see this by writing ")#mi("f(y) = \\tilde f(t) = \\tilde f( -(y_1^2+\\ldots+y_N^2)/2N )")#text(" and applying the Laplacian operator ")#mi("\\Delta_y")#text(" directly). If we restrict attention to the region of ")#mi("{\\Bbb R}^N")#text(" where all the coordinates ")#mi("y_i")#text(" are O(1), so ")#mi("r^2 = O(N)")#text(" and ")#mi("\\tau = -t = O(1)")#text(", and fix ")#mi("\\tilde f")#text(" while letting N go off to infinity, we thus see that ")#mi("\\Delta_y f")#text(" converges to ")#mi("- \\partial_t f")#text(" (with errors that are ")#mi("O(1/N)")#text(").")

#text("Returning back to our ancient solution ")#mi("u: (-\\infty,0] \\times {\\Bbb R}^d \\to {\\Bbb R}")#text(" to the heat equation (6), it is now clear how to express this solution as a high-dimensional nearly harmonic function: if we define the high-dimensional lift ")#mi("u^{(N)}: {\\Bbb R}^N \\times {\\Bbb R}^d \\to {\\Bbb R}")#text(" of u to the N+d-dimensional Euclidean space ")#mi("{\\Bbb R}^N \\times {\\Bbb R}^d := \\{ (y,x): y \\in {\\Bbb R}^N, x \\in {\\Bbb R}^d \\}")#text(" for some large N by using the change of variables (9), i.e.")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("u^{(N)}(y,x) := u(t,x) = u( - \\frac{y_1^2+\\ldots+y_N^2}{2N}, x )")]]

#text("then we see from (10) and (6) that ")#mi("u^{(N)}")#text(" is nearly harmonic as claimed; indeed we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\Delta_{y,x} u^{(N)} = \\frac{r^2}{N^2} \\partial_{tt} u - \\partial_t u + \\Delta_x u = O(1/N)")]]

#text("in the region ")#mi("y_i = O(1), x = O(1)")#text(", which implies as before that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("y_i = O(1), x = O(1), r^2 = O(N), \\tau = -t = O(1).")]]

#strong[#text("Remark 3. ")]#text("Writing y in polar coordinates as ")#mi("y = r\\omega")#text(", the metric ")#mi("ds^2")#text(" on ")#mi("{\\Bbb R}^N \\times {\\Bbb R}^d")#text(" can be expressed as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("ds^2 = dr^2 + r^2 d\\omega^2 + dx^2 = \\frac{N}{2\\tau} d\\tau^2 + \\tau d\\omega_{1/2N}^2 + dx^2")]]

#text("where ")#mi("d\\omega_{1/2N}^2")#text(" is the metric on the sphere ")#mi("S^N")#text(" of constant curvature ")#mi("1/2N")#text(". This expression is essentially the first equation in Section 6 of ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s paper")]#text(" in the Euclidean case. Perelman works exclusively in polar coordinates, but I have found that the Cartesian coordinate approach can be more illuminating at times. ")#mi("\\diamond")

#strong[#text("Remark 4.")]#text(" The formula (9) seems closely related to ")#link("http://en.wikipedia.org/wiki/It%C5%8D%27s_lemma")[#text("Itō’s formula")]#text(" ")#mi("dt = (dB)^2")#text(" from stochastic calculus, combined perhaps with the central limit theorem, though I was not able to make this connection absolutely precise. Note that for reasons of duality, stochastic calculus tends to involve the backwards heat equation rather than the forwards heat equation (see e.g. the ")#link("http://en.wikipedia.org/wiki/Black%E2%80%93Scholes")[#text("Black-Scholes formula")]#text("), which seems to explain why the minus sign in (9) is not present in Itō’s formula. ")#mi("\\diamond")

#text("To illustrate how this correspondence could be used, let us heuristically derive the classical formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("u(0,0) = \\frac{1}{(4\\pi\\tau)^{d/2}} \\int_{{\\Bbb R}^d} e^{-\\left|x\\right|^2/4\\tau} u(-\\tau,x)\\ dx", block: true)]]

#text("for solutions ")#mi("u: (-\\infty,0] \\times {\\Bbb R}^d \\to {\\Bbb R}")#text(" to the heat equation (6) from the classical ")#link("http://en.wikipedia.org/wiki/Harmonic_function#The_mean_value_property")[#text("mean value principle")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("u^{(N)}(0,0) = \\frac{1}{\\text{mes}(r \\cdot S^{N+d-1})} \\int_{S^{N+d-1}} u^{(N)}(r\\omega)\\ d\\omega")]]

#text("for harmonic functions ")#mi("u^{(N)}: {\\Bbb R}^N \\times {\\Bbb R}^d \\to {\\Bbb R}")#text(". Actually, it will be slightly simpler to use the mean value principle for balls rather than spheres,")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("u^{(N)}(0,0) = \\frac{1}{\\text{Vol}(B^{N+d}(0,r_0))} \\int_{\\left|y\\right|^2+\\left|x\\right|^2 \\leq r_0^2} u^{(N)}(y,x)\\ dy dx,", block: true)]]

#text("though in high dimensions there is actually very little difference between balls and spheres (the bulk of the volume of a high-dimensional ball is concentrated near its boundary, which is a sphere).")

#text("Let ")#mi("u")#text(" and ")#mi("u^{(N)}")#text(" be as in (6) and (11). From (12) we see that ")#mi("u^{(N)}")#text(" is almost harmonic; let us be non-rigorous and pretend that ")#mi("u^{(N)}")#text(" is close enough to harmonic that the formula (17) remains accurate for this function. We write the volume of the ball ")#mi("B^{N+d}(0,r_0)")#text(" as ")#mi("C_{N,d} r_0^{N+d}")#text(" for some constant ")#mi("C_{N,d}")#text(". As for the integrand in (17), we use polar coordinates ")#mi("y = r \\omega")#text(", ")#mi("dy = r^{N-1} dr d\\omega")#text(" and rewrite (17) as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("c_{N,d} r_0^{-N-d} \\int_{{\\Bbb R}^d} \\int_{0 \\leq r \\leq \\sqrt{r_0^2-\\left|x\\right|^2}} u( -r^2/2N, x ) r^{N-1} dr dx", block: true)]]

#text("for some other constant ")#mi("c_{N,d} > 0")#text(". In view of (9), it is natural to write ")#mi("r_0^2 = 2N \\tau")#text(" for some ")#mi("\\tau > 0")#text(", and in view of (13) it is natural to work in the regime in which ")#mi("x = O(1), \\tau = O(1)")#text(", and ")#mi("r_0^2 = O(N)")#text(". Because ")#mi("r^{N-1}")#text(" is so rapidly increasing when N is large, the bulk of the inner integral is concentrated at its endpoint (cf. our previous remark about high-dimensional balls concentrating near their boundary), and so we expect")

#align(center)[#tao-fit-display[#tao-math("\\int_{0 \\leq r \\leq \\sqrt{r_0^2-\\left|x\\right|^2}} u( -r^2/2N, x ) r^{N-1} dr", block: true)]]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\approx \\frac{1}{N} (\\sqrt{r_0^2-\\left|x\\right|^2})^N u( - (r_0^2-\\left|x\\right|^2)/2N, x ).", block: true)]]

#text("Since ")#mi("r_0")#text(" is so much larger than |x| in our regime of interest, we can heuristically approximate ")#tao-math("u( - (r_0^2-\\left|x\\right|^2)/2N, x)", block: false)#text(" by ")#mi("u( -r_0^2/2N,x) = u(-\\tau,x)")#text(". Also, by Taylor approximation we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("(\\sqrt{r_0^2-\\left|x\\right|^2})^N \\approx r_0^{N} \\exp( - \\frac{N \\left|x\\right|^2}{2 r_0^2} ).", block: true)]]

#text("Putting all this together, and substituting ")#mi("r_0^2 = 2N\\tau")#text(", we heuristically conclude")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("u(0,0) \\approx \\frac{\\tilde c_{N,d}}{\\tau^{d/2}} \\int_{{\\Bbb R}^d} e^{-\\left|x\\right|^2/4\\tau} u(-\\tau,x)\\ dx", block: true)]]

#text("for some other constant ")#mi("\\tilde c_{N,d} > 0")#text(". Taking limits as ")#mi("N \\to \\infty")#text(" we heuristically obtain (15) up to a constant.")

#strong[#text("Exercise 4. ")]#text("Work through the calculations more carefully (but still heuristically), using ")#link("http://en.wikipedia.org/wiki/Stirling%27s_approximation")[#text("Stirling’s approximation")]#text(" to the ")#link("http://en.wikipedia.org/wiki/Gamma_function")[#text("Gamma function")]#text(", together with the ")#link("http://en.wikipedia.org/wiki/Unit_sphere#General_area_and_volume_formulas")[#text("classical formulae for the volume of balls and spheres")]#text(", to verify that one does indeed get the right constant of ")#mi("\\frac{1}{(4\\pi)^{d/2}}")#text(" in (15) at the end of the day (as one must). ")#mi("\\diamond")

#text("Now let us perform a variant of the above computations which is more closely related to the monotonicity of Perelman’s reduced volume. The Euclidean space ")#mi("{\\Bbb R}^N \\times {\\Bbb R}^d")#text(" is of course Ricci-flat, and so from Corollary 1 we know that the Bishop-Gromov reduced volume")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("r_0^{-N-d} \\int_{\\left|y\\right|^2+\\left|x\\right|^2 \\leq r_0^2}\\ dy dx", block: true)]]

#text("is non-decreasing in ")#mi("r_0")#text(" (and thus non-decreasing in ")#mi("\\tau")#text("). (Of course, being Euclidean, (22) is equal to a constant ")#mi("C_{N,d}")#text("; but let us ignore this fact (which we have already used in our heuristic derivation of (15)) for now.) Repeating all the above computations (but with u and ")#mi("u^{(N)}")#text(" replaced by 1) we thus heuristically conclude that the quantity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#tao-math("\\frac{1}{\\tau^{d/2}} \\int_{{\\Bbb R}^d} e^{-\\left|x\\right|^2/4\\tau}\\ dx", block: true)]]

#text("is also non-decreasing in ")#mi("\\tau")#text(". (Indeed, this quantity is equal to ")#mi("(4\\pi)^{d/2}")#text(" for all ")#mi("\\tau")#text(".) The quantity (23) is precisely the ")#emph[#text("Perelman reduced volume")]#text(" of Euclidean space ")#mi("{\\Bbb R}^d")#text(" (which we view as a trivial example of an ancient Ricci flow) at the spacetime origin (0,0) and backwards time parameter ")#mi("\\tau")#text(".")

#heading(level: 1)[#text("— From Ricci flow to Ricci flat manifolds —")]

#text("We have seen how ancient solutions to the heat equation on a Euclidean spacetime can be viewed as (approximately) harmonic functions on an “infinitely high dimensional” Euclidean space. Now we would like to analogously view ancient solutions to a heat equation on a flow ")#mi("t \\mapsto (M,g(t))")#text(" of Riemannian manifolds as harmonic functions on an “infinitely high dimensional” Riemannian manifold, and similarly to view ancient Ricci flows as infinite dimensional infinitely high dimensional Ricci-flat manifolds.")

#text("Let’s begin with the former task. Starting with an ancient flow ")#mi("t \\mapsto (M,g(t))")#text(" of d-dimensional Riemannian metrics for ")#mi("t \\in (-\\infty,0]")#text(" (which we will not assume to be a Ricci flow just yet) and a large integer N, we can consider the N+d-dimesional manifold ")#mi("M^{(N)} := {\\Bbb R}^N \\times M = \\{ (y,x): y \\in {\\Bbb R}^N, x \\in M \\}")#text(". As a first attempt to mimic the situation in the Euclidean case, it is natural to endow ")#mi("M^{(N)}")#text(" with the Riemannian metric ")#mi("g^{(N)}")#text(" given by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("(dg^{(N)})^2 = dy^2 + dg(t)^2")]]

#text("where t is given by the formula (9). In terms of local coordinates, if we use the indices a,b,c to denote the d indices for the x variable and i,j,k to denote the N indices for the y variable, we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("g^{(N)}_{ab} = g_{ab}(t); g^{(N)}_{ai} = g^{(N)}_{ia} = 0; g^{(N)}_{ij} = \\delta_{ij}")]]

#text("where ")#mi("\\delta")#text(" is the Kronecker delta. From this we see that the volume measure ")#mi("d\\mu^{(N)}")#text(" on ")#mi("M^{(N)}")#text(" is given by")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("d\\mu^{(N)} = d\\mu(t) dy")]]

#text("and the Dirichlet form")

#tao-aligned(keep: true)[


#tao-math("E^{(N)}(u,v)  & := \\int_{M^{(N)}} g^{(N)}( \\nabla^{(N)} u, \\nabla^{(N)} v )\\ d\\mu^{(N)}", block: true)



#tao-math(" & = - \\int_{M^{(N)}} \\Delta^{(N)} u v\\ d\\mu^{(N)}", block: true, numbering: n => [#text("(27)")])



#tao-math(" & = - \\int_{M^{(N)}} u \\Delta^{(N)} v\\ d\\mu^{(N)}", block: true)
]

#text("for this Riemannian manifold is given by")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("E^{(N)}(u,v) = \\int_{{\\Bbb R}^N} \\int_{M(t)} \\nabla_y u \\cdot \\nabla_y v + g(t)( \\nabla_{x,g(t)} u, \\nabla_{x,g(t)} v)\\ d\\mu(t) dy,")]]

#text("where ")#mi("\\nabla_{x,g(t)} u")#text(" is the gradient of u in the x variable using the metric g(t). We can then integrate by parts to compute the Laplacian ")#mi("\\Delta^{(N)} u")#text(". Recalling that ")#mi("d\\mu(t)")#text(" varies in t by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("\\frac{d}{dt} d\\mu(t) = \\frac{1}{2} \\text{tr}(\\dot g) d\\mu(t)")]]

#text("(equation (19) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(") and using (9) and the chain rule, we see that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\Delta^{(N)} u^{(N)} = \\Delta_y u^{(N)} + \\Delta_{x, g(t)} u^{(N)} - \\frac{r}{2N} \\text{tr}(\\dot g) \\partial_r u^{(N)}")]]

#text("where ")#mi("\\Delta_{x,g(t)}")#text(" is the Laplace-Beltrami operator in the x variable using the metric g(t). If we specialise to radial functions")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("u^{(N)}(y,x) = u(t,x)")]]

#text("and use (10) and the chain rule, we can rewrite (29) as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("-\\frac{t}{2N} \\partial_{tt} u - \\partial_t u + \\Delta_{x,g(t)} u + \\frac{t}{N} \\text{tr}(\\dot g) \\partial_t u")]]

#text("Thus we see that if u solves the heat equation ")#mi("u_t = \\Delta_{g(t)} u")#text(", then its lift ")#mi("u^{(N)}: M^{(N)} \\to {\\Bbb R}")#text(" is approximately harmonic in the sense that ")#mi("\\Delta^{(N)} u^{(N)} = O(1/N)")#text(" in the region where ")#mi("-t = \\tau = O(1)")#text(" and x is confined to a compact region of space.")

#strong[#text("Remark 5.")]#text(" The ")#mi("\\frac{t}{N} \\text{tr}(\\dot g) \\partial_t u")#text(" term in (32) is somewhat annoying; we will later tweak the metric (24) in order to remove it (at the cost of other, more acceptable, terms). ")#mi("\\diamond")

#text("Now let us see whether Ricci flows ")#mi("t \\mapsto (M, g(t))")#text(" lift to approximately Ricci-flat manifolds ")#mi("M^{(N)}")#text(". We begin by computing the ")#link("http://en.wikipedia.org/wiki/Christoffel_symbol")[#text("Christoffel symbols")]#text(" ")#mi("(\\Gamma^{(N)})^{\\gamma}_{\\alpha \\beta}")#text(" in local coordinates, where ")#mi("\\alpha,\\beta,\\gamma")#text(" refer to the N+d combined indices coming from the indices a on M and the indices i on ")#mi("{\\Bbb R}^N")#text(". We recall the standard formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("\\Gamma^{\\gamma}_{\\alpha \\beta} = \\frac{1}{2} g^{\\gamma \\delta} ( \\partial_\\alpha g_{\\beta \\delta} + \\partial_\\beta g_{\\alpha \\delta} - \\partial_\\delta g_{\\alpha \\beta} )")]]

#text("for the Christoffel symbols of a general Riemannian manifold in local coordinates. Specialising to the metric (25), some computation reveals that")

#tao-aligned(keep: true)[


#tao-math("(\\Gamma^{(N)})^i_{jk}  & = 0", block: true)



#tao-math("(\\Gamma^{(N)})^i_{ja}  & = (\\Gamma^{(N)})^i_{aj} = (\\Gamma^{(N)})^a_{ij} = 0", block: true)



#tao-math("(\\Gamma^{(N)})^i_{ab}  & = \\frac{y_i}{2N} \\dot g_{ab}", block: true, numbering: n => [#text("(34)")])



#tao-math("(\\Gamma^{(N)})^a_{ib}  & = (\\Gamma^{(N)})^a_{bi} = -\\frac{y_i}{2N} g^{ac} \\dot g_{cb}", block: true)
]

#align(center)[#mi("\\displaystyle (\\Gamma^{(N)})^a_{bc} = \\Gamma^a_{bc}")#text(".")]

#text("Now the Ricci curvature ")#mi("\\text{Ric}_{\\alpha \\beta}")#text(" can be computed from the Christoffel symbols by the standard formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("\\text{Ric}_{\\alpha \\beta} = \\partial_\\gamma \\Gamma^\\gamma_{\\alpha \\beta} - \\partial_\\beta \\Gamma^\\gamma_{\\alpha \\gamma} + \\Gamma_{\\alpha \\beta}^\\gamma \\Gamma^\\mu_{\\gamma \\mu} - \\Gamma^\\mu_{\\alpha \\gamma} \\Gamma^\\gamma_{\\beta \\mu}.")]]

#text("If we apply this formula we obtain (after some computation)")

#tao-aligned(keep: true)[


#tao-math("\\text{Ric}^{(N)}_{ij}  & = \\frac{\\delta_{ij}}{2N} \\text{tr}(\\dot g) + O( 1 / N^2 )", block: true)



#tao-math("\\text{Ric}^{(N)}_{ia}  & = O( 1 / N )", block: true, numbering: n => [#text("(36)")])
]

#align(center)[#mi("\\displaystyle \\text{Ric}^{(N)}_{ab} = \\text{Ric}_{ab} + \\frac{1}{2} \\dot g_{ab} + O(1/N)")#text(".")]

#text("We thus see that if the original flow ")#mi("t \\mapsto (M,g(t))")#text(" obeys the Ricci flow equation ")#mi("\\dot g = -2 \\text{Ric}")#text(", then the lifted manifold ")#mi("(M^{(N)}, \\mu^{(N)})")#text(" is nearly Ricci flat in the sense that all components of the Ricci curvature tensor are O(1/N) (in the region ")#mi("t = O(1)")#text("). In fact the above estimates show that the Ricci curvature tensor is also O(1/N) in the operator norm sense and ")#mi("O(1/\\sqrt{N})")#text(" in the ")#link("http://en.wikipedia.org/wiki/Hilbert-Schmidt_operator")[#text("Hilbert-Schmidt")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Frobenius_norm#Frobenius_norm")[#text("Frobenius")]#text(") sense.")

#text("It turns out that this approximation is not quite good enough for applications to Ricci flow, mainly because the ")#mi("\\frac{\\delta_{ij}}{2N} \\text{tr}(\\dot g) = - R \\delta_{ij} / N")#text(" term in (36) gives a significant contribution to the trace of the Ricci tensor ")#mi("\\text{Ric}^{(N)}")#text(" (i.e. the scalar curvature ")#mi("R^{(N)}")#text("), even in the limit ")#mi("N \\to \\infty")#text(". It turns out however that one can eliminate this problem by adding a correction term to the metric (24) involving the scalar curvature. More precisely, given an ancient Ricci flow ")#mi("t \\mapsto (M,g(t))")#text(", define the modified metric ")#mi("\\tilde g^{(N)}")#text(" by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#mitex("(d\\tilde g^{(N)})^2 = dy^2 + \\frac{r^2}{N^2} R(t) dr^2 + dg(t)^2")]]

#text("where of course ")#mi("dr = \\sum_{i=1}^N \\frac{y_i}{r} dy_i")#text(" is the derivative of the radial variable r, and R(t,x) is the scalar curvature of g(t) at x. In coordinates, we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("\\tilde g^{(N)}_{ij} = \\delta_{ij} + \\frac{y_i y_j}{N^2} R(t); \\tilde g^{(N)}_{ia} = 0; \\tilde g^{(N)}_{ab} = g_{ab}.")]]

#strong[#text("Exercise 5.")]#text(" Let ")#mi("t \\mapsto (M,g(t))")#text(" be a smooth ancient Ricci flow on ")#mi("(-\\infty,0]")#text(", and let ")#mi("\\tilde g^{(N)}")#text(" be defined by (37). Show that in the region where ")#mi("y_i = O(1)")#text(" (so ")#mi("-t = \\tau = O(1)")#text(") and x ranges in a compact set, the Christoffel symbols ")#mi("(\\tilde \\Gamma^{(N)})^{\\gamma}_{\\alpha \\beta}")#text(" take the form")

#tao-aligned(keep: true)[


#tao-math("(\\tilde \\Gamma^{(N)})^i_{jk}  & = \\frac{\\delta_{jk}}{N^2} R y_i + O(1/N^3)", block: true)



#tao-math("(\\tilde \\Gamma^{(N)})^i_{ja}, (\\tilde \\Gamma^{(N)})^i_{aj}, (\\tilde \\Gamma^{(N)})^a_{ij}  & = O(1/N^2)", block: true)



#tao-math("(\\tilde \\Gamma^{(N)})^i_{ab}  & = \\frac{y_i}{2N} \\dot g_{ab} + O(1/N^2)", block: true, numbering: n => [#text("(39)")])



#tao-math("(\\tilde \\Gamma^{(N)})^a_{ib}  & = (\\tilde \\Gamma^{(N)})^a_{bi} = - \\frac{y_i}{2N} g^{ac} \\dot g_{cb} + O(1/N^2)", block: true)
]

#align(center)[#mi("(\\tilde \\Gamma^{(N)})^a_{bc} = \\Gamma^a_{bc}")#text(".")]

#text("and the Ricci curvature ")#mi("\\widetilde{\\text{Ric}}^{(N)}_{\\alpha \\beta}")#text(" takes the form")

#tao-aligned(keep: true)[


#tao-math("\\widetilde{\\text{Ric}}^{(N)}_{ij}  & = O( 1 / N^2 )", block: true)



#tao-math("\\widetilde{\\text{Ric}}^{(N)}_{ia}  & = O( 1 / N )", block: true, numbering: n => [#text("(40)")])
]

#align(center)[#mi("\\widetilde{\\text{Ric}}^{(N)}_{ab} = O(1/N)")#text(".")]

#text("In particular, ")#mi("\\widetilde{\\text{Ric}}^{(N)}")#text(" has norm ")#mi("O(1/\\sqrt{N})")#text(" in the ")#link("http://en.wikipedia.org/wiki/Trace_class")[#text("trace")]#text(" (i.e. ")#link("http://en.wikipedia.org/wiki/Nuclear_operator")[#text("nuclear")]#text(") norm (and hence in the Hilbert-Schmidt/Frobenius and operator norms). ")#mi("\\diamond")

#strong[#text("Exercise 6. ")]#text(" Let the assumptions and notation be as in Exercise 5, let ")#mi("u: (-\\infty,0] \\times M \\to {\\Bbb R}")#text(" be a smooth function, and let ")#mi("u^{(N)}")#text(" be as in (31). Show that the Laplacian ")#mi("\\tilde \\Delta^{(N)}")#text(" associated to ")#mi("\\tilde g^{(N)}")#text(" obeys a similar formula to (32), but with the ")#mi("\\frac{r}{2N} \\text{tr}(\\dot g) \\partial_r u^{(N)}")#text(" term replaced by terms which are ")#mi("O(1/N^2)")#text(" when t, x are bounded. ")#mi("\\diamond")

#heading(level: 1)[#text("— Perelman’s reduced length and reduced volume —")]

#text("In the previous discussion, we have converted a Ricci flow ")#mi("t \\mapsto (M,g(t))")#text(" to a Riemannian manifold ")#mi("(M^{(N)}, \\tilde g^{(N)})")#text(" of much higher dimension which is almost Ricci flat. Let us adopt the heuristic that this latter manifold is sufficiently close to being Ricci flat that the Bishop-Gromov inequality (Corollary 1) holds (at least in the asymptotic limit ")#mi("N \\to \\infty")#text("), thus the Bishop-Gromov reduced volume ")#mi("r_0^{-N-d} B_{\\tilde g^{(N)}}((0,x_0),r_0)")#text(" should heuristically be non-increasing in ")#mi("r_0")#text(", where we fix a spatial origin ")#mi("x_0 \\in M")#text(".")

#text("In order to exploit the above heuristic, we first need to understand the distance function on ")#mi("(\\tilde M, g(t))")#text(". Let ")#mi("(y_1,x_1) = (r_1\\omega_1, x_1)")#text(" be a point in ")#mi("\\tilde M = {\\Bbb R}^N \\times M")#text(", and consider a length-minimising geodesic ")#mi("\\gamma^{(N)}: [0,\\tau_1] \\to \\tilde M")#text(" from ")#mi("(0,x_0)")#text(" to ")#mi("(r_1\\omega_1, x_1)")#text(", where we have normalised the length ")#mi("\\tau_1")#text(" of the parameter interval by the formula ")#mi("\\tau_1 = r_1^2/2N")#text(".")

#text("Observe that the metric (37) can be rewritten in polar coordinates (after substituting ")#mi("-t = \\tau = r^2/2N")#text(") as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#mitex("(d\\tilde g^{(N)})^2 = (\\frac{N}{2\\tau} + R) d\\tau^2 + 2N\\tau d\\omega^2 + dg(-\\tau)^2")]]

#text("(which is essentially the first formula in Section 6 of ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s paper")]#text("). Note that the angular variable ")#mi("\\omega")#text(" only influences the second term in this metric and not the other two. Because of this, one sees that the geodesic ")#mi("\\gamma^{(N)}")#text(" must keep ")#mi("\\omega")#text(" constant in order to be length-minimising (i.e. ")#mi("\\omega = \\omega_1")#text(" for the duration of the geodesic). Turning next to the ")#mi("\\tau")#text(" variable, we then see that for N large enough, the geodesic ")#mi("\\gamma^{(N)}")#text(" should increase ")#mi("\\tau")#text(" continuously from 0 to ")#mi("\\tau_1")#text(" (as the ")#mi("\\frac{N}{2\\tau}")#text(" term in (41) will severely penalise any backtracking. After a reparameterisation we may in fact assume that ")#mi("\\tau")#text(" increases at constant speed, thus we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#mitex("\\gamma^{(N)}(\\tau) = ( \\sqrt{2N\\tau} \\omega_1, \\gamma(\\tau) )")]]

#text("for some path ")#mi("\\gamma: [0,\\tau_1] \\to M")#text(" from ")#mi("x_0")#text(" to ")#mi("x_1")#text(". Using (41), the length of this geodesic is")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(43)")])
#tao-math("\\int_0^{\\tau_1} \\sqrt{ \\frac{N}{2\\tau} + R + \\left|\\gamma^{\\prime}(\\tau) \\right|_{g(-\\tau)}^2}\\ d\\tau", block: true)]]

#text("which by Taylor expansion is equal to")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(44)")])
#mitex("\\sqrt{2N\\tau_1} + \\frac{1}{\\sqrt{2N}} {\\mathcal L}(\\gamma) + O(N^{-3/2})")]]

#text("where the ")#emph[#mi("{\\mathcal L}")#text("-length")]#text(" of ")#mi("\\gamma")#text(" is defined as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(45)")])
#tao-math("{\\mathcal L}(\\gamma) := \\int_0^{\\tau_1} \\sqrt{\\tau} ( R + \\left|\\gamma^{\\prime}(\\tau)\\right|_{g(-\\tau)}^2 )\\ d\\tau", block: true)]]

#text("Note that this quantity is independent of N. Thus, heuristically, geodesics in ")#mi("{\\mathcal M}")#text(" from ")#mi("(0,x_0)")#text(" to ")#mi("(r_1 \\omega_1,x_1)")#text(" should (approximately) minimise the ")#mi("{\\mathcal L}")#text("-length. If we define ")#mi("L_{(0,x_0)}(-\\tau_1,x_1)")#text(" to be the infimum of ")#mi("{\\mathcal L}(\\gamma)")#text(" over all paths ")#mi("\\gamma: [0,\\tau_1] \\to M")#text(" from ")#mi("x_0")#text(" to ")#mi("x_1")#text(", we thus obtain the heuristic approximation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(46)")])
#mitex("d_{\\tilde g^{(N)}}( (0,x_0), (r_1 \\omega_1, x_1) ) = \\sqrt{2N\\tau_1} + \\frac{1}{\\sqrt{2N}} L_{(0,x_0)}(-\\tau_1,x_1).")]]

#strong[#text("Exercise 7.")]#text(" When M is the Euclidean space ")#mi("{\\Bbb R}^d")#text(" (with the trivial Ricci flow, of course), show that ")#tao-math("L_{(0,x_0)}(-\\tau_1,x_1) = \\left|x_1-x_0\\right|^2 / 2 \\sqrt{\\tau_1}", block: false)#text(", and the minimiser is given by ")#mi("\\gamma(\\tau) = x_0 + \\sqrt{\\frac{\\tau}{\\tau_1}} (x_1-x_0)")#text(". ")#mi("\\diamond")

#text("From (46) we see that the ball in ")#mi("(M^{(N)}, \\tilde g^{(N)})")#text(" of radius ")#mi("r_0 = \\sqrt{2N \\tau_0}")#text(" centred at ")#mi("(0,x_0)")#text(" (where, as always, we are in the regime ")#mi("\\tau_0 = O(1)")#text(", so ")#mi("r_0^2 = O(N)")#text(") should heuristically take the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(47)")])
#mitex("\\{ (r_1 \\omega_1, x_1): L_{(0,x_0)}(-\\tau_1,x_1) \\leq 2N (\\sqrt{\\tau_0}-\\sqrt{\\tau_1}) \\}.")]]

#text("If we make the plausible assumption that ")#mi("L_{(0,x_0)}(-\\tau,x)")#text(" varies smoothly in ")#mi("\\tau")#text(", then (47) is heuristically close (when N is large) to")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(48)")])
#mitex("\\{ (r_1 \\omega_1, x_1): L_{(0,x_0)}(-\\tau_0,x_1) \\leq 2N (\\sqrt{\\tau_0}-\\sqrt{\\tau_1}) \\}")]]

#text("or equivalently")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(49)")])
#mitex("\\{ (r_1 \\omega_1, x_1): r_1 \\leq r_0 - \\frac{1}{\\sqrt{2N}} L_{(0,x_0)}(-\\tau_0,x_1) \\}.")]]

#text("Now, the volume measure of (37) is of the form ")#mi("(1 + O(1/N)) dy d\\mu(t)")#text(", and so the volume of (49) is approximately")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(50)")])
#mitex("C_N \\int_M \\int_0^{r_0 - \\frac{1}{\\sqrt{2N}} L_{(0,x_0)}(-\\tau_0,x_1)} r_1^{N-1}\\ dr_1 d\\mu(t_1)(x_1).")]]

#text("(Note there is a slight abuse of notation since ")#mi("t_1")#text(" depends on ")#mi("r_1")#text(", but it will soon be clear that this abuse is harmless.) When N is large, the inner integral is dominated by its right endpoint as before, and so (50) is approximately")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(51)")])
#mitex("\\frac{1}{N} C_N \\int_M (r_0 - \\frac{1}{\\sqrt{2N}} L_{(0,x_0)}(-\\tau_0,x))^N d\\mu(t_0)(x).")]]

#text("We can Taylor expand this to be approximately")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(52)")])
#mitex("\\frac{1}{N} C_N r_0^N \\int_M \\exp(- l_{(0,x_0)}(-\\tau_0,x) )\\ d\\mu(t_0)(x)")]]

#text("where the ")#emph[#text("Perelman reduced length")]#text(" ")#mi("l_{(0,x_0)}(-\\tau_0,x)")#text(" is defined as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(53)")])
#mitex("l_{(0,x_0)}(-\\tau,x) := \\frac{L_{(0,x_0)}(-\\tau,x)}{2\\sqrt{\\tau}} = \\frac{\\sqrt{2N} L_{(0,x_0)}(-\\tau,x)}{2r_0}")]]

#strong[#text("Example 1.")]#text(" Continuing the Euclidean example of Exercise 7, we have ")#tao-math("l_{(0,x_0)}(-\\tau,x) = \\left|x-x_0\\right|^2/4\\tau", block: false)#text(", which is the familiar exponent in the fundamental solution (15). This is, of course, not a coincidence. ")#mi("\\diamond")

#text("From (52) we thus heuristically conclude that the Bishop-Gromov reduced volume of ")#mi("(M^{(N)}, \\tilde g^{(N)})")#text(" at ")#mi("(0,x_0)")#text(" and at radius ")#mi("r_0 = \\sqrt{2N\\tau_0}")#text(" is approximately equal to a constant multiple of ")#mi("\\tilde V_{(0,x_0)}( -\\tau )")#text(", where the ")#emph[#text("Perelman reduced volume")]#text(" ")#mi("\\tilde V_{(0,x_0)}( -\\tau )")#text(" is defined as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(54)")])
#mitex("\\tilde V_{(0,x_0)}( -\\tau ) := \\int_M \\tau^{-d/2} \\exp( - l_{(0,x_0)}( -\\tau,x) )\\ d\\mu(-\\tau)(x).")]]

#strong[#text("Example 2.")]#text(" Again continuing the Euclidean example, the reduced volume in Euclidean space (with the trivial Ricci flow) is always ")#mi("(4\\pi)^{d/2}")#text(". ")#mi("\\diamond")

#emph[#text("Formally")]#text(" applying Corollary 1, we are thus led to")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1.")]#text(" (Monotonicity of Perelman reduced volume) Let ")#mi("t \\mapsto (M,g(t))")#text(" be a Ricci flow on ")#mi("{}[-T,0]")#text(", and let ")#mi("x_0 \\in M_0")#text(". Then the quantity ")#mi("\\tilde V_{(0,x_0)}( -\\tau )")#text(" for ")#mi("0 < \\tau \\leq T")#text(" is monotone non-increasing in ")#mi("\\tau")#text(".")
]

#strong[#text("Remark 6. ")]#text("Note here we are not taking the Ricci flow to be ancient; this would correspond to the manifold ")#mi("M^{(N)}")#text(" being replaced by an incomplete manifold, of radius about ")#mi("\\sqrt{2NT}")#text(". However, because of the restriction ")#mi("\\tau \\leq T")#text(", the above heuristic arguments never “encounter” the lack of completeness, and so it is reasonable to expect that the conjecture will continue to hold in the non-ancient case. This is of course an essential point for our applications, since the Ricci flows we study are not assumed to be ancient. ")#mi("\\diamond")

#strong[#text("Remark 7.")]#text(" At an crude heuristic level, the Perelman reduced volume ")#mi("\\tilde V_{(0,x_0)}( -\\tau )")#text(" is roughly like ")#mi("\\text{Vol}_{g(-\\tau)}( -\\tau, O(\\sqrt{\\tau}) ) / \\tau^{d/2}")#text(" (since, in view of Exercise 7, we expect ")#mi("l_{(0,x_0)}(-\\tau,x)")#text(" to behave like ")#mi("d(x_0,x)^2/\\tau")#text(", especially in regions of bounded normalised curvature, where we are deliberately vague about exactly what metric we using to define d). This heuristic suggests that Conjecture 1 should be able to establish the non-collapsing result we want (Theorem 2 from ")#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("Lecture 7")]#text("). This will be made more rigorous in subsequent lectures. For now, we observe that the Perelman reduced length and reduced volume are dimensionless (just as the Bishop-Gromov reduced volume is), which as discussed in ")#link("https://terrytao.wordpress.com/2008/04/20/285g-lecture-7-rescaling-of-ricci-flows-and-kappa-noncollapsing/")[#text("Lecture 7")]#text(" is basically a necessary condition in order for this quantity to force non-collapsing of the geometry. ")#mi("\\diamond")

#text("As far as I am aware, there is no rigorous proof of Conjecture 1 that follows the above high-dimensional comparison geometry heuristic argument. Nevertheless, it is possible to prove Conjecture 1 by other means, and in particular by developing parabolic analogues of all the comparison geometry machinery that is used to prove the Bishop-Gromov inequality (and in particular, developing a theory of ")#mi("{\\mathcal L}")#text("-geodesics analogous to the “elliptic” theory of geodesics on a Riemannian manifold. This will be the focus of the next few lectures.")

#strong[#text("Remark 8.")]#text(" It seems of interest to try to make the above arguments more rigorous, and to expand the dictionary between elliptic and parabolic equations. I do not know however of much literature in this direction, apart from Section 6 of ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s original paper")]#text(" (see also Section 3.1 of ")#link("http://arxiv.org/abs/math/0612069")[#text("Cao-Zhu")]#text("), in which a few other parabolic notions (e.g. the backwards heat equation, or the modified Ricci flow from the ")#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/")[#text("previous lecture")]#text(") are reinterpreted as high-dimensional elliptic notions. See however the work of ")#link("http://www.ams.org/mathscinet-getitem?mr=1362964")[#text("Chow and Chu")]#text(" (see also this ")#link("http://www.ams.org/mathscinet-getitem?mr=1406020")[#text("sequel paper")]#text("), which views parabolic theory as a degenerate version of elliptic theory; Perelman’s viewpoint can be interpreted as a regularisation of Chow-Chu’s viewpoint. ")#mi("\\diamond")

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-29397")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2008")])]

#text("Dear Prof. Tao,")

#text("I don’t know if it’s related, but the infinite-dimensional limit dealt with in this")#linebreak()#text(" lecture (as well as parabolic theory being an infinite-dimensional limit of elliptic theory) does ring me a bell about the derivation of the heat equation from Brownian motion. The infinite-dimensional Riemannian manifold in question")#linebreak()#text(" would be the space of Brownian paths in the original Riemannian manifold, up")#linebreak()#text(" to some time rescaling – indeed, recall that the time variable has the")#linebreak()#text(" dimension of ")#mi("\\sqrt{N}")#text(", where ")#mi("N")#text(" is the number of steps")#linebreak()#text(" in the random walk. Moreover, we also know that the heat kernel is the")#linebreak()#text(" (infinite-dimensional) Fourier transform of a Gaussian measure in the space")#linebreak()#text(" of random fields which are the continuum limit of Brownian paths, by the Bochner-Minlos theorem. It seems, judging, for example, by the work")#linebreak()#text(" of Grigor’yan and others on the heat kernel in complete Riemannian manifolds, that much of this derivation can be performed for more general Riemannian manifolds, under assumptions on the geometry which are similar to those underlying the Bishop-Gromov formula.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-29488")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2008")])]

#text("Hi,")

#text("I was wondering if there was a link that categorized all the Ricci Flow/Poincare Conjecture articles into one webpage? I’m having trouble finding the first lecture and working my way to the present article.")

#text("Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-29489")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2008")])]

#text("Dear Anon,")

#text("You can try")

#link("https://terrytao.wordpress.com/category/teaching/285g-poincare-conjecture/")[#text("https://terrytao.wordpress.com/category/teaching/285g-poincare-conjecture/")]

#text("(For some reason, my articles are not being picked up by the global wordpress tag system, so the links just below the article titles are not working properly, but presumably this will sort itself out at some point.)")

#text("Dear Pedro: Thanks for the interesting comments; what you say sounds broadly consistent with my own speculations on the role of Brownian motion in this limit (see Remark 4 above). It would be nice to have a precise connection, though, even in the Euclidean case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 10: Variation of L-geodesics, and monotonicity of Perelman reduced volume « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-29644")[#strong[#text("285G, Lecture 10: Variation of L-geodesics, and monotonicity of Perelman reduced volume « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2008")])]

#text("[…] a heuristic derivation of the monotonicity of Perelman reduced volume (Conjecture 1 from the previous lecture), we now turn to a rigorous proof. Whereas in the previous lecture we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 11: κ-noncollapsing via Perelman reduced volume « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-29888")[#strong[#text("285G, Lecture 11: κ-noncollapsing via Perelman reduced volume « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2008")])]

#text("[…] reduced volume in the previous lecture (after first heuristically justifying this monotonicity in Lecture 9), we now show how this can be used to establish -noncollapsing of Ricci flows, thus giving a second […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 13: Li-Yau-Hamilton Harnack inequalities and κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-29891")[#strong[#text("285G, Lecture 13: Li-Yau-Hamilton Harnack inequalities and κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2008")])]

#text("[…] one by Chow and Chu using a metric closely related to the high-dimensional metrics considered in Lecture 9, but all of the proofs I know of require a significant amount of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 14: Stationary points of Perelman entropy or reduced volume are gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-29966")[#strong[#text("285G, Lecture 14: Stationary points of Perelman entropy or reduced volume are gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2008")])]

#text("[…] we first consider the simpler model case of the Bishop-Gromov reduced volume (Corollary 1 of Lecture 9). An inspection of the proof of that result reveals that the key point was to establish the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 15: Geometric limits of Ricci flows, and asymptotic gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-30085")[#strong[#text("285G, Lecture 15: Geometric limits of Ricci flows, and asymptotic gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2008")])]

#text("[…] large n. Also, from the curvature bounds and Bishop-Gromov comparison geometry (Lemma 1 from Lecture 9) we know that the volume of is uniformly bounded from above for sufficiently large […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 16: Classification of asymptotic gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-30142")[#strong[#text("285G, Lecture 16: Classification of asymptotic gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2008")])]

#text("[…] geometry of constant curvature K, much as in the discussion of the Bishop-Gromov inequality in Lecture 9. See Petersen’s book for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-30164")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("There’s an issue that puzzles me about the Bishop-Gromov volume comparison theorem, especially in the case of non-negative Ricci curvature.")

#text("If we look at balls ")#mi("B(x,r)")#text(" of (small) radius ")#mi("r")#text(" inside geodesically convex charts centered, say, at ")#mi("x\\in M")#text(", we can think of the Radon-Nikodym derivative of the measure induced by the Riemannian metric w.r.t. the one induced by the Euclidean metric in the chart (which is just the Lebesgue measure) at ")#mi("x")#text(" as the limit of (a constant which depends only on the dimension times) the Bishop-Gromov reduced volume of ")#mi("B(x,r)")#text(" as ")#mi("r\\searrow 0")#text(". The Bishop-Gromov inequality seems to imply that the Radon-Nikodym derivative at ")#mi("x")#text(" equals 1. So far, nothing strange.")

#text("What seems puzzling to me is that, if ")#mi("\\mu")#text(" is the usual Riemannian")#linebreak()#text(" measure and we define a new measure ")#mi("\\nu")#text(" in ")#mi("M")#text(" by first defining ")#mi("\\nu(B(x,r))=\\frac{\\text{Vol} S^{d-1}}{d}r^d")#text(" and then extending it to all Borel sets by means of Caratheodory’s construction of outer measures (the latter can be modified so as to guarantee that ")#mi("\\nu(U\\cap V)=0")#text(" for all Borel sets ")#mi("U,V")#text(" such that ")#mi("\\inf_{x\\in U,y\\in V}  d(x,y) > 0")#text("), then not only will ")#mi("\\nu")#text(" match Lebesgue measure in Riemannian normal charts for small geodesically convex balls, but, by the reasoning in the previous paragraph, we will have that ")#mi("\\frac{d\\mu}{d\\nu}=1")#text(" (almost) everywhere, however these two measures are not equal in general! Am I missing or screwing up something in my reasoning above?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-30187")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("Dear Pedro,")

#text("Caratheodory’s construction requires the volumes that one assigns to balls to be compatible: if for instance one ball is the countable disjoint union of many other balls, then the volume assigned to the former ball must be the sum of the volume assigned to the latter. The balls you propose will not have this property (think about what happens, say, on the round sphere ")#mi("S^d")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-30196")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("So, the problem is what happens to _large_ (i.e. non geodesically convex) balls, I suppose? Because for small balls in geodesically convex neighbourhoods, ")#mi("\\nu")#text(" as defined in my last post is just Lebesgue measure in Riemann normal coordinates, and for those countable disjoint coverings by smaller balls should give the right result.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-30199")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2008")])]

#text("Dear Pedro,")

#text("The measure formed from Lebesgue measure on normal coordinates from one point x are not the same as the measure formed by Lebesgue measure on normal coordinates from another point y, unless the manifold happens to be flat. Thus, for instance, you can have B(x,r) have Euclidean volume for all r (up to the injectivity radius, at least), or B(y,r) have Euclidean volume for all r, but in general you can’t have both simultaneously with a single measure, due to the presence of curvature. For instance, in hyperbolic space one can pack many more small balls of radius r disjointly into a large ball of radius R than in Euclidean space (indeed, in hyperbolic space the packing number grows exponentially in R for fixed r). Here the problem is not failure of injectivity (normal coordinates are global here), but the constant presence of negative curvature.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-30204")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2008")])]

#text("Now I see my mistake… :-p Thanks a lot!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ky")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-30947")[#strong[#text("ky")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2008")])]

#text("If somebody could please explain in more detail the derivation behind the five formulas in (34) involving Christoffel symbols and the three formulas in (36) involving Ric, it would be really great.")

#text("Thanks you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JC")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-30961")[#strong[#text("JC")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2008")])]

#text("ky:")

#text("For (34), simply use the expressions for the metric in (25) into the formula (33), and calculate, e.g. the first equation:")

#mi("(\\Gamma^{(N)})^i_{jk} = \\frac{1}{2} g^{i \\delta} ( \\partial_j g_{k \\delta} + \\partial_k g_{j \\delta} - \\partial_\\delta g_{jk} )")

#text("Now ")#mi("g^{(N)}_{ij} =\\delta_{ij}")#text(" implies that the last term vanishes (since it’s a constant). The second and third terms you can break into the ")#mi("g_{ka}, g_{ja}")#text(" type terms (when the index ")#mi("\\delta=a")#text("), which are zero from (25), and also ")#mi("g_{ki}, g_{ji}")#text(" terms (when the index ")#mi("\\delta=i")#text(") which are ")#mi("\\delta_{ki},\\delta_{ji}")#text(" and hence zero after differentiation with respect to ")#mi("j,k")#text("…")

#text("For (36), just use the equations derived in (34) in evaluating the components of (35) in a similar way. Is this what you meant?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ky")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-31052")[#strong[#text("ky")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2008")])]

#text("JC:")

#text("Thank you so much. As a student, while I took baby Riemannian Geometry course, I never understood the Christoffel symbol fully. With you help, I got the first 2 of (34). But when it comes to the last 3 of (34) and (36) I am still struggling; e.g. the N on the denominator and y_i on the numerator. If you could get me started with those the way you did for the first one in (34), I would appreciate it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tricks Wiki article: The tensor product trick « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-32275")[#strong[#text("Tricks Wiki article: The tensor product trick « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2008")])]

#text("[…] Example 8. (Monotonicity of Perelman’s reduced volume) One of the key ingredients of Perelman’s proof of the Poincaré conjecture is a monotonicity formula for Ricci flows, that establishes that a certain geometric quantity, now known as the Perelman reduced volume, increases as time goes to negative infinity. Perelman gave both a rigorous proof and a heuristic proof of this formula. The heuristic proof is much shorter, and proceeds by first (formally) applying the Bishop-Gromov inequality for Ricci flat metrics (which shows that another geometric quantity – the Bishop-Gromov reduced volume, increases as the radius goes to infinity) not to the Ricci flow itself, but to a high-dimensional version of this Ricci flow formed by adjoining an M-dimensional sphere to the flow in a certain way, and then taking (formal) limits as . This is not precisely the tensor power trick, but is certainly in a similar spirit. For further discussion see “285G Lecture 9: Comparison geometry, the high-dimensional limit, and Perelman’s reduced volume.” […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikhail Gromov wins 2009 Abel prize « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-37506")[#strong[#text("Mikhail Gromov wins 2009 Abel prize « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("[…] geometry (which (together with its parabolic variant, the monotonicity of Perelman reduced volume) plays an important role in Perelman’s proof of the Poincaré conjecture), the concept of Gromov-Hausdorff convergence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 9: Applications of the structural theory of approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-104885")[#strong[#text("254A, Notes 9: Applications of the structural theory of approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2011")])]

#text("[…] of Ricci curvature, which would be beyond the scope of these notes); but see for instance this previous blog post of mine for a proof. This inequality is consistent with the geometric intuition that an increase in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on simple groups of Lie type | What's new")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-243959")[#strong[#text("Notes on simple groups of Lie type | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("[…] and sectional curvatures uniformly bounded from below. Applying Myers’ theorem (discussed in this previous blog post), we conclude that any cover of is necessarily compact also; this implies that the fundamental […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb985f16b0b2cab9f6cd0eeaf7c9d42a4b11e0e8c50435f62ce79e685c67fcda-046a844fea67b30a5da4ba375600100765a7a23a50f3b89a926a36d12bc9dab0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yifan")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-640485")[#strong[#text("Yifan")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2022")])]

#text("I think in formula (10), we should get -2t/N \\partial_{tt} f-\\partial_t f and also in formula (12) we should have r^2/N^2 \\partial_{tt} u-\\partial_t u+\\Delta_x u")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb985f16b0b2cab9f6cd0eeaf7c9d42a4b11e0e8c50435f62ce79e685c67fcda-046a844fea67b30a5da4ba375600100765a7a23a50f3b89a926a36d12bc9dab0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yifan")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-640489")[#strong[#text("Yifan")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2022")])]

#text("Also in formula (20) RHS should be r_0^N exp(-N|x|^2/(2r_0^2))")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb985f16b0b2cab9f6cd0eeaf7c9d42a4b11e0e8c50435f62ce79e685c67fcda-046a844fea67b30a5da4ba375600100765a7a23a50f3b89a926a36d12bc9dab0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yifan")]], [#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/#comment-640699")[#strong[#text("Yifan")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2022")])]

#text("Again some typos: in formula (49) (50) (51), it should be ")#mi("\\frac{1}{\\sqrt {2N}}L_{(0,x_0)}(-\\tau_0,x_1)")

#emph[#text("[Corrected, thanks – T.]")]
]
