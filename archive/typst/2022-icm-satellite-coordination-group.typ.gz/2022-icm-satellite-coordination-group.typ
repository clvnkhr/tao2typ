// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/
// Converted to Typst by tao2typ: "2026-10-14T16:39:01.039008+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "2022 ICM satellite coordination group", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("2022 ICM satellite coordination group")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 March 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/")[#text("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[Note: while I happen to be the chair of the ICM Structure Committee, I am authoring this blog post as an individual, and not as a representative of that committee or of the IMU, as they do not have jurisdiction over satellite conferences. -T.]")]

#text("The International Mathematical Union (IMU) has ")#link("https://www.mathunion.org/fileadmin/IMU/Publications/CircularLetters/2022/IMU%20AO%20CL%209_2022.pdf")[#text("just released some updates")]#text(" on the status of the ")#link("https://www.mathunion.org/icm/virtual-icm-2022")[#text("2022 International Congress of Mathematicians")]#text(" (ICM), which was discussed in ")#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/")[#text("this previous post")]#text(":")

#list(
[#text("The General Assembly will take place in person in Helsinki, Finland, on July 3-4.")],
[#text("The IMU award ceremony will be held in the same location on July 5.")],
[#text("The ICM will take place virtually (with free participation) during the hours 9:00-18:00 CEST of July 6-14, with talks either live or pre-recorded according to speaker preference.")]
)

#text("Due to the limited time and resources available, the core ICM program will be kept to the bare essentials; the lectures will be streamed but without opportunity for questions or other audience feedback. However, the IMU encourages grassroots efforts to supplement the core program with additional satellite activities, both “traditional” and “non-traditional”. Examples of such satellite activities include:")

#list(
[#text("“Traditional” satellite conferences, held in person at a time near the ICM. Several such satellite events had already been scheduled, and are now satellite events for the virtual ICM:")

#list(
[#link("http://math.iisc.ac.in/fpsac2022/")[#text("34th International Conference on Formal Power Series & Algebraic Combinatorics")]#text(" (July 18-22, India)")],
[#link("https://www2.helsinki.fi/en/conferences/probability-and-mathematical-physics")[#text("Probability and Mathematical Physics")]#text(" (June 28-July 5, Finland)")],
[#link("https://indico.ipmu.jp/event/409/")[#text("Geometric Representation Theory")]#text(" (June 27-July 2, Japan)")],
[#link("https://mega2022.up.krakow.pl/")[#text("Effective Methods in Algebraic Geometry")]#text(" (June 20-24, Poland)")],
[#link("https://racag22.c.matinf.uj.edu.pl/")[#text("Recent Advances in Classical Algebraic Geometry")]#text(" (June 28-July 7, Poland)")],
[#link("https://www.math.ku.dk/english/calendar/events/oadg2022")[#text("Operator Algebras, Dynamics and Groups")]#text(" (July 1-4, Denmark) [Note: several ICM speakers from Section 8 will present their lecture here.]")],
[#link("https://prf.uhk.cz/dga2022/")[#text("Differential Geometry and its Applications")]#text(" (July 17-23, Czech Republic)")],
[#link("https://www.mathematik.uni-marburg.de/~agricola/SSL2022/")[#text("Seminar Sophus Lie")]#text(" (June 12-19, Norway)")],
[#link("https://icdea2022.sciencesconf.org/")[#text("27th International Conference on Difference Equations and Applications")]#text(" (July 18-22, France)")],
[#link("https://www.math.columbia.edu/~idpeis22/")[#text("Isomonodromic Deformations, Painlevé Equations, and Integrable Systems")]#text(" (June 27-Jul 1, USA)")]
)],
[#text("“Watch parties” or “mirror conferences” hosted by institutions and departments around the world.")],
[#text("“Sectional overlay conferences”, in which ICM speakers from a ")#link("https://www.mathunion.org/fileadmin/IMU/Report/SC/2019/structure_committee_final.pdf")[#text("specific section")]#text(" (or pair of sections) are invited to present their ICM talk in person in front of a live audience from that section. Some overlay conferences will be held concurrently with the ICM; others are planned to be held shortly beforehand, and the talks then supplied to the ICM as prerecorded talks. Of course, ICM speakers would not be obligated to attend these conferences (and several of these meetings may also schedule additional events not associated to the ICM). Currently we have the following such conferences:")

#list(
[#text("An ")#link("https://people.math.ethz.ch/~zerbess/index_ICM.html")[#text("ICM sectional workshop in number theory and algebraic geometry")]#text(", ETH Zürich, July 11th–14th 2022, covering Sections 3 and 4 of the program.")],
[#link("https://www.math.ku.dk/english/calendar/events/icmgeometrytopologysections/")[#text("Geometry and Topology ICM sectional workshop")]#text(", University of Copenhagen, July 6-14 2022, covering Sections 5 and 6 of the program.")],
[#link("https://ims.nus.edu.sg/events/representations-and-characters-revisiting-some-aspects-of-the-works-of-harish-chandra-and-weil/")[#text("Representations and Characters: Revisiting the Works of Harish Chandra and André Weil")]#text(", National University of Singapore, Jul 1-15, covering Section 7 of the program.")],
[#link("https://math.huji.ac.il/~dynamics/ETB-ICM.php")[#text("Dynamics in Jerusalem")]#text(", Hebrew University, July 6-8, covering Section 9 of the program.")],
[#text("The aforementioned ")#link("https://www2.helsinki.fi/en/conferences/probability-and-mathematical-physics")[#text("Probability and Mathematical Physics")]#text(" meeting in Finland on June 28-July 5 will also overlay Sections 11 and 12 of the program.")],
[#link("http://www.hairer.org/ICM/")[#text("Applied mathematics ICM overlay/satellite meeting")]#text(", Imperial College London, July 8-12 2022, covering Sections 15 and 18 of the program.")]
)],
[#text("Regional satellite events, which would be similar to sectional overlay conferences but focused on a single geographical region rather than a section. Efforts are underway to set up such events in ")#link("https://mathematical-research-institute.sydney.edu.au/news/icm2022-down-under/")[#text("Australia")]#text(", Boston, Bonn, ")#link("https://www.mathsoc.jp/activity/meeting/JapanForum2022/")[#text("Japan")]#text(", and possibly Vietnam.")],
[#text("Q&A sessions or online chats. A ")#link("https://discord.gg/T72dTkfSzF")[#text("Discord channel has been set up")]#text(" (administered by Martin Hairer, Kevin Buzzard, and myself) to (unofficially) discuss the ICM lectures as they are being given; input is welcome on how best to utilize this channel.")],
[#text("An ")#link("https://sites.google.com/view/scs-2022-call/")[#text("online short communications satellite")]#text(" for the virtual ICM.")],
[#text("The London Mathematical Society has kindly agreed to host the ICM public lectures (as well as the LMS lecture) as a virtual satellite event, by ")#link("https://www.lms.ac.uk/events/vICM-Satellite-Event-Public-Lecture-by-Geordie-Williamson-%28Sydney%29")[#text("Geordie Williamson")]#text(", ")#link("https://www.lms.ac.uk/events/vICM-Satellite-Event-Public-Lecture-by-Eleni-Giorgi-Colombia")[#text("Elena Giorgi")]#text(", and ")#link("https://www.lms.ac.uk/events/vICM-Satellite-Event-Public-Lecture-by-Tadashi-Tokieda-Stanford")[#text("Tadashi Tokieda")]#text(".")],
[#text("Other creative examples of “non-traditional satellite events”. (For instance, one idea would be to create a wiki-type web site for the ICM in which speakers could supply introductory videos, slides, and other material for their talks; the IMU unfortunately does not have the logistical and technical capability to run this themselves, but one could imagine some third party being able to set this up instead.)")]
)

#text("A more updated list of these events ")#link("http://www.hairer.org/ICMSCG/")[#text("can be found here")]#text(".")

#text("I will also mention the ")#link("https://caseazatmiftakhov.org/2022/02/15/azat-miftakhov-days-july-5-6-2022/")[#text("second Azat Miftakov Days")]#text(", which are unaffiliated with the ICM but held concurrently with the beginning of the congress (and the prize ceremony).")

#text("Strictly speaking, satellite events are not officially part of the Congress, and not directly subject to IMU oversight; they also receive no funding or support from the IMU, other than sharing of basic logistical information, and recognition of the satellite conferences on the ICM web site. Thus this (very exceptional and ")#emph[#text("sui generis")]#text(") congress will differ in format from previous congresses, in that many of the features of the congress that traditionally were managed by the local organizing committee will be outsourced this one time to the broader mathematical community in a highly decentralized fashion.")

#text("In order to coordinate the various grassroots efforts to establish such satellite events, Alexei Borodin, Martin Hairer, and myself have set up a ")#link("https://groups.google.com/g/icm-satellite-event-coordination-group")[#text("satellite coordination group")]#text(" to share information and advice on these events. (It should be noted that while Alexei, Martin and myself serve on either the structure committee or the program committee of the ICM, we are acting here as individuals rather than as official representatives of the IMU.) Anyone who is interested in organizing, hosting, or supporting such an event is welcome to ask to join the group (though I should say that most of the discussion concerns boring logistical issues). Readers are also welcome to discuss broader issues concerning satellites, or the congress as a whole, in the comments to this post. I will also use this space to announce details of satellite events as they become available (most are currently still only in the early stages of planning).")

#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/#comment-641343")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2022")])]

#text("Concerning the discord server, right now the sections are organized as separate channels under the category “Sections” and everything else is placed in the “General” category.")

#text("It might be better to subdivide this a bit more, so that we have a category for “Plenary Lectures” and each plenary lecture is given its own channel. This would avoid chat overlap between people discussing different talks. Each section could similarly be given its own category, with the individual talks given their own channels.")

#text("Also, the section names are currently labeled as “section-N”. It might be better to include the subject as well, so that it reads “section-5 geometry” for instance.")

#emph[#text("[Channels have been renamed as per your suggestions – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/#comment-641344")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2022")])]

#text("I think this would also help to transition the discord server into a permanent discussion hub after the ICM. Having a separate category for each math subject area would make it easier to create new channels in an organized fashion under a pre-existing category, should there be any demand for them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/#comment-641346")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2022")])]

#text("Has it been decided what software will be used to stream the live lectures?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a04c83e86d769062ef3f777df324f02635f2a99d7c66fac69532f11520f36e3-7401a58e80ec2855688c84b36976b1c0074af1891fec75caa2763143a37c8c6e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Hairer")]], [#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/#comment-641512")[#strong[#text("Martin Hairer")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("My understanding is that the current plan is to use the platform developed by “Let’s Get Digital”, which has also been used for the online editions of the Heidelberg Laureates Forum. I am not familiar with this platform though, so do not know what (if any) interactive features it would provide.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grpaseman")]], [#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/#comment-641352")[#strong[#text("grpaseman")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2022")])]

#text("I have made a post regarding some issues that relate to the upcoming efforts. It is at ")#link("https://grpaseman.wordpress.com/2022/03/11/international-congress-of-mathematicians-reminscence-and-suggestions/")[#text("https://grpaseman.wordpress.com/2022/03/11/international-congress-of-mathematicians-reminscence-and-suggestions/")]#text(" .")

#text("Briefly, archiving and curating the data coming forth from this is important, and the IMU should declare a policy on what data from the ICM will be preserved and what won’t; it should also have guidelines for what it will take from satellite events to archive for future students/members; a congress message box for each attending member can be useful to catch some of the questions and ideas associated with the ICM; there are ways to crowdsource efforts to hold Short Communications and Poster sessions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd8d1d90343ef0d9a57e051b72b88d2de782cd809dac95bb2dbf1614a2a56642-91cf450563022cceb09332b8020a4b26ff66f7804c9d6f16073e8b9358a278d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor Porton")]], [#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/#comment-641357")[#strong[#text("Victor Porton")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2022")])]

#text("“For instance, one idea would be to create a wiki-type web site for the ICM in which speakers could supply introductory videos, slides, and other material for their talks; the IMU unfortunately does not have the logistical and technical capability to run this themselves, but one could imagine some third party being able to set this up instead.”")

#text("A wiki scientific conference is already several years as set: ")#link("https://conference.portonvictor.org")[#text("https://conference.portonvictor.org")]#text(" (however, the project is in need of moderators, so I disabled new user creation and funding for such things as a top-level domain name). Consider to donate here: ")#link("https://giveth.io/project/help-my-open-source-software-and-science-development")[#text("https://giveth.io/project/help-my-open-source-software-and-science-development")]

#text("It would be a stupid idea to create a new wiki site for every separate scientific conference (that’s like having separate Wikipedia for astronomy and for dietology), you already have my wiki site, use it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/#comment-641358")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2022")])]

#text("It would be nice to have a blog for ICM2022, where video recordings and discussions are posted, and then others can discuss the subject by posting comments like they do at your blog posts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/654860f7ab3bccdacdd1edf4ed9ca7a452824bc33757d21bd183dd0012aafae1-bef87085757bcf462a3a59c721d677df37b119c3fd1e9113e67b868e9183be0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edgawliet")]], [#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/#comment-641391")[#strong[#text("Edgawliet")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2022")])]

#text("Where can I register for this? Or the program? At IMU web page cannot find it.")

#emph[#text("[The web page for the ICM is still under construction; details will be made available later. As the congress is now free admission, probably no registration will be required. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/#comment-641479")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2022")])]

#text("Something wrong with your blog. The most recent comments section is missing on the left column.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/#comment-641511")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("I feel like I had something to do with this, but I’m sorry if that is the case. Someone wants to do Professor Tao’s analysis books’ exercises and read the chapters, I’ve never read them but I anticipate good things.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/#comment-641517")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("Tao，have you find the suitable virtual conference organizer？if not，give me a message，I have someone to recommend～")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f893e77b7bd3dff46eaa1408c8ac1f37522d51244f0d8740c4eaaa121612f63-0a2b21e4e6e006adc42411c5cef550e9508e3508ed30f315082c2b6165528d5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steffen Plunder")]], [#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/#comment-641616")[#strong[#text("Steffen Plunder")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2022")])]

#text("About the idea of wiki-based “non-traditional satellite events”.")

#text("Maybe mathoverflow.net would be an interesting location for that? One could try to provide a timeslots where researchers are encouraged to post/answer their research questions there. It could be a nice way for math exchange and the output would remain visible afterwards.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/#comment-641632")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2022")])]

#text("One could perhaps propose this idea at ")#link("https://meta.mathoverflow.net/")[#text("https://meta.mathoverflow.net/")]#text(" to gauge feedback from the user community there. My guess though is that the mathoverflow format is best optimized for question/answer posts where there is a single well defined question that can be answered definitively by a single answer, with only a limited amount of back-and-forth conversation. The unofficial ICM Discord server that is already set up at ")#link("https://discord.gg/T72dTkfSzF")[#text("https://discord.gg/T72dTkfSzF")]#text(" might be able to host this sort of discussion more effectively, however.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/#comment-641628")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2022")])]

#text("I’m pleased to announce that one of the sectional overlay conferences now has a web page: the ")#link("https://people.math.ethz.ch/~zerbess/index_ICM.html")[#text("ICM sectional workshop in number theory and algebraic geometry")]#text(", to be held in Zurich in parallel with the virtual ICM, and which will cover Sections 3 and 4 of the program. Further such satellite events will be announced here as they go “live”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/#comment-641795")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2022")])]

#text("Another sectional overlay conference now has a live web page: the ")#text("Geometry and Topology ICM sectional workshop")#text(", to be held at the University of Copenhagen, July 6-14 2022, covering Sections 5 and 6 of the program.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adrian Fellhauer")]], [#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/#comment-641754")[#strong[#text("Adrian Fellhauer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2022")])]

#text("I see, so the ICM is going on… I’ve got a feeling I’m not going to be invited to the party…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/#comment-641852")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2022")])]

#text("Tao，I cannot open the link of the 27th international conference on difference of equations and applications…")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/03/11/2022-icm-satellite-coordination-group/#comment-643030")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2022")])]

#text("We now have a ")#link("http://www.hairer.org/ICMSCG/")[#text("stable web page")]#text(" to maintain a list of all satellite events (both traditional and non-traditional) for the virtual 2022 ICM. In particular, we now have physical satellite events to “overlay” Sections 3, 4, 5, 6, 9, 11, 12, 15, and 18 of the program, as well as a satellite for short communications.")
]
