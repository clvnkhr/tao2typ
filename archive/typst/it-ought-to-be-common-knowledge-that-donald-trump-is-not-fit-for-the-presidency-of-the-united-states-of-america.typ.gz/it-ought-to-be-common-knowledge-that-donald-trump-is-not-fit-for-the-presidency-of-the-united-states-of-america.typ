// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/
// Converted to Typst by tao2typ: "2026-10-14T15:19:44.830994+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "It ought to be common knowledge that Donald Trump is not fit for the presidency of the United States of America", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("It ought to be common knowledge that Donald Trump is not fit for the presidency of the United States of America")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 June 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/")[#text("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In logic, there is a subtle but important distinction between the concept of ")#emph[#text("mutual knowledge")]#text(" – information that everyone (or almost everyone) knows – and ")#link("https://en.wikipedia.org/wiki/Common_knowledge_(logic)")[#text("common knowledge")]#text(", which is not only knowledge that (almost) everyone knows, but something that (almost) everyone knows that everyone else knows (and that everyone knows that everyone else knows that everyone else knows, and so forth). A classic example arises from Hans Christian Andersens’ ")#link("https://en.wikipedia.org/wiki/The_Emperor%27s_New_Clothes")[#text("fable of the Emperor’s New Clothes")]#text(": the fact that the emperor in fact has no clothes is mutual knowledge, but not common knowledge, because everyone (save, eventually, for a small child) is refusing to acknowledge the emperor’s nakedness, thus perpetuating the charade that the emperor is actually wearing some incredibly expensive and special clothing that is only visible to a select few. My own personal favourite example of the distinction comes from the blue-eyed islander puzzle, discussed previously ")#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/")[#text("here")]#text(", ")#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/")[#text("here")]#text(" and ")#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/")[#text("here")]#text(" on the blog. (By the way, I would ask that any commentary about that puzzle be directed to those blog posts, rather than to the current one.)")

#text("I believe that there is now a real-life instance of this situation in the US presidential election, regarding the following")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(". The presumptive nominee of the Republican Party, Donald Trump, is not even remotely qualified to carry out the duties of the presidency of the United States of America.")
]

#text("Proposition 1 is a statement which I think is approaching the level of mutual knowledge amongst the US population (and probably a large proportion of people following US politics overseas): even many of Trump’s nominal supporters ")#link("http://bigstory.ap.org/article/dcf9e9b0552c40b1964c6c5c87e7c51f/speaker-paul-ryans-trump-endorsement-comes-caveats")[#text("secretly suspect that this proposition is true, even if they are hesitant to say it out loud")]#text(". And there have been many prominent people, from both major parties, that have made the case for Proposition 1: for instance Mitt Romney, the Republican presidential nominee in 2012, ")#link("http://www.nytimes.com/video/us/politics/100000004249503/mitt-romneys-full-speech-against-donald-trump.html")[#text("did so back in March")]#text(", and just a few days ago Hillary Clinton, the likely Democratic presidential nominee this year, did so in this speech:")#linebreak()

#text("I highly recommend watching the entirety of the (35 mins or so) speech, followed by the ")#link("https://twitter.com/realDonaldTrump/status/738449664752553984")[#text("entirety of")]#text(" ")#link("https://twitter.com/realDonaldTrump/status/738720347239809024")[#text("Trump’s")]#text(" ")#link("http://www.nytimes.com/2016/06/03/us/politics/donald-trump-california-protests.html")[#text("rebuttal")]#text(".")

#text("However, even if Proposition 1 is approaching the status of “mutual knowledge”, it does not yet seem to be close to the status of “common knowledge”: one may secretly believe that Trump cannot be considered as a serious candidate for the US presidency, but must continue to entertain this possibility, because they feel that others around them, or in politics or the media, appear to be doing so. To reconcile these views can require taking on some implausible hypotheses that are not otherwise supported by any evidence, such as the hypothesis that Trump’s ")#link("https://www.youtube.com/watch?v=DnpO_RTSNmQ")[#text("displays of policy ignorance, pettiness, and other clearly unpresidential behaviour")]#text(" are merely “for show”, and that behind this facade there is actually a competent and qualified presidential candidate; much like the emperor’s new clothes, this alleged competence is supposedly only visible to a select few. And so the charade continues.")

#text("I feel that it is time for the charade to end: Trump is unfit to be president, and everybody knows it. But more people need to say so, openly.")

#strong[#text("Important note")]#text(": I anticipate there will be any number of “")#link("https://en.wikipedia.org/wiki/Tu_quoque")[#text("tu quoque")]#text("” responses, asserting for instance that Hillary Clinton is also unfit to be the US president. I personally do not believe that to be the case (and certainly not to the extent that Trump exhibits), but in any event such an assertion has no logical bearing on the qualification of Trump for the presidency. ")#strong[#text("As such, any comments that are purely of this “tu quoque” nature, and which do not directly address the validity or epistemological status of Proposition 1, will be deleted as off-topic")]#text(". However, there is a legitimate case to be made that there is a fundamental weakness in the current mechanics of the US presidential election, particularly with the “")#link("https://en.wikipedia.org/wiki/First-past-the-post_voting")[#text("first-past-the-post")]#text("” voting system, in that (once the presidential primaries are concluded) a voter in the presidential election is effectively limited to choosing between just two viable choices, one from each of the two major parties, or else refusing to vote or making a largely symbolic protest vote. This weakness is particularly evident when at least one of these two major choices is demonstrably unfit for office, as per Proposition 1. I think there is a serious case for debating the possibility of major electoral reform in the US (I am particularly partial to the ")#link("https://en.wikipedia.org/wiki/Instant-runoff_voting")[#text("Instant Runoff Voting system")]#text(", used for instance in my home country of Australia, which allows for meaningful votes to third parties), and I would consider such a debate to be on-topic for this post. But this is very much a longer term issue, as there is absolutely no chance that any such reform would be implemented by the time of the US elections in November (particularly given that any significant reform would almost certainly require, at minimum, a constitutional amendment).")

#heading(level: 1)[#text("Comments (506)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-7/#comment-682834")[#strong[#text("Wealth, Intellectualism, and Individualism, Part 6 – Grey Enlightenment")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2024")]

#text("[…] Terrance Tao, possibly the most brilliant mathematician alive, wrote an article about Trump being unfit to be president, which went massively viral despite the article having nothing to do with math, but because people, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-7/#comment-684916")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2024")])]

#text("This election also seems close. Some say Trump is going to win.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-7/#comment-685356")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2024")])]

#text("It ought to be common knowledge that Joe Biden is not fit for the presidency of the United States of America")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-7/#comment-688818")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2025")])]

#text("Did you read the part about ‘Tu quoque’? Do you realize that you just committed that same logical fallacy?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-7/#comment-685370")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2024")])]

#text("Seeing the news? It seems the incident will make it not even close for Trump. He may win with better margins.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-7/#comment-685821")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2024")])]

#text("How things have changed since July")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-7/#comment-686535")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2024")])]

#text("Think Harris will win 2024? This election is also to close to predict. Can the current climate be modeled by any mathematical models with any certainty?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-7/#comment-686540")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2024")])]

#text("With certainty? No. Especially with polling being such big business, the average citizen is aware enough of polling that it skews results. This is a general phenomena is statistics where the more aware people are of how they are measured, the harder it is to measure them. Currently things look better for Harris, but it maxes at 60-40 if you are being objective. Anyone telling you their model is guaranteed to produce the winner is selling you a dream.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-7/#comment-688535")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2025")])]

#text("Thanks for stating the obvious Terry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-7/#comment-688721")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2025")])]

#text("The posting was just after the escalator ")#link("https://en.wikipedia.org/wiki/Donald_Trump_2016_presidential_campaign#Announcement")[#text("Donald Trump 2016 presidential campaign – Wikipedia")]#text(". It shows how many of us were misguided, deluded, opportunistic to support him in 2016 though waveringly but enough to distort results and how even Professor Tao with all his knowledge was not fast enough (including Barack Obama and Hillary Clinton) to foresee the trainwreck to write sooner.")

#text("It will be Gavin Newsom in 2028.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bb59e0a8353ef50c4fa01fca09e0afc26abe865572c899f7afb646046fee258-58022e796e82df0a245199d944dabdb763afe041c4093e84a6b0d8008cdbe1ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffrey Helkenberg")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-474790")[#strong[#text("Jeffrey Helkenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2016")])]

#text("I appear to draw out poison; have I ever stated that I am in any way superior to those gathered here? I am sure we are all quite “fit” for our jobs. We are familiar with the symbols of our trades, but surely the inner workings of our government are known only as shadows to those of us who get our “facts” at a distance.")

#text("I appreciate the erratum. Functional languages only overlap so much with poetic expression. My logic was spot-on as relates to Mr. Tao’s assertion that a man not fit to be President has become so. Had he met Mr Trump prior to his becoming President-Elect Trump? If so it was not mentioned in the Proposition.")

#text("######")#linebreak()#text(" Proposition 1. The presumptive nominee of the Republican Party, Donald Trump, is not even remotely qualified to carry out the duties of the presidency of the United States of America.")#linebreak()#text(" ######")

#text("Alternatively,")

#text("######")#linebreak()#text(" Machine 1.")#linebreak()#text(" Where,")#linebreak()#text(" “A man who is not remotely qualified is the most likely to be elected,”")#linebreak()#text(" it must be that,")#linebreak()#text(" “The United States (as a population) is not even remotely qualified to gauge the duties of the Office of President.”")#linebreak()#text(" #######")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7a18708ef03756cf2269d403f1d30447fb749f4254cb3e3d4aeee286d5e24b2-47dc46877f33c9d3a1446ce768710f4167850da611ab4a27bb15c1f43abba30c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-475070")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2016")])]

#text("Stop. Just stop making a complete fool out of yourself.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-474961")[#strong[#text("Shtetl-Optimized » Blog Archive » Daddy, why didn’t you blog about Trump?")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2016")]

#text("[…] typically focuses on things like gaps in the primes and finite-time blowup in PDEs, wrote an unusual post, arguing that virtually everyone knows Donald Trump is unqualified to be President, so the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64c90ce0f36c60d347f3c6d79f8c556c6b308d05a6d6107508ca517ccd22f953-aba000ceaa4b77ed6b8797617517cb31d53a2d8c71445d3dc89d03a3116732c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nuclear Trump")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-475191")[#strong[#text("Nuclear Trump")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2016")])]

#text("OH MA DAYS this must be some sort of nightmare is this guy crazy or what “The United States must greatly strengthen and expand its nuclear capability until such time as the world comes to its senses regarding nukes” ")#link("https://twitter.com/realDonaldTrump/status/811977223326625792")[#text("https://twitter.com/realDonaldTrump/status/811977223326625792")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/392fd86c10fadb1498ef563602a7550b0cdc861ea84521e9e061635b44366281-55f01768ccaabe45bd3bcc23fa7368b9ff84d120abcae0e5039a88d8401a813a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-476271")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2017")])]

#text("This is the Reverse Sokal Hoax.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/392fd86c10fadb1498ef563602a7550b0cdc861ea84521e9e061635b44366281-55f01768ccaabe45bd3bcc23fa7368b9ff84d120abcae0e5039a88d8401a813a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-476272")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2017")])]

#text("Hate is OK, as long as it’s toward a hater.")#linebreak()#text(" All misogynists love women.")#linebreak()#text(" Any other paradox?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-476358")[#strong[#text("How Polling Works…Or Doesn’t Work – Study Score Calc")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2017")]

#text("[…] are a host of quantitative ways to deal with the election right now – and some slightly more qualitative ways as well – but I find the best thing to do is light some aromatherapy candles, immerse […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e769f5dc38f291cc6a2303462740a721d4da7f21d4f6c8d90dc31edce0c8698b-769c9e4ba666c54d35128348eb3dea4f47e8f8e35fd29891986f9cf6fcf06b78.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tracey Cullen")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-476371")[#strong[#text("Tracey Cullen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2017")])]

#text("What now?")#linebreak()#text(" Seriously.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-477301")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2017")])]

#text("Just noticed the quote at the top from the The New Colossus. Bravo!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-477313")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2017")])]

#text("Just noticed it too!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-477323")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("I can not believe that the partition is closed")

#text("From Gordon Ball")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Open thread for mathematicians on the immigration executive order | What's new")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-477326")[#strong[#text("Open thread for mathematicians on the immigration executive order | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("[…] of the qualifications, or lack thereof, of the current US president can be carried out at this previous post.) I would therefore like to open this post to readers to discuss the effects or potential effects […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-478244")[#strong[#text("Terry’s inference about the president Trump – 站点标题")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2017")]

#text("[…] 通过 It ought to be common knowledge that Donald Trump is not fit for the presidency of the United States… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3bdc152281f9e625e4a808cf1a512e847a380dcd23d2ac11a6bd4d83a3d446ab-7c240195a7e876656f4f5cc83616ef3acbcb20417e02580cc574dce12e459854.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trump Cutting Science Funding is Sad")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-479144")[#strong[#text("Trump Cutting Science Funding is Sad")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2017")])]

#text("Trump is cutting a lot of science funding for the military, sad!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon123")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-481013")[#strong[#text("Anon123")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2017")])]

#text("This blog entry has aged very well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fae26034fda84a22ddc16e94578a9d62e4485aa226a7c34c097820da105cf4d-5c87fea301987f6f750c5a6cae722842da01f1f1c4d5c49761ee778b523427a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TrumpSupporter")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-481177")[#strong[#text("TrumpSupporter")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2017")])]

#text("Terry,")

#text("I saw you removed my comment. Too bad. Silencing critics is never the way to go, particularly in the age of the internet. I am replying here, per your indication.")

#text("Hillary Clinton and the left wing media learned the lesson painfully that silencing views in traditional media today is pointless these days. Fewer and fewer people get their information from there.")

#text("I get that you are new to using your scientific celebrity for political purposes, particularly in the US.")

#text("So let me offer a piece of unsolicited advise.")

#text("Unlike the world of mathematics, where there is a somehow objective way to measure good ideas, particularly say, proofs to theorems known to be very difficult, like both Wiles and Perelman did, or by coming up ideas that, while mathematical in nature, end up affecting society at large as say John Nash did with his work in non cooperative games, the world of politics, particularly in the US, is eminently subjective.")

#text("What this means is that the reason people vote for this or that candidate are very personal and most times do not have a very rational explanation. That applies to both people voting for right wing candidates as well as left wing candidates. Take for example the candidate you preferred for the general election. We know, and this is factual, from the Wikileaks revelations, that she is politically corrupt. I don’t know how many of the Podesta emails you read, but in case you didn’t read any, somebody did the effort of compiling the most compromising ones and making the case why each of them showed political corruption of the first order: ")#link("http://www.mostdamagingwikileaks.com/")[#text("http://www.mostdamagingwikileaks.com/")]#text(" .")

#text("I get that you probably like Hillary Clinton for other reasons, such as the Democratic Party’s traditional support of government funding for research, but that opinion would essentially prove my point: you too probably find things you don’t like about her, but there are other reasons you believe she was the best candidate. Fair enough.")

#text("The world of academia in the US is essentially an echo chamber for left wing ideology. If you feel you are surrounded by very smart people and that those smart people lean left and you are making the mental connection “smart people are leftists” is because few in academia would openly declare their support for right wing ideas, let alone Trump, for fear of retaliation from people like you. I can assure you, and I have both anecdotal as well as more rigorous evidence, to back this up, that academics with right wing tendencies or that support Trump are not unicorns. They are real and they exist in every top notch American university, yet they have to live in the halls of academia like gays in the 50s: leading a double life. Over time, you also have the pernicious effect that young scholars give up the opportunity of joining the tenured academic ranks altogether because whatever benefits academia provides, they do not make up for having to live silenced during one’s most valuable years.")

#text("You are at a crucial point in your career. You have gotten great awards already but none of your achievements amount to anything that would make you belong to the pantheon of mathematicians when you pass away. The only Millennium problem solved to this day is the work of Grigori Perelman who decided to quit mathematics altogether and refused to join you guys at the 2006 ICM because he understood that 100 yeas from now all that people will remember is that he is the one who solved the Poincare conjecture, not the names of those of you who accepted to be part of the charade. Nobody remembers today what were the most sought after scientific awards in the the time of Gauss and who won them. We remember Gauss for the monumental contributions he made to mathematics and physics.")

#text("So it is your choice frankly. Getting on board with hating leftists will get you celebrity today and this life for sure. But, are you sure you want this your legacy to be vs say, proving the Riemann hypothesis?")

#text("Once thing is for certain. The more you come across as an anti-Trump bigot, the more non leftists will shun you out. Even the same leftists who hail you today will have no problem running away from you the day you are first and foremost known for your political agenda vs your mathematical contributions.")

#text("This doesn’t mean it is a bad idea to have your political views known by the public. But it matters that you do it in a way that makes people who support the candidates you don’t like, like me, feel that they don’t belong to your intellectual discussion.")

#text("I voted for Trump and I would vote again for him. I also happen to be highly educated. From my vantage point, he is the best thing that has happened in US politics since Ronald Reagan. The events of the last few weeks show to what point the swamp is real and the degree to which all US presidents since Eisenhower had gladly accommodated the wishes of the military industrial complex. We are lucky we have a president who doesn’t back down and who is willing to put a fight with the losers who have been ruining the United States since the end of the cold war.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-481185")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2017")])]

#text("you sound highly educated.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d80708e880dc7f7c882132be130fb8035ffb380baad61a23bfea1212af84745b-72a1b48f0db1368b5bd4bdc6df32fb86c3c0a3ae2a3c6c21bcc6be92aec49edb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TrumpSupporter")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-481187")[#strong[#text("TrumpSupporter")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2017")])]

#text("Not sure if this is a serious comment. Just in case it is: what Terry did with this post is to cross what I call the “William Shockley line”. Shockley, a brilliant man, made possible for you and I to have this conversation since without the transistor there would not have been an electronics age. Debates aside whether the transistor would have been invented by other people any way -such as by co-inventor and co-winner of the Noble Prize in physics for doing so John Bardeen- the reality is that Shockley was a brilliant man.")

#text("In the latter part of his life, he became obsessed with the pseudoscience of ")#link("https://en.wikipedia.org/wiki/Dysgenics")[#text("https://en.wikipedia.org/wiki/Dysgenics")]#text(" ; he started to preach that data showed that blacks were genetically inferior to whites when it came to intelligence and that they -blacks- should be paid to undergo voluntary sterilization for the benefit of the United States. He died, and duly so, ostracized and in infamy.")

#text("Terry is basically implying in this post that only absolute and complete morons would even consider voting for Trump for who would vote for somebody who is not qualified to be president of the USA knowingly? To be clear, I am pretty sure that some absolute morons voted for Trump -just as I am certain that some absolute morons voted for Hillary Clinton- but really, are there 63 million morons in the United States? That’s what Terry implies with this post!")

#text("To the best of my knowledge he has not apologized for writing this crap nor has he tried to reach out to those 63 million people in the aftermath of Trump’s election with something like “I deeply disagree with your decision to vote for Trump, but I feel your pain”. If he -Terry- has, I apologize for my comments.")

#text("Ultimately, Terry’s is a sad case. Up until he wrote this entry, he had an impeccable reputation as somebody who was a pleasure to work with and who was always willing to entertain working on interesting mathematical problems with people regardless of any other consideration. Who will now approach him knowing that he thinks that Trump voters are morons? Certainly not Trump voters or supporters. So he has suddenly reduced the universe of potential collaborators by roughly half (the half of people who support Trump). I am sure he got a lot of great supportive emails from leftists, but he already had their support anyway. I don’t know what he gets by coming across so insensitive with the people who voted for Trump. Only to confirm the widespread belief that academics live in ivory towers detached from reality. Et tu,Terry! The Terry Tao myth was just busted.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f749cd7344d3de40ef2e29773a1e9b2f8c99ed43f1f19c93f4eb54f4455c1d38-362f920eb4db23b093115afd011185078dd4bf0c534f54680fb190d6f3fcfed5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TrumpSupporter")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-481192")[#strong[#text("TrumpSupporter")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2017")])]

#text("@Shocked It is not an overreach. If anything, Tao’s position is even worse than Shockley’s as measured by the numbers. William Shockley was obsessed with the intelligence of blacks. There were 22.5 million blacks living in the US in 1970, when Shockley’s lunacy was at its peak. Today there are around 40 million blacks living in the United States. That’s still blow the 63 million people whose intelligence Terry Tao questions. Granted, Terry Tao hasn’t asked that Trump voters follow voluntary sterilization as Shockley did but I think that’s a minor difference. On both cases you have an individual who considers a big chunk of his fellow American citizens as not worth having a big role in society because they are too dumb to have one. If you think that racial animus is worse than political animus, then that’s a different matter, but honestly, I don’t see much of a difference except for the victim: political preferences can be hidden from plain sight whereas racial status cannot. Still, as a Trump supporter who lives and works in a very liberal place, I can assure you that it is not fun to be surrounded by people who hate Trump as much as Terry.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-481210")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2017")])]

#text("How much is the GRU paying you for this BS?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ADT")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-481270")[#strong[#text("ADT")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2017")])]

#text("It’s “Nobel Prize”, not “Noble Prize”.")

#text("Yeah, you really sound “highly educated”.")

#text("Here’s some “unsolicited advise [sic]”: better to keep your mouth shut and be thought perhaps a fool, than to open it and remove all doubt.")

#text("Let’s guess: you are “Jeffy Helkenberg’s” latest sockpuppet.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-481208")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2017")])]

#text("Hey moron, you posted your chickenshit Trump ass-kissing in a thread devoted to a math issue, and now you’re whining here that you’ve somehow been “silenced”….after Tao allows you to post.")

#text("Go away. You’re obviously an idiot.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7cd1449a13c6871b59e01a46ea21582e9acf8ad9665155029d44c1b7b38daed7-d18c3dd93b4b0f3784eabe7cd423901ecb4b2451bb37eaaaf87831f4b11f2ddc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TrumpSupporter")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-481213")[#strong[#text("TrumpSupporter")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2017")])]

#text("Do you have any substantive refutation to my arguments? Because frankly, but resorting to insults you are just proving my point.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FreedomSupporter")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-481222")[#strong[#text("FreedomSupporter")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2017")])]

#text("Ugh. What “arguments” did you make, victim? You are a petulant child, sobbing you were “silenced” by posting on the very website you claim “silenced” you.")

#text("You’re the one who wandered in to insult the host with your utter stupidity. Now you’re whining that we’re insulting you. Hypocrite much?")

#text("We get it. You’re an eternal victim with the insecurities of a baby bunny. No wonder Trump appeals to you.")

#text("You posted illogical nonsense, inappropriately, in a thread devoted to a mathematical discussion. You are now here complaining that because you couldn’t be bothered to abide by simple site rules and common courtesy, you were…wait for it…”silenced”.")

#text("The fact that everyone is here reading your ongoing stupidity means you weren’t “silenced”, right genius? So much for any grasp of logic on your part. Do you bother to even read your own illogic and misspellings that put the lie to your odd “highly educated” self-description?")

#text("As for your vapid support for a racist, sexual-assaulting, draft-dodging, failed businessman, tax-cheat, gutless serial liar, that’s not an “argument”. But it says everything we all need to know about your own values and ethics.")

#text("As you yourself noted, that’s something you and the people who are unfortunate enough to be around you are painfully dealing with. You’re bringing it on yourself.")

#text("Work out your personal issues somewhere else, idiot.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20d33672c0a79fd0048159e7dcd59e421800bfd284e930e3c1e3c1714c42cae5-321d146ab513bdebfefdd8e641b03402d6f1c439b34617b8dac8dde229f546f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TrumpSupporter")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-481229")[#strong[#text("TrumpSupporter")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2017")])]

#text("63 million Americans voted for Trump. Thanks for confirming that this post has transformed Terry Tao into a cult leader. The cult of bigots who look down at people who don’t think like them. As I said, the parallel with William Shockley could not be clearer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-481266")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2017")])]

#text("Fantastic. Arguing ethics…from vote counts. Why, the logic of it all. The mind reels…")

#text("A certain politician received 18 million votes in 1933 — about the same percentage of voters as Trump in 2016 — and went on to shut down the courts, tell countless “big lies”, shut down the free press, and build any number of xenophobic walls in the holy service of nation-first and generalized anxiety disorder.")

#text("Here are bleating idiots like you in 1934: “how can 18 million people be idiots? Any contempt toward such voters MUST be “bigotry”. How could it be otherwise? It’s 18 MILLION people”.")

#text("Could you possibly be any more illogical?")

#text("Trump is a demonstrably mentally-ill coward. You keep mentioning William Shockley for some unknown reason – he’s a racist idiot. He and his few followers are despicable. Trump is a racist idiot. He and his followers (the numbers are shrinking rapidly) are despicable. You and they are creating enormous suffering via your ignorance.")

#text("You ARE the typical Trump supporter – illogical, semi-literate, ignorant, and quasi-hysterical. You’ve proven that here, right before our eyes. This site is a celebration of logic and reason. Trump and your views are the antithesis of such. You came in and tried to ridicule Dr. Tao with your long-winded stupidity, then whined like a child when your silly, impotent attack was rightly ridiculed.")

#text("Please take it somewhere else.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/430033ec661f80c4a80a72a8a9380f31c567e5fa85a3982ca9285d90c4c517fc-96a04359325edfc7b7a4b2bb48aa11dbabc37593a813ed4e2bdbf6906010bbfc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 573")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-542358")[#strong[#text("573")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2020")])]

#text(">claiming you were “silenced” by posting on the very website you claim “silenced” you.")

#text("Do you need some reading glasses? Terry removed his comment.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-481223")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2017")])]

#text("“Because frankly, but resorting to insults you are just proving my point.”")

#text("Yessirree, that’s a sentence only the “highly educated” write.")

#text("Looks like you are proving a different point here, Mr. TrumpSupporter (that’s like Trump jock-strap, right?)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20d33672c0a79fd0048159e7dcd59e421800bfd284e930e3c1e3c1714c42cae5-321d146ab513bdebfefdd8e641b03402d6f1c439b34617b8dac8dde229f546f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TrumpSupporter")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-481230")[#strong[#text("TrumpSupporter")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2017")])]

#text("Dude, I don’t follow you anymore.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/430033ec661f80c4a80a72a8a9380f31c567e5fa85a3982ca9285d90c4c517fc-96a04359325edfc7b7a4b2bb48aa11dbabc37593a813ed4e2bdbf6906010bbfc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 573")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-542359")[#strong[#text("573")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2020")])]

#text(">that you’ve somehow been “silenced”….after Tao allows you to post.")

#text("Do you need some reading glasses, idiot? Tao removed his original comment.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/913f718c20efc03a0fd5a0e27977cf4ae8896b716558e69ae13196887256a0fd-a7ba1983474cc6d1780e77ba0b6dbab90c1b75134d64a3fefba0e6a12dc91b8b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shocked")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-481190")[#strong[#text("Shocked")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2017")])]

#text("someone who compares the level at which Shockley and Tao ever worked needs to get his brain checked up")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/913f718c20efc03a0fd5a0e27977cf4ae8896b716558e69ae13196887256a0fd-a7ba1983474cc6d1780e77ba0b6dbab90c1b75134d64a3fefba0e6a12dc91b8b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shocked")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-481255")[#strong[#text("Shocked")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2017")])]

#text("But I do think that Trump will be winning in 2020 as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jubalix Zxcain")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-483980")[#strong[#text("Jubalix Zxcain")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2017")])]

#text("Fitness to be president is not by the population saying or believing proposition ‘x’ in general, it comes from meeting constitutional requirements and a specific manifestation of belief via voteing from a specific group of people, which not necessarily coincidence (though part of it could be) with the forms of knowledge you propose.")

#text("You maybe confusion the meaning of ‘Fit to be president’ within a popular but irrelevant context, rather than the specific context which actually qualifies you to be president, meeting the various constitutional and subordinate legislation.")

#text("The important part is the system where you can try to effect constitutional change, to encompass a bundle of markers you may see as a better mix to establish who or what entity holds what power. This seems to be the correct point of redress to your issues.")

#text("Looking at the pointy end and saying person X in not fit sort of misses the whole machinery of trying to establish a balance of powers that can operate over a long period of time and give some sort of benefit (arguable in itself but put it to one side).")

#text("I proffer the real complaint here is one of constitutional operation as the proper feed back mechanism and how the separation of powers are apportioned and gained, and the debate has been sort of uselessly co-opted to near lowest common denominators of “fit to be president” in a sound byte form rather than actually dealing with what that means.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b5c57f0afaf8612d547ccaba86d53d773103fae1eea0862b755c24e04c27d87-0301e2fa309e70a02be2cd8ce7c72fee31c0fcbdc82c423049266d946f2a5120.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-484950")[#strong[#text("Guilherme")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2017")])]

#text("Reasonable ideas. Unfortunately, wrong ones. You could not prove your proposition that Trump was unqualified to the position. That is not a mathematical problem. We did’t/don’t have all the sufficient premises to get to that kind of strong conclusion. Not even close. In politics, “right” or “wrong”, “qualified” or “unqualified”, depends hugely on what you want. To people who wanted an outsider, a conservative, or maybe even a “crazy” president to “drain the Washington swamp”, maybe in this case Trump was perfect and fit. For example, the fact that Trump has a rough and rude rhetoric, which you consider very bad, could never be considered an absolute bad: it could actually be a good thing in the view of people who are very angry with Washington politicians, and so on. So, you can not “prove” that Trump was unfit, to everybody, as a fact and an universal truth. At least you can not so easily prove that. In politics, subjective factors matters a lot. By the way, you forgot to define “qualified President” (or “a good President”), which would be logically necessary.")

#text("Besides that, even taking your premises and your implicit definition of “qualified President” as the “right” ones, even in this case it would be very very hard to ensure that Trump was unfit to the job. There are so many variables, there are so many uncertain things, there are so many misleading “facts” (from all sides), there are so many lies (from all sides), there are so many secrets (about Trump, Hillary, USA, the world and everything). Plus: you can not believe 100% in CNN, or NYTimes or Fox News. How could you 100% ensure that NYTimes and CNN only work for sake of the truth? What about if the lie(d) about Trump? And even if they only publish(ed) true stories, how could you guarantee that they don’t/didn’t omit inconvenient truths in order to favor people they support?")

#text("In fact, if you watch Fox News or CNN or NYTimes you have two very different perspectives. Who is saying the truth? I give you a very good example. Do you remember when NYTimes and CNN media said that Trump had mocked a disabled reporter? They even published the video “proving the truth”. Had you believed that story? Everybody believed. Well, that was an untrue story. Trump had already made very similar gestures to mock many other people who were not disabled. But the (fake) media of course didn’t tell us that detail. Watch this: ")#link("https://www.youtube.com/watch?v=UgaC0leEb68")[#text("https://www.youtube.com/watch?v=UgaC0leEb68")]

#text("You could find many other similar examples to that effect. You see? The media can mislead people not only telling false stories (which is not so frequent) but also omitting some truths (which is common), or even focusing too much in some specific truths (which happens all the time). Another example: ")#link("http://www.factcheck.org/")[#text("http://www.factcheck.org/")]#text(". Ok, a good website, but what about if they mostly fact check Trump? Maybe if they fact checked every politician they would find the same number of mistakes or lies.")

#text("Even YOU did that here, Sir. You wrote this text claiming that Trump is disqualified for the job, but you did not mention anything about Hillary qualification. That could mislead people. Politics is the art of the “least worse”, so it is indispensable to evaluate all the possibilities.")

#text("It is often very disappointing to read or listen to some experts in areas such as math talking about politics. We realize that expertise in one fields doesn’t guarantee good opinions in other ones. Even mathematicians, physicists or engineers, who work so much with logic, who work everyday so rigorously to find truths, even those people make so big mistakes when the are out of their specialized field of knowledge. Those people so often express very childish, naïve, superficial and even false opinions. It’s so disappointing and almost unbelievable. That shows the total difference between intelligence (“IQ”) and culture, knowledge and experience.")

#text("Finally, I know that Trump has and had many failures, many problems. Of course I know. But to state categorically that he was/is unqualified and unfit to be the President is not THAT easy. Man, politics is even more complex than mathematics and I thought that your knowledge of dynamic systems would prevent you from venturing with such strong opinions into complex fields that you apparently don’t know very well, with all due respect.")

#text("Thank for the space. (Sorry about my english, it’s not my first language).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Give it a rest")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-485039")[#strong[#text("Give it a rest")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2017")])]

#text("Blah blah blah we get it, you don’t know the difference between a proposition and a proof and you spread misinformation and you want us all to overlook Trump’s widely acknowledged and documented draft-dodging, racism, sexual assault bragging, business failures, tax-dodging, and probable treason.")

#text("Trump is FAILING. There is no doubt of that. He is DANGEROUS in his ignorance and hatred.")

#text("Tao warned us about it months ago. He was exactly right.")

#text("Oh. And quit using repeated sock puppets to post the exact same mindless drivel here. Your endless, ineffectual axe grinding is stupid.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b5c57f0afaf8612d547ccaba86d53d773103fae1eea0862b755c24e04c27d87-0301e2fa309e70a02be2cd8ce7c72fee31c0fcbdc82c423049266d946f2a5120.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-485060")[#strong[#text("Guilherme")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2017")])]

#text("You didn’t contradict anything I said in my comment. I only see feelings, empty words and names coming out from your reply. Usual…")

#text("You just repeat the leftist pattern of histeria and partisanship. I challenge you to prove that Trump is racist, sexist and criminal, as you said. That’s not true, thats just propaganda! The fact that Trump has many flaws, the fact that he said many stupidities in his life, the fact that he committed many mistakes etc., doesn’t mean he is that devil that some people paint and imagine – some of them with political or economic motivations. We all have flaws, man. But part of the media only exploit and show his flaws!")

#text("Furthermore, Trump is not failing as President. Besides the fact that this assertion is partly subjetive, I give three briefs arguments: (1) Economy and jobs are doing very well; (2) illegal immigrations has been decreasing; and (3) North Korea is finally being controlled (Kim Jong Un has just backed down on his last missile threat).")

#text("Finally, I don’t want to discuss Trump’s administration. My point was a philosophical one. And I repeat it here: “good” or “bar”, “right” or “wrong” in politics and ethics depends highly on subjective factors (as interests, culture etc.), something very different from mathematics. I didn’t say “totally”, I said “highly”. So it’s not simple to state that A or B is absolutely unqualified or unfit. Respect Trump and his supporters, respect democracy and before expressing your histeria and hate, try to see that Trump is a human being like us and, although he has MANY PROBLEMS, he has virtues as well.")

#text("My suggestion: try to read different perspectives. Read people who criticizes Trump but also read people who support Trump. It’s vital.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Give it a rest II")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-489076")[#strong[#text("Give it a rest II")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2017")])]

#text("There’s nothing to “contradict” in your statement, moron. You spew opinion and think of it as fact. Like Trump himself…")

#text("We get it. You have mommy issues. Work them out somewhere else besides a math blog.")

#text("My suggestion: grow a brain. And a spine. Your support for someone of Trump’s horrible character and his cowardice says volumes about you and your values. And your grasp of math is as tenuous as your ethics.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3dda66135e8e69b5f4bc9ecbd2b3493e3b998e4733e211b287c06aa83780d24d-c826ac1df0836aef7ffb86f3138c9c8cf431cd8e3d67c99626b9a7b20d93101a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LiberalsAreNewNazis")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-485050")[#strong[#text("LiberalsAreNewNazis")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2017")])]

#text("I come here a bit late, but given what happened last Saturday, and that the label “Nazi” has been thrown around as a mantra I need to say this.")

#text("First of all, I condemn unambiguously and without qualifications the violence perpetrated in Charlottesville, the so called “neo Nazis”, the KKK and all white (and in fact all “race”) supremacists. Period, no qualifications. They are all evil, as far as I am concerned.")

#text("I want to add to that, in fact. When one thinks about the label “Nazi”, one is referring to the original ones, those who lived during the 1930s and the 1940s. Those people had the following characteristics,")

#text("– They were, on average, more educated than the rest of the world population. It is not only that Nazi Germany, itself, was more educated than the rest of world societies -including the US-, it’s that those around the world who professed love for the German Nazis were also the most educated of their respective societies, specially here in the US.")

#text("– They had a blind faith in government; to be more precise, they strongly believed that if only they- the Nazis- became in charge of governing without democratic controls, a more “perfect” society could be achieved. Obviously “perfect” meant, whatever those Nazis deemed perfect.")

#text("– Speaking of “perfect”, in their “perfect” society, a series of people where declared anathema and undesirable: not only Jews, but gays, Gypsies, mentally and physically disabled, etc.")

#text("This week, CBS did a special on how Iceland had virtually eliminated people with down syndrome,")

#link("https://www.cbsnews.com/news/down-syndrome-iceland/")[#text("https://www.cbsnews.com/news/down-syndrome-iceland/")]

#text("Now, you tell me which group of people, in 2017, puts a high premium on higher education -ie, not that they believe that higher education is valuable, but rather, that they treat it as if it was some sort divine oracle-, believe that government should have the power to tell most people how to live their lives and believe in eliminating -via abortion- people they deem undesirable, like people with down syndrome. Let me tell you, it is not the average Trump voter. It is the average liberal who is more likely to be like this, and therefore a genuine 2017 Nazi.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-485081")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2017")])]

#text("Jesus this is dumb.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2a0466d4ff3e6aa3fe748759e56e5f36ca00ebf268f97bb04753189e4fc0d04-b0732cc9ecf3ad3cf0d098b674e72c4809acedeba25e57f8875e9aff61337d37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LiberalsAreNewNazis")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-485085")[#strong[#text("LiberalsAreNewNazis")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2017")])]

#text("How so? For a label to have meaning, it needs to focus on the substance, not on peripheral characteristics. It’s basic mathematical reasoning A -> B by no means is the same as B -> A. Just because these so called “neo Nazis” use the same label, it doesn’t mean they are as corrosive as the original ones. To be as corrosive as the original ones, they would need to be highly educated -much higher than average-, have a belief in government’s ability to so called “improve society” and finally, have a meticulous plan to get rid of large groups of people whom they deem undesirable. As I said, this substantive description fits better the way of American liberals, particularly highly educated ones, than the ways of the losers that call themselves “neo Nazi”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-485123")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2017")])]

#text("As a German, let me educate you on German history. The Nazis were not keen on education. To the contrary, Hitler promulgated the kind of perverse view that the only healthy individual was a physically adept one, ready to fight against the people he wanted to destroy; after all, this was Hitler’s significant character trait: The desire to destroy and kill. The educated were bullied (e.g. large portions of the Jewish intellectual elite were driven out of the country or, in fact, murdered) and if you had any social democratic ideas, you were at risk of suffering repercussions.")

#text("You will find upon reading the corresponding Wikipedia entry (")#link("https://en.wikipedia.org/wiki/Economy_of_Nazi_Germany")[#text("https://en.wikipedia.org/wiki/Economy_of_Nazi_Germany")]#text(") that Hitler in fact went for a free-market economical programme in order to boost Germany’s economy into a ready-for-war state, despite having promised the exact opposite before the election. Furthermore, individuals subject to slave labour had NO social security, workplace rights etc., which would perhaps be things which a U.S. liberal may endorse.")

#text("Equating abortion with murder always upsets me somewhat, since abortion is not about murdering a living creature, but merely aborting a fetus that has no feelings, since it does not have a central nervous system.")

#text("Finally, I believe that if people like, say, Andreas Mölzer of Austria were to gain power, it may well happen that atrocities like the murderous internment camps of Nazi Germany respawn. Neo-Nazis are still evil, but since, as back then, they recruit themselves from the rather more shallow thinkers (indeed, note that many of the greatest German mathematicians (Hilbert, Weyl, Friedrichs, Artin etc. and certainly not the Jewish ones like von Neumann, Hausdorff, Noether etc.) were not Nazis, and further note that the other nations had their fair stock of genius which possibly ultimately defeated Nazi Germany) they are simply powerless to implement their vicious agenda.")

#text("The Nazi period is a shameful spot on Germany’s history. It was by no means a historical necessity. My obligation is, I feel, to do everything in my power to prevent a Nazi resurgency, and yet, some (probably you too) would call me a “liberal” for my political stances.")

#text("And finally, let’s hope that Obamacare remains in place, so that people with Down syndrome can get access to the care they need, disregarding the financial status of their parents.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5292f20423322eb3d3a2c813abc13e693d944f07b624f7084abbe05d73cf5d36-0a6565d3ad3358ae47a4ef851910532cc8c2bb0b077366073eb4a98f2d82d8be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LiberalsAreNewNazis")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-485126")[#strong[#text("LiberalsAreNewNazis")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2017")])]

#text("Maths student,")

#text("I see you are very confused about several things. Let’s begin with this,")

#text("“Equating abortion with murder always upsets me somewhat, since abortion is not about murdering a living creature, but merely aborting a fetus that has no feelings, since it does not have a central nervous system.”")

#text("I don’t think you realize you are making my point by dehumanizing -just as the Nazis did with Jews, gays, Gypsies and disabled- unborn children. Now, that thinking of fetuses as unborn children is proper is something that very intelligent people agree with these days. Just watch this,")

#text("Christopher Hitchens, Robert Price, Arif Ahmed and the late Nat Hentoff are among the most important XXI-st century atheist intellectuals.")

#text("But you don’t stop there. Then you try to re-write history by trying to make us believe that the overwhelming majority of highly educated German Nazis opposed the eugenics agenda of Hitler. Or that Hitler, the poster example of what a totalitarian ruler is, somehow defended free markets. The recent publishing of letters by Bohr addressing his meeting with Heisenberg in September 1941 when the Nazi victory seemed assured directly contradicts what you are saying.")

#text("Look, I understand that it must be hard, as a German who loves science, to live with the cognitive dissonance that some of Germany’s greatest intellectuals, such as Heisenberg, were at the very minimum supporters of eugenics and in most cases outright Nazi sympathizers. But you don’t get to a better destination by denying and forgetting history. You get to a better destination by analyzing it and fight hard not to make the same mistakes. For example, to pretend that Iceland is not committing genocide against Down Syndrome people is just delusional. Iceland’s government, admittedly, is in a quest to get rid of these people. Does it really matter that their lives are terminated inside their mothers’ womb rather than the Aktion T4 way from a moral point of view? I don’t think so.")

#text("The arrogance that comes with intellectual brilliance is way more dangerous for humanity than the uneducated “neo Nazis” of today. Remember that it was the best of the brightest that got the US into Vietnam War, into the Iraq War and who caused the 2008 financial crisis via sophisticated financial engineering.")

#text("If we are going to use the “Nazi” label properly, today’s Nazis are overwhelmingly liberal Democrats in the US. I know a bit less about German politics, but from a distance it seems to me that both the CSU/CDU and the SPD embrace Nazi like ideas like the annihilation of Down Syndrome people.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b4f056c2bd46692f5ed8125b43e1d738131f1273f044c03950ce6f8d5ce37bc-bfb598f73596994f30a7c21e40750d2ac5ecf702da523a0d7a7302474bece3e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LiberalsAreNewNazis")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-485127")[#strong[#text("LiberalsAreNewNazis")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2017")])]

#text("Maths student,")

#text("And I forgot. This reference to Obamacare must be one of biggest red herrings -which in case you don’t know is a logical fallacy- ever. If the availability of government paid benefits that enable people to lead normal lives were the way we decide the value human life, pretty soon tons of people would join the list of undesirables.")

#text("If you truly believe that the reason Down Syndrome people are being eliminated by Iceland is to save costs, then again you are making my point that Germany didn’t get very far in its Nazi detox program. They just massaged the 1930s Nazi concepts to make it more amenable for people like you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4162a44cd9a6770ba63777bc5ac1d70f74ecd76c9c98c2174e4381c466fea707-fad2313f3c2860a0dfd08d61cf7f178dd72407823bdb66fb6b00d3da7bef3240.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LiberalsAreNewNazis")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-485128")[#strong[#text("LiberalsAreNewNazis")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2017")])]

#text("Maths student,")

#text("And my apologies for yet another post, because your so called “reasoning” keeps getting worse. From the Wikipedia link you sent,")

#text("” When Hitler became Chancellor in 1933, he introduced policies aimed at improving the economy. The changes included privatization of state industries, autarky, and tariffs on imports. Wages increased by 10.9% in real terms during this period However, reduced foreign trade meant rationing in consumer goods like poultry, fruit, and clothing for many Germans.”")

#text("That’s something that Bernie Sanders would propose in the US. One of the biggest mischaracterizations of Trump’s economic program is that he is a protectionist. He isn’t. He is for re-negotiating existing trade deals, like NAFTA, to ensure they have the interest of the American people first (and not Mexico’s or Canada’s) and to not get into new ones unless the terms benefit the American people. As a matter of principle Trump is pro-trade, but trade that is mutually beneficial to the US, not trade that enriches countries like Mexico and China at the expense of destroying American’s middle class. It is Bernie Sanders who is a true protectionist.")

#text("But it gets better. Then you read,")

#text("“Even before the war, Nazi Germany maintained a supply of slave labour. “Undesirables” (German: unzuverlässige Elemente), such as the homeless, homosexuals, and alleged criminals as well as political dissidents, communists, Jews, and anyone else that the regime wanted out of the way were imprisoned in labour camps. Prisoners of war and civilians were brought into Germany from occupied territories after the German invasion of Poland. The necessary labour for the German war economy was provided by the new camp system, serving as one of the key instruments of terror. Historians estimate that some 5 million Polish citizens (including Polish Jews) went through them.”")

#text("How this is “free market” is beyond me. In fact, making an analogy to today’s America, which party defends the influx of uneducated laborers so that these laborers work in the US in such harsh conditions that they they could be called properly “indentured servitude”? Well, you guessed it: the Democratic Party for the most part. You also have the Republican faction of “Never Trumpers” defending this too. This faction, while being the majority among the so called “establishment Republicans” is the minority among Republican primary voters who soundly defeated it by nominating Donald Trump for President.")

#text("I’ll stop now. I hope you get the idea. Not only you didn’t refute any of my points, but your attempts to play semantics and massage words ended up backfiring badly.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f46e51164f6a7dd5aaa22c74bd847003237597c65ff95e3a03460c409666c050-0a9aa28b82be3374c1007c9af04265bdab9f9b209cbb588a1ed74b22deae5062.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TRUMP FOR 2020")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-485193")[#strong[#text("TRUMP FOR 2020")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2017")])]

#text("Trump for 2020!!! GO TRUMP #MAGA!! LIBS BTFO")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65fc0348e2ef251f8457e4b0e76ca0df9b424a2b1c21a71854c598f28c3f506c-d2512f0be132f953edd04eb00d0d0757c088546cc572f4f17f50a5cce527eed6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LiberalsAreNewNazis")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-485198")[#strong[#text("LiberalsAreNewNazis")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2017")])]

#text("Amen brother! Nazis are as pervasive in the higher echelons of academia today as they were in the 1930s, only they have learned to adapt their language and manners to sound reasonable when they speak to the public. At the same time they have found it too convenient to have the losers who call themselves “neo Nazis” as a way to deflect attention.")

#text("You want to hear what Nazi self-righteous speak looks like? Attend a high profile academic conference or meeting of academics and listen how the attendees talk when they believe nobody is watching. I have literally, heard people praising both William Shockley and James Watson racist ideas in these settings.")

#text("These racists have to be soundly defeated again in 2020!!!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/313e2e7aa1baac1b723fb0fcef38306287aaeb6f5b6c0cf6926483d6281e21b9-f1db1b61a4380e65a0e3a022e6e70a5c3179b13a3e71a2313b1ce5781e2206b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bigfoot is real")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-488977")[#strong[#text("Bigfoot is real")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2017")])]

#text("Trump has proven beyond any doubt that he’s our smart leader and will fix our country from the false song of GLOBALISM #MAGA #2020 #SethRich")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9af86fe3ceffd67f344fbde65b61471482b1cf9e4afab6c688805f8916392c1-a3cee2816b5b14f59ac25160a21ba348b7009016616bd709f70c2de3dd707a0a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trump for 2020")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-488995")[#strong[#text("Trump for 2020")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2017")])]

#text("It ought to be common knowledge that Donald Trump is the only person on earth that can shatter the false song of globalism")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-489000")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2017")])]

#text("An opinion is an opinion. Without a supporting argument, it is a useless slogan. Please stop your crap. Mr Trump himself would not even appreciate your pointless comment here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd8c9a7efa74288fc6071a550706d2c6e33e5429e7d8cf56204b6b71ab6ed68d-86515654af7bd055792d7f94ee5e2e834a4583aa3b0c7578c847255186dfce4f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Build that Wall Deport them All")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-489008")[#strong[#text("Build that Wall Deport them All")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2017")])]

#text("RussiaGate explained:")

#link("https://imgoat.com/uploads/93f65e080a/58830.jpg")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://imgoat.com/uploads/93f65e080a/58830.jpg")[Original image]]]]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd8c9a7efa74288fc6071a550706d2c6e33e5429e7d8cf56204b6b71ab6ed68d-86515654af7bd055792d7f94ee5e2e834a4583aa3b0c7578c847255186dfce4f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Build that Wall Deport them All")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-489009")[#strong[#text("Build that Wall Deport them All")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2017")])]

#text("Why would any country value foreigners more than its own citizens? Isn’t the whole point of being a citizen that the state values you above all others?")

#text("I say: Deport them all.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/459d0929d9e6e14eec90ac6e1a1569bf5e83cfb7d07d8e417c60050565f4f1b5-d3c8699345b23b6544102260a097098318b0e726cd4f327fde2238c885d13738.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trump Lover")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-489044")[#strong[#text("Trump Lover")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2017")])]

#text("I <3 our president, makes me proud :')")

#link("https://i.redd.it/f94a0h44e4zz.jpg")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i.redd.it/f94a0h44e4zz.jpg")[Original image]]]]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-489048")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2017")])]

#text("Mr President said: Thank you for your love and support. But PLEASE stop the nonsense crap and go home to learn more math. In that way, you would understand the world better and truly make America great again.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65bfb4c604edbd4516611dc0cbc95a514ce16778c8e08b03f4611f64a1dfb8e3-1629aa05f990ca10b1e9312c5ef87bd51a5a78f1c99f32913cacbd7772d8f541.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Minion (not pinyin)")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-489047")[#strong[#text("The Minion (not pinyin)")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2017")])]

#text("To all site users and admin")

#text("A key component of this ‘life lesson’ engineered by ‘blog admin’ is to watch/listen to the speech by Hillary Clinton, and the first two minutes were a bit slow of her speech but then it gets really entertaining on some levels, it’s as though a real political speech has turned into a scene from a Hollywood film albeit a comedy one.")

#text("I just think sequentially (and it is a maths based blog) one needs to accept ‘blog admin’ knows best, and if one can put that piece of the puzzle together then try to actively learn and listen from it, it is high quality teaching, even if a person like me has to receive the lessons in this form, I mean, how you receive a lesson like that is irrelevant, yet the receiving seems the operative…")

#text("I’m still listening to the speech by Hillary Clinton, when that is complete I will have a listen to the rebuttal.")

#text("Cheers")

#text("IB")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65bfb4c604edbd4516611dc0cbc95a514ce16778c8e08b03f4611f64a1dfb8e3-1629aa05f990ca10b1e9312c5ef87bd51a5a78f1c99f32913cacbd7772d8f541.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Minion")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-489050")[#strong[#text("The Minion")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2017")])]

#text("To all site users and admin")

#text("In maths education, this is called a diversion, such as a mathematical joke for instance. Key materials one could acknowledge for higher appreciation of this diversion is the proposition one, and, the speech by Hillary Clinton along with the website about Trump’s rebuttal.")

#text("It is also up for debate whether site admin have really stated anything tangible with this diversion, however it seems educational, it seems experimental and overall some lessons one can take from this is about judgment, is site admin right to say that Proposition one is true? Is site admin giving away their political beliefs, I mean, there is no conclusive evidence that site admin aren’t voting Trump?? It seems to me to be a very clever educational diversion, and can I just say, people use diversions to take a rest and I think they should, just because I took notes on Hilary’s speech (a depressing experience I assure you) but that isn’t why site admin published this. I suspect it is to give us a rest, and in doing so, done what any smart human being would do and created extra output by providing high interest.")#linebreak()#text(" cheers")

#text("IB")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65bfb4c604edbd4516611dc0cbc95a514ce16778c8e08b03f4611f64a1dfb8e3-1629aa05f990ca10b1e9312c5ef87bd51a5a78f1c99f32913cacbd7772d8f541.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Minion")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-489052")[#strong[#text("The Minion")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2017")])]

#text("Using quotes from site users:")

#text("“I think, this is not the real issue.” 2016 — The real issue here is that good maths study is likely always best")

#text("“”go home to learn more math.”” 2017 — Yes, in total agreement, maths improves one’s intelligence, teaches hard work and countless things")

#text("I think a huge problem is diversions, the maths costs high intensity concentration, which due to restrictions on self promotion, one feels hesitant to discuss, but site admin has mentioned in other articles about how to deal with the need to do high concentration tasks and lower concentration tasks.")

#text("Site admin welcomes quotes from all people, and processes it accordingly, Finally, with one’s last ounce of posting tolerant strength says, there are other superbly talented people and mathematicians, from other Fields winners to successful students, I’m left to question why I am writing this and why I am even being read?")

#text("In Bolognie (talk)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf6d62f758e3abfc13d17411494ee6f84c685959c56204aee5f928f6d8383ec-e8924cd1f2c57207b994b5b8656774ccb2fdc15d1c97d283853f19d32fbaa9ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trump Rambling")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-489066")[#strong[#text("Trump Rambling")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2017")])]

#text("“Look, having nuclear — my uncle was a great professor and scientist and engineer, Dr. John Trump at MIT; good genes, very good genes, OK, very smart, the Wharton School of Finance, very good, very smart — you know, if you’re a conservative Republican, if I were a liberal, if, like, OK, if I ran as a liberal Democrat, they would say I’m one of the smartest people anywhere in the world — it’s true! — but when you’re a conservative Republican they try — oh, do they do a number — that’s why I always start off: Went to Wharton, was a good student, went there, went there, did this, built a fortune — you know I have to give my like credentials all the time, because we’re a little disadvantaged — but you look at the nuclear deal, the thing that really bothers me — it would have been so easy, and it’s not as important as these lives are — nuclear is powerful; my uncle explained that to me many, many years ago, the power and that was 35 years ago; he would explain the power of what’s going to happen and he was right, who would have thought? — but when you look at what’s going on with the four prisoners — now it used to be three, now it’s four — but when it was three and even now, I would have said it’s all in the messenger; fellas, and it is fellas because, you know, they don’t, they haven’t figured that the women are smarter right now than the men, so, you know, it’s gonna take them about another 150 years — but the Persians are great negotiators, the Iranians are great negotiators, so, and they, they just killed, they just killed us.” snopes.com/donald-trump-sentence/")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/05cb6436dcf485d77af4cca0f23ea9eb1cf27c320b85b91822260db656ee4527-7134e3a7990d6686c20d5f7c0c695f4eafedf4240d9d84346c391b3a8538721f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ajit Pai Fan")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-489116")[#strong[#text("Ajit Pai Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2017")])]

#text("Thanks to Trump we will get rid of commie Net Neutrality backed by George Soros and the globalists, can’t thank Trump enough for appointing that Indian American patriot that is Ajit Pai! Woohoo!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f5262ffcea2a9eb982108075ad1ad4b7e0c6c04944cab7424dd3a9f886fad47-e40ecdc5f693e734e57bd9f7a85fd500c6e267587d95d996036fc5a96a7b35cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dem libs")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-489135")[#strong[#text("Dem libs")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2017")])]

#text("Haha no more net neutrality, get that liberals! #DrainTheSwamp #FalseSongOfGlobalism #MAGA")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-489277")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2017")])]

#text("The lack of net neutrality is going to affect *everyone* including “non-liberals.” I hope you could put two thoughts on something before speaking.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-489361")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2017")])]

#text("Trump proves yet again that he’s a hateful imbecile: ")#link("https://www.theguardian.com/us-news/2017/nov/29/trumps-anti-muslim-retweets-prompt-backlash-in-washington-the-president-is-racist")[#text("https://www.theguardian.com/us-news/2017/nov/29/trumps-anti-muslim-retweets-prompt-backlash-in-washington-the-president-is-racist")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf32a82f10b973bfcc1263ccc6e4fb84381e7eeb8a3e4a5898f7e5fee522ae77-73a62aea72343c9327c7e3eb56fddddb2a49fbb415b945049e4be41121f7d3df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Pinkerton")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-499546")[#strong[#text("John Pinkerton")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2018")])]

#text("Ironically, Trump is also the child in the emperor story. Despite all his failings, he provides value by calling out false narratives where PC norms in mainstream media and establishment politics have hidden the truth from common knowledge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad019c388d7abb58a1f65ab6d5ba77c171e1ea2d5db3bfad807e6d297e7b4c1e-2ffcce9866bfd49a23028cc9813c6d77c3bafc12c4a5aa93958854449ed49d57.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Favoritism")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-504277")[#strong[#text("Favoritism")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2018")])]

#text("OK, finally Trump is close to being impeached, was Terry Tao right all along or the probability of Russian collusion depends on UCLA’s government spending on her favor?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8fb5ff0275c4db4a1cd180a94ab81fcba1b401b18c5513c44a48ecf38f437b2e-b2d5e43b4a163c0397eec996bf16ad79d3c95ef44958fdead3d86ada76bb621a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kavanaugh victory lap – posttenuretourettes")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-505791")[#strong[#text("Kavanaugh victory lap – posttenuretourettes")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2018")])]

#text("[…] Trump manage to convert mutual knowledge into common knowledge? That’s how you do it, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-513217")[#strong[#text("Donald Trump is fit to be president - IND2906")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2019")]

#text("[…] It ought to be common knowledge that Donald Trump is not fit for the presidency of the United States… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d3513d7175c3a7fe944a6a8d2a6eae816a88a0bfcddfd79342508f7de519818-76ef259f9cc65fa5cdb2733e2016b486e090905182882100c9de1dd6e858cdfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-513802")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2019")])]

#text("I think he will still win in 2020 even if they launch Bernie against him. 1. He has to win Fl, Az and two of Mi, Wi, Oh, Pa. Winning Oh is an indicator of strong showing in last four. So in essence he has to win Fl, Az and Oh only. 2. Ideological underpinnings indicate both legal and white majority would prefer status quo. It is unlikely dramatic changes promised by democrats can swing populace with ease. There is no historical evidence for things changing with ease. People would rather prefer status quo which seems to be a case with DT. 3. He has been lucky all through his life and there is probably a fundamental reason behind this. Will he loose his luck in 2020? 4. His base still values what they valued and in 2018 with all the blue swing democrats won little ground. Similar effort in 2020 in a presidential year likely to produce worser results.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7f4bf91e9f2e5a75e40f1eaa37e3a1b8679b2a6c6a2fe01ab359f51aa2a58fb-af7dc6f68b3790bd473a1048a45b8e38db026faf455739e09d918295e4ab3626.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-514353")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2019")])]

#text("See luck as reason on 3. Mueller probe did nothing. He might be beatable but it is unclear. With 2 more judges he might even have a shot for long term goals.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3417e1899754034eb0731b603a8895475cda4197c4aac76791702405e17c9f2-ce0e5471c9c485082c67d2d4dfb2415af5573b24623a1e8ffd9b23e230f6e0f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonomouse")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-522773")[#strong[#text("anonomouse")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2019")])]

#text("As usual, Terry is right.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-542130")[#strong[#text("יומיות 15.06.2016: Pebble להאקרים, אוטובוס העתיד בסין, שערורית כוכב התכנות של Tor והוצאת יניב מציפה את השוק בספרי מדב”פ | ניימן 3.0")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2020")]

#text("[…] הסביר למה טראמפ לא ראוי להיות נשיא ארצות הברית. תראו איזה יופי הוא מנסח דעה פוליטית בכלים מתמטיים. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86c4bc28eb4ec21f07f4e33fc6284751203f6fc287e406be3dafc080835d09b6-f27030599efcf7ee386e90cc17263c40c397ee81b2083cd8d5f0c011b405e034.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Any common knowledge left to be spread?")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-597003")[#strong[#text("Any common knowledge left to be spread?")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2020")])]

#link("https://en.wikipedia.org/wiki/2020_United_States_presidential_election#State_predictions")[#text("https://en.wikipedia.org/wiki/2020_United_States_presidential_election#State_predictions")]

#text("The coloring looks pretty much the same as 2016.")

#text("Any mathematical predictions?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-613609")[#strong[#text("Anthroprogenic Political Climate Change. DIe Hard Blowhards and Media Presstitutes , Global Level Extinction Event. NOV 8 2016 – Not The Grub Street Journal")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2020")]

#text("[…] and mathematicians such as Peter Woit, Leonard Susskind and Terence Tao have come out as strong supporters of Hillary in the presidential race, and then of course as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd355f89eabe8e858afc8ffffdea8eabd57b3c42ab01963ef718ec454d0b333e-ffc26dfc1f80edc741e217bb2245f5a5ddc1a8d9de2d2d79760ef95bbe73fff9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Darby L")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-633144")[#strong[#text("Darby L")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2021")])]

#text("STAR voting Rocks!")#linebreak()#text(" Ranked Choice / IRV is way overrated, compared to STAR, or even Approval voting. Different criteria can be weighted differently by every individual, but the defects of RCV are glaring. Most notably, it doesn’t fix the problem of two-party dominance. Third (4th, 5th, etc.) parties actually have strong viability with STAR voting. Equal Vote Coalition has the info.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-633327")[#strong[#text("TJR (@renosaer)")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2021")]

#text("This comment is only about the invitation to debate electoral reform. Mr. Tao briefly indicates a preference for Instant Runoff Voting due to its use in his home country. I also briefly want to point out that IRV still falls victim to Favorite Betrayal (i.e. you can’t always give your favorite the highest rating when voting strategically), it does not empirically solve the problem of 2-party dominance, it ignores most of the information given on most of the ballots (for example, if your 1st-choice loses in the last round, then all of your other preferences are essentially ignored), it exhibits chaotic behavior when there are 3+ strong candidates (just look at the Yee diagrams; yikes!), and there is little evidence that it even helps reduce negative politicking and hyper-partisanship. I humbly recommend Mr. Tao consider other alternative voting systems, such as Approval, Score, STAR, and perhaps even the various Condorcet-style systems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-639432")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2022")])]

#text("This blog post has aged better than fine wine. Kudos to Tao for making his political thoughts public despite the backlash.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5650b942fbc8479d53950a3ff4cc60804d8a8da1ae7e15aac1526445b0d0730-28fbc98b0d395fa11071b7f908d6e39ca4e82070d2e34216d3b702914b5272f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roger Schlafly")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-649145")[#strong[#text("Roger Schlafly")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2022")])]

#text("I look forward to this post being updated with the proposition that Joe Biden is not even remotely qualified to carry out his duties. And also opinion on which Presidency turned out better, Trump’s or Biden’s.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9dd83c2affad2f791cdc21549a50fc6a514be915f9a4d6a9aea1f4bac48481c7-666cd3c5af19c2cadff0efaf9e92fb226d441731fd2da527b9101911328db449.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bradley R Krantz")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-650203")[#strong[#text("Bradley R Krantz")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2022")])]

#text("Your graduate degree from THE University of Whataboutism has paid off.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/635a9a5791b6d820d42a0dae63503874c0154ed2c66e6d9605cb92a220fa9e8c-24db9c74352b83b267cd91081e566bd07e0f77ac1098b8fc7f323c321d2bef1e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Kelly")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-649795")[#strong[#text("Joe Kelly")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2022")])]

#text("It’s always more fun to answer something well after the fact. Anyhow, I completely agree with Terry’s logic above and my head still aches to think millions and millions of people can and did vote for Trump. I try to use logic and reasoning for thinking issues or problems through to completion. Moreover, why people will still vote for Trump is beyond me. I guess an ounce of emotion TRUMPS a pound or ton of logic. 😊.")#linebreak()#text(" I think even The NY Post or Wall Street Journal would agree with Terry’s original assumption, he just put the pieces together a little faster.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/515e518907d47b6b6d8ad0eeba588593a4d465978563327f96dcd0f3243d6a43-e1ca936985bd3124c9915c167e5acf5f5d9079b505b67c8b43649f537326a143.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of What have you been upto?")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-660358")[#strong[#text("What have you been upto?")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2022")])]

#text("At least Yitang Zhang got his green card and decided to screw around with mathematics while getting paid for doing lowkey work in the US. Rest of us are doomed. Trump is still running.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-669407")[#strong[#text("Obligatory Post Opposing Donald Trump. – rants.org")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2022")]

#text("[…] “Daddy, why didn’t you blog about Trump?” post and Terence Tao’s “It ought to be common knowledge that Donald Trump is not fit for the presidency of the United… — relax, Tao is not indulging in liberal tribalism but rather is using a technical […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-682365")[#strong[#text("Good guys vs Bad guys in chess based on Liren Ding’s stupid list of role model players ( 2023Apr ) and Team Hans vs Team Magnus ( 2022Sep ) | Mathematiciowned")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2023")]

#text("[…] Donald Trump […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-6/#comment-682833")[#strong[#text("Wealth, Intellectualism, and Individualism, Part 6 – Grey Enlightenment")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2024")]

#text("[…] Terrance Tao, possibly the most brilliant mathematician alive, wrote an article about Trump being unfit to be president, which went massively viral despite the article having nothing to do with math, but because people, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33a2b53553ff103d52fdd5d51c3d7887e87ce7c8afea41b51ccda7b8e9c00c19-c6c0a2c9b334130aa0249fa5cc3fb7c0c34a317df0e051839e233a0d3634a37e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christine da Pizzano")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-471364")[#strong[#text("Christine da Pizzano")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2016")])]

#text("To Trump supporters, ideology is more important than competence. See ")#emph[#text("The Guardian")]#text(", August 7, 2016, “American Nazi Party leader sees ‘a real opportunity’ with a Trump presidency.” Quoting from the article: “The leader of the American Nazi Party has said the election of Donald Trump as president would present ‘a real opportunity for people like white nationalists’ to start ‘acting intelligently’, with the aim of building a mainstream political presence similar to that of the Congressional Black Caucus…. The American Nazi Party is a fringe group that grew out of that founded by George Lincoln Rockwell in 1959. According to the Southern Poverty Law Center, David Duke, the former Ku Klux Klan grand wizard who is running for the US Senate in Louisiana and has spoken favourably of Trump, was once a follower. This week, Duke told NPR: ‘As a United States senator, nobody will be more supportive of his legislative agenda, his supreme court agenda, than I will.'”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-471927")[#strong[#text("La raison du sexe - Le Blog Perso de Duverger PETGA")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2016")]

#text("[…] parcourant un billet de Terence Tao, le célèbre mathématicien, sur sa position par rapport à l’élection présidentielle en cours aux Etats-Unis, j’ai observé qu’il aborde deux concepts utilisés en logique fort intéressants pour la […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e01c4295a842ef1e77b72802260c1efc0c3a5654ee477954534efdc1219e2beb-3ce5501c8990f738a517822a42336005b1c6b7d4a047689bad145a662f134e4f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-471934")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2016")])]

#text("Censor me if you must, but can we trade this guy in for another Bertrand Russell, please?")

#link("https://en.wikipedia.org/wiki/Bertrand_Russell#Political_causes")[#text("https://en.wikipedia.org/wiki/Bertrand_Russell#Political_causes")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e57eb0677e2ff7fa2aa028c9c49b6541bd6fe291dc99a2d1ef29a340f695dba3-f4241befb3792e8a07a3205f0b1ab1b18a83337e94fea37c762b97263cae4938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Julio")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-472269")[#strong[#text("Julio")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2016")])]

#text("I fully agree and support Dr. Tao opinion; Donald Trump is NOT fit to lead America and quite honestly isn’t a very good businessman either. If you know any history about Trump, you’ll see that he has actually use bankruptcy as a business solution and that he is inconsistent; and quite frankly, I don’t want someone with those characteristics to be the President of my country. I believe that Hillary Clinton with her experience and knowledge in politics, would be the best option we have.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e4d0eba2448876cc4a1f8b0997b9f00c711b34020199f240f0f4a885da05f42-795e642b3d1fa2b84753f6372d1ceb4b3a153d12cf9787b0d0e4213933f7611b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of easy")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-472384")[#strong[#text("easy")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2016")])]

#text("It could be common knowledge that he is unfit but it is also common knowledge that he will be or else you would have logically refrained from this posting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/035e73379883a1bbd6c4cbdba2d8b3672dd30bc7a8af78b1487cb22b392ce11f-dddbfa6b3249c7b3be37ddb777e317eed04b4f3b07fb44951b443fefadaa8729.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twoifbycharm")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-472469")[#strong[#text("twoifbycharm")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2016")])]

#text("Thanks for your article. It was quite interesting. I believe we are all getting a good lesson in a high-functioning sociopath, and have done a lot of research on the topic. The emperor fable is often used to portray how sociopaths function as leaders, and that may be the link between our articles. I invite you to read my article, and feel free to re-post it if you wish. Again, thanks for provoking thought and discussion. B. Ashley ")#link("https://twoifbycharmwordpress.wordpress.com/")[#text("https://twoifbycharmwordpress.wordpress.com/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90621e18dd099c8e3e01247d4a1e023f36be2a8033eef5424130c51e0edc8e9c-f299cea29e62a53db2ebb88414da8c51109d574073d139c2300ed7e669505859.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zackattacknyu")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-472613")[#strong[#text("zackattacknyu")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2016")])]

#text("You are using the logic of urban academics/professionals and not many of the people likely to support Trump. To many voters outside the professional class, they want someone who they feel like is similar to them. That is what Donald Trump provides. It is no coincidence that Jerry Falwell Jr called Trump a “blue collar billionaire.” He is tapping into an anger that is still largely prevalent among blue collar Americans about economic and social changes in the country.")

#text("If you want to see the logic in action, drive to Bakersfield, Fresno, or another city in the Central Valley and talk about politics. If you drive from LA to SF right now, you will see Trump signs along the way on I-5. Stop by a diner in one of the towns hit hard by the drought and see how far your logic goes. Even though Trump can’t affect it, the people are so hard hit by the water restrictions that his rhetoric is what they want to hear.")

#text("Vox has done extensive reporting about the mechanisms behind Trump’s rise. It is actually quite easy to see and quite easy to study. It just occurs in places that are outside the stomping grounds of many academics, professionals, and journalists. It also involves different logic than that group is accustomed to.")

#text("Two great articles from Vox on it:")#linebreak()#text(" ")#link("http://www.vox.com/2016/9/6/12803636/arlie-hochschild-strangers-land-louisiana-trump")[#text("http://www.vox.com/2016/9/6/12803636/arlie-hochschild-strangers-land-louisiana-trump")]#linebreak()#text(" ")#link("http://www.vox.com/2016/3/1/11127424/trump-authoritarianism")[#text("http://www.vox.com/2016/3/1/11127424/trump-authoritarianism")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474351")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("Oh look, a Trump supporter who now claims Trump can fix the drought.")

#text("Psuedo-science and general stupidity is rampant among you deplorables.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e6264d9bc9110421451f6267f43c174477f82f584d7a9dc4e49f8dc659db96f-8cf49927ad6833cdf66e3a39ce25e50207fcccd932e746ed60b7be4bbfefcc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Nahay")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-472686")[#strong[#text("John Nahay")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2016")])]

#text("There exists no such thing as “qualified” in politics. Politics is just whatever anyone wants the laws to be. That’s it. No matter how fair or unfair they seem to you. Everything outside formal mathematics is bullshit.")#linebreak()#text(" There is no objective proof or truth outside formal math & testable quantifiable falsifiable objective physical science.")#linebreak()#text(" There exists no such things as “fact” in politics or law.")#linebreak()#text(" They are ALL just political opinions.")

#text("I am more anti-Trump & anti-Clinton than anyone.")#linebreak()#text(" But, I NEVER delude myself into believing this nonsense of conflating “what is/was/will be” with “what should be”.")

#text("We SHOULD have laws outlawing factory farming & breeding nonhuman animals for meat, and mandating veganism until bioengineers perfect biocultured meat without breeding animals.")#linebreak()#text(" Forcing new nonhuman animals into existence, especially for needless torture & murder, violates THEIR animal rights.")#linebreak()#text(" We SHOULD have laws outlawing breeding humans: people have kids,")#linebreak()#text(" or allow antinatalist citizens to physically stop breeders from breeding, forcing new humans into existence.without their permission")#linebreak()#text(" We SHOULD have laws allowing civilians to blow up prisons to free all prisoners. All prisoners are prisoners of war.")#linebreak()#text(" ALL law is violent force. It is MEANINGLESS to condemn “violence” and “violent force” in general, legal or illegal, unless you add up the POSITIVES for which it is used: i.e. the REASONS. It is UNREASONABLE, i.e. anti-reason NOT to include an individual’s REASONS for fighting/killing/imprisoning/arresting another.")

#text("We SHOULD go to war against Wall Street & banking & financial terrorists.")

#text("We SHOULD go to war against Anthropogenic Global Warming (AGW)")#linebreak()#text(" & fossil fuel addiction.")

#text("And there is NO excuse to deny prisoners the right to vote.")#linebreak()#text(" Because I sure as hell would love to deny anti-secular anti-atheist")#linebreak()#text(" breeding pronatalist meat-eaters the right to vote.")

#text("I just toss those meaningless words “terrorist” & “criminal” around,")#linebreak()#text(" because all these dumb anti-math people seem to like using them & taking them seriously. But, to me, I don’t care whether somebody “is” a terrorist or “is” a criminal or “is” a racist or “is” a muslim or “is” a child molestor or “is” a legal citizen or “is” an atheist, etc etc I care about what they DO or WOULD do or think SHOULD be done, and their REASONS for doing so, about the POSITIVES outweighing the NEGATIVES FOR THOSE WHO DESERVE IT. Logical consistency is what matters most.")

#text("In fact, I have worked out an elegant formalized Mathematical Metatheory of Justice (my MMToJ) to be used to replace law as we know it.")

#text("And don’t worry: either Dr Jill Stein or Zoltan Istvan or Clifton Roberts or John McAfee will be elected president.")#linebreak()#text(" I’ve worn the Zoltan Istvan buttons all summer, so I should keep my loyalty to him and will probably vote for him.")

#text("Idiots call ANY philosophy or opinion they don’t like “religion”.")#linebreak()#text(" I have heard theist after theist call “atheism” a religion or “communism” a religion. (Yes, communism has been taken to extremes of forcing people to believe certain specific ridiculous things. Still does not mean communism has to be turned into a religion.)")

#text("Then they DAMNED well had better call ALL LAW, especially Western law, the world’s most dangerous violent religious cult, where they brainwash students into law school into believing such MYTHS that “bomb & death threats are illegal or a crime” or that “one HAS to show up to court if some judge says so”. Prove me wrong. Prove me judges & cops & prosecutors & prison guards will back down & not use violent force if they don’t get their way. And this goes, too, for the religious cult of the military.")#linebreak()#text(" And I am not even anti-war or anti-violence.")#linebreak()#text(" I care only about computing FAIRNESS & positives outweighing negatives for those who deserve it.")

#text("Show me political candidates for U.S. President who analyze everything I said here. Until then, NOBODY is “qualified” for president, because the concept is meaningless.")

#text("Proud of my nihilism.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27896df7aced9bedff508a327d4d47203e55c29237fc0fd0a32dfdfb8f878099-8b64431d11c756c6ba73ef1d88eb29ff4ed38d607fbfc9fbdc72a6becbbbcbad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lex Corvus")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-472717")[#strong[#text("Lex Corvus")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2016")])]

#text("I think the near-converse of the proposition is much likelier to be true, namely, that everyone knows the Establishment is a rotten old building, and Trump is the only wrecking ball in town. (Bernie was another, but the DNC saw to it that he didn’t make it this far.) Indeed, I view this post’s quasi-mathematical presentation of Trump’s “obvious” unsuitability, and its utterly unsubstantiated assertions to that effect, to be classic tells of cognitive dissonance on this exact point.")

#text("With the entire mainstream united against him—including academia, the media, and both the Inner & Outer Parties—few want to admit publicly that Trump is the first candidate in years to offer a genuine alternative to Orwell as usual. ")#emph[#text("Contra")]#text(" Terry’s hypothesis regarding an incipient transition from mutual to common knowledge, I propose we’re instead on the cusp of a preference cascade, leading to a general acknowledgment that a significant majority of voters back Trump for reasons that are rationally grounded in their own self-interest.")

#text("I’ll be surprised if I can persuade many with this short comment, but if you’re interested in digging deeper the ")#link("http://blog.dilbert.com/")[#text("blog of Scott Adams")]#text(" is simply essential. Start with ")#link("http://blog.dilbert.com/post/126589300371/clown-genius")[#text("Clown Genius")]#text(", published August 2015, and read chronologically from there. If you consider Adams’s arguments (and track record of predictions) with an open mind, you’ll have to agree that Proposition 1, while perhaps true, is not ")#emph[#text("obviously")]#text(" true.")

#text("(For the record, I don’t endorse any candidate for president.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e6264d9bc9110421451f6267f43c174477f82f584d7a9dc4e49f8dc659db96f-8cf49927ad6833cdf66e3a39ce25e50207fcccd932e746ed60b7be4bbfefcc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Nahay")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-472738")[#strong[#text("John Nahay")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2016")])]

#text("I kept this URL around for the entire year.")#linebreak()#text(" ")#link("http://2016.presidential-candidates.org/")[#text("http://2016.presidential-candidates.org/")]#linebreak()#text(" I have not counted how many names are on it now,")#linebreak()#text(" but at the start of 2016, I counted 84 candidates running for office.")#linebreak()#text(" With this new invention called the internet, humans can grow a brain")#linebreak()#text(" and look up each name and then go to their websites and check out each candidates’ past voting records on bills, how they would have voted, what they fought for, what struggles they are up against.")

#text("There exists absolutely nothing special, nothing unique about Trump. There is no logical reason to vote for him. Only some kind of bizarre mental sickness & insanity would think that a freeloading tax-avoiding Wall Street financial terrorist billionaire like Trump, who tortures & murders cows needlessly instead of mandating veganism, who gets billions of free handouts from the government, benefiting from socialism for the rich, but demanding & forcing capitalism on the poor, would give a damn about anyone but himself. Trump would destroy the USA even faster than Clinton, with his denial of AGW, and advocating murdering American citizen & patriot Edward Snowden. So I exercise my free speech right to advocate hanging/executing Trump for treason for doing nothing to end AGW,")#linebreak()#text(" not to mention doing nothing to end extreme political correctness.")

#text("The more I see subhumans vote for Trump & Clinton,")#linebreak()#text(" the more I realize anything is justified by the Principle of Explosion in Logic.")#linebreak()#text(" The more I realize they don’t have feelings.")#linebreak()#text(" There exists no scientific & no mathematical proof that Republican or Democrat voters have feelings.")#linebreak()#text(" There exists no scientific & no mathematical proof that anyone has ever broken any law ever in the history of the universe. That is just a fearmongering myth that police, judges, prison guards bureaucrats force onto citizens to extort & take their taxes & get rich.")#linebreak()#text(" There are no such things as “terrorist attacks”.")#linebreak()#text(" Those events are just atoms moving around.")#linebreak()#text(" All that matters is computing cause & effect logically consistently")#linebreak()#text(" upon each player, and choosing to cause more positive than negative for each player who deserves it. Obviously, no unique solutions exist,")#linebreak()#text(" but many alternatives can be eliminated.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e6264d9bc9110421451f6267f43c174477f82f584d7a9dc4e49f8dc659db96f-8cf49927ad6833cdf66e3a39ce25e50207fcccd932e746ed60b7be4bbfefcc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Nahay")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-472762")[#strong[#text("John Nahay")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2016")])]

#text("Mathematicians, and the world, should be up in arms, doing any physical action to free patriotic American citizen & hero & mathematician, Dr Theodore Kaczynski, from prison. As is well known fact: all prisoners are prisoners of war: i.e. soldiers. There is no scientific & no mathematical proof that Dr Kaczynski, or anyone ever, has ever done anything “illegal”. That is just a myth that the religious cult of human law – lawyers, cops, prison guards, prosecutors, judge – use as an excuse to get rich.")#linebreak()#text(" PhD mathematicians should run the world, applying and forcing our PhD-level math into the computation of justice & fairness.")

#text("According to the ultra-politically correct conservative world: consequences of actions do not matter. Only respect & maintaining the status quo. Holding anyone hostage in prison is the most disrespectful thing you can do to another person.")

#text("The Principle of Explosion in Logic: this has to be applied ruthlessly against republicrat & demopublican voters.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-473103")[#strong[#text("Vote for Clinton or Johnson for president: « The Story's Story")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2016")]

#text("[…] with cruelty is large. LeBron James endorses Clinton. Mathematician Terry Tao writes, “It ought to be common knowledge that Donald Trump is not fit for the presidency of the United States…” (he’s right: it ought to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-473110")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2016")])]

#text("Trump would be the worst Presidental canidate ever -he has not a clue what it would take to be President of our great Country of the the United States. I am afraid we would be the laughing stock of the world. Many Great Republicans have stated that they would hope he would drop out- he never will do that. He is an arrogant ( sorry) Bastard that only cares about himself. Get him out of there.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/14f8ef9fe2ef45480f1f3b9db2590259fd41720b24988fa0bb168bc293cccfc2-1260346b8d89f723c1c15f4dd30a742d3dc7c4fc05cc637fb56b1d6a8c55ca48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymouslady")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-473321")[#strong[#text("anonymouslady")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2016")])]

#text("1.Natasha Stoynoff, a staff writer at People,")#linebreak()#text(" came forward as an alleged victim of Trump on October 12.")#linebreak()#text(" Stoynoff wrote that Trump assaulted her and forcibly kissed her in 2005 ,")#linebreak()#text(" 2.Mindy McGillivray claims Donald Trump groped her 13 years ago")#linebreak()#text(" while she was visiting Mar-a-Lago.3.former Miss Washington USA")#linebreak()#text(" Cassandra Searles claimed Trump grabbed her ass,4.Four women")#linebreak()#text(" who competed in the 1997 Miss Teen USA beauty pageant have accused")#linebreak()#text(" Trump of walking into their dressing room Trump reportedly said something")#linebreak()#text(" along the lines of, “Don’t worry, I’ve seen it all before.”5Makeup artist Jill Harth")#linebreak()#text(" Trump he allegedly groped sexual advances,1993, when Harth and Houraney")#linebreak()#text(" visited Mar-a-Lago, Trump’s Florida estate, he allegedly groped her.6.Ivana")#linebreak()#text(" Trump accused her then-husband of rape 1993 book Lost Tycoon: The Many")#linebreak()#text(" Lives of Donald J. Trump 7.Alicia Machado won Trump’s Miss Universe pageant")#linebreak()#text(" in 1996, In a series of 5 a.m. tweets, Trump accused Machado")#linebreak()#text(" of having a sex tape — which he urged voters to “check out.8.Correspondents’")#linebreak()#text(" Dinner in 1993 Trump had spent his entire time with her assaying the ‘tits’ and")#linebreak()#text(" legs of the other female guests.9.Mistreating His Female Employees9.Trump")#linebreak()#text(" was caught on tape bragging toBilly Bush about sexually assaulting women.")#linebreak()#text(" 10.Hiring Women Based on Appearances 11.Groping a Woman at a Manhattan")#linebreak()#text(" Nightclub Kristin Anderson, who worked as a model and makeup artist in New York")#linebreak()#text(" early 1990s Donald Trump groped her .12.Summer Zervos, a contestant on the")#linebreak()#text(" fifth season of The Apprentice, says she was both kissed and groped by Trump.")#linebreak()#text(" “that is over 12 examples of Don Trump think he can do whatever he likes to")#linebreak()#text(" women and thinks he can get away with it ,it not just one isolated case it is")#linebreak()#text(" many many cases where Don trump has shown he can’t control his sexual urges")#linebreak()#text(" and sexual hormones?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80398e289c660038bd547feb9f2133307a21f4c9011e03ba12069f39d921ba48-274c7f099e3c4da81daa8d237e2213c687241f9b8a211823eef995cd137af2f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TrudyPen")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-473493")[#strong[#text("TrudyPen")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2016")])]

#text("Don Trump admits use foreign companies matterials.")#linebreak()#text(" Don Trump admits use foreign companies STEEL .")#linebreak()#text(" Don Trump admits use foreign people other countries do the work.")#linebreak()#text(" Don Trump DENYS he did not do those things to those women.")#linebreak()#text(" Don Trump DENYS He knows those women.")#linebreak()#text(" Don Trump has said No way would i have affair with those women.")#linebreak()#text(" Don Trump has said Have seen those women -cuts down women.")#linebreak()#text(" Don Trump Accuses Hilary Campaign bring women out public.")#linebreak()#text(" Don Trump Accuses Hilary Campaign cause violence at his rallys.")#linebreak()#text(" Don Trump admits using any tax breaks to not pay taxes.")#linebreak()#text(" Don trump wife Mel is Russian and Trump brag up Put_!")#linebreak()#text(" Don Trump has said Put_ has beat USA what kind man is TRUMP?")#linebreak()#text(" Don trump has no strategy plan just give rich tax breaks !")#linebreak()#text(" The phrase “talk is cheap” is actually a shortened version of at least two other commonly used American idioms — “talk is cheap but it takes money to buy whisky” and “talk is cheap but it takes money to buy a farm.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92a4bfd89ee50521f53ff147ea7108d138421e30c7dd4819d68a0ab22f4fc7cb-30bc1b9cfb3c3114810512fa9ac403810f7816b8b8f6c0db55aae3b00d66032c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristen")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-473509")[#strong[#text("Kristen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")])]

#text("He also doesn’t know how to pronounce Guantánamo. He called “Guan tin amo”.")

#text("For the word hombre, he used in a derogatory way during the third debate, he pronounced the “o” as in the word omelette. It’s a long “o” it’s in the word oratory. I can’t imagine him speaking to world leaders around the world or giving a State of the Union address. The man speaks as if he has never listened to a news report in his life.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-473529")[#strong[#text("Mutual Knowledge vs. Common Knowledge – Rainy Streets")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2016")]

#text("[…] In logic, there is a subtle but important distinction between the concept of mutual knowledge – information that everyone (or almost everyone) knows – and common knowledge, which is not only knowledge that (almost) everyone knows, but something that (almost) everyone knows that everyone else knows (and that everyone knows that everyone else knows that everyone else knows, and so forth). A classic example arises from Hans Christian Andersens’ fable of the Emperor’s New Clothes: the fact that the emperor in fact has no clothes is mutual knowledge, but not common knowledge, because everyone (save, eventually, for a small child) is refusing to acknowledge the emperor’s nakedness, thus perpetuating the charade that the emperor is actually wearing some incredibly expensive and special clothing that is only visible to a select few. My own personal favourite example of the distinction comes from the blue-eyed islander puzzle, discussed previously here, here and here on the blog. (By the way, I would ask that any commentary about that puzzle be directed to those blog posts, rather than to the current one.) (Source) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e6264d9bc9110421451f6267f43c174477f82f584d7a9dc4e49f8dc659db96f-8cf49927ad6833cdf66e3a39ce25e50207fcccd932e746ed60b7be4bbfefcc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Nahay")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-473709")[#strong[#text("John Nahay")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("I did my patriotic duty already: I voted for Zoltan Istvan, Transhumanist, for President. Extremely difficult choice between him versus Dr Jill Stein (Green) or Clifton Roberts (Animal Rights) or John McAfee (Libertarian). Luckily, 2 of my family members have voted already, also by absentee ballot, for Jill Stein. Hopefully, when Dr Jill Stein gets into the White House in January she will start steering the country in the right direction again.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c57ab582dc04049d092f82d44f749064431b88a666a57b289fe75bef87282b9-c82d7cfc51890db18a0ab7c7f91551175cca2add373275080b0dbaf9e7e3cf00.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-473781")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2016")])]

#text("But Terence, Corruption is the number one problem in America right now. Hillary is the posterchild for political corruption.")

#text("I mean think about this; The media hates trump, even IF he is incompetent, the public will know everything he does. Every move he makes.")

#text("With Hillary the media has already proven they’re willing to cover up for her, regardless of what she does.")

#text("With Trump, if the worse case happens and he is horrible, we can always impeach him.")

#text("We can’t even bring Hillary to justice despite the mountain of criminal evidence against her for all kinds of things, emails, outright treason…etc.")

#text("What makes you think wel’l EVER be able to impeach her if she’s in the white house with presidential powers AND the media smokecreening half the population to believe she’s NOT doing anything bad?")

#text("I mean a simple analysis of worse case scenarios of both candidates would show that Hillary is far worse in terms of the damage she can possibly do. I mean this is like a fight between getting pneumonia and getting cancer.")

#text("One is bad don’t me wrong, the other is neigh incurable once it takes root.")#linebreak()#text(" Surely you can see that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d6b2816cccc86fbf2c8c030cfdc4bfbcd502e18c4d92c04a6dcf945ac7ae10b-96c2335b54ceeb3233c18a965ee609d814a773c8aed0c091921d8e42ea50defb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pepe")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-473782")[#strong[#text("Pepe")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2016")])]

#text("Hi Terry,")#linebreak()#text(" Please commit suicide ASAP, because it’s clears you’re contributing to the decline of the western world.")

#text("Sincerely,")

#text("Pepe")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474349")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("Get psychiatric help. Now.")

#text("If I were the owner of this blog, I’d get your IP address, track you down, and prosecute you.")

#text("Also, go back to school. You can’t even write a grammatically correct sentence. Clearly you represent Trump supporters.")

#text("Talk about deplorables…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474122")[#strong[#text("And the winner is… Harambe | A bunch of data")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2016")]

#text("[…] voting for Hillary Clinton. I urge you to read the posts by Scott Aaronson: here and by Terry Tao here or John Oliver’s segment here to see why. I would have thought that 99% of their readers, and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cd277f1ac0746e8ff0d585fb86c59877c5d615db2d966e61d1762690c2d33c6-f3e9e441f25d3976cc7e70b8199ddb8f30601510694348bd7f94ea01d2013ce3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trump is Winning Haha")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474188")[#strong[#text("Trump is Winning Haha")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2016")])]

#text("looks like trump is winning hahaha we made it")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c2d9f94818e8ae402a9884a58445e67a1cfcc99058656d3f735769be5fafc9c-63315e87c1b3f9c88704e7cc24e2fedd44e62984e7bb6b4bdd730f3600e577fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trump is the best")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474190")[#strong[#text("Trump is the best")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2016")])]

#text("Here’s why I think Trump is great for our democracy:")

#text("1. Donald Trump supports NSA surveillance on the American People.")

#text("2. Donald Trump supports torture.")

#text("3. Trump said: “Well, I’m very pro-choice. I hate the concept of abortion. I hate it. I hate everything it stands for. I cringe when I listen to people debate the subject. But, you still, I just believe in choice.”")

#text("4. Trump will build a wall to stop illegal rapist immigrants.")

#text("5. Trump didn’t fall for that climate change hoax invented by the Chinese.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6d14d0fa07a108f0f9673f91b5adddd2d64d3cfd2a724a12f03f9d7351601b0-7515943af767875659bb264183462064f3532f1b32ca054b49ec047ec68cb943.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474193")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2016")])]

#text("What has the world come to Terence? The idiots in America have managed to destroy the world. I wanted to come and study in American universities but now with that idiot as president… and it couldn’t have come at a worse time! The world is dying because of climate change and the idiots elected someone who thinks the Chinese invented it. I don’t understand how can so many people be so stupid.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6768e3d468b4b07a80c9892dd61444e098818d436bf9d119fbeec523826a1957-04ca2b255481493681a4dc0803e4b8a03d95aa44ea7716fbb97f197bdf073661.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brexitrump")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474195")[#strong[#text("Brexitrump")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2016")])]

#text("I hate democracy because most people are stupid and most people are going to vote for stupids (Brexit, Trump, … whoo’s next?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b4627521b7e27d1a657be7b329876595608256ab08d4cb83834a6d4ebd80f17-0878ea2a4eee4b524bc2215f68c82b72ea1fbbbab71e90ee621030c32fd5be4d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of WhiningAholes")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474223")[#strong[#text("WhiningAholes")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2016")])]

#text("Yeah the majority of people are just so stupid, but you have it all figured out, right? :) Heard it before, still don`t care. You have an opinion and it`s just your opinion, nothing else. The faster you learn that, the easier life will be.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84e2f1f8ecc13ad197bfcf8bf54e500b76a55ecd513a9d2e78dbc27dd1ae30e7-87c2aaffb0fad1eb700a656f52f7bed17cb3553b07811cc9293137b01077dce3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Power Rangers")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474198")[#strong[#text("Power Rangers")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2016")])]

#text("From now on, I will always bring an egg in my pocket while I navigate towards UCLA. Why you may ask. To throw it in the face of each one who didn’t vote for president Donald J. Trump.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474347")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("No, you won’t. You’re as testicularly-challenged as any Trump supporter.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/679e6d92fc726b66b99aa5a81aadf96c334c6004b528a1a6f078c1f46b46466a-e854e007935c91dad57f26e46d78bf7ebd550e798185e1e65ad64261e9b0ae4e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Kojar")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474203")[#strong[#text("Thomas Kojar")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2016")])]

#text("I wish science people could run for president.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6d14d0fa07a108f0f9673f91b5adddd2d64d3cfd2a724a12f03f9d7351601b0-7515943af767875659bb264183462064f3532f1b32ca054b49ec047ec68cb943.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474206")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2016")])]

#text("I wish people had to earn votes through intelligence. The stupid don’t even know whats good for them")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474301")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2016")])]

#text("Yeah, we should impose something like literacy tests or grandfather clauses to make sure only the correct people can vote.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ed9cd049be259ac55323e4b1dbef7ea1acecbc23e8d6cadf81c94cb59f0b047-2ef8e7fe96b07b30852d493079c4d2048bc8795e574a984b57941b644b6222b2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of analysis")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474208")[#strong[#text("analysis")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2016")])]

#text("The common knowledge was always that he was going to win.")

#text("The irony is no one will be willing to admit he/she voted for Trump (not even a Fields medal winner) lest be named a racist.")

#text("Being an immigrant I am terrified and very greatly worried.")

#text("But the alternative was sure end of US of A. The great war was fought by the whites mostly in 1940s and with their actions US became a superpower with the help of intellectuals. They have a point that more resources need to be allocated to blacks and whites to lift their decaying culture, bad schools, drug addition and so on. What even UCLA is proposing is take in more migrant students from China and else where to fund the undocumented (so called DREAMers) and throw the Chinese out (with their ‘what for useful’ education, hard work, relationships ruined at UCLA) and give the undocumented every goodie they want. How was this justice?")

#text("Obama was weak even in 2008 (he poisoned the well with the hispanic appeasement rhetoric and snatched the candidacy in 2008 from Clinton). If Clinton was there the financial crisis would have ended 1 year earlier (simply because she had the connections to get the entire bailout money needed in 1 year instead of spreading over 3 years), get a better healthcare reform done, get a better finance law passed and many more things done. Obama was weak and a great idealist. Now in 2016 Clinton could not escape the hispanic appeasement rhetoric.")

#text("How was it not racist when Mayor Antonio Villaraigosa publicly says if you dont give undocumented citizenship republicans will not will presidency.")

#text("John Oliver says more illegals come from plane. The point of matter is more illegals COME FROM DIFFERENT COUNTRIES in plane while from ONLY ONE country cross the border leading to a political shift.")

#text("Lets see how screwed it is going to be. Obama legacy is tarnished.")

#text("Lets also see what was the bigger mistake Germany made – losing the war or losing civilizational advantage to US (both countries are protestant majority – no wonder Trump won).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ed9cd049be259ac55323e4b1dbef7ea1acecbc23e8d6cadf81c94cb59f0b047-2ef8e7fe96b07b30852d493079c4d2048bc8795e574a984b57941b644b6222b2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of analysis")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474209")[#strong[#text("analysis")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2016")])]

#text("The great war was fought by the whites mostly and also blacks in 1940s and with their actions US became a superpower with the help of intellectuals coming from Europe.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/392fd86c10fadb1498ef563602a7550b0cdc861ea84521e9e061635b44366281-55f01768ccaabe45bd3bcc23fa7368b9ff84d120abcae0e5039a88d8401a813a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474954")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2016")])]

#text(",I don’t think Grisha voted.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fd0d5fbe6b751ce491528ba8f80c6b8705ff55a7c3e75e41845cce1691c4bb5-3d39432d234e06e96f2eea23f5f5df540bef85de1089da301b176a893153ce14.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of IamTrumphater")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474213")[#strong[#text("IamTrumphater")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2016")])]

#text("If you had a slightly lower IQ and were from China imagine how miserable your life would have been here as a mathematics phd holder. The only sin you would have made was you were not a hispanic.")

#text("Hopefully people like yourselves can come up with creative ideas to the next president. This man is as everyone believes truthful in the things he says he will do and he should like good ideas.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b4627521b7e27d1a657be7b329876595608256ab08d4cb83834a6d4ebd80f17-0878ea2a4eee4b524bc2215f68c82b72ea1fbbbab71e90ee621030c32fd5be4d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of WhiningAholes")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474222")[#strong[#text("WhiningAholes")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2016")])]

#text("I have two words for you Americans who are so afraid of Trump; Ronald Reagan. Have you heard that name before? He was an actor and no one believed he could be president. He then became the greatest president the US have ever seen. So calm down, you guys have never had any idea what you are doing, it`s a crapshoot. Just remember Reagan, anything is possible.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cd69bcc4e5319249835c4ad3a651f7ce8eaf9bedbd2f79c9dc00b1fbd2ecabf-5675334e052ba14629b2db9cf49eff07fb6e801fab634a4666b5c8388a3a976e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of When Trump Sends His People They're Bringing Drugs")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474234")[#strong[#text("When Trump Sends His People They're Bringing Drugs")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2016")])]

#text("Trump is a rapist. Ronald Reagan wasn’t. Trump is a racist. Ronald Reagan wasn’t. Trump is a fascist. Ronald Reagan wasn’t. Trump is a dictator. Ronald Reagan wasn’t. Trump is a xenophobe. Ronald Reagan wasn’t. Trump is a climate change denier.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/392fd86c10fadb1498ef563602a7550b0cdc861ea84521e9e061635b44366281-55f01768ccaabe45bd3bcc23fa7368b9ff84d120abcae0e5039a88d8401a813a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474955")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2016")])]

#text("And Reagan was.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f861ae317410d9b67b9c8aa198e0169f19ce22b1824bb5d8833c64ba3d760fc-27591c1ed4e6d070bb4511bd2664acbe1e4a5ead848d49465677dab8ea154c1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474235")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2016")])]

#text("Should scientists that can leave the U.S. now?")

#text("It is horrifying to read the comments above. I always ask myself whether the people are stupid or evil. But I am absolutely certain that Donald Trump is dead evil, and he will probably screw up badly.")

#text("And day by day Fox News pumps the nonsense straight into people’s heads, and nobody trusts us mathematicians, ALTHOUGH WE REALLY KNOW BETTER. WE COULD BUILD A WORLD SUITABLE FOR ALL OF US, BUT THEY HAVE THEIR OWN THICK SKULL AND F*** EVERYTHING UP. I’M SO P***** O**.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67e3b6ba84b0ab8c7c146bb63a14bb9341d9aa1ae29dc20ce48057deb5daee5e-2bf0843c881c91ccce18d19ee980dc45742730c50e4ea4a8f7db0c7167000fbd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LogicMatters")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474237")[#strong[#text("LogicMatters")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2016")])]

#text("Terry Tao (2016): “It ought to be common knowledge that Donald Trump is not fit for the presidency of the United States of America”")

#text("Terry Tao (2017): “It ought to be common knowledge that Donald Trump is the president of the United States of America”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b39fc56b8a1645bd105b0a64fab1915acb943530473582f96d10fc0c0ba1213-1f5a9b638db522473228aa4d674015abc52a2ec078c138de6c6f6e3341ec8421.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shecky R")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474240")[#strong[#text("Shecky R")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2016")])]

#text("You’re assuming of course that the Electoral College electors, who haven’t convened yet, actually vote the way you believe they will, AND that Trump is alive and well come Jan. 20 to take office….")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/392fd86c10fadb1498ef563602a7550b0cdc861ea84521e9e061635b44366281-55f01768ccaabe45bd3bcc23fa7368b9ff84d120abcae0e5039a88d8401a813a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474957")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2016")])]

#text("I hope at least 270 of them possess such common knowledge. (That’s why Americans are called stupid.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f861ae317410d9b67b9c8aa198e0169f19ce22b1824bb5d8833c64ba3d760fc-27591c1ed4e6d070bb4511bd2664acbe1e4a5ead848d49465677dab8ea154c1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474258")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2016")])]

#text("Yeah, now you gave it to us liberals, right? Now you are the WINNER, right? But no, in order to convince yourself of your view, you will bash us again and again, and we will have to work harder and harder to compensate. The only thing I am sad about is the millions who will succumb due to Climate Change. But no, that’s just a hoax invented by the Chinese, as you know from Fox News, which doesn’t tell you ANY BULLSHIT at all.")

#text("Well, you can change. You probably can’t even watch it for an hour (since this would be too contrary to your view) but just in case: ")#link("http://www.democracynow.org/")[#text("http://www.democracynow.org/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/caf5fab8cff3b49322291020d31d562a56b6fe8f2a9829fe8267844da5a35c5a-490a39a0c3c7686e6de74ee76ec25920836a580ce4b594568dadf120e5555008.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mitt Romney's Dog")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474272")[#strong[#text("Mitt Romney's Dog")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2016")])]

#text("If you actually knew logic, you’d know those aren’t mutually exclusive statements.")

#text("Especially in a country where half the citizenry is governed by fear of their own shadows, and is willing to overlook that little Donny Trump is a sexual predator, racist, tax cheat, draft dodger, and failed businessman.")

#text("Let me know if you need any additional tutoring in logic….or ethics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e6264d9bc9110421451f6267f43c174477f82f584d7a9dc4e49f8dc659db96f-8cf49927ad6833cdf66e3a39ce25e50207fcccd932e746ed60b7be4bbfefcc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Nahay")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474280")[#strong[#text("John Nahay")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2016")])]

#text("What happened to all the “THE POLLS ARE RIGGED! THE POLLS ARE RIGGED! THE ELECTION IS RIGGED!”")#linebreak()#text(" bullshit that extreme far-right conservatards shouted endlessly before the election?")#linebreak()#text(" Suddenly, all the righties are utterly silent on the issue.")

#text("Anyone who did not vote for Dr Jill Stein (Green), or Zoltan Istvan (Transhumanist),")#linebreak()#text(" or Clifton Roberts (Humane), or John McAfee (Libertarian) is a worthless subhuman piece of shit")#linebreak()#text(" who hates America and just wants to make the USA a shithole fascist state like Saudi Arabia.")

#text("When Trump frees ALL prisoners, then bombs the prisons so they can never hold anyone hostage again,")#linebreak()#text(" including factory farms with billions of nonhuman animals murdered for meat,")#linebreak()#text(" even though the hardship of going vegan is INSIGNIFICANT compared to the pain & suffering forced")#linebreak()#text(" upon nonhuman animals, THEN rightards can claim Trump is pro-freedom.")

#text("When Trump gets the nation off its fossil fuel addiction & switches ASAP to green energy")#linebreak()#text(" & products (electric cars), makes the USA carbon-neutral or even carbon-negative –")#linebreak()#text(" soak up all those megatons of carbon it forced into the atmosphere in the first place,")#linebreak()#text(" and outlaws factory farming & breeding animals for meat & fur,")#linebreak()#text(" & guarantees everyone a basic minimal income, then he can claim he made America great again.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/392fd86c10fadb1498ef563602a7550b0cdc861ea84521e9e061635b44366281-55f01768ccaabe45bd3bcc23fa7368b9ff84d120abcae0e5039a88d8401a813a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474956")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2016")])]

#text("It takes a subhuman to spot one. It takes a transhuman to name one.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c399ce8553ab0189a79fc58e77d07acc1bc8a0dd3a87b51087bbaf8af36f79c3-4136d45621f8e09d08291849616f1dcc9fb4c43a24ce23b32c989009634683bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Math - Update")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474243")[#strong[#text("Math - Update")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2016")])]

#text("Reblogged this on ")#link("https://mathupdatesblog.wordpress.com/2016/11/11/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/")[#text("math – update")]#text(" and commented:")#linebreak()#text(" Very interesting.. .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/89727d76889db00e54fc6e6696c740b0d2640bb6c12894bbb2f1038707cc5954-92df2b330b542fdd549293f0d7492f8c4da1227d33c34459996d419df073bfc7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yvon")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474244")[#strong[#text("Yvon")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2016")])]

#text("JOKE.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d074d7542e375bc482ac186e8d338cfbc1d9b08552b5895b2a50f49566d7b985-fa1f69571482dd37c6957694562b5c05ed24648c5c3838fd7190785f2e8fabe8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ku Klux Klan member")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474260")[#strong[#text("Ku Klux Klan member")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2016")])]

#text("Meanwhile, Ku Klux Klan (KKK) announces Donald Trump victory parade as a celebration ")#link("http://www.independent.co.uk/news/world/americas/ku-klux-klan-parade-north-carolina-donald-trump-celebration-president-elect-white-supremacists-alt-a7410671.html")[#text("http://www.independent.co.uk/news/world/americas/ku-klux-klan-parade-north-carolina-donald-trump-celebration-president-elect-white-supremacists-alt-a7410671.html")]

#text("Good job America, will purify our country")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f861ae317410d9b67b9c8aa198e0169f19ce22b1824bb5d8833c64ba3d760fc-27591c1ed4e6d070bb4511bd2664acbe1e4a5ead848d49465677dab8ea154c1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474262")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2016")])]

#text("Murder of any kind must be punished by the law.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e6264d9bc9110421451f6267f43c174477f82f584d7a9dc4e49f8dc659db96f-8cf49927ad6833cdf66e3a39ce25e50207fcccd932e746ed60b7be4bbfefcc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Nahay")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474281")[#strong[#text("John Nahay")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2016")])]

#text("If you cannot do math, i.e. do quantum mechanics from the atoms on up, then you cannot claim to “know” cause & effect & how reality works. Therefore, you cannot call anyone a murderer or a terrorist or a rapist. All you know, all you see, is atoms moving around.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e88c7926d9acf39035fcdb3d33ef5c2940f4a00bc7284f30302b5111f1ddb3a4-80cf16a30f288c39529de39aae4b9548b11a77e99b69844b2aea4cfb77fd4807.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of onlyearthleft.")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474287")[#strong[#text("onlyearthleft.")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2016")])]

#text("here is why he won ")#link("http://www.nytimes.com/2016/11/13/business/economy/can-trump-save-their-jobs-theyre-counting-on-it.html")[#text("http://www.nytimes.com/2016/11/13/business/economy/can-trump-save-their-jobs-theyre-counting-on-it.html")]

#text("it is shocking he won. but we knew it.")

#text("it looks like it will be shocking he will follow on his campaign promises. but we think he will do it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/546e234ea5cf80969c177d35d4001fa2969fbbb5c7b85b0fa4c29a6ef0de34a8-78362a6e3f0d6b26022286bf2da02c3f4417b34e079c640b5f1ffef133831914.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R. Moses")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474290")[#strong[#text("R. Moses")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2016")])]


]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474331")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2016")])]

#text("I wonder how the author explains in mathematical theory now that DJT is elected.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b118d72fade5df27bbc9543c709e5b599e6967367def577bf5508f3e8374c10-3df9672d63de9aae4764091bb3699cd4793c8a595c457972e731643de18aa94c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lazar Ergo")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474338")[#strong[#text("Lazar Ergo")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("Donald Trump has NEVER held public office before and every single former president has.")

#text("Trump openly calls for the U.S to commit war crimes and advocates for the murder of innocent women and children.")

#text("thinkprogress.org/politics/2015/12/15/3732671/trump-isis-kill-family-members/")

#text("independent.co.uk/news/world/americas/donald-trump-reiterates-desire-to-murder-terrorists-families-a6912496.html")

#text("cnn.com/2015/12/02/politics/donald-trump-terrorists-families/")

#text("Trump doubles down after veterans speak out claiming U.S soldiers would not commit war crimes or torture children even if ordered to. Trump responds with, “They’re not going to refuse me. If I say do it, they’re going to do it.“")

#text("washingtontimes.com/news/2016/mar/3/donald-trump-says-hed-force-us-military-commit-war/")

#text("politifact.com/truth-o-meter/statements/2015/dec/17/rand-paul/rand-pauls-right-geneva-conventions-bar-donald-tru/")

#text("Trump on torture: “Even if it doesn’t work they probably deserved it anyway.”")

#text("cnn.com/2016/03/11/opinions/trump-wrong-on-american-torture/")

#text("Trump renews calls for torture citing public executions and mass rape committed by ISIS promising for the U.S to do the same, “fighting fire with fire.”")

#text("talkingpointsmemo.com/livewire/trump-responds-istanbul-waterboarding-torture")

#text("Trump says Geneva Conventions a problem and needs to be changed since, US soldiers are to afraid to do their job due to laws which outline the definition of war crimes.")

#text("politico.com/blogs/2016-gop-primary-live-updates-and-results/2016/03/donald-trump-geneva-conventions-221394?cmpid=sf")

#text("Trump threatens to shoot down Russian planes starting war with Russia.")

#text("newsweek.com/trump-says-us-should-shoot-russian-planes-if-putin-calls-fail-454902")

#text("Trump says he, “won’t rule out” using nuclear weapons in Europe.")

#text("independent.co.uk/news/world/americas/us-elections/donald-trump-refuses-to-rule-out-using-nuclear-weapons-in-attack-on-europe-a6961101.html")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35ccd8104ec6ef76d0151eb6591534c713fbb37315ec2ecfd38fa769386a4b21-14b63b1f493a65950b6c0451aee7986c3329a468dcd41ec7eac95c60cd438902.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Mandelson")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474398")[#strong[#text("David Mandelson")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2016")])]

#text("Lazar Ergo, you are such a liar! Living in your own pathetic imagination.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474400")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2016")])]

#text("Predictable. A moron Trump supporter shows up to call names.")

#text("Crawl back in your hole or back under your bedsheets. Your bleating “liar” is childish.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd3af300a3018824f1c2e32940daca5b24b140034b80ecee81072364b138f0a8-1bd0c03e4ab28c768288b5432bed86c5c425367573b9b2adf371464fdb8a53b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Take Away")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474413")[#strong[#text("Take Away")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2016")])]

#text("He isn’t a liar, he literally just showed you what Trump said, where is “pathetic imagination” in all of this? I’m sure you’re behaving just like Donald Trump when he was talking like a lobotomy patient whilst trying to assert how intelligent he is:")

#text("“People don’t know how great you are. People don’t know how smart you are. These are the smart people. These are the smart people. These are really the smart people. And they never like to say it, but I say it and I’m a smart person. These are the smart, we have the smartest people. We have the smartest people. And they know it. And some say it, but they hate to say it. But we have the smartest people. Government will start working again. Fixing things.” (twitter.com/kylegriffin1/status/781251501947748352/photo/1) (youtube.com/watch?v=vlSkiaO3Z60)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Mandelson")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474419")[#strong[#text("David Mandelson")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2016")])]

#text("you liberals are first of all, painters – painting the world or people in whatever manner you deem glorious, and then, mad dogs – biting any views or people that deviate from your MSM parents.")

#text("I respect Terry for writing a blog, with his own approach to predict. Though failed, the approach and views are at least still respectable.")

#text("But to you mad dogs, I feel you all deserve to be flushed into the toilet. Period.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474433")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2016")])]

#text("You paint yourselves. What exactly do you expect when you support a blatant racist, and then bleat piteously that you yourself aren’t just a simple, ignorant racist?")

#text("You’re either an intellectual coward, or just ignorant. Which is it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474434")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2016")])]

#text("What’s ironic is that the most effective criticism of Trump and his shall-we-say morally and mentally-challenged fans is to simply broadcast his own words, and their own breathless, mindless adoration….over and over.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa048abf670d8b778a116698023bbe5af050f74ace9980fe92754cc9c83d18a0-b6954857dbb9d5d512d89daa07c4a34a10bd7a7bec5cac9b1259418a64cc840d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trump's Genius")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474450")[#strong[#text("Trump's Genius")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2016")])]

#text("Some President-elect Trump that illustrates his creative genius:")

#text("“I’m a very smart guy, I went to the best college, I had good marks. I was a very smart guy, good student. […] I was a really good student at the best school. I’m like a smart guy […] If I were a liberal Democrat, people would say I’m the super genius of all time. The super genius of all time.”")

#text("“My whole life is about winning. I always win. I win at golf. I’m a club champion many times at different clubs. I win at golf. I can sink the three-footer on the 18th hole when others can’t. My whole life is about winning. I don’t lose often. I almost never lose.”")

#text("thedailybeast.com/articles/2015/09/21/trump-won-t-prove-he-was-a-super-genius-at-wharton.html")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bb59e0a8353ef50c4fa01fca09e0afc26abe865572c899f7afb646046fee258-58022e796e82df0a245199d944dabdb763afe041c4093e84a6b0d8008cdbe1ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffrey Helkenberg")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474411")[#strong[#text("Jeffrey Helkenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2016")])]

#text("If you were not able to predict the outcome it is because you lack sufficient data from which to derive a(n accurate) function (to model voter turnout). In terms of real measurements it means you live in a bubble the boundary of which describes your worldview.")

#text("Donald Trump excites the janitor that empties your office trash can. Unless your janitors is an “illegal immigrant” at which point he or she might be woefully underpaid and therefore terrified of being shipped back to his or her country of origin; if you are poor you have no “luck.” The person who is growing food and spraying toxic chemicals on migrant workers is not a fan of Trump. It takes a Hillary supporter to gas humans and rationalize it as a normal cost of doing business.")

#text("I a not surprised that you are not a fan of Trump. By the way, were you able to meet President Elect Donald Trump prior to your character assassination attempt? I wonder if that will affect your budget? Has he read of your disdain for him? I wouldn’t want to get on his bad side lest I wanted to be drawn and quartered. Like a graph, is what I am saying. Analyzed graphically.")

#text("“You’re FIRED!”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474418")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2016")])]

#text("Your gutless hero Trump is a sexual assaulter, failed businessman, tax cheat, draft dodger, adulterer, and serial liar. He has no character, hence it’s a little idiotic of you to whine about “character assassination”.")

#text("Just curious – how do you like playing lickspittle to the rich? One marvels at the kind of life story that would make your sycophancy palatable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bb59e0a8353ef50c4fa01fca09e0afc26abe865572c899f7afb646046fee258-58022e796e82df0a245199d944dabdb763afe041c4093e84a6b0d8008cdbe1ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffrey Helkenberg")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474501")[#strong[#text("Jeffrey Helkenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2016")])]

#text("I see that you are remaining safe behind the veil of anonymity while castigating me. How “dodgy” of you. I dare say that some of the greatest Presidents owned slaves. We find that what is intolerable in one time is relatively normal in another. For instance, you accuse The Donald of cheating on his taxes, yet anyone with a shred of intellect understands that it is not cheating to use the instruments available to you. He did not cheat on his taxes, rather he “won” on his taxes.")

#text("As for being a failed businessman, I will have to assume you are an academician who relies on public funding (to wit, enslaving unsuspecting children to a life of penury). Of course, since you are hiding your name I will not be able to actually vouchsafe the accuracy of that accusation. It is just that your post is dripping with the kind of narcissistic self-assuredness most often associated with people who have never had to meet a payroll.")

#text("Playing lickspittle to the rich? My, that is the very definition of reaching. Perhaps it is because I am wealthy that I can accept (as an article of faith) that we need to at least give Technocracy a chance.")

#text("Yes, Trump is a technocrat. Thankfully no one pointed that out. He would have lost the election had that moniker stuck.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/697e30841310e6de216cf1c889edd8ab7716cddb0fb41a4e2da21f3b51522620-38c487ffa22cc32547274c3d082e3e1a5651d24b2f3dfed3c612cef6c8084412.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Love trumps Hate")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474511")[#strong[#text("Love trumps Hate")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2016")])]

#text("How is this acceptable to you regardless of time and place?")

#text("Donald Trump has NEVER held public office before and every single former president has.")

#text("Trump openly calls for the U.S to commit war crimes and advocates for the murder of innocent women and children.")

#text("thinkprogress.org/politics/2015/12/15/3732671/trump-isis-kill-family-members/")

#text("independent.co.uk/news/world/americas/donald-trump-reiterates-desire-to-murder-terrorists-families-a6912496.html")

#text("cnn.com/2015/12/02/politics/donald-trump-terrorists-families/")

#text("Trump doubles down after veterans speak out claiming U.S soldiers would not commit war crimes or torture children even if ordered to. Trump responds with, “They’re not going to refuse me. If I say do it, they’re going to do it.“")

#text("washingtontimes.com/news/2016/mar/3/donald-trump-says-hed-force-us-military-commit-war/")

#text("politifact.com/truth-o-meter/statements/2015/dec/17/rand-paul/rand-pauls-right-geneva-conventions-bar-donald-tru/")

#text("Trump on torture: “Even if it doesn’t work they probably deserved it anyway.”")

#text("cnn.com/2016/03/11/opinions/trump-wrong-on-american-torture/")

#text("Trump renews calls for torture citing public executions and mass rape committed by ISIS promising for the U.S to do the same, “fighting fire with fire.”")

#text("talkingpointsmemo.com/livewire/trump-responds-istanbul-waterboarding-torture")

#text("Trump says Geneva Conventions a problem and needs to be changed since, US soldiers are to afraid to do their job due to laws which outline the definition of war crimes.")

#text("politico.com/blogs/2016-gop-primary-live-updates-and-results/2016/03/donald-trump-geneva-conventions-221394?cmpid=sf")

#text("Trump threatens to shoot down Russian planes starting war with Russia.")

#text("newsweek.com/trump-says-us-should-shoot-russian-planes-if-putin-calls-fail-454902")

#text("Trump says he, “won’t rule out” using nuclear weapons in Europe.")

#text("independent.co.uk/news/world/americas/us-elections/donald-trump-refuses-to-rule-out-using-nuclear-weapons-in-attack-on-europe-a6961101.html")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bb59e0a8353ef50c4fa01fca09e0afc26abe865572c899f7afb646046fee258-58022e796e82df0a245199d944dabdb763afe041c4093e84a6b0d8008cdbe1ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffrey Helkenberg")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474551")[#strong[#text("Jeffrey Helkenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2016")])]

#text("Well-researched. Loads and loads of references. You must think that these kinds of choices are made by people who are going to take time to reflect on the consequences of their decisions. However, we moved way beyond that with this election. We have, in fact, been in a post-fact Universe for a very long time. Are you just now realizing this?")

#text("First, the vast majority of people in this country are dissatisfied with government at the Federal level. I am sure that the intelligentsia, safely ensconced in their taxpayer-supported castles, are *very satisfied* and therefore completely unable to digest the real fury that much of the country is feeling. You see, it is precisely those with education who are living counterfactually. And, even worse, the same people are now “informing” Trump supporters that the sky is falling.")

#text("Meanwhile, equity investors have to be enjoying the rally – quite the opposite of the collapse that was billed as “factually inevitable.” I suspect it is money flowing out of bonds that is driving the rally; probably not a good sign. Whatever; I doubt many Trump supporters own stock.")

#text("By owning nuclear weapons we can never rule out using them. And as the only nation to have ever detonated them over a population center we are hardly in a position to tell the world that we have moved beyond “using them.” My, how enlightened of us.")

#text("At any rate I would suggest that you remain focused on non-moving targets like the theoretical math that deals with deterministic systems. And I think that applies to most people here. You might be great watchmakers, but you are patently terrible at telling the time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf7d6e2f98a6e80d9a04d66a4f987c35174007c97d05e2d58a606477c16daceb-907f88d640b9b248fc2a3e95b23d18fa283c81b7b31d7b133234c36fed1c8dc5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HIIIIIIIIIIIIIIIIIIIIS")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474554")[#strong[#text("HIIIIIIIIIIIIIIIIIIIIS")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2016")])]

#text("To Jeffrey: So there’s nothing wrong with a president who says he wants to make war crimes and change the Geneva convention?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474714")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2016")])]

#text("Yes, “Jeffrey Helkenberg”, like Trump supporters everywhere, has some problems with simple logic, and is a delicate little snowflake when it comes to reason of any kind.")

#text("Be gentle with him. It’s easy to hurt his feelings.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474713")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2016")])]

#text("Hi Jeffy, just a protip:")

#text("Amazon has replacement kneepads so you can continue to worship those with money, in the kind of warm, milky comfort your life story demands.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e88c7926d9acf39035fcdb3d33ef5c2940f4a00bc7284f30302b5111f1ddb3a4-80cf16a30f288c39529de39aae4b9548b11a77e99b69844b2aea4cfb77fd4807.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of onlyearthleft.")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474420")[#strong[#text("onlyearthleft.")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2016")])]

#text("If Trump is elected on Dec 19 he may turn out to be the best president in anyone’s memory. The reason is simple – the economy is still in sweet spot in interest rate cycle, he is front loading on infrastructure and defense spending, he is going to cut rates across the board. In such a scenario if he does not go to war his time will turn out to be successful. I am unsure about health care and retirement subsidies.")

#text("The biggest issue then is following. It legitimizes his platform of presidency as an inspiration for the foreseeable future just like Reagan’s platform was inspirational and so times could indeed change permanently.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10897067b25ad18fe92cb021069ce7a088352dfedc706ddf74e89509b3a4588c-af84ceeb9f54bcc9c8eb40230ff6c60700f7375606390abbf45fc1b57c9b6e03.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trump is a con")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474456")[#strong[#text("Trump is a con")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2016")])]

#text("President-elect Trump has agreed to pay $25 million to settle civil fraud suits against Trump University")

#text("In other words he agreed that his “Trump University” was a scam")

#text("25 million less 40% to lawyers = 15 million divided by 6,000 victims equals $2,500 per victim.")

#text("In fact, records produced indicate 7611 tickets in total were sold to customers attending courses. Approximately 6000 of these tickets were for a $1,500 3-day course and 1000 tickets were for silver, gold or elite mentored courses ranging in price from $10,000 to $35,000. That equals $9 million in revenue for the 3-day seminars. If we assume all other tickets were only silver, that’s another $10 million. So, the minimum revenue Trump screwed people for was $19 million and likely much more.")

#text("I don’t think those victims are getting restitution and Trump gets away with no admission of guilt. The lawyers will have done fine, as usual.")

#text("Yet he VOWED to never settle and said ‘I Don’t Settle’")

#text("What a LIAR, SCAMMER, CON. And he’s now president")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e6264d9bc9110421451f6267f43c174477f82f584d7a9dc4e49f8dc659db96f-8cf49927ad6833cdf66e3a39ce25e50207fcccd932e746ed60b7be4bbfefcc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Nahay")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474491")[#strong[#text("John Nahay")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2016")])]

#text("As always, the world gets f’ed up by conservatives. The power & control is ALWAYS in the hands of EXTREME conservatives – whether Republican or Democrat. Muslims killing muslims, or muslims battling US troops is extreme rightwingers killing other extreme rightwingers. The needless breeding & torture of ten BILLION animals each year is caused by selfish psychotic extremist conservatives – 99.99% of the human population – who put their stupid selfish habits & cultures & traditions & nationalism above doing what is fair & right & minimizing pain & suffering.")#linebreak()#text(" What stupid morons would think a billionaire Wall Street welfare-sucking Republican would be a “contrarian”, an “alternative”, an “anti-authoritarian”, an “anti-establishment”, who stands up to big governments, and puts an end to agencies like the FBI and NSA and would free all prisoners held hostage in prison?")

#link("http://www.dailykos.com/story/2016/9/18/1570275/-Donald-Trump-is-the-establishment")[#text("http://www.dailykos.com/story/2016/9/18/1570275/-Donald-Trump-is-the-establishment")]

#text("I voted for Transhumanist Zoltan Istvan this election,")#linebreak()#text(" as the most pro-science candidate.")#linebreak()#text(" I voted for Dr Jill Stein in 2012 and 2008, and Ralph Nader in 2004 & 2000 & 1996.")

#text("Show me a leader who openly & proudly advocates outlawing the meat industry, outlawing breeding animals for meat fur & experimentation,")#linebreak()#text(" as OFTEN as rightwing politicians talk about outlawing abortion –")#linebreak()#text(" show me a leader who proudly openly advocates forcing all churches & mosques to pay taxes just like everyone else,")#linebreak()#text(" show me a leader with the guts to proudly openly advocates mandatory vasectomies & mandatory abortion & putting people in jail for reproducing.")#linebreak()#text(" Then you can claim that leader is a liberal.")

#text("I proudly openly do.")

#text("Righties are the most EXTREME HYPOCRITES for RIDICULING IMAGINARY “leftists” – all over the comment sections of RT News YouTube channel videos – for not standing up to muslim refugees flooding into Europe & demanding that they use birth control, when it was ALWAYS the rightards who insulted & attacked leftists for DECADES for making ANY mention of mandatory birth control because it violated the rightists’ STUPID TRIVIALLY UNIMPORTANT religious or libertarian beliefs.")

#text("Righties, including libertarians, now join the antiscience natural medicine craze – because it is – once again – pushing for a cause that BENEFITS ONLY THEM PERSONALLY. It is IMPOSSIBLE for a rightie EVER to take a stand in which THEY have to acknowledge responsibility, blame, & give up something in their personal habit or custom or lifestyle.")

#text("ALWAYS so much easier to blame & target a small handful of abortion doctors or Hollywood moviemakers or the FDA or biotechnologists at Monsanto working on GMOs. (Not saying Monsanto is perfect: their LEGAL department is evil, not their scientists.)")

#text("SO much harder to attack a HUGE majority of the population that overpopulates & eats meat.")

#text("That is why I have ZERO respect for anyone who does not take antinatalist animal rights as seriously as all their other issues combined.")

#text("I have said the same think since 1980. Nothing has changed.")#linebreak()#text(" Show me evidence to the contrary.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e6264d9bc9110421451f6267f43c174477f82f584d7a9dc4e49f8dc659db96f-8cf49927ad6833cdf66e3a39ce25e50207fcccd932e746ed60b7be4bbfefcc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Nahay")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474493")[#strong[#text("John Nahay")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2016")])]

#text("Fact: you cannot claim to be “persecuted” or “silenced” when the laws are all in your favor or when politicians or mainstream media talk about YOUR issues all the time.")

#text("Ergo: christians, muslims & conservatives have nothing to complain about.")#linebreak()#text(" They don’t pay taxes. They force their “god” crap onto MY money & MY pledge of allegiance. Medical naturopathic scammers have nothing to complain about. Their worthless “drugs” never have to pass the rigorous FDA tests that pharmaceutical drugs do.")

#text("Ergo: vegan antinatalist animal rights atheists & UFO disclosure activists DO have a right to be angry & claim persecution")

#text("The ONLY thing conservatives have to complain about is being RELENTLESSLY called racist or sexist or homophobic when there is no testable falsifiable evidence to look inside their minds & determine what their feelings are. That’s not MY fault. That is the fault of millions of subhuman humanities majors at universities who are too stupid to do something hard like math or science or work with their hands.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9305491a7d22208164c6cff5c47c96b9ac328e6168102856ab999eca042175b-bb8d09a7f0b240fca5632db668a18ecabfdf5a8586e4ac25148c8fbe9929ad56.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 80 kinds of trump supporters")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474514")[#strong[#text("80 kinds of trump supporters")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2016")])]

#text("80 kinds of trump supporters: i.imgur.com/6MPynAO.png")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e0f8bd0470133d7b3805b4dc66b3f0138fa3a2545ad9749df9990ea7d3ee880-15e1917c079bf44bb098f38da37b73dd1a262658290f854ce23e39332990f394.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trump's U-turns")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474583")[#strong[#text("Trump's U-turns")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2016")])]

#text("15 Trump flip-flops:")

#text("On his predecessor:")

#text("“I think president Obama has been the most ignorant president in our history…President Obama when he became president, he didn’t know anything. This guy didn’t know a thing. And honestly, today he knows less. Today, he knows less. He has done a terrible job.” (Press conference in Florida, July 27, 2016)")

#text("“I have great respect…I very much look forward to dealing with the President in the future, including counsel. He explained some of the difficulties, some of the high-flying assets and some of the really great things that have been achieved.” (White House, November 10, 2016)")

#text("On anti-Trump protesters:")

#text("“Just had a very open and successful presidential election. Now professional protesters, incited by the media, are protesting. Very unfair!” (Twitter, November 10, 2016, 9:19pm ET)")

#text("“Love the fact that the small groups of protesters last night have passion for our great country. We will all come together and be proud!” (Twitter, November 11, 2016, 6:14am ET)")

#text("On Obamacare:")

#text("“It’s gotta go.” (CNN, July 30, 2015)")

#text("“I like those [the prohibition against insurers denying coverage because of patients’ existing conditions and a provision that allows parents to provide years of additional coverage for children on their insurance policies] very much.” (Wall Street Journal, November 11, 2016)")

#text("On the border wall:")

#text("“Jeb Bush just talked about my border proposal to build a “fence.” It’s not a fence, Jeb, it’s a WALL, and there’s a BIG difference!” (Twitter, August 25, 2015)")

#text("“There could be some fencing.” (60 Minutes, November 13, 2016)")

#text("On gay marriage:")

#text("“If I’m elected, I would be very strong on putting certain judges on the bench that I think maybe could change things…I don’t like the way they ruled…I would strongly consider [trying to appoint justices to overrule the decision on same-sex marriage].” (Fox News Sunday, January 31, 2016)")

#text("“It’s irrelevant because it was already settled. It’s law. It was settled in the Supreme Court. I mean it’s done…And I’m fine with that.” (60 Minutes, November 13, 2016)")

#text("On locking her up:")

#text("“If I win, I am going to instruct my attorney general to get a special prosecutor to look into your situation. There has never been so many lies, so much exception. There has never been anything like it. We will have a special prosecutor. I go out and speak and the people of this country are furious. The long time workers at the FBI are furious. There has never been anything like this with emails. You get a subpoena and after getting the subpoena you delete 33,000 emails and acid wash them or bleach them. An expensive process. We will get a special prosecutor and look into it. You know what, people have been—their lives have been destroyed for doing one-fifth of what you have done. You should be ashamed.” (Second Presidential Debate, October 9, 2016)")

#text("“I don’t want to hurt the Clintons, I really don’t…It’s just not something that I feel very strongly about.” (New York Times, November 22, 2016)")

#text("On deporting illegal immigrants:")

#text("“We have at least 11 million people in this country that came in illegally. They will go out.” (CNN-Republican Debate, February 25, 2016)")

#text("“What we are going to do is get the people that are criminal and have criminal records, gang members, drug dealers, we have a lot of these people, probably two million, it could be even three million, we are getting them out of our country or we are going to incarcerate.” (60 Minutes, November 13, 2016)")

#text("On the generals:")

#text("“Well the generals under Barack Obama and Hillary Clinton have not been very successful.” (Commander-in-Chief Forum, September 7, 2016)")

#text("“We have some great generals. We have great generals.” (60 Minutes, November 13, 2016)")

#text("“Well, I’ll be honest with you, I probably do [know more about ISIS than the generals do] because look at the job they’ve done. Okay? Look at the job they’ve done. They haven’t done the job.” (60 Minutes, less than a minute later)")

#text("On nuclear Japan:")

#text("“Well I think maybe it’s not so bad to have Japan — if Japan had that nuclear threat, I’m not sure that would be a bad thing for us.” (New York Times, March 26, 2016)")

#text("“The @nytimes states today that DJT believes “more countries should acquire nuclear weapons.” How dishonest are they. I never said this!” (Twitter, November 13, 2016)")

#text("On the Electoral College:")

#text("“The electoral college is a disaster for democracy.” (Twitter, November 06, 2012)")

#text("“The Electoral College is actually genius in that it brings all states, including the smaller ones, into play. Campaigning is much different!” (Twitter, November 15, 2016)")

#text("“I’d rather do the popular vote.” Says he was “never a fan of the electoral college.” (New York Times, November 22, 2016)")

#text("On the Trump University lawsuit:")

#text("“Trump University has a 98% approval rating. I could have settled but won’t out of principle!” (Twitter, February 29, 2016)")

#text("“I don’t settle cases…I won’t settle because it’s an easy case to win in court.” (Morning Joe, March 3, 2016)")

#text("“I settled the Trump University lawsuit for a small fraction of the potential award because as President I have to focus on our country” (Twitter, November 19, 2016)")

#text("On man-made climate change:")

#text("“I am not a great believer in man-made climate change.” (Washington Post, March 21, 2016)")

#text("“I think there is some connectivity. Some, something.” (New York Times, November 22, 2016)")

#text("On the Paris climate agreement:")

#text("“We’re going to cancel the Paris Climate Agreement” (Policy address in North Dakota, May 26, 2016)")

#text("“I have an open mind to it.” (New York Times, November 22, 2016)")

#text("On torture:")

#text("“Torture works. OK, folks? You know, I have these guys—‘Torture doesn’t work!’—believe me, it works. And waterboarding is your minor form. Some people say it’s not actually torture. Let’s assume it is. But they asked me the question: What do you think of waterboarding? Absolutely fine. But we should go much stronger than waterboarding.” (South Carolina, February 17, 2016)")

#text("“[Mattis] said, ‘I’ve never found it to be useful…Give me a pack of cigarettes and a couple of beers and I’ll do better.’…I was very impressed by that answer… [Torture is] not going to make the kind of a difference that a lot of people are thinking.’’ (New York Times, November 22, 2016)")

#text("On the New York Times:")

#text("“Wow, the @nytimes is losing thousands of subscribers because of their very poor and highly inaccurate coverage of the ‘Trump phenomena.'” (Twitter, November 13, 2016)")

#text("“I have great respect for the New York Times. I have tremendous respect…The New York Times is a world jewel. And I hope we can all get along.” (New York Times, November 22, 2016)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/392fd86c10fadb1498ef563602a7550b0cdc861ea84521e9e061635b44366281-55f01768ccaabe45bd3bcc23fa7368b9ff84d120abcae0e5039a88d8401a813a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474959")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2016")])]

#text("You forgot that when he was going to grad biz school in Philly he got a tix for running a stop sign. And 48 years later his daughter’s gofer went to a 20-item checkout lane in a supermarket while having 23.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d80ac5e8997793688c94e988aec31e697b5c594bbbceee2d86f82b00cf3376a-799c4be03bc6ec2d75be703419cce31fe2a43d8076079088adda47c37dca786a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Clilary")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474704")[#strong[#text("Clilary")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2016")])]

#text("Donald Trump just said that the elections are rigged: “In addition to winning the Electoral College in a landslide, I won the popular vote if you deduct the millions of people who voted illegally” twitter.com/realDonaldTrump/status/802972944532209664")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f2db6d422c9d6b358e8060ecf246d4ed3cbfdc96f4ac925f83ff8dae6c0f8b3-b22a9cdff82db49c9d501b41934ba7833860ca1405c1bf2d04ed65b1cfe5e5a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Constitution of the United States of America")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474735")[#strong[#text("Constitution of the United States of America")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2016")])]

#text("WHAAT? This guy didn’t read the constitution?")

#text("“Nobody should be allowed to burn the American flag – if they do, there must be consequences – perhaps loss of citizenship or year in jail!”")#linebreak()#text(" twitter.com/realDonaldTrump/status/803567993036754944")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bb59e0a8353ef50c4fa01fca09e0afc26abe865572c899f7afb646046fee258-58022e796e82df0a245199d944dabdb763afe041c4093e84a6b0d8008cdbe1ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffrey Helkenberg")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474738")[#strong[#text("Jeffrey Helkenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2016")])]

#text("He did this to illustrate that people on the left have very short memories. It once again proves the outright hypocrisy that the left seems all to willing to display like a badge of courage.")

#link("https://en.wikipedia.org/wiki/Flag_Protection_Act_of_2005")[#text("https://en.wikipedia.org/wiki/Flag_Protection_Act_of_2005")]

#text("“Sad.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b709e3aa796904f416f3f4c21fb6dfe65ed4e2d5719f2add84f340c3cb62d46-86d295cc3323402b603a5bffd65a9a9c2d949384099ce42a1fa71410abaac608.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474741")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2016")])]

#text("No, it illustrates that he didn’t read the constitution and wants us to behave like a fascist dictatorship.")

#text("“SAAAAAD.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474761")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2016")])]

#text("Oh look, it’s Helkenberg again! Abstract: he’s checking in with the effective 4th grader “so’s your mother” argument.")

#text("Here’s a tiny hint, junior. It will go completely over your head, but hey:")

#text("3 is a prime number. So is 5.")

#text("Happy to continue tutoring you and Trump supporters on logic. But the ethics of you folks and your worship of a racist, woman-assaulting, tax cheating, draft dodging, free-speech-fearing, failed businessman is pitiable and no doubt permanent features – one suspects those kinds of issues arise from deep-rooted personality and upbringing issues, and therefore not amenable to reason.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bb59e0a8353ef50c4fa01fca09e0afc26abe865572c899f7afb646046fee258-58022e796e82df0a245199d944dabdb763afe041c4093e84a6b0d8008cdbe1ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffrey Helkenberg")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474762")[#strong[#text("Jeffrey Helkenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2016")])]

#text("Awww. Thank you for your concern. I merely wanted to illustrate that what is at once acceptable if coming from the left will be instantly derided when it comes from the right and vice versa. NAFTA was a Republican pipe dream until Bill Clinton signed it into law. Romneycare was attacked by the left until they renamed it Obamacare.")

#text("All water under the bridge at this point. We have a new President and by the looks of things Obamacare will be repealed. Of course, I suspect you get insurance through your employer and that it is funded by tying young adults to penury via student loans. I also suspect you know nothing about that (bubble preference) so there is no real chance at bringing you out of your particular cave.")

#text("As for 3 and 5 being prime numbers, that is truly fascinating. You know the number 2 is also a prime. Appears you might not have known that. You can thank me by writing something really snarky about how vastly superior you are to me. I wait with baited breath.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474763")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2016")])]

#text("Awww. It’s “bated”, not “baited”, genius. Let us guess: home-schooled, like Trump nation? Go have someone read to you about “straw men” and ask them nicely to explain-it-like-you’re-5 how your comments about left-vs-right waft in the slightest breeze.")

#text("And speaking of breezes – as predicted, the whoosh above your head as you struggled to understand analogy no doubt frightened you and bystanders. Sorry. Guess you’re not quite ready for “prime” time, eh?")

#text("But snark is really not required, little fella. Your comments here filled with errors in reason and your despicable support for a truly gutless moron, answer the question of “vast superiority” without any help from us. QED.")

#text("I won’t pick on you any more. No doubt someone else will be along to help you more. You obviously need it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-5/#comment-474773")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2016")])]

#text("You might also go look up “tu quoque”, “Jeffrey Helkenberg”, if that is your name.")

#text("Frankly you’re tiresome and kind of nauseating. A better place to make repeated mistakes in logic and argumentation would be Breitbart or Reddit. I’m sure you’ll find people of your ethical and intellectual equal there.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9906081d95a802c591ba0288c5fb28befa9ae076a9af98c48541ef6919fb84e4-301e31d3b6f06115bb7657331a399c735ea9639216abe72702a020669734edb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of O'Rafferty")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469624")[#strong[#text("O'Rafferty")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("At the San Jose Trump rally White Males were violently assaulted by the post-1965 Democratic Party Voting Bloc(Mexican Gang Bangers…ma-13 Salvadoran Male Yoots…and Blacklivesmatter activists(who are organized and given a Divine Edict by the Democratic Party Whitehouse)). I suppose this qualifies Hillary Clinton to be the next POTUS.")

#text("The violence against Trump Native White Male supporters in San Jose last week=Democratic Party Family Values!!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88c898ac6619a23bcd79dcc6c9b28335ec7afa1e440927c73ec182e117de1d0f-474dbd3dc237fb212a70282ce8c872906cbe1549fe772d7d5af9fb1d501509bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kiers")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469625")[#strong[#text("kiers")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("It’s “normal” for this common knowledge vs mutual knowledge conundrum to arise because we are being FED by mass media in a ONE-WAY communication medium. The ability to converse and do feedback (the way humans were SUPPOSED to communicate) would have brought this cognitive dissonance to equilibrium LONG AGO")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81ce9c67ce58e4d24ab61467ac4608b234789a8361a9a64c7ace23d6a7eba46a-e8081476d12611948266e38073f98cc8e8a8ee034953468f648f7198d1b4b402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469628")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("One of the criteria for *fitness* as president is the candidate should not diminish or compromise the power of the presidency.")

#text("This means NOT diminising or compromising the options available (either cooperation or competition) when dealing with 3rd party actors.")

#text("Trump employs a strategy (brinkmanship-esque) that maximizes his chances to win the nomination but by tying his hand (credibility brinkmanship) eventually diminishes the power of the presidency.")

#text("Trump’s position on many issues like religion, race, media, democratic processes, foreign policy reduces the credibiity of the presidency, therefore makes him unfit.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/380df033e13a2b9b4221287220bfb9ebd0824a94f508abf7f38a49d0e1f2c383-87390e19e9bcba1448fc06bfe65bcb78a89e83af1b93778e3dac0803aedd55e0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469632")[#strong[#text("George")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("Candidate ‘fitness’ is relevant. For example it is defined differently for an ivy university professor in comparison to a not educated ‘professional’ pub bud drinker. There is no ‘mutual knowledge’, only ‘mutual ignorance’.")

#text("For the ‘academic person’ and the ‘establishment’ Trump seems “dangerous”. He is not. Trump sells homes, he is a salesman and he is good at it. Now he tries to sell himself as president. He will not change anything, he can’t change anything and he knows that.")

#text("Actually the only ‘mutual knowledge’ that exists is between aware people and Trump. They both know that Trump knows that he can’t do what he says he will do in order to sell himself as a future president.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9906081d95a802c591ba0288c5fb28befa9ae076a9af98c48541ef6919fb84e4-301e31d3b6f06115bb7657331a399c735ea9639216abe72702a020669734edb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of O'Rafferty")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469638")[#strong[#text("O'Rafferty")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2016")])]

#text("George")

#text("There is something to your point. However, the issues that Trump talks about at his rallies are 1)issues that are popular with Native Born White American Voters…and 2)issues that are not going away if either Trump betrays his Native Born White American base and 2) the majority nonwhite Democratic Party Voting Bloc revolts against Trump.")

#text("To be brutally honest:The nonwhite Democratic Party Voting Bloc is delusional if it thinks that Native Born White American are not going to play the hard-core-racial-identity politics game that the Democratic Party Voting Bloc is playing. Native Born White Americans do not need the majority nonwhite Democratic Party Voting Bloc’s permission to this-which of course they won’t give.")

#text("In the context of the Blue Islander puzzle:Humans are a glorified ape species whose brains have been shaped by evolution. Racial Tribalism is hardwired into the Human Brain. At the end of the day, if human evolution is factored into the Blue Eye Islander Puzzle…The Blue Islanders don’t commit suicide..good old gut-level Boolean logic kicks in:you are member of our racial tribe…or you are not a member of our racial tribe.")

#text("White Liberals should have seriously considered this before they fanatically pushed the abstract proposition Nation nonsense-for nobody really every believed in this nonsense in the first place. The Han People of China certainly don’t believe in the abstract proposition Nation nonsense…Neither do the Israelis, even though Bibi Netanyahou demands that the Nations of Western Europe and Scandanavia open their borders to young male Muslim Yoots who are on a mass raping spree of Swedish ,German and English Women. We are talking about future European Mothers who will have been mass gang raped by a Muslim Male Yoot(Italian American slang from the movie “My Cousin Vinny”) invading army. This of course is Hillary Clinton’s immigration policy..which isn’t too much of a stretch for her considering that she is married to violent psychopathic serial rapist.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9906081d95a802c591ba0288c5fb28befa9ae076a9af98c48541ef6919fb84e4-301e31d3b6f06115bb7657331a399c735ea9639216abe72702a020669734edb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of O'Rafferty")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469639")[#strong[#text("O'Rafferty")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2016")])]

#text("I suppose what I am attempting to say is that axiom S5 of epistemic modal logic doesn’t apply to real human brains that have a very long evolutionary history.")

#text("Axiom S5 of epistemic modal logic is just the Abstract Proposition Nation America nonsense in disguise…the ideology of Neoliberal Rape,Pillage an Plunder Economics much beloved by the Harvard trained Economic Advisors of Bill and Hillary Clinton….The ones that caused the genocidal collapse of the Russian population during the Clinton 1 administration. But they are very smart at math I am told.")

#text("I do have a significant criticism of Trump:he is taking advice from the War Criminal Henry Kissinger at the moment.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86a4db85cd7a7c51d28e34169b63020bcd76d9a28b87776b13b0e3e28fb14223-8507e8b27ad1fb638eab586978e5bd1c1e24d01545aaeda1786024b4543ae92a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DP")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469641")[#strong[#text("DP")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2016")])]

#text("This conversation continues here:")

#link("http://www.scottaaronson.com/blog/?p=2777")[#text("http://www.scottaaronson.com/blog/?p=2777")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469643")[#strong[#text("✠ Accountability ✠ (@TransitToPangea)")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2016")]

#text("“Mutual knowledge,” he says. If people from both parties believe someone is unfit to be president, all the others should wise up!")#linebreak()#text(" I fail to notice anything that convinces me that Trump is not the right man for the job. The people that want the same thing for the country as me see Trump as positively as I do.")#linebreak()#text(" ——————————————————————————————————")#linebreak()#text(" “I feel that it is time for the charade to end: Trump is unfit to be president, and everybody knows it. But more people need to say so, openly.”")

#text("His support extends to both parties, and his interpreted competence is similarly. The choice of the word “unfit” is split into three meanings for this.")#linebreak()#text(" 1) His direction for the Country")#linebreak()#text(" 2) His image for the Country (including physical if you wish)")#linebreak()#text(" 3) His competence for the Country")

#text("If you cannot argue – and simply assume we all have the same motives – that Trump is objectionably a negative towards all suspected motivations for supporting him, you will get no objectionably negative.")#linebreak()#text(" ——————————————————————————————————")#linebreak()#text(" “But more people need to say so, openly.”")

#text("And there is your reason for writing the article. You came to the justification that because you feel like there is no more proof necessary to claim he is an unfit presidential nominee, it should be apparent to everyone. There is nothing wrong with this, if there is no further evidence necessary to show the people that what he stands for why he is not capable.")

#text("——————————————————————————————————")#linebreak()#text(" If you would like to actually lessen Trump’s acceptance, argue why Trump is unfit to be the president of the Alt-Right, who is at least towards the direction of all of his truest supporters.")

#text("Use this to get started. The references may be more useful.")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Alt-right")[#text("https://en.wikipedia.org/wiki/Alt-right")]

#text("Though, I assume you don’t value clarity as much as you think you do, making this article as it is, so I predict that no reply will come.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09bf1bba6531c9907483e3d75e5503909d7caef449a380c75f22e6250e429f36-c6463f37e9239274b5d444497b585b90285989e04507a0abd7e30cc7e63a2484.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Cory")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469646")[#strong[#text("Matthew Cory")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2016")])]

#text("I know I let you in on the secrets about Trump in a prior video post but to your general point, mutual knowledge isn’t always true knowledge. Qualifications are elusive. For instance, higher education has no general empirical support just considering the history of invention. Here is are the facts:")

#text("“The Obama administration recently created a valuable online database called College Scorecard to offer a more realistic picture of income prospects with a college degree. One of the indicators in this database shows that more than half of graduates at hundreds of colleges are earning less than the average income of someone holding a high school degree ($25,000 a year) ten years after enrollment. Ideally, this ratio should be zero.”")

#text("It turns out that the causation is backwards:")

#text("“Cross national data show no association between the increases in human capital attributable to rising educational attainment of the labor force and the rate of growth of output per worker. This implies the association of educational capital growth with conventional measures of TFP is large, strongly statistically significant, and negative. ” – Lant Pritchett (World Bank & Kennedy School of Government)")

#text("“[N]either the increase nor the initial level of higher education is found to have a statistically significant relationship with growth rates both in the OECD and worldwide. This result is robust to numerous different specifications.” – Craig Holmes (Oxford University)")

#text("Who says people are even good at judging complex qualifications?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1a1abe34e3dca71336ae2cc49434e0eddbe5abf1ff902cd0e51279947efb4d9-f90f08de4e1116cb871ac86f7ca27ed6687e3ac7c32168d0b25646ca976df77d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sid Roast")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469647")[#strong[#text("Sid Roast")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2016")])]

#text("The old axiom is true…")

#text("Those who can, do.")#linebreak()#text(" Those who cannot, teach.")#linebreak()#text(" Those who cannot teach, teach college!")

#text("Ah, why would the world listen to a man so afraid that his theories might not be true that he shrouds himself in academia, knowing that what he preaches, will likely not work in practice…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469817")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2016")])]

#link("https://en.wikipedia.org/wiki/Dunning%E2%80%93Kruger_effect")[#text("https://en.wikipedia.org/wiki/Dunning%E2%80%93Kruger_effect")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/668efaae78faaa9da405a2d228e367dd06a39707f24799f1f990c4276beb4e1a-5bf8ed2099887372225ed0e6510fb81e5cc6fec4730706968e7e9d0cbec2bba8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469649")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2016")])]

#text("I realize this is your blog and you can delete whatever you want, but for you to set the ground rules for what type of arguments can be made against your position is loading the dice against a fair debate.")

#text("There have been past Presidents who had very limited political experience who nevertheless turned out OK. Eisenhower apparently had never voted before he became President. Our current President had a brief and uneventful career as a Senator and before that he was a law professor. I don’t recall that you or many others argued that he was unqualified at the time.")

#text("Trump was a very successful businessman who has conducted business all over the world (and not just the Miss Universe pageant). In a world where politicians rarely say what they really have on their mind (in other words, they lie most of the time) he is a refreshing breath of fresh air, which is why he has appealed to millions of voters.")

#text("He may not be your cup of tea, but Constitutionally, he is a natural born American citizen over the age of 35, so therefore he IS qualified. There are no official qualifications for President other than those.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e89a5a2a0726b6197e7512c89c571e62c5859873fd1c4d251c62bcd4de3758a-72bc1e53d8937ac28505dbee127f7b4cb91efcaab4d38f5930baf37206253bcc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Gogins")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469732")[#strong[#text("Michael Gogins")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2016")])]

#text("Like so many commenters here, you are equivocating on the meaning of the word “qualified” and thus you have actually failed even to address Terry Tao’s proposition. Tao never denies that Trump is legally qualified. But Trump is not at all qualified to effectively perform the duties of the President without harming our standing in the world, our military power, our economy, our race relations, and our Constitution.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9e17fa1c73fe2904b825b1ea01fcd4b31d98c7749fecf0efcbaaac15df3bd59-2fad5ee654ce334b8fdc65fd688d5d493e487a8adce12bfab889fc913abb1cb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mickey Nose")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469651")[#strong[#text("Mickey Nose")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2016")])]

#text("To give to any opinion the status of a mathematical proposition is not only silly ; it betrays a fundamental misconception of what democracy is about.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9906081d95a802c591ba0288c5fb28befa9ae076a9af98c48541ef6919fb84e4-301e31d3b6f06115bb7657331a399c735ea9639216abe72702a020669734edb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of O'Rafferty")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469663")[#strong[#text("O'Rafferty")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2016")])]

#text("That’s true, and it was my initial reaction to Professor Tao’s comments. But his comments do touch upon something very deep and very relevant….COMMON KNOWLEGE. Quite possibly Professor Tao’s comments were a gut-level unconscious-semiconscious reflex to what is obviously a historically very significant US election.")

#text("The Common Knowledge that professor Tao writes about in his post in a quasi-analytic way is in reality the Democratic Party Voting Bloc-Mega-CEO agreement about what is permissible public thought and speech for The Historic Native Born White American Majority. This is just another way of saying that The Historic Native Born White American Majority has been giving a divine edict to keep quite and accept the post-1965 political consensus passively…which is:full-speed ahead with the open and deliberate policy of radically transforming the racial transformation of America by importing highly racialized nonwhite legal immigrants who are the hardcore majority of the Democratic Party Voting Bloc, who would never never tolerate the exact same race-replacement legal immigration policy for China,India,Israel,Mexico, the Dominican Republic..and South Korea. And they do it in a very Boolean logic kind of way:our racial kind your in…not our racial kind you don’t get in. Its very binary. Hey what the heck, isn’t all modal logic ultimately reducible to idempotency anyway?")

#text("The Democratic Party Voting Bloc sees Trump as a very serious threat because Trump…whether it is his intent or not….is activating long dormant-hibernating Native Born White American Racial Identity Politics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Franky_GTH")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470834")[#strong[#text("Franky_GTH")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2016")])]

#text("Seems like a misunderstanding, it is a proposition given the $form$ a mathematical statement (one which is in analogy called as well proposition), which appears when looking at the readership appropiate (anyway its just the form). Another question is the content, one might agree or disagree with that. discussing this, rather then discrediting it is at the very heart of democraty.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9906081d95a802c591ba0288c5fb28befa9ae076a9af98c48541ef6919fb84e4-301e31d3b6f06115bb7657331a399c735ea9639216abe72702a020669734edb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of O'Rafferty")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469666")[#strong[#text("O'Rafferty")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2016")])]

#text("Shockingly, among the reasons Scott Aaronson will be voting for Hillary Clinton is that Donald Trump lacks the intestinal fortitude to threaten Conservative Orthodox Christian Vladimir Putin and the Conservative Orthodox Christian Russian People with thermonuclear extermination.")

#text("Scott Aaronson..a Quantum Complexity Theorist that only Jeffrey Sachs and Andrie Schlieffer could love!!!!")

#text("I always thought that spreading the Gospel of the Entangled Quibit Realm would usher in the era of Really Groovy Hippie Yippie …I’ll be gender neutral about this…Universal Human Luv!!!!!!!!!….You know like eating brown rice was suppose to do in the 1960’s.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JB")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469686")[#strong[#text("JB")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2016")])]

#text("As your post is clearly intended to persuade people against voting for Trump, and in favor of some other candidate or not at all, ““tu quoque” is not relevant here. In my opinion, both of the main candidates are unfit, but Hillary is more unfit than Trump. You would no doubt disagree, but that is because we have different preferences and hence judge the candidates along different axes. Rather than Trump’s unfitness, you are seeking to establish Hillary’s greater fitness as common knowledge. But that is not even mutual knowledge, let alone common.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9906081d95a802c591ba0288c5fb28befa9ae076a9af98c48541ef6919fb84e4-301e31d3b6f06115bb7657331a399c735ea9639216abe72702a020669734edb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of O'Rafferty")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469690")[#strong[#text("O'Rafferty")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2016")])]

#text("JB")

#text("I think I agree with you. The US is with very high probability ungovernable.")

#text("I am not an expert on this stuff…but I wonder if the Blue Eyed Islander Puzzle has something to with economic social welfare theorems.")

#text("The Blue Eyed Islander Puzzle possibly-might have something to do with the concept of the social contract in a society where the consent to governed is withdrawn by 1)all demographic groups…or 2)one large demographic group.")

#text("I think I should start reading up on Tom Schilling.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469694")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2016")])]

#text("Dear Mr Tao,")#linebreak()#text(" All the world (only me) understands you.You are very careful in problem such politics .Once you post, you are sure you are right and win 100%.That is a core all the word not uunderstand you.You are more than others great scientists that you are not very smart ,but also very sensitive with the sixth sense,I know that you are not genius in math,but also in politics,astronomy(you are very good at universe),physics,with the sixth and seventh sense you solve all Clay millennium problem,beside if someone claims he solves the best problem,you immediately know he is wrong or right,you are never pioneer,you always go behind(you are humble,you are waiting aan opportunity ,you turn back 360% with the opponent,this makes him fail down from high mountain with wrong proofs")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Darius Mangual")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469695")[#strong[#text("John Darius Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2016")])]

#text("Here we get a glimpse into Donald Trump’s rhetorical strategy (one of them).")

#text("Bullshit is a statement whose truth cannot be checked — call it “immeasurable” or “borderline”.")

#text("Someone on his team, found a statement about Senator Warren — which may be false… let’s all this truth value “Maybe False”. Trump, then uses such Maybe False statements in order to give a “Maybe” Proof that he would make a good President.")

#link("https://www.washingtonpost.com/politics/trumps-pocahontas-attack-leaves-fellow-republicans-squirming-again/2016/06/10")[#text("https://www.washingtonpost.com/politics/trumps-pocahontas-attack-leaves-fellow-republicans-squirming-again/2016/06/10")]

#text("Good Day.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9906081d95a802c591ba0288c5fb28befa9ae076a9af98c48541ef6919fb84e4-301e31d3b6f06115bb7657331a399c735ea9639216abe72702a020669734edb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of O'Rafferty")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469719")[#strong[#text("O'Rafferty")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2016")])]

#text("Donald Trump was stating the very obvious…in the Kolmogorov 0-1 law sense…that Elizabeth Warren is a fake…as in a fake Poccohantus with probability 1 of this being true.")

#text("The Washington Post is owned by Jeff Bezzos who created a torture chamber wage slave work environment for Amazon Workers. Jeff Bezzos sees himself as a demi-god billionaire with life and death power…as does greedy parasite Mark Zuckerberg….over millions of Native Born White American Workers. It is psychopathy write large!!!!!-that’s for sure.")

#text("Elizabeth Warren is basically acting as a corporate lawyer working on behalf of the White Liberal Greedy Cheating Class Mega-CEO. We are all in the REALM OF THE MEGA-CEO PSYCHOPATH….")

#text("The post-WW2 Social Contract has been flushed down the toilet bowl by the likes of Jeff Bezzos…Mark Zuckerberg…Steve Balmer….Bill Gates….every Silicon Valley demi-god billionaire.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469696")[#strong[#text("Censorship of Australian Science | Exploring The Unexplored")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2016")]

#text("[…] brought enough concern that Terence Tao, one of the greatest living mathematicians, has devoted a blog post solely to make the point that it is about time that people publicly stand up against Trump. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469697")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2016")])]

#text("Terry put a link on to this on his sidebar:")#linebreak()#text(" ")#link("http://chem.tufts.edu/AnswersInScience/RelativityofWrong.htm")[#text("http://chem.tufts.edu/AnswersInScience/RelativityofWrong.htm")]

#text("from 1989 by Isaac Asimov. This got me to wishing Terry would write another piece about Trump and his followers using this as a jumping off point.")

#text("The Relativity of Wrong")

#text("Asimov begins:")

#text("I RECEIVED a letter the other day. It was handwritten in crabbed penmanship so that it was very difficult to read. Nevertheless, I tried to make it out just in case it might prove to be important. In the first sentence, the writer told me he was majoring in English literature, but felt he needed to teach me science. (I sighed a bit, for I knew very few English Lit majors who are equipped to teach me science, but I am very aware of the vast state of my ignorance and I am prepared to learn as much as I can from anyone, so I read on.)")

#text("It seemed that in one of my innumerable essays, I had expressed a certain gladness at living in a century in which we finally got the basis of the universe straight.")

#text("I didn’t go into detail in the matter, but what I meant was that we now know the basic rules governing the universe, together with the gravitational interrelationships of its gross components, as shown in the theory of relativity worked out between 1905 and 1916. We also know the basic rules governing the subatomic particles and their interrelationships, since these are very neatly described by the quantum theory worked out between 1900 and 1930. What’s more, we have found that the galaxies and clusters of galaxies are the basic units of the physical universe, as discovered between 1920 and 1930.")

#text("[[[[ I’d skim through the middle part where he explains why the arguments that the earth is flat and that the earth is a perfect sphere have been proven wrong. We all know that. Instead read the first nine paragraphs ending with “let’s take an example.”]]]")

#text("Then consider the last four paragraphs:")

#text("Since the refinements in theory grow smaller and smaller, even quite ancient theories must have been sufficiently right to allow advances to be made; advances that were not wiped out by subsequent refinements.")

#text("The Greeks introduced the notion of latitude and longitude, for instance, and made reasonable maps of the Mediterranean basin even without taking sphericity into account, and we still use latitude and longitude today.")

#text("The Sumerians were probably the first to establish the principle that planetary movements in the sky exhibit regularity and can be predicted, and they proceeded to work out ways of doing so even though they assumed the earth to be the center of the universe. Their measurements have been enormously refined but the principle remains.")

#text("Naturally, the theories we now have might be considered wrong in the simplistic sense of my English Lit correspondent, but in a much truer and subtler sense, they need only be considered incomplete.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f861ae317410d9b67b9c8aa198e0169f19ce22b1824bb5d8833c64ba3d760fc-27591c1ed4e6d070bb4511bd2664acbe1e4a5ead848d49465677dab8ea154c1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469706")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2016")])]

#text("Dear Prof. Tao,")

#text("I know that you are probably shy of media and don’t want to get into trouble there. But given what is at stake, I recommend considering the following.")

#text("The media seems to have had no trouble in the past identifying you as the greatest or one of the greatest living mathematicians. If you were to, say, contact the campaign of a major presidential contestant in order to have arranged to publicly (that is, rallies, interviews, …) throw your weight behind that candidate, you would perhaps not only be able to promote the cause of that candidate, but also to form a relationship to that candidate that may allow for a healthy influence on important issues like climate change, the economy and so on, where your mind surely more than dwarfs the political think tanks informing US politicians (even, which I doubt, if not in terms intelligence, then certainly in terms of neutrality), not to mention a public stage given to you to advocate for certain issues. Consider your possibilities, I’m pretty sure you can do it faster than I do (I work hard with good methods, but unfortunately, there are physical speed limits to my brain, at least given a method!). (Fritz Zwicky had a nice method called the ‘morphological approach’, look for the 1969 book ")#link("https://en.wikipedia.org/wiki/Fritz_Zwicky#Publications")[#text("https://en.wikipedia.org/wiki/Fritz_Zwicky#Publications")]#text(")")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wade")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469721")[#strong[#text("Wade")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2016")])]

#text("I presume that most Americans feel that Hilary Clinton is “more of the same”, i.e. her presidency would largely be similar to that of Obama or her husband’s. Similarly, Marco Rubio, Mitt Romney, Rick Santorum and many others, would have acted similarly to GHWB and GWB as presidents.")

#text("One must understand that there is a large group of Americans who’ve been extremely disappointed with *all* the presidents of the last 20-30 years. They are not interested in “more of the same”, whether it is the Democrat “same” or the Republican “same”. Both “same”s have failed them miserably time and again, at least from a socioeconomic perspective.")

#text("What are Trump’s qualifications? He isn’t more of the same. And for plently of people, that’s enough. Here’s a snippet from a January 2016 survey by RAND:")#linebreak()#text(" ")#link("http://wwwassets.rand.org/content/rand/blog/2016/01/rand-kicks-off-2016-presidential-election-panel-survey/_jcr_content/par/blogpost/par-blog/imagewithclass_878964663.aspectfit.0x0.png/x1453910257067.png.pagespeed.ic.1MjP2C4N6m.png")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/wwwassets.rand.org/content/rand/blog/2016/01/rand-kicks-off-2016-presidential-election-panel-survey/_jcr_content/par/blogpost/par-blog/imagewithclass_878964663.aspectfit.0x0.png/x1453910257067.png.pagespeed.ic.1MjP2C4N6m.png")[Original image]]]]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/760ddd8bad27c570c5995a8ca954c5a38fd4fac69f38771b25a6b6db36d6b11e-4ad57592ce78782880a2c818635ada04dd6ba4cba69ace173598d068d4466749.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Livre")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469768")[#strong[#text("Livre")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2016")])]

#text("better dodge a dice than contemplate an alien.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d48927b38aeb68657e0aae499ce77078d84d3ae58b51e9be619cdeaa7206450-64f69974669e32c8e6e1ea32e25d7f7f4103a76b9e97ad2d651683515c7fdacc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469769")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2016")])]

#text("Interesting.")

#text("Propositions from me:")

#text("0: There are no perfect person, but a leader need to be correct on big major issues.")

#text("1: Real world problems about people are always complex but not complicated. The complex part is that not all information are provided like Math problems and there’re fake information.")

#text("2: If you don’t have enough good information, you can’t possibly know what are big issues and what kind of solution is practical.")

#text("3. You know little about the following topics(i.e. you don’t have enough information):")#linebreak()#text(" + Islam")#linebreak()#text(" + Terror attacks")#linebreak()#text(" + ISIS, how it is born, how it is related with US foreign policy")#linebreak()#text(" + History of conflicts and killings caused by radical religion in big countries (like China, European countries)")

#text("4. As a result of 0-3, your proposition have little meaning.")

#text("PS:")#linebreak()#text(" + If you just google a topic and hit the first link, you’re very likely to be manipulated (you have to experience and know enough to identify false information).")#linebreak()#text(" + I think it is totally reasonable if you don’t want to waste your SUPER brain power on such things.")

#text("I wish you become more and more successful on math and science.")

#text("Two video for you if you prefer Hillary:")

#text("+ ")#link("https://www.youtube.com/watch?v=-dY77j6uBHI")[#text("https://www.youtube.com/watch?v=-dY77j6uBHI")]#linebreak()#text(" + ")#link("https://www.youtube.com/watch?v=ZRlOm4IUuJk")[#text("https://www.youtube.com/watch?v=ZRlOm4IUuJk")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5d00e492125e18aa6b65c15c8c12dfb4729c29ddc8749456b714451565a454b-f845eff15a859bc13ca990ead2ed2d4bd70d90dc0dd287d46a056283d1a51bfa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bernat")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469783")[#strong[#text("Bernat")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2016")])]

#text("I believe there is an axiom that your proposition is using, and I believe that axiom does not hold in our current state of democracy:")#linebreak()#text(" Axiom 1.")#linebreak()#text(" The candidate who gets more votes is the most qualified to be President of the USA.")

#text("Now, the following proposition IS true, at least in the Republican primaries:")#linebreak()#text(" Proposition 1.bis")#linebreak()#text(" Donald Trump is the candidate able to gather the most votes.")

#text("I believe that, similar to the systems of quantifying intelligence (exams and scores), the rules of Democracy were created with the intent of “if you are fit for being President, you will get more votes”. But that was because the objective function at the time was “be a good President for your people”. That objective function has changed, inevitably, to “get the most votes”. (I say it’s similar to exams and grades because the rules have changed from “learn as much as you can and you will get good grades” to “do what you can to get good grades”). It is human nature, in my opinion, and in any case, Trump’s nomination as the Republican Candidate makes the negation of Axiom 1. common knowledge.")

#text("I’d be happy to discuss about this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60056590f059b00f9f42c9c1bf34ed4f8771eb624e77df9de9e6dd6d0aa6011b-78850c89d7b74cd5cd27061ecf21a6ed5f57b3513f40a85c231cc68842fb4cf6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robin Saunders")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469792")[#strong[#text("Robin Saunders")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2016")])]

#text("On the subject of electoral reform, I’d be interested to hear your perspective on the various alternative voting systems, and the pros and cons of the different criteria by which they can be compared.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe70e96702a9785b49ea729308839baaef81e5eb162e639e7b66b2d1b04d4d9f-7a2512c5144d14139567c5769f9f4e5a94e46234d2f2d35e4d74080e8adcf37e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FedUpPleb")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469803")[#strong[#text("FedUpPleb")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2016")])]

#text("I don’t think mathematicians should get involved in politics, much less US politics (excepting regrettably perhaps now, the matter of the NSA, which we will soon be unable to avoid)")

#text("I read enough history about Americans not to be all that concerned about a Trump presidency, and as far as I can see he is simply the US electorates blowout after being squeezed dry by neo-liberalism. I say let them have their blowout now, or risk them picking someone even worse later.")

#text("In any case, I don’t think mathematicians should involve themselves at all in these matters. It only undermines the authority of the profession in its own field. Maths should be above politics and trying to construct propositions about boorish property tycoons in a country which elected Ronald Regan and Roosevelt I is just dragging ourselves down into the mud to wrestle with the pig — and the pig likes it!")

#text("Save your ammo for the coming NSA fallout. If there’s any proposition to be made, it’s that the fallout from that scandal on the mathematical community is truly inevitable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469819")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2016")])]

#text("I doubt Terry is even following these posts… but if he is I am sure he is ignoring those who say that by dint of his having study mathematics he shouldn’t apply a logical paradigm to understanding why so many people are in thrall to the small digit legerdemain of wannabe president Donald Trump.")#linebreak()#text(" “Watch my stubby fingers, back and forth, back and forth, I am wearing the finest best clothes of anyone ever, and if you don’t see it you’re just plain stupid…. “")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/110db9d23ad1a3d599c3ef6eab4174aa25b734b33d14543b529bf3eb495f7999-012854237fa3cf40043069157af9296311fdfe60a0a339b1e41a7bb5df6079b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doc Holiday")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469806")[#strong[#text("Doc Holiday")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2016")])]

#text("Trump is qualified by being democratically nominated. Your post goes against the principle of universal suffrage.")

#text("Neither you, nor Hillary, are above the people who voted for Trump. Neither you, nor Hillary, are qualified to judge who is “fit” to be a president, or what “ought to be common knowledge”. That is how modern democracy works.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bbd7712af5f6766676b748273a9c3eedba918473dc1ccbd08865c02d5bf4dae5-806c4decf98a2fb574ddedea811c9a78d8e053beec3311c4a1ac8bfaa4449c43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carte")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469807")[#strong[#text("Carte")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2016")])]

#text("It’s astonishing how you completely fail to spot the logical contradiction in your gibberish. It’s not even worth pointing out, it should be clear for anyone not mentally challenged.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469839")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2016")])]

#text("This is not a logical argument at all and should be deleted.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16514b6868ba7d94f1f775dd5ea3e7545286114ba9e1529fe6086c440054d8b2-49971cc57cbbebc2419e9fa665afa2b7ba316162959127bb23bf63cdef9c5b93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of -iPI/lnp")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469822")[#strong[#text("-iPI/lnp")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2016")])]

#text("It’s not about being fit ,But destroying politics and politicians FORVER and TRUMP has noticed the cry !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c11fc4442f97dd27c04d8b401e81c5341d05c0f2a1fda199083b65cfbb176016-550224c451cecf4b887d7008b806a3a0e5d6f95056aae8aba3bb3baab0310159.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Herikko")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469852")[#strong[#text("Herikko")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2016")])]

#text("Hi Terry.")#linebreak()#text(" Your entire argument amounts to an appeal to authority fallacy, and a very poorly constructed one at that!")

#text("Come on, you’re better than this!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13c85a26fbc4af8042406d3fb74ea8cb9dd6905024f1a27841516c901dd32a05-d3ad44edcb32e84a1d0106eb8bc15598b6d33d688afff86e88cb13a8088ed4ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John from London")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469870")[#strong[#text("John from London")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2016")])]

#text("I saw this post mentioned in a sidebar while browsing moyhu’s blog but I misread the title. I thought that it said “It ought to be common knowledge that Donald Trump is not fit for the *Predator* of the United States of America”, and I had to disagree … until I read it again. ;o)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/355b7a34448edbc25b48c6d93b464cd99e886a2407b7e06cd1fb9642ac65745c-3ccd155508f869e71c11a6f0709f11b64ce8085bd15789fb8d2a564aeb052e35.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of easy")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469885")[#strong[#text("easy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2016")])]

#text("Professor:")#linebreak()#text(" Read this article and decide yourselves.")#linebreak()#text(" ")#link("https://www.linkedin.com/pulse/20130212153628-8451-are-the-democrats-holding-skilled-immigrant-workers-hostage-to-the-plight-of-the-undocumented")[#text("https://www.linkedin.com/pulse/20130212153628-8451-are-the-democrats-holding-skilled-immigrant-workers-hostage-to-the-plight-of-the-undocumented")]

#text("Please try to spend time and understand the dynamics of the country. What the democrats are seeking is immoral. In 2012 they tried to pass an unfair reform. The illegals just need to pay taxes for 10 years and they become citizens (and 15 million of them are just from one country) while the legals still need to find a sponsor and slave work and convince their employers to sponsor them (it will still take 15 years to get legally 15 million of them and 100 years to from a single contry). I do not like the right wingers either but center right or center left is much more better than far left and far right.")

#text("Though I would prefer a democrat to come I strongly believe democrats are literally changing the racial dynamics of the country. Both parties are racists but decide yourselves who is most dangerous in the long run and I hope you will take this as input and post a wiser post again.")

#text("Your post and scott aaronson’s post do not address immigration dynamics which is the primary reason Trump has a chance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/355b7a34448edbc25b48c6d93b464cd99e886a2407b7e06cd1fb9642ac65745c-3ccd155508f869e71c11a6f0709f11b64ce8085bd15789fb8d2a564aeb052e35.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of easy")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470004")[#strong[#text("easy")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2016")])]

#text("Supreme court blocked the executive order. The EO did nothing to legals who spend a fortune to get educated and follow rules and cannot get any permit for a job without company sponsoring them for several 1000 dollars. The illegals get the goodies for free with no catch attached. If they get laid off they can drink and smoke for several months and find another job at next walmart. This is what the EO literally does. It is almost as good as a Green card which takes a life time of suffering for a legal to get.")

#text("Please decide who is the real demagogue and placates to the mind of the people and for where the country should be.")

#text("It is clear if the conservative judge had not passed away the executive order would have been in peril. It is ‘time’ which is what is saving the status quo.")

#text("I do not like Donald Trump and I would agree pretty much everything the democrats say but it will only be the 4 or 5 states which will pretty much decide the election and there is a 50+% chance these will go to Trump.")

#text("Being a legal immigrant I am afraid of Trump but the alternative is immoral. Please get down from your glass house.")

#text("If the illegals from one country are not swamping the system here there will be a provision for many other poor countries to benefit since like Australia or other developed countries there could be a technically legal way for poor people from other countries to benefit.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/355b7a34448edbc25b48c6d93b464cd99e886a2407b7e06cd1fb9642ac65745c-3ccd155508f869e71c11a6f0709f11b64ce8085bd15789fb8d2a564aeb052e35.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of easy")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470005")[#strong[#text("easy")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2016")])]

#text("‘and not for where the country should be’.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/de8fd6f3ac0d6a7b73d8e0f525112b38fbc4bf12913cdd514dce12ba778f5bcd-11fe82f9bc53951041905ed855c88686ef05e0eff224cf46603823330e0fe1d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of random reader")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469887")[#strong[#text("random reader")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2016")])]

#text("In the “emperor’s new clothes” story there is no failure of common knowledge because everyone observes the same information (assuming that they all see the emperor and each other). Technically, for any finite and sequence of people who can see each other and the emperor, A knows that B knows that C knows that … Z knows the emperor is unclothed, which is the definition of common knowledge. The equivalent of a public announcement is in the words “they all see the emperor and each other”.")

#text("The reason that the conclusion takes so long to reach in both the Emperor’s Clothes story and the Blue-Eyed Islander puzzle, is that there is a severe disincentive for anyone to say publicly what he can observe.")

#text("In Trump’s case there has never been any disincentive to criticizing him, and it seems that the opposite is true; there is (unless he gets elected) a significant cost to public figures who openly endorse Trump.")

#text("So the arguments about common knowledge are beside the point here.")#linebreak()#text(" This blog post is actually arguing the more conventional and non-mathematical point that this is a time for anti-Trump opinion to coalesce by making the anti-Trump arguments more forcefully.")

#text("Finally, the survey that Jacques Distler linked gives evidence that Trump’s supporter is robust and issue-driven, and if that is what it comes from, it is not likely to be affected much by a strategy of preaching more vocally to the choir. Instead one would have to point out something horribly wrong with Trump (compared to, for example, president Reagan or governor Schwarzenegger) or amazingly good about Clinton or Sanders so as to reduce his level of support.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/de8fd6f3ac0d6a7b73d8e0f525112b38fbc4bf12913cdd514dce12ba778f5bcd-11fe82f9bc53951041905ed855c88686ef05e0eff224cf46603823330e0fe1d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of random reader")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469888")[#strong[#text("random reader")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2016")])]

#text("(oh. The Distler link I had in mind was actually at Aaronson’s blogpost that continued the discussion initiated here. Here’s the source: ")#link("http://www.scottaaronson.com/blog/?p=2777#comment-1147971")[#text("http://www.scottaaronson.com/blog/?p=2777#comment-1147971")]#text(" )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469890")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2016")])]

#text("Here’s what happened when I wrote three essays about Trumps fitness to be president on Daily Kos, on of the largest liberal websites, from the POV of a psychotherapist – ")#link("http://www.dailykos.com/story/2016/06/17/1539678/-Ethics-Shrinks-and-Trump-Should-they-speak-out")[#text("http://www.dailykos.com/story/2016/06/17/1539678/-Ethics-Shrinks-and-Trump-Should-they-speak-out")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469897")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2016")])]

#text("Just adding this…. another example of how pundits are constrained to say that the emperor is naked is how none of them dare to say that the kinds of people that flock to Trump rallies are, by and large, white trash. I wrote about this here… I wonder what kind of comments I get where I posted it on the high readership Daily Kos: ")#link("http://www.dailykos.com/stories/2016/6/19/1540366/-White-Trash-for-Trump-An-analysis")[#text("http://www.dailykos.com/stories/2016/6/19/1540366/-White-Trash-for-Trump-An-analysis")]

#text("As I start reading my usual political websites and have an ear tuned to the news on MSNBC I don’t know what, if anything, I’m going to write later this morning. One thing caught my attention on Politico, Hillary Clinton’s path to victory, so of course I click on that cautioning my self before I do not to get too overconfident. Trump has only one path to victory:")

#text("… ginning up disaffected, non-college educated, working-class white voters — many whom may never have voted before — to sweep across the Rust Belt, in places like Wisconsin, Pennsylvania, Michigan and Ohio.")#linebreak()#text(" I’m not particularly proud of my reaction to this because it seems elitist, snobbish, and in current parlance certainly not politically correct. If it was merely disaffected voters he needed to win, you could say the same thing about Bernie Sanders. Much of his support has been among disaffected voters, the younger of those who may have never voted. However many if not most of them are either in college or college graduates. No matter that they may make the same or even less than those considered working class, when you consider other commonalities rather than economic class they are among those who might – non-PC alert – be called the critical thinking class.")

#text("If income is taken out of the equation, can we call the majority of Trump supporters poorly educated and working at blue collar jobs. Those that I’ve seen interviewed who were in college seemed to be, dare I say, gullible. The term that came to mind for may Trump supporters was “white trash.” I decided to talk a little walk on the Google side and found looking up”white trash” that there was so much written on a subject I’d have to spent several days wading though the relevant material of write a front page worth Daily Kos essay.")

#text("I thought I’d skim though some of the articles just to get a general idea what academic experts had to say.")

#text("In 2013 sociologist Matt Wray published “White Trash: The Social Origins of a Stigmatize”. He writes about the “deep historical entanglements with the politics of sex, race, and class.” But he reminds us that awhile back the term white trash was synonymous with poor white trash, often synonymous with “trailer park trash.”")

#text("I think the crowds that came out to hear Sarah Palin speak showed us that you didn’t have to be poor or live in a trailer park to be susceptible to demagoguery.")

#text("In 2014 an Urban Dictionary contributor named Mike offered up a pretty good definition of the kind of white trash whose mindset Trump is tapping into: Urban Dictionary:")

#text("A term used broadly and often inaccurately to define a person or group of persons whom embody the concepts of ignorance, racism, violence, alcoholism, and anglo-saxon ancestry. It is often used as a label on the poor caucasian working class. Many people are labelled “white trash” because of the clothes they wear and their appearance, regardless of wealth and standing. Many that use this term do not understand the lifestyles of those whom they deride and oftentimes neglect to see that many people in the poor white working class are actually very intelligent tolerant people who tend to like professional wrestling, cheap beer and NASCAR. Many others were born with mental or physical disabilities and are forced into the stereotypical “white trash” lifestyle by the opressive society of the united states which tends to ignore its lowest classes. If correctly applied, the term refers to people such as the military personnel who had a wonderful time playing fraternity pranks on the prisoners of Abu Ghraib prison, the corporate scum who build their big box department stores right across the road from mom and pop stores which are then forced out of business for the greater good of a couple of obscenely rich assholes at the top, idiots who write “dotheads are dirty” on the walls of gas station restrooms that are not even run by east Indians but people of middle-eastern descent yet they are too full of themselves to notice a difference, and especially Texan wannabe cowboys who carelessly overrun foreign countries without noticing the thousands of innocent lives that are constantly being ended and then having the nerve to say “GOD IS ON OUR SIDE!")#linebreak()#text(" As I embarked on my second cup of coffee and reread this definition it hit me that these are the sort of people who are fans of Howard Stern. I expect Stern would proudly say he appeals to white trash. This being said, I think it is telling that Donald Trump has been on the Howard Stern show some two dozen times (according to Huffington Post) where he once said “Do you like girls that are five-foot-one? They call it — they come up to you-know-where.”")

#text("In 2013, The New York Post, not known for scholarly articles, had a good opinion piece “When did white trash become normal?”")

#text("When Snooki, whose talents include getting sloppy drunk and throwing up on camera, made Barbara Walters’ “Ten Most Fascinating People” list a few years back, one could only ask: Was Octomom not available?")

#text("Last year, “Here Comes Honey Boo Boo,” which features a cornucopia of social ills, was TLC’s highest-rated show, attracting more cable viewers than the Republican National Convention, which had the misfortune to share the time slot with the charmers from Georgia. The show’s matriarch, June Shannon, has four daughters by four men, one of whose names she can’t recall.")

#text("White Trash is the new normal — and you don’t have to tune in to reality TV to rub elbows with pathologies that once stayed put in Skunk Hollow. White Trash Normal has invaded every nook and cranny of life, from table manners, to dress, to money management.")

#text("As unnerving as it is to say, Donald Trump appeals to “the new normal.” Scary.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f5e7ad0a1fdcb3b13c0b93664ab90d177ce17fb26cf3d56eacd57e5a68306e1-32f192b590b7feb6219289fd43f8f71dfb4a7053aa3985aa128b84463531a463.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dude")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469955")[#strong[#text("Dude")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2016")])]

#text("You really need to cut it. Almost every one of your posts is either annoying, condescending garbage or whining about how you’re getting tons of downvotes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ca1f66148acbda6beb4c04f89c2094f8f1d2f2fda37ae736d9a01f8900e619b-86e56d18414d3f6cbafd9df3c84b2fd120022c59ae5b5e1999f4997c94bf6ee0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Holden McGroin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470049")[#strong[#text("Holden McGroin")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2016")])]

#text("I just wanted to let you know that I gave you a thumbs-down.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-469911")[#strong[#text("Is it common knowledge that anyone is fit to be US President? | Mathematics without Apologies, by Michael Harris")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2016")]

#text("[…] difference between mutual knowledge and common knowledge, in a blog post with the normative title It ought to be common knowledge that Donald Trump is not fit for the presidency of the United States…. It’s common knowledge that Terry Tao, in addition to being one of the Mozarts of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a5f266aab00ff64849cbb8aaca87c5320d167a1f929215c472ade5203f82bb89-92198f97adb073b2863eb05a517b62fcd0134e0b5699a84f4e71f78fc1b6d247.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470006")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2016")])]

#text("I have another good example.")#linebreak()#text(" This quote comes from the Washington Post.")#linebreak()#text(" ‘Despite his hopes for an economic relationship with Libya, Trump apparently felt no qualms about a military strike on Gaddafi. In 2011, he was recorded saying that the West should “knock this guy out very quickly, very surgically, very effectively, and save the lives,” ‘")#linebreak()#text(" also from the same item (background info),")#linebreak()#text(" ‘Gaddafi renounced his support for terrorist groups and publicly gave up his quest for nuclear weapons.’")#linebreak()#text(" The US was unable to get a nuclear deal with Iran as a result. No one will give up their nuclear weapons programs as requested by US after seeing how the US betrayed Gaddafi. He was physically ripped apart in the streets by US supported rebels.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3dc8d508354bdbe661dee076ea49ca3a46e3025631bb0d5ae1deece3bd491301-f066f43d0a59d4424c5a2e47704e7f9db67633ced3fa25c67848c20c44c8de0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Wolf")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470013")[#strong[#text("Aaron Wolf")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2016")])]

#text("So, is IRV in Australia helping them to succeed at having a diverse political system not controlled by two parties?")

#text("I think you need to seriously reconsider IRV. It has serious pathologies that can lead it to further entrenching 2-party systems and this squandering our chance at effective electoral reform.")

#text("The only system that makes sense (being far simpler than the screwiness of IRV, lacking the serious pathologies, and for electing consensus candidates) is score voting (or its simpler cousin, approval voting). See electology.org for details, and consider the real-world insanity of IRV such as this atrocious result in Burlington, VT: ")#link("http://www.rangevoting.org/Burlington.html")[#text("http://www.rangevoting.org/Burlington.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3e70213003ccd073b80e315c81fe872823884f16498500131d5cd1f05259060-5b0be47db6542147f7d241ef2dc6c3e6600433181762f92f13a74211cd903572.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470017")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2016")])]

#text("So did common knowledge prevent Brexit?")

#text("I think your hypothesis is flawed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a04e90eb6f2d1f27b45e0a71a50e99e533bb0834c7e5634a7d599d9c9406d28d-fb125e73d05dba29fae14f1e479c2f6f327b162e4a556587f4c4ac2afa0efaf3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous from the UK")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470141")[#strong[#text("anonymous from the UK")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2016")])]

#text("Plenty of people in the UK (a sizable minority, at least) were, and still are, completely and thoroughly convinced (with their own reasons) that leaving the EU was the best option, so I’m not convinced the discussion of Brexit has much at all to do with the notion of “common knowledge”, which would presuppose that everybody (or almost everybody) “knew” (or believed) otherwise.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96c4f24a6a2a5284e8d2584d0bb47d5b672354edf373896b893d8e11bc612c81-24f35e94095810b29b87a684c155cd2aa0070a84550ab1f5ddd79c2155e84300.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Konrad Benz")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470111")[#strong[#text("Konrad Benz")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2016")])]

#text("You think Donald Trump is not qualified/ Well sorry, I do not think that most republican Representatives are qualified to represent the people or be president. Trump is a real estate person and knows how to deal with difficult circumstances. Just read his books. It all depends on who he will be listening to, who will advice him, on how successful he would be as president.")#linebreak()#text(" Look at the Bush people with Cheney etc. Look at the Clinton friends.")#linebreak()#text(" Sorry I like his brash talk and his way of upsetting the establishment.")#linebreak()#text(" You never judge a candidate from what he says while running for office.")#linebreak()#text(" Study his past, read the books, then make up your mind on who to vote for.")#linebreak()#text(" Regards")#linebreak()#text(" Konrad Benz")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470193")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2016")])]

#text("Donald Trump is an extremely capable businessman, negotiator, parent, and golfer. He is now learning how to deal with a highly corrupt political system that has failed to put the interests of average Americans before self interest and global glamour in a rapidly changing world. Many people like him….go figure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470282")[#strong[#text("月旦 V | Fight with Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2016")]

#text("[…] Trump. 他的post引发了巨大的争议。 这让我想起von […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4647cb26542306dae4179e4b13dbb14da40c1991ab4c62e73cf6b54653f1f67-cf522212e981561cd03e9c3dab0841c16e1cf5adf3eeebb7f7ddc6c675ecbe1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter H. Martin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470302")[#strong[#text("Peter H. Martin")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2016")])]

#text("Maybe America needs a Donald Trump so there will never be more Donald Trump supporters in the future!! that seems paradoxical, but hear me out.")#linebreak()#text(" The problem is not Donald Trump, the problem is the people that think Donald Trump could be a valid POTUS. Maybe, once and for all, america needs a Donald Trump so we’ll never have to deal with any more trump lookalikes in any presidential run….presidents come and go, America is more than its presidents; and what is the worst that could reallistically happen to America if Donald Trump is president for 4 years?")#linebreak()#text(" I can name you a very good thing, no more Donald Trumps for 100 years…..")#linebreak()#text(" It is like the Brexit, in 20 years all the guys who voted for Brexit are going to beg the rest of Europe to come back….sometimes you need to go to the wrong direction to remind you what was the right direction and to get rid of all the base support of the candidate who was misleading you….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4609c1b9c19cad4ddd28f34cf39f582deb3aa752209984b72c2d9d8f7ef58e87-9ce05de6f8b45a68fee4297327baa98452c11e42e467d67c6acb684cbeb5ef81.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yaoyun Shi")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470357")[#strong[#text("Yaoyun Shi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2016")])]

#text("If a scientist discovered some ground truth (such as a certain element or elementary particle), s/he is praised and rewarded, no matter what s/he background was (where s/he got his degree or his/her affiliation etc.)")

#text("Trump discovered an important ground truth that the political elites from both parties have failed to see (or did not bother to respond to):")

#text("Fact 1. Many disadvantaged Americans suffered greatly or at least have not been benefiting as much as the upper classes.")

#text("If the language used above sounds biased, how about this:")

#text("Fact 1′. Many Americans supported Trump and believed that he would serve them better than any political insider.")

#text("Are we, scientists, giving Trump enough credit for his discovery? Or are we professors as disconnected with common Americans as the ruling families? If we are so shocked by Trump’s success, aren’t we missing some knowledge common to his supporters? Who is the child and who is the emperor?")

#text("Have we ever accepted/rejected/scrutinized a paper influenced by the authors’ affiliation/reputation? What exactly are the reasons for us to love one candidate so much yet hate the other equally intensely?")

#text("I’m afraid that the many reasons articulated for supporting Hilary can be used to support the following proposition.")

#text("Proposition: Princes/Princelings are in general better equipped to govern a country.")

#text("So, even if you vote for Clinton, Trump deserves your praise for making many Americans heard. In fact, if you are an American, Trump is a reason for you to be a proud American. His rise is a testimony of American democracy — that people still have voice. Hopefully the winner of this race, he or she, could learn from the loser how to do his/her job better.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4609c1b9c19cad4ddd28f34cf39f582deb3aa752209984b72c2d9d8f7ef58e87-9ce05de6f8b45a68fee4297327baa98452c11e42e467d67c6acb684cbeb5ef81.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yaoyun Shi")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470358")[#strong[#text("Yaoyun Shi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2016")])]

#text("and, everyone of us can have a better understanding of others — making more mutual knowledge common.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4609c1b9c19cad4ddd28f34cf39f582deb3aa752209984b72c2d9d8f7ef58e87-9ce05de6f8b45a68fee4297327baa98452c11e42e467d67c6acb684cbeb5ef81.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-474187")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2016")])]

#text("Fact. Trump won.")#linebreak()#text(" What Corollary would you claim, Terry?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33ef196a38486a9147a95b182346362ebea3aca1eaa5bde2a0eeee06a567485e-d8a57408814df855273c435f0b1cc274268606c0b1b7480f114abdf85cbd749f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mr. Tumnis")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470385")[#strong[#text("Mr. Tumnis")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2016")])]

#text("Terry, why don’t you instead put your mind to performing an ideological Turing test: argue for the pro-Trump position in a way convincing to a real trump support. Steel-man your arguments. Deal with a broad swathe of important issues–like abortion and immigration. Generate the best arguments possible–even if their not ones currently made by Trump.")

#text("I think you’ll find this a far more profitable exercise for understanding Trumpism or even persuasively arguing against it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33ef196a38486a9147a95b182346362ebea3aca1eaa5bde2a0eeee06a567485e-d8a57408814df855273c435f0b1cc274268606c0b1b7480f114abdf85cbd749f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mr. Tumnis")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470387")[#strong[#text("Mr. Tumnis")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2016")])]

#text("Terry,")

#text("What belief do you hold to be true that is both important and controversial?")

#text("Do you have any dangerous ideas that go against the modern leftist consensus?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470452")[#strong[#text("Un hombre listo, de verdad | carlosmanada")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2016")]

#text("[…] ")#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-f…Terence")[#text("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-f…Terence")]#text(" Tao […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470453")[#strong[#text("La verdad ante todo. | carlosmanada")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2016")]

#text("[…] Terence Tao […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/844a909004a6b3a818c99096988d56fbcb11977fde15deaaffa58b5fd4c2b971-dcf1a3a91aeb6d0b76b83580759c0fd282edcd48f62342c595eb0c56bf5d311f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ciprian")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470493")[#strong[#text("Ciprian")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2016")])]

#text("I do not find Proposition 1 to be a correct assertion. I believe it is missing a very important continuation and that is a compared to statement. This statement is crucial as the elections are between two individuals and not an inidividual against an abstract notion of what is or is not a president figure. I also believe that the importance of “compared to what” is voting system agnostic as again we compare individuals between one and another. Sure these individuals might be compared to approach one’s abstract thought of a president but that is more an expedience in the sense that you measure them against each other in comparison to the ideea of an ideal president, so it alwais comes down to the comparison between candidate A and candidate B. So I am making the assertion that for all pragmatic purposes even if every candidate in an ellection is not qualified, when measured agains the minimum requrements for the position, they can be the most qualified when compared to others for the individual voter. To be more concrete people can assert that donald trump is a good candidate for presidency when compared to Hillary and it would be a valid proposition. Now, i am not an american but from what i can tell, i would find it very difficult to say that one is better than the other but this, i believe, does not contradict my previous statement regarding Proposition 1")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5dec8efd0c002aec8ab65de4853f93516069c613aa326780d47646ae12c2f82-617c40cca919db70277c54d6989dc524c6225f8da5e78254a6315f1daba7a16e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gwb")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470609")[#strong[#text("gwb")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2016")])]

#text("Fitness varies significantly throughout time,")#linebreak()#text(" and can only ever be proven in hindsight,")#linebreak()#text(" but never in foresight of a hypothetical future.")

#text("I think that Fitness currently is mostly name recognition.")

#text("Perot 3rd w/ 18% in 1992, and Roosevelt 2nd w/ 27% 1912.")#linebreak()#text(" The people who are most likely to split the vote in 2016 are")#linebreak()#text(" Trump, Clinton, Palin, Sanders, Gingrich and Warren, in that order.")#linebreak()#text(" No one else has anywhere near the necessary name recognition.")#linebreak()#text(" But they can be promised vp or other cabinet positions for support.")

#text("It could be that things are as close to the mathematical optimum")#linebreak()#text(" in the US as it is possible to be, regardless of the candidate.")

#text("If could be that all that is left is to get those that don’t know it,")#linebreak()#text(" ie. those who are unfit, to truly believe it in their hearts, then")#linebreak()#text(" they would be truly happy.")

#text("The emperor having no clothes only matters when having clothes matter.")

#text("A pill being a placebo only matters when “ignorance is bliss” does not apply.")

#text("This currently is not in the mathematics domain, but if it is, one needs")#linebreak()#text(" to show that either fitness matters in the case of a near mathematical")#linebreak()#text(" optimum, or that currently it is not close enough to a mathematical")#linebreak()#text(" optimum yet.")

#text("Back to 1992, both party was about 40% satisfied with the candidates,")#linebreak()#text(" and the party that was more satisfied, the Republicans, lost. In 2016,")#linebreak()#text(" both parties are about 40% satisfied with the candidates, but this time")#linebreak()#text(" the party that is more satisfied is the Democrats. However, Republicans")#linebreak()#text(" are more polar than ever, made polar by fake promises, made fake by")#linebreak()#text(" even the most “FIT” Republicans have failed to fulfill and have now")#linebreak()#text(" chosen to basically shut the congress down in many ways that matter")#linebreak()#text(" the most to such voters, showing they have done all they can, it is time")#linebreak()#text(" for someone else to try, if they dare.")

#text("Supreme Court Justice Ruth Bader Ginsburg called Trump a “faker.”")

#text("So I THINK this means that:")

#text("Clinton will name Sanders as VP choice.")

#text("and")

#text("Trump will name Palin as VP choice.")

#text("While Palin was not the best choice in 2008, it is a different time now,")#linebreak()#text(" and she has had time to prepare. The surprise of such a pick, which")#linebreak()#text(" should not be a surprise at all in HINDSIGHT, shows just how out of touch")#linebreak()#text(" “FIT” Republicans are.")

#text("Furthermore, if the Republicans revolt at their Convention, that would give")#linebreak()#text(" TRUMP/PALIN more votes as INDEPENDENTS. and the new dichotomy (or tracheotomy) would be D/I (or D/R/I). Which is why Trump and Palin are")#linebreak()#text(" keeping it a surprise.")

#text("Palin is the only person as VP for Trump that Proves he is not a “faker.”")#linebreak()#text(" Both truly don’t care what others think, will do things their way, and will")#linebreak()#text(" not be pushed around or changed by BIG MONEY/LOBBYS/ETC.")

#text("But my point of view has no more or less worth than other points of view,")#linebreak()#text(" although is has much less numbers than the two polar mainstreams.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Franky_GTH")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470824")[#strong[#text("Franky_GTH")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2016")])]

#text("Question is if plausible (=? obvious) is equivalent to valid. Look at ants, each one is like a machine running on a very simple program lets say. You cannot predict “plausibly” (easily) what the effect of such a simple program will be in the complex environment of the anthill (the will build roads tunnels, search for paths, kill ill ones, …). Trump apparently is running on a very (lets call it) “simple” program, but who knows what will be the effects of that in politics (of course this view of politics is far away from common sense and mutual knowledge, but who knows).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Franky_GTH")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-470837")[#strong[#text("Franky_GTH")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2016")])]

#text("Just to make it clear, my personal opinion on Trump is a very low one, and I feel that he is not more appropriate for being president then a huge majority of the population. Though as a scientists we should, as you do, bring more interesting/deeper arguments into the discussion, if we choose so. Most of us when it comes to taking the weight of our names in, will rarely choose to do so. In this case the sheer significance of the outcome justifies in my eyes this choice.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5dec8efd0c002aec8ab65de4853f93516069c613aa326780d47646ae12c2f82-617c40cca919db70277c54d6989dc524c6225f8da5e78254a6315f1daba7a16e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gwb")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-471020")[#strong[#text("gwb")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2016")])]

#text("The only way to prove of disprove Dr. Tao conjecture that Trump is unfit is to vote for Trump to get him elected as president so Trump can prove or disprove it himself.")

#text("Dr. Tao is the best mathematician currently working. He just about only blogs about math stuff. So when he blogs about politics with a conjecture, it is important enough to be sure to empirically test. The only way to do that is to vote for trump so he wins and the conjecture is tested.")

#text("Well, Dr. Tao, you may have changed a vote for Clinton to a vote for Trump.")

#text("Unless, of course, both Clinton&Sanders decline & endorse Biden/Warren.")#linebreak()#text(" Otherwise, a small percentage of Sanders voters will vote trump because of the DNC emails.")

#text("After the DNC emails, Clinton’s email server, and Obama’s Snowden (Snowden leaked during Obama’s term and Obama just acted like it was no big deal, textbook unfitness, I just don’t get it), it is clear to me that, to the Democrats, it is common knowledge that knowing and following the rules, especially ones about sensitive information, is not important.")

#text("The republicans hated Trump out of fear he was unfit, yet those on the RNC had the courage and integrity to be fair to Trump because it is in the rules and being fair to all candidates according to the rules is also fair and respectful of the voter. In the end, the republicans decided to change and unite behind Trump respecting the voters and Democracy. (The most disagreeing republicans at most tried and failed to change the rules).")

#text("The democrats thought Sanders was fit enough, though some thought Clinton was more fit, which is fine, but what is not fine is the DNC to work against Sanders according to the news reports about the DNC’s own emails, whether fit or unfit, they chose to ignore or break or disregard their own rules about impartiality, the foundation of the purpose of the DNC, ignoring, disrespecting, and insulting the voter and the democratic process.")

#text("However, the response of the DNC, rewarding the leader by excusing him/her form his/her speaking duty, saying it is sufficient to satisfy Sanders, shows how little the DNC thinks of the voter and the democratic process.")

#text("To be fair, the only way to prove or disprove a anybody is unfit to be president is themselves during the time they are president, and the voter has the last word in that matter.")

#text("All front runners has expressed hope for improvement of society.")#linebreak()#text(" And certainly there are significantly worse choices for president that Trump:")#linebreak()#text(" Palin, or even worse myself, or even worse. The perpetual pessimist P Atkinson: www ourcivilisation com.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-471182")[#strong[#text("Updates and Links | Stacking Pennies")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2016")]

#text("[…] Terrance Tao on Trump (a few months old). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-471334")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2016")])]

#text("I totally agree – Trump is unfit for president. I’ll just add that, for similar reasons, i believe no one is fit for president. Thankfully, we can still do our best to pick the least unfit option.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dc46777c9770d47226989fd81de0a319efcd827f7fd1e976c08cbb08f3db79b-429decd35a3170950cd3db7142468ca899dde58ffd780db7ae5b0e26f4bd33c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wew")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-4/#comment-471355")[#strong[#text("Wew")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2016")])]

#text("Donald Trump is the smartest person in US politics. He single-handedly overthrew an entire political party all while fending off the rabid hounds of the corporate media. Anyone that thinks Trump is “not fit” for the presidency is totally disconnected from reality and probably does math all day")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/858971f5df19656d1a3d655386e0197e2a7d42b043f96578db512bcc87e5dd69-33201d3cd41f016e8aec6130c7a18124d476df2bb9347ff665a71eaa3ac25314.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asdl")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469462")[#strong[#text("asdl")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Kill yourself Terry you chink fuck")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16384430a77fb046424a08371dc0ecbd3c8dcf9441d1db1559596a6362eef76c-12c40458c1bebbd048bc8848a7c52c341b7dbd7b7ffcc9826425d36b9502ff00.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of eventhisoneistaken")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469464")[#strong[#text("eventhisoneistaken")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("This is a left-wing provocateur troll. I urge all sane people not to respond (don’t feed the trolls).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a9d5f30b6aca29e6afcc2910d639059124fabccb87b971828f10cc4e64df9cc-d65a29e4960704f5627efd93ab74873d42c2ca9fd93921bb1c9dfbf6b0946ebe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of esprit")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469465")[#strong[#text("esprit")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Nice try, Hillary.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ca1f66148acbda6beb4c04f89c2094f8f1d2f2fda37ae736d9a01f8900e619b-86e56d18414d3f6cbafd9df3c84b2fd120022c59ae5b5e1999f4997c94bf6ee0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Holden McGroin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469469")[#strong[#text("Holden McGroin")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Grandpa, I told you to stop using the computer and take your meds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee308bbd92e1bf2ba4ac90a89e445f5b8ccce2cf3e1183ccdb61e3fb641b3921-1cc60d5deb2fbb4c416950951e12aef2ce8eb3513167d7955f78aa9d92b7f39d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469484")[#strong[#text("Jason")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("I believe that “Donald trump is partly to blame” for this guy’s post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66f23f0f56bdf0086ce02130bbd54c3b761155e2ee9809be4455df2c425618ad-27db570b7a87447955af355454c4e8fb1769356d71b95a7c79c52e6870cdd615.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edwin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469531")[#strong[#text("Edwin")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Wow, all the pathetic Trump apologists trying to blame this on a left-wing troll. It’s not as if Trump doesn’t receive plenty of genuine support from White supremacists and Neo-Nazis, but Trump supporters are fundamentally dishonest and prefer to whitewash (heh) that part.")

#text("You stand with Trump, you stand with David Duke, with Andrew Anglin and The Daily Stormer, with Kevin B. MacDonald, with Jared Taylor, with Richard Spencer, with William Johnson, all of whom have enthusiastically thrown their support behind Trump and have explicitly stated that he is mainstreaming their racist cause. You vote for Trump, you enable people like that. Those are the stakes, and no amount of sophistry will obviate that fact.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16384430a77fb046424a08371dc0ecbd3c8dcf9441d1db1559596a6362eef76c-12c40458c1bebbd048bc8848a7c52c341b7dbd7b7ffcc9826425d36b9502ff00.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of eventhisoneistaken")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469549")[#strong[#text("eventhisoneistaken")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Can we hold Obama voters responsible for the Rev. Jeremiah Wright’s views?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f1b830e558b13bd98e7f9425cb7434390cefd4bfd6dc8a4f1373d7e50af333b-76593824a2290b0e4e7c750a1b05d51f8bb3b7ad21e87628ce8796a26d3ecd16.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Boothman")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469463")[#strong[#text("Will Boothman")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Proposition 1 is invalid.")

#text("A) Trump meets the qualifications outlined in Article 2 Section 1 clause 5 of the constitution: “No Person except a natural born Citizen, or a Citizen of the United States, at the time of the Adoption of this Constitution, shall be eligible to the Office of President; neither shall any person be eligible to that Office who shall not have attained to the Age of thirty five Years, and been fourteen Years a Resident within the United States.”")#linebreak()#text(" B) All other qualifications are subjective. However common or mutual knowledge these perceived qualifications might be, they remain irrelevant.")

#text("Perhaps a better study would be to look at your personal defined POTUS qualifications and determine whether they are common or mutual knowledge?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c96762b4354f206c5f603a3bdd47dc30a09edfe76e70f5abb9704becb4febd3-e117b6c937459c66edef735d34e31aab10b89d2e5879931fe5c6fb956006a219.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SKhan")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-470094")[#strong[#text("SKhan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2016")])]

#text("Proposition 1 states Trump is not qualified to “carry out the duties” of the President of the United States. It does not say Trump is not qualified to run for the office or be elected to the office.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/19d4f20cb1f4d001535e68cdaa809b5e30a359bed21d4e2b8862d707246cf1f7-371518d73bb829036b7daab95f1994abc9b998e454618348bfbad92c4335affb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469466")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Your claim of a canidate being unfit for presidency stems from his direct competitor’s speech. Isn’t trying to prove your fitness as opposed to your competition’s what campaigning is about?")

#text("Trump *still* hasn’t settled on his policy. That’s probably what’s behind his appeal not only to the frustrated lower middle class that falls for his promises, but to more affluent intellectuals (Peter Thiel being one), I suspect due to him swimming through the disappointment caused by buzzwords (reformer, results, hope, change) that never came to life in previous presidencies, ever since Clinton left office.")

#text("If previous candidates made false promises, what stops you from voting to one that put the practice to shame by pushing it as much as possible?")

#text("Besides, the presidential office does come with plenty of safety nets. Say Trump reverts the Iran deal (which was generally positive, in my opinion) and starts yet another war with a ridiculous price tag. In that case, there are political entities which may, on the condition of a majority vote, impeach him.")

#text("It’s about flipping a coin vs. settling for a combination of populism and aggressive foreign policy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a3efe64c12b3af467b5d92e6639ab4d9afb862120ed59c2a0524237cbc523799-cb0d00a4c7da65c4f38e1a7e704d02d34a9ff0aa0ddc3d2d89218fe64e17162c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AnonSoICanSpeak")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469468")[#strong[#text("AnonSoICanSpeak")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Tao’s Prop 1 is really just a vaguely defined opinion. Encasing Prop 1 in “For all n, (everyone knows that)^n[Prop 1]” escalates this expression of opinion to an emphatic but unempathic denial that reasonable and sensible people can differ in this opinion. The argument could only have worked if Prop 1 is replaced by a tautology like “Illegal immigration is illegal”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469470")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("It’s interesting that some here are debating what the qualifications are to be president by reducing them essentially to that one has to be a living America born citizen over a certain age. They are remiss in reminding us of the presidential oath (“I, name, do solemnly swear (or affirm) that I will faithfully execute the office of President of the United States, and I will to the best of my ability, preserve, protect, and defend the Constitution of the United States.”)… which perhaps in view to the possibility that Trump may be reciting this should probably read “I, Donald Trump, do solemnly swear ( on the Bible or affirm on “The Art of the Deal”) that I will faithfully execute the office of President of the United States, and I will to the best of my ability, preserve, protect, defend, read, and understand the Constitution of the United States.”")

#text("It is instructive to read who a group of 10 historians from different political parties listed as the 10 most influential presidents since 1900. Love them or hate them, it is impossible for anyone but the most narrow minded to dispute that all 10 were very influential.")

#link("http://www.thedailybeast.com/galleries/2012/09/24/from-franklin-delano-roosevelt-to-john-f-kennedy-newsweek-s-10-best-presidents-photos.html#e86a8b2e-632b-465a-9c7c-45258df2457c")[#text("http://www.thedailybeast.com/galleries/2012/09/24/from-franklin-delano-roosevelt-to-john-f-kennedy-newsweek-s-10-best-presidents-photos.html#e86a8b2e-632b-465a-9c7c-45258df2457c")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ac1e8b4859cff5ca4772fd461a2218bf935fd756d3790d8046361b1ad09cdb8-7a97576037a02634cc8ab76ea0865e9393787b7d9dd129bb002a9d7fcd654d01.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of baraq")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469471")[#strong[#text("baraq")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Dear Dr. Tao, do you get all your news from Mr. John Oliver?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ac1e8b4859cff5ca4772fd461a2218bf935fd756d3790d8046361b1ad09cdb8-7a97576037a02634cc8ab76ea0865e9393787b7d9dd129bb002a9d7fcd654d01.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of baraq")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469472")[#strong[#text("baraq")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("I would also add that substituting Trump with Obama, and John Oliver with Jon Stewart, using your methodology, one can also prove Mr. Obama is unfit to be POTUS; yet he was elected twice. What does this tell us?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b11fbded877b4a31dbfd3d81f92fd3b5f936ae3a6f8fcbc815ac900c5de3ab9-6aeda26237e9955e30cb19e93aa90e04217165629828b5485baf40d4866936f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jack")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469473")[#strong[#text("jack")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Terry, I remember once you said in an interview that you’re good at subjects that were objective and had clearly right or wrong answers, but not so much on things that were subjective. I think that’s a fair and honest self-assessment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469476")[#strong[#text("(((Schiklgruber))) (@Dont4get6000000)")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")]

#text("Proposition 1. Terry Tao is not even remotely qualified to judge who is qualified to carry out the duties of the president of the United States of America.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469477")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("I’m curious to hear from thoughtful Trump supporters what you think *your* nation should do if *another* nation’s democracy (which incidentally was the preeminent economic and military power worldwide) were to decisively position a Trump-analogue one step from that nation’s leadership.")

#text("Your answers may depend on whether relations were formerly friendly, neutral, or antagonistic, so feel free to elaborate. Any further measures you would advocate should the Trump-analogue actually be elected, are also of interest.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469488")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Sheesh, I didn’t intend “thoughtful” to disqualify *everyone*…:-)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469478")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("You actually used a comedian as a source?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469479")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("It is mutual knowledge that the 197th decade is the years 1961-1970. Still J.F.Kennedy considered it to be 1960-1969, which is the common knowledge. The one year early millenium celebration was an embarrassing display of false common knowledge. Where is the child to shout out that the president was mistaken?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5dec8efd0c002aec8ab65de4853f93516069c613aa326780d47646ae12c2f82-617c40cca919db70277c54d6989dc524c6225f8da5e78254a6315f1daba7a16e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gwb")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469481")[#strong[#text("gwb")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("the problem is that no matter how the voting system to get elected is changed it is probably not going to prevent significantly unfit presidents being elected")

#text("even out of the most seeming fittest to be president some prove they are unfit while in office, it is only by hindsight that we think we should have know better.")

#text("it is possible that some seeming unfit before election to do a better job than expected. (someone who has unspecific or unstated policy positions turning into more of a lame duck than a either pleasant or unpleasant surprise)")

#text("however, perhaps there should be an additional safeguard, automatic yearly recall elections for every president (and every elected official )")

#text("keep the current voting system to be elected as is (every 4 years)(in other words years divisible by 4), and max total term, but for each of the three years in between the 4 years, have a national ballot like this for each elected official:")

#text("1. should the current president be replaced immediately? yes no")#linebreak()#text(" 2. if replaced, who should be the replacement?")#linebreak()#text(" please circle either yes or no for each candidate")#linebreak()#text(" for each candidate you circled yes to, please circle a preference")#linebreak()#text(" party 1 candidate 1 yes no 123456789…")#linebreak()#text(" party 1 candidate 2 yes no 123456789…")#linebreak()#text(" party 1 candidate 3 yes no 123456789…")#linebreak()#text(" …")#linebreak()#text(" party 2 candidate 1 yes no 123456789…")#linebreak()#text(" party 2 candidate 2 yes no 123456789…")#linebreak()#text(" …")

#text("(number of named candidates per party will be no less than those who have a 10% or more approval rating within their party taken exactly 30 days before date of recall election according to more than half of polling organizations approved by both major parties )")

#text("if 67% or more people who answered question 1 answered yes,")#linebreak()#text(" then whichever candidate gets the most yes vote will become the new president and take office 15 days after the date of this election")

#text("(if there is an exact tie, the candidate with the least no votes among the candidates that tied will break the tie, if there is still a tie after this, then a preferential system based on the weighted ranking (sum of reciprocals of number of preferences(1st,1st,3rd,2nd->1/1+1/1+1/3+1/2)), if there is still a tie, then each candidate who tied will serve a proportional continuous equal amount of time as president over a year long period )")

#text("I think something like this is the best safeguard.")

#text("Let the voters decide if the elected official if fit based upon the voters judgment of the elected officials performance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/de8fd6f3ac0d6a7b73d8e0f525112b38fbc4bf12913cdd514dce12ba778f5bcd-11fe82f9bc53951041905ed855c88686ef05e0eff224cf46603823330e0fe1d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of random reader")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469483")[#strong[#text("random reader")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Election of past “obviously unfit” media personalities such as Ronald Reagan, Arnold Schwarzenegger and Jesse Ventura did not cause any disasters in office, which suggests that the definition of “not fit” is off-base. Trump has additional business experience that the others three did not have, in addition to the media exposure.")

#text("Trump is quite similar to the ex-governor Reagan, a pop-culture personality with some experience running things, whose appeal to the electorate is based on a combination of America First ideology, telegenic charisma and name recognition. And his policies run less of a risk of creating a nuclear war, which is always a plus. Had things run differently for the Soviet Union, such as the discovery of immense new oil resources on its territory, or severe economic problems in the West, the Reagan military buildup could have very well led to a war between nuclear superpowers or their proxies during the 1990’s. Trump by contrast seems a lot less aggressive in his foreign policy stances.")

#text("Reagan on the eve of his election to the US presidency was widely (though not universally) viewed as too old and close to senility to hold office, and he became medically and mentally unfit for office after the assassination attempt in 1981. The official diagnosis of full blown Alzheimer’s was not given until later in his presidency but his staff and his wife were propping him up after the assassination. The presidential debate performances in 1984 confirmed the suspicion that he was not fully present mentally. Before and after his election, Reagan had many gaffes that were interpreted (often correctly) as evidence of incompetence, and such things were noticed and compiled less often than in the Internet age.")

#text("Despite all these extraordinary qualification deficits for a sitting US president, Reagan was not any less effective than a super-qualified, smart (Oxford chemistry PhD) and micromanaging technocrat like Margaret Thatcher at pushing the essentially identical political program.")

#text("With this sort of background in mind I don’t see how Trump should not be taken seriously. The choice is between political programs and likely cabinets of the different candidates, as well as the candidates themselves, and for the latter one has to choose from the 2-3 electable presidential candidates, not compare Trump to an idealized “qualified candidate” who is not on the ballot.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/de8fd6f3ac0d6a7b73d8e0f525112b38fbc4bf12913cdd514dce12ba778f5bcd-11fe82f9bc53951041905ed855c88686ef05e0eff224cf46603823330e0fe1d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of random reader")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469486")[#strong[#text("random reader")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("(well, Nancy and Donald et al were propping up Reagan after the assassination “attempt”, not after “the assassination”. Fun typo.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469528")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("I guess Terry just did not do enough homework in either history or politics before he posted his naive political “proposition”. With his talent I am sure he can pick up any intellectual subjects much quicker than almost all other people in the world. That said, he still needs to devote enough time, energy, and thoughts into that subject before he can gain anything profound. He used Trump’s opponents’ opinions as his sole evidence for his proposition. If this was his way of doing literature review in his research, that will be a disaster. Fortunately he didn’t.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33a2b53553ff103d52fdd5d51c3d7887e87ce7c8afea41b51ccda7b8e9c00c19-c6c0a2c9b334130aa0249fa5cc3fb7c0c34a317df0e051839e233a0d3634a37e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christine da Pizzano")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-471365")[#strong[#text("Christine da Pizzano")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2016")])]

#text("You don’t think Ronald Reagan caused “any disasters in office”? His illicit support for the apartheid regime in South Africa, while it killed over one million people in wars with neighboring countries amid brutal internal repression, wasn’t a disaster? Reagan’s support for a fascist military dictatorship in Guatemala, which left 100,000 people dead, wasn’t a disaster? Reagan’s support for a similar dictatorship in El Salvador, which left 65,000 people dead, wasn’t a disaster? How about Reagan’s support for the mujahideen in Afghanistan, who evolved into the terrorists who would go on to attack the United States? How about Reagan’s assistance to Pakistan in its pursuit of nuclear weapons, conceivably the greatest threat to life on earth today?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/de8fd6f3ac0d6a7b73d8e0f525112b38fbc4bf12913cdd514dce12ba778f5bcd-11fe82f9bc53951041905ed855c88686ef05e0eff224cf46603823330e0fe1d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of random reader")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-471943")[#strong[#text("random reader")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2016")])]

#text("Your opinion of the Reagan administration (or Schwarzenegger or Ventura administrations’) policies is not really relevant to the issue of Trump’s qualifications. The issue as it concerns Reagan is whether there were any major problems during his presidency that are attributable to him being relatively unqualified or, after a certain point, mentally impaired.")

#text("Every “disaster” you listed did not begin during Reagan’s term in office, and involved a continuation of US policy from the previous administrations of objectively more qualified presidents such as Carter. In addition, every one of those cases was driven by Cold War geopolitics, and Huntington’s “clash of civilizations”, much less a state of war with the Islamic world, was not yet in focus as the successor to that conflict. Criticizing the consequences of US policy in Central Asia with the benefit of 30 years’ hindsight does not (necessarily) imply that at the time it was bad decision-making. It certainly does not imply that Carter or Mondale, who were the better-qualified alternatives to Reagan, would have made better decisions. It’s not as though Carter’s foreign policy decisions all look awesome in hindsight, either.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b4f0d7eff3cd4c62d995cc7aa8ca6a3a0544e653744bed24ec33a30671021b5b-6a71491e6dec7ffadede168961a5efed2a6b997a69f10f3212f35e33a76aa6b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469485")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Dr. Tao, can you add John Oliver as a co-author on this piece of work? This will make the work more credible and attract more citations. It perhaps won’t lead to another Fields modal, but nonetheless a solid piece of work. Congrats!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/faa180bbd644d700c49eeaa5680080da3b5773b605f63982bec05233fbaa1e00-18f305c461f93b97dfb9015463dda64079a6f23972af8ee9220de7b3cc8f769f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adolf")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469489")[#strong[#text("adolf")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text(">Proposition 1. The presumptive nominee of the Republican Party, Donald Trump, is not even remotely qualified to carry out the duties of the presidency of the United States of America.")

#text("sure he is")

#text("he’s a human")

#text("he is qualified")

#text("now piss off back to kindergarten")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/42be6c2de2e202ea1e67839e43c37afc09334ac2e0d756cbd04d31b8a2b99cc3-0587b6bb86a745d7a4e448a32724dce087458ee80c678de057cfdeb46260d120.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 99morequestionsthananswers")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469490")[#strong[#text("99morequestionsthananswers")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("You say that Trump is not qualified, but what do you mean by that? Do you suspect he has lied about his age and is younger than the 35 year minimum? Are you proposing that Trump is not a citizen? Maybe we should take a closer look at his birth certificate. I suspect that you are suggesting neither of these things. Although you say he is not qualified, what you mean is that he does not live up to your own personal standards for a president. Since you are referring to your own standards and not a universal standards, the idea that it can be known by everyone that these standards are not met is absurd. Clearly, millions of people feel that he either meets their own standards or that he comes closer than any other candidate. Not only is your article absurd, your attempts to dress it up as an exercise in logic are comical.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469535")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("This is the best and most succinct and pithy reply here. Well done.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/42be6c2de2e202ea1e67839e43c37afc09334ac2e0d756cbd04d31b8a2b99cc3-0587b6bb86a745d7a4e448a32724dce087458ee80c678de057cfdeb46260d120.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 99morequestionsthananswers")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469545")[#strong[#text("99morequestionsthananswers")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Thankyou sir")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5dec8efd0c002aec8ab65de4853f93516069c613aa326780d47646ae12c2f82-617c40cca919db70277c54d6989dc524c6225f8da5e78254a6315f1daba7a16e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gwb")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469494")[#strong[#text("gwb")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("why is your proposition a bad thing for democrats???")

#text("why is your proposition a bad thing for republicans???")

#text("lets put this a different way.")

#text("the candidates will probably are Clinton and Trump and each that each candidate will make VP choices better than Palin, say Sanders(or Biden) and Gingrich respectively.")

#text("now this should make democrats happy beyond belief.")

#text("an opponent they are sure they can beat in the election.")

#text("would it make democrats happier if the republicans had their own version of B Obama, a super fit superstar genius (remember when he was first elected he crushed H Clinton like a foot crushed an aluminum can).")

#text("Trump being the Republican nominee is the Republican party’s fault for not having better candidates. Who decides who is better, the voting people who are registered republicans do.")

#text("The people have spoken. They have spoken. That is the only real “qualifications” other than constitution 3, that matters in the American system. the people decide who is most qualified based on their vote.")

#text("if the experts disagree with the people, or did not understand the people enough to see Trump doing so well relative to the other candidates, then how much of an expert are they really???")

#text("the people, not only experts, decide by vote, because in the end the president serves the people not only experts.")

#text("Next election in 4 years, will the Republicans learn from their mistake?")

#text("The party is responsible for knowing its own base–that is the whole ball game, satisfying your party base. Ok it is good if you can convert some of the other party to vote for you candidate or more likely abstain, but if you don’t have the support of your base what is the point?")

#text("The republican base has sent a crystal clear message. Trump is more satisfying then the other republican candidates by a significant margin")

#text("that is who they have screamed for who they think is their best chance at winning compared with the other republican candidates.")

#text("do you really think he should be disqualified and be taken off the ballot because he does not meet some common sense fitness standard.")

#text("if you are republican, would you rather have the people who voted for Trump in the primaries vote for Clinton in the election because you took the republican majority favorite Trump off the ballot")

#text("if you are democrat, if the democrats cannot beat trump, who can they beat??? who do you think that Clinton would have a better chance of beating that is more fit than Trump???(this is a serious question)")

#text("if you are neither, do you really think it best to tell people they are not qualified or fit enough to vote because they are fooled by Trump and tell them their vote no longer matters and will no longer be counted?")

#text("on the objective merits of your post in light of your mathematical talent:")

#text("you did not define fit")#linebreak()#text(" you did not define qualified")#linebreak()#text(" you did not define duties")

#text("therefore the proposition is not well formed")

#text("further analysis is on the merits is no longer objective.")

#text("unless that is part of the puzzle, to deduce how reliant possible definitions are to the puzzle itself.")

#text("I think you were intending to informally state an analogy of how Trump being a nominee is similar in some way to a very easy logical puzzle")

#text("*there are simultaneously exactly two logically correct answers depending on what is meant by specific terms. because of this, it is undecidable*")#linebreak()#text(" that is the answer to the logic puzzle")

#text("you say “I feel that it is time for the charade to end”. are you saying that the American citizen voters should not be taken seriously, and that their vote not be counted???")

#text("are you intentionally trying to act the part of the outsider who does not know they should not speak about eye color and gives people info they can use to deduce that would lead them to the conclusion of suicide???")

#text("on the other hand, if you have someone Trump trusts, like time traveling trump from the future tell Trump he is unfit and trump believes it he is a suicide risk, that by extension the republicans will deduce because they voted for him are unfit or unqualified to be voters, and upon that realization, they will suicide themselves,")

#text("or do you mean figurative suicide of the Republican party, not literal individual suicide.")

#text("I think I get it now.")

#text("Because Republicans were fooled by McCain who demonstrated profoundly poor judgment in deciding on Palin thus showing the Republicans how truly unfit McCain was to be president even by Republican standards, and because this became common knowledge amount Republicans, Republicans kinda figuratively suicided their own party and the choice of Trump is simply an observed symptom of the dead decaying corpse of the Republican party.")#linebreak()#text(" (I disagree with this perspective, it could just as easily be a caterpillar before it finishes changing into a butterfly, but regardless, this perspective seems to be the only thing I can think of so far that seems to fit best)")

#text("is that the correct answer???")

#text("look, you are a super-genius at math, maybe in a few decades you will be among the all time greats like A. Einstein, or S. Ramanujan, so you are trying to be all zen like and teach something a different way.")

#text("this is kind of like trying to solve a mechanical puzzle.")

#text("please don’t forget to post the correct answer, or at least a clue. thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469495")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("BEFORE ANYONE ELSE POSTS SUPPORTING DONALD TRUMP – and give me a thumbs down – read the two referenced article, PLEASE.")

#text("Nobody should even have to say that there are no universal standards besides the meager ones spelled out in the Constitution. While not possible to conduct a person-to-person psychiatric diagnostic assessment of Donald Trump he gives mental health experts ample fodder for analysis as to his mental condition. When the framers wrote the Constitution nobody thought somebody not of “sound mind” would be elected president. So far the country has been lucky, and all our presidents, while some have had their quirks, none have been assessed as having had mental impairments are the beginning of their tenure. Donald Trump, as a number of psychotherapists more learned in making at-a-distance diagnosis than I am have noted, he is more than likely to suffer from narcissistic personality disorder. See “IS DONALD TRUMP ACTUALLY A NARCISSIST? THERAPISTS WEIGH IN!")#linebreak()#text(" As his presidential campaign trundles forward, millions of sane Americans are wondering: What exactly is wrong with this strange individual? Now, we have an answer.”")#linebreak()#text(" BY HENRY ALFORD")

#link("http://www.vanityfair.com/news/2015/11/donald-trump-narcissism-therapists")[#text("http://www.vanityfair.com/news/2015/11/donald-trump-narcissism-therapists")]

#text("Dan McAdams, the author of “George W. Bush and the redemptive dream: A psychological portrait.” New York: Oxford University Press, doesn’t make a diagnosis. Instead he presents an in-depth analysis of what a Trump presidency would be like based on personality characteristics.")

#link("http://www.theatlantic.com/magazine/archive/2016/06/the-mind-of-donald-trump/480771/")[#text("http://www.theatlantic.com/magazine/archive/2016/06/the-mind-of-donald-trump/480771/")]

#text("NOW that you’ve actually read both articles, go ahead and click the thumbs down arrow if you want to.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ca1f66148acbda6beb4c04f89c2094f8f1d2f2fda37ae736d9a01f8900e619b-86e56d18414d3f6cbafd9df3c84b2fd120022c59ae5b5e1999f4997c94bf6ee0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Holden McGroin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469510")[#strong[#text("Holden McGroin")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("How do you expect me to trust your sources without a phrenology report?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469513")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("I hope (really truly do hope) that you recognize that what I wrote about phenology was tongue in cheek. Anyway, that you for remembering me,")#linebreak()#text(" probably your only non-mathematician posting here – unless some of those I shared this great blog with also post comments. Notice that the sources, The Atlantic, founded in 1857, and Vanity Fair (first published in 1983) have been around for awhile, since before the Internet became the Internet in fact —— way before in the case of The Atlantic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ca1f66148acbda6beb4c04f89c2094f8f1d2f2fda37ae736d9a01f8900e619b-86e56d18414d3f6cbafd9df3c84b2fd120022c59ae5b5e1999f4997c94bf6ee0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Holden McGroin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469516")[#strong[#text("Holden McGroin")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("I’m very disappointed to hear you’re not a true believer in phrenology, as I was very much looking forward to your impression of Trump’s skull impressions. I gave your comment a “thumbs down” just because.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469521")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Send me mold of his bald head and I’ll see what I can do. Who knows what lurks beneath that hairsprayed orange coif? By the way, how about owing me a thumbs up sometime just because?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ca1f66148acbda6beb4c04f89c2094f8f1d2f2fda37ae736d9a01f8900e619b-86e56d18414d3f6cbafd9df3c84b2fd120022c59ae5b5e1999f4997c94bf6ee0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Holden McGroin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469522")[#strong[#text("Holden McGroin")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("I’m sure Trump will take off his wig sometime if Hillary does too. Peer pressure is a powerful force.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469517")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Six thumbs down, and counting. OF COURSE everyone giving me the digital Bronx cheer actually did read, or at least scan, the two articles. Yeah, if you believe that I have a good deal on selling you the Pelham Bridge. ")#link("https://en.wikipedia.org/wiki/Pelham_Bridge")[#text("https://en.wikipedia.org/wiki/Pelham_Bridge")]

#text("Here’s another thought about these mathematician naysayers who reside at the top of the science world pyramid. Perhaps the six of you just don’t psychology is even a science given that it does indeed mix art and science and proofs are rarely if ever readily testable. I mean, what gall to even call the Rorschach a test!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29156f3af02f70434edcca0cf0708b6c18ac1aa57e670cfddded16a38e0e5a41-86ebb22abfc0190e05cfce681324367803ca7c230f039a13d728f7ca6d6fdeac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristen slawinski")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469496")[#strong[#text("Kristen slawinski")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Gary Johnson will be on the ballot for the Libertarian party. The choice for president is not limited to 2. Vote for freedom.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469497")[#strong[#text("A Collection of Comments | 99MQTA")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")]

#text("[…] #2 (In response to this blog.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8936bfc9b86c00e45bb2256630f2ce115a23b26259aa55970f6dabee73069e7e-01aa26e1d26140207a204c8bc20da8fe418b53d4c0bba07d74c5bc914a0de359.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BBT")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469498")[#strong[#text("BBT")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("May I make a devil’s advocate? Proposition 1 is: American working class issues need to be addressed.")

#text("This is the mutual knowledge becoming common knowledge in recent half year. Media are by and large progressive left. People might be aware of the losing working class conservative Joe. But nobody want to say anything because that’s not cool to support conservative ideas. Trump is more like the little boy saying emperor has no clothes on.")

#text("N.B. I don’t support Trump.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75bd236a64262b5bf6e9a327bf58ad68ebcdeac37c225539347a3fbb7bda444e-1b7b08af4124a2f815580ea6068d664fd8d787c7fef8f3c440412f10c225f7f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John A. Visser")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469500")[#strong[#text("John A. Visser")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("The Democratic party, and the progressive left, have been lamenting the loss of the middle class at the hands of greedy capitalists for over 100 years. And for all of the programs they have instituted, starting with the income tax, a progressive one, in 1913, they haven’t change things one iota except to make the country more socialist and less industrial.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469543")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Exactly. If you would like to find an analogy of this election in the Emperor’s cloth story, Trump is the child. The emperor’s non-existing cloth is the propagada of the so-called “free media” and the controlling hands behind them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8936bfc9b86c00e45bb2256630f2ce115a23b26259aa55970f6dabee73069e7e-01aa26e1d26140207a204c8bc20da8fe418b53d4c0bba07d74c5bc914a0de359.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BBT")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469502")[#strong[#text("BBT")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("We can take voting preferences as mutual knowledge and poll figures as common knowledge. Poll of trump was low 7 months ago. People who secretly supported Trump back then thought nobody else supports him. Now people have voted, they revealed their preference to the public. Now it’s common knowledge that Trump has lots of supporters.")

#text("N.B. I still don’t support Trump.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469504")[#strong[#text("疯狗问题 | 食神")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")]

#text("[…] 8年前汶川地震，在blog上讨论过疯狗问题（本博“众所周知”及“答chen”）。近日陶哲轩在博客上提到类似问题（里面的blue-eyed islander puzzle就是疯狗问题），原文链接为： 这里 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469506")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("The massage of the post that I identified with the most is the stance that “Trump is unfit to be president” and the call “But more people need to say so, openly.”")

#text("I also share the main point of the analysis: At present, there are many people, possibly a solid majority of the US population, who are deeply disturbed by Trump’s candidacy, by Trump’s behavior and by Trump’s positions, and regard him unfit, not even remotely. But many among them are uncertain because of not being aware of how wide spread the concerns regarding Mr. Trump are.")

#text("Of course, we cannot refer literally to “everybody” or “almost everybody”.")#linebreak()#text(" (And it is a good trait of democracy that nothing is accepted by “almost everybody”.) There are people who do identify with Mr. Trumps’ positions and who approve of his behavior. Some people may even think that “fits to be president” is not the right criterion to start with.")

#text("However, I do believe that there is a solid majority of Americans, quite possibly even a solid majority in every single state of the US who privately regard Mr. Trump as unfit and his actions and positions as largely violating the American values. For people, also those who are not typically involved in politics, to stand up and say so, could make a difference.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469507")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Thus, mathematically speaking, I conjecture that “almost everybody” is correct if interpreted in terms of electoral votes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5fb8d3ea7b87ff69aeca40d60f0e35587f359acc642ea394fda7eb22ea123c30-f238aa76aef7ab6a0df0eb868ab8522a09749dd6362249746264c2e1da8b0657.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469524")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Trump routinely gets about 40 percent in nationwide polls. It’s probably not a solid majority that privately thinks the way you are conjecturing. And if you restrict to white voters, Trump does seem to get over 50 percent support as of now.")

#text("People here make their opinions of both candidates quite well-known. It may be hard for you to accept that the American voters are not as disturbed by Trump as you are hoping. But this is the reality. A lot of people will overlook Trump’s overt racism and dictatorial tendencies, or even not mind them, and choose him as an alternative to “the system”.")

#text("If there are any secret opinions not being expressed, it’s the people who vote for Trump but keep quiet about it. In public he is routinely trashed. In academic circles you could conceivably lose your job for expressing his kind of views. On the other hand, there’s absolutely no need to hold back if you are a Clinton supporter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469548")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Michael, Perhaps, the point of the post is not so much about secret opinion not being expressed but about widely held private opinions not being expressed strong enough. You are probably right that there are also people who identify with Trump’s massage and keep quite about it. As always, but especially so because of the high stakes, it is probably instrumental to have as wide and as open discussion as possible. I hope that people who are deeply disturbed by Trump’s overt racism and dictatorial tendencies will say it, openly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469592")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("Michael, one more remark. You wrote: “It may be hard for you to accept that the American voters are not as disturbed by Trump as you are hoping…A lot of people will overlook Trump’s overt racism and dictatorial tendencies, or even not mind them, and choose him as an alternative to ‘the system’.” and")

#text("“If there are any secret opinions not being expressed, it’s the people who vote for Trump but keep quiet about it…On the other hand, there’s absolutely no need to hold back if you are a Clinton supporter.”")

#text("Indeed, I am hoping that the American voters will reject Donald Trump. Note that people who live in communities or families with support for Trump’s overt racism, dictatorial and anti-women positions, may also need to hold back or keep secret their views. This may especially apply to women.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/427dec019c6c02612758c0254b62bf919f69d7b58053e628a51571479408f198-7594e3e4723ff9d1d64d36c34b5203a382a6f14aa2a79e21e465d0528440af70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dcohen")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469623")[#strong[#text("dcohen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("The use of the word “knowledge” rather than “belief” in Terry’s post reveals a certain rigid moral arrogance, though. It seems to me that trump’s strategy is essentially a provocation. He may well turn out be a non ideologic, and possibly good president. Or at least, predicting the opposite from his current provocations sounds a bit too immediate and might just show that his campaign strategy is actually working.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91ba065c8bb4f7d002b7842a03f300980122cd55943861d33657023f8cd401c6-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469653")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2016")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("It seems to me that Trump’s strategy is essentially a provocation. He may well turn out be a non ideologic, and possibly good president.")
]

#text("Sanford L. Segal’s ")#emph[#text("Mathematicians under the *****")]#text(" (2014) documents a mathematical community that similarly rationalized indecision and inaction, in effect by deluding themselves along parallel lines:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("It seems to us that [the National Socialist platform] is essentially a provocation. [Their candidate] may well turn out be a non ideologic, and possibly good president.”")
]

#text("A crucial lesson of Segal’s history is “Speak up early, speak up plainly, and speak up loudly.” There’s no rational reason to study this history, if we don’t take lessons from it, is there?")

#text("Shall we criticize Terry Tao — and now Scott Aaronson and increasingly many other prominent STEM professionals — for speaking up earlier and more plainly and more loudly, than the too-shy too-quiet STEM professionals of the 1930s?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/427dec019c6c02612758c0254b62bf919f69d7b58053e628a51571479408f198-7594e3e4723ff9d1d64d36c34b5203a382a6f14aa2a79e21e465d0528440af70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dcohen")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469671")[#strong[#text("dcohen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2016")])]

#text("well, certainly not, but I don’t like the use of the term “knowledge”, which I find arrogant. I don’t think mathematicians are more politically qualified than politicians, and so this sounds a bit ridiculous to me. And trump may of course turn out to be a bad president. But a nazi or even something vaguely reminiscent seems almost impossible given the constitution. The worst he could do would be to fuel further trouble in the middle east. But I think bush may be unbeatable in this respect and, by the way, hillary doesn’t sound better…")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469534")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("I’m sure you’ll still defend Clinton’s fitness to be president after this book drops: ")#link("http://goo.gl/hnAJYn")[#text("http://goo.gl/hnAJYn")]

#text("In terms of personality and temperament, Clinton may very well be worse than Trump. Her scandals are practically uncountable.")

#text("You claim this is irrelevant. And yet you admit that we will have no other practical choices than Trump or Clinton for president in November. In assessing which of our only 2 options is better, how is this not relevant information for consideration? Even if Trump is unfit, Clinton may be less fit. In that case, one ought to vote Trump.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469536")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("It should be common knowledge that Clinton is going to be indicted by the FBI.")

#text("There, if I say it the same way you did, then it must be right.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a647a59bc51f60a3feb6c7dcf414ad8addb7c9b48b79f1c6554df682095d6df0-0cca9662942d1c4b15bc23790ce1ad943e14f54522250b84f5355623ac26f40a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of paul hughes")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469537")[#strong[#text("paul hughes")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Whether he may be “fit” (your undefined term, not usually employed or considered relevant in actual politics) or not, many will vote for him simply because they consider him the better of the two alternatives.")

#text("If you have ever been involved in politics, you know that one side usually considers the other guy unfit for anything but prison.")

#text("This piece is markably naive and pointless.")

#text("Trump exists as a viable political actor because the established power structure in both parties has ignored the wishes of the practical majority which put the current Congress in place.")

#text("So if we end up with an “unfit” president (not for the first time) it will be the people who “know” he is unfit who will have brought it about. Sort of ironic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14449a1e94ea561bc3ba23eea5018da3a206b9195dee1c8d60c94a13e4727f1-460c9008dbdf288e46239e1d6a2c919902d35ac106d77268bc04c38edef4d1b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fashun Zhang")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469539")[#strong[#text("fashun Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Hi Terry,")

#text("I believe that many people have the feeling that Trump is not so reliable at least in certain aspects, but they can’t be sure of it. Trump’s supporters must have a trade off between Trump’s good and bad points, or Trump will not be supported by so many people with such a long time.")

#text("If everybody knows that the sun rises from the east, such common knowledge will be formed at a short time. In the fable of the Emperor’s New Clothes, the key reason for the situation that everyone is refusing to acknowledge the emperor’s nakedness kept for such a long time is that they have not the courage to tell the truth because of the possible punishment. It is not the case for Trump.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/94927ae87ce38c66b3985c146e84513e12a582e80ed2646c0f3fce08b1a12bd0-76e6a6a33e07698971aac371d4bd771d6c8294e9f9295953af8ef2b8a57cb0a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fei Liu")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469541")[#strong[#text("Fei Liu")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("I am afraid not so. The constitution states no requirement for “fitness” of a president by any intellectual, physical or ideological standard. Hence, Donald Trump is as “fit” to be president as Hillary, since he is a natural born American over 35. As a progressive, who is trying to get the society to abolish discrimination of a person based on any natural traits, we have to swallow the bitter pill of Donald Trump, and realize this is a price to pay for equality for all. I have said it many times, democracy is not about right leading the wrong, the intelligent leading the stupid, democracy is simply, what the majority of the members of a society want. If Donald Trump is elected, he is fit for president by satisfying the criteria set by the constitution. If we don’t accept this, and impose an artificial “fit” criteria, then, may I ask, who is to define this “fitness”? The liberals, the conservatives, or the libertarian?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469546")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("This thread is petering out. Considering that it is almost certain that following the A.P. announcing the result of their analysis is that Hillary has enough pledged and super-delegates (the later having been asked by A.P.) to win. Therefore, considering the interest Terry Tao’s commentariat has shown, I hope her writes another blog from his unique perspective. Certainly by tomorrow night when the Tuesday primary results are in we will know whether or not Bernie Sanders will withdraw.")#linebreak()#text(" Lots for Terry to write about.")#linebreak()#text(" I certainly intend to on my own blabbing blog (those few of us making comments who have websites have their names, as links, in purple here), and probably on Daily Kos where I frequently post what they call diaries.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ca1f66148acbda6beb4c04f89c2094f8f1d2f2fda37ae736d9a01f8900e619b-86e56d18414d3f6cbafd9df3c84b2fd120022c59ae5b5e1999f4997c94bf6ee0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Holden McGroin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469561")[#strong[#text("Holden McGroin")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("I expect a full handwriting analysis, phrenology report, and palm reading from you before November.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469563")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("How about an analysis of why people choose certain noms de plume for their comments instead.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ca1f66148acbda6beb4c04f89c2094f8f1d2f2fda37ae736d9a01f8900e619b-86e56d18414d3f6cbafd9df3c84b2fd120022c59ae5b5e1999f4997c94bf6ee0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Holden McGroin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469568")[#strong[#text("Holden McGroin")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("That would be easy. Some names resemble other English words and when presented as such are quite funny. On the other hand, logically maneuvering from the way someone writes the letter “y” or “t” or the contour of their skull to a personality trait is an enigma.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fda6704461b207bfde220627e42d7f6dcbdd124c4d221c9b50e0a8ad54f5e116-e748904e97642ac1f5c4d29491b24d33381ab7ede1e8ccb321a868e891846244.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sluhovoe_okno")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469547")[#strong[#text("sluhovoe_okno")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("I think that you should limit yourself to mathematics. What should worry you, is not who you are “electing for president”, but how to avoid war.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/380df033e13a2b9b4221287220bfb9ebd0824a94f508abf7f38a49d0e1f2c383-87390e19e9bcba1448fc06bfe65bcb78a89e83af1b93778e3dac0803aedd55e0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469550")[#strong[#text("George")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("How the “fitness” of a presidential candidate is defined?")#linebreak()#text(" Was Reagan fit? Or was G.W. Bush?")

#text("Or, for example, Obama seemed to be fit, but it is now ‘mutual knowledge amongst the US population’ that he produced nothing.")

#text("So in order to make ‘Proposition 1’ we should first make a ‘Definition 1’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469559")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("This debate is completely flooding the Recent Comments bar. Is there a way to prevent that?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ab103bf7810e6cf45d9edf56f8347b81756674c695338d5bd1be03b6c1834d7-659f9958604df4f0ac624856d75dba4b03dd620ebb3b52d696163afe65d96e42.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous coward")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469560")[#strong[#text("anonymous coward")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("It’s scarey to see that politics bedazzles even a Fields Medalist.")

#text("The parent post entertains a nice idea but, without first defining “remotely qualified”, it is totally moot (and probably a future source of embarrassment).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4809f67451f3fe4f954e44cf4f8ccfdb483c6384502214c3e1123a6d30208510-601eeb5546aec037238f5e212b7744a840dfbb522e8556b4ed13712c144ff139.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sheldon")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469562")[#strong[#text("Sheldon")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("Tao has made a fundamental blunder. He has mistaken opinion as fact. Mutual vs common knowledge as applies in epistemic logic is about facts (or ‘beliefs’ which are demonstratively provable as opposed to faith based beliefs) i.e. information to which everyone has (potential) access.")#linebreak()#text(" Facts inform us about the world. Opinions are reactions to an interpretation one has of the world.")#linebreak()#text(" Proposition 1 presented is an opinion not fact. Evidence in support of Prop 1 is merely a list of pros & cons to explain why or why not Prop 1 is the case. One may apply some math by attaching weights to the pros & cons and create some calculus to determine the necessary and sufficient conditions that would ‘prove’ or not Prop 1.")

#text("And, I am astonished even after Plato and Arrow’s Theorem, Tao believes, trusts, or favours still in any voting schema. Here in the United States, the Fourth Estate has implicitly imposed the winner-take-all because by limited focus upon just two, there exists the possibility of not breaking Arrow’s axioms.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0c8bf3aeed36cd4795c4d80a9a06a4aea64439e663c90731aad9071a009cc2c-a5e2691bec74961804cc9b9b303621f041578e0b30d52bd68078df3a97f02a32.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jamal")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469565")[#strong[#text("Jamal")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("Nassim Nicholas Taleb wrote something quite interesting on his Facebook page regarding the underlying motives to vote for someone like Trump. Thought it might be interesting to read for some of you commenting here:")

#text("“What we are seeing worldwide, from India to the UK to the US, is the rebellion against the inner circle of no-skin-in-the-game policymaking “clerks” and journalists-insiders, that class of paternalistic semi-intellectual experts with some Ivy league, Oxford-Cambridge, or similar label-driven education who are telling the rest of us 1) what to do, 2) what to eat, 3) how to speak, 4) how to think… and 5) who to vote for.")

#text("With psychology papers replicating less than 40%, dietary advice reversing after 30y of fatphobia, macroeconomic analysis working worse than astrology, microeconomic papers wrong 40% of the time, the appointment of Bernanke who was less than clueless of the risks, and pharmaceutical trials replicating only 1/5th of the time, people are perfectly entitled to rely on their own ancestral instinct and listen to their grandmothers with a better track record than these policymaking goons.")

#text("Indeed one can see that these academico-bureaucrats wanting to run our lives aren’t even rigorous, whether in medical statistics or policymaking. I have shown that most of what Cass-Sunstein-Richard Thaler types call “rational” or “irrational” comes from misunderstanding of probability theory.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1129c11c02535b3dd3b837e28485a83cb7917feffb121975baf46295ddce212e-c3eb21fd4d3b5ef8caf39c2614284b5e97d7c9ca9b68084519ce80f7a12885a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469615")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("I have been thinking about this. We have a number of things going on that are *clearly* sub-optimal. We have “civil forfeiture” which is anything but civil, we have the government apparently spying on the population, videos of police killing unarmed civilians, H1Bs process being abused, etc. etc. Political parties change, but the underlying problems aren’t fixed. I believe people want change in the worst way. (And that, unfortunately, is what they are voting for.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29884bbba47c6be14a754803ce5ef4f246acbf49de864658588ee8546cbd08c4-926f96a1e80ba6c336337d531a4bb56248108c322a0061d9db8b005b0901ac97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giampiero Campa")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469569")[#strong[#text("Giampiero Campa")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("I also think that Proposition 1 is true for most reasonable fitness metrics.")

#text("However i also feel that, since we don’t know the future, and since our models of how the world works are not perfect, we cannot totally discount the (very small but non-zero) possibility that Trump could turn out to be better (at least under some reasonable metric, and mostly due to unintended consequences).")

#text("Again, i think i am very very far from Trump positions (which -by the way- are themselves very unclear), but i though that some kind of discussion on what we mean by “fitness” could also be appropriate in this context.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29884bbba47c6be14a754803ce5ef4f246acbf49de864658588ee8546cbd08c4-926f96a1e80ba6c336337d531a4bb56248108c322a0061d9db8b005b0901ac97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giampiero Campa")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469570")[#strong[#text("Giampiero Campa")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("Anyway, that being said,practically speaking, it’s not really possible to make the case that he is more competent that Clinton for the presidency.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f09de86d71f177e40d2a573813d7807793923114f3d4d38af4e7eb591de87cb1-11ba9ceac01bcdb452452f86f1d53d15e32d792af281a262c154b50e4d180aad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AG")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469571")[#strong[#text("AG")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("It is probably worth remarking that in the Andersen’s tale “common silence” was rooted in the cognitive dissonance between “mutual knowledge” of the emperor’s nakedness and “common belief” in the lie perpetuated by swindlers-weavers, asserting that “their cloth had a wonderful way of becoming invisible to anyone who was unfit for his office, or who was unusually stupid”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/355b7a34448edbc25b48c6d93b464cd99e886a2407b7e06cd1fb9642ac65745c-3ccd155508f869e71c11a6f0709f11b64ce8085bd15789fb8d2a564aeb052e35.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of easy")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469573")[#strong[#text("easy")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("Professor Tao:")#linebreak()#text(" I have great respect for your achievements.")

#text("I feel immigration is the only issue holding Trump up. White Americans feel one of two $1.$ they are superior or $2.$ they are not responsible for what their ancestors did.")

#text("On the other hand why wouldn’t they not support trump? He promises a racial composition that made America great in 1945.")

#text("He promises fairness – why do not latino immigrants face the same rules as other immigrants and in what sense are they special? In fact the white or minority democrats do not like people like you and me who are in a sense well qualified to do skilled jobs. They only like latino immigrants essentially because they are low skilled and not a threat to them So they are also racist.")

#text("Please get down from your glass house and cast your stone. You need to stay away from John Oliver and other BS and talk to the people who know the issue.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/355b7a34448edbc25b48c6d93b464cd99e886a2407b7e06cd1fb9642ac65745c-3ccd155508f869e71c11a6f0709f11b64ce8085bd15789fb8d2a564aeb052e35.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of easy")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469574")[#strong[#text("easy")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("I do not like Trump but he may win. Why do not latino immigrants face the same rules as other immigrants and in what sense are they special?")

#text("In 1986 they already received 300 year supply of green card allocation given for any one country in a single year. Why are they again seeking a 1500 year supply in one year?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/baea9228f020af2f828dbc74824425a1a952fc473015b9780c83838818da2777-3fdf195a907a0bf2f08c71110e29f844b0b1dc215a870640abe9783fdb140a62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469584")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("On the subject of common knowledge, you might enjoy Scott Alexander’s take: ")#link("http://slatestarcodex.com/2015/10/15/it-was-you-who-made-my-blue-eyes-blue/")[#text("http://slatestarcodex.com/2015/10/15/it-was-you-who-made-my-blue-eyes-blue/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a3efe64c12b3af467b5d92e6639ab4d9afb862120ed59c2a0524237cbc523799-cb0d00a4c7da65c4f38e1a7e704d02d34a9ff0aa0ddc3d2d89218fe64e17162c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AnonSoICanSpeak")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469585")[#strong[#text("AnonSoICanSpeak")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("It is a very interesting point about how people can look at the same thing and see something totally different. I have always regarded myself as solidly left of center, (and always will), but over the past couple of years I have really opened my eyes and realized that in the USA, virtually all of the racism, bigotry, hate speech, misrepresentations, bullying, narcissism, lack of empathy, abuses of power, violence, criminality, attacks on free speech, insanely nutty ideas, and cult-like activity come from the Democratic Party and The Left in general. I’m shocked to realize that The Left in reality, bears so little resemblance to what I always thought it should be it should be. It’s time for The Left to look inwards upon itself, and try to completely change into a force that can make the world a better place, instead of the horrifyingly negative force it is now. I believe I am one of millions of traditionally left of center voters who have opened their eyes and in this election will vote for Donald Trump and the Republicans, in the hope that the Democrats/Left, while out of power, will see that they absolutely have to purge their many toxic components. It really comes down to how many left-leaning people will permit themselves to see how it really is, and will speak out to permit others to see it too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2504db315deb68c5a2adb289f12fe168277f3dd5caef1f7ab7c0d6c5eda557fb-52f39f2c5b0b31587ab68ebc2b16a7c421fe6c0b71a512cb91dc74f6313bfdc2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hanzo")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469598")[#strong[#text("Hanzo")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("I think, this is not the real issue. Maybe a fair election in U.S. is just like an operator acting on an ensemble, probing how people model “success” in their social construct. Then, in this operator probe the Donald Trump term is so strong because the ideology he represents is so strong. It doesn’t matter if he is a liar, a cheat, there are simply too many people that want to be like him. He is the definition of success for many.")

#text("This is exactly the case how Berlusconi stayed in power in Italy for so long, everyone knew he was corrupt, everybody knew he was bad, and everybody complained, but at the same time, he was the idea of many Italians wanted to be, rich, powerful, surrounded by young girls.")

#text("Also, in my country, it is how the current president stays in his position, although he is commonly known to be corrupt, and it is common knowledge that he is ruining the country, the absolute hard-handed power he represents is apparently how my kindred want to be.")

#text("Thus, Donald Trump is not a cause. It is a consequence. And symptomatic cures rarely work. I think it is time USA should start thinking about how their society is organized, if Donald Trump is really a problem.")

#text("He is,")#linebreak()#text(" Because he is one of the signs of the collapse of the western culture. The demagog, as Plato wrote.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1129c11c02535b3dd3b837e28485a83cb7917feffb121975baf46295ddce212e-c3eb21fd4d3b5ef8caf39c2614284b5e97d7c9ca9b68084519ce80f7a12885a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469603")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("Proposition 2: Anyone who runs for president in the modern times is de facto not qualified.")#linebreak()#text(" Proof: Obama, Donald, Hillary.")#linebreak()#text(" Proposition 3: There is a solution to this problem.")#linebreak()#text(" Proof — I wish I could give a proof to this. Anyone have any ideas?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11a014ab4ecb744299a6b542a1fa739d699affd9a23ec8e35d5cd39f6364ab43-f14c373e7464c0479d5f19b8457725235601d80e31e1ef8a2101b2acb890d724.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sf")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469608")[#strong[#text("sf")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("1. Is voting Trump (in the primaries) not rational, insofar as it achieves the voter’s goal of national attention focussing on a forgotten segment of the population? Having major media sitting up and taking more notice of these forgotten segments may be one big step to dissipating his momentum.")

#text("2. In game theory common knowledge usually applies to “the rules of the game”, but a lot of the (unofficial) rules in this election are being rewritten in real time — so even the rules are not common knowledge anymore. This is somehow reminiscent of the EU’s deficit problems, where the unwritten rules are the only ones that count. Some politicians do refer to the (official) written rules only when its politically convenient.")

#text("3. Tao’s proposition 1 is meaningless until you say where we put the bar for being qualified. The point is that it might be too high for any realistic candidate, so the issue loses its force. Just because we’re used to mediocre government doesn’t mean that staying the course is a safe bet in the future.")

#text("Technically, ‘qualified’ goes beyond what ken(neth) mentioned — there are formidable obstacles to getting on the ballot, state by state, so the legal criterion really depends on having sufficient public support – it’s a democratic criterion rather than a competency based criterion. Usually its sufficient as a safeguard.")

#text("Competent vs Qualified")

#text("While “competent “ is probably closer to T.-Tao’s meaning, there’s no point in dwelling on semantics.")#linebreak()#text(" So where do we put the bar for competency?")#linebreak()#text(" Not causing nuclear armageddon? or not causing huge irreversible damage? But what about not reversing a slow continuing slide into growing inequality, and hopelessness for a large segment of the population? It seems that something has gone missing in the usual system of checks and balances; lobbies are able to manipulate government quite easily. This may be related to the sheer increase in the scales of the organizations involved, especially with colossal scaling up due to globalization and in high finance. My point is that Clinton needs a serious plan to reverse this gradual deterioration, if the Trump ‘bomb’ is to be defused. This would probably involve drastic measures by most standards. The lack of determination to advocate anything too drastic is her weakness when faced with the likes of Trump.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9906081d95a802c591ba0288c5fb28befa9ae076a9af98c48541ef6919fb84e4-301e31d3b6f06115bb7657331a399c735ea9639216abe72702a020669734edb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of O'Rafferty")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469609")[#strong[#text("O'Rafferty")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("Gil Kalai")

#text("Perhaps we can talk about the Jewish Values of Irgun and the “kind…”welcoming”…”tolerant” Jewish People of Israel.")

#text("Hillary Clinton is a bona fide war criminal. Trump won’t go to war against Orthodox Christian Russia. This makes him very qualified to be POTUS.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9906081d95a802c591ba0288c5fb28befa9ae076a9af98c48541ef6919fb84e4-301e31d3b6f06115bb7657331a399c735ea9639216abe72702a020669734edb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of O'Rafferty")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469611")[#strong[#text("O'Rafferty")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("To state the very very obvious:The Democratic Party is nonwhite identity politics on nonwhite identity politics steroids. The White Natives have noticed this, and they want for America the same type of race based-ethnic based National Origins Immigration Policy that Gil Kalai supports for his Israel. Imagine that, and Israelie Foreigner whose father was a high ranking member of Irgun lecturing Whitey about racism.")

#text("Terrence Tao")

#text("Perhaps you can tell us why you are so enthusiastic about Hillary Clinton’s Foreign Policy towards Conservative Orthodox Christian Russia?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86a4db85cd7a7c51d28e34169b63020bcd76d9a28b87776b13b0e3e28fb14223-8507e8b27ad1fb638eab586978e5bd1c1e24d01545aaeda1786024b4543ae92a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DP")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469613")[#strong[#text("DP")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("Dear Terry,")

#text("I hope you realize that the sharp way your formulated your opinion, combined with your influence within your department and your university, essentially silences and intimidates anyone (especially the tenure-track faculty) holding a possibly different view.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9906081d95a802c591ba0288c5fb28befa9ae076a9af98c48541ef6919fb84e4-301e31d3b6f06115bb7657331a399c735ea9639216abe72702a020669734edb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of O'Rafferty")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469614")[#strong[#text("O'Rafferty")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("I just want to add that just recently Hillary Clinton viciously attacked Donald Trump for not showing a sufficient amount of over-the-top-violent hatred for Vladimir Putin.")

#text("During the 1990’s The Clinton Administration gang raped the Orthodox Christian Russian People with its neo-liberal economic policy. It is no big secret as to the ethnicity of these Clinton Administration Economists who forced this on the Russian People. And its no big secret as to the ethnicity of Russian Oligarchs who benefited from this mass gang rape of Russia.")

#text("How many Russians died from neoliberal shock therapy?..How many possible Russians were not born because of neoliberal shock therapy? Six million?…A Holocaust….don’t you think so Ben Golub?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9906081d95a802c591ba0288c5fb28befa9ae076a9af98c48541ef6919fb84e4-301e31d3b6f06115bb7657331a399c735ea9639216abe72702a020669734edb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of O'Rafferty")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-3/#comment-469616")[#strong[#text("O'Rafferty")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("The “Arrows Theorem” approach of Terrence Tao to the 2016 POTUS election is so way beside the point. Mega-CEO power has rigged the system….")

#text("The 2016 POTUS is all about Racial Identity Politics which is a direct consequence of the passage of the 1965 Immigration Reform Act.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdccaee97f82c5da1f8ed8bae161e6d8f3139813652b483f4dde495fc0619c87-20e2e9c3cb6faa44e6cf8e52679ced7202be1c219c3b005d1fbfd2bf16ed114e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469355")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Let me start with a common knowledge among regular readers of this blog:")

#text("Fact: Terry Tao is very smart, very careful, deep, insightful person, including outside of mathematics.")

#text("The question arises – why this particular post does not fully reflect such description? I have my own theory.")

#text("Hypothesis 1. This blog post is just a test to an undisclosed purpose.")

#text("If this is correct, then:")

#text("Hypothesis 2. Clinton’s campaign asked Terry Tao to find a good line of attack against Donald Trump.")

#text("If this turns out to be correct, expect a response from Trump:")

#text("@realdonaldtrump, Crooked Hillary is so desperate, she asked the brightest mind in the world for help! Sad.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e6264d9bc9110421451f6267f43c174477f82f584d7a9dc4e49f8dc659db96f-8cf49927ad6833cdf66e3a39ce25e50207fcccd932e746ed60b7be4bbfefcc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Nahay")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-474492")[#strong[#text("John Nahay")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2016")])]

#text("Bill – what proof is there that Hillary Clinton hor her husband has ever done anything illegal? None. I hate them, for all their extreme rightwing bias in favor of the billionaire Wall Street class. For hunting animals. For NAFTA. For being pro-corporate welfare. For not freeing prisoners.")#linebreak()#text(" But, there is no evidence that they ever did anything illegal.")

#text("All the Anthropogenic Global Warming (AGW) deniers have only themselves to blame when people openly declare that there is absolutely no proof whatsoever for anything. The Holocaust, 9/11, anyone ever dying, anything “illegal”, terrorism, the moonlanding, anti-vax.")

#text("The Principle of Explosion in Logic is the #1 Law of the universe.")#linebreak()#text(" It outranks ALL other human & physical & mathematical laws.")

#text("I proudly wear this button: “Bomb all prisons. Free all prisoners.”")

#text("Hero Timothy McVeigh & Dr Theodore Kaczynski tried doing that.")#linebreak()#text(" They fought for YOUR & my freedom.")

#text("So all you stupid conservatives have NO business LECTURING ANYONE to")#linebreak()#text(" worship & kiss the asses of “the troops”. Because NOBODY has to accept your THEORY that paid government soldiers have “hard” jobs, or that they fight for my “freedom” rather than against it. When they bomb a prison that holds me hostage, then you can claim they fight “for” my freedom.")

#text("Until then, I will decide who is courageous & has a hard job & who is fighting for freedom rather than against it.")

#text("But conservative extremists – such as Dems & Pubs – HATE alternative opinions such as these. That is why they always try to SILENCE antinatalist animal rights & prison rights activists.")

#text("EVERYTHING is justified from a logical contradiction.")#linebreak()#text(" And that includes contradictions with observed evidence.")

#text("Let’s see how “anti-authoritarian” you conservatards are now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f0aedc16bd5d8f308688ee704fd43937c66bf0afea96c3c33b860738f93522c-e649e9cf7468a7c42d182e079424fbff09af453dd0f7cbf6b2f6bd51a8e5b63a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469356")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("So if I am understanding you correctly…your claim is that there are lots of people out there who think that Trump is “unfit” (whatever that means), but would vote for him, unless they found out that other people consider him unfit as well? Or that if all the people who think he is unfit somehow banded together and were more public than they already have been about him being unfit, then those who currently consider him unfit would change their minds? I think there’s little evidence for either proposition.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdccaee97f82c5da1f8ed8bae161e6d8f3139813652b483f4dde495fc0619c87-20e2e9c3cb6faa44e6cf8e52679ced7202be1c219c3b005d1fbfd2bf16ed114e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469357")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("By the way, everyone at my university in Canada supports Trump, because it will make finding good job candidates much easier this coming year.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/427dec019c6c02612758c0254b62bf919f69d7b58053e628a51571479408f198-7594e3e4723ff9d1d64d36c34b5203a382a6f14aa2a79e21e465d0528440af70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dcohen")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469358")[#strong[#text("dcohen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("as far as mathematical rigor goes, even if it isn’t the purpose of the post, it may be better to replace “common knowledge” and “mutual knowledge” by “common belief” and “mutual belief”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37b0d08f5f2d055b7ff6b43e8ce260e37635cfbbe685fa2907d90221498f54b6-19e5e87510ddfbd262bdc70204c0df79bd34c022881ca327d67204cd74267fa7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin (@igriv)")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469359")[#strong[#text("Igor Rivin (@igriv)")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I am shocked that a person as intelligent as Terry Tao can be so unwise as to believe that life can be axiomatized, or that his axioms can be so misguided. I completely agree with Ken(neth) on what the qualifications are, and it is clear that Trump has them. It is also clear that while Trump is clearly less experienced in (say) foreign policy than Clinton, her experience has been one of unremitting failure – some would argue that this would make Trump more qualified. There is also the historical record: Obama had absolutely no qualifications for anything when elected (and has been a disaster, in my opinion, but he did get elected twice). George Bush had no foreign policy experience whatever, and again got elected twice. Bill Clinton’s only experience when elected was as a (corrupt) governor of a back-woods state. His foreign policy record turned out to be mediocre at best. He also got re-elected. GHW Bush was actually very experienced. He did not get re-elected.Anyway, I will not rehash wikipedia here, but just say that the vast majority of US presidents had no foreign policy qualifications whatever when elected. That’s democracy for you. You don’t like democracy, and like the “philosopher king” model? Well, that’s what they practice in France, and it is a disaster.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef9b90042017c21c418c17b6fb08bd509a0cad9672e14b0f1fa5d3c3f39a9f40-6354a726d6ff61183697d25055cd1a6b822f9688950db4e81372ba589c80affc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raskolnikov")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469567")[#strong[#text("Raskolnikov")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("That’s way too laudatory a description of the French model. :D")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b39fc56b8a1645bd105b0a64fab1915acb943530473582f96d10fc0c0ba1213-1f5a9b638db522473228aa4d674015abc52a2ec078c138de6c6f6e3341ec8421.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shecky R")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469360")[#strong[#text("Shecky R")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Me thinkest we can safely assume a number of trolls, sockpuppets, Trumpbots, and self-perceived Aryans are rushing in to defend the candidacy of this mentally-ill demagogue/business fraud.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16384430a77fb046424a08371dc0ecbd3c8dcf9441d1db1559596a6362eef76c-12c40458c1bebbd048bc8848a7c52c341b7dbd7b7ffcc9826425d36b9502ff00.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of eventhisoneistaken")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469372")[#strong[#text("eventhisoneistaken")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Is there a way of finding out the true identities of these Aryans, so we can publicly shame them and possibly get them fired from their jobs?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f6052589def0686ac005d51d6dd2662327a5b80a735c1204788117741e74e0a-400e343875b1446dc8c0e3346a370578c99505d9c9b59ccbb9d2e04f83678c5f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anton")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469602")[#strong[#text("Anton")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("Nah, that would be inhumane. With their intellectual abilities, they would be hard pressed to find another job.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469361")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Genius in math, dumbass in politics")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e6264d9bc9110421451f6267f43c174477f82f584d7a9dc4e49f8dc659db96f-8cf49927ad6833cdf66e3a39ce25e50207fcccd932e746ed60b7be4bbfefcc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Nahay")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-474549")[#strong[#text("John Nahay")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2016")])]

#text("You are a fucking subhuman dumbass hypocrite rightard if you force laws upon other people, but then CRY & WHINE over animal rights activists & vegans HYPOTHETICALLY passing laws against you eating me.")

#text("Only SUBHUMAN TRASH WITH NO FEELINGS vote republican or deomcrat.")

#text("Only SUBHUMAN TRASH WITH NO FEELINGS whine more about HYPOTHETICAL laws but say nothing about EXISTING UNJUST laws,")#linebreak()#text(" such as fossil fuel companies (coal, oil, gas) & meat industry getting")#linebreak()#text(" BILLIONS of dollars in free welfare from taxpayers to DESTROY")#linebreak()#text(" the country & civilization & technological progress just to make")#linebreak()#text(" subhuman reps & dems rich by climate change")#linebreak()#text(" and breed & torture & murder billons of animals.")

#text("Who the FUCK are you to demand that I praise & honor")#linebreak()#text(" paid government soldiers, no matter whether I agree or disagree")#linebreak()#text(" with whatever particular war they’re fighting?")

#text("Who the FUCK are you to demand that I praise & honor")#linebreak()#text(" paid government police, to imprison & take away my freedoms?")

#text("Who the FUCK are you to dictate to me")#linebreak()#text(" that I mustn’t support ARMED VIOLENT REVOLUTION")#linebreak()#text(" against fossil fuel addiction & the breeding of billions of animals for meat & fur?")

#text("The #1 FUNDAMENTAL BULLSHIT that conservatards")#linebreak()#text(" are too stupid to get through their heads:")#linebreak()#text(" that it is ok & heroic & justified when soldiers in YOUR nation")#linebreak()#text(" kill & maim & bomb & gun down the enemy")#linebreak()#text(" & ok if civilians long in the past or in OTHER nations")#linebreak()#text(" may use violent armed revolution to end an injust,")#linebreak()#text(" but “not ok” if civilians were to use violent armed uprising")#linebreak()#text(" in YOUR NATION RIGHT NOW.")

#text("No. Sorry. Police & soldiers have easy “jobs”.")#linebreak()#text(" It is just a THEORY that their jobs are hard.")

#text("It’s rightwing conservatives – i.e. muslims, the military, police,")#linebreak()#text(" all mainstream media, governments – who have ONLY THEMSELVES")#linebreak()#text(" TO BLAME when antinatalist animal rights vegan supporters")#linebreak()#text(" don’t take THEIR non-existent unimportant causes seriously,")#linebreak()#text(" don’t give a fuck about “terrorism” or rape or racism or sexism")#linebreak()#text(" or false accusations of rape/racism, etc –")

#text("They DEFEND the status quo of ignoring animal rights")#linebreak()#text(" & climate rights because they deny the reality or")#linebreak()#text(" do the Fallacy of Relative Privation (FRP).")

#text("So TOO fucking bad that nobody will believe their FALSE THEORIES")#linebreak()#text(" that cops & judges & prison guards & the military soldiers “suffer stress”. There is NO proof NO evidence that")#linebreak()#text(" ANYONE has EVERY done anything “illegal” in the history of the world.")#linebreak()#text(" That is just fearmongering BULLSHIT to take away our freedoms.")

#text("If you want to torture & murder animals for meat & destroy the climate")#linebreak()#text(" for future people & the poor right now, YOU should be gunned down,")#linebreak()#text(" tortured & killed for YOUR STUPID SELFISH cause.")

#text("FUCK you – I have ZERO obligation to believe in this myth called “terrorism” or “terrorist”. Just fearmongering words that freeloading")#linebreak()#text(" extortionist judges, lawyers & cops use. Even mentally inferior")#linebreak()#text(" subhuman shithead Alex Jones, conspiracy idiot & AGW-denier,")#linebreak()#text(" stands up to big government using the “terrorism” excuse to")#linebreak()#text(" take away our freedoms.")

#text("Glad to see so many downvotes: that means I am telling the truth")#linebreak()#text(" that the extreme rightwing media never talks about.")

#text("The Law of Explosion in Logic justifies everything.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf050c0f21e27ed8954be1ff385eb0b74d0a6b71cfd26581871b474282d00220-c4e8e7872c2afb4f1017cfc7a379f98b485f55de535ed5d1d5d84f392ae0affb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Invisible Mikey")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469362")[#strong[#text("Invisible Mikey")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("In addition to being a thought-promoting article, this has to be the (in the voice of Comic Book Guy from “The Simpsons”)")#linebreak()#text(" Best…comment section…EVER!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469363")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("This is a well-thought and well-written post, both in the obvious opposition to Donald Trump and his dangerous racist, anti women, anti-democratic and violent rhetoric and actions, and in the timely support of Hillary Clinton who can stop Trump. Yes she can!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cd4a5f0669370f9571e27716411c50d44da067ae9dfc45a669050e7efbb750c-33bad2d03393884655498be8a8b01b5295ec0a309b5f7603256efc2e5acc67ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manuel Bernardo")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469364")[#strong[#text("Manuel Bernardo")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Mr. Tao, I think the crux of your argument lies in whether Trump’s carefree displays of ignorance and uncouth behavior are genuine or calculated. You assume the former, asserting that is incompetence must be mutual knowledge but an emperors-new-clothes scenario is preventing people from admiting it.")

#text("In fact, I don’t think we can assume mutual knowledge based on the evidence we have. His supporters don’t seem beffudled. They argue very clearly that their candidate has demonstrated throughout his campaign to be shrewed and confident in a manner that makes him look fit for office. And when analyzing Trump’s run over the last year a pattern emerges which seems to substantiate this. Every one of his more jarrying declarations or attacks turned out to have a positive outcome for him. When he called Mexican immigrants “rapists” everyone assumed it was the death knell to his campaign – but it gave him a projection in media whose benefits outstripped our indignation, making him shine among reactionary sects of American society, at a time when other candidates didn’t have a well-established following. So this and many other outbursts gave him a headstart in the race – he has since toned them down considerably. His attacks on his opponents had always a devastating effect: every time one of them was poised to finally take down “the clown”, Trump would successfully brand him as week (Low-Energy Jeb), unprepared (Little Marco) or dishonest (Lying Ted). Again, now that he has clinched the nomination he’s all cordiality and good-will toward his Republican peers.")

#text("Let’s agree that Trump is gleefuly ignorant, bigoted, crass, etc, and even that Proposition 1 is valid – he’s unfit for the Presidency. But can it be said that what I described before was done by chance? Doesn’t it rather seem like he was ingenuously manipulating the media in his favor? You would have to predicate a considerable number of happy coincidences to view his behaviour as random – logic would perhaps dictate a more simple explanation. After all, a man might be an ignoramus and still be astute. Trump has led many to see his underhanded tactics of manipulations as a sign of ingenuity and strategical ability. So, even though Proposition 1 might be valid, I don’t think it can be said for certain that his incompetence is mutual knowledge – which means it’s unlikely to became common knowledge, as you hope.")

#text("I’d also like to say something about your “et quoque” clause. While I understand your motive, the fact is most people don’t vote because they support one candidate, but rather because they dislike the alternative. So if you remove “et quoque” from the equation you won’t be able to see the big picture. In fact, you can’t fully explain Trump’s success without facing Mrs. Clinton’s shortcomings.")

#text("P.S: I agree that Trump’d be a terrible President. I hope it’s clear none of this was an endorsement. In fact I’m concerned ignoring the man’s obvious political talents will help clear his path to the White House – and so far it’s been easy peachy, I fear.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469365")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("This is how a would-be president talks? This is from just one article in Huffington Post about Trump’s changing positions. – Saith the little boy who doesn’t know to keep his mouth shut “the emperor has no clothes and talks Palinesque gibberishy word salad.” (A new phase coined just for Trump.)")

#text("“I didn’t mind surgical. And I said surgical. You do a surgical shot and you take him out.” Face the Nation")

#text("“We would be so much better off if Gaddafi were in charge right now. If these politicians went to the beach and didn’t do a thing and we had Saddam Hussein and we had Gaddafi in charge, instead of having terrorism all over the place, we’d be — at least they killed terrorists, alright?” Trump in February")

#text("“It’s horrible what’s going on; it has to be stopped. We should do it on a humanitarian basis, immediately go into Libya, knock this guy out very quickly, very surgically, very effectively, and save the lives.”")

#text("“I was for something, but I wasn’t for what we have right now. I wasn’t for what happened. Look at the way — I mean look at with Benghazi and all of the problems that we’ve had. It was handled horribly … I was never for strong intervention. I could have seen surgical, where you take out Gaddafi and his group.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72ccd260d0ae89f7ae7cb078ff81a79b303c0c4755b87ec815cb652f8f3aeffa-ea45c322ea1f44e8d270a2207ab511deb39b3ecfea207f29306e4c2e1b17a894.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christopher Chang")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469367")[#strong[#text("Christopher Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("One of the best things about mathematical culture is that there’s no shame in presenting a proof that you honestly believe is solid, but actually isn’t, and then correcting/retracting your statement in the face of counterarguments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bc3ca449c2ebc83a53332b20e9736b24e10e2a0cfbf189423336e5e695473b5-8df4d657c1dba3ec50191b7c242866c5f037feb2f5bb0fa2baf2846042f64873.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ccarminat")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469368")[#strong[#text("ccarminat")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I appreciate your taking a position against Trump, and yet I think your analysis misses some important points.")

#text("1) The Trump phenomenon is not just a consequence of the voting system: different voting systems have produced similar results, lately. For instance here in Italy Mr. Berlusconi was PM several times, and Trump really looks like a conformal copy of Berlusconi;")

#text("2) logic often plays very little role in politics, so trying to analyze politics through the lenses of rational thought in the end might be misleading.")

#text("I recently happened to read an interesting article on the Trump phenomenon on the Guardian: ")#link("http://www.theguardian.com/us-news/2016/may/19/welcome-to-the-age-of-trump")[#text("http://www.theguardian.com/us-news/2016/may/19/welcome-to-the-age-of-trump")]#linebreak()#text(" I find it is really worth reading.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d22d51c891432bd8cd9fe700ef6e3d5432e77baeaf3dab616bc11ec798c4dbd9-c756ca7a017ec0fbc6c015bcbe1d3020b75f7706943e1b3a2da3984e7a4c9763.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of paolgiacometti")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469369")[#strong[#text("paolgiacometti")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I think that Donal Trump election is a best to be example of a self-fulfilling prophecy")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Self-fulfilling_prophecy")[#text("https://en.wikipedia.org/wiki/Self-fulfilling_prophecy")]

#text("from the moment the first patient zero stateted proposition 1 a series of temporary consensum wave has gone.")

#text("As Italian we had the same experience with Berlusconi who is for background and aspiration very similar to Trump.")

#text("For Italy the prophecy was true and as prime minister Berlusconi had something like 16 years of charge…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/427dec019c6c02612758c0254b62bf919f69d7b58053e628a51571479408f198-7594e3e4723ff9d1d64d36c34b5203a382a6f14aa2a79e21e465d0528440af70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dcohen")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469370")[#strong[#text("dcohen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I do not follow the us campaign in detail, but it seems to me that given the somewhat provocative or erratic statements that trump makes, it is probably fairly hard to predict how things would go should he be elected")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f16043cba735cb67426abd19ea8875a97355ff672d56dba6c9fe84c73c54c60d-e851a1af43fbaaeddb186bf794ba9744ab721711a21340284d5b5680bd6de963.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lee")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469371")[#strong[#text("Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I dont understand why using Hillary speech as evidence, which is nothing but to weaken your proposition. Anyway, you are only a mathematican, who tend to fail ay politics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469374")[#strong[#text("Col Rollbuhler (@col_roll)")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")]

#text("Where is your evidence? Even so it is a bunk claim, because those who have been president who are “fit” for office have not done what was necessary. If I put a key into a machine and it just electrocutes me. I am going to willingly not put a key that fits into the machine, and try to gum up or jam the keyhole so it doesn’t happen again.")#linebreak()#text(" “Trump isn’t a politician, he can’t be president.”")#linebreak()#text(" That is why he ought to be president. You have to go back.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e23ea31230ea71ae18ec0dbd2a8a603ed2a04a629e852bb276b96c9ba2b2e2f1-e89718d62ddbc42fd300ead58f018902393318d642672627d62f6cced1c3b79c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469379")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Terry,")

#text("I think it’s worth exploring the voting system question further.")

#text("The American presidential election system is much more the product of ad hoc evolution than intelligent design. It’s so complicated that it seems hardly plausible that it’s a great choice. On the other hand, it may or may not be a terrible choice, in general.")

#text("I personally am more enthusiastic about approval voting than runoff voting, instant or otherwise. My impression is that approval voting is centrist, while runoff voting is fairly non-centrist. However, I am no expert in this topic.")

#text("It seems hard to argue that “anything but the American system” (among modern voting systems) necessarily works very well to prevent the election of terrible leaders. Trump has been compared to Berlusconi, who came to power in Italy in a reasonable standard proportional representation system. Proportional representation is has an obvious mathematical motivation, certainly more so than the American system. But an abstractly compelling solution to any applied problem can be too clever by half in the real world; it can be worse than a much more arbitrary ad hoc solution.")

#text("Maybe partly to be provocative, I could argue that the Republican primary this year was a quasi-runoff system that knocked out wiser, more centrist choices in favor of two unqualified populists as the last men standing.")

#text("Certainly the American voters now have an important responsibility to elect someone else (presumably Clinton) instead of Trump. But I’m not sure that that dramatic concern shows weaknesses in our election system, even though I certainly agree that it has weaknesses.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6edd511a5db87d7a918f6c3f762fe7a39a9815a870366d2c20378dc56c7050b2-506729bbe63c6822a164c838564c8b4523f9d9b77a7d70563b2065938cf886be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grizzlez")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469380")[#strong[#text("grizzlez")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Your preamble was irrelevant and weakened the blog post by making it inaccessible to all but the choir. Why say it openly, if they are your only audience. What you needed to say was what you eventually said:")

#text("I feel that it is time for the charade to end: Trump is unfit to be president, and everybody knows it. But more people need to say so, openly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c18a97abbec7e74bc762cf198501d91639cd314eafdf0ddb11c0c4e38902a39-2724fc75f9b2f88e8e8fc3ba88942046683efafcfcfca092c094fefc056b8767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill Rider")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469381")[#strong[#text("Bill Rider")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("While I agree with the general sentiment of the article, I believe the concern is slightly misplaced. Mr Trump is a horrible person expressing horrible views based more on a media impact and ratings ala reality television than a politician. He is a thoroughly modern candidate perfectly suited to our modern, vacuous, anti-intellectual, and anti-eite populace. He is most likely committing the single great con job in the history of the Nation. If so he has a certain level of talent while awful and malignant, it is certainly historic in caliber.")

#text("He isn’t the real problem. The real problem is the number of Americans willing to vote for him. Without their willingness to vote for such an utterly and completely repugnant human the problem of Mr. Trump’s suitability for office becomes moot. The level of vile world view, intolerant and/or racist sentiments, and outright ignorance of the voting public is an indictment of the American population, educational system and culture. This should be the target of our collective ire and fear. If not, Trump they will elect someone who is even worse.")

#text("Trump was heralded by another blithering idiot Sarah Palin. She was one of many completely incompetent, anti-intellectual know-nothings to be elected to a variety offices across the nation at all levels of government. Trump is simply the natural step backward from the political horror show unfolding for the last three decades.")

#text("People who make the argument that Mrs. Clinton is the same or worse than Trump are the same ones duped by our poisonous political process. We are being played for fools by Trump and the media. Mrs. Clinton is by no means perfect or perhaps even desirable in a perfect World. We don’t live in a perfect world as the viability of Mr. Trump’s candidacy terrifyingly proves.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c18a97abbec7e74bc762cf198501d91639cd314eafdf0ddb11c0c4e38902a39-2724fc75f9b2f88e8e8fc3ba88942046683efafcfcfca092c094fefc056b8767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill Rider")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469786")[#strong[#text("Bill Rider")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2016")])]

#text("This comments section ! What an incredibly depressing commentary on humanity.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ca1f66148acbda6beb4c04f89c2094f8f1d2f2fda37ae736d9a01f8900e619b-86e56d18414d3f6cbafd9df3c84b2fd120022c59ae5b5e1999f4997c94bf6ee0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Holden McGroin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469382")[#strong[#text("Holden McGroin")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("This is neither a solid piece of mathematical reasoning nor a well-articulated piece of political commentary. I’m not sure which Mr. Tao intended it to be. All it boils down to is a mere assertion of his politics couched in logical form (use of the pretentious phrasing “proposition 1”) as though this were something to be deductively proven.")

#text("Mr. Tao should also tell us what he believes would constitute a remote qualification – the words used in “proposition 1”. Since apparently this proposition is going to be proven to deductive certainty, one should expect a full fleshing-out of the word “qualified” here, so as to prevent ambiguity. I might recommend a checklist format to assure complete transparency. In addition, Mr. Tao should feel free to speculate as to why each of the qualifications on this imagined checklist are necessary to hold office.")

#text("Nonetheless, it is always quite lively to point out that even those academically-minded people, where people naively expect them to hold sophisticated thoughts in fields outside their occupation, end up doing nothing more than regurgitating trivialities. Here, we observe Mr. Tao’s espousal of the trivial statement “Trump is unfit for office (whatever “fit” means)” along with a case which is made no better than a bungling political commentator. It will also be amusing to see particle physicists, organic chemists, algebaists, and other academics step outside their limited domains of expertise to offer us their opinions and guts feeling, masquerading as sophisticated and informed political positions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/608301e60fab2bd58541c2042c695aa15bcb825d453f8e352e9d464c6bac6e01-4f6462f98a0299791f129538419f9212dd94b4db819cac7db1aa97882002fcbc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ken(neth)")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469394")[#strong[#text("Ken(neth)")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I don’t think it was necessarily meant to be well-reasoned or mathematical. I took it more as a John Stewerty expression of political concern.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469383")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I am not sure that the mutual/common knowledge distinction applies to Trump supporters so much as Sanders supporters. It is mutual knowledge that Bernie Sanders has lost the Democratic primary, but it is not common knowledge yet.")

#text("After Tuesday and California’s primary it will become common knowledge that he has lost and that will likely lead to his conceding the contest.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/789553c649aae79816a4177aef22e37eb48972ba848b19737ae5886f72587151-7c518c666ce338d37c43859c829e234dd1a1752d5ad9b55754d0ff434e5e0ed3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brent")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469385")[#strong[#text("Brent")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Hi Terry,")

#text("I’m going to have to outright reject your premise altogether because you aren’t working from provable fact, but a narrative constructed from facts, which itself is composed largely of something I would call half-truths. See here for a well constructed counter narrative using the same set of facts. ")#link("https://www.youtube.com/watch?v=Gw8c2Cq-vpg")[#text("https://www.youtube.com/watch?v=Gw8c2Cq-vpg")]

#text("The idea that people will look at the same set of facts and can derive similar conclusions is a flawed one. What your argument misses is that many people who support Trump simply cannot say so lest they be branded with the same bywords (racist, sexist, islamophobe)of the popular media narrative. You seem to be mistaking the current era group censorship as people accepting the idea that this is “common knowledge” that Trump cannot lead is a flawed one. You see, you yourself face ZERO real-world backlash for writing a blog post criticizing Trump whereas anyone from an academic on down to a factory worker could face social and even career repercussions for endorsing Trump in even hushed, non-committal tones. Your error is mistaking this media enforced social bubble as solid ground from which to derive fact. You yourself may have friends and co-workers who have looked at his policies and determined that he is the one they most agree with. They would never tell YOU though. For you see, the only “common knowledge” is that publicly ENDORSING Trump is anathema.")

#text("To declare Trump for all his bombacity to be unfit for the office of president, more or less displays a historical ignorance of the characters of people who have held the office.")

#text("LBJ would regularly expose himself.")#linebreak()#text(" JFK had affairs.")#linebreak()#text(" Thomas Jefferson and Sally Hemmings.")#linebreak()#text(" Bill Clinton.")#linebreak()#text(" Nixon.")

#text("People like Scoundrels. They also like successful people. Trump is both.")

#text("I think you are truly overestimating the public’s trust in the media and equating it with your own possibly censored social feedback. It really resonates poorly with some when Trump is attacked unfairly (e.g. Trump had 4 casinos file for bankruptcy in Atlantic city, whose gaming and resort industry completely crumbled not long after he left – the problems were not unique to Trump); out of about 515 entities and companies he controls – this last part is usually left off to paint him a some sort of ineffective charlatan, by people like John Oliver, who is an actual charlatan when it comes to making his case against Trump).")

#text("The man has turned millions into billions and survived many recessions, on top of the fact that he has been espousing the same economic policies since the 80s and the last slew of ineffective leaders seem to despise him.")

#text("That is enough for most people – however it is not “common knowledge”. Yet.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ca1f66148acbda6beb4c04f89c2094f8f1d2f2fda37ae736d9a01f8900e619b-86e56d18414d3f6cbafd9df3c84b2fd120022c59ae5b5e1999f4997c94bf6ee0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Holden McGroin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469389")[#strong[#text("Holden McGroin")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("One could say we have got a scoundrel in both parties and one of the two has a whole family history of scoundrelry. And we Americans will have the option to give our nation a total of 12 years from this family of villains and have the man assume the dual role of president and first man. In fact, it may give us the opportunity to see the Clintons carefully select their interns to Bill’s tastes and also see to it that the oval office turn into one big cathouse.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c978ae119cf264abfb14b750b424b42f3028b81c566ed2cfe784a4fb152dbcbb-93dc944583e279071c5ba85e6b16807d05f350aa9dca7f9189939d7f121289c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bowman")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469386")[#strong[#text("Bowman")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("“He says what we’re all thinking, but too afraid to say ourselves.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469390")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("You may have just neglected to add Reagan at the end of his term when he was in the early stages of Alzheimer’s. However of those you do list, only Nixon before he resigned and was drinking was too mentally unstable to be president. I argue that Trump is now mental unstable what with having a narcissistic personality disorder with enough characteristics to make it clinically significant to impair his judgment. I also did a little amateur handwriting analysis and based on just one letter it occurred to me that instead of being a conscious liar he is engaging in a lot of self-deceit. Check my blog….")#linebreak()#text(" By the way, I’m not a mathematician like just about all of you. I’m a retired clinical social worker and former mental heath center director who was led to this blog by my physicist friend.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ca1f66148acbda6beb4c04f89c2094f8f1d2f2fda37ae736d9a01f8900e619b-86e56d18414d3f6cbafd9df3c84b2fd120022c59ae5b5e1999f4997c94bf6ee0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Holden McGroin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469392")[#strong[#text("Holden McGroin")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("You analyzed his handwriting? Did you make sure to check the bumps on his skull and read his palms too?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469395")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I am working on the phrenology now but it is more difficult than graphology. I figure I may get good at it in eight or so years. While it has been calculated by someone, who like some who comment here wants to remain anonymous, that handwriting breaks down personality into a mere 300 types based on only 9,245 styles of letters and 345 other characteristics, analysis of the lumps and bumps and numerous locations where the same bump in location A may mean something entirely different in location B etc. in exponentially more difficult. Check out the chart: ")#link("https://en.wikipedia.org/wiki/Phrenology#/media/File:PhrenologyPix.jpg")[#text("https://en.wikipedia.org/wiki/Phrenology#/media/File:PhrenologyPix.jpg")]#linebreak()#text(" You can take an online course in graphology for under $100 and declare yourself an expert, or just fake up a diploma and announce that you’re an expert. To learn phrenology you have to be self taught, track down old texts, and find numerous subjects to practice on.")

#text("Seriously, the handwriting experts to actually make handwriting comparisons for law enforcement are probably do have some expertise.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ca1f66148acbda6beb4c04f89c2094f8f1d2f2fda37ae736d9a01f8900e619b-86e56d18414d3f6cbafd9df3c84b2fd120022c59ae5b5e1999f4997c94bf6ee0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Holden McGroin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469396")[#strong[#text("Holden McGroin")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I should think that the candidates will be very interested to know what those bumps on their skull mean. I wish you luck on this particular endeavor. Personally, I look forward to reading their tea leaves.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of serenus21")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469397")[#strong[#text("serenus21")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("“Proposition 1 is a statement which I think is approaching the level of mutual knowledge amongst the US population (and probably a large proportion of people following US politics overseas)”")

#text("Well, speaking of people “overseas”, I can tell you what a lot of people in Asia are thinking: we dread Trump, but Sanders is a thousand times worse. Why not do a hatchet job on him too?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/513ae7c5911180af342c32ffd0cfd428b0c2f14081b76cd7a08b7755b20ea25b-7e9982f0b2aaa1d33ce142cbadf999c4b03b65cf63046e5a1b74d58c496c6568.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Barry O'Neill")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469401")[#strong[#text("Barry O'Neill")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I’d be interested in hearing why you see the Emperor and the Donald as parallel. If a statement from a child can establish common knowledge in one case, why can’t explanations from Romney and many more do it in the other?")

#text("Also, the Australian system has a big flaw, to my mind. This can happen: Take the winning candidate and raise that person in some voter’s preference ranking. Rehold the vote, and that candidate now loses. That’s perverse.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70b97f18c9fb1409a127d04f9c6dfee4238b277b7d51ad62ab57377057154914-73bc2937d18fe1bd074e7bfeb0cf7c761885538d30e9510e942d2e805bb355af.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Noah Simon")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469402")[#strong[#text("Noah Simon")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Thank you for writing this. Sorry you are getting so much hate. Sometimes people forget/ignore that as mathematicians/scientists we have a duty to the world beyond just advances in our chosen discipline, and it is very heartening to see someone held in such high mathematical esteem taking this very seriously!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ca1f66148acbda6beb4c04f89c2094f8f1d2f2fda37ae736d9a01f8900e619b-86e56d18414d3f6cbafd9df3c84b2fd120022c59ae5b5e1999f4997c94bf6ee0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Holden McGroin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469403")[#strong[#text("Holden McGroin")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Surely, you mean “criticism”, not “hate”. No one here hates Mr. Tao and he is held in high esteem as an intellectual. However, if a professional academic steps into the political realm, he will be held to the same standards as anyone else. That means a poorly made case will be quickly sniffed out and attacked.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66f23f0f56bdf0086ce02130bbd54c3b761155e2ee9809be4455df2c425618ad-27db570b7a87447955af355454c4e8fb1769356d71b95a7c79c52e6870cdd615.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edwin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469407")[#strong[#text("Edwin")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Not a single one of the Trump defenders here have articulated a solid case that Trump would make a good POTUS. This is a pattern with them. I’ve heard much of these mystical mastikal “intelligent Trump voters,” but they seem as difficult to locate as Bigfoot.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469408")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("You don’t think any of them make a solid case because you dismiss them outright due to your bias. A couple of people made solid, good counterarguments in this thread.")

#text("In any case, it’s ridiculous to pretend personal opinions about a candidate “ought to be common knowledge” and that a speech by the opposing candidate is proof.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469410")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Prof. Tao basically says that Hillary’s speech is one “proof” among many that Trump is not qualified to be president, saying that Mitt Romney among other prominent people from both parties have also made this case. Tao neglected to mention that another prominent mathematician named Stephen Hawking also said the same thing: “He is a demagogue who seems to appeal to the lowest common denominator.” This was originally reported in the AP but since embargoed since it was released it before the tape was due to be released. You can find the article here however:")#linebreak()#text(" ")#link("http://bigstory.ap.org/article/c562d36dc0ea4e9eb6e7cfe155e1a6c7/physicist-stephen-hawking-baffled-donald-trumps-rise-0")[#text("http://bigstory.ap.org/article/c562d36dc0ea4e9eb6e7cfe155e1a6c7/physicist-stephen-hawking-baffled-donald-trumps-rise-0")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The child")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469409")[#strong[#text("The child")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Hi Terry,")

#text("From your posted proof, I see that you are not only a genius in Math, but also a genius in Politics. Maybe you have expertises in many other fields that we are not awaring of now but we would gradually see down the road. Given this post I would not be surprised if you go to Rio this summer and win some gold medals in the Olympics. Because you are a genius in Math so presumably you must be a genius in every other subjects/fields. Btw, do you have any other similar proof that shows whether any incumbents of any significant positions are not fit for their positions? If there were a lot, did you go back to check your proof? The danger here is that many folks repecting your work in Math tend to consider your opinions on other unrelated issues correct. That could be true, but is not guaranteed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469411")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Just as I posted the above reference Stephen Hawking, The child posted this….")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75b4d3e5971e93ddf3cd637096bf04aa405a527321064e6ee593bfcf26d3c854-ea7dd134bcec8410e689e782cff471f1b19174a9f9e39bf726f18ed909406188.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pct38")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469412")[#strong[#text("pct38")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Trump is the preseident that US needs now, and his politics he is succesfully proposing is so new that you fail to understand it. After the fall of Soviet Union, left parties abandoned supporting workers and degenerated into cultural Marxism and victimocracy (namely hating white men and painting women as victims, illegal immigrants as victims, homosexuals as victims…), fighting against free speech. After 25 years of this nonsense workers are understanding that the left turned into their enemy, and Trump is proposing that the former religious right will now defend their intererest. What we now see is a historical shift of voters from the corrupt left to something new that is badly needed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b712095acdd09411e4bcac3ca14c4586d808708686fefcb7f32ae9dbc5af4c9-34297a8522af6f4a25424ed196d5f8b4c23e27770275bc314d5e137c7185eb56.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chao")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469413")[#strong[#text("Chao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Dear Prof. Tao,")

#text("I think it’s safe to say Proposition 1 is not an actual proposition (even though you framed like it is); it’s an opinion at best.")

#text("But that’s not my main point here. My point is where is your rigor in this regard as we usually see in your posts and papers. Specifically, even if it’s a proposition, where are definitions of “qualification”, “remotely”, etc? And where is the proof?")

#text("Prof. Tao, it’s common knowledge that you have a lot of fans/followers, and you influence many people in different ways (whether it’s regarding math or not). So I hope, in the future, instead of making your point look like a rigorous argument by phrasing it as a proposition, you could actually apply the same rigor shown in your math blogs/papers to other things you comment on (not to the same extent, of course), especially when it’s posted in this MATH blog. This is because many people value your opinions, which they take seriously. And after all, you have great power (your intellectual, reputation and influence), so there must also come great responsibility.")

#text("BTW, Google+ might be a better place for this kind of posts. Just my 2 cents.")

#text("Regards,")#linebreak()#text(" Chao")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469417")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Like many examples of “applied mathematics” the way to judge Tao’s propositions is to what extent they contribute to understanding the situation. I think that the idea that there are many people who personally tend to see Trump as unfit but do not realize the extent that this is a wide held assessment rather than expressing ordinary politically-based claims before an election is very relevant to the situation at hand.")

#text("Of course, Trump himself contributes to the the crucial step from private to common knowledge (among many). For example, when he refers to a judge overseeing a lawsuit against Trump University as biased because of his Mexican heritage.")

#text("We can hope that the crucial turning point in assessing Mr. Trump will happen well before the election rather than after.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d18ba2704850eca0be01e2acd2a644f7cbe7dd653f3c64467681b537fe0dfcb-a2aef91f2bc6d436444f6b039fc464d97359c5c601fced3736705a2734b70b3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Smith")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469418")[#strong[#text("Sam Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("There is just one requirement to be fit for the US Presidency and that is if the majority of delegates vote for you over your contenders. Trump has already sealed the nomination making him more qualified than every other Republican who chose to run. Policies and what Trump or anyone else says is irrelevant to this fact.")

#text("However since you did use speeches to make your case so will I. Trump doesn’t have to order the wall built, he doesn’t have to ban Muslim immigration he doesn’t have to follow through with a single thing he’s said. The reason however, for him to say these things is because it is what the working class wants to hear and are willing to vote for. It is the basis of populism. You may find it uncouth but the working class have been betrayed by their leaders many times and are naturally rebelling away from the people who resemble them. Who better than a billionaire who appears to share their views while having the power and wealth to follow through with them?")

#text("You see the fatal flaw with your case for common knowledge is the assumption that it is common at all. You assume it is common so you choose to believe it rather than ask those voting for him if they share your common knowledge or have their own common knowledge which runs counter to yours.")

#text("Since your proposition based entirely on common knowledge is now debunked I shall go a step further and inform you that even if it was common knowledge that Trump is not fit to rule that does not mean there is no reason to vote for him above all others.")#linebreak()#text(" Politics is a game of appeasement not one of logic and mathematics. By voting for Trump your vote becomes a display for all other republicans that in future to claim your vote their mannerisms and proposals must be more Trumpish. In this way even if you do not believe in Trump but believe in what Trump preaches it’s in your interest to vote for him so next time a leader who is qualified to rule will champion those beliefs.")

#text("Please stick to mathematics, if you honestly thought the post you made held water in the emotionally not logically driven world of politics you don’t know what you’re talking about.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b689385b7e7b20b5eb4ce963f22b54ac82761d678d34dbf9d11b3f218e2e6d3-0c81cc83d34dab81b5e439724379351448bb000d2a59a3712aacaa8ca83d1c1c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kai")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469419")[#strong[#text("Kai")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Proposition 1. The presumptive nominee of the Republican Party, Donald Trump, is not even remotely qualified to carry out the duties of the presidency of the United States of America.")

#text("I agree with this statement. However there is fundamental flaw in this reasoning. It assumes that Presidents are lone cowboys responsible for all duties the POTUS is assigned by law. In reality many duties of POTUS are delegated to other people, thus POTUS capabilities are dependent on other factors, such as his advisors and people he surrounds himself with.")

#text("We could create simple equation with POTUS value being low, but add additional values for people in his cabinet compensating for the lower value of POTUS. Same thing vice-versa.")

#text("What I’m saying here is the president is as good as his advisors are. I have reason to believe that advisors Trump will pick will be good.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2158d5744d7f14c39f496c6df05751372a04da1eb8814ab2949a3e24171a37c-3d75a7dd66646c827fb34a7b9890d7d87716bbffbe363d8811913351e5396883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469420")[#strong[#text("Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("An case which excellently illustrates the distinction of those forms of knowledge and how bad things go if Terry’s proposed move between them does not happen is the science fraudster Meinertzhagen: “Everyone knew” that e was a criminal, so the museum staff in the tv episode below was asked to observe him secretly on visits, but as he was a public figure of highest esteem, his frauds damaged science seriously. Acc. to his biography below, his criminal behaviour was s well known that parents threatened their kids to obey orders, because “else Meinertzhagen comes to you”: ")#link("http://edge.channel4.com/news/2005/11/week_3/16_tring.wmv")[#text("http://edge.channel4.com/news/2005/11/week_3/16_tring.wmv")]#text(" , ")#link("http://scienceblogs.com/grrlscientist/2007/03/23/the-meinertzhagen-mystery-the/")[#text("http://scienceblogs.com/grrlscientist/2007/03/23/the-meinertzhagen-mystery-the/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11356900f4345a60b181eeffeaa6751d35df0b73641340e9e42523b35604af3a-f35605448c4019b84a9c8f01a6e26b40130a98ce97b248f0995874732ffc041e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469423")[#strong[#text("Matthew")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("“This is it, the apocalypse.”")

#link("http://pol.foundation")[#text("http://pol.foundation")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/610c00b543e70952d6f028c3ce24136411d76a12e66efb872b8e9f88463a9c72-65978122f0fd2fb7f5d7bbe1aea585d1e5ca47f411b84f55cf5990111f804291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Donny_Did_Ivanka's_Daycare")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469424")[#strong[#text("Donny_Did_Ivanka's_Daycare")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("An ostentatious dullard dictator for an Orwellian Dystopia in the throes of its destruction.")

#text("It’s inevitable, Mr. Anderson.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469427")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("In mathematics one proof is enough, but in politics …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d988e333c9bf589aee615cb9b5f071b3f7e9f12c0d82f347c836ee2ed0378f8-b7fe8486452deb4a3f335dfc15f927320efd01a2c8e46ce5600c249f43f086f5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A Logician")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469428")[#strong[#text("A Logician")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Luboš Motl has given a reply to this blog post:")#linebreak()#text(" ")#link("http://motls.blogspot.co.uk/2016/06/donald-trump-is-fit-to-be-president.html")[#text("http://motls.blogspot.co.uk/2016/06/donald-trump-is-fit-to-be-president.html")]

#text("That raises reasonable objections, and is more logical than this post.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/51a2069cd7997e481d487a899c84b2e08d65810c86acec9bf5f6dbcee496139f-133010fd9a6bbc1b6b34df5fe252fcc658d5279cf8d33a173e3a8f5c14565703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luca")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469684")[#strong[#text("Luca")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2016")])]

#text("Ahahaha!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16384430a77fb046424a08371dc0ecbd3c8dcf9441d1db1559596a6362eef76c-12c40458c1bebbd048bc8848a7c52c341b7dbd7b7ffcc9826425d36b9502ff00.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of eventhisoneistaken")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469430")[#strong[#text("eventhisoneistaken")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("I’ve counted 137 comments so far — not a huge sample size, but enough to do some non-trivial statistics. Project for an eager undergrad: classify the comments into (+) agreeing and (-) disagreeing with the post, and into signed (S) vs. anonymous (A). [This one would be anonymous, since the author is *hopefully* not easily identifiable.] What percentage of the (+)comments are anonymous vs. the same percentage for (-)? Any thoughts on why people would be unwilling to go on record either disagreeing with a famous mathematician or supporting Trump? I certainly know my reasons…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c193bd548f0e0af2c8e7a48fbf42ada16e8bef390bdd8c1452ed7b5d3d325c8-5bb97aa60fccd2d89fa2ff04a88e04427327bb252d667a4d434411fbb89887f5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hyfmath")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469431")[#strong[#text("hyfmath")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Reblogged this on ")#link("https://yufeng16.wordpress.com/2016/06/06/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/")[#text("yufeng16")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5dec8efd0c002aec8ab65de4853f93516069c613aa326780d47646ae12c2f82-617c40cca919db70277c54d6989dc524c6225f8da5e78254a6315f1daba7a16e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gwb")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469433")[#strong[#text("gwb")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("many think he does not have necessary and sufficient experience and or knowledge to do a acceptable job as president for at least 51% of the population, this has nothing to do with qualifications to be on the ballot as one of the named candidates (or in general to be counted as an eligible candidate )")

#text("there are three qualifications in the constitution:")#linebreak()#text(" “age, residency, and citizenship—that must be satisfied at the time of taking office.”")

#text("it is common knowledge that he meets these three qualifications")

#text("how good or bad of a job someone will do if they are elected president is entirely a different matter, it is subjective, not objective. Most presidents have lower than 70% approval rating, if it is an academic class, that is a fail.")

#text("who decides which people are fit to be president, the voters will, that is how democracy works.")

#text("for example, the voters decided that Sarah Palin was unfit to be president by not voting for her in sufficient enough numbers, however, she met the qualifications to be president so that votes for her are counted as valid.")

#text("all this aside, to your point, getting the vote is a major part of becoming the president, and all the republican candidates, regardless of how fit they are in other respects, have proven beyond all doubt, they are profoundly unfit to get the vote.")

#text("just imagine how much more profoundly unfit you would have to be at getting votes, for Trump, who is profoundly unfit at everything else, to get significantly more votes.")

#text("if common people are simple enough to be fooled by Trump, it should not be overwhelmingly difficult to figure out what they want and give it to them. each candidate knew how important it is to get the vote. if a candidate is not fit enough to figure out how to beat Trump in the polls, I don’t think that person is fit enough to be president.")

#text("It is the candidates job to convince the people they are fit. The polls are an accurate indicator of how convinced the people are.")

#text("If it was J. Biden or E. Warren, I would vote for them rather than Trump on their character alone, but I would rather vote for Trump than Clinton, so that maybe after 4 years of Trump, they will feel enough of a need to run for president to give the people what they really want.")

#text("I would rather vote for T. Tao than D. Trump, but T. Tao has not announced that he is running.")

#text("is T. Tao more or less unfit to be president than D. Trump. How should I know.")

#text("All I know is that D. Trump is qualified to be president according to the constitution.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37b0d08f5f2d055b7ff6b43e8ce260e37635cfbbe685fa2907d90221498f54b6-19e5e87510ddfbd262bdc70204c0df79bd34c022881ca327d67204cd74267fa7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin (@igriv)")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469442")[#strong[#text("Igor Rivin (@igriv)")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("You would vote for E. Warren, who got into Harvard by claiming to be an American Indian? Does not seem very moral to me…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7951c0aeddcbe67e28c64d83981fe95bfcdd8aafd8df37a8f21aa51385cb92a-fc73c327190f841e4d365db37ce978ff839396f3940307aa5716f03d9bdb2ea7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DP")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469448")[#strong[#text("DP")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Igor,")

#text("Bringing `morals’ into a discussion about Trump’s qualifications sounds a bit strange, don’t you think? I am undecided because I think Trump might be a good president, but even his supporters would not mistake him for a model if morality.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7951c0aeddcbe67e28c64d83981fe95bfcdd8aafd8df37a8f21aa51385cb92a-fc73c327190f841e4d365db37ce978ff839396f3940307aa5716f03d9bdb2ea7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DP")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469434")[#strong[#text("DP")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("I am an independent who generally votes D across the board. This is not a contradiction. I don’t feel tied to Democrats and, when they screw up, I am not defending them. I will try to explain why I am undecided between these two options: (A) vote D across the board; (B) vote for Trump and D otherwise.")

#text("My biggest problem with both parties is that, over time, the idea of what it means to be a Democrat or Republican became so rigid that politicians are now completely defined by these boundaries, even when it makes no sense. This is particularly pronounced in foreign policy (and here I don’t distinguish between D and R), where politicians treat countries and regions by inertia as if we still live in the middle of the last century. They twist themselves in knots not to admit that their position is incongruent with reality, driven by nothing other than political calculations. (To give an example, I would prefer if the US and the EU were friends with Russia instead of Saudi Arabia.)")

#text("Mrs. Clinton is a great example of such a rigid politician, and it is truly ironic than her biggest claim to being qualified is that she was the country’s Top Diplomat. If she wants someone like me to vote for her, she should stop emphasizing her inflexibility by focusing on partisan attacks. She should instead emphasize how her policies would address the concerns of all people, including those on the other side.")

#text("Mr. Trump is far less rigid, but he also needs to show that he is willing to listen to people on the other side, especially because he is so uniquely positioned to be the bridge between R and D. For example, if he is elected president and it becomes clear how unrealistic his idea to build the wall is, he is uniquely positioned to move GOP to support the national ID law. By the same logic, he is also uniquely positioned to make the rich pay more taxes. Now that the primaries are over, he needs to show that he is ready to adopt good policies of the Democrats. I want to see him move to the middle, and move GOP to the middle with him.")

#text("I know that it sounds like wishful thinking and one can argue that we should take politicians at their word. Perhaps. And maybe I will vote for Mrs. Clinton in the end, despite the fact that her judgement is often overruled by political calculations. But at this point my mind is open, and my decision will not be based on an abstract definition of who is qualified or not qualified.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7951c0aeddcbe67e28c64d83981fe95bfcdd8aafd8df37a8f21aa51385cb92a-fc73c327190f841e4d365db37ce978ff839396f3940307aa5716f03d9bdb2ea7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DP")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469435")[#strong[#text("DP")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("T. Tao is unqualified to be POTUS, because he was not born in the US.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469437")[#strong[#text("Did they expect us to treat them with any respect? The EU Referendum drones on.. | My Little Underground")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")]

#text("[…] and Northern Ireland being dragged into the slipstream) with Boris Johnson at it’s helm. Yet, like Donald Trump, it should be clear for all that Johnson isn’t fit to govern and should be held in the utmost […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/038a98dafd49f4ff803942e9f751e94c8425c7272efd054c69a976d1308908ee-2da49564d13287e2fa629da72a6e7978d289e67fd0172917e573133a7717ec67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469439")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("The constitution does not address “qualification” in the manner you speak. Eligibility is what it addresses. Trump is eligible. Everything else is up to the voters.")

#text("As far as I can tell, your Proposition is akin to all the adults telling the Emperor how beautiful his clothes are. Because in the privacy of the polling booth, the voters are saying something entirely different. However qualified Trump is, what do you think that says of Cruz, Bush, Walker, Fiorina, et al that he so easily beat them? Are they more qualified in your book? If they are more qualified, why would the voters be choosing the less qualified individual? The multiple candidates certainly help explain some early success, but how do you explain Indiana?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ef91d7079d1e5ad1b455b15ba1a033e7ab34a6edcb3b0cea6226eb8c99a759e-d7190e757b9682f47e2cb103e5d40cc4d85f9bb799d50f8843e73d83e0c5f372.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benjamin Cooper")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469450")[#strong[#text("Benjamin Cooper")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Donald Trump is proof that:")#linebreak()#text(" 1. Everyone should NOT be allowed to vote. Some level of competence should be demonstrated before every election/vote. People that seek to destabilize the world to further their own interests at the expense of others are indeed terrorists. Racists $\\subset$ terrorists should not be allowed to vote.")#linebreak()#text(" 2. Reparations and financial embargoes are necessary for this country to move forward. He has millions of supporters (they are all white supremacists- regardless of their race). Germany was punished for the holocaust, now they look upon the event with shame. Slavery was similar, however it took place over the course of 400 years. –")#linebreak()#text(" Donald Trump wants to make America “great” again. You can’t do that without hundreds of years of free labor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/25e20872a47eaad857186060b41857db9bda6841a80dab487f72e81fbb8fa6dc-fb98cc2f980942636fc267f6825f63eb627c59245cf4f885240035f1ab29f9bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tony")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469453")[#strong[#text("tony")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("The argument for Trump is simple: He is not Hillary. You mentioned Hillary’s speech, well, let’s look at the actual content: War, and more war.")

#link("http://www.counterpunch.org/2016/06/03/hillary-and-the-military-industrial-complex/")[#text("http://www.counterpunch.org/2016/06/03/hillary-and-the-military-industrial-complex/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75bd236a64262b5bf6e9a327bf58ad68ebcdeac37c225539347a3fbb7bda444e-1b7b08af4124a2f815580ea6068d664fd8d787c7fef8f3c440412f10c225f7f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Visser")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-2/#comment-469454")[#strong[#text("John Visser")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Dear Terrence,")

#text("As an engineer, my initial reaction to your blog post is “define qualified.” What is the measure of qualification for this office? The constitution is brilliantly clear on this, and by that measure Trump qualifies:")

#text("“No Person except a natural born Citizen, or a Citizen of the United States, at the time of the Adoption of this Constitution, shall be eligible to the Office of President; neither shall any Person be eligible to that Office who shall not have attained to the Age of thirty five Years, and been fourteen Years a Resident within the United States.”")

#text("(ARTICLE II, SECTION 1, CLAUSE 5)")

#text("And what is the definition of the continuum upon which we find “not even remotely qualified?”")

#text("As a mathematician you certainly know that stating one’s premises is essential to making a case. I would like to know yours.")

#text("Thanks,")

#text("jv")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e5928cb7453d13aa8f0734511e9d6312c4e9a42f10c59cfc04dbc4358abf3a1-cffbc8050cc8b8daf687de1a11830edad97b9a4ad50e4c00faf3c6dfa8fe83bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Known As Drew")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469272")[#strong[#text("Known As Drew")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("Hi Terry,")

#text("You’re almost certainly aware that we’re having our own election campaign at the moment in Australia, and we’re profoundly irritated that ours is going for 8 weeks. Like many others overseas, I have trouble understanding the Trump phenomenon, but then thinking about some of our own politicians it makes we realise maybe we haven’t done much better.")

#text("In the Australian/UK system, leaders are nominated by the party, which I believe tends to limit the power of autocrats to take over as self interest in the party room comes into play.")

#text("In Australia, we have had our own Trump in the form of Clive Palmer. That’s too long a story for a comment, but to the politically interested it’s well worth seeking out.")

#text("You’ve raised the preferential system (which has in my opinion been given a sensible reform in Australia where you no longer need to number the entire ballot paper) but let me also suggest the merits of compulsory voting. In truth, it’s not compulsory to vote, just to turn up on polling day. But the true merit is that it forces the state to supply the necessary infrastructure to enable every citizen to vote. While occasionally there are queues on polling day in Australia, it’s never to the same extent as has happened in the US or UK, where voting officials seem surprised if “turnout was greater than expected”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fff5e83672a134dc49335dd14d21c63ce41bd05a27e520e5d1051c8da22d5216-f4659ee76c5dd0908f57b17ec711baaaa5cd676fa0c8998b0b0b708c8f011bba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of occam's raza")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469594")[#strong[#text("occam's raza")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("Stephen Hawking has unearthed a little-known preprint from Trump University’s Maths Department, “I Alone Can Solve: My New Method for Determining the Lowest Common Denominator”. It explains a lot!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d755958db0c9da0fcb44ca1a4d4124a057ed5fbbeaf64aa56dbb3e1b4db4f26-d910e488744851ee6980f11d10b7e7fd56945cb50288f6decf6ed47543a4587e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ethan")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469275")[#strong[#text("Ethan")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("I believe that you have made it clear that you took Proposition 1 seriously and carefully. To allow for more meaningful discussion, can you show us your evidence and proofs for your proposition, or the reader can safely take the entire Hillary speech above to be all the evidence you would offer?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469278")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("I believe there are multiple proofs of Proposition 1. Clinton’s argument, based primarily on foreign policy expertise and temperament, is my favourite, but the other two arguments I linked to, ")#link("http://www.nytimes.com/video/us/politics/100000004249503/mitt-romneys-full-speech-against-donald-trump.html")[#text("of Mitt Romney")]#text(" and ")#link("https://www.youtube.com/watch?v=DnpO_RTSNmQ")[#text("of John Oliver")]#text(", I think would also suffice; in addition to foreign policy and temperament, Romney also discusses Trump’s lack of economic expertise, and Oliver brings up Trump’s lack of regard for facts and their bearing on policy (e.g. ")#link("https://www.youtube.com/watch?v=vU8dCYocuyI")[#text("on Trump’s famous “border wall” proposal")]#text("). One could also demonstrate Proposition 1 by other means, for instance using his lack of prior experience in any sort of public office or service, or his demonstrated lack of regard for basic constitutional principles such as freedom of the press and an independent judiciary. This is probably not an exhaustive list of possible approaches to prove Proposition 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d755958db0c9da0fcb44ca1a4d4124a057ed5fbbeaf64aa56dbb3e1b4db4f26-d910e488744851ee6980f11d10b7e7fd56945cb50288f6decf6ed47543a4587e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ethan")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469306")[#strong[#text("Ethan")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("Thank you for your reply and hints.")

#text("As you have mentioned, the US presidential election is largely limited to 2 choices, so the voting population’s task is to pick the better one, which cannot be accomplished wisely without adequate and reliable information on both sides. Information provided by those who are against Trump could have been spun or misquoted on purpose. On more vital occasions, for example the court, those would be categorized as interested parties. With all due respect, Donald Trump is the only obstacle at present between Hillary Clinton and the Presidency. Romney is an outstanding cheerleader for GOP Establishments, which was behind thousands of anti-Trump ads, and also tried to stop Trump as a third party or independent candidate after Trump became the presumptive nominee. John Oliver dislikes Trump with a passion the other night.")

#text("Hillary Clinton is an experienced lecturer. However, in the recent foreign policy speech, she made some mistakes about Trump. To be short, I will post 3 of them below with link.")

#text("1. Hillary: “This is someone who has threatened to abandon our allies in NATO.”")#linebreak()#text(" Trump wanted reconstruction of NATO. “I don’t mind NATO per se, but it has to be reconstituted, it has to be modernized,” “You know, we’re dealing with NATO from the days of the Soviet Union, which no longer exists. We need to either transition into terror or we need something else, because we have to get countries together.”")#linebreak()#text(" ")#link("http://www.breitbart.com/big-government/2016/03/23/terror-trump-trade-and-nato/")[#text("http://www.breitbart.com/big-government/2016/03/23/terror-trump-trade-and-nato/")]

#text("2. Hillary: “He says he doesn’t have to listen to our generals or our admirals, our ambassadors and other high officials, because he has – quote – ‘a very good brain.’“")#linebreak()#text(" Trump put his own ideas to be primary while listening to others. ”I’m speaking with myself, number one, because I have a very good brain and I’ve said a lot of things,” “I know what I’m doing, and I listen to a lot of people, I talk to a lot of people, and at the appropriate time I’ll tell you who the people are,” Mr. Trump said Wednesday. “But I speak to a lot of people, but my primary consultant is myself, and I have a good instinct for this stuff.”")#linebreak()#text(" ")#link("http://www.washingtontimes.com/news/2016/mar/17/donald-trump-i-consult-myself-on-foreign-policy-be/")[#text("http://www.washingtontimes.com/news/2016/mar/17/donald-trump-i-consult-myself-on-foreign-policy-be/")]

#text("3. Hillary: “He … picks fights with our friends – including … the mayor of London.”")#linebreak()#text(" Donald Trump Says Sadiq Khan, New London Mayor, Could Be Exception to His Muslim Ban.")

#text("I just hope that I didn’t do any“tu quoque” thing by pasting contradictions and bias.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e5ba814db2385673414a44d1f63bf18515b8bd3bf1b1c0adcb06d8fe2c3fc71-0fb1240f5658697e82d1aa193a17c852899550836988ee265d0eb0fd135f849a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469329")[#strong[#text("Andy")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Ethan,")

#text("I think you may be taking Trump at his face value. To the three points you raised, I have these comments.")

#text("(1) Trump’s suggestion to “reconstruct” NATO: sure, but how has he exactly proposed to do that? Like with every other policy issues, he has failed to produce any concrete plan to exact his “propositions”–if they can even be called that. And that’s why he’s unfit as a leader; else, every other person with superficial ideas can call themselves “a leader with visions”.")

#text("(2) Trump listens to his advisers. Does he? On multiple occasions he has demonstrated himself to be interested in first and foremost his own voice. In addition, he has made it this far without being able to enlist any credible policy minds, which bodes badly to his prospects as a leader.")

#text("(3) Trump will exclude the new mayor of London from his Muslim ban. Here Clinton may have used rhetorics to amp up Trump’s previous statements but it doesn’t change the fact that Trump is, like with most other issues, inconsistent. He initially promised his voters to ban all Muslims. Then, after the people of London had elected their first Muslim mayor, he made an ex-post comment to retract part of his original statement. The fight he picked and the offense he made would not go away just like that.")

#text("Going back to Terry’s main topic of whether Mr Trump’s unfitness to be POTUS is common knowledge, the fact that both sides of the political spectrum still have arguments/counterarguments like these suggests that it may not even be mutual, let alone common knowledge. Both sides have been trying to make their respective perspective mutual to the other side but as each mainly refers to their preferred sources, I doubt it will happen.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d755958db0c9da0fcb44ca1a4d4124a057ed5fbbeaf64aa56dbb3e1b4db4f26-d910e488744851ee6980f11d10b7e7fd56945cb50288f6decf6ed47543a4587e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ethan")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469556")[#strong[#text("Ethan")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("Andy,")

#text("You can surely disagree with my summarizations of Trump’s speeches, but it should be hard to summarize as the way Hillary put them. As “face value” lacks definition, I will not discuss that here, whereas I still have some comments for you.")

#text("1) Propositions are not solutions, which you may prefer, but still an essential step before any solutions are established. It is exactly the responsibility of a leader to detect a potential or existing problem and make propositions accordingly. Given that the NATO is consisted of countries with various interests and the detailed mechanism of NATO should be kept classified from the public, the reconstruction requires a series of complex secret negotiations, which may lead to completely different plans from the original ones. Even if Trump has any clues on these, he’d better keep them away from the crowd for confidentiality of the organization.")

#text("2) I believe it to be of the “tu quoque” nature. Moreover, “credible policy minds” are not defined.")

#text("3) To start with, rather than banning *all* muslims, which some media and others tend to use rhetorics to amp up, Trump proposed to ban muslim entering the U.S. Here is his press release which can be found on his own website.")#linebreak()#text(" “Donald J. Trump is calling for a total and complete shutdown of Muslims entering the United States until our country’s representatives can figure out what is going on.”")

#text("Exceptions are not inconsistency, for the representatives will certainly figure out that Sadiq Khan is no threat to the country.")

#text("I’m looking forward to having a glance at your preferred sources of facts and reaching mutual understanding with you at some degree.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/133b9f08b6dce26c29f3744ef3d1d8845b2c7b503e9c9ff7875dbb666338238c-ace1aaffd26b45b7df8372d1e0618d73098c12272ca7e9c49fee1db09414d186.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469366")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Ethan,")

#text("one of the issues with Trump is that he does so many interviews and is so inconsistent on the issues that pinning him down is difficult, especially given that he seems to be able to backtrack without suffering much damage politically. However, I think there’s a case to be made that Clinton is correct on 1 and 3 at least.")

#text("1. On NATO, Trump stated that he would push other countries to pay more to the US in order to be a part of NATO and that ‘if it breaks up NATO, it breaks up NATO’. It’s also very unclear, I think, that a NATO aimed at targeting terrorism would still be NATO; after all, the ex-Soviet states are a part of NATO solely for defense against Russia. Hell, if the aim of NATO is anti-terrorism, why not invite Russia to join?")

#text("3. He did so, only after challenging him to an IQ test. ")#link("http://www.bbc.co.uk/news/uk-36299929")[#text("http://www.bbc.co.uk/news/uk-36299929")]#text(" As someone in Britain, I can tell you that Trump’s remarks were widely seen as disrespectful (although Khan was already anti-Trump because of the Muslim ban before he became Mayor).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/adc80d7d60523186e7f9ea4b578103e6545a5434f83fe250ede86a8755dad58e-87c36191e225d30adc91ab6bbf2b5f0bbb790f25404c3f5952d334896f7f8b0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ethan")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469447")[#strong[#text("Ethan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Daniel,")

#text("in fact, I did have some difficulties pinning down full text of Trump from newspapers, which sometimes quote partially, on certain claims.")

#text("1. It is indeed weird that some members of NATO are from part of its original rivals in the treaty. However, it also reveals that NATO is in the process of repositioning itself in the greatly different new world after achieving its previous goal. As the very cause for which NATO was founded is nothing more than protecting the US and its alliances internationally and, for years, NATO proves to be an effective cooperative platform, transforming the NATO against new threats of its people, e.g. terrorism, means higher efficiency of time and resources, which is especially important after depression. As a matter of fact, coordination between the US, the primary leader of NATO, and Russia truly exists for the sake of anti-terrorism. Moreover, what Hillary actually said was “abandon our allies”, which should be to “push other countries to pay” as you have found out.")#linebreak()#text(" 3. Let’s get the timeline right. The list below is mostly based on your reply and reports of the Guardian website, therefore inevitably delayed, but should be enough to reflect the order of events, which could be further confirmed in the articles itself.")#linebreak()#text(" 1) Trump proposed to ban Muslim immigration")#linebreak()#text(" 2) Sadiq Khan became “anti-Trump” before he became Mayor")#linebreak()#text(" 3) Sadiq Khan became the Mayor, Saturday 7 May 2016 00.24 BST")#linebreak()#text(" ")#link("http://www.theguardian.com/politics/2016/may/07/sadiq-khan-elected-mayor-of-london-labour")[#text("http://www.theguardian.com/politics/2016/may/07/sadiq-khan-elected-mayor-of-london-labour")]#linebreak()#text(" 4) Trump says London mayor Sadiq Khan could be ‘exception’ to Muslim ban, Tuesday 10 May 2016 08.55 BST")#linebreak()#text(" ")#link("http://www.theguardian.com/politics/2016/may/10/donald-trump-london-mayor-sadiq-khan-exception-muslim-ban")[#text("http://www.theguardian.com/politics/2016/may/10/donald-trump-london-mayor-sadiq-khan-exception-muslim-ban")]#linebreak()#text(" 5) Sadiq Khan: I don’t want exemption from ‘ignorant’ Trump’s Muslim ban, Tuesday 10 May 2016 10.25 BST")#linebreak()#text(" ")#link("http://www.theguardian.com/politics/2016/may/10/sadiq-khan-i-dont-want-ignorant-donald-trump-to-make-me-an-exception")[#text("http://www.theguardian.com/politics/2016/may/10/sadiq-khan-i-dont-want-ignorant-donald-trump-to-make-me-an-exception")]#linebreak()#text(" 6) London Mayor Sadiq Khan Wants to ‘Educate’ Trump on Islam , May 13 2016, 9:20 am ET")#linebreak()#text(" ")#link("http://www.nbcnews.com/news/world/london-mayor-sadiq-khan-wants-educate-trump-islam-n573591")[#text("http://www.nbcnews.com/news/world/london-mayor-sadiq-khan-wants-educate-trump-islam-n573591")]#linebreak()#text(" 7) He challenged Khan to “take an IQ test” after the mayor called him ignorant. Monday 16 May 2016 09.02 BST")#linebreak()#text(" ")#link("http://www.theguardian.com/uk-news/2016/may/16/donald-trump-unlikely-have-good-relationship-david-cameron")[#text("http://www.theguardian.com/uk-news/2016/may/16/donald-trump-unlikely-have-good-relationship-david-cameron")]

#text("It is disrespectful to call someone “ignorant” and try to “educate”, especially for someone with big ego.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469422")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Terry – I have trouble relating to this. I have a feeling based on heuristics that Trump is unfit to be president. I wouldn’t say I’ve reached the level of “clear and convincing evidence,” in the legal terminology — and certainly nothing even close to a proof. Suppose we define “unfit to be president” (UTBP) as “if given the position of President, likely to cause substantial damage to the welfare of Americans and, secondarily, to other people in the world, relative to the conditions they would’ve been in had someone else been president.”")

#text("You’ve presented some information about him. But I don’t know what are the conditions that predict unfitness. What is the relationship between the traits that you’ve presented and unfitness? How predictive are they?")

#text("I am at a pre-rigorous stage in thinking about politics. It’s just so much more complicated than the things I know how to prove.")

#text("Do you feel you’re at a post-rigorous stage in thinking about politics? What definition of UTBP do you have in mind? Could you demonstrate your claims? Or are you using heuristics that might be totally wrong, like I am – and using the word “proof” in an informal way, to mean something more like “suggestion”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dwayne \"The Rock\" Johnson")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469640")[#strong[#text("Dwayne \"The Rock\" Johnson")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2016")])]

#text("I would guess that Tao does not think he (or anyone else) has reached a rigorous (much less post-rigorous) understanding of politics. A “rigorous” understanding of politics would allow intelligent people to finally reach a consensus about political decisions. Mankind is nowhere near that point, as evidenced by this comment thread, and probably a “rigorous” understanding of politics is impossible.")

#text("I guess that Tao’s use of the words “proposition” and “proof” in this discussion is slightly joking. It goes without saying that these words are not being used in the way they are used in math, of course.")

#text("In online forums people tend to make the error of interpreting remarks in the least generous possible way.")

#text("I’ll just throw my opinion in here : Trump’s suggestion to temporarily ban Muslims from entering the US was appalling to me and I would never vote for him after that (as well as many other things he has said).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e6264d9bc9110421451f6267f43c174477f82f584d7a9dc4e49f8dc659db96f-8cf49927ad6833cdf66e3a39ce25e50207fcccd932e746ed60b7be4bbfefcc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Nahay")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-474550")[#strong[#text("John Nahay")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2016")])]

#text("“A “rigorous” understanding of politics would allow intelligent people to finally reach a consensus about political decisions.”")

#text("No such bullshit as “intelligent” people in politics,")#linebreak()#text(" as that would imply “stupid” people in politics.")#linebreak()#text(" There is no such thing. Politics is all about what people")#linebreak()#text(" (the lawmakers) think SHOULD be. It is not a test of knowledge")#linebreak()#text(" about what is.")

#text("Politics & law are just dumb brainless brute force war.")#linebreak()#text(" So, yes, I proudly DO advocate & encourage gunning down")#linebreak()#text(" unpatriotic stupid hypocrites who eat meat & breed,")#linebreak()#text(" torturing & murdering hundreds of others in the process,")#linebreak()#text(" while forcing laws (justified or not) onto others.")#linebreak()#text(" Preaching the “law of the jungle” except when one is")#linebreak()#text(" in a disadvantage, then crying to the big govt, police,")#linebreak()#text(" to save them.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8a8b402dd9970aa3a5edba07bc495a28386b9ed46c3fafd27217271bc6467fb-ee1b35682bedff467f28f3e90884d1914a30fa8b3db0ec34ef4e29f63f44fba2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lherman22")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469429")[#strong[#text("lherman22")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("…Unironically listing John Oliver as evidence. Oh, wew lad. Time to get a refund on all those degrees.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469553")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2016")])]

#text("Argumentum ad hominem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bd857079511d11ebe237b3aa5a0ad21386fb1bc49e3c39a95d3405df0ec5b21-ddce209435273722cf6ef12f6d3706b13ac8804c03faff1ba71e4d5a9b30f3bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eugene Kapinos")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-590462")[#strong[#text("Eugene Kapinos")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2020")])]

#text("lherman22 – Thank you I was afraid no one was paying attention.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/016f7ba17c2a3cba8f8a810e271d399c275f692e8a7aa575816e61817932c1ac-4a67c5796759b31feeac43baf522ecbbf9332e3461c12c83fabc5576f92bc9bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of State Pary")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-470944")[#strong[#text("State Pary")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2016")])]

#text("You forgot to mention his demonstrated lack of regard for basic constitutional principles such as freedom of religion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61428788f4c15543dcd8367ae0d85afbd3cd2ffa1f8bfacf35d850a1e912a295-07014d76f4eb73aeda5dfa9c10e520cd980382c5d000c3829c70ad9adf9c3614.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Herzl")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-474464")[#strong[#text("Matthew Herzl")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2016")])]

#text("Trump is an extremely successful businessman. The fact that being a successful businessman is a meaningful qualification for the presidency is something that ought to be common knowledge. Building a successful business takes a world of skills that merely holding public office does not. In fact, the primary hurdle to public office is often winning an election, which is not necessarily a meaningful qualification, as this very article accurately suggests. The claims about Trump’s views on freedom of the press or on independent judiciary being at odds with constitutional principles are unsubstantiated. Advocating a “border wall” (sic scare quotes) is not unreasonable. Here is a paper substantiating that: ")#link("https://mckinneylaw.iu.edu/iiclr/pdf/vol15p349.pdf")[#text("https://mckinneylaw.iu.edu/iiclr/pdf/vol15p349.pdf")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9d2b471a95950cf9ab900a2a956433a802e53dd7dce19b8f99e969eecbfb6d-928b219cdc034ba412fab685a5c24ece80537934e15e706cc872bf337f74deba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of allenknutson")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469276")[#strong[#text("allenknutson")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("To Ethan and others, I recommend James Fallows’ sequence ")#link("http://www.theatlantic.com/notes/all/2016/05/the-daily-trump/484064/")[#text("here")]#text(", presently on its 12th entry, as a very succinct summary of the unfitnesses of Trump.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0edc51e1d359a442aa2abf8cd0e44aa8b406a7098b8f8cd1bc8e17a62cb82255-2c226ff5ee28e322d49ff1d7acdbea0efe15b544fe98e59e1b7e142cc7f83d56.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boaz Barak")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469292")[#strong[#text("Boaz Barak")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("This is a great sequence. See also")

#link("https://www.hillaryclinton.com/briefing/updates/2016/06/02/trump-literally-said-all-those-things/")[#text("https://www.hillaryclinton.com/briefing/updates/2016/06/02/trump-literally-said-all-those-things/")]

#text("for a point by point collaboration of the points in Clinton’s speech.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da1c73f2d2aaf7670d1b5a946c7ed533b10d40b5c543177924e6b4671970fc7d-d6f174897cf8052041801305ce14b69ec061f5fd9f2cfe050dace942ffbdb33f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rufus")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469384")[#strong[#text("rufus")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Collaboration, huh?! Your vocabulary is impressive… for a third grader.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0edc51e1d359a442aa2abf8cd0e44aa8b406a7098b8f8cd1bc8e17a62cb82255-2c226ff5ee28e322d49ff1d7acdbea0efe15b544fe98e59e1b7e142cc7f83d56.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boaz Barak")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469393")[#strong[#text("Boaz Barak")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Thank you for this complement.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9d2b471a95950cf9ab900a2a956433a802e53dd7dce19b8f99e969eecbfb6d-928b219cdc034ba412fab685a5c24ece80537934e15e706cc872bf337f74deba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of allenknutson")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469398")[#strong[#text("allenknutson")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Incidentally, bringing up his own quotes directly to his face ")#link("http://www.motherjones.com/kevin-drum/2016/06/donald-trump-ups-his-game-moves-lying-meta-lying")[#text("won’t get him to acknowledge or explain them")]#text(". (By the way, the newer entries in the Fallows sequence also are very good.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa110cd843baa2000ae418ed3de2ae68b28bc66ef4075ccbcac1820a765bc52e-85a2258f3dc17fc3c3f5478e04ec551c8963350f4e5cfb87059b48fab2cfb0f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris J.")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469277")[#strong[#text("Chris J.")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("Thanks for your post! You’re in good company, and I wish more people would speak out.")

#text("Regarding chances for reform at the US Presidential election level, there’s a very interesting and clever plan called the National Popular Vote plan, which was invented by a Stanford computer science professor. While it doesn’t address the spoiler effect, it doesn’t require a constitutional amendment. Eleven states have enacted it so far: ")#link("http://www.nationalpopularvote.com/")[#text("http://www.nationalpopularvote.com/")]

#text("Regarding Proposition 1, the media has a vested interest in preventing it from becoming common knowledge. This is because a closer race leads to greater readership / viewership.")

#text("PS – I live and vote in San Francisco, which also uses IRV (we’ve been using it since 2004), and I’m also a big fan of IRV for single-winner elections.")

#text("SB 1288, which just passed the State Senate in California and is now going to the Assembly, would let all cities and counties in the state use IRV (and not just chartered ones): ")#link("http://leginfo.legislature.ca.gov/faces/billNavClient.xhtml?bill_id=201520160SB1288")[#text("http://leginfo.legislature.ca.gov/faces/billNavClient.xhtml?bill_id=201520160SB1288")]#text(" Call or write your Assemblymember today!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469279")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("Jurn Leung, my across the street neighbor, forwarded this essay. I want to share with you a story I’ve told some of my friends or when relevant, my psychotherapy patients over the years about real ending of “The Emperor Has No Clothes.” In my version – i.e. what usually happens in real life (think of with many whistle blowers) is that the child (or anyone who sees things clearly about a person in power) shouts out that the emperor has no clothes. Instead of the crowd finally seeing the emperors nakedness and taking up the chant, the emperor has the child arrested and – I should say – sent to Guantanamo to be water boarded.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469280")[#strong[#text("故事背后的逻辑学 – 127.0.0.1")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")]

#text("[…] 通过 It ought to be common knowledge that Donald Trump is not fit for the presidency of the United States… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469282")[#strong[#text("Robert Smart")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")]

#text("STV is a bit more than instant-runoff, particularly in its ability to do proportional representation without political parties (when I first started voting the parties didn’t appear on the Australian Senate voting paper). I would also like to see some acknowledgement by elite figures (such as yourself and John Baez and David Brin) that Trump is a symptom of the fact that the middle class is doing it tough over the last 20 years, with technology producing wealth without jobs. This is creating tribalism that can work out badly in more ways than electing inappropriate candidates. The success of the advanced economies is based on technology creating as well as destroying jobs. During periods when this worked badly (1890s, 1930s) America was tenacious in sticking with minimal government intervention and that was eventually the right solution. Whether it can work in the age of AI is not so clear.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/592d7ac13f627bb243428cd22f5b001a58567692b03f4e2b2fc31f0583c5d2a6-badeff9485b1d517fd62df84254367253d650214747204bf5dad3c434903f8c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of janice allen")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469284")[#strong[#text("janice allen")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("Dear Terry,")

#text("What are the duties of the president of the U.S.? First you have to define what a government is. It is the executive council of the ruling class, i.e. in the case of the U.S., the capitalist class. Then the president is nothing more or less than the chairman of the board of the executive committee of the ruling class. In other words, the president works only in the interest of the ruling and by definition against the interests of the working class, as their interests are, for all practical purposes, diametrically opposed. Only when the working class confronts and makes demands regarding the injustices and exploitation by the ruling does, does the president bring in reforms – never before.")

#text("Trump is leading fascist mobs and they must be confronted and defeated. The ruling class calls on these fascist gangs to attack the working class and their organizations. The U.S. had fascism for 100 years and it is called Jim Crow.")

#text("A better position than yours would be to determine which interests among the ruling class each party and candidate represents. But rest assured, both Trump and Clinton represent the interests of the ruling class.")

#text("Date: Sun, 5 Jun 2016 01:02:42 +0000 To: ")#link("mailto:sashalasa@hotmail.com")[#text("sashalasa@hotmail.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0edc51e1d359a442aa2abf8cd0e44aa8b406a7098b8f8cd1bc8e17a62cb82255-2c226ff5ee28e322d49ff1d7acdbea0efe15b544fe98e59e1b7e142cc7f83d56.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boaz Barak")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469285")[#strong[#text("Boaz Barak")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("Thank you for writing this. I completely agree with both the proposition itself, and the fact that it’s important for people to come out and say it.")

#text("I think there are a few reasons why people don’t take the danger of Trump as seriously as they should.")

#text("1. Some people might believe that the identity of the president might not matter as much, and the office shapes the person much more than the other way around. I believe the last 16 years should offer a very strong counterexample to that. Whatever your views are of George W. Bush and Barack Obama, it’s hard to argue that each of them did not make a very significant difference (in largely opposing directions).")

#text("2. We tend to try to force facts into our preconceived paradigms. One needs to go back many many years to find a candidate for president as uniquely unqualified as Trump, and so, once he was nominated, it’s sometimes easier for us to assume that he’s no worse than usual, than to accept that something truly outrageous happened.")

#text("3. The nature of political debate often tends to emphasize smaller differences and not distinguish so much between someone that is opposed to you in several issues and someone who’s completely beyond the pale. So you could have democrats arguing that all republicans are equally unfit for office or even some more liberal democrats arguing that Hillary is indistinguishable from Trump. That view can be understandable if you feel that anything short of The One True Policy is equally terrible, but one should remember that the president of the United States is going to have a lot of real impact on real people, and different imperfect policies can make a huge difference for them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68770994525ea216df1fbbcfb68466bbb12efd5ae6d316f5a75fe2b05017e9b4-da253ccfa65d565708fcfb387476a76f9dadc2a3569069c710958eecc4d18a64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Classy Mofo")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469673")[#strong[#text("Classy Mofo")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2016")])]

#text("Regarding point 1, really? With a few exceptions (eg healthcare), seems to me that Obama was simply Bush 3.0. Certainly that’s true regarding foreign policy, which, of all the functions of the US government, has had the largest impact on the world. What do you think Bush would have done differently if he were president 09-present, or what would Obama have done differently if he were president 01-09?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10905479e9b4f913fc4f0ad44e4ba398f7c4e8ce957f89154e9701f6274c48bf-7feed935cc53149e1eca87854c9d7339e4b41f1966ac419b1fa8e6aaada06a4d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rcv4 at ucs.psu.edu")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469287")[#strong[#text("rcv4 at ucs.psu.edu")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("Hi Terry,")

#text("You make a good point, but I don’t think your proposition is the correct one. Might I suggest it should be")

#text("Hilary Clinton is much better qualified than Donald Trump to be President")

#text("And the analogy of the child saying that the emperor has no clothes is a distinguished Republican saying it.")

#text("Bob Vaughan")

#text("Sent from my iPhone")

#text(">")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed046b007edd4bf6a15278d7564d157fc9c34d712271e9aa069fcc6d6a6e7dcb-f539147a908df5110a56179e9284bfac88cde2a98cc0fa50ca6afa3278cff458.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kamal Jain")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469288")[#strong[#text("Kamal Jain")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("My comment is not related to politics. If people were allowed to cast their vote confidentially whether the emperor is naked or not then the truth would come out. Would not it? So why worry here? If everybody or almost everybody believes Trump is unfit then is not that will be voted? Does one’s vote depend upon personal knowledge or common knowledge?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b26ddb73003fe01a672af93995eaa6fd71470981dc7fd6902d71e3ca430f291a-ce093f375f56496103da8646b6a6314fd7281fc1d926dc2c71ed4d2b010d9ff3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. Sivakumar")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469399")[#strong[#text("D. Sivakumar")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Kamal, I think your very nice question might be related to the difference between “preference polling” and “expectation polling” (see ")#link("http://www.nytimes.com/2012/11/02/us/politics/a-better-poll-question-to-predict-the-election.html")[#text("http://www.nytimes.com/2012/11/02/us/politics/a-better-poll-question-to-predict-the-election.html")]#text(", for example) — is anyone aware of the results of an expectation poll for this election? It might very well be that belief matters more than knowledge in elections.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a8c1203d7f31aafc34322b009621eb45b736076bb0a611be7053943dfafc686-51bcccf5ddb2ff5658e8ce8dc6b1c1fd8cc866c0e0306612367dcd242fb15df0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabor Pete")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469648")[#strong[#text("Gabor Pete")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2016")])]

#text("Hi Kamal. Many people don’t like to be wrong. Hence their votes are strongly influenced by their beliefs about the beliefs of other people. Also, many people like to act against what smart people say should be common knowledge.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469289")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("I recommend everyone read the cover page featured article from The Atlantic written by a psychologist, “The Mind of Donald Trump.” ")#link("http://www.theatlantic.com/magazine/archive/2016/06/the-mind-of-donald-trump/480771/")[#text("http://www.theatlantic.com/magazine/archive/2016/06/the-mind-of-donald-trump/480771/")]

#text("I also wrote about this article and added some of my clinical impressions here: ")#link("http://www.dailykos.com/story/2016/05/29/1532283/-A-psychologist-analyzes-Trump-the-narcissist")[#text("http://www.dailykos.com/story/2016/05/29/1532283/-A-psychologist-analyzes-Trump-the-narcissist")]

#text("Some of the comments are interesting…")#linebreak()#text(" especially these:")

#text("Thanks for posting the symptoms of NPD. That certainly describes Trump.")

#text("Some articles suggest that Trump might have dementia. That would explain his strange speech patterns, and more.")

#text("HalBrown SoCalSal May 29 · 10:07:08 AM")#linebreak()#text(" I’ve wondered about dementia too. I have seen indications of early signs which I won’t go into here beyond saying it is mostly when he seems befuddled when trying to respond to a question he doesn’t have a ready canned answer for, and his sometimes disjointed language. Of course one can have a personality disorder and develop dementia too. If it’s true, unless it is the rapidly developing kind, the symptoms won’t be severe enough to get people currently supporting him to change their minds.")

#text("see")

#link("http://www.inquisitr.com/..")[#text("http://www.inquisitr.com/..")]#text(".")

#text("SoCalSal HalBrown May 29 · 12:28:21 PM")#linebreak()#text(" As you say, the public might not notice if Trump is developing dementia. I wonder if his family and close associates wouldn’t notice, and what they’d do about it if they do notice a decline.")

#text("TheProgressiveAlien SoCalSal May 29 · 10:44:38 AM")#linebreak()#text(" *Reads article* Holy Heck… A narcissistic Alzheimer’s sufferer? Shit, I don’t really want to have any sympathy for the schmuck, but that’s pretty sad. Doesn’t quite mitigate just how awful the man is, though.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Séguin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469349")[#strong[#text("Richard Séguin")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("It was just yesterday that I was thinking to myself that Trump is exhibiting signs of dementia in his speech. I have not until now heard anyone else talk about this idea, but I do have personal experience with someone with dementia. It’s not just the “disjointed language” that I see; it’s also the apparent loss of executive function relative to social verbal inhibition, and his persistent use of a limited number of pejorative adjectives, sometimes naked without their associated nouns.")

#text("To be fair, Bernie Sanders, who is now 74, could already be in early dementia without yet showing obvious signs.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469354")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Here is an article speculating that Trump’s problem might be sleep deprivation. He’s often boasted of sleeping only 4 hours per night.")#linebreak()#text(" ")#link("http://www.huffingtonpost.com/kelly-bulkeley-phd/donald-trump-the-sleep-de_b_9413588.html")[#text("http://www.huffingtonpost.com/kelly-bulkeley-phd/donald-trump-the-sleep-de_b_9413588.html")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kodlu")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469373")[#strong[#text("kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("then there is nothing to worry about, GW Bush was said to sleep very long hours while he was president!")

#text(":-)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68770994525ea216df1fbbcfb68466bbb12efd5ae6d316f5a75fe2b05017e9b4-da253ccfa65d565708fcfb387476a76f9dadc2a3569069c710958eecc4d18a64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Classy Mofo")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469674")[#strong[#text("Classy Mofo")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2016")])]

#text("Look at some Trump interviews from the 80’s and 90’s, he has always talked like that. He used to be much more soft spoken, but apart from that his speech patterns are pretty much the same. I think The Apprentice is what made him louder and less inhibited. Here")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0200f3d5e3b1ba6faa93cdcc483292b5331a564a8eee0e2995a7afc742551e-7d541da8152d31712a035f9208f2418cd7bb637dc7c6296490fd74081a996b8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of daneix")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469290")[#strong[#text("daneix")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("The transition from mutual knowledge to common knowledge is some kind of breaking an equilibrium and moving to another. So you need to give current equilibrium a disturbance, e.g. the child in Emperor’s New Clothes, or the foreigner in red-blue-eyed islander puzzle, to let it move.")

#text("But Trump was bashed by celebrities and media from beginning (remember those headlines from Huffington Post, Fox, CNN, Washington Post, etc? you name it), so IMHO, it’s not feasible to say there’s not enough disturbance. And quite contrary, no other candidate has even taken as much negative views but Trump still dominated GOP. I cannot think of what more disturbance is like, maybe the riots brought by anti-Trump parties are not enough?")

#text("Anyway, this proposition is hard to prove or disprove since the term presidency is far from a boolean judgement.")

#text("As presidential election, I partially agree with you that something must be changed. But the root issue is that states have more power than in Australia, and that’s why this country is called U.S. So Any candidate dominates a state will take all votes from it, and unfortunately this is granted as state’s privilege. If this is not changed, the 3rd runner still have no chance to win.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6dfb0f053fba55a62f351637e19580a6e8cc7bc71f6b17468d4b151140a8b7b-2a913f9fecf94422d385338b49bd7cdcc889314c41560f9ba65f18b4032f22e5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lanfengdubu")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469376")[#strong[#text("lanfengdubu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("haha, didn’t expect to see you here!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b23e1f11c2c18121497a0209fb2752c80c0a6a756d89e761cf2173174d40f125-5868ce43e3cd541361e552874f141f2104840421b4039deb78ed0cd2ae83d7da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of metalogike")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469291")[#strong[#text("metalogike")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("“making a largely symbolic protest vote”")

#text("It’s often worse than symbolic (worse than useless): in many cases, a vote for a third-party candidate is equivalent to handing a vote to one’s worse (worst) major-party choice, which many people unhappy with the two-party system rightly find repugnant.")

#text("“But this is very much a longer term issue, as there is absolutely no chance that any such reform would be implemented by the time of the US elections in November (particularly given that any significant reform would almost certainly require, at minimum, a constitutional amendment).”")

#text("That’s true of any significant reform which required legislative change, legislatures being controlled by the two major parties, who have a shared interest in maintaining their duopoly. But it’s not necessarily true of the reform which citizens can enact on their own, without legislative mediation, and protected by the Constitution in its current form. This can take the form of pairing up R and D dissenters to defeat the spoiler effect. (We make the argument here, and are very interested in rebuttals or other responses: ")#link("http://pairvote.org/")[#text("http://pairvote.org/")]#text(")")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a7dbf0fc4f87d9dd7d9265b8d742254449560def99ea67f4a0bdffbedeff30-6357b353d4083e451e5adfb16009055f7689e1058db5dc6c29d9cb3641abf55b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Baez")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469293")[#strong[#text("John Baez")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("I woke up one night and had a bout of insomnia as I imagined with horror what a Trump presidency could do to our nation. I realized I had to do everything I could to stop it – not because I’m so influential, but because I couldn’t live with myself otherwise. So I’ve begun a series of articles telling people why Trump is unfit for office:")

#text("1) ")#link("https://plus.google.com/u/0/117663015413546257905/posts/LhYuxDC4nwe")[#text("Elizabeth Warren’s case against Trump.")]

#text("2) ")#link("https://plus.google.com/u/0/117663015413546257905/posts/TrHqFyuveLr")[#text("Trump announcing a war against the free press.")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ca1f66148acbda6beb4c04f89c2094f8f1d2f2fda37ae736d9a01f8900e619b-86e56d18414d3f6cbafd9df3c84b2fd120022c59ae5b5e1999f4997c94bf6ee0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Holden McGroin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469482")[#strong[#text("Holden McGroin")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Behold hyperbole in it’s purest form.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68770994525ea216df1fbbcfb68466bbb12efd5ae6d316f5a75fe2b05017e9b4-da253ccfa65d565708fcfb387476a76f9dadc2a3569069c710958eecc4d18a64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Classy Mofo")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469675")[#strong[#text("Classy Mofo")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2016")])]

#text("What specifically do you fear? I don’t think Trump will be a particularly good president but I’m puzzled by all this “sky is falling” stuff from otherwise intelligent people. In some ways Trump is clearly better tha Clinton – look at his foreign policy speech. He is one of the few political contenders in recent years to admit that the US is somewhat responsible for the chaos in the middle east, and he advocates a less interventionist foreign policy. Compare this to Clinton’s track record.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1307a71b1b2dcf1c4b2189e86616d09f3061fddc1b7b7a4d8ccdc8d9e6070fb7-0ec55a2bf86453e502c162312439f2939e0aaef4aee628df3bb5e266f55bb708.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Pachter")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469294")[#strong[#text("Lior Pachter")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("It goes without saying that there is plenty of evidence in support of Proposition 1 but I thought I’d add a small piece that makes sense to mention on a math blog. Donald Trump can’t even count: ")#link("https://www.facebook.com/DonaldTrump/posts/10156462054585725:0")[#text("https://www.facebook.com/DonaldTrump/posts/10156462054585725:0")]

#text("Thanks for your post Terry. I wholeheartedly agree with your statement that ” “more people need to say so, openly” and applaud the step you’ve taken in that direction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d4db647d607b88d6567c7dc07533a7aa3284078bc6a1b3d173ec41cbaca6049-22db6e691de770075e8d729f0b3663588e42abc4bb0e2a809bb7fa831a8a2a31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 50x50")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469295")[#strong[#text("50x50")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("Let’s check some of the “proofs” of Proposition 1.")

#text("Looking at what is happening in the Middle East, Hillary Clinton is barely in the position to talk about expertise in foreign policy, because she supported it all. Unless, of course, we think that it is a success. Do we? Neither she is in the position to point at someone’s temperament. So, this proof needs reconsideration.")

#text("Trump’s lack of any experience in public office is not necessarily a shortcoming. This proof needs more elaboration on why not being a professional politician is a bad thing for a candidate.")

#text("Whether Trump fits to be a president or not – is irrelevant. More important thing is: why he is being supported by so many? Why is Sanders being also supported? People tired of current policy, economy, etc. Hillary is not going to change the status quo.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08c57b5f8b0d2224810c448d299125adc8d30f04285d879f0b8d563a6dbaa449-a77e48610f9d0e3edac0a67795e88eee890cb01ede29505e8e79ba46549866ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Sapir")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469297")[#strong[#text("Mark Sapir")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("Dear Terri, The proof of Proposition 1 is false. You refer to statements by Hillary (who is a political opponent, and who said similar things about Obama in 2008) and Oliver, who is very smart but just a left-leaning comedian after all. By the way I remember that Bush-41 said quite the same things about Bill Clinton in 1992. Using similar math-like arguments one can prove anything. For example, Teichmuller “proved” that Jews are totally unfit to teach mathematics to true Germans. In fact he honestly believed in his “proof”, and tried to convince Landau because he thought that Landau as a good mathematician should agree with Teichmuller’s logic. Best, — Mark")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cd500aabd56b81f6643b31f074d92d701784e77b43ef82f0e830e7297b64a1a-c88b1a2ad26c3a5f6335fb15e3fcfc1701468232fcf2f1505acdc89f12c66e49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of victorivrii")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469300")[#strong[#text("victorivrii")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("I am afraid that T. Tao makes a logical mistake applying “The Emperor’s New Clothes” fable in the way he does. I think, that a situation is rather opposite:")

#text("In this fable people were publicly admiring the Emperor’s new clothes while privately knowing that the Emperor was naked. However now we see mainly public claims that Trump does not fit to be a president while electors privately vote for him.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a small child")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469353")[#strong[#text("a small child")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("It’s the Professional Protesters’ New Clothes!")#linebreak()#text(" “So I’ve decided to endorse Hillary Clinton for President, for my personal safety. Trump supporters don’t have any bad feelings about patriotic Americans such as myself, so I’ll be safe from that crowd. But Clinton supporters have convinced me – and here I am being 100% serious – that my safety is at risk if I am seen as supportive of Trump. So I’m taking the safe way out and endorsing Hillary Clinton for president.” –Scott Adams")#linebreak()#text(" ")#link("http://blog.dilbert.com/post/145456082991/my-endorsement-for-president-of-the-united-states")[#text("http://blog.dilbert.com/post/145456082991/my-endorsement-for-president-of-the-united-states")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37b0d08f5f2d055b7ff6b43e8ce260e37635cfbbe685fa2907d90221498f54b6-19e5e87510ddfbd262bdc70204c0df79bd34c022881ca327d67204cd74267fa7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin (@igriv)")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469391")[#strong[#text("Igor Rivin (@igriv)")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I have discovered, in recent years, that academics (even people who get papers in Annals occasionally) to be worse than the Komsomol, group-think wise. Depressing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cd500aabd56b81f6643b31f074d92d701784e77b43ef82f0e830e7297b64a1a-c88b1a2ad26c3a5f6335fb15e3fcfc1701468232fcf2f1505acdc89f12c66e49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of victorivrii")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469415")[#strong[#text("victorivrii")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Not really. Even if you may be occasionally frown upon for supporting unpopular view but at least you would not be accused for insufficient enthusiasm lambasting it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37b0d08f5f2d055b7ff6b43e8ce260e37635cfbbe685fa2907d90221498f54b6-19e5e87510ddfbd262bdc70204c0df79bd34c022881ca327d67204cd74267fa7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin (@igriv)")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469438")[#strong[#text("Igor Rivin (@igriv)")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Not true. I have been there, and undergone full-blown shaming sessions. Welcome to USSA.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bef5858847bf78dca2582af2dc3e346dda27d57aec4a87a03e9ad68537e08685-d48e7c2822e9fcdd05a74ba63784f09e6bee83a9a962db9c111cda5a7617e8da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469301")[#strong[#text("Antoine")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("I have an issue with Proposition 1, and it’s not that it’s false, it’s that it’s an answer to the wrong question. Many Americans (and many others around the world) are not voting for someone qualified because they don’t care about qualifications ; they are voting for someone they perceive to be “outside the system” or “different” to “shake things up” in government. This is why Trump is dangerous, and will not be defeated using pure logic in the conventional set of political logic and assumptions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/568130204b653e321d4e9c20d5210b7377d9e1afd532f91a35d56968aa8b8bf4-ad0d317e484bd46544231168fee17b8700d0047e62b4be43326540aa6ded26b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Narm No")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469304")[#strong[#text("Narm No")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("Terry, unless I’m mistaken, which I hope I am, it appears you’ve transformed from intellectual to poo-slinging monkey. It would be very sad if someone in your position and with your natural gifts had degraded himself to such chimp-like behavior, so I hope it isn’t true.")

#text("Here’s my thesis: Your statement “not even remotely qualified” is immaterial.")

#text("For example, “qualified” is fundamentally a relative term. If every single major party candidate in the last 20 years were less qualified than Trump, then a normal person wouldn’t say Trump is unqualified; instead quite the opposite. Yet you say that comparing Trump to, say, Hillary Clinton is not a valid line of reasoning and un-related to the “epistemological” (terrible jargon, by the way) nature of the proposition. Huh? But the proposition itself is a relative proposition.")

#text("Further, in order to judge whether someone is qualified for the presidency, you must understand several deep issues. One of them being: the nature of the presidency.")

#text("Do you? If not, are you simply relying on experts (New York Times, academics, etc.) who tell you what the president should do? And if you are, are you correcting for the bias of the experts? Experts who aren’t leftist (compared to, say, the general population) tend not to get published or get tenure– it’s no conspiracy theory. And many soft forces (like groupthink, incentives, signaling, …) pushes “experts” in a certain direction, as well. So you better be doing a great deal of bias correction here.")

#text("And generally to correct for massive bias, you ideally want to have some actual familiarity with the matter at hand…")

#text("What do you make of the many very intelligent people outside of your social group who support and admire Trump? Consider that Peter Thiel, a very intelligent person, is a Trump delegate. Sure, I don’t know whether he personally thinks Trump is qualified, but that should give you some pause.")

#text("Other things you may want to understand is, “How does democracy work?” “How does politics work?” “What is the aim of politics?” “How are the lives of different types of people and how are they affected by politics?”")

#text("The answers to those questions are all connected and let you honestly evaluate how qualified a candidate is. And you can’t just take some expert’s word for it! (Bias, and even outright lying, is rampant at all levels of intellectual/political society.)")

#text("For instance, let’s say the aim of US politics should be to serve the interests of the American people (I’m not so bold as to make that claim!). Has it done that? If you read some Mencius Moldbug, you’ll see the answer is, no. If you haven’t read Mencius Moldbug–the smartest right-wing intellectual alive–you probably haven’t really read any right-wing intellectuals, and are probably forming your opinions almost entirely on what you’ve heard from left-wing intellectuals.")

#text("Which really makes your announcement about “Trump is bad!” uninformed and worse than useless. Terry, you have a good job. You’re smart. You seem to have a happy life. What do you personally gain by making deceptive and uninformed statements? Surely your personal goal shouldn’t be to spout off about things you know nothing about? It doesn’t help you or anyone else.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/568130204b653e321d4e9c20d5210b7377d9e1afd532f91a35d56968aa8b8bf4-ad0d317e484bd46544231168fee17b8700d0047e62b4be43326540aa6ded26b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Narm No")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469309")[#strong[#text("Narm No")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("By the way, your recommendation that someone watch a 35 minute Clinton speech is, I hate to say it, disgustingly stupid. In the time spent watching a bland 35 minute speech written by a speechwriter/propagandist for the TV-watching sub-100 IQ masses, one could read a chapter of a good book, or a post on a good blog, and have gained, rather than lost, knowledge. (Perhaps skimming a transcript of the Clinton speech can be justified for certain people, but only if your mind has sufficient context for interpreting what you read accurately.)")

#text("Spending 35 minutes of your time consuming mindless propaganda should make a sane person throw up his food. The number of manipulation/influence techniques there will bend your mind, and not in a good way.")

#text("Don’t watch new speeches. Read old books and think instead.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/568130204b653e321d4e9c20d5210b7377d9e1afd532f91a35d56968aa8b8bf4-ad0d317e484bd46544231168fee17b8700d0047e62b4be43326540aa6ded26b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Narm No")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469311")[#strong[#text("Narm No")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Here are a bunch of arguments that Trump is qualified:")

#text("1. He’s a billionaire. He had a reputation as a businessman for getting a lot of things done. His properties are run very smoothly. Conclusion: He’s good at getting things done.")

#text("2. He has many children and grandchildren. So he doesn’t want the world to go to hell. Conclusion: He has skin in the game.")

#text("3. His wife loves him. He sells many books. He’s very skilled at persuading people (e.g. in rallies). He’s a skilled talker in interviewers. Conclusion: He’s sharp and good with people.")

#text("4. His family members endorse him, including ex-wife. Contestants on the Apprentice who’ve worked for him like him. Golfers like Natalie Gulbis like him. Conclusion: He’s honest and has worked to keep a good reputation all his life.")

#link("http://www.golf.com/tour-and-news/natalie-gulbis-donald-trump-i-know")[#text("http://www.golf.com/tour-and-news/natalie-gulbis-donald-trump-i-know")]

#text("5. His policies are, in my opinion, the policies most aligned with the self interests of math professors.")

#text("Arguments he’s not qualified:")

#text("1. When he talks to normal people he doesn’t talk like an intellectual; e.g. he jokes around. (Well, that’s because he’s trying to relate to normal people as a politician.)")

#text("2. His numbers sometimes don’t add up. He’s changed stances. (That’s nitpicking, people. You can make that argument for any politician.)")

#text("Let’s see. 5 pro, 2 con. Sounds like he’s qualified, no?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66f23f0f56bdf0086ce02130bbd54c3b761155e2ee9809be4455df2c425618ad-27db570b7a87447955af355454c4e8fb1769356d71b95a7c79c52e6870cdd615.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edwin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469406")[#strong[#text("Edwin")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("This comment is a joke, right? You’re a liberal trying to make right-wingers look intellectually vacuous by making the most patently ridiculous and self-refuting arguments possible, right? You can’t possibly write nonsense like this and think it’s convincing on a blog frequented by logically rigorous commentators.")

#text("And on top of that, you think a word like “epistemological” is “terrible jargon” on an academic’s blog.")

#text("By the way, I have wasted my time reading “Mencius Moldbug” as well as the far superior writers he tries to imitate, like Thomas Carlyle, and I can conclusively tell you that if Moldbug is the best “intellectual” the right-wing has to offer, then the right-wing is indeed a sick joke on society.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/568130204b653e321d4e9c20d5210b7377d9e1afd532f91a35d56968aa8b8bf4-ad0d317e484bd46544231168fee17b8700d0047e62b4be43326540aa6ded26b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Narm No")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469414")[#strong[#text("Narm No")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("(1) You claim “logically rigorous commentators,” and here we have Mr Tao citing John Oliver, an intellectual midget, as “proof” of Proposition 1. This is anything but logically rigorous. You are being deceptive, Edwin.")

#text("(2) “Epistemological” is a big, meaningless word typically used as cover for bad ideas. That you don’t admit this is sad, Edwin.")

#text("(3) “Patently ridiculous and self-refuting arguments.” This is nonsense, Edwin.")

#text("For instance, let me elaborate on my first argument above, about Trump being a billionaire.")

#text("Competing at Trump’s level in the private sector requires skill that few people possess. Politicians don’t have those skills. Academics don’t have those skills. Internet commenters certainly don’t have those skills. Self-made billionaires don’t become billionaires out of dumb luck. They need strong business sense. This Trump has and makes him more qualified for the presidency.")

#text("See Trump’s books on managing downside, or also this old interview of Trump, showing his thinking process around risk: ")#link("http://infoproc.blogspot.com/2016/02/trump-on-trump.html")[#text("http://infoproc.blogspot.com/2016/02/trump-on-trump.html")]

#text("(4) Not everyone likes or can understand Moldbug. Reading him is not for everyone. But claiming his well-read arguments are a “sick joke” is absurd and smacks of dishonesty, Edwin. Moldbug is a very intelligent man.")

#text("(5) Edwin, you have an annoying, intellectually dishonest habit of smashing together multiple lies in a single sentence in order to try to win an argument. Based on the repeated instances of deceptive sophistry in your comment, Edwin, I look at you with a mixture of pity and contempt.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab233cc31b81e8300bc14416925f0c0d28af63deac38bae7053b2e277678f941-5714c94ec8bc08939f0423d3b0041d900694f731e8f2225462fc27179fe1d441.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469421")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("> 1. He’s a billionaire. He had a reputation as a businessman for getting a lot of things done. His properties are run very smoothly. Conclusion: He’s good at getting things done.")

#text("This is demonstrably false, as many of his businesses have failed — including the likes of Trump stakes that he tried to market during his campaign.")

#text("> 2. He has many children and grandchildren. So he doesn’t want the world to go to hell.")

#text("Apparently not enough to consider global warming a serious threat, instead of a Chinese conspiracy.")

#text("> 3. His wife loves him.")

#text("Unrelated.")

#text("> He sells many books.")

#text("Not as much as he claims. He lied about his book sales.")

#text("> 4. His family members endorse him, including ex-wife. Contestants on the Apprentice who’ve worked for him like him. Golfers like Natalie Gulbis like him. Conclusion: He’s honest and has worked to keep a good reputation all his life.")

#text("Unrelated, and the argument does not support the conclusion. Just because some people like him, does not mean that he is honest. In fact, he has been caught lying so many times it’s pretty much impossible to fact check him.")

#text("> 5. His policies are, in my opinion, the policies most aligned with the self interests of math professors.")

#text("I suppose you are not a math professor ?")

#text("> 2. His numbers sometimes don’t add up.")

#text("Like that time that he claimed that unemployment is 20%?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/568130204b653e321d4e9c20d5210b7377d9e1afd532f91a35d56968aa8b8bf4-ad0d317e484bd46544231168fee17b8700d0047e62b4be43326540aa6ded26b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Narm No")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469530")[#strong[#text("Narm No")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text(">This is demonstrably false, as many of his businesses have failed")

#text("“Trump had some failures so he was a bad businessman” is the Romney argument, but it’s a bad one. Entrepreneurship is about failure. If you don’t fail you don’t learn. A successful businessman has many failures. Here’s how Trump thinks about business: he expects to make many bad deals, but he limits potential losses and expects to win in the long-run.")

#text(">Apparently not enough to consider global warming a serious threat, instead of a Chinese conspiracy.")

#text("I never said Trump wasn’t clownish. Trump has made clownish statements such as that one in the past. I’d excuse this statement as joking banter; a reaction to global warming alarmism. After all, there’s evidence global warming scientists exaggerate claims to get funding, etc. He hasn’t repeated this clownish statement since he started running.")

#text("> Unrelated.")

#text("If your wife loves you, your personal life is in order. It’s a good sign as to your emotional strength and stability. Attractive women don’t like unstable men.")

#text("> Just because some people like him, does not mean that he is honest.")

#text("He’s made business deals with thousands of people. If Trump had been dishonest in his business, these people would be coming out against him in droves. (Remember the press hates him!) Instead, these people if anything tend to praise him!")

#text("> Like that time that he claimed that unemployment is 20%?")

#text("Official unemployment rate (5%?) doesn’t include people who’ve given up looking for work. The official employment rate for working age people is around 60% and at historic lows. Trump’s defining unemployment differently from the government and making a point that jobs are becoming harder to find for many Americans. This rings true for voters.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37b0d08f5f2d055b7ff6b43e8ce260e37635cfbbe685fa2907d90221498f54b6-19e5e87510ddfbd262bdc70204c0df79bd34c022881ca327d67204cd74267fa7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin (@igriv)")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469388")[#strong[#text("Igor Rivin (@igriv)")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("If I could up vote 10 times, I would.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa11700e51fce1eb752758c12996f21ce39eb991ef73fe801db8465b430a71a3-5333da29b7ad852337eff466b64add18272d924ecbf3c4a6cc7097d03fc1aaf2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Hughes")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469305")[#strong[#text("Martin Hughes")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("I think that you are absolutely right about Trump not being remotely qualified to be president. The problem is that this idea easily spills over to the idea that his supporters are not even remotely qualified to vote. This I profoundly disagree with.")

#text("What we have in this Trump thing is similar to what we had here in the UK with Farage and UKIP. Supporters were routinely portrayed as knuckle dragging morons who had been duped into believing poisonous ideas about immigrants etc.")

#text("The idea that there could be any rational content to their rejection of the liberal agenda was not even considered. The liberals just got more and more illiberal as if talking about another race of human beings. ‘You can’t say that” and so forth. Then a bit of liberal baiting from the other side and so on back and forth like a sick Punch and Judy show.")

#text("What this reveals is really a crisis of democracy that leads liberal and very intelligent people to reveal the fact that they have lost all sense of social solidarity with large sections of their own people. No one actually says it but the liberals themselves have no clothes either. They have become illiberal and if they were honest would say what they actually think about Trump supporters “They are not fit to vote, they are too thick, too easily led, they are not educated like us, perhaps only educated liberal people with the ‘right’ ideas ought to have the vote.” This is why it is a crisis of democracy that goes deeper than Trump getting elected.")

#text("I’m not suggesting for a moment that you are such an illiberal but the thought seems to hover in the air around the debate like an electrical charge waiting for something to ground it. An unspoken mutual knowledge of the educated classes.")

#text("I would suggest that the reason that the Trump supporters are voting for him doe as have a rational content. In the fable of the King with no clothes, the rational content was the peoples’ fear of arbitrary power. The answer is not to ridicule the people but to act in solidarity with them to remove that arbitrary power. The answer to Trump is to offer them another way of being free that has a rational form because that is why they are voting Trump, because they want to be more free. Free of what? That’s for you guys over there to find out by reaching out and talking to them. Always look for the rational core to ideology because there has to be some truth in order for the lie to be believed. The rational core is ‘freedom’. And it’s about time the left reclaimed this word from the right.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa0e8389968f25240a07946d2807695bfa6e82ac1c2aba9e71f0eb0803877e8c-bf2829ddd37348e566548658fbe796d9a95cbeedf8b4109f2fda944637684391.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of no")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469307")[#strong[#text("no")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("he’s not remotely qualified yet still the better choice")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0842619b40b080de5f59589ccb82d5e51cd8f7bc0181cc5fa8bbcb7cba4b187-bad285d30d50227a646bb8300032a3e4d1f861a297ec8f9b4e6bf4636dbac760.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469308")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("While I do agree with the core message here, the argument provided is a tad ridiculous. The proof of Proposition 1 is, both in the comments and the post, provided by political opponents. One could do this with *any* presidential candidate in recent years. The post seems to convey a message of an ironclad proof of Trump’s incompetence; this line of rhetoric can quickly become dangerous.")

#text("Politics is not mathematics. You are expressing an inherently subjective opinion (and I do happen to agree with it.) The way you present that opinion, however, is done in a somewhat forceful manner. Trump satisfies the formal qualifications to become the US president. With the current definitions, if he is to win the US election, Proposition 1 is false. Perhaps a better direction to go is to change the definitions as to make the proposition true.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cdc8ad894736f8f0e751625ad3205a343ece947694832dc88f69b23d0f8416ee-6913566b91572eed61bd41c845ecd5f970b8253e82bd8d66551eef52337f4b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469310")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("While better voting system would be great improvement, I don’t think It’s the main reason for Trump.")

#text("Italy had Silvio Berlusconi. Berlusconi became PM in multi party proportional political system. He even had his own party. US Establishment has previously picked people like Dan Quayle and Sarah Palin and changed the view of what is considered qualified.")

#text("I see Trump as evolution. There are only two things that make Trump more advanced version of his predecessors:")

#text("1. lack of handlers. GWB had his neocons. Trump has selected his own. Some of them have credentials but there are many unknowns.")

#text("2. Complete lack of shame. Trump truly is America’s Silvio Berlusconi.")

#text("Berlusconi owned media, Trump knows how to use it. Future candidates will learn from Trump all over the world. Media changes what is considered acceptable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f563bddef1ea6c900459b818043ae43f59604042e090bc80cd98e994ab2ad2d-855eee57d6ce545af19e1c1d482f30e9f9ca47a674424b7182685751495a71c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davidmfisher")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469312")[#strong[#text("davidmfisher")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Though I agree entirely with the sentiment behind the Proposition, I’m afraid I’m going to have to agree with those above who disagree with you on it’s truth. It’s a wonderful metaphor, but it isn’t a logical proposition. Trump as President will likely destroy the entire US constitutional system by his complete disregard for it’s underlying construction. Rule of law survives because it is respected by those with power and he will not respect it. Those voting for him to “shake things up” will discover that shaking things up too much can and will make things worse. I think the fact that he will likely destroy the constiutional system which will elect him is the best argument that he is unqualified. But I don’t think other people are required to accept an axiom system in which this is a true statement, so I don’t think the Proposition, as such, is proven. ")#link("http://www.nytimes.com/2016/06/04/us/politics/donald-trump-constitution-power.html?_r=0")[#text("http://www.nytimes.com/2016/06/04/us/politics/donald-trump-constitution-power.html?_r=0")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f563bddef1ea6c900459b818043ae43f59604042e090bc80cd98e994ab2ad2d-855eee57d6ce545af19e1c1d482f30e9f9ca47a674424b7182685751495a71c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davidmfisher")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469313")[#strong[#text("davidmfisher")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I think one can make some additional interesting arguments about how both Bush II and Obama have already degraded the rule of law, by say spying on US citizens illegally and having them executed by drone strike. So one could argue that even this aspect of Trump is a difference of degree and not a difference of kind. Of course differences of degree can lead to phase transitions and I suspect Trump, if elected, leads to a phase transition. I sincerely hope he is not elected.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33ef196a38486a9147a95b182346362ebea3aca1eaa5bde2a0eeee06a567485e-d8a57408814df855273c435f0b1cc274268606c0b1b7480f114abdf85cbd749f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mr. Tumnis")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-470383")[#strong[#text("Mr. Tumnis")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2016")])]

#text("Liberals, through their blatant disregard of the commonsense meaning of the Constitution, have done a very fine job eviscerating the Constitution of any objective meaning. They have self-serving short circuited the legislature and managed to magically find all sorts of rights–abortion, homogamy, etc–hidden in its text. Interpretations which would obviously be reprehensible to any of the Founders. Shame.")

#text("Terry, I find you’re pseudoproof to be specious; and, inter alia, doesn’t begin to address the entirety of the relevant issues that a voter has to balance.")

#text("Trump has so many enemies on the establishment right and left, I see a far greater likelihood that he will be held accountable. The inertia of a vast, unseen and unelected bureaucracy will be against him to. Can’t say the same for Hillary.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/407a6ea9d20f51d66e19ce220898b5da95f48a5dca0100b8e8224496d8f3e355-0b63cd214dba92ceee81806d1311186579f46fc2c2ce461917a45f30b27a63f3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trump’s new cloths | The Leisure of the Theory Class")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469314")[#strong[#text("Trump’s new cloths | The Leisure of the Theory Class")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("[…] but, as political observers like to say, normal rules don’t apply this year. Tao ﻿writes that many of Trump’s supporters secretly believe that he is not even remotely remotely […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2158d5744d7f14c39f496c6df05751372a04da1eb8814ab2949a3e24171a37c-3d75a7dd66646c827fb34a7b9890d7d87716bbffbe363d8811913351e5396883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469316")[#strong[#text("Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Did you notice that Trump’s rhetoric is a case of your proposal to move from “mutual” to “common” knowledge?:")#linebreak()#text(" Trump’s bet on the stupidity of the people includes a bet on the intellectual inability of the scientists – without doubt his advisers and all of the republican think tanks took the climate change public discourse as proof of the later. There too, it was very clear that only a strong repeated public communication by scientists would be needed, but they failed completely. (Misleading PR by climate damaging industry took in turn the previous cigarette smoking discourse as model, which showed a similar unability of the (medical) science community). Other sources of that special “mutual knowledge” among Trump’s supporters comes from business experience, how one can treat academic employees, academic customers (e.g. it is well known in financial industry that academic degrees increase the gullibility in silly investments), how easy academic education gets turned into silly business schemes.")#linebreak()#text(" Trump’s rhetoric turns that from “mutual” to “common” knowledge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16384430a77fb046424a08371dc0ecbd3c8dcf9441d1db1559596a6362eef76c-12c40458c1bebbd048bc8848a7c52c341b7dbd7b7ffcc9826425d36b9502ff00.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of eventhisoneistaken")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469317")[#strong[#text("eventhisoneistaken")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Dear Prof. Tao,")

#text("You’re of course free to delete this comment and change your blog policy at whim. (Is this still a math research blog? I came here looking for “[u]pdates on [your] research and expository papers, discussion of open problems, and other maths-related topics”, and certainly not expecting to be bombarded with political propaganda.)")

#text("But to the substance of your post: I actually agree with your Proposition 1. In turn, I present for your consideration Proposition 2: Hillary Clinton is unfit to be President of the United States. As proof, I offer the Benghazi fiasco and the illegal storage of classified emails on a private server (most likely to avoid FOIA requests), which has already caused the country significant damage:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://observer.com/2016/02/breaking-hillary-clinton-put-spies-lives-at-risk/")[#text("BREAKING: Hillary Clinton Put Spies’ Lives at Risk")]
]

#text("This is not exactly a tu-quoque retort. Rather, this is a question to you and your readers: What is a nation to do when both of its two major-party presidential nominees are unfit for the high office? (Aside from mourning the sad state of affairs, that is.)")

#text("One answer would be to bring out the pitchforks. Barring that, when both candidates are unfit for office, fitness ceases to be a relevant criterion. So personality, likability, and the very visceral consideration of “which one is more likely to look out for me” come to the forefront.")

#text("Trump voters are not (all) idiots; you can be assured that this one is not. Logically accepting Prop. 1 does not entail pulling the lever for Hillary.")

#text("Best,")#linebreak()#text(" -Anonymous")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5a5dbc19a058ab2e2c919272603d4f748a9ada75a639084750bcf9f11654f96b-ab6e0e416c4cc89c38d701caa3590c7c1e6fbb63027e30ad67bd162b6517d08a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wolfgang")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469352")[#strong[#text("wolfgang")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text(">> What is a nation to do when both of its two major-party presidential nominees are unfit for the high office?")

#text("Perhaps consider a 3rd party candidate? e.g. Gary Johnson.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8fb5ff0275c4db4a1cd180a94ab81fcba1b401b18c5513c44a48ecf38f437b2e-b2d5e43b4a163c0397eec996bf16ad79d3c95ef44958fdead3d86ada76bb621a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Response to Prof. Terry Tao | posttenuretourettes")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469318")[#strong[#text("Response to Prof. Terry Tao | posttenuretourettes")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("[…] of course free to delete this comment and change your blog policy at whim. (Is this still a math research blog? I came here looking for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dcabc3f6443ce4cc5ba83f5749fb861577b4068f267cbf61ea85a215970ebcaf-19d8ce367839b3b88b922d867afce81a9138ed7602594424da3169ce271cf123.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff Lewis")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469321")[#strong[#text("Jeff Lewis")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("There’s a third type of knowledge, maybe we can call it propagandized knowledge. Basically the idea is, if you keep saying something enough times, eventually people will believe it as the truth.")

#text("Look, I’m anything but a Trump supporter. But the notion that Trump’s incompetency is “mutual knowledge” is obsurd. There are millions of people voting for him–people who believe our biggest issues are the influx of illegals, the threats of ISIS, and a society that has gone crazy with political correctness.")

#text("Whether they’re right or wrong is certainly open for debate, but I certainly wouldn’t suggest there’s a general consensus regarding Trump and being unfit for the office.")

#text("And before you write that off as the dumb masses following an idiot, there are plenty of politicians and political figures who have supported Trump for quite some time. Former speaker of the house Newt Gingrich certainly Coles to mind, as does Chris Christie, Pat Buchanan, etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/380df033e13a2b9b4221287220bfb9ebd0824a94f508abf7f38a49d0e1f2c383-87390e19e9bcba1448fc06bfe65bcb78a89e83af1b93778e3dac0803aedd55e0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469322")[#strong[#text("George")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Years ago similar propositions were made for, that period’s, presidential candidate Ronald Reagan. History proved that they were wrong.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f68278deb8afe135f9195941ddf81b5e8d92bbfaab15d756ca5e041cbcffd28-9305d43b78d2e5d8d117eac3a28deebd286a963bab06d6c189ff475adc935251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elchanan Mossel")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469324")[#strong[#text("Elchanan Mossel")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Terry,")

#text("I am not sure that the axiomatic setting of common knowledge is appropriate for many economic situations including the current US elections.")

#text("To talk about common knowledge you have to make numerous assumptions that are hard to justify in this context – including 1) players are rational 2) there is a common partition of the space which everybody knows and includes each and every person opinion 3) people can compute logical deductions on the partition based on other people statement etc. etc.")

#text("I think it is fair to say that Bayesian Econ is not considered a predictive model for rational players such as financial institutions so applying it in the context of voting is more than a bit of stretch.")

#text("This is not to say that I do not think that Donald Trump is a good candidate obviously.")

#text("Just for fun let me give you the common knowledge argument from the other direction:")

#text("1. Everybody knows that establishment politicians are corrupt and do not answer to their voters (I actually think that some version of this statement is well accepted and also correct. For a liberal perspective on this you can read for example the recent book, “nation on the take”).")

#text("2. HRC is an establishment politician.")

#text("3. DT is not an establishment politician.")

#text("The logical conclusion from this argument is that it is common knowledge that HRC is corrupt while it is not clear if DT is.")

#text("Again – this is not my personal opinion. However, I want to make the case that since the mathematical model of common knowledge is not a good model for decision making in the context of the current elections, one can possibly arguments going in the other direction as well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/acb60df38d3f64e49ba0d925a29a0de078644878e593b196fe216dba8a3f3f81-90f18da174327c251ee030f93cbb28f46145e90cf1e5d15d2b2f0e1db5c883d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Golub")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469404")[#strong[#text("Ben Golub")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Elchanan,")

#text("Some nerdy nitpicking:")

#text("“1) players are rational 2) there is a common partition of the space which everybody knows and includes each and every person opinion 3) people can compute logical deductions on the partition based on other people statement etc. etc.”")

#text("This is not really true: common knowledge is defined independent of assumptions about rationality, though to make connections between actions and knowledge or belief hierarchies, you do need axioms about rationality or similar things.")

#text("Relatedly, “the same partition” is, when the model is appropriately defined, a tautology rather than a substantive assumption….")

#text("So I think your critique misrepresents the needed assumptions a little bit. Though I understand that for some of the stronger conclusions of analyses that use common knowledge, you do need strong and implausible assumptions.")

#text("best,")#linebreak()#text(" Ben")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/acb60df38d3f64e49ba0d925a29a0de078644878e593b196fe216dba8a3f3f81-90f18da174327c251ee030f93cbb28f46145e90cf1e5d15d2b2f0e1db5c883d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Golub")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469405")[#strong[#text("Ben Golub")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I should have said at the beginning — it is not really true that 1) 2) 3) are always *needed*")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c988dc5aeac7cbcfa8f4f366d2ed8af4074aa7131b2cc6401846be58b5af5441-74ff5027811a3fbcd41bd7a43cfc64952d56b368f1f39d51ae9b390c924a930e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Smith")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469326")[#strong[#text("James Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I think that only a very view would not concede that there is something not quite right with democracy in America, not least the electoral system. I suppose you could argue that Donald Trump is proof of that and Hilary Clinton hardly the best counter-example.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6c8741a0e27a5b7f8c3ed5c9a564a9b5f4e13c3813b1a372078dfe0caa40816-842b45d6579e14b6782f1c5abe81bf949e91929e70cdcf7776825c85e8df116a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pauldepstein")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469327")[#strong[#text("pauldepstein")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I basically agree with you. I’m not an American, and therefore can’t vote, and even if I could vote, I would not vote for Trump. However, “the duties of the presidency” isn’t particularly well-defined. Among intelligent political operatives and commentators who are pro-Trump, their support is probably based on the idea that a lot of activities normally done by Presidents would be delegated. For example, there’s quite a consensus that Reagan didn’t have much competence or ability. But this simply meant that many normally presidential tasks (such as making substantive comments to the media) were delegated to subordinates. Of course, the Reagan programme was ultra-conservative, so, from a liberal point of view, I don’t like what his administration did. But I don’t see that Reagan’s incompetence caused problems — it just meant that there was more delegation.")

#text("From: Whats new To: ")#link("mailto:pauldepstein@yahoo.com")[#text("pauldepstein@yahoo.com")]#text(" Sent: Sunday, June 5, 2016 2:02 AM Subject: [New post] It ought to be common knowledge that Donald Trump is not fit for the presidency of the United States of America #yiv2214098539 a:hover {color:red;}#yiv2214098539 a {text-decoration:none;color:#0088cc;}#yiv2214098539 a.yiv2214098539primaryactionlink:link, #yiv2214098539 a.yiv2214098539primaryactionlink:visited {background-color:#2585B2;color:#fff;}#yiv2214098539 a.yiv2214098539primaryactionlink:hover, #yiv2214098539 a.yiv2214098539primaryactionlink:active {background-color:#11729E;color:#fff;}#yiv2214098539 WordPress.com | Terence Tao posted: “In logic, there is a subtle but important distinction between the concept of mutual knowledge – information that everyone (or almost everyone) knows – and common knowledge, which is not only knowledge that (almost) everyone knows, but something that (almo” | |")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3edc2b5793392836af950eeb23fe4605cd1a49edfd489217490ae36ad4439b53-0befbbaa0c92eb31ff3b7ad1eb168e3471bcece25afb5f3e4263ee0f85a8dc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nets Katz")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469328")[#strong[#text("Nets Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Terry, I think there may be an error in the epistemology of this post. I am not certain that if people are unwilling to say that Trump is unfit to be president, it really means that they don’t know that others know he is unfit. I, myself, am a great believer in telling the truth. There are situations where it would be politically advantageous to lie and I cannot make myself do it. Nevertheless, sometimes it is politically advantageous to lie even when you know that everyone knows you are doing it.")

#text("Let me give an example from math department politics. This will be a true example. Luckily, I have belonged to enough math departments that any of my colleagues or former colleagues can credibly believe I am not referring to them. Once I sat on a hiring committee which was very fractured. Each member of the committee has his or her own candidate that year. One of those candidates was not really qualified for the job. Everyone knew this except possibly the person who proposed the candidate. Each of us knew that the others knew. In fact, we even discussed these facts among ourselves in private. However, when we discussed the unqualified candidate in committee. It was nothing but flattery. (A departmental bigwig not on the committee had already criticized the candidate in a way which offended the person who had proposed him.) The members of the committee felt compelled to say what a good candidate it was in order to have the opposite effect. I could not say that, and as I sat silently in that meeting, I felt it having a detrimental effect on the prospects of my own candidate. Incidentally, it was a very near-run thing that we did not hire the unqualified candidate. All that would have had to happen so that we would have is that all the other candidates reject us. We would not have been able to get out of it without offending the person who had proposed the candidate.")

#text("I think a very similar thing is going on here. DT has real supporters. In addition to that, those real supporters have friends. When you argue, in my view correctly, that DT is unqualified, you offend those supporters and even their friends. This can have the effect of riling them up and making them more enthusiastic. I think this is what DT is counting on and is a risk which Clinton takes by taking this tack.")

#text("This may even have been the case with the naked emperor. The reason the child could what it did, was because it was functionally autistic and therefore ignorant of the social conventions in which it was acting. Because everyone recognized the child’s ignorance, nobody could be offended by it, which is why it was safe for the child.")

#text("Nets")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/608301e60fab2bd58541c2042c695aa15bcb825d453f8e352e9d464c6bac6e01-4f6462f98a0299791f129538419f9212dd94b4db819cac7db1aa97882002fcbc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ken(neth)")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469330")[#strong[#text("Ken(neth)")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("If we are going to be logical about this, it seems that one would need to define the meaning of “qualified.” Per the U.S. Constitution, the qualifications to be president are defined in Article II, Section I, Clause 5 — which states: “No Person except a natural born Citizen, or a Citizen of the United States, at the time of the Adoption of this Constitution, shall be eligible to the Office of President; neither shall any Person be eligible to that Office who shall not have attained to the Age of thirty five Years, and been fourteen Years a Resident within the United States.” It appears that Trump in fact meets these qualifications. However, it is important to note that there are legal questions concerning citizenship with regards to the meaning of the phrase “natural born.” Such issues could very well apply to Trump for all we know, but not as the clause has been interpreted in current case law.")

#text("Of course, any would-be president would also have to be elected. In this sense, it’s up to the American people to judge any other qualifying criteria in the voting booth. This said, Trump can in fact take office if he is elected. When people ask me who should be president, I usually respond: “The candidate elected by the people, of course.” It seems to me that this is the most important qualification of all. That doesn’t mean that I necessarily want that candidate to be president — but what I want and what should be are different things altogether. I could view the potentially disastrous outcomes as an inherent flaw of democracy. However, I tend to believe the dharma or causality of the natural system serves as the judge of people’s choices rather than democracy itself.")

#text("Looking at the positive side, Donald Trump may be a wake-up call that there is something wrong with the system. People have been making suggestions and recommendations for constitutional change since its ratification. The topic became of particular interest following the American Civil War, generally focusing on the problem of a difficult amendment process, and proposing additional legal qualifications would require amending the U.S. Constitution. There are other structural changes that would be easier, such as changing the electoral system and addressing political polarization due to party politics. Even so, I think that the most important change that needs to take place is a cultural one among the electorate. Changing the electoral process could aid in transforming the culture. There are many different types of electoral systems with their advantages and disadvantages, but no amount of legal and procedural change will help if something doesn’t change in the minds of the American people.")

#text("The ultimate question is whether that change can take place without the appropriate organizational changes, or whether those organizational or structural changes can happen without some cultural change in the electorate’s mentality. I guess I’m of the opinion that if you change what happens within the system, the needed changes to the system will happen — but that’s simply my idealism as an educator talking. The reality could be that we are faced with an impossible triangle sealing our fate.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/608301e60fab2bd58541c2042c695aa15bcb825d453f8e352e9d464c6bac6e01-4f6462f98a0299791f129538419f9212dd94b4db819cac7db1aa97882002fcbc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ken(neth)")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469892")[#strong[#text("Ken(neth)")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2016")])]

#text("Political Culture ")#link("http://randomthoughtsagainandagain.blogspot.kr/?view=sidebar")[#text("http://randomthoughtsagainandagain.blogspot.kr/?view=sidebar")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f57da2e2e751494d17453580b2f36864fc53f4c5a9a03c410b10cc9c01553552-b1f4d571ca37a0d018cf662f026417c88715f88d1c8201e167a9c2f993cf11a3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luisgarciapuente")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469331")[#strong[#text("luisgarciapuente")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I do not think Proposition 1 is close to being mutual knowledge in the population of the US. After living for 12 years in a small town in Texas, I know many people including university colleagues and neighbors that would disagree with Proposition 1. In my opinion there are 3 types of Trump supporters: (1) the people in the anyone but Hillary camp. One could make a case that this group also knows Proposition 1 is true. (2) Republicans that do not know what are the duties of a president. I think that this is the group Paul Ryan was addressing in his pseudo-endorsement of Trump where he essentially said the GOP would create the agenda and Trump would only help pushing it through. In my opinion this group may not know Proposition 1 is true. (3) People that do not base their decisions based on facts but on gut feeling. Bill Maher loves to talk about this group, usually when he talks about climate change. In my opinion this group also may not know that Proposition 1 is true simply because they do not care to ponder about it. Their vote does not depend on arguments or facts showing Trump may or may not be fit to be president. It depends entirely on their gut feeling. In the opinion of this Texan resident, this camp is not as small as one would tend to think.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7297454ae01ef3ac3544dbcaa3c19da24441cb71f32a1d0c6c0f143add6761ae-a9aca689f96b5c99d6c7311a813a721c67d840c7b440a159ee4a8de0c94645a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Enoch Powell")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469458")[#strong[#text("John Enoch Powell")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Have you ever considered that there are people who support Donald Trump for reasons other than the ones you have summed up?")

#text("To me, Trump is a means to an end – a way to finally halt the Overton window’s decades-long gradual shift towards the progressive left. I believe that social and cultural identity are central to human existence and the human experience, and that governments as we have in the West today – which assume equality and compatibility between cultures, a laughable impossibility – are so out of touch with the real world that they must inevitably fail. This breakdown of fact-based government could physically destroy our civilization.")

#text("As a result, a Trump presidency would be a milestone, a sign that finally the pendulum might start swinging ever so slowly back to a more moderate position instead of the far-left position that it finds itself in today.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71280b536b1432843064021ecbabec32996edc30f12b8acfafc84b23bab30255-89664768714fbf7bf0cdb2537f159120e7a7041707c42ffc99959ecf53e57175.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuvallevental")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469332")[#strong[#text("yuvallevental")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I don’t know if you have stated it, but I would ask if one of your axioms is that the most unfit president is necessarily the least desirable scenario. Not necessarily in my view.")

#text("If a person wants to completely change the system, it would be unwise to play by the current rules of the system. It is my assumption that American politics is irredeemably corrupt, and we therefore should elect someone who is the most openly corrupt so we can be honest about it. Any attempt to change the system for the better using the system’s means itself will backfire. Sanders and Clinton make many promises, but don’t give any mathematical model as to the odds of those promises being fulfilled. Trump makes some false promises too, but these are the promises that you don’t want.")

#text("Every government in the world is corrupt. This is because there is an imbalance of power between certain individuals, and that this imbalance of power is an illusion, though the governments claim it is real.")

#text("There are better ways to serve the people than the use of governmental institutions. Private enterprise and volunteer work can be very gratifying.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469335")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Personal note to Terry:")#linebreak()#text(" I’ve been so busy reading the comments to this essay that I couldn’t think of anything to post on my own updated daily blog. Instead I wrote about you…")#linebreak()#text(" ")#link("http://halbrown.org")[#text("http://halbrown.org")]#linebreak()#text(" Thanks…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9062a689f54014f0a8ab6879814d602b1e695457202f245bcb26179bec30e682-26996dbcee7a683597be47c3b9bc2db0ee60163b4c49c187303e5c70161a1ae6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carl Chern")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469336")[#strong[#text("Carl Chern")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("The way you shut up the mouths of people who do not support Hillary is so upsetting just like what those leftist media do. What I see is a majority of media suppressing the negative information about Hillary and deleting the comments and search results going against her. It is these people who are “refusing to acknowledge the emperor’s nakedness”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71280b536b1432843064021ecbabec32996edc30f12b8acfafc84b23bab30255-89664768714fbf7bf0cdb2537f159120e7a7041707c42ffc99959ecf53e57175.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuvallevental")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469337")[#strong[#text("yuvallevental")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Well, to be fair, this thread should be only about Trump, but I don’t like the idea that just because Hillary SAYS some nicer promises means that we should bow down to her, no questions asked.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f6d11826e59fc429cbef55438a3972d30c892b6232d3f5d5209c371b273b0ab-052e39cd222db4d051489ffa01a86f4a46421b089d5a2f0802f1a7c5ad374c3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hal Brown")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469338")[#strong[#text("Hal Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("First – the idea that there’s some conspiracy from Google and other search machines to in for the tin hat crowd who read World Net Daily and Prison Planet. Second, Hillary is the most scrutinized candidate we’ve ever had. Trump’s rants about her are aimed at people who don’t have the smarts to realize, for example, that there’s nothing conceivable she could have done in the email brouhaha that could land her in prison. I believe she made mistakes which I won’t bother listing; but I believe she has learned from them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71280b536b1432843064021ecbabec32996edc30f12b8acfafc84b23bab30255-89664768714fbf7bf0cdb2537f159120e7a7041707c42ffc99959ecf53e57175.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuvallevental")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469339")[#strong[#text("yuvallevental")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Additionally, there is something I must completely dispute with Terry: The idea that most of his supporters support him because they think he is qualified. They support him because he reflects their viewpoint on reality, regardless of qualification.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5fb8d3ea7b87ff69aeca40d60f0e35587f359acc642ea394fda7eb22ea123c30-f238aa76aef7ab6a0df0eb868ab8522a09749dd6362249746264c2e1da8b0657.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469340")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Donald Trump has an approval rating similar to what Nixon had at the time of his resignation (and had similar supporters). It’s common knowledge, even amongst many of his supporters, that he is unqualified to be president. Many of them are of the opinion that he will hire qualified advisors who will help him sort things out, and that he will run the country like a company which he wants to succeed, and point to his business record. They are further willing to overlook his deficiencies out of hostility towards the growing nonwhite population of the United States. Yes, there are a lot of racists in this country. It is taboo to express such views, but they are everywhere.")

#text("I think you might have trouble accepting that many people can be very openly aware of Trump’s many deficiencies and still support him, and that it’s just a matter of pointing out his failings as Hillary did in her speech. Perhaps unlike many of your readers, I know several Trump supporters, including one who is an immigrant with a PhD. These people are truly disillusioned with the system, feel they are not represented by either party, and are willing to risk having an obviously unqualified person as president because having “qualified” presidents has failed them and their families over many years. Was George W. Bush qualified? He gave us Iraq and the economic meltdown. Trump pointed it out over and over in the primaries and he ended out winning. It’s not a question of common vs mutual knowledge. It’s an issue of total disillusionment with politics and a willingness to go to extreme measures to “fix” the problem.")

#text("And to make it clear, I am not a Trump apologist. I’m voting for the first time in over a decade solely to vote against him.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66f23f0f56bdf0086ce02130bbd54c3b761155e2ee9809be4455df2c425618ad-27db570b7a87447955af355454c4e8fb1769356d71b95a7c79c52e6870cdd615.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edwin")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469532")[#strong[#text("Edwin")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("“Many of them are of the opinion that he will hire qualified advisors who will help him sort things out, and that he will run the country like a company which he wants to succeed, and point to his business record.”")

#text("I know you’re not an apologist, but I just wanted to point out that if the people who he’s hired for his campaign are any indication, he will not hire anything close to “the best” people, and probably wouldn’t heed their advice even if he did.")

#text("There’s also good reason to believe his business record is nowhere near as successful as he claims because he won’t release his tax returns. In addition, the stinginess with which he’s spent money his primary campaign and his imminent dependence on big donors to fund his general election campaign, suggest that he’s not as wealthy as he claims. He might not even be a billionaire.")

#text("One of his biographers, Tim O’Brien, was unsuccessfully sued by Trump for reporting that Trump is not a billionaire. O’Brien is one of the few people who has been privy to Trump’s tax returns.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02301021cb356b7b701aed2d6b9c61ef5bc17548828c6e55d0702773d7267c40-4456b383c750277a9b38227e8e01f2be7044f14b17fa86f169fd8271ce91a65b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fraac")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469341")[#strong[#text("fraac")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("You need a third kind of knowledge, call it ‘mutual delusion’, for the people who believe the Emperor is clothed. There us no deliberate method for either the mutually knowing or the mutually delusional to ‘flip’ their counterparts, they can only wait for the spread of common knowledge.")

#text("Most of what I know about being president comes from The West Wing. Bartlet was perfectly presidential while unconscious from being shot. Does Trump have the minimal intelligence required to take counsel and delegate? I believe so. Speaking as a narcissist, nothing makes me look better than a competent staff.")

#text("Either you or I are delusional, we can only wait to find out which.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b39fc56b8a1645bd105b0a64fab1915acb943530473582f96d10fc0c0ba1213-1f5a9b638db522473228aa4d674015abc52a2ec078c138de6c6f6e3341ec8421.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shecky R")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469342")[#strong[#text("Shecky R")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Thanks for writing this Dr. Tao; more scientists and mathematicians need to be speaking up about this unmitigated disaster, even if we are largely speaking to a choir… silence and accommodation does not have a good history. It’s bad enough that some in the science arena defend Republicans, but defending Trump is beyond the pale.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7297454ae01ef3ac3544dbcaa3c19da24441cb71f32a1d0c6c0f143add6761ae-a9aca689f96b5c99d6c7311a813a721c67d840c7b440a159ee4a8de0c94645a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Enoch Powell")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469459")[#strong[#text("John Enoch Powell")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Why are you so afraid of views other than your own?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jhon Manugal")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469343")[#strong[#text("Jhon Manugal")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I think Donald Trump can win if he can persuade enough people to vote for him. Democrats and other Republicans grossly underestimated how many people reason like him, or in the presence of someone like him. Such populations have always existed latent in American society (and across the world). Then at any given time, they can express themselves.")

#text("It is a defect of reasoning of we feel there is only one type of candidate that can be successful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0bfe654e7e61077a4250cea1af3d142adc459802e863e37a26f483669eabcaad-44d9b34af6ad3f6d873675f1a54785a83a2e5f6c2faada20a5136f334915995c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Don")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469344")[#strong[#text("Don")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Some of the comments here remind me of an old New Yorker cartoon with a caption that proclaimed “Logic, the last refuge of a scoundrel!”")#linebreak()#text(" That said a better analogy might be a need for a phase transition in public perception of Mr. Trump. There are some promising signs that it could finely be happening. We can hope anyway… In the meantime, thanks for speaking out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cd7ea7575fc832fa77fe82b731bffcb2cefab3d2327ff7acdd92e94f97c9bef-77ed7bdc296e23c03398b8b2ae35654eb8a357164d9f7e840f2492574c02dc2c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Verjovsky")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469347")[#strong[#text("Alberto Verjovsky")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Thank you!! Very clear arguments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469348")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("What is logic but a summary of one’s experience mixed with a bit of what we would like to be true?")

#text("Trump’s candidacy States firmly that his views are representative of those of the American people.")

#text("Why do you have a problem with that? What is your problem Terry, that your views are not representative everyone else’s?")

#text("There’s a term for when one person’s views are held above all else. It’s called a dictatorship.")

#text("If / when Trump becomes president, the current American oligarchy gets replaced with another one. Maybe one not so favorable to you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5fb8d3ea7b87ff69aeca40d60f0e35587f359acc642ea394fda7eb22ea123c30-f238aa76aef7ab6a0df0eb868ab8522a09749dd6362249746264c2e1da8b0657.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469350")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("I think this raises a relevant point. People who recognize Trump and all of his flaws have trouble recognizing the flaws in their preferred candidate, even if the flaws are similar to those of Trump. Hillary Clinton is the wife of a former president, a former cabinet member, and was the sole serious candidate the Democrats were able and willing to put forth. (I consider Sanders to be an outsider.) This too really is not very democratic. Trump supporters would argue that people’s fears of authoritarianism under Trump have already been effectively realized. An entrenched system where ultimate insiders are only permitted to run for office. Recall that before the campaign season started, the most popular expectation was that it would be another Clinton vs Bush election. What democracy?")

#text("What of course Trump supporters do not realize is that there are things worse than “the system”, and that Trump is in that category. But I think there is some not recognizing the naked emperor in the anti-Trump camp, because their views are more aligned with those of the establishment. But if you live in a rural town with limited job opportunities and a heroin epidemic, hearing the anointed Official Next President say how great America is today, maybe you’d look for any alternative you can find.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab233cc31b81e8300bc14416925f0c0d28af63deac38bae7053b2e277678f941-5714c94ec8bc08939f0423d3b0041d900694f731e8f2225462fc27179fe1d441.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469425")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("> What is logic but a summary of one’s experience mixed with a bit of what we would like to be true?")

#text("It is exactly not that.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469351")[#strong[#text("Joel Grus (@joelgrus)")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")]

#text("As it happens, my view is that he *is* qualified; therefore it de facto cannot be *common knowledge* that he isn’t.")

#text("(More technically, whether someone is “qualified” for a job is purely a subjective opinion; as far as I know the usual “blue eyed islanders” common knowledge setup is not really appropriate for reasoning about such beliefs.)")

#text("(Then you insist that your assertion about Trump’s qualifications is somehow an objective truth, and then I point out that you’re essentially making a religious statement of faith, and then we’re at an impasse.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37b0d08f5f2d055b7ff6b43e8ce260e37635cfbbe685fa2907d90221498f54b6-19e5e87510ddfbd262bdc70204c0df79bd34c022881ca327d67204cd74267fa7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Rivin (@igriv)")]], [#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america/comment-page-1/#comment-469387")[#strong[#text("Igor Rivin (@igriv)")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("Mathematically, what you are saying is that TT’s argument is circular: his religious belief is that @realdonaldtrump is unqualified. Therefore he is unqualified! It gets better (a la Monty Python): anyone who believes Donald IS qualified, is obviously delusional, and should not be listened to. Sigh.")
]
]
