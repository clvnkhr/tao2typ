// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/10/20/math-overflow/
// Converted to Typst by tao2typ: "2026-10-14T16:35:54.859422+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Math Overflow", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Math Overflow")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 October 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/10/20/math-overflow/")[#text("https://terrytao.wordpress.com/2009/10/20/math-overflow/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’m lagging behind the rest of the maths blog community in reporting this, but there is an interesting (and remarkably active) new online maths experiment that has just been set up, called ")#link("http://mathoverflow.net/")[#text("Math Overflow")]#text(", in which participants can ask and answer research maths questions (though homework questions are discouraged). It reminds me to some extent of the venerable newsgroup ")#link("http://groups.google.com/group/sci.math/topics")[#text("sci.math")]#text(", but with more modern, “Web 2.0” features (for instance, participants can earn “points” for answering questions or rating comments, which then give administrative privileges, which seems to encourage participation). The activity and turnover rate is quite remarkable: perhaps an order of magnitude higher than a typical maths blog, and two orders higher than a typical maths wiki. It’s not clear that the model is transferable to these two settings, though.")

#text("There is an active discussion of Math Overflow ")#link("http://sbseminar.wordpress.com/2009/10/14/math-overflow/")[#text("over at the Secret Blogging Seminar")]#text(". I don’t have much to add to that discussion, except to say that I am happy to see continued experimentation in various online mathematics formats; we still don’t fully understand what makes an online experiment succeed or fail (or get stuck halfway between the two extremes), and more data points like this are very valuable.")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c8d284dd2ddbb40626c126309bc8e8f09a743a2912dbd9b7b72bfd1a29c8e63-fb26f3846087993e4a4209154a6ee4d8b3e21164c0e309de7f1e307e01f6612f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Morrison")]], [#link("https://terrytao.wordpress.com/2009/10/20/math-overflow/#comment-41910")[#strong[#text("Scott Morrison")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2009")])]

#text("I’ve been thinking a bit about whether the StackExchange software (which mathoverflow is running on) could be used to host a polymath project.")

#text("I’d imagine it involving many many questions and answers, with links between them, modelling the division of the “big question” into its constituent chunks.")

#text("There are some big advantages — in particular, it’s easier to pay attention to individual parts, because there’s more structure than in blog comments.")

#text("As a first approximation, you might start out like this: Terry asks the polymath7 problem, linking elsewhere for motivation and background. Tim posts a first ‘answer’: “Could we attack this by proving Lemmas X, Y and then generalising the approach of Theorem Z?” and at the same time creates questions corresponding the Lemmas X and Y and a more open question about Theorem Z. Other participants can then go to those questions to give their thoughts. Answers don’t have to be “answers” in the convention sense — they’re just meant to correspond to “ideas”, and should often link to a new question if it’s obvious that the idea needs further development. The StackExchange software allows for comments on answers, which would allow short responses to previous answers.")

#text("The big disadvantages of StackExchange are that")#linebreak()#text(" * at this point, there’s no LaTeX support, although this will hopefully change.")#linebreak()#text(" * the reputation system inhibits new participants, at least at first (they can still ask and answer questions, but commenting and upvoting are limited).")#linebreak()#text(" * it may end up harder to understand the “big picture” than in a blog thread.")

#text("The solution to the first two of these may be to try a polymath project at mathoverflow.net itself, rather than a new installation. Many participants will already have reputation (and on an established site it’s very easy to gain enough reputation to comment and upvote, because any decent question will quickly garner reputation). It’s easy to filter questions by tags, so I think you could ignore everything else happening on mathoverflow.net if you wanted to.")

#text("The last problem might be addressed by having a “community wiki” answer at the top of each question, summarising progress so far, as well as regular progress reports on blogs.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c8d284dd2ddbb40626c126309bc8e8f09a743a2912dbd9b7b72bfd1a29c8e63-fb26f3846087993e4a4209154a6ee4d8b3e21164c0e309de7f1e307e01f6612f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Morrison")]], [#link("https://terrytao.wordpress.com/2009/10/20/math-overflow/#comment-41911")[#strong[#text("Scott Morrison")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2009")])]

#text("I “top-posted” this over at the ")#link("http://sbseminar.wordpress.com/2009/10/20/polymath-projects-on-stackexchangemathoverflow/")[#text("Secret Blogging Seminar")]#text(" after realising it was a little lengthy for a blog comment.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/20/math-overflow/#comment-42263")[#strong[#text("Test Your Intuition (10): How Does “Random Noise” Look Like. « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")]

#text("[…] I should try to ask the problem also on “math overflow“. See also here, here and here for what math […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43dd7a3a0aa801d74b8a44fdefc6caefe690d220397eb473bb159b6b9da4928e-12c10826ee2b3fe2c268ec35bedb94b1854f4102fda2841c431943fc7764b5b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asdf")]], [#link("https://terrytao.wordpress.com/2009/10/20/math-overflow/#comment-42498")[#strong[#text("asdf")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2009")])]

#text("Wikipedia’s math reference desk is pretty good:")

#link("http://en.wikipedia.org/wiki/wp:Reference")[#text("http://en.wikipedia.org/wiki/wp:Reference")]#text(" desk/Mathematics")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43dd7a3a0aa801d74b8a44fdefc6caefe690d220397eb473bb159b6b9da4928e-12c10826ee2b3fe2c268ec35bedb94b1854f4102fda2841c431943fc7764b5b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asdf")]], [#link("https://terrytao.wordpress.com/2009/10/20/math-overflow/#comment-42499")[#strong[#text("asdf")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2009")])]

#text("This link may work better:")

#link("http://en.wikipedia.org/wiki/wp:Reference_desk/Mathematics")[#text("http://en.wikipedia.org/wiki/wp:Reference_desk/Mathematics")]
]
