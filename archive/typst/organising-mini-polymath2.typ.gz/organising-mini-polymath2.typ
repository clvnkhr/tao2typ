// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/06/21/organising-mini-polymath2/
// Converted to Typst by tao2typ: "2026-10-14T16:36:13.905082+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Organising mini-polymath2", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Organising mini-polymath2")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 June 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/06/21/organising-mini-polymath2/")[#text("https://terrytao.wordpress.com/2010/06/21/organising-mini-polymath2/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This is a continuation of the ")#link("https://terrytao.wordpress.com/2010/06/12/future-mini-polymath-project-2010-imo-q6/")[#text("preceding post")]#text(" regarding the setting up of the mini-polymath2 project. From the discussion, it seems that it is best to start at some fixed time, either on July 8 or July 9, to ensure an orderly opening to the project and also so that I can select which of the six questions would be most suitable for such a project.")

#text("I have set up a placeholder wiki page for the project ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2010")[#text("here")]#text(", though right now it is necessarily quite bare.")

#text("There wasn’t much feedback on where to host the polymath project, but I am thinking of hosting the main project over on the ")#link("http://polymathprojects.org/")[#text("polymath blog")]#text(", in order to take advantage of the slightly better threading format there (numbered comments and nested comments in particular, although unfortunately there is no comment editing capability), and also because it would be technically easier to have multiple moderators on that blog. When the project begins, I will also announce it in a brief post on this blog, which can then serve as the “meta” or “discussion” page for the project.")

#text("The one thing that I need to fix before the project begins is the starting time. I do not know exactly when the Kazakhstan local IMO organising committee will release the full list of questions, but presumably they should be available by, say, noon July 8 at Kazazhstan time (GMT+4), or about 8am July 8 GMT, which would probably be the earliest feasible starting time. Given that I am at GMT-8, the next reasonable starting time would be about eight hours later, at 4pm July 8 GMT. Below is a poll regarding what times participants would most prefer and least prefer, spaced at 4 hour intervals:")

#metadata(none) <tao-f92e2271712416a5feb8>

#metadata(none) <tao-a4a6b6020de6327ca341>

#metadata(none) <tao-be8b0bc99a441de8ae4b>

#text("I’ve set it so that up to three answers may be selected. I am also open to other suggestions regarding the starting time. I encourage everyone who is interested in participating to select some times for the poll. Note: the times given are with respect to GMT. A list of some representative time zones and their UTC offsets (which are more or less equivalent to GMT offsets, modulo daylight savings issues) can be found ")#link("http://en.wikipedia.org/wiki/Time_zone")[#text("here")]#text(".")

#text("With this feedback, I should be able to select a reasonable starting time. The previous mini-polymath was active for about 48 hours (in particular, continuing to produce alternate solutions well after the first one was posted), and I would expect something similar here. I am hoping therefore that provided there is some effort by participants to help bring people up to speed, that one could drop in even several hours after the formal start of the project and still be able to contribute.")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/087efbd64dbb2bf3003cb0fe9d7cf1229bad84470d1637450d2d5f36eaa73bc9-3cee5444008f795ba5d1dd46a139a06cdd7870234ded3639372d93dcdead54da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mmailliw/william")]], [#link("https://terrytao.wordpress.com/2010/06/21/organising-mini-polymath2/#comment-45616")[#strong[#text("mmailliw/william")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2010")])]

#text("I’m pretty sure that your time zone information is incorrect (in a way that almost cancels each other out).")

#text("With GMT = UTC, Atsana’s time zone is GMT+6 (not +4); it is in the eastern of the two Kazakhstan time zones.")

#text("Further, with daylight saving time (observed in California but not in Kazakhstan), California is currently at GMT-7 (not GMT-8, which would be correct in the winter).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/087efbd64dbb2bf3003cb0fe9d7cf1229bad84470d1637450d2d5f36eaa73bc9-3cee5444008f795ba5d1dd46a139a06cdd7870234ded3639372d93dcdead54da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mmailliw/william")]], [#link("https://terrytao.wordpress.com/2010/06/21/organising-mini-polymath2/#comment-45617")[#strong[#text("mmailliw/william")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2010")])]

#text("I was 1 hour off with the Kazakh time; Atsana is in the other Kazakh time zone (GMT+5)!")

#text("(So the conversion between Atsana time and California time is exactly as you had it; it’s only the conversion to GMT that’s off).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d084d144f22860131bf45031f77c83a1b623ef01cde684f9f2e6454920339ff6-527b58d31bd0ad0ecabac5708bf4ba225ffae6cee0e00b645036f2e226cc51de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nurdin Takenov")]], [#link("https://terrytao.wordpress.com/2010/06/21/organising-mini-polymath2/#comment-45621")[#strong[#text("Nurdin Takenov")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2010")])]

#text("The time in Astana is UTC +6. AFAIK it’s 12:55 in Astana now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4ad6c18186ffa1aab4aadbb6437ddfdfd03ffdb28fa7b75fb5a4b74dadd060d-b17876bb6ed44b4eb4e6f409d6e9c2e04bf2fd6789fad7fda897a642de72445e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mini-polymath proposal: IMO 2010 Q6 « The polymath blog")]], [#link("https://terrytao.wordpress.com/2010/06/21/organising-mini-polymath2/#comment-45619")[#strong[#text("Mini-polymath proposal: IMO 2010 Q6 « The polymath blog")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2010")])]

#text("[…] June 20: a new post to set up the starting time is here.] Leave a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43f6fd83668935da0d0c70a669432cf5eb387b8faa5576153ca95d588e50eca3-ba65af4f8d940a2eb73d6e1943bd99ab517942572df95a5b8ab817a1dfc89aee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Woett")]], [#link("https://terrytao.wordpress.com/2010/06/21/organising-mini-polymath2/#comment-45636")[#strong[#text("Woett")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2010")])]

#text("Great project! Hopefully I´ll be able to remember this (I’m quite forgetful), and make a tiny non-trivial contribution myself. Looking forward to it!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/19f86090bbdafb63e5413723967942d72d32936735e550513dad291b95f66c5f-496e402e3b1ba204923bce7da6313b07f7d06a479d6b9bdda79a4e537f99801e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jonas")]], [#link("https://terrytao.wordpress.com/2010/06/21/organising-mini-polymath2/#comment-45662")[#strong[#text("jonas")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2010")])]

#text("You are missing an option at the middle (July 8 noon) if you really want them to be spaced 4 hours apart.")

#text("Also, for the timezones, you may want to link the options to “http://www.timeanddate.com/worldclock/fixedtime.html?year=2010&month=7&day=8&hour=16&min=0&sec=0&p1=0” and similar.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/06/21/organising-mini-polymath2/#comment-45665")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2010")])]

#text("Thanks for the link!")

#text("The reason I omitted July 8 noon is that I am not particularly keen on starting the project at 5am Los Angeles time. ;-)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/21/organising-mini-polymath2/#comment-45761")[#strong[#text("Mini-Polymath2 « Euclidean Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2010")]

#text("[…] By kristalcantwell There is a post here about the organization of the upcoming mini-Polymath project. It should start July 8 or 9. There is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/06/21/organising-mini-polymath2/#comment-47208")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2010")])]

#text("Dear Prof. Tao,")

#text("I would like to suggest an idea on math olympiads and Putnam competition.")#linebreak()#text(" Why do not we solve all math olympiad and Putnam competition problems of the")#linebreak()#text(" previous year each year? For example, each weekend you could start a thread on one problem from olympiads and we could try to solve collaboratively. Then we start to solve Putnam problems of the previous year. In that case your blog could be accessible to high school and undergrad students..")

#text("Thank you very much")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mini-polymath 3: 2011 IMO question « What’s new")]], [#link("https://terrytao.wordpress.com/2010/06/21/organising-mini-polymath2/#comment-53698")[#strong[#text("Mini-polymath 3: 2011 IMO question « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2011")])]

#text("[…] participation). For ease of comparison I am going to use the same four-hour time slots as for the 2010 poll. All times are in Coordinated Universal Time (UTC), which is essentially the same as GMT; […]")
]
