// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/07/27/poincares-legacies-now-published/
// Converted to Typst by tao2typ: "2026-10-14T07:25:22.704949+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "“Poincaré’s legacies” now published", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("“Poincaré’s legacies” now published")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 July 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/07/27/poincares-legacies-now-published/")[#text("https://terrytao.wordpress.com/2009/07/27/poincares-legacies-now-published/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("My two-volume book, “")#link("https://terrytao.wordpress.com/2009/07/27/books/poincares-legacies-course-notes-expository-articles-and-lecture-series-from-a-mathematical-blog/")[#text("Poincaré’s legacies: pages from year two of a mathematical blog")]#text("“, which was based on the 2008 posts of this blog, ")#link("http://www.ams.org/bookstore-getitem/item=MBK-66")[#text("has now been published")]#text(" by the ")#link("http://www.ams.org/")[#text("American Mathematical Society")]#text(".")

#text("[")#emph[#text("Update")]#text(", Aug 3: Actually, only the first volume has been published so far. The second volume of this book will be available on Aug 10.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thuris")]], [#link("https://terrytao.wordpress.com/2009/07/27/poincares-legacies-now-published/#comment-40718")[#strong[#text("Thuris")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2009")])]

#text("Congratulations!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd4bfb06bd050a989093ed573685723febc2f7fbc97be93869ddd8bab3257fc9-7fe956b9f8b7dae1686b686a0691c02b9667dd8802e8de59c9cf328efac02d71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A semana nos arXivs… « Ars Physica")]], [#link("https://terrytao.wordpress.com/2009/07/27/poincares-legacies-now-published/#comment-40722")[#strong[#text("A semana nos arXivs… « Ars Physica")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2009")])]

#text("[…] “Poincaré’s legacies” now published […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/27/poincares-legacies-now-published/#comment-40730")[#strong[#text("A semana nos arXivs… | Phasing")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2009")]

#text("[…] “Poincaré’s legacies” now published […]")
]
