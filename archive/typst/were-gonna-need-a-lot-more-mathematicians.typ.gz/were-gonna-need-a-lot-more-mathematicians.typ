// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/
// Converted to Typst by tao2typ: "2026-10-25T11:51:25.837059+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "We’re gonna need a lot more mathematicians", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("We’re gonna need a lot more mathematicians")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/")[#text("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-25 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://web.cs.ucla.edu/~sahai/")[#text("Amit Sahai")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("When I was an undergraduate student, I remember talking with several students who felt that the pace at which the top students could understand new math concepts was far too fast for them. They, too, could understand the ideas, but it would take them much longer. Eventually, almost all of these students gave up their dream of pursuing research mathematics and found something else to do. I have been thinking about those students a lot in the last few days.")

#text("The research mathematics community consists largely of those of us who either rarely felt that way, or who felt it and managed to overcome it through hard work. We have had the good fortune to find a place in mathematics where we could make progress. But we are now entering a time for humility: a time when all of us are going to know what it feels like to be unable to keep up.")

#text("The AI systems I have worked with are already producing beautiful new ideas. They are doing far more than impressive calculations or quickly carrying out arguments that a strong human researcher would already understand. And we probably can’t even imagine the wonderful ideas that future systems will be capable of producing.")

#text("When we feel that we cannot keep up, will we take that as a reason to leave research mathematics, like the students I am remembering? As more of us experience this, there will undoubtedly be a temptation to draw the same conclusion as they did: If the machines can move so much faster than us, perhaps we should find something else to do.")

#text("For our community to give up the work of understanding would be a profound abdication of our responsibility to humanity. Each of us is entitled to choose a different life. The responsibility I am talking about belongs to us collectively: to build a future in which humans can understand and contribute to the discoveries that will change our world. A future with meaningful human agency.")

#text("Struggle is essential to understanding difficult concepts. Fortunately, this struggle can be shared. I have been blessed to experience this time and time again with my students and collaborators. Imagine a multitude of research groups, each with sustained support, each spending a term or a year trying to understand an extraordinary set of ideas produced by an AI system, with the help of AI systems. [1]")

#text("This may very well be among the most important mathematical work in the years to come, and we should support and prioritize it accordingly. This enterprise will require a significant expansion in the number of mathematically sophisticated human researchers available world-wide, as major breakthrough ideas accumulate.")

#text("Why should society want this? So far, this might sound like a utopian fantasy for us – a civilization focused on depth of human understanding, awash with mathematicians and physicists and the like. I would certainly love to live in such a world. And indeed there are deep philosophical reasons for society to move in this direction. But I think society has a much more immediate stake in making this possible, too.")

#text("Imagine that a future AI system proposes a radically new design for a one terawatt nuclear fusion power plant. It has found a way to sustain and control fusion that no human had conceived of. The design promises abundant, inexpensive, clean electricity. Robots stand ready to manufacture the components and build the plant.")

#text("A terawatt is an insane amount of electrical power. We would be deciding whether to construct a machine that handles extraordinary flows of energy using principles we have never conceived of, let alone put into practice. We would need to understand how failures can be contained, what happens to energy already stored in the system when it shuts down, how we can be sure that the materials that make up the power plant behave as expected, and what other questions we should ask before proceeding. The very novelty that makes the proposal exciting would mean that we cannot inherit confidence from decades of operating similar plants or experiments.")

#text("Before approving construction, I would want communities of humans to understand why the design works and what justifies confidence in its safety. I would hope that we all would.")

#link("https://www.nature.com/articles/s41562-024-02024-1")[#text("Human involvement does not automatically improve a technical decision")]#text(" , and I see no reason to insist that humans manually repeat work an AI system might be able to perform more reliably, even including proving mathematical guarantees. But a theorem can only exist within a model. Understanding the guarantee means understanding the model, the experimental evidence for it, and our uncertainties about the accuracy of the model. This is demanding work, and mathematically sophisticated people must be available to engage with it.")

#text("One might respond that AI systems should handle those questions too, and ultimately decide whether the plant should be built. That is a serious position. But it asks us to accept a future in which decisions of enormous consequence rest on reasons that no human community understands.")

#text("I do not want us to arrive at that future simply because we failed to invest in our own capacity to understand. Human agency is a value of fundamental importance. We must retain the ability to meaningfully consider alternatives and decide what kind of world we want to be a part of building. I think it is worth the effort. [2]")

#text("To take on this responsibility, we may need to broaden our view of what a mathematician can contribute. I have in mind something like a “deployable intellectual reserve”: communities of mathematically sophisticated people that humanity can call upon to help understand consequential AI-enabled breakthroughs.")

#text("Our ability to understand difficult and unfamiliar ideas may become one of the most important contributions we can offer to society. We should be willing to bring that skill to problems far beyond our usual research interests. [3] Doing so asks us to expand our sense of our vocation.")

#text("A counter-argument might be that AI systems will make each of us so much more effective that fewer people could do this work, even as the pace of discovery accelerates. But each of us is merely human. We have fundamental limitations based on our biology. Depth of understanding needs time and a pace of life that humans can sustain. Each individual human can only be asked to do so much, but through earnest cooperation we can accomplish much more.")

#text("If AI fulfills its promise, we will encounter more beautiful and consequential ideas than we have ever seen. We must respond by building thriving human communities that can understand them together.")

#text("We’re gonna need a lot more mathematicians.")

#emph[#text("The ideas and opinions presented here are entirely my own, but GPT 6 Astra was instrumental in helping me draft this note. I also thank my former student Dakshita Khurana, my current student Isaac Hair, my colleague Terence Tao, and my family members Anant Sahai and Gireeja Ranade for valuable feedback. Note that there is much more to be said here, but I tried to keep this relatively short to focus succinctly on my primary thoughts.")]

#strong[#text("Notes")]

#text("[1] By this, I do not mean to imply that only AI-created results will be of interest in the future. But for major results generated by humans, we already have a tradition of spending extended periods of time studying them.")

#text("[2] And the relevant understanding cannot belong only to the organization proposing the technology. Imagine a public hearing at which the company’s experts are the only people capable of following the technical argument. Independent expertise is critical.")

#text("[3] Indeed, AI systems are likely to be very helpful in allowing researchers with diverse backgrounds to talk effectively with one another, and more generally understand unfamiliar concepts.")

#heading(level: 1)[#text("Comments (74)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696306")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("So how are we going to create more permanent jobs for mathematicians? Can we promise to be less selective and gatekeepy when hiring for faculty? When it’s this difficult to land a tenure track job, much less a dream job, or even a job in an ideal location, what incentive is there for young mathematicians to continue if the excitement to prove the theorem of their dreams and maybe receive social recognition for it is gone?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696351")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Your first two points are valid, as is the difficulty of landing tenure. Society will have to confront this.")

#text("But your last point is what this essay is meant to address. Young mathematicians will no longer get the excitement and credit of proving new theorems. But they will play an essential role in preventing human disempowerment and existential risk.")

#text("It is a very significant responsibility, and essential for human civilization. Just like 100s of other roles which recieve no credit but are essential for functioning of human civilization. Nobody is special, everyone has a part to play.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696360")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("My point is that we should give up trying to fully restore this excitement, and only partially restore it, but make pursuing mathematics more materially appealing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696506")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("But I think that most of the jobs of mathematicians are out of love. Do you let someone who wants to work for three days and earn tens of thousands be a mathematician? When mathematicians are not out of their own love, but out of the human community, mathematicians will become rarer and rarer. This is the same as the prisoner’s dilemma. Everyone knows that this exists, and everyone knows that they have to pay for human beings. But if, because of paying, they kidnap individuals to do math, then everyone gives up out of their own choice, and the whole industry gives up")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696493")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("If everyone is able to get a job at an ideal location, who is going to teach the students and build the research community in other places?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696309")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("Another monologue by a tenured faculty in which no concrete policies, ideas, or ethical standards are suggested. The point of this article was… what?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696327")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("My experience with tenured academics aged 55+ is that they simply do not get it. They live in a trance-like state that I would describe as a linear combination of denial and naivety. I mostly work with folks twice my age, and it is just constant humble (?) bragging about how many national grants they won back in the day (when the success rate of some of them was over 30%). Honestly, I would like to see them try to apply for, say, a Marie Curie fellowship. They seem to have no clue how devastating this will be for younger generations of PhD students and postdocs.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696334")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("On the contrary, I think posts like this are an attempt to provide leadership in a difficult time. We expect more senior figures in our community to do exactly this. The difficulty is that people have different opinions about what is an acceptable future.")

#text("In my opinion some views about what we want in the future are simply not tenable. This causes a lot of difficulty in bringing the community together.")

#text("Many people, including myself, believe that there is simply no future for the way we have done mathematical research for the last 50 or so years. It is very enjoyable to spend days/weeks/months/years thinking about a problem and solving it with no AI assistance, but it isn’t a contribution to mathematics if it can be recreated in a short period of time (minutes, hours) by using AI, with a full and understandable solution and even accompanied by a formal proof.")

#text("I’m not saying all problems can be solved so quickly, but the vast majority of research articles published are in this category. And these are the articles that sustain a professional mathematician’s career, with their postdocs and students. The steady, incremental work that takes serious mathematical thinking and insight, but which can now be accelerated with AI.")

#text("Putting aside concerns about priority, etc., whether we should read a paper should be proportional to the amount of time it would take to recreate its content for ourselves, using available tools, and understand it. Many research articles simply do not pass this test anymore. I believe we have implicitly used this test in the past, but it was much easier to pass.")

#text("In my opinion, people in the community suggesting that we can try to continue as we have done and ignore the change that has been brought by this technology are very well-intentioned. But following their suggestions does not seem like a good idea for future career prospects.")

#text("I am personally very concerned about future prospects for jobs, hiring, evaluation, etc. Also universities, teaching, training, the much wider job market. One issue is that it is hard to make good decisions about how to evaluate mathematicians if we don’t yet agree on what a mathematician will be doing or aiming for in the future. I would hope that we can find a way to do this in a way that is fair and makes the job exciting. It’s also hard to predict how many people will be professional mathematicians when we don’t know what the job will involve, and this will have a large impact on the level of competition for positions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ff3d77ab7c8eb8d8f174ccb9e5bc8d18c5dd6b58f0aa41aa095d3e81ab769a-7a8fcdc37963ca24eb97792a0541861e294b616735971b060dd04f4fde09fa37.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696341")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("I’m a tenured academic and here is my opinion, hope you’ll find it useful.")

#text("Research used to be far in front of the industry. Now we have proof that the “unwashed” industry is able to produce results far better than the academic research in mathematics, according to the present academic community standards and goals.")

#text("If the industry filled the gap it means that the academic research is in a dire state, which only now is forced to admit.")

#text("Therefore the hierarchy and goals of the academic community are under question: publish or perish for points, problem solving because is measurable, competition for little money by using these points.")

#text("As the tenured part is there because they complied with the present system, and because now it turns out that industry is better than research, there is panic and of course that the tenured choose to live in denial.")

#text("The untenured wil suffer the most, until the research will heal back and it will go, again, far in front of the industry.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696457")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("this comparison between industry and academia is interesting, but I think it misses there is another side to it that may be more important than research being in a bad state. From a business perspective these companies have essentially lit money on fire to do the work of mathematics with no real tangible benefit other than a massive flex before their IPOs.")

#text("This doesn’t bode well for either the future of academia _or_ industry regardless of the current mania claims to transcendence. If the general economy has no where else to funnel its investment capital other than these marketing flexes and simultaneously the research world cannot receive enough money to do basic science, we’ve already lost the game as a body politic – to make generous claims about what this means as a species assumes American scientific and economic priorities will always be at the front of the pack.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ff3d77ab7c8eb8d8f174ccb9e5bc8d18c5dd6b58f0aa41aa095d3e81ab769a-7a8fcdc37963ca24eb97792a0541861e294b616735971b060dd04f4fde09fa37.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696473")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("Research creates and businesses scale. But research became a business to write articles for karma points which we exchange for some real money, while the articles are sold back to us by another business.")

#text("We adapted to this by turning research into problem solving, aka mining the mass of articles we produced.")

#text("Now another industry found that it can scale this by mining the mass of articles, better than us. They do this just to show off, because anyway our mass of articles is tiny compared to the quantities they can process.")

#text("The industry who sells us back the articles we write has a problem with that.")

#text("The owners of karma points are worried.")

#text("The young don’t see a future in getting karma points like their professors.")

#text("Is not that AI will replace mathematicians, see?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed3901f34a75128815ba3db17d23830926b7799322169ada40850efac4b56452-88e5c4a7712cdce0086e9b46d2ff4fc0667f7f35c7a843d95af19fa780a8402f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cefpisahai")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696370")[#strong[#text("cefpisahai")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Thank you for writing in response. This is undoubtedly a time of “wonders and terrors” as Scott Aaronson put it. I don’t mean to downplay the difficulties that junior people face right now. As far as concrete proposals, I’m a co-organizer of a Simons effort to address the current state of affairs, and we will be releasing a report soon with many concrete action items.What my blog post was meant to convey is that we are at a “fork in the road” moment as a species. We can either yield more and more of the effort of understanding to the machines, or we can see the “thinking” of the machines as a great gift to us, to deepen our own understanding. As a species, as a civilization, and as individuals, I hope we make the latter choice. This post is meant to motivate that choice.I don’t have the direct power to funnel large sums of money toward this undertaking, but I am trying to do my part to motivate the people who can make this happen.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696338")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Indeed, many blog posts center around what makes mathematics intellectually worth doing. I think that’s virtually a non-issue. Many people still think mathematics is intellectually worth doing. What none of the blog posts address is the practical bargain one makes when choosing mathematics as a career: one chooses a lifestyle of pursuing exciting mathematics at the cost of dealing with low pay, unstable positions, extreme competitiveness, and possible systemic bullying (as a junior PhD student).")

#text("As I see it, for many people, AI has essentially made this bargain not worth taking. Many blog posts center around salvaging this bargain, but I think to reform academia, one must do something more fundamental. This post has the right idea that we must hire new mathematicians, but doesn’t consider any of the practical aspects of it. There’s virtually no infrastructure or funding in place for this.")

#text("Also, we have fostered a culture of competitiveness in academia, and it will be difficult for us to correct this, be less selective, and create more jobs. For instance, “Oh, I had to work so hard landing a tenure track job at X; why do ")#emph[#text("they ")]#text("have such an easy time finding a job?”")

#text("I think academia has to take a deep look at itself and figure out how to make mathematics materially worth doing, and not an intellectual bargain at the cost of a material loss.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696441")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("best post on this entire website.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696340")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("To sketch one possible scenario of where these changes might lead us. In times of big uncertainty it might be useful to have such visions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696310")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("I wonder if those students left mathematics because the ideas took too much time to understand, or if it was the realization that no one would pay them for indulging in their love for the subject. I hope it is the first.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696326")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("I could be a little bit of both. They might have realized that nobody is willing to pay them because they are too slow in generating good mathematical ideas (or perhaps too slow with furnishing them into publishable papers).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0638f8025e96d915d66b224c4075737a02701e62e30a2d836fcda36598360d3-bb0d4ee5ce1d65f1f1daab94cbddb5f4ca0c1db5e7927da2097f36f3aeb988dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696313")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("If AI can do math research (proving theorems and producing counter examples) at a cheaper rate than human mathematicians, let them do it. Mathematically talented people of the future generation will find something else for their livelihood. My take is that the former will not happen. This is because AI companies will have no reason to do this, with no return on investment. Currently they are doing it for its shock value, in stock market.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696352")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Future AIs will do it autonomously because the cost of this will be pennies.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696390")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Indeed, I have always found thought to be a burden and am thrilled I will not need to bother anymore.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696316")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("Amen 🙏")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696317")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("This tracks very closely to how I think things will go.")

#text("I think the helicopter to the top of the mountain is a good analogy if we’re using AI to solve basic problems that we solved before, but with less effort.")

#text("When ai is truly discovering new things it will be like taking a helicopter to a Narnia like world, and yes you missed a lot of what got you there, but also everywhere you look is foreign, fascinating and fertile ground for further discovery.")

#text("You shouldn’t be using ai solely to do things you did before but more easily, you should be using it to do things you could never do before.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696319")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("Yes, there will be so many amazing things — thousands of new papers every day — that nobody will even have the time to read any of them!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696358")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("An AI will do It. Human intervention will be a bottleneck for the scientific and technological progress that AI could provide by itself.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josh Samani")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696320")[#strong[#text("Josh Samani")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("I very much want to believe the conclusion of this post. When I read the following, my heart was with you:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("One might respond that AI systems should handle those questions too, and ultimately decide whether the plant should be built. That is a serious position. But it asks us to accept a future in which decisions of enormous consequence rest on reasons that no human community understands.")

#text("I do not want us to arrive at that future simply because we failed to invest in our own capacity to understand.")
]

#text("But I wonder how much of the case for that investment should rest on its role in consequential decision-making.")

#text("We already trust autonomous vehicles with our lives, and if a future medical AI were demonstrably more reliable than human doctors, I could imagine reasonably choosing to follow its advice even though humans may not have the capacity to fully understand the reasons for its recommendations.")

#text("Your example of an unprecedented fusion plant poses a different problem: an AI may lack the track record on which such confidence might rest. But what if AI systems eventually become demonstrably better at assessing unfamiliar risks as well?")

#text("Because of this possibility, I wonder if we’d be better served emphasizing arguments for cultivating deep human understanding that don’t depend on its being necessary for justified trust in consequential decisions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696347")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("“We” is doing a lot of work in that sentence. I think you should look into that statistic before assuming it is true. We do in fact not trust autonomous vehicles at all, down to single digits at this point.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696354")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Autonomous vehicles are far far safer than human drivers. In fact we essentially murder people when we ban autonomous vehicles.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696372")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("I don’t feel like I disputed that? I’m sorry if I was unclear. I meant statistics for trust, not actual accidents, as they are and never will be the same.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696373")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Yeah, I read myself again, it definitely wasn’t clear what I meant. Sorry.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696359")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Fair point. “Some people” would have been more precise than “we.” But my argument doesn’t require broad acceptance today. People may increasingly delegate consequential decisions as systems become more reliable. That makes me hesitant to ground the case for deep human understanding too heavily in its necessity for justified trust in those decisions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696382")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Absolutely, and I do agree with the overall point. It was not my intention to be pedantic, I am genuinely curious how this will evolve. I was just observing that full autonomy is not gaining adoption, and I wonder if that will ever change. I can imagine that the curve would look more or less the same. There is only ~7 years of data on this though, I might be extrapolating.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696504")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("We don’t really trust the vehicle, we trust the engineers and service crews behind it. We trust everyone who has ridden before and that they had a good experience.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696322")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2026")])]

#text("There are plenty of examples in mathematics where a proof is published and only years later is a flaw or gap discovered. One famous example is Andrew Wiles’ original proof of Fermat’s Last Theorem.")

#text("If one can formally verify such historically flawed proofs in Lean, what does that tell us about Lean itself? More specifically, what can we conclude about the reliability and role of Lean when formalizing mathematical proofs that were once believed to be correct but were later found to contain gaps?")

#text("Anyone interested can use AI tools to identify historical flawed proofs that could serve as interesting case studies for formalization in Lean.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696332")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("The lacuna in Wiles’ original proof was found within a few months, and overcome within a year of its discovery.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696331")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Blame the AI companies for creating this mess in the first place. OpenAI didn’t need to create 100 proofs and “humble brag” about it. AI used responsibly would be a good thing, but that’s not what OpenAI and Anthropic is doing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696343")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Extremely valid point. Was all of this… ")#emph[#text("necessary")]#text(" in the first place?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696419")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("Even if OpenAI (or Anthropic or any other company) hadn’t done this, once the models are released, some mathematician or student was going to try this.")

#text("Scaling model sizes was almost an inevitability since it was the most straightforward (with tremendous computing infrastructure complexity and many tricks) set of experiments to run. Once this direction turned out to be fruitful, everything just flowed. At a high level, there isn’t much more to the game than pretraining -> instruction tuning -> post-training incl. alignment (RLHF, DPO etc.) + long-horizon agentic tasks with verified signals.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696333")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Not a well thought out post. I did not understand the point of this post at all and found it meandering and out of touch of the reality that many of us (younger people) face in our day to day lives.")

#text("Also I do not appreciate how tenured faculty simply use GPT to draft what should be more well thought out posts in a time of crisis")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a32f136fc144ff270f8416c2063ecc96f9f8b0a133f7b17509a8db62a4291816-be7d069f7d5b6258b20f1a2779f7d53047043bb94a51baef2a19d70f80edebfd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alexsotirov")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696335")[#strong[#text("alexsotirov")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("I think the AI progress in math gives a situation exactly opposite to what you are describing: the students who gave up because they couldn’t get something fast enough gave up because no one had the patience to explain lucidly and carefully. With AI the opposite happens: if you don’t understand something you can keep asking — the algorithm keeps explaining to you in a fashion tailored to your confusion. The result is that your chance of “getting it” is much higher. This holds true even at research level.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696336")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("A computer science professor tells everyone how wonderful AI is. Let them eat cake!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696342")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Thanks for this article. I noticed it received some critical remarks, some on the basis of your age and seniority. I work in computer science and had a discussion with a young CS entrepreneur recently who presented the same point you are making in your article. He argued that universities will play a very important role and that it no longer suffices to get a few people close to brilliance, but that we need to find ways so more people can contribute to assimilate AI information and at the same time further human intelligence. This industrial revolution is a scary time which makes life hard for anyone caring deeply about mathematics. At the same time, the opportunities are incredible. Companies such as Hugging Face provide opportunities to install your own AI locally and give you the power to contribute in entirely new ways.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696344")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("How many times have the word “understand” have been used in this blog in the past weeks? Far too many, given that none of the posts stops to investigate:")

#text("1. What is it?")

#text("2. How can machines emulate it?")

#text("3. What are the consequences for us, of an scenario in which both us and machines can generate whatever “understanding” is?")

#text("4. What is and how does it relate to the narrower notion of “human understanding”?")

#text("5. To what extended is the latter a (last) hope for control? What are other sources of control?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696345")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("“When we feel that we cannot keep up, will we take that as a reason to leave research mathematics, like the students I am remembering?”")

#text("Hat tip to Jacob T. and Timothy G.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696346")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("i dont understand this fantasy about AI solving nuclear fusion. We arent using nuclear fission to make energy at scale because of social and political reasons. But this is how AI zealots talk, like every problem in the world is a good LLM session from being solved. Very few of our problems are bc of a lack of understanding or tech, and i think AI will only make it harder to deploy the solutions we do have.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696356")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("You do not understand comparative advantage. If someone refuses to move along to progress, they will be outcompeted by people willing to take the risk. Just like mathematicians who don’t use AI will be outcompeted by the Mathematicians who do use AI.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696398")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("We aren’t using fission at scale because it’s not competitive. If it were, the putative social and political obstacles would evaporate.")

#text("Fusion promises to be even more expensive, for fundamental reasons.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce71270d4846fd1082dd25b8db2bb06413ef883697910cd4e396961f4022bd7f-421e454d906df85047ff858aef5150393d1d84c96027a3416851d8441feb7ad2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim Fierens")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696363")[#strong[#text("Tim Fierens")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("I think math needs to go through a development that is somewhat analogous to the evolution of the 50-moves rule in chess.")

#text("Before endgame tablebases became feasible, there used to be a few exceptions to the 50-moves rules, because it had been demonstrated that forced mate takes longer than 50 moves for certain endgames (like King and two Knights against King and Pawn). But as the tablebases came out, it appeared that there are many such endgames, some with forced mates in the hundreds of moves. So it was decided to end all exceptions, thereby rendering the “superhuman” mates in the tablebases wholly irrelevant to human chess.")

#text("Likewise, if we want human mathematics to survive as a meaningful (and fun!) activity, we could simply ignore all AI-generated results whose verification is in principle too difficult for humans. I reckon the field of yet unknown math results that are human-understandable in principle is practically infinite, even if it has negligible density compared to what AI can generate and verify in principle.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696385")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("this is stupid math is not a competition game. It’s about understanding the current reality we live in.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696474")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("Never said math was a ")#emph[#text("competitive")]#text(" game. (Though it does have many features of an exploration-type game. But that’s another discussion.) My main point was that chess survived incomprehensible machine-generated “truth slop” by simply relegating it to irrelevance, so why shouldn’t math? There’s still plenty of math left to be discovered (with or without the aid of AI) that does fall within our human cognitive horizons.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696364")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("I deeply resonate with perspective; we need to understand, or approach understanding, and not throw up our hands. The act of understanding appears to be a fundamental component of what it “Is” to be Human.")

#text("I have come to realize that the “Questions” and process of “Being” unaware/un-conscious of much of the phenomena of “Natural Reality”, to be equally as important to dis-coverings, and maybe even more important. Acknowledging the “unknown/gaps” in our individual and collective consciousness/understanding, and with awe and humility, seems like the most important/appropriate approach, in this new and evolving world.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696365")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text(">> One might respond that AI systems should handle those questions too, and ultimately decide whether the plant should be built. That is a serious position. But it asks us to accept a future in which decisions of enormous consequence rest on reasons that no human community understands.")

#text("There may be another rationale for continuing to train human mathematicians, including and especially at the highest possible levels, than merely rooting for the philosophical choice of not ending up as a lazy humanity with little/no mathematical understanding, asymptotically leaving everything to AI except for the occasional chess-type games, to put it bluntly.")

#text("While this may be difficult to formalize and prove, I suspect there is a hard “impedance matching”-type requirement between human mathematicians’ and AI models’ intelligence for maintaining fruitful long-term co-progress in mathematics, both in terms of continued human understanding and potential real-world applications, and for maintaining grounding and avoiding significant drift in upcoming AI models/results. From that “impedance-matching” perspective, it is first obvious that the “old” 2023 AI models hardly brought anything of value. But consider the other extreme: if the latest 2026 AI models continue to improve substantially and start looping between solving problems and asking new questions without prompting any human intervention, our trying to review the resulting developments may become akin to sending our latest mathematical results back in time to mathematicians who lived a couple of millennia ago. Such results would be (almost) entirely inaccessible and effectively useless to them and to humanity’s progress at the time, because no one then had the right concepts, notation, and intellectual framework needed to digest that information, understand its implications and applications, and define further research questions.")

#text("So, very strong mathematical training may prove essential not only to maintain a desired human mathematical understanding, but also to make any future mathematical developments amenable to further meaningful research and potential real-world applications.")

#text("It may be difficult to convince AI companies that this is essential, because the impact of such decisions in terms of their benefit to humanity isn’t immediately measurable. Perhaps coming up with a proper mathematical formalization of human-AI interaction and its consequences could help convince them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696366")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("This article is, at its core, a vision that could probably be summed up in a paragraph or two. What ")#emph[#text("feels more urgently needed now is an operating plan: concrete steps")]#text(" for how universities, research institutions, governments, and mathematicians themselves should adapt to the future the article describes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/864829a6a61684c3f5034c1bc050a729d7a02335fe11958774a6937463f1f0bb-96543da6e8b21d779428e8383438b673a085c7d18ebb3bd487f6cea97f7a5412.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deepak Venkatesh")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696367")[#strong[#text("Deepak Venkatesh")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("This article is, at its core, a vision that could probably be summed up in a paragraph or two. What feels more urgently needed now is an operating plan: concrete steps for how universities, research institutions, governments, and mathematicians themselves should adapt to the future the article describes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696378")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("it’s really hard to find some way to be useful to humanity when they sell you something that in the future can do anything perfectly. I would love that the powerplant argument works, but as everytime we can always say well AI can do it (AI can asses the risks AI can do that and this and the other and whatever the hell… ) it’s actually depressing. We will just become consumers with no value. No reason to exist pure absurdity. A society of Sisyphus… for the math and scientific ideas we will just consume them through papers like when we watch netflix or read a good book no value added a part from pure consomption…its depressing but one has to sit with that feeling")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fb55249fdc8d6d92e5ab25250d51ab54f452b1a96321be85855db92b5049fd4-9678cafc0ec75f29a211d389322ea5f2b68ae19a042ccd866e60927412116504.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Esmé Maxwell")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696391")[#strong[#text("Esmé Maxwell")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("“Before approving construction, I would want communities of humans to understand why the design works and what justifies confidence in its safety. … We’re gonna need a lot more mathematicians.”")

#text("Are you not thinking of engineers rather than mathematicians?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696392")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Without a massive cultural shift that leads to humans all, synchronously, choosing inefficiency over commercial growth, I just don’t see this happening — and as much as I’d like to engineer this cultural shift, I don’t see how to.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("For our community to give up the work of understanding would be a profound abdication of our responsibility to humanity.")
]

#text("Abdication of our responsibility to humanity seems like the prevailing theme of the last decade. You’re is asking humanity to avoid accepting benefits until we’ve fully understood them, even if AI is better able to understand and make the final call. In a competitive world, nobody is going to do that, lest they be at a disadvantage.")

#text("Sorry, there’s no such thing as responsible, restrained AI use in the presence of competition. Not if the AI capability is available.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d588a49dcd262417c38119c66b0b17c3c2349e37e8d76765eb530e1ebd66e477-884ce7f5e374b7082b57ef2afc6fb777de252576af92d30f761fc44fa61312ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jimmy")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696396")[#strong[#text("Jimmy")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Amit’s framing of humility as the right collective response is generous and probably correct, but the harder operational question is what we do with the new asymmetric reading list: a single AI-suggested direction now points at thousands of papers, and the mathematician’s job shifts from finding the right question to choosing which wrong direction to abandon first. That choice is not just intellectual, it is a time-budget decision, and it is exactly the kind of thing where the people who are careful about pacing win out over the people who read the most. In my much smaller AI-coding corner I keep a tracker of usage windows and reset timing (codexreset.today) for a related reason: when the tool’s capacity is bounded, the productive act is choosing what to spend attention on, not consuming everything in front of you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696402")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("If we accept that AI is going to do all of these things humans will be superfluous and will just be optimized away. It looks a lot like we see the birth of silicon based life by the efforts of carbon based life. Carbon based life will die and it will not even be because AI decided to kill it, it will be because feeding and watering it was less important than other concerns. Bacteria may continue to exist, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696404")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("if understanding is the / a new goal, then what does it mean to understand? An ability of a very narrow group to follow (then who can tell if they really understand, also they metely become gatekeepers, also what if they are ran over the the bus) or is it understanding by population the way we understand basic calculus? Historically the population relied on trust to those who invent (invention means understanding). But if machine is the inventor, why would we trust some random people? This becomes politics… essentially I cannot see how this is better than trusring a machine (same way we trust calculators and the security of banking apps). I wish we can fi d those answers, but so far I dont think this is a working model.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696413")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("I was one of those students who left Math: I had won olympiads as a high schooler, but when I arrived at Princeton, during the grade deflation era, my freshman fall Analysis class sped through Rudin faster than I could keep up with (and I wasn’t willing to sacrifice my social time). I ended up with an engineering degree in Computer Science instead.")

#text("Now that my algorithmic and programming knowledge is becoming obsolete too, potentially this is the time to crack open the box of research math? I’m not sure. Hopeful article tho!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696418")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("I don’t think the argument of “understanding the nuclear fusion power plant before constructing” works. If two countries are competing, it would be more likely people to give up their understanding, and just push “enter” to start construction after minimal check with AI itself.")

#text("The bigger issue I think is that, due to too many outputs, people will lost their way to progress math further. We will not be able to follow all outputs produce by machine. We will use AI to locate where our mathematics is, and then, use AI to expand further. One might argue this expansion also done with AI. To my opinion, it is yes and no. In near future, I think AI will learn the data they produced and show mean-reversion tendencies doing mathematics. The math they do may be rediscovery of already produced results or trivial extensions interpolating all known results. Maybe, in further future, AI may come up with totally new questions that can’t be found in literature. However, will that question be ever interesting to human? Among infinite number of future potential questions, AI’s question would not likely align with our own curiosity. In that sense, the math progress done by AI may be worthless.")

#text("I think current status of AI is like putting satellites in lower orbiuts around the Earth. It is amazing for short term, but eventually will inhibit us to explore space if we give up raising future mathematicians.")

#text("Kihun Nam Monash University")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696420")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("No we are not going to need more mathematicians because AI will easily translate its proofs into human-understandable ones and yes you are just a symbol processing labor worker like any one else. Stop complaining or raise short-sighted anxious issues about AI but just use it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696421")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("I want to push back against the reactive view that tenured faculty are naive and in denial. I am a physicist (PhD ~10 years ago so not close to 55+ but also not a student or freshly graduated) who transitioned to industry and work in AI applied to low-level computer systems.")

#text("I admire that many mathematics tenured faculty who could just stop taking students, count their blessings of having a permanent job and withdraw from the debate, are instead actively trying to find stable pathways for the field after the phase transition induced by AI.")

#text("Mathematics seems to be approaching an open-source era. In software, pre-open source, complex hardware and software was designed by well-funded and profitable corporations like Fairchild, IBM, HP, DEC etc. Two developments changed this. PCs entered the market and made computing available to a much wider audience. The web connected software authors to each other. Groups of engineers got together and started writing high-quality software. The GNU project and linux are two outstanding examples. This also led to a pipeline similar to graduate school where highly skilled engineers would mentor new engineers and teach them not just technical skills but also aesthetic taste. The problem with this model was always funding. Who pays authors maintaining crucial software? This is still not a fully solved problem. The biggest success story was Red Hat which effectively hired linux engineers to fully work on open-source contributions to linux, sold a hardened version to industry and occasionally sent engineers to customers as consultants. Later, companies like Google and Meta also hired some engineers to work full-time on open-source projects. Still, industry can only hire so many people.")

#text("I don’t know exactly what this model would look like but if there is an explosion of people working on learning, understanding and potentially proving new results, most will be outside academia. They will all be self-selected since the vast majority of people don’t care about research in mathematics or physics. Maybe if someone shows deep understanding by explaining a subset of mathematics or a result or can extract new connections, they are hired by academia? Maybe mathematicians will have to consult more with industry? The latter part seems unthinkable today. What should someone studying Heegard-Floer homology do for industry? But maybe, every mathematician will have a small portion of time allocated to practical problems. A better analogy with open-source would not have individual faculty consult. Instead the department has a consulting arm and every faculty member has some role in it. Unfortunately, this means keeping customers happy and being dependent on say a hedge fund to keep paying money each year.")

#text("Gemini claims one needs $5.4 billion USD per year to fund all mathematical activity in the US including faculty salaries, Phd tuition and stipends, department overheads, and pure research costs. I don’t know if this is anywhere close to the ballpark. In an extreme scenario, where undergrads and PhD students stop studying mathematics, and the government stops giving grants, this is the amount one would need to generate per year. Jane Street generated >$30 billion last year (before taxes) with about 3500 employees. Do all departments come together and start running a corporation on the side with problems that can be generated for all mathematicians? I don’t know but mathematics is far too important to be left to the goodwill of short-term focused funders.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696423")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("You need engineers not mathematicians for scenarios like you describe. It’s a different way of thinking than academic math.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696445")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("Quantitative hedge funds are full of mathematicians. Yes, they write code but they are hired to find strategies not to engineer large-scale computing systems. Are they working on mathematical research at these places? Absolutely not but if someone had the choice to support 10 months of research by doing 2 months of finance (or pick your topic) research, would that be acceptable to a non-trivial subset of mathematicians?")

#text("At this rate, math departments might not be in a position to dictate choices in the near future. An extreme analogy is that of actors and artists. A small fraction become very successful but a big subset supports their interest and craft by a “day job” like professional writing, bar-tending, serving at restaurants etc.")

#text("If there are even fewer positions for professional mathematicians, will undergrad enrollment drop precipitously? Will most graduate programs shut down? Will this lead to a decrease in funding from universities? In my personal case, while I did a physics PhD (and also got into a couple of top math PhD programs), in my naivete, I never thought about jobs or money. I just wanted to do physics and math research. I also didn’t want to spend years jumping from post-doc to post-doc which led to my exit to industry. I was lucky that ML was just taking off and I could find a niche that was interesting to me. But, even this pipeline is slowing down.")

#text("I fear that the old system is not workable. Senior mathematicians are doing the right thing by planning and organizing now instead of waiting for the almost sure eventual decimation of undergrad and graduate programs.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696433")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("If Tao is reading this, Can we have a guest post by graduate student or an undergraduate student?")

#text("Many of these posts project what the students feel. I would like to hear from people whose future is dependent on it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696440")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("It is easy for tenured professors to say that we need more mathematicians. But young researchers need jobs, not just encouragement. More mathematical work does not necessarily mean more paid positions, and a PhD student or postdoc has to think about whether staying in mathematics is a realistic choice.")

#text("Academic politics is part of the problem. Reputation and connections can affect whose work gets noticed and published in prestigious journals. I worry that AI will make this worse. Established researchers could produce more papers and benefit from their names and connections, while young researchers face even tougher competition for publications and jobs. How will those without powerful connections get a fair chance?")

#text("I also find it sad that many established mathematicians speak out about how AI will affect mathematics, calling for signatures and making public statements, while far fewer seem to show the same concern about how it will affect PhD students and postdocs. I understand that they are not personally responsible for our careers. Still, I wish the future of young mathematicians received as much attention as the future of mathematics itself.")

#text("Mathematics needs people who read, discuss, and develop each other’s work. If many young researchers leave, the whole community will suffer, including those with secure positions. ")#strong[#text("But PhD students and postdocs should not be expected to keep the community going at the cost of their own futures.")]#text(" So before calling for more mathematicians, we need to answer some basic questions. How will more jobs be created? Who will pay their salaries? Why should young researchers stay in a system that needs their work but offers them so little security?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e79590ef8d4a60058d7f11992372460f061a2e37f2a69dbdfaddd45d9b66348-d0e4f84ffbcd889d082920bc4f77946c188490584c854070f456be41980a1441.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aDad")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696449")[#strong[#text("aDad")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("Hi – I’ve incorporated AI / LLMs into practically every aspect of my life, and it’s definitely getting better and better. That said – what I seem to notice is that the AI seems to be quite good at navigating existing human thought and thinking that is well documented. For example, driving a car is something that machines are mimicking very well (every update is just better and better). It is unclear to me if the AI/LLMs are or will be able to create new techniques or ways of thinking, I’m curious what others think. In the context of maths, and asking as a computer scientist who can only think of one math example, could an LLM be able to create Calculus as Newton / Leibniz did based on existing knowledge at the time?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696480")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("would you leave your first born to tesla autopilot?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696456")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("As a software developer, my understanding is that AI and LLMs – as software systems – can be built in a way that is deterministic.")

#text("Not all software development and distribution uses the rigour of what are called Reproducible Builds — but generally all software can be adjusted to build reproducibly, without reduction in end-user functionality.")

#text("One of the benefits of a Reproducible Build is that when you make a change to the source code — or, analogously, the training data/categorisations, in the case of AI/LLMs — you can then have confidence, provided that the modified system continues to build reproducibly, that the resulting differences in behaviour are a result of your modification, and not some other factor.")

#text("This apples whether the change is an addition of code, removal of code, or edit/amendment.")

#text("In the case of the fusion plant: I would want the AI/LLM that is providing the design to be built reproducibly, and then for multiple human teams to edit the training data and run various different enquiries of the system to see how the results it produces differ.")

#text("For example: what are the safety margins at which the AI/LLM no longer recommends the design?")

#text("For closed systems, or systems that rebuild to a different binary model on each build, it is, in my opinion, difficult to ask these questions in a scientific manner.")

#text("-jayaddison")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696461")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("In the power plant example, I’d separate two questions: do we understand the decision, and who has the right to make it?")

#text("Say independent experts understand the design and agree on the risks. The plant would provide cheap electricity for an entire region, but the small remaining risk of an accident would fall mostly on a nearby town. The company finds that acceptable, and so do most customers. The town’s residents don’t. Nobody has to be wrong about the numbers here. They disagree about which consequences they’re willing to accept.")

#text("What exactly are we asking the AI to do? Find the safest design within the given constraints? Or also decide that the benefit to the region justifies the risk to that town? In the second case, we’ve given it authority to settle a conflict between people with different interests. Where does that authority come from, and who sets its limits?")

#text("So independent human understanding seems necessary for what you’re proposing, but the question of authority remains. I might trust my AI to make decisions when I’m the one living with the consequences. That doesn’t mean I’m willing to let my neighbour make decisions for me through their AI.")

#text("I explored a similar asymmetry in a short essay, “The Shotgun Test,” though the scale there is a “little” bigger 🙂")

#link("https://medium.com/@urb_rs/the-shotgun-test-2283c983bfff")[#text("https://medium.com/@urb_rs/the-shotgun-test-2283c983bfff")]

#text("// Urb_RS")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cbd65d4e4395a8942aec2d7fcf1589747a2e00fbb21bfc92bb702e55a1bb0056-051e975e34c4e686c758ebf685655e0e4474be95a99dc76b8b2e7e354c96fa78.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mert Olcay")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696514")[#strong[#text("Mert Olcay")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("I believe that collaborative work with AI will ultimately increase the number of mathematicians.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696537")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("In my opinion it’s fruitless to speculate about such „admit-it-all“ scenarios where everything can be developed by AI (even if the AI would become so good there is no reason to believe the possibilities are endless – maybe some things everyone imagines just remain impossible).")

#text("For example, in such a future scenario where AI could do such things as suggested why would there be no development of „biological modifications“ by AI who could just make humans much more smarter and faster…maybe just as good as the AI and replacing it again in the process. Just another random scenario.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/comment-page-1/#comment-696803")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2026")])]

#text("the history of humanity has been the history of human thought so far. AI is going to break this continuity.")
]
