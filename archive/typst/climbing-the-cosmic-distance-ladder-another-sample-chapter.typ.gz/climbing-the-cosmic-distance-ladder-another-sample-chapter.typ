// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/
// Converted to Typst by tao2typ: "2026-10-14T15:21:08.215591+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Climbing the cosmic distance ladder: another sample chapter", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Climbing the cosmic distance ladder: another sample chapter")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 November 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/")[#text("https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Five years ago, I ")#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/")[#text("announced")]#text(" a popular science ")#link("https://terrytao.wordpress.com/books/climbing-the-cosmic-distance-ladder/")[#text("book project")]#text(" with ")#link("https://courtauld.ac.uk/people/tanya-klowden/")[#text("Tanya Klowden")]#text(" on the cosmic distance ladder, in which we released a ")#link("https://terrytao.wordpress.com/wp-content/uploads/2025/11/sample_fourth.pdf")[#text("sample draft chapter")]#text(" of the book, covering the “fourth rung” of the ladder, which for us meant the distances to the planets. In the intervening time, a number of unexpected events have slowed down this project significantly; but I am happy to announce that we have ")#link("https://terrytao.wordpress.com/wp-content/uploads/2025/11/sample_seventh.pdf")[#text("completed a second draft chapter")]#text(", this time on the “seventh rung” of measuring distances across the Milky Way, which required the maturation of the technologies of photography and spectroscopy, as well as the dawn of the era of “big data” in the early twentieth century, as exemplified for instance by the “")#link("https://en.wikipedia.org/wiki/Harvard_Computers")[#text("Harvard computers")]#text("“.")

#text("We welcome feedback of course, and are continuing to work to complete the book despite the various delays. In the mean time, you can check out ")#link("https://www.instagram.com/cosmic_distance_ladder/")[#text("our instagram account")]#text(" for the project, or the ")#link("https://www.youtube.com/watch?v=YdOXS_9_P4U")[#text("pair")]#text(" ")#link("https://www.youtube.com/watch?v=hFMaT9oRbs4")[#text("of videos ")]#text("that Grant Sanderson (3blue1brown) produced with us on this topic, which I previously blogged about ")#link("https://terrytao.wordpress.com/2025/02/13/cosmic-distance-ladder-video-with-grant-sanderson-3blue1brown-commentary-and-corrections/")[#text("here")]#text(".")

#text("Thanks to Clio Cresswell, Riley Tao, and Noah Klowden for comments and corrections.")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/#comment-689115")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2025")])]

#text("Arg, the fonts and layout don’t match! :-)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/#comment-689117")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2025")])]

#text("Can you clarify what the issue is? Of course the files will eventually be edited by the publisher, but it will be good to know what the problems are in advance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/#comment-689118")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2025")])]

#text("I just mean the two sample chapter pdfs, and it’s more a reflection on me. Five years between two drafts can definitely see a shift in preferred style for a working document.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/#comment-689116")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2025")])]

#text("I will definitely buy the book.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/#comment-689119")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2025")])]

#text("The last line of page 24 has a spurious period between “system” and “to”.")

#emph[#text("[Thanks, this will be corrected in the published version -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/#comment-689120")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2025")])]

#text("Yeay! I can finally comment on something in Terry Tao’s blog: “riches nearly beyond imaging” on pg 28– maybe you meant “imagining”?")

#emph[#text("[Thanks, this will be corrected in the published version – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/#comment-689122")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2025")])]

#text("Dear Prof. Tao, Here are some typos I have collected. I will post more comments as I find them.")

#text("1) P88:")

#text("(a)”..were able today use…” should be ” were able to use”.")

#text("(b)”as a stars” should be ” as stars”")

#text("2) P89:")

#text("(a)”rare occurance” should be “rare occurrence”.")

#text("(b) “obseration” should be “observation”.")

#text("3) P90:")

#text("(a)”millenia” should be “millennia”.")

#text("I apologize for raising a topic unrelated to this post, but I want to ask you about: In your previous commons, you mentioned that there a couple of perspectives of modern maths, and you explained the set-theoretic perspective v. s. the categor- theoretic perspective——Could you also explained what the other perspectives (such as information-theoretic perspective, etc.) are? Also, when is it appropriate to adopt these perspectives?")

#emph[#text("[Thanks, this will be corrected in the published version. As for your other question, I refer you to ")#link("https://mathoverflow.net/questions/38639/thinking-and-explaining")[#text("https://mathoverflow.net/questions/38639/thinking-and-explaining")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/#comment-689126")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2025")])]

#text("P. 28, l. -3: The word “Lutheran” goes into the text margin.")

#emph[#text("[Thanks, this will be corrected in the published version – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/#comment-689127")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2025")])]

#text("P. 30, l. 12: The two hyphens should be m-dashes and the spaces around them should be deleted.")

#text("P. 31, l. 17: The hyphen should be an m-dash and the space around it should be deleted.")

#text("(I’m out of time for now but you should probably do a search and replace to check if this needs changing in other places.)")

#emph[#text("[Thanks, this will be corrected in the published version – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/#comment-689140")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2025")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("In a very slow process lasting millions of years, a typical star gradually sheds their mass through the radiation they emit, and steadily move down the main sequence until they run out of their primary nuclear fuel of hydrogen, at which point they leave the main sequence")
]

#text("should be either singular “it”, or plural “stars”")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/#comment-689166")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2025")])]

#text("On page 114, “Karl Scharzschild” should be replaced by “Karl Schwarzschild”, the famous creator of the Schwarzschild solution to Einstein’s field equations.")

#text("In the maths part you may want to consider typesetting physical units with the siunitx LaTeX package (such that units do not appear in maths font italics).")

#text("The chapter was very entertaining and informative to read!")

#emph[#text("[Thanks, this will be corrected in the final version of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/371ed51c3b5dfba1e2d7e8fb33621989f6d10c0e171be43b00805d3a28e36cb9-34338f6d6ffe8cdc607b34fa19f5e1212b8b31f2a3f04a97fd3d01991a86b1b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lebesguemeasure")]], [#link("https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/#comment-689168")[#strong[#text("lebesguemeasure")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2025")])]

#text("On page 122, you say that, “the orbital plans of the stars will also tend to become aligned.” I assume this should be planes?")

#text("-Aaron Cofer")

#emph[#text("[Thanks, this will be corrected in the final version of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a2fc1fbdccb8173cb5cf54d9b2d4f36e3cff96312200702ba3c84615fbc2d331-76ce4afa9e573355f26ea6f1bea1cf18df24d78a24ef1521efee87ae1070eff8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of universallycollection781395846a")]], [#link("https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/#comment-689174")[#strong[#text("universallycollection781395846a")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2025")])]

#text("One small typo following eq. (7.4) in chapter 7.1.2: “")#emph[#text("that relates the [[apparent]] ")#strong[#text("absolute")]#text(" magnitude m0, the [[absolute]] ")#strong[#text("apparent")]#text(" magnitude m, and the distance r in parsecs")]#text("“")

#text("“")

#emph[#text("[Thanks, this will be corrected in the final version of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/#comment-689256")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2025")])]

#text("This looks very interesting professor!")

#text("Something which caught my eye in the sample draft for the “fourth rung” (perhaps already commented on elsewhere) is that the first sentence starts with “it’s”. However, elsewhere in the text you write “it is”. This is a little bit inconsistent, and I would suggest consistently writing “it is”.")

#text("-Clovis V")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/#comment-692255")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2026")])]

#text("do you know how the ancient civilixations were able to distinguish time within two minutes using planetary positions? The D60 chart in vedic astrology is able to distinguish within two minutes using planetary positions (the chart shows difference of planet positions every two min or less and there are many charts d1 through d60 with different precisions (not every di occurs in charts)).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/11/21/climbing-the-cosmic-distance-ladder-another-sample-chapter/#comment-692266")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2026")])]

#text("My understanding is that many ancient cultures, including the Greeks, Indians, and Arabs, were able to draw upon a large amount of historical observational data dating back to the Babylonians to help construct reasonably accurate planetary models. By the 5th century CE, the Indians also had managed to develop early versions of modern trigonometry, which allowed for somewhat simpler ways to adjust their models for what we now know to be heliocentric and Keplerian corrections, as compared with the corresponding corrections made (e.g., by al-Tusi) to the Ptolemaic model.")
]
]
