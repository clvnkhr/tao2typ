// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/08/30/slmath-announces-new-research-programs/
// Converted to Typst by tao2typ: "2026-10-14T11:14:29.306369+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "SLMath announces new research programs", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("SLMath announces new research programs")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 August 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/08/30/slmath-announces-new-research-programs/")[#text("https://terrytao.wordpress.com/2025/08/30/slmath-announces-new-research-programs/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The Simons-Laufer Mathematical Sciences institute, or ")#link("https://www.slmath.org/")[#text("SLMath")]#text(" (formerly the Mathematical Sciences Research Institute, or MSRI) has recently restructured its program formats, and is now ")#link("https://www.slmath.org/news-and-events/new-research-initiatives-starting-fall-2025")[#text("announcing three new research initiatives")]#text(", whose applications open on Sep 1 2025:")

#list(
[#text("AxIOM (Accelerating Innovation in Mathematics) is a new, month-long research program at SLMath, designed to accelerate innovation and introduce transformative ideas into the mathematical sciences. Programs begin in Spring 2027.")],
[#text("PROOF (Promoting Research Opportunities and Open Forums) is a two-week summer program designed to provide research opportunities for U.S.-based mathematicians, statisticians, and their collaborators in the U.S. and abroad, whose ongoing research may have been impacted by factors such as heavy teaching loads, professional isolation, limited access to funding, heavy administrative duties, personal obligations, or other constraints. Programs begin June-July 2026. The priority application deadline for PROOF 2026 is October 12, 2025.")],
[#text("Lasting Alliance Through Team Immersion and Collaborative Exploration (LATTICE) is a yearlong program which provides opportunities for U.S. mathematicians to conduct collaborative research on topics at the forefront of the mathematical and statistical sciences. Programs begin June-July 2026. LATTICE 2026 applications are open through February 1, 2026.")]
)

#text("(Disclosure: I am vice-chair of the ")#link("https://www.slmath.org/board-of-trustees")[#text("board of trustees")]#text(" at SLMath.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7147a7ee7b171cd69b9f790bf09604ae4aa8bd7dfa05ba8c2f6a8cada0ddbfd-446cf56bd211b705015c0145dc378ed05443a47120378d6d90eedbdeec49ac25.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of danielstone010")]], [#link("https://terrytao.wordpress.com/2025/08/30/slmath-announces-new-research-programs/#comment-688686")[#strong[#text("danielstone010")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2025")])]

#text("I just love that!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2025/08/30/slmath-announces-new-research-programs/#comment-688722")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2025")])]

#text("I hope the current administration realizes the value of funding science. They claim to be all about the US national interest, “America First” and such.")
]
