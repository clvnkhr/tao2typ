// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/
// Converted to Typst by tao2typ: "2026-10-14T11:01:49.798331+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "246B, Notes 3: Elliptic functions and modular forms", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("246B, Notes 3: Elliptic functions and modular forms")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 February 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/")[#text("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Previous set of notes: ")#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/")[#text("Notes 2")]#text(". Next set of notes: ")#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/")[#text("Notes 4")]#text(".")

#text("On the real line, the quintessential examples of a periodic function are the (normalised) sine and cosine functions ")#mi("{\\sin(2\\pi x)}")#text(", ")#mi("{\\cos(2\\pi x)}")#text(", which are ")#mi("{1}")#text("-periodic in the sense that")

#align(center)[#tao-fit-display[#mitex("\\sin(2\\pi(x+1)) = \\sin(2\\pi x); \\quad \\cos(2\\pi (x+1)) = \\cos(2\\pi x).")]]

#text("By taking various polynomial combinations of ")#mi("{\\sin(2\\pi x)}")#text(" and ")#mi("{\\cos(2\\pi x)}")#text(" we obtain more general trigonometric polynomials that are ")#mi("{1}")#text("-periodic; and the theory of Fourier series tells us that all other ")#mi("{1}")#text("-periodic functions (with reasonable integrability conditions) can be approximated in various senses by such polynomial combinations. Using Euler’s identity, one can use ")#mi("{e^{2\\pi ix}}")#text(" and ")#mi("{e^{-2\\pi ix}}")#text(" in place of ")#mi("{\\sin(2\\pi x)}")#text(" and ")#mi("{\\cos(2\\pi x)}")#text(" as the basic generating functions here, provided of course one is willing to use complex coefficients instead of real ones. Of course, by rescaling one can also make similar statements for other periods than ")#mi("{1}")#text(". ")#mi("{1}")#text("-periodic functions ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" can also be identified (by abuse of notation) with functions ")#mi("{f: {\\bf R}/{\\bf Z} \\rightarrow {\\bf C}}")#text(" on the quotient space ")#mi("{{\\bf R}/{\\bf Z}}")#text(" (known as the ")#emph[#text("additive ")#mi("{1}")#text("-torus")]#text(" or ")#emph[#text("additive unit circle")]#text("), or with functions ")#mi("{f: [0,1] \\rightarrow {\\bf C}}")#text(" on the fundamental domain (up to boundary) ")#mi("{[0,1]}")#text(" of that quotient space with the periodic boundary condition ")#mi("{f(0)=f(1)}")#text(". The map ")#mi("{x \\mapsto (\\cos(2\\pi x), \\sin(2\\pi x))}")#text(" also identifies the additive unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(" with the ")#emph[#text("geometric unit circle")]#text(" ")#mi("{S^1 = \\{ (x,y) \\in {\\bf R}^2: x^2+y^2=1\\} \\subset {\\bf R}^2}")#text(", thanks in large part to the fundamental trigonometric identity ")#mi("{\\cos^2 x + \\sin^2 x = 1}")#text("; this can also be identified with the ")#emph[#text("multiplicative unit circle")]#text(" ")#tao-math("{S^1 = \\{ z \\in {\\bf C}: \\left|z\\right|=1 \\}}", block: false)#text(". (Usually by abuse of notation we refer to all of these three sets simultaneously as the “unit circle”.) Trigonometric polynomials on the additive unit circle then correspond to ordinary polynomials of the real coefficients ")#mi("{x,y}")#text(" of the geometric unit circle, or Laurent polynomials of the complex variable ")#mi("{z}")#text(".")

#text("What about periodic functions on the complex plane? We can start with ")#emph[#text("singly periodic functions")]#text(" ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" which obey a periodicity relationship ")#mi("{f(z+\\omega)=f(z)}")#text(" for all ")#mi("{z}")#text(" in the domain and some period ")#mi("{\\omega \\in {\\bf C} \\backslash \\{0\\}}")#text("; such functions can also be viewed as functions on the “additive cylinder” ")#mi("{\\omega {\\bf Z} \\backslash {\\bf C}}")#text(" (or equivalently ")#mi("{{\\bf C} / \\omega {\\bf Z}}")#text("). We can rescale ")#mi("{\\omega=1}")#text(" as before. For holomorphic functions, we have the following characterisations:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Description of singly periodic holomorphic functions)")]#text(" ")#metadata(none) <tao-cf7341eb8ec10c18cb33>

#list(
[#text("(i) Every ")#mi("{1}")#text("-periodic entire function ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" has an absolutely convergent expansion")

#metadata(none) <tao-b1c4d1f75430b6a185ee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("f(z) = \\sum_{n=-\\infty}^\\infty a_n e^{2\\pi i nz} = \\sum_{n=-\\infty}^\\infty a_n q^n")]]

#text("where ")#mi("{q}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Nome_(mathematics)")[#text("nome")]#text(" ")#mi("{q := e^{2\\pi i z}}")#text(", and the ")#mi("{a_n}")#text(" are complex coefficients such that")

#metadata(none) <tao-7cfe10fee7c741f64d9f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\limsup_{n \\rightarrow +\\infty} \\left|a_n\\right|^{1/n} = \\limsup_{n \\rightarrow +\\infty} \\left|a_{-n}\\right|^{1/n} = 0.", block: true)]]

#text("Conversely, every doubly infinite sequence ")#mi("{(a_n)_{n \\in {\\bf Z}}}")#text(" of coefficients obeying ")#link(<tao-7cfe10fee7c741f64d9f>)[#text("(2)")]#text(" gives rise to a ")#mi("{1}")#text("-periodic entire function ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" via the formula ")#link(<tao-b1c4d1f75430b6a185ee>)[#text("(1)")]#text(".")],
[#text("(ii) Every bounded ")#mi("{1}")#text("-periodic holomorphic function ")#mi("{f: {\\bf H} \\rightarrow {\\bf C}}")#text(" on the upper half-plane ")#mi("{\\{ z: \\mathrm{Im}(z) > 0\\}}")#text(" has an expansion")

#metadata(none) <tao-66f97f6dc38b3fe6693f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("f(z) = \\sum_{n=0}^\\infty a_n e^{2\\pi i nz} = \\sum_{n=0}^\\infty a_n q^n")]]

#text("where the ")#mi("{a_n}")#text(" are complex coefficients such that")

#metadata(none) <tao-5347837af0b6c2c399c3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\limsup_{n \\rightarrow +\\infty} \\left|a_n\\right|^{1/n} \\leq 1.", block: true)]]

#text("Conversely, every infinite sequence ")#mi("{(a_n)_{n \\in {\\bf Z}}}")#text(" obeying ")#link(<tao-5347837af0b6c2c399c3>)[#text("(4)")]#text(" gives rise to a ")#mi("{1}")#text("-periodic holomorphic function ")#mi("{f: {\\bf H} \\rightarrow {\\bf C}}")#text(" which is bounded away from the real axis (i.e., bounded on ")#mi("{\\{ z: \\mathrm{Im}(z) \\geq \\varepsilon\\}}")#text(" for every ")#mi("{\\varepsilon > 0}")#text(").")]
)

#text("In both cases, the coefficients ")#mi("{a_n}")#text(" can be recovered from ")#mi("{f}")#text(" by the Fourier inversion formula")

#metadata(none) <tao-6e77e1227ec256cfedfd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("a_n = \\int_{\\gamma_{z_0 \\rightarrow z_0+1}} f(z) e^{-2\\pi i nz}\\ dz")]]

#text("for any ")#mi("{z_0}")#text(" in ")#mi("{{\\bf C}}")#text(" (in case (i)) or ")#mi("{{\\bf H}}")#text(" (in case (ii)).")
]

#emph[#text("Proof:")]#text(" If ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" is ")#mi("{1}")#text("-periodic, then it can be expressed as ")#mi("{f(z) = F(q) = F(e^{2\\pi i z})}")#text(" for some function ")#mi("{F: {\\bf C} \\backslash \\{0\\} \\rightarrow {\\bf C}}")#text(" on the “multiplicative cylinder” ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(", since the fibres of the map ")#mi("{z \\mapsto e^{2\\pi i z}}")#text(" are cosets of the integers ")#mi("{{\\bf Z}}")#text(", on which ")#mi("{f}")#text(" is constant by hypothesis. As the map ")#mi("{z \\mapsto e^{2\\pi i z}}")#text(" is a covering map from ")#mi("{{\\bf C}}")#text(" to ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(", we see that ")#mi("{F}")#text(" will be holomorphic if and only if ")#mi("{f}")#text(" is. Thus ")#mi("{F}")#text(" must have a Laurent series expansion ")#mi("{F(q) = \\sum_{n=-\\infty}^\\infty a_n q^n}")#text(" with coefficients ")#mi("{a_n}")#text(" obeying ")#link(<tao-7cfe10fee7c741f64d9f>)[#text("(2)")]#text(", which gives ")#link(<tao-b1c4d1f75430b6a185ee>)[#text("(1)")]#text(", and the inversion formula ")#link(<tao-6e77e1227ec256cfedfd>)[#text("(5)")]#text(" follows from the usual contour integration formula for Laurent series coefficients. The converse direction to (i) also follows by reversing the above arguments.")

#text("For part (ii), we observe that the map ")#mi("{z \\mapsto e^{2\\pi i z}}")#text(" is also a covering map from ")#mi("{{\\bf H}}")#text(" to the punctured disk ")#mi("{D(0,1) \\backslash \\{0\\}}")#text(", so we can argue as before except that now ")#mi("{F}")#text(" is a bounded holomorphic function on the punctured disk. By the Riemann singularity removal theorem (Exercise 35 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("246A Notes 3")]#text(") ")#mi("{F}")#text(" extends to be holomorphic on all of ")#mi("{D(0,1)}")#text(", and thus has a Taylor expansion ")#mi("{F(q) = \\sum_{n=0}^\\infty a_n q^n}")#text(" for some coefficients ")#mi("{a_n}")#text(" obeying ")#link(<tao-5347837af0b6c2c399c3>)[#text("(4)")]#text(". The argument now proceeds as with part (i). ")#mi("\\Box")

#text("The additive cylinder ")#mi("{{\\bf Z} \\backslash {\\bf C}}")#text(" and the multiplicative cylinder ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(" can both be identified (on the level of smooth manifolds, at least) with the geometric cylinder ")#mi("{\\{ (x,y,z) \\in {\\bf R}^3: x^2+y^2=1\\}}")#text(", but we will not use this identification here.")

#text("Now let us turn attention to ")#emph[#text("doubly periodic")]#text(" functions of a complex variable ")#mi("{z}")#text(", that is to say functions ")#mi("{f}")#text(" that obey two periodicity relations")

#align(center)[#tao-fit-display[#mitex("f(z+\\omega_1) = f(z); \\quad f(z+\\omega_2) = f(z)")]]

#text("for all ")#mi("{z \\in {\\bf C}}")#text(" and some periods ")#mi("{\\omega_1,\\omega_2 \\in {\\bf C}}")#text(", which to avoid degeneracies we will assume to be linearly independent over the reals (thus ")#mi("{\\omega_1,\\omega_2}")#text(" are non-zero and the ratio ")#mi("{\\omega_2/\\omega_1}")#text(" is not real). One can rescale ")#mi("{\\omega_1,\\omega_2}")#text(" by a common scaling factor ")#mi("{\\lambda \\in {\\bf C} \\backslash \\{0\\}}")#text(" to normalise either ")#mi("{\\omega_1=1}")#text(" or ")#mi("{\\omega_2=1}")#text(", but one of course cannot simultaneously normalise both parameters in this fashion. As in the singly periodic case, such functions can also be identified with functions on the additive ")#mi("{2}")#text("-torus ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(", where ")#mi("{\\Lambda}")#text(" is the lattice ")#mi("{\\Lambda := \\omega_1 {\\bf Z} + \\omega_2 {\\bf Z}}")#text(", or with functions ")#mi("{f}")#text(" on the solid parallelogram bounded by the contour ")#mi("{\\gamma_{0 \\rightarrow \\omega_1 \\rightarrow \\omega_1+\\omega_2 \\rightarrow \\omega_2 \\rightarrow 0}}")#text(" (a fundamental domain up to boundary for that torus), obeying the boundary periodicity conditions")

#align(center)[#tao-fit-display[#mitex("f(z+\\omega_1) = f(z)")]]

#text("for ")#mi("{z}")#text(" in the edge ")#mi("{\\gamma_{\\omega_2 \\rightarrow 0}}")#text(", and")

#align(center)[#tao-fit-display[#mitex("f(z+\\omega_2) = f(z)")]]

#text("for ")#mi("{z}")#text(" in the edge ")#mi("{\\gamma_{\\omega_0 \\rightarrow 1}}")#text(".")

#text("Within the world of holomorphic functions, the collection of doubly periodic functions is boring:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" ")#metadata(none) <tao-f953f70b9132340e2782>#text(" Let ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" be an entire doubly periodic function (with periods ")#mi("{\\omega_1,\\omega_2}")#text(" linearly independent over ")#mi("{{\\bf R}}")#text("). Then ")#mi("{f}")#text(" is constant.")
]

#text("In the language of Riemann surfaces, this proposition asserts that the torus ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(" is a non-hyperbolic Riemann surface; it cannot be holomorphically mapped non-trivially into a bounded subset of the complex plane.")

#emph[#text("Proof:")]#text(" The fundamental domain (up to boundary) enclosed by ")#mi("{\\gamma_{0 \\rightarrow \\omega_1 \\rightarrow \\omega_1+\\omega_2 \\rightarrow \\omega_2 \\rightarrow 0}}")#text(" is compact, hence ")#mi("{f}")#text(" is bounded on this domain, hence bounded on all of ")#mi("{{\\bf C}}")#text(" by double periodicity. The claim now follows from Liouville’s theorem. (One could alternatively have argued here using the compactness of the torus ")#mi("{(\\omega_1 {\\bf Z} + \\omega_2 {\\bf Z}) \\backslash {\\bf C}}")#text(". ")#mi("\\Box")

#text("To obtain more interesting examples of doubly periodic functions, one must therefore turn to the world of ")#emph[#text("meromorphic functions")]#text(" – or equivalently, holomorphic functions into the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(". As it turns out, a particularly fundamental example of such a function is the ")#link("https://en.wikipedia.org/wiki/Weierstrass%27s_elliptic_functions")[#text("Weierstrass elliptic function")]#text(" ")#metadata(none) <tao-b545ddf5b84555a4dd95>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\wp(z) := \\frac{1}{z^2} + \\sum_{z_0 \\in \\Lambda \\backslash 0} \\left( \\frac{1}{(z-z_0)^2} - \\frac{1}{z_0^2} \\right)")]]

#text(" ")#text(" which plays a role in doubly periodic functions analogous to the role of ")#mi("{x \\mapsto \\cos(2\\pi x)}")#text(" for ")#mi("{1}")#text("-periodic real functions. This function will have a double pole at the origin ")#mi("{0}")#text(", and more generally at all other points on the lattice ")#mi("{\\Lambda}")#text(", but no other poles. The derivative")

#metadata(none) <tao-534b7d22d901bbabd3fd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\wp^{\\prime}(z) = -2 \\sum_{z_0 \\in \\Lambda} \\frac{1}{(z-z_0)^3}")]]

#text("of the Weierstrass function is another doubly periodic meromorphic function, now with a triple pole at every point of ")#mi("{\\Lambda}")#text(", and plays a role analogous to ")#mi("{x \\mapsto \\sin(2\\pi x)}")#text(". Remarkably, all the other doubly periodic meromorphic functions with these periods will turn out to be rational combinations of ")#mi("{\\wp}")#text(" and ")#mi("{\\wp^{\\prime}}")#text("; furthermore, in analogy with the identity ")#mi("{\\cos^2 x+ \\sin^2 x = 1}")#text(", one has an identity of the form")

#metadata(none) <tao-3e9417dce4568dba3e1c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\wp^{\\prime}(z)^2 = 4 \\wp(z)^3 - g_2 \\wp(z) - g_3")]]

#text("for all ")#mi("{z \\in {\\bf C}}")#text(" (avoiding poles) and some complex numbers ")#mi("{g_2,g_3}")#text(" that depend on the lattice ")#mi("{\\Lambda}")#text(". Indeed, much as the map ")#mi("{x \\mapsto (\\cos 2\\pi x, \\sin 2\\pi x)}")#text(" creates a diffeomorphism between the additive unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(" to the geometric unit circle ")#mi("{\\{ (x,y) \\in{\\bf R}^2: x^2+y^2=1\\}}")#text(", the map ")#mi("{z \\mapsto (\\wp(z), \\wp^{\\prime}(z))}")#text(" turns out to be a complex diffeomorphism between the torus ")#mi("{(\\omega_1 {\\bf Z} + \\omega_2 {\\bf Z}) \\backslash {\\bf C}}")#text(" and the ")#link("https://en.wikipedia.org/wiki/Elliptic_curve")[#text("elliptic curve")]

#align(center)[#tao-fit-display[#mitex("\\{ (z, w) \\in {\\bf C}^2: z^2 = 4w^3 - g_2 w - g_3 \\} \\cup \\{\\infty\\}")]]

#text("with the convention that ")#mi("{(\\wp,\\wp^{\\prime})}")#text(" maps the origin ")#mi("{\\omega_1 {\\bf Z} + \\omega_2 {\\bf Z}}")#text(" of the torus to the point ")#mi("{\\infty}")#text(" at infinity. (Indeed, one can view elliptic curves as “multiplicative tori”, and both the additive and multiplicative tori can be identified as smooth manifolds with the more familiar ")#link("https://en.wikipedia.org/wiki/Torus")[#text("geometric torus")]#text(", but we will not use such an identification here.) This fundamental identification with elliptic curves and tori motivates many of the further remarkable properties of elliptic curves; for instance, the fact that tori are obviously an abelian group gives rise to an abelian group law on elliptic curves (and this law can be interpreted as an analogue of the trigonometric sum identities for ")#mi("{\\wp, \\wp^{\\prime}}")#text("). The description of the various meromorphic functions on the torus also helps motivate the more general ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93Roch_theorem")[#text("Riemann-Roch theorem")]#text(" that is a fundamental law governing meromorphic functions on other compact Riemann surfaces (and is discussed further in ")#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/")[#text("these 246C notes")]#text("). So far we have focused on studying a single torus ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(". However, another important mathematical object of study is the space of ")#emph[#text("all")]#text(" such tori, modulo isomorphism; this is a basic example of a ")#link("https://en.wikipedia.org/wiki/Moduli_space")[#text("moduli space")]#text(", known as the ")#link("https://en.wikipedia.org/wiki/Moduli_space")[#text("(classical, level one) modular curve")]#text(" ")#mi("{X_0(1)}")#text(". This curve can be described in a number of ways. On the one hand, it can be viewed as the upper half-plane ")#mi("{{\\bf H} = \\{ z: \\mathrm{Im}(z) > 0 \\}}")#text(" quotiented out by the discrete group ")#mi("{SL_2({\\bf Z})}")#text("; on the other hand, by using the ")#mi("{j}")#text("-invariant, it can be identified with the complex plane ")#mi("{{\\bf C}}")#text("; alternatively, one can compactify the modular curve and identify this compactification with the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(". (This identification, by the way, produces a very short proof of the little and great Picard theorems, which we proved in ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("246A Notes 4")]#text(".) Functions on the modular curve (such as the ")#mi("{j}")#text("-invariant) can be viewed as ")#mi("{SL_2({\\bf Z})}")#text("-invariant functions on ")#mi("{{\\bf H}}")#text(", and include the important class of ")#link("https://en.wikipedia.org/wiki/Modular_form")[#text("modular functions")]#text("; they naturally generalise to the larger class of (weakly) ")#link("https://en.wikipedia.org/wiki/Modular_form")[#text("modular forms")]#text(", which are functions on ")#mi("{{\\bf H}}")#text(" which transform in a very specific way under ")#mi("{SL_2({\\bf Z})}")#text("-action, and which are ubiquitous throughout mathematics, and particularly in number theory. Basic examples of modular forms include the ")#link("https://en.wikipedia.org/wiki/Eisenstein_series")[#text("Eisenstein series")]#text(", which are also the Laurent coefficients of the Weierstrass elliptic functions ")#mi("{\\wp}")#text(". More number theoretic examples of modular forms include (suitable powers of) ")#link("https://en.wikipedia.org/wiki/Theta_function")[#text("theta functions")]#text(" ")#mi("{\\theta}")#text(", and the ")#link("https://en.wikipedia.org/wiki/Modular_discriminant")[#text("modular discriminant")]#text(" ")#mi("{\\Delta}")#text(". Modular forms are ")#mi("{1}")#text("-periodic functions on the half-plane, and hence by Proposition ")#link(<tao-cf7341eb8ec10c18cb33>)[#text("1")]#text(" come with Fourier coefficients ")#mi("{a_n}")#text("; these coefficients often turn out to encode a surprising amount of number-theoretic information; a dramatic example of this is the famous ")#link("https://en.wikipedia.org/wiki/Modularity_theorem")[#text("modularity theorem")]#text(", (a special case of which was) used amongst other things to establish Fermat’s last theorem. Modular forms can be generalised to other discrete groups than ")#mi("{SL_2({\\bf Z})}")#text(" (such as ")#link("https://en.wikipedia.org/wiki/Congruence_subgroup")[#text("congruence groups")]#text(") and to other domains than the half-plane ")#mi("{{\\bf H}}")#text(", leading to the important larger class of ")#link("https://en.wikipedia.org/wiki/Automorphic_form")[#text("automorphic forms")]#text(", which are of major importance in number theory and representation theory, but which are well outside the scope of this course to discuss.")

#metadata(none) <tao-5c1d4919e4fb4f8ab384>

#heading(level: 1)[#strong[#text(" — 1. Doubly periodic functions — ")]]

#text("Throughout this section we fix two complex numbers ")#mi("{\\omega_1,\\omega_2}")#text(" that are linearly independent over ")#mi("{{\\bf R}}")#text(", which then generate a lattice ")#mi("{\\Lambda := \\omega_1 {\\bf Z} + \\omega_2{\\bf Z}}")#text(".")

#text("We now study the doubly periodic meromorphic functions with respect to these periods that are not identically zero. We first observe some constraints on the poles of these functions. Of course, by periodicity, the poles will themselves be periodic, and thus the set of poles forms a finite union of disjoint cosets ")#mi("{\\zeta_j + \\Lambda}")#text(" of the lattice ")#mi("{\\Lambda}")#text(". Similarly, the zeroes form a finite union of disjoint cosets ")#mi("{\\lambda_j + \\Lambda}")#text(". Using the residue theorem, we can obtain some further constraints:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Consequences of residue theorem)")]#text(" ")#metadata(none) <tao-60e77101e76950a9b183>#text(" Let ")#mi("{f: {\\bf C} \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" be a doubly periodic meromorphic function (not identically zero) with periods ")#mi("{\\omega_1,\\omega_2}")#text(", poles at ")#mi("{\\zeta_j + \\Lambda}")#text(", and zeroes at ")#mi("{\\lambda_j + \\Lambda}")#text(".")

#list(
[#text("(i) The sum of residues at each ")#mi("{\\zeta_j}")#text(" (i.e., we sum one residue per coset) is equal to zero.")],
[#text("(ii) The number of poles ")#mi("{\\zeta_j}")#text(" (counting multiplicity, but only counting once per coset) is equal to the number of zeroes ")#mi("{\\lambda_j}")#text(" (again counting multiplicity, and once per coset).")],
[#text("(iii) The sum of the poles ")#mi("{\\zeta_j + \\Lambda}")#text(" (counting multiplicity, and working in the group ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(") is equal to the sum of the zeroes ")#mi("{\\lambda_j + \\Lambda}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" For (i), we first apply a translation so that none of the pole cosets ")#mi("{\\zeta_j + \\Lambda}")#text(" intersects the fundamental parallelogram boundary ")#mi("{\\gamma_{0 \\rightarrow \\omega_1 \\rightarrow \\omega_1+\\omega_2 \\rightarrow \\omega_2 \\rightarrow 0}}")#text("; this of course does not affect the sum of residues. Then, by the residue theorem, the sum in (i) is equal to the expression")

#align(center)[#tao-fit-display[#mitex("\\frac{\\pm 1}{2\\pi i} \\int_{\\gamma_{0 \\rightarrow \\omega_1 \\rightarrow \\omega_1+\\omega_2 \\rightarrow \\omega_2 \\rightarrow 0}} f(z)\\ dz")]]

#text("(the sign depends on whether this contour is oriented counter-clockwise or clockwise). But from the double periodicity we see that the integral vanishes (the contribution of parallel pairs of edges cancel each other). For part (ii), apply part (i) to the logarithmic derivative ")#mi("{f^{\\prime}/f}")#text(", which is also doubly periodic.")

#text("For part (iii), we again translate so that none of the pole or zero cosets intersects ")#mi("{\\gamma_{0 \\rightarrow \\omega_1 \\rightarrow \\omega_1+\\omega_2 \\rightarrow \\omega_2 \\rightarrow 0}}")#text(", noting from part (ii) that any such translation affects the sum of poles and sum of zeroes by the same amount. By the residue theorem, it now suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\frac{\\pm 1}{2\\pi i} \\int_{\\gamma_{0 \\rightarrow \\omega_1 \\rightarrow \\omega_1+\\omega_2 \\rightarrow \\omega_2 \\rightarrow 0}} z \\frac{f^{\\prime}(z)}{f(z)}\\ dz")]]

#text("lies in the lattice ")#mi("{\\Lambda}")#text(". But one can rewrite this using the double periodicity as")

#align(center)[#tao-fit-display[#mitex("\\frac{\\pm 1}{2\\pi i} ( \\int_{\\gamma_{0 \\rightarrow \\omega_2}} \\omega_1 \\frac{f^{\\prime}(z)}{f(z)}\\ dz - \\int_{\\gamma_{0 \\rightarrow \\omega_1}} \\omega_2 \\frac{f^{\\prime}(z)}{f(z)}\\ dz ),")]]

#text("so it suffices to show that ")#mi("{\\frac{1}{2\\pi i} \\int_{\\gamma_{0 \\rightarrow \\omega_j}} \\frac{f^{\\prime}(z)}{f(z)}\\ dz}")#text(" is an integer for ")#mi("{j=1,2}")#text(". But (a slight modification of) the argument principle shows that this number is precisely the winding number around the origin of the image of ")#mi("{\\gamma_{0 \\rightarrow \\omega_j}}")#text(" under the map ")#mi("{\\frac{f^{\\prime}}{f}}")#text(", and the claim follows. ")#mi("\\Box")

#text("This lemma severely limits the possible number of behaviors for the zeroes and poles of a meromorphic function. To formalise this, we introduce some general notation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4 (Divisors)")]

#list(
[#text("(i) A ")#link("https://en.wikipedia.org/wiki/Divisor_(algebraic_geometry)")[#text("divisor")]#text(" on the torus ")#mi("{\\Lambda\\backslash {\\bf C}}")#text(" is a formal integer linear combination ")#mi("{D = \\sum_P c_P \\cdot (P)}")#text(", where ")#mi("{P}")#text(" ranges over a finite collection of points in the torus ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(" (i.e., a finite collection of cosets ")#mi("{\\zeta + \\Lambda}")#text("), and ")#mi("{c_P}")#text(" are integers, with the obvious additive group structure; equivalently, the space ")#mi("{\\mathrm{Div}( \\Lambda\\backslash {\\bf C} )}")#text(" of divisors is the free abelian group with generators ")#mi("{(P)}")#text(" for ")#mi("{P \\in \\Lambda \\backslash {\\bf C}}")#text(" (with the convention ")#mi("{1 \\cdot (P) = (P)}")#text(").")],
[#text("(ii) The number ")#mi("{\\sum_P c_P}")#text(" is the ")#emph[#text("degree")]#text(" ")#mi("{\\mathrm{deg}(D)}")#text(" of a divisor ")#mi("{D = \\sum_P c_P \\cdot (P)}")#text(", the point ")#mi("{\\sum_P c_P P \\in \\Lambda \\backslash {\\bf C}}")#text(" is the ")#emph[#text("sum")]#text(" ")#mi("{\\mathrm{sum}(D)}")#text(" of ")#mi("{D}")#text(", and each ")#mi("{c_P}")#text(" is the ")#emph[#text("order")]#text(" ")#mi("{\\mathrm{ord}_P(D)}")#text(" of the divisor at ")#mi("{P}")#text(" (with the convention that the order is ")#mi("{0}")#text(" if ")#mi("{P}")#text(" does not appear in the sum). A divisor is ")#emph[#text("non-negative")]#text(" (or ")#emph[#text("effective")]#text(") if ")#mi("{c_P \\geq 0}")#text(" for all ")#mi("{P}")#text(". We write ")#mi("{D_1 \\geq D_2}")#text(" if ")#mi("{D_1 - D_2}")#text(" is non-negative (i.e., the order of ")#mi("{D_1}")#text(" is greater than or equal to that of ")#mi("{D_2}")#text(" at every point ")#mi("{P}")#text(", and ")#mi("{D_1 > D_2}")#text(" if ")#mi("{D_1 \\geq D_2}")#text(" and ")#mi("{D_1 \\neq D_2}")#text(".")],
[#text("(iii) Given a meromorphic function ")#mi("{f: \\Lambda \\backslash {\\bf C} \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" (or equivalently, a doubly periodic function ")#mi("{f: {\\bf C} \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(") that is not identically zero, the ")#emph[#text("principal divisor")]#text(" ")#mi("{(f)}")#text(" is the divisor ")#mi("{\\sum_P \\mathrm{ord}_P(f) (P)}")#text(", where ")#mi("{P}")#text(" ranges over the zeroes and poles of ")#mi("{f}")#text(", and ")#mi("{\\mathrm{ord}_P(f)}")#text(" is the order of the zero (if ")#mi("{P}")#text(" is a zero) or negative the order of the pole (if ")#mi("{P}")#text(" is a pole).")],
[#text("(iv) Given a divisor ")#mi("{D = \\sum_P c_P \\cdot (P)}")#text(", we define ")#mi("{L(D)}")#text(" to be the space of all meromorphic functions ")#mi("{f}")#text(" that are either zero, or are such that ")#mi("{(f)+D \\geq 0}")#text(". That is to say, ")#mi("{L(D)}")#text(" consists of those meromorphic functions that have at most a pole of order ")#mi("{c_P}")#text(" at ")#mi("{P}")#text(" if ")#mi("{c_P}")#text(" is positive, or at least zero of order ")#mi("{-c_P}")#text(" if ")#mi("{c_P}")#text(" is negative.")]
)
]

#text("A divisor can be viewed as an abstraction of the concept of a set of zeroes and poles (counting multiplicity). Observe that principal divisors obey the laws ")#mi("{(fg) = (f)+(g)}")#text(", ")#mi("{(f/g) = (f) - (g)}")#text(" when ")#mi("{f,g}")#text(" are meromorphic and non-zero. In particular, the space ")#mi("{\\mathrm{PDiv}(\\Lambda \\backslash {\\bf C})}")#text(" of principal divisors is a subgroup of the space ")#mi("{\\mathrm{Div}(\\Lambda \\backslash {\\bf C})}")#text(" of all divisors. By Lemma ")#link(<tao-60e77101e76950a9b183>)[#text("3")]#text("(ii), all principal divisors have degree zero, and from Lemma ")#link(<tao-60e77101e76950a9b183>)[#text("3")]#text("(iii), all principal divisors have sum zero as well. Later on we shall establish the converse claim that every divisor of degree and sum zero is a principal divisor; see Exercise ")#link(<tao-dbb4e692c9327807fd2d>)[#text("7")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" One can define divisors on other Riemann surfaces, such as the complex plane ")#mi("{{\\bf C}}")#text(". Observe from the fundamental theorem of algebra that if one has two non-zero polynomials ")#mi("{P(z), Q(z)}")#text(", then ")#mi("{(P) \\leq (Q)}")#text(" if and only if ")#mi("{P}")#text(" divides ")#mi("{Q}")#text(" as a polynomial. This may give some hint as to the origin of the terminology “divisor”. The machinery of divisors turns out to have a rich algebraic and topological structure when applied to more general Riemann surfaces than tori, for instance enabling one to associate an ")#link("https://en.wikipedia.org/wiki/Abelian_variety")[#text("abelian variety")]#text(" (the ")#link("https://en.wikipedia.org/wiki/Jacobian_variety")[#text("Jacobian variety")]#text(") to every algebraic curve; see ")#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/")[#text("these 246C notes")]#text(" for further discussion.")
]

#text("It is easy to see that ")#mi("{L(D)}")#text(" is always a vector space. All non-zero meromorphic functions ")#mi("{f: \\Lambda \\backslash {\\bf C} \\rightarrow {\\bf C}}")#text(" belong to at least one of the ")#mi("{L(D)}")#text(", namely ")#mi("{L(-(f))}")#text(", so to classify all the meromorphic functions on ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(", it would suffice to understand what all the spaces ")#mi("{L(D)}")#text(" are.")

#text("Liouville’s theorem (in the form of Proposition ")#link(<tao-f953f70b9132340e2782>)[#text("2")]#text(") tells us that all elements of ")#mi("{L(0)}")#text(" – that is to say, the holomorphic functions on ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(" – are constant; thus ")#mi("{L(0)}")#text(" is one-dimensional. If ")#mi("{D<0}")#text(" is a negative divisor, the elements of ")#mi("{L(D)}")#text(" are thus constant and have at least one zero, thus in these cases ")#mi("{L(D)}")#text(" is trivial.")

#text("Now we gradually work our way up to higher degree divisors ")#mi("{L(D)}")#text(". A basic fact, proven from elementary linear algebra, is that every time one adds a pole to ")#mi("{D}")#text(", the dimension of the space ")#mi("{L(D)}")#text(" only goes up by at most one:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6")]#text(" ")#metadata(none) <tao-2492c2a18ce9f3ca5b0a>#text(" For any divisor ")#mi("{D}")#text(" and any ")#mi("{P \\in \\Lambda \\backslash {\\bf C}}")#text(", ")#mi("{L(D)}")#text(" is a subspace of ")#mi("{L(D + (P))}")#text(" of codimension at most one. In particular, ")#mi("{L(D)}")#text(" is finite-dimensional for any ")#mi("{D}")#text(".")
]

#emph[#text("Proof:")]#text(" It is clear that ")#mi("{L(D)}")#text(" is a subspace of ")#mi("{L(D + (P))}")#text(". If ")#mi("{D}")#text(" has order ")#mi("{m}")#text(" at ")#mi("{P = \\zeta + \\Lambda}")#text(", then there is a linear functional ")#mi("{\\lambda: L(D+(P)) \\rightarrow {\\bf C}}")#text(" that assigns to each meromorphic function ")#mi("{f: \\Lambda \\backslash {\\bf C} \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" the ")#mi("{\\frac{1}{(z-\\zeta)^{m+1}}}")#text(" coefficient of the Laurent expansion of ")#mi("{f}")#text(" at ")#mi("{\\zeta}")#text(" (note from periodicity that the exact choice of coset representative ")#mi("{\\zeta}")#text(" is not relevant. A little thought reveals that the kernel of ")#mi("{\\lambda}")#text(" is precisely ")#mi("{L(D)}")#text(", and the first claim follows. The second claim follows from iterating the first claim, noting that any divisor ")#mi("{D}")#text(" can be obtained from a suitable negative divisor by the addition of finitely many poles ")#mi("{(P)}")#text(". ")#mi("\\Box")

#text("Now consider the space ")#mi("{L((P))}")#text(" for some point ")#mi("{P \\in \\Lambda \\backslash {\\bf C}}")#text(". Lemma ")#link(<tao-2492c2a18ce9f3ca5b0a>)[#text("6")]#text(" tells us that the dimension of this space is either one or two, since ")#mi("{L(0)}")#text(" was one-dimensional. The space ")#mi("{L((P))}")#text(" consists of functions ")#mi("{f}")#text(" that possibly have a simple pole at most at ")#mi("{P}")#text(", and no other poles. But Lemma ")#link(<tao-60e77101e76950a9b183>)[#text("3")]#text("(i) tells us that the residue at ")#mi("{P}")#text(" has to vanish, and so ")#mi("{f}")#text(" is in fact in ")#mi("{L(0)}")#text(" and thus is constant. (One could also argue here using the other two parts of Lemma ")#link(<tao-f953f70b9132340e2782>)[#text("2")]#text("; how?) So ")#mi("{L((P))}")#text(" is no larger than ")#mi("{L(0)}")#text(", and is thus also one-dimensional.")

#text("Now let us study the space ")#mi("{L(2 \\cdot (P))}")#text(" – the space of meromorphic functions that have at most a double pole at ")#mi("{P}")#text(" and no other poles. Again, Lemma ")#link(<tao-2492c2a18ce9f3ca5b0a>)[#text("6")]#text(" tells us that this space is one or two dimensional. To figure out which, we can normalise ")#mi("{P}")#text(" to be the origin coset ")#mi("{\\Lambda}")#text(". The question is now whether there is a doubly periodic meromorphic function that has a double pole at each point of ")#mi("{\\Lambda}")#text(". A naive candidate for such a function would be the infinite series")

#align(center)[#tao-fit-display[#mitex("\\sum_{z_0 \\in \\Lambda} \\frac{1}{(z-z_0)^2},")]]

#text("however this series turns out to not be absolutely convergent. Somewhat in analogy with the discussion of the Weierstrass and Hadamard factorisation theorems in ")#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")[#text("Notes 1")]#text(", we then proceed instead by working with the normalised function ")#mi("{\\wp}")#text(" defined by the formula ")#link(<tao-b545ddf5b84555a4dd95>)[#text("(6)")]#text(". Let us first verify that the series in ")#link(<tao-b545ddf5b84555a4dd95>)[#text("(6)")]#text(" is absolutely convergent for ")#mi("{z \\not \\in \\Lambda}")#text(". There are only finitely many ")#mi("{z_0 \\in \\Lambda}")#text(" with ")#tao-math("{\\left|z_0\\right| \\leq 2\\left|z\\right|}", block: false)#text(", and all the summands are finite for ")#mi("{z \\not \\in\\Lambda}")#text(", so we only need to establish convergence of the tail")

#align(center)[#tao-fit-display[#tao-math("\\sum_{z_0 \\in \\Lambda: \\left|z_0\\right| \\geq 2\\left|z\\right|} \\frac{1}{(z-z_0)^2} - \\frac{1}{z_0^2}.", block: true)]]

#text("However, from the fundamental theorem of calculus we have")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{(z-z_0)^2} - \\frac{1}{z_0^2} = z\\int_0^1 \\frac{-2}{(tz-z_0)^3}\\ dt = O_z( \\left|z_0\\right|^{-3} )", block: true)]]

#text("so to demonstrate absolute convergence it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{z_0 \\in \\Lambda: z_0 \\neq 0} \\frac{1}{\\left|z_0\\right|^3} < \\infty.", block: true)]]

#text("But a simple volume packing argument (considering the areas of the translates ")#mi("{z_0 + D}")#text(" of the fundamental domain ")#mi("{D}")#text(") shows that the number of lattice points ")#mi("{z_0}")#text(" in any disk ")#mi("{D(0,R)}")#text(", ")#mi("{R \\geq 1}")#text(" is ")#mi("{O_\\Lambda(R^2)}")#text(", and so by dyadic decomposition as in ")#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")[#text("Notes 1")]#text(", the series is absolutely convergent. Further repetition of the arguments from ")#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")[#text("Notes 1")]#text(" shows that the series in ")#link(<tao-b545ddf5b84555a4dd95>)[#text("(6)")]#text(" converges locally uniformly in ")#mi("{{\\bf C} \\backslash \\Lambda}")#text(", and thus is holomorphic on this set. Furthermore, for any ")#mi("{z_0 \\in \\Lambda}")#text(", the same arguments show that ")#mi("{\\wp(z) - \\frac{1}{(z-z_0)^2}}")#text(" stays bounded in a punctured neighbourhood of ")#mi("{z_0}")#text(", thus by the Riemann singularity removal theorem ")#mi("{\\wp(z)}")#text(" is equal to ")#mi("{\\frac{1}{(z-z_0)^2}}")#text(" plus a bounded holomorphic function in the neighbourhood of ")#mi("{z_0}")#text(". Thus ")#mi("{\\wp}")#text(" is meromorphic with double poles (and vanishing residue) at every lattice point ")#mi("{\\Lambda}")#text(", and no other poles.")

#text("Now we show that ")#mi("{\\wp}")#text(" is doubly periodic, thus ")#mi("{\\wp(z + \\omega_1) = \\wp(z)}")#text(" and ")#mi("{\\wp(z + \\omega_2) = \\wp(z)}")#text(" for ")#mi("{z \\in {\\bf C} \\backslash \\Lambda}")#text(". We just prove the first identity, as the second is analogous. From ")#link(<tao-b545ddf5b84555a4dd95>)[#text("(6)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\wp(z+\\omega_1) - \\wp(z) = \\sum_{z_0 \\in \\Lambda} \\frac{1}{(z-z_0+\\omega_1)^2} - \\frac{1}{(z-z_0)^2}.")]]

#text("The series on the right is absolutely convergent, and on every coset of ")#mi("{\\omega_1 {\\bf Z}}")#text(" it telescopes to zero. The claim then follows by Fubini’s theorem.")

#text("By construction, ")#mi("{\\wp}")#text(" lies in ")#mi("{L(2 \\cdot (\\Lambda))}")#text(", and is clearly non-constant. Thus ")#mi("{L(2 \\cdot (\\Lambda))}")#text(" is two-dimensional, being spanned by the constant function ")#mi("{1}")#text(" and ")#mi("{\\wp}")#text(". By translation, we see that ")#mi("{L(2 \\cdot (P))}")#text(" is two-dimensional for any other point ")#mi("{P \\in \\Lambda \\backslash {\\bf C}}")#text(" as well.")

#text("From ")#link(<tao-b545ddf5b84555a4dd95>)[#text("(6)")]#text(" it is also clear that the function ")#mi("{\\wp}")#text(" is even: ")#mi("{\\wp(-z) = \\wp(z)}")#text(". In particular, for any ")#mi("{a \\in {\\bf C}}")#text(" avoiding the half-lattice ")#mi("{\\frac{1}{2} \\Lambda = \\{ \\frac{1}{2} z_0: z_0 \\in \\Lambda\\}}")#text(" (so that ")#mi("{a}")#text(" and ")#mi("{-a}")#text(" occupy different locations in the torus ")#mi("{\\Lambda \\backslash {\\bf C}}")#text("), the function ")#mi("{\\wp - \\wp(a) \\in L(2 \\cdot (\\Lambda))}")#text(" has a zero at both ")#mi("{a+\\Lambda}")#text(" and ")#mi("{-a+\\Lambda}")#text(". By Lemma ")#link(<tao-60e77101e76950a9b183>)[#text("3")]#text("(ii) there are no other zeroes of this function (and this claim is also consistent with Lemma ")#link(<tao-60e77101e76950a9b183>)[#text("3")]#text("(iii)); thus the divisor ")#mi("{(\\wp - \\wp(a))}")#text(" of this function is given by ")#metadata(none) <tao-039d927ee7a98f0a0f2c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("(\\wp - \\wp(a)) = -2 \\cdot (\\Lambda) + (a + \\Lambda) + (-a+\\Lambda).")]]

#text(" ")#text(" If ")#mi("{a}")#text(" lies in the half-lattice ")#mi("{\\frac{1}{2} \\Lambda}")#text(" but not in ")#mi("{\\Lambda}")#text(" (thus, it lies in one of the ")#emph[#text("half-periods")]#text(" ")#mi("{\\frac{\\omega_1}{2} + \\Lambda}")#text(", ")#mi("{\\frac{\\omega_2}{2} + \\Lambda}")#text(", or ")#mi("{\\frac{\\omega_1+\\omega_2}{2} + \\Lambda}")#text(") then from the even and doubly periodic nature of ")#mi("{\\wp}")#text(" we see that ")#mi("{\\wp(a+z) = \\wp(a-z)}")#text(" for all ")#mi("{z \\not \\in \\frac{1}{2} \\Lambda}")#text(", so ")#mi("{\\wp - \\wp(a)}")#text(" in fact must have at least a double zero at ")#mi("{a}")#text(", and again from Lemma ")#link(<tao-60e77101e76950a9b183>)[#text("3")]#text("(ii) these are the only zeroes of this function. So the identity ")#link(<tao-039d927ee7a98f0a0f2c>)[#text("(9)")]#text(" also holds in this case.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7 (Classification of principal divisors)")]#text(" ")#metadata(none) <tao-dbb4e692c9327807fd2d>

#list(
[#text("(i) Let ")#mi("{P,Q,R,S}")#text(" be four points ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(" such that ")#mi("{P+Q=R+S}")#text(". Show that the divisor ")#mi("{(P)+(Q)-(R)-(S)}")#text(" is a principal divisor. (")#emph[#text("Hint:")]#text(" if ")#mi("{P = \\zeta_P + \\Lambda, Q = \\zeta_Q + \\Lambda, R = \\zeta_R + \\Lambda, S = \\zeta_S + \\Lambda}")#text(" are all distinct, use a function such as")

#tao-aligned(keep: true)[


#tao-math("f(z)  & := \\sum_{z_0 \\in \\Lambda} \\frac{1}{z-(\\zeta_R+z_0)} - \\frac{1}{z-(\\zeta_S+z_0)}", block: true)



#tao-math(" & - \\frac{1}{\\zeta_P-(\\zeta_R+z_0)} + \\frac{1}{\\zeta_P-(\\zeta_S+z_0)} .", block: true)
]

#text("If some of the ")#mi("{P,Q,R,S}")#text(" coincide, use some transformed version of the Weierstrass elliptic function ")#mi("{\\wp}")#text(" instead.)")],
[#text("(ii) Show that every divisor of degree zero and sum zero is a principal divisor.")],
[#text("(iii) Two divisors are said to be ")#emph[#text("equivalent")]#text(" if their difference is a principal divisor. Show that two divisors are equivalent if and only if they have the same degree and same sum.")],
[#text("(iv) Show that the quotient group ")#mi("{\\mathrm{Pic}(\\Lambda \\backslash {\\bf C}) := \\mathrm{Div}(\\Lambda \\backslash {\\bf C}) / \\mathrm{PDiv}(\\Lambda \\backslash {\\bf C})}")#text(" (known as the ")#emph[#text("divisor class group")]#text(" or ")#link("https://en.wikipedia.org/wiki/Picard_group")[#text("Picard group")]#text(") is isomorphic (as a group) to ")#mi("{{\\bf Z} \\times (\\Lambda \\backslash {\\bf C})}")#text(", and that the subgroup ")#mi("{\\mathrm{Pic}^0(\\Lambda \\backslash {\\bf C})}")#text(" arising from degree zero divisors (also known as the ")#link("https://en.wikipedia.org/wiki/Jacobian_variety")[#text("Jacobian variety")]#text(" of ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(") is isomorphic to ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(".")]
)
]

#text("Now let us study the space ")#mi("{L(3 \\cdot (P))}")#text(", where we again normalise ")#mi("{P = \\Lambda}")#text(" for sake of discussion. Lemma ")#link(<tao-2492c2a18ce9f3ca5b0a>)[#text("6")]#text(" tells us that this space is two or three dimensional, being spanned by ")#mi("{1}")#text(", ")#mi("{\\wp}")#text(", and possibly one other function. Note that the derivative ")#mi("{\\wp^{\\prime}}")#text(" of the meromorphic function ")#mi("{\\wp}")#text(" is also doubly periodic with a triple pole at ")#mi("{P}")#text(", so it lies in ")#mi("{L(3 \\cdot (P))}")#text(" and is not a linear combination of ")#mi("{1}")#text(" or ")#mi("{\\wp}")#text(" (as these have a lower order singularity at ")#mi("{P}")#text("). Thus ")#mi("{L(3 \\cdot (\\Lambda))}")#text(" is three-dimensional, being spanned by ")#mi("{1,\\wp,\\wp^{\\prime}}")#text(". A formal term-by-term differentiation of ")#link(<tao-b545ddf5b84555a4dd95>)[#text("(6)")]#text(" gives ")#link(<tao-534b7d22d901bbabd3fd>)[#text("(7)")]#text(". To justify ")#link(<tao-534b7d22d901bbabd3fd>)[#text("(7)")]#text(", observe that the arguments that demonstrated the meromorphicity of the right-hand side of ")#link(<tao-b545ddf5b84555a4dd95>)[#text("(6)")]#text(" also show the meromorphicity of ")#link(<tao-534b7d22d901bbabd3fd>)[#text("(7)")]#text(". From Fubini’s theorem, the fundamental theorem of calculus, and ")#link(<tao-b545ddf5b84555a4dd95>)[#text("(6)")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma (-2 \\sum_{z_0 \\in \\Lambda} \\frac{1}{(z-z_0)^3})\\ dz = \\wp(z_2) - \\wp(z_1)")]]

#text("for any contour ")#mi("{\\gamma}")#text(" in ")#mi("{{\\bf C} \\backslash \\Lambda}")#text(" from one point ")#mi("{z_1 \\in {\\bf C} \\backslash \\Lambda}")#text(" to another ")#mi("{z_2 \\in {\\bf C} \\backslash \\Lambda}")#text(", and the claim ")#link(<tao-534b7d22d901bbabd3fd>)[#text("(7)")]#text(" now follows from another appeal to the fundamental theorem of calculus. Of course, ")#mi("{L(3 \\cdot (P))}")#text(" will then also be three-dimensional for any other point ")#mi("{P}")#text(" on the torus. From ")#link(<tao-534b7d22d901bbabd3fd>)[#text("(7)")]#text(" we also see that ")#mi("{\\wp^{\\prime}}")#text(" is odd; this also follows from the even nature of ")#mi("{\\wp}")#text(". From the oddness and periodicity ")#mi("{\\wp^{\\prime}}")#text(" has to have zeroes at the half-periods ")#mi("{\\frac{1}{2} \\Lambda \\backslash \\Lambda}")#text("; in particular, from Lemma ")#link(<tao-60e77101e76950a9b183>)[#text("3")]#text("(ii) there are no other zeroes, and the principal divisor is given by")

#metadata(none) <tao-a7486489dd763891e39c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("(\\wp^{\\prime}) = -3 \\cdot (\\Lambda) + (\\frac{\\omega_1}{2} + \\Lambda) + (\\frac{\\omega_2}{2}+\\Lambda) + (\\frac{\\omega_1+\\omega_2}{2}+\\Lambda).")]]

#text("Turning now to ")#mi("{L(4 \\cdot (\\Lambda))}")#text(", we could differentiate ")#mi("{\\wp}")#text(" yet again to generate a doubly periodic function ")#mi("{\\wp^{\\prime\\prime}}")#text(" with a fourth order pole at the origin, but we can also work with the square ")#mi("{\\wp^2}")#text(" of the Weierstrass function. From Lemma ")#link(<tao-2492c2a18ce9f3ca5b0a>)[#text("6")]#text(" we conclude that ")#mi("{L(4 \\cdot (\\Lambda))}")#text(" is four-dimensional and is spanned by ")#mi("{1, \\wp, \\wp^2, \\wp^{\\prime}}")#text(". In a similar fashion, ")#mi("{L(5 \\cdot (\\Lambda))}")#text(" is a five-dimensional space spanned by ")#mi("{1, \\wp, \\wp^2, \\wp^{\\prime}, \\wp \\wp^{\\prime}}")#text(".")

#text("Something interesting happens though at ")#mi("{L(6 \\cdot (\\Lambda))}")#text(". Lemma ")#link(<tao-2492c2a18ce9f3ca5b0a>)[#text("6")]#text(" tells us that this space is the span of ")#mi("{1, \\wp, \\wp^2, \\wp^{\\prime}, \\wp\\wp^{\\prime}}")#text(", and possibly one other function, which will have a pole of order six at the origin. Here we have ")#emph[#text("two")]#text(" natural candidates for such a function: the cube ")#mi("{\\wp^3}")#text(" of the Weierstrass function, and the square ")#mi("{(\\wp^{\\prime})^2}")#text(" of its derivative. Both have a pole of order exactly six and lie in ")#mi("{L(6 \\cdot (\\Lambda))}")#text(", and so ")#mi("{(\\wp^{\\prime})^2}")#text(" must be a linear combination of ")#mi("{1, \\wp, \\wp^2, \\wp^3, \\wp^{\\prime}, \\wp \\wp^{\\prime}}")#text(". But since ")#mi("{(\\wp^{\\prime})^2, 1, \\wp, \\wp^2, \\wp^3}")#text(" are even and ")#mi("{\\wp^{\\prime}, \\wp \\wp^{\\prime}}")#text(" are odd, ")#mi("{(\\wp^{\\prime})^2}")#text(" must in fact just be a linear combination of ")#mi("{1, \\wp, \\wp^2, \\wp^3}")#text(". To work out the precise combination, we see by repeating the derivation of ")#link(<tao-534b7d22d901bbabd3fd>)[#text("(7)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\wp^{(k)}(z) = (-1)^k (k+1)! \\sum_{z_0 \\in \\Lambda} \\frac{1}{(z-z_0)^{k+2}}")]]

#text("for any ")#mi("{k=1,2,\\dots}")#text(", so that the function ")#mi("{\\wp(z) - \\frac{1}{z^2}}")#text(", which extends holomorphically to the origin, has ")#mi("{k^{th}}")#text(" derivative at the origin equal to ")#mi("{(k+1)! G_{k+2}(\\Lambda)}")#text(", where the ")#link("https://en.wikipedia.org/wiki/Eisenstein_series")[#text("Eisenstein series")]#text(" ")#mi("{G_k(\\Lambda)}")#text(" is defined by the formula")

#align(center)[#tao-fit-display[#mitex("G_k(\\Lambda) := \\sum_{z_0 \\in \\Lambda \\backslash \\{0\\}} \\frac{1}{z_0^k};")]]

#text("we can also extend this to the ")#mi("{k=0}")#text(" case with convention ")#mi("{G_2(\\Lambda)=0}")#text(". Note from the symmetric nature of ")#mi("{\\Lambda}")#text(" that ")#mi("{G_k(\\Lambda)}")#text(" vanishes for odd ")#mi("{k}")#text("; this is consistent with the even nature of ")#mi("{\\wp}")#text(". We thus have the Laurent expansion")

#tao-aligned(keep: true)[


#tao-math("\\wp(z)  & = \\frac{1}{z^2} + \\sum_{k=1}^\\infty (2k+1) G_{2k+2}(\\Lambda) z^{2k}", block: true)



#tao-math(" & = \\frac{1}{z^2} + 3 G_4(\\Lambda) z^2 + 5 G_6(\\Lambda) z^4 + \\dots", block: true)
]

#text("for ")#mi("{z}")#text(" near zero. This then gives the further Laurent expansions")

#tao-aligned(keep: true)[


#tao-math("\\wp(z)^2  & = \\frac{1}{z^4} + 6 G_4(\\Lambda) + 10 G_6(\\Lambda) z^2 + \\dots", block: true)



#tao-math("\\wp(z)^3  & = \\frac{1}{z^6} + \\frac{9 G_4(\\Lambda)}{z^2} + 15 G_6(\\Lambda) + \\dots", block: true)



#tao-math("\\wp^{\\prime}(z)  & = -\\frac{2}{z^3} + 6 G_4(\\Lambda) z + 20 G_6(\\Lambda) z^3 + \\dots", block: true)



#tao-math("\\wp^{\\prime}(z)^2  & = \\frac{4}{z^6} - \\frac{24 G_4(\\Lambda)}{z^2} - 80 G_6(\\Lambda) + \\dots.", block: true)
]

#text("From these expansions we see that the decomposition of ")#mi("{\\wp^{\\prime}(z)^2}")#text(" into a linear combination of ")#mi("{1,\\wp,\\wp^2,\\wp^3}")#text(" does not actually involve ")#mi("{\\wp^2}")#text(" (as this function is the only one that has a ")#mi("{1/z^4}")#text(" term in its Laurent expansion), and on comparing ")#mi("{1/z^6}")#text(" coefficients we see that the coefficient of ")#mi("{\\wp^3}")#text(" must be ")#mi("{4}")#text(". Thus we have a linear relationship of the form ")#link(<tao-3e9417dce4568dba3e1c>)[#text("(8)")]#text(" for some coefficients ")#mi("{g_2 = g_2(\\Lambda), g_3 = g_3(\\Lambda)}")#text(", which on inspection of the ")#mi("{\\frac{1}{z^2}}")#text(" and constant terms leads to the formulae")

#align(center)[#tao-fit-display[#mitex("g_2 := 60 G_4(\\Lambda); \\quad g_3 := 140 G_6(\\Lambda).")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Derive ")#link(<tao-3e9417dce4568dba3e1c>)[#text("(8)")]#text(" directly from Proposition ")#link(<tao-f953f70b9132340e2782>)[#text("2")]#text(" by showing that the difference between the two sides is doubly periodic and holomorphic after removing singularities.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9 (Classification of doubly periodic meromorphic functions)")]#text(" ")#metadata(none) <tao-4b329e0081a1c93e1863>

#list(
[#text("(i) For any ")#mi("{k \\geq 2}")#text(", show that ")#mi("{L( k \\cdot (\\Lambda))}")#text(" has dimension ")#mi("{k}")#text(", and every element of this space is a polynomial combination of ")#mi("{\\wp, \\wp^{\\prime}}")#text(".")],
[#text("(ii) Show that every doubly periodic meromorphic function is a rational function of ")#mi("{\\wp, \\wp^{\\prime}}")#text(".")]
)
]

#text("We have an alternate form of ")#link(<tao-3e9417dce4568dba3e1c>)[#text("(8)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" ")#metadata(none) <tao-a4a3a4d7d4292cb4bcc8>#text(" Define the roots ")#mi("{e_1 := \\wp( \\frac{\\omega_1}{2} )}")#text(", ")#mi("{e_2 := \\wp( \\frac{\\omega_2}{2} )}")#text(", ")#mi("{e_3 := \\wp( \\frac{\\omega_1+\\omega_2}{2} )}")#text(".")

#list(
[#text("(i) Show that ")#mi("{e_1,e_2,e_3}")#text(" are distinct, and that")

#align(center)[#tao-fit-display[#mitex("(\\wp^{\\prime}(z))^2 = 4 (\\wp(z) - e_1) (\\wp(z) - e_2) (\\wp(z) - e_3)")]]

#text("for all ")#mi("{z \\in {\\bf C} \\backslash \\Lambda}")#text(". (")#emph[#text("Hint:")]#text(" use ")#link(<tao-a7486489dd763891e39c>)[#text("(10)")]#text(".) Conclude in particular that ")#mi("{e_1+e_2+e_3=0}")#text(", ")#mi("{g_2 = 2(e_1^2+e_2^2+e_3^2)}")#text(", and ")#mi("{g_3=4e_1e_2e_3}")#text(".")],
[#text("(ii) Show that the ")#link("https://en.wikipedia.org/wiki/Weierstrass%27s_elliptic_functions#Modular_discriminant")[#text("modular discriminant")]

#align(center)[#tao-fit-display[#mitex("\\Delta = \\Delta(\\Lambda) := g_2^3 - 27 g_3^2")]]

#text("is equal to ")#mi("{16(e_1-e_2)^2 (e_2-e_3)^2 (e_1-e_3)^2}")#text(", and is in particular non-zero.")]
)
]

#text("If we now define the ")#link("https://en.wikipedia.org/wiki/Elliptic_curve")[#text("elliptic curve")]

#tao-aligned(keep: true)[


#tao-math("C  & := \\{ (z,w) \\in {\\bf C}^2: w^2 = 4z^3 - g_2 z - g_3 \\} \\cup \\{ \\infty\\}", block: true)



#tao-math(" & = \\{ (z,w) \\in {\\bf C}^2: w^2 = 4(z-e_1)(z-e_2)(z-e_3) \\} \\cup \\{ \\infty\\}", block: true)
]

#text("to be the union of a certain cubic curve in the complex plane ")#mi("{{\\bf C}^2}")#text(" together with the point at infinity (where the notions of “curve” and “plane” are relative to the underlying complex field ")#mi("{{\\bf C}}")#text(" rather than the more familiar real field ")#mi("{{\\bf R}}")#text("), then we have a map")

#metadata(none) <tao-60be9861750facbfad87>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\Phi: z \\mapsto (\\wp(z), \\wp^{\\prime}(z))")]]

#text("from ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(" to ")#mi("{C}")#text(", with the convention that the origin ")#mi("{\\Lambda}")#text(" is mapped to the point at infinity ")#mi("{\\infty}")#text(". For instance, the half-periods ")#mi("{\\frac{\\omega_1}{2} + \\Lambda}")#text(", ")#mi("{\\frac{\\omega_2}{2} + \\Lambda}")#text(", ")#mi("{\\frac{\\omega_1+\\omega_2}{2} + \\Lambda}")#text(" are mapped to the points ")#mi("{(e_1,0), (e_2,0), (e_3,0)}")#text(" of ")#mi("{C}")#text(" respectively.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11")]#text(" The map ")#mi("{\\Phi}")#text(" defined by ")#link(<tao-60be9861750facbfad87>)[#text("(11)")]#text(" is a bijection between ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(" and ")#mi("{C}")#text(".")
]

#text("Among other things, this lemma implies that the elliptic curve ")#mi("{C}")#text(" is topologically equivalent (i.e., homeomorphic to) a torus, which is not an entirely obvious fact (though if one squints hard enough, the real analogue of an elliptic curve does resemble a distorted slice of a torus embedded in ")#mi("{{\\bf R}^3}")#text(").")

#emph[#text("Proof:")]#text(" Clearly ")#mi("{\\Lambda}")#text(" is the only point that maps to ")#mi("{\\infty}")#text(", and (from ")#link(<tao-a7486489dd763891e39c>)[#text("(10)")]#text(") the half-periods are the only points that map to ")#mi("{(e_1,0), (e_2,0), (e_3,0)}")#text(". It remains to show that all the other points ")#mi("{(z,w)}")#text(" arise via ")#mi("{\\Phi}")#text(" from exactly one element of ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(". The function ")#mi("{\\wp - z}")#text(" has exactly two zeroes by Lemma ")#link(<tao-60e77101e76950a9b183>)[#text("3")]#text("(ii), which lie at ")#mi("{a+\\Lambda, -a+\\Lambda}")#text(" for some ")#mi("{a}")#text(" as ")#mi("{\\wp}")#text(" is even; since ")#mi("{(z,w) \\neq (e_1,0), (e_2,0), (e_3,0)}")#text(", ")#mi("{z}")#text(" is not equal to ")#mi("{e_1,e_2,e_3}")#text(", hence ")#mi("{a}")#text(" is not a half-period. As ")#mi("{\\wp^{\\prime}}")#text(" is odd, the map ")#link(<tao-60be9861750facbfad87>)[#text("(11)")]#text(" must therefore map ")#mi("{a+\\Lambda, -a+\\Lambda}")#text(" to the two points ")#mi("{(z,w), (z,-w)}")#text(" of the elliptic curve ")#mi("{C}")#text(" that lie above ")#mi("{z}")#text(", and the claim follows. ")#mi("\\Box")

#text("Analogously to the Riemann sphere ")#mi("{{\\bf C} \\cup \\{ \\infty\\}}")#text(", the elliptic curve ")#mi("{C}")#text(" can be given the structure of a Riemann surface, by prescribing the following charts:")

#list(
[#text("(i) When ")#mi("{(z_0,w_0)}")#text(" is a point in ")#mi("{C}")#text(" other than ")#mi("{\\infty}")#text(" or ")#mi("{(e_1,0), (e_2,0), (e_3,0)}")#text(", then locally ")#mi("{C}")#text(" is the graph of a holomorphic branch ")#mi("{(4(z-e_1)(z-e_2)(z-e_3))^{1/2}}")#text(" of the square root of ")#mi("{4(z-e_1)(z-e_2)(z-e_3)}")#text(" near ")#mi("{(z_0,w_0)}")#text(", and one can use ")#mi("{z}")#text(" as a coordinate function in a sufficiently small neighbourhood of ")#mi("{(z_0,w_0)}")#text(".")],
[#text("(ii) In the neighbourhood of ")#mi("{(e_j,0)}")#text(" for some ")#mi("{j=1,2,3}")#text(", the function ")#mi("{f: z \\mapsto 4(z-e_1)(z-e_2)(z-e_3)}")#text(" has a simple zero at ")#mi("{e_j}")#text(" and so has a local inverse ")#mi("{f^{-1}}")#text(" that maps a neighbourhood of ")#mi("{0}")#text(" to a neighbourhood of ")#mi("{e_j}")#text(", and a point ")#mi("{(z,w)}")#text(" sufficiently near ")#mi("{(e_j,0)}")#text(" can be parameterised by ")#mi("{(f^{-1}(w^2),w)}")#text(". One can then use ")#mi("{w}")#text(" as a coordinate function in a neighbourhood of ")#mi("{(e_j,0)}")#text(".")],
[#text("(iii) A neighbourhood of ")#mi("{\\infty}")#text(" consists of ")#mi("{\\infty}")#text(" and the points ")#mi("{(z,w)}")#text(" in the remaining portion of ")#mi("{C}")#text(" with ")#mi("{z, w}")#text(" sufficiently large; then ")#mi("{w}")#text(" is asymptotic to a square root of ")#mi("{4z^3}")#text(", so in particular ")#mi("{w/z^2}")#text(" and ")#mi("{1/z}")#text(" should both go to zero as ")#mi("{(z,w)}")#text(" goes to infinity in ")#mi("{C}")#text(". We rewrite the defining equation ")#mi("{w^2 = 4z^3 - g_2 z - g_3}")#text(" of the curve in terms of ")#mi("{w/z^2}")#text(" and ")#mi("{1/z}")#text(" as ")#mi("{(w/z^2)^2 = 4 (1/z) - g_2 (1/z)^3 - g_3 (1/z)^4}")#text(". The function ")#mi("{h(\\xi) := 4 \\xi - g_2 \\xi^3 - g_3 \\xi^4}")#text(" has a simple zero at zero and thus has a holomorphic local inverse ")#mi("{h^{-1}}")#text(" that maps ")#mi("{0}")#text(" to ")#mi("{0}")#text(", and we have ")#mi("{1/z = h^{-1}((w/z^2)^2)}")#text(" in a neighbourhood of infinity. We can then use ")#mi("{w/z^2}")#text(" as a coordinate function in a neighbourhood of ")#mi("{\\infty}")#text(", with the convention that this coordinate function vanishes at infinity.")]
)

#text("It is then a tedious but routine matter to check that ")#mi("{C}")#text(" has the structure of a Riemann surface. We then claim that the bijection ")#mi("{\\Phi}")#text(" defined by ")#link(<tao-60be9861750facbfad87>)[#text("(11)")]#text(" is holomorphic, and thus a complex diffeomorphism of Riemann surfaces. In the neighbourhood of any point ")#mi("{\\zeta+\\Lambda}")#text(" of the torus ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(" other than the origin ")#mi("{\\Lambda}")#text(", ")#mi("{\\Phi}")#text(" maps to a neighbourhood of finite point ")#mi("{(z,w)}")#text(" of ")#mi("{C}")#text(", including the three points ")#mi("{(e_1,0), (e_2,0), (e_3,0)}")#text(", the holomorphicity is a routine consequence of composing together the various local holomorphic functions and their inverses. In the neighbourhood of the origin ")#mi("{\\Lambda}")#text(", ")#mi("{\\Phi}")#text(" maps ")#mi("{z+\\Lambda}")#text(" for small ")#mi("{z}")#text(" to a point of ")#mi("{C}")#text(" with a Laurent expansion")

#align(center)[#tao-fit-display[#mitex("(\\frac{1}{z^2} + O(z^2), \\frac{-2}{z^3} + O(z))")]]

#text("from the Laurent expansions of ")#mi("{\\wp, \\wp^{\\prime}}")#text(", so in particular the coordinate ")#mi("{w/z^2}")#text(" takes the form ")#mi("{-4 z + O(z^5)}")#text(" where the error term ")#mi("{O(z^5)}")#text(" is holomorphic, with ")#mi("{0}")#text(" mapping to ")#mi("{0}")#text(". In particular the map is a local complex diffeomorphism here and again we have holomorphicity. We thus conclude that the elliptic curve ")#mi("{C}")#text(" is complex diffeomorphic to the torus ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(" using the map ")#mi("{\\Phi}")#text(". From Exercise ")#link(<tao-4b329e0081a1c93e1863>)[#text("9")]#text(", the meromorphic functions on ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(" may be identified with the rational functions on ")#mi("{C}")#text(".")

#text("While we have shown that all tori are complex diffeomorphic to elliptic curves, the converse statement that all elliptic curves are diffeomorphic to tori will have to wait until the next section for a proof, once we have set up the machinery of modular forms.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Group law on elliptic curves)")]

#list(
[#text("(i) Let ")#mi("{P,Q,R}")#text(" be three distinct elements of the torus ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(" that are not equal to the origin ")#mi("{\\Lambda}")#text(". Show that ")#mi("{P+Q+R=\\Lambda}")#text(" if and only if the three points ")#mi("{(\\wp(P), \\wp^{\\prime}(P))}")#text(", ")#mi("{(\\wp(Q), \\wp^{\\prime}(Q))}")#text(", ")#mi("{(\\wp(R), \\wp^{\\prime}(R))}")#text(" are collinear in ")#mi("{C}")#text(", in the sense that they lie on a common complex line ")#mi("{\\{ (z,w) \\in {\\bf C}^2: az+bw=c\\}}")#text(" for some complex numbers ")#mi("{a,b,c}")#text(" with ")#mi("{a,b}")#text(" not both zero.")],
[#text("(ii) What happens in (i) if (say) ")#mi("{P}")#text(" and ")#mi("{Q}")#text(" agree? What about if ")#mi("{R = \\Lambda}")#text("?")],
[#text("(iii) Using (i), (ii), give a purely geometric definition of a group addition law on the elliptic curve ")#mi("{C}")#text(" which is compatible with the group addition law on the torus ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(" via ")#link(<tao-60be9861750facbfad87>)[#text("(11)")]#text(". (We remark that the associativity property of this law is not obvious from a purely geometric perspective, and is related to the Cayley-Bacharach theorem in classical geometry; see ")#link("https://terrytao.wordpress.com/2011/07/15/pappuss-theorem-and-elliptic-curves/")[#text("this previous blog post")]#text(".)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Addition law)")]#text(" Show that for any ")#mi("{z, w \\in {\\bf C} \\backslash \\Lambda}")#text(" with ")#mi("{z-w, z+w \\not \\in \\Lambda}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\wp(z+w) = \\frac{1}{4} \\left( \\frac{\\wp^{\\prime}(z) - \\wp^{\\prime}(w)}{\\wp(z)-\\wp(w)} \\right)^2 - \\wp(z) - \\wp(w).")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14 (Special case of Riemann-Roch)")]

#list(
[#text("(i) Show that if two divisors ")#mi("{D,D^{\\prime}}")#text(" are equivalent (in the sense of Exercise ")#link(<tao-dbb4e692c9327807fd2d>)[#text("7")]#text("(iii)), then the vector spaces ")#mi("{L(D)}")#text(" and ")#mi("{L(D^{\\prime})}")#text(" are isomorphic (in particular, they have the same dimension).")],
[#text("(ii) If ")#mi("{D}")#text(" is a divisor of some degree ")#mi("{d}")#text(", show that the dimension of the space ")#mi("{L(D)}")#text(" is zero if ")#mi("{d < 0}")#text(", equal to ")#mi("{d}")#text(" if ")#mi("{d>0}")#text(", equal to ")#mi("{0}")#text(" if ")#mi("{d=0}")#text(" and ")#mi("{D}")#text(" has non-zero sum, and equal to ")#mi("{1}")#text(" if ")#mi("{d=0}")#text(" and ")#mi("{D}")#text(" has zero sum. (")#emph[#text("Hint:")]#text(" use Exercise ")#link(<tao-dbb4e692c9327807fd2d>)[#text("7")]#text("(iii) and part (i) to replace ")#mi("{D}")#text(" with an equivalent divisor of a simple form.)")],
[#text("(iii) Verify the identity")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim} L(D) - \\mathrm{dim} L(-D) = \\mathrm{deg}(D)")]]

#text("for any divisor ")#mi("{D}")#text(". This is a special case of the more general ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93Roch_theorem")[#text("Riemann-Roch theorem")]#text(", discussed in ")#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/")[#text("these 246C notes")]#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Elliptic integrals)")]

#list(
[#text("(i) Show that ")#mi("{\\wp}")#text(" is a covering map from ")#mi("{{\\bf C} \\backslash \\frac{1}{2} \\Lambda}")#text(" to the thrice-punctured plane ")#mi("{{\\bf C} \\backslash \\{e_1,e_2,e_3\\}}")#text(".")],
[#text("(ii) Let ")#mi("{\\gamma}")#text(" be a contour in ")#mi("{{\\bf C} \\backslash \\{e_1,e_2,e_3\\}}")#text(" from some complex number ")#mi("{z_1}")#text(" to another complex number ")#mi("{z_2}")#text(", and suppose that there is a holomorphic branch ")#mi("{\\sqrt{4(z-e_1)(z-e_2)(z-e_3)}}")#text(" of the square root of ")#mi("{4(z-e_1)(z-e_2)(z-e_3)}")#text(" in a neighbourhood of ")#mi("{\\gamma}")#text(". Show that there exists complex numbers ")#mi("{\\zeta_1, \\zeta_2 \\in {\\bf C} \\backslash \\frac{1}{2} \\Lambda}")#text(" with ")#mi("{\\wp(\\zeta_1) = z_1}")#text(", ")#mi("{\\wp(\\zeta_2) = z_2}")#text(" such that")

#metadata(none) <tao-a12947dbf7d04ce3a055>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\int_\\gamma \\frac{dz}{\\sqrt{4(z-e_1)(z-e_2)(z-e_3)}} = \\zeta_2 - \\zeta_1.")]]]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 16")]#text(" The integral ")#mi("{\\int_\\gamma \\frac{dz}{\\sqrt{4(z-e_1)(z-e_2)(z-e_3)}}}")#text(" is an example of an ")#link("https://en.wikipedia.org/wiki/Elliptic_integral")[#text("elliptic integral")]#text("; many other elliptic integrals (such as the integral arising when computing the perimeter of an ellipse) can be transformed into this form (or into a closely related integral) by various elementary substitutions. Thus the Weierstrass elliptic function ")#mi("{\\wp}")#text(" can be employed to evaluate elliptic integrals, which may help explain the terminology “elliptic” that occurs throughout these notes. In ")#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/")[#text("246C notes")]#text(" we will introduce the notion of a meromorphic ")#mi("{1}")#text("-form on a Riemann surface. The identity ")#link(<tao-a12947dbf7d04ce3a055>)[#text("(12)")]#text(" can then be interpreted in this language as the differential form identity ")#mi("{d(\\Phi^{-1}) = \\frac{dz}{w}}")#text(", where ")#mi("{z,w}")#text(" are the standard coordinates on the elliptic curve ")#mi("{C}")#text("; the meromorphic ")#mi("{1}")#text("-form is initially only defined on ")#mi("{C}")#text(" outside of the four points ")#mi("{(e_1,0), (e_2,0), (e_3,0), \\infty}")#text(", but this identity in fact reveals that the form extends holomorphically to all of ")#mi("{C}")#text("; it is an example of what is known as an ")#link("https://en.wikipedia.org/wiki/Differential_of_the_first_kind")[#text("Abelian differential of the first kind")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 17")]#text(" The elliptic curve ")#mi("{C}")#text(" (for various choices of parameters ")#mi("{g_2,g_3}")#text(") can be defined in other fields than the complex numbers (though some technicalities arise in characteristic two and three due to the pathological behaviour of the discriminant in those cases). On the other hand, the Weierstrass elliptic function ")#mi("{\\wp}")#text(" is a transcendental function which only exists in complex analysis and does not have a direct analogue in other fields. So this connection between elliptic curves and tori is specific to the complex field. Nevertheless, many facts about elliptic curves that were initially discovered over the complex numbers through this complex-analytic link to tori, were then reproven by purely algebraic means, so that they could be extended without much difficulty to many other fields than the complex numbers, such as finite fields. (For instance, the role of the complex torus can be replaced by the Jacobian variety, which was briefly introduced in Exercise ")#link(<tao-dbb4e692c9327807fd2d>)[#text("7")]#text(".) Elliptic curves over such fields are of major importance in number theory (and cryptography), but we will not discuss these topics further here.")
]

#heading(level: 1)[#strong[#text(" — 2. Modular functions and modular forms — ")]]

#text("In Exercise 32 of ")#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/")[#text("246A Notes 5")]#text(", it was shown that two tori ")#mi("{(\\omega_1 {\\bf Z} + \\omega_2{\\bf Z}) \\backslash {\\bf C}}")#text(" and ")#mi("{(\\omega^{\\prime}_1 {\\bf Z} + \\omega^{\\prime}_2{\\bf Z}) \\backslash {\\bf C}}")#text(" are complex diffeomorphic if and only if one has ")#metadata(none) <tao-26574434d2443863acd5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\frac{\\omega^{\\prime}_1}{\\omega^{\\prime}_2} = \\pm \\frac{a\\omega_1+b\\omega_2}{c\\omega_1+d\\omega_2}")]]

#text(" ")#text(" for some integers ")#mi("{a,b,c,d}")#text(" with ")#mi("{ad-bc=1}")#text(". From this it is not difficult to see that if ")#mi("{\\Lambda,\\Lambda^{\\prime}}")#text(" are two lattices in ")#mi("{{\\bf C}}")#text(", then ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(" and ")#mi("{\\Lambda^{\\prime} \\backslash {\\bf C}}")#text(" are diffeomorphic if and only if ")#mi("{\\Lambda^{\\prime} = \\lambda \\cdot \\Lambda}")#text(" for some ")#mi("{\\lambda \\in {\\bf C} \\backslash \\{0\\}}")#text(", i.e., the lattices ")#mi("{\\Lambda,\\Lambda^{\\prime}}")#text(" are complex dilations of each other.")

#text("Let us write ")#mi("{X_0(1)}")#text(" for the set of all tori ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(" quotiented by the equivalence relation of complex diffeomorphism; this is the (classical, level one, noncompactified) ")#link("https://en.wikipedia.org/wiki/Classical_modular_curve")[#text("modular curve")]#text(". By the above discussion, this set can also be identified with the set of pairs ")#mi("{(\\omega_1,\\omega_2)}")#text(" of linearly independent (over ")#mi("{{\\bf R}}")#text(") complex numbers quotiented by the equivalence relation given implicitly by ")#link(<tao-26574434d2443863acd5>)[#text("(13)")]#text(". One can simplify this a little by observing that any pair ")#mi("{(\\omega_1,\\omega_2)}")#text(" is equivalent to ")#mi("{(1,\\tau)}")#text(" for some ")#mi("{\\tau}")#text(" in the upper half-plane ")#mi("{{\\mathbf H}}")#text(", namely either ")#mi("{+\\omega_2/\\omega_1}")#text(" or ")#mi("{-\\omega_2/\\omega_1}")#text(" depending on the relative phases of ")#mi("{\\omega_1}")#text(" and ")#mi("{\\omega_2}")#text("; this quantity ")#mi("{\\tau}")#text(" is known as the ")#emph[#text("period ratio")]#text(". From ")#link(<tao-26574434d2443863acd5>)[#text("(13)")]#text(" (swapping the roles of ")#mi("{\\omega_1,\\omega_2}")#text(" as necessary), we then see that two pairs ")#mi("{(1,\\tau), (1,\\tau^{\\prime})}")#text(" are equivalent if one has")

#align(center)[#tao-fit-display[#mitex("\\tau^{\\prime} = \\pm \\frac{a \\tau + b}{c\\tau + d}")]]

#text("for some integers ")#mi("{a,b,c,d}")#text(" with ")#mi("{ad-bc=1}")#text(". Recall that the Möbius transformation ")#mi("{\\tau \\mapsto \\frac{a \\tau + b}{c\\tau + d}}")#text(" preserves ")#mi("{{\\bf H}}")#text(" (see Exercise 20 of ")#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/")[#text("246A Notes 5")]#text("), so the ")#mi("{\\pm}")#text(" sign here must actually be positive. We can interpret this in terms of the action of the matrix group")

#align(center)[#tao-fit-display[#mitex("SL_2({\\bf Z}) := \\{ \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix}: a,b,c,d \\in {\\bf Z}: ad-bc = 1 \\}")]]

#text("on ")#mi("{{\\bf H}}")#text(" by Möbius transformation")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} \\cdot \\tau := \\frac{a\\tau+b}{c\\tau+d}")]]

#text("and we conclude that two pairs ")#mi("{(1,\\tau), (1,\\tau^{\\prime})}")#text(" are equivalent if and only if the period ratios ")#mi("{\\tau,\\tau^{\\prime}}")#text(" lie in the same orbit of ")#mi("{SL_2({\\bf Z})}")#text(". Thus we can identify the modular curve ")#mi("{X_0(1)}")#text(" (as a set, at least) with the quotient space ")#mi("{SL_2({\\bf Z}) \\backslash {\\bf H}}")#text(". Actually if one wished one could replace ")#mi("{SL_2({\\bf Z})}")#text(" here with the projective subgroup ")#mi("{PSL_2({\\bf Z})}")#text(", since the negative identity matrix ")#mi("{\\begin{pmatrix} -1 & 0 \\\\0 & -1 \\end{pmatrix}}")#text(" acts trivially on ")#mi("{{\\bf H}}")#text(".")

#text("If we use the relation ")#mi("{ad-bc=1}")#text(" to write ")#metadata(none) <tao-88d4266fd4e6338d13b8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\frac{a \\tau + b}{c\\tau + d} = \\frac{a}{c} - \\frac{1}{c(c\\tau+d)}")]]

#text(" ")#text(" we see that ")#mi("{\\frac{a \\tau + b}{c\\tau + d}}")#text(" approaches the real line as ")#mi("{(c,d) \\rightarrow \\infty}")#text(" if ")#mi("{c}")#text(" is non-zero; also, if ")#mi("{c}")#text(" is zero, then from ")#mi("{ad-bc=1}")#text(" we must have ")#mi("{d = \\pm 1}")#text(", and ")#mi("{\\frac{a\\tau+b}{c\\tau+d}}")#text(" will either have imaginary part going off to infinity (if ")#mi("{a}")#text(" goes to infinity) or real part going to infinity (if ")#mi("{a}")#text(" is bounded and ")#mi("{b}")#text(" goes to infinity). In all cases we then conclude that ")#mi("{\\frac{a\\tau+b}{c\\tau+d}}")#text(" goes to infinity as ")#mi("{\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} \\in SL_2({\\bf Z})}")#text(" goes to infinity, uniformly for ")#mi("{\\tau}")#text(" in any fixed compact subset of ")#mi("{{\\bf H}}")#text(", which makes the action of ")#mi("{SL_2({\\bf Z})}")#text(" on ")#mi("{{\\bf H}}")#text(" proper (for any compact set ")#mi("{K \\subset {\\bf H}}")#text(", one has ")#mi("{\\gamma K}")#text(" intersecting ")#mi("{K}")#text(" for at most finitely many ")#mi("{\\gamma \\in SL_2({\\bf Z})}")#text(". If ")#mi("{PSL_2({\\bf Z})}")#text(" acted freely on ")#mi("{{\\bf H}}")#text(" (i.e., any element ")#mi("{\\gamma}")#text(" of ")#mi("{SL_2({\\bf Z})}")#text(" other than the identity and negative identity has no fixed points in ")#mi("{{\\bf H}}")#text("), then the quotient ")#mi("{SL_2({\\bf Z}) \\backslash {\\bf H}}")#text(" would be a Riemann surface by the discussion in Section 2 of ")#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/")[#text("246A Notes 5")]#text(". Unfortunately, this is not quite true. For instance, the point ")#mi("{i \\in {\\bf H}}")#text(" is fixed by the Möbius transformation ")#mi("{\\omega \\mapsto \\frac{-1}{\\omega}}")#text(" coming from the rotation matrix ")#mi("{\\begin{pmatrix} 0 & -1 \\\\ 1 & 0 \\end{pmatrix}}")#text(" of ")#mi("{SL_2({\\bf Z})}")#text(", and the point ")#mi("{e^{\\pi i/3} \\in {\\bf H}}")#text(" is similarly fixed by the transformation ")#mi("{\\omega \\mapsto \\frac{-1}{\\omega-1}}")#text(" coming from the matrix ")#mi("{\\begin{pmatrix} 0 & -1 \\\\ 1 & -1 \\end{pmatrix}}")#text(" of ")#mi("{SL_2({\\bf Z})}")#text(". Geometrically, these fixed points come from the fact that the ")#link("https://en.wikipedia.org/wiki/Gaussian_integer")[#text("Gaussian integgers")]#text(" ")#mi("{{\\bf Z} + i{\\bf Z}}")#text(" are invariant with respect to rotation by ")#mi("{\\pi/2}")#text(", while the ")#link("https://en.wikipedia.org/wiki/Eisenstein_integer")[#text("Eisenstein integers")]#text(" ")#mi("{{\\bf Z} + e^{\\pi i/3} {\\bf Z}}")#text(" are invariant with respect to rotation by ")#mi("{\\pi/3}")#text(". On the other hand, these are basically the only two places where the action is not free:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Suppose that ")#mi("{\\tau}")#text(" is an element of ")#mi("{{\\bf H}}")#text(" which is fixed by some element ")#mi("{\\gamma}")#text(" of ")#mi("{SL_2({\\bf Z})}")#text(" which is not the identity or negative identity. Let ")#mi("{\\Lambda}")#text(" be the lattice ")#mi("{\\Lambda := {\\bf Z} + \\tau {\\bf Z}}")#text(".")

#list(
[#text("(i) Show that ")#mi("{\\Lambda}")#text(" obeys a dilation invariance ")#mi("{\\Lambda = \\lambda \\cdot \\Lambda}")#text(" for some complex number ")#mi("{\\lambda}")#text(" which is not real.")],
[#text("(ii) Show that the dilation ")#mi("{\\lambda}")#text(" in part (i) must have magnitude one. (Hint: look at a non-zero element of ")#mi("{\\Lambda}")#text(" of minimal magnitude.)")],
[#text("(iii) Show that there is no rotation invariance ")#mi("{\\Lambda = e^{i\\theta} \\cdot \\Lambda}")#text(" with ")#mi("{0 < \\theta < \\pi/3}")#text(". (Hint: again, work with a non-zero element of ")#mi("{\\Lambda}")#text(" of minimal magnitude, and use the fact that ")#mi("{\\Lambda}")#text(" is closed under addition and subtraction. It may help to think geometrically and draw plenty of pictures.)")],
[#text("(iv) Show that ")#mi("{\\Lambda}")#text(" is equivalent to either the Gaussian lattice ")#mi("{{\\bf Z} + i{\\bf Z}}")#text(" or the Eisenstein lattice ")#mi("{{\\bf Z} + e^{\\pi i/3} {\\bf Z}}")#text(", and conclude that the period ratio ")#mi("{\\tau}")#text(" is equivalent to either ")#mi("{i}")#text(" or ")#mi("{e^{\\pi i/3}}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 19")]#text(" The conformal map ")#mi("{z \\mapsto iz}")#text(" on the complex numbers preserves the Gaussian integers ")#mi("{{\\bf Z} + i{\\bf Z}}")#text(" and thus descends to a conformal map from the Gaussian torus ")#mi("{{\\bf Z} + i{\\bf Z} \\backslash {\\bf C}}")#text(" to itself; similarly the conformal map ")#mi("{z \\mapsto e^{\\pi i/3}}")#text(" preserves the Eisenstein integers and thus descends to a conformal map from the Eisenstein torus ")#mi("{{\\bf Z} + e^{\\pi i/3}{\\bf Z} \\backslash {\\bf C}}")#text(" to itself. These rare examples of complex tori equipped with additional conformal automorphisms are examples of tori (or elliptic curves) endowed with ")#link("https://en.wikipedia.org/wiki/Complex_multiplication")[#text("complex multiplication")]#text(". There are additional examples of elliptic curves endowed with conformal ")#emph[#text("endomorphisms")]#text(" that are still considered to have complex multiplication, and have a particularly nice algebraic number theory structure, but we will not pursue this topic further here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 20")]#text(" The fact that the action of ")#mi("{PSL_2({\\bf Z})}")#text(" on lattices contains fixed points is somewhat annoying, as it prevents one from immediately viewing the modular curve as a Riemann surface. However by passing to a suitable finite index subgroup of ")#mi("{PSL_2({\\bf Z})}")#text(", one can remove these fixed points, leading to a theory that is cleaner in some respects. For instance, one can work with the ")#link("https://en.wikipedia.org/wiki/Congruence_subgroup")[#text("congruence group")]#text(" ")#mi("{\\Gamma(2)}")#text(", which roughly speaking amounts to decorating the lattices ")#mi("{\\Lambda}")#text(" (or their tori ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(") with an additional “")#mi("{2}")#text("-marking” that eliminates the fixed points. This leads to a modification of the theory which is for instance well suited for studying theta functions; the role of the ")#mi("{j}")#text("-invariant in the discussion below is then played by the ")#link("https://en.wikipedia.org/wiki/Modular_lambda_function")[#text("modular lambda function")]#text(" ")#mi("{\\lambda}")#text(", which also gives a uniformisation of the twice-punctured complex plane ")#mi("{{\\bf C} \\backslash \\{0,1\\}}")#text(". However we will not develop this parallel theory further here.")
]

#text("If we let ")#mi("{{\\bf H}^{\\prime}}")#text(" be the elements ")#mi("{\\tau}")#text(" of ")#mi("{{\\bf H}}")#text(" not equivalent to ")#mi("{i}")#text(" or ")#mi("{e^{\\pi i/3}}")#text(", and ")#mi("{X_0(1)^{\\prime}}")#text(" the equivalence class of tori not equivalent to the Gaussian torus ")#mi("{({\\bf Z}+i{\\bf Z}) \\backslash {\\bf C}}")#text(" or the Eisenstein torus ")#mi("{{\\bf Z} + e^{\\pi i/3} {\\bf Z} \\backslash {\\bf C}}")#text(", then ")#mi("{X_0(1)^{\\prime}}")#text(" can be viewed as the quotient ")#mi("{PSL_2({\\bf Z}) \\backslash {\\bf H}^{\\prime}}")#text(" of the Riemann surface ")#mi("{{\\bf H}^{\\prime}}")#text(" by the free and proper action of ")#mi("{PSL_2({\\bf Z})}")#text(", so it has the structure of a Riemann surface; ")#mi("{X_0(1)}")#text(" can thus be thought of as the Riemann surface ")#mi("{X_0(1)^{\\prime}}")#text(" with two additional points added. Later on we will also add a third point ")#mi("{\\infty}")#text(" (known as the ")#emph[#text("cusp")]#text(") to the Riemann surface to compactify it to ")#mi("{X_0(1) \\cup \\{\\infty\\}}")#text(".")

#text("A function ")#mi("{f: X_0(1) \\rightarrow {\\bf C}}")#text(" on the modular curve ")#mi("{X_0(1)}")#text(" can be thought of, equivalently, as a function ")#mi("{f: {\\bf H} \\rightarrow {\\bf C}}")#text(" that is ")#mi("{SL_2({\\bf Z})}")#text("-invariant in the sense that ")#mi("{f(\\gamma \\cdot \\tau) = f(\\tau)}")#text(" for all ")#mi("{\\tau \\in {\\bf H}}")#text(" and ")#mi("{\\gamma \\in SL_2({\\bf Z})}")#text(", or equivalently that one has the identity ")#metadata(none) <tao-c2242e2c12190babaf9f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("f(\\frac{a\\tau+b}{c\\tau+d}) = f(\\tau)")]]

#text(" ")#text(" whenever ")#mi("{\\tau \\in {\\bf H}}")#text(" and ")#mi("{a,b,c,d}")#text(" are integers with ")#mi("{ad-bc = 1}")#text(". Similarly if ")#mi("{f}")#text(" takes values in the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" rather than ")#mi("{{\\bf C}}")#text(". If ")#mi("{f}")#text(" is holomorphic (resp. meromorphic) on ")#mi("{{\\bf H}}")#text(", this will in particular define a holomorphic (resp. meromorphic) function on ")#mi("{X_0(1)^{\\prime}}")#text(", and morally to all of ")#mi("{X_0(1)}")#text(" as well (although we have not yet defined a Riemann structure on all of ")#mi("{X_0(1)}")#text(").")

#text("We define a ")#link("https://en.wikipedia.org/wiki/Modular_form")[#text("modular function")]#text(" to be a meromorphic function ")#mi("{f}")#text(" on ")#mi("{{\\bf H}}")#text(" that obeys the condition ")#link(<tao-c2242e2c12190babaf9f>)[#text("(15)")]#text(", and which also has at most polynomial growth at the cusp ")#mi("{\\infty}")#text(" in the sense that one has a bound of the form ")#metadata(none) <tao-30d0b7c7be6f8f94b19e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left|f(\\tau)\\right| \\leq C e^{2\\pi m \\left|\\mathrm{Im}(\\tau)\\right|}", block: true)]]

#text(" ")#text(" for all ")#mi("{\\tau}")#text(" with sufficiently large imaginary part, and some constants ")#mi("{C,m}")#text(" (this bound is needed for technical reasons to ensure “meromorphic” behaviour at the cusp ")#mi("{\\infty}")#text(", as opposed to an essential singularity). Specialising to the matrices")

#metadata(none) <tao-0c1c541af9cc252a1c75>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} = \\begin{pmatrix} 1 & 1 \\\\ 0 & 1 \\end{pmatrix}, \\begin{pmatrix} 0 & -1 \\\\ 1 & 0 \\end{pmatrix}")]]

#text("we see that the condition ")#link(<tao-c2242e2c12190babaf9f>)[#text("(15)")]#text(" in particular implies the ")#mi("{1}")#text("-periodicity")

#metadata(none) <tao-511ea6aff5ad7ee4bde4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("f(\\tau+1) = f(\\tau)")]]

#text("and the inversion law")

#metadata(none) <tao-7705accd2694bdc7c292>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("f(-1/\\tau) = f(\\tau)")]]

#text("for all ")#mi("{\\tau \\in {\\bf H}}")#text(". Conversely, these two special cases of ")#link(<tao-c2242e2c12190babaf9f>)[#text("(15)")]#text(" imply the general case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]

#list(
[#text("(i) Let ")#mi("{(a,b), (c,d)}")#text(" be two elements of ")#mi("{{\\bf Z}^2}")#text(" with ")#mi("{ad-bc=1}")#text(". Show that it is possible to transform the quadruplet ")#mi("{((a,b),(c,d))}")#text(" to the quadruplet ")#mi("{((1,0),(0,1))}")#text(" after a finite number of applications of the moves")

#tao-aligned(keep: true)[


#tao-math("((a,b),(c,d))  & \\mapsto ((a+c,b+d), (c,d)),", block: true)



#tao-math("((a,b),(c,d))  & \\mapsto ((a-c,b-d), (c,d))", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("((a,b),(c,d)) \\mapsto ((-c,-d), (a,b)).")]]

#text("({")#emph[#text("Hint:")]#text(" use the principle of infinite descent, applying the moves in a suitable order to decrease the lengths of ")#mi("{(a,b)}")#text(" and ")#mi("{(c,d)}")#text(" when the dot product ")#mi("{ac+bd}")#text(" is not too small, taking advantage of the Lagrange identity ")#mi("{(a^2+b^2)(c^2+d^2) = (ac+bd)^2 + (ad-bc)^2}")#text(" to determine when this procedure terminates. It may help to think geometrically and draw plenty of pictures.) Conclude that the two matrices ")#link(<tao-0c1c541af9cc252a1c75>)[#text("(17)")]#text(" generate all of ")#mi("{SL_2({\\bf Z})}")#text(".")],
[#text("(ii) Show that a function ")#mi("{f: {\\bf H} \\rightarrow {\\bf C}}")#text(" obeys ")#link(<tao-c2242e2c12190babaf9f>)[#text("(15)")]#text(" if and only if it obeys both ")#link(<tao-511ea6aff5ad7ee4bde4>)[#text("(18)")]#text(" and ")#link(<tao-7705accd2694bdc7c292>)[#text("(19)")]#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22 (Standard fundamental domain)")]#text(" ")#metadata(none) <tao-cf4dc1825c66d842861d>#text(" Define the ")#emph[#text("standard fundamental domain")]#text(" ")#mi("{{\\mathcal F}}")#text(" for ")#mi("{X_0(1)}")#text(" to be the set")

#align(center)[#tao-fit-display[#tao-math("{\\mathcal F} := \\{ \\tau \\in {\\bf H}: \\left|\\tau\\right| \\geq 1; \\left|\\mathrm{Re} \\tau\\right| \\leq \\frac{1}{2} \\}.", block: true)]]

#list(
[#text("(i) Show that every lattice ")#mi("{\\Lambda}")#text(" is equivalent (up to dilations) to a lattice ")#mi("{{\\bf Z} + \\tau {\\bf Z}}")#text(" with ")#mi("{\\tau \\in {\\mathcal F}}")#text(", with ")#mi("{\\tau}")#text(" unique except when it lies on the boundary of ")#mi("{{\\mathcal F}}")#text(", in which case the lack of uniqueness comes either from the pair ")#mi("{\\tau = \\frac{1}{2}+it, -\\frac{1}{2} +it}")#text(" for some ")#mi("{t \\geq \\frac{\\sqrt{3}}{2}}")#text(", or from the pair ")#mi("{\\tau = e^{i\\theta}, e^{i(\\pi-\\theta)}}")#text(" for some ")#mi("{\\pi/3 < \\theta < \\pi/2}")#text(". (")#emph[#text("Hint:")]#text(" arrange ")#mi("{\\Lambda}")#text(" so that ")#mi("{1}")#text(" is a non-zero element of ")#mi("{\\Lambda}")#text(" of minimal magnitude.)")],
[#text("(ii) Show that ")#mi("{X_0(1)}")#text(" can be identified with the fundamental domain ")#mi("{{\\mathcal F}}")#text(" after identifying ")#mi("{\\frac{1}{2}+it}")#text(" with ")#mi("{-\\frac{1}{2}+it}")#text(" for ")#mi("{t \\geq \\frac{\\sqrt{3}}{2}}")#text(", and ")#mi("{e^{i\\theta}}")#text(" with ")#mi("{e^{i(\\pi-\\theta)}}")#text(" for ")#mi("{\\pi/3 < \\theta < \\pi/2}")#text(". Show also that the set ")#mi("{X_0(1)^{\\prime}}")#text(" is then formed the same way, but first deleting the points ")#mi("{i, e^{\\pi i/3}, e^{2\\pi i/3}}")#text(" from ")#mi("{{\\mathcal F}}")#text(".")]
)
]

#text("We will give some examples of modular functions (beyond the trivial example of constant functions) shortly, but let us first observe that when one differentiates a modular function one gets a more general class of function, known as a ")#link("https://en.wikipedia.org/wiki/Modular_form")[#text("modular form")]#text(". In more detail, observe from ")#link(<tao-88d4266fd4e6338d13b8>)[#text("(14)")]#text(" that the derivative of the Möbius transformation ")#mi("{\\tau \\mapsto \\frac{a\\tau+b}{c\\tau+d}}")#text(" is ")#mi("{\\frac{1}{(c\\tau+d)^2}}")#text(", and hence by the chain rule and ")#link(<tao-c2242e2c12190babaf9f>)[#text("(15)")]#text(" the derivative of a modular function ")#mi("{f}")#text(" would obey the variant law")

#align(center)[#tao-fit-display[#mitex("f^{\\prime}(\\frac{a\\tau+b}{c\\tau+d}) = (c\\tau+d)^2 f^{\\prime}(\\tau).")]]

#text("Motivated by this, we can define a (weakly) ")#emph[#text("modular form")]#text(" of weight ")#mi("{k}")#text(" for any natural number ")#mi("{k}")#text(" to be a meromorphic function ")#mi("{f: {\\bf H} \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" which obeys the modularity relation")

#metadata(none) <tao-68ee6963df5d14b4765f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("f(\\frac{a\\tau+b}{c\\tau+d}) = (c\\tau+d)^k f(\\tau)")]]

#text("for all ")#mi("{\\tau \\in {\\bf H}}")#text(" and all integers ")#mi("{a,b,c,d}")#text(" with ")#mi("{ad-bc=1}")#text(" (with the convention that ")#mi("{c \\infty = \\infty}")#text(" for any non-zero complex ")#mi("{c}")#text("), and which is meromorphic at the cusp ")#mi("{\\infty}")#text(" in the sense of ")#link(<tao-30d0b7c7be6f8f94b19e>)[#text("(16)")]#text(". Thus for instance modular functions are weakly modular forms of weight ")#mi("{0}")#text(". A ")#emph[#text("modular form")]#text(" of weight ")#mi("{k}")#text(" is a weakly modular form ")#mi("{f}")#text(" of weight ")#mi("{k}")#text(" which is holomorphic (not just meromorphic) on ")#mi("{{\\bf H}}")#text(", and also “holomorphic at ")#mi("{\\infty}")#text("” in the sense that ")#mi("{f(\\tau)}")#text(" is bounded for ")#mi("{\\mathrm{Im}(\\tau)}")#text(" large enough. Note that as viewed a function ")#mi("{f(\\tau) = \\tilde f(e^{2\\pi i \\tau}) = \\tilde f(q)}")#text(" of the nome ")#mi("{q = e^{2\\pi i \\tau}}")#text(", a modular form ")#mi("{f}")#text(" can be thought of as a certain type of holomorphic function ")#mi("{\\tilde f}")#text(" on the disk ")#mi("{D(0,1)}")#text(" (using the Riemann singularity removal theorem to remove the singularity at the origin ")#mi("{q=0}")#text("), while weakly modular forms (and in particular modular functions) are certain types of meromorphic functions on this disk. A modular form that vanishes at infinity is known as a ")#emph[#text("cusp form")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Let ")#mi("{k}")#text(" be a natural number. Show that a function ")#mi("{f: {\\bf H} \\rightarrow {\\bf C}}")#text(" obeys ")#link(<tao-68ee6963df5d14b4765f>)[#text("(20)")]#text(" if and only if it is ")#mi("{1}")#text("-periodic in the sense of ")#link(<tao-511ea6aff5ad7ee4bde4>)[#text("(18)")]#text(" and obeys the law")

#metadata(none) <tao-7ed131f5707162afad35>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("f(-1/\\tau) = \\tau^k f(\\tau)")]]

#text("for all ")#mi("{\\tau \\in {\\bf H}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24 (Lattice interpretation of modular forms)")]#text(" ")#metadata(none) <tao-473c3cba6f0b66454d76>#text(" Let ")#mi("{f}")#text(" be a modular form of weight ")#mi("{k}")#text(". Show that there is a unique function ")#mi("{F}")#text(" from lattices ")#mi("{\\Lambda}")#text(" to complex numbers such that")

#align(center)[#tao-fit-display[#mitex("f(\\tau) = F({\\bf Z} + \\tau {\\bf Z})")]]

#text("for all ")#mi("{\\tau \\in {\\bf H}}")#text(", and such that one has the homogeneity relation")

#align(center)[#tao-fit-display[#mitex("F(\\lambda \\cdot \\Lambda) = \\lambda^{-k} F(\\Lambda)")]]

#text("for any lattice ")#mi("{\\Lambda}")#text(" and non-zero complex number ")#mi("{\\lambda}")#text(".")
]

#text("Observe that the product of a modular form of weight ")#mi("{k}")#text(" and a modular form of weight ")#mi("{l}")#text(" is a modular form of weight ")#mi("{k+l}")#text(", and that the ratio of two modular forms of weight ")#mi("{k}")#text(" will be a modular function (if the denominator is not identically zero). Also, the space of modular forms of a given weight is a vector space, as is the space of modular functions. This suggests a way to generate non-trivial modular functions, by first locating some modular forms and then taking suitable rational combinations of these forms.")

#text("Somewhat analogously to how we used Lemma ")#link(<tao-60e77101e76950a9b183>)[#text("3")]#text(" to investigate the spaces ")#mi("{L(D)}")#text(" for divisors ")#mi("{D}")#text(" on a torus, we will investigate the space of modular forms via the following basic formula:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 25 (Valence formula)")]#text(" Let ")#mi("{f}")#text(" be a modular form of weight ")#mi("{k}")#text(", not identically zero. Then we have")

#metadata(none) <tao-ee407a4ccfbd73eb081e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\sum_\\rho \\mathrm{ord}_\\rho(f) + \\frac{1}{2} \\mathrm{ord}_i(f) + \\frac{1}{3} \\mathrm{ord}_{e^{\\pi i}/3}(f) + \\mathrm{ord}_\\infty(f) = \\frac{k}{12}")]]

#text("where ")#mi("{\\mathrm{ord}_\\rho}")#text(" is the order of vanishing of ")#mi("{f}")#text(" at ")#mi("{\\rho}")#text(", ")#mi("{\\mathrm{ord}_\\infty(f)}")#text(" is the order of vanishing of ")#mi("{\\tilde f(q) := f(\\tau)}")#text(" (i.e., ")#mi("{f}")#text(" viewed as a function of the nome ")#mi("{q = e^{2\\pi i \\tau}}")#text(") at ")#mi("{q=0}")#text(", and ")#mi("{\\rho}")#text(" ranges over the zeroes of ")#mi("{f}")#text(" that are not equivalent to ")#mi("{i, e^{\\pi i/3}, \\infty}")#text(", with just one zero counted per equivalence class. (This will be a finite sum.)")
]

#text("Informally, this formula asserts that the point ")#mi("{i}")#text(" only “deserves” to be counted in ")#mi("{X_0(1)}")#text(" with multiplicity ")#mi("{1/2}")#text(" due to its order ")#mi("{2}")#text(" stabiliser, while the point ")#mi("{e^{\\pi/3}}")#text(" only “deserves” to be counted in ")#mi("{X_0(1)}")#text(" with multiplicity ")#mi("{1/3}")#text(" due to its order ")#mi("{3}")#text(" stabiliser. (The cusp ")#mi("{\\infty}")#text(" has an infinite stabiliser, but this is compensated for by taking the order with respect to the nome variable ")#mi("{q}")#text(" rather than the period ratio variable ")#mi("{\\tau}")#text(".) The general philosophy of weighting points by the reciprocal of the order of their stabiliser occurs throughout mathematics; see ")#link("https://terrytao.wordpress.com/2017/04/13/counting-objects-up-to-isomorphism-groupoid-cardinality/")[#text("this blog post")]#text(" for more discussion.")

#emph[#text("Proof:")]#text(" Firstly, from Exercise ")#link(<tao-cf4dc1825c66d842861d>)[#text("22")]#text(", we can place all the zeroes ")#mi("{\\rho}")#text(" in the fundamental domain ")#mi("{{\\mathcal F}}")#text(". When parameterised in terms of the nome ")#mi("{q}")#text(", this domain is compact, hence has only finitely many zeros, so the sum in ")#link(<tao-ee407a4ccfbd73eb081e>)[#text("(22)")]#text(" is finite.")

#text("As in the proof of Lemma ")#link(<tao-60e77101e76950a9b183>)[#text("3")]#text("(ii), we use the residue theorem. For simplicity, let us first suppose that there are no zeroes on the boundary of the fundamental domain ")#mi("{{\\mathcal F}}")#text(" except possibly at the cusp ")#mi("{\\infty}")#text(". Then for ")#mi("{T}")#text(" large enough, we have from the residue theorem that")

#align(center)[#tao-fit-display[#mitex("\\sum_\\rho \\mathrm{ord}_\\rho(f) = \\frac{1}{2\\pi i} \\int_\\gamma \\frac{f^{\\prime}(z)}{f(z)}\\ dz,")]]

#text("where ")#mi("{\\gamma}")#text(" is the closed contour consisting of the polygonal path ")#mi("{\\gamma_{\\frac{1}{2}+\\frac{\\sqrt{3}i}{2} \\rightarrow \\frac{1}{2} + iT \\rightarrow -\\frac{1}{2}+iT \\rightarrow -\\frac{1}{2}+\\frac{\\sqrt{3}i}{2}}}")#text(" concatenated with the circular arc ")#mi("{\\{ e^{i(2\\pi/3 - \\theta)}: 0 \\leq \\theta \\leq \\pi/3 \\}}")#text(". From the ")#mi("{1}")#text("-periodicity, the contribution of the two vertical edges ")#mi("{\\gamma_{\\frac{1}{2}+\\frac{\\sqrt{3}i}{2} \\rightarrow \\frac{1}{2} + iT}}")#text(" and ")#mi("{\\gamma_{-\\frac{1}{2}+iT \\rightarrow -\\frac{1}{2}+\\frac{\\sqrt{3}i}{2}}}")#text(" cancel each other out. The contribution of the horizontal edge ")#mi("{\\gamma_{\\frac{1}{2}+iT \\rightarrow -\\frac{1}{2}+iT}}")#text(" can be written using the change of variables ")#mi("{q = e^{2\\pi i \\tau}}")#text(" as")

#align(center)[#tao-fit-display[#mitex("-\\frac{1}{2\\pi i} \\int_{\\gamma_{0,e^{-2\\pi T},\\circlearrowleft}} \\frac{\\tilde f^{\\prime}(q)}{\\tilde f(q)}\\ dq")]]

#text("which by the residue theorem is equal to ")#mi("{-\\mathrm{ord}_\\infty(f)}")#text(". Finally, using the modularity ")#link(<tao-7ed131f5707162afad35>)[#text("(21)")]#text(", one calculates that the contribution of the left arc ")#mi("{\\{ e^{i(2\\pi/3 - \\theta)}: 0 \\leq \\theta \\leq \\pi/6 \\}}")#text(" is equal to ")#mi("{k/12}")#text(" minus the contribution of the right arc ")#mi("{\\{ e^{i(2\\pi/3 - \\theta)}: \\pi/6 \\leq \\theta \\leq \\pi/3 \\}}")#text(". This gives the proof of the valence theorem in the case that there are no zeroes on the boundary of ")#mi("{{\\mathcal F}}")#text(".")

#text("Suppose now that there is a zero on the right edge ")#mi("{\\frac{1}{2}+it}")#text(" of ")#mi("{{\\mathcal F}}")#text(", and hence also on the left edge ")#mi("{-\\frac{1}{2}+it}")#text(" by periodicity, for some ")#mi("{t > \\frac{\\sqrt{3}}{2}}")#text(". One can account for this zero by perturbing the contour ")#mi("{\\gamma}")#text(" to make a little detour to the right of ")#mi("{\\frac{1}{2}+it}")#text(" (e.g., by a circular arc), and a matching detour to the right of ")#mi("{-\\frac{1}{2}+it}")#text(". One can then verify that the same argument as before continues to work, with this boundary zero being counted exactly once. Similarly, if there is a zero on the left arc ")#mi("{e^{i\\theta}}")#text(" for some ")#mi("{\\pi/2 < \\theta < 2\\pi/3}")#text(", and hence also at ")#mi("{e^{i(\\pi-\\theta)}}")#text(" by modularity, one can make a detour slightly above ")#mi("{e^{i\\theta}}")#text(" and slightly below ")#mi("{e^{i(\\pi-\\theta)}}")#text(" (with the two detours being related by the transform ")#mi("{\\tau \\mapsto -1/\\tau}")#text(" to ensure cancellation), and again we can argue as before. If instead there is a zero at ")#mi("{i}")#text(", one makes an (approximately) semicircular detour above ")#mi("{i}")#text("; in this case the detour does not cancel out, but instead contributes a factor of ")#mi("{\\frac{1}{2} \\mathrm{ord}_i(f)}")#text(" in the limit as the radius of the detour goes to zero. Finally, if there is a zero at ")#mi("{e^{i\\pi/3}}")#text(" (and hence also at ")#mi("{e^{2\\pi i/3}}")#text("), one makes detours by two arcs of angle approximately ")#mi("{\\pi/3}")#text(" at these two points; these two (approximate) sixth-circles end up contributing a factor of ")#mi("{\\frac{1}{2} \\mathrm{ord}_{e^{\\pi i/3}}(f)}")#text(" in the limit, giving the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26 (Quick applications of the valence formula)")]#text(" ")#metadata(none) <tao-17b7e72d51f2291a7f9f>

#list(
[#text("(i) Let ")#mi("{f}")#text(" be a modular form of weight ")#mi("{k}")#text(", not identically zero. Show that ")#mi("{k}")#text(" is equal to ")#mi("{0}")#text(" or an even number that is at least ")#mi("{4}")#text(".")],
[#text("(ii) (Liouville theorem for ")#mi("{X_0(1)}")#text(") If ")#mi("{f}")#text(" is a modular form of weight zero, show that it is constant. (Hint: apply the valence theorem to various shifts ")#mi("{f-c}")#text(" of ")#mi("{f}")#text(" by constant.)")],
[#text("(iii) For ")#mi("{k=4,6,8,10,14}")#text(", show that the vector space of modular forms of weight ")#mi("{k}")#text(" is at most one dimensional. (Hint: in these cases, there are a very limited number of solutions to the equation ")#mi("{a + \\frac{1}{2} b + \\frac{1}{3} c = \\frac{k}{12}}")#text(" with ")#mi("{a,b,c}")#text(" natural numbers.)")],
[#text("(iv) Show that there are no cusp forms of weight ")#mi("{k}")#text(" when ")#mi("{k < 12}")#text(" or ")#mi("{k=14}")#text(", and for ")#mi("{k=12}")#text(" the space of cusp forms of weight ")#mi("{k}")#text(" is at most one dimensional.")],
[#text("(v) Show that for any ")#mi("{k}")#text(", the space of cusp forms of weight ")#mi("{k}")#text(" is a subspace of the space of modular forms of weight ")#mi("{k}")#text(" of codimension at most one, and that both spaces are finite-dimensional.")]
)
]

#text("A basic example of modular forms are provided by the Eisenstein series ")#metadata(none) <tao-2e6e6d21193caf16fad9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("G_k( \\Lambda ) := \\sum_{z \\in \\Lambda \\backslash \\{0\\}} \\frac{1}{z^{k}}")]]

#text(" ")#text(" that we have already encountered for even integers ")#mi("{k = 4,6,8,\\dots}")#text(" greater than two (we ignore the odd Eisenstein series as they vanish). We can view this as a function on ")#mi("{{\\bf H}}")#text(" by the formula")

#metadata(none) <tao-6d0f624fe0d1b241c0d5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("G_k( \\tau) := G_k( {\\bf Z} + \\tau {\\bf Z} ).")]]

#text("Observe that if ")#mi("{a,b,c,d}")#text(" are integers with ")#mi("{ad-bc = 1}")#text(", then")

#align(center)[#tao-fit-display[#mitex("{\\bf Z} + \\frac{a\\tau+b}{c\\tau+d} {\\bf Z} = \\frac{1}{c\\tau+d} ( (c\\tau+d) {\\bf Z} + (a\\tau+b) {\\bf Z} ) = \\frac{1}{(c\\tau+d)} ({\\bf Z} + \\tau {\\bf Z})")]]

#text("using the matrix inverse in ")#mi("{SL_2({\\bf Z})}")#text(". Inserting this into ")#link(<tao-2e6e6d21193caf16fad9>)[#text("(23)")]#text(", ")#link(<tao-6d0f624fe0d1b241c0d5>)[#text("(24)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("G_k( \\frac{a\\tau+b}{c\\tau+d} ) = (c\\tau+d)^k G_k(\\tau).")]]

#text("(Compare also with Exercise ")#link(<tao-473c3cba6f0b66454d76>)[#text("24")]#text(".) Also, from ")#link(<tao-2e6e6d21193caf16fad9>)[#text("(23)")]#text(", ")#link(<tao-6d0f624fe0d1b241c0d5>)[#text("(24)")]#text(" we have")

#metadata(none) <tao-e7184388c404166a3e7d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("G_k(\\tau) = \\sum_{(n,m) \\in {\\bf Z}^2 \\backslash \\{(0,0)\\}} \\frac{1}{(n+m\\tau)^{k}}.")]]

#text("The series here is locally uniformly convergent for ")#mi("{\\tau \\in {\\bf H}}")#text(", so ")#mi("{G_k}")#text(" is holomorphic. Also, using the bounds")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\in {\\bf Z}} \\frac{1}{\\left|n+m\\tau\\right|^k}  & \\lesssim \\sum_{n \\in {\\bf Z}} \\min( \\frac{1}{\\left|n + m \\mathrm{Re} \\tau\\right|^k}, \\frac{1}{\\left|m \\mathrm{Im} \\tau\\right|^k} )", block: true)



#tao-math(" & \\lesssim \\int_{\\bf R} \\min( \\frac{1}{t^k}, \\frac{1}{\\left|m \\mathrm{Im} \\tau\\right|^k} )\\ dt", block: true)



#tao-math(" & \\lesssim \\frac{1}{\\left|m \\mathrm{Im} \\tau\\right|^{k-1}}", block: true)
]

#text("for non-zero ")#mi("{m}")#text(", while")

#metadata(none) <tao-e140a56a0a7415daebcc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\sum_{n \\in {\\bf Z} \\backslash 0} \\frac{1}{n^k} = 2 \\zeta(k)")]]

#text("where ")#mi("{\\zeta(k)}")#text(" is the famous ")#link("https://en.wikipedia.org/wiki/Riemann%27s_zeta_function")[#text("Riemann zeta function")]

#align(center)[#tao-fit-display[#mitex("\\zeta(k) := \\sum_{n=1}^\\infty \\frac{1}{n^k},")]]

#text("we conclude on summing in ")#mi("{m}")#text(" and using the hypothesis ")#mi("{k>2}")#text(" that")

#align(center)[#tao-fit-display[#tao-math("G_k(\\tau) = 2 \\zeta(k) + O_k( \\frac{1}{\\left|\\mathrm{Im}(\\tau)\\right|^{k-1}}).", block: true)]]

#text("In particular, ")#mi("{G_k}")#text(" is bounded at infinity. Summarising, we have established that the Eisenstein series ")#mi("{G_k}")#text(" is a modular form of weight ")#mi("{k}")#text(", which is not identically zero (since it approaches the non-zero value ")#mi("{2 \\zeta(k)}")#text(" at the cusp ")#mi("{\\infty}")#text("). Combining this with Exercise ")#link(<tao-17b7e72d51f2291a7f9f>)[#text("26")]#text("(iii), we see that we have completely classified the modular forms of weight ")#mi("{k}")#text(" for ")#mi("{k=4,6,8,10,14}")#text(", namely they are the scalar multiples of ")#mi("{G_k}")#text(". For instance, the coefficients")

#align(center)[#tao-fit-display[#mitex("g_2(\\tau) = 60 G_4(\\tau)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("g_3(\\tau) = 140 G_6(\\tau)")]]

#text("appearing in the previous section are modular forms of weight ")#mi("{4}")#text(" and weight ")#mi("{6}")#text(" respectively, and the modular discriminant")

#align(center)[#tao-fit-display[#mitex("\\Delta(\\tau) = g_2^3(\\tau) - 27 g_3^2(\\tau)")]]

#text("from Exercise ")#link(<tao-a4a3a4d7d4292cb4bcc8>)[#text("10")]#text(" is a modular form of weight ")#mi("{12}")#text(". From that exercise, this modular form never vanishes on ")#mi("{{\\bf H}}")#text(", hence by the valence formula it must have a simple zero at ")#mi("{\\infty}")#text(", and in particular is a cusp form. From Exercise ")#link(<tao-17b7e72d51f2291a7f9f>)[#text("26")]#text(" it is the unique cusp form of weight ")#mi("{12}")#text(", up to constants.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" Give an alternate proof that ")#mi("{\\Delta}")#text(" is a cusp form, not using the valence identity, by first establishing that ")#mi("{\\zeta(4) = \\frac{\\pi^4}{90}}")#text(" and ")#mi("{\\zeta(6) = \\frac{\\pi^6}{945}}")#text(".")
]

#text("We can now create our first non-trivial modular function, the ")#link("https://en.wikipedia.org/wiki/J-invariant")[#mi("{j}")#text("-invariant")]

#align(center)[#tao-fit-display[#mitex("j(\\tau) := 1728 \\frac{g_2(\\tau)^3}{\\Delta(\\tau)}.")]]

#text("The factor of ")#mi("{1728}")#text(" is traditional, as it gives a nice normalisation at ")#mi("{\\infty}")#text(", as we shall see later. One can take advantage of complex multiplication to compute two special values immediately:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 28")]#text(" ")#metadata(none) <tao-b6ff3b277328011539a2>#text(" We have ")#mi("{j(i) = 1728}")#text(" and ")#mi("{j(e^{\\pi i/3})=0}")#text(".")
]

#emph[#text("Proof:")]#text(" Using the rotation symmetry ")#mi("{z \\mapsto iz}")#text(" we see that ")#mi("{G_6(i) = 0}")#text(", hence ")#mi("{g_3(i)=0}")#text(" which implies that ")#mi("{\\Delta(i)=g_2(i)^3}")#text(" and hence ")#mi("{j(i)=1728}")#text(". Similarly, using the rotation symmetry ")#mi("{z \\mapsto e^{\\pi i/3} z}")#text(" we have ")#mi("{G_4(e^{\\pi i/3}) = 0}")#text(", hence ")#mi("{j(e^{\\pi i/3}=0)}")#text(". (One can also use the valence formulae to get the vanishing ")#mi("{G_6(i)=G_4(e^{\\pi i/3})=0}")#text("). ")#mi("\\Box")

#text("Being modular, we can think of ")#mi("{j}")#text(" as a map from ")#mi("{X_0(1)}")#text(" to ")#mi("{{\\bf C}}")#text(". We have the following fundamental fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 29")]#text(" The map ")#mi("{j: X_0(1) \\rightarrow {\\bf C}}")#text(" is a bijection.")
]

#emph[#text("Proof:")]#text(" Note that for any ")#mi("{\\lambda \\in {\\bf C}}")#text(", ")#mi("{j(\\tau) = 1728 \\lambda}")#text(" if and only if ")#mi("{\\tau}")#text(" is a zero of ")#mi("{g_2^3 - \\lambda \\Delta}")#text(". It thus suffices to show that for every ")#mi("{\\lambda \\in {\\bf C}}")#text(", the zeroes of the function ")#mi("{g_2^3 - \\lambda \\Delta}")#text(" in ")#mi("{{\\bf H}}")#text(" consist of precisely one orbit of ")#mi("{SL_2({\\bf Z})}")#text(". This function is a modular form of weight ")#mi("{12}")#text(" that does not vanish at infinity (since ")#mi("{g_2}")#text(" does not vanish while ")#mi("{\\Delta}")#text(" does). By the valence formula, we thus have")

#align(center)[#tao-fit-display[#mitex("\\sum_\\rho \\mathrm{ord}_\\rho( g_2^3 - \\lambda \\Delta ) + \\frac{1}{2} \\mathrm{ord}_1( g_2^3 - \\lambda \\Delta ) + \\frac{1}{3} \\mathrm{ord}_{e^{\\pi i/3}}( g_2^3 - \\lambda \\Delta ) = 1.")]]

#text("As the orders are all natural numbers, some case checking reveals that there are now only three possibilities:")

#list(
[#mi("{g_2^3 - \\lambda \\Delta}")#text(" has a simple zero at precisely one ")#mi("{SL_2({\\bf Z})}")#text("-orbit, not equivalent to ")#mi("{1}")#text(" or ")#mi("{e^{\\pi i/3}}")#text(".")],
[#mi("{g_2^3 - \\lambda \\Delta}")#text(" has a double zero at ")#mi("{i}")#text(" (and equivalent points), and no other zeroes.")],
[#mi("{g_2^3 - \\lambda \\Delta}")#text(" has a triple zero at ")#mi("{e^{\\pi i/3}}")#text(" (and equivalent points), and no other zeroes.")]
)

#text("In any of these three cases, the claim follows. ")#mi("\\Box")

#text("Note that this proof also shows that ")#mi("{j(\\tau)-1728}")#text(" has a double zero at ")#mi("{i}")#text(" and ")#mi("{j(\\tau)}")#text(" has a triple zero at ")#mi("{e^{\\pi i/3}}")#text(", but that ")#mi("{j(\\tau)-j(\\tau_0)}")#text(" has a simple zero for any ")#mi("{\\tau_0 \\in {\\bf H}}")#text(" not equivalent to ")#mi("{i}")#text(" or ")#mi("{e^{\\pi i/3}}")#text(".")

#text("We can now give the entire modular curve ")#mi("{X_0(1)}")#text(" the structure of a Riemann surface by declaring ")#mi("{j}")#text(" to be the coordinate function. This is compatible with the existing Riemann surface structure on ")#mi("{X_0(1)^{\\prime}}")#text(" since ")#mi("{j}")#text(" was already holomorphic on this portion of the curve. Any modular function ")#mi("{f}")#text(" can then factor as ")#mi("{f(\\tau) = F(j(\\tau))}")#text(" for some meromorphic function ")#mi("{F}")#text(" that is initially defined on the punctured complex plane ")#mi("{{\\bf C} \\backslash \\{ 0, 1728 \\}}")#text("; but from meromorphicity of ")#mi("{f}")#text(" on ")#mi("{{\\bf H}}")#text(" and at infinity we see that ")#mi("{F}")#text(" blows up at an at most polynomial rate as one approaches ")#mi("{0}")#text(", ")#mi("{1728}")#text(", or ")#mi("{\\infty}")#text(", and so ")#mi("{F}")#text(" is in fact a meromorphic function on the entire Riemann sphere and is thus a rational function (Exercise 19 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("246A Notes 4")]#text("). We conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 30")]#text(" Every modular function is a rational function of the ")#mi("{j}")#text("-invariant ")#mi("{j}")#text(".")
]

#text("Conversely, it is clear that every rational function of ")#mi("{j}")#text(" is modular, thus giving a satisfactory description of the modular functions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" Show that every modular function is the ratio of two modular forms of equal weight (with the denominator not identically zero).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32 (All elliptic curves are tori)")]#text(" Let ")#mi("{A, B}")#text(" be two complex numbers with ")#mi("{A^3 - 27B^3 \\neq 0}")#text(". Show that there is a lattice ")#mi("{\\Lambda}")#text(" such that ")#mi("{g_2(\\Lambda) = A}")#text(" and ")#mi("{g_3(\\Lambda) = B}")#text(", so in particular the elliptic curve")

#align(center)[#tao-fit-display[#mitex("\\{ (z,w): w^2 = 4 z^3 - A z - B \\} \\cup \\{\\infty\\}")]]

#text("is complex diffeomorphic to a torus ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 33")]#text(" By applying some elementary algebraic geometry transformations one can show that any (smooth, irreducible) cubic plane curve ")#mi("{\\{ (z,w): P(z,w) = 0 \\}}")#text(" generated by a polynomial ")#mi("{P: {\\bf C} \\times {\\bf C} \\rightarrow {\\bf C}}")#text(" of degree ")#mi("{3}")#text(" is a Riemann surface complex diffeomorphic to a torus ")#mi("{\\Lambda \\backslash {\\bf C}}")#text(" after adding some finite number of points at infinity; also, some degree ")#mi("{4}")#text(" curves such as")

#align(center)[#tao-fit-display[#mitex("\\{ (z,w): w^2 = (z-a)(z-b)(z-c)(z-d) \\} \\cup \\{\\infty\\}")]]

#text("can also be placed in this form. However we will not detail the required transformations here.")
]

#text("A famous application of the theory of the ")#mi("{j}")#text("-invariant is to give a short Riemann surface-based proof of the the ")#link("https://en.wikipedia.org/wiki/Picard_theorem")[#text("little Picard theorem")]#text(" (first proven in Theorem 55 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("246A Notes 4")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 34 (Little Picard theorem)")]#text(" Let ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" be entire and non-constant. Then ")#mi("{f({\\bf C})}")#text(" omits at most one point of ")#mi("{{\\bf C}}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that ")#mi("{f({\\bf C})}")#text(" omits at least two points of ")#mi("{{\\bf C}}")#text(". By applying a linear transformation, we may assume that ")#mi("{f}")#text(" omits the points ")#mi("{0}")#text(" and ")#mi("{1728}")#text(". Then ")#mi("{j^{-1} \\circ f}")#text(" is a holomorphic function from ")#mi("{{\\bf C}}")#text(" to ")#mi("{X_0(1)^{\\prime} = PSL_2({\\bf Z}) \\backslash {\\bf H}^{\\prime}}")#text(". Since the domain ")#mi("{{\\bf C}}")#text(" is simply connected, ")#mi("{j^{-1} \\circ f}")#text(" lifts to a holomorphic function from ")#mi("{{\\bf C}}")#text(" to ")#mi("{{\\bf H}}")#text(". Since ")#mi("{{\\bf H}}")#text(" is complex diffeomorphic to a disk, this lift must be constant by Liouville’s theorem, hence ")#mi("{f}")#text(" is constant as required. (This is essentially Picard’s original proof of this theorem.) ")#mi("\\Box")

#text("The great Picard theorem can also be proven by a more sophisticated version of these methods, but it requires some study of the possible behavior of elements of ")#mi("{SL_2({\\bf Z})}")#text("; see Exercise ")#link(<tao-45160e98d943fc20d258>)[#text("37")]#text(" below.")

#text("All modular forms are ")#mi("{1}")#text("-periodic, and hence by Proposition ")#link(<tao-cf7341eb8ec10c18cb33>)[#text("1")]#text(" should have a Fourier expansion, which is also a Laurent expansion in the nome. As it turns out, the Fourier coefficients often have a highly number-theoretic interpretation. This can be illustrated with the Eisenstein series ")#mi("{G_k}")#text("; here we follow the treatment in Stein-Shakarchi. To compute the Fourier coefficients we first need a computation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35")]#text(" Let ")#mi("{k \\geq 2}")#text(" and ")#mi("{\\tau \\in {\\bf H}}")#text(", and let ")#mi("{q := e^{2\\pi i \\tau}}")#text(" be the nome. Establish the identity")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}} \\frac{1}{(n+\\tau)^k} = \\frac{(-2\\pi i)^k}{(k-1)!} \\sum_{\\ell=1}^\\infty \\ell^{k-1} q^\\ell")]]

#text("in two different ways:")

#list(
[#text("(i) By applying the Poisson summation formula (Proposition 3(v) of ")#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/")[#text("Notes 2")]#text(").")],
[#text("(ii) By first establishing the identity")

#metadata(none) <tao-e77c4b3f81059b97c4d2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\sum_{n \\in {\\bf Z}} \\frac{1}{(n+\\tau)^2} = \\frac{\\pi^2}{\\sin^2(\\pi \\tau)}")]]

#text("by applying Proposition ")#link(<tao-cf7341eb8ec10c18cb33>)[#text("1")]#text(" to the difference of the two sides, and differentiating in ")#mi("{\\tau}")#text(". (You may also establish ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(27)")]#text(" by other means, such as differentiating and then manipulating the identities in Exercises 25 or 27 of ")#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")[#text("Notes 1")]#text(".)")]
)
]

#text("From ")#link(<tao-e7184388c404166a3e7d>)[#text("(25)")]#text(", ")#link(<tao-e140a56a0a7415daebcc>)[#text("(26)")]#text(" (and symmetry) one has")

#align(center)[#tao-fit-display[#mitex("G_k(\\tau) = 2 \\zeta(k) + 2 \\sum_{m=1}^\\infty \\sum_{n \\in {\\bf Z}} \\frac{1}{(n+m\\tau)^k}")]]

#text("and hence by the above exercise")

#align(center)[#tao-fit-display[#mitex("G_k(\\tau) = 2 \\zeta(k) + 2 \\frac{(-2\\pi i)^k}{(k-1)!} \\sum_{m=1}^\\infty \\sum_{\\ell=1}^\\infty \\ell^{k-1} q^{m\\ell}.")]]

#text("Since ")#tao-math("{\\left|q\\right|<1}", block: false)#text(" it is not difficult to show that the double sum here is absolutey convergent and can be rearranged as we please. If we group the terms based on the product ")#mi("{r=m\\ell}")#text(" we thus have the Fourier expansion")

#align(center)[#tao-fit-display[#mitex("G_k(\\tau) = 2 \\zeta(k) + 2 \\frac{(-2\\pi i)^k}{(k-1)!} \\sum_{r=1}^\\infty \\sigma_{k-1}(r) q^r")]]

#text("where the ")#mi("{(k-1)^{th}}")#text(" ")#link("https://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]#text(" ")#mi("{\\sigma_{k-1}(r)}")#text(" is defined by")

#align(center)[#tao-fit-display[#mitex("\\sigma_{k-1}(r) := \\sum_{\\ell|r} \\ell^{k-1}")]]

#text("where the sum is over those natural numbers ")#mi("{\\ell}")#text(" that divide ")#mi("{r}")#text(". Thus for instance")

#tao-aligned(keep: true)[


#tao-math("G_4(\\tau)  & = 2 \\zeta(4) + \\frac{2(2\\pi)^4}{3!} \\sum_{r=1}^\\infty \\sigma_3(r) q^r", block: true)



#tao-math(" & = \\frac{\\pi^4}{45} ( 1 + 240 \\sum_{r=1}^\\infty \\sigma_3(r) q^r )", block: true)



#tao-math(" & = \\frac{\\pi^4}{45} ( 1 + 240 q + \\dots )", block: true)
]

#text("and")

#tao-aligned(keep: true)[


#tao-math("G_6(\\tau)  & = 2 \\zeta(6) - \\frac{2(2\\pi)^6}{5!} \\sum_{r=1}^\\infty \\sigma_5(r) q^r", block: true)



#tao-math(" & = \\frac{2\\pi^6}{945} ( 1 - 504 \\sum_{r=1}^\\infty \\sigma_5(r) q^r )", block: true)



#tao-math(" & = \\frac{2\\pi^6}{945} ( 1 - 504 q - \\dots )", block: true)
]

#text("so after some calculation")

#tao-aligned(keep: true)[


#tao-math("g_2(\\tau)  & = \\frac{4 \\pi^4}{3} (1 + 240 q + \\dots )", block: true)



#tao-math("g_3(\\tau)  & = \\frac{8 \\pi^6}{27} (1 - 504 q - \\dots)", block: true)



#tao-math("\\Delta(\\tau)  & = (2\\pi)^{12} (q - \\dots)", block: true)
]

#text("and therefore")

#metadata(none) <tao-b97c07162e854a668a28>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("j(\\tau) = q^{-1} + \\dots,")]]

#text("thus the factor of ")#mi("{1728}")#text(" in the definition of the ")#mi("{j}")#text("-invariant normalises the “residue” of ")#mi("{j}")#text(" at infinity to equal ")#mi("{1}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 36")]#text(" If one expands out a few more terms in the above expansions, one can calculate")

#metadata(none) <tao-1df75193aca9eae7402d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("j(z) = q^{-1} + 744 + 196884 q + 21493760 q^2 + \\dots.")]]

#text("The various coefficients in here have several remarkable algebraic properties. For instance, applying this expansion at ")#mi("{\\tau = (1 + \\sqrt{-d})/2}")#text(" for a natural number ")#mi("{d}")#text(", so that ")#mi("{q = -e^{-\\pi \\sqrt{d}}}")#text(", one obtains the approximation")

#align(center)[#tao-fit-display[#mitex("j( (1 + \\sqrt{-d})/2 ) = - e^{\\pi \\sqrt{d}} + 744 + O( e^{-\\pi \\sqrt{d}} ).")]]

#text("Now for certain values of ")#mi("{d}")#text(", most famously ")#mi("{d = 163}")#text(", the torus ")#mi("{({\\bf Z} + (1 + \\sqrt{-d})/2 {\\bf Z}) \\backslash {\\bf C}}")#text(" admits a complex multiplication that allows for computation of the ")#mi("{j}")#text("-invariant by algebraic means (think of this as a more advanced version of Lemma ")#link(<tao-b6ff3b277328011539a2>)[#text("28")]#text("; it is closely related to the fact that the ring of algebraic integers in ")#mi("{{\\bf Q}(\\sqrt{-163})}")#text(" admit unique factorisation, see ")#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/")[#text("these previous notes")]#text(" for some related discussion). For instance, one can eventually establish that")

#align(center)[#tao-fit-display[#mitex("j( (1 + \\sqrt{-163})/2 ) = (-640320)^3")]]

#text("which eventually leads to the famous approximation")

#align(center)[#tao-fit-display[#mitex("e^{\\pi \\sqrt{163}} \\approx 640320^3 + 744")]]

#text("(first observed by Hermite, but also attributed to Ramanujan via an April Fools’ joke of Martin Gardner) which is accurate to twelve decimal places. The remaining coefficients have a remarkable interpretation as dimensions of components of a certain representation of the ")#link("https://en.wikipedia.org/wiki/Monster_group")[#text("monster group")]#text(" known as the ")#link("https://en.wikipedia.org/wiki/Moonshine_module")[#text("moonshine module")]#text(", a phenomenon known as ")#link("https://en.wikipedia.org/wiki/Monstrous_moonshine")[#text("monstrous moonshine")]#text(". For instance, the smallest irreducible representation of the monster group has dimension ")#mi("{196883}")#text(", precisely one less than the ")#mi("{q}")#text(" coefficient of ")#mi("{j}")#text(". The Fourier coefficients ")#mi("{\\tau(n)}")#text(" of the (normalised) modular discriminant,")

#align(center)[#tao-fit-display[#mitex("\\Delta(\\tau) = (2\\pi)^{12} \\sum_{n=1}^\\infty \\tau(n) q^n = (2\\pi)^{12} (q - 24 q^2 + 252 q^3 + \\dots)")]]

#text("form a sequence known as the ")#link("https://en.wikipedia.org/wiki/Ramanujan_tau_function")[#text("Ramanujan ")#mi("{\\tau}")#text(" function")]#text(" and obeys many remarkable properties. For instance, there is the totally non-obvious fact that this function is multiplicative in the sense that ")#mi("{\\tau(nm) = \\tau(n) \\tau(m)}")#text(" whenever ")#mi("{n,m}")#text(" are coprime; see Exercise ")#link(<tao-6790fe8ad5532ce91297>)[#text("43")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37 (Great Picard theorem)")]#text(" ")#metadata(none) <tao-45160e98d943fc20d258>

#list(
[#text("(i) Show that every fractional linear transformation ")#mi("{\\gamma: z \\mapsto \\frac{az+b}{cz+d}}")#text(" on ")#mi("{{\\bf H}}")#text(" with ")#mi("{a,b,c,d \\in {\\bf Z}}")#text(", ")#mi("{ad-bc=1}")#text(" is either of finite order (elliptic case), conjugate to a translation ")#mi("{z \\mapsto z+h}")#text(" for some ")#mi("{h > 0}")#text(" after conjugating by another fractional linear transformation (parabolic case), or conjugate to a dilation ")#mi("{z \\mapsto \\lambda z}")#text(" for some ")#mi("{\\lambda >1}")#text(" after conjugating by another fractional linear transformation (hyperbolic case). (")#emph[#text("Hint:")]#text(" study the eigenvalues and eigenvectors of ")#mi("{\\begin{pmatrix} a & b \\\\ c& d\\end{pmatrix}}")#text(", based on the value of the trace ")#mi("{a+d}")#text(" and in particular whether the magnitude of the trace is less than two, equal to two, or greater than two. Note that the trace also has to be an integer.)")],
[#text("(ii) Let ")#mi("{f: D(0,1) \\backslash \\{0\\} \\rightarrow {\\bf C} \\backslash \\{0,1728\\}}")#text(" be holomorphic. Show that there exists a holomorphic function ")#mi("{F: {\\bf H} \\rightarrow {\\bf H}}")#text(" such that ")#mi("{j(F(z)) = f(e^{2\\pi i z})}")#text(" for all ")#mi("{z \\in {\\bf H}}")#text(", as well as a fractional linear transformation ")#mi("{\\gamma:\\frac{az+b}{cz+d}}")#text(" with ")#mi("{a,b,c,d \\in {\\bf Z}}")#text(" and ")#mi("{ad-bc=1}")#text(" such that ")#mi("{F(z+1) = \\gamma(F(z))}")#text(" for all ")#mi("{z \\in {\\bf H}}")#text(".")],
[#text("(iii) If the transformation ")#mi("{\\gamma}")#text(" in (ii) is in the elliptic case of (i), show that ")#mi("{f}")#text(" is bounded in a neighbourhood of ")#mi("{0}")#text(", and hence has a removable singularity at the origin. (")#emph[#text("Hint:")]#text(" ")#mi("{F}")#text(" will have some finite period and can thus be studied using Proposition ")#link(<tao-cf7341eb8ec10c18cb33>)[#text("1")]#text(" after applying a Möbius transform to map ")#mi("{{\\bf H}}")#text(" to a disk.)")],
[#text("(iv) If the transformation ")#mi("{\\gamma}")#text(" in (ii) is in the hyperbolic case of (i), show that ")#mi("{f}")#text(" is bounded in a neighbourhood of ")#mi("{0}")#text(", and hence has a removable singularity at the origin. (")#emph[#text("Hint:")]#text(" The standard branch of ")#mi("{z \\mapsto z^{2\\pi i / \\log\\lambda}}")#text(" maps ")#mi("{{\\bf H}}")#text(" to an annulus, and is invariant with respect to the dilation action ")#mi("{z \\mapsto \\lambda z}")#text(". Use this to create a bounded ")#mi("{1}")#text("-periodic holomorphic function on ")#mi("{{\\bf H}}")#text(".)")],
[#text("(v) If the transformation ")#mi("{\\gamma}")#text(" in (ii) is in the parabolic case of (i), show that ")#mi("{f}")#text(" exhibits at most polynomial growth as one approaches ")#mi("{0}")#text(", and hence has at most a pole at the origin. (")#emph[#text("Hint:")]#text(" If for instance ")#mi("{F(z+1)=F(z)+h}")#text(", then ")#mi("{F(z)-h z}")#text(" is ")#mi("{1}")#text("-periodic and takes values in ")#mi("{{\\bf H}}")#text(", and one can now repeat the arguments of (iii). Also use the expansion ")#link(<tao-b97c07162e854a668a28>)[#text("(28)")]#text(".)")],
[#text("(vi) Use the previous parts of this exercise to give another proof of the ")#link("https://en.wikipedia.org/wiki/Picard_theorem")[#text("great Picard theorem")]#text(" (")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("Theorem 56 of 245A Notes 4")]#text("): the image of a holomorphic function in a punctured disk ")#mi("{D(z_0,r) \\backslash \\{z_0\\}}")#text(" with an essential singularity at ")#mi("{z_0}")#text(" omits at most one value of ")#mi("{{\\bf C}}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38 (Dimension of space of modular forms)")]

#list(
[#text("(i) If ")#mi("{k}")#text(" is an even natural number, show that the dimension of the space of modular forms of weight ")#mi("{k}")#text(" is equal to ")#mi("{\\lfloor k/12\\rfloor+1}")#text(" except when ")#mi("{k}")#text(" is equal to ")#mi("{2}")#text(" mod ")#mi("{12}")#text(", in which case it is equal to ")#mi("{\\lfloor k/12\\rfloor}")#text(". (")#emph[#text("Hint:")]#text(" for ")#mi("{k \\leq 12}")#text(" this follows from Exercise ")#link(<tao-17b7e72d51f2291a7f9f>)[#text("26")]#text("; to cover the larger ranges of ")#mi("{k}")#text(", use the modular discriminant ")#mi("{\\Delta}")#text(" to show that the space of cusp forms of weight ")#mi("{k+12}")#text(" is isomorphic to the space of modular forms of weight ")#mi("{k}")#text(".")],
[#text("(ii) If ")#mi("{k}")#text(" is an even natural number, show that a basis for the space of modular forms of weight ")#mi("{k}")#text(" is provided by the powers ")#mi("{G_4^i G_6^j}")#text(" where ")#mi("{i,j}")#text(" range over natural numbers (including zero) with ")#mi("{4i+6j=k}")#text(".")]
)
]

#text("Thus far we have constructed modular forms and modular functions starting from Eisenstein series ")#mi("{G_k}")#text(". There is another important, and seemingly quite different, way to generate modular forms coming from ")#link("https://en.wikipedia.org/wiki/Theta_function")[#text("theta functions")]#text(". Typically these functions are not ")#emph[#text("quite")]#text(" modular in the sense given in these notes, but are close enough that after some manipulation one can transform theta functions into modular forms. The simplest example of a theta function is the Jacobi theta function ")#metadata(none) <tao-973e223542ffe23e2d24>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\theta(\\tau) := \\sum_{n \\in {\\bf Z}} e^{\\pi i n^2 \\tau},")]]

#text(" ")#text(" which is easily seen to be a holomorphic function on ")#mi("{{\\bf H}}")#text(" that goes to one as ")#mi("{\\mathrm{Im}(\\tau) \\rightarrow +\\infty}")#text(". It is not quite a modular form, but is ")#mi("{2}")#text("-periodic (instead of ")#mi("{1}")#text("-periodic) in the sense that")

#align(center)[#tao-fit-display[#mitex("\\theta(\\tau+2) = \\theta(\\tau)")]]

#text("for all ")#mi("{\\tau \\in {\\bf H}}")#text(", and from Poisson summation (see Exercise 7 of ")#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/")[#text("Notes 2")]#text(") we have the variant")

#align(center)[#tao-fit-display[#mitex("\\theta(-1/\\tau) = (-i\\tau)^{1/2} \\theta(\\tau)")]]

#text("of the modularity relation ")#link(<tao-7ed131f5707162afad35>)[#text("(21)")]#text(", using the standard branch of the square root. This is not quite modular in nature, but a slight variant of the theta function fares better:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39")]#text(" Define the ")#link("https://en.wikipedia.org/wiki/Dedekind_eta_function")[#text("Dedekind eta function")]#text(" ")#mi("{\\eta: {\\bf H} \\rightarrow {\\bf C}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\eta(\\tau) := e^{\\pi i \\tau/12} \\sum_{n \\in {\\bf Z}} (-1)^n e^{(3n^2-n)\t\\pi i \\tau}")]]

#text("or in terms of the nome ")#mi("{q = e^{2\\pi i \\tau}}")

#align(center)[#tao-fit-display[#mitex("\\eta(\\tau) = q^{1/24} \\sum_{n \\in {\\bf Z}} (-1)^n q^{(3n^2-n)/2}")]]

#text("where ")#mi("{q^{1/24}}")#text(" is one of the ")#mi("{24^{th}}")#text(" roots of ")#mi("{q}")#text(".")

#list(
[#text("(i) Establish the modified ")#mi("{1}")#text("-periodicity")

#align(center)[#tao-fit-display[#mitex("\\eta(\\tau+1) = e^{\\pi i/12} \\eta(\\tau)")]]

#text("and the modified modularity")

#align(center)[#tao-fit-display[#mitex("\\eta(-1/\\tau) = (-i\\tau)^{1/2} \\eta(\\tau)")]]

#text("using the standard branch of the square root. (")#emph[#text("Hint:")]#text(" a direct application of Poisson summation applied to ")#mi("{\\eta(-1/\\tau)}")#text(" gives a sum that looks somewhat like ")#mi("{\\eta(\\tau)}")#text(" but with different numerical constants (in particular, one sees terms like ")#mi("{e^{\\pi i n^2 \\tau/3}}")#text(" instead of ")#mi("{e^{3\\pi i n^2 \\tau}}")#text(" arising). Split the index of summation ")#mi("{n}")#text(" into three components ")#mi("{n = 3m}")#text(", ")#mi("{n=3m+1}")#text(", ")#mi("{n=3m+2}")#text(" based on the residue classes modulo ")#mi("{3}")#text(" and rearrange each component separately.)")],
[#text("(ii) Establish the identity")

#align(center)[#tao-fit-display[#mitex("\\Delta(\\tau) = (2\\pi)^{12} \\eta(\\tau)^{24}.")]]

#text("(")#emph[#text("Hint:")]#text(" show that both sides are cusp forms of weight ")#mi("{12}")#text(" that vanish like ")#mi("{(2\\pi)^{12} q}")#text(" near the cusp.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 40")]#text(" The relationship between ")#mi("{\\Delta}")#text(" and the ")#mi("{24^{th}}")#text(" power of the eta function can be interpreted (after some additional effort) as a relation ")#mi("{\\Theta_\\Lambda = G_{12} - \\frac{65520}{691} \\Delta}")#text(" between the modular discriminant ")#mi("{\\Delta}")#text(" and the theta function ")#tao-math("{\\Theta_\\Lambda(\\tau) := \\sum_{x \\in \\Lambda} e^{-i\\pi \\tau \\left\\|x\\right\\|^2}}", block: false)#text(" of a certain highly symmetric ")#mi("{24}")#text("-dimensional lattice ")#mi("{\\Lambda \\subset {\\bf R}^{24}}")#text(" known as the ")#link("https://en.wikipedia.org/wiki/Leech_lattice")[#text("Leech lattice")]#text(", but we will not pursue this connection further here.")
]

#text("The ")#mi("{\\eta}")#text(" function has a remarkable factorisation coming from ")#link("https://en.wikipedia.org/wiki/Pentagonal_number_theorem")[#text("Euler’s pentagonal number theorem")]#text(" ")#metadata(none) <tao-8645983a27787cad2b80>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("\\sum_{n \\in {\\bf Z}} (-1)^n q^{(3n^2-n)/2} = \\prod_{m=1}^\\infty (1 - q^m),")]]

#text(" ")#text(" so that")

#metadata(none) <tao-680a0f679ffe4d10d0ca>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("\\eta(\\tau) = e^{\\pi i \\tau/12} \\prod_{m=1}^\\infty (1 - e^{2\\pi i m \\tau}).")]]

#text("There are many proofs of the pentagonal number theorem in the literature. One approach is to first establish the more general ")#link("https://en.wikipedia.org/wiki/Jacobi_triple_product")[#text("Jacobi triple product identity")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 41 (Jacobi triple product identity)")]#text(" For any ")#mi("{\\tau \\in {\\bf H}}")#text(" and ")#mi("{z \\in{\\bf C}}")#text(", one has")

#metadata(none) <tao-9dcc6fbbb4f3d0969043>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("\\sum_{n \\in {\\bf Z}} e^{\\pi i n^2 \\tau} e^{2\\pi i nz}")]]

#align(center)[#tao-fit-display[#mitex("= \\prod_{m=1}^\\infty (1 - e^{2\\pi i m \\tau}) (1 + e^{\\pi i (2m-1) \\tau} e^{2\\pi i z}) (1 + e^{\\pi i (2m-1) \\tau} e^{-2\\pi i z}).")]]
]

#text("Observe that by replacing ")#mi("{\\tau}")#text(" by ")#mi("{3\\tau/2}")#text(" and ")#mi("{z}")#text(" with ")#mi("{1/2 - \\tau/4}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}} (-1)^n q^{(3n^2-n)/2} = \\prod_{m=1}^\\infty (1 - q^{3m}) (1 - q^{3m-2}) (1-q^{3m-1})")]]

#text("and this gives the identity ")#link(<tao-8645983a27787cad2b80>)[#text("(31)")]#text(" after splitting the integers into the three residue classes ")#mi("{3m, 3m-2, 3m-1}")#text(" modulo ")#mi("{3}")#text(". One can obtain many further identities of this type by other substitutions; for instance, by setting ")#mi("{z=0}")#text(" in the triple product identity, one obtains")

#align(center)[#tao-fit-display[#mitex("\\theta(\\tau) = \\prod_{n=1}^\\infty (1 - e^{2\\pi i nz}) (1 + e^{\\pi i (2n-1)z})^2.")]]

#emph[#text("Proof:")]#text(" Let us denote the left-hand side and right-hand side of ")#link(<tao-9dcc6fbbb4f3d0969043>)[#text("(33)")]#text(" by ")#mi("{\\Theta(z|\\tau)}")#text(" and ")#mi("{\\Pi(z|\\tau)}")#text(" respectively. For fixed ")#mi("{\\tau \\in {\\bf H}}")#text(", both sides are clearly holomorphic in ")#mi("{z}")#text(", with ")#mi("{\\Pi(z|\\tau)}")#text(". Our strategy in showing that ")#mi("{\\Theta}")#text(" and ")#mi("{\\Pi}")#text(" agree (following Stein-Shakarchi) is to first observe that they have many of the same periodicity properties. We clearly have ")#mi("{1}")#text("-periodicity")

#align(center)[#tao-fit-display[#mitex("\\Theta(z+1|\\tau) = \\Theta(z|\\tau); \\quad \\Pi(z+1|\\tau) = \\Pi(z|\\tau).")]]

#text("From the identity")

#align(center)[#tao-fit-display[#mitex("e^{\\pi i n^2 \\tau} e^{2\\pi i n(z+\\tau)} = e^{-\\pi i \\tau} e^{-2\\pi i z} e^{\\pi i (n+1)^2 \\tau} e^{2\\pi i (n+1)z}")]]

#text("we also have the modified ")#mi("{\\tau}")#text("-periodicity")

#align(center)[#tao-fit-display[#mitex("\\Theta(z+\\tau|\\tau) = e^{-\\pi i \\tau} e^{-2\\pi i z} \\Theta(z|\\tau);")]]

#text("similarly from the telescoping products")

#align(center)[#tao-fit-display[#mitex("\\prod_{m=1}^\\infty (1 + e^{\\pi i (2m-1) \\tau} e^{2\\pi i (z+\\tau)}) = \\prod_{m=1}^\\infty (1 + e^{\\pi i (2(m+1)-1) \\tau} e^{2\\pi i z})")]]

#align(center)[#tao-fit-display[#mitex("(1 + e^{\\pi i \\tau} e^{2\\pi i z})^{-1} \\prod_{m=1}^\\infty (1 + e^{\\pi i (2m-1) \\tau} e^{2\\pi i z})")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\prod_{m=1}^\\infty (1 + e^{\\pi i (2m-1) \\tau} e^{-2\\pi i (z+\\tau)}) = \\prod_{m=1}^\\infty (1 + e^{\\pi i (2(m-1)-1) \\tau} e^{-2\\pi i z})")]]

#align(center)[#tao-fit-display[#mitex("(1 + e^{-\\pi i \\tau} e^{-2\\pi i z}) \\prod_{m=1}^\\infty (1 + e^{\\pi i (2m-1) \\tau} e^{-2\\pi i z})")]]

#text("we conclude that ")#mi("{\\Pi}")#text(" also obeys the same modified ")#mi("{\\tau}")#text("-periodicity")

#align(center)[#tao-fit-display[#mitex("\\Pi(z+\\tau|\\tau) = e^{-\\pi i \\tau} e^{-2\\pi i z} \\Pi(z|\\tau).")]]

#text("Thus the ratio ")#mi("{z \\mapsto \\Theta(z|\\tau)/\\Pi(z|\\tau)}")#text(" is meromorphic and doubly periodic. Furthermore, one checks that ")#mi("{\\Pi(z|\\tau)}")#text(" only vanishes when ")#mi("{z}")#text(" is equal to ")#mi("{\\frac{1+\\tau}{2}}")#text(" modulo ")#mi("{{\\bf Z} + \\tau{\\bf Z}}")#text(" with a simple zero at those locations, so the ratio ")#mi("{z \\mapsto \\Theta(z|\\tau)/\\Pi(z|\\tau)}")#text(" has at most a single simple pole on the torus ")#mi("{{\\bf Z} + \\tau {\\bf Z} \\backslash {\\bf C}}")#text(" and thus constant by the discussion after Lemma ")#link(<tao-2492c2a18ce9f3ca5b0a>)[#text("6")]#text(" (alternatively, one can show that ")#mi("{\\Theta(z|\\tau)}")#text(" also vanishes at this point and apply Proposition ")#link(<tao-f953f70b9132340e2782>)[#text("2")]#text("). Thus there is some quantity ")#mi("{c(\\tau)}")#text(" depending only on ")#mi("{\\tau}")#text(" for which we have the identity")

#align(center)[#tao-fit-display[#mitex("\\Theta(z|\\tau) = c(\\tau) \\Pi(z|\\tau)")]]

#text("for all ")#mi("{z \\in {\\bf H}}")#text(". To exploit this, we first set ")#mi("{z = 1/2}")#text(" and replace ")#mi("{\\tau}")#text(" by ")#mi("{4\\tau}")#text(" to conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}} (-1)^n e^{4\\pi i n^2 \\tau} = c(4\\tau) \\prod_{m=1}^\\infty (1 - e^{8\\pi i m \\tau}) (1 - e^{4\\pi i (2m-1) \\tau})^2")]]

#text("but on rearranging the absolutely convergent product we have")

#align(center)[#tao-fit-display[#mitex("\\prod_{m=1}^\\infty (1 - e^{8\\pi i m \\tau}) (1 - e^{4\\pi i (2m-1) \\tau}) = \\prod_{m=1}^\\infty (1 - e^{4\\pi i m \\tau})")]]

#text("and thus")

#metadata(none) <tao-0c62f876ef1dea830de9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("\\sum_{n \\in {\\bf Z}} (-1)^n e^{4\\pi i n^2 \\tau} = c(4\\tau) \\prod_{m=1}^\\infty (1 - e^{4\\pi i m \\tau}) (1 - e^{4\\pi i (2m-1) \\tau}).")]]

#text("If instead we set ")#mi("{z=1/4}")#text(" and not modify ")#mi("{\\tau}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}} i^n e^{\\pi i n^2 \\tau} = c(\\tau) \\prod_{m=1}^\\infty (1 - e^{2\\pi i m \\tau}) (1 + e^{2\\pi i (2m-1) \\tau});")]]

#text("the contribution of ")#mi("{n}")#text(" and ")#mi("{-n}")#text(" on the left-hand sides cancel when ")#mi("{n}")#text(" is odd, so that on making the substitution ")#mi("{n = 2\\tilde n}")#text(" we obtain")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}} i^n e^{\\pi i n^2 \\tau} = \\sum_{\\tilde n \\in {\\bf Z}} (-1)^{\\tilde n} e^{4\\pi i \\tilde n^2 \\tau}")]]

#text("while from rearranging an absolutely convergent product we have")

#align(center)[#tao-fit-display[#mitex("\\prod_{m=1}^\\infty (1 - e^{2\\pi i m \\tau}) = \\prod_{m=1}^\\infty (1 - e^{2\\pi i (2m-1) \\tau}) (1 - e^{2\\pi i (2m) \\tau})")]]

#text("and thus by difference of two squares")

#metadata(none) <tao-9f2e6d33a3717ee82635>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("\\sum_{\\tilde n \\in {\\bf Z}} (-1)^{\\tilde n} e^{4\\pi i \\tilde n^2 \\tau} = c(\\tau) \\prod_{m=1}^\\infty (1 - e^{4\\pi i m \\tau}) (1 - e^{4\\pi i (2m-1) \\tau}).")]]

#text("Comparing this with ")#link(<tao-0c62f876ef1dea830de9>)[#text("(34)")]#text(" we obtain the surprising additional symmetry")

#metadata(none) <tao-0012a3fa000c5dc26ee6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#mitex("c(\\tau) = c(4\\tau).")]]

#text("On the other hand, taking limits in (say) ")#link(<tao-9f2e6d33a3717ee82635>)[#text("(35)")]#text(" we see that ")#mi("{c(\\tau) \\rightarrow 1}")#text(" as ")#mi("{\\mathrm{Im} \\tau \\rightarrow +\\infty}")#text(". If we then iterate ")#link(<tao-0012a3fa000c5dc26ee6>)[#text("(36)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("c(\\tau) = \\lim_{j \\rightarrow \\infty} c(4^j \\tau) = 1")]]

#text("and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 42")]#text(" Another equivalent form of ")#link(<tao-680a0f679ffe4d10d0ca>)[#text("(32)")]#text(" is")

#align(center)[#tao-fit-display[#mitex("\\eta(\\tau)^{-1} = e^{-\\pi i \\tau/12} \\sum_{n=0}^\\infty p(n) e^{2\\pi i n \\tau}")]]

#text("where ")#mi("{p(n)}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Partition_function_(number_theory)")[#text("partition function")]#text(" of ")#mi("{n}")#text(" – the number of ways to represent ")#mi("{n}")#text(" as the sum of positive integers (up to rearrangement). Among other things, this formula can be used to ascertain the asymptotic growth of ")#mi("{p(n)}")#text(" (which turns out to roughly be of the order of ")#mi("{\\exp( \\pi \\sqrt{2n/3} )}")#text(", as famously established by Hardy and Ramanujan).")
]

#text("Theta functions can be used to encode various number-theoretic quantities involving quadratic forms, such as sums of squares. For instance, from ")#link(<tao-973e223542ffe23e2d24>)[#text("(30)")]#text(" and collecting terms one obtains the formula")

#align(center)[#tao-fit-display[#mitex("\\theta(\\tau)^k := \\sum_{m=0}^\\infty r_k(m) e^{\\pi i m \\tau}")]]

#text("for any natural number ")#mi("{k}")#text(", where ")#mi("{r_k(m)}")#text(" denotes the number of ways to express a natural number ")#mi("{m}")#text(" as the sum ")#mi("{m = n_1^2 + \\dots + n_k^2}")#text(" of ")#mi("{k}")#text(" squares of integers. From Fourier inversion (Proposition ")#link(<tao-cf7341eb8ec10c18cb33>)[#text("1")]#text(" and a rescaling) one then has a representation")

#align(center)[#tao-fit-display[#mitex("r_k(m) = \\frac{1}{2} \\int_{\\gamma_{\\tau_0 \\rightarrow \\tau_0+2}} \\theta(\\tau)^k e^{-\\pi i m \\tau}\\ d\\tau")]]

#text("for any ")#mi("{\\tau_0 \\in {\\bf H}}")#text(", which allows one to obtain asymptotics for ")#mi("{r_k}")#text(" when ")#mi("{k}")#text(" is large through estimation of the theta function (this is an example of the circle method); moreover, explicit identities relating the theta function to other near-modular forms (such as the Eisenstein series and their relatives) can be used to obtain exact formulae for ")#mi("{r_k(m)}")#text(" for small values of ")#mi("{k}")#text(" that can be used for instance to establish the famous ")#link("https://en.wikipedia.org/wiki/Lagrange%27s_four-square_theorem")[#text("Lagrange four-square theorem")]#text(" that all natural numbers are the sum of four squares. We refer the reader to the Stein-Shakarchi text for an exposition of this connection.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 43 (Hecke operators)")]#text(" ")#metadata(none) <tao-6790fe8ad5532ce91297>#text(" Let ")#mi("{k}")#text(" be a natural number.")

#list(
[#text("(i) If ")#mi("{f}")#text(" is a modular form of weight ")#mi("{k}")#text(", and ")#mi("{F}")#text(" is the corresponding function on lattices given by Exercise ")#link(<tao-473c3cba6f0b66454d76>)[#text("24")]#text(", and ")#mi("{m}")#text(" is a positive natural number, show that there is a unique modular form ")#mi("{T_m f}")#text(" of weight ")#mi("{k}")#text(" whose corresponding function ")#mi("{G}")#text(" on lattices is related to ")#mi("{F}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("G(\\Lambda) := m^{k-1} \\sum_{\\Lambda^{\\prime} \\subset \\Lambda: [\\Lambda:\\Lambda^{\\prime}] = m} F(\\Lambda^{\\prime})")]]

#text("where the sum ranges over all sublattices ")#mi("{\\Lambda^{\\prime}}")#text(" of ")#mi("{\\Lambda}")#text(" whose index ")#mi("{[\\Lambda:\\Lambda^{\\prime}]}")#text(" is equal to ")#mi("{m}")#text(". Show that ")#mi("{T_m}")#text(" is a linear operator on the space of weight ")#mi("{k}")#text(" modular forms that also maps the space of weight ")#mi("{k}")#text(" cusp forms to itself; this operator is known as a ")#link("https://en.wikipedia.org/wiki/Hecke_operator")[#text("Hecke operator")]#text(".")],
[#text("(ii) Give the more explicit formula")

#align(center)[#tao-fit-display[#mitex("T_m f(\\tau) = m^{k-1} \\sum_{a,d>0: ad=m} \\frac{1}{d^k} \\sum_{b=0}^{d-1} f( \\frac{az+b}{d} ).")]]],
[#text("(iii) Show that the Hecke operators all commute with each other, thus ")#mi("{T_n T_m f = T_m T_n f}")#text(" whenever ")#mi("{f}")#text(" is a modular form of weight ")#mi("{k}")#text(" and ")#mi("{n,m}")#text(" are positive natural numbers. Furthermore show that ")#mi("{T_n T_m = T_{nm}}")#text(" if ")#mi("{n,m}")#text(" are coprime.")],
[#text("(iv) If ")#mi("{f}")#text(" is a modular form of weight ")#mi("{k}")#text(" with Fourier expansion ")#mi("{f(\\tau) = \\sum_{n=0}^\\infty a_n q^n}")#text(", show that for any coprime positive integers ")#mi("{n,m}")#text(" that the ")#mi("{q^n}")#text(" coefficient of ")#mi("{T_m f}")#text(" is equal to ")#mi("{a_{nm}}")#text(".")],
[#text("(v) Establish the multiplicativity ")#mi("{\\tau(nm) = \\tau(n) \\tau(m)}")#text(" of ")#link("https://en.wikipedia.org/wiki/Ramanujan_tau_function")[#text("the Ramanujan tau function")]#text(" (the Fourier coefficients of the modular discriminant). (")#emph[#text("Hint:")]#text(" use the one-dimensionality of the space of cusp forms of weight ")#mi("{12}")#text(" to conclude that ")#mi("{\\Delta}")#text(" is a simultaneous eigenfunction of the Hecke operators.)")]
)

#text("Simultaneous eigenfunctions of the Hecke operators are known as ")#emph[#text("Hecke eigenfunctions")]#text(" and are of major importance in number theory.")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (56)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1023cbeae7fa1cb7b6324c5ec1e5c2d122356b31e48c5045126620b58522232-11ba9b9aa1ee90b17a2169a1f1a1523b1f05ef6bad89d3b61fe094e71e585a97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On the notes on applications")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-621861")[#strong[#text("On the notes on applications")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2021")])]

#text("Would number theoretic and sphere packing applications be covered in the class and would the notes be posted?")

#emph[#text("[No, I am not planning to cover those topics in this course. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-621863")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2021")])]

#text("The top-level tags of this post appear to have the wrong course tagging.")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-621864")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2021")])]

#text("typo in Lemma 6: P should be in the torus, not in \\Lambda")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-621865")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2021")])]

#text("Lemma 3 is referred to as Lemma 2.")

#emph[#text("[Corrected – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-621869")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2021")])]

#text("I think there’s a typo in the first paragraph: \\omega Z\\C should be C/\\omega Z")

#emph[#text("[Both forms are acceptable. In the case of quotients of actions by abelian groups it makes little difference, but when it comes to nonabelian groups such as ${\\bf SL}_2({\\bf Z})$ the convention matters a little bit, and I have elected to have the groups act on the left and define quotients accordingly. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-621879")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2021")])]

#text("The product representation of ")#mi("\\eta")#text(" function is closely related to the product representation of the generating function for the partition function ")#mi("p(n)")#text(" (and can be used to derive its convergent asymptotic series)")

#emph[#text("[A remark to this effect has been added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-621920")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2021")])]

#text("The identity (8) can also be proved by observing (via Laurent expansion coefficients) that its LHS is entire – so by proposition 2 it is a constant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-621921")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2021")])]

#text("Correction: I meant that the difference(!) between the LHS and the RHS (not the LHS) of (8) is entire – so it must be a constant.")

#emph[#text("[An exercise to this effect has been added – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-621938")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2021")])]

#text("For a different approach to Exercise 17, note that if ")#mi("\\gamma\\in\\mathrm{SL}_2(\\mathbb{Z})")#text(" fixes a point in ")#mi("\\mathbb{H}")#text(" then it lies in the intersection of a discrete group and a compact group, hence had finite order.")

#text("Its eigenvalues must then be roots of unity which are also quadratic irrationalities. Since a primitive root of unity of order ")#mi("n")#text(" has degree ")#mi("\\phi(n)")#text(", we see that the order must be one of 1,2,3,4,6. This computes the cojugacy classes of these elements.")

#text("Also, dividing by ")#mi("\\pm I")#text(" which act trivially we see that ")#mi("\\gamma")#text(" has order 1,2,3 in ")#mi("\\mathrm{PSL}_2(\\mathbb{Z})")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-621964")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2021")])]

#text("Thanks for this! One can also see that an element of ")#mi("SL_2({\\bf Z})")#text(" that has roots of unity as eigenvalues must have trace in the set ")#mi("\\{-2, -1, 0, 1, 2\\}")#text(" which also gives the eigenvalues and thus the conjugacy class in ")#mi("{\\bf SL}_2({\\bf R})")#text(". But I was not able to easily show that any two such elements of ")#mi("SL_2({\\bf Z})")#text(" with the same eigenvalues were conjugate in ")#mi("SL_2({\\bf Z})")#text(" (which is what one needs to specify the fixed points) without messing around with lattices as in the stated exercise. (Maybe this is just some consequence of the algebraic integer nature of the eigenvalues, but I didn’t immediately see an argument.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jarek Kuben")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-622213")[#strong[#text("Jarek Kuben")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2021")])]

#text("This argument can be finished using the shape of the standard fundamental domain. With notation as above, if ")#mi("\\gamma\\cdot\\tau=\\tau")#text(" for ")#mi("\\gamma\\ne\\pm I")#text(", then ")#mi("c\\ne0")#text(" and we can WLOG assume ")#mi("c>0")#text(" by replacing ")#mi("\\gamma")#text(" with ")#mi("-\\gamma")#text(" if necessary. This equation also implies that ")#mi("(\\tau,1)^T")#text(" is an eigenvector of ")#mi("\\gamma")#text(" with eigenvalue ")#mi("c\\tau+d")#text(", and since ")#mi("c\\tau+d\\in\\bf H")#text(", it’s ")#mi("c\\tau+d\\in\\{i,(\\pm1+i\\sqrt{3})/2\\}")#text(". But if we also WLOG assume ")#mi("\\tau\\in\\mathcal F")#text(", then it follows that ")#mi("\\tau\\in\\{i,(\\pm1+i\\sqrt{3})/2\\}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-622287")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("Let ")#mi("\\gamma\\in\\Gamma = \\mathrm{SL}_2(\\mathbb{Z})")#text(" be an element of finite order (other than ")#mi("\\pm I")#text(") with characteristic polynomial ")#mi("p(x)=x^2-tx+1 \\in \\mathbb{Z}[x]")#text(" where ")#mi("t=\\mathbb{Tr}\\gamma")#text(", and consider ")#mi("\\mathbb{Z}^2")#text(" as a module of over the commutative subring ")#mi("\\mathbb{Z}[\\gamma] \\subset M_2(\\mathbb{Z})")#text(".")

#text("As a ring we have ")#mi("\\mathbb{Z}[\\gamma] \\equiv \\mathbb{Z}[x]/(p) \\equiv \\mathbb{Z}[\\zeta]")#text(" where ")#mi("\\zeta")#text(" is a root of ")#mi("p")#text(", that is a primitive root of unity of order 3,4,6. It so happens that ")#mi("\\mathcal{O}=\\mathbb{Z}[\\zeta]")#text(" is the ring of integers of the quadratic field ")#mi("\\mathbb{Q}(\\zeta)")#text(", and that these rings of integers are PIDs (in fact both these rings are Euclidean). By the classification of modules over a PID and since ")#mi("\\mathbb{Z}^2")#text(" is torsion-free we see that ")#mi("\\mathbb{Z}^2")#text(" is isomorphic to ")#mi("\\mathcal{O}")#text(" as an ")#mi("\\mathcal{O}")#text("-module.")

#text("Now if ")#mi("\\gamma,\\delta")#text(" are two such elements then we get an isomorphism ")#mi("\\eta\\colon\\mathbb{Z}^2\\to\\mathbb{Z}^2")#text(" intertwining the two ")#mi("\\mathcal{O}")#text("-module structures, in other words an element of ")#mi("\\mathrm{GL}_2(\\mathbb{Z})")#text(" conjugating ")#mi("\\gamma,\\delta")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-622294")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("Nice! So a little bit of algebraic number theory allows one to show the transitivity of the ")#mi("SL_2({\\bf Z})")#text(" action amongst all elements of finite order with fixed characteristic polynomial. (Unfortunately this argument is difficult to work into this complex analysis class as it requires a set of prerequisites that are basically disjoint from those already assumed for this course.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-622297")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("By the way you can also apply the same idea to the hyperbolic elements (those with ")#tao-math("\\left|t\\right|>2", block: false)#text("). The the ring ")#mi("\\mathbb{Z}[\\gamma]")#text(" is an order in the corresponding real quadratic field ")#mi("\\mathbb{Q}(\\sqrt{t^2-4})")#text(" (a subring which is also a lattice), it is not hard to show ")#mi("\\mathbb{Z}^2")#text(" is one of the ideal classes of the order. We thus obtain the well-known bijection between closed geodesics on the modular surface and ideal classes in quadratic orders.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-622298")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("(and I forgot to add to the bijection the conjugacy classes in the modular group of [primitive] hyperbolic elements)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jarek Kuben")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-678425")[#strong[#text("Jarek Kuben")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2023")])]

#text("It’s also possible to combine the lattice and algebraic number theory approaches in a way that perhaps gives more insight and shows that the two exceptional orbits are related to complex multiplication.")

#text("Indeed, let ")#mi("\\tau\\in\\mathbf H")#text(" be a fixed point of ")#mi("\\gamma=\\begin{pmatrix}a&b\\\\c&d\\end{pmatrix}\\in\\mathrm{SL}_2(\\mathbf Z)")#text(", then ")#mi("[\\tau,1]=[a\\tau+b,c\\tau+d]=(c\\tau+d)[\\frac{a\\tau+b}{c\\tau+d},1]")#text(", thus ")#mi("c\\tau+d\\in\\mathrm{Aut}(\\Lambda)")#text(", where ")#mi("\\Lambda=[\\tau,1]")#text(". We claim that the map ")#mi("\\mathrm{Stab}(\\tau)\\to\\mathrm{Aut}(\\Lambda)\\le\\mathbf C^\\times")#text(" given by ")#mi("\\gamma\\to c\\tau+d")#text(" is a group isomorphism. Indeed, it’s easy to check that it’s a homomorphism, and it’s injective since ")#mi("c\\tau+d=1")#text(" implies ")#mi("c=0")#text(", ")#mi("d=1")#text(", and then ")#mi("a=1")#text(", and thus ")#mi("\\tau=\\gamma\\cdot\\tau=\\tau+b")#text(", and so ")#mi("b=0")#text(" and ")#mi("\\gamma=I")#text(". It’s also surjective since for ")#mi("\\lambda\\in\\mathrm{Aut}(\\Lambda)")#text(" the couple ")#mi("(\\lambda\\tau,\\lambda)")#text(" is a ")#mi("\\mathbf Z")#text("-basis of ")#mi("\\Lambda")#text(" with ")#mi("\\mathrm{Im}(\\lambda\\tau/\\lambda)=\\mathrm{Im}(\\tau)>0")#text(", and so there exists ")#mi("\\gamma\\in\\mathrm{SL}_2(\\mathbf Z)")#text(" such that ")#mi("\\lambda\\begin{pmatrix}\\tau\\\\1\\end{pmatrix}=\\gamma\\begin{pmatrix}\\tau\\\\1\\end{pmatrix}")#text(", which implies ")#mi("\\gamma\\in\\mathrm{Stab}(\\tau)")#text(" and ")#mi("\\gamma\\to\\lambda")#text(".")

#text("However for a lattice ")#mi("\\Lambda")#text(" it’s ")#mi("\\mathrm{End}(\\Lambda)=\\mathbf Z")#text(" and thus ")#mi("\\mathrm{Aut}(\\Lambda)=\\mathbf Z^\\times=\\pm1")#text(", except for the case when ")#mi("\\Lambda")#text(" is a scalar multiple of an invertible ideal in some imaginary quadratic order ")#mi("\\mathcal O")#text(", in which case it’s ")#mi("\\mathrm{End}(\\Lambda)=\\mathcal O")#text(" and ")#mi("\\mathrm{Aut}(\\Lambda)=\\mathcal O^\\times")#text(".")

#text("It follows that ")#mi("\\tau")#text(" has a stabilizer larger that ")#mi("\\pm I")#text(" iff ")#mi("\\Lambda=[\\tau,1]")#text(" is a scalar multiple of an invertible ideal in an imaginary quadratic order that has units other that ")#mi("\\pm1")#text(". However the only such orders are ")#mi("\\mathbf Z[i]")#text(" and ")#mi("\\mathbf Z[\\zeta_3]")#text(", and they both have trivial class group, thus ")#mi("\\Lambda")#text(" is a scalar multiple of ")#mi("\\mathbf Z[i]")#text(" or ")#mi("\\mathbf Z[\\zeta_3]")#text(", and so ")#mi("\\tau")#text(" belongs to the orbit of ")#mi("i")#text(" or ")#mi("\\zeta_3")#text(".")

#text("Furthermore it’s ")#mi("\\mathrm{Stab}(i)\\cong\\mathrm{Aut}(\\mathbf Z[i])=\\mathbf Z[i]^\\times=\\langle i\\rangle\\cong\\mathbf Z/4")#text(" and ")#mi("\\mathrm{Stab}(\\zeta_3)\\cong\\mathrm{Aut}(\\mathbf Z[\\zeta_3])=\\mathbf Z[\\zeta_3]^\\times=\\langle\\zeta_6\\rangle\\cong\\mathbf Z/6")#text(", and we can use the above map to explicitly compute these stabilizers. Indeed, it’s ")#mi("i\\begin{pmatrix}i\\\\1\\end{pmatrix}=\\begin{pmatrix}0&-1\\\\1&0\\end{pmatrix}\\begin{pmatrix}i\\\\1\\end{pmatrix}")#text(" and ")#mi("\\zeta_6\\begin{pmatrix}\\zeta_3\\\\1\\end{pmatrix}=\\begin{pmatrix}0&-1\\\\1&1\\end{pmatrix}\\begin{pmatrix}\\zeta_3\\\\1\\end{pmatrix}")#text(", hence ")#mi("\\mathrm{Stab}(i)=\\left\\langle\\begin{pmatrix}0&-1\\\\1&0\\end{pmatrix}\\right\\rangle")#text(" and ")#mi("\\mathrm{Stab}(\\zeta_3)=\\left\\langle\\begin{pmatrix}0&-1\\\\1&1\\end{pmatrix}\\right\\rangle")#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-621953")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2021")])]

#text("Professor Tao, in the proof of Great Picard’s theorem, why is it that ")#mi("j^{-1}\\circ f(e^{iz})")#text(" lifts to a 1-periodic function?")

#emph[#text("[Oops, this is an issue. It can be resolved by analysing the possible shifts by elements of ")#mi("{SL}_2({\\bf Z})")#text(" that can occur, but this is a little tricky. For now I have deleted the proof of the theorem, will think more about whether there is a painless fix to it. UPDATE: now an exercise. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-621965")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2021")])]

#text("In exercise 34 it seems that ")#mi("\\int")#text(" should be ")#mi("\\sum")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-621970")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2021")])]

#text("In the proof of theorem 39, it seems that there are some latex problems in some formulas.")

#emph[#text("[Fixed now – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-621996")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2021")])]

#text("In remark 42 it seems (from the product representation of the generating function for ")#mi("p(n)")#text(") that the summand ")#mi("p(0) := 1")#text(" should also be included in the displayed sum.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-622025")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2021")])]

#text("In the first line of proposition 1, it seems that “periodic” should appear between “singly” and “holomorphic”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-622116")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2021")])]

#text("In proposition 2, the periods should be linearly independent over ")#mi("\\mathbb R")#text(" (not ")#mi("\\mathbb C")#text(")")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-622117")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2021")])]

#text("In exercise 37, the statement of the great Picard theorem is missing.")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-622327")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2021")])]

#text("I don’t know if this is the best place to put it, but there is a typo remark 40 (descriminant)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-622425")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2021")])]

#text("Should Lemma 6 be codimension at most 1, i.e. 0 or 1?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RJD")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-622453")[#strong[#text("RJD")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2021")])]

#text("I admit, I’m a little puzzled in exercise 43. I am reading Serre’s “A course in Arithmetic” and looking at the Hecke operator section. He defines T_m(f) in the way I expect (i.e., using the notation above, T_m(f)(z)=G(z,1)). However, he derives that this is a modular form using the more explicit expression in part (ii). Is there some way of concluding that this is the unique modular form with lattice function G without using the expression directly?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-622522")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2021")])]

#text("Yes; ")#mi("G")#text(" is clearly a function on ")#mi("\\Lambda")#text(" (so different generators give rise to the same value of ")#mi("G")#text(") and obeys the same homogeneity relation as ")#mi("F")#text(" does (see Exercise 24), so modularity can be proven rather painlessly without needing the explicit expansion in (ii).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RJD")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-622558")[#strong[#text("RJD")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2021")])]

#text("Okay, so I have a dumb question. I agree that weak modularity follows fairly easily. What about holomorphicity at infinity? What am I missing here? It seems Serre does what he does to establish the holomorphicity at infinity, so I was wondering specifically about how that is taken care of.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-622683")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2021")])]

#text("There are only a bounded number of sublattices ")#mi("\\Lambda^{\\prime}")#text(" of ")#mi("\\Lambda")#text(" of a fixed index (note that all lattices are isomorphic to each other as abelian groups, so once one has finiteness for say ")#mi("{\\bf Z}^2")#text(" one has finiteness for the rest), so if ")#mi("F")#text(" is bounded at infinity then so is ")#mi("G")#text(". (Holomorphicity can be established by a similar argument.) Part (ii) comes from actually enumerating these bounded number of sublattices, but this isn’t necessary for the qualitative properties in (i).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RJD")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-622746")[#strong[#text("RJD")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2021")])]

#text("Thank you so much for your responses Professor Tao! One more question. You mention that F being bounded at infinity implies that G is bounded at infinity, and that holomorphicity can be established by a similar argument. What do you mean by bounded at infinity? Do you mean that the associated modular function given by Exercise 24 is bounded as $Im(\\tau) \\rightarrow \\infty$?")

#emph[#text("[Yes – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Course announcement: 246B, complex analysis | What's new")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-622825")[#strong[#text("Course announcement: 246B, complex analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("[…] Elliptic functions and their relatives; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 2: Some connections with the Fourier transform | What's new")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-622829")[#strong[#text("246B, Notes 2: Some connections with the Fourier transform | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("[…] Previous set of notes: Notes 1. Next set of notes: Notes 3. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 4: The Riemann zeta function and the prime number theorem | What's new")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-622832")[#strong[#text("246B, Notes 4: The Riemann zeta function and the prime number theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("[…] set of notes: Notes 3. Next set of notes: 246C Notes […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-640408")[#strong[#text("J.")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2022")])]

#text("Throughout the notes, you have used both ")#mi("{\\bf R}/{\\bf Z}")#text(" (as in the “additive unit circle”) and something like ")#mi("\\Lambda\\backslash {\\bf C}")#text(". Are there any reasons for the preferences?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-640468")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2022")])]

#text("For abelian actions the two notations are interchangeable. For non-abelian actions like ")#mi("\\mathrm{SL}_2({\\mathbf{Z}}) \\backslash \\mathbf{H}")#text(" one has to use the left quotient if one wants the group ")#mi("SL_2({\\bf Z})")#text(" to act on the left, so I set up my notation for Riemann surface structures on quotient spaces using left quotients (and I have tried to emphasise the analogy between the torus ")#mi("\\Lambda \\backslash {\\bf C}")#text(" and the modular curve ")#mi("\\mathrm{SL}_2({\\mathbf{Z}}) \\backslash \\mathbf{H}")#text(" in these notes). But I am not viewing the unit circle ")#mi("{\\bf R}/{\\bf Z}")#text(" as part of a larger class of possibly non-abelian quotient spaces, so here I am happy to use the traditional right quotient notation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-642737")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2022")])]

#text("If one has a group ")#mi("X")#text(" and ")#mi("X")#text(" being a normal subgroup of ")#mi("X")#text(", then one has the quotient group ")#mi("X/G")#text(".")

#text("In this set of notes, it seems to be the case that ")#mi("X")#text(" is just a ")#emph[#text("set")]#text(" and ")#mi("G")#text(" being ")#emph[#text("any")]#text(" group acting on ")#mi("X")#text("; and you talk about the “quotient” ")#mi("G/X")#text(" or ")#mi("X\\backslash G")#text(". Is there a group structure hiding somewhere for the set ")#mi("X")#text("? Also, is there a “normal subgroup” lurking somewhere?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-642929")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2022")])]

#text("One can quotient out any set by any equivalence relation to obtain a ")#link("https://en.wikipedia.org/wiki/Quotient_space_(topology)")[#text("quotient space")]#text(". In particular, any group acting on a space gives rise to a quotient space through the orbit equivalence relation. For instance, one can quotient any group ")#mi("G")#text(" by any subgroup ")#mi("H")#text(" to obtain a quotient space ")#mi("G/H")#text(" (of left-cosets) or ")#mi("H \\backslash G")#text(" (of right cosets). The normality of ")#mi("H")#text(" is only required if one wants this quotient space to also be a group.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-642849")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2022")])]

#text("In the proof of Lemma 3(iii), the path ")#mi("{\\gamma_{0 \\rightarrow \\omega_j}}")#text(" is not closed. What modification of the argument principle is used?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-642932")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2022")])]

#text("While the path ")#mi("\\gamma_{0 \\to \\omega_j}")#text(" is not closed, the image ")#mi("f \\circ \\gamma_{0 \\to \\gamma_j}")#text(" is. Apply a change of variables ")#mi("w = f(z)")#text(" to conclude.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-642853")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2022")])]

#text("Consider the example of ")#mi("f(z)=z-1")#text(" and ")#mi("D=0(P)")#text(" where ")#mi("P=1")#text(". According to the notes, ")#mi("L(D)=L(0)")#text(" consists of only constant functions and thus ")#mi("f\\not\\in L(D)")#text(" by the definition.")

#text("But I got ")#mi("(f)=1(P)")#text(" because the order of zero is ")#mi("1")#text(" at ")#mi("P")#text(". So ")#mi("(f)+D\\ge 0")#text(" and thus ")#mi("f\\in L(D)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-642854")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2022")])]

#text("What is going wrong in the calculation above?")

#emph[#text("[The function ")#mi("f(z)=z-1")#text(" is not elliptic (doubly periodic) and so does not give a well-defined holomorphic function on the torus. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-642869")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2022")])]

#emph[#linebreak()#text(" … To figure out which, we can normalise ")#mi("{P}")#text(" to be the origin coset ")#mi("{\\Lambda}")#text(". The question is now whether there is a doubly periodic meromorphic function that has a double pole at each point of ")#mi("{\\Lambda}")#text(". A naive candidate for such a function would be the infinite series")#linebreak()#text(" ")#mi("\\displaystyle  \\sum_{z_0 \\in \\Lambda} \\frac{1}{(z-z_0)^2},")#linebreak()#text(" however this series turns out to not be absolutely convergent.")#linebreak()#text(" ")]

#text("I am confused with the reasoning here.")

#text("The goal was to study the dimension of ")#mi("L(2\\cdot(P))")#text(", which is at least ")#mi("1")#text(" since every constant function ")#mi("{f: \\Lambda \\backslash {\\bf C} \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" (or equivalently, a doubly periodic function ")#mi("{f: {\\bf C} \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(") satisfies ")#mi("(f)+2\\cdot(P)\\geq 0")#text(". So question is now whether")

#text("– there is a meromorphic function ")#mi("{f: \\Lambda \\backslash {\\bf C} \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" that has a double pole at ")#mi("P=\\Lambda")#text(";")

#text("– or equivalently, a doubly periodic (meromorphic) function ")#mi("{f: {\\bf C} \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" that has a double pole at some point of ")#mi("\\Lambda")#text(".")

#text("(Why should it be that “The question is now whether there is a doubly periodic meromorphic function that has a double pole ")#emph[#text("at each point")]#text(" of ")#mi("{\\Lambda}")#text(".”? Isn’t it that any single point in ")#mi("\\Lambda")#text(" is a representative of the coset?)")

#text("What is really the equivalent way to say “poles” for meromorphic function ")#mi("{f: \\Lambda \\backslash {\\bf C} \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" and meromorphic function ")#mi("{f: {\\bf C} \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-642933")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2022")])]

#text("If a doubly periodic function ")#mi("f: {\\bf C} \\to {\\bf C} \\cup \\infty")#text(" has a pole at any point ")#mi("z")#text(", it will also have a pole (of the same order) at every other point in the coset ")#mi("z+\\Lambda")#text(" by periodicity, and so when viewed as a function ")#mi("f: \\Lambda \\backslash {\\bf C} \\to {\\bf C} \\cup \\infty")#text(", it can be said to have a pole at the point ")#mi("z+\\Lambda \\in \\Lambda \\backslash {\\bf C}")#text(" (of the specified order).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-642874")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2022")])]

#text("Minor typo in (6):")

#mi("\\displaystyle  \\wp(z) := \\frac{1}{z^2} + \\sum_{z_0 \\in \\Lambda \\backslash 0} \\frac{1}{(z-z_0)^2} - \\frac{1}{z_0^2} \\ \\ \\ \\ \\ (6)")

#text("is meant to be")

#mi("\\displaystyle  \\wp(z) := \\frac{1}{z^2} + \\sum_{z_0 \\in \\Lambda \\backslash \\{0\\}} \\left(\\frac{1}{(z-z_0)^2} - \\frac{1}{z_0^2}\\right) \\ \\ \\ \\ \\ (6)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-642875")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2022")])]

#text("In proving the double periodicity of the function ")#mi("\\wp")#text(", it is said that")

#emph[#linebreak()#text(" … The series on the right is absolutely convergent, and on every coset of ")#mi("{\\omega_1 {\\bf Z}}")#text(" it telescopes to zero.")#linebreak()#text(" ")]

#text("Cosets of ")#mi("\\Lambda\\backslash{\\bf C}")#text(" is of the form ")#mi("\\lambda+\\Lambda")#text(" for some ")#mi("\\lambda\\in{\\bf C}")#text(". What do you mean by “coset of ")#mi("{\\omega_1 {\\bf Z}}")#text("“?")

#emph[#text("[A set of the form ")#mi("z + \\omega_1 {\\bf Z}")#text(" for some complex number ")#mi("z")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-642911")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2022")])]

#text("In (11): ")#mi("\\wp(z^{\\prime})")#text(" –> ")#mi("\\wp^{\\prime}(z)")#text(".")

#emph[#text("… we have ")#mi("{1/z = h^{-1}(w/z^2)}")#text(" in a neighbourhood of infinity. ")]

#text("–>")

#text("… we have ")#mi("{1/z = h^{-1}((w/z^2)^2)}")#text(" in a neighbourhood of infinity.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-642966")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2022")])]

#emph[#linebreak()#text(" … so to demonstrate absolute convergence it suffices to show that")#linebreak()#text(" ")#tao-math("\\displaystyle  \\sum_{z_0 \\in \\Lambda: z_0 \\neq 0} \\frac{1}{\\left|z_0\\right|^3} < \\infty.", block: false)#linebreak()#text(" But a simple volume packing argument (considering the areas of the translates ")#mi("{z_0 + D}")#text(" of the fundamental domain ")#mi("{D}")#text(") shows that the number of lattice points ")#mi("{z_0}")#text(" in any disk ")#mi("{D(0,R)}")#text(", ")#mi("{R \\geq 1}")#text(" is ")#mi("{O_\\Lambda(R^2)}")#text(", and so by dyadic decomposition as in Notes 1, the series is absolutely convergent.")#linebreak()#text(" ")]

#text("Can you please elaborate on what the “volume packing argument” is?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-643032")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2022")])]

#text("As ")#mi("z_0")#text(" ranges over the lattice points in the disk ")#mi("D(0,R)")#text(", the translates ")#mi("z_0+D")#text(" of the fundamental domain each have area ")#tao-math("\\left|D\\right|", block: false)#text(" and are disjoint (up to null sets) and occupy (a subset of) a disk of radius ")#mi("R + O(1)")#text(", which has area ")#mi("O(R^2)")#text(". So the total number of such lattice points is at most ")#tao-math("O(R^2) / \\left|D\\right| = O_\\Lambda(R^2)", block: false)#text(".")#linebreak()#text(" (The same argument also gives a comparable lower bound.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-642969")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2022")])]

#emph[#linebreak()#text(" If ")#mi("{a}")#text(" lies in the half-lattice ")#mi("{\\frac{1}{2} \\Lambda}")#text(" but not in ")#mi("{\\Lambda}")#text(" (thus, it lies in one of the half-periods ")#mi("{\\frac{\\omega_1}{2} + \\Lambda}")#text(", ")#mi("{\\frac{\\omega_2}{2} + \\Lambda}")#text(", or ")#mi("{\\frac{\\omega_1+\\omega_2}{2} + \\Lambda}")#text(") then from the even and doubly periodic nature of ")#mi("{\\wp}")#text(" we see that ")#mi("{\\wp(a+z) = \\wp(a-z)}")#text(" for all ")#mi("{z \\not \\in \\frac{1}{2} \\Lambda}")#text(", so ")#mi("{\\wp - \\wp(a)}")#text(" in fact must have at least a double zero at ")#mi("{a}")#text(",…")#linebreak()#text(" ")]

#text("If ")#mi("a")#text(" lies in one of the half-periods, isn’t it true for *all* ")#mi("z")#text(" that")#linebreak()#text(" ")#mi("\\wp(a+z)=\\wp(-a-z)=\\wp(a-z)")#text("? (I guess the notes just want to emphasize that it is particularly true for ")#mi("z\\not\\in\\frac{1}{2}\\Lambda")#text(". Correct?) How does this fact ")#emph[#text("imply")]#text(" that ")#mi("\\wp-\\wp(a)")#text(" must have at least a double zero at ")#mi("a")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-642970")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2022")])]

#text("Also, why is it not possible that when ")#mi("a")#text(" is a half-period, ")#mi("\\wp-\\wp(a)")#text(" has a simple zero at ")#mi("a")#text(", and another simple zero at another half-period?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-643033")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2022")])]

#text("The exclusion ")#mi("z \\not \\in \\frac{1}{2} \\Lambda")#text(" is solely to avoid the poles of ")#mi("\\wp")#text(". Applying the even symmetry ")#mi("\\wp(a+z) = \\wp(a-z)")#text(" to the Taylor expansion of ")#mi("\\wp")#text(" around ")#mi("a")#text(", we see that only the even power coefficients can be non-zero, hence the order of any zero of ")#mi("\\wp - \\wp(a)")#text(" at ")#mi("a")#text(" must be even.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-643001")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2022")])]

#text("Are there relations between “elliptic curves” and “modular curves” in this set of notes? It seems that according to the definition in Section 2, a modular curve is a set of equivalent classes of elliptic curves. Is there anything more than that?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-643035")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2022")])]

#text("There are additional, much deeper, connections between elliptic curves and modular forms, most notably through the ")#link("https://en.wikipedia.org/wiki/Modularity_theorem")[#text("modularity theorem")]#text(" that asserts that the L-function of an elliptic curve defined over the rationals has coefficients that are also the Fourier coefficients of a modular form (which, among other things, famously implies Fermat’s last theorem, and also serves as a special case for the broader Langlands program), but this is well beyond the scope of this course.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-643037")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2022")])]

#emph[#text("… so that the function ")#mi("{\\wp(z) - \\frac{1}{z^2}}")#text(", which extends holomorphically to the origin, has ")#mi("{k^{th}}")#text(" derivative at the origin equal to ")#mi("{(-1)^k (k+1)! G_{k+2}(\\Lambda)}")#text(",")#linebreak()#text(" ")]

#text("Without taking into account the fact that ")#mi("G_k=0")#text(" for odd ")#mi("k")#text(", by direct calculation, should the derivative at the origin equal to")

#mi("{ (k+1)! G_{k+2}(\\Lambda)}")#text(" instead?")

#text("Taking the ")#mi("k")#text("-th derivative, one has")

#mi("(\\wp(z)-\\frac{1}{z^2})^{(k)}=(-1)^k(k+1)!\\sum_{z_0\\in\\Lambda\\setminus \\{0\\}}\\frac{1}{(z-z_0)^{k+2}}")

#text("Taking ")#mi("z\\to 0")#text(" one has a factor of ")#mi("(-1)^{k+2}")#text(" in the denominator and thus cancel out with ")#mi("(-1)^k")#text(".")

#emph[#text("[Updated, though by making the change of variables ")#mi("z_0 \\mapsto -z_0")#text(" one could also have retained the ")#mi("(-1)^k")#text(" factor if desired. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-670758")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2022")])]

#text("Where can I read more about the connection mentioned in Remark 40, between the Dedekind eta function and the theta function of the Leech lattice?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/02/02/246b-notes-3-elliptic-functions-and-modular-forms/#comment-687627")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2025")])]

#text("In (30), ")#mi("\\theta(\\tau) \\rightarrow 1")#text(" (instead of zero) as ")#mi("{\\mathrm{Im}(\\tau) \\rightarrow +\\infty}")#text(", because of the term corresponding to ")#mi("n = 0")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
