// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/02/13/yet-another-proof-of-szemeredis-theorem/
// Converted to Typst by tao2typ: "2026-10-14T15:17:39.574251+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Yet another proof of Szemerédi’s theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Yet another proof of Szemerédi’s theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 February 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/02/13/yet-another-proof-of-szemeredis-theorem/")[#text("https://terrytao.wordpress.com/2010/02/13/yet-another-proof-of-szemeredis-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(", and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" a short (six-page) paper “")#link("http://arxiv.org/abs/1002.2254")[#text("Yet another proof of Szemeredi’s theorem")]#text("“, submitted to the 70th birthday conference proceedings for Endre Szemerédi. In this paper we put in print a folklore observation, namely that the inverse conjecture for the Gowers norm, together with the density increment argument, easily implies ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("Szemerédi’s famous theorem on arithmetic progressions")]#text(". This is unsurprising, given that ")#link("http://www.ams.org/mathscinet-getitem?mr=1844079")[#text("Gowers’ proof")]#text(" of Szemerédi’s theorem proceeds through a weaker version of the inverse conjecture and a density increment argument, and also given that it is possible to derive Szemerédi’s theorem from knowledge of the characteristic factor for multiple recurrence (the ergodic theory analogue of the inverse conjecture, first established ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("by Host and Kra")]#text("), as was ")#link("http://arxiv.org/abs/0710.4862")[#text("done by Bergelson, Leibman, and Lesigne")]#text(" (and also implicitly in the ")#link("http://www.math.northwestern.edu/~kra/papers/synd.pdf")[#text("earlier paper of Bergelson, Host, and Kra")]#text("); but to our knowledge the exact derivation of Szemerédi’s theorem from the inverse conjecture was not in the literature. Ordinarily this type of folklore might be considered too trifling (and too well known among experts in the field) to publish; but we felt that the venue of the Szemerédi birthday conference provided a natural venue for this particular observation.")

#text("The key point is that one can show (by an elementary argument relying primarily an induction on dimension argument and the Weyl recurrence theorem, i.e. that given any real ")#mi("{\\alpha}")#text(" and any integer ")#mi("{s \\geq 1}")#text(", that the expression ")#mi("{\\alpha n^s}")#text(" gets arbitrarily close to an integer) that given a (polynomial) nilsequence ")#mi("{n \\mapsto F(g(n)\\Gamma)}")#text(", one can subdivide any long arithmetic progression (such as ")#mi("{[N] = \\{1,\\ldots,N\\}}")#text(") into a number of medium-sized progressions, where the nilsequence is nearly constant on each progression. As a consequence of this and the inverse conjecture for the Gowers norm, if a set has no arithmetic progressions, then it must have an elevated density on a subprogression; iterating this observation as per the usual density-increment argument as introduced long ago by Roth, one obtains the claim. (This is very close to the scheme of ")#link("http://www.ams.org/mathscinet-getitem?mr=1844079")[#text("Gowers’ proof")]#text(".)")

#text("Technically, one might call this the shortest proof of Szemerédi’s theorem in the literature (and would be something like the sixteenth such genuinely distinct proof, by our count), but that would be cheating quite a bit, primarily due to the fact that it assumes the inverse conjecture for the Gowers norm, our current proof of which is checking in at about 100 pages…")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/743ec659e95a03c26d192883fa7bbe7647704868ea113c827a627daa82ded8e0-dbc98e08ce176ef4ec67b629e09f1f3d2786817a4f2ebdb07194ca7cd341d047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2010/02/13/yet-another-proof-of-szemeredis-theorem/#comment-43621")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2010")])]

#text("Dear Terry, What kind of bounds follow from this proof?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/13/yet-another-proof-of-szemeredis-theorem/#comment-43623")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2010")])]

#text("It depends on the bounds one gets from the inverse conjecture for the Gowers norms.")

#text("For length 3 progressions, one has polynomial bounds in the U^2 inverse theorem from Fourier analysis, which eventually gives the usual Roth-type result that ")#mi("r_3(N) \\ll N / (\\log \\log N)^c")#text(" with this argument. For length 4 progressions, we have exponential bounds in the U^3 inverse theorem in its standard formulation, which moves the double log to a triple log; but it was observed by Gowers and Wolf that the proof of the U^3 inverse theorem gives a more complicated variant of this theorem which in some sense continues to have polynomial bounds, and which lets one recover log log type bounds for ")#mi("r_4(N)")#text(". For longer progressions, the inverse theorem bounds are terrible (tower exponential or worse; we haven’t tried to quantify this) and so at best one would get ")#mi("\\log_* N")#text(" type denominators, and probably worse. (But if one assumes polynomial bounds on the inverse conjecture in all dimensions, one should get back to log log type bounds, I think.)")

#text("There is another trick of Heath-Brown and Szemeredi which, in principle, removes another log, but even in the AP4 case this is a bit tricky to implement. Ben and I were able to do it in the finite field model, and could get half-way in the integer case (getting the somewhat strange bound ")#mi("r_4(N) \\ll N \\exp( - c \\sqrt{\\log \\log N} )")#text(" but are still working on finishing off the integer case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a1fc5b5751b962e0eaa33c46950720e44bae6e13c5c5bf6908505900bbdeff77-da7da91a4f1aa4858d5b55fec0e3f8587cccca6681b912e7a6ad3fd00b6ac162.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tamar Ziegler")]], [#link("https://terrytao.wordpress.com/2010/02/13/yet-another-proof-of-szemeredis-theorem/#comment-43622")[#strong[#text("Tamar Ziegler")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2010")])]

#text("Hi Terry,")

#text("In the ergodic world the derivation of Szemeredi’s theorem via nilsequences was done in a paper of ")#link("http://www.sciencedirect.com/science?_ob=ArticleURL&_udi=B6W9F-4ST45YB-2&_user=32321&_coverDate=09%2F10%2F2008&_rdoc=1&_fmt=high&_orig=search&_sort=d&_docanchor=&view=c&_acct=C000004038&_version=1&_urlVersion=0&_userid=32321&md5=59230d1b9ab93c6ef4c46fc22231251c ")[#text("Bergelson, Leibman and Lesigne")]#text(" (here is the ")#link("http://arxiv.org/abs/0710.4862")[#text(" arxiv link ")]#text("). They prove a Szemeredi type theorem for “intersective polynomials” – arithmetic progressions are a special case. Actually, their theorem is a nice example of a theorem for which one must use nilsequences.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/13/yet-another-proof-of-szemeredis-theorem/#comment-43624")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2010")])]

#text("Thanks Tammy! Yes, you are right, strictly speaking knowing the characteristic factor is not quite enough in itself, one still has to check recurrence on that factor using some nilmanifold equidistribution theory. In the case of linear recurrence, though, this would follow fairly quickly from Leibman’s version of Ratner’s theorem on nilmanifolds and the Hall-Petresco group machinery (I suppose this is already implicit in your thesis, for instance). I’ll modify the text accordingly.")

#text("One curious thing is that a step which is almost trivial in the infinitary world – the Furstenberg-Katznelson observation that recurrence is preserved by inverse limits – becomes remarkably difficult to replicate in the finitary world; in particular, in the finitary world one is always bedeviled by little errors that are small in L^2 norm, but not so small that they can’t be neglected immediately. So duplicating the ergodic theory proof of Szemeredi’s theorem in the finitary world turns out to be non-trivial. But using a density increment argument seems to be easier (even though it does not have an obvious ergodic theory counterpart).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/826a2728424b30ad8cc83000d2bfd8744edcd1bafba060e1c70b63281a0934f6-5e3de4a3d5bde314bee2c1b42ac7f851cee463773970099eaeb046cc61a7dd19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harrison")]], [#link("https://terrytao.wordpress.com/2010/02/13/yet-another-proof-of-szemeredis-theorem/#comment-43628")[#strong[#text("Harrison")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2010")])]

#text("“…and would be something like the sixteenth such genuinely distinct proof, by our count.”")

#text("I don’t know how tongue-in-cheek that statement is meant to be, but now I’m wondering how many “genuinely distinct proofs” there are. Obviously this depends on how fine your definition of “genuinely distinct” is, but the ones I can think of are (relatively broadly speaking):")

#text("1. Szemeredi’s original proof")#linebreak()#text(" 2. Furstenberg’s ergodic proof")#linebreak()#text(" 3. Furstenberg-Katznelson’s ergodic proof of DHJ")#linebreak()#text(" 4. Gowers’ Fourier-analytic/weak inverse conjecture proof")#linebreak()#text(" 5(*). Hypergraph regularity proof(s)")#linebreak()#text(" 6. The Polymath proof")#linebreak()#text(" 7. Austin’s Polymath-Furstenberg-Katznelson “hybrid” proof")#linebreak()#text(" 8. Your new proof via the Gowers inverse conjecture")#linebreak()#text(" and 9. The Bergelson-Leibman-Lesigne “ergodic inverse conjecture” proof, which I only just now learned about from this blog post.")

#text("I’m aware there are a couple of different proofs of hypergraph regularity, which is why it’s marked (*), but this is all I can think of. (Admittedly, I’m not an expert and don’t actually understand anything beyond maybe Szemeredi’s k=4 proof, but I like to think I’m a fairly informed amateur at least.) Are there other “genuinely different” methods apart from the ones listed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/13/yet-another-proof-of-szemeredis-theorem/#comment-43632")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2010")])]

#text("That’s getting close to an exhaustive list. Furstenberg-Katznelson’s ergodic proof of the multidimensional Szemeredi theorem is a little different from Furstenberg’s original proof (in particular, it makes explicit use of the multidimensional van der Waerden theorem, whereas Furstenberg’s original argument did not use van der Waerden explicitly (instead relying on a kind of colour focusing argument as a substitute).")

#text("Tim Austin has a separate proof of multidimensional Szemeredi at ")#link("http://arxiv.org/abs/0808.2267")[#text("http://arxiv.org/abs/0808.2267")]#text(" which is closely related to 7 but not the same.")

#text("I have a proof which finitises Furstenberg’s proof but also combines it with some aspects of Gowers’ proof.")

#text("The ergodic inverse conjecture has two separate proofs, one by Host-Kra and one by Ziegler. There is a paper of Bergelson-Host-Kra which also implicitly establishes Szemeredi’s theorem using the ergodic inverse conjecture, and which may have served as the inspiration for the subsequent paper of Bergelson-Leibman-Lesigne.")

#text("The hypergraph removal lemma (which implies Szemeredi) also has a number of proofs: Gowers, Nagle-Rodl-Schacht-Skokan, Ishigami, myself (finitarily), myself (infinitarily), Rodl-Schacht (infinitarily, via a more general property testing result), and myself and Austin (giving an alternate proof and generalisation of Rodl-Schacht). Of course they are all fairly closely related to each other.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/02/13/yet-another-proof-of-szemeredis-theorem/#comment-44020")[#strong[#text("Theorem 22: Szemeredi’s theorem « Theorem of the week")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2010")]

#text("[…] But still the story goes on. A few years later, several people (such as Nagle-Rödl-Schacht and Gowers) found another approach, using a “hypergraph regularity lemma”. And one can also deduce the theorem from the density Hales-Jewett theorem, and so on… Tao has a list of approaches on his blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3205d8eeb9c554b4dd0cc3d073ee0fccb7caa8f5245405e7db9ef43dfd7e2b5-a4d99c4307912feff11c653ffa27243560eff8a237c725adfd34835995912cc1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Convergence and Recurrence of Z actions | I Can't Believe It's Not Random!")]], [#link("https://terrytao.wordpress.com/2010/02/13/yet-another-proof-of-szemeredis-theorem/#comment-256355")[#strong[#text("Convergence and Recurrence of Z actions | I Can't Believe It's Not Random!")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2013")])]

#text("[…] (6), it seems this has been done implicitly in many places (and maybe explicitly somewhere), see this post of Terry Tao (and the comments in particular). There is one more type of results about a single -action, and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/02/13/yet-another-proof-of-szemeredis-theorem/#comment-260752")[#strong[#text("Des progressions arithmetiques en dynamique: le théorème de Szemerédi | Dynamique à Jussieu")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2014")]

#text("[…] c’est à dire que admet une progression arithmétique arbitrairement longue. Une première preuve fut donnée par E. Szemerédi en 1975 puis une seconde fut publiée en 1977 par H.Furstenberg. Nous nous intéresserons à cette dernière qui a l’avantage de reposer sur un résultat de théorie ergodique que nous admettrons (de nombreuses autres demonstrations ont depuis été données, voir par exemple le blog de T.Tao. […]")
]
