// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/
// Converted to Typst by tao2typ: "2026-10-14T15:18:55.170043+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath8b, VII: Using the generalised Elliott-Halberstam hypothesis to enlarge the sieve support yet further", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath8b, VII: Using the generalised Elliott-Halberstam hypothesis to enlarge the sieve support yet further")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 January 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/")[#text("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is the seventh thread for the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8b project")]#text(" to obtain new bounds for the quantity")

#align(center)[#tao-fit-display[#mitex("H_m := \\liminf_{n \\rightarrow\\infty} (p_{n+m} - p_n),")]]

#text("either for small values of ")#mi("{m}")#text(" (in particular ")#mi("{m=1,2}")#text(") or asymptotically as ")#mi("{m \\rightarrow \\infty}")#text(". The previous thread may be found ")#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/")[#text("here")]#text(". The currently best known bounds on ")#mi("{H_m}")#text(" can be found at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("the wiki page")]#text(".")

#text("The current focus is on improving the upper bound on ")#mi("{H_1}")#text(" under the assumption of the generalised Elliott-Halberstam conjecture (GEH) from ")#mi("{H_1 \\leq 8}")#text(" to ")#mi("{H_1 \\leq 6}")#text(". Very recently, we have been able to exploit GEH more fully, leading to a promising new expansion of the sieve support region. The problem now reduces to the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1")]#text(" Does there exist a (not necessarily convex) polytope ")#mi("{R \\subset [0,2]^3}")#text(" with quantities ")#mi("{0 \\leq \\varepsilon_1,\\varepsilon_2,\\varepsilon_3 \\leq 1}")#text(", and a non-trivial square-integrable function ")#mi("{F: {\\bf R}^3 \\rightarrow {\\bf R}}")#text(" supported on ")#mi("{R}")#text(" such that")

#list(
[#mi("{R + R \\subset \\{ (x,y,z) \\in [0,4]^3: \\min(x+y,y+z,z+x) \\leq 2 \\},}")],
[#mi("{\\int_0^\\infty F(x,y,z)\\ dx = 0}")#text(" when ")#mi("{y+z \\geq 1+\\varepsilon_1}")#text(";")],
[#mi("{\\int_0^\\infty F(x,y,z)\\ dy = 0}")#text(" when ")#mi("{x+z \\geq 1+\\varepsilon_2}")#text(";")],
[#mi("{\\int_0^\\infty F(x,y,z)\\ dz = 0}")#text(" when ")#mi("{x+y \\geq 1+\\varepsilon_3}")#text(";")]
)

#text("and such that we have the inequality")

#align(center)[#tao-fit-display[#mitex("\\int_{y+z \\leq 1-\\varepsilon_1} (\\int_{\\bf R} F(x,y,z)\\ dx)^2\\ dy dz")]]

#align(center)[#tao-fit-display[#mitex("+ \\int_{z+x \\leq 1-\\varepsilon_2} (\\int_{\\bf R} F(x,y,z)\\ dy)^2\\ dz dx")]]

#align(center)[#tao-fit-display[#mitex("+ \\int_{x+y \\leq 1-\\varepsilon_3} (\\int_{\\bf R} F(x,y,z)\\ dz)^2\\ dx dy")]]

#align(center)[#tao-fit-display[#mitex("> 2 \\int_R F(x,y,z)^2\\ dx dy dz?")]]
]

#text("An affirmative answer to this question will imply ")#mi("{H_1 \\leq 6}")#text(" on GEH. We are “within two percent” of this claim; we cannot quite reach ")#mi("{2}")#text(" yet, but have got as far as ")#mi("{1.962998}")#text(". However, we have not yet fully optimised ")#mi("{F}")#text(" in the above problem. In particular, the simplex")

#align(center)[#tao-fit-display[#mitex("R = \\{ (x,y,z) \\in [0,2]^3: x+y+z \\leq 3/2 \\}")]]

#text("is now available, and should lead to some noticeable improvement in the numerology.")

#text("There is also a ")#emph[#text("very")]#text(" slim chance that the twin prime conjecture is now provable on GEH. It would require an affirmative solution to the following problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 2")]#text(" Does there exist a (not necessarily convex) polytope ")#mi("{R \\subset [0,2]^2}")#text(" with quantities ")#mi("{0 \\leq \\varepsilon_1,\\varepsilon_2 \\leq 1}")#text(", and a non-trivial square-integrable function ")#mi("{F: {\\bf R}^2 \\rightarrow {\\bf R}}")#text(" supported on ")#mi("{R}")#text(" such that")

#list(
[#mi("{R + R \\subset \\{ (x,y) \\in [0,4]^2: \\min(x,y) \\leq 2 \\}}")

#align(center)[#tao-fit-display[#mitex("= [0,2] \\times [0,4] \\cup [0,4] \\times [0,2],")]]],
[#mi("{\\int_0^\\infty F(x,y)\\ dx = 0}")#text(" when ")#mi("{y \\geq 1+\\varepsilon_1}")#text(";")],
[#mi("{\\int_0^\\infty F(x,y)\\ dy = 0}")#text(" when ")#mi("{x \\geq 1+\\varepsilon_2}")#text(";")]
)

#text("and such that we have the inequality")

#align(center)[#tao-fit-display[#mitex("\\int_{y \\leq 1-\\varepsilon_1} (\\int_{\\bf R} F(x,y)\\ dx)^2\\ dy")]]

#align(center)[#tao-fit-display[#mitex("+ \\int_{x \\leq 1-\\varepsilon_2} (\\int_{\\bf R} F(x,y)\\ dy)^2\\ dx")]]

#align(center)[#tao-fit-display[#mitex("> 2 \\int_R F(x,y)^2\\ dx dy?")]]
]

#text("We suspect that the answer to this question is negative, but have not formally ruled it out yet.")

#text("For the rest of this post, I will justify why positive answers to these sorts of variational problems are sufficient to get bounds on ")#mi("{H_1}")#text(" (or more generally ")#mi("{H_m}")#text(").")

#metadata(none) <tao-bc049c7a0653f77181ad>

#heading(level: 1)[#strong[#text(" — 1. Crude sieve bounds — ")]]

#text("Let the notation be as in the ")#link("https://www.dropbox.com/s/16bei7l944twojr/newgap.pdf")[#text("Polymath8a paper")]#text(", thus we have an admissible tuple ")#mi("{(h_1,\\dots,h_k)}")#text(", a residue class ")#mi("{b\\ (W)}")#text(" with ")#mi("{b+h_i}")#text(" coprime to ")#mi("{W}")#text(" for all ")#mi("{i=1,\\dots,k}")#text(", and an asymptotic parameter ")#mi("{x}")#text(" going off to infinity. It will be convenient to use the notation")

#align(center)[#tao-fit-display[#mitex("\\log_x y := \\frac{\\log y}{\\log x}.")]]

#text("We let ")#mi("{I}")#text(" be the interval")

#align(center)[#tao-fit-display[#mitex("I := \\{ n \\in [x,2x]: n = b\\ (W) \\}")]]

#text("and for each fixed smooth compactly supported function ")#mi("{F: [0,+\\infty) \\rightarrow {\\bf R}}")#text(", we let ")#mi("{\\alpha_F: {\\bf Z} \\rightarrow {\\bf R}}")#text(" denote the divisor sum")

#align(center)[#tao-fit-display[#mitex("\\alpha_F(n) := \\sum_{d|n} \\mu(d) F(\\log_x d).")]]

#text("We wish to understand the correlation of various products of divisor sums on ")#mi("{I}")#text(". For instance, in ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")[#text("this previous blog post")]#text(", the asymptotic ")#metadata(none) <tao-ba4788b226aa8dc2e6dc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{n \\in I} \\prod_{i=1}^k \\alpha_{F_i}(n+h_i) \\alpha_{G_i}(n+h_i) = \\delta^k |I| ( \\prod_{i=1}^k \\int F^{\\prime}_i(t) G^{\\prime}_i(t)\\ dt + o(1) )")]]

#text("was established whenever one has the support condition ")#metadata(none) <tao-ed435d547bd1f76180a4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{i=1}^k S(F_i) + S(G_i) < 1")]]

#text("where ")#mi("{S(F) := \\sup \\{ x: F(x) \\neq 0 \\}}")#text(" is the outer edge of the support of ")#mi("{F}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\delta := \\frac{W}{\\phi(W) \\log x}.")]]

#text("We are now interested in understanding the asymptotics when ")#link(<tao-ed435d547bd1f76180a4>)[#text("(2)")]#text(" fails. We have a crude pointwise upper bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" Let ")#mi("{F: [0,+\\infty) \\rightarrow {\\bf R}}")#text(" be a fixed smooth compactly supported function. Then for any natural number ")#mi("{n}")#text(",")

#align(center)[#tao-fit-display[#tao-math("\\left|\\alpha_F(n)\\right| \\ll \\int_0^\\infty [ \\prod_{p|n} O( \\min( t \\log_x p, 1 ) ) ] \\frac{dt}{1+\\left|t\\right|^A}", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(". More generally, for any fixed number ")#mi("{F_1,\\ldots,F_j: [0,+\\infty) \\rightarrow {\\bf R}}")#text(" of fixed smooth compactly supported functions, one has ")#metadata(none) <tao-d73d3e7a7e1d181671a5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|\\alpha_{F_1}(n)\\right| \\dots \\left|\\alpha_{F_j}(n)\\right| \\ll \\int_0^\\infty [ \\prod_{p|n} O( \\min( t \\log_x p, 1 ) ) ] \\frac{dt}{1+t^A}", block: true)]]
]

#emph[#text("Proof:")]#text(" We extend ")#mi("{F}")#text(" smoothly to all of ")#mi("{{\\bf R}}")#text(" as a compactly supported function, and write the Fourier expansion")

#align(center)[#tao-fit-display[#mitex("F(x) = \\int_{\\bf R} \\hat F(t) e^{-ixt}\\ dt")]]

#text("for some rapidly decreasing function ")#mi("{\\hat F(t)}")#text(". Then")

#tao-aligned(keep: true)[


#tao-math("\\alpha_F(n)  & = \\int_{\\bf R} \\hat F(t) \\sum_{d|n} \\mu(d) \\exp( - i t \\log_x p )\\ dt", block: true)



#tao-math(" & = \\int_{\\bf R} \\hat F(t) \\prod_{p|n} (1 - \\exp( - i t \\log_x p )\\ dt.", block: true)
]

#text("Taking absolute values, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\alpha_F(n)\\right| \\leq \\int_{\\bf R} |\\hat F(t)| \\prod_{p|n} |1 - \\exp( - i t \\log_x p|\\ dt.", block: true)]]

#text("Since ")#tao-math("{|1 - \\exp( - i t \\log_x p| \\ll \\min( \\left|t\\right| \\log_x p, 1 )}", block: false)#text(", the first claim now follows from the rapid decrease of ")#mi("{\\hat F}")#text(". To prove the second claim, we use the first claim to bound the left-hand side of ")#link(<tao-d73d3e7a7e1d181671a5>)[#text("(3)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty \\dots \\int_0^\\infty [\\prod_{p|n} O( \\prod_{i=1}^j \\min( t_i \\log_x p, 1 ) )] \\frac{dt_1 \\dots dt_j}{\\prod_{i=1}^j (1+t_i^A)}.")]]

#text("Bounding")

#align(center)[#tao-fit-display[#mitex("\\prod_{i=1}^j \\min( t_i \\log_x p, 1 ) \\ll \\min( (t_1+\\dots+t_j) \\log_x p, 1)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\prod_{i=1}^j (1+t_i^A) \\gg 1 + (t_1+\\dots+t_j)^A")]]

#text("the claim follows after a change of variables. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4")]#text(" For each ")#mi("{i=1,\\dots,k}")#text(", let ")#mi("{j_i \\geq 1}")#text(" and ")#mi("{m_i \\geq 0}")#text(" be fixed, and let ")#mi("{F_{i,1},\\dots,F_{i,j_i}: [0,+\\infty) \\rightarrow {\\bf R}}")#text(" be fixed smooth compactly supported functions. Then ")#metadata(none) <tao-b24d6d33736ecd5604a4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{n \\in I} \\prod_{i=1}^k (\\prod_{l=1}^{j_i} |\\alpha_{F_l}(n+h_i)| \\tau(n+h_i)^{m_i}) \\ll \\delta^k |I|.")]]

#text("We also have the variant ")#metadata(none) <tao-03e40e0198218881083f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{n \\in I} \\prod_{i=1}^k (\\prod_{l=1}^{j_i} |\\alpha_{F_l}(n+h_i)| \\tau(n+h_i)^{m_i}) 1_{p(n+h_s) \\leq x^\\epsilon} \\ll \\epsilon \\delta^k |I|.")]]

#text("for any ")#mi("{\\epsilon>0}")#text(" and ")#mi("{s=1,\\dots,k}")#text(", where ")#mi("{p(n)}")#text(" is the least prime factor of ")#mi("{n}")#text(".")
]

#text("The intuition here is that each of the ")#mi("{\\alpha_{F_l}(n+h_i)}")#text(" is mostly bounded and mostly supported on the ")#mi("{n}")#text(" for which ")#mi("{n+h_i}")#text(" is almost prime (so in particular ")#mi("{\\tau(n+h_i)}")#text(" is bounded), which has a density of about ")#mi("{\\delta}")#text(" in ")#mi("{I}")#text(".")

#emph[#text("Proof:")]#text(" From ")#link(<tao-d73d3e7a7e1d181671a5>)[#text("(3)")]#text(" (and bounding ")#mi("{\\tau(n)^{m_i} \\leq \\prod_{p|n} O(1)}")#text("), we can bound the left-hand side of ")#link(<tao-b24d6d33736ecd5604a4>)[#text("(4)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty \\dots \\int_0^\\infty \\sum_{n \\in I} \\prod_{i=1}^k \\prod_{p_i|n+h_i} O( \\min(t_i \\log_x p_i, 1) ) \\frac{dt_1 \\dots dt_k}{\\prod_{i=1}^k (1+t_i^A)}.")]]

#text("Let ")#mi("{c>0}")#text(" be a small fixed number (")#mi("{c=1/10k}")#text(" will do). For each ")#mi("{n+h_i}")#text(", we let ")#mi("{p_{i,1} \\leq \\ldots \\leq p_{i,\\Omega(n+h_i)}}")#text(" be the prime factors of ")#mi("{n+h_i}")#text(" in increasing order (counting multiplicity), and let ")#mi("{p_{i,1} \\dots p_{i,r_i}}")#text(" be the largest product of consecutive primes factors that is bounded by ")#mi("{x^c}")#text(". In particular, we see that")

#align(center)[#tao-fit-display[#mitex("p_{i,1} \\dots p_{i,r_i+1} \\geq x^c")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("p_{i,r_i+1} \\geq x^{c/(r_i+1)}")]]

#text("which in particular implies that ")#mi("{\\Omega(n+h_i) = O( r_i)}")#text(". This implies that")

#align(center)[#tao-fit-display[#mitex("\\prod_{p_i|n+h_i} O( \\min(t_i \\log_x p_i, 1) ) \\ll \\prod_{j=1}^{r_i} O( \\min( t_i \\log_x p_{i,j}, 1) ).")]]

#text("Now observe that ")#mi("{n+h_i = p_{i,1} \\dots p_{i,r_i} m}")#text(", where ")#mi("{m}")#text(" is ")#mi("{p_{i,r_i+1}}")#text("-rough (i.e. no prime factors less than ")#mi("{p_{i,r_i+1}}")#text("). In particular, it is ")#mi("{x^{c/(r_i+1)}}")#text("-rough. Thus we can bound the left-hand side of ")#link(<tao-b24d6d33736ecd5604a4>)[#text("(4)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\sum_{r_1,\\dots,r_k \\geq 0} \\sum_{p_{i,1} \\leq \\dots \\leq p_{i,r_i} \\forall i=1,\\dots,k} \\int_0^\\infty \\dots \\int_0^\\infty")]]

#align(center)[#tao-fit-display[#mitex("(\\prod_{i=1}^k \\prod_{j=1}^{r_i} O(\\min( t_i \\log_x p_{i,j}, 1)))")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I} \\prod_{i=1}^k 1_{n+h_i = p_{i,1} \\dots p_{i,r_i} m; m \\text{ is } x^{c/(r_i+1)}\\text{-rough}}")]]

#align(center)[#tao-fit-display[#mitex("\\frac{dt_1 \\dots dt_k}{\\prod_{i=1}^k (1+t_i^A)}.")]]

#text("By using a standard upper bound sieve (and taking ")#mi("{c}")#text(" small enough), the quantity")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I} \\prod_{i=1}^k 1_{n+h_i = p_{i,1} \\dots p_{i,r_i} m; m \\text{ is } x^{c/(r_i+1)}\\text{-rough}}")]]

#text("may be bounded by")

#align(center)[#tao-fit-display[#tao-math("\\delta^k \\frac{\\left|I\\right|}{\\prod_{i=1}^k \\prod_{j=1}^{r_i} p_{i,j}} \\prod_{i=1}^k O( r_i + 1 ).", block: true)]]

#text("Since ")#mi("{O(r_i+1) \\leq \\prod_{j=1}^{r_i} O(1)}")#text(", we can thus bound the left-hand side of ")#link(<tao-b24d6d33736ecd5604a4>)[#text("(4)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\delta^k |I| \\sum_{r_1,\\dots,r_k \\geq 0} \\sum_{p_{i,1} \\leq \\dots \\leq p_{i,r_i} \\forall i=1,\\dots,k} \\int_0^\\infty \\dots \\int_0^\\infty")]]

#align(center)[#tao-fit-display[#mitex("(\\prod_{i=1}^k \\prod_{j=1}^{r_i} O(\\frac{\\min( t_i \\log_x p_{i,j}, 1)}{p_{i,j}}))")]]

#align(center)[#tao-fit-display[#mitex("\\frac{dt_1 \\dots dt_k}{\\prod_{i=1}^k (1+t_i^A)}.")]]

#text("We can bound this by")

#align(center)[#tao-fit-display[#mitex("\\delta^k |I| \\sum_{r_1,\\dots,r_k \\geq 0} \\int_0^\\infty \\dots \\int_0^\\infty")]]

#align(center)[#tao-fit-display[#mitex("(\\prod_{i=1}^k \\frac{1}{r_i!} O(\\sum_{p \\leq x^c} \\frac{\\min( t_i \\log_x p, 1)}{p})^{r_i})")]]

#align(center)[#tao-fit-display[#mitex("\\frac{dt_1 \\dots dt_k}{\\prod_{i=1}^k (1+t_i^A)}")]]

#text("(strictly speaking one has some additional contribution coming from repeated primes ")#mi("{p_{i,j}=p_{i,j+1}}")#text(", but these can be eliminated in a number of ways, e.g. by restricting initially to square-free ")#mi("{n+h_i}")#text("). By Mertens’ theorem we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x^c} \\frac{\\min( t_i \\log_x p, 1)}{p} = O( 1 + \\log(1+t_i) ),")]]

#text("\\endand then by summing the series in ")#mi("{r_i}")#text(", we can bound the left-hand side of ")#link(<tao-b24d6d33736ecd5604a4>)[#text("(4)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\delta^k |I| \\int_0^\\infty \\dots \\int_0^\\infty")]]

#align(center)[#tao-fit-display[#mitex("\\prod_{i=1}^k \\exp( O( 1 + \\log(1+t_i) ) )")]]

#align(center)[#tao-fit-display[#mitex("\\frac{dt_1 \\dots dt_k}{\\prod_{i=1}^k (1+t_i^A)}.")]]

#text("which for ")#mi("{A}")#text(" large enough is ")#tao-math("{O(\\delta^k \\left|I\\right|)}", block: false)#text(" as required. This proves ")#link(<tao-b24d6d33736ecd5604a4>)[#text("(4)")]#text(".")

#text("The proof of ")#link(<tao-03e40e0198218881083f>)[#text("(5)")]#text(" is similar, except that (assuming ")#mi("{\\epsilon}")#text(" small, as we may) ")#mi("{r_s}")#text(" is forced to be at least ")#mi("{1}")#text(", and ")#mi("{\\log_x p_{s,1}}")#text(" is at most ")#mi("{\\epsilon}")#text(". From this we may effectively extract an additional factor of ")#mi("{\\min( \\epsilon t_s, 1 )}")#text(" (times a loss of ")#mi("{O(1+\\log(1+t_s))}")#text(" due to having to reduce ")#mi("{r_s!}")#text(" to ")#mi("{(r_s-1)!}")#text("), which gives rise to the additional gain of ")#mi("{\\epsilon}")#text(". ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 2. The generalised Elliott-Halberstam conjecture — ")]]

#text("We begin by stating the conjecture ")#mi("{GEH[\\theta]}")#text(" more formally, using (a slightly weaker form of) the version from this paper of ")#link("http://www.ams.org/mathscinet-getitem?mr=834613")[#text("Bombieri, Friedlander, and Iwaniec")]#text(". We use the notation from the ")#link("https://www.dropbox.com/s/16bei7l944twojr/newgap.pdf")[#text("Polymath8a paper")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 5 (GEH)")]#text(" Let ")#mi("{x^\\epsilon \\leq N,M \\leq x^{1-\\epsilon}}")#text(" for some fixed ")#mi("{\\epsilon>0}")#text(", be such that ")#mi("{NM \\sim x}")#text(", and let ")#mi("{\\alpha, \\beta}")#text(" be coefficient sequences at scale ")#mi("{N,M}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\lessapprox x^\\theta} \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\alpha * \\beta; a\\ (q))\\right| \\ll x \\log^{-A} x", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(".")
]

#text("We use GEH to refer to the assertion that ")#mi("{GEH[\\theta]}")#text(" holds for all ")#mi("{0 < \\theta < 1}")#text(". As ")#link("http://www.ams.org/mathscinet-getitem?mr=422179")[#text("shown by Motohashi")]#text(", a modification of the proof of the Bombieri-Vinogradov theorem shows that ")#mi("{GEH[\\theta]}")#text(" is true for ")#mi("{0 < \\theta < 1/2}")#text(". (It is possible that some modification of the arguments of Zhang give some weak version of GEH for some ")#mi("{\\theta}")#text(" slightly above ")#mi("{1/2}")#text(", but we will not focus on that topic here.)")

#text("For our purposes, we will need to apply GEH to functions supported on products of ")#mi("{r}")#text(" primes for a fixed ")#mi("{r}")#text(" (generalising the von Mangoldt function, which is the focus of the Elliott-Halberstam conjecture EH). More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" Assume ")#mi("{GEH[\\theta]}")#text(" holds. Let ")#mi("{r \\geq 1}")#text(" and ")#mi("{\\epsilon>0}")#text(" be fixed, let ")#mi("{\\Delta_{r,\\epsilon} := \\{ (t_1,\\dots,t_r) \\in [\\epsilon,1]^r: t_1 \\leq \\dots \\leq t_r; t_1+\\dots+t_r=1\\}}")#text(", and let ")#mi("{F: \\Delta_{r,\\epsilon} \\rightarrow {\\bf R}}")#text(" be a fixed smooth function. Let ")#mi("{\\tilde F: {\\bf N} \\rightarrow {\\bf R}}")#text(" be the function defined by setting")

#align(center)[#tao-fit-display[#mitex("\\tilde F(n) := F( \\log_n p_i, \\dots, \\log_n p_r)")]]

#text("whenever ")#mi("{n=p_1 \\dots p_k}")#text(" is the product of ")#mi("{r}")#text(" distinct primes ")#mi("{p_1 < \\dots < p_r}")#text(" with ")#mi("{p_1 \\geq x^\\epsilon}")#text(" for some fixed ")#mi("{\\epsilon>0}")#text(", and ")#mi("{\\tilde F(n)=0}")#text(" otherwise. Then")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\lessapprox x^\\theta} \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\tilde F; a\\ (q))\\right| \\ll x \\log^{-A} x", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(".")
]

#text("Remark: it may be possible to get some version of this proposition just from EH using ")#link("http://www.ams.org/mathscinet-getitem?mr=491570")[#text("Bombieri’s asymptotic sieve")]#text(".")

#emph[#text("Proof:")]#text(" (Sketch) This is a standard partitioning argument (not sure where it appears first, though). We choose a fixed ")#mi("{A^{\\prime}>0}")#text(" that is sufficiently large depending on ")#mi("{A}")#text(". We can decompose the primes from ")#mi("{x^\\epsilon}")#text(" to ")#mi("{x}")#text(" into ")#mi("{O( \\log^{A^{\\prime}+1} x)}")#text(" intervals ")#mi("{[y, (1+\\log^{-A} x) y]}")#text(". This splits ")#mi("{\\tilde F}")#text(" into ")#mi("{O( \\log^{rA^{\\prime}+r} x)}")#text(" pieces, depending on which intervals the ")#mi("{p_i}")#text(" lie in. The contribution when two primes lie in the same interval, or when the products of the specified intervals touches the boundary of ")#mi("{[x,2x]}")#text(", can be shown to be negligible by crude divisor function estimates if ")#mi("{A^{\\prime}}")#text(" is large enough (a similar argument appears in the Polymath8a paper), basically because there are only ")#mi("{O( \\log^{(r-1)A^{\\prime}+r-1} x)}")#text(" such terms, and each one contributes ")#mi("{O( x \\log^{-rA^{\\prime}+O(1)} x)}")#text(" to the total. For the remaining pieces, one can approximate ")#mi("{\\tilde F}")#text(" by a constant, up to errors which can also be shown to be negligible by crude estimates for ")#mi("{A^{\\prime}}")#text(" large enough (each term contributes ")#mi("{O( x \\log^{-(r+1)A^{\\prime}+O(1)} x)}")#text("), and then ")#mi("{\\tilde F}")#text(" can be modeled by a convolution of ")#mi("{r}")#text(" coefficient sequences at various scales between ")#mi("{x^\\epsilon}")#text(" and ")#mi("{x}")#text(", at which point one can use GEH to conclude. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 7")]#text(" Assume ")#mi("{GEH[\\theta]}")#text(" holds for some ")#mi("{0 < \\theta < 1}")#text(". Let ")#mi("{r\\geq 1}")#text(" and ")#mi("{\\epsilon>0}")#text(" be fixed, let ")#mi("{F: \\Delta_{r,\\epsilon} \\rightarrow {\\bf R}}")#text(" be fixed and smooth, and let ")#mi("{\\tilde F}")#text(" be as in the previous proposition. Let ")#mi("{\\nu_1: {\\bf N} \\rightarrow {\\bf R}}")#text(" be a divisor sum of the form")

#align(center)[#tao-fit-display[#mitex("\\nu_1(n) := \\sum_{d_2,\\ldots,d_k: d_i|n+h_i \\text{ for } i=2,\\dots,k} \\lambda_{d_2,\\dots,d_k}")]]

#text("where ")#mi("{\\lambda_{d_2,\\dots,d_k} = O( \\tau(d_2\\dots d_k)^{O(1)} )}")#text(" are coefficients supported on the range ")#mi("{d_2 \\dots d_k \\leq x^\\theta}")#text(". Then")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\in I} \\tilde F(n+h_1) \\nu_1(n)  & = (\\frac{1}{\\left|I\\right|} \\sum_{n \\in I} \\tilde F(n+h_1)) (\\sum_{n \\in I} \\nu_1(n))", block: true)



#tao-math(" & + O( x \\log^{-A} x)", block: true)
]

#text("for any fixed ")#mi("{A>0}")#text(".")

#text("Similarly for permutations of the ")#mi("{h_1,\\dots,h_k}")#text(".")
]

#emph[#text("Proof:")]#text(" (Sketch) We can rearrange ")#mi("{\\sum_{n \\in I} \\tilde F(n+h_1) \\nu_1(n)}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_2,\\dots,d_k: d_2 \\dots d_k \\leq x^\\theta} \\lambda_{d_2,\\dots,d_k} (\\sum_{n \\in I: n = -h_i\\ (d_i) \\text{ for } i=2,\\dots,k} \\tilde F(n+h_1) ).")]]

#text("Using the previous proposition, and the Chinese remainder theorem, we may approximate ")#mi("{\\sum_{n \\in I: n = -h_i\\ (d_i) \\text{ for } i=2,\\dots,k} \\tilde F(n+h_1)}")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\phi([d_2,\\dots,d_k])} \\sum_{n \\in I} \\tilde F(n+h_1)")]]

#text("plus negligible errors (here we need the crude bounds on ")#mi("{\\lambda_{d_2,\\dots,d_k}}")#text(" and some standard bounds on the divisor function), thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I} \\tilde F(n+h_1) \\nu_1(n) = (\\sum_{n \\in I} \\tilde F(n+h_1)) (\\sum_{d_2,\\dots,d_k} \\frac{\\lambda_{d_2,\\dots,d_k}}{\\phi([d_2,\\dots,d_k])} + O( x \\log^{-A} x).")]]

#text("A similar argument gives")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\in I} \\nu_1(n) = \\left|I\\right| (\\sum_{d_2,\\dots,d_k} \\frac{\\lambda_{d_2,\\dots,d_k}}{\\phi([d_2,\\dots,d_k])} + O( x \\log^{-A} x),", block: true)]]

#text("and the claim follows by combining the two assertions. ")#mi("\\Box")

#text("Next, from ")#link("https://terrytao.wordpress.com/2013/12/11/mertens-theorems/")[#text("Mertens’ theorem")]#text(" one easily verifies that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I} \\tilde F(n+h_1) = \\delta |I| (\\int_{\\Delta_{r,\\epsilon}} \\frac{F(t_1,\\dots,t_r)}{t_1 \\dots t_r} + o(1))")]]

#text("where ")#mi("{\\delta := \\frac{W}{\\phi(W)\\log x}}")#text(" is the expected density of primes in ")#mi("{I}")#text(", and the measure on ")#mi("{\\Delta_{r,\\epsilon}}")#text(" is the one induced from Lebesgue measure on the first ")#mi("{r-1}")#text(" coordinates ")#mi("{t_1,\\dots,t_{r-1}}")#text(". (One could improve the ")#mi("{o(1)}")#text(" term to ")#mi("{O(\\log^{-A} x)}")#text(" here by using the prime number theorem, but it isn’t necessary for our analysis.)")

#text("Applying ")#link(<tao-ba4788b226aa8dc2e6dc>)[#text("(1)")]#text(", we thus have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 8")]#text(" ")#metadata(none) <tao-c7c25cf63498ff73b179>#text(" Assume ")#mi("{GEH[\\theta]}")#text(" holds for some ")#mi("{0 < \\theta < 1}")#text(". Let ")#mi("{r\\geq 1}")#text(" and ")#mi("{\\epsilon>0}")#text(" be fixed, let ")#mi("{F: \\Delta_{r,\\epsilon} \\rightarrow {\\bf R}}")#text(" be fixed and smooth, and let ")#mi("{\\tilde F}")#text(" be as in the previous proposition. For ")#mi("{i=2,\\dots,k}")#text(", let ")#mi("{F_i,G_i: [0,+\\infty) \\rightarrow {\\bf R}}")#text(" be smooth compactly supported functions with ")#mi("{\\sum_{i=2}^k S(F_i)+S(G_i) < \\theta}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I} \\tilde F(n+h_1) \\prod_{i=2}^k \\alpha_{F_i}(n+h_i) \\alpha_{G_i}(n+h_i) = \\delta^k |I| (X_1 \\dots X_k + o(1))")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("X_1 := \\int_{\\Delta_{r,\\epsilon}} \\frac{F(t_1,\\dots,t_r)}{t_1\\dots t_r}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("X_i := \\int_0^\\infty F^{\\prime}_i(t) G^{\\prime}_i(t)\\ dt")]]

#text("for ")#mi("{i=2,\\dots,k}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 3. Some integration identities — ")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9")]#text(" ")#metadata(none) <tao-549ce58984289d8f0391>#text(" Let ")#mi("{f: [0,a] \\rightarrow {\\bf R}}")#text(" be a smooth function. Then")

#align(center)[#tao-fit-display[#mitex("\\int_0^a f^{\\prime}(t)^2\\ dt = \\frac{1}{a} (\\partial^{(a)} f(0))^2 + \\int_{t+u \\leq a; t,u \\geq 0}(\\partial^{(u)} f^{\\prime}(t))^2 \\frac{dt du}{a}")]]

#text("where ")#mi("{\\partial^{(u)} f(t) := f(t+u) - f(t)}")#text(".")
]

#emph[#text("Proof:")]#text(" Making the change of variables ")#mi("{v := u+t}")#text(", the integral ")#mi("{\\int_{t+u \\leq a; t,u \\geq 0} (\\partial^{(u)} f^{\\prime}(t))^2 \\frac{dt du}{a}}")#text(" can be written as")

#align(center)[#tao-fit-display[#mitex("\\int_{0 \\leq t \\leq v \\leq a} (f^{\\prime}(v)-f^{\\prime}(t))^2 \\frac{dt dv}{a}")]]

#text("which by symmetry is equal to")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\int_0^a \\int_0^a (f^{\\prime}(v)-f^{\\prime}(t))^2 \\frac{dt dv}{a}")]]

#text("which after expanding out the square and using symmetry is equal to")

#align(center)[#tao-fit-display[#mitex("\\int_0^a f^{\\prime}(t)^2\\ dt - \\frac{1}{a} (\\int_0^a f^{\\prime}(t)\\ dt)^2")]]

#text("and the claim follows from the fundamental theorem of calculus. ")#mi("\\Box")

#text("Iterating this lemma ")#mi("{k}")#text(" times, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_0^a f^{\\prime}(t)^2\\ dt = \\sum_{i=1}^{k-1} \\int_{u_1+\\dots+u_i = a; u_1,\\dots,u_i \\geq 0}")]]

#align(center)[#tao-fit-display[#mitex("\\frac{(\\partial^{(u_1)} \\dots \\partial^{(u_i)} f(0))^2}{a(a-u_1) \\dots (a-u_1-\\dots-u_{i-1})}")]]

#align(center)[#tao-fit-display[#mitex("+ \\int_{u_1+\\dots+u_k+t \\leq a; u_1,\\dots,u_k,t \\geq 0} (\\partial^{(u_1)} \\dots \\partial^{(u_k)} f^{\\prime}(t))^2")]]

#align(center)[#tao-fit-display[#mitex("\\frac{dt du_1 \\dots du_{k-1}}{a(a-u_1) \\dots (a-u_1-\\dots-u_{k-1})}")]]

#text("for any ")#mi("{k \\geq 1}")#text(", where the first integral is integrated using ")#mi("{du_1 \\dots du_{i-1}}")#text(". In particular, discarding the final term (which is non-negative) and then letting ")#mi("{k \\rightarrow \\infty}")#text(", we obtain the inequality ")#metadata(none) <tao-80d078c7dc84b0746fb0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{i=1}^\\infty \\int_{u_1+\\dots+u_i = a; u_1,\\dots,u_i \\geq 0} \\frac{(\\partial^{(u_1)} \\dots \\partial^{(u_i)} f(0))^2}{a(a-u_1) \\dots (a-u_1-\\dots-u_{i-1})}")]]

#align(center)[#tao-fit-display[#mitex("\\leq \\int_0^a f^{\\prime}(t)^2\\ dt.")]]

#text("In fact we have equality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10")]#text(" Let ")#mi("{f: [0,a] \\rightarrow {\\bf R}}")#text(" be smooth. Then ")#metadata(none) <tao-d0b064dacc9bd617892d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\sum_{i=1}^\\infty \\int_{u_1+\\dots+u_i = a; u_1,\\dots,u_i \\geq 0} \\frac{(\\partial^{(u_1)} \\dots \\partial^{(u_i)} f(0))^2}{a(a-u_1) \\dots (a-u_1-\\dots-u_{i-1})}")]]

#align(center)[#tao-fit-display[#mitex("= \\int_0^a f^{\\prime}(t)^2\\ dt.")]]

#text("In particular, by depolarisation we have ")#metadata(none) <tao-43388e727df1f06a8103>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\sum_{i=1}^\\infty \\int_{u_1+\\dots+u_i = a; u_1,\\dots,u_i \\geq 0} \\frac{\\partial^{(u_1)} \\dots \\partial^{(u_i)} f(0) \\partial^{(u_1)} \\dots \\partial^{(u_i)} g(0)}{a(a-u_1) \\dots (a-u_1-\\dots-u_{i-1})}")]]

#align(center)[#tao-fit-display[#mitex("= \\int_0^a f^{\\prime}(t)g^{\\prime}(t)\\ dt")]]

#text("for smooth ")#mi("{f,g: [0,a] \\rightarrow {\\bf R}}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\epsilon>0}")#text(" be a small quantity, and write")

#align(center)[#tao-fit-display[#mitex("X_0 := \\int_0^a f^{\\prime}(t)^2\\ dt.")]]

#text("From Lemma ")#link(<tao-549ce58984289d8f0391>)[#text("9")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("X_0 = Y_1 + Z_1 + X_1")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("Y_1  & := \\frac{1}{a} (\\partial^{(a)} f(0))^2", block: true)



#tao-math("Z_1  & := \\int_{u_1+t \\leq a; 0 \\leq u_1 \\leq \\epsilon; t \\geq 0} (\\partial^{(u_1)} f^{\\prime}(t))^2 \\frac{dt du_1}{a}", block: true)



#tao-math("X_1  & := \\int_{u_1+t \\leq a; u_1 \\geq \\epsilon; t \\geq 0} (\\partial^{(u_1)} f^{\\prime}(t))^2 \\frac{dt du_1}{a}.", block: true)
]

#text("From another application of Lemma ")#link(<tao-549ce58984289d8f0391>)[#text("9")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("X_1 = Y_2 + Z_2 + X_2")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("Y_2  & := \\int_{u_1+u_2= a; u_1 \\geq \\epsilon; u_2 \\geq 0} (\\partial^{(u_1)} \\partial^{(u_2)} f(0))^2 \\frac{du_1}{a(a-u_1)}", block: true)



#tao-math("Z_2  & := \\int_{u_1+u_2+t \\leq a; u_1 \\geq \\epsilon; 0 \\leq u_2 \\leq \\epsilon; t \\geq 0} (\\partial^{(u_1)} \\partial^{(u_2)} f^{\\prime}(t))^2 \\frac{dt du_1 du_2}{a(a-u_1)}", block: true)



#tao-math("X_2  & := \\int_{u_1+u_2+t \\leq a; u_1,u_2 \\geq \\epsilon; t \\geq 0} (\\partial^{(u_1)} \\partial^{(u_2)} f^{\\prime}(t))^2 \\frac{dt du_1 du_2}{a(a-u_1)}.", block: true)
]

#text("Iterating this, we see that")

#align(center)[#tao-fit-display[#mitex("X_0 = Y_1+\\dots+Y_k + Z_1+\\dots+Z_k + X_k")]]

#text("for any ")#mi("{k \\geq 1}")#text(", where")

#tao-aligned(keep: true)[


#tao-math("Y_i  & := \\int_{u_1+\\dots+u_i =a; u_1,\\dots,u_{i-1} \\geq \\epsilon; u_i \\geq 0} (\\partial^{(u_1)} \\dots \\partial^{(u_i)} f(0))^2", block: true)



#tao-math("Z_i  & := \\int_{u_1+\\dots+u_i+t \\leq a; u_1,\\dots,u_{i-1} \\geq \\epsilon; 0 \\leq u_i \\leq \\epsilon; t \\geq 0}", block: true)
]

#align(center)[#tao-fit-display[#mitex("(\\partial^{(u_1)} \\dots \\partial^{(u_i)} f^{\\prime}(t))^2 \\frac{dt du_1 \\dots du_i}{a(a-u_1)\\dots(a-u_1-\\dots-u_{i-1})}")]]

#align(center)[#tao-fit-display[#mitex("X_i := \\int_{u_1+\\dots+u_i+t \\leq a; u_1,\\dots,u_i \\geq \\epsilon; t \\geq 0} (\\partial^{(u_1)} \\dots \\partial^{(u_i)} f^{\\prime}(t))^2")]]

#align(center)[#tao-fit-display[#mitex("\\frac{dt du_1 \\dots du_i}{a(a-u_1)\\dots(a-u_1-\\dots-u_{i-1})}.")]]

#text("If ")#mi("{k > 1/\\epsilon}")#text(", then ")#mi("{X_k}")#text(" vanishes, thus")

#align(center)[#tao-fit-display[#mitex("X_0 = Y_1+\\dots+Y_k + Z_1+\\dots+Z_k.")]]

#text("For ")#mi("{i \\geq 2}")#text(", we may rewrite ")#metadata(none) <tao-8b9ec864ab630b4be856>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("Z_i = \\int_{u+t \\leq a; 0 \\leq u\\leq \\epsilon; t \\geq 0} W_i(t,u)\\ dt du")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("W_i(t,u) := \\int_{u_1+\\dots+u_{i-1} \\leq a-t-u; u_1,\\dots,u_{i-1} \\geq \\epsilon}")]]

#align(center)[#tao-fit-display[#mitex("(\\partial^{(u_1)} \\dots \\partial^{(u_{i-1})} f_{t,u}(0))^2\\ \\frac{du_1 \\dots du_{i-1}}{a(a-u_1) \\dots (a-u_1-\\dots-u_{i-1})}")]]

#text("and ")#mi("{f_{t,u}(s) := \\partial^{(u)} f(s+t)}")#text(". By Fubini’s theorem, we have")

#align(center)[#tao-fit-display[#mitex("W_i(t,u) = \\int_0^{a-t-u} [\\int_{u_1+\\dots+u_{i-1} = b; u_1,\\dots,u_{i-1} \\geq \\epsilon}")]]

#align(center)[#tao-fit-display[#mitex("\\frac{(\\partial^{(u_1)} \\dots \\partial^{(u_{i-1})} f_{t,u}(0))^2}{a(a-u_1) \\dots (a-u_1-\\dots-u_{i-2})}] \\frac{db}{a-b}.")]]

#text("Discarding the constraints ")#mi("{u_1,\\dots,u_{i-1} \\geq \\epsilon}")#text(" and using ")#mi("{a-b \\geq u}")#text(" and ")#mi("{a \\geq b}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("W_i(t,u) \\leq \\frac{1}{u} \\int_0^{a-t-u} [\\int_{u_1+\\dots+u_{i-1} = b}")]]

#align(center)[#tao-fit-display[#mitex("\\frac{(\\partial^{(u_1)} \\dots \\partial^{(u_{i-1})} f_{t,u}(0))^2}{b(b-u_1) \\dots (b-u_1-\\dots-u_{i-2})}]\\ db.")]]

#text("Summing over ")#mi("{2 \\leq i \\leq k}")#text(" using ")#link(<tao-80d078c7dc84b0746fb0>)[#text("(6)")]#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=2}^k W_i(t,u) \\leq \\frac{1}{u} \\int_0^{a-t-u} \\int_0^b f_{t,u}^{\\prime}(s)^2\\ ds db;")]]

#text("since ")#mi("{f_{t,u}^{\\prime} = O_f(1)}")#text(" by the smoothness of ")#mi("{f}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=2}^k W_i(t,u) = O_f(1)")]]

#text("and thus by ")#link(<tao-8b9ec864ab630b4be856>)[#text("(9)")]

#align(center)[#tao-fit-display[#mitex("\\sum_{i=2}^k Z_i = O_f(\\epsilon).")]]

#text("Direct computation also shows that ")#mi("{Z_1 = O_f(\\epsilon)}")#text(", hence")

#align(center)[#tao-fit-display[#mitex("X_0 \\leq Y_1+\\dots+Y_k+O_f(\\epsilon)")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("X_0 \\leq \\sum_{i=1}^\\infty Y_i + O_f(\\epsilon).")]]

#text("But by the monotone convergence theorem, as ")#mi("{\\epsilon \\rightarrow 0}")#text(", ")#mi("{\\sum_{i=1}^\\infty Y_i}")#text(" converges to")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^\\infty \\int_{u_1+\\dots+u_i = a; u_1,\\dots,u_i \\geq 0} \\frac{(\\partial^{(u_1)} \\dots \\partial^{(u_i)} f(0))^2}{a(a-u_1) \\dots (a-u_1-\\dots-u_{i-1})}.")]]

#text("Thus we can complement ")#link(<tao-80d078c7dc84b0746fb0>)[#text("(6)")]#text(" with the matching upper bound, giving the claim. ")#mi("\\Box")

#text("We can rewrite the above identity using the following cute identity (which presumably has a name?)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11")]#text(" ")#metadata(none) <tao-1c2537a15ce2a4d34d9a>#text(" For any positive reals ")#mi("{t_1,\\dots,t_r}")#text(" with ")#mi("{r \\geq 1}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{t_1 \\dots t_r} = \\sum_{\\sigma \\in S_r} \\frac{1}{\\prod_{i=1}^r \\sum_{j=i}^r t_{\\sigma(j)}}")]]

#text("where ")#mi("{\\sigma}")#text(" ranges over the permutations of ")#mi("{\\{1,\\dots,r\\}}")#text(".")
]

#text("Thus for instance")

#tao-aligned(keep: true)[


#tao-math("\\frac{1}{t_1}  & = \\frac{1}{t_1}", block: true)



#tao-math("\\frac{1}{t_1 t_2}  & = \\frac{1}{(t_1+t_2) t_1} + \\frac{1}{(t_1+t_2) t_2}", block: true)



#tao-math("\\frac{1}{t_1 t_2 t_3}  & = \\frac{1}{(t_1+t_2+t_3)(t_2+t_3)t_3} + \\frac{1}{(t_1+t_2+t_3)(t_2+t_3)t_2}", block: true)



#tao-math(" & + \\frac{1}{(t_1+t_2+t_3)(t_1+t_3)t_3} + \\frac{1}{(t_1+t_2+t_3)(t_1+t_3)t_1}", block: true)



#tao-math(" & + \\frac{1}{(t_1+t_2+t_3)(t_1+t_2)t_1} + \\frac{1}{(t_1+t_2+t_3)(t_1+t_2)t_2}", block: true)
]

#text("and so forth.")

#emph[#text("Proof:")]#text(" We induct on ")#mi("{r}")#text(". The case ")#mi("{r=1}")#text(" is trivial. If ")#mi("{r>1}")#text(" and the claim has already been proven for ")#mi("{r-1}")#text(", then from induction hypothesis one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\sigma \\in S_r: \\sigma(1)=l} \\frac{1}{\\prod_{i=1}^r \\sum_{j=i}^r t_{\\sigma(j)}}")]]

#align(center)[#tao-fit-display[#mitex("= \\frac{1}{(t_1+\\dots+t_r) \\prod_{1 \\leq i \\leq r: i \\neq l} t_i}")]]

#text("for each ")#mi("{l=1,\\dots,r}")#text(". Summing over ")#mi("{l}")#text(", we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 12")]#text(" Let ")#mi("{f,g: [0,a] \\rightarrow {\\bf R}}")#text(" be smooth. Then")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^\\infty \\int_{u_1+\\dots+u_i = a; 0 \\leq u_1 \\leq \\dots \\leq u_i \\geq 0} \\frac{\\partial^{(u_1)} \\dots \\partial^{(u_i)} f(0) \\partial^{(u_1)} \\dots \\partial^{(u_i)} g(0)}{u_1 \\dots u_i}")]]

#align(center)[#tao-fit-display[#mitex("= \\int_0^a f^{\\prime}(t) g^{\\prime}(t)\\ dt.")]]
]

#emph[#text("Proof:")]#text(" Average ")#link(<tao-d0b064dacc9bd617892d>)[#text("(7)")]#text(" over permutations of the ")#mi("{u_1,\\dots,u_i}")#text(" and use Lemma ")#link(<tao-1c2537a15ce2a4d34d9a>)[#text("11")]#text(". ")#mi("\\Box")

#text("This gives us a variant of")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 13")]#text(" ")#text(" Assume ")#mi("{GEH[\\theta]}")#text(" holds for some ")#mi("{0 < \\theta < 1}")#text(". For ")#mi("{i=1,\\dots,k}")#text(", let ")#mi("{F_i,G_i: [0,+\\infty) \\rightarrow {\\bf R}}")#text(" be smooth compactly supported functions with ")#mi("{\\sum_{i=2}^k S(F_i)+S(G_i) < \\theta}")#text(". Then ")#metadata(none) <tao-82a4eda9cf6a2ac129a9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\sum_{n \\in I} \\prod_{i=1}^k \\alpha_{F_i}(n+h_i) \\alpha_{G_i}(n+h_i) = \\delta^k |I| (X_1 \\dots X_k + o(1))")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("X_i := \\int_0^1 F^{\\prime}_i(t) G^{\\prime}_i(t)\\ dt")]]

#text("for ")#mi("{i=1,\\dots,k}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\epsilon>0}")#text(". By ")#link(<tao-03e40e0198218881083f>)[#text("(5)")]#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\in I} \\prod_{i=1}^k \\alpha_{F_i}(n+h_i) \\alpha_{G_i}(n+h_i) 1_{p(n+h_1) \\leq x^\\epsilon} = O(\\epsilon \\delta^k \\left|I\\right| )", block: true)]]

#text("so by paying a cost of ")#tao-math("{O(\\epsilon \\delta^k \\left|I\\right|)}", block: false)#text(", we may restrict to ")#mi("{n+h_1}")#text(" which are ")#mi("{x^\\epsilon}")#text("-rough, and are thus of the form ")#mi("{p_1 \\dots p_r}")#text(" for some ")#mi("{r \\leq 1/\\epsilon}")#text(" and ")#mi("{x^\\epsilon < p_1 \\leq \\dots \\leq p_r}")#text(". For ")#mi("{n+h_1 = p_1 \\dots p_r}")#text(" (restricting to squarefree integers ")#mi("{n+h_1}")#text(" to avoid technicalities), we have")

#align(center)[#tao-fit-display[#mitex("\\alpha_{F_1}(n+h_1) = \\partial^{(\\log_{n+h_1} p_1)} \\dots \\partial^{(\\log_{n+h_1}p_r} F_1(0)")]]

#text("and similarly for ")#mi("{\\alpha_{G_1}(n+h_1)}")#text(". Using this and Corollary ")#link(<tao-c7c25cf63498ff73b179>)[#text("13")]#text(", we may write the left-hand side of ")#link(<tao-82a4eda9cf6a2ac129a9>)[#text("(10)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\delta^k |I| ( X_2 \\dots X_k \\sum_{1 \\leq r \\leq 1/\\epsilon} \\int_{\\Delta_{r,\\epsilon}} \\partial^{(t_1)} \\dots \\partial^{(t_r)} F_1(0) \\partial^{(t_1)} \\dots \\partial^{(t_r)} G_1(0) \\frac{dt_1 \\dots dt_r}{t_1 \\dots t_r}")]]

#align(center)[#tao-fit-display[#mitex("+ O(\\epsilon) + o(1) ).")]]

#text("Sending ")#mi("{\\epsilon \\rightarrow 0}")#text(" and using dominated convergence and Proposition ")#link(<tao-1c2537a15ce2a4d34d9a>)[#text("11")]#text(", we obtain the claim. ")#mi("\\Box")

#text("Taking linear combinations, we conclude the usual “denominator” asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I} (\\sum_{d_i|n+h_i \\forall i=1,\\dots,k} \\mu(d_1) \\dots \\mu(d_k) F(\\log_x d_1,\\dots,\\log_x d_k))^2")]]

#align(center)[#tao-fit-display[#mitex("= \\delta^k |I| ( X + o(1) )")]]

#text("with")

#align(center)[#tao-fit-display[#mitex("X = \\int_{[0,1]^k} F_{1,\\dots,k}(t_1,\\dots,t_k)^2\\ dt_1\\dots dt_k")]]

#text("whenever ")#mi("{F: [0,+\\infty)^k \\rightarrow {\\bf R}}")#text(" is supported on a polytope ")#mi("{R}")#text(" (not necessarily convex) with")

#align(center)[#tao-fit-display[#mitex("R+R \\subset \\bigcup_{i=1}^k \\{ (t_1,\\dots,t_k): \\sum_{j \\neq i} t_j < \\theta \\},")]]

#text("and is a finite linear combination of tensor products ")#mi("{F_1(t_1) \\dots F_k(t_k)}")#text(" of smooth compactly supported functions. We use this as a replacement for the denominator estimate in ")#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/")[#text("this previous blog post")]#text(", we obtain the criteria described above.")

#heading(level: 1)[#text("Comments (117)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268582")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("In the second product above lemma 4, the upper index should be ")#mi("j")#text(". ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268630")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("I think in both Problem 1 and Problem 2, the range integrated over that refers to epsilon2 should be “<=\", not \"<\". At least, that's what it was in Problem 1 in the previous post.")

#emph[#text("[The two are equivalent, since the difference has measure zero – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9baa737b3fce740a97ad2ce02a0a5c04a06a01e6991a661ef7c04da2a91ef3c-cbffa0137e4686517be753555ed93da24cb95028b052932817b000c1a5f7a89d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonas KAHN")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268631")[#strong[#text("Jonas KAHN")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("Probably not useful since it cannot be pushed further, but it’s obvious we may find F as close to 2 as we may want in Problem 1 (in Problem 2 as well for that matter):")#linebreak()#text(" Take ")#mi("\\epsilon")#text(". Define ")#mi("F")#text(" on the three “rods” ")#mi("[0, \\epsilon]^{2} \\times [0, 2 - 2\\epsilon]")#text(" and its symmetries as:")#linebreak()#text(" * if ")#mi("z \\geq \\epsilon")#text(": ")#mi("F(x,y,z) = 1")#text(" if ")#mi("(x,y) \\in [0,\\epsilon/2]^2 \\cup   [\\epsilon/2, \\epsilon]^2")#text(", and ")#mi("F(x,y,z) = -1")#text(" if ")#mi("(x,y) \\in [0,\\epsilon/2]\\times [\\epsilon/2, \\epsilon] \\cup  [\\epsilon/2, \\epsilon] \\times [0,\\epsilon/2]")#text(".")#linebreak()#text(" * symmetric definition on the other rods.")#linebreak()#text(" * ")#mi("F(x,y,z) = 0")#text(" on the small cube ")#mi("[0, \\epsilon]^3")#text(".")#linebreak()#text(" We get factor ")#mi("2 - 3 \\epsilon")#text(".")#linebreak()#text(" (We could also use the sum of the functions on the small cube, with no big difference, and it could be seen as a sum of three iid variables on this cube.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce25dfc4d1785dc990327a1416f9b473aaba3ee15f1a556911008424070b0a44-31c276ad2a192973fde0af09c31d197b15cf813167979390e914ef20b396c5ef.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of polikimre")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268675")[#strong[#text("polikimre")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("My background is numerical optimization and not number theory, but I was wondering if Problems 1 and 2 could be discretized and solved numerically. Define a fine grid on the cube, define F on the grid points and interpolate either piecewise or with any other method. R is defined implcitly as the support of F. Then convert all constraints into constraints on the pointwise values. It wouldn’t be a small problem, but things are mostly quadratic or cubic so it might be tractable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268709")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("It seems to me (naively, as there’s a lot of this I’m not understanding) that some global optimization heuristic such as Simulated Annealing might be applicable to the formulation you describe (I’m guessing that in addition to the scads of pointwise F values, the 3 epsilons would need to be explicit optimization parameters). It would be interesting to hear someone with the big picture weigh in.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9baa737b3fce740a97ad2ce02a0a5c04a06a01e6991a661ef7c04da2a91ef3c-cbffa0137e4686517be753555ed93da24cb95028b052932817b000c1a5f7a89d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonas KAHN")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268685")[#strong[#text("Jonas KAHN")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("By the way, a ")#mi("R")#text(" strictly bigger than the simplex is available, too:")#linebreak()#text(" ")#mi("R = \\{2x + y + z \\leq 2; x + 2y + z \\leq 2\\} \\cup   \\{x + 2y + z \\leq 2; x + y + 2z \\leq 2\\} \\cup  \\{x + y + 2z \\leq 2; 2x + y + z \\leq 2\\}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268747")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("This is indeed an interesting new region to use, although it doesn’t quite strictly contain the simplex: ")#mi("(0.499, 0.499, 0.502)")#text(", for instance, is in the simplex but not in this region. With recent developments it may no longer be necessary to test out this polytope, but we can certainly keep it in reserve in case a problem develops with the simplex.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9baa737b3fce740a97ad2ce02a0a5c04a06a01e6991a661ef7c04da2a91ef3c-cbffa0137e4686517be753555ed93da24cb95028b052932817b000c1a5f7a89d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonas KAHN")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268748")[#strong[#text("Jonas KAHN")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("Right, even if the counter-example should be ")#mi("(0.501, 0.501, 0.498)")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268699")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("Is it possible to relax the polytope condition on ")#mi("R")#text(" to a (finite) union of disjoint polytopes ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268712")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("If not, couldn’t you just replace any solution based on a disjoint-polytope R, with an essentially equivalent one based on a single-polytope R by adding arbitrarily skinny umbilical cords?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268726")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("It seems that (instead of the polytope property) only ")#mi("R")#text(" measurability is really needed (the finite union of polytopes was stated only to simplify the optimization).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268744")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("This should be OK (and probably one can allow R to be any compact set, though there may be some technical issues regarding approximating F by smooth functions while staying supported in the interior of R and respecting all the marginal conditions).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268710")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("Does problem 2 indicates a method/idea to overcome the “parity problem” (under GEH)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268734")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("On the previous thread, James said “I’d be skeptical the parity barrier isn’t hiding somewhere.” I agree. I did a quick computation, using ")#mi("\\varepsilon_1=\\varepsilon_2")#text(" on the region ")#mi("\\{x+y\\leq 2; x,y\\geq 0\\}")#text(" and (if I didn’t make a mistake) the optimal value that pops out is exactly 2, for any epsilon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268756")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("That’s reassuring; if our calculations indicated we had somehow stumbled accidentally into a way to somehow sneak past the parity barrier, I would think it much more likely that there was an error in the calculation than that we had unwittingly defeated one of the most notorious barriers in analytic number theory. I agree with James that the barrier is still present, it’s just that we can’t quite see it right now; instead of having a solid iron door between us and the twin prime conjecture, we’ve now moved into a position where there is a dark corridor between us and the conjecture, but presumably the parity barrier is still lurking behind the darkness.")

#text("A bit more formally, we used to play exclusively with sieves ")#mi("\\nu(n)")#text(" which were anticorrelated with both the Mobius function ")#mi("\\mu(n)")#text(" and its shift ")#mi("\\mu(n+2)")#text(", which meant that weighted to ")#mi("\\nu(n)")#text(", the probability of n being prime is at most 1/2, and the probability that n+2 is at most 1/2, so one cannot force n and n+2 to both be prime just from “one-point correlations” on how likely n and n+2 are separately to be prime.")

#text("Now that we are moving beyond the unit cube, we are permitted to use sieves ")#mi("\\nu(n)")#text(" that correlate with ")#mi("\\mu(n)")#text(" and/or ")#mi("\\mu(n+2)")#text(". For instance, one extreme is to take ")#mi("\\nu(n) = \\Lambda(n)")#text(", in which case we have a 100% correlation with ")#mi("\\mu(n)")#text(" (and a 100% chance asymptotically for n to be prime), but no non-trivial control on the probability that n+2 is prime. Or one could take ")#mi("\\nu(n) = \\Lambda(n+2)")#text(", or some convex combination of ")#mi("\\Lambda(n)")#text(" and ")#mi("\\Lambda(n+2)")#text(". In none of these situations can we get “probability that n is prime” + “probability that n+2 is prime” to exceed 1, but it’s not clear whether there is a systematic obstruction that guarantees that this is impossible. As James points out, all the new sieves ")#mi("\\nu(n)")#text(" we play with should (conjecturally at least) still be anticorrelated with ")#mi("\\mu(n) \\mu(n+2)")#text(", but this by itself does not seem to block the possibility of a sieve ")#mi("\\nu(n)")#text(" for which n and n+2 both have (say) a 2/3 chance of being prime. (Consider for instance a scenario in which n and n+2 are both prime with probability 5/12, that n is prime and n+2 has an even number of prime factors with probability 1/4 and vice versa for n+2 and n, and finally n and n+2 both have an even number of prime factors with probability 1/12.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18fd74c0c5e50254b82392937715254d907e1158c29190a49d1feee642b5b0d3-c8b1f3c436a435581aa24f8881ce2e45621e3a01f277c09ff0bfafc9c90e9e2d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Axel Obermeier")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268774")[#strong[#text("Axel Obermeier")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("I think that there might be a mistake hiding in the derivation of Problem 2 (or in my calculations below) – otherwise I might have found an F/R-combination which satisfies Problem 2.")

#text("I should add that I am far out of my league as far as polymath8a/b is concerned, but I have been following it with interest and was intrigued by the apparent simplicity of Problem 2 (at least in terms of mathematical concepts involved). In a procrastination-induced rush of hubris, I tried to find an F/R combination, and it is with tremendous hesitation that I post this here – most probably I overlooked a condition or a factor somewhere, which collapses my very simplistic argument.")

#text("I have correspondingly double- and triple-checked my calculations, and still can’t believe my own lying eyes and calculations. Please excuse me wasting your time if a mistake is readily apparent nevertheless.")

#text("While I have seen how polymath8a in particular exploited the splitting of parameters into separate parts, the inherent symmetry of Problem 2 led me to start with ")#mi("\\epsilon_1=\\epsilon_2=\\epsilon")#text(" and ")#mi("F(x,y)=F(y,x)")#text(" and with the biggest possible ")#mi("R")#text(", namely $R=[0,1]\\times[0,2] \\cup [0,2]\\times[0,1]$.")

#text("Problem 2 is then equivalent to finding ")#mi("F")#text(" such that:")#linebreak()#text(" ")#mi("\\int_0^{1-\\epsilon} \\left( \\int_0^t F(t,y) dy \\right)^2 + \\left(\\int_t^2 F(x,t) dx\\right)^2 dt > \\int_R F(x,y)^2 dx dy")#linebreak()#text(" which is just the restriction of the problem to the lower part ")#mi("R_{x\\ge y}")#text(" of the L-shaped ")#mi("R")#text(".")

#text("Defining ")#mi("F")#text(" on ")#mi("R_{x\\ge y}")#text(" as ")#mi("\\frac{1}{2}")#text(" when ")#mi("0\\le y \\le \\frac{1-\\epsilon}{2}")#text(" (second inequality is strict) and as ")#mi("-\\frac{1}{2}")#text(" when ")#mi("\\frac{1-\\epsilon}{2}\\le y \\le 1-\\epsilon")#text(", we see that the marginal conditions are satisfied, and integrating is easy:")

#text("The result of the left-hand side is ")#mi("(1-\\epsilon) - \\frac{1}{2}(1-\\epsilon)^2 + \\frac{5}{48}(1-\\epsilon)^3")#text(", whereas the right-hand side is ")#mi("\\frac{1}{2}(1-\\epsilon) + \\frac{1}{4}(1-\\epsilon)^2")#text(". Substracting the right from the left, we can see (by plotting or by an actual discussion of the curve) that the inequality holds for ")#mi("\\epsilon \\ge 0.255...")#text(" (of course, the root, as well as the maximum could easily be determined).")

#text("Fearing a mistake, I went back again to the original formulation and tried ")#mi("\\epsilon=0.5")#text(" for my F/R-combination, The first term on the left-hand side is then ")#mi("\\int_0^{\\frac{1}{4}} \\left(\\int_0^2 \\frac{1}{2} dx \\right)^2 dy + \\int_{\\frac{1}{4}}^{\\frac{1}{2}} \\left( \\int_0^{\\frac{1}{4}} \\frac{1}{2} dx + \\int_{\\frac{1}{4}}^2 -\\frac{1}{2} dx\\right)^2 dy = \\frac{1}{4}+\\frac{1}{4}\\frac{4}{9}=\\frac{13}{36}")#text(".")

#text("For symmetry reasons, the second term is exactly the same. The right-hand side equals ")#mi("2\\frac{5}{4}\\frac{1}{4}=\\frac{10}{16}")#text(", and thus we have ")#mi("0.7222 = \\frac{13}{18} > \\frac{10}{16}=0.625")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18fd74c0c5e50254b82392937715254d907e1158c29190a49d1feee642b5b0d3-c8b1f3c436a435581aa24f8881ce2e45621e3a01f277c09ff0bfafc9c90e9e2d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Axel Obermeier")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268780")[#strong[#text("Axel Obermeier")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("Oh how I wish I could eat my words, obviously ")#mi("R+R \\subset ...")#text(" is not satisfied. Prof. Tao, you’re welcome to delete my comments (in fact I’d be very thankful).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268788")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("Axel, we’ve all made similar mistakes while working on this problem. (One of my early mistakes was forgetting the cross terms after squaring!) I’m just glad to see others join the “fray”. Keep it up!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18fd74c0c5e50254b82392937715254d907e1158c29190a49d1feee642b5b0d3-c8b1f3c436a435581aa24f8881ce2e45621e3a01f277c09ff0bfafc9c90e9e2d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Axel Obermeier")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268908")[#strong[#text("Axel Obermeier")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("@Pace Nielson, thank you for the encouragement – I shouldn’t have tried to do this in the middle of the night (MEST here).")

#text("Similarly, I should probably stop digging myself into a deeper hole, but I couldn’t keep myself from tinkering a bit more (in the process finding another error that I’d made before – the equivalence above is wrong).")

#text("So, if I may be allowed another try:")#linebreak()#text(" Define ")#mi("R:=\\left([0,\\frac{2}{3}]\\times[0,\\frac{4}{3}]\\cup[0,\\frac{4}{3}]\\times[0,\\frac{2}{3}]\\right)\\setminus[0,\\frac{1}{3}]^2")#text(", which, as a subset of ")#mi("\\{(x,y):x+y\\le 2\\}")#text(" satisfies the Minkowski-sum condition ")#mi("R+R \\subset ...")#text(".")

#text("Again, set ")#mi("\\epsilon_1=\\epsilon_2=\\epsilon")#text(" and define ")#mi("F")#text(" on ")#mi("R_{x\\ge y}")#text(" as ")#mi("\\sqrt{x}")#text(" for ")#mi("0\\le y \\le \\frac{1-\\epsilon}{2}\\frac{2}{3}=\\frac{1}{3}(1-\\epsilon)")#text(" (second ineq. strict) and as ")#mi("-\\sqrt{x}")#text(" for ")#mi("\\frac{1}{3}(1-\\epsilon) \\le y \\le \\frac{2}{3}(1-\\epsilon)")#text(". Extend to ")#mi("R_{x\\le y}")#text(" with ")#mi("F(x,y)=F(y,x)")#text(".")

#text("The marginal conditions are satisfied and we see that Problem 2 is equivalent to ")#mi("\\int_0^{1-\\epsilon} \\left(\\int_0^{\\frac{4}{3}} F(x,y) dx \\right)^2 dy > \\int_R F(x,y)^2 dx dy = 2 \\int_{R_{x\\ge y}} F(x,y)^2 dx dy")#text(" – due to symmetry the second term on the left-hand side is the same and we just divided by two.")

#text("The first integral actually only goes to ")#mi("\\frac{2}{3}(1-\\epsilon)")#text(" because the rest cancels in the same way as the marginal condition.")

#text("Putting this into Maple – I wanted to avoid making mistakes in the integration – the inequality seems to hold for ")#mi("\\epsilon\\ge 0.52...")#text(" (the actual discussion of the curve would be tedious).")

#text("The code (using z for ")#mi("\\epsilon")#text("):")#linebreak()#text(" n:=1/2")#linebreak()#text(" plot(int((int(x^n, x = (1-z)*(1/3) .. 4/3))^2, y = 0 .. (1-z)*(1/3))+int((int(y^n, x = 0 .. (1-z)*(1/3))-(int(y^n, x = (1-z)*(1/3) .. y))-(int(x^n, x = y .. 4/3)))^2, y = (1-z)*(1/3) .. 2/3*(1-z))-2*(int(int(x^(2*n), x = (1-z)*(1/3) .. 4/3), y = 0 .. (1-z)*(1/3))+int(int(x^(2*n), x = y .. 2/3*(1-z)), y = (1-z)*(1/3) .. 2/3*(1-z))), z = 0 .. 1)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18fd74c0c5e50254b82392937715254d907e1158c29190a49d1feee642b5b0d3-c8b1f3c436a435581aa24f8881ce2e45621e3a01f277c09ff0bfafc9c90e9e2d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Axel Obermeier")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268923")[#strong[#text("Axel Obermeier")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("Too excited again… Made a mistake in the integral limits which kills the inequality (second-to-last integral should go from x=y..4/3). Serves me right for trying to break the parity problem with stone-age methods…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39d042cd343763a0074f825ecdf61ade3a1f833c09d7322d7ed33b69d91748e0-004ee65ff1042e640b0bfa8bf9563704de056663a81b46994f471f2da9bfde76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bogdan")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268924")[#strong[#text("Bogdan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("The inequality does not hold, should be a mistake in your Maple code. In general, if the marginal conditions are satisfied with ")#mi("x>=1")#text(", ")#mi("y>=1")#text(" (as it is in your example), then I could take ")#mi("\\epsilon=0")#text(" and avoid ")#mi("\\epsilon")#text(" trick, but in this case (as far as I remember) there was a strict proof that such function cannot exist.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268732")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("It appears that Zeno’s paradox has fallen prey to James’ newest idea! If I haven’t made any mistakes, I get ")#mi("M\\geq 2.0009")#text(". I’ve now double checked all of the integrals (and in the process actually found an error from my previous computation, which was *lowering* the needed value). Those who want to check the details can look at the three documents:")

#text("1. A pdf listing all integrals involves, choices of epsilon, etc…: ")#link("http://www.math.byu.edu/~pace/BddGapsSize6.pdf")[#text("http://www.math.byu.edu/~pace/BddGapsSize6.pdf")]#linebreak()#text(" 2. The Mathematica notebook doing the computation: ")#link("http://www.math.byu.edu/~pace/Computation-BddGapsSize6.nb")[#text("http://www.math.byu.edu/~pace/Computation-BddGapsSize6.nb")]#linebreak()#text(" 3. Another Mathematica notebook, with nice pictures of the regions involved: ")#link("http://www.math.byu.edu/~pace/RegionPlots-BddGapsSize6.nb")[#text("http://www.math.byu.edu/~pace/RegionPlots-BddGapsSize6.nb")]

#text("If anyone finds an error, just let me know.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268746")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("This sounds like excellent news! I’ll try to confirm the polynomial decomposition at least. It looks like James has some independent code for this sort of thing, so hopefully we’ll get confirmation soon. The numbers seem to be reasonable though, and it sounds like you have a little bit of room in optimising the epsilons and degrees to make the value a little bigger, so we have a bit of cushion for numerical error etc. (Now that epsilon is the nice round value of 1/4, presumably we can find an F which is piecewise polynomial with rational coefficients and still gets above 2, so that we can work with exact arithmetic and not have to worry about roundoff error, at least.)")

#text("It’s interesting that epsilon has been slowly growing larger as we keep unlocking more regions of space to optimise over, but I guess this makes sense: the more room there is beyond ")#mi("{\\cal R}_k")#text(", the more profit one can make off of a large value of epsilon, thus offsetting the cost of shrinking the J integrals (which, intuitively, is a cost which is more or less insensitive to how much more room one has).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268749")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("I followed James’s lead from his code attached to his preprint. Just as he does, at the very end of my code all polynomial approximations are made to have rational coefficients. So the exact arithmetic part is being done.")

#text("On the increasing epsilon, I wonder if Eytan could do an analysis similar to the one he did before (for ")#mi("\\varepsilon\\in (1/2,1]")#text(") but for this larger simplex.")

#text("By the way, regarding unlocking space– that is what motivated me to break up (what I call in my notes) the ")#mi("F_{xyz}")#text(" region into the three pieces. After the split, the biggest piece (")#mi("T_{xyz}")#text(") appears in only one marginal condition.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268759")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("In the wiki page on the variational problem, Pace’s newest lower bound record (2.0009) for ")#mi("R = \\frac{3}{2} \\mathcal R_3")#text(" should be for ")#mi("M^{\\prime\\prime}_{3,\\epsilon, 2/3}")#text(" (i.e. for ")#mi("\\theta = 2/3")#text(" instead of ")#mi("\\theta = 1/2")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268765")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("Um – should it? Surely that subscript refers to the reciprocal of the edge-length of the cube that MUST bound the supported region, rather than the reciprocal of the edge-length of the smallest cube that actually bounds the region on which the calculation was done?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268767")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("Note that ")#mi("R")#text(" is at least ")#mi("(1/\\theta)\\mathcal R_3")#text(" (which for")#linebreak()#text(" ")#mi("\\theta = 1/2")#text(" is ")#mi("2 \\mathcal R_3")#text(" – which is larger than our ")#mi("R = (3/2) \\mathcal R_3")#text(" – which is the ")#mi("R")#text(" for ")#mi("\\theta = 2/3")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268770")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("Hmm, fair point. Maybe I’ll call it ")#mi("\\hat M^{\\prime\\prime}_{3,\\varepsilon,1}")#text(" (as I don’t want to artificially set ")#mi("\\theta")#text(" to 2/3, since that’s not the value of ")#mi("\\theta")#text(" for which GEH holds), with the hat meant to indicate that we get to add the corners of the simplex as opposed to having to truncate it.")

#text("EDIT: have now added a table to the Selberg sieve wiki page, ")#link("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem")[#text("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem")]#text(" , to summarise all the notation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268773")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("Anyway, the appropriate ")#mi("R")#text(" for this new M-value should be defined.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268789")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("Nice tables! Thank you for doing all of that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268795")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("This new table is most helpful – thank you Terry!")

#text("Doesn’t there need to be some dependence on epsilon in the polytope constraints of the M”_k,epsilon rows?")

#text("Also: maybe the “non-convex” polytope can be described in a k-independent form, which I think is that more than half of the t_i must be at least the sum of all t_i minus 1. (I hope that an intelligible notation for this constraint can be devised!) This may perhaps be useful in the soon-to-be-refocused-upon unconditional setting, especially bearing in mind that James’s new trick somewhat diminishes (I think) the dominance of the 2/theta-sized simplex’s contribution to R+R for larger k.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268833")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("The table only lists the constraints for the overall polytope R. The epsilon parameter affects how one partitions the polytope, the marginal conditions imposed on the function on the polytope, and the domain of integration of the J integrals.")

#text("I think that once the k=3 breakthrough is confirmed, we might experiment with a number of the different polytope options for other small values of k, with an eye to extrapolating out to the 50s where the Bombieri-Vinogradov results are currently living. My feeling is that all of these expansions only improve M by a factor of O(1/k) or so, corresponding to an improvement in k by O(1) – but when k is already around 50, this is not so bad of a gain…")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268850")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2014")])]

#text("I did a number of spot checks on Pace’s polytope decomposition and it looks good, but it got fairly tedious, and I thought that perhaps it would be better to spend time to find a different way to compute the same quantity, as this might give a more convincing confirmation of the number.")

#text("I realised that there is an adjoint problem to the ")#mi("M = \\hat M^{\\prime\\prime}_{3,\\varepsilon,1}")#text(" problem, in terms of a two-dimensional function G. Recall that M is the best constant in the inequality")

#mi("3 \\int\\int_{x+y \\leq 1-\\varepsilon} (\\int F\\ dz)^2 dx dy \\leq M \\int\\int\\int F^2\\ dx dy dz")#text(" (*)")

#text("where F is symmetric, supported on ")#mi("R=\\{ x+y+z \\leq 3/2\\}")#text(", and has the vanishing marginal condition ")#mi("\\int F\\ dz = 0")#text(" when ")#mi("x+y \\geq 1+\\varepsilon")#text(".")

#text("I claim that M is also the best constant in the adjoint inequality")

#mi("\\int_R (G(x,y)+G(x,z)+G(y,z))^2\\ dx dy dz \\leq 3M \\int_{x+y \\leq 1-\\varepsilon} G(x,y)^2\\ dx dy")#text(" (**)")

#text("whenever G is symmetric and supported on the disconnected region ")#mi("\\{x+y \\leq 1-\\varepsilon\\} \\cup \\{ 1+\\varepsilon \\leq x+y \\leq 3/2\\}")#text(", and the function ")#mi("F(x,y,z) := G(x,y)+G(x,z)+G(y,z)")#text(" obeys the vanishing marginal condition. Let’s just show that (**) holds for the M appearing in (*); the converse implication is also true, but the forward implication is the relevant one for the purposes of lower bounding M. We can write the left-hand side of (**) using symmetry, the vanishing marginal condition, and Cauchy-Schwarz as")

#mi("\\int_R F(x,y,z) (G(x,y) + G(x,z) + G(y,z))\\ dx dy dz")#linebreak()#text(" ")#mi("= 3 \\int_{x+y \\leq 3/2} G(x,y) (\\int F\\ dz)\\ dx dy")#linebreak()#text(" ")#mi("= 3 \\int_{x+y \\leq 1-\\varepsilon} G(x,y) (\\int F\\ dz)\\ dx dy")#linebreak()#text(" ")#mi("\\leq (3 \\int_{x+y \\leq 1-\\varepsilon} G(x,y)^2\\ dx dy)^{1/2}")#linebreak()#text(" ")#mi("(3 \\int_{x+y \\leq 1-\\varepsilon} (\\int F\\ dz)^2\\ dx dy)^{1/2}.")

#text("Applying (*) and rearranging, we obtain (**).")

#text("The left-hand side of (**) can also be simplified a bit using symmetry as")

#mi("3 \\int_{x+y \\leq 3/2} G(x,y)^2 (3/2-x-y) + 6 \\int_{x+y \\leq 3/2} G(x,y) (\\int_0^{3/2-x-y} G(x,z)\\ dz)\\ dx dy")#text(".")

#text("The vanishing marginal condition takes the form")

#mi("(3/2-x-y) G(x,y) + \\int_0^{3/2-x-y} G(x,z)\\ dz + \\int_0^{3/2-x-y} G(y,z)\\ dz = 0")#text(" (***)")

#text("for ")#mi("1+\\varepsilon \\leq x+y \\leq 3/2")#text(".")

#text("We are now in a variational problem similar to the original one (*), except that all the domains of integration are basically two dimensional. In particular, when ")#mi("\\varepsilon=1/4")#text(", it looks like one should decompose the support of G into seven regions (plus the reflections of five of these, so 12 regions in all):")

#mi("A_{xy} = \\{ 0 \\leq y \\leq x \\leq 1/4 \\}")

#mi("B_{xy} = \\{ 0 \\leq y \\leq 1/4 \\leq x \\leq 3/4 - y \\}")

#mi("C_{xy} = \\{ 0 \\leq y \\leq 1/4; 5/4-y \\leq x \\leq 5/4 \\}")

#mi("D_{xy} = \\{ 0 \\leq y \\leq 1/4; 5/4 \\leq x \\leq 3/2-y \\}")

#mi("E = \\{ x,y \\geq 1/4; x+y \\leq 3/4 \\}")

#mi("F = \\{ x,y \\leq 3/4; x+y \\geq 5/4 \\}")

#mi("G_{xy} = \\{ x \\geq 3/4; y \\geq 1/4; 5/4 \\leq x+y \\leq 3/2 \\}")

#text("One can set G to be a polynomial on each of these domains (with symmetry enforced on E and F), with the vanishing marginal condition (***) being a set of linear constraints (there is one set involving A,C,D, there is another involving B,G, and a third set involving B,F). Both sides of (**) are then quadratic functions of the coefficients. This looks like a problem of slightly lower complexity than the one Pace was using, and hopefully a modification of Pace’s code will then give a separate confirmation of the 2.0009 result (and maybe it could even improve it a little, due to the more efficient representation of the function). I might try tinkering with this myself, although I’ve not used Mathematica before, so I don’t know how successful I’ll be.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268928")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("Terry, I hope you enjoy playing around with Mathematica. It can be a lot of fun.")

#text("There does seem to be one problem with your decomposition; I believe you want ")#mi("x\\geq 3/4")#text(" in ")#mi("G_{xy}")#text(" (so that it doesn’t overlap with ")#mi("F")#text("). ")#emph[#text("[Corrected, thanks – T.]")]

#text("For these two-dimensional regions, the function “RegionPlot” can be quite useful to double-check overlapping. For instance, to graph ")#mi("C_{xy}")#text(" just type: The thing you should type is: RegionPlot[0 <= y <= 1/4 && 5/4-y <= x <= 5/4].")

#text("If the lines are not straight, increase the number of points by using the PlotPoints modifier.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268952")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("In the offset equation following “The left-hand side of (**) can also be simplified a bit using symmetry as…” I believe that in the first integrand the function ")#mi("G(x,y,z)")#text(" should be squared.")

#text("This equation can be simplified further, using the vanishing marginals.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268957")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("Thanks for the correction! I was in fact in the process of simplifying the problem further, and have gotten to a point where one only needs to work with polynomials on three triangles (")#mi("\\{x,y \\geq 0; x+y \\leq 3/2\\}")#text(", ")#mi("\\{ x+y \\geq 5/4; x \\leq 5/4; y \\leq 1/4\\}")#text(" and ")#mi("\\{ x+y \\leq 3/2; y \\geq 0; x \\geq 5/4 \\}")#text(" with a quite clean formula for the numerator and denominator. Details to follow soon…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268965")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("I wrote up the formulation involving polynomials on these three triangles at")

#link("https://terrytao.files.wordpress.com/2014/01/variational.pdf")[#text("Click to access variational.pdf")]

#text("The numerator is mildly messy, as are the linear constraints, but it still looks like a slightly simpler problem than the three-dimensional one. Unfortunately I don’t think I will be able to modify Pace’s Mathematica code (or more importantly, to debug the resulting modification) to implement this, but this should be doable by someone with better Mathematica skills than I.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268979")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("In the proof of proposition 0.1, it seems that the marginal condition (0.2) should imply that the integration is over ")#mi("x+y \\leq 1+\\epsilon")#text(" (instead of ")#mi("x+y \\leq 1-\\epsilon")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268984")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("Well, the two integrals are the same because G vanishes when ")#mi("1-\\varepsilon \\leq x+y \\leq 1+\\varepsilon")#text(". I’ve made a few minor other corrections to the file, new version is at ")#link("https://terrytao.files.wordpress.com/2014/01/variational1.pdf")[#text("https://terrytao.files.wordpress.com/2014/01/variational1.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269004")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("Terry, thank you for this nice file!")

#text("Just a small comment. In your decomposition, since you have broken symmetry (at least with the ")#mi("B,C,D")#text(" parts) one should not assume that the restriction of the function ")#mi("G")#text(" to these regions is symmetric. Because of this, I recommend replacing quantities like ")#mi("G(y,z)")#text(" with ")#mi("G(z,y)")#text(", because then it is much easier to keep track of which “copy” of ")#mi("B")#text(" one is working on when we start decomposing the region further.")

#text("An example where this can be an issue arises in (0.6). I believe ")#mi("G_{1,B}(y,z)")#text(" should rather be ")#mi("G_{2,B}(y,z)")#text(" [the restriction of ")#mi("G")#text(" to the “other” copy of ")#mi("B")#text(". Or, more easily, ")#mi("G_{1,B}(z,y)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269021")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("Good point; I’ve made the appropriate changes at the latest version: ")#link("https://terrytao.files.wordpress.com/2014/01/variational2.pdf")[#text("https://terrytao.files.wordpress.com/2014/01/variational2.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269065")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("I did the computation with the given integrals and am only getting ")#mi("M\\geq 1.55")#text(" or so, even for degrees up to 13. I’ve triple checked it now. But I’ve been awake too long to give it more thought tonight, so I’ll give it a good look in the morning!")

#text("By the way, in the last formula given for ")#mi("J")#text(" have you taken into account that we need to double the contributions of the parts from B,C,D, but not from E? (It just strikes me as strange that the coefficient for the E part is the same as for the others. Maybe this will make sense in the morning.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269079")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("Hmm, that is odd; the first term in J alone should already give 1.5; admittedly, some of the later terms can be negative, but still the 1.55 value is surprising. Could you post the code?")

#text("One possibility is that one needs to partition A more. I guess this would be reflected in a slow convergence rate with respect to the degree. (Still, the fact that you can get up to degree 13 now is encouraging, hopefully once all the bugs are sorted out, we can get quite precise numerics now.)")

#text("As for the E vs. B,C,D issue, it comes from having broken the symmetry at an earlier stage of the argument. J is basically the inner product , that is to say")

#mi("\\int (G(x,y) + G(x,z) + G(z,y)) (G_0(x,y) + G_0(x,z) + G_0(z,y))\\ dx dy dz.")

#text("The fragment")

#mi("\\int G_1(x,z) G_0(x,y)\\ dx dy dz")

#text("of this is what is giving the B,C,D,E contributions. There is a reflected fragment")

#mi("\\int G_1(x,z) G_0(y,z)\\ dx dy dz")

#text("which would have contributions from reflections of B,C,D and a (reflected) contribution to E. Note that for (x,z) in E, both G_0(y,z) and G_0(x,y) can be nonzero, but for other regions, only one of the two is nonzero. This doubling up of the E contribution sort of cancels out the fact that E is its own reflection")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269124")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2014")])]

#text("On page 4, is the last equality of the first offset equation correct? When I plot the region given by ")#mi("x+y\\leq 1-\\varepsilon;y\\leq 1/2-\\varepsilon; 1+\\varepsilon-x\\leq z\\leq 3/2-x-y")#text(" I do not get the same region as given by ")#mi("1+\\varepsilon\\leq x+z\\leq 3/2; 0\\leq y\\leq 3/2-x-z")#text(". For instance, if ")#mi("(x,y,z)=(1.4,0.05,0)")#text(" then this seems to live in the second region, but not the first.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269127")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2014")])]

#text("Nevermind, I see now you are implicitly using the support of ")#mi("G_0")#text(" here to cover this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269133")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2014")])]

#text("You can find my code here: ")#link("http://www.math.byu.edu/~pace/Computation-BddGaps6-2D.nb")[#text("http://www.math.byu.edu/~pace/Computation-BddGaps6-2D.nb")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269155")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2014")])]

#text("Thanks for this! It looks like the convergence is pretty slow, if degree 10 gives 1.51 and degree 13 gives 1.55. So probably there is a need to partition the big triangle further here (although this removes a lot of the supposed advantage of this framework.")

#text("I should be able to do this from the code you gave me, but it turns out that my Mathematica skills are so primitive I can barely run the notebook and tweak the parameters: could you give an explicit example of a low-degree choice for the polynomials Gmain, GA-GE, H1, H2 together with the values you computed for I, J? I can try to confirm these values with Maple (and also to convert things back into the original F-formulation using F(x,y,z)=G(x,y)+G(y,z)+G(z,x), to confirm that there wasn’t something going wrong with the calculations in my notes; also I want to see how accurate the eigenfunction equation is). If they check out then likely the problem is with the partitioning.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269166")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2014")])]

#text("I’ve replaced the Mathematica notebook with a new one which contains the explicit polynomials one gets from taking d=3, and it also gives the integral outputs. Use the same link above to get to it. You should be able to just copy and paste the information into Maple. (I turned the complicated fractions into floating point. To get the polynomials with the exact fractions, instead of evaluating “N[GMain]” just evaluate “Expand[GMain]” (after running all the other lines).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268900")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("Is it possible to relax the conditions on ")#mi("R")#text(" by enlarging it to ")#mi("[0, 2]^3")#text(" and replacing the condition on ")#mi("R+R")#text(" by the (more flexible) condition on ")#mi("F")#text(" as follows:")

#mi("F(x_1+x_2, y_1+y_2, z_1+z_2) = 0")#text(" , whenever")

#text("(i) ")#mi("(x_i, y_i, z_i) \\in R, i=1,2")#text(" and")

#text("(ii) ")#mi("(x_1+x_2, y_1+y_2, z_1+z_2)")#text(" is outside the region containing ")#mi("R+R")#text(" (as defined in problem 1.)")

#text("In addition, perhaps condition (ii) may be relaxed from a pointwise vanishing condition to a vanishing condition in some weaker sense (e.g. a certain type of vanishing marginals condition)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268939")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("Yes, this should work. This would fit well with a grid-type scheme as suggested by polikimre above, although the constraint is nonlinear and may not be so easy to solve numerically (plus, I don’t have a good sense of how many grid points one would need to get a good approximation).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268967")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("The idea is to avoid the many possible candidates for ")#mi("R")#text(" by converting the somewhat “too restrictive” constraint on ")#mi("R+R")#text(" into a more efficient constraint (which is “really needed”) on ")#mi("F")#text(" without the need to use fixed ")#mi("R")#text(" with the above property during ")#mi("F")#text(" optimization.")#linebreak()#text(" Instead of using (approximate) grid points, I suggest to use piecewise ")#mi("F")#text(" representation (with appropriate partition) for which ")#mi("F")#text(" is supported on the intersection of ")#mi("[0, 2]^3")#text(" with the region containing ")#mi("R+R")#text(" (as described in problem 1) – which should be very simple (in terms of the piecewise polynomial representation.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269028")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("Consequently, it seems that problem 1 can be modified for the (largest possible) region")

#mi("R = {(x,y,z) \\in [0, 2]^3 : x+y+z \\leq 2 + \\max(x, y, z)}")

#text("without the constraint on ")#mi("R+R")#text(" ! (which now is imposed in a relaxed form on ")#mi("F")#text(").")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268940")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("Some sad news: Heini Halberstam, whose conjecture with Peter Elliott (and its generalisations) have been powering all of our recent advances, and who also wrote a seminal textbook on sieve theory with Hans-Egon Richert back in 1974, died last week, aged 87: ")#link("http://www.news-gazette.com/obituaries/2014-01-27/heini-halberstam.html")[#text("http://www.news-gazette.com/obituaries/2014-01-27/heini-halberstam.html")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268964")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("This is sad news indeed. I took his course in 1995 as an undergraduate when I visited UIUC, and he was also very close to me during my graduate studies there from 1996 to 1998. Interestingly, I watched the documentary Nicky’s family (")#link("http://www.nickysfamily.com/")[#text("http://www.nickysfamily.com/")]#text(") a few days ago, and it made me very emotional. I realized Heini Halberstam was among the 669 children saved by the Kindertransport that the movie was about.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PD")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268985")[#strong[#text("PD")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("From wikipedia: “The Kindertransport was a rescue mission that took place during the nine months prior to the outbreak of the Second World War. The United Kingdom took in nearly 10,000 predominantly Jewish children from Nazi Germany, Austria, Czechoslovakia, Poland, and the Free City of Danzig. The children were placed in British foster homes, hostels, schools and farms. Often they were the only members of their families who survived the Holocaust.”")

#text("Nicholas Winton (whom this movie is about) found homes for 669 children. “Throughout the summer, he placed advertisements seeking British families to take them in. The last group, which left Prague on 3 September 1939, was sent back because the Nazis had invaded Poland, marking the start of the Second World War.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268992")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("Thanks for the additional information. In fact Heini Halberstam was among the 669 children saved by Nicholas Winton. See the list at the end of the movie All My Loved Ones (")#link("http://www.youtube.com/watch?v=0Ww5PQ8CfMA")[#text("http://www.youtube.com/watch?v=0Ww5PQ8CfMA")]#text("), at 1:33:00.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268982")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("Congrats to all working on this problem for getting to 6 on GEH!")

#text("Just a comment, is section 1.2 on the wiki page still timeline of the bounds? or is it just notation because the timeline has been moved elsewhere?")

#emph[#text("[I’ve reorganised the section slightly to clarify this. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269050")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2014")])]

#text("OK, I’ve located the parity barrier again for our new sieves, showing that we cannot prove the twin prime conjecture with the sieves we have (and in particular giving an indirect proof that the answer to Problem 2 is negative; I don’t have a direct proof though). I would imagine that some version of the argument below also blocks any attempt to get ")#mi("H_1 \\leq 4")#text(", but I haven’t checked this yet.")

#text("Here are the details (presented somewhat heuristically; also we pretend that everybody is squarefree, otherwise we have to replace the Mobius function with the Liouville function in the discussion below).")#linebreak()#text(" To recall: the strategy to prove the twin prime conjecture by these methods would be to build a non-negative sieve ")#mi("\\nu(n) = \\sum_{d_1|n, d_2|n+2} \\lambda_{d_1,d_2}")#text(" for some cleverly chosen weights ")#mi("\\lambda_{d_1,d_2}")#text(" supported on the (generous) region where ")#mi("\\min(d_1, d_2) < x")#text(" (ignoring epsilon powers of x), and get an upper bound")

#mi("\\sum_n \\nu(n) \\leq A")#text(" (1)")

#text("and lower bounds")

#mi("\\sum_n \\nu(n) 1_{n \\text{ prime}} \\geq B_1")#text(" (2)")

#mi("\\sum_n \\nu(n) 1_{n+2 \\text{ prime}} \\geq B_2")#text(" (3)")

#text("for which ")#mi("B_1+B_2 > A")#text(". A key point, to be exploited below, is that we are only “allowed” to use lower bounds (2), (3) that are obtainable from sieve-theoretic methods; in particular the values of ")#mi("B_1,B_2")#text(" may fall well short of what we believe the true value of the LHS of (2) or (3) to be.")

#text("Due to the generous support region, we cannot presume that ")#mi("\\nu")#text(" anticorrelates with ")#mi("\\mu(n)")#text(" or with ")#mi("\\mu(n+2)")#text(". (For instance, ")#mi("\\nu(n) = \\Lambda(n)")#text(" is currently an admissible sieve.) However, the constraint ")#mi("\\min(d_1,d_2) < x")#text(" still gives anticorrelation with ")#mi("\\mu(n) \\mu(n+2)")#text(":")

#mi("\\sum_n \\nu(n) \\mu(n) \\mu(n+2) \\approx 0")#text(". (4)")

#text("and in particular from (1) we have")

#mi("\\sum_n \\nu(n) (1-\\mu(n)\\mu(n+2)) \\leq A")#text(" (5)")

#text("up to negligible errors.")

#text("Also, the way we would prove (2) relies on distribution hypotheses on the function ")#mi("1_{n \\text{ prime}}")#text(" (the EH conjecture), as well as the non-negativity of this function. Conjecturally, the function ")#mi("1_{n \\text{ prime}} (1+\\mu(n+2))")#text(" has the same distributional and non-negativity properties as ")#mi("1_{n \\text{ prime}}")#text(", so if we can prove (2) by sieve-theoretic techniques,, we can also prove")

#mi("\\sum_n \\nu(n) 1_{n \\text{ prime}} (1+\\mu(n+2)) \\geq B_1")

#text("which by non-negativity of ")#mi("\\nu")#text(" also implies")

#mi("\\sum_n \\nu(n) \\frac{1-\\mu(n)}{2} (1+\\mu(n+2))\\geq B_1")#text(".")

#text("Similarly")

#mi("\\sum_n \\nu(n) \\frac{1-\\mu(n+2)}{2} (1+\\mu(n)) \\geq B_2")#text(".")

#text("and thus on summing")

#mi("\\sum_n \\nu(n) (1 - \\mu(n) \\mu(n+2)) \\geq B_1 + B_2")#text(".")

#text("Combining this with (5) we see that ")#mi("B_1+B_2 \\leq A")#text(", contradiction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269191")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2014")])]

#text("I looked back at the proof (from ")#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-265206")[#text("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-265206")]#text(" ) that ")#mi("H_1 \\leq 4")#text(" was not achievable from sieve-theoretic methods and realised that the same proof actually works verbatim for our new sieves too, thus giving another proof of the parity problem obstruction to ")#mi("H_1=2")#text(". Basically, any asymptotics we give for a quantity such as ")#mi("\\sum_n \\nu(n)")#text(" or ")#mi("\\sum_n \\nu(n) 1_{n+2 \\text{prime}}")#text(", etc. that can be obtained from sieve-theoretic methods, would also apply if we replaced the constant weight 1 with the weight")

#mi("a(n) = (1 - \\mu(n)\\mu(n+2)) (1-\\mu(n+2)\\mu(n+6)).")

#text("All the upper and lower bounds we have for quantities such as ")#mi("\\sum_n \\nu(n) 1_{n+2 \\text{ prime}}")#text(" or ")#mi("\\sum_n \\nu(n) 1_{n,n+6 \\text{ prime}}")#text(" ultimately come from linear combinations of such asymptotics, together with non-negativity of ")#mi("\\nu")#text(". (For instance the “epsilon trick” that gives lower bounds on ")#mi("\\sum_n \\nu(n) 1_{n+2 \\text{ prime}}")#text(" falls into this category.) So if these methods could produce ")#mi("H_1 \\leq 4")#text(" with the constant weight 1, they should also produce ")#mi("H_1\\leq 4")#text(" with n weighted by a(n). But by design, for any n in the support of a(n) cannot have n,n+2 both prime, or n+2,n+6 both prime, and so ")#mi("H_1 \\leq 4")#text(" cannot be proven sieve-theoretically using the tuple (n,n+2,n+6).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5162cf9bfb600aae7b0dc75c9f8954e80ab40e82e0a8fce12c188ea5c394ffa1-a5f3ee3445e76a613b7f243e63de1aa8fa020a569c47d4983450280115329df4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michel Eve")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269254")[#strong[#text("Michel Eve")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("Dear Prof Tao,")#linebreak()#text(" If sieve theory cannot prove the twin prime conjecture because of the parity barrer, what other techniques are left in analytic number theory to overcome this barrier ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269289")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("I discuss this at ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")]#text(" . Basically, sieve theory, which is based on linear summation techniques, is known to be insufficient, so the best hope appears to be to somehow convert the twin prime conjecture to a “bilinear” or perhaps even “multilinear” sums problem, and then do … something … to the resulting sums. The problem is that we don’t have a viable candidate for the “something”. On GEH, one can use the Bombieri sieve to convert the twin prime conjecture to the “quartilinear” problem of counting solutions to the equation pq-rs=2, where p,q,r,s are primes (i.e. convert the twin prime problem to a twin semiprime problem). This equation looks tantalisingly susceptible to SL_2-based techniques (e.g. automorphic forms), but we don’t know how to deal with the constraint that p,q,r,s are prime. (The standard technique of Cauchy-Schwarz to eliminate those constraints is insufficient; something else must be done.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1364493cfd7f48c6b2b2ab4231ab82454afc4042bdc1f1599dc60e03c059372-da32375ae61020796dd2b224c27114ac281abf7df417682669159cebaca59f45.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chen Wang")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269768")[#strong[#text("Chen Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2014")])]

#text("For solutions of the twin semiprime problem, could the techniques similar to Chen’s twin prime-semiprime theorem be used?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kalpesh Muchhal")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269168")[#strong[#text("Kalpesh Muchhal")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2014")])]

#text("Hi, I had a question regarding high k where H=270 has been achieved, whether this can be further lowered conditional on GRH. Since BV controls average error, while GRH does that for individual progressions..is this finer control helpful in the present case..(although with both EH and GRH being conjectures, and EH already giving such great bounds, I now feel the question is somewhat moot :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269189")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2014")])]

#text("I think GRH can be used to get more effective and explicit bounds on the size of the first k-tuple of primes that can be located in a short interval (because the Bombieri-Vinogradov theorem has some ineffectivity in its error terms arising from the possibility of Siegel zeroes), but does not directly impact the size H of that interval. In sieve theory, one is sieving out using a lot of progressions at once, with no single progression causing a significant impact on the sieve, so averaged results such as Bombieri-Vinogradov are what are really of importance in sieve theory; the extra uniformity coming from GRH type hypotheses is only of secondary benefit.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kalpesh Muchhal")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269251")[#strong[#text("Kalpesh Muchhal")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("Thanks Prof. Tao. Speaking of RH, in a future article could you also throw some light on why zeta zeroes and pair correlation concepts haven’t been as fruitful in this area..for example sieves based on sums like sum[pi(x+h) – pi(x)], x between n and 2n, and the prime count function pi estimated using Riemann’s formula, must have been tried and faced some obstacles..")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269287")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("Unfortunately, the zeta function appears to be the wrong tool for the job – being essentially Fourier transform of the primes, it captures behaviour of the primes at medium and large scales (particularly if one is willing to average over all values of the position parameter x), but gives significantly less information about the primes at short scales (small values of h). So for instance the RH can give information about primes in [x,x+h] for a single x and h a bit bigger than sqrt(x), or for average x and h bigger than ")#mi("x^\\varepsilon")#text(" for any fixed ")#mi("\\varepsilon > 0")#text(". For twin primes etc., one wants to take h to be bounded, and x in a sparse set (since most short intervals [x,x+h] will not contain even one prime, let alone two), and this is far from the regime in which the zeta function carries information.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269228")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2014")])]

#text("My colleague Roger Baker was wondering if we have a formula to find an explicit k for which ")#mi("M_k\\geq 32/5")#text(" (say). I know that Terry found an effectively computable lower bound. Has this been given explicit constants?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269230")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2014")])]

#text("In principle this is extractable from ")#link("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem#Lower_bounds")[#text("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem#Lower_bounds")]#text(" , but one has to optimise in a number of additional parameters (")#mi("c, T, \\tau")#text(", though in practice we set ")#mi("\\tau = 1-k\\mu")#text("). Maple code for this can be found for instance at ")#link("https://math.mit.edu/~drew/maple_5_BV.txt")[#text("https://math.mit.edu/~drew/maple_5_BV.txt")]#text(" ; the lower bound for M_k is what is called M0-Delta there, and one can optimise in c and T. (One can ignore the m, varpi, delta variables for the purposes of your particular question.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269280")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("In the notes on the variational problem, it is not clear why the solutions ")#mi("G_{1, B}, G_{1, C}")#text(" to (0.6), (0.7) should be polynomials.")#linebreak()#text(" Moreover, it seems (by (0.6), (0.7)) that the degrees of these solutions (assuming them to be polynomials) should be at least the degree of ")#mi("H")#text(" (i.e. ")#mi("D+1")#text(") and not at most ")#mi("D")#text(" (as suggested at the end.)")

#text("Therefore, I suggest to increase the degrees of these polynomial solutions (at least to ")#mi("D+1")#text(") and check if (0.6), (0.7) are exactly satisfied by the computed polynomial solutions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269281")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("I made a mistake in the degree of ")#mi("H")#text(" (it is ")#mi("D")#text(" .)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269291")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("Yes, we have exact solutions which suggest that for polynomial G_0, the functions ")#mi("G_{1,B}, G_{1,C}")#text(" should in fact involve some logarithmic factors, but the hope was that polynomials would serve as a good approximation since one does not expect any singularities here. On the other hand, there may be singularities of some sort within G_0 which are slowing down the analysis.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269290")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("I’m posting this as a new comment rather than a reply to the relevant comment, just because the chronology of the thread is getting hard to navigate.)")

#text("I’ve played with Pace’s latest notebook a little (though I too am a Mathematica novice). First, I’m not succeeding in reproducing Pace’s value of 1.55 for d=13: I get only 1.5279. The convergence is wobbly after d=8, but rather tight – d=7 gives me 1.4940 – so I’m having trouble believing we can progress much more by further increasing d, and even additional partitioning looks quite unpromising.")

#text("However, I’ve found something else that might be a clue. I tried to emulate the previous findings arising from exploring changing d just for one partition (or a category of them), and I can’t get ANY change in M from raising the degree that way. I thought I should be able to do this for region A just by replacing “d” by (for example) “10” in the line:")

#text("{GMain, AAvars} = SymmPolyGen[x, y, d, AA];")

#text("(I can’t see any other place that looks like it would do it) but this has no effect at all on the result. Is this to be expected in this new formulation, or does it indicate a bug?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269303")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("Aubrey, the value 1.55 was me trying to remember what the actual value was. [I just remembered M wasn’t bigger than that.] I think 1.5279 is probably correct. Sorry about that confusion.")

#text("On the “increasing d” issue, the following is what I’m observing. The vanishing marginal conditions are essentially rewriting each of the polynomial approximations in terms of the others. So, if you increase the degree on the main piece A, then the low degree polynomial approximation on B and C will in turn force most of that degree increase to be worthless.")

#text("I currently think that main problem is the symmetry on A. By breaking the symmetry we will have more freedom to choose monomials on (half of) A, and more of this will be compatible with the vanishing marginals.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269309")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("Many thanks for the clarification Pace. If you’re sure that that works to explain the TOTAL lack of impact of changing d for one of the (sets of) partitions, right down to 10^-20, so be it, though that seems odd to me (especially since I see that you only write “force MOST of that degree increase to be worthless”).")

#text("Are you saying that you expect a big benefit from dividing A into just two parts, separated by x=y? I would hope that that would not remove too much of the hoped-for advantage of switching from F to G.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269317")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("Yes, I’m pretty sure. But one way to double check it is to do the following. In the code for the “Answer” function, the first line includes a list of local variables.")

#text("1. Remove SetOfConditions and SetOfReductions from the list.")#linebreak()#text(" 2. Run the code with all the same d’s.")#linebreak()#text(" 3. Then print the SetOfReductions.")#linebreak()#text(" 4. Run the code with the modified d’s.")#linebreak()#text(" 5. Print the SetOfReductions again.")

#text("If my guess is correct, the new SetOfReductions should include a lot more variables being set to 0. (If you increase degree on the A portion, look for A variables with high numbers being set to 0.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269367")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("Yep, that’s what I’m seeing.")

#text("Since you already topped 2 with the 3D approach, might it be possible to see the the explicit polynomials and integral outputs for that case, so that Terry can do a Maple computation? Playing a little with the degrees I found that one can stay above M=2 with the U and G degrees being 4 and all the others only 2, which might make this easier. (I find that an epsilon of 2555/10000 does better than 1/4, so there’s no motivation to look at a different partitioning.) Also I’m still curious about the extended prism, since it’s so much bigger than the untruncated simplex; if its M is indeed bigger for a given fixed degree, it might top 2 with even lower degrees.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269379")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("I just obtained some very surprising behavior while playing more with the degrees in Pace’s 3D notebook. Previously I was keeping the degree of all partitions with the same letter equal, but I tried departing from that and discovered that Gxyz is ridiculously powerful. Setting the degree of Gxyz to 2 and that of absolutely everything else to 1 gives me M=2.046968.")

#text("If this is all correct, I hope it will considerably simplify a Maple validation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269384")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("Ah… by way of caution in relation to the previous post: I thought I should explore a few other options in order to provide a good “world record”, and I got up to 2.09, but then unfortunately found a set of degrees that gives M=127.93 :-( The set in question is:")

#text("Gxyz=5")#linebreak()#text(" Gyzx=Gzyx=Uyzx=4")#linebreak()#text(" Uxyz=3")#linebreak()#text(" Axyz=Cxyz=Sxyz=Hxyz=2")#linebreak()#text(" everything else 1")

#text("I presume that rather than unveiling a bug in Pace’s code this simply means that stipulating different degrees for components with the same letter is not allowed, thus calling into question my previous finding.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269455")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2014")])]

#text("Aubrey, yes in my code you must stipulate the same degree for the other G-components. As it is set up, this is what ensures that we keep symmetry, and we need symmetry to guarantee that the three J integrals are all equal, etc…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269470")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2014")])]

#text("Thanks Pace. Just to clarify, however: my initial finding (that one can stay above M=2 with the U and G degrees being 4 and all the others only 2, with possible implications for Maple validation) was not subject to this flaw.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269310")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("I think you’re right about this as the explanation for the slow convergence. The logical thing to do would then be to break A into two pieces, depending on whether ")#mi("x \\leq y")#text(" or ")#mi("x \\geq y")#text(". Unfortunately this creates a “crease” in H on the diagonal, which in turn causes the B and C triangles to be cut in half if one wants to keep them polynomial. Ugh, it’s quite a mess now. (Somehow the 3D partitioning already avoided this problem; it’s still a bit unintuitive to me that the 3D program is performing so much better than the 2D program, but perhaps that’s simply how it is.)")

#text("I thought briefly about dropping the symmetry condition altogether, but this would triple (or maybe even sextuple) the number of vanishing marginal conditions and is almost certainly not a win. I’ll try to think if there are any other “cheap” ways to get better convergence here, but we may just have to grit our teeth and partition the 2D polytopes further.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269315")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("I think the intuition on why the 2D problem is performing worse than the 3D problem may be the following. While the 2D version reveals more structure to an optimal solution, the 3D version gives us more room to “decompress” the structure and work on independent pieces.")

#text("For instance, in the 3D version the marginal conditions say nothing about the main component. Further, there is a large region (the T region) where the vanishing marginal condition gives only one (very mild) restriction. Thus, there is more freedom to choose polynomials and optimize over these portions of the domain.")

#text("In the 2D model, the function’s restrictions to the separate regions are forced to be interdependent, which makes polynomial approximation harder.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269522")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2014")])]

#text("Aubrey, you asked for explicit polynomials coming from my Mathematica workbook. Here they are (with floating point coefficients) for epsilon=1/4.")

#text("FA=1- 1.28813 x + 0.81663 x^2 – 1.30652 y +")#linebreak()#text(" 0.887704 x y + 1.06809 y^2 – 1.25622 z + 0.643331 x z +")#linebreak()#text(" 0.447091 y z + 0.835724 z^2")

#text("FB=0.557582- 0.615844 x + 0.472821 x^2 – 1.07377 y +")#linebreak()#text(" 0.448855 x y + 1.03211 y^2 – 0.248981 z – 0.0606339 x z +")#linebreak()#text(" 0.223752 y z + 0.0916695 z^2")

#text("FC=0.340116- 0.657288 x + 0.453068 x^2 – 0.64547 y +")#linebreak()#text(" 0.581099 x y + 0.511376 y^2 – 0.00929844 z + 0.00330427 x z +")#linebreak()#text(" 0.0146546 y z + 0.00416013 z^2")

#text("FD=0")

#text("FE=-2.16828 + 1.88879 x – 1.93478 x^2 – 0.978705 y + 0.294345 x y +")#linebreak()#text(" 0.546622 y^2 + 5.61586 z + 0.38199 x z + 0.270168 y z – 4.5987 z^2")

#text("FG=-263.521 + 1699.78 x – 4784.39 x^2 + 5222.13 x^3 – 1806.61 x^4 +")#linebreak()#text(" 1154.1 y + 48.4907 x y + 68.5822 x^2 y – 1471.88 x^3 y –")#linebreak()#text(" 4024.1 y^2 – 503.705 x y^2 + 3235.68 x^2 y^2 + 5031.37 y^3 –")#linebreak()#text(" 1413.72 x y^3 – 1806.61 y^4 + 630.748 z – 3053.12 x z +")#linebreak()#text(" 5974.22 x^2 z – 3344.09 x^3 z – 2390.97 y z + 5532.79 y^2 z –")#linebreak()#text(" 3344.09 y^3 z – 552.712 z^2 + 1788.29 x z^2 – 1848.33 x^2 z^2 +")#linebreak()#text(" 1633.01 y z^2 – 1891.95 y^2 z^2 + 208.274 z^3 – 338.891 x z^3 –")#linebreak()#text(" 367.971 y z^3 – 28.0339 z^4")

#text("FH=-0.518424 + 2.09666 x – 1.16736 x^2 – 10.9012 y + 5.3936 x y +")#linebreak()#text(" 11.5925 y^2 + 2.17563 z – 2.38737 x z + 5.2883 y z – 1.22001 z^2")

#text("FS=0.0626347+ 1.89748 x – 1.93478 x^2 – 9.76006 y +")#linebreak()#text(" 0.271189 x y + 6.21113 y^2 + 0.107294 z + 0.370413 x z +")#linebreak()#text(" 10.8039 y z – 1.22001 z^2")

#text("FT=-0.0445971 + 0.069443 x – 0.0264744 x^2 – 0.565025 y + 0.363377 x y +")#linebreak()#text(" 0.624488 y^2 + 0.35029 z – 0.24018 x z – 0.0110861 y z – 0.213706 z^2")

#text("FU=-62.4771 + 759.264 x – 2974.81 x^2 + 4220.43 x^3 – 1806.61 x^4 –")#linebreak()#text(" 0.816031 y + 8.23017 x y – 61.3701 x^2 y + 130.845 x^3 y –")#linebreak()#text(" 4.86221 y^2 + 44.7764 x y^2 – 82.771 x^2 y^2 + 3.9055 y^3 –")#linebreak()#text(" 21.0704 x y^3 + 0.214361 y^4 + 88.709 z – 984.165 x z +")#linebreak()#text(" 3143.87 x^2 z – 2542.72 x^3 z – 28.088 z^2 +")#linebreak()#text(" 299.853 x z^2 – 742.184 x^2 z^2 –")#linebreak()#text(" 2.44422 z^3 + 9.27222 x z^3 – 0.0428723 z^4")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269552")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2014")])]

#text("Many thanks Pace. (I presume you confirmed an M of 2.0000395 for this set of degrees.) Even though this reduces the number of coefficients by 40% relative to the degree set you used to get 2.0009, there are still 132 of them, which I’m guessing is quite laborious to code in Maple (something that I’m afraid I have no idea how to do). I suppose the question is whether there is any cheaper way than that to obtain satisfactory confirmation of H_1=6 and allow focus to return to the unconditional setting. The extended prism might be the only other option, but of course there’s work involved in creating the Mathematica code and it’s a complete guess whether it would deliver less complexity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269644")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("Thanks for this! I should be able to confirm that this works in Maple, though I might not get around to it for a few days as there are several other things on my plate right now. If you could post your values for I and J for this choice of coefficients that would help for the confirmation purposes. (One nice thing is that once one actually has the explicit description of F, it doesn’t really matter where it came from or what exactly it was optimising; one can simply compute the ratio J/I and check that it exceeds 2. So one doesn’t have to confirm all of the numerical optimisation, one just has to check the answer that comes out at the end.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269651")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("Even with these explicit polynomials I think this will still be complicated, but good luck!")

#text("My values for the I and J integrals are (respectively) 0.0306247, 0.0612506.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-270584")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2014")])]

#text("Finally have some spare time to compute the I and J integrals. I am getting 0.03062203133 for the I integral (computed in a slightly different way from in your notes), but this might possibly be due to the roundoff coming from the use of decimals instead of fractions. Do you have a version of FA-FH with rational (or maybe integer) coefficients (clearing denominators if necessary)?")

#text("For sake of checking, here are the individual I integrals I am getting:")

#text("I(A)= 0.003405849935")#linebreak()#text(" I(B)= 0.0008483246927")#linebreak()#text(" I(C)= 0.0008209224485")#linebreak()#text(" I(D)= 0")#linebreak()#text(" I(E)= 0.4684111483 10^-5")#linebreak()#text(" I(S)=0.7034444492 10^-6")#linebreak()#text(" I(T)=0.2366227122 10^-5")#linebreak()#text(" I(U)=0.8858487383 10^-5")#linebreak()#text(" I(G)=0.7143129988 10^-5")#linebreak()#text(" I(H)=0.4819411681 10^-5")

#text("I was hoping to use Maple’s Heaviside function to perform the integrals, but in practice I found that Maple can really only handle one Heaviside function at a time (and occasionally two), which allowed me to compute some, but not all, of the integrals directly.")

#text("I also computed the volumes of the various polytopes as a further checksum:")

#text("A = 27/1536")#linebreak()#text(" B = 26/1536")#linebreak()#text(" C = 55/1536")#linebreak()#text(" D = 8/1536")#linebreak()#text(" E = 1/1536")#linebreak()#text(" F = 22/1536")#linebreak()#text(" S = 2/1536")#linebreak()#text(" T = 16/1536")#linebreak()#text(" U = 4/1536")#linebreak()#text(" G = 4/1536")#linebreak()#text(" H = 1/1536")

#text("everything adds up as expected.")

#text("I’ll turn to the J integrals next, of course, then the vanishing marginal conditions. Here I don’t see any shortcuts other than to simply repeat what is in your notes, but I’ll try to check the integral formulae while doing so.")

#raw("\neps:=1/4;")

#text("Axyz:=Heaviside((1-eps)-(z+x));")#linebreak()#text(" Dxyz:=Heaviside(1+eps-(z+x))*Heaviside((x+y)-(1-eps));")#linebreak()#text(" ABCDxyz:=Heaviside(1+eps-(z+x));")#linebreak()#text(" ABExyz:=Heaviside((1-eps)-(y+z));")#linebreak()#text(" Exyz:=Heaviside((z+x)-(1+eps))*Heaviside((1-eps)-(y+z));")#linebreak()#text(" BExyz := ABExyz - Axyz;")#linebreak()#text(" Bxyz:=ABExyz-Axyz-Exyz;")#linebreak()#text(" Gxyz:=Heaviside(y+z-(1+eps));")#linebreak()#text(" DHxyz:=Heaviside(x+y-(1-eps));")#linebreak()#text(" CFxyz:=Heaviside((y+z)-(1-eps))-DHxyz-Gxyz;")#linebreak()#text(" Hxyz:=DHxyz-Dxyz;")#linebreak()#text(" Fxyz:=CFxyz-Cxyz;")

#text("FA:=1-1.28813*x+0.8166*x^2-1.30652*y+0.887704*x*y+1.06809*y^2-1.25622*z+0.643331*x*z+0.447091*y*z+0.835724*z^2;")

#text("FB:=0.557582-0.615844*x+0.472821*x^2-1.07377*y+0.448855*x*y+1.03211*y^2-0.248981*z-0.0606339*x*z+0.223752*y*z+0.0916695*z^2;")

#text("FC:=0.340116-0.657288*x+0.453068*x^2-0.64547*y+0.581099*x*y+0.511376*y^2-0.00929844*z+0.00330427*x*z+0.0146546*y*z+0.00416013*z^2;")

#text("FD:=0")

#text("FE:=-2.16828+1.88879*x-1.93478*x^2-0.978705*y+0.294345*x*y+0.546622*y^2+5.61586*z+0.38199*x*z+0.270168*y*z-4.5987*z^2;")

#text("FG:=-263.521+1699.78*x-4784.39*x^2+5222.13*x^3-1806.61*x^4+1154.1*y+48.4907*x*y+68.5822*x^2*y-1471.88*x^3*y-4024.1*y^2-")

#text("503.705*x*y^2+3235.68*x^2*y^2+5031.37*y^3-1413.72*x*y^3-1806.61*y^4+630.748*z-3053.12*x*z+5974.22*x^2*z-3344.09*x^3*z-2390.97*y*z+5532.79*y^2*z-")

#text("3344.09*y^3*z-552.712*z^2+1788.29*x*z^2-1848.33*x^2*z^2+1633.01*y*z^2-1891.95*y^2*z^2+208.274*z^3-338.891*x*z^3-367.971*y*z^3-28.0339*z^4;")

#text("FH:=-0.518424+2.09666*x-1.16736*x^2-10.9012*y+5.3936*x*y+11.5925*y^2+2.17563*z-2.38737*x*z+5.2883*y*z-1.22001*z^2;")

#text("FS:=0.0626347+1.89748*x-1.93478*x^2-9.76006*y+0.271189*x*y+6.21113*y^2+0.107294*z+0.370413*x*z+10.8039*y*z-1.22001*z^2;")

#text("FT:=-0.0445971+0.069443*x-0.0264744*x^2-0.565025*y+0.363377*x*y+0.624488*y^2+0.35029*z-0.24018*x*z-0.0110861*y*z-0.213706*z^2;")

#text("FU:=-62.4771+759.264*x-2974.81*x^2+4220.43*x^3-1806.61*x^4-0.816031*y+8.23017*x*y-61.3701*x^2*y+130.845*x^3*y-4.86221*y^2+44.7764*x*y^2-")

#text("82.771*x^2*y^2+3.9055*y^3-21.0704*x*y^3+0.214361*y^4+88.709*z-984.165*x*z+3143.87*x^2*z-2542.72*x^3*z-28.088*z^2+299.853*x*z^2-742.184*x^2*z^2-")

#text("2.44422*z^3+9.27222*x*z^3-0.0428723*z^4;")

#text("IA := int(int(int(FA*FA*Axyz,z=x..(3/2-y-x)),x=y..(3/2-y)/2),y=0..1/2);")#linebreak()#text(" # 0.003405849935")

#text("IB := int(int(int(FB*FB*BExyz,z=x..(3/2-y-x)),x=y..(3/2-y)/2),y=0..1/2) - int(int(int(FB*FB,y=0..1-eps-z),x=1+eps-z..z),z=1/2+eps/2..1-eps);")#linebreak()#text(" # 0.0008483246927")

#text("IC := int(int(int(FC*FC*ABCDxyz,z=x..(3/2-y-x)),x=y..(3/2-y)/2),y=0..1/2) - int(int(int(FC*FC*Axyz,z=x..(3/2-y-x)),x=y..(3/2-y)/2),y=0..1/2) - int(int(int")

#text("(FC*FC*BExyz,z=x..(3/2-y-x)),x=y..(3/2-y)/2),y=0..1/2) - int(int(int(FC*FC*Dxyz,z=x..(3/2-y-x)),x=y..(3/2-y)/2),y=0..1/2) + int(int(int(FC*FC,y=0..1-")

#text("eps-z),x=1+eps-z..z),z=1/2+eps/2..1-eps);")#linebreak()#text(" # 0.0008209224485")

#text("ID := int(int(int(FD*FD*Dxyz,z=x..(3/2-y-x)),x=y..(3/2-y)/2),y=0..1/2);")#linebreak()#text(" # 0")

#text("IE := int(int(int(FE*FE,y=0..1-eps-z),x=1+eps-z..z),z=1/2+eps/2..1-eps);")#linebreak()#text(" # 0.4684111483 10^-5")

#text("IS := int(int(int(FS*FS,x=1+eps-z..(1-eps-y)),z=y+2*eps..1/2+eps),y=1/2-3*eps/2..1/2-eps)+int(int(int(FS*FS,x=1+eps-z..(1-eps-y)),z=1-eps-")

#text("y..1/2+eps),y=0..1/2-3*eps/2);")#linebreak()#text(" # 0.7034444492 10^-6")

#text("IT := int(int(int(FT*FT,y=0..3/2-x-z),x=1/2-eps..3/2-z),z=1/2+2*eps..1+eps)+int(int(int(FT*FT,y=0..3/2-x-z),x=1+eps-z..3/2-z),z=1/2+eps..1/2+2*eps);")#linebreak()#text(" # 0.2366227122 10^-5")

#text("IU := int(int(int(FU*FU,z=1+eps-x..1+eps-y),y=0..x),x=0..1/2-eps);")#linebreak()#text(" # 0.8858487383 10^-5")

#text("IG := int(int(int(FG*FG*Gxyz,z=x..(3/2-y-x)),x=y..(3/2-y)/2),y=0..1/2);")#linebreak()#text(" # 0.7143129988 10^-5")

#text("IH := int(int(int(FH*FH*Hxyz,z=x..(3/2-y-x)),x=y..(3/2-y)/2),y=0..1/2);")#linebreak()#text(" # 0.4819411681 10^-5")

#text("Isum := 6*(IA+IB+IC+ID+IE+IS+IT+IU+IG+IH);")#linebreak()
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-270588")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2014")])]

#text("I quickly proofread the Maple code and found only one typo, which I’m not sure would explain the discrepancy: the second coefficient in FA is missing its last digit (0.8166, should be 0.81663).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-270592")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2014")])]

#text("Well spotted! This increases the I-value to 0.03062212678 (I(A) increases to 0.003405865844). So this doesn’t explain the entire discrepancy…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-270594")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2014")])]

#text("Here are the numbers I get:")

#text("I(A)=0.003405880062")#linebreak()#text(" I(B)=0.0008483272329")#linebreak()#text(" I(C)=0.0008209190117")#linebreak()#text(" I(D)=0")#linebreak()#text(" I(E)=4.684618094*10^-6")#linebreak()#text(" I(S)=7.034678581*10^-7")#linebreak()#text(" I(T)=2.366234915*10^-6")#linebreak()#text(" I(U)=8.881367920*10^-6")#linebreak()#text(" I(G)=7.535069959*10^-6")#linebreak()#text(" I(H)=4.820553682*10^-6")

#text("These seem to all match extremely well, except the U and G pieces. (This makes a lot of sense as you’ll see below that the U and G pieces should have a lot of round-off error since they involve more of the variables.)")

#text("—————–")

#text("I’m going to copy and paste some variables and fractions and hopefully you can just copy these into your code. (If this doesn’t work, I’ll make the file available tomorrow when I get to work.)")

#text("The variables are:")#linebreak()#text(" {AA1, AA10, AA2, AA3, AA4, AA5, AA6, AA7, AA8, AA9, BB1, BB10, BB2, BB3, BB4, BB5, BB6, BB7, BB8, BB9, CC1, CC10, CC2, CC3, CC4, CC5, CC6, CC7, CC8, CC9, EE4, EE6, EE7, EE9, HH9, SS10, SS3, SS4, SS6, SS7, SS8, SS9, TT4, TT7, TT8, TT9, UU16, UU18, UU2, UU20, UU21, UU22, UU23, UU24, UU25, UU26, UU27, UU28, UU29, UU3, UU30, UU31, UU4, UU5, UU6, UU7, UU8, UU9}")

#text("The values to be plugged in for these variables are:")

#text("{1, 1045142938208869499191181851782774507/\\")#linebreak()#text(" 1250583557010555646667061395704693241, -(")#linebreak()#text(" 316190143410376180877743423449314379/")#linebreak()#text(" 245464443795540077818629001202004919), -(")#linebreak()#text(" 1891769024614429265911454167348900079/")#linebreak()#text(" 1447939476712835671464363817808062688), -(")#linebreak()#text(" 6645228840627884543963048543908513027/")#linebreak()#text(" 5289876174681743792060084416381005195), \\")#linebreak()#text(" 339382475899332801872344573142712540/\\")#linebreak()#text(" 382315024741410006634197807400450109, \\")#linebreak()#text(" 800533017763591087028889327164205386/\\")#linebreak()#text(" 1244356905396458217205005409940313975, \\")#linebreak()#text(" 610227319942583521343573321987866901/\\")#linebreak()#text(" 1364882503730947175994072119119099314, \\")#linebreak()#text(" 889358636648145697618963860699826673/\\")#linebreak()#text(" 1089059167005007839552742646367084883, \\")#linebreak()#text(" 1129697701772130766129061623987627555/\\")#linebreak()#text(" 1057677648341105966172642014701620358, \\")#linebreak()#text(" 369411148833963466416948486507827637/\\")#linebreak()#text(" 662523432040271503868922466512394931, \\")#linebreak()#text(" 70036650704097962432270211642055587/\\")#linebreak()#text(" 764012880419651000309703978698201099, -(")#linebreak()#text(" 1560220310742393302871638104929376767/")#linebreak()#text(" 2533466855538622711494072790849524188), -(")#linebreak()#text(" 675291956550121180518604625359119746/")#linebreak()#text(" 628900966577543384705927335762397661), -(")#linebreak()#text(" 2529381695462699016828722243204952689/")#linebreak()#text(" 10158934785795031265990553206322976713), \\")#linebreak()#text(" 301473130543012653915144253204794977/\\")#linebreak()#text(" 671648655006425274620020662289591135, -(")#linebreak()#text(" 72843967588099728726005521157785775/")#linebreak()#text(" 1201374210126871248100329027582696868), \\")#linebreak()#text(" 143825707895572733498873732281838861/\\")#linebreak()#text(" 642792029730168691317286168208033538, \\")#linebreak()#text(" 649120491616113171860687738354432093/\\")#linebreak()#text(" 1372868684761191246523483175495609470, \\")#linebreak()#text(" 923204127144474133750324575031071970/\\")#linebreak()#text(" 894483138835109750336516244948229253, \\")#linebreak()#text(" 504054606061804606346982706190041169/\\")#linebreak()#text(" 1482009696315178162834773520112425988, \\")#linebreak()#text(" 6393539409569434525570984945744351/\\")#linebreak()#text(" 1536858786446366256984445263822713064, -(")#linebreak()#text(" 790669890434879790226924633515000611/")#linebreak()#text(" 1202927660436616925000852487643859754), -(")#linebreak()#text(" 583951140942993837488005058061406582/")#linebreak()#text(" 904691553133220160159156823559029957), -(")#linebreak()#text(" 22155783335807716384604672631876769/")#linebreak()#text(" 2382741655599610617339893240473178207), \\")#linebreak()#text(" 861834403869460514116581559993754859/\\")#linebreak()#text(" 1483110658557996492977375659547372425, \\")#linebreak()#text(" 1929146726486743959255980765537648/\\")#linebreak()#text(" 583834071458801022674364752868975235, \\")#linebreak()#text(" 21780572077072279546180172035622479/\\")#linebreak()#text(" 1486260981903228631659801660491854709, \\")#linebreak()#text(" 184535211848461345418175814435319135/\\")#linebreak()#text(" 407301027098512230853641880451245568, \\")#linebreak()#text(" 232080145073024378344663228214923163/\\")#linebreak()#text(" 453834445204584035710168200740458909, \\")#linebreak()#text(" 5472538654920722429742789691613843676/\\")#linebreak()#text(" 974479232954197975340589995394266455, \\")#linebreak()#text(" 927222828149050158923800771583485723/\\")#linebreak()#text(" 2427346765941624985384346616239603038, \\")#linebreak()#text(" 250517508328910949894678249652185722/\\")#linebreak()#text(" 927265216411134102504733935734045705, \\")#linebreak()#text(" 1240108547818177956234040673419197568/\\")#linebreak()#text(" 2268677602592314368751160380697174029, \\")#linebreak()#text(" 9405819102419059244834716575963924175/\\")#linebreak()#text(" 811372333735457494738136754843943653, -(")#linebreak()#text(" 1432088304215654669021352650864060725/")#linebreak()#text(" 1173831359938549301293098635807566287), -(")#linebreak()#text(" 11612115950284073971150222762767416620/")#linebreak()#text(" 1189758425639212572034398845328452639), \\")#linebreak()#text(" 103937977558232440508940501348834518/\\")#linebreak()#text(" 968720338025380091790884725502334715, \\")#linebreak()#text(" 214224468539246347682035898225657185/\\")#linebreak()#text(" 578340038314441580717115396074382778, \\")#linebreak()#text(" 16011015326505338708151388841891253041/\\")#linebreak()#text(" 1481970237969351533821283886719874867, -(")#linebreak()#text(" 2152329004242745879844194442185193763/")#linebreak()#text(" 1112441007795743584614598777366749922), \\")#linebreak()#text(" 8652296470217515560135397830496043201/\\")#linebreak()#text(" 1393032063270399805786566196554189095, \\")#linebreak()#text(" 2724262739331687731618153452386489771/\\")#linebreak()#text(" 7777163575787859138926611143971853064, -(")#linebreak()#text(" 3533612330801100162685856352893683/")#linebreak()#text(" 318742786972619370533192728831094789), -(")#linebreak()#text(" 8634152014937802133186289083541939/")#linebreak()#text(" 326132136552676474614615351931787892), \\")#linebreak()#text(" 639258673765815764176758921945001459/\\")#linebreak()#text(" 1023652233362766137377498777586011863, 0, -(")#linebreak()#text(" 1036177365908403576222625465669165224191/")#linebreak()#text(" 1396118752614173365815190752515315262), \\")#linebreak()#text(" 683163754447358515357759652655917657307/\\")#linebreak()#text(" 899770442732486890915132953316493212, \\")#linebreak()#text(" 3977430161340892036145546371180618658240/\\")#linebreak()#text(" 942423718900792196615855892814714641, \\")#linebreak()#text(" 4369967465028547394227392689218793956/\\")#linebreak()#text(" 1118925727402664937850908867587807095, -(")#linebreak()#text(" 6493264317462327139909085594207259201/")#linebreak()#text(" 2656583931468774802084917498666106861), \\")#linebreak()#text(" 208533806588523947204108028241851658601/\\")#linebreak()#text(" 1593749576650909843879153107097169586, -(")#linebreak()#text(" 2586867413257547105405021630653379594931/")#linebreak()#text(" 1017361494191501491128242008483670506), -(")#linebreak()#text(" 46075356336908979453982139912989909769/")#linebreak()#text(" 2186736965136790998934152365709299888), \\")#linebreak()#text(" 21583120699474906684881271067473540892/\\")#linebreak()#text(" 2327719037190114284507554697536132109, 0, 0, -(")#linebreak()#text(" 4493884950736564857307858442065834123411/")#linebreak()#text(" 2487469455179284947187381390582168137), -(")#linebreak()#text(" 912131634231853063945020626889013945/")#linebreak()#text(" 1117765710674185487041664983420906397), \\")#linebreak()#text(" 385418773588866232850515087462213507/\\")#linebreak()#text(" 1797985734299399330339559894335414707, -(")#linebreak()#text(" 60846714782262228976526525072918278/")#linebreak()#text(" 1419255270556600115075698318707631525), \\")#linebreak()#text(" 38086532340155117976291869658511569399/\\")#linebreak()#text(" 429342259347747976339594153498728242, \\")#linebreak()#text(" 9900518239375432526911040812620204965/\\")#linebreak()#text(" 1202954557712616339652022357371972894, -(")#linebreak()#text(" 1363826261161475275558885344800775294047/")#linebreak()#text(" 1385770492279731028804032285608964254), 0, -(")#linebreak()#text(" 3986739775635725156458528972312106107630/")#linebreak()#text(" 1340165793339507490854268037177642059), -(")#linebreak()#text(" 2967616495233435231968510933124363413/")#linebreak()#text(" 610343298456544672866212720080088296)}")

#text("The explicit polynomials are:")

#text("FA= AA1 + AA2 x + AA8 x^2 + AA3 y + AA5 x y + AA9 y^2 + AA4 z + AA6 x z + AA7 y z + AA10 z^2")

#text("FB= BB1 + BB2 x + BB8 x^2 + BB3 y + BB5 x y + BB9 y^2 + BB4 z + BB6 x z + BB7 y z + BB10 z^2")

#text("FC= CC1 + CC2 x + CC8 x^2 + CC3 y + CC5 x y + CC9 y^2 + CC4 z + CC6 x z + CC7 y z + CC10 z^2")

#text("FE= -((3 EE4)/4) – (9 EE7)/32 + (3 EE9)/16 – (9 SS10)/16 – (3 SS3)/8 – ( 3 SS9)/8 + (-((3 EE6)/4) + SS3/2 + (3 SS7)/8 – (3 SS8)/4 + SS9/4) x + SS8 x^2 + (2 EE4 + (3 EE7)/4 – EE9 + SS3 – 2 SS4 – (3 SS7)/4 +")#linebreak()#text(" SS9) y + (2 EE6 – 2 SS6 + 2 SS8 + (2 SS9)/3) x y + EE9 y^2 +")#linebreak()#text(" EE4 z + EE6 x z + EE7 y z + (EE7/2 – EE9/3 + SS10 – SS7/2 + SS9/3) z^2")

#text("FS= -((9 SS10)/16) – (3 SS3)/8 – (3 SS4)/4 – (9 SS7)/32 – (")#linebreak()#text(" 3 SS9)/16 + (SS3/2 – (3 SS6)/4 + (3 SS7)/8 – (3 SS8)/4 + SS9/4) x +")#linebreak()#text(" SS8 x^2 + SS3 y + (2 SS8 + (2 SS9)/3) x y + SS9 y^2 + SS4 z +")#linebreak()#text(" SS6 x z + SS7 y z + SS10 z^2")

#text("FT = -((3 TT4)/2) – (9 TT7)/8 + (")#linebreak()#text(" 3 TT9)/4 + (TT4 + (3 TT7)/4 – (3 TT8)/2 – TT9/2) x +")#linebreak()#text(" TT8 x^2 + (2 TT4 + (3 TT7)/2 – 2 TT9) y + (2 TT8 + (2 TT9)/3) x y +")#linebreak()#text(" TT9 y^2 + TT4 z + (TT7/2 + TT8 – TT9/3) x z +")#linebreak()#text(" TT7 y z + (TT7/2 – TT9/3) z^2")

#text("FU= -((125 UU16)/256) – UU2/16 + UU20/512 + (125 UU22)/128 + (")#linebreak()#text(" 5 UU23)/8192 + (5 UU24)/4096 + (125 UU26)/2048 – (")#linebreak()#text(" 625 UU28)/1024 + UU29/1280 – (5 UU3)/16 + (625 UU31)/256 – (")#linebreak()#text(" 5 UU4)/8 – (5 UU5)/256 – (5 UU6)/128 – (25 UU7)/64 + UU2 x +")#linebreak()#text(" UU8 x^2 + UU20 x^3 + UU29 x^4 + UU3 y +")#linebreak()#text(" UU5 x y + (-((225 UU16)/26) + (5 UU18)/2 – (24 UU2)/5 + (333 UU20)/")#linebreak()#text(" 260 + (225 UU21)/26 + (225 UU22)/13 – (423 UU23)/832 + (")#linebreak()#text(" 1089 UU24)/416 + (45 UU25)/16 – (105 UU26)/16 – (1125 UU28)/")#linebreak()#text(" 104 – (3 UU29)/25 + (72 UU3)/13 + (225 UU30)/26 + (1125 UU31)/")#linebreak()#text(" 26 – (144 UU4)/13 – (3 UU5)/2 – 3 UU6 – (90 UU7)/13 – (8 UU8)/")#linebreak()#text(" 5 + (120 UU9)/13) x^2 y + UU23 x^3 y +")#linebreak()#text(" UU9 y^2 + ((165 UU16)/26 – (27 UU20)/52 – (165 UU21)/26 – (165 UU22)/")#linebreak()#text(" 13 – (75 UU23)/416 – (15 UU24)/52 – (69 UU25)/80 – (87 UU26)/")#linebreak()#text(" 40 + (825 UU28)/104 – (27 UU29)/25 – (264 UU3)/65 – (165 UU30)/")#linebreak()#text(" 26 – (825 UU31)/26 + (528 UU4)/65 – (3 UU5)/5 + (6 UU6)/5 + (")#linebreak()#text(" 66 UU7)/13 – (88 UU9)/13) x y^2 + (-3 UU18 + (81 UU23)/80 – (")#linebreak()#text(" 81 UU24)/40 – (147 UU25)/40 + (147 UU26)/10 + (108 UU29)/")#linebreak()#text(" 25) x^2 y^2 + UU21 y^3 + UU25 x y^3 + UU30 y^4 + UU4 z +")#linebreak()#text(" UU6 x z + ((225 UU16)/52 – (5 UU18)/4 – (12 UU2)/5 – (567 UU20)/")#linebreak()#text(" 520 – (225 UU21)/52 – (225 UU22)/26 + (189 UU23)/1664 – (")#linebreak()#text(" 1323 UU24)/832 – (45 UU25)/32 + (255 UU26)/32 + (1125 UU28)/")#linebreak()#text(" 208 – (3 UU29)/50 – (36 UU3)/13 – (225 UU30)/52 – (1125 UU31)/")#linebreak()#text(" 52 + (72 UU4)/13 – (3 UU5)/4 – (3 UU6)/2 + (45 UU7)/13 – (4 UU8)/")#linebreak()#text(" 5 – (60 UU9)/13) x^2 z + UU24 x^3 z +")#linebreak()#text(" UU7 y z + ((3 UU16)/2 + (3 UU21)/4 – 3 UU22 + (3 UU25)/16 – (3 UU26)/")#linebreak()#text(" 4 – (15 UU27)/16 + (15 UU28)/8 + (3 UU30)/2 – (15 UU31)/2) y^2 z +")#linebreak()#text(" UU27 y^3 z + ((5 UU16)/13 – (3 UU20)/208 – (15 UU21)/208 – (")#linebreak()#text(" 105 UU22)/52 + (5 UU23)/3328 – (35 UU24)/1664 – (3 UU25)/128 + (")#linebreak()#text(" 3 UU26)/32 + (25 UU28)/52 + (2 UU3)/13 – (15 UU30)/208 – (")#linebreak()#text(" 725 UU31)/208 – (4 UU4)/13 + (4 UU7)/13 – UU9/")#linebreak()#text(" 13) z^2 + (-((15 UU16)/13) + (3 UU20)/13 + (15 UU21)/13 + (")#linebreak()#text(" 30 UU22)/13 – (63 UU23)/2080 + (363 UU24)/1040 + (3 UU25)/8 – (")#linebreak()#text(" 27 UU26)/8 – (75 UU28)/52 + (48 UU3)/65 + (15 UU30)/13 + (")#linebreak()#text(" 75 UU31)/13 – (96 UU4)/65 + UU5/5 – (2 UU6)/5 – (12 UU7)/13 + (")#linebreak()#text(" 16 UU9)/13) x z^2 + UU18 x^2 z^2 +")#linebreak()#text(" UU16 y z^2 + ((3 UU27)/4 + (3 UU28)/2 – (3 UU30)/5 –")#linebreak()#text(" 3 UU31) y^2 z^2 + UU22 z^3 + UU26 x z^3 + UU28 y z^3 + UU31 z^4")

#text("FG= -((9 UU2)/4) + (27 UU20)/64 + (513 UU23)/2048 + (27 UU24)/1024 – (")#linebreak()#text(" 243 UU25)/512 + (2097 UU26)/512 + (153 UU29)/160 – (45 UU5)/64 – (")#linebreak()#text(" 45 UU6)/32 + (6 UU2 – (99 UU23)/256 + (99 UU24)/128 + (99 UU25)/")#linebreak()#text(" 64 – (771 UU26)/64 – (33 UU29)/20 + (15 UU5)/8 + (15 UU6)/")#linebreak()#text(" 4) x + (-3 UU2 – (27 UU20)/16 – (117 UU23)/512 – (423 UU24)/")#linebreak()#text(" 256 – (153 UU25)/128 + (987 UU26)/128 + (33 UU29)/40 – (15 UU5)/")#linebreak()#text(" 16 – (15 UU6)/8) x^2 + (UU20 + UU23/4 + (3 UU24)/4 + UU25/4 –")#linebreak()#text(" UU26 – (8 UU29)/5) x^3 +")#linebreak()#text(" UU29 x^4 + (-((675 UU16)/104) + 6 UU2 – (81 UU20)/208 + (675 UU21)/")#linebreak()#text(" 104 + (675 UU22)/52 – (8919 UU23)/16640 + (4869 UU24)/8320 + (")#linebreak()#text(" 369 UU25)/160 – (4827 UU26)/320 – (3375 UU28)/416 – (123 UU29)/")#linebreak()#text(" 50 + (54 UU3)/13 + (675 UU30)/104 + (3375 UU31)/104 – (108 UU4)/")#linebreak()#text(" 13 + (15 UU5)/8 + (15 UU6)/4 – (135 UU7)/26 + (90 UU9)/13) y + ((")#linebreak()#text(" 225 UU16)/13 – 8 UU2 – (45 UU20)/13 – (225 UU21)/13 – (450 UU22)/")#linebreak()#text(" 13 + (1929 UU23)/4160 – (10929 UU24)/2080 – (453 UU25)/80 + (")#linebreak()#text(" 2437 UU26)/80 + (1125 UU28)/52 + UU29/25 – (144 UU3)/13 – (")#linebreak()#text(" 225 UU30)/13 – (1125 UU31)/13 + (288 UU4)/13 – (5 UU5)/2 –")#linebreak()#text(" 5 UU6 + (180 UU7)/13 – (240 UU9)/13) x y + (-((225 UU16)/26) + (")#linebreak()#text(" 207 UU20)/52 + (225 UU21)/26 + (225 UU22)/13 – (441 UU23)/1040 + (")#linebreak()#text(" 6057 UU24)/1040 + (243 UU25)/80 – (243 UU26)/20 – (1125 UU28)/")#linebreak()#text(" 104 + (9 UU29)/25 + (72 UU3)/13 + (225 UU30)/26 + (1125 UU31)/")#linebreak()#text(" 26 – (144 UU4)/13 – (90 UU7)/13 + (120 UU9)/13) x^2 y + ((3 UU23)/")#linebreak()#text(" 5 – (6 UU24)/5 – (2 UU25)/5 + (8 UU26)/5 + (64 UU29)/")#linebreak()#text(" 25) x^3 y + ((225 UU16)/26 – 3 UU2 – (243 UU20)/208 – (225 UU21)/")#linebreak()#text(" 26 – (225 UU22)/13 – (981 UU23)/33280 – (23319 UU24)/16640 – (")#linebreak()#text(" 1773 UU25)/640 + (8967 UU26)/640 + (1125 UU28)/104 + (381 UU29)/")#linebreak()#text(" 200 – (72 UU3)/13 – (225 UU30)/26 – (1125 UU31)/26 + (144 UU4)/")#linebreak()#text(" 13 – (15 UU5)/16 – (15 UU6)/8 + (90 UU7)/13 – (120 UU9)/")#linebreak()#text(" 13) y^2 + (-((375 UU16)/26) + (189 UU20)/52 + (375 UU21)/26 + (")#linebreak()#text(" 375 UU22)/13 – (579 UU23)/1040 + (5883 UU24)/1040 + (417 UU25)/")#linebreak()#text(" 80 – (417 UU26)/20 – (1875 UU28)/104 – (9 UU29)/25 + (120 UU3)/")#linebreak()#text(" 13 + (375 UU30)/26 + (1875 UU31)/26 – (240 UU4)/13 – (150 UU7)/")#linebreak()#text(" 13 + (200 UU9)/13) x y^2 + ((27 UU23)/20 – (27 UU24)/10 – (")#linebreak()#text(" 33 UU25)/20 + (33 UU26)/5 + (54 UU29)/")#linebreak()#text(" 25) x^2 y^2 + (-((25 UU16)/13) + (23 UU20)/26 + (25 UU21)/13 + (")#linebreak()#text(" 50 UU22)/13 + (107 UU23)/520 + (361 UU24)/520 + (39 UU25)/40 – (")#linebreak()#text(" 39 UU26)/10 – (125 UU28)/52 – (46 UU29)/25 + (16 UU3)/13 + (")#linebreak()#text(" 25 UU30)/13 + (125 UU31)/13 – (32 UU4)/13 – (20 UU7)/13 + (")#linebreak()#text(" 80 UU9)/39) y^3 + ((3 UU23)/5 – (6 UU24)/5 – (7 UU25)/5 + (")#linebreak()#text(" 28 UU26)/5 + (64 UU29)/25) x y^3 +")#linebreak()#text(" UU29 y^4 + ((675 UU16)/208 + 3 UU2 – (621 UU20)/416 – (675 UU21)/")#linebreak()#text(" 208 – (675 UU22)/104 – (20799 UU23)/33280 – (10251 UU24)/16640 + (")#linebreak()#text(" 99 UU25)/320 – (2667 UU26)/640 + (3375 UU28)/832 – (129 UU29)/")#linebreak()#text(" 50 – (27 UU3)/13 – (675 UU30)/208 – (3375 UU31)/208 + (54 UU4)/")#linebreak()#text(" 13 + (15 UU5)/16 + (15 UU6)/8 + (135 UU7)/52 – (45 UU9)/")#linebreak()#text(" 13) z + (-((225 UU16)/26) – 4 UU2 + (45 UU20)/26 + (225 UU21)/")#linebreak()#text(" 26 + (225 UU22)/13 + (5169 UU23)/8320 + (3831 UU24)/4160 – (")#linebreak()#text(" 93 UU25)/160 + (997 UU26)/160 – (1125 UU28)/104 + (181 UU29)/")#linebreak()#text(" 50 + (72 UU3)/13 + (225 UU30)/26 + (1125 UU31)/26 – (144 UU4)/")#linebreak()#text(" 13 – (5 UU5)/4 – (5 UU6)/2 – (90 UU7)/13 + (120 UU9)/13) x z + ((")#linebreak()#text(" 225 UU16)/52 + (27 UU20)/104 – (225 UU21)/52 – (225 UU22)/26 + (")#linebreak()#text(" 909 UU23)/2080 – (1143 UU24)/2080 + (63 UU25)/160 – (63 UU26)/")#linebreak()#text(" 40 + (1125 UU28)/208 – (81 UU29)/50 – (36 UU3)/13 – (225 UU30)/")#linebreak()#text(" 52 – (1125 UU31)/52 + (72 UU4)/13 + (45 UU7)/13 – (60 UU9)/")#linebreak()#text(" 13) x^2 z + (-(UU23/5) + (2 UU24)/5 – UU25/5 + (4 UU26)/5 + (")#linebreak()#text(" 32 UU29)/25) x^3 z + (-4 UU2 + (9 UU20)/4 + (105 UU23)/128 + (")#linebreak()#text(" 75 UU24)/64 – (15 UU25)/32 + (185 UU26)/32 + (47 UU29)/10 – (")#linebreak()#text(" 5 UU5)/4 – (5 UU6)/2) y z + (-((75 UU16)/52) – (9 UU20)/104 + (")#linebreak()#text(" 75 UU21)/52 + (75 UU22)/26 + (633 UU23)/2080 – (1491 UU24)/")#linebreak()#text(" 2080 + (51 UU25)/160 – (51 UU26)/40 – (375 UU28)/208 – (117 UU29)/")#linebreak()#text(" 50 + (12 UU3)/13 + (75 UU30)/52 + (375 UU31)/52 – (24 UU4)/13 – (")#linebreak()#text(" 15 UU7)/13 + (20 UU9)/13) y^2 z + (-(UU23/5) + (2 UU24)/5 – UU25/")#linebreak()#text(" 5 + (4 UU26)/5 + (32 UU29)/25) y^3 z + (-((225 UU16)/52) – UU2 + (")#linebreak()#text(" 297 UU20)/208 + (225 UU21)/52 + (225 UU22)/26 + (21297 UU23)/")#linebreak()#text(" 33280 + (8403 UU24)/16640 – (39 UU25)/640 + (781 UU26)/640 – (")#linebreak()#text(" 1125 UU28)/208 + (523 UU29)/200 + (36 UU3)/13 + (225 UU30)/52 + (")#linebreak()#text(" 1125 UU31)/52 – (72 UU4)/13 – (5 UU5)/16 – (5 UU6)/8 – (45 UU7)/")#linebreak()#text(" 13 + (60 UU9)/13) z^2 + ((75 UU16)/13 – (15 UU20)/13 – (75 UU21)/")#linebreak()#text(" 13 – (150 UU22)/13 – (243 UU23)/520 – (33 UU24)/65 + (3 UU25)/")#linebreak()#text(" 5 – (12 UU26)/5 + (375 UU28)/52 – (66 UU29)/25 – (48 UU3)/13 – (")#linebreak()#text(" 75 UU30)/13 – (375 UU31)/13 + (96 UU4)/13 + (60 UU7)/13 – (")#linebreak()#text(" 80 UU9)/13) x z^2 + (-((9 UU23)/80) + (9 UU24)/40 – (27 UU25)/")#linebreak()#text(" 40 + (27 UU26)/10 + (18 UU29)/25) x^2 z^2 + ((75 UU16)/26 – (")#linebreak()#text(" 69 UU20)/52 – (75 UU21)/26 – (75 UU22)/13 – (111 UU23)/208 – (")#linebreak()#text(" 123 UU24)/208 – (9 UU25)/16 + (9 UU26)/4 + (375 UU28)/104 –")#linebreak()#text(" 3 UU29 – (24 UU3)/13 – (75 UU30)/26 – (375 UU31)/26 + (48 UU4)/")#linebreak()#text(" 13 + (30 UU7)/13 – (40 UU9)/13) y z^2 + (-((9 UU23)/80) + (")#linebreak()#text(" 9 UU24)/40 + (3 UU25)/40 – (3 UU26)/10 + (18 UU29)/")#linebreak()#text(" 25) y^2 z^2 + ((75 UU16)/52 – (43 UU20)/104 – (75 UU21)/52 – (")#linebreak()#text(" 75 UU22)/26 – (659 UU23)/2080 + (243 UU24)/2080 + (37 UU25)/")#linebreak()#text(" 160 – (37 UU26)/40 + (375 UU28)/208 – (59 UU29)/50 – (12 UU3)/")#linebreak()#text(" 13 – (75 UU30)/52 – (375 UU31)/52 + (24 UU4)/13 + (15 UU7)/13 – (")#linebreak()#text(" 20 UU9)/13) z^3 + ((3 UU23)/20 – (3 UU24)/10 – (3 UU25)/5 + (")#linebreak()#text(" 12 UU26)/5 + (16 UU29)/25) x z^3 + ((3 UU23)/20 – (3 UU24)/10 –")#linebreak()#text(" UU25/10 + (2 UU26)/5 + (16 UU29)/25) y z^3 + (UU23/16 – UU24/8 –")#linebreak()#text(" UU25/8 + UU26/2 + UU29/5) z^4")

#text("FH= (3 HH9)/8 – (9 SS10)/8 – (3 SS4)/2 – (")#linebreak()#text(" 9 SS7)/16 + (-((3 HH9)/4) + (3 SS10)/4 + SS4 – (3 SS6)/2 + (9 SS7)/")#linebreak()#text(" 8) x + (HH9/3 + SS6 – SS7/2) x^2 + (-((3 HH9)/2) + (3 SS10)/2 +")#linebreak()#text(" 2 SS4 + (3 SS7)/4) y + ((4 HH9)/3 + 2 SS6 – SS7) x y +")#linebreak()#text(" HH9 y^2 + (-(HH9/4) – (3 SS10)/4 + SS4 + (3 SS7)/8) z + (HH9/3 +")#linebreak()#text(" SS10 + SS6 – SS7/2) x z + ((2 HH9)/3 + 2 SS10) y z + SS10 z^2")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-270601")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2014")])]

#text("I computed the J sum to be 0.06142977105 (using the decimal data with Aubrey’s correction; I just saw the rational values but have not yet input them). This is close to what you have (in fact, my ratio is somewhat better), but the numerical discrepancy is a little troubling. Here is the breakdown:")

#text("J1 = 0.005366492245")#linebreak()#text(" J2 = 0.0002247808601")#linebreak()#text(" J3 = 0.002180015009")#linebreak()#text(" J4 = 0.0001510339809")#linebreak()#text(" J5 = 0.001311833953")#linebreak()#text(" J6 = 0.0004372898451")#linebreak()#text(" J7 = 0.0003343819451")#linebreak()#text(" J8 = 0.0002324673362")

#text("I have not yet verified the formulae for the J integrals; I am going to do that next.")

#text("(the code below should be run after the previous set of code).")

#raw("")

#text("FAxyz := FA;")#linebreak()#text(" FAyzx := subs( {x=y,y=z,z=x}, FA );")#linebreak()#text(" FAzyx := subs( {x=z,z=x}, FA );")#linebreak()#text(" FBxyz := FB;")#linebreak()#text(" FByzx := subs( {x=y,y=z,z=x}, FB );")#linebreak()#text(" FBzyx := subs( {x=z,z=x}, FB );")#linebreak()#text(" FCxyz := FC;")#linebreak()#text(" FCyzx := subs( {x=y,y=z,z=x}, FC );")#linebreak()#text(" FCzyx := subs( {x=z,z=x}, FC );")#linebreak()#text(" FExyz := FE;")#linebreak()#text(" FEyzx := subs( {x=y,y=z,z=x}, FE );")#linebreak()#text(" FEzyx := subs( {x=z,z=x}, FE );")#linebreak()#text(" FSxyz := FS;")#linebreak()#text(" FSyzx := subs( {x=y,y=z,z=x}, FS );")#linebreak()#text(" FSzyx := subs( {x=z,z=x}, FS );")#linebreak()#text(" FTxyz := FT;")#linebreak()#text(" FTyzx := subs( {x=y,y=z,z=x}, FT );")#linebreak()#text(" FTzyx := subs( {x=z,z=x}, FT );")#linebreak()#text(" FUxyz := FU;")#linebreak()#text(" FUyzx := subs( {x=y,y=z,z=x}, FU );")#linebreak()#text(" FUzyx := subs( {x=z,z=x}, FU );")#linebreak()#text(" FGxyz := FG;")#linebreak()#text(" FGyzx := subs( {x=y,y=z,z=x}, FG );")#linebreak()#text(" FGzyx := subs( {x=z,z=x}, FG );")#linebreak()#text(" FHxyz := FH;")#linebreak()#text(" FHyzx := subs( {x=y,y=z,z=x}, FH );")#linebreak()#text(" FHzyx := subs( {x=z,z=x}, FH );")

#text("J1func := int(FAyzx, z=0..y) + int(FAzyx, z=y..x) + int(FAxyz, z=x..1-eps-x) + int(FBxyz, z=1-eps-x..1-eps-y) + int(FCxyz, z=1-eps-y..1+eps-x) + int(FUxyz, z=1+eps-x..1+eps-y) + int(FGxyz, z=1+eps-y..3/2-x-y);")#linebreak()#text(" J1 := int(int(J1func*J1func, y=0..x), x=0..1/2-eps);")

#text("J2func := int(FAyzx, z=0..y) + int(FAzyx, z=y..x) + int(FAxyz, z=x..1-eps-x) + int(FBxyz, z=1-eps-x..1-eps-y) + int(FCxyz, z=1-eps-y..3/2-x-y);")#linebreak()#text(" J2 := int(int(J2func*J2func, y=1/2-eps..x),x=1/2-eps..1/2-eps/2);")

#text("J3func := int(FAyzx, z=0..y) + int(FAzyx, z=y..x) + int(FAxyz, z=x..1-eps-x) + int(FBxyz, z=1-eps-x..1-eps-y) + int(FCxyz, z=1-eps-y..1+eps-x) + int(FTxyz, z=1+eps-x..3/2-x-y);")#linebreak()#text(" J3 := int(int(J3func*J3func, y=0..1/2-eps),x=1/2-eps..1/2-eps/2);")

#text("J4func := int(FAyzx, z=0..y) + int(FAzyx, z=y..1-eps-x) + int(FBzyx, z=1-eps-x..x) + int(FBxyz, z=x..1-eps-y) + int(FCxyz, z=1-eps-y..3/2-x-y);")#linebreak()#text(" J4 := int(int(J4func*J4func, y=1/2-eps..1-eps-x), x=1/2-eps/2..1/2);")

#text("J5func := int(FAyzx, z=0..y) + int(FAzyx, z=y..1-eps-x) + int(FBzyx, z=1-eps-x..x) + int(FBxyz, z=x..1-eps-y) + int(FCxyz, z=1-eps-y..1+eps-x) + int(FTxyz, z=1+eps-x..3/2-x-y);")#linebreak()#text(" J5 := int(int(J5func*J5func,y=0..1/2-eps),x=1/2-eps/2..1/2);")

#text("J6func := int(FAyzx, z=0..y) + int(FAzyx, z=y..1-eps-x) + int(FBzyx, z=1-eps-x..x) + int(FBxyz, z=x..1-eps-y) + int(FCxyz, z=1-eps-y..1+eps-x) + int(FSxyz, z=1+eps-x..1/2+eps) + int(FTxyz, z=1/2+eps..3/2-x-y);")#linebreak()#text(" J6 := int(int(J6func*J6func,y=x-2*eps..1-eps-x),x=2*eps..1/2+eps/2) + int(int(J6func*J6func,y=0..1-eps-x),x=1/2..2*eps);")

#text("J7func := int(FAyzx, z=0..y) + int(FAzyx, z=y..1-eps-x) + int(FBzyx, z=1-eps-x..x) + int(FBxyz, z=x..1-eps-y) + int(FExyz, z=1+eps-x..1-eps-y) + int(FSxyz, z=1-eps-y..1/2+eps) + int(FTxyz, z=1/2+eps..3/2-x-y);")#linebreak()#text(" J7 := int(int(J7func*J7func,y=0..x-2*eps),x=2*eps..1/2+eps/2);")

#text("J8func := int(FAyzx, z=0..y) + int(FAzyx, z=y..1-eps-x) + int(FBzyx, z=1-eps-x..1+eps-x) + int(FEzyx, z=1+eps-x..x) + int(FExyz, z=x..1-eps-y) + int(FSxyz, z=1-eps-y..1/2+eps) + int(FTxyz, z=1/2+eps..3/2-x-y);")#linebreak()#text(" J8 := int(int(J8func*J8func,y=0..1-eps-x),x=1/2+eps/2..1-eps);")

#text("Jsum := 6*(J1+J2+J3+J4+J5+J6+J7+J8);")#linebreak()
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-270604")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2014")])]

#text("Here are the values I get for the various J integral parts:")

#text("J1= 0.005361969338")#linebreak()#text(" J2= 0.0002247811682")#linebreak()#text(" J3= 0.002180020663")#linebreak()#text(" J4= 0.0001510347099")#linebreak()#text(" J5= 0.001311839873")#linebreak()#text(" J6= 0.0004372914519")#linebreak()#text(" J7= 0.0003090305213")#linebreak()#text(" J8= 0.0002324692288")

#text("The only one that doesn’t match well is the J7 component. (Looking at your code, I believe that the integral on Bxyz should have a different upper limit.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-270615")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2014")])]

#text("Thanks for checking! I now get J7 = 0.0003090289458 and J=0.06127746389. So J-2I is about ")#mi("3.3 \\times 10^{-5}")#text(", which is barely one order of magnitude above all the rounding errors we are seeing here – but presumably when we switch to the precise rational coefficients, this will no longer be a problem.")

#text("I did check (rather tediously) that all the limits of integration in the J integrals appear to be correct (other than my typo that you caught). Next step will be entering the precise rational data, then checking the marginals, and then we can call ")#mi("H_1 \\leq 6")#text(" on GEH confirmed. :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-270616")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2014")])]

#text("Excellent! As you noted, the integrals get quite tedious so it is good to get a double check on that computation. Thank you for doing that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-270623")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2014")])]

#text("With the rational values, I match your I and J integrals exactly! More precisely, I have")

#text("I = 0.03062470572 and J = 0.06125062172 (which are also enormous rational numbers). I put the code at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Notes_on_polytope_decomposition#Code")[#text("http://michaelnielsen.org/polymath1/index.php?title=Notes_on_polytope_decomposition#Code")]

#text("Last thing to do now is to check the marginals…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-270631")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2014")])]

#text("Good news – the marginals check out, and I also verified the range of integrations for the marginals. Actually, in the eps=1/4 case it looks like the M6 and M8 conditions are not needed, so one might possibly be able to get better/cleaner numbers and/or lower degrees by removing these conditions.")

#text("Anyway… I’m now listing H_1=6 on GEH as confirmed! If this were a physical collaboration, I’d pop the champagne about now, but we’ll have to content ourselves with virtual bubbly here. ;-)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269840")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2014")])]

#text("Rigorous confirmation using piecewise polynomial which does not satisfy the marginal condition:")

#text("Let ")#mi("v=v_F")#text(" be a vector representing (in some fixed order) the coefficients of a piecewise polynomial ")#mi("F")#text(".")#linebreak()#text(" The quadratic functionals ")#mi("J(F), I(F)")#text(" can be represented by")

#text("(1) ")#mi("J(F) = v^T A v , I(F) = v^T B v")

#text("where ")#mi("A, B")#text(" are fixed, positive semi-definite matrices.")

#text("Similarly, the marginal constraints can be represented by")

#text("(2) ")#mi("C v = 0")

#text("where ")#mi("C")#text(" is a fixed, full-rank matrix.")

#text("In order to confirm a solution to problem 1, we need to show the existence of a (representing) vector ")#mi("v")#text(" which satisfy (2) and")

#text("(3) ")#mi("v^T (A - 2 B) v > 0")

#text("Now suppose that a vector ")#mi("v_0")#text(" is given which satisfy (3) but not (2). The problem is to use this (approximate) information to show the existence of ")#mi("v")#text(" satisfying both (2) and (3).")

#text("The natural choice for ")#mi("v")#text(" is to take the projection of ")#mi("v_0")#text(" on the subspace satisfying (2), i.e")

#text("(4) ")#mi("v = v_0 - C^T (C C^T)^{-1} C v_0")

#text("Note that ")#mi("v")#text(" (automatically) satisfy (2), we need only to verify that it satisfy also (3). Since")

#mi("v^T(A-2 B)v \\geq v_0^T(A-2 B)v_0")

#tao-math("-\\left|\\left|v-v_0\\right|\\right|(2\\left|\\left|(A-2 B)v_0\\right|\\right|+\\left|\\left|A-2 B\\right|\\right| \\left|\\left|v-v_0\\right|\\right|)", block: false)

#text("The confirmation of (3) follows provided that we have a sufficiently small upper bound on ")#tao-math("\\left|\\left|v- v_0\\right|\\right|", block: false)#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269650")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("For a rigorous confirmation, the coefficients should be given as rational numbers (to satisfy the marginal vanishing constraints!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269655")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("True, but the fractions that arise are not suited to copy and pasting to this blog. One should be able to at least test whether the marginals get extremely close to zero.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269661")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("The problem is with the numerical sensitivity (i.e. how one knows that by slightly perturbing the coefficients in order to satisfy the constraints, the ratio still stays above 2 ?)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269296")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("This reminds me that in a previous comment (related to slow convergence) it was observed that certain coefficients were enforced to be zero (indicating significant loss in the remaining degrees of freedom.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6525d7cd9db10f0f8b9a18fa0e62f21ac78916ee3eed4debea5956daeaf030-72219f07d23f0f1bc893af77a76e1cfd99cff0d2c3626a52796f2e15ac6c7e88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of interested non-expert")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269525")[#strong[#text("interested non-expert")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2014")])]

#text("Hello! I wonder what the next step of this project is now, after Pace Nielsen’s code gave H_1<=6 and Terence Tao showed that this sieve can not get H_1<=4 (both on GEH). Is the next step expanding the result without (G)EH assumtion or are you trying to get a new sieve which might go beyond H_1<=4? Thanks and good luck :-)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269630")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("I’m beginning to incline to the view that we might soon declare victory on the Polymath8b project, even though the headline bound of 270 may still have some room for improvement. Initially, the hope was to use the Polymath8a results to improve these bounds, but (except for the m >= 2 results) the progress has instead proceeded in a slightly different direction, through advances in the sieves used and in the numerics. There are actually quite a lot of technical innovations that go into the Polymath8b results already in this regard, and it would make a sizeable paper (not quite as large as the Polymath8a behemoth, but still pretty big). Trying to also tack on Polymath8a type results (in particular, the tentative improvement to MPZ that requires some nontrivial algebraic geometry facts that have yet to be verified) may simply be too much for a single paper. So perhaps after we verify the H_1=6 results, and see if there are any “cheap” ways to push the 270 down further, we may just write up what we have. (There could always be a Polymath8c, of course; and, given recent history, there could also be a surprising new breakthrough coming from outside Polymath.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269639")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("Makes sense. An alternative might be to write up the [G]EH work and the unconditional work as separate papers – is that worth considering? The two papers might not be written at the same time, I guess – maybe the GEH setting may be felt to have reached a natural victory-declaring point but the unconditional setting not?")

#text("Since it’s been a while since the unconditional setting was discussed, there may be value in refreshing our memory by briefly collecting together the ideas that seemed to offer opportunities for cheap progress beyond H_1=270. Here’s what I can recall; am I missing anything?")

#text("1) Increasing theta from 0.5 to the polymath8a equivalent of 0.524 or so, as noted. If the current upper bounds of M and M’ are any guide, this might reduce k by as much as 10.")

#text("2) The epsilon trick. Seems like its impact will decay rather fast with k, but it’s too soon to say how fast, since it hasn’t been tried with two-digit k for any domain.")

#text("3) Exploring higher-degree F. On current evidence it’s looking, however, as though there’s very little more to squeeze here; my guess is that, for k of current interest, degrees of 25 and infinity will deliver k differing by at most 1.")

#text("4) Extending the domain of F from R to R’. The known upper bounds for M and M’ imply that k might fall by about 3 if methods used to get to k=54 are adapted to M’. I’m not clear whether there are currently any obstacles to this avenue.")

#text("5) Further extending the domain to some version of R’’. Even though the impact of extending R’ to R’’ fell short of initial expectations for small k, this could be a bigger win for two-digit k since the ratio of volumes is so much bigger (in particular, the simplex of size 2 is so huge that the extra volume arising from the prisms that comprise R+R may not even be worth considering). I think Eytan suggested that this might at least halve k.")

#text("Avenue (5) would seem to be the most promising quantitatively, but it could be the most challenging computationally. I believe there are two alternatives so far raised to the presumably-totally-impractical option of dissecting the polytope as with k=3:")

#text("– the method Terry outlined in ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258264")[#text("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258264")]#text(" . However, Pace noted that even this is likely to be combinatorially challenging as k rises.")

#text("– the grid-point scheme proposed by polikimre in ")#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268675")[#text("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-268675")]#text(" – but maybe the computations are daunting there too. In that regard might it be worth looking at grids of hybrid granularity – coarser for coordinates further from the R’’ boundary?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269674")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("A couple of small followups relating to computational complexity:")

#text("– In ")#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263500")[#text("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263500")]#text(" Terry provided a “cheap scaling trick” for incorporating epsilon after F has already been chosen, but as far as I can see Pace is instead calculating F with epsilon already specified. I’m unclear as to the status of Terry’s trick – and, in particular, whether it can be applied for larger R or larger k. If it can, could it provide a significant efficiency saving?")

#text("– A trick that Pace is indeed using for k=3 is to restrict the monomials of F to have only two dimensions with non-zero exponents, taking advantage of the calculus-of-variations observation that allowed F to be converted to G. This has turned out to be of only modest utility for k=3, because the key goal was reached with only low-degree polynomials – but does it also work for larger k? In ")#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264256")[#text("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264256")]#text(" Terry explained that one cannot iterate on this idea with k=3, but even restricting to monomials with at most k-1 dimensions represented could be a significant efficiency win if the degree is being allowed to rise into two digits.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269683")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("Another possibility is to use the largest possible ")#mi("R")#text(" (as described in a previous, comment – 30 January, 5:11 pm). The idea is to get rid of the ")#mi("R+R")#text(" constraint by replacing it with a weaker constraint on ")#mi("F")#text(" (which is automatically satisfied for this largest ")#mi("R")#text(".) Unfortunately, there is no response yet to the potential use of this large ")#mi("R")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269689")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("Ah yes. Is that essentially equivalent to the “free boundary problem” idea that Terry mentioned in ")#link("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267880")[#text("https://terrytao.wordpress.com/2014/01/17/polymath8b-vi-a-low-dimensional-variational-problem/#comment-267880")]#text(" ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269693")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("Perhaps it looks similar, but the idea here (as confirmed by Terry to my previous question) is that the constraint on ")#mi("R+R")#text(" is not really needed but a (weaker) constraint on ")#mi("F")#text(" is what really needed!")#linebreak()#text(" It follows that the latter constraint on ")#mi("F")#text(" automatically holds by choosing the above largest ")#mi("R")#text(" (without satisfying the original constraint on ")#mi("R+R")#text(" – which is no more needed for this large ")#mi("R")#text("!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269696")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("Going further back, Terry also offered a couple of other ideas back before Christmas for expanding the domain in ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258637")[#text("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258637")]#text(" – so there seems to be no shortage of options in that regard. However, I have no idea to what extent those older ideas are obviated by more recent ones such as the epsilon trick.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269703")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("Yes. but note that this large ")#mi("R")#text(" seems to be the largest possible (since it is the region containing ")#mi("R+R")#text(" – according to the current “too strong” constraint on ")#mi("R+R")#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269710")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("Sure – it’s just that it remains to be seen whether there are greater difficulties in computing with that choice than with others.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-269786")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2014")])]

#text("Building on the hybrid grid notion, I wonder whether in some scenarios it could be useful to change grid size as a function not only of space but also of time, in order to radically reduce expected # of processor cycles relative to a static grid.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-270206")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2014")])]

#text("Here is a question of a more general type. Selberg’s beautiful original application for his sieve was to give an upper bound for the number of k-tuples of primes of the form ")#mi("p+h_1,p+h_2,...,p+h_k")#text(" and this upper bound was ")#mi("2^k k!")#text(" (or so) times the Hardy-Littlewood conjecture. Are the new methods developed recently capable of improving this bound, even based on conjectures like EH or GEH? Incidently what is a good self-contained place to read about Selberg’s original application?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-270328")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")])]

#text("This is a good question! Here’s what I think the situation is with the most general sieve we have: the count for prime k-tuples given by a sieve with cutoff function F overshoots the expected number predicted by the prime tuples conjecture by the quantity")

#mi("\\displaystyle \\frac{\\int F^2\\ dt_1 \\dots dt_k}{(\\int F\\ dt_1\\dots dt_k)^2},")

#text("and in particular if F is the indicator function of a region R (which is the optimal case given that F is supported on R), the overshoot is the reciprocal of the volume of R.")

#text("Now, the constraints on R are that ")#mi("R+R")#text(" lies in the union of the simplex")

#mi("\\{ (t_1,\\dots,t_k): t_1+\\dots+t_k \\leq 1 \\}")

#text("and the prisms")

#mi("\\{ (t_1,\\dots,t_k): t_1+\\dots+t_{i-1}+t_{i+1}+\\dots+t_k \\leq \\theta; t_i \\leq 1 \\}")

#text("where ")#mi("\\theta")#text(" is the level of distribution (1/2 from BV, or 1 if one assumes GEH).")

#text("Selberg’s original argument, in this language, amounts to taking R to be the simplex ")#mi("\\{ t_1+\\dots+t_k \\leq 1/2 \\}")#text(", which has volume ")#mi("\\frac{1}{2^k k!}")#text(", explaining the overshoot by ")#mi("2^k k!")#text(". One can also take the prism ")#mi("\\{ t_1+\\dots+t_{k-1} \\leq \\theta/2; t_k \\leq 1 \\}")#text(", which has volume ")#mi("\\frac{\\theta^{k-1}}{2^{k-1} (k-1)!}")#text(", giving an overshoot of ")#mi("2^{k-1} (k-1)! / \\theta^{k-1}")#text("; I think this bound was already known in the literature (one uses a k-1-dimensional Selberg sieve weighted by ")#mi("\\Lambda")#text("), though I don’t know of an explicit reference (the k=2 case is in Montgomery-Vaughan’s book though). We can take the simplex ")#mi("\\{t_1+\\dots+t_k \\leq \\frac{k}{k-1} \\frac{\\theta}{2} \\}")#text(", but this gives an inferior result even on GEH, namely ")#mi("2^k k! (\\frac{k-1}{k})^k / \\theta^k")#text(". There might be other choices of R that beat the prism, but I can’t think of one right now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of “New equidistribution estimates of Zhang type, and bounded gaps between primes” – and a retrospective | What's new")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-270283")[#strong[#text("“New equidistribution estimates of Zhang type, and bounded gaps between primes” – and a retrospective | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")])]

#text("[…] paper) to a fresh thread. (Discussion of the ongoing Polymath8b project is however being kept on a separate thread, to try to reduce […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8b, VIII: Time to start writing up the results? | What's new")]], [#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-270633")[#strong[#text("Polymath8b, VIII: Time to start writing up the results? | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2014")])]

#text("[…] for small values of (in particular ) or asymptotically as . The previous thread may be found here. The currently best known bounds on can be found at the wiki […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further/#comment-488031")[#strong[#text("Computers, Mathematics, and Complexity – Think Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2017")]

#text("[…] current best research tells us that there are infinitely many primes that differ by at most six. This was established […]")
]
