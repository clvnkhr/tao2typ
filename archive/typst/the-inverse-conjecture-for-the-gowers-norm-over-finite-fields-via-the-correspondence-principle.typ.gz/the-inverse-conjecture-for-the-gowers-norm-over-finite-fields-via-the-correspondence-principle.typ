// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/
// Converted to Typst by tao2typ: "2026-10-14T15:16:54.425875+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The inverse conjecture for the Gowers norm over finite fields via the correspondence principle", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The inverse conjecture for the Gowers norm over finite fields via the correspondence principle")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 November 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/")[#text("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.technion.ac.il/~tamarzr/")[#text("Tamar Ziegler")]#text(" and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" our paper, “")#link("http://arxiv.org/abs/0810.5527")[#text("The inverse conjecture for the Gowers norm over finite fields via the correspondence principle")]#text("“, submitted to ")#link("http://pjm.math.berkeley.edu/apde/about/cover/cover.html")[#text("Analysis & PDE")]#text(". As announced a few months ago in ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("this blog post")]#text(", this paper establishes (most of) the inverse conjecture for the Gowers norm from an ergodic theory analogue of this conjecture (in a forthcoming paper by ")#link("http://www.math.ohio-state.edu/~vitaly/")[#text("Vitaly Bergelson")]#text(", Tamar Ziegler, and myself, which should be ready shortly), using a variant of the Furstenberg correspondence principle. Our papers were held up for a while due to some unexpected technical difficulties arising in the low characteristic case; as a consequence, our paper only establishes the full inverse conjecture in the high characteristic case ")#mi("p \\geq k")#text(", and gives a partial result in the low characteristic case ")#mi("p < k")#text(".")

#text("In the rest of this post, I would like to describe the inverse conjecture (in both combinatorial and ergodic forms), and sketch how one deduces one from the other via the correspondence principle (together with two additional ingredients, namely a statistical sampling lemma and a local testability result for polynomials).")

#heading(level: 1)[#metadata(none) <tao-2950c3eefcb036d6fe70>#text("— Polynomials and the Gowers norm —")]

#text("Let F be a finite field, and let ")#mi("F^n")#text(" be a vector space over that field. Given any function ")#mi("P: F^n \\to {\\Bbb R}/{\\Bbb Z}")#text(" taking values in the unit circle ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(", we define the")#emph[#text(" additive derivative")]#text(" ")#mi("\\Delta^+ P: F^n \\to {\\Bbb R}/{\\Bbb Z}")#text(" of P in the direction h by the formula")

#align(center)[#mi("\\Delta^+_h f(x) := f(x+h) - f(x)")#text(".")]

#text("Now let ")#mi("k \\geq 0")#text(". A function ")#mi("P: F^n \\to {\\Bbb R}/{\\Bbb Z}")#text(" is said to be a ")#emph[#text("polynomial of degree ")#mi("<k")]#text(" if one has ")#mi("\\Delta^+_{h_1} \\ldots \\Delta^+_{h_k} P = 0")#text(" for all ")#mi("h_1,\\ldots,h_k \\in F^n")#text(". Thus for instance, the only polynomial of degree <0 is the zero function, the only polynomials of degree <1 are the constants, the only polynomial of degree <2 are the ")#link("http://en.wikipedia.org/wiki/Affine_transformation")[#text("affine")]#text(" ")#link("http://en.wikipedia.org/wiki/Character_(mathematics)")[#text("characters")]#text(", and so forth. If ")#mi("F=F_p")#text(" is a field of prime order, and we make the additional assumption that P takes values in the ")#mi("p^{th}")#text(" roots of unity (which we can identify with F in the usual manner), then we can express the polynomial P in the customary manner as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("P(x_1,\\ldots,x_n) = \\sum_{i_1+\\ldots+i_n < k} c_{i_1,\\ldots,i_n} x_1^{i_1} \\ldots x_n^{i_n}")]]

#text("for some coefficients ")#mi("c_{i_1,\\ldots,i_n} \\in F")#text("; let us refer to these as ")#emph[#text("classical polynomials of degree <k")]#text(". However, if one does not require P to take values in ")#mi("p^{th}")#text(" roots of unity, then the above definition also encompasses some non-classical polynomials. For instance, if ")#mi("F = F_2")#text(", the function ")#mi("P: F \\to {\\Bbb R}/{\\Bbb Z}")#text(" defined by P(0)=0 and P(1)=1/4 is of degree <3 (i.e. is a “quadratic” polynomial), but is not classical. [However, it is a nice exercise to show that in the high characteristic case ")#mi("p \\geq k")#text(", every polynomial of degree ")#mi("<k")#text(" can be expressed as the sum of a classical polynomial and a constant; thus the genuinely non-classical polynomials are a purely low characteristic phenomenon. I may write more about the relationship between classical and non-classical polynomials in a future post.]")

#text("We can define multiplicative analogues of the above concept. Given a function ")#mi("f: F^n \\to {\\Bbb C}")#text(", we define the ")#emph[#text("multiplicative derivative")]#text(" ")#mi("\\Delta_h^\\times f: F^n \\to {\\Bbb C}")#text(" to be the function")

#align(center)[#tao-fit-display[#mitex("\\Delta^\\times_h f(x) := f(x+h) \\overline{f(x)},")]]

#text("and say that f is a ")#emph[#text("phase polynomial of degree <k")]#text(" if ")#mi("\\Delta^\\times_{h_1} \\ldots \\Delta^\\times_{h_k} f = 1")#text(" for all ")#mi("h_1,\\ldots,h_k \\in F^n")#text(". It is not hard to show that f is a phase polynomial of degree <k if and only if ")#mi("f=e(P)")#text(" for some polynomial ")#mi("P: F^n \\to {\\Bbb R}/{\\Bbb Z}")#text(" of degree <k, where ")#mi("e:{\\Bbb R}/{\\Bbb Z} \\to {\\Bbb C}")#text(" is the standard character ")#mi("e(x) = e^{2\\pi i x}")#text(".")

#text("The ")#emph[#text("Gowers uniformity norms")]#text(" are a means to measure the extent to which an arbitrary function ")#mi("f: F^n \\to {\\Bbb C}")#text(" behaves like a phase polynomial; if ")#mi("k \\geq 1")#text(", they are defined by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^k(F^n)} := [{\\Bbb E}_{x,h_1,\\ldots,h_k \\in F^n} \\Delta^\\times_{h_1} \\ldots \\Delta^\\times_{h_k} f(x)]^{1/2^k}", block: true)]]

#text("where ")#tao-math("{\\Bbb E}_{a \\in A} f(a) := \\frac{1}{\\left|A\\right|} \\sum_{a \\in A} f(a)", block: false)#text(" denotes the average of f on A. Thus, for instance, if f is bounded in magnitude by 1, then ")#tao-math("\\left\\|f\\right\\|_{U^k(F^n)}", block: false)#text(" is a number between 0 and 1, and equals 1 if and only if f is a phase polynomial of degree <k.")

#text("We have just seen that exact extremisers of the Gowers norms are given by phase polynomials. This statement is in fact robust, in that near-exact extremisers of the Gowers norms are close to phase polynomials:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" (local testabilty of phase polynomials) Suppose that ")#mi("f: F^n \\to {\\Bbb C}")#text(" is bounded in magnitude by 1 and obeys the bound ")#tao-math("\\left\\|f\\right\\|_{U^k(F^n)} \\geq 1-\\varepsilon", block: false)#text(". Then there exists a phase polynomial g of degree <k such that ")#tao-math("{\\Bbb E}_x \\left|f(x)-g(x)\\right| = o_{\\varepsilon \\to 0;k}(1)", block: false)#text(", where ")#mi("o_{\\varepsilon \\to 0;k,F}(1)")#text(" denotes a quantity that goes to zero as ")#mi("\\varepsilon \\to 0")#text(" for fixed k, F, uniformly in the choice of f or n.")
]

#text("This fact is essentially due ")#link("http://www.ams.org/mathscinet-getitem?mr=2080792")[#text("to Alon, Kaufman, Krivelevich, Litsyn, and Ron")]#text("; their paper is focused on the case when ")#mi("F=F_2")#text(" and P is a classical polynomial, but it is not too difficult to extend the result to the generality of Theorem 1 (this is done in an appendix to our paper, as we need this local testability result in our arguments). One consequence of this theorem is that one can test (with high confidence) whether a given function is close to a phase polynomial of degree <k, by randomly computing some derivatives ")#mi("\\Delta^\\times_{h_1} \\ldots \\Delta^\\times_{h_k} f(x)")#text(" and seeing whether they are consistently close to 1. Note that this test is ")#emph[#text("local")]#text(", in the sense that one only has to evaluate f at a bounded number of positions in ")#mi("F^n")#text(" (even as ")#mi("n \\to \\infty")#text(") in order to perform the test.")

#text("Theorem 1 describes what happens when a function “behaves like a phase polynomial 99% of the time”, in the sense that the Gowers norm is very close to 1. The inverse conjecture for the Gowers norm addresses the more general case in which a function “behaves like a phase polynomial 51% of the time”, in the sense that the Gowers norm is bounded below by some small constant ")#mi("\\delta > 0")#text(". (Note that if ")#mi("F=F_2")#text(" and ")#mi("f: F^n \\to \\{-1,+1\\}")#text(" was a random boolean function, then ")#mi("\\Delta^\\times_{h_1} \\ldots \\Delta^\\times_{h_k} f(x)")#text(" would equal +1 about 50% of the time and -1 for the other 50%, leading to a very small Gowers norm.) More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Inverse Conjecture for the Gowers norm over finite fields.")]#text(" Let ")#mi("f: F^n \\to {\\Bbb C}")#text(" be a function bounded in magnitude by 1 such that ")#tao-math("\\left\\|f\\right\\|_{U^k(F^n)} \\geq \\delta > 0", block: false)#text(". Then there exists a phase polynomial g of degree <k such that ")#tao-math("\\left|{\\Bbb E} f(x) \\overline{g(x)}\\right| \\geq c(k,F,\\delta) > 0", block: false)#text(" for some ")#mi("c(k,F,\\delta)")#text(" independent of n.")
]

#text("This conjecture has a number of applications to the structural theory of additive patterns (e.g. arithmetic progressions) in subsets of ")#mi("F^n")#text("; see for instance this ")#link("http://arxiv.org/abs/0711.0185")[#text("paper of Gowers-Wolf")]#text(". It is also connected to various problems in computer science, such as generation of pseudorandom bits (see e.g. this ")#link("http://projectamericano.com/adib/pubs/lowdeggen.pdf")[#text("paper of Bogdanov-Viola")]#text("), and to polynomiality testing (see e.g. this ")#link("http://www.cs.huji.ac.il/~salex/papers/gowers.pdf")[#text("paper of Samorodnitsky-Trevisan")]#text(").")

#text("Previously, this conjecture had been verified for ")#mi("k \\leq 3")#text(" by ")#link("http://www.cs.huji.ac.il/~salex/papers/low_degree.ps")[#text("Samorodnitsky")]#text(" (in even ")#link("http://en.wikipedia.org/wiki/Characteristic_(algebra)")[#text("characteristic")]#text(") and by ")#link("http://front.math.ucdavis.edu/math.NT/0503014")[#text("Ben Green and myself")]#text(" (in odd characteristic). In high characteristic ")#mi("p \\geq k")#text(", a partial result (assuming that f was already a classical polynomial of bounded degree) was obtained by ")#link("http://arxiv.org/abs/0711.3191")[#text("Ben and myself")]#text("; but in low characteristic, it was discovered in that paper and simultaneously by ")#link("http://www.cs.huji.ac.il/~salex/papers/Gowers-false.pdf")[#text("Lovett-Meshulam-Samorodnitsky")]#text(" that the conjecture can fail if one restricts g to be a classical phase polynomial. Nevertheless we believe the conjecture should still in the low characteristic case hold if we allow g to be non-classical.")

#text("Our main results are as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2. ")]#text(" The inverse conjecture is true in the high characteristic case ")#mi("p \\geq k")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3.")]#text(" In general characteristic, a weaker form of the inverse conjecture is true, in which we allow g to be a phase polynomial of degree ")#mi("<C(k)")#text(" rather than ")#mi("<k")#text(", for some C(k) depending only on k.")
]

#text("As mentioned above, we expect that we should be able to take C(k)=k in any characteristic, but this seems to require a delicate algebraic analysis and we were not able to establish it here.")

#heading(level: 1)[#text("— Ergodic theory —")]

#text("We were able to deduce the combinatorial results in Theorems 2, 3 from ergodic analogues of these results. Roughly speaking, these ergodic results correspond to “local” versions of the “global” theorems in Theorem 2, 3, because they involve averaging over only a small portion of the underlying space, as opposed to the global averages used to define the Gowers norms. [In this regard, the ergodic theory results are weaker than the combinatorial ones. However, there is another direction in which the ergodic results are stronger, in that they encode some additional “measurability” information that is not present in the combinatorial setting; roughly speaking, this information asserts that the function g appearing in the above conjecture can be “locally reconstructed” from f in some sense, as opposed to merely existing in some non-constructive sense.] Fortunately, thanks to some “local-to-global” principles (including the local testability result in Theorem 1), we are able to pass back and forth between the two types of theorems in a fairly “soft” manner.")

#text("Whereas the combinatorial results take place in the finitary setting of a finite-dimensional vector space ")#mi("F^n")#text(", the ergodic theory results take place in the infinitary setting of a probability space ")#mi("(X, {\\mathcal B}, \\mu)")#text(" with a measure-preserving action ")#mi("(T_g)_{g \\in F^{\\omega}}")#text(" of the countably infinite vector space ")#mi("F^\\omega := \\lim_{n \\to \\infty} F^n = \\bigcup_n F^n")#text(". Given a measurable function ")#mi("f: X \\to {\\Bbb C}")#text(", one can define multiplicative derivatives")

#align(center)[#tao-fit-display[#mitex("\\Delta^\\times_h f(x) := f( T_h x ) \\overline{f(x)}")]]

#text("for ")#mi("h \\in F^\\omega")#text(", and we say that f is a ")#emph[#text("phase polynomial of degree <k")]#text(" if ")#mi("\\Delta^\\times_{h_1} \\ldots \\Delta^\\times_{h_k} f = 1")#text(" a.e. for all ")#mi("h_1,\\ldots,h_k \\in F^\\omega")#text(". We can also define the ")#emph[#text("Gowers-Host-Kra uniformity seminorm")]#text(" ")#tao-math("\\left\\|f\\right\\|_{U^k(X)}", block: false)#text(" for ")#mi("k \\geq 1")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^k(X)} := (\\lim_{n_1 \\to \\infty} \\ldots \\lim_{n_k \\to \\infty} {\\Bbb E}_{h_1 \\in F^{n_1}, \\ldots, h_k \\in F^{n_k}}", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\int_X \\Delta^\\times_{h_1} \\ldots \\Delta^\\times_{h_k} f\\ d\\mu)^{1/2^k};")]]

#text("it can be shown that the limits exist and that this is indeed a seminorm. Thus for instance, as in the combinatorial setting, phase polynomials of degree <k have a Gowers-Host-Kra seminorm of 1.")

#text("There is an analogue of the inverse conjecture:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Ergodic Inverse Conjecture for the Gowers norm over finite fields.")]#text(" Suppose that X is ")#link("http://en.wikipedia.org/wiki/Ergodic_(adjective)")[#text("ergodic")]#text(". Let ")#mi("f \\in L^\\infty(X)")#text(" be such that ")#tao-math("\\left\\|f\\right\\|_{U^k(X)} > 0", block: false)#text(". Then there exists a phase polynomial g of degree <k such that ")#tao-math("\\left|\\int_X f \\overline{g}\\ d\\mu\\right| > 0", block: false)#text(".")
]

#text("In a forthcoming paper of Bergelson, Ziegler, and myself, we show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2′. ")]#text(" The ergodic inverse conjecture is true in the high characteristic case ")#mi("p \\geq k")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3′.")]#text(" In general characteristic, a weaker form of the ergodic inverse conjecture is true, in which we allow g to be a phase polynomial of degree ")#mi("<C(k)")#text(" rather than ")#mi("<k")#text(", for some C(k) depending only on k.")
]

#text("The aim of the current paper is to deduce Theorems 2, 3 from Theorems 2′, 3′ respectively.")

#heading(level: 1)[#text("— Outline of proof —")]

#text("The main idea here is to use the compactness and contradiction argument as embodied in the Furstenberg correspondence principle (which was discussed in my ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("previous blog post")]#text("). Suppose for instance that Theorem 2 failed; then one would have a sequence of bounded functions ")#mi("f_j: F^{n_j} \\to {\\Bbb C}")#text(" (where ")#mi("n_j")#text(" is going off to infinity) with Gowers norms of order k uniformly bounded from below, but such that ")#mi("f_j")#text(" becomes increasingly orthogonal to all phase polynomials of degree <k. The idea is then to exploit weak compactness to take a “limit”, which would be a bounded measurable function ")#mi("f \\in L^\\infty(X)")#text(" on some measure space X with an ")#mi("F^\\omega")#text(" action.")

#text("The problem in doing this is that the convergence given by weak compactness is only in the “weak” or “local” sense; for instance, one can establish convergence results for ")#emph[#text("local")]#text(" statistics, e.g.")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E}_{x \\in F^{n_j}} f_j(x) f_j(x+h) f_j(x+k) \\to \\int_X f(x) f(T_h x) f(T_k x)\\ d\\mu(x)")]]

#text("for any ")#emph[#text("fixed")]#text(" ")#mi("h, k \\in F^\\omega")#text(", but one cannot immediately establish convergence results for ")#emph[#text("global")]#text(" statistics, e.g.")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E}_{x,h,k \\in F^{n_j}} f_j(x) f_j(x+h) f_j(x+k)")]]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\not \\to \\lim_{N \\to \\infty} \\lim_{M \\to \\infty} {\\Bbb E}_{h \\in F^N, k \\in F^M} \\int_X f(x) f(T_h x) f(T_k x)\\ d\\mu(x)")]]

#text("for the limit objects X, f obtained by the traditional Furstenberg correspondence principle. To get around this, we first “shuffle” each of the original spaces ")#mi("F^{n_j}")#text(" by a randomly chosen general linear transformation before applying the correspondence principle argument (actually, to be more precise, we pull back ")#mi("F^{n_j}")#text(" to ")#mi("F^\\infty")#text(" using a random linear transformation from the latter to the former, but never mind this technical detail). The point of doing this shuffling is that it makes local averages approximate global averages with high confidence, for exactly the same reason that random polls with moderately large sample sizes can be accurate even when the overall population is enormous (see ")#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/")[#text("my previous post")]#text(" for more discussion on this). To cut a long story short, this shuffling (or “statistical sampling”) enables one to obtain convergence results such as (2). This serves several useful purposes in our paper. For instance, it allows us to ensure that the limit system X is ergodic. But more importantly, it allows us to carry the information that each ")#mi("f_j")#text(" has large Gowers norm into the limit, concluding that f has large Gowers-Host-Kra seminorm. Thus we are now in a position to apply the hypothesis Theorem 2′ (or Theorem 3′, if the objective is to prove Theorem 3) and conclude that f correlates with a phase polynomial g.")

#text("Now we want to pass back from the limit system to the original finitary systems and conclude the desired contradiction. A new problem emerges: the nature of the convergence of the latter to the former allows one to relate (local) statistics of ")#mi("f")#text(" to (local) statistics of ")#mi("f_j")#text(" (which in turn relate to global statistics of ")#mi("f_j")#text("), but says nothing about g. Fortunately, the ergodic inverse theorems tell us that g is measurable, which turns out to imply that g is “nearly local” in the sense that it can be approximated to arbitrary accuracy as some function g’ of finitely many shifts of f, which is almost a phase polynomial and will continue to correlate with f if the approximation is good enough. This latter object can be passed back to the original finitary systems, creating functions ")#mi("g^{\\prime}_j")#text(" correlating with ")#mi("f_j")#text(" which are also almost polynomials. To finish off the proof, we use the local testability (Theorem 1) to approximate ")#mi("g^{\\prime}_j")#text(" by a genuine phase polynomial; this means that the ")#mi("f_j")#text(" do, after all, have significant correlation with a phase polynomial, contradicting our hypothesis and establishing the result.")

#text("It is tempting to try to use this type of argument to handle the inverse conjecture for the Gowers norm on the integers ")#mi("{\\Bbb Z}")#text(", especially since ergodic inverse conjectures in this setting are already known thanks to the work of ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("Host-Kra")]#text(" (and also ")#link("http://www.ams.org/mathscinet-getitem?mr=2257397")[#text("Ziegler")]#text("). However, there are two non-trivial obstacles here. Firstly, one cannot “shuffle” the integers (or related objects, such as cyclic groups ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(") with the same degree of freedom as one can for a vector space, causing a difficulty in relating local and global statistics. Secondly, whereas polynomials are known to be local testable, the local testability of the analogous object for the integer case, namely that of nilsequences, is unknown. These difficulties do not appear to be totally insurmountable, but they would require some additional effort to resolve.")

#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/#comment-33365")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2008")])]

#text("Ah, this puts in context the interesting questions Tamar was asking me about “fake polynomials,” (which I guess in this context have the classier name of “non-classical”) in situations where the degree is larger than the cardinality of the finite field. The problem of classifying these guys really does seem interesting, and perhaps hard. By “perhaps hard” I guess I mean “I have no idea how to do it, but I don’t see a conceptual barrier to someone having an immensely clever idea and just knocking it off somehow.” In this sense, though, it reminds me of the affine cap problem, which also tantalizes the algebraic geometer with the hope that it’ll yield to one clever idea, and which, so far, hasn’t.")

#text("So let me see if I understand: when you say")

#text("“Nevertheless we believe the conjecture should still in the low characteristic case hold if we allow g to be non-classical.”")

#text("do you mean to say, independent of any connection with classical polynomials (i.e. degree-k subvarieties), there should be a theorem that says “if f fails equidistribution in the Gowers norm sense by 1%, f is correlated with something which is maximally badly distributed in the Gowers norm sense?”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/#comment-33369")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2008")])]

#text("Dear Jordan,")

#text("Yes, this is what we believe to be true. (It is already known to be true in the case of 99% non-equidistribution, as mentioned above.) I plan to post a bit more on these “non-classical” polynomials later; I think they aren’t as mysterious as, say, the capsets, because they already obey a very strong algebraic condition (their iterated derivatives always vanish) and so should be able to be studied by algebraic tools. Incidentally, a good example to keep in mind of such a polynomial is the function ")#tao-math("P_k(x_1,\\ldots,x_n) := (\\left|x_1\\right|+\\ldots+\\left|x_n\\right|)/2^k \\text{ mod } 1", block: false)#text(" on ")#mi("F_2")#text(", where ")#tao-math("x \\mapsto \\left|x\\right|", block: false)#text(" is the obvious map from ")#mi("F_2")#text(" to ")#mi("\\{0,1\\}")#text(". It’s a nice exercise to see inductively that ")#mi("P_k")#text(" is a non-classical polynomial of degree ")#mi("<k+1")#text(" (thus ")#mi("P_1")#text(" is linear, ")#mi("P_2")#text(" is quadratic, etc.). So I guess this corresponds to the “non-classical algebraic variety” ")#tao-math("\\{ (x_1,\\ldots,x_n): 2^k | \\left|x_1\\right| + \\ldots + \\left|x_n\\right| \\}", block: false)#text(".")

#text("We are able to show that any non-classical polynomial of degree <k in a field of characteristic p is also equal to a function of C(k,p) classical polynomials of degree <C(k,p) for some C(k,p) depending in an explicit fashion on k and p, so non-classical algebraic varieties are also classical algebraic varieties of somewhat higher degree. (For instance, in the above example, if we expand ")#mi("P_k")#text(" in binary as ")#mi("P_k = \\sum_{j=0}^{k-1} P_{k,j}/2^j")#text(" for ")#mi("P_{k,j} \\in \\{0,1\\} \\equiv F_2")#text(", then each ")#mi("P_{k,j}")#text(" is a classical polynomial of degree C(k,j) for some explicit C(k,j) independent of n.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/#comment-33405")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2008")])]

#text("I like the new banner Terry.")

#text("-Erik")

#emph[#text("[NB: the banner was intended for one day only, and has now reverted. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/#comment-33419")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2008")])]

#text("too bad, it was awesome :)")#linebreak()#text(" (the new banner that is)")#linebreak()#text(" jon")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An inverse theorem for the uniformity seminorms associated with the action of F^infty_p « What’s new")]], [#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/#comment-35118")[#strong[#text("An inverse theorem for the uniformity seminorms associated with the action of F^infty_p « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2009")])]

#text("[…] the action of “. This paper establishes the ergodic inverse theorems that are needed in our other recent paper to establish the inverse conjecture for the Gowers norms over finite fields in high characteristic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/147482393610484c93925d6cbc3fba1e520b6f37bd905f42a130fd2f770c7200-259e2682752c56e131b6737d34471f3ba2deafd53b7c6f786c1f43a38b2aeeff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of real estate")]], [#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/#comment-38152")[#strong[#text("real estate")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2009")])]

#text("I happened upon your blog and was fascinated with the theorem and proof.")

#text("Can you, if you would be so kind, illustrate to a layman such as myself the potential practical applications of this theorem.")

#text("Or is it more in the way of a cerebral exercise rather than practical. Please excuse my ignorance but this level of maths is well beyond me")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/#comment-38157")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2009")])]

#text("Dear real estate,")

#text("These results are more in the area of pure mathematics than applied mathematics – they aim to improve one’s general understanding of a mathematical phenomenon (in this case, a form of pseudorandomness called “Gowers uniformity”). A secondary aim here is also to get better at transferring the powerful techniques of ergodic theory to attack combinatorial problems, a strategy which has proven quite fruitful in the past but is still not as fully exploited as I believe it could be.")

#text("However, there are some applications which are related to these results. Bogdanov and Viola observed that a variant of this result allows for a new construction of pseudorandom strings of bits that can be efficiently generated, and which are guaranteed to “look random” with regard to any “polynomial test”.")

#text("There is also a corresponding inverse conjecture for the Gowers norm over the integers (which is not yet completely proven), which would imply, among other things, some rather precise asymptotic statements about the number of solutions to a variety of linear equations involving primes, see")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2008/11/18/marker-lectures-ii-linear-equations-in-primes/")[#text("Marker lectures II, “Linear equations in primes”")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iverson")]], [#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/#comment-38194")[#strong[#text("Iverson")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2009")])]

#text("Dear Terry:")#linebreak()#text(" Last time, i read your and Green’s paper, you obtain the asymptotic value of the progression in prime under the assume Mn(s) and GI(s), it is great and beatuiful result. And the Mn(s) is solved, whethe GI(s) is more difficlut than Mn(s), and the recent paper you with Ziegler or with Bergelson solve the case in the finite filed or the case of the original GI(s)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0b7c4aa131da825e9764009116e884e211c7ad7ac8e900e8db59f8a58433fd9-f65738458d08595e2fa6ae7c501d1de7723dbbae59671735eb6c701edecd8b54.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan O'Donnell")]], [#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/#comment-41535")[#strong[#text("Ryan O'Donnell")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2009")])]

#text("This recent paper of Haramaty and Shpilka contains several interesting new results in the same vein:")

#link("http://eccc.hpi-web.de/report/2009/080/")[#text("http://eccc.hpi-web.de/report/2009/080/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/#comment-118235")[#strong[#text("Szemerédi’s regularity lemma « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2011")]

#text("[…] are still being developed to generate what is being called higher-order Fourier analysis. See this post of Terence Tao for a discussion about this topic. Going back to what matters, let’s prove the Proposition 10 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deducing a weak ergodic inverse theorem from a combinatorial inverse theorem. | What's new")]], [#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/#comment-457638")[#strong[#text("Deducing a weak ergodic inverse theorem from a combinatorial inverse theorem. | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2015")])]

#text("[…] the ergodic inverse theorem by a variant of the Furstenberg correspondence principle, as worked out by Tamar Ziegler and myself, however in the current context of -actions, the connection is less […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on inverse theorem entropy | What's new")]], [#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/#comment-644064")[#strong[#text("Notes on inverse theorem entropy | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2022")])]

#text("[…] field of prime order (so that ), then the inverse theorem of Ziegler and myself (available in both high and low characteristic) allows one to obtain an -inverse theorem for some and the collection of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A Host–Kra ${bf F}^omega_2$-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the $U^6({bf F}^n_2)$ norm; The structure of totally disconnected Host–Kra–Ziegler factors, and the inverse th")]], [#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/#comment-675860")[#strong[#text("A Host–Kra ${bf F}^omega_2$-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the $U^6({bf F}^n_2)$ norm; The structure of totally disconnected Host–Kra–Ziegler factors, and the inverse th")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2023")])]

#text("[…] compared to . One approach to this theorem proceeds via ergodic theory. Indeed it was observed in this previous paper of Ziegler and myself that for a given choice of and , the above theorem follows from the following ergodic […]")
]
