// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/06/24/global-regularity-of-wave-maps-iv-absence-of-stationary-or-self-similar-solutions-in-the-energy-class/
// Converted to Typst by tao2typ: "2026-10-14T16:35:21.860933+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Global regularity of wave maps IV.  Absence of stationary or self-similar solutions in the energy class", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Global regularity of wave maps IV.  Absence of stationary or self-similar solutions in the energy class")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 June 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/06/24/global-regularity-of-wave-maps-iv-absence-of-stationary-or-self-similar-solutions-in-the-energy-class/")[#text("https://terrytao.wordpress.com/2008/06/24/global-regularity-of-wave-maps-iv-absence-of-stationary-or-self-similar-solutions-in-the-energy-class/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" the second installment of my “")#link("http://wordpress.com/tag/project-heatwave/")[#text("heatwave")]#text("” project, entitled “")#link("http://arxiv.org/abs/0806.3592")[#text("Global regularity of wave maps IV. Absence of stationary or self-similar solutions in the energy class")]#text("“. In the ")#link("https://terrytao.wordpress.com/2008/06/02/global-regularity-of-wave-maps-iii-large-energy-from-r12-to-hyperbolic-spaces/")[#text("first installment of this project")]#text(", I was able to establish the global existence of smooth ")#link("https://terrytao.wordpress.com/2007/08/30/pcm-deleted-scene-wave-maps/")[#text("wave maps")]#text(" from 2+1-dimensional spacetime ")#mi("{\\Bbb R}^{1+2}")#text(" to ")#link("http://en.wikipedia.org/wiki/Hyperbolic_space")[#text("hyperbolic space")]#text(" ")#mi("{\\bf H} = {\\bf H}^m")#text(" from arbitrary smooth initial data, conditionally on five claims:")

#enum(start: 1, 
[#text("A construction of an energy space for maps into hyperbolic space obeying a certain set of reasonable properties, such as compatibility with symmetries, approximability by smooth maps, and existence of a well-defined stress-energy tensor.")],
[#text("A large data local well-posedness result for wave maps in the above energy space.")],
[#text("The existence of an almost periodic “minimal-energy blowup solution” to the wave maps equation in the energy class, if this equation is such that singularities can form in finite time.")],
[#text("The non-existence of any non-trivial degenerate maps into hyperbolic space in the energy class, where “degenerate” means that one of the partial derivatives of this map vanishes identically.")],
[#text("The non-existence of any travelling or self-similar solution to the wave maps equation in the energy class.")]
)

#text("In this paper, the second of four in this series (or, as the title suggests, the fourth in a series of six papers on wave maps, the first two of which can be found ")#link("http://www.ams.org/mathscinet-getitem?mr=1820329")[#text("here")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1869874")[#text("here")]#text("), I verify Claims 1, 4, and 5. (The third paper in the series will tackle Claim 2, while the fourth paper will tackle Claim 3.) These claims are largely “elliptic” in nature (as opposed to the “hyperbolic” Claims 2, 3), but I will establish them by a “parabolic” method, relying very heavily on the harmonic map heat flow, and on the closely associated ")#emph[#text("caloric gauge")]#text(" introduced in an ")#link("http://www.ams.org/mathscinet-getitem?mr=2135366")[#text("earlier paper of mine")]#text(". The results of paper can be viewed as nonlinear analogues of standard facts about the linear energy space ")#mi("\\dot H^1({\\Bbb R}^2) \\times L^2({\\Bbb R}^2)")#text(", for instance the fact that smooth compactly supported functions are dense in that space, and that this space contains no non-trivial harmonic functions, or functions which are constant in one of the two spatial directions. The paper turned out a little longer than I had expected (77 pages) due to some surprisingly subtle technicalities, especially when excluding self-similar wave maps. On the other hand, the heat flow and caloric gauge machinery developed here will be reused in the last two papers in this series, hopefully keeping their length to under 100 pages as well.")

#text("A key stumbling block here, related to the critical (scale-invariant) nature of the energy space (or to the failure of the endpoint Sobolev embedding ")#mi("\\dot H^1({\\Bbb R}^2) \\not \\subset L^\\infty({\\Bbb R}^2)")#text(") is that changing coordinates in hyperbolic space can be a non-uniformly-continuous operation in the energy space. Thus, for the purposes of making quantitative estimates in that space, it is preferable to work as covariantly (or co-ordinate free) manner as possible, or if one is to use co-ordinates, to pick them in some canonical manner which is optimally adapted to the tasks at hand. Ideally, one would work with directly with maps ")#mi("\\phi: {\\Bbb R}^2 \\to {\\bf H}")#text(" (as well as their velocity field ")#mi("\\partial_t \\phi: {\\Bbb R}^2 \\to T{\\bf H}")#text(") without using any coordinates on ")#mi("{\\bf H}")#text(", but then it becomes to perform basic analytical operations on such maps, such as taking the Fourier transform, or (even more elementarily) taking the difference of two maps in order to measure how distinct they are from each other.")

#metadata(none) <tao-90a7a3d9f298a3c33fcf>

#text("Fortunately, the harmonic map heat flow can resolve a lot of these problems. Thanks to the negative curvature of the target manifold ")#mi("{\\bf H}")#text(", one can show that any (finite energy) map ")#mi("\\phi: {\\Bbb R}^2 \\to {\\bf H}")#text(" will contract under harmonic map heat flow to a single point (or more precisely, to a constant map). This result (essentially due to ")#link("http://www.ams.org/mathscinet-getitem?mr=164306")[#text("Eells and Sampson")]#text(") is consistent with the fact that ")#mi("{\\bf H}")#text(" does not support any non-trivial finite energy ")#link("http://en.wikipedia.org/wiki/Harmonic_map")[#text("harmonic maps ")]#text("(in contrast with positive curvature targets, such as the sphere), and is ultimately derived from a version of the ")#link("http://en.wikipedia.org/wiki/Bochner%27s_formula")[#text("Bochner-Weitzenböck identity")]#text(".")

#text("When the map has become constant, one can put a constant orthonormal frame on it. Running the heat flow backwards in time, and dragging back this frame, one obtains a canonical frame (up to a rotation of the entire frame) to place on the original map, which is remarkably “flat”, in the sense that its connection coefficients are small in various function space norms. I call this frame the “caloric gauge” for the map (as opposed to other frames one can place on such maps, such as the Coulomb gauge, radial gauge, Lorenz gauge, or Cronstrom gauge). It has the advantage of being well-defined and essentially unique even for large energy maps, so long as the target is negatively curved. (The situation here is analogous to that of using Ricci flow to understand the geometry of manifolds, as in Perelman’s proof of the Poincaré conjecture, though things are enormously simpler in the setting of harmonic map heat flows into hyperbolic space due to the lack of topological obstructions (the domain ")#mi("{\\Bbb R}^2")#text(" is contractible) or geometric obstructions (no non-trivial harmonic maps, which are the analogue of Ricci solitons); also, the heat flow equation is semilinear rather than quasilinear, with the geometry of the background domain being fixed rather than evolving).")

#text("When viewed in this gauge, the heat flow resembles a nonlinear version of the linear heat equation, and the velocity field (which now takes values in the vector space ")#mi("{\\Bbb R}^m")#text(") can be viewed as a nonlinear Littlewood-Paley resolution of the original map. It then becomes possible to define the energy space (and its attendant metric structure) using this resolution in exact analogy with standard Littlewood-Paley theory. One can then verify Claim 1 by a heavy use of parabolic regularity estimates.")

#text("Claims 4 and 5 are proven by the strategy of first applying the heat flow for a short amount of time to regularise the solution to the extent that formal computations can be justified rigorously (with all error terms incurred being manageable), and then adapting whatever arguments work in the smooth case to this regularised energy space setting. For instance, a non-trivial smooth finite energy map cannot have vanishing derivative in some direction, as this would cause the map to be constant for arbitrarily amounts of displacement in this direction, leading to an infinite amount of energy in the map. This argument can be adapted to regularised energy class maps, using a one-dimensional ")#link("http://en.wikipedia.org/wiki/Poincar%C3%A9_inequality")[#text("Poincaré inequality")]#text(" in that direction.")

#text("To rule out travelling wave maps (the first part of Claim 5), the idea is to represent each such travelling wave map as a (")#link("http://en.wikipedia.org/wiki/Length_contraction")[#text("Lorentz contracted")]#text(") harmonic map, and then use standard arguments (based on the ")#link("http://en.wikipedia.org/wiki/Bochner%27s_formula")[#text("Bochner-Weitzenböck identity")]#text(") to show such maps are trivial. [In principle, one could use ")#link("http://en.wikipedia.org/wiki/Lorentz_transformation")[#text("Lorentz transforms")]#text(" to send the velocity of the wave map to zero, but I had difficulty making these transforms cooperate with the initial value problem or the caloric gauge, and eventually abandoned any use of these transformations.] To do this one must first regularise the wave map via heat flow in order to be able to use the wave map equation classically (rather than in some weak or distributional sense), as this is necessary in order to establish the harmonic map property. Unfortunately, the heat flow and wave map equation do not quite commute, and so one has to measure this failure of commutativity quite precisely (and in particular, obtain bounds and uniform continuity for second time derivatives of wave maps under heat flow, which turns out to be rather delicate technically), and one eventually ends up with an approximate harmonic map rather than an exaclty harmonic map. Fortunately, one can use the heat flow again to show that such maps are nearly trivial, which suffices to establish the first part of Claim 5.")

#text("Similarly, by using hyperbolic polar coordinates one sees that self-similar wave maps are (formally) equivalent to harmonic maps on hyperbolic space, which can then be converted to a harmonic map on the unit disk by a conformal transformation. A classical ")#link("http://www.ams.org/mathscinet-getitem?mr=520601")[#text("argument of Lemaire")]#text(" shows that such maps are trivial if they are smooth and vanish on the boundary. I was unable to use this argument directly – it requires too much regularity (in particular, exploiting unique continuation, which is very expensive in regularity and not particularly stable) – but a heat flow argument turns out to work well instead. In order to keep boundary effects manageable, though, it was necessary to obtain additional decay of angular derivatives near this boundary, which we achieved using the holomorphicity of the Hopf differential (which was also a key component of Lemaire’s argument).")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2008/06/24/global-regularity-of-wave-maps-iv-absence-of-stationary-or-self-similar-solutions-in-the-energy-class/#comment-30638")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2008")])]

#text("Eh… there seems to be a small typo in the end of the third paragraph")#linebreak()#text(" after that 5-point list at the beginning of the post: it’s “W_ei_tzenböck”,")#linebreak()#text(" and not “W_ie_tzenböck”…")

#text("Great post, by the way… It’s very interesting how giving a course such")#linebreak()#text(" as this one on Perel’man’s proof of the Poincaré conjecture was able to")#linebreak()#text(" freshen up the mind with new insights… Eager to see the end of this")#linebreak()#text(" story!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/24/global-regularity-of-wave-maps-iv-absence-of-stationary-or-self-similar-solutions-in-the-energy-class/#comment-30663")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2008")])]

#text("Dear Pedro: Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Students")]], [#link("https://terrytao.wordpress.com/2008/06/24/global-regularity-of-wave-maps-iv-absence-of-stationary-or-self-similar-solutions-in-the-energy-class/#comment-30666")[#strong[#text("Students")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2008")])]

#text("Dear, Pro. Tao,")#linebreak()#text(" Great work!")#linebreak()#text(" I think that the inequality (23) in your preprint should be")#linebreak()#text(" ")#tao-math("\\left\\|\\partial_{x}^{k}e^{s\\triangle}u(x)\\right\\|_{L^{q}} \\lesssim s^{-(1/p-1/q)-k/2}\\left\\|u\\right\\|_{L^{p}}.", block: false)#linebreak()#text(" So, I think that you’d better to change s^{-2/p} of Lemma 2.5 to")#linebreak()#text(" s^{2/p}.")

#text("On the orther hand I don’t how to use Schur’s test in the last of your proof for Lemma 2.5. Would you like give some hints? Similarly to the last estimate in the proof of Lemma 2.5, can we get,")#linebreak()#text(" ")#tao-math("\\sum_{n=1}^{\\infty}2^{n/(p\\beta)}\\int_{0}^{\\infty} \\int_{2^{-n}s<=s^{^{\\prime}}<=2^{-n+1}s}f(s^{^{\\prime}})f(s)/s^{\\beta}dsds^{^{\\prime}} \\lesssim\\sum_{n=1}^{\\infty} 2^{n/(p\\beta)}2^{n/(p\\beta)}2^{-n/(2\\beta)}\\left\\|f\\right\\|^{2}_{L^{2}}", block: false)#text("?")#linebreak()#text(" Thank you very much")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/24/global-regularity-of-wave-maps-iv-absence-of-stationary-or-self-similar-solutions-in-the-energy-class/#comment-30674")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2008")])]

#text("Dear Students,")

#text("Thanks for the correction! But I believe the factor ")#mi("s^{-2/p}")#text(" in Lemma 2.5 is still correct; an application of the corrected version of (23) would bound this integral by a multiple of ")#mi("\\int_0^\\infty ds/s")#text(", which logarithmically diverges as claimed.")

#text("Schur’s test asserts that if a kernel ")#mi("K(x,y)")#text(" has all row integrals ")#mi("\\int |K(x,y)|\\ dx")#text(" bounded by A and all column integrals ")#mi("\\int |K(x,y)|\\ dy")#text(" bounded by B, then the integral operator ")#mi("T f(x) := \\int K(x,y) f(y)\\ dx")#text(" has an ")#mi("L^2")#text(" operator norm of at most ")#mi("A^{1/2} B^{1/2}")#text(" (and more generally, an ")#mi("L^p")#text(" operator norm of at most ")#mi("A^{1-1/p} B^{1/p}")#text(" for ")#mi("1 \\leq p \\leq \\infty")#text("). For Lemma 2.5, one would apply this lemma with ")#mi("K(s,s^{\\prime}) := \\frac{1}{s} 1_{2^n s \\leq s^{\\prime} \\leq 2^{n+1} s}")#text(". If the s denominator was replaced with ")#mi("s^\\beta")#text(", the resulting operator would not be bounded on ")#mi("L^2")#text(" (though it would obey some other ")#mi("(L^p,L^q)")#text(" estimates, which can be established by some generalisations of Schur’s test).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Students")]], [#link("https://terrytao.wordpress.com/2008/06/24/global-regularity-of-wave-maps-iv-absence-of-stationary-or-self-similar-solutions-in-the-energy-class/#comment-30676")[#strong[#text("Students")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2008")])]

#text("Dear Pro. Tao,")#linebreak()#text(" Thank you very much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ac3c48206cfa42079534194a93da90fd5b8c178db85ea5c50443c9270673242-70f00c58b67671a947b0766a90307a56f969c7b834a2ba80435fa1003cc87e19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charles Baker")]], [#link("https://terrytao.wordpress.com/2008/06/24/global-regularity-of-wave-maps-iv-absence-of-stationary-or-self-similar-solutions-in-the-energy-class/#comment-31193")[#strong[#text("Charles Baker")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2008")])]

#text("Hello Terry,")

#text("I was wondering if you could provide some quick comments on the possibility of extending these results of yours to positively curved targets that do not admit any non-trivial harmonic maps?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/24/global-regularity-of-wave-maps-iv-absence-of-stationary-or-self-similar-solutions-in-the-energy-class/#comment-31220")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2008")])]

#text("Dear Charles,")

#text("If the harmonic map heat flow does not develop any singularities, then in principle the method should also extend to this case, though in practice things become substantially more complicated technically if the curvature becomes non-constant. For the sphere, in analogy with other results in “focusing” nonlinear PDE, it seems plausible that one should have global regularity as long as the energy is smaller than that of the first non-trivial harmonic map, though again there are likely to be non-trivial technical issues in working all this out. I’m planning to have one of my graduate students look at some of these questions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ac3c48206cfa42079534194a93da90fd5b8c178db85ea5c50443c9270673242-70f00c58b67671a947b0766a90307a56f969c7b834a2ba80435fa1003cc87e19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charles Baker")]], [#link("https://terrytao.wordpress.com/2008/06/24/global-regularity-of-wave-maps-iv-absence-of-stationary-or-self-similar-solutions-in-the-energy-class/#comment-31734")[#strong[#text("Charles Baker")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2008")])]

#text("Thanks very much Terry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Global regularity of wave maps V. Large data local wellposedness in the energy class « What’s new")]], [#link("https://terrytao.wordpress.com/2008/06/24/global-regularity-of-wave-maps-iv-absence-of-stationary-or-self-similar-solutions-in-the-energy-class/#comment-31870")[#strong[#text("Global regularity of wave maps V. Large data local wellposedness in the energy class « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2008")])]

#text("[…] continuously on the initial data in the energy topology. (This topology was constructed in my previous paper.) Once one has this result, the only remaining task is to show a “Palais-Smale […]")
]
