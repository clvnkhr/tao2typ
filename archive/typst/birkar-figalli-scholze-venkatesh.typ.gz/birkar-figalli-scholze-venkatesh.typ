// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/
// Converted to Typst by tao2typ: "2026-10-14T16:38:23.794042+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Birkar, Figalli, Scholze, Venkatesh", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Birkar, Figalli, Scholze, Venkatesh")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 August 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/")[#text("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Every four years at the ")#link("https://en.wikipedia.org/wiki/International_Congress_of_Mathematicians")[#text("International Congress of Mathematicians")]#text(" (ICM), the ")#link("https://en.wikipedia.org/wiki/Fields_Medal")[#text("Fields Medal")]#text(" laureates are announced. Today, at the 2018 ICM in Rio de Janeiro, it was announced that the Fields Medal was awarded to ")#link("https://en.wikipedia.org/wiki/Caucher_Birkar")[#text("Caucher Birkar")]#text(", ")#link("https://en.wikipedia.org/wiki/Alessio_Figalli")[#text("Alessio Figalli")]#text(", ")#link("https://en.wikipedia.org/wiki/Peter_Scholze")[#text("Peter Scholze")]#text(", and ")#link("https://en.wikipedia.org/wiki/Akshay_Venkatesh")[#text("Akshay Venkatesh")]#text(".")

#text("After the two previous congresses in 2010 and 2014, I wrote ")#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/")[#text("blog")]#text(" ")#link("https://terrytao.wordpress.com/2014/08/12/avila-bhargava-hairer-mirzakhani/")[#text("posts")]#text(" describing some of the work of each of the winners. This time, though, I happened to be a member of the Fields Medal selection committee, and as such had access to a large number of confidential letters and discussions about the candidates with the other committee members; in order to have the opinions and discussion as candid as possible, it was explicitly understood that these communications would not be publicly disclosed. Because of this, I will unfortunately not be able to express much of a comment or opinion on the candidates or the process as an individual (as opposed to a joint statement of the committee). I can refer you instead to the ")#link("https://www.mathunion.org/imu-awards/fields-medal/fields-medals-2018")[#text("formal citations")]#text(" of the laureates (which, as a committee member, I was involved in crafting, and then signing off on), or the ")#link("https://www.quantamagazine.org/tag/2018-fields-medal-and-nevanlinna-prize-winners/")[#text("profiles of the laureates by Quanta magazine")]#text("; see also the short ")#link("https://www.simonsfoundation.org/mathematics-physical-sciences/news/")[#text("biographical videos of the laureates by the Simons Foundation")]#text(" that accompanied the formal announcements of the winners. I am sure, though, that there will be plenty of other mathematicians who will be able to present the work of each of the medalists (for instance, there was a ")#emph[#text("laudatio")]#text(" given at the ICM for each of the winners, which should eventually be made available at ")#link("http://www.icm2018.org/portal/en/prize-laudations")[#text("this link")]#text(").")

#text("I know that there is a substantial amount of interest in finding out more about the inner workings of the Fields Medal selection process. For the reasons stated above, I as an individual will unfortunately be unable to answer any questions about this process (e.g., I cannot reveal any information about other nominees, or of any comparisons between any two candidates or nominees). I think I can safely express the following two personal opinions though. Firstly, while I have served on many prize committees in the past, the process for the Fields Medal committee was by far the most thorough and deliberate of any I have been part of, and I for one learned an astonishing amount about the mathematical work of all of the shortlisted nominees, which was an absolutely essential component of the deliberations, in particular giving the discussions a context which would have been very difficult to obtain for an individual mathematician not in possession of all the confidential letters, presentations, and other information available to the committee (in particular, some of my preconceived impressions about the nominees going into the process had to be corrected in light of this more complete information). Secondly, I believe the four medalists are all extremely deserving recipients of the prize, and I fully stand by the decision of the committee to award the Fields medals this year to these four.")

#text("I’ll leave the comments to this post open for anyone who wishes to discuss the work of the medalists. But, for the reasons above, I will not participate in the discussion myself.")

#emph[#text("[Edit, Aug 1: looks like the ICM site is (barely) up and running now, so links have been added. At this time of writing, there does not seem to be an online announcement of the composition of the committee, but this should appear in due course. -T.]")]

#emph[#text("[Edit, Aug 9: the composition of the Fields Medal Committee for 2018 (which included myself) can be found ")#link("https://www.mathunion.org/imu-awards/fields-medal")[#text("here")]#text(". -T.]")]

#heading(level: 1)[#text("Comments (35)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503571")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("I would just like to point out that you forgot the n(which seems slightly amusing) in “laudation”. :)")

#emph[#text("[I am using the ")#link("https://en.wiktionary.org/wiki/laudatio")[#text("Latin form")]#text(" of the term. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30a9f9b1621abd7b04ca420171aed30e91677989bb7de01be4c0c07125fda1aa-e9a2701704eead7eabed2961af49f1c84539a18fc9b0d03fa0dc12f18b164224.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fausto di Biase")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503582")[#strong[#text("Fausto di Biase")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("In the web page of the icm2018 dedicated to the laudations, the title read ”Price Laudatios”, which is incorrect if it is meant to be latin, since the plural in latin is ”laudationes”, and it is also incorrect if it is meant to be in English, since then it is ”laudations”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6e6a6c5e828a574570011bdab079348b88d2eda6b8831851501f70858eb7e93-b6984f004f4662cfea331f5b113dd2e85bc4d2452c22034dcef995e3afc20043.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sameenahmedkhanS")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503573")[#strong[#text("sameenahmedkhanS")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("Heartiest Congratulations!!! From Sameen Ahmed KHAN, College of Arts and Applied Sciences, Dhofar University, Salalah, Sultanate of OMAN.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503574")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("I am really interested in who was on the committee. I know that this is made public after the winners are announced, but I haven’t seen it yet.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503595")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2018")])]

#text("Mori, Esnault, Feireisi, Guionnet, Hitchin, Morgan, Oh, Okounkov, Raghunathan, Ribet, Tao: ")#link("https://youtu.be/Webvi7vxUCk?t=2h46m1s")[#text("https://youtu.be/Webvi7vxUCk?t=2h46m1s")]

#text("ICM Committee: ")#link("https://youtu.be/Webvi7vxUCk?t=2h45m20s")[#text("https://youtu.be/Webvi7vxUCk?t=2h45m20s")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503787")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2018")])]

#text("More info here: ")#link("https://www.mathunion.org/fileadmin/IMU/ICM2018/Panelists_2018.pdf")[#text("https://www.mathunion.org/fileadmin/IMU/ICM2018/Panelists_2018.pdf")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503583")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("As Terry says, I think one gets Field medal is not difficult.Many people get medal, but after they go to the alley .They do not have any breakthrough.They sleep very very long.Rare a horse always that running unceasingly like Terry Tao")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503584")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("I believe you may have a small misspelling of Caucher Birkar’s name in the link text in the second sentence of the body.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503585")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("It’s now all over the internet that Caucher Birkar’s medal was stolen within minutes of his receiving it. He apparently put it in his briefcase (along with his cell phone and wallet) and then the briefcase was stolen after he had left it on the table. The Rio police are working on it and I hope they get the medal back. If they don’t get it back, I hope the ICM can issue Birkar with a duplicate. That would make him perhaps history’s first mathematician to receive TWO Fields medals, though in a less interesting way than that sounds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/238ee1d9da8ca3ab25eae81d3aa3599068e23fbed8a22a811722fdb0b83a4260-1a9364bf62fba8adbded36a283de2b887c05430a19bd40074afc7d7e23062258.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503587")[#strong[#text("Anthony")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("It seems coming to Australia as a baby, leaving to go to Princeton, and not moving back might be a good background to becoming a Fields medalist! :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf92cdffba8a3d9bc4cec429bede87218aa60c103282a6861c56d2f5c6b24108-7cfd7a275a8c8207780e950ef46b4198f8ae33fd828821151e769bfbfe3a7927.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wilsonofgordon")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503590")[#strong[#text("wilsonofgordon")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("as an australian IMOer i feel immense pressure now…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503591")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("Dear Terry. Have you been involved in the Fields medals only, or also in the Nevanlinna Prize?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4119bd6aa38ceec69e970f100ed27fae7af1470284b23fe82da938d3fd8a962-3c7fcd89e3f166b22e7f2289c1423b69c074700e6e583326c65dfeac908dde76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yok")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503597")[#strong[#text("Yok")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2018")])]

#text("Pierre-Louis Lions is a Fields medallist and thesis supervisor of Cedric Villani who is a Fields medallist and thesis supervisor of Allessio Figalli who is a Fields medallist.")#linebreak()#text(" Is there other examples of such triple-Fields “lineage”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reply")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503610")[#strong[#text("Reply")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2018")])]

#text("Schwartz, Grothendieck, Deligne.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503602")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2018")])]

#text("Slightly embarassing to Birkar: ")#link("https://www.theguardian.com/world/2018/aug/01/fields-medal-award-stolen-brazil-maths-prize")[#text("https://www.theguardian.com/world/2018/aug/01/fields-medal-award-stolen-brazil-maths-prize")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8fb5ff0275c4db4a1cd180a94ab81fcba1b401b18c5513c44a48ecf38f437b2e-b2d5e43b4a163c0397eec996bf16ad79d3c95ef44958fdead3d86ada76bb621a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fields medal – posttenuretourettes")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503609")[#strong[#text("Fields medal – posttenuretourettes")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2018")])]

#text("[…] kind of political considerations might have played a role in the decision. For one thing, Terry Tao served on the prize committee, and seeing as his blog masthead features the zeroth amendment and how […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503627")[#strong[#text("I quattro filmati ufficiali sulle medaglie Fields 2018 e non solo | Maddmaths!")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2018")]

#text("[…] Terence Tao essendo stato in commissione non si esprime come gli altri anni, ma commenta brevemente. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dac6643d4ca0f9533c209d483318a1c0e6cbf4176397b59ec29f1da7c3f26b6-56165df5b336697819e6aff2efaa8268db777a4cb1536d9ad53cbba6cf3f88d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of florian")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503633")[#strong[#text("florian")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2018")])]

#text("For the Nobel prizes they publish a sientific background information for each prize, which is often very usefull for scientists working in different (or even related) fields. A similar scientific background information for the Fields medal winners would be fantastic. Your blogposts in the past have also been very useful (Thanks!) . Given, so much effort has been spent in collecting the relevant scientificinformation, perhaps the Fields Medal selection committee could find a way that someone composes and publishes a similar scientific background information about the work of each winner.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503641")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2018")])]

#text("Look at the write-ups here:")

#link("https://www.mathunion.org/imu-awards/fields-medal/fields-medals-2018")[#text("https://www.mathunion.org/imu-awards/fields-medal/fields-medals-2018")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aNoNyMouS")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503644")[#strong[#text("aNoNyMouS")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2018")])]

#text("After reading the write-up about Birkar, my first thought was — he clearly deserves the medal. My second thought was — how come Shakurov didn’t get half of the Breakthrough Prize?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of florian")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503663")[#strong[#text("florian")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2018")])]

#text("Very helpful link – thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503738")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2018")])]

#text("Dear Prof. Tao,")

#text("I want to alert to a pitfall that I sometimes see with regard to the way that mathematicians respect each other.")

#text("Namely, I believe that a mathematician will respect another mathematician more if he or she works in a different area. This is because the first mathematician does not know the methods therein and thus the mathematics is more remote from her/him.")

#text("Also, I was wondering whether today’s mathematics is sufficiently applied. If only a small percentage of the very good mathematicians worked on problems in medicine, say, they’d advance the subject by decades. But I’m sure you’ve had this argument with yourself. (You hinted at it in one of your posts.) Can you explain your reasoning?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amon")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503742")[#strong[#text("Amon")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2018")])]

#text("Too sad, I would have hoped for some enlightening thoughts about perfectoid spaces from your point of view together with some estimate where this development cold lead to. In any case your decision not to comment repectable and to be respected. Greetings!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kodlu")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503759")[#strong[#text("kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2018")])]

#text("OT for this post, sorry: Your link on the left sidebar to the “world digital mathematical library” seems to be dead. ")#emph[#text("[Link changed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ddffc3a3ebf8dd6990efe772bfd2f435a9ddd74938982902bda0e0cdbdd8fb80-285f5672799472a47416daa0baf51f35d21d25a71105e6b38eb8905e88347dc7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TrumpSupporter")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503798")[#strong[#text("TrumpSupporter")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2018")])]

#text("First of all, congratulations to all 4 Fields Medals winners. As it happens with most prizes, I am sure that there were more deserving winners than awards available and a decision had to be made so good for the winners and good luck to those who didn’t make it this time. I am sure there will be other opportunities to prove your talents.")

#text("The comment that I have is about the idiotic 40 years old limit. Since you are now well connected with the IMU -so much so that you were in the selection committee- any chance that this limit will be dropped any time soon?")

#text("Think about this. When the first Medals were conceived, the life expectancy in the US was 62 years and the amount of preparation required to be a top performing mathematician was lower than now. Thus the 40 year limit perhaps made sense then. We don’t live in that world anymore, thus the pattern that I increasingly see in the recent winners -yourself included- and I mean this as no offense whatsoever is that it is people who have what I call, for lack of a better word, the “I was raised in home where I was carefully groomed to be a professional mathematician” advantage. That leaves behind people who took alternative paths to get there or people who make great work later in their lives or people where the entirety of their work requires more than 40 years to judge. If I were to pick two names where this limit shows: Andrew Wiles and Yitang Zhang. Does it really make sense to exclude these two from Mathematics alleged top honor, particularly Wiles?")

#text("I know the standard answer: other prizes like the Abel Prize will take care of the problem. I am afraid to say that this is still not the case and I strongly believe in preaching by example.")

#text("So Terry, this is my request to you: please use your influence with the IMU to drop this idiotic limit from both the Fields and Nevanlinna prizes!")

#emph[#text("[Several prize-related issues, including this one, were ")#link("https://www.mathunion.org/fileadmin/IMU/Organization/GA/GA_2014/17_GA_Report_Final_140810_Gyeongju.pdf")[#text("discussed extensively")]#text(" at the 2014 IMU general assembly, with ")#link("https://www.mathunion.org/fileadmin/IMU/Organization/GA/Resolutions/RESOL2014.pdf")[#text("an ad hoc committee consisting of past prize committee chairs assigned")]#text(" to look into the matter and give recommendations. Two years later, after soliciting input from many sources, the report of the ad hoc committee was completed, and can be found at ")#link("https://www.mathunion.org/fileadmin/IMU/Publications/CircularLetters/2015-2016/IMU_AO_CL_3_2016_IMUprizesrev.pdf")[#text("https://www.mathunion.org/fileadmin/IMU/Publications/CircularLetters/2015-2016/IMU_AO_CL_3_2016_IMUprizesrev.pdf")]#text(" . In 2016, the IMU executive committee ")#link("https://www.mathunion.org/fileadmin/IMU/Publications/CircularLetters/2015-2016/IMU_AO_CL_3_2016.pdf")[#text("voted unanimously")]#text(" to accept the recommendations of the ad hoc committee. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c89413a51e4d4c5e0536bc1a506fb837e366ced027468f0e2e626048b820ef3-c36bb24a2a115dfa13f8229d4d4cab889d479dce18da04e489af3850648e1824.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TrumpSupporter")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503803")[#strong[#text("TrumpSupporter")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2018")])]

#text("Thank you for the detailed clarifications that this issue was discussed in the past.")

#text("I don’t find the arguments in favor of keeping the age limit very compelling though. Yes the IMU cannot compete financially with the Breakthrough or Abel prizes, but it can compete in being the premier mathematical body and keeping the Fields medal as the premier mathematical award given its past.")

#text("Keeping the age limit risks, in the long run, diminishing the significance of the Fields medal particularly if prizes like the Abel Prize continue to be awarded to people like Andrew Wiles or Robert Langlands. Take the latter. The so called “Langlands program” is not my area of expertise and I understand little of it. It would seem to me that when history of mathematics is written 100 years from now, the guy who built the theory will be given more credit than the several winners of Fields Medals that worked on proving some of his conjectures. For example, it’s Einstein who gets the credit for coming up with General Relativity, not the different Nobel Prize winners who have worked in verifying experimentally the predictions of the theory as important as this verification work was.")

#text("If the list of Abel Prize continues to be as impressive, we could see in 100 years two tracks of honors in Mathematics: one track honoring the best mathematics humans do before they reach the age of 40. The second honoring the best mathematics humans can do in a lifetime. Something tells me that the second track is likely to be the most impressive of the two, even though I am also sure that the intersection between the two tracks won’t be an empty set.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503804")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2018")])]

#text("[This is a reply to Terry’s comment]")

#text("Ah, I was wondering about this committee and the result. I didn’t realise it had concluded two years ago! Here was me still telling people this year that the IMU was looking into the age limit…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503806")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2018")])]

#text("This reminds Hardy’s influence to modify the Tripos (in particular, in his 1926 presidential address to the Mathematical Association on “The case against the Mathematical Tripos”).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af16cfc077649efef30730903bbfae1acabaf89236b58d80870a19c314c0ee3d-9a9c343ccfac4c9a3c25ab4ca99c74a9e08071db8719a80d32f61d36f001ea52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TrumpSupporter")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503817")[#strong[#text("TrumpSupporter")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2018")])]

#text("I had never heard about it, but I found a copy here ")#link("http://www-history.mcs.st-and.ac.uk/Extras/Hardy_Tripos.html")[#text("http://www-history.mcs.st-and.ac.uk/Extras/Hardy_Tripos.html")]#text(" . I find this paragraph particularly interesting,")

#text("“It has often been said that Tripos mathematics was a collection of elaborate futilities, and the accusation is broadly true. My own opinion is that this is the inevitable result, in a mathematical examination, of high standards and traditions. The examiner is not allowed to content himself with testing the competence and the knowledge of the candidates; his instructions are to provide a test of more than that, of initiative, imagination, and even of some sort of originality. And as there is only one test of originality in mathematics, namely the accomplishment of original work, and as it is useless to ask a youth of twenty-two to perform original research under examination conditions, the examination necessarily degenerates into a kind of game, and instruction for it into initiation into a series of stunts and tricks. It was in any case certainly true, at the time of which I am speaking, that an undergraduate might study mathematics diligently throughout the whole of his career, and attain the very highest honours in the examination, without having acquired, and indeed without having encountered, any knowledge at all of any of the ideas which dominate modern mathematical thought. His ignorance of analysis would have been practically complete.”")

#text("In my experience, a lot of undergraduate and some graduate classes fit precisely this paradigm at America’s most prestigious universities (I know less the rest of the world). It’s only at the PhD level that people make the transition to doing actual original mathematical work.")

#text("Coming back to the Fields Medal/Nevanlinna Prize age limit. Suppose that somebody, somehow were to come up with a definite answer to either the Riemann hypothesis or the P vs NP question and that somebody is 50. The current age limit is signaling the world that such thing cannot happen provided that the Fields Medal/Nevanlinna Prize prize remain the most prestigious awards in mathematics/computer science. If that were to happen, then the idea of these awards being the most prestigious awards would have been falsified. In a way, keeping the age limit is setting up some sort of demonic scenario in mathematics. The only guy who has solved one of the Millennium problems was also eligible for a Fields Medal but there is no guarantee that this will continue to be the case in the future.")

#text("I think that keeping the age limit has more to do with the current winners seeking to keep the value of their award up than anything else. It’s like the kind of laws that restrict new construction developments in areas with high priced real estate. They have nothing to do with their alleged goals (such as environmental concerns) but are really proxies to keeping the value of existing real estate high. This might work in the short term, but in the long run, I doubt it will because people will find creative ways to overcome the limit, such as was the case for Yitang Zhang. I do not know enough about advanced number theory to judge whether his theorem was a breakthrough of the first order, but given the awards he collected as a result, it would seem so.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503868")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2018")])]

#text("” the examination necessarily degenerates into a kind of game, and instruction for it into initiation into a series of stunts and tricks.”")

#text("Hardy’s comments seem somewhat appropriate to the IMO as well, for what it’s worth.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9731dd491e6d250e650666e2a47fd39f5fd98a9b3bf48e98d6e23c8ebe85252-6ade34b147bfd8b95def69ec41279ef65eb902d545728bd544c14a2abf906f3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TrumpSupporter")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503895")[#strong[#text("TrumpSupporter")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2018")])]

#text("Good point. It’s amazing how pervasive, and old, these schemes are. I think they are the ultimate over-fitting schemes: winning the game becomes the goal as opposed to being experiences that help advance the discipline, be that discipline mathematics or any other. As I mentioned elsewhere, whether keeping the 40 year limit in the Fields Medal is good for the medals will only become clear 20 to 30 years from now given that now there are alternative ways to honor great mathematicians that do not have the 40 year old limit.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e2c7190341fb2bb4e35f936ffa118d348bbaf572297898d8057f302c63038cb-5d4a4c320d83fc35e9732b3a672ccd556d402294bcfac75a1ece43bf5793f353.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RepealAndReplaceTrump")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503818")[#strong[#text("RepealAndReplaceTrump")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2018")])]

#text("I do think the Fields Medal retains some of its original purpose, which was to encourage and publicize the work of younger researchers. For example, this time I had never heard of Caucher Birkar, who works in a field far removed from mine. While I agree it is rather uninspiring to see how many Fields medalists today were raised by professors of math, physics, CS, or engineering, I think a better way to deal with the changes in the subject would be to say raise the age limit to 45 or maybe replace the age limit with a limit on the number of years since getting their PhD. But the original purpose seems valid to me.")

#text("With the Abel prize, it always seems to me that the winner is one of the “usual suspects”, one of the older leaders in math who surprises no one when he wins. I tend to pay little attention to it since its purpose seems to just confirm what everyone already believes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b4f056c2bd46692f5ed8125b43e1d738131f1273f044c03950ce6f8d5ce37bc-bfb598f73596994f30a7c21e40750d2ac5ecf702da523a0d7a7302474bece3e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TrumpSupporter")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503833")[#strong[#text("TrumpSupporter")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2018")])]

#text("Happy to see that there is some common ground. When it comes to the Abel Prize, I think we will need another 20 or 30 years of data (say by 2050) to see how things turn out, but neither of the winners starting in 2014 has won a Fields Medal (even though they would have been eligible under the Fields Medal rules):")

#text("– Yakov Sinai")#linebreak()#text(" – John Nash")#linebreak()#text(" – Louis Nirenberg")#linebreak()#text(" – Andrew Wiles")#linebreak()#text(" – Yves Meyer")#linebreak()#text(" – Robert Langlands")

#text("I don’t know if this was a deliberative decision by the Abel Committee but it is hard not to notice.the pattern.")

#text("Of these, I am most familiar with Yves Meyer’s work. He started the work he was given the Abel Prize for -the development of wavelet theory- when he was in his mid 40s. Wavelets are now pervasively used in applied mathematics. Did the different Fields committees miss Yves’ potential or is it just that indeed the Fields Medals rules should be relaxed lest they -the medals- become irrelevant in 50 years?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-503999")[#strong[#text("How valuable is a Fields Medal? – Site Title")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2018")]

#text("[…] I ever could so I point there: here. Terry Tao also has some comments on the Fields Medal here. So does Doron […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2ad47e0056b0961e106972bc30dc87c91d6f369dfdd5e3d7259ddaaf9584c69-82f769c9a9dfd6b4b82c91966568cc93fa36a95795012c81d518f8a76cdfe1fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ABC")]], [#link("https://terrytao.wordpress.com/2018/08/01/birkar-figalli-scholze-venkatesh/#comment-504176")[#strong[#text("ABC")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2018")])]

#text("Dear Terry,")

#text("You write that the text of the Laudationes (using Fausto Di Biase’s linguistic remark above) will be eventually available. Do you know roughly when? I am quite surprised that this is still not the case (unless I am doing something stupid when I check the website, which I cannot exclude). What is the customary amount of time that passes through the cerimony and the public release of the texts of the Laudationes.")

#text("I am honestly very curious to read those two neighboring my area and it would be convenient to get a sense of “when to look for them”, instead of trying out every week.")

#text("Thank you in advance in case you can provide this Info.")
]
