// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/03/20/short-communication-satellite-event-for-the-2022-virtual-icm/
// Converted to Typst by tao2typ: "2026-10-14T15:20:44.488793+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Short communication satellite event for the 2022 virtual ICM?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Short communication satellite event for the 2022 virtual ICM?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 March 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/03/20/short-communication-satellite-event-for-the-2022-virtual-icm/")[#text("https://terrytao.wordpress.com/2022/03/20/short-communication-satellite-event-for-the-2022-virtual-icm/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[As with previous posts regarding ICM satellite events, I am authoring this post as an individual, and not in my capacity as chair of the ICM Structure Committee, which does not have any advisory or supervisory role over ICM satellite events – T.]")]

#text("One of the traditional features of the International Congress of Mathematicians are the “short communications”, organized by the local organizing committee (as opposed to the International Mathematical Union), which allows participants at the congress to present either a poster or a short talk (typically 15 minutes or so) during the congress. For instance, here are the titles of the ")#link("https://www.mathunion.org/fileadmin/IMU/ICM2018/static_site/portal/results-short-communications.html")[#text("short communications")]#text(" and ")#link("https://www.mathunion.org/fileadmin/IMU/ICM2018/static_site/portal/results-short-communications-posters.html")[#text("posters")]#text(" from the 2018 ICM, and here are the ")#link("http://www.icm2014.org/en/program/scientific/short.html")[#text("short communications")]#text(" and ")#link("http://www.icm2014.org/en/program/scientific/poster.html")[#text("posters")]#text(" from the 2014 ICM. While not as high profile as other events of the ICM such as the plenary lectures, sectional lectures, or prize lectures, the short communications and posters can offer a chance for academics from a quite diverse range of institutions worldwide (and even a few independent mathematicians) be able to present their work to a mathematical audience.")

#text("There has been some volunteer effort to try to replicate some form of this event for the upcoming virtual ICM this July as a semi-official “satellite” event of the virtual ICM; it would technically not be part of the core ICM program, but I expect it would be recognized by the IMU as an independently organized satellite. Due to lack of time, funding, and technical expertise, we will not be able to offer any video, audio, or physical hosting for such an event, but we believe that a modest virtual event is possible involving submission of either a PDF “poster” or a PDF “slide deck”, together with other metadata such as author, title, abstract, and external links (e.g., to an externally hosted video presentation of the poster or slides), with some reviewing to ensure a certain minimum level of quality of approved submissions (we are thinking about setting guidelines similar to ")#link("https://arxiv.org/help/moderation")[#text("those required for a submission to the arXiv")]#text("), and some ability to offer feedback on each submission. (For instance, we are thinking of hosting the event on a MediaWiki, with each communication being given a separate page which can attract discussion and responses to queries from the author(s).) We are also thinking of grouping the poster or slides according to the ")#link("https://www.mathunion.org/fileadmin/IMU/Report/SC/2019/structure_committee_final.pdf")[#text("20 sections of the 2022 ICM")]#text(". We would then promote these communications during the virtual ICM, for instance on this blog or on the ")#link("https://discord.gg/T72dTkfSzF")[#text("unofficial ICM Discord")]#text(". Perhaps some of the other proposed online experiments for virtual events discussed in ")#link("https://terrytao.wordpress.com/2022/02/26/the-international-congress-of-mathematicians-icm-2022-will-now-be-fully-virtual-how-best-to-utilise-this-format/")[#text("this previous post")]#text(" could also be implemented experimentally on this satellite event to demonstrate proof-of-concept. (If the event turns out to be successful, one could hope that it could serve as a pilot project for a longer-term and better funded platform for virtual short communications to accompany other conferences, but for now we would like to focus just on the virtual ICM satellite event.)")

#text("As one of our first actions, we would like to survey the level of interest in such an event, both among potential submitters of posters or slides, and also potential volunteers to help organize the event (in particular we may need some assistance in manually reviewing submissions, though we do plan to enlist peer reviewers by requiring submitters to rate and comment on other submissions in the same section). We have therefore created a ")#link("https://docs.google.com/forms/d/e/1FAIpQLSfStWINRskYhK37v2d_0QEkxXhx0l-whudg5xQak4ELFKU7aw/viewform")[#text("form")]#text(" to (very unscientifically) gauge this level in order to decide on the scale of this project (or whether to attempt it at all). All readers of this blog are welcome to offer feedback through that form, or as a comment to this blog.")

#text("EDIT (Mar 29): a formal announcement will be made soon, but you can view a draft of the announcement ")#link("https://docs.google.com/document/d/e/2PACX-1vS_smRK3OPCTJqheDeTVNIRX2dsvnCr_38yrJRixZEFokP7J-Jwwalyb4cZEO71NHlLCb9Cr0hBA-Pv/pub")[#text("here")]#text(".")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 2022 ICM satellite coordination group | What's new")]], [#link("https://terrytao.wordpress.com/2022/03/20/short-communication-satellite-event-for-the-2022-virtual-icm/#comment-641727")[#strong[#text("2022 ICM satellite coordination group | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2022")])]

#text("[…] Traditional in-person congresses allocate some space for “short communications” of about 15 minutes each by mathematicians around the world; for instance here is the information for such communciations from the 2018 ICM. Due to limited resources, the IMU will not be able to directly organize such communications for the 2022 ICM, but perhaps there will be a volunteer effort to create a semi-official substitute for this component of the congress as a satellite event. (Further discussion of this proposal can be found at this blog post.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d1f7927d9a190044082b3c61e79c577b7594f0d5f2f48b0a0f196dd40ece672c-094e2a4883bd146fcd4b859efcf17739200be22956f74a5ae26793b4a07ab871.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank Vega Delgado (@vega_frank)")]], [#link("https://terrytao.wordpress.com/2022/03/20/short-communication-satellite-event-for-the-2022-virtual-icm/#comment-641730")[#strong[#text("Frank Vega Delgado (@vega_frank)")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2022")])]

#text("Dear Tao,")

#text("I am interested in extending a result that was accepted in a journal as a short communication. I always check your blog by email and I already participated in the survey. Then I would like to see the results and the final decision on your blog if possible.")

#text("Thanks in advance,")#linebreak()#text(" Frank")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6e0a90e872e7c20a9c39fe93fb432d35e14b0e94d966ad57afe4bd253e1958e-c50d95a6696bd39501fcdb9709b06dfd557dee5a07c4dd1c086dc87f17a56fb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sang-il")]], [#link("https://terrytao.wordpress.com/2022/03/20/short-communication-satellite-event-for-the-2022-virtual-icm/#comment-641739")[#strong[#text("Sang-il")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2022")])]

#text("One of the purposes of having short contributed talks and posters at the ICM is that some funding agencies or universities in the world do not reimburse the travel money unless the participants present talks or posters. Now ICM is virtual and free, and so perhaps it is not really necessary to have short communications and posters.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b196981b438d17e454e2c80441f283eafc08683e8e13d6a538fa7947ec16d91a-e9f1e16ad8f8c40ae170196f615af3a31809330f17162c6f4560227cd4677d58.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Łukasz")]], [#link("https://terrytao.wordpress.com/2022/03/20/short-communication-satellite-event-for-the-2022-virtual-icm/#comment-641892")[#strong[#text("Łukasz")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2022")])]

#text("As I understand, there is still an opportunity of registering for virtual ICM 2022. So, what about the opportunity of submission of a talk (at least a short talk or communication) – is this still possible to submit at least a short talk or communication ?")#linebreak()#text(" There on the website ")#link("http://www.mathunion.org/icm/virtual-icm-2022")[#text("http://www.mathunion.org/icm/virtual-icm-2022")]#text(", is only the information “Participation is free of charge, but registration will be required.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grpaseman")]], [#link("https://terrytao.wordpress.com/2022/03/20/short-communication-satellite-event-for-the-2022-virtual-icm/#comment-641912")[#strong[#text("grpaseman")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2022")])]

#text("As I read Terry’s post, any event which handles short communications will be independent of the efforts of the IMU, and is likely to have an independent registration process. (Some in the satellite coordination group are announcing their efforts to host various invited lectures from some sections; I am optimistic a similar effort will arise for short communications.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Web page for the Short Communication Satellite (SCS) of the 2022 virtual ICM now live | What's new")]], [#link("https://terrytao.wordpress.com/2022/03/20/short-communication-satellite-event-for-the-2022-virtual-icm/#comment-642089")[#strong[#text("Web page for the Short Communication Satellite (SCS) of the 2022 virtual ICM now live | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2022")])]

#text("[…] a brief update to the previous post. Gerhard Paseman and I have now set up a web site for the Short Communication Satellite (SCS) for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/03/20/short-communication-satellite-event-for-the-2022-virtual-icm/#comment-642528")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2022")])]

#text("Tao，how is everything going？I miss you a lot，and hope to receive the message of everyday progressing～")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/03/20/short-communication-satellite-event-for-the-2022-virtual-icm/#comment-650688")[#strong[#text("Internet web page for the Quick Communication Satellite tv for pc (SCS) of the 2022 digital ICM now reside - Veja Online")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2022")]

#text("[…] a transient replace to the earlier submit. Gerhard Paseman and I’ve now arrange a website online for the Quick Communication Satellite […]")
]
