// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/07/01/compactness-and-contradiction/
// Converted to Typst by tao2typ: "2026-10-14T16:36:33.539280+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Compactness and contradiction", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Compactness and contradiction")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 July 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/07/01/compactness-and-contradiction/")[#text("https://terrytao.wordpress.com/2011/07/01/compactness-and-contradiction/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I recently finished the ")#link("https://terrytao.wordpress.com/wp-content/uploads/2011/06/blog-book.pdf")[#text("first draft")]#text(" of the last of ")#link("https://terrytao.wordpress.com/books/")[#text("my books")]#text(" based on my ")#link("https://terrytao.wordpress.com/2010/")[#text("2010 blog posts")]#text(" (and also my Google buzzes), entitled “")#link("https://terrytao.wordpress.com/books/compactness-and-contradiction/")[#text("Compactness and contradiction")]#text("“. The PDF of this draft is available ")#link("https://terrytao.wordpress.com/wp-content/uploads/2011/06/blog-book.pdf")[#text("here")]#text(". This is a somewhat assorted (and lightly edited) collection of posts (and buzzes), though concentrating in the areas of analysis (both standard and nonstandard), logic, and group theory. As always, comments and corrections are welcome.")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2011/07/01/compactness-and-contradiction/#comment-54803")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2011")])]

#text("First of all: Thank you for giving me this book. I look forward to studying it.")

#text("I looked at the Contents, and I would like to tell you about (my) Ordinal Fractions. They are effective for numbering chapters and paragraphs and anything else. They are too elementary to catch the attention of mathematicians.")

#text("The digit zero has two meanings. In ‘1770’ zero means ‘nothing’, and in ‘the 1770s’ zero means ‘everything’.")

#text("In order to avoid misunderstandings, zero should mean only one thing, and in an ordinal fraction, zero means ‘everything’.")

#text("There are only 9 one digit numbers left when zero doesn’t count. So this is not decimal, it is most nonal.")

#text("There is no dot between the chapter number and the section number. When there are more than 9 sections in a chapter the sections are numbered with two (nonzero) digits.")

#text("An ordinal fraction is something like ‘the third fourth’, because ‘the third’ is an ordinal number and ‘a fourth’ is a fraction. Like this:")

#text("00 whole")#linebreak()#text(" 01 odd fourths")#linebreak()#text(" 02 even fourths")#linebreak()#text(" 10 first half")#linebreak()#text(" 11 first fourth")#linebreak()#text(" 12 second fourth")#linebreak()#text(" 20 second half")#linebreak()#text(" 21 first fourth")#linebreak()#text(" 22 second fourth")

#text("The five ordinal fraction relations are these:")#linebreak()#text(" 1 The first half is equal to the first half: 10=10")#linebreak()#text(" 2 The first half is part of the whole: 1011")#linebreak()#text(" 4 The first half is parallel with the second half: 10><20")#linebreak()#text(" 5 The first half intersects the odd fourths: 1001")

#text("Ordinal fractions are and’ed like this:")#linebreak()#text(" 10+10=10")#linebreak()#text(" 10+00=10")#linebreak()#text(" 10+11=11")#linebreak()#text(" 10+20=Ø")#linebreak()#text(" 10+01=11")#linebreak()#text(" 10+Ø=Ø")#linebreak()#text(" Ø is the empty set or the impossible condition.")#linebreak()#text(" Ø is the improper ordinal fraction.")

#text("So your table of contents may look like below,")

#text("Note that 2122<2100, meaning that the section on circular arguments are part of chapter on logic and foundations.")

#text("Yours truly, Bo.")

#text("0000 Compactness and contradiction")#linebreak()#text(" 1100 Preface")#linebreak()#text(" 1200 A remark on notation")#linebreak()#text(" 1300 Acknowledgments")#linebreak()#text(" 2100 Logic and foundations")#linebreak()#text(" 2111 Material implication")#linebreak()#text(" 2112 Errors in mathematical proofs")#linebreak()#text(" 2113 Mathematical strength")#linebreak()#text(" 2114 Stable implications")#linebreak()#text(" 2115 Notational conventions")#linebreak()#text(" 2121 Abstraction")#linebreak()#text(" 2122 Circular arguments")#linebreak()#text(" 2123 The classical number systems")#linebreak()#text(" 2124 Round numbers")#linebreak()#text(" 2125 The \\no self-defeating object\" argument, revisited")#linebreak()#text(" 2131 The \\no self-defeating object\" argument, and the vagueness paradox")#linebreak()#text(" 2132 A computational perspective on set theory")#linebreak()#text(" 2200 Group theory")#linebreak()#text(" 2211 Torsors")#linebreak()#text(" 2212 Active and passive transformations")#linebreak()#text(" 2213 Cayley graphs and the geometry of groups")#linebreak()#text(" 2214 Group extensions")#linebreak()#text(" 2215 A proof of Gromov's theorem")#linebreak()#text(" 2300 Analysis")#linebreak()#text(" 2311 Orders of magnitude, and tropical geometry")#linebreak()#text(" 2312 Descriptive set theory vs. Lebesgue set theory")#linebreak()#text(" 2313 Complex analysis vs. real analysis")#linebreak()#text(" 2314 Sharp inequalities")#linebreak()#text(" 2315 Implied constants and asymptotic notation")#linebreak()#text(" 2321 Brownian snowflakes")#linebreak()#text(" 2322 The Euler-Maclaurin formula, Bernoulli numbers, the zeta function, and real-variable analytic continuation")#linebreak()#text(" 2323 Finitary consequences of the invariant subspace problem")#linebreak()#text(" 2324 The Guth-Katz result on the Erd}os distance problem")#linebreak()#text(" 2325 The Bourgain-Guth method for proving restriction theorems")#linebreak()#text(" 2400 Nonstandard analysis")#linebreak()#text(" 2411 Real numbers, nonstandard real numbers, and nite precision arithmetic")#linebreak()#text(" 2412 Nonstandard analysis as algebraic analysis")#linebreak()#text(" 2413 Compactness and contradiction: the correspondence principle in ergodic theory")#linebreak()#text(" 2414 Nonstandard analysis as a completion of standard analysis")#linebreak()#text(" 2425 Concentration compactness via nonstandard analysis")#linebreak()#text(" 2500 Partial di erential equations")#linebreak()#text(" 2511 Quasilinear well-posedness")#linebreak()#text(" 2512 A type diagram for function spaces")#linebreak()#text(" 2513 Amplitude-frequency dynamics for semilinear dispersive equations")#linebreak()#text(" 2514 The Euler-Arnold equation")#linebreak()#text(" 2600 Miscellaneous")#linebreak()#text(" 2611 Multiplicity of perspective")#linebreak()#text(" 2612 Memorisation vs. derivation")#linebreak()#text(" 2613 Coordinates")#linebreak()#text(" 2614 Spatial scales")#linebreak()#text(" 2615 Averaging")#linebreak()#text(" 2621 What colour is the sun?")#linebreak()#text(" 2622 Zeno's paradoxes and induction")#linebreak()#text(" 2623 Jevons' paradox")#linebreak()#text(" 2624 Bayesian probability")#linebreak()#text(" 2625 Best, worst, and average-case analysis")#linebreak()#text(" 2631 Duality")#linebreak()#text(" 2632 Open and closed conditions")#linebreak()#text(" 3100 Bibliography")#linebreak()#text(" 3200 Index")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb9b14c4f3b8ddd3ec179613cf5e6417e66305974e7457655828e12f97779c31-49f5595229e131378b0c2f9a70b4e675d508a25fb69b06944134e5b895dc215e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew N. Petersen")]], [#link("https://terrytao.wordpress.com/2011/07/01/compactness-and-contradiction/#comment-54809")[#strong[#text("Matthew N. Petersen")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2011")])]

#text("Pg. 18, you have “Gdel’s incompleteness theorem”, rather than “Gödel’s…”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb9b14c4f3b8ddd3ec179613cf5e6417e66305974e7457655828e12f97779c31-49f5595229e131378b0c2f9a70b4e675d508a25fb69b06944134e5b895dc215e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew N. Petersen")]], [#link("https://terrytao.wordpress.com/2011/07/01/compactness-and-contradiction/#comment-54811")[#strong[#text("Matthew N. Petersen")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2011")])]

#text("Same difficulty on p. 29")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2011/07/01/compactness-and-contradiction/#comment-54817")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2011")])]

#text("A quick typo: in the statement of Theorem 4.3.11 you write “Szemerdi”. An easy exercise in reverse engineering suggests, in the light of the “Gdel” typo mentioned above, that something more general has gone wrong …")

#emph[#text("[Ah, some of the text I incorporated to the book contained accents which LaTeX then refused to recognise. I think the problem is fixed now and will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fef4423c53c5ed17f86aef264f9ac9e0649daa01ff0ec29d66444a41ad200afa-deb84e0d9e9d8d5f0fd26405aad02f813f1e39286fecfb7faa41881d008c848f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg")]], [#link("https://terrytao.wordpress.com/2011/07/01/compactness-and-contradiction/#comment-54940")[#strong[#text("Greg")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2011")])]

#text("Couple of typos right at the start. On page 2, in statement (8) you have “Is A, then B” which looks like it should be “If A, then B”. Lower down, penultimate paragraph (just before the footnote 1) your implication arrows seem to have gone wrong (-> rather than -> for A \\implies B and B \\implies A)")#linebreak()#text(" Otherwise, this looks good so far!")

#emph[#text("[Thanks, this will be corrected in the next version of the ms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fef4423c53c5ed17f86aef264f9ac9e0649daa01ff0ec29d66444a41ad200afa-deb84e0d9e9d8d5f0fd26405aad02f813f1e39286fecfb7faa41881d008c848f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg")]], [#link("https://terrytao.wordpress.com/2011/07/01/compactness-and-contradiction/#comment-54943")[#strong[#text("Greg")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2011")])]

#text("One more before bed: on page 9, top paragraph, you have “the two are not symmetric, because in both cases is bounding an unknown quantity by a known quantity.” The “is” in the second clause is missing its subject — we’re not told _what_ is bounding the unknown quantity.")

#text("–g")

#emph[#text("[Thanks, this will be corrected in the next version of the ms. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cfac5b3ef194e618cb71e8e4ae4aa23d27d6b36b8bf5f6454d5614e39e738ae7-dcb05b6dc0577cad9c08608858c14d18c03bd7a3f554ef584d62423deec70604.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2011/07/01/compactness-and-contradiction/#comment-54947")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2011")])]

#text("Page 80: “algberaic” -> “algebraic”")

#emph[#text("[Thanks, this will be corrected in the next version of the ms. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of diego.maldona@gmail.com")]], [#link("https://terrytao.wordpress.com/2011/07/01/compactness-and-contradiction/#comment-55002")[#strong[#text("diego.maldona@gmail.com")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2011")])]

#text("Dear Terry, thank you for posting the book. It’s always insightful to read your unifying take on so many, seemingly disconnected, Math topics. Below are a few typos I found.")

#text("p.13, line 8, misplaced comma")#linebreak()#text(" p.20, line 16, “doesnt”")#linebreak()#text(" p.22, line -13, “and its proof is” should be “and its proof are”")#linebreak()#text(" p.22, last line, extra semicolon")#linebreak()#text(" p.23, “If B was an element” should read “If B were an element”")#linebreak()#text(" p.29. The sentence starting with “However…” goes on for ten and a half lines and there is a “then” that’s not quite working out.")#linebreak()#text(" p.29, first footnote, I believe “boolean” should be “Boolean” (as “Bayesian” reads “Bayesian”). “boolean” also appears in other parts of the manuscript. Same issue with “gaussian”; but, apparently, “abelian” is ok.")#linebreak()#text(" p.30, line 8, “that A was ﬁnite” should be “that A were ﬁnite” or “that A is ﬁnite”")#linebreak()#text(" p.48, line 8, “translation” should be “translations”")#linebreak()#text(" p.110, There are several “Erdos” and “Holder” (without the umlaut).")#linebreak()#text(" p.110, line 11, “considing”")#linebreak()#text(" p.192, lines -5, -4, the parameter “p” should be in math font")

#text("In Section 1.11, after discussing Richard’s paradox (p.32), you could mention that if a reader runs into a genie willing to grant three wishes, the instruction “I wish for 1000 wishes” won’t have any effect, since that’s not a wish, but a meta-wish. This situation could also be phrased as a paradox (writing, for instance, that the genie will grant exactly 3 wishes).")

#text("Regarding paradoxes, it will be illuminating to have your take on the “surprise test paradox”")

#link("http://en.wikipedia.org/wiki/Unexpected_hanging_paradox")[#text("http://en.wikipedia.org/wiki/Unexpected_hanging_paradox")]

#link("http://arxiv.org/abs/math/9903160")[#text("http://arxiv.org/abs/math/9903160")]

#text("I loved the “digital-images analogy” when illustrating the concepts of extension and quotient.")

#emph[#text("[Thanks for the corrections! They will be incorporated in the next revision of the ms. The surprise test paradox is discussed on this blog at ")#link("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/")[#text("https://terrytao.wordpress.com/2011/05/19/epistemic-logic-temporal-epistemic-logic-and-the-blue-eyed-islander-puzzle-lower-bound/")]#text(" -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a49f89ecd0ab9c8a8d7a36958e7e731aeadb85da96d1584bc1bc3175cb2e3645-71f6774c8eaa85e997b41111eed741d3fc5b086230557f7b2b2c781886015821.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hemant Verma")]], [#link("https://terrytao.wordpress.com/2011/07/01/compactness-and-contradiction/#comment-55426")[#strong[#text("Hemant Verma")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2011")])]

#text("Hi All,")

#text("There are related mathematics and algorithms problem here, for those who love mathematics / algorithm problem solviing ")#link("http://mathalon.in/?page=show_problem.php&pid=1")[#text(" Mathalon ")]#text(" , after all whats in mathematics without problems.")

#text("-Hemant")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/07/01/compactness-and-contradiction/#comment-472607")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2016")])]

#text("Dear Terry!")

#text("What’s the point of thinking of an implication A –> B as asserting that B is at least as true as A in order to understand the disjunction elimination? In know that “A or B” has the biggest truth value of the two truth values of A and B. Thus if C is at least as true as A and also at least as true as B, then “A or B” is at least as true as C (since “A or B” has the same truth value as A or as B). But why does this shed light on the disjunction elimination?")
]
