// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/
// Converted to Typst by tao2typ: "2026-11-05T14:55:48.460529+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Doctoral Advising Guidelines by the AHM", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Doctoral Advising Guidelines by the AHM")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/")[#text("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-05 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by the ")#link("https://www.ahmath.org/")[#text("AHM")]#text(" communications group. — T.]")]

#text("We are happy to announce that the Teaching Working Group of the Association for Human Mathematics wrote ")#link("https://www.ahmath.org/doctoraladvising")[#text("a set of recommendations on doctoral advising")]#text(" aimed at departments, advisors, and students. The document contains five guidelines centered on prioritizing human-authored writing, avoiding overreliance on AI, confronting the ethical concerns of AI use, and improving the wellbeing of students, as well as concrete proposals on how to implement them. We encourage everyone to read and share the document, and we especially look forward to feedback and suggestions.")

#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699163")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("The proposal is very restrictive. Math with AI help can be a successful path, also for young scientists. Many here will not like to hear this: in chess, starting in the middle 1990’s, it took only about 10 years until ALL young people executed chess WITH computer help in their training sessions.")

#text("Back in 1986 Bielefeld University gave me a title “Dr. math”. Perhaps it is an idea to introduce a second doctoral title: “Dr. math-with-AI”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699168")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("A separate comment about humans vs. engines (I understand that you worked on them, so your opinion would be interesting).")

#text("A chess engine has perfect knowledge of the game position after descending into the search tree. Then it calls the evaluation function.")

#text("Humans are not allowed to use pencil and paper or a second chessboard to try out positions and then evaluate at a certain depth. Philosophically, why are humans playing against engines without external memory assistance? It seems that humans are artificially handicapped.")

#text("To come back to math, maybe humans need better lookup mechanisms for theorems and patterns how to use them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699188")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("Here are some facts rom Chess history in times of strong chess programs:")

#list(
[#enum(start: 1996, 
[#text("After his win over Deep Blue I")#linebreak()#text("by 4-2 in February 1996, negotiations for")#linebreak()#text("a revenge match started immediately.")#linebreak()#text("Kasaparov was aware that it might become")#linebreak()#text("a narrow encounter, and asked for special")#linebreak()#text("conditions. IBM should allow him threefold")#linebreak()#text("computer help against Deep Blue II: an opening")#linebreak()#text("database, an endgame tablebase (5-stoners),")#linebreak()#text("and a little tactical helper (like chess")#linebreak()#text("program Fritz 4 from ChessBase). IBM")#linebreak()#text("simply said NO – and knew from that moment")#linebreak()#text("on that Kasparov was frightened.")]
)

#enum(start: 1998, 
[#text("Oldtime World Champion Anatoly Karpov")#linebreak()#text("and rising hero Vishy Anand played an echibition")#linebreak()#text("match in computer-aided chess (each player having")#linebreak()#text("a normal PC with chess software besides the board).")#linebreak()#text("Karpov lost by 1-5, mainly do to his basic problems")#linebreak()#text("to operate a chess program.")]
)

#enum(start: 2000, 
[#text("World Chess Championships between favorite")#linebreak()#text("Kasparov and outsider Kramnik. Kramnik had two assistants")#linebreak()#text("who made opening preparation around the clock with")#linebreak()#text("computer help, in particular the “Berlin Wall”. One")#linebreak()#text("of the assistants, GM Bareev, described the exhausting")#linebreak()#text("work (including “almost-burnout”). Kramnik was a hard")#linebreak()#text("boss. At one point, the assistants just had a hard nichgt")#linebreak()#text("behindt them, he simply said: “I had expected more of you.”")]
)],
[#text("2014-2020. In the top German chess scene there was a")#linebreak()#text("longlasting dispute between National Coach Rogozenko and")#linebreak()#text("top player Matthias Blübaum. “Rogo” insisted that players")#linebreak()#text("had to understand the motivs behind the computer proposals.")#linebreak()#text("Blübaum instead simply said: “I believe in the bots.”")#linebreak()#text("This dispute was one of the reason why Rogozenko’s job")#linebreak()#text("was not prolonged in 2020.")#linebreak()#text("Soon afterwards Blübaum won the European Championships")#linebreak()#text("twice (2022 and 2025). Side aspect: Blübaum studied")#linebreak()#text("Mathematics at Bielefeled University and got a Master")#linebreak()#text("degree in pure math (in 2022), of course still completely")#linebreak()#text("without AI help.")],
[#text("Correspondence Chess is more or less dead")#linebreak()#text("due to the overhelmingly strong chess programs.")#linebreak()#text("Here is the final table of the latest completed")#linebreak()#text("World Championships:")#linebreak()#link("https://www.iccf.com/event?id=100104")[#text("https://www.iccf.com/event?id=100104")]#linebreak()#text("and here the preliminary table of the one that")#linebreak()#text("is currently still underway:")#linebreak()#link("https://www.iccf.com/event?id=107382")[#text("https://www.iccf.com/event?id=107382")]#linebreak()#text("Almost all games are draws! Non-draws only when")#linebreak()#text("a player has to step back, for instance because")#linebreak()#text("of death.")],
[#text("A central avantgarde figure was Grandmaster John Nunn (UK)")#linebreak()#text("(born 1955, PhD in Math in 1978 from Oxford). Active in")#linebreak()#text("computer-aided chess and “problem chess” already in the")#linebreak()#text("mid 1980’s")]
)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699203")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("I think that is all undisputed but does not answer the question: Computers literally violate tournament rules by writing down exact board positions to arbitrary depths before calling the evaluation function, have endgame table-bases etc.")

#text("It would be instructive to run an experiment and test how much ELO a selected SuperGM would gain vs. his peers if he were allowed a secret second chessboard to test variations to arbitrary depths and have an opening book and an endgame tablebase.")

#text("I’m not saying that humans would beat a computer with these aids because the computer is faster, but the magic evaporates quite a bit if you look behind the scenes.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699169")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("Magnus Carlsen avoids engines, but his seconds use them:")

#link("https://www.chess.com/news/view/lex-fridman-podcast-magnus-carlsen")[#text("https://www.chess.com/news/view/lex-fridman-podcast-magnus-carlsen")]

#text("“My team does but personally, I try not to use [engines] too much on my own because I know that when I play you obviously cannot have help from engines and I feel like often having imperfect knowledge about a position or some engine knowledge can be a lot worse than having no knowledge. So I try to look at engines as little as possible.”")

#text("This ties back into the other AI discussion whether LLMs make you less intelligent (I think they do). Unfortunately we don’t have seconds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699185")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("The current world chess champion, Gukesh Dommaraju, did not use engines until he reached 2500, see e.g. ")#link("https://en.wikipedia.org/wiki/Gukesh_Dommaraju#Chess_beginnings")[#text("https://en.wikipedia.org/wiki/Gukesh_Dommaraju#Chess_beginnings")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699170")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("Terry I really do not think you should be posting these AHM guest posts. It is very unhealthy for the future of the profession, and extremely damaging to the reputation of mathematicians. The document by Bryna Kra and the others was fantastic, and emphasized both the need for students to learn to understand deep mathematics as well as engage productively with the new technology.")

#text("I also do not understand why you would abstain from using AI for “ethical” reasons. Can you explain this? I get that you would want to not use it because you prefer to think for yourself, and I get that you would be worried about people forgetting to think because of LLMs. I also get worrying about AI risk, from a virus or a Yudkowsky-type scenario.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0034ededecf4c8af3a0b27bb02c23241832b564237a5c06a1d2e01e8c05e579b-92345ce847ad29f2a22c82ec382f9f22dd3e4b24c78ff35fc93a69d970efb626.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699191")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("I’m glad the AHM at least exists. Because people should have a choice NOT to engage with AI. I love math but want nothing to do with AI.")

#text("AI is also unethical for two reasons: environmental cost, and promoting it also promotes the destruction of human communities.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699197")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("The choice exists and AHM has nothing to do with it existing.")

#text("The crucial aspect of mathematical practice that LLM use impacts is evaluation and AHM’s document gave zero, null, nada, in recommendations on how to address it. How to evaluate and compare candidate A who used LLM to candidate B who did not? Their only position, abstention. Do not use. “We are the Ludites of this time”. However, that doesn’t solve anything. Society still needs to do separation of labour. Candidate A who used LLM and candidate B who didn’t need both be evaluated, and more importantly, during hiring be compared. There is zero, null, nada, in terms of recommendations from AHM regarding that. Useless bunch.")

#text("And you are leaving academia, so …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699207")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("I agree that people should have a choice not to engage with AI. However, people shouldn’t be writing serious proposals saying that grad schools should discourage their students from ever using AI. That’s why I object to the AHM. If you look at the Harvard PhD summit here ")#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/")[#text("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/")]#text(" there are many reasonable proposals, encouraging people to learn to use AI but also saying that no one should be forced to use AI.")

#text("The environmental cost is fake. The unit distance conjecture cost as much water as three almonds. I don’t think AI promotes the “destruction of human communities”. It disrupts some things but it is ultimately up to humans what to do. The future of AI and math will be determined by mathematicians.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699171")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("History will not look kindly on those people at the AHM.")

#text("None of the recommendations make sense or are anything new.")

#text("Recommendation 1: The first sentence already every moderately decent program does. The second sentence is their Ludite push. Good luck with that. The last sentence says nothing. There is nothing that needs to change to accomplish it. You met the requisite (without LLM use), good for you, of course you get your degree.")

#text("Was recommendation 2 written by LLM? It is mixing unrelated “LLM use agreement” and documenting progress. The latter is existing practice. The no need to be first, is not new. Lots of PhD dissertations don’t prove anything new, and get the novelty checkmark from other aspects, like a new proof, some new definitions, algorithm, etc.")

#text("Recommendation 3, i.e. “be careful”, is a well know, non-recommendation. How? Full Ludite?")

#text("Recommendation 4 also says nothing. The “in effect at the time of their program entry” would make a program that can take 4 years not be adaptable. War begins, should still be there the same expectations?")

#text("Recommendation 5 is already in place.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699193")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("This is how cigarettes were marketed to fools back in the day. You weren’t cool if you didn’t smoke. Now everyone tries to ban them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699173")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("In my view while it contains useful recommendations (e.g. treating everyone with empathy, not rewriting the standards for people already in the program, maintaining research records and lab books so that priority and independent discovery can be documented) this report needs to be rejected, and forcefully, by the community. These ordinary recommendations are universal goods that predate the current situation; the stresses placed on everyone merely increase the value of good practices, yet we don’t need the report to tell us that. The real subject, LLMs, are enormously capable tools that will clearly proliferate in the coming years, and mathematics graduates must be trained to be competent in their use, including for mathematical research. The report militates in the opposite direction, and this is unfortunate.")

#text("The capacity for independent understanding, thinking, and research will remain essential, we must still train our students in those skills. For example, my graduate courses in January will ask students to not use LLMs, exactly to develop their mathematical technique and their independent thinking skills. But the overall ")#emph[#text("graduate")]#text(" ")#emph[#text("program")]#text(" (including, quite often, thesis-writing) ")#strong[#text("must")]#text(" involve the most powerful tools available to mathematicians, tools that our graduates are virtually certain to be required to use if they are to pursue mathematics after their degree.")

#text("Would we insist that a “pathways” through a transportation-worker training program “remain available for students who wish to completely abstain from” the driving of gasoline and eletcric cars due to their preference to only use human and animal muscle power? Of course wealthy individuals can choose to ride horses as a luxury, and muscle power is used in a few very exceptional situations, but the transportation industry almost universally uses machines. Our training program is paid for by the larger society, and we should acknowledge that.")

#text("Ultimately, it is quite possible that proving theorems ourselves will turn out to have been more personally satisfying than having a machine generate the proof. But this does not give us a right to socially-funded satisfaction in doing things inefficiently. Mathematics is ")#emph[#text("valuable")]#text(" to society, and we have a duty to teach our students to be able to contribute as powerfully as they can. LLMs are there. That is a fact, and we cannot bury our head in the sand and insist that society preserve our lives the way they were before simply because we want to cling to the past.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0034ededecf4c8af3a0b27bb02c23241832b564237a5c06a1d2e01e8c05e579b-92345ce847ad29f2a22c82ec382f9f22dd3e4b24c78ff35fc93a69d970efb626.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699192")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("This makes no sense. Mathematics teaching is valuable, and a subset of mathematics that is decades old is valuable. But hardly any new mathematics is valuable to anyone. Improving bounds on twin prime gaps, Langlands, geometric group theory, it’s really not valuable at all except to produce fine mathematicians capable of understanding math to be taught.")

#text("You’re fooling yourself if you think pushing mathematics further and faster will make any difference whatosever to society compared to just humans doing mathematics.")

#text("Sometimes we should cling to the past. It’s an incredible folly to think that every single technological advancement is a good thing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699210")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("Are you really saying that the practice of mathematical research is mostly for training new mathematicians to teach the older, and actually valuable, theories and results? Even if this were true, I guess there would be more efficient ways of training for this objective. Also “current math research is useless” reads more like push for more applied math than a counter to AI in math in general.")

#text("Current day mathematical results may not be immediately useful, but they may become incredibly applicable in the far future; number theory being the famous example. It’s true that most pure math results may not be as useful, but it can also be difficult to point out which ones will be. So, one could argue that on average we’ll get something out of funding mathematicians worldwide.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699195")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("“Larger society” pays for public parks, museums, libraries, and a bunch of other things that only exist in order to give people personal satisfaction. We do not require people that go to the park to get around the park by car on the grounds that “parks are paid for by larger society, and we have a duty to use parks as efficiently as we can”.")

#text("I do not mean to imply that you are objectively wrong, and I think your perspective is valid. But I think there is room for a bit more nuance here, and this argument is closely tied with deep questions about the purpose of life itself. If we, as a society must forgo all our sources of “personal satisfaction” for the sake of “progress”, one is left wondering: what is the point of “progress” in the first place?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699200")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("Public parks are available for everyone to enjoy; typically all comers can use the park simultaneously. My faculty position at a Canadian public university is not available to the public: I’m the sole occupant, and when I retire maybe one person will replace me. In particular, if a significant justification for Canadian taxpayers spending ~$200K/year on me were the enjoyment I derive from doing mathematics we would have a serious problem, especially since the government is not spending similar sums on the enjoyment of every other resident.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699202")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("I don’t think that’s the right analogy (if one exists at all). Your faculty position is not available to everyone; but the math department you work on is, ")#emph[#text("and")]#text(" it is not unreasonable to argue that its societal values lies in the enjoyment it provides to people who love mathematics and who love connecting with other like-minded people through it. (Again, I’m only saying that it is not unreasonable to argue this; it is certainly also not unreasonable to argue that its value lies elsewhere).")

#text("You, in your faculty position, act as a caretaker for this “intellectual park”. Similarly, public parks are available to everyone, but only a few get to work there as gardeners.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Oliver")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699212")[#strong[#text("William Oliver")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("It might help if you were to explain what work of yours has provided value to the general public in the way you describe, and how.")
]
]
]
]
