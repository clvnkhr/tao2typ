// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/
// Converted to Typst by tao2typ: "2026-11-04T14:45:13.404414+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Doctoral Advising Guidelines by the AHM", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Doctoral Advising Guidelines by the AHM")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/")[#text("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-04 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by the ")#link("https://www.ahmath.org/")[#text("AHM")]#text(" communications group. — T.]")]

#text("We are happy to announce that the Teaching Working Group of the Association for Human Mathematics wrote ")#link("https://www.ahmath.org/doctoraladvising")[#text("a set of recommendations on doctoral advising")]#text(" aimed at departments, advisors, and students. The document contains five guidelines centered on prioritizing human-authored writing, avoiding overreliance on AI, confronting the ethical concerns of AI use, and improving the wellbeing of students, as well as concrete proposals on how to implement them. We encourage everyone to read and share the document, and we especially look forward to feedback and suggestions.")

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3a67e42ee6dddacfe12657ab6801ed29cd7965344c6646279b187c7b76fefcd-cebbe0226281f777dfd322b06ca6de71b1485abcc4c199db5f5e8d10bdec0816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699163")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("The proposal is very restrictive. Math with AI help can be a successful path, also for young scientists. Many here will not like to hear this: in chess, starting in the middle 1990’s, it took only about 10 years until ALL young people executed chess WITH computer help in their training sessions.")

#text("Back in 1986 Bielefeld University gave me a title “Dr. math”. Perhaps it is an idea to introduce a second doctoral title: “Dr. math-with-AI”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699168")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("A separate comment about humans vs. engines (I understand that you worked on them, so your opinion would be interesting).")

#text("A chess engine has perfect knowledge of the game position after descending into the search tree. Then it calls the evaluation function.")

#text("Humans are not allowed to use pencil and paper or a second chessboard to try out positions and then evaluate at a certain depth. Philosophically, why are humans playing against engines without external memory assistance? It seems that humans are artificially handicapped.")

#text("To come back to math, maybe humans need better lookup mechanisms for theorems and patterns how to use them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699169")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("Magnus Carlsen avoids engines, but his seconds use them:")

#link("https://www.chess.com/news/view/lex-fridman-podcast-magnus-carlsen")[#text("https://www.chess.com/news/view/lex-fridman-podcast-magnus-carlsen")]

#text("“My team does but personally, I try not to use [engines] too much on my own because I know that when I play you obviously cannot have help from engines and I feel like often having imperfect knowledge about a position or some engine knowledge can be a lot worse than having no knowledge. So I try to look at engines as little as possible.”")

#text("This ties back into the other AI discussion whether LLMs make you less intelligent (I think they do). Unfortunately we don’t have seconds.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699170")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("Terry I really do not think you should be posting these AHM guest posts. It is very unhealthy for the future of the profession, and extremely damaging to the reputation of mathematicians. The document by Bryna Kra and the others was fantastic, and emphasized both the need for students to learn to understand deep mathematics as well as engage productively with the new technology.")

#text("I also do not understand why you would abstain from using AI for “ethical” reasons. Can you explain this? I get that you would want to not use it because you prefer to think for yourself, and I get that you would be worried about people forgetting to think because of LLMs. I also get worrying about AI risk, from a virus or a Yudkowsky-type scenario.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699171")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("History will not look kindly on those people at the AHM.")

#text("None of the recommendations make sense or are anything new.")

#text("Recommendation 1: The first sentence already every moderately decent program does. The second sentence is their Ludite push. Good luck with that. The last sentence says nothing. There is nothing that needs to change to accomplish it. You met the requisite (without LLM use), good for you, of course you get your degree.")

#text("Was recommendation 2 written by LLM? It is mixing unrelated “LLM use agreement” and documenting progress. The latter is existing practice. The no need to be first, is not new. Lots of PhD dissertations don’t prove anything new, and get the novelty checkmark from other aspects, like a new proof, some new definitions, algorithm, etc.")

#text("Recommendation 3, i.e. “be careful”, is a well know, non-recommendation. How? Full Ludite?")

#text("Recommendation 4 also says nothing. The “in effect at the time of their program entry” would make a program that can take 4 years not be adaptable. War begins, should still be there the same expectations?")

#text("Recommendation 5 is already in place.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/comment-page-1/#comment-699173")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("In my view while it contains useful recommendations (e.g. treating everyone with empathy, not rewriting the standards for people already in the program, maintaining research records and lab books so that priority and independent discovery can be documented) this report needs to be rejected, and forcefully, by the community. These ordinary recommendations are universal goods that predate the current situation; the stresses placed on everyone merely increase the value of good practices, yet we don’t need the report to tell us that. The real subject, LLMs, are enormously capable tools that will clearly proliferate in the coming years, and mathematics graduates must be trained to be competent in their use, including for mathematical research. The report militates in the opposite direction, and this is unfortunate.")

#text("The capacity for independent understanding, thinking, and research will remain essential, we must still train our students in those skills. For example, my graduate courses in January will ask students to not use LLMs, exactly to develop their mathematical technique and their independent thinking skills. But the overall ")#emph[#text("graduate")]#text(" ")#emph[#text("program")]#text(" (including, quite often, thesis-writing) ")#strong[#text("must")]#text(" involve the most powerful tools available to mathematicians, tools that our graduates are virtually certain to be required to use if they are to pursue mathematics after their degree.")

#text("Would we insist that a “pathways” through a transportation-worker training program “remain available for students who wish to completely abstain from” the driving of gasoline and eletcric cars due to their preference to only use human and animal muscle power? Of course wealthy individuals can choose to ride horses as a luxury, and muscle power is used in a few very exceptional situations, but the transportation industry almost universally uses machines. Our training program is paid for by the larger society, and we should acknowledge that.")

#text("Ultimately, it is quite possible that proving theorems ourselves will turn out to have been more personally satisfying than having a machine generate the proof. But this does not give us a right to socially-funded satisfaction in doing things inefficiently. Mathematics is ")#emph[#text("valuable")]#text(" to society, and we have a duty to teach our students to be able to contribute as powerfully as they can. LLMs are there. That is a fact, and we cannot bury our head in the sand and insist that society preserve our lives the way they were before simply because we want to cling to the past.")
]
