// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/
// Converted to Typst by tao2typ: "2026-11-10T15:04:12.859894+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Doctoral Advising Guidelines by the AHM", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Doctoral Advising Guidelines by the AHM")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/")[#text("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-10 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by the ")#link("https://www.ahmath.org/")[#text("AHM")]#text(" communications group. — T.]")]

#text("We are happy to announce that the Teaching Working Group of the Association for Human Mathematics wrote ")#link("https://www.ahmath.org/doctoraladvising")[#text("a set of recommendations on doctoral advising")]#text(" aimed at departments, advisors, and students. The document contains five guidelines centered on prioritizing human-authored writing, avoiding overreliance on AI, confronting the ethical concerns of AI use, and improving the wellbeing of students, as well as concrete proposals on how to implement them. We encourage everyone to read and share the document, and we especially look forward to feedback and suggestions.")

#heading(level: 1)[#text("Comments (32)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699163")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("The proposal is very restrictive. Math with AI help can be a successful path, also for young scientists. Many here will not like to hear this: in chess, starting in the middle 1990’s, it took only about 10 years until ALL young people executed chess WITH computer help in their training sessions.")

#text("Back in 1986 Bielefeld University gave me a title “Dr. math”. Perhaps it is an idea to introduce a second doctoral title: “Dr. math-with-AI”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2471604c8902ec9746d53afa441873dadc9012b5022d6ff0bc83852a9993e-b8d80f565218ccfbd08a65971f9e4d3de692f80225ef4b30178db5d2e2c01251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699168")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("A separate comment about humans vs. engines (I understand that you worked on them, so your opinion would be interesting).")

#text("A chess engine has perfect knowledge of the game position after descending into the search tree. Then it calls the evaluation function.")

#text("Humans are not allowed to use pencil and paper or a second chessboard to try out positions and then evaluate at a certain depth. Philosophically, why are humans playing against engines without external memory assistance? It seems that humans are artificially handicapped.")

#text("To come back to math, maybe humans need better lookup mechanisms for theorems and patterns how to use them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699188")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("Here are some facts rom Chess history in times of strong chess programs:")

#list(
[#enum(start: 1996, 
[#text("After his win over Deep Blue I")#linebreak()#text("by 4-2 in February 1996, negotiations for")#linebreak()#text("a revenge match started immediately.")#linebreak()#text("Kasaparov was aware that it might become")#linebreak()#text("a narrow encounter, and asked for special")#linebreak()#text("conditions. IBM should allow him threefold")#linebreak()#text("computer help against Deep Blue II: an opening")#linebreak()#text("database, an endgame tablebase (5-stoners),")#linebreak()#text("and a little tactical helper (like chess")#linebreak()#text("program Fritz 4 from ChessBase). IBM")#linebreak()#text("simply said NO – and knew from that moment")#linebreak()#text("on that Kasparov was frightened.")]
)

#enum(start: 1998, 
[#text("Oldtime World Champion Anatoly Karpov")#linebreak()#text("and rising hero Vishy Anand played an echibition")#linebreak()#text("match in computer-aided chess (each player having")#linebreak()#text("a normal PC with chess software besides the board).")#linebreak()#text("Karpov lost by 1-5, mainly do to his basic problems")#linebreak()#text("to operate a chess program.")]
)

#enum(start: 2000, 
[#text("World Chess Championships between favorite")#linebreak()#text("Kasparov and outsider Kramnik. Kramnik had two assistants")#linebreak()#text("who made opening preparation around the clock with")#linebreak()#text("computer help, in particular the “Berlin Wall”. One")#linebreak()#text("of the assistants, GM Bareev, described the exhausting")#linebreak()#text("work (including “almost-burnout”). Kramnik was a hard")#linebreak()#text("boss. At one point, the assistants just had a hard nichgt")#linebreak()#text("behindt them, he simply said: “I had expected more of you.”")]
)],
[#text("2014-2020. In the top German chess scene there was a")#linebreak()#text("longlasting dispute between National Coach Rogozenko and")#linebreak()#text("top player Matthias Blübaum. “Rogo” insisted that players")#linebreak()#text("had to understand the motivs behind the computer proposals.")#linebreak()#text("Blübaum instead simply said: “I believe in the bots.”")#linebreak()#text("This dispute was one of the reason why Rogozenko’s job")#linebreak()#text("was not prolonged in 2020.")#linebreak()#text("Soon afterwards Blübaum won the European Championships")#linebreak()#text("twice (2022 and 2025). Side aspect: Blübaum studied")#linebreak()#text("Mathematics at Bielefeled University and got a Master")#linebreak()#text("degree in pure math (in 2022), of course still completely")#linebreak()#text("without AI help.")],
[#text("Correspondence Chess is more or less dead")#linebreak()#text("due to the overhelmingly strong chess programs.")#linebreak()#text("Here is the final table of the latest completed")#linebreak()#text("World Championships:")#linebreak()#link("https://www.iccf.com/event?id=100104")[#text("https://www.iccf.com/event?id=100104")]#linebreak()#text("and here the preliminary table of the one that")#linebreak()#text("is currently still underway:")#linebreak()#link("https://www.iccf.com/event?id=107382")[#text("https://www.iccf.com/event?id=107382")]#linebreak()#text("Almost all games are draws! Non-draws only when")#linebreak()#text("a player has to step back, for instance because")#linebreak()#text("of death.")],
[#text("A central avantgarde figure was Grandmaster John Nunn (UK)")#linebreak()#text("(born 1955, PhD in Math in 1978 from Oxford). Active in")#linebreak()#text("computer-aided chess and “problem chess” already in the")#linebreak()#text("mid 1980’s")]
)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2471604c8902ec9746d53afa441873dadc9012b5022d6ff0bc83852a9993e-b8d80f565218ccfbd08a65971f9e4d3de692f80225ef4b30178db5d2e2c01251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699203")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("I think that is all undisputed but does not answer the question: Computers literally violate tournament rules by writing down exact board positions to arbitrary depths before calling the evaluation function, have endgame table-bases etc.")

#text("It would be instructive to run an experiment and test how much ELO a selected SuperGM would gain vs. his peers if he were allowed a secret second chessboard to test variations to arbitrary depths and have an opening book and an endgame tablebase.")

#text("I’m not saying that humans would beat a computer with these aids because the computer is faster, but the magic evaporates quite a bit if you look behind the scenes.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699233")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2026")])]

#text("Your argument about “violating tounament rules by computer” does not apply. Such computer programs do not participate in “normal” chess tournaments (for humans). Instead these events are specially designed experiments, for instance Kasparov vs Deep Blue II back in 1997. IBM paid Kasparov big money (if I remember correctly 700,000 $ if he would have won, and 400,000 $ for the loss). Kasparov asked for other side conditions, but IBM simply said: “We pay, and so we decide the rules”.")

#text("I myself also paid the Grandmasters for participation in my experiments. Look at the first picture at althofer.de . In the upper left East German grandmaster Rainer Knaak (chess pro, but also a mathematician, by the way) is operating a laptop (200 Mhz tact speed) in an experiment against a standalone chess program on 600 MHz PC (operated by me). In that event (8 games in 8 days) Knaak won by 5.5 – 2.5 (+4, =3, -1)")

#text("Very recently speed chess matches have become popular: 3 min plus two seconds/move for each side. One side is a human chess master, the other side a chess program (like Stockfish) playing without queen (so very heavy odds). Typically it is hard for the human to achieve at least 50 % scores.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699240")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2026")])]

#text("That’s not an appropriate comparison. Humans also store thousands of positions and games in their brains and look them up when they play. They also create there alternative boards and simulate moves. The same kind of cheating that machines do.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2471604c8902ec9746d53afa441873dadc9012b5022d6ff0bc83852a9993e-b8d80f565218ccfbd08a65971f9e4d3de692f80225ef4b30178db5d2e2c01251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699169")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("Magnus Carlsen avoids engines, but his seconds use them:")

#link("https://www.chess.com/news/view/lex-fridman-podcast-magnus-carlsen")[#text("https://www.chess.com/news/view/lex-fridman-podcast-magnus-carlsen")]

#text("“My team does but personally, I try not to use [engines] too much on my own because I know that when I play you obviously cannot have help from engines and I feel like often having imperfect knowledge about a position or some engine knowledge can be a lot worse than having no knowledge. So I try to look at engines as little as possible.”")

#text("This ties back into the other AI discussion whether LLMs make you less intelligent (I think they do). Unfortunately we don’t have seconds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699185")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("The current world chess champion, Gukesh Dommaraju, did not use engines until he reached 2500, see e.g. ")#link("https://en.wikipedia.org/wiki/Gukesh_Dommaraju#Chess_beginnings")[#text("https://en.wikipedia.org/wiki/Gukesh_Dommaraju#Chess_beginnings")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699170")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("Terry I really do not think you should be posting these AHM guest posts. It is very unhealthy for the future of the profession, and extremely damaging to the reputation of mathematicians. The document by Bryna Kra and the others was fantastic, and emphasized both the need for students to learn to understand deep mathematics as well as engage productively with the new technology.")

#text("I also do not understand why you would abstain from using AI for “ethical” reasons. Can you explain this? I get that you would want to not use it because you prefer to think for yourself, and I get that you would be worried about people forgetting to think because of LLMs. I also get worrying about AI risk, from a virus or a Yudkowsky-type scenario.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e31250526a5b9f6f1463c1abf69b93591d80f40877c1d78e606d35cc858c94bc-d6fb1e585e2ad7f7710f938b6b53a3ff8e0410d89aa0ffcfee5c4b99fe5fad70.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699191")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("I’m glad the AHM at least exists. Because people should have a choice NOT to engage with AI. I love math but want nothing to do with AI.")

#text("AI is also unethical for two reasons: environmental cost, and promoting it also promotes the destruction of human communities.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699197")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("The choice exists and AHM has nothing to do with it existing.")

#text("The crucial aspect of mathematical practice that LLM use impacts is evaluation and AHM’s document gave zero, null, nada, in recommendations on how to address it. How to evaluate and compare candidate A who used LLM to candidate B who did not? Their only position, abstention. Do not use. “We are the Ludites of this time”. However, that doesn’t solve anything. Society still needs to do separation of labour. Candidate A who used LLM and candidate B who didn’t need both be evaluated, and more importantly, during hiring be compared. There is zero, null, nada, in terms of recommendations from AHM regarding that. Useless bunch.")

#text("And you are leaving academia, so …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699207")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("I agree that people should have a choice not to engage with AI. However, people shouldn’t be writing serious proposals saying that grad schools should discourage their students from ever using AI. That’s why I object to the AHM. If you look at the Harvard PhD summit here ")#link("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/")[#text("https://terrytao.wordpress.com/2026/09/25/recommendations-of-the-summit-on-phd-math-education-in-the-age-of-ai/")]#text(" there are many reasonable proposals, encouraging people to learn to use AI but also saying that no one should be forced to use AI.")

#text("The environmental cost is fake. The unit distance conjecture cost as much water as three almonds. I don’t think AI promotes the “destruction of human communities”. It disrupts some things but it is ultimately up to humans what to do. The future of AI and math will be determined by mathematicians.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699171")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("History will not look kindly on those people at the AHM.")

#text("None of the recommendations make sense or are anything new.")

#text("Recommendation 1: The first sentence already every moderately decent program does. The second sentence is their Ludite push. Good luck with that. The last sentence says nothing. There is nothing that needs to change to accomplish it. You met the requisite (without LLM use), good for you, of course you get your degree.")

#text("Was recommendation 2 written by LLM? It is mixing unrelated “LLM use agreement” and documenting progress. The latter is existing practice. The no need to be first, is not new. Lots of PhD dissertations don’t prove anything new, and get the novelty checkmark from other aspects, like a new proof, some new definitions, algorithm, etc.")

#text("Recommendation 3, i.e. “be careful”, is a well know, non-recommendation. How? Full Ludite?")

#text("Recommendation 4 also says nothing. The “in effect at the time of their program entry” would make a program that can take 4 years not be adaptable. War begins, should still be there the same expectations?")

#text("Recommendation 5 is already in place.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2471604c8902ec9746d53afa441873dadc9012b5022d6ff0bc83852a9993e-b8d80f565218ccfbd08a65971f9e4d3de692f80225ef4b30178db5d2e2c01251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699193")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("This is how cigarettes were marketed to fools back in the day. You weren’t cool if you didn’t smoke. Now everyone tries to ban them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699173")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("In my view while it contains useful recommendations (e.g. treating everyone with empathy, not rewriting the standards for people already in the program, maintaining research records and lab books so that priority and independent discovery can be documented) this report needs to be rejected, and forcefully, by the community. These ordinary recommendations are universal goods that predate the current situation; the stresses placed on everyone merely increase the value of good practices, yet we don’t need the report to tell us that. The real subject, LLMs, are enormously capable tools that will clearly proliferate in the coming years, and mathematics graduates must be trained to be competent in their use, including for mathematical research. The report militates in the opposite direction, and this is unfortunate.")

#text("The capacity for independent understanding, thinking, and research will remain essential, we must still train our students in those skills. For example, my graduate courses in January will ask students to not use LLMs, exactly to develop their mathematical technique and their independent thinking skills. But the overall ")#emph[#text("graduate")]#text(" ")#emph[#text("program")]#text(" (including, quite often, thesis-writing) ")#strong[#text("must")]#text(" involve the most powerful tools available to mathematicians, tools that our graduates are virtually certain to be required to use if they are to pursue mathematics after their degree.")

#text("Would we insist that a “pathways” through a transportation-worker training program “remain available for students who wish to completely abstain from” the driving of gasoline and eletcric cars due to their preference to only use human and animal muscle power? Of course wealthy individuals can choose to ride horses as a luxury, and muscle power is used in a few very exceptional situations, but the transportation industry almost universally uses machines. Our training program is paid for by the larger society, and we should acknowledge that.")

#text("Ultimately, it is quite possible that proving theorems ourselves will turn out to have been more personally satisfying than having a machine generate the proof. But this does not give us a right to socially-funded satisfaction in doing things inefficiently. Mathematics is ")#emph[#text("valuable")]#text(" to society, and we have a duty to teach our students to be able to contribute as powerfully as they can. LLMs are there. That is a fact, and we cannot bury our head in the sand and insist that society preserve our lives the way they were before simply because we want to cling to the past.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e31250526a5b9f6f1463c1abf69b93591d80f40877c1d78e606d35cc858c94bc-d6fb1e585e2ad7f7710f938b6b53a3ff8e0410d89aa0ffcfee5c4b99fe5fad70.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699192")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("This makes no sense. Mathematics teaching is valuable, and a subset of mathematics that is decades old is valuable. But hardly any new mathematics is valuable to anyone. Improving bounds on twin prime gaps, Langlands, geometric group theory, it’s really not valuable at all except to produce fine mathematicians capable of understanding math to be taught.")

#text("You’re fooling yourself if you think pushing mathematics further and faster will make any difference whatosever to society compared to just humans doing mathematics.")

#text("Sometimes we should cling to the past. It’s an incredible folly to think that every single technological advancement is a good thing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699210")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("Are you really saying that the practice of mathematical research is mostly for training new mathematicians to teach the older, and actually valuable, theories and results? Even if this were true, I guess there would be more efficient ways of training for this objective. Also “current math research is useless” reads more like push for more applied math than a counter to AI in math in general.")

#text("Current day mathematical results may not be immediately useful, but they may become incredibly applicable in the far future; number theory being the famous example. It’s true that most pure math results may not be as useful, but it can also be difficult to point out which ones will be. So, one could argue that on average we’ll get something out of funding mathematicians worldwide.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699195")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("“Larger society” pays for public parks, museums, libraries, and a bunch of other things that only exist in order to give people personal satisfaction. We do not require people that go to the park to get around the park by car on the grounds that “parks are paid for by larger society, and we have a duty to use parks as efficiently as we can”.")

#text("I do not mean to imply that you are objectively wrong, and I think your perspective is valid. But I think there is room for a bit more nuance here, and this argument is closely tied with deep questions about the purpose of life itself. If we, as a society must forgo all our sources of “personal satisfaction” for the sake of “progress”, one is left wondering: what is the point of “progress” in the first place?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699200")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("Public parks are available for everyone to enjoy; typically all comers can use the park simultaneously. My faculty position at a Canadian public university is not available to the public: I’m the sole occupant, and when I retire maybe one person will replace me. In particular, if a significant justification for Canadian taxpayers spending ~$200K/year on me were the enjoyment I derive from doing mathematics we would have a serious problem, especially since the government is not spending similar sums on the enjoyment of every other resident.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699202")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("I don’t think that’s the right analogy (if one exists at all). Your faculty position is not available to everyone; but the math department you work on is, ")#emph[#text("and")]#text(" it is not unreasonable to argue that its societal values lies in the enjoyment it provides to people who love mathematics and who love connecting with other like-minded people through it. (Again, I’m only saying that it is not unreasonable to argue this; it is certainly also not unreasonable to argue that its value lies elsewhere).")

#text("You, in your faculty position, act as a caretaker for this “intellectual park”. Similarly, public parks are available to everyone, but only a few get to work there as gardeners.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699219")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2026")])]

#text("I think you are correct. The downvotes, I think, are an indication that there has been a huge disconnect between the value the general public would get from mathematicians and what they actually provide.")

#text("That said, to Lior Silberman’s point, what you are describing is ")#emph[#text("not")]#text(" how mathematics operates currently. But I think this is a failing on the part of the mathematics community as it currently stands, not something that is intrinsic to it.")

#text("There are many other high-skill fields where what you are describing ")#emph[#text("is ")]#text("the case. Take music for an example, not only do musicians have concerts, but a member of the general public who has a full time job can join a local class to go from a beginner to an advanced (‘graduate’) level of knowledge in theory, if they are willing to stick with it for long enough. In most cities, there is a relatively accessible pathway to be a part of the local community of musicians. Importantly, ")#emph[#text("you can be a part of this community even if you are not great at music. ")]#text("This is because there is far less of a ‘cult of genius’ in music. The same goes for other fields like visual art, martial arts, etc.")

#text("In contrast, the community of mathematicians is not like this at all. Its extremely inaccessible. If you have a full time job, in practice, you have to invest many, many years, and (in some countries) tens of thousands of dollars before you can get someone to even begin to teach you ")#emph[#text("actual ")]#text("mathematics. By ")#emph[#text("actual ")]#text("mathematics, I mean a) independent thought, thinking for yourself, and b) communicating that independent thinking in such a way that it will be taken seriously by other people. You can reasonably learn the former on your own, but the latter is very difficult if not impossible to do on your own in the current mathematical climate.")

#text("There is a gigantic wall between ‘knowing’ math and actually being part of a community of mathematicians in essentially any capacity. That is, ")#emph[#text("unless you are extremely good at it")]#text(" ")#emph[#text("from the get go")]#text(", and ")#emph[#text("then")]#text(" mathematicians will engage with you.")

#text("Personally, I want to be able to do math ")#emph[#text("in a community of people,")]#text(" the way an amateur musicians can do music in a community of people, even if they have no desire to be a professional musician. But if not impossible, this is at least prohibitively difficult for members of the general public to do. And that is a ")#emph[#text("major")]#text(" problem.")

#text("Where are the local math studios with weekend classes?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699241")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2026")])]

#text("And also not every park is equally available to everyone. A park at an attractive location is hardly available to all those who can’t afford living anywhere near to it. It’s mainly available to the privileged locals, or to those who merited the privilege if you wish.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Oliver")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699212")[#strong[#text("William Oliver")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("It might help if you were to explain what work of yours has provided value to the general public in the way you describe, and how.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699292")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2026")])]

#text("That is a good question that we us public employees should always us ourselves. In my view the honest answer is that most mathematical work will not be specifically useful — it is merely of academic interest. The enterprise as a whole, on the other hand, is useful, and we cannot predict in advance which parts will turn out to be the useful ones. It would be great if we could tell in advance what parts are useful and only engage in them, but this kind of centrally planned research has not worked out (in mathematics; in parts of science where experiments cost hundreds of millions or billions of dollars the situation is, by necessity, different). What works is that we all pursue whatever interests us for our private purposes, and the discipline as a whole benefits society.")

#text("That said, I hope that my current work on faster numerical integration for the electronic structure of molecules will be used by the public once the project as a whole is complete.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699214")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("Not all public funds need to go towards an explicitly communal asset like public parks. Let me explain with a somewhat idealized model.")

#text("I believe we, as a society, aim to produce more than just the bare minimum necessary for survival; we want to live enjoyable and meaningful lives, not merely just get by. In a very naive model, we would collect all taxpayer money and begin distributing it towards basic necessities like healthcare, housing, basic education, etc. But there should be an excess (ever increasing as technology evolves) which can be put towards arts and culture, technology, research, and other non-essential goals.")

#text("As we distribute this excess, perhaps some artist will get more support than another one, or perhaps some cultural activities will be only interesting to a small parcel of the population. That is all fine, we are distributing excess resources and we can’t perfectly compute how to give everyone an exactly equal amount of utility. Of course, we shouldn’t just randomly give everything to one person, but the smaller variations in how things are allocated are to be expected. Maybe you live far away from the public park, but you happened to get public funding to make a beautiful art piece, and maybe you feel that things balance out.")

#text("In this type of scenario, I would argue you are being paid mostly with the excess funds to do mathematics, teach it, bring together those interested in it, etc. As the other comment said, at your institution you serve as one of the caretaker of mathematics. In this capacity, you are also given the privilege of contributing to define what it means to do mathematics.")

#text("The fact that you would be paid in part to fund your personal enjoyment is not inherently bad, as other people are also similarly receiving a parcel of our excess societal resources that you do not receive.")

#text("One of the problems of making this argument more realistic is that clearly we are not even close to distributing things approximately equally. We are not even doing an excellent job at distributing the essentials. So you can claim that your $200k salary is actually magnitudes more than the typical funding that a regular citizen gets for their own enjoyment, and that you believe this is unfair.")

#text("We could make it more fair by demanding the activity is not totally leisurely, as you point out. But couldn’t we also direct some of the efforts at simply improving our overall excess resources? Such that more and more people get paid $200k to do something enjoyable. As with all things, the answer probably lies in the middle: maybe we should justify at least a parcel of your $200k as being due to your contributions to society. This is already somewhat true: you teach, you contribute to the overall organization of the department, etc.")

#text("In essence, I do not believe it is wrong that we are trying to fund people’s happiness. Ethically, you can feel too privileged to be paid to enjoy mathematics, and you have every right of trying to make this a more fair exchange. But I’d like to believe you simply happened to land in a lucky situation in the timeline: one where we are not yet at the stage in which we can do this for everyone.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699227")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2026")])]

#text("I am the “public parks” guy and I just wanted to say that you expressed my opinion on this topic better than I possibly could. Good job!")

#text("People being able to dedicate their lives to things that fulfill them is (or should be) the ultimate goal of progress. Technology should serve that goal, not the other way around.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699222")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2026")])]

#text("Lior, I agree with the sentiment")

#text("‘Mathematics is ")#emph[#text("valuable")]#text(" to society, and we have a duty to teach our students to be able to contribute as powerfully as they can.’")

#text("What is less clear to me is what this means as a prescription. I -think- you’re saying we must teach students the most powerful tools they have to conduct mathematics ")#emph[#text("so as to contribute to society")]#text(" (emphasis mine).")

#text("If this is what you mean, then it’s worth asking what’s the nature of mathematical contributions actually valued. I think the taxpayer values the teaching of mathematics.")

#text("In terms of occupations, here’s what I can find in the US. It’s very interesting to see the ‘top employing’ occupations for someone with a math degree. ")#link("https://www.bls.gov/ooh/field-of-degree/mathematics/mathematics-field-of-degree.htm")[#text("https://www.bls.gov/ooh/field-of-degree/mathematics/mathematics-field-of-degree.htm")]

#text("In BC, if one looks for jobs for mathematicians, one gets a list.")#link("https://www.workbc.ca/find-job/search-jobs#/job-search;search=mathematics;")[#text("https://www.workbc.ca/find-job/search-jobs#/job-search;search=mathematics;")]#link("https://www.workbc.ca/find-job/search-jobs#/job-search;search=mathematics")[#text("https://www.workbc.ca/find-job/search-jobs#/job-search;search=mathematics")]#text(";")

#text("What I infer is three things: (a) already most industries don’t pay for theorems themselves and (b) most industries value ")#emph[#text("the habits of mind mathematicians are supposed to have")]#text(" and (c) we don’t really structure graduate programs to teach the power tools or skills industries need at any moment in time (this is a moving target, but let’s be honest, no math phd program is requiring students to learn PyTorch or TensorFlow or R etc.) I might personally love for our classes in scientific computing or the mathematics of data to be required classes for every student in the grad program, but they’re not!")

#text("The key is (b), unless we have evidence of something else being more important. A graduate training in mathematics is valued in society in terms of occupations because of the habits of mind inculcated, with the assumption that students with these habits of mind will learn the specific skills needed by a specific employer.")

#text("If my reading of all this is correct, then it isn’t immediately obvious that we all -must- or -must not- do something with regards to the inclusion of LLM in graduate training. Instead, at least I’d like to know a bit more. Maybe some supervisors and programs will come to some conclusion, and others to a diametrically opposite one. I think ")#emph[#text("individuals")]#text(" will make diverse choices about which tools they adopt, as they always have.")

#text("-Nilima")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699293")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2026")])]

#text("Hello Nilima! I don’t have a prescription exactly: I was mostly arguing against the view that PhD students ought to have a right to refuse to engage with modern technology. Here’s what I can say:")

#list(
[#text("Mathematics is, above all, the ")#emph[#text("way of thinking")]#text(", and it is that which is most useful (and what the students take with them for later). I agree that the theorems are of academic interest: they are not the point of the training, outside the few students who will continue in academia, but rather a training tool. This will be especially true in a world where machines can prove theorems cheaply. On this I am definite.")],
[#text("However, while we must thus provide extensive training in how to think without recourse to LLMs (perforce this training must be done without LLMs doing any thinking), I personally think our programs do need to provide space for training in how to think and obtain results ")#emph[#text("with")]#text(" LLMs (and whatever other tools become available). Otherwise we will deny our graduates essential training for their future.")],
[#text("These are thoughts of the level of the ")#emph[#text("graduate program")]#text(", not any particular part of it. For example in my graduate courses for next term I hope the students will not use LLMs at all (to solve the homework), since the goal of the courses is to train them to personally think about classical mechanics and analytic number theory (respectively).")],
[#text("Speaking of choice, if some colleagues would prefer to work entirely without LLMs and train students traditionally, that would be their choice, and students who want to should be free to seek such advisors. Part of academic freedom is that I don’t make choices for my colleagues or their students — even if I may disagree with their choices. But that is not what the AHM is calling for: giving students the ")#strong[#text("right")]#text(" to refuse to work as their advisor directs.")]
)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699309")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2026")])]

#text("You write: “the AHM is calling for: giving students the ")#strong[#text("right")]#text(" to refuse to work as their advisor directs.”")

#text("Where precisely in their recommendations is this called for?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699311")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2026")])]

#text("It’s literally recommendation 1: “Doctoral programs and faculty should ensure that pathways to a doctoral degree remain available for students who wish to completely abstain from generative AI and LLM use in their academic work and training.”")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02f9807e0b8c18038b6631c56848e63e0f088c03640277e302dca07d02c17973-3f8fb85a3b766a6c73f3600e2565cc9ba7195425bdc715cece1d754cafa2112e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guill Guill")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699226")[#strong[#text("Guill Guill")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2026")])]

#text("mhh")#linebreak()#text("Doing maths w/o the use of ai mandatory to have a phd is sane. But on the other hand you cannot blind yourself, future mathematicians will use ai so students should also be formed to find intersting question and try to solve them with ai. The two are needed: beeing able do to maths w/o the use of ai and beeing able to use the ai tool to come with new interesting stuff.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/03/doctoral-advising-guidelines-by-the-ahm/#comment-699264")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("3. Members of the AI-free caucus do not use AI models in a research capacity.")]#text(" Members of this caucus engage in core mathematical activities, such as finding proofs, exploring examples, and posing research questions, without prompting Al tools.")
]

#text("“I” (i.e. myself with AI extensive assistance) have published three papers in three days, each of which on its own would have earned me a PhD in Mathematics and a faculty position, pre-AI. I have an undergraduate degree with a major in Pure Mathematics (among others), completed almost 40 years ago.")

#text("Three in three days. As side projects to my primary work.")

#text("Whatever you think of AI, I don’t see how the viewpoint expressed in the above blockquote can survive.")
]
