// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/08/25/rotating-needles-in-space-the-road-to-the-kakeya-conjecture-and-why-it-matters/
// Converted to Typst by tao2typ: "2026-11-25T17:27:07.827969+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Rotating needles in space: the road to the Kakeya conjecture, and why it matters", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Rotating needles in space: the road to the Kakeya conjecture, and why it matters")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 August 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/08/25/rotating-needles-in-space-the-road-to-the-kakeya-conjecture-and-why-it-matters/")[#text("https://terrytao.wordpress.com/2026/08/25/rotating-needles-in-space-the-road-to-the-kakeya-conjecture-and-why-it-matters/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-25 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("A recent tradition of the ICM is to have a non-technical popular article written for each of its medallists. (This is separate from the older tradition of having a laudatio for the winner, which is similar but aimed at a more advanced audience.) I was approached to write such an article for Hong Wang on the occasion of her Fields Medal. I have uploaded my initial version of this article, “")#link("https://arxiv.org/abs/2608.22209")[#text("Rotating needles in space: the road to the Kakeya conjecture, and why it matters")]#text("“, to the arXiv. Chris Sogge gave the corresponding laudatio; both should eventually appear in the Proceedings of the ICM.")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/25/rotating-needles-in-space-the-road-to-the-kakeya-conjecture-and-why-it-matters/#comment-694109")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2026")])]

#text("Thanks for sharing this. It was a great read for a non-mathematician and I now have a better understanding of Wang and colleagues’ contribution and impact on so many seemingly unrelated fields!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/25/rotating-needles-in-space-the-road-to-the-kakeya-conjecture-and-why-it-matters/#comment-694118")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2026")])]

#text("Thank you for this accessible and explanatory article! I am very interested in the Gibbs phenomenon mentioned in the article, and I am wondering why this phenomenon occurs. May I ask what the fundamental cause of the Gibbs phenomenon is?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/25/rotating-needles-in-space-the-road-to-the-kakeya-conjecture-and-why-it-matters/#comment-694121")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2026")])]

#text("The word “rangle” appears on page 3, was that a typo?")

#emph[#text("[That should be “rectangle”; it will be corrected in the next revision of the ms -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/25/rotating-needles-in-space-the-road-to-the-kakeya-conjecture-and-why-it-matters/#comment-694173")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2026")])]

#text("page 11, “to difficult”, typo?")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0b423fadc513ac0411dd0514ea026a2d16a4135f02398c6cf3e216875f731e7-f10415d608fb7f54446cf1edbfc12d995d6764cec76d613dd19362a166d378a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Justin Bian")]], [#link("https://terrytao.wordpress.com/2026/08/25/rotating-needles-in-space-the-road-to-the-kakeya-conjecture-and-why-it-matters/#comment-694184")[#strong[#text("Justin Bian")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2026")])]

#text("Dear Professor Tao,")

#text("In the “back of the envelope calculation”, at the end of page 3, we have “a typical point in one rectangle is covered by only one or two other rectangles”. Can we pin down the number to one or two, or should we also use O(1) wordings here?")

#emph[#text("[I will reword “one or two” to “a small number of” in the next revision – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/25/rotating-needles-in-space-the-road-to-the-kakeya-conjecture-and-why-it-matters/#comment-694205")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2026")])]

#text("I am curious about the use of Al assistance to generate images in published articles (though not necessarily this article in particular). Some images, like figure 1 in your article, can easily be created using Al-generated TikZ code. But more complicated images (perhaps figure 5—the Gaussian wave packet) may be generated as an image and then imported into the file.")

#text("How does an author prevent unintentional plagiarism and/or copyright infringement in such cases? It seems possible that an Al-created image could be “similar enough” to some other published image to warrant this concern.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c3afd068e53cf7f93d9ab27a0dbfec7677115a4cd5b2262e3e436db59957ce45-f2190f84cffcf30467e824f51d0e975d2762789f7e25a57eaf22b7ee6efdee42.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zhigang Zhang")]], [#link("https://terrytao.wordpress.com/2026/08/25/rotating-needles-in-space-the-road-to-the-kakeya-conjecture-and-why-it-matters/#comment-700083")[#strong[#text("Zhigang Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("Dear Professor Tao,")#linebreak()#text("Thank you for your beautiful exposition on the Kakeya conjecture.")#linebreak()#text("While studying the classical Perron tree construction, I noticed a geometric constraint that may relate to the “sticky” case you mentioned.")#linebreak()#text("The Kakeya problem requires a continuous rotation in a single direction through all 360°. However, in the Perron tree construction, the sliced sectors often carry opposite rotation histories—like a left-handed circle and a right-handed circle. They appear identical in shape, but cannot fully coincide under translation alone.")#linebreak()#text("Two facts, verifiable through simple overlap and congruence constructions, convince me that this chirality cannot be eliminated by translation:")#linebreak()#text("First, for any two adjacent infinitesimal sectors, using simple overlap and congruence constructions, the total remaining area after translation is at least 3/4 of their original combined area. This means no matter how finely the sectors are cut, there is a clear lower bound on the area loss caused by translation.")#linebreak()#text("Second, within the 0° to 90° rotation range, the overlap ratio between each small sector and the first sector decreases monotonically. This is a geometric fact directly verifiable through overlap and congruence relations.")#linebreak()#text("Based on these two points, in my simple model, for sectors possibly smaller than 90°, the residual non-overlapping area converges to 1/2 of the original triangle, not zero. Beyond 90°, one-dimensional symmetry begins to intervene and the overlap ratio may increase—but this is beyond my ability to calculate precisely. Notably, at 360° (a full circle), the translation compression limit of the disk generated by endpoint rotation is 1/4 of the original area—an interesting contrast to the classical center-rotation construction (deltoid, π/8).")#linebreak()#text("I suspect that in the classical proof, when dealing with infinitesimal sectors, the information about “rotation direction” may have been inadvertently lost—and this might be precisely what makes the sticky case difficult.")#linebreak()#text("I have posted some informal notes on Zenodo regarding this observation. I would be very grateful if you could offer any guidance on whether this direction is worth pursuing further.")#linebreak()#text("Finally, I should honestly mention that I am an independent thinker from China, and my English expression relies heavily on AI assistance. Please forgive any awkwardness in phrasing.")#linebreak()#text("Best regards,")
]
