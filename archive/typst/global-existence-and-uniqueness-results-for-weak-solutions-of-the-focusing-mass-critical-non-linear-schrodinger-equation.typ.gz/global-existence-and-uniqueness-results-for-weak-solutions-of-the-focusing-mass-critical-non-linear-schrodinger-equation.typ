// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/07/19/global-existence-and-uniqueness-results-for-weak-solutions-of-the-focusing-mass-critical-non-linear-schrodinger-equation/
// Converted to Typst by tao2typ: "2026-10-14T15:16:50.412423+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Global existence and uniqueness results for weak solutions of the focusing mass-critical non-linear Schrödinger equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Global existence and uniqueness results for weak solutions of the focusing mass-critical non-linear Schrödinger equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 July 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/07/19/global-existence-and-uniqueness-results-for-weak-solutions-of-the-focusing-mass-critical-non-linear-schrodinger-equation/")[#text("https://terrytao.wordpress.com/2008/07/19/global-existence-and-uniqueness-results-for-weak-solutions-of-the-focusing-mass-critical-non-linear-schrodinger-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("I’ve just uploaded to the ")#link("http://www.arxiv.org/")[#text("arXiv")]#text(" the paper “")#link("http://arxiv.org/abs/0807.2676")[#text("Global existence and uniqueness results for weak solutions of the focusing mass-critical non-linear Schrödinger equation")]#text("“, submitted to ")#link("http://pjm.math.berkeley.edu/apde/about/journal/about.html")[#text("Analysis & PDE")]#text(". This paper is concerned with solutions ")#mi("u: I \\times {\\Bbb R}^d \\to {\\Bbb C}")#text(" to the focusing ")#link("http://tosio.math.toronto.edu/wiki/index.php/Mass_critical_NLS")[#text("mass-critical NLS ")]#text("equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("i u_t + \\Delta u = -\\left|u\\right|^{4/d} u,", block: true)]]

#text("where the only regularity we assume on the solution is that the mass ")#tao-math("M(u(t)) := \\int_{{\\Bbb R}^d} \\left|u(t,x)\\right|^2\\ dx", block: false)#text(" is finite and locally bounded in time. (For sufficiently strong notions of solution, the mass is in fact conserved, but part of the point with this paper is that mass conservation breaks down when the solution becomes too weak.) Note that the mass is dimensionless (i.e. scale-invariant) with respect to the natural scale invariance ")#mi("u(t,x) \\mapsto \\frac{1}{\\lambda^{d/2}} u(\\frac{t}{\\lambda^2}, \\frac{x}{\\lambda})")#text(" for this equation. For various technical reasons I work in high dimensions ")#mi("d \\geq 4")#text(" (this in particular allows the nonlinearity in (1) to be locally integrable in space).")

#text("In the classical (smooth) category, there is no ambiguity as to what it means for a function u to “solve” an equation such as (1); but once one is in a low regularity class (such as the class of finite mass solutions), there are several competing notions of solution, in particular the notions of a ")#emph[#text("strong solution")]#text(" and a ")#emph[#text("weak solution")]#text(". To oversimplify a bit, both strong and weak solutions solve (1) in a distributional sense, but strong solutions are also continuous in time (in the space ")#mi("L^2({\\Bbb R}^d)")#text(" of functions of finite mass). A canonical example here is given by the ")#link("http://tosio.math.toronto.edu/wiki/index.php/Pseudoconformal_Transformation")[#text("pseudoconformally transformed")]#text(" soliton blowup solution")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("u(t,x) := \\frac{1}{\\left|t\\right|^{d/2}} e^{-i/t} e^{i\\left|x\\right|^2/4t} Q(x/t)", block: true)]]

#text("to (1), where Q is a solution to the ground state equation ")#tao-math("\\Delta Q + \\left|Q\\right|^{4/d} Q = Q", block: false)#text(". This solution is a strong solution on (say) the time interval ")#mi("(-\\infty,0)")#text(", but cannot be continued as a strong solution beyond time zero due to the discontinuity at t=0. Nevertheless, it can be continued as a weak solution by extending by zero at t=0 and at ")#mi("t>0")#text(" (or alternatively, one could extend for ")#mi("t>0")#text(" using (2); thus there is no uniqueness for the initial value problem in the weak solution class. Note this example also shows that weak solutions need not conserve mass; all the mass in (1) concentrates into the spatial origin as ")#mi("t \\to 0")#text(" and disappears in the limit t=0).")

#text("There is a slightly stronger notion than a strong solution, which I call a Strichartz-class solution, in which one adds an additional regularity assumption ")#mi("u \\in L^2_{t,loc} L^{2d/(d-2)}_x")#text(". This assumption is natural from the point of view of ")#link("http://tosio.math.toronto.edu/wiki/index.php/Strichartz_estimates")[#text("Strichartz estimates")]#text(", which are a major tool in the analysis of such equations.")

#text("There is a vast ")#link("http://tosio.math.toronto.edu/wiki/index.php/Mass_critical_NLS")[#text("theory for the initial value problem for these sorts of equations")]#text(", but basically one has the following situation: in the category of Strichartz class solutions, one has local existence and uniqueness, but not global existence (as the example (2) already shows); at the other extreme, in the category of weak solutions, one has global existence, but not uniqueness (as (2) again shows).")

#text("(This contrast between strong and weak solutions shows up in many other PDE as well. For instance, global existence of smooth solutions to the Navier-Stokes equation is one of the Clay Millennium problems that I have ")#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")[#text("blogged about before")]#text(", but global existence of weak solutions is quite easy with today’s technology and was first done by Leray back in 1933.)")

#text("In this paper, I introduce a new solution class, which I call the semi-Strichartz class; rather than being continuous in time, it varies ")#emph[#text("right")]#text("-continuously (in both the mass space and the Strichartz space) in time in the future of the initial time ")#mi("t_0")#text(", and ")#emph[#text("left")]#text("-continuously in the past of ")#mi("t_0")#text(". With this tweak of the definition, it turns out that one has both global existence and uniqueness in this class. (For instance, if one started with the initial data u(-1) given by (2) at time t=-1, the unique global semi-Strichartz solution from this initial data would be given by (2) for negative times and by zero for non-negative times.) This notion of solution is analogous (but much, much simpler than) the notion of Ricci flow with surgery used by Hamilton and Perelman; basically, every time a singularity develops, the semi-Strichartz solution removes the portion of mass that was becoming discontinuous, leaving only the non-singular portion of the solution to continue onwards in time.")

#metadata(none) <tao-cd71f671bede7394a145>

#text("There are a number of other auxiliary results. For instance, I show that the mass in the semi-Strichartz class is conserved except at a finite number of “surgery times”, in which the mass drops by at least a fixed amount; in the spherically symmetric case, the mass must drop by at least the mass M(Q) of the ground state; this is consistent with the general philosophy of “quantisation of mass” for these equations. Outside of the surgery class, one has a Strichartz class solution. These results are proven by minor variations of the standard Strichartz theory (and in the spherically symmetric case, also use a global well-posedness result for masses below M(Q) of ")#link("http://arxiv.org/abs/math.AP/0609692")[#text("myself, Visan, and Zhang")]#text(").")

#text("When I work in higher dimensions ")#mi("d \\geq 5")#text(" and assume spherical symmetry, I can use a decomposition of spherically symmetric waves into inward and outward components (that I used an ")#link("http://arxiv.org/abs/math.AP/0309428")[#text("earlier paper")]#text(" on NLS, as well as in a ")#link("http://arxiv.org/abs/0707.3188")[#text("paper with Killip and Visan")]#text("), there are some further results available. First of all, one can show that the notions of strong solution and Strichartz class solution are equivalent, and that weak solutions of sufficiently small mass are automatically strong. In particular, strong solutions are unique in this category (this type of result is known as ")#emph[#text("unconditional uniqueness")]#text(" in the literature). Also, a weak solution is strong precisely when its mass function is continuous, and if the mass is continous, then it is in fact constant. So one can easily read off the nature of a solution just by inspecting how the mass changes in time.")

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/07/19/global-existence-and-uniqueness-results-for-weak-solutions-of-the-focusing-mass-critical-non-linear-schrodinger-equation/#comment-31309")[#strong[#text("Global existence and uniqueness results for weak solutions of the focusing mass-critical non-linear Schrödinger equation | Techspedia™")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2008")]

#text("[…] I’ve just uploaded to the arXiv the paper “Global existence and uniqueness results for weak solutions of the focusing mass-critical non-linear Schrödinger equation“, submitted to Analysis & PDE. This paper is concerned with solutions to the focusing mass-critical NLS equation , (1) where the only regularity we assume on the solution is that the mass is finite and locally bounded in time. (For sufficiently strong notions of solution, the mass is in fact conserved, but part of the poin The Rest Of The Story at Technorati … […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabrice Planchon")]], [#link("https://terrytao.wordpress.com/2008/07/19/global-existence-and-uniqueness-results-for-weak-solutions-of-the-focusing-mass-critical-non-linear-schrodinger-equation/#comment-31375")[#strong[#text("Fabrice Planchon")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2008")])]

#text("Dear Terry,")

#text("concerning unconditional well-posedness (UWP), there are a few results beyond Kato’s papers in the 90’s, most notably Furioli-Terraneo and recently Tsutsumi and one of his students. See e.g.")

#link("http://eprints.math.sci.hokudai.ac.jp/archive/00001753/01/Tsutsumi2.pdf")[#text("Click to access Tsutsumi2.pdf")]

#text("Of course, UWP at scaling level for the L^2 critical NLS seems totally out of reach by these methods.")#linebreak()#text(" On the other hand, I am not aware of anything related to weak-strong uniqueness in the context of NLS, whereas for Navier-Stokes there is quite a litterature on it (see a CRAS note by Lions-Masmoudi for a short and elegant proof); so I quite like the result in that spirit in the radial case !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/07/19/global-existence-and-uniqueness-results-for-weak-solutions-of-the-focusing-mass-critical-non-linear-schrodinger-equation/#comment-31387")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2008")])]

#text("Dear Fabrice,")

#text("Thanks for the comments and references! I had wondered what the precise analogue of the Navier-Stokes weak-strong uniqueness results for NLS would be, but I am not sure exactly what they should be, given that uniqueness for weak solutions to NLS can break down even for zero initial data. But what the radial case seems to show is that as long as one somehow excludes a significant amount of mass from being spontaneously created or destroyed, then one has uniqueness of weak solutions (in particular, one has uniqueness when the mass is uniformly small).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabrice Planchon")]], [#link("https://terrytao.wordpress.com/2008/07/19/global-existence-and-uniqueness-results-for-weak-solutions-of-the-focusing-mass-critical-non-linear-schrodinger-equation/#comment-31413")[#strong[#text("Fabrice Planchon")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2008")])]

#text("Hey,")

#text("It will look like I am trying to lenghten your references ;-), but I recalled 2 other things which I should mention to be fair: one is again on unconditional uniqueness, a CRAS note by Keith Rogers (probably overlaps Tsutsumi, but the interesting point is that he is using off-diagonal inhomogeneous estimates to get something). The other is actually a weak-strong uniquess result by Michael Struwe (in the supercritical setting and considering smooth solutions as the strong ones). Somehow one has to add some entropy condition on the weak solution, and reversibility suggests mass conservation, I guess…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/07/19/global-existence-and-uniqueness-results-for-weak-solutions-of-the-focusing-mass-critical-non-linear-schrodinger-equation/#comment-31671")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2008")])]

#text("Dear Fabrice: Thanks again for the references!")

#text("In the high-dimensional radial case, one can recover uniqueness of weak solutions as long as one imposes a monotonicity condition on the mass; this follows from one of the results in my paper. I suspect this to be true in the non-radial case, but this will need a lot more analysis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/297ba35fceba57126d9613193c7cd9b835407adfe13d536390a27ced310e32e2-a380eea33e7db527042e9dcd6848d8e1ec0adf2e9b8d886dab8b90081140dfe3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2008/07/19/global-existence-and-uniqueness-results-for-weak-solutions-of-the-focusing-mass-critical-non-linear-schrodinger-equation/#comment-31676")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2008")])]

#text("I’m not an analyst, so this might be a dumb question, but I’ll ask it anyway. It seems like in several of your posts, a result that assumes radial symmetry is easier than the same result without the assumption of symmetry. I guess it seems obvious that symmetry in general makes things easier, but is there some more specific or informative reason this happens with some of the results you’ve discussed? Also, radial symmetry seems to be more useful than other types of symmetry, is there a reason for this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/07/19/global-existence-and-uniqueness-results-for-weak-solutions-of-the-focusing-mass-critical-non-linear-schrodinger-equation/#comment-31692")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2008")])]

#text("Dear Peter,")

#text("There are several advantages to assuming spherical symmetry. One is that many equations preserve spherical symmetry: spherically symmetric initial data leads to spherically symmetric solutions. (This is ultimately due to the fact that many equations enjoy a rotation invariance symmetry, as well as uniqueness for the initial value problem.) Another is that spherically symmetric states must necessarily have zero total momentum, and centre of mass at the origin; this tends to rule out many examples of singularity formation in which the position or momentum of the solution (or of key components of the solution) escape to infinity. (There is still the problem that the wavelength of the solution could concentrate to zero in finite time.) Related to this, spherically symmetric waves with bounded energy (or bounds on other energy-like quantities) tend to decay spatially away from the spatial origin, because in order for a spherically symmetric wave to have large amplitude at a point far away from the origin, it must in fact be large on the entire sphere that contains that point, which requires a large amount of energy.")

#text("Somewhat paradoxically, one advantage of imposing spherical symmetry on the solution is that it ")#emph[#text("destroys")]#text(" some other symmetries that might otherwise be present in the equation, notably translation symmetry and Galilean or Lorentz invariance. The point is that symmetric problems often require symmetric proofs; for instance, solving a translation-invariant PDE in a translation-invariant class of initial data is likely to require translation-invariant techniques. Breaking such a symmetry removes this requirement and (in principle) allows a much larger range of techniques to be brought to bear on the problem (e.g. weighted estimates, which are generally not translation-invariant).")

#text("Another key advantage is that spherical symmetry allows for a dimensional reduction: if one expresses physical space in polar coordinates, the angular variable tends to behave trivially for spherically symmetric solutions (pretty much by definition) and so one can often transform a PDE in many spatial dimensions to a PDE in just one spatial dimension, which is often much simpler for a variety of reasons. (For instance, wave equations in one spatial dimension have extremely simple solutions compared to those in higher dimensions.)")

#text("From a more technical viewpoint, many estimates in harmonic analysis become easier to prove and/or stronger when assuming spherical symmetry; for instance, the Sobolev embedding theorem admits some very useful weighted generalisations in the spherically symmetric case.")

#text("It is really quite fortunate in nonlinear wave equations that we have the spherically symmetric model to play with as a test case; there are quite a few examples of major problems that looked hopeless to solve directly, until someone first tackled the much simpler spherically symmetric case, thus giving both a psychological boost to solving the original problem, as well as providing valuable clues and insight as to how to proceed (or perhaps more importantly, how ")#emph[#text("not")]#text(" to proceed) in general.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fcbc3a9888272b385a675ccd3f8f4b6a147b894566dc78790687d64bdafe71ce-591a675dd8f7ab17a245aa9298e048b828bbc6675d4bc0bc194fa0abe735dfcf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim Candy")]], [#link("https://terrytao.wordpress.com/2008/07/19/global-existence-and-uniqueness-results-for-weak-solutions-of-the-focusing-mass-critical-non-linear-schrodinger-equation/#comment-36120")[#strong[#text("Tim Candy")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2009")])]

#text("Dear Prof. Tao")

#text("I was reading through your paper “Global existence and uniqueness results for weak solutions of the focusing mass-critical non-linear Schrödinger equation” and found the definition of a semi-Strichartz solution a little strange. I think perhaps you mean ")#mi("t")#text(" instead of ")#mi("t_0")#text(" in the last line of the following on page 6,")

#text("“…A semi-strong solution (resp. semi-Strichartz class solution) is a weak solution ")#mi("u")#text(" such that for every $\\latex t \\in I \\cap [t_0,+∞) $ there exists ")#mi("\\epsilon > 0")#text(" such that ")#mi("u")#text(" is a strong solution (resp. Strichartz class solution) when restricted to ")#mi("I \\cap [t_0, t_0+ \\epsilon)")#text(", and for…”")

#text("Since if we consider the solution (2) above then it satisfies this definition (picking ")#mi("t_0 >0")#text(") if we either extend it to zero for ")#mi("t<0")#text(", or use (2) again in this region. Hence we dont have uniqueness.")

#text("Tim")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/07/19/global-existence-and-uniqueness-results-for-weak-solutions-of-the-focusing-mass-critical-non-linear-schrodinger-equation/#comment-36123")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2009")])]

#text("Dear Tim: Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/923a0970bd6eabc4ade1663e26bfdd52b128322ef1e48b28252d015fa70b07fe-5e4d9c4d5e6c99ab6b043987062f58ce740137c3081af1d82f2a6d03c1c72bc9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yunrui")]], [#link("https://terrytao.wordpress.com/2008/07/19/global-existence-and-uniqueness-results-for-weak-solutions-of-the-focusing-mass-critical-non-linear-schrodinger-equation/#comment-673305")[#strong[#text("Yunrui")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2023")])]

#text("In the proof of Thm1.18, it seems that Prop 1.11 is not used.")

#emph[#text("[This is correct – T.]")]
]
