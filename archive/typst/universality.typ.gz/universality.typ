// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/01/29/universality/
// Converted to Typst by tao2typ: "2026-10-14T15:17:59.760233+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Universality", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Universality")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 January 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/01/29/universality/")[#text("https://terrytao.wordpress.com/2011/01/29/universality/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Last week I gave a ")#link("http://www.srcf.ucam.org/tms/archive.php")[#text("talk at the Trinity Mathematical Society")]#text(" at ")#link("http://www.trin.cam.ac.uk/")[#text("Trinity College")]#text(", ")#link("http://en.wikipedia.org/wiki/Trinity_College,_Cambridge")[#text("Cambridge")]#text(" UK. As the audience was primarily undergraduate, I gave a fairly non-technical talk on the universality phenomenon, based on ")#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/")[#text("this blog article of mine on the same topic")]#text(". It was a quite light and informal affair, and this is reflected in the ")#link("https://terrytao.wordpress.com/wp-content/uploads/2011/01/universality.pdf")[#text("talk slides")]#text(" (which, in particular, play up quite strongly the role of former students and Fellows of Trinity College in this story). There was some interest in making these slides available publicly, so I have placed them on this site ")#link("https://terrytao.wordpress.com/wp-content/uploads/2011/01/universality.pdf")[#text("here")]#text(". (Note: copyright for the images in these slides has not been secured.)")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb5c087673d10b538d76ca770e47c611b4718285d0cc72f990b5ce91971516bc-db1a130088c560172cf7f49435aeea139071fff178b54e3a911a0fa5c9012a93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leo")]], [#link("https://terrytao.wordpress.com/2011/01/29/universality/#comment-49927")[#strong[#text("Leo")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2011")])]

#text("Thank you for the talk it was really interesting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b65250bb5838c66ca74ae006e465d2c97993d53ae65a1872331c95224125dbc-f63b062d12effd708db263692f4c9be00d3d9dc57248c9b85c47ece75e841b1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of science and math")]], [#link("https://terrytao.wordpress.com/2011/01/29/universality/#comment-49949")[#strong[#text("science and math")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2011")])]

#text("Nice.")#linebreak()#text(" If you the talk video is available online then please also share the link.")#linebreak()#text(" The slide is also very informative.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2011/01/29/universality/#comment-49964")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2011")])]

#text("Prof. Tai’s lecture on ")#emph[#text("“universality”")]#text(" was wonderfully enjoyable, and it made me (a one person) long for a similar lecture on ")#emph[#text("“naturality”")]#text(".")

#text("As a mathematical abstraction, the idea of “universality” first appears in AMS Mathematical Reviews in 1940, while the idea of “naturality” first appears somewhat later, in 1951.")

#text("In subsequent decades the usage of these two abstractions (and their derivatives) has grown dramatically, as the following lexical statistics show:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("(natural*,universal*) in AMS Review texts")#linebreak()#text(" 2001-2005: (16788, 05288) usages")#linebreak()#text(" 1996-2000: (14880, 04977)")#linebreak()#text(" 1991-1995: (12550, 04432)")#linebreak()#text(" 1986-1990: (10335, 03343)")#linebreak()#text(" 1981-1985: (08775, 03013)")#linebreak()#text(" 1976-1980: (07402, 02412)")#linebreak()#text(" 1971-1975: (05668, 02040)")#linebreak()#text(" 1966-1970: (03466, 01167)")#linebreak()#text(" 1961-1965: (02211, 00610)")#linebreak()#text(" 1956-1960: (01368, 00406)")#linebreak()#text(" 1951-1955: (00880, 00253)")#linebreak()#text(" 1946-1950: (00502, 00107)")#linebreak()#text(" 1941-1945: (00251, 00060)")
]

#text("Now that the Trinity Mathematical Society has sponsored a lecture on universality, perhaps their great rivals, the Adams’ Society of St. John’s College, might sponsor a complementary lecture on naturality?")

#text("Such a lecture could begin with the 1942 definition of ")#emph[#text("naturality")]#text(" proposed by Eilenberg and Mac Lane,")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Frequently in modern mathematics there occur phenomena of “naturality”: a “natural” isomorphism between two groups or between two complexes, a “natural” homeomorphism of two spaces and the like. We here propose a precise definition of the “naturality” of such correspondences, as a basis for an appropriate general theory.")
]

#text("The body of the lecture might seek to illuminate the role(s) of Mac Lane’s vision of universality and naturality in the 21st century:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Mathematical ideas do not live fully until they are presented clearly, and we never quite achieve that ultimate clarity.")
]

#text("To engineers, universality and naturality are two cardinal mathematical virtues that have a wonderful property: each gains greatly in value by the company of the other. Surely the same might be said, of the Trinity Mathematical Society and the Adams’ Mathematical Society of St. John’s! :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb51726bd063af172ba39a53eda3ddc9762c5f3aa7254c070cb5693753d9c202-9bc66e3e6f8fe1dcb9a04cd89f7ca969a85348ef706a29607a5231550fcfbb36.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of saurabh")]], [#link("https://terrytao.wordpress.com/2011/01/29/universality/#comment-49966")[#strong[#text("saurabh")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2011")])]

#text("Nice talk.")

#text("One minor bug: on Slide 13, for the central limit theorem, the denominator should sqrt(N) rather than N.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e12d2e3555fd4e97a33dee9fbc0ace9a3cb3480285d1cb2ff44d760dff20e52f-d963c5e633962d86cd1714718d482d9d025366f413d19e3037f8d5dbd8c338bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon")]], [#link("https://terrytao.wordpress.com/2011/01/29/universality/#comment-49994")[#strong[#text("Jon")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2011")])]

#text("I liked the talk, thanks for posting it. Terence, any chance of a post about Ono’s partition-counting breakthrough? I still don’t see how the “fractal” thing comes in that the news stories have been touting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3a47b6de658452ca5b464a62786f4ae70f780424c7a4f5f37c716ff83d23ebe-46930ffdf16758ff4c9f553ffe939be1d8fb8258626aad31cddf8809d57ff9dd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ibai")]], [#link("https://terrytao.wordpress.com/2011/01/29/universality/#comment-50057")[#strong[#text("Ibai")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2011")])]

#text("Dear Professor Tao,")

#text("Thank you for your slides. Would you be willing to extend this entry to include your ideas on the similarities between the microscopical and macroscopical physical scales, and relating these to the discussion on universality?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/01/29/universality/#comment-381255")[#strong[#text("What books to read to get smarter? | Key to study")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2014")]

#text("[…] This talk by Fields Medalist Terry Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/01/29/universality/#comment-391980")[#strong[#text("Complexity, ‘fog and moonlight’, prediction, and politics I | Dominic Cummings's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2014")]

#text("[…] (Platonism). For a non-specialist summary of many issues concerning maths and prediction, cf. a talk by Fields Medallist Terry Tao. Wigner answered Einstein in a famous paper, ‘The Unreasonable […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/01/29/universality/#comment-442953")[#strong[#text("Here Are 97 Books, Articles, And Movies That Will Make You Smarter | TAR News")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2014")]

#text("[…] This talk by Fields Medalist Terry Tao. […]")
]
