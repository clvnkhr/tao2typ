// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/
// Converted to Typst by tao2typ: "2026-10-14T08:53:47.862370+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Linear approximate groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Linear approximate groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 January 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/")[#text("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.u-psud.fr/~breuilla/indexgb.html")[#text("Emmanuel Breuillard")]#text(", ")#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(", and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" our announcement “")#link("http://arxiv.org/abs/1001.4570")[#text("Linear approximate groups")]#text("“, submitted to ")#link("http://www.math.psu.edu/era/")[#text("Electronic Research Announcements")]#text(".")

#text("The main result is a step towards the classification of ")#mi("{K}")#text("-approximate groups, in the specific setting of simple and semisimple Lie groups (with some partial results for more general Lie groups). For ")#mi("{K \\geq 1}")#text(", define a ")#emph[#mi("{K}")#text("-approximate group")]#text(" to be a finite subset ")#mi("{A}")#text(" of a group ")#mi("{G}")#text(" which is a symmetric neighbourhood of the origin (thus ")#mi("{1 \\in A}")#text(" and ")#mi("{A^{-1} := \\{a^{-1}: a \\in A \\}}")#text(" is equal to ")#mi("{A}")#text("), and such that the product set ")#mi("{A \\cdot A}")#text(" is covered by ")#mi("{K}")#text(" left-translates (or equivalently, ")#mi("{K}")#text(" right-translates) of ")#mi("{A}")#text(". For ")#mi("{K=1}")#text(", this is the same concept as a finite subgroup of ")#mi("{G}")#text(", but for larger values of ")#mi("{K}")#text(", one also gets some interesting objects which are close to, but not exactly groups, such as geometric progressions ")#mi("{\\{ g^n: -N \\leq n \\leq N \\}}")#text(" for some ")#mi("{g \\in G}")#text(" and ")#mi("{N \\geq 1}")#text(".")

#text("The expectation is that ")#mi("{K}")#text("-approximate groups are ")#mi("{C_K}")#text("-controlled by “structured” objects, such as actual groups and progressions, though the precise formulation of this has not yet been finalised. (We say that one finite set ")#mi("{A}")#text(" ")#emph[#mi("{K}")#text("-controls")]#text(" another ")#mi("{B}")#text(" if ")#mi("{A}")#text(" is at most ")#mi("{K}")#text(" times larger than ")#mi("{B}")#text(" in cardinality, and ")#mi("{B}")#text(" can be covered by at most ")#mi("{K}")#text(" left translates or right translates of ")#mi("{A}")#text(".) The task of stating and proving this statement is the ")#emph[#text("noncommutative Freiman theorem problem")]#text(", discussed in ")#link("https://terrytao.wordpress.com/2007/03/02/open-question-noncommutative-freiman-theorem/")[#text("these")]#text(" ")#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/")[#text("earlier")]#text(" ")#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/")[#text("blog")]#text(" ")#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/")[#text("posts")]#text(".")

#text("While this problem remains unsolved for general groups, significant progress has been made in special groups, notably abelian, nilpotent, and solvable groups. Furthermore, the work ")#link("http://www.ams.org/mathscinet-getitem?mr=2398145")[#text("of Chang")]#text(" (over ")#mi("{{\\mathbb C}}")#text(") ")#link("http://arxiv.org/abs/math/0509024")[#text("and")]#text(" ")#link("http://arxiv.org/abs/0807.2027")[#text("Helfgott")]#text(" (over ")#mi("{{\\Bbb F}_p}")#text(") has established the important special cases of the special linear groups ")#mi("{SL_2(k)}")#text(" and ")#mi("{SL_3(k)}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Helfgott’s theorem)")]#text(" Let ")#mi("{d = 2,3}")#text(" and let ")#mi("{k}")#text(" be either ")#mi("{{\\Bbb F}_p}")#text(" or ")#mi("{{\\mathbb C}}")#text(" for some prime ")#mi("{p}")#text(". Let ")#mi("{A}")#text(" be a ")#mi("{K}")#text("-approximate subgroup of ")#mi("{G = SL_d(k)}")#text(".")

#list(
[#text("If ")#mi("{A}")#text(" generates the entire group ")#mi("{SL_d(k)}")#text(" (which is only possible in the finite case ")#mi("{k={\\Bbb F}_p}")#text("), then ")#mi("{A}")#text(" is either controlled by the trivial group or the whole group.")],
[#text("If ")#mi("{d=2}")#text(", then ")#mi("{A}")#text(" is ")#mi("{K^{O(1)}}")#text("-controlled by a ")#emph[#text("solvable")]#text(" ")#mi("{K^{O(1)}}")#text("-approximate subgroup ")#mi("{B}")#text(" of ")#mi("{G}")#text(", or by ")#mi("{G}")#text(" itself. If ")#mi("{k={\\mathbb C}}")#text(", the latter possibility cannot occur, and ")#mi("{B}")#text(" must be ")#emph[#text("abelian")]#text(".")]
)
]

#text("Our main result is an extension of Helfgott’s theorem to ")#mi("{SL_d(k)}")#text(" for general ")#mi("{d}")#text(". In fact, we obtain an analogous result for any simple (or almost simple) ")#link("http://en.wikipedia.org/wiki/Group_of_Lie_type#Chevalley_groups")[#text("Chevalley group")]#text(" over an arbitrary finite field (not necessarily of prime order), or over ")#mi("{{\\mathbb C}}")#text(". (Standard embedding arguments then allow us to in fact handle arbitrary fields.) The results from simple groups can also be extended to (almost) semisimple Lie groups by an approximate version of ")#link("http://en.wikipedia.org/wiki/Goursat's_lemma")[#text("Goursat’s lemma")]#text(". Given that general Lie groups are known to split as extensions of (almost) semisimple Lie groups by solvable Lie groups, and Freiman-type theorems are known for solvable groups also, this in principle gives a Freiman-type theorem for arbitrary Lie groups; we have already established this in the characteristic zero case ")#mi("{k={\\mathbb C}}")#text(", but there are some technical issues in the finite characteristic case ")#mi("{k = {\\Bbb F}_q}")#text(" that we are currently in the process of resolving.")

#text("We remark that a qualitative version of this result (with the polynomial bounds ")#mi("{K^{O(1)}}")#text(" replaced by an ineffective bound ")#mi("{O_K(1)}")#text(") was also recently obtained ")#link("http://arxiv.org/abs/0909.2190")[#text("by Hrushovski")]#text(".")

#text("Our arguments are based in part on Helfgott’s arguments, in particular maximal tori play a major role in our arguments for much the same reason they do in Helfgott’s arguments. Our main new ingredient is a surprisingly simple argument, which we call the ")#emph[#text("pivot argument")]#text(", which is an analogue of a corresponding argument of Konyagin and Bourgain-Glibichuk-Konyagin that was used to prove a sum-product estimate. Indeed, it seems that Helfgott-type results in these groups can be viewed as a manifestation of a ")#emph[#text("product-conjugation phenomenon")]#text(" analogous to the ")#emph[#text("sum-product phenomenon")]#text(". Namely, the sum-product phenomenon asserts that it is difficult for a subset of a field to be simultaneously approximately closed under sums and products, without being close to an actual field; similarly, the product-conjugation phenomenon asserts that it is difficult for a union of (subsets of) tori to be simultaneously approximately closed under products and conjugations, unless it is coming from a genuine group. In both cases, the key is to exploit a sizeable gap between the behaviour of two types of “pivots” (which are scaling parameters ")#mi("{\\xi}")#text(" in the sum-product case, and tori in the product-conjugation case): ones which interact strongly with the underlying set ")#mi("{A}")#text(", and ones which do not interact at all. The point is that there is no middle ground of pivots which only interact weakly with the set. This separation between interacting (or “involved”) and non-interacting (or “non-involved”) pivots can then be exploited to bootstrap approximate algebraic structure into exact algebraic structure. (Curiously, a similar argument is used all the time in PDE, where it goes under the name of the “bootstrap argument”.)")

#text("Below the fold we give more details of this crucial pivot argument.")

#text("One piece of trivia about the writing of this paper: this was the first time any of us had used ")#strike[#text("modern")]#text(" version control software to collaboratively write a paper; specifically, we used ")#link("http://en.wikipedia.org/wiki/Subversion_(software)")[#text("Subversion")]#text(", with the repository being hosted online by ")#link("http://www.xp-dev.com/")[#text("xp-dev")]#text(". (See ")#link("http://sbseminar.wordpress.com/2008/06/18/subverting-the-system/")[#text("this post at the Secret Blogging Seminar")]#text(" for how to get started with this software.) There were a certain number of technical glitches in getting everything to install and run smoothly, but once it was set up, it was significantly easier to use than our traditional system of emailing draft versions of the paper back and forth, as one could simply download and upload the most recent versions whenever one wished, with all changes merged successfully. I had a positive impression of this software and am likely to try it again in future collaborations, particularly those involving at least three people. (It would also work well for polymath projects, modulo the technical barrier of every participant having to install some software.)")

#metadata(none) <tao-142a449ac7f12279a07d>

#heading(level: 1)[#strong[#text(" — 1. The pivot argument — ")]]

#text("For simplicity let us work in ")#mi("{SL_2(k)}")#text(", which is slightly simpler because all semisimple (which, in this linear context, simply means diagonalisable) elements other than ")#mi("{\\pm 1}")#text(" are ")#emph[#text("regular")]#text(", which in the case of linear groups just means that the eigenvalues are distinct. Every regular element ")#mi("{a}")#text(" of the three-dimensional ")#mi("{SL_2(k)}")#text(" then generates a one-dimensional ")#emph[#text("maximal torus")]#text(" ")#mi("{Z(a)}")#text(", which is also the centraliser of ")#mi("{a}")#text(" (the set of all matrices in ")#mi("{SL_2(k)}")#text(" that commute with ")#mi("{a}")#text(").")

#text("Let ")#mi("{A}")#text(" be a ")#mi("{K}")#text("-approximate group that generates ")#mi("{SL_2(k)}")#text(", where we think of ")#mi("{K}")#text(" as being small, say ")#mi("{K=O(1)}")#text(" to simplify the discussion (of course, in the full argument we will need to track the dependence on ")#mi("{K}")#text(" and keep it polynomial in nature). We may assume that ")#mi("{A}")#text(" is not too small (more precisely, ")#tao-math("{\\left|A\\right| \\geq CK^C}", block: false)#text(" for some large ")#mi("{C}")#text("). As ")#mi("{A}")#text(" lives in the three-dimensional group ")#mi("{SL_2(k)}")#text(", it is reasonable to expect that the intersection of ")#mi("{A}")#text(" with a one-dimensional subset, such as a maximal torus, would be of size about ")#tao-math("{\\left|A\\right|^{1/3}}", block: false)#text(". And indeed this is true, as was observed by Helfgott:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Intersection with torus)")]#text(" ")#metadata(none) <tao-c84c8016356014e02b04>#text(" If a maximal torus ")#mi("{T}")#text(" intersects ")#mi("{A^2}")#text(" (say) outside of ")#mi("{\\{-1,+1\\}}")#text(", then ")#mi("{A^{20} \\cap T}")#text(" (say) has cardinality ")#tao-math("{\\sim \\left|A\\right|^{1/3}}", block: false)#text(".")
]

#text("For more general Lie groups, one can establish a similar upper bound (for more general algebraic varieties than just a torus) by using the ")#emph[#text("Larsen-Pink inequality")]#text(", which I discussed in ")#link("https://terrytao.wordpress.com/2009/12/06/non-commutative-freiman-theorems-and-model-theory/")[#text("this previous blog post")]#text(". The lower bound is more important to us; it comes from noting that the conjugacy class ")#mi("{\\{ gag^{-1}: g \\in A^{20} \\}}")#text(" lies in ")#mi("{A^{41}}")#text(" and also in a two-dimensional subset ")#mi("{C(a)}")#text(" of ")#mi("{SL_2(k)}")#text(", and so should have cardinality ")#tao-math("{O(\\left|A\\right|^{2/3})}", block: false)#text(".")

#text("This lemma gives an important ")#emph[#text("gap property")]#text(": as soon as a maximal torus encounters just one regular element of ")#mi("{A^2}")#text(", it in fact has to absorb quite a lot of elements of the slightly larger set ")#mi("{A^{20}}")#text(". It is this gap which we exploit as follows. Let us say that a maximal torus ")#mi("{T}")#text(" is ")#emph[#text("involved")]#text(" if it intersects ")#mi("{A^2}")#text(" outside of ")#mi("{\\{-1,+1\\}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Pivot rotation lemma)")]#text(" ")#metadata(none) <tao-d6386c59a6bcfcb1e4ce>#text(" If ")#mi("{T}")#text(" is an involved torus, then ")#mi("{aTa^{-1}}")#text(" is also an involved torus for any ")#mi("{a \\in A}")#text(".")
]

#emph[#text("Proof:")]#text(" (Sketch) We conjugate ")#mi("{aTa^{-1}}")#text(" by a further element ")#mi("{b \\in A}")#text(", and then multiply it on the left to get a new torus ")#mi("{cbaTa^{-1}b^{-1}}")#text(", where ")#mi("{a, b \\in A}")#text(". On the one hand, we can think of this torus as of the form ")#mi("{xTy}")#text(", where ")#mi("{x \\in A^3/T}")#text(" and ")#mi("{y \\in T \\backslash A^2}")#text(". From Lemma ")#link(<tao-c84c8016356014e02b04>)[#text("2")]#text(" we see that there are only ")#tao-math("{O(\\left|A\\right|^{2/3})}", block: false)#text(" values of ")#mi("{x}")#text(" and ")#mi("{y}")#text(", and so there are ")#tao-math("{O(\\left|A\\right|^{4/3})}", block: false)#text(" tori here. On the other hand, there are ")#tao-math("{\\left|A\\right|^2}", block: false)#text(" choices of ")#mi("{b}")#text(" and ")#mi("{c}")#text(". Hence there must be lots of collisions of the form")

#align(center)[#tao-fit-display[#mitex("cbaTa^{-1}b^{-1} = c^{\\prime} b^{\\prime} aTa^{-1} (b^{\\prime})^{-1}.")]]

#text("Taking quotients, we see that")

#align(center)[#tao-fit-display[#mitex("baTa^{-1}b^{-1} = b^{\\prime} aTa^{-1} (b^{\\prime})^{-1}")]]

#text("and thus ")#mi("{b^{\\prime} b^{-1}}")#text(" lies in the ")#emph[#text("normaliser")]#text(" ")#mi("{N(aTa^{-1})}")#text(" of ")#mi("{aTa^{-1}}")#text(". But this is only twice as large as ")#mi("{aTa^{-1}}")#text(" (the quotient of ")#mi("{N(aTa^{-1})}")#text(" by ")#mi("{aTa^{-1}}")#text(" is the ")#emph[#text("Weyl group")]#text(" of ")#mi("{SL_2}")#text(", which in this two-dimensional case has cardinality ")#mi("{2!}")#text(".) But because there are so many collisions, it is not hard to use a pigeonhole argument to find a non-trivial pair ")#mi("{b,b^{\\prime}}")#text(" where ")#mi("{b^{\\prime} b^{-1}}")#text(" lies in the torus ")#mi("{aTa^{-1}}")#text(" itself, and is not equal to ")#mi("{\\pm 1}")#text(". This makes ")#mi("{aTa^{-1}}")#text(" an involved torus as required. ")#mi("\\Box")

#text("Now suppose that ")#mi("{A}")#text(" generates all of ")#mi("{SL_2(k)}")#text(", then the set of involved tori is then invariant under conjugation by arbitrary elements of ")#mi("{SL_2(k)}")#text(". But all maximal tori in ")#mi("{SL_2}")#text(" are conjugate to each other, and it is not hard to show that any large ")#mi("{A}")#text(" must intersect at least one maximal torus non-trivially (using something called an ")#emph[#text("escape from subvarieties")]#text(" argument), and so every maximal torus is an involved torus. But then there are ")#tao-math("{\\sim \\left|SL_2(k)\\right|^{2/3}}", block: false)#text(" such tori; this is only consistent with Lemma ")#link(<tao-c84c8016356014e02b04>)[#text("2")]#text(" if ")#tao-math("{\\left|A\\right| \\sim \\left|SL_2(k)\\right|}", block: false)#text(", at which point one is done. A slightly more sophisticated version of this argument also works when ")#mi("{A}")#text(" does not generate all of ")#mi("{SL_2(k)}")#text(".")

#text("It is instructive to compare the above argument to the analogous sum-product argument. Let ")#mi("{A}")#text(" be an approximate subring of a field ")#mi("{F}")#text(" (let us not define this concept precisely here). We say that a non-zero field element ")#mi("{\\xi}")#text(" is ")#emph[#text("involved")]#text(" with ")#mi("{A}")#text(" if the set of sums ")#mi("{\\{ a+\\xi b: a, b \\in A \\}}")#text(" are not distinct, i.e. ")#tao-math("{\\left|A + \\xi A\\right| < \\left|A\\right|^2}", block: false)#text(". The analogue of Lemma ")#link(<tao-c84c8016356014e02b04>)[#text("2")]#text(" here is that if ")#mi("{\\xi}")#text(" is involved, then in fact ")#mi("{\\xi}")#text(" must lie in the ")#emph[#text("quotient set")]#text(" ")#mi("{Q := (A-A) / ((A-A) \\backslash \\{0\\})}")#text(" of ")#mi("{A}")#text(", just by using a collision ")#mi("{a+\\xi b = c + \\xi d}")#text(" to solving for ")#mi("{\\xi}")#text(". The analogue of Lemma ")#link(<tao-d6386c59a6bcfcb1e4ce>)[#text("3")]#text(" is then the observation that if ")#mi("{\\xi}")#text(" and ")#mi("{\\eta}")#text(" lie in ")#mi("{Q}")#text(", then ")#mi("{\\xi+\\eta}")#text(" and ")#mi("{\\xi \\cdot \\eta}")#text(" are still sufficiently involved with ")#mi("{A}")#text(" that one can bound ")#tao-math("{\\left|A + (\\xi+\\eta) A\\right|}", block: false)#text(" or ")#tao-math("{\\left|A + \\xi \\eta A\\right|}", block: false)#text(" to be strictly smaller than ")#tao-math("{\\left|A\\right|^2}", block: false)#text(", so that the sum and product of any two involved elements is again involved; this can be deduced from the so-called ")#emph[#text("Katz-Tao lemma")]#text(", which roughly asserts that if a set ")#mi("{A}")#text(" is approximately closed under sums and products, then it (or a large portion thereof) is closed under more complicated polynomial and rational operations as well.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/#comment-43378")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2010")])]

#text("Terry,")

#text("I don’t think you’ve quoted Helfgott’s theorem quite correctly in the case d = 3. For example, A could be controlled by a copy of SL_2(F_p). Even over C, there are 2-step nilpotent, nonabelian, examples in SL_3.")

#text("Best")#linebreak()#text(" Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/#comment-43379")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2010")])]

#text("Terry,")

#text("Another comment: I think we *do* get the full Freiman theorem for Lie groups (over R, or over C) but not at this stage for groups of Lie type (such as SL_d(F_p)).")

#text("Ben")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/#comment-43385")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2010")])]

#text("Oops, right. Thanks for the corrections!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c8d284dd2ddbb40626c126309bc8e8f09a743a2912dbd9b7b72bfd1a29c8e63-fb26f3846087993e4a4209154a6ee4d8b3e21164c0e309de7f1e307e01f6612f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Morrison")]], [#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/#comment-43386")[#strong[#text("Scott Morrison")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2010")])]

#text("Regarding subversion: congratulations on making the jump. I really think this is a good piece of technology for mathematicians.")

#text("These days, however, subversion isn’t really considered “modern version control”. The newer generation (mercurial, git, bzr) allowed “distributed version control”, and in particular let you commit changes even while offline. This at first sounds silly — after all your collaborators can’t see those changes until you get online. The nice thing is that it encourages “granular” commits, and in particular I find I write better “commit messages” (clues to others as to what changes you’re making) when I commit early and often. It also ends up being easier to set up a distributed system, as you never have to lock in to a particular hosting setup. If mathematicians want help setting up mercurial for a paper or collaboration, I’m happy to help — email me or follow the link to the secret blogging seminar post above.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9433218afd2a296d68e0a0ddcdca747fbff8a9486aeb84a5385620ce1bed8aaa-0d07f89db3f93ee85a8ef57476bf078eaac9b6956ea72a7e1c233e98a422219a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Laci Pyber")]], [#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/#comment-43387")[#strong[#text("Laci Pyber")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2010")])]

#text("Dear Terence Tao,")#linebreak()#text(" looking at arxiv:1001.4556 you will find another research announcement")#linebreak()#text(" “Growth in finite simple groups of Lie type” by Endre Szabó and myself.")#linebreak()#text(" As the title indicates the two research announcements have a very substantial overlap. It is a rather curious coincidence that these announcements appeared side by side on the arxiv.")#linebreak()#text(" Best")#linebreak()#text(" Laci Pyber")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/#comment-43388")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2010")])]

#text("Yes, this is quite a remarkable coincidence. I’ve seen simultaneous releases of closely related results before (and been involved in some of them personally), but this is the first time I know of that the announcements were released on the same day. (We’ve been announcing these results in talks and in discussion with colleagues over the past few weeks, though.)")

#text("It seems that both of our papers rely crucially on the same underlying pivot argument and on the Larsen-Pink type inequality (although the arguments are arranged a bit differently in the fine details). I suppose that in retrospect this is the “natural” way to proceed, especially given how easily these arguments establish the sum-product phenomenon (which used to be quite difficult from a psychological point of view, before the easy proofs were found).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/#comment-43392")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2010")])]

#text("Yes, I’ve already been informed privately by those more technologically up-to-date than I that a late 1990s era piece of software doesn’t count as “modern” nowadays, so I’m retracting that particular term :-)")

#text("For the current scale of projects (with 2-3 authors) it seems that the Subversion system works “well enough”, which is often a sufficient standard for these sorts of things. If one were to do a much larger-scale project, such as a polymath writeup, I could imagine that a distributed VCS offer further real advantages. In any case, either system is a definite advance over email-based methods.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/#comment-43393")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2010")])]

#text("Terry, a further point: I think you’re using the word “pivot” in a somewhat opposite sense to the way it used in, for example, Helfgott’s paper on SL_3. The world “involved” as used in our announcement seems more descriptive.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/#comment-43394")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2010")])]

#text("Ah, good point. (I was wondering where that term came from, actually.) I’ve reworded the argument accordingly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fac1eeb1dd8f9455228833f962802a575b4ef16d9cb91303ec5db915305f23ad-c546abf6e77cccbfaec3e5e60470ea1b73ad37d1d53351642ae76a65c77d98c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Link Starbureiy")]], [#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/#comment-43399")[#strong[#text("Link Starbureiy")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2010")])]

#text("Terry-")

#text("An even better alternative might be to use Google Code Project Hosting (code.google.com/p). It also utilizes subversion/mercurial. Depending on how large the commit group is, it can be pretty generous (and versatile) for storage. I’ve been using it for my own projects for about a year now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/#comment-43401")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2010")])]

#text("A few words on “pivots” and the like.")

#text("It seems to me that the proof you have sketched for Lemma 3 is a little more complicated than it needs to be. In particular, the use of double-sided cosets aTb is unnecessary, as is the use of the Weyl group. Emmanuel was talking to me about this; if I understood him correctly, he proceeded guided by his reading of Proposition 3.1 in my SL_3 paper (where I used the term “pivot”). The idea there was to get an element xi (the “pivot”) of a group G (acted on by another group \\Upsilon) such that the map (g,y)\\mapsto g\\cdot y(xi) would be injective when restricted to a set A\\times Y \\subset G\\times \\Upsilon. One could obtain this pivot as follows: if there is no pivot, then A and Y are very large and the argument is easy; if there is a pivot, there has to be in some sense a last “non-pivot”, which is one step away from being a pivot under the action of A or Y; this non-pivot is shown to be in some sense constructible (or “involved”, to use your term) and thus one can construct a pivot using one more step. (As I wrote back then and as you state above, this argument can be seen as an abstraction of an argument of Konyagin and Glibichuk in the sum-product setting; what I had in SL_3 was simply the first such statement in the setting of groups.) It is clear then why Emmanuel wanted a map (g,g’)\\mapsto gTg’.")

#text("In fact, this is unnecessary in this setting; one can work entirely with left cosets a T. Here’s a simpler complete proof of your Lemma 3 (which works for every simple group, just like the proof in your paper will work for every simple group).")

#text("Proof.- Suppose T’=g T g^(-1) is not involved. Look at the map phi:G\\mapsto G/T’ given by g\\mapsto g T’. If g and g’ map to the same element, then g^(-1) g’ lies in T’; since T’ is not involved, it must be a non-regular element of T’. Since there are at most <>|A|^{1-(dim(T)-1)/dim(G))}. Pick a set R\\subset A of representatives of every preimage phi^{-1}(x), x\\in phi(A).")#linebreak()#text(" Evidently, |R|=|phi(A)|>>|A|^{1-(dim(T)-1)/dim(G))}.")

#text("Now, because T is involved, there is a regular element x in A^(-1) A \\cap T(K). Hence g x g^(-1) in A A^{-1} A A^{-1} is regular, and so |A_8\\cap T(K)|>>|A|^(dim(T)/dim(G)). Now the map (g,t)->gt restricted to R\\times")#linebreak()#text(" (A_8\\times T(K)) will (a) be injective (and thus have image of size")#linebreak()#text(" >> |A|^{1+1/dim(G)}) and (b) have image contained in A_9. Hence |A_9|>>|A|^(1+1/dim(G)).")

#text("End of proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/#comment-43402")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2010")])]

#text("One other thing. My post-doc (Nick Gill) and I wrote a draft some time ago proving that a set A generating SL_n(F_p) grows, provided that |A| << p^(n+1-epsilon). I had talked on the subject already (e.g. at Luminy last November).We were planning to put a full paper out on the arxiv very soon; we will still do so. Hopefully the techniques used therein will prove useful elsewhere.")

#text("Congratulations for a beautiful result.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/#comment-43496")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2010")])]

#text("Right before Lemma 2, “would be of size about {|A|^3}.” should be")#linebreak()#text(" “would be of size about |A|^{1/3}”. Also, my congratulations were intended for both teams, obviously.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An arithmetic regularity lemma, an associated counting lemma, and applications « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/#comment-43607")[#strong[#text("An arithmetic regularity lemma, an associated counting lemma, and applications « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2010")])]

#text("[…] last “production note”. Like our previous paper with Emmanuel Breuillard, we used Subversion to write this paper, which turned out to be a significant efficiency boost as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Suzuki groups as expanders « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/#comment-44687")[#strong[#text("Suzuki groups as expanders « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2010")])]

#text("[…] by Pyber-Szábo and can also be obtained by the methods of proof of the results announced by ourselves. (These arguments are in turn based on an earlier result of Helfgott establishing the analogous […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Approximate subgroups of linear subgroups « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/#comment-44809")[#strong[#text("Approximate subgroups of linear subgroups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2010")])]

#text("[…] of linear groups“, submitted to GAFA. This paper contains (the first part) of the results announced previously by us; the second part of these results, concerning expander groups, will appear subsequently. The […]")
]
