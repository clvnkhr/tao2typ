// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/12/13/sciencedebate-2008/
// Converted to Typst by tao2typ: "2026-10-14T16:35:06.680943+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Sciencedebate 2008", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Sciencedebate 2008")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 December 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/12/13/sciencedebate-2008/")[#text("https://terrytao.wordpress.com/2007/12/13/sciencedebate-2008/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This post will have only the most tangential connection to mathematics.")

#text("I am an Australian citizen (and permanent resident in the US), but I nevertheless take an interest in the upcoming US presidential election in 2008. I’ve recently learned of a ")#link("http://www.sciencedebate2008.com/www/index.php")[#text("grassroots campaign to have one of the presidential debates focused on policy issues in science, technology, health, and the environment")]#text(". (See also this ")#link("http://www.latimes.com/news/opinion/la-oe-mooney12dec12,0,2945719.story")[#text("LA Times op-ed")]#text(" and ")#link("http://genesis1.phys.cwru.edu/~krauss/dec6opedwsj.html")[#text("Wall Street Journal op-ed")]#text(".) Personally, I think this is an excellent idea, and hope that it succeeds; it seems that they are currently petitioning signatures towards this goal.")

#text("While on this topic, it is also interesting to see ")#link("http://specials.slate.com/futures/2008/")[#text("what the political prediction markets are currently forecasting")]#text(" as the outcome of the election…")

#text("[Via ")#link("http://www.badastronomy.com/bablog/2007/12/12/more-on-the-science-debate/")[#text("Bad Astronomy")]#text(".]")

#text("[")#emph[#text("Update")]#text(", Dec 20: ")#link("http://www.popularmechanics.com/geekthevote08")[#text("Here is a table")]#text(" listing the major candidates and their positions on mostly science-related issues.]")

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/12/13/sciencedebate-2008/#comment-20362")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2007")])]

#text("Hi Terence,")

#link("http://www.biz.uiowa.edu/iem/")[#linebreak()#text(" “The Iowa Electronic Markets”")]#text(" … “are operated by faculty at the University of Iowa Tippie College of Business as part of our research and teaching mission.”")

#text("Note:")#linebreak()#text(" “Can I try out the IEM without investing money?")#linebreak()#text(" “YES. Login to the IEM and follow the directions on the screen to log into the practice market. You will be able to do everything a trader can do, except trade in our real-money contracts.?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5162cf9bfb600aae7b0dc75c9f8954e80ab40e82e0a8fce12c188ea5c394ffa1-a5f3ee3445e76a613b7f243e63de1aa8fa020a569c47d4983450280115329df4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michel")]], [#link("https://terrytao.wordpress.com/2007/12/13/sciencedebate-2008/#comment-20429")[#strong[#text("Michel")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2007")])]

#text("Dear Terence,")#linebreak()#text(" I have been looking for a suitable post to ask you a question on the future of mathematics and perhaps this is the right moment.")#linebreak()#text(" Richard Feynman once wrote that theoretical physics would stop developing one day brcause new models would require the production of so energetic particles to test those new theories that the world would not be rich enough to invest so much in physics.")#linebreak()#text(" Looking at mathematics and the time and effort taken to check the recent proofs of some theorems such as Fermat last theorem and lately the proof of the Poicaré conjecture,I sometimes wonder whether one day the mathematical community might not be able to decide on the validity of some proofs.This feeling is somewhat enhanced by the fact that today’s mathematicians are extremely specialized and sometimes less than 50 researchers can comment usefully. What do you think ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/12/13/sciencedebate-2008/#comment-20467")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2007")])]

#text("Dear Michel,")

#text("It is true that the initial proof of a major result is often rather complicated. But over time, the proof gets simplified, digested, strengthened, and boiled down to its core components; perhaps more importantly, the proof gets placed in context with other related results, ideas, principles, and theories. Also, if the result is important enough, one usually sees new and very different proofs of the same result emerge as well (in the areas that I work in, I have seen these things happen for instance with Carleson’s theorem on the almost everywhere convergence of Fourier series, or Szemeredi’s theorem on arithmetic progressions). So while a proof of a major result may be inaccessible to all but a few people initially, this is a problem that usually corrects itself over time, especially if the result continues to be of major interest.")

#text("Another encouraging trend is that many breakthroughs these days involve multiple fields of mathematics, sometimes creating new connections between them that are in some ways more interesting than the initial problem that was being worked on. (For instance, the work of Hamilton and Perelman have emphasised the close connection between geometric PDE and low-dimensional topology; the work of Frey, Ribet, and Wiles connects Fermat’s last theorem with elliptic curves and the Langlands programme; and so forth.) This tends to expand the number of people who can understand at least part of the breakthrough, and usually leads to a number of different ways of looking at the argument; in particular, one often sees multiple ways to perform each individual step of the argument, increasing confidence that the proof will not be destroyed if one of these ways turns out to have some unforeseen difficulty.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2440d6a669b266b1e0ded0cf262bd8572dc362e7aa000fb14c6782e94a6cbf7-545719ca34e8c1d255335ce8638b341f6cc5ba0edfe9ede6f49618c2d9c7de51.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Debate de temas científicos na política americana « problemas | teoremas")]], [#link("https://terrytao.wordpress.com/2007/12/13/sciencedebate-2008/#comment-20530")[#strong[#text("Debate de temas científicos na política americana « problemas | teoremas")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2007")])]

#text("[…] 15, 2007 in Geral, Política, USA Tags: Geral, Política, USA Através da entrada do blog “What´s new”, de Terence Tao tomei conhecimento da existência de um apelo para que haja debate público de temas ligados […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/12/13/sciencedebate-2008/#comment-20535")[#strong[#text("pt : Debate de temas científicos na política americana")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2007")]

#text("[…] da entrada do blog “What´s new”, de Terence Tao tomei conhecimento da existência de um apelo para que haja debate público de […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of problemasteoremas")]], [#link("https://terrytao.wordpress.com/2007/12/13/sciencedebate-2008/#comment-20582")[#strong[#text("problemasteoremas")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2007")])]

#text("Dear Prof. Tao,")#linebreak()#text(" My Portuguese text was placed here automatically when I linked my short words to your blog.")#linebreak()#text(" Pease delete it if you deem necessary.")#linebreak()#text(" Americo Tavares (from “problemasteoremas” and “pt”)")
]
