// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/
// Converted to Typst by tao2typ: "2026-10-14T08:50:15.564845+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "UCLA Math Seeks Exceptional Student for Undergraduate Merit Scholarship", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("UCLA Math Seeks Exceptional Student for Undergraduate Merit Scholarship")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 November 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/")[#text("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[A little bit of advertising on behalf of my maths dept. Unfortunately funding for this scholarship was secured only very recently, so the application deadline is extremely near, which is why I am publicising it here, in case someone here may know of a suitable applicant. – T.]")]

#text("UCLA Mathematics has launched a new scholarship to be granted to an entering freshman who has an exceptional background and promise in mathematics. The UCLA Math Undergraduate Merit Scholarship provides for full tuition, and a room and board allowance. To be considered for fall 2010, candidates must apply on or before November 30, 2009. Details and online application for the scholarship are ")#link("https://www.mathprograms.org/db/4/20")[#text("available here")]#text(".")

#heading(level: 2)[#text("Eligibility Requirements:")]

#list(
[#text("12th grader applying to UCLA for admission in Fall of 2010.")],
[#text("Outstanding academic record and standardized test scores.")],
[#text("Evidence of exceptional background and promise in mathematics, such as: placing in the top 25% in the U.S.A. Mathematics Olympiad (USAMO) or comparable (International Mathematics Olympiad level) performance on a similar national competition.")],
[#text("Strong preference will be given to International Mathematics Olympiad medalists.")]
)

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (32)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42429")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2009")])]

#text("I question the use of success in competition maths as a predictor for success in professional mathematics based on the near zero empirical correlation between the two (with a couple of huge exceptions of course).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42433")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2009")])]

#text("> based on the near zero empirical correlation between the two (with a couple of huge exceptions of course).")

#text("You’re joking, right? While of course many IMO/Putnam winners end up not achieving anything in math, and many of those achieving important results in math never won these competitions, the idea that a success there is not a valuable signal is ridiculous.")

#text("Just count how many of Hilbert’s problems were solved by IMO/Putnam winners.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of presently anon")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42452")[#strong[#text("presently anon")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2009")])]

#text("Just for laughs, how about some actual, controlled, statistically valid evidence that demonstrates that competition performance is correlated with professional achievement? As in, evidence that is independent of the fact that so many people in decision-making positions already believe that competition performance is a good predictor and hence give much better opportunities to those that do well in competitions?")

#text("My personal suspicion: Competition performance is much better correlated with early opportunity–who your parents are and where you were lucky enough to go to school–than it is with long-term evidence of mathematical talent. So it’s classist, and it’s sexist as well because girls are much less likely to enjoy the kind of pointless competitiveness the competitions foster.")

#text("UCLA (and everyone else) should scrap that criterion. Competitions shouldn’t be considered as anything other than “fun,” and hence indicative only of interest and access to opportunity, until it’s been proven otherwise.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11d99a9c9b768acd04f9dd2e9d00d1c3f732470e8baccbc0682c9801874827b7-827cb0909be45b7a5d91c98024e2ef69e1e62af3fa2aab81b020b189956bc67d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walter")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42455")[#strong[#text("Walter")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2009")])]

#text("The especially uninspiring thing to me is how many of the top IMO performers have one or both parents as mathematicians or math teachers in some form. Not exactly a wide pool of the general population.")

#text("But really quite a few of them do become good mathematicians, at least the ones from countries with well-developed math graduate education etc. I think math is just a specialized area where long and specialized training starting really young helps a lot. Math contests are just one way of getting there. It may not foster the best attitude when they “grow up” but if you look at Perelman, Tao, etc it seems to be quite effective in helping create top-notch mathematicians.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42454")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2009")])]

#text("China has incredible IMO prowess. They can probably field an IMO team from each province and would still come out on top. So far there is simply no evidence that this horde of extremely skilled Chinese IMO’ers have much success in professional mathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b80186b23ecd7183baf3997fea0be9728242b29992242075d680bd57d5ecaf5e-c01d0095c1e1fd68ce186085beae7f7aa8012003d8a49df53762ddeb97b4ffff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phi. Isett")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42474")[#strong[#text("Phi. Isett")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2009")])]

#text("I don’t think there is any debating that the Chinese are capable of producing some good, professional mathematicians without their going to a different country for a graduate education. I also don’t know to what degree the trend described by the poster above is accurate. But, those same people who win the IMO… There are reasons to believe that other factors (e.g. rampant corruption) would contribute to them not scaling to the top of mathematics ultimately. See, for example:")

#link("http://english.people.com.cn/200508/18/eng20050818_203206.html")[#text("http://english.people.com.cn/200508/18/eng20050818_203206.html")]

#text("I think (based on no statistical evidence) that presently Anon has a good point that a certain amount of luck is required for competition success (or even participation). But what other statistics are available, really, for UCLA to use? AP exam and SAT II exam scores don’t reveal anything serious (at least the way AP scores are reported out of 5 — a perfect AP score might mean something). No matter which factors one considers, the same “luck” issues arise to consider that statistic. It is very difficult to get rid of the luck factor, and luck may mean you were lucky enough to be encouraged work much harder than other people (like if your parents are math teachers, this would probably happen). In the end, it seems to me that scholarships inevitably go to lucky people who work hard, and when people are aware of them and what it takes to get them, they encourage a certain kind of behavior among students which may be desirable.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of null")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42485")[#strong[#text("null")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2009")])]

#text("UCLA gives money to encourage young students to learn math. Any organization that does this should only be applauded. Go spread the word; Prof. Tao thank you for the post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7fe72d8655255f3f1b56b525a083260cfa76b97637a23d3d71e687de66329c3-c2136c9e18da0a4fe5b89a65ce4e204d4068505542819e18bc3f1639bdd5e445.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of secondhandparanoia")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42430")[#strong[#text("secondhandparanoia")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2009")])]

#text("Perhaps UCLA is trying to improve the Putnam team, similar to what Duke has done?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11d99a9c9b768acd04f9dd2e9d00d1c3f732470e8baccbc0682c9801874827b7-827cb0909be45b7a5d91c98024e2ef69e1e62af3fa2aab81b020b189956bc67d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walter")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42431")[#strong[#text("Walter")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2009")])]

#text("How many IMO medalists from the US are even applying for colleges right now? No one on last’s year’s team is, for example. Also the domestic IMO people almost always go to private universities. I guess this is for foreign IMO medalists. They’d also be more likely to be need a full ride to UCLA, I think the American ones can rack up plenty of scholarships :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42436")[#strong[#text("UCLA Math Seeks Exceptional Student for Undergraduate Merit … | Baylor")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2009")]

#text("[…] post: UCLA Math Seeks Exceptional Student for Undergraduate Merit … Posted in Scholarships | Tagged a-room-and, background-and, entering-freshman, full-tuition, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lebertram")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42437")[#strong[#text("lebertram")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2009")])]

#text("Any details on criteria for foreign applicants? Some of the given (GPA, for example) obviously don’t apply.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/de35ecc2cef83eca7ca7aadb141fc215edcac81121305bfc9cd0849349f600a3-1b3795700934efa7bc5fca84187325b0d6c48f8b02a9bd4f9c1f022d594d66eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jagandecapri")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42438")[#strong[#text("jagandecapri")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2009")])]

#text("ya agreed.equal chance must given to all and not preference to IMO winner only.Interest in mathematics might bring greater success compared to innate talent alone.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5a76ce0c7b3e654571b98fd64d3858d2fb0fc3adb2dffd660ff0dc9b1033c9cc-561b6b4223fe38d9f3efb68a30dcb35fdaaea39e318d2cd3568a7dae5fa59e31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thatanonguy")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-453564")[#strong[#text("thatanonguy")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2015")])]

#text("I have never seen an IMO medalist who is not interested in what mathematics has to offer. They wouldn’t have made it that far otherwise.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42441")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2009")])]

#text("Why would equal chance be given to everyone? Anyone can argue that he has a strong interest in Math. What’s the evidence? Winning the IMO is a strong evidence. If one applies for a job, do they give equal chance to everyone regardless of background and experience. Hell, I could have said I had a strong interest in becoming the CEO of Google, but do you think they would give me so much as a job interview?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42443")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2009")])]

#text("Foreign applicants are welcome, and will be evaluated according to the nearest foreign equivalent of the domestic guidelines.")

#text("While competition performance is perhaps the most prominent example of mathematical achievement at the high school level, other tangible evidence of exceptional ability or promise (e.g. a research publication) would also be accepted as support for this merit scholarship. (A high level of interest or enthusiasm in mathematics, while desirable, would not qualify in and of itself as such tangible evidence.)")

#text("The GPA requirement in the description of the scholarship relates to the conditions for renewing the scholarship while at UCLA, and does not refer to high school grade performance. (However, we do require high levels of achievement in one’s high school academic record for this scholarship.)")

#text("Note also that these criteria only apply to this particular merit scholarship. Regular admissions to the UCLA maths major program are not subject to these requirements.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42456")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2009")])]

#text("Although I do think that IMO performance is probably a good (but not infallible) indicator of future success, I am quite curious about the subsequent careers of past winners and near-winners. Has anyone been tracking this? Moreover, I wonder how the particular kinds of problems that they are heavily immersed in as kids (i.e., combinatorics, number theory and geometry) influences future professional interest, style, and accomplishment. I suspect that there is some correlation. Do any of the IMO participants later experience burn out? I think that these are interesting questions that beg to be answered. Maybe some past IMO participants reading here know something about all this and can share with us.")

#text("Pre-college math competitions in the US were slightly after my time, so I know little about them except what I’ve seen in Hard Problems. I do agree that competition performance is probably at least partially correlated with family culture and the quality of local schools. If your high school doesn’t even have a math club (as mine didn’t) then you are probably at a huge disadvantage in this sort of thing no matter how great your innate talent is. And yes, I do believe that intense math competitions is not the sort of environment that many girls would thrive in, or anyone of any sex whose personal working style is not sharply competitive.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42457")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2009")])]

#text("Here’s something else that I’m wondering about. What about all the (very talented) kids who participate in the IMO but do not excel for any reason — they’re not feeling well, they are too nervous, etc. Does this experience ever crush and derail the ambition of someone who may otherwise have had an exemplary career?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82d6eabec437fbf94773280a984d4b84a2a89e032a956911395ce895b022b794-b24fe21b4efb623c76d96553bc9d9d50459118a26ba2f9bee65cf5477d051323.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42501")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2009")])]

#text("I would advise such an IMO medalist to compare the math textbooks that the undergrads at UCLA use with those at other universities offering financial aid.")

#text("If s/he would immediately start taking UCLA’s math graduate student classes, then UCLA will be fine mathematically. But in that case there won’t be much camaraderie with any other math majors of a similar age.")

#text("The Valedictorian at my highschool (and mostly his parents) chose a college that offered him a fancy fellowship. He got bored there and dropped out. I think the fellowship was actually a disservice in his case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42503")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2009")])]

#text("Having less talented classmates may be a disadvantage; it depends on one’s personality. But don’t assume that every student there is average. It’s a large student body and there must be good talents. In addition, the UCLA Math faculty is quite large and very good. At least one should be able to learn much, either mathematically or just how to succeed, from Prof. Tao :-) And having a full scholarship is a great help, especially in this economy. When someone fails to succeed, it could be lots of things. Even if a student goes to Harvard or MIT, there chance to succeed needs not be better, especially if the world class faculty is so occupied with themselves that they had little time for undergraduates.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43dd7a3a0aa801d74b8a44fdefc6caefe690d220397eb473bb159b6b9da4928e-12c10826ee2b3fe2c268ec35bedb94b1854f4102fda2841c431943fc7764b5b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asdf")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42557")[#strong[#text("asdf")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2009")])]

#text("Certainly one prerequisite to being a successful math researcher is wanting very intensely to work at math research. It’s quite possible to be highly talented and yet not have such an overpowering desire. As an undergraduate I hung out with a guy who had done quite well on the IMO in high school and he also did well in the Putnam (I think he was in the #6-10 group in one year). He ended up getting a bachelors and masters degree simultaneously and I’m sure he could have gotten into any PhD program he wanted, and eventually become a successful researcher by most normal standards. But while he had entered college as a hardcore math guy, he branched out into other interests by the time he graduated, eventually becoming a chip designer. Knowing how thoroughly he understood math and how he could get immediately to the essence of anything I asked him, it seems clear to me that “ability” wasn’t the issue in his not staying with math.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d46abcc59ad0a9a816aa0603f855d874694eee412f2914dfe20d196b5839bcc3-d39ed73657646f1f046f05d757814fd21972e4fe477f5e95177e6ab09ce9c6a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42686")[#strong[#text("A")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2009")])]

#text("I applaud UCLA for your initiative, and I hope more universities follow the same pattern. It will only make them better.")

#text("As an undergraduate, I can say that the difference between people who have excelled at high school contests and almost all of the other people is incredibly large at the undergraduate levels. Probably this is not so much true at the graduate level, but this is not what the scholarship is for.")

#text("For people who are interested in this topic, by the way, I think the article at dg.icme11.org/document/get/439 from the proceedings of the last ICM is a very good source.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42760")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2009")])]

#text("Hi There is at least one IMO Medalist who is quite successful in his career, ")#link("http://en.wikipedia.org/wiki/Ngo_Bao_Chau")[#text("http://en.wikipedia.org/wiki/Ngo_Bao_Chau")]#text(" . I think that IMO medal is not always the indicator of future success but it should be a factor to consider.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-42762")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2009")])]

#text("UCLA wants to do the same thing that USSR did several years ago. During that time many IMO medalists from Socialism countries were selected to join the undergraduate program at Lomonosov Moscow State University. They did succeeded in some sense. For example, Vladimir Drinfeld was an IMO medalist of Ukraine and later on became a Field Medalist. I like this scholarship program of UCLA and I hope that UCLA would be successful in near future.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-43688")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2010")])]

#text("I’m from Guatemala (a country in Central America). I love Math, and I have been studying some of it these last years. I have won national competitions and regional ones (honorific mention in OMCC). I participated in the 50th IMO but I won nothing there.")

#text("Does I have any opportunity to obtain a similar scholarship to study math?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-45767")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2010")])]

#text("While I would say there is a lot of bias regionally and upbringing-wise in deciding who will be a successful competitor in mathematics competition, I would say it is the best measure one has for high school level mathematics success. SAT scores are immaterial to problem solving ability for the most part, and do not decipher at such a high level on what they do test. High School courses do not mean much, as they are very algorithmic in nature, and there will be plenty of 4.0-ers competing for the scholarship. Thus, it is the best we have. We should make a push for high level, problem solving oriented, mathematics training encouraged for and available to every child in the states. But in the mean time, Tao and UCLA are doing the best in specifying the most well-prepared students, and rewarding their hard work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of UCLA Math Undergraduate Merit Scholarship for 2010 « What’s new")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-48130")[#strong[#text("UCLA Math Undergraduate Merit Scholarship for 2010 « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2010")])]

#text("[…] advertising on behalf of my department. The inaugural 2009 scholarship was announced on this blog last year. – T.] Last year, the UCLA mathematics department launched a scholarship opportunity for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/56d4b33e330dde63e3074db677891582f685d62de09598edbcb1fd296c89fe8d-e63cc38cc44a14267b3af8f20f56bcf1c5e165c60d143f33ba978a0ada5c4802.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-50963")[#strong[#text("Victor")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2011")])]

#text("Here is a wikipedia article about some past IMO contestants and their later achievements:")

#link("http://en.wikipedia.org/wiki/List_of_International_Mathematical_Olympiad_participants")[#text("http://en.wikipedia.org/wiki/List_of_International_Mathematical_Olympiad_participants")]

#text("A significant portion of the Field medals awarded during the past two decades appear to have been won by previous IMO medalists. So, contrary to what the first poster said, there seems to be a good correlation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/56d4b33e330dde63e3074db677891582f685d62de09598edbcb1fd296c89fe8d-e63cc38cc44a14267b3af8f20f56bcf1c5e165c60d143f33ba978a0ada5c4802.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-51193")[#strong[#text("Victor")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2011")])]

#text("Just to make a small clarification. By “significant portion”, I mean HALF (of the Field medals in the past two decades). If that is not a correlation I don’t know what is.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of UCLA Math Undergraduate Merit Scholarship for 2011 « What’s new")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-104496")[#strong[#text("UCLA Math Undergraduate Merit Scholarship for 2011 « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2011")])]

#text("[…] some advertising on behalf of my department, following on a similar announcement in the previous two years.] Two years ago, the UCLA mathematics department launched a scholarship opportunity for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of UCLA Math Undergraduate Merit Scholarship for 2013 « What’s new")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-192988")[#strong[#text("UCLA Math Undergraduate Merit Scholarship for 2013 « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2012")])]

#text("[…] [Once again, some advertising on behalf of my department, following on a similar announcement in the previous three years.] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5a76ce0c7b3e654571b98fd64d3858d2fb0fc3adb2dffd660ff0dc9b1033c9cc-561b6b4223fe38d9f3efb68a30dcb35fdaaea39e318d2cd3568a7dae5fa59e31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Neil Park")]], [#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-453563")[#strong[#text("Neil Park")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2015")])]

#text("Success in contest math was never implied to be perfectly correlated with the ability to do research mathematics. However, strong competition results are a much, MUCH better indicator of raw problem solving ability and mathematical talent (as well as dedication) than GPA, SAT scores, AP scores, classroom rigor, or anything a typical standardized test in high school could ever hope to measure. The majority of graduating seniors have only been assessed through these standard methods. I say that UCLA is doing the right thing. Besides, it’s only given to one student a year; there is plenty of room for others to be admitted as math majors. Not to mention that strong competition results don’t account for all the criteria.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/11/19/ucla-math-seeks-exceptional-student-for-undergraduate-merit-scholarship/#comment-453566")[#strong[#text("Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2015")]

#strong[#text("Is there a more accessible indicator of mathematical talent at the high school level other than math competitions?")]

#text("Many professional mathematicians argue that math competitions hold very little merit to a student’s full mathematical talent (which I am sure is completely true), but I have yet to find any better or more readily accessible assessment at the high scho…")
]
