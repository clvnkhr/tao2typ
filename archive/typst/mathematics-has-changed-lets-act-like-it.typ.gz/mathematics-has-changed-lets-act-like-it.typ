// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/
// Converted to Typst by tao2typ: "2026-11-07T13:20:12.725096+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mathematics has changed. Let’s act like it", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mathematics has changed. Let’s act like it")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/")[#text("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-07 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#emph[#text("[This is a guest post by ")#link("https://math.uchicago.edu/~fcale/")[#text("Frank Calegari")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#strong[#text("Why we should not be sad")]

#text("The release by OpenAI on October 6 of over 700 research papers was a watershed in the history of mathematics. AI is now undeniably capable of making groundbreaking contributions across many areas of mathematics. So why are some mathematicians so unhappy?")

#metadata(none) <tao-d32ccb88a1816bdea989>

#text("Some of it is the apparent disregard by AI companies for the practice of mathematics. The OpenAI papers — despite some tremendous ideas — are atrociously written and violate our community expectations of attribution. Some of them are even wrong. We have much more control over how we hire mathematicians, publish papers, and train students than over the behavior of trillion-dollar companies, and that is where our efforts would be better spent.")

#text("Much of the reaction seems to reflect a feeling that the subject that they love is under attack, and is being “hollowed out”. The recent OpenAI dump made barely a dent on the general problems of functoriality and reciprocity in the Langlands program. But even if it ")#emph[#text("had")]#text(" solved every problem in the Langlands program, to imagine that would have “solved number theory” would be as naive as saying that the construction of the periodic table solved chemistry. Mathematicians should do a better job explaining that when we talk about the central problems in any area, we are merely discussing the most natural boundaries of our understanding — and that unlocking them is not the end but the first step to finding new playgrounds to explore. Of course, this takes time. I looked for areas of mathematics which were “harder hit”. It is hard not to be struck by Hugo Duminil-Copin’s ")#link("https://proofsandprompts.com/2026/10/08/100-reactions-to-100-solutions/")[#text("lament")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Not a single one of the major open problems I have publicly mentioned throughout my career (whether in a talk, a lecture, an article, or even a grant proposal) was left untouched by the announcement. Everything has been claimed to be proved.")

#text("I expected to see a few of them in the list. But not all of them. Not all at once. Not with such nonchalance.")
]

#text("How would I respond to that?")

#strong[#text("The classification of finite simple groups.")]

#text("I can’t say much about percolation theory, but there is another historical precedent I think mathematicians should take note of. In 1972, Dan Gorenstein announced a program towards the classification of finite simple groups. After a flurry of activity over around a decade, the “classification” was announced by Gorenstein in 1983 (somewhat prematurely, with the case of quasithin groups not being completed for another two decades by Aschbacher and Smith).")

#text("The classification of finite simple groups was in many ways a huge success, but it was also a failure in that it — apologies to my group theorist friends and collaborators — cooled a lot of the interest around the subject. The “famous problem” had gone, and mathematicians on the whole turned their attention elsewhere. And yet, there remain very rich questions in finite group theory and even about the classification itself (to name just one: John Conway’s favorite question is ")#link("https://youtu.be/xOCe5HUObD4?si=qLrOZGG3F4lUBDUO&t=428")[#text("why does the Monster group exist?")]#text("). Perhaps for some fields, the OpenAI dump feels like how a group theorist may have felt in 1970 if the classification was dumped in their office, not in the form of the actual papers, but printed out on a spirit duplicator, smudged a little, then spread randomly like confetti all over the floor.")

#text("Right now, we need efforts like that of Gorenstein, Lyons, and Solomon and their work on the revised classification. If this was all we had to do, then it would be a fairly thankless task. But we also have the responsibility not to pronounce the subject “done” but rather — with these new tools available — ripe for further investigation. When mathematicians lament the winding paths missed by the construction of a galactic bypass, they need to realize that those old paths still exist and seek them out. And we need to reward that behavior when it comes to offering people jobs.")

#strong[#text("The promise of AI, and the (dis)-unity of mathematics:")]

#text("Since I was 15, I’ve wanted to know what ")#mi("{\\zeta(3)}")#text(" was. First, there was the childhood fantasy of finding a formula that Euler missed. But soon one learns more: how Grothendieck’s period conjecture, together with a sufficiently fine understanding of the geometry of mixed Tate motives (following work of Don Zagier, Sasha Goncharov, Francis Brown, and others) gives a completely satisfying structural, conjectural explanation of what’s going on. The irrationality of ")#mi("{\\zeta(3)}")#text(", or even its transcendence, is a mere shadow of the actual interesting underlying problem. Apéry’s proof of the irrationality of ")#mi("{\\zeta(3)}")#text(" has inspired me for over ")#mi("{30}")#text(" years not because of its conclusion, but for how it reveals the tiniest hints of some still secret story relating algebraic ")#mi("{G}")#text("-functions to arithmetic.")

#text("I hope AI can help mathematicians break out of the straitjacket of being constrained by the first natural conjecture they cannot prove, and work on unraveling the deeper mysteries woven throughout our subject. In the last thirty years, progress in mathematics by humans has been remarkable. But at the same time, I have felt a growing unease; the number of times I have seen mathematicians of all levels being unable to explain to someone even slightly outside their field why what they are doing is interesting has been distressing. The natural grooves of our profession have very much been bent toward more narrow technical expertise than a bigger vision. AI allows us an amazing opportunity to broaden ourselves as mathematicians.")

#text("I have tried (not always successfully) to be broad as a mathematician. I had some help by the fact that, while I knew since I was 17 that I wanted to work in algebraic number theory and the Langlands program, I grew up in the crucible of Melbourne University, which was a home to many Thurston students and low-dimensional topologists. This meant I was bathed in the sweet liqueur of hyperbolic 3-manifolds. That exposure has helped my career immeasurably. As with any two deep areas of mathematics, hyperbolic three-manifolds and arithmetic are much more closely connected than would first appear. But it’s still hard to be an expert on both, let alone pursue a crazy idea combining them. Let me get technical for a moment. For every imaginary quadratic field ")#mi("{F}")#text(", there are many commensurability classes of compact arithmetic hyperbolic three-manifolds indexed by non-split quaternion algebras ")#mi("{D/F}")#text(". Manifolds ")#mi("{M}")#text(" in each of these commensurability classes give rise to elements in ")#mi("{K_3(F)}")#text(" via the decomposition of ")#mi("{M}")#text(" into hyperbolic tetrahedra, and their volumes are always rational multiples of ")#tao-math("{\\zeta_F(2) \\cdot \\pi^{-2} \\cdot \\sqrt{\\left|\\Delta_F\\right|}}", block: false)#text(". I have always had this idea that one could conceive of elements in these different commensurability classes as forming some type of geometric Kolyvagin system (“Heegner points”) associated to ")#mi("{K_3(F)}")#text(", which one could yoke together by some unknown integral arithmetic version of the Jacquet–Langlands correspondence. This is not a question I have pursued, for two reasons. First, there were so many underlying conjectures involved that any result I could prove was going to be conditional on many of them, something that’s not always appreciated by the mathematical community. Second, assembling all the technical background to formulate such an idea precisely would have taken a huge amount of background work. Now, with AI, the barriers to trying such a problem are much lower. It’s not trying to prove a theorem. It’s trying to explore some completely new direction that may or may not be nonsense. There are so many problems in mathematics that are still so fresh and vital but were previously untouchable that the opportunity to approach them is massively exciting. We need to be more ambitious, to create bold research plans that weren’t even conceivable a year ago.")

#text("This is not to say that everyone must (or must not) use AI. But we have to rethink and readjust what’s important. Proofs of major conjectures, using AI or otherwise, are going to remain part of the new mathematics. But working toward broader programs (new and old) and structural understanding is going to play a more fundamental role. Christian Szegedy raised the ")#link("https://docs.google.com/document/u/1/d/e/2PACX-1vTSh-pyNP3Gi99WMmsinnLmE9V5CDI0HEm6WGbIPMNt3V5SGlClHF8-BetotKHOImrvQDSXmFdiOw8D/pub")[#text("following point:")]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Mathematics prided itself on being meritocratic, with deep reverence for the explorers: the people who could climb what nobody else could. That specific kind of heroism will matter less, and other skills will matter more: choosing which terrain is worth exploring, steering fleets of airplanes, and explaining what they find to the rest of the world.")
]

#text("I’m ready to board the plane, because I want to see what’s there. At the same time, I would add that people who previously have been walking around on earth with their eyes closed are not going to recognize anything however high they fly; I still believe that many of the skills that mathematicians have now will not only be transferable but vital to the new world order.")

#text("The difference in reaction between the optimists and the pessimists is that, for the pessimists, the game is over. For the optimists, the game has just changed. I acknowledge that there are aspects of our mathematical culture that we treasure that won’t survive, and it is only human to grieve that loss. But there now exists an amazing new tool to study mathematics. To turn away and say that the community of mathematics as it currently exists is more important than mathematics itself would be a terrible mistake.")

#strong[#text("The ugly truth.")]

#text("For all that everyone has been saying on this blog and elsewhere about how mathematics is about understanding, it takes one look at the arXiv to see many people in our profession rushing out AI-assisted papers in a somewhat unsightly rush to be the “first” to prove things. As many others have noted, there is quickly becoming a gulf between the ability to produce novel proofs and the ability to either demonstrate understanding or push the subject in new and interesting directions. As people crank out more and more results, the Leiden declaration is being honored more in name than in spirit, and it seems like “business as usual” except with a much more compressed time scale and the constant threat of being scooped hanging over people’s heads.")

#text("To me, someone who chooses a worthwhile problem, obtains a proof completely using AI, understands it thoroughly, and uses it to develop interesting further questions or directions has made a substantial mathematical contribution. I would give that person substantial credit even if they supplied no new ingredient in the original proof. Choosing worthwhile problems may end up mattering more than producing proofs.")

#text("Our obsession with conjectures tends to greatly undervalue the exploratory work that makes answering (or even asking) these problems possible. We are in danger of making that mistake a hundredfold now by encouraging or rewarding the rush for everyone to press the button to get these new results out as soon as possible. I would encourage all senior mathematicians (with the privilege of tenure) to take up the work of creating future problems and exploring new ideas rather than simply using AI to answer existing questions. If you, as a senior mathematician, are stressed about being scooped by AI, then you are not being ambitious enough.")

#strong[#text("So what are we actually going to do?")]

#text("Think pieces are ultimately pointless unless they propose some mechanism for actually affecting how people act. The tools that are going to be the most effective are going to be economic rather than rhetorical. Mathematicians want recognition, mathematicians want jobs, mathematicians want grants. The tools that we currently have to affect this are hiring and accepting papers at journals.")

#text("Let me offer some very basic concrete suggestions, followed by a few details.")

#enum(start: 1, 
[#text("Evaluate all work as if it is AI-assisted.")],
[#text("Make hiring much more about personal interactions rather than a paper file. Interview postdocs and graduate students in person.")],
[#text("Demand more from journals, and abandon those that do not adapt.")],
[#text("Put a greater emphasis on breadth in graduate education, but do not abandon technical skills.")],
[#text("Give better seminars.")],
[#text("Take more ownership of the results of AI.")]
)

#strong[#text("Evaluations:")]

#text("Nelson Cole famously spent ")#link("https://en.wikipedia.org/wiki/Frank_Nelson_Cole")[#text("three years of Sundays")]#text(" discovering the prime factorization")

#align(center)[#tao-fit-display[#mitex("2^{67}-1 = 193707721 \\cdot 761838257287.")]]

#text("In ")#mi("{1903}")#text(", this was a contribution to mathematics. Factoring the same number in ")#mi("{2003}")#text(" by hand would be an equally impressive feat of arithmetic, but its contribution to mathematics (even if it had not previously been known) would be far less, since this can be done on a computer algebra system in far less than a second. It’s obvious that AI is changing the economics of what is “easy” or “hard” — much has already been said about the coming collapse of the theorem economy. In time (perhaps quickly) there will emerge a new sense of what remains a substantial contribution to mathematics, whether it be asking interesting questions, developing new programs, or something completely different. In the future, I see no reason to reward a paper based ")#emph[#text("purely")]#text(" on a result that could be produced by machine, whether it was or not. A new proof can still deserve substantial credit for the ideas it introduces, even when its conclusion is already obtainable by machine. So why not start now? Importantly, I do not think this in any way means that access to AI will be required to make progress in mathematics — as long as we continue to value human understanding. While I feel that this is the most controversial recommendation, I also feel it is the most inevitable. It requires relinquishing an aspect of our reward structure that has been around for a long time, but at the same time a structure that will make no sense in the future. Right now, the use of AI carries a stigma, and the phrasing of many AI disclosures reads more like an attempt to minimize the contribution of the machine. If we evaluate every paper as potentially AI-assisted, then we must insist that its authors explain why the mathematics is interesting, what questions it raises, and how it connects to the broader subject. Don’t we want people to be doing this anyway?")

#strong[#text("Hiring:")]

#text("It’s not going to be possible to get people to change unless we change how we evaluate people at the level of hiring. Lazy committees in the past have sometimes pointed toward a JAMS paper, an Annals paper, or some other collection of publications to justify how a candidate is impressive. I am looking for a narrative of where you want mathematics to go, the technical ability to explain why this may be possible, being able to converse about many areas of mathematics, and a demonstrable record of having done all of this in the past. This is not in any way a radical new idea. The hiring process is going to have to be much more about personal interactions than a paper file.")

#text("It should become standard practice to interview not only for tenure-track jobs, but also for postdocs and graduate student positions. I’m sure we have all had the experience of admitting a graduate student who was “working on higher homotopy theory” to only find out after they are admitted they can’t compute the homology of the circle. At the same time, I have interviewed candidates at the tenure level whom I was initially ambivalent about, but after a 30 minute conversation in my office I was totally convinced that here was someone who not only had a deep vision of mathematics but who was also able to communicate this to their colleagues. Once we take this approach, we then have the responsibility to train our own graduate students to be better able to communicate mathematics, something that we should take much more seriously. Note there is also a difference between knowing mathematics deeply and explaining it fluently; they are related but different skills. Ideally I want both, but it is the first that I ultimately value more highly.")

#strong[#text("Journals:")]

#text("The journal system was in dire need of reform even before AI. Our current incentives already are to produce more and more incremental mathematics which is only flooding the system. The radical overhaul required is not going to happen through consensus agreements with editorial boards. (Do you know how hard it is to get academics to agree on anything?) Being accepted by a journal has long since ceased to be a guarantee of correctness (if it ever was) and has simply acted as an imprimatur of quality. I explained above the philosophy of how I think we should evaluate manuscripts going forward. On that basis, I would say that a significant proportion of papers posted to the arXiv should not be published anywhere. If journals demand much more from a paper in terms of writing, ideas, and exposition, I think that would make life better for everyone — editors, reviewers, and even ultimately authors.")

#text("If editorial boards are unable to adjust, then a more radical idea is to (at least temporarily) abandon journals altogether. (I still see a place for journals which emphasize exceptional utility and clarity (consider ")#link("https://msp.org/ent/about/journal/about.html")[#text("Essential Number Theory")]#text(")). I am not advocating that people stop writing papers, but removing the fig leaf of journal publication forces the paper to stand on its own merits. Is the paper telling a compelling story? Is it Lean-verified? We should be producing fewer (and better) papers, not more. Autonomously AI-produced proofs, hopefully Lean-checked, also have their place, and should be recorded as part of our collective body of knowledge. (see ")#link("https://hexagonmath.org/")[#text("hexagonmath")]#text(".)")

#strong[#text("Graduate students, first-year courses, and seminars.")]

#text("One of the thorniest issues we face is how to train graduate students. The typical thesis has always been to assign a problem in the overhang, an exercise that will teach the student the technical skills to solve a variation on some old problem, with the expectation that, as they continue, they can expand the techniques they’ve learned to new cases and then hopefully branch out to wider problems. In an age where such a thesis can be produced by the press of a button, we need to re-evaluate based on what we hope a good student will be doing in the future. Even with AI resources, no one is going to be able to explore the links between compact arithmetic hyperbolic three-manifolds and Kolyvagin systems if they don’t know what either of these terms means. (And even if somehow they could, why would they care?) It has become much more important to give students a broader overview of mathematics as a discipline. What I want a graduate student to achieve at the end of their PhD is a view of mathematics that extends well beyond their discipline, and yet with demonstrable technical skills on at least some class of problems. Often, students graduate with technical skills in a subarea, but their experience with other aspects of their area, let alone other areas of mathematics, consists of technical instruction which they have since forgotten, without any real vision. I advocated above that we need to evaluate work as if AI was involved. But this does not imply that we don’t need to teach students to do deep mathematics without AI just as the existence of computers doesn’t mean we should no longer teach children arithmetic.")

#text("This has consequences for what we teach, as well as how students learn to talk about it. A graduate course should leave students with some understanding of what the topic makes possible elsewhere in mathematics. We should expect them to retain a sense of the questions and connections, even when they have forgotten some of the technical details.")

#text("If we are to evaluate people more on how they can demonstrate understanding in person, we clearly need to be far more conscious of training our students to explain mathematics to other people, either in person, or in seminars, and to their peers. We need to work on giving our students opportunities to learn this skill. Remember that the most successful cohorts of students are the ones who learn together and who talk mathematics with each other.")

#text("We should also not forget that not everyone who completes a PhD in mathematics goes on to academia. We should also ask whether the length and structure of doctoral training serve students who will pursue careers outside academia.")

#strong[#text("Seminars:")]

#text("Seminars are traditionally where someone presents the details of their latest result. Because math is difficult, this almost always consists of explaining some minor tweak to a previous method, often without anywhere near enough broader context to make it interesting. Instead, seminars should rarely be focused entirely on new work. They should be framed around the broader interesting questions, explaining the avenues on which we are stuck, on which we can make progress, on which we are hopeful, and then perhaps at the very end explaining some novelty, if there is any. This is how I have always encouraged my students to give talks! As senior faculty we all need to be vocal in our seminars demanding more from our speakers.")

#strong[#text("Ownership.")]

#text("Mathematicians ")#emph[#text("as a profession")]#text(" would do well to take more ownership of these results. What has come out of the machine has been built on the intellectual foundations of several millennia of human mathematical endeavor. Once you start to take credit on behalf of humanity (rather than attributing these results to either a Silicon Valley tycoon or a mathematical Twitter buffoon), you’ll immediately start to feel much better.")

#strong[#text("The world is looking at us.")]

#text("My dean recently visited New York to meet with donors and other friends of the University of Chicago, and everyone she spoke to, regardless of whether they were a math major or not, wanted to talk to her about mathematics. The world is looking at us. There are many many people who care about mathematics without necessarily having a deep technical background (")#link("https://www.youtube.com/c/3blue1brown")[#text("3Blue1Brown")]#text(" has over six million subscribers!). All of my friends in the humanities truly believe that having mathematicians in society both as custodians of one of humanity’s oldest intellectual activities and explorers of the frontiers of knowledge is important. I understand that some part of the culture we so deeply care about will disappear, and as humans, an emotional response to that is very natural. But this is a time to explain to everyone that there are so many great new opportunities, possibilities, and reasons to be optimistic. We are on the verge of a new era of mathematics, and I am excited to see what happens.")

#strong[#text("Notes:")]

#text("For more context on Duminil-Copin’s remarks, see also ")#link("https://www.youtube.com/watch?v=Zh86i_azaQw")[#text("this numberphile video")]#text(". His full quote also says “We are a resilient community, and I have no doubt that we will adapt”.")

#text("Many of the themes mentioned here have been brought up in other posts. To give three examples:")

#list(
[#text("The idea that mathematicians should take more ownership of the results produced by AI was also explored in ")#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/")[#text("Nestor Guillen’s post")]#text(".")],
[#text("The idea that AI gives us the opportunity to be far more ambitious is raised in ")#link("https://terrytao.wordpress.com/2026/09/15/fast-math-slow-math/")[#text("Ben Antieau’s post")]#text(".")],
[#text("The idea that we need to revisit our reward structure to create the right incentives was explored in ")#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/")[#text("Bryna Kra’s post.")]]
)

#heading(level: 1)[#text("Comments (62)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699005")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("First off, thank you for putting into words what I’ve been insinuating privately to my friends for months.")

#text("Second off, I didn’t know Karthik Prasanna was important enough to merit its own category on your blog, but, having stuffing myself with poutine and having seen Darmon ask away so many rapidfire questions across one week last year, can definitely see the allure.")

#text("Third off, I think it’s hardly a coincidence that you both enjoy chess as a hobby and regard class field theory as taking years to master, despite being “solved” for nearly a century now. Actually there is a 500 move forced mate KQN/KRBN that has long been “solved” by the Lomonosov tablebase, but for which humans have approximately zero idea what is going on. I find these comparisons to be a nice toy model of your essay above.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699145")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("Let me revise what I said, only slightly. I believe that more emphasis in this essay should be placed on making sure that whoever you’re trying to hire is actually productive! You should absolutely still look at a candidate’s output to make sure it’s worth something, it’s just that paper count alone is no longer acceptable. I believe that you regard this as equally important as I do, and I believe that you tried to make that point, but I think it just needed a bit more emphasis so that universities don’t get lulled into picking someone who only has a vision and nothing much to show for it.")

#text("You know, there was a circulating trope on a now-deleted forum that mid-tier universities grade their tenure track candidates’ output roughly by L^2 norm, while higher tier universities grade by something approaching L^infty norm. Someone high in L^2 norm might be someone who has written a bunch of very solid papers fleshing out a research program; the recent hire of Samir Canning comes to mind. Someone high in L^infty norm might have a low paper count, but three amazing papers all in a row; the recent hire of Lue Pan comes to mind. Well, I think that both L^2 and L^infty norms ought to maintain their rightful places in hiring committees, in both mid- and high-tier universities alike! It’s just that the L^p norms for lower p are now weighted less in importance.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/610c305c5a89f7a5031c7ec6bc8ddb6d91d521994e86d8363c06a3ce953e68cc-8aab02501278ed1ae21b91bbf2eb5e337a6f723c99915386207d17de6af92b3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nietzky")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699006")[#strong[#text("Nietzky")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("Adapt how? Similar how adapted to neoliberal model? By hollowing ourselves out, flattening the culture, fitting into the market, and surrendering the remnants of human agency to cybernetic capitalist system?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699020")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("Flattening culture? By all means please explain what you mean here? And I do mean that in the most literal “this is my culture, that we are losing, because of this”. Because that’s valuable in itself. Understanding culture, has value in itself. So what is being lost. Do tell the world.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699007")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("I see nothing but common sense in this article. Let’s act like it!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f5c698b3bddf1654b0afc66b85bd592a9ab4e15a0c3aa4f7dab7d96de5b443c-af3af3302127b17fd48ccb7c4ae4cd8dfbafe08ebc0175b66c961d00f7864791.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699009")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("Great ideas. I feel like this is the right approach")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699010")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#align(center)[
#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://x.com/FanNie1208")[#text("Fan Nie (@FanNie1208)")]#text(" · ")#text("27 October, 2026")

#text("AI is now taking on some of the hardest open problems that scientists have posed. But research is broader than solving problems. Can AI also propose research questions that experts find genuinely interesting?")

#text("We built After42 to find out. Experts judged 45 of its 135 final… pic.twitter.com/E3NUEO3TZo")

#link("https://x.com/FanNie1208/status/2115113813620211818?s=20")[#text("View on X")]
]
]

#text("You said “Choosing worthwhile problems may end up mattering more than producing proofs.” Check out the linked video. It shows that AI is already pretty good at this in math.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef56db71d958f5047139912a0c9b31b770236c367cfa407466708f3d3ed9626e-8536151e32c141f00c22d3db8a7c045b3e045c1ab1cdb6157c04c755d0e6b6c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nestor")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699013")[#strong[#text("Nestor")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("Frank — this is great, thank you. This really gets at the optimistic vision –, but also clear-eyed about the current problems — that I feel captures where most mathematicians are today. This optimism has gotten a bit lost in the conversation.")

#text("By the way, you mentioned my essay from the summer. In it, I wondered about the possibility about the solution to problems dear to me, and not just NS: I mentioned the the Komlós conjecture, the Mahler conjecture, and the nonlocal ABP. Since that essay came out, the first two problems have had complete solutions found in the output of an LLM (for Komlós in particular, this was something I had been working on a lot the last 2 years), and the nonlocal ABP had on one had a counterexample in its strongest form, while also a proof of a still quite good version of the nonlocal ABP was also found — again, the output of an LLM.")

#text("In all cases, those solutions did feel to me like a triumph of the fields that they come out of. There were really gems that we had been missing out on. Another good example came out last week with the proof of the local smoothing conjecture, which connects the problem to the Monge-Ampère equation.")

#text("In the behavior of the companies and the lack of transparency some of the genuine excitement over this progress has been lost. This is why its important to not equate AI technology with AI companies. I do think more than I did months ago that, as we take claim over these proofs as a community, and we start working on the reforms to the profession, that the mathematical community will indeed come out of this not only stronger, but also having a more useful and substantive relationship with the world outside mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699016")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("Another piece saying that there is no room for the average mathematician in the new math.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699018")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("Spend any time with a pro LLM model and you’ll see how much lower the bar is for dreaming the good dream. This bar is lowered as much for average mathematicians as it is for top mathematicians.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18dd5bc93786287b663a5910f1e3ba4324428939556077e94b77d786dec56c71-6517122cbaa638c73002b2ccdfabf0fc0815c7cf3c27d3fbabaf13c1fa976ec6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699017")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("We should also not forget that not everyone who completes a PhD in mathematics goes on to academia. We should also ask whether the length and structure of doctoral training serve students who will pursue careers outside academia.")
]

#text("I think we should also do the inverse, not everyone who lacks a degree in mathematics are incapable of mathematics, and I think with the introduction of AI, many more individuals who are actually mathematically gifted will find themselves able to understand mathematics, not because they couldn’t before, but because the pedagogy of mathematics is somewhat elitist and very expensive.")

#text("Personally, I love graphing in desmos, I love using python to graph things, I enjoy digging into a problem, but I also have Autism and ADHD. For the first time in my life, I can take mathematics at my own pace, and it has been incredibly rewarding. Insofar that I was able to get top 13% in HackerRank’s most recent Orchestrate Hackathon; two years ago I was struggling to figure out how to get python 3.9 and Ryzen AI software to work together, now I can write triton kernels for specific AI models on specific hardware and understand exactly what I am doing.")

#text("The future is now and honestly I’ve never been more excited.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8592e1d49bd79df28201a050bf6012468ab9cd11f1f47812c96cde8804dfee0-e0c55de8321d58740c95ff02f1bc74c880ee3a8957d1a69ac1f130119029edb5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fairplaywes")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699019")[#strong[#text("fairplaywes")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("I actually disagree at least in part with the statement")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("To turn away and say that the community of mathematics as it currently exists is more important than mathematics itself would be a terrible mistake.")
]

#text("If one believes that AI is already and might soon be better than humans at all aspects of math, including proofs, theory building, exposition, asking new questions, etc, then the one thing left for human mathematicians is human mathematical communities. To suggest our communities are less valuable than OpenAI’s slop theorems is to start down the road to a future in which all research mathematics is done by AI and for AI with no human involvement, and in which mathematics as a human endeavor is left for hobbyists.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/043c8143d0722f0800cd190087cafdf1acd88d0f18f3e5d6fea6f87944d0e108-eeae760036e049bbb61697b2760cde66afbbb4151b070ae9d3247b586f2fbf84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699045")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Given the rest of the paragraph, I think the quote should be understood as stressing “as it currently exists”, rather than the community aspect. (But I agree with the point you are making after that.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/385706eb4b20841b7b9fad56fcc3e9a3ca9f5f141869248024126da086d2dda8-c90ace576b3f40213e183d6737cde6f6fc2130abf5312f97937aa92f3357bcd1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kęstutis")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699021")[#strong[#text("Kęstutis")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("The work of Maxim Kontsevich is extremely profound. Maxim Kontsevich is absolutely horrendous at explaining that to somebody who doesn’t have prerequisites of having read Grothendieck’s Sketch of a Program and other diving into the weeds of geometric anaylsis. Countless students getting a degree don’t care at all anyhow, they just want their school to give them a certificate so they can seek a job on wall street or something. It’s hard to compartmentalize feelings about sociology, economics, and politics from raw math. For the aforementioned type of student outsourcing intellectual labor to available tools is almost a no brainer.")

#text("Well before AI it wasn’t that much of a hot take to insinuate the modern academic situation would discourage chew up and hinder the raw curiosity and passion of Einstein or Grothendieck.")

#text("There is no crisis if AI solved the Reimann Hypothesis today, mathematicians will find new problems. I think the vague worries emerging here are the same if it was a human who did that instead on a sheet of paper, that this knowledge is not very valuable or meaningful in the society we seem to be building that resembles an “idiocracy” or “don’t look up” where it takes herculean effort to get the average individual glued to tik tok for hours a day to even engage with the critical thinking required for a simpler problem.")

#text("This is a good article but I do ask about when and if this ethos is brought to something like environmental data and advocacy, in fact there’s quite a lot of stories to tell about how for what is workers concerned about their labor and favor compensation a very meek response.")

#text("I really am growing more and more stern that the problem is that there is no problem with mathematics at all. In fact it’s pretty telling it’s easier for us to fantasize about that than actually imagine any meaning suggestion to addressing critical issues with education…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699046")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Well you are in proximity to Federico Scavia who (along with you) is basically AI trained on torsors under algebraic groups…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6eabb4634930032914d212474fdd60cfe5a4bdd05781acb6cb37a76dabc79451-3d361a4ad1bcf3838239aaa861d266fdd08ada99f46a8182ae78555d22df9261.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kestutis Cesnavicius")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699080")[#strong[#text("Kestutis Cesnavicius")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("The above comment is not from me (Kestutis Cesnavicius). I do not read this blog regularly and have never commented here (at least not in the past 10+ years…).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6eabb4634930032914d212474fdd60cfe5a4bdd05781acb6cb37a76dabc79451-3d361a4ad1bcf3838239aaa861d266fdd08ada99f46a8182ae78555d22df9261.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kestutis Cesnavicius")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699081")[#strong[#text("Kestutis Cesnavicius")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("P.S. Thanks to a friend for alerting me about this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6eabb4634930032914d212474fdd60cfe5a4bdd05781acb6cb37a76dabc79451-3d361a4ad1bcf3838239aaa861d266fdd08ada99f46a8182ae78555d22df9261.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kestutis Cesnavicius")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699082")[#strong[#text("Kestutis Cesnavicius")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("The initial comment was not made by me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/385706eb4b20841b7b9fad56fcc3e9a3ca9f5f141869248024126da086d2dda8-c90ace576b3f40213e183d6737cde6f6fc2130abf5312f97937aa92f3357bcd1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kęstutis")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699091")[#strong[#text("Kęstutis")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("No imitation is intended, I just learned who you are right now. I am just a random American student here who happens to have the same name and would have never expected that to mislead that my comment was authoritative in anyway.")

#text("Most Americans aren’t aware Lithuania exist lmfao I guess it’s pretty cool coincidence there’s someone across the pond sharing the name with an even deeper passion than I for the subject")

#text("What a small world")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6eabb4634930032914d212474fdd60cfe5a4bdd05781acb6cb37a76dabc79451-3d361a4ad1bcf3838239aaa861d266fdd08ada99f46a8182ae78555d22df9261.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kestutis Cesnavicius")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699101")[#strong[#text("Kestutis Cesnavicius")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Cool! No offense and nice to meet you.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70ddeab5d9c6b2e56e1efcf9292e8fcbc41ed5b24fd02e8d5d5ad3f45aea0aa2-82fd0c9b2ddeff65cfa6d5c510a1729856196e9a893f1cb183266110d5a6b697.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel M Gessel")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699023")[#strong[#text("Daniel M Gessel")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("Should we analyze the AI models to understand how they are making these discoveries or just accept artificial intelligence as equal or superior to our own? Would the response be different the discoveries were found by a traditional heuristic search based theorem prover? One with algorithms we could analyze and understand, rather than the giant black boxes that are today’s AI. If the AI weren’t designed to present a human-like interface, would we understand it as a tool, not as an alternative to human beings?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70ddeab5d9c6b2e56e1efcf9292e8fcbc41ed5b24fd02e8d5d5ad3f45aea0aa2-82fd0c9b2ddeff65cfa6d5c510a1729856196e9a893f1cb183266110d5a6b697.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel M Gessel")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699075")[#strong[#text("Daniel M Gessel")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Alternatively: can we learn something about the structure of Mathematics from AI models? If they don’t have embedded meta-mathematical structure in their parameters, it seems they must be making progress only through brute force and/or luck.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cb067b0f33d12c3a86d73a344ef94e95ea21b15a43123049a5f27d357651841-b88726d4249dd0be563473abf73112b1d1e0af6c0b0c8076773c0490c4adb47e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jesusvilelajato")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699024")[#strong[#text("jesusvilelajato")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("Dear Professor Frank,")

#text("Thanks for sharing your deep meditations and perspectives on the surely brigth future of present and future mathematics and mathematicians alike.")

#text("Coming precisely from the other end, a seasoned enterprise practicioner with years of accumulated AI studies, understanding and practical usage, I also see with increasing concern how both major AI labs and Academia single out our contributions, even when those come in the form of explicit machine checked AI formalizations, on the grounds of AI usage.")

#text("We are indeed navigating dangerous epistemic times, where major labs feel as tough displacing traditional mathematic gatekeepers in Academia, but also where Academia fences out contributions on the grounds of AI usage, as tough the observable increase in quantity and the painful decrease in quality of published papers were not easy to correlate with the advent of mainstream large language model usage, such as GPT-4.")

#text("It takes only paraphrasing to circumvent most AI detectors, and one can pose some members inside the fence are prodigally using such tehcniques to present minor advances in methods and results. in a non-sensical race for the flag. All the while, different epistemic angles and ordinary common sense approaches are discarded upon the basis of AI usage, even when such usage is explicitly recongized and accounted for, both in the form of machine verification and epistemic hardening.")

#text("Even when not a mathematician, I do belive mathematics will change, and if I migth be so bold as to point out where help is needed, I woudl answer from engineering. In a decade, mathematicians will need maps, covering formalizations as well as sematic lineage, and powerful novel systems ensuring their insigth is not lost in the transformation.")

#text("That is why a great deal of my research concerns trnasformations, changes of perspective, holonomy and what remains true even when we don´t share common worlds.")

#text("With admiration,")

#text("Jesús.")

#text("Note: as a spanish speaker I oftentimes write in my words, only to have it AI corrected. I hope you will still feel my voice in the text. As a matter of fact, I prompt my model with “in the manifold of my words”")

#text("Research website:")

#link("https://jesusvilela.github.io/")[#text("https://jesusvilela.github.io/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699025")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("Apart from everything else, this post deserves a +100 for the little allusion to “mathematical Twitter buffoon.” 😄 I think everyone reading the post will know who that is and the buffonery was definitely super annoying.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699034")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("(1) It may be a brief window in which you get to be more ambitious in your research. Maybe in five years your ambition will be reduced to understanding the AI’s explorations, because yours will pale in comparison. (Not to mention mine!)")

#text("(Would you bet on the ratio between the following two numbers? 1) The total grant money given by governments to human mathematicians in 2031. 2) Money used for marketing privately-owned AI in the same year.)")

#text("Luckily, being tenured, you’ll still get to spend time doing what you like.")

#text("(2) The talented young people similar to who you were at 15 or 17: will they get to develop their technical skills in the way you did? Will they see a point in going after research math as a career, when they may never have a chance to be at the forefront of its development? Will they see it as something likely to be viable?")

#text("To be clear, as a pessimist I don’t think “the game is over” for mathematics. Maybe it won’t be over until AI is so good that there’s no drive to improve it further beyond force of habit. (At that point “the cloud” may be a system of yottawatt server farms in space or whatever.) I’m just more worried about what this means for humans than you seem to be. It doesn’t have to be the case that the best models are available to use for a reasonable price, and that we own what we use them to produce. They could lead to a massive concentration of power.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd95e80daf16ad5b92a71c6462480902a783fc95fb30a35ba175a669e22b63b0-7f481c20628a50745480041bcdc12df443d9ce89cff363c6b8429ee285743d75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gordon Royle")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699036")[#strong[#text("Gordon Royle")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("In related discussions on MathOverflow, various commentators were extremely concerned about how those who are not mathematicians but whose opinion matters (external members of hiring, tenure, grant committees) could be expected to evaluate people without the supposedly objective measure of “research output” as measured by counting papers. Interviews are great for picking the winner from the 5-person shortlist, but how to do the initial selection from the 250 applicants? I fear it will degenerate into an informal country club where who you know and where you study will be the defining factor in making it past the first cut.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699049")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("while I agree with you that the human touch is lost, I do not think it is reasonably possible to give fair consideration to everybody who would want a tenure position at even a middling university in a middling country. There are SO MANY people in this world, you simply cannot consider all the many talented individuals that will apply.")

#text("I think the only fair way to deal with this fact is to select the 5 person shortlist entirely at random, given some low base criteria filter. Trying to filter people at all is going to be by definition dehumanizing and likely to filter out the very rare jewels you are looking for in the first place – if they were both brilliantly talented and had a stellar CV they wouldn’t be applying to you but to some other place instead")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699065")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("In person math competitions. Just like there are for high school and undergraduate students, there can be for junior researchers.")

#text("With enough universities on board, there could be a system of competitions for a range of difficulty levels, and topics. Graduate students, and post, can take part on them, just like comprehensive exams, but every year. The rankings provide credit on the topic of the competition. Exam A can be issued by university U, but administered at multiple universities and institutions simultaneously. So, that takes case of the volume.")

#text("No evaluation system is perfect, but in person exams have the desired property of being in person.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ee0e835155fb1d659e8eb9d79ce55bec4e01304fbec346dbdcbcff8a17a8348-124ffab86645d4b8a2479158b59b3f0a9e3d74d17d75e0d239e3e68f6479b630.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699040")[#strong[#text("M")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("The main problem I see with the argument in this post is that it vastly downplays the power and influence of AI companies themselves, both as providers of the “new tools” (models) and the main source of information for common folk when it comes to news about AI-assisted mathematical breakthroughs. This gives AI companies a lot of power to shape the future of mathematics in the way that ")#strong[#text("they")]#text(" see fit, which is to publish a bunch of incomprehensible papers claiming to solve long-standing conjectures and further push humans out of the loop. And even if they had any moral leaning against doing this, I doubt they would even see it as a problem, because much of AI research — which these companies claim to be doing — can best be described as “throw shit at the wall without good understanding and see what sticks”, and this has been a problem since ")#strong[#text("before")]#text(" LLMs. Since this is the philosophy of the “researchers” at these companies, that is likely what they think everyone else should go with.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9b5070a42381b43e33fcc39479c7e4b931d244edf74730371bd515d9d2e7c4b-2e4d2ba4c0e89711a32f6a0946a0a3a408da2b70c37877a3025204c63eefa79d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel T")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699043")[#strong[#text("Daniel T")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Many important observations about what’s often neglected. What I don’t quite see is how one could be sure that the realm of asking the good questions, providing well-explained answers, discovering not only the galactic bypasses, but the beautiful side-alleys and even theory making, will remain in the human domain. 1blue3brown argues for an increasing human collaboration, the transferability of the mathematical skills and the sheer enjoyment of it as the raison d’être for maths in this age. Maybe those arguments have greater chance to withstand the test of time?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aimen")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699044")[#strong[#text("Aimen")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("At its core, artificial intelligence is fundamentally a mathematical engine. Using it to assist with, or even prove, a result from A to Z can be viewed, from a certain perspective, much like using existing lemmas to imply a theorem. This is a reality we must accept and adapt to; we can harness AI’s power to push mathematics further.")

#text("As one commenter noted, “there is no room for the average mathematician in the new math,” and we might be inching closer to that reality. However, AI has yet to crack major long-standing problems like the Riemann Hypothesis or the Hadwiger Conjecture, leaving plenty of room for genuine human research and breakthroughs. If someone were to successfully prove the Riemann Hypothesis tomorrow and present a complete, rigorous explanation from first principles in front of an audience, they would unquestionably merit an extraordinary reward, something like a Fields Medal ++.")

#text("Ultimately, I think we need to accept the new rules of the game and use AI as an assistive tool. But as the author noted, and with whom I completely agree, this requires establishing entirely new policies for evaluating researchers, mathematicians, candidates, papers, and journals.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699048")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Evaluate all work as if it is AI-assisted.")
]

#text("But what if someone chooses not to use AI for their research? How will they be assessed compared to someone who happily accelerates/assists their progress with the tools? How does one equitably recognise the work and ideas and promise of such an “AI vegan” if you insist on assuming that their relative-to-AI slower progress was somehow their poor use/application of it?")

#text("I have no answers, but surely this type of insistence is the kind of driver that penalises people who otherwise would have been considereed perfectly solid citizens, even if not the rising stars of their field, who don’t want to use AI?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699063")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("In person evaluation. The math competition system needs to be brought, with proper adjustment to subjects and format, into the hiring process.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699064")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("The game has changed. Directing AI is now where a mathematician adds value. It’s the same as if you wanted to be rewarded for not using a calculator.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699070")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("It is probably a good think, that people that would click all the check boxes of the AHM, do not end up being the mathematician of the future. Why would anyone want to hire one of those?")

#text("You made the tacit wrong assumption that people who make the choice to not use, or not know how to use tools of the trade are “people who otherwise would have been considered perfectly solid citizens”. What constitute “perfectly solid citizens” changes with time. I knew professors who refused to use email, or computers. At earlier times, they could have been perfectly solid citizens. They don’t exist any more. Someone like that would even be able to begin entering the system or graduate studies.")

#text("The problem is with those who don’t have access, not by choice. But that problem goes beyond AI. There has always been talent lost from disenfranchised countries.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0287fa6ed42e04bc83f65e86e74f136a3b1a1145976a81f7da741b5640eaa4ee-55f51209f6b63dc95588449e5c1791a6f72adc72aff14fffd6b9122bcad3e615.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nobody")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699055")[#strong[#text("nobody")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("I am increasingly dissatisfied with how narrowly we discuss AI and mathematics. Mathematics is an early warning of upheaval across society, and keeping this debate inside mathematics misses the point. Even planning solely for mathematicians must start with how AI will transform the society they depend on. We have repeatedly underestimated AI. Stop waiting until the disruption becomes undeniable, when society may already have lost its chance to prepare. The world changes before evidence catches up—even frontier labs must take time to discover what their models can do, and outsiders learn still later. My position: err on the side of overestimating AI and prepare now for rapid disruption across society.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70ddeab5d9c6b2e56e1efcf9292e8fcbc41ed5b24fd02e8d5d5ad3f45aea0aa2-82fd0c9b2ddeff65cfa6d5c510a1729856196e9a893f1cb183266110d5a6b697.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel M Gessel")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699106")[#strong[#text("Daniel M Gessel")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("I think Mathematics is the canary in the coal mine. From articles in the general news media and the comments I see, most cannot cope with what the world may look like if AI (assisted by robotics) competes with the human ability to “contribute economically” across the board. For so many, an economic system must separate “winners” from “losers” to be legitimate – a utopian future is seen as empty, another form of dystopia.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00761e96d3d7e280b4bb5c8e264c707aa6a47776d17c035e08bf3eb382cc7a03-634216ba6373d7953c8b5d45120afeac9586491ea0b3e8b3f7ccdb4cc88efade.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stefan Dawydiak")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699161")[#strong[#text("Stefan Dawydiak")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("Thank you saying this. Many plans like this one begin with the assumption of “mathematical power of AI increases unboundedly, the rest of the world is entirely unchanged.” This is already not true, and it is getting less true by the day. The evidence seems to be that AI abilities in other aspects of science and engineering are proportional to their mathematical abilities, as is the case for human countries (e.g. there are no geopolitically neglible but mathematically productive countries). Even its mathematical abilities are not harmless to the “real world,” e.g. by breaking most forms of encryption.")

#text("One of our purposes in the near term is to raise the alarm. As a profession we get media coverage, and are not suspected of being part of an advertising ploy like the ex-employees of AI companies. We are slowly wasting these advantages. We are very much the canaries, and the correct action when the canaries feel lightheaded is not “oxygen masks or UBI for the canaries, then continue mining as usual.”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699061")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Here’s a thought experiment: suppose major AI firms did not exist yet. Suppose the mathematical community had seen the potential uses of the technology, and sought to develop this as shared infrastructure. We’d recognize the potential for the good, bad and disruptive [it doesn’t take a savant or a pessimist to predict the disruption]. ")#linebreak()#text("How would we have approached this? How would we decide to manage the transition? What norms would we change?")

#text("We’re presently in fully reactive mode, rushing on someone else’s timeline. This is because we’ve taken as axiomatic that (a) AI adoption is necessary and (b) commercial AI lab practices should dictate the pace and nature of adoption.")

#text("What would a more intentional, thoughtful adoption of the technology look like?")

#text("I’ll give a small example of an intentional change we might have considered. We’d have discussed it, piloted it, and then decided to adopt or not.")

#text("At present, most conferences in my field don’t have many 50-60 minute talks. The bulk are in the 20-25 minute range. The short talks may be inadequate for communicating one’s deep understanding about results of ever-increasing sophistication [AI is supposed to help with the latter]. Deep questioning doesn’t happen either.")

#text("Well, maybe we should change the format of conferences. Maybe have a vast number of parallel sessions, with each talk being sufficiently long so as to reveal understanding and allow meaningful discussion? Maybe plenary speakers give 15 minute talks [we agree they know of what they speak], and everyone else gives hour-long talks?")

#text("Andrew Ng has a very interesting proposal around how we may revise dissemination: ")#link("https://proofsandprompts.com/2026/11/01/a-new-system-of-accreditation/")[#text("https://proofsandprompts.com/2026/11/01/a-new-system-of-accreditation/")]

#text("All of this to say: I’d be much more optimistic about the miracles of AI, if I were convinced that we’re not just in purely reactive mode, our decision-making tied to the vagaries of IPOs.")

#text("-Nilima Nigam")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of old-bielefelder")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699121")[#strong[#text("old-bielefelder")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Others in the math scene are more optimistic (including me), mostly also more active in the use of AI tools. Math with AI help is like gliding (instead of Everest-climbing).")

#text("Probably it is a once-in-human-culture-time where people without much technical machinery can contribute to progress in math. For me it feels like grace to live in this year as a freshly retired math prof.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699062")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Note there is also a difference between knowing mathematics deeply and explaining it fluently; they are related but different skills. Ideally I want both, but it is the first that I ultimately value more highly.")
]

#text("This is an important point. It is easy to do interviews, at least at the last stages of hiring, but what those interviews target can be very subtle. If it becomes just “talk about this”, those characters who are “good at talking” have an advantage. That’s OK, in part. People good at teaching pass through that sieve. Now, one doesn’t want the hiring process to be permeable to the “good at talking, but not good at doing (unassisted)”.")

#text("So, I would add a little more precision to the “knowing mathematics” and clarify that problem solving skills go in there, not only an enumeration of results, and ideas.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699066")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Richard Hamilton was a more important figure for proving the Poincare conjecture than Grigori Perelman.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c15c60086024e7375df28ef92650f81dc607f2d5297e5ceab8d9b9d19bcc8e10-3d0da8f90f1182504009ee2f45a2622cd475df2a2accc7d3f4d051628935dedb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hector")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699098")[#strong[#text("Hector")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Perelman would actually agree with you.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699069")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("We should not be sad because OpenAI feeds on mathematicians’ anguish, that is, they are interested in increasing it for the sake of their market valuations. LLMs in themselves are neither ‘good’ nor ‘evil’; rather, they are being developed and deployed in completely irresponsible ways that are dangerous to humanity, not just to us mathematicians.")

#text("I agree with much of what is said in this essay. When it speaks of “optimism” and “pessimism”, however, it risks inviting the readership to side with the optimists. In my book, the most responsible attitude is neither of those two, but purposeful realism.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0faa10cf5128f4f466e2189f0cf98d0f98f52e15a018714920ed97b64388d6d0-f0c23b1882a6175eef39658e3c0e0340327b9735dbeef67c7112c073e029ab3c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Skylar Wapato")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699071")[#strong[#text("Skylar Wapato")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Could attribution be clawed back from mathlib and lean?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8022e58766cca42c0c990f4f58fd19dc2c6fd0dee00790675c31961ee2bd0dea-bf8377c7bd25694f25b86d6cce9866c28b4371a190f065ade4a7510dd9db75ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lee Larson")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699077")[#strong[#text("Lee Larson")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Perhaps this will be like how physics and cosmology were revolutionized by Galileo’s telescope or biology by Leeuwenhoek’s microscope. Both new tools opened a thrilling new view of the horizon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699095")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("I think these are attempts to revive a dead body. They are not revolutionary enough for the level the AI world is leading us toward. We cannot continue to rely on old ideas and solutions in a world that is entirely new to us.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8b30e051cb7b48b34f0753738f67a2848698657d32658e3a578673925f4cc09-944c66a5ad60bae8c9f556b35c26f702281d78d656c5b1956abb9f716767cffa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jenfns")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699107")[#strong[#text("jenfns")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Thanks for this post, Frank. I am largely aligned with your point of view, and I appreciate the optimism, especially as it comes through in this quote:")

#text("“I hope AI can help mathematicians break out of the straitjacket of being constrained by the first natural conjecture they cannot prove, and work on unraveling the deeper mysteries woven throughout our subject.”")

#text("You’re right that the popular culture is paying attention to mathematics in an unprecedented way, at least in our lifetimes. We should be sure that we present ourselves as we would like to be seen.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699108")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("The ecosystem of academic mathematics, which had existed largely unchanged for over a century, has been completely shaken up over just a few months, and the new equilibrium point in sight does not look appealing. It is as simple as that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of simin")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699120")[#strong[#text("simin")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("my two cents: lots of narrow ai is blindsight (as in the sci-fi novel praised by neurologists) which is chomsky’s critique of ai, i.e. more or less using bayesian methods to approximate the physcial world rather than understanding it. however form is function, quantity is quality at a very large scale and a large enough network is more and more ‘understanding’ than ‘blindsight’ (see top post on hacker news best today on astra designing neural nets)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699134")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("I realise now that at the end of the day everything is about showing you’re better than the other person for opportunities that come. For hiring purposes, define the domain of an academic position and issue extensive but standardised tests. Like 200 questions with one and one answer only that demonstrate the level of understanding , technical Breath required. Otherwise subjectivity will bring chaos")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d17ba42f83ff20fbd38bb36afc83b5f1aebc1caecec7e78d702aa83be5d7de07-61be6c843d12cfa18ae3aa2bcb2eb572572d050015237fb2c66e6db02ce12e79.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pearl")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699135")[#strong[#text("Pearl")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("Introduce Standardised testing for any hiring position in academia as the dominant part of interviewing process and determining suitability of a candidate. It even inspires to learn and understand more")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699151")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("This is an excellent essay, and it is nice for me to learn some new mathematics that I did not know and some nice descriptions of Frank’s early days and dreams as a mathematician. Overall, I am closer to the optimistic side when it comes to AI+math and I am also curious and happy to see many of our mathematical problems solved, many new theorems, insights, theories, etc. (I don’t care if Silicon Valley tycoons will get credit, in fact, they deserve credit.)")

#text("However, it is not just that many aspects of doing mathematics have changed for us, and some aspects are considerably less challenging and fulfilling than the traditional ways of doing mathematics. It is also true that the whole mathematical endeavor and especially pure mathematics is under risk. I do not see good solutions for this reality.")

#text("The specific suggestions do not look very useful. I am fine with (1). As for (2), going back to “personal interactions” based hiring is understandable but it runs the problem of reinstating the old-boys network system with its sad biases. Yes, let’s go for breadth and technical skills for our graduate students and for better seminars. And finally, I don’t understand what “taking ownership” even means.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6bd8ec8740846028d9cedad033c107b8800f71e18fdce1c19fe28b1bddace0fd-93cd82cba1d9a6bacd34a0feba51c16b2f16776af6fe0bb5dfaed1ec843202d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699242")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2026")])]

#text("Do you have an alternative for (2)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699243")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2026")])]

#text("As for (2), no, I don’t have an alternative. As I said, this is an understandable move, it gives very limited answers to the real issues, and it raises some concerns as well.")

#text("Some more comments:")

#text("1) There is a saying that people judge others by their achievements and judge themselves by their dreams. When moving from dreams to achievements becomes automatic (and fund-dependent), this will change the nature of our discipline.")

#text("2) Erdos used to say something like “It is early in the morning, I conjecture and prove” (and sometimes he said “My job is to conjecture and prove”.) Theorems, proofs, definitions, and conjectures were at the center of the mathematical activity in most areas of mathematics. The measure of success was primarily the ability to produce high quality theorems, proofs, definitions, and conjectures.")

#text("3) I completely agree with Frank that with AI, mathematical goals (and dreams) can be more ambitious. As for (2), no, as I said this is an understandable move, it gives very limited answer to the real issues and it raises some concerns as well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699248")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2026")])]

#text("In person competitions (exams, but fun). We already have the solution for (2) implemented at all levels of education all the way up to undergraduate studies, and some early graduate too in the form of comprehensive exams. Just extend its use beyond that, to the hiring of new researchers. It would be a lot of fun too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699251")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2026")])]

#text("What did Erdos do for the rest of the day?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bf119b3dd5d123915485eb87aaa4894c18e24177d32284b2a7ff3ba4f805e13-2caea4b3a20b9440ba3d14a763682a70fd2f42d7755e8184b61a024315367fb6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin J")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699158")[#strong[#text("Martin J")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("Lowly Claude Opus 5.5 gave quite a good analysis of the ‘crazy idea’ you introduced early on, concluding:")

#text("The strongest defensible version would therefore pair the K₃ class and its index with a K₂-valued Eisenstein map on H₁. The primes with Nv ≡ 1 mod p would control both sides, and D-to-GL₂ transfer of the Eisenstein quotient would supply the missing integral Jacquet–Langlands statement. The difficulty is that compact M_D has no cusps to anchor Eisenstein classes, so any such transfer must detect K₂(O_F) through congruence homology or torsion.")

#text("LLMs are far better than embodied humans at coordinating questions, but often poor at evaluating answers.")

#text("Humans need to collaborate with LLMs to produce a new intellectual symbiosis, which mis one important component of the wider ‘Alignment Problem’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699159")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("What you are describing is very similar how to some people in mathematical physics were already working. With colleagues, for several years we have been devising interesting model physical systems that exhibit a variety of exotic “topological phases of matter”, trying to figure out what phases can actually exist, and what consistency conditions aren’t there. Since I and my colleagues are more physicists by background than mathematicians, we commented on a few occasions previously that it would be great if we had some topology grad student on call to answer our basic questions. Well, now we do!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2920e8847712abd9adf23d72a1368af39ea699fe4e828344e00e468cd711c13b-d350272287f0de99c7eef3a7578db1b46dd2da883018ca00af322b68c23e1608.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Basalat Raja")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699196")[#strong[#text("Basalat Raja")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2026")])]

#text("AI successes have revealed a hidden assumption in our ideas about ourselves that we are just now starting to grasp the implications of: skill is not intelligence. Skills can be taught. Since they can taught, they can also be automated. Time and again, computer science has automated what we thought was intelligence, only to find out that it was a skill – arithmetic is a prime example. I am starting to think that the mathematicianal angst comes from the same folding of the two concepts together. A lot of mathematical work is applying a skill. Knowing when and how to apply that skill requires intelligence. We cannot automate that, at least not so far. The massive amount of “maths” that mathematicians are now repeatedly being confronted with can be multiplied severalfold. Somewhere in there is possibly a “diamond”, some really valuable insight. Possibly. For mathematicians, the choice is simple – hope to find that diamond while traversing that immense field, or keep using that slow but steady method that has worked for thousands of years: figuring it out. It is certainly not a fast process, indeed it is so grindingly slow that mathematicians working on it might die of old age as younger mathematicians continue their legacy. Or you can partake in the random search. There is a 3rd choice. As I mentioned earlier, a lot of mathematical work is application of skill. Automation can indeed help mathematicians. But just as carpenters had to learn machine tools, mathematicians will also need to become experts at using power tools.")

#text("It was interesting reading about manifolds. It reminds me of an adage: All algebra is geometry. All geometry is algebra. I get pushback but that’s resolved when geometry also covers hyperdimensionality. There’s nothing exceptional about hyperdimensionality; when one goes from 3D to 4D, all that happens is that more things can now be put next to each other. Things can be broken apart more easily in 4D that are coherent in 3D. The two statements are the same fact. I have constantly had to deal with hyperdimensionality when exploring LLMs, which are themselves several distinct hyperdimensional spaces.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/998aa84176888b70e6bb0f3b71482354153c5f868c9b1eb68f432b908c0c4464-d47aad15c9418ef99d0904f48c92d07e3f873a6eee79e663e1b1f6206f0c7c4c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699217")[#strong[#text("Jason")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2026")])]

#text("This is a very good article with many great insights. While I agree with 90% of its content, my 10% disagreement centers on the following statement:")

#emph[#text("The difference in reaction between the optimists and the pessimists is that, for the pessimists, the game is over. For the optimists, the game has just changed.")]

#text("I do not think the divide is actually between “optimists” and “pessimists.” Rather, it is between tenured professors and those who have not yet secured permanent positions.")#linebreak()#text("Unfortunately, like most pieces published on this blog, this article is written from the perspective of a tenured professor, which makes it somewhat biased. Of course, the author provides valuable ideas on how to select the next generation of mathematicians and adapt the hiring process. However, I still think it is unfair to label early-career researchers as “pessimists” simply because they haven’t gotten their permanent positions yet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/01/mathematics-has-changed-lets-act-like-it/#comment-699244")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2026")])]

#text("A wonderful article with almost nothing said. What does it mean to “take more ownership of the results of AI” and “take credit on behalf of humanity”?. I ask you: after you have done your mathematical explorations using your traditionaly honed skills and AI capabilities, and have posed many new and wonderful problems, do you really expect the next generation with their dulled technical skills be able to appretiate your questions and take your exploration further? And their skills will have inevitably dulled due to AI use, no matter how much we try to pretend, and will continue getting dulled untill no one will care, as no one will have a sufficient depth of understanding, having lost their touch with the inner working of mathematics. And that will really be the early death of mathematics, a subject with is supposed to go on forever. And this will be because we mathematicians were complacent and selfish, focused on our short term intellectual goals and blind to the mathematical dystopia we are helping build, as we normalize AI use in problem solving. All one has to do is to set an example for the younger generation by abstaining from AI use and shunning it in the most extreme way possible. But alas, we mathematicians are just way too nice.")
]
