// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/29/ai-mathematics-education-and-a-public-goods-problem/
// Converted to Typst by tao2typ: "2026-10-30T13:15:26.498487+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "AI, Mathematics, Education, and a public goods problem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("AI, Mathematics, Education, and a public goods problem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/29/ai-mathematics-education-and-a-public-goods-problem/")[#text("https://terrytao.wordpress.com/2026/10/29/ai-mathematics-education-and-a-public-goods-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-30 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://people.eecs.berkeley.edu/~gireeja/")[#text("Gireeja Ranade")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("The day after the Navier-Stokes result was announced, a student came to my office hours. They said, “Can we please talk about the Navier-Stokes result and what it means? I really need some therapy.” Two days ago another student mentioned, “I used to be really motivated, but now that all the models can do everything with just a prompt, I don’t feel like putting in any effort at all.”")

#text("Every time I have such a conversation with students, I appreciate how lucky my generation has been. We didn’t have to grapple with the temptations or threats of AI when we were students. Not being able to quickly look up answers forced us to challenge ourselves, and do it together with our friends. And years of challenging ourselves somehow made us love it [1], and led us to challenging jobs across academia and industry. These jobs are simultaneously wonderful and hard. But I wonder and worry for my students, for the next generation. What do we need to do to make sure these jobs [2] are (1) available for the next generation and (2) that we have enough students who are motivated to train for them?")

#text("I’ve been in conversations where people are concerned about whether mathematics will survive. I’m actually not concerned about this — I’m fairly sure it will, so let us set that aside for the moment. But what I want to think about is, what do we need to do to make sure ")#emph[#text("all")]#text(" mathematicians survive? And not just the `great’ mathematicians, but also regular, ordinary mathematicians? Because even if we decide society only really needs the `greats [3],’ we need to train many tens of thousands of students to identify who those greats are. If we want one Steph Curry, we need to make basketball exciting for a whole generation of people, and we need to support college basketball, and after-school basketball, and neighbourhood basketball.")

#text("We’ve seen that by treating mathematical problems as a benchmark, humans have been able to train AI models to be very good at solving hard math problems and writing proofs. Soon we will create benchmarks about `asking good questions’ and `giving clear explanations’ and then AI models will be good at those tasks too. They will do the thinking and the meta-thinking. This is the reality we need to plan for.")

#text("For this post I will talk about “mathematics,” but I often mean mathematics broadly construed (the sciences, engineering, social sciences, and even many humanities subjects that require complex reasoning and critical thinking).")

#strong[#text("Background")]

#text("People are attracted to mathematics and mathematical sciences for a variety of reasons. But importantly, whatever the motivation, mathematics has always been a `safe’ subject to study. Historically, being good at math has led to a solid job and a stable lifestyle. Why? Because along the way, by studying beautiful mathematics (which in itself might not be exactly what leads to employment), the student learns critical thinking and perseverance, and becomes stronger. The transferable skills are helpful for employment.")

#text("As a result, society has encouraged students to do math, even when they might not be `great’ at math. For example, as a teenager, I was part of a special program called ")#emph[#text("Gold 2002")]#text(", [4] which trained students for the International Mathematical Olympiad (IMO). I was not among the `greats’ in this program. I did not make it to the IMO, unlike some of my friends. And today, I have no hope of ever winning a Fields medal. But I still enjoy doing mathematics, and (thanks to some hard work as a teenager) I’m good enough at it to be paid to do it (again broadly construed, I’m a professor in an EECS department [5]). But one of the reasons that my parents let me spend months and years working on crazy math problems was that math was a `good’ thing. And so it was ok to do this, even if I didn’t win any gold medals.")

#text("But today people wonder — does mathematics still have the same status? Do we need critical thinking if a prompt can do it for us? My students ask — is it worth their time to get a PhD, in mathematics, or any theoretical field, without an immediate application? Or should they focus on learning to train better deep learning models? When previously I would have many undergraduate researchers from my lab applying for PhD programs, many now prefer to go straight to industry. What do we say to them?")

#text("I have heard people say — in this new era, math will become more like the humanities. We will continue to pursue mathematics because it is beautiful and because we love it. While this may be the case, will as many students pursue it if it does not lead to a good job and a steady life [6]?")

#text("Which leads to the thought — well, does society really need all these mathematicians? We will have only our strongest, most passionate students do the very hard math, or those who love mathematics enough to do it even as `starving artists’. With AI, if one mathematician can do the job of five or ten, should we shrink our departments and our graduate programs? What jobs do we expect our students to get when they graduate? And if there are no jobs for `thinkers,’ and `intellectual explorers’, then why should students pursue a path towards a PhD in math or a theoretical science?")

#text("This brings us to a public goods problem, which I elaborate on further below. I believe it is essential for us, the human society, to maintain our intellectual culture. And for this we need lots of students getting degrees in mathematics, sciences, and the humanities, but we need to find ways to actually motivate the students to want these degrees and the associated training.")

#strong[#text("What is our culture and why is it important?")]

#text("As a child, I would see a big splash in the newspaper about the Nobel prizes every year. I didn’t understand the science or why the literature was meaningful. I just understood that this stuff was important, and that humans valued creativity, expression and intellectual and scientific achievement. And until recently, I had never consciously wondered about the cultural importance of Alfred Nobel establishing those prizes. I had always taken for granted that we should strive for excellence… but I see now that this was an impact of our culture, and that there are so many conscious decisions that have led to this culture.")

#text("But now, people have begun to worry about `")#link("https://www.noahpinion.blog/p/the-end-of-the-age-of-heroes")[#text("The end of the age of heroes")]#text("‘. In his blog post, Noah Smith makes multiple interesting points, but I will paraphrase one: even as mathematicians will likely retain their jobs as math-understanders [7] (since mathematicians are relatively cheap), they will lose their status as heroes.")

#text("My question is: while it may be ok for the mathematician to lose their hero status, what impact does this have on the next generation? In my younger days, and even now, I know I benefitted from being around, and hearing about, heroes — the brilliant, blazingly quick, hardworking minds, with the humblest of personalities to match. It gave me someone to look up to and goals to aspire to. With heroes gone, how would we orient our cultural compass?")

#text("Aspects of our culture are built on respect for facts about the universe. Nvidia CEO Jensen Huang said in an ")#link("https://www.nytimes.com/2026/09/23/opinion/ezra-klein-podcast-jensen-huang.html")[#text("interview with Ezra Klein")]#text(" a few weeks ago that it doesn’t matter if the multiplication table is starting to be forgotten, and that “we’re going to lose some finer intellectual dexterity … I don’t know how valuable it is for most people to learn how to do surface integrals or partial differential equations. I don’t really know how important that is, but it’s important to some people.”")

#text("I was bothered reading this, because I was worried about the implications for our culture.")

#text("Multiplication tables matter not just for their own sake but for what they represent [8]. Yes, knowing ")#mi("11 \\times 12")#text(" builds fine intellectual dexterity. But they also show young children that there are fundamental, unchanging facts about the world. Invariants. And starting from this, we can build up confidence that allows kids to grow into students who are grounded and questioning because they can both see and understand why there are invariants [9].")

#text("Our understanding of partial differential equations allowed us to develop numerical computer programs that can solve them for us. And when the computer does solve them, it is amazing that we (as a human society, not every individual) are able to understand exactly what the computer did. But this is not true when AI does all the work for us; we lose the essential human understanding. I will come back to the value of this soon.")

#text("It is important to maintain a culture where we value and respect intellectual dexterity and expertise. And admire the young children who know their multiplication tables, and the older people who win Fields medals and Nobel prizes. And respect those people who care deeply about partial differential equations, and create space for them to develop their expertise, even if not everyone understands them. The goal of expanding and developing human expertise in subjects can and should be independent of the state of AI [10]. So that we can ensure generations of students will continue to want to study and experience the “unreasonable effectiveness” of mathematics.")

#strong[#text("Education: Canary in the coal mine")]

#text("Every professor and teacher I know has grappled with AI-based academic dishonesty by students. Students cheat when `doing it the right way’ doesn’t seem worth the time and effort. And because our culture for students (especially in the United States) has focused on achievements/badges (or, as I tell my students, `sticker collection’), instead of building true understanding and intellectual depth, students want to do more and do it faster, even if they are not doing it deeper or better.")

#text("We need to realize that this is just the canary in the coal mine. Students are turning in proofs/essays/code they don’t fully understand. But this behavior is not limited to academic settings. It is likely that engineers are checking in code they didn’t fully read. It is only a matter of time before a researcher publishes a result they don’t fully understand, or an administrator signs off on a decision they don’t fully comprehend. And soon enough, AI systems will be making ever more complex decisions that we just sign off on, because we don’t understand the foundation of the system and we gave up questioning.")

#text("If we go down the slippery slope, we risk becoming AI-sock puppets [11]. Faced with AI-output, we will take quick looks and “sanity checks” to make sure AI output is reasonable and move on, but it won’t have the same gravitas and deliberation that comes from a human-authored proof/document. We will have no choice but to use AI, because that will be the only way to keep up. Sanity checks themselves may become illusions — because we will be out of practice at true understanding. It is likely that we will have verified Lean proofs that assure us of correctness, but now we have to evaluate the faithfulness of the theorem statements. (And Lean itself has a very steep learning curve. There is a lot of work to be done to make sure such verification tools are universally accessible to all [12].)")

#text("The only thing that can protect us against this is culture. A culture where the point of pride is in the understanding of the work and in the exposition of it. A culture where it is ok to say we don’t understand, ask for clarification, or (respectfully) push back. And where such requests are valued (instead of saying, “let us move on, we only have a few minutes”).")

#text("A culture that appreciates being slow and steady and careful. A culture where a student can pursue a more theoretical research area for their PhD, but also be assured that this does not destroy their chance to get a stable, enjoyable job.")

#strong[#text("So how do we cultivate this culture?")]

#text("Such culture building must start in the classroom. We must teach harder, better, and stronger [13]. We need to train students so that they know what they know and don’t know — students who can identify proof by intimidation and by authority, and have the confidence to push back. We should provide homework problems that let students explore concepts in depth, and force them to confront ideas they do not understand. Students thrive when they are challenged (with support) and then succeed. This needs resources.")

#text("We must walk away from classes that teach students the “high-level ideas” but do not expect students to fully grasp the rigorous details “because AI can do this stuff nowadays, [14]” or because “it is too hard for the students [15].” Because these can create a generation of students who don’t know the difference between understanding things deeply versus superficially. And then this can propagate.")

#text("This is now a bigger deal than it was a few years ago. It used to be that knowing a solution strategy or the right algorithm to apply was sufficient for students to become productive members of society. But now that this work can be done by AI systems, we have to be able to understand what the AI has generated, process it and question it, which requires not just knowing the names of the algorithms but also the proofs of why they work, what the key assumptions are, and where and how they break down.")

#text("A theorem may be correct given its assumptions. But the gap between assumptions and what we actually care about might admit counterexamples. Identifying such counterexamples requires knowing the modeling and the math at multiple levels. Interpretation matters and ambiguity can creep in when identifying if a formal Lean statement is faithful to the natural language. For such tasks mathematical mental muscles are essential.")

#link("https://terrytao.wordpress.com/2026/09/24/were-gonna-need-a-lot-more-mathematicians/")[#text("Amit Sahai")]#text(", ")#link("https://terrytao.wordpress.com/2026/09/19/why-do-we-need-human-mathematicians-anymore/")[#text("Po-Shen Loh")]#text(", and others have beautifully argued why we are going to need more (highly trained) mathematicians. I won’t repeat their argument here. But I will add to their point — it is important that we have a large, diverse set of people, with different life paths and trajectories, becoming mathematicians. People who do not all think exactly the same way, who can interpret, debate, disagree and convince one another.")

#strong[#text("A public goods problem")]

#text("This brings us to a public goods problem. We need to maintain our culture. For this, we need to engage and excite lots of different students. We know that if we don’t incentivize students to learn, many of them won’t, and our (humankind’s) mental muscles will atrophy. We know that when humans moved from working in the fields to having indoor desk jobs, our bodies suffered. And to compensate, we invented things like the gym to make sure our bodies stayed fit.")

#text("But there is a catch. We pay to go to the gym, not the other way around. Entry-level jobs in fact used to train people while also getting useful contributions from them. Entry-level jobs, or PhD programs, are like being paid to go to the gym. If these are taken away by AI, how do we train people? And how do we convince people that they should be trained?")

#text("There is a tremendous investment needed in thinking about what future sustainable solutions to this will look like. This is just the beginning of that conversation. But in the short term, it is important culturally to celebrate and reward the work of understanding and communicating mathematical results — and not just by mathematicians but by society at large. We also need to advocate for educational institutions at all levels and for what they represent for our culture. Teachers need more resources, not less, to be able to teach in the AI-age, because we need to be teaching more, not less. There is no silver bullet. AI tools alone cannot solve problems in the education sector — these come with their own set of challenges. We should be able to offer individualized, 1-1 human tutoring to help students at different levels. I hope we can collectively build a positive future, where we use AI-tools effectively to help us in ways that raise everyone up together.")

#text("As a concrete first step in this direction, I invite university leaders to declare their commitment to hiring across departments in the sciences, engineering, social sciences and humanities, and announce their unwavering support for human intellectual growth and exploration. Similarly I invite philanthropists and funding agencies to declare their support for open-ended research, theoretical pursuits and rigorous, grounded education in the fundamentals. Students need to know that we have got their back, and that we are working for their future — because they are our future.")

#text("I would like to thank Terry Tao and Nestor Guillen for the invitation to write this post, and also Ted Theodosopoulos, whose ")#link("https://www.youtube.com/watch?v=7pukV1WtkO0")[#text("1st Relatorium dialogue on Mathematics and AI")]#text(" started part of this conversation. Thanks also to Anant Sahai for many conversations that have helped refine these thoughts, as well as Vinayak Ranade, Sukhada Fadnavis, Shubhangi Saraf and Amit Sahai for their helpful feedback. Thank you also to the organizers and participants of the ")#link("https://www.renaissancephilanthropy.org/ai-for-math-fund")[#text("Renaissance Philanthropy AI for Math Workshop 2026")]#text(" — conversations there also influenced my thoughts.")

#strong[#text("Notes")]

#text("[1] I understand that challenge and struggle does not work for all students, but it does help a good number. In this post, I will focus on that set. There is a longer discussion about education to be had more broadly at another time.")

#text("[2] Jobs that are typically held by PhDs that apply mathematical/other critical thinking skills. I understand that there are far more complex questions regarding jobs in the age of AI, and I’m not trying to tackle them. For now I focus on the narrow question of jobs for highly-trained scientists/mathematicians/humanists.")

#text("[3] I argue that we need far more than just the `greats,’ but just hypothetically.")

#text("[4] I am forever indebted to M. Prakash sir, out of the Bhaskaracharya Pratishthan. He intensively trained 200+ highschoolers across Pune, India, and several from the group went on to win IMO medals (another example of the Steph Curry argument). And the rest of us benefitted on the side. It was a privilege to participate.")

#text("[5] I teach courses on the mathematical side of the department, such as optimization, probability, and deep learning.")

#text("[6] I also love to dance, it is beautiful. But I am nowhere good enough to earn a living doing this. Luckily the math worked out ;-).")

#text("[7] Human understanding can never be developed by an AI, no matter how good AIs get. AI-augmentation of humans cannot generate human understanding.")

#text("[8] Perhaps we will find skills that are a suitable substitute for multiplication tables, that do everything that tables do and are `better’ in other ways. I’m ok with teaching those skills instead.")

#text("[9] As Picard said “")#link("https://en.wikipedia.org/wiki/Chain_of_Command_(Star_Trek:_The_Next_Generation)")[#text("there are four lights")]#text(".”")

#text("[10] And every PhD granted is a new human expert in a subject.")

#text("[11] Not quite a ")#link("https://www.urbandictionary.com/define.php?term=Meat+proxy")[#text("meat proxy")]#text(", but still bad.")

#text("[12] Some of our work to make lean accessible is available at leantutor.org")

#text("[13] not faster. ")#link("https://www.youtube.com/watch?v=gAjR4_CbPpQ")[#text("https://www.youtube.com/watch?v=gAjR4_CbPpQ")]

#text("[14] There is a space in this system for courses that teach students how to “use” tools (e.g. prompt engineering courses that have recently come up at many community colleges in California), or general AI literacy courses. But we must not confuse the role of these courses. Those may be helpful (in the current climate) for maintaining employment. But they do not replace the role of courses that fundamentally teach critical thinking, and should not take resources away from such courses.")

#text("[15] To cater to the fact that students come in at different levels, we need to have scaffolding classes at the lower-division level. A student may take longer to graduate, but should be able to take even the hardest class given enough time and hard work.")
