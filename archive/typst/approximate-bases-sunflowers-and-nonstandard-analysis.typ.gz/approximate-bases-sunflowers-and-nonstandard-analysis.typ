// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/12/13/approximate-bases-sunflowers-and-nonstandard-analysis/
// Converted to Typst by tao2typ: "2026-10-14T15:17:33.152603+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Approximate bases, sunflowers, and nonstandard analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Approximate bases, sunflowers, and nonstandard analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 December 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/12/13/approximate-bases-sunflowers-and-nonstandard-analysis/")[#text("https://terrytao.wordpress.com/2009/12/13/approximate-bases-sunflowers-and-nonstandard-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the most basic theorems in linear algebra is that every finite-dimensional vector space has a finite basis. Let us give a statement of this theorem in the case when the underlying field is the rationals:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Finite generation implies finite basis, infinitary version)")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" Let ")#mi("{V}")#text(" be a vector space over the rationals ")#mi("{{\\mathbb Q}}")#text(", and let ")#mi("{v_1,\\ldots,v_n}")#text(" be a finite collection of vectors in ")#mi("{V}")#text(". Then there exists a collection ")#mi("{w_1,\\ldots,w_k}")#text(" of vectors in ")#mi("{V}")#text(", with ")#mi("{1 \\leq k \\leq n}")#text(", such that")

#list(
[#text("(")#mi("{w}")#text(" generates ")#mi("{v}")#text(") Every ")#mi("{v_j}")#text(" can be expressed as a rational linear combination of the ")#mi("{w_1,\\ldots,w_k}")#text(".")],
[#text("(")#mi("{w}")#text(" independent) There is no non-trivial linear relation ")#mi("{a_1 w_1 + \\ldots + a_k w_k = 0}")#text(", ")#mi("{a_1,\\ldots,a_k \\in {\\mathbb Q}}")#text(" among the ")#mi("{w_1,\\ldots,w_m}")#text(" (where non-trivial means that the ")#mi("{a_i}")#text(" are not all zero).")]
)

#text("In fact, one can take ")#mi("{w_1,\\ldots,w_m}")#text(" to be a subset of the ")#mi("{v_1,\\ldots,v_n}")#text(".")
]

#emph[#text("Proof:")]#text(" We perform the following “rank reduction argument”. Start with ")#mi("{w_1,\\ldots,w_k}")#text(" initialised to ")#mi("{v_1,\\ldots,v_n}")#text(" (so initially we have ")#mi("{k=n}")#text("). Clearly ")#mi("{w}")#text(" generates ")#mi("{v}")#text(". If the ")#mi("{w_i}")#text(" are linearly independent then we are done. Otherwise, there is a non-trivial linear relation between them; after shuffling things around, we see that one of the ")#mi("{w_i}")#text(", say ")#mi("{w_k}")#text(", is a rational linear combination of the ")#mi("{w_1,\\ldots,w_{k-1}}")#text(". In such a case, ")#mi("{w_k}")#text(" becomes redundant, and we may delete it (reducing the rank ")#mi("{k}")#text(" by one). We repeat this procedure; it can only run for at most ")#mi("{n}")#text(" steps and so terminates with ")#mi("{w_1,\\ldots,w_m}")#text(" obeying both of the desired properties. ")#mi("\\Box")

#text("In additive combinatorics, one often wants to use results like this in finitary settings, such as that of a cyclic group ")#mi("{{\\mathbb Z}/p{\\mathbb Z}}")#text(" where ")#mi("{p}")#text(" is a large prime. Now, technically speaking, ")#mi("{{\\mathbb Z}/p{\\mathbb Z}}")#text(" is not a vector space over ")#mi("{{\\mathbb Q}}")#text(", because one only multiply an element of ")#mi("{{\\mathbb Z}/p{\\mathbb Z}}")#text(" by a rational number if the denominator of that rational does not divide ")#mi("{p}")#text(". But for ")#mi("{p}")#text(" very large, ")#mi("{{\\mathbb Z}/p{\\mathbb Z}}")#text(" “behaves” like a vector space over ")#mi("{{\\mathbb Q}}")#text(", at least if one restricts attention to the rationals of “bounded height” – where the numerator and denominator of the rationals are bounded. Thus we shall refer to elements of ")#mi("{{\\mathbb Z}/p{\\mathbb Z}}")#text(" as “vectors” over ")#mi("{{\\mathbb Q}}")#text(", even though strictly speaking this is not quite the case.")

#text("On the other hand, saying that one element of ")#mi("{{\\mathbb Z}/p{\\mathbb Z}}")#text(" is a rational linear combination of another set of elements is not a very interesting statement: any non-zero element of ")#mi("{{\\mathbb Z}/p{\\mathbb Z}}")#text(" already generates the entire space! However, if one again restricts attention to rational linear combinations ")#emph[#text("of bounded height")]#text(", then things become interesting again. For instance, the vector ")#mi("{1}")#text(" can generate elements such as ")#mi("{37}")#text(" or ")#mi("{\\frac{p-1}{2}}")#text(" using rational linear combinations of bounded height, but will not be able to generate such elements of ")#mi("{{\\mathbb Z}/p{\\mathbb Z}}")#text(" as ")#mi("{\\lfloor\\sqrt{p}\\rfloor}")#text(" without using rational numbers of unbounded height.")

#text("For similar reasons, the notion of linear independence over the rationals doesn’t initially look very interesting over ")#mi("{{\\mathbb Z}/p{\\mathbb Z}}")#text(": any two non-zero elements of ")#mi("{{\\mathbb Z}/p{\\mathbb Z}}")#text(" are of course rationally dependent. But again, if one restricts attention to rational numbers of bounded height, then independence begins to emerge: for instance, ")#mi("{1}")#text(" and ")#mi("{\\lfloor\\sqrt{p}\\rfloor}")#text(" are independent in this sense.")

#text("Thus, it becomes natural to ask whether there is a “quantitative” analogue of Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(", with non-trivial content in the case of “vector spaces over the bounded height rationals” such as ")#mi("{{\\mathbb Z}/p{\\mathbb Z}}")#text(", which asserts that given any bounded collection ")#mi("{v_1,\\ldots,v_n}")#text(" of elements, one can find another set ")#mi("{w_1,\\ldots,w_k}")#text(" which is linearly independent “over the rationals up to some height”, such that the ")#mi("{v_1,\\ldots,v_n}")#text(" can be generated by the ")#mi("{w_1,\\ldots,w_k}")#text(" “over the rationals up to some height”. Of course to make this rigorous, one needs to quantify the two heights here, the one giving the independence, and the one giving the generation. In order to be useful for applications, it turns out that one often needs the former height to be much larger than the latter; exponentially larger, for instance, is not an uncommon request. Fortunately, one can accomplish this, at the cost of making the height somewhat large:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Finite generation implies finite basis, finitary version)")]#text(" ")#metadata(none) <tao-0e3d661d1de125ea7e32>#text(" Let ")#mi("{n \\geq 1}")#text(" be an integer, and let ")#mi("{F: {\\mathbb N} \\rightarrow {\\mathbb N}}")#text(" be a function. Let ")#mi("{V}")#text(" be an abelian group which admits a well-defined division operation by any natural number of size at most ")#mi("{C(F,n)}")#text(" for some constant ")#mi("{C(F,n)}")#text(" depending only on ")#mi("{F,n}")#text("; for instance one can take ")#mi("{V = {\\mathbb Z}/p{\\mathbb Z}}")#text(" for ")#mi("{p}")#text(" a prime larger than ")#mi("{C(F,n)}")#text(". Let ")#mi("{v_1,\\ldots,v_n}")#text(" be a finite collection of “vectors” in ")#mi("{V}")#text(". Then there exists a collection ")#mi("{w_1,\\ldots,w_k}")#text(" of vectors in ")#mi("{V}")#text(", with ")#mi("{1 \\leq k \\leq n}")#text(", as well an integer ")#mi("{M \\geq 1}")#text(", such that")

#list(
[#text("(Complexity bound) ")#mi("{M \\leq C(F,n)}")#text(" for some ")#mi("{C(F,n)}")#text(" depending only on ")#mi("{F, n}")#text(".")],
[#text("(")#mi("{w}")#text(" generates ")#mi("{v}")#text(") Every ")#mi("{v_j}")#text(" can be expressed as a rational linear combination of the ")#mi("{w_1,\\ldots,w_k}")#text(" of height at most ")#mi("{M}")#text(" (i.e. the numerator and denominator of the coefficients are at most ")#mi("{M}")#text(").")],
[#text("(")#mi("{w}")#text(" independent) There is no non-trivial linear relation ")#mi("{a_1 w_1 + \\ldots + a_k w_k = 0}")#text(" among the ")#mi("{w_1,\\ldots,w_k}")#text(" in which the ")#mi("{a_1,\\ldots,a_k}")#text(" are rational numbers of height at most ")#mi("{F(M)}")#text(".")]
)

#text("In fact, one can take ")#mi("{w_1,\\ldots,w_k}")#text(" to be a subset of the ")#mi("{v_1,\\ldots,v_n}")#text(".")
]

#emph[#text("Proof:")]#text(" We perform the same “rank reduction argument” as before, but translated to the finitary setting. Start with ")#mi("{w_1,\\ldots,w_k}")#text(" initialised to ")#mi("{v_1,\\ldots,v_n}")#text(" (so initially we have ")#mi("{k=n}")#text("), and initialise ")#mi("{M=1}")#text(". Clearly ")#mi("{w}")#text(" generates ")#mi("{v}")#text(" at this height. If the ")#mi("{w_i}")#text(" are linearly independent up to rationals of height ")#mi("{F(M)}")#text(" then we are done. Otherwise, there is a non-trivial linear relation between them; after shuffling things around, we see that one of the ")#mi("{w_i}")#text(", say ")#mi("{w_k}")#text(", is a rational linear combination of the ")#mi("{w_1,\\ldots,w_{k-1}}")#text(", whose height is bounded by some function depending on ")#mi("{F(M)}")#text(" and ")#mi("{k}")#text(". In such a case, ")#mi("{w_k}")#text(" becomes redundant, and we may delete it (reducing the rank ")#mi("{k}")#text(" by one), but note that in order for the remaining ")#mi("{w_1,\\ldots,w_{k-1}}")#text(" to generate ")#mi("{v_1,\\ldots,v_n}")#text(" we need to raise the height upper bound for the rationals involved from ")#mi("{M}")#text(" to some quantity ")#mi("{M^{\\prime}}")#text(" depending on ")#mi("{M, F(M), k}")#text(". We then replace ")#mi("{M}")#text(" by ")#mi("{M^{\\prime}}")#text(" and continue the process. We repeat this procedure; it can only run for at most ")#mi("{n}")#text(" steps and so terminates with ")#mi("{w_1,\\ldots,w_m}")#text(" and ")#mi("{M}")#text(" obeying all of the desired properties. (Note that the bound on ")#mi("{M}")#text(" is quite poor, being essentially an ")#mi("{n}")#text("-fold iteration of ")#mi("{F}")#text("! Thus, for instance, if ")#mi("{F}")#text(" is exponential, then the bound on ")#mi("{M}")#text(" is ")#link("http://en.wikipedia.org/wiki/Tetration")[#text("tower-exponential")]#text(" in nature.) ")#mi("\\Box")

#text("(A variant of this type of approximate basis lemma was used in ")#link("http://front.math.ucdavis.edu/math.CO/0501313")[#text("my paper with Van Vu")]#text(" on the singularity probability of random Bernoulli matrices.)")

#text("Looking at the statements and proofs of these two theorems it is clear that the two results are in some sense the “same” result, except that the latter has been made sufficiently quantitative that it is meaningful in such finitary settings as ")#mi("{{\\mathbb Z}/p{\\mathbb Z}}")#text(". In this note I will show how this equivalence can be made formal using the language of ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("non-standard analysis")]#text(". This is not a particularly deep (or new) observation, but it is perhaps the simplest example I know of that illustrates how nonstandard analysis can be used to transfer a quantifier-heavy finitary statement, such as Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text(", into a quantifier-light infinitary statement, such as Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(", thus lessening the need to perform “epsilon management” duties, such as keeping track of unspecified growth functions such as ")#mi("{F}")#text(". This type of transference is discussed at length in ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("this previous blog post of mine")]#text(".")

#text("In this particular case, the amount of effort needed to set up the nonstandard machinery in order to reduce Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text(" from Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" is too great for this transference to be particularly worthwhile, especially given that Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text(" has such a short proof. However, when performing a particularly intricate argument in additive combinatorics, in which one is performing a number of “rank reduction arguments”, “energy increment arguments”, “regularity lemmas”, “structure theorems”, and so forth, the purely finitary approach can become bogged down with all the epsilon management one needs to do to organise all the parameters that are flying around. The nonstandard approach can efficiently hide a large number of these parameters from view, and it can then become worthwhile to invest in the nonstandard framework in order to clean up the rest of a lengthy argument. Furthermore, an advantage of moving up to the infinitary setting is that one can then deploy all the firepower of an existing well-developed infinitary theory of mathematics (in this particular case, this would be the theory of linear algebra) ")#link("http://en.wikipedia.org/wiki/Out_of_the_box")[#text("out of the box")]#text(", whereas in the finitary setting one would have to painstakingly finitise each aspect of such a theory that one wished to use (imagine for instance trying to finitise the ")#link("http://en.wikipedia.org/wiki/Rank%E2%80%93nullity_theorem")[#text("rank-nullity theorem")]#text(" for rationals of bounded height).")

#text("The nonstandard approach is very closely related to use of compactness arguments, or of the technique of taking ultralimits and ultraproducts; indeed we will use an ultrafilter in order to create the nonstandard model in the first place.")

#text("I will also discuss a two variants of both Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" and Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text(" which have actually shown up in my research. The first is that of the ")#emph[#text("regularity lemma")]#text(" for polynomials over finite fields, which came up when studying the equidistribution of such polynomials (in ")#link("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/")[#text("this paper with Ben Green")]#text("). The second comes up when is dealing not with a single finite collection ")#mi("{v_1,\\ldots,v_n}")#text(" of vectors, but rather with a ")#emph[#text("family")]#text(" ")#mi("{(v_{h,1},\\ldots,v_{h,n})_{h \\in H}}")#text(" of such vectors, where ")#mi("{H}")#text(" ranges over a large set; this gives rise to what we call the ")#emph[#text("sunflower lemma")]#text(", and came up in this ")#link("https://terrytao.wordpress.com/2009/12/02/an-inverse-theorem-for-the-gowers-u4-norm/")[#text("recent paper of myself, Ben Green, and Tamar Ziegler")]#text(".")

#text("This post is mostly concerned with nonstandard translations of the “rank reduction argument”. Nonstandard translations of the “energy increment argument” and “density increment argument” were briefly discussed in ")#link("https://terrytao.wordpress.com/2009/11/16/nonstandard-analogues-of-energy-and-density-increment-arguments/")[#text("this recent post")]#text("; I may return to this topic in more detail in a future post.")

#metadata(none) <tao-83b4260a776307f3b921>

#heading(level: 1)[#strong[#text(" — 1. Equivalence of Theorems 1 and 2 — ")]]

#text("Both Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" and Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text(" are easy enough to prove. But we will now spend a certain amount of effort in showing that one can deduce each theorem from the other without actually going through the proof of either. This may not seem particularly worthwhile (or to be serious overkill) in the case of these two particular theorems, but the method of deduction is extremely general, and can be used to relate much more deep and difficult infinitary and finitary theorems to each other without a significant increase in effort. (This is closely related to ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("various correspondence principles")]#text(" between combinatorics and parts of infinitary mathematics, such as ergodic theory; see also my ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("post on soft and hard analysis")]#text(" for a closely related equivalence.)")

#text("Let’s first show why the finitary theorem, Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text(", implies Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(". We argue by contradiction. If Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" failed, then we could find a vector space ")#mi("{V}")#text(" over the rationals, and a finite collection ")#mi("{v_1,\\ldots,v_n}")#text(" of vectors, for which ")#emph[#text("no")]#text(" finite subcollection ")#mi("{w_1,\\ldots,w_k}")#text(" of the ")#mi("{v_1,\\ldots,v_n}")#text(" obeyed both the generation property and the linear independence property. In other words, whenever a subcollection ")#mi("{w_1,\\ldots,w_k}")#text(" happened to generate ")#mi("{v_1,\\ldots,v_n}")#text(" by rationals, then it must necessarily contain a linear dependence.")

#text("We use this to create a function ")#mi("{F: {\\mathbb N} \\rightarrow {\\mathbb N}}")#text(" as follows. Given any natural number ")#mi("{M}")#text(", consider all the finite subcollections ")#mi("{w_1,\\ldots,w_k}")#text(" of ")#mi("{v_1,\\ldots,v_n}")#text(" which can generate the ")#mi("{v_1,\\ldots,v_n}")#text(" using rationals of height at most ")#mi("{M}")#text(". By the above hypothesis, all such subcollections contain a linear dependence involving rationals of some finite height. There may be many such dependences; we pick one arbitrarily. We then choose ")#mi("{F(M)}")#text(" to be any natural number larger than the heights of all the rationals involved in all the linear dependencies thus chosen. (Here we implicitly use the fact that there are only finitely many subcollections of the ")#mi("{v_1,\\ldots,v_n}")#text(" to search through.)")

#text("Having chosen this function ")#mi("{F}")#text(", we then apply Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text(" to the vectors ")#mi("{v_1,\\ldots,v_n}")#text(" and this choice of function ")#mi("{F}")#text(", to obtain a subcollection ")#mi("{w_1,\\ldots,w_k}")#text(" which generate the ")#mi("{v_1,\\ldots,v_n}")#text(" using rationals of height at most ")#mi("{M}")#text(", and have no linear dependence involving rationals of height at most ")#mi("{F(M)}")#text(". But this contradicts the construction of ")#mi("{F}")#text(", and gives the claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Note how important it is here that the growth function ")#mi("{F}")#text(" in Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text(" is not specified in advance, but is instead a parameter that can be set to be as “large” as needed. Indeed, for Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text(" for any fixed ")#mi("{F}")#text(" (e.g. exponential, tower-exponential, Ackermann, etc.) gives a statement which is strictly “weaker” than Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" in a sense that I will not try to make precise here; it is only the union of ")#emph[#text("all")]#text(" these statements for ")#emph[#text("all")]#text(" conceivable ")#mi("{F}")#text(" that gives the full strength of Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(". A similar phenomenon occurs with the ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("finite convergence principle")]#text(". It is this “second order” nature of infinitary statements (they quantify not just over numerical parameters such as ")#mi("{N}")#text(" or ")#mi("{\\epsilon}")#text(", but also over functional parameters such as ")#mi("{F}")#text(") that make such statements appear deeper than finitary ones, but the distinction largely disappears if one is willing to perform such second-order quantifications.")
]

#text("Now we turn to the more interesting deduction, which is to obtain Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text(" from Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(". Again, one argues by contradiction. Suppose that Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text(" failed. Carefully negating all the quantifiers (and using the axiom of choice), we conclude that there exists a function ")#mi("{F: {\\mathbb N} \\rightarrow {\\mathbb N}}")#text(" and a natural number ")#mi("{n}")#text(" with the following property: given any natural number ")#mi("{K}")#text(", there exists an abelian group ")#mi("{V_K}")#text(" which is divisible up to height ")#mi("{K}")#text(", and elements ")#mi("{v_{1,K},\\ldots,v_{n,K}}")#text(" in ")#mi("{V_K}")#text(" such that there is ")#emph[#text("no")]#text(" subcollection ")#mi("{w_{1,K},\\ldots,w_{k,K}}")#text(" of the ")#mi("{v_{1,K},\\ldots,v_{n,K}}")#text(", together with an integer ")#mi("{M \\leq K}")#text(", such that ")#mi("{w_{1,K},\\ldots,w_{k,K}}")#text(" generate ")#mi("{v_{1,K},\\ldots,v_{n,K}}")#text(" using rationals of height at most ")#mi("{M}")#text(", and such that the ")#mi("{w_{1,K},\\ldots,w_{k,K}}")#text(" have no linear dependence using rationals of height at most ")#mi("{F(M)}")#text(".")

#text("We now perform an ")#link("http://en.wikipedia.org/wiki/Ultralimit")[#text("ultralimit")]#text(" as ")#mi("{K \\rightarrow \\infty}")#text(". We will not pause here to recall the machinery of ultrafilters, ultralimits, and ultraproducts, but refer the reader instead to ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("this previous blog post of mine")]#text(" for discussion.")

#text("We pick a non-principal ultrafilter ")#mi("{p}")#text(" of the natural numbers. Starting with the “standard” abelian groups ")#mi("{V_K}")#text(", we then form their ")#link("http://en.wikipedia.org/wiki/Ultraproduct")[#text("ultraproduct")]#text(" ")#mi("{V = \\prod_K V_K / p}")#text(", defined as the space of sequences ")#mi("{v = (v_K)_{K \\in {\\mathbb N}}}")#text(" with ")#mi("{v_K \\in V_K}")#text(" for each ")#mi("{K}")#text(", modulo equivalence by ")#mi("{p}")#text("; thus two sequences ")#mi("{v = (v_K)_{K \\in {\\mathbb N}}}")#text(" and ")#mi("{v^{\\prime} = (v^{\\prime}_K)_{K \\in {\\mathbb N}}}")#text(" are considered equal if ")#mi("{v_K = v^{\\prime}_K}")#text(" for a ")#mi("{p}")#text("-large set of ")#mi("{K}")#text(" (i.e. for a set of ")#mi("{K}")#text(" that lies in ")#mi("{p}")#text(").")

#text("Now that non-standard objects are in play, we will need to take some care to distinguish between standard objects (e.g. standard natural numbers) and their nonstandard counterparts.")

#text("Since each of the ")#mi("{V_K}")#text(" are an abelian group, ")#mi("{V}")#text(" is also an abelian group (an easy special case of the ")#link("http://en.wikipedia.org/wiki/Transfer_principle")[#text("transfer principle")]#text("). Since each ")#mi("{V_K}")#text(" is divisible up to height ")#mi("{K}")#text(", ")#mi("{V}")#text(" is divisible up to all (standard) heights; in other words, ")#mi("{V}")#text(" is actually a vector space over the (standard) rational numbers ")#mi("{{\\mathbb Q}}")#text(". The point is that while none of the ")#mi("{V_K}")#text(" are, strictly speaking, vector spaces over ")#mi("{{\\mathbb Q}}")#text(", they increasingly behave as if they were such spaces, and in the limit one recovers genuine vector space structure.")

#text("For each ")#mi("{1 \\leq i \\leq n}")#text(", one can take an ultralimit of the elements ")#mi("{v_{i,K} \\in V_K}")#text(" to generate an element ")#mi("{v_i := (v_{i,K})_{K \\in {\\mathbb N}}}")#text(" of the ultraproduct ")#mi("{V}")#text(". So now we have ")#mi("{n}")#text(" vectors ")#mi("{v_1,\\ldots,v_n}")#text(" of a vector space ")#mi("{V}")#text(" over ")#mi("{{\\mathbb Q}}")#text(" – precisely the setting of Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text("! So we apply that theorem and obtain a subcollection ")#mi("{w_1,\\ldots,w_k \\in V}")#text(" of the ")#mi("{v_1,\\ldots,v_n}")#text(", such that each ")#mi("{v_i}")#text(" can be generated from the ")#mi("{w_1,\\ldots,w_k}")#text(" using (standard) rationals, and such that the ")#mi("{w_1,\\ldots,w_k}")#text(" are linearly independent over the (standard) rationals.")

#text("Since all (standard) rationals have a finite height, one can find a (standard) natural number ")#mi("{M}")#text(" such that each of the ")#mi("{v_i}")#text(" can be generated from the ")#mi("{w_1,\\ldots,w_k}")#text(" using (standard) rationals of height at most ")#mi("{M}")#text(". Undoing the ultralimit, we conclude that for a ")#mi("{p}")#text("-large set of ")#mi("{K}")#text("‘s, all of the ")#mi("{v_{i,K}}")#text(" can be generated from the ")#mi("{w_{1,K},\\ldots,w_{k,K}}")#text(" using rationals of height at most ")#mi("{M}")#text(". But by hypothesis, this implies for all sufficiently large ")#mi("{K}")#text(" in this ")#mi("{p}")#text("-large set, the ")#mi("{w_{1,K},\\ldots,w_{k,K}}")#text(" contain a non-trivial rational dependence of height at most ")#mi("{F(M)}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\frac{a_{1,K}}{q_{1,K}} w_{1,K} + \\ldots + \\frac{a_{k,K}}{q_{k,K}} w_{k,K} = 0")]]

#text("for some integers ")#mi("{a_{i,K},q_{i,K}}")#text(" of magnitude at most ")#mi("{F(M)}")#text(", with the ")#mi("{a_{k,K}}")#text(" not all zero.")

#text("By the pigeonhole principle (and the finiteness of ")#mi("{F(M)}")#text("), each of the ")#mi("{a_{i,K},q_{i,K}}")#text(" is constant in ")#mi("{K}")#text(" on a ")#mi("{p}")#text("-large set of ")#mi("{K}")#text(". So if we take an ultralimit again to go back to the nonstandard world, the quantities ")#mi("{a_i := (a_{i,K})_{K \\in {\\mathbb N}}}")#text(", ")#mi("{q_i := (q_{i,K})_{K \\in {\\mathbb N}}}")#text(" are standard integers (rather than merely nonstandard integers). Thus we have")

#align(center)[#tao-fit-display[#mitex("\\frac{a_{1}}{q_{1}} w_{1} + \\ldots + \\frac{a_{k}}{q_{k}} w_{k} = 0")]]

#text("with the ")#mi("{a_i}")#text(" not all zero, i.e. we have a linear dependence amongst the ")#mi("{w_1,\\ldots,w_k}")#text(". But this contradicts Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. Polynomials over finite fields — ")]]

#text("Let ")#mi("{{\\Bbb F}}")#text(" a fixed finite field (e.g. the field ")#mi("{{\\Bbb F}_2}")#text(" of two elements), and consider a high-dimensional finite vector space ")#mi("{V}")#text(" over ")#mi("{{\\Bbb F}}")#text(". A polynomial ")#mi("{P: {\\Bbb F}^n \\rightarrow {\\Bbb F}}")#text(" of degree ")#mi("{\\leq d}")#text(" can then be defined as a combination of monomials each of degree at most ")#mi("{d}")#text(", or alternatively as a function whose ")#mi("{d+1^{th}}")#text(" derivative vanishes; see ")#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/")[#text("this previous blog post")]#text(" for some discussion of this equivalence.")

#text("We define the ")#emph[#text("rank")]#text(" ")#mi("{rank_{\\leq d-1}(P)}")#text(" of a degree ")#mi("{\\leq d}")#text(" polynomial ")#mi("{P}")#text(" to be the least number ")#mi("{k}")#text(" of degree ")#mi("{\\leq d-1}")#text(" polynomials ")#mi("{Q_1,\\ldots,Q_k}")#text(", such that ")#mi("{P}")#text(" is completely determined by ")#mi("{Q_1,\\ldots,Q_k}")#text(", i.e. ")#mi("{P = f( Q_1,\\ldots,Q_k )}")#text(" for some function ")#mi("{f: {\\Bbb F}^k \\rightarrow {\\Bbb F}}")#text(". In the case when ")#mi("{P}")#text(" has degree ")#mi("{\\leq 2}")#text(", this concept is very close to the familiar ")#link("http://en.wikipedia.org/wiki/Rank_(linear_algebra)")[#text("rank")]#text(" of a quadratic form or matrix.")

#text("A generalisation of the notion of linear independence is that of linear independence modulo low rank. Let us call a collection ")#mi("{P_1,\\ldots,P_n}")#text(" of degree ")#mi("{\\leq d}")#text(" polynomials ")#emph[#mi("{M}")#text("-linearly independent")]#text(" if every non-trivial linear combination ")#mi("{a_1 P_1 + \\ldots + a_n P_n}")#text(" with ")#mi("{a_1,\\ldots,a_n \\in {\\Bbb F}}")#text(" not all zero, has rank at least ")#mi("{M}")#text(":")

#align(center)[#tao-fit-display[#mitex("rank_{\\leq d-1}(a_1 P_1 + \\ldots + a_n P_n) \\leq M.")]]

#text("There is then the following analogue of Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Polynomial regularity lemma at one degree, finitary version)")]#text(" ")#metadata(none) <tao-b0b5ce1a02ba8604d69d>#text(" Let ")#mi("{n,d \\geq 1}")#text(" be integers, let ")#mi("{{\\Bbb F}}")#text(" be a finite field and let ")#mi("{F: {\\mathbb N} \\rightarrow {\\mathbb N}}")#text(" be a function. Let ")#mi("{V}")#text(" be a vector space over ")#mi("{{\\Bbb F}}")#text(", and let ")#mi("{P_1,\\ldots,P_n: V \\rightarrow F}")#text(" be polynomials of degree ")#mi("{\\leq d}")#text(". Then there exists a collection ")#mi("{Q_1,\\ldots,Q_k: V \\rightarrow F}")#text(" of polynomials of degree ")#mi("{\\leq d}")#text(", with ")#mi("{1 \\leq k \\leq n}")#text(", as well an integer ")#mi("{M \\geq 1}")#text(", such that")

#list(
[#text("(Complexity bound) ")#mi("{M \\leq C(F,n,d,{\\Bbb F})}")#text(" for some ")#mi("{C(F,n,d,{\\Bbb F})}")#text(" depending only on ")#mi("{F, n, d, {\\Bbb F}}")#text(".")],
[#text("(")#mi("{Q}")#text(" generates ")#mi("{P}")#text(") Every ")#mi("{P_j}")#text(" can be expressed as a ")#mi("{{\\Bbb F}}")#text("-linear combination of the ")#mi("{Q_1,\\ldots,Q_k}")#text(", plus an error ")#mi("{E}")#text(" which has rank ")#mi("{rank_{\\leq d-1}(E)}")#text(" at most ")#mi("{M}")#text(".")],
[#text("(")#mi("{P}")#text(" independent) There is no non-trivial linear relation ")#mi("{a_1 Q_1 + \\ldots + a_k Q_k = E}")#text(" among the ")#mi("{w_1,\\ldots,w_m}")#text(" in which ")#mi("{E}")#text(" has rank ")#mi("{rank_{\\leq d-1}(E)}")#text(" at most ")#mi("{F(M)}")#text(".")]
)

#text("In fact, one can take ")#mi("{Q_1,\\ldots,Q_k}")#text(" to be a subset of the ")#mi("{P_1,\\ldots,P_n}")#text(".")
]

#text("This theorem can be proven in much the same way as Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text(", and the reader is invited to do so as an exercise. The constant ")#mi("{C(F,n,d,{\\Bbb F})}")#text(" can in fact be taken to be independent of ")#mi("{d}")#text(" and ")#mi("{{\\Bbb F}}")#text(", but this is not important to us here.")

#text("Roughly speaking, Theorem ")#link(<tao-b0b5ce1a02ba8604d69d>)[#text("3")]#text(" asserts that a finite family of degree ")#mi("{\\leq d}")#text(" polynomials can be expressed as a linear combination of degree ")#mi("{\\leq d}")#text(" polynomials which are “linearly independent modulo low rank errors”, plus some lower rank objects. One can think of this as ")#emph[#text("regularising")]#text(" the degree ")#mi("{\\leq d}")#text(" polynomials, modulo combinations of lower degree polynomials. For applications (and in particular, for understanding the equidistribution) one also needs to regularise the degree ")#mi("{\\leq d-1}")#text(" polynomials that arise this way, and so forth for increasingly lower degrees until all polynomials are regularised. (A similar phenomenon occurs for the hypergraph regularity lemma.)")

#text("When working with theorems like this, it is helpful to think conceptually of “quotienting out” by all polynomials of low rank. Unfortunately, in the finitary setting, the polynomials of low rank do not form a group, and so the quotient is ill-defined. However, this can be rectified by passing to the infinitary setting. Indeed, once one does so, one can quotient out the low rank polynomials, and Theorem ")#link(<tao-b0b5ce1a02ba8604d69d>)[#text("3")]#text(" follows directly from Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" (or more precisely, the analogue of that theorem in which the field of rationals ")#mi("{{\\mathbb Q}}")#text(" is replaced by the finite field ")#mi("{{\\Bbb F}}")#text(").")

#text("Let’s see how this works. To prove Theorem ")#link(<tao-b0b5ce1a02ba8604d69d>)[#text("3")]#text(", suppose for contradiction that the theorem failed. Then one can find ")#mi("{F, n, d, {\\Bbb F}}")#text(", such that for every natural ")#mi("{K}")#text(", one can find a vector space ")#mi("{V_K}")#text(" and polynomials ")#mi("{P_{1,K},\\ldots,P_{n,K}: V_K \\rightarrow {\\Bbb F}}")#text(" of degree ")#mi("{\\leq d}")#text(", for which there do not exist polynomials ")#mi("{Q_{1,K},\\ldots,Q_{k,K}}")#text(" with ")#mi("{k \\leq n}")#text(" and an integer ")#mi("{M \\leq K}")#text(" such that each ")#mi("{P_{j,K}}")#text(" can be expressed as a linear combination of the ")#mi("{Q_{i,K}}")#text(" modulo an error of rank at most ")#mi("{M}")#text(", and such that there are no nontrivial linear relations amongst the ")#mi("{Q_{i,K}}")#text(" modulo errors of rank at most ")#mi("{F(M)}")#text(".")

#text("Taking an ultralimit as before, we end up with a (nonstandard) vector space ")#mi("{V}")#text(" over ")#mi("{{\\Bbb F}}")#text(" (which is likely to be infinite), and (nonstandard) polynomials ")#mi("{P_1,\\ldots,P_n: V \\rightarrow {\\Bbb F}}")#text(" of degree ")#mi("{\\leq d}")#text(" (here it is best to use the “local” definition of a polynomial of degree ")#mi("{\\leq d}")#text(", as a (nonstandard) function whose ")#mi("{d+1^{th}}")#text(" derivative, but one can also view this as a (nonstandard) sum of monomials if one is careful).")

#text("The space ")#mi("{Poly_{\\leq d}( V )}")#text(" of (nonstandard) degree ")#mi("{\\leq d}")#text(" polynomials on ")#mi("{V}")#text(" is a (nonstandard) vector space over ")#mi("{{\\Bbb F}}")#text(". Inside this vector space, one has the subspace ")#mi("{Lowrank_{\\leq d}(V)}")#text(" consisting of all polynomials ")#mi("{P \\in Poly_{\\leq d}(V)}")#text(" whose rank ")#mi("{rank_{\\leq d-1}(V)}")#text(" is a standard integer (as opposed to a nonstandard integer); call these the ")#emph[#text("bounded rank")]#text(" polynomials. This is easily seen to be a subspace of ")#mi("{Poly_{\\leq d}(V)}")#text(" (although it is not a ")#emph[#text("nonstandard")]#text(" or ")#emph[#text("internal")]#text(" subspace, i.e. the ultralimit of subspaces of the ")#mi("{Poly_{\\leq d}( V_K )}")#text("). As such, one can rigorously form the quotient space ")#mi("{Poly_{\\leq d}(V) / Lowrank_{\\leq d}(V)}")#text(" of degree ")#mi("{\\leq d}")#text(" polynomials, modulo bounded rank ")#mi("{\\leq d}")#text(" polynomials.")

#text("The polynomials ")#mi("{P_1,\\ldots,P_n}")#text(" then have representatives ")#mi("{P_1,\\ldots,P_n \\text{ mod } Lowrank_{\\leq d}(V)}")#text(" in this quotient space. Applying Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" (for the field ")#mi("{{\\Bbb F}}")#text("), one can then find a subcollection ")#mi("{Q_1,\\ldots,Q_k \\text{ mod } Lowrank_{\\leq d}(V)}")#text(" which are linearly independent in this space, which generate ")#mi("{P_1,\\ldots,P_n}")#text(". Undoing the quotient, we see that the ")#mi("{P_1,\\ldots,P_n}")#text(" are linear combinations of the ")#mi("{Q_1,\\ldots,Q_k}")#text(" plus a bounded rank error, while no nontrivial linear combination of ")#mi("{Q_1,\\ldots,Q_k}")#text(" has bounded rank. Undoing the ultralimit as in the previous section, we obtain the desired contradiction.")

#text("We thus see that in the nonstandard world, the somewhat nonrigorous concepts of “low rank” and “high rank” can be formalised as that of “bounded rank” and “unbounded rank”. Furthermore, the former space forms a subspace, so in the nonstandard world one can rigorously talk about “quotienting out by bounded rank errors”. Thus we see that the algebraic machinery of quotient spaces can be applied in the nonstandard world directly, whereas in the finitary world it can only be applied heuristically. In principle, one could also start deploying more advanced tools of abstract algebra (e.g. exact sequences, cohomology, etc.) in the nonstandard setting, although this has not yet seriously begun to happen in additive combinatorics (although there are strong hints of some sort of “additive cohomology” emerging in the body of work surrounding the inverse conjecture for the Gowers norm, especially on the ergodic theory side of things).")

#heading(level: 1)[#strong[#text(" — 3. Sunflowers — ")]]

#text("Now we return to vector spaces (or approximate vector spaces) ")#mi("{V}")#text(" over the rationals, such as ")#mi("{V = {\\mathbb Z}/p{\\mathbb Z}}")#text(" for a large prime ")#mi("{p}")#text(". Instead of working with a single (small) tuple ")#mi("{v_1,\\ldots,v_n}")#text(" of vectors in ")#mi("{V}")#text(", we now consider a ")#emph[#text("family")]#text(" ")#mi("{(v_{1,h},\\ldots,v_{n,h})_{h \\in H}}")#text(" of such vectors in ")#mi("{V}")#text(", where ")#mi("{H}")#text(" ranges over a large set, for instance a dense subset of the interval ")#mi("{X := [-N,N] = \\{-N,\\ldots,N\\}}")#text(" for some large ")#mi("{N}")#text(". This situation happens to show up in our recent work on the inverse conjecture for the Gowers norm, where the ")#mi("{v_{1,h},\\ldots,v_{n,h}}")#text(" represent the various “frequencies” that arise in a derivative ")#mi("{\\Delta_h f}")#text(" of a function ")#mi("{f}")#text(" with respect to the shift ")#mi("{h}")#text(". (This need to consider families is an issue that also comes up in the ")#link("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/")[#text("finite field ergodic theory analogue")]#text(" of the inverse conjectures, due to the unbounded number of generators in that case, but interestingly does not arise in the ergodic theory over ")#mi("{{\\mathbb Z}}")#text(".)")

#text("In Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text(", the main distinction was between linear dependence and linear independence of the tuple ")#mi("{v_{1},\\ldots,v_{n}}")#text(" (or some reduction of this tuple, such as ")#mi("{w_1,\\ldots,w_k}")#text("). We will continue to be interested in the linear dependence or independence of the tuples ")#mi("{v_{1,h},\\ldots,v_{n,h}}")#text(" for various ")#mi("{h}")#text(". But we also wish to understand how the ")#mi("{v_{i,h}}")#text(" vary with ")#mi("{h}")#text(" as well. At one extreme (the “structured” case), there is no dependence on ")#mi("{h}")#text(": ")#mi("{v_{i,h} = v_i}")#text(" for all ")#mi("{i}")#text(" and all ")#mi("{h}")#text(". At the other extreme (the “pseudorandom” case), the ")#mi("{v_{i,h}}")#text(" are basically independent as ")#mi("{h}")#text(" varies; in particular, for (almost) all of the pairs ")#mi("{h, h^{\\prime} \\in H}")#text(", the tuples ")#mi("{v_{1,h},\\ldots,v_{n,h}}")#text(" and ")#mi("{v_{1,h^{\\prime}},\\ldots,v_{n,h^{\\prime}}}")#text(" are not just separately independent, but are ")#emph[#text("jointly")]#text(" independent. One can think of ")#mi("{v_{1,h},\\ldots,v_{n,h}}")#text(" and ")#mi("{v_{1,h^{\\prime}},\\ldots,v_{n,h^{\\prime}}}")#text(" as being in “general position” relative to each other.")

#text("The ")#emph[#text("sunflower lemma")]#text(" asserts that any family ")#mi("{(v_{1,h},\\ldots,v_{n,h})_{h \\in H}}")#text(" is basically a combination of the above scenarios, thus one can divide the family into a linearly independent ")#emph[#text("core")]#text(" collection of vectors ")#mi("{(w_1,\\ldots,w_m)}")#text(" that do not depend on ")#mi("{h}")#text(", together with ")#emph[#text("petals")]#text(" ")#mi("{(v^{\\prime}_{1,h},\\ldots,v^{\\prime}_{k,h})_{h \\in H^{\\prime}}}")#text(", which are in “general position” in the above sense, relative to the core. However, as a price one pays for this, one has to refine ")#mi("{H}")#text(" to a dense subset ")#mi("{H^{\\prime}}")#text(" of ")#mi("{H}")#text(". This lemma, which significantly generalises Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text(", is formalised as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Sunflower lemma, finitary version)")]#text(" ")#metadata(none) <tao-27756f050e14a1cb1c1e>#text(" Let ")#mi("{n \\geq 1}")#text(" be an integer, and let ")#mi("{F: {\\mathbb N} \\rightarrow {\\mathbb N}}")#text(" be a function. Let ")#mi("{V}")#text(" be an abelian group which admits a well-defined division operation by any natural number of size at most ")#mi("{C(F,n)}")#text(" for some constant ")#mi("{C(F,n)}")#text(" depending only on ")#mi("{F,n}")#text(". Let ")#mi("{H}")#text(" be a finite set, and let ")#mi("{(v_{1,h},\\ldots,v_{n,h})_{h \\in H}}")#text(" be a collection of ")#mi("{n}")#text("-tuples of vectors in ")#mi("{V}")#text(" indexed by ")#mi("{H}")#text(". Then there exists a subset ")#mi("{H^{\\prime}}")#text(" of ")#mi("{H}")#text(", integers ")#mi("{k,m \\geq 0}")#text(" with ")#mi("{m+k \\leq n}")#text(", a collection ")#mi("{w_1,\\ldots,w_m}")#text(" of “core” vectors in ")#mi("{V}")#text(" for some ")#mi("{m}")#text(", a collection of “petal” vectors ")#mi("{(v^{\\prime}_{1,h},\\ldots,v^{\\prime}_{k,h})_{h \\in H^{\\prime}}}")#text(" for each ")#mi("{h \\in H^{\\prime}}")#text(", as well an integer ")#mi("{M \\geq 1}")#text(", such that")

#list(
[#text("(Complexity bound) ")#mi("{M \\leq C(F,n)}")#text(" for some ")#mi("{C(F,n)}")#text(" depending only on ")#mi("{F, n}")#text(".")],
[#text("(")#mi("{H^{\\prime}}")#text(" dense) one has ")#tao-math("{\\left|H^{\\prime}\\right| \\geq c(F,n) \\left|H\\right|}", block: false)#text(" for some ")#mi("{c(F,n) > 0}")#text(" depending only on ")#mi("{F, n}")#text(".")],
[#text("(")#mi("{w, v^{\\prime}}")#text(" generates ")#mi("{v}")#text(") Every ")#mi("{v_{j,h}}")#text(" with ")#mi("{1 \\leq j \\leq n}")#text(" and ")#mi("{h \\in H^{\\prime}}")#text(" can be expressed as a rational linear combination of the ")#mi("{w_1,\\ldots,w_m}")#text(" and ")#mi("{v^{\\prime}_{1,h},\\ldots,v^{\\prime}_{k,h}}")#text(" of height at most ")#mi("{M}")#text(".")],
[#text("(")#mi("{w}")#text(" independent) There is no non-trivial rational linear relation among the ")#mi("{w_1,\\ldots,w_m}")#text(" of height at most ")#mi("{F(M)}")#text(".")],
[#text("(")#mi("{v^{\\prime}}")#text(" in general position relative to ")#mi("{w}")#text(") More generally, for ")#mi("{1-\\frac{1}{F(M)}}")#text(" of the pairs ")#mi("{(h,h^{\\prime}) \\in H^{\\prime} \\times H^{\\prime}}")#text(", there is no non-trivial linear relation among ")#mi("{w_1,\\ldots,w_m, v^{\\prime}_{1,h},\\ldots,v^{\\prime}_{k,h},v^{\\prime}_{1,h^{\\prime}},\\ldots,v^{\\prime}_{k,h^{\\prime}}}")#text(" of height at most ")#mi("{F(M)}")#text(".")]
)
]

#text("One can take the ")#mi("{v^{\\prime}_{1,h},\\ldots,v^{\\prime}_{k,h}}")#text(" to be a subcollection of the ")#mi("{v_{1,h},\\ldots,v_{n,h}}")#text(", though this is not particularly useful in applications.")

#emph[#text("Proof:")]#text(" We perform a two-parameter “rank reduction argument”, where the rank is indexed by the pair ")#mi("{(k,m)}")#text(" (ordered lexicographically). We initially set ")#mi("{m=0}")#text(", ")#mi("{k=n}")#text(", ")#mi("{H^{\\prime}=H}")#text(", ")#mi("{M=1}")#text(", and ")#mi("{v^{\\prime}_{i,h} = v_{i,h}}")#text(" for ")#mi("{h \\in H}")#text(".")

#text("At each stage of the iteration, ")#mi("{w, v^{\\prime}}")#text(" will generate ")#mi("{v}")#text(" (at height ")#mi("{M}")#text("), and we will have some complexity bound on ")#mi("{M, m}")#text(" and some density bound on ")#mi("{H^{\\prime}}")#text(". So one needs to check the independence of ")#mi("{w}")#text(" and the general position of ")#mi("{v^{\\prime}}")#text(" relative to ")#mi("{w}")#text(".")

#text("If there is a linear relation of ")#mi("{w}")#text(" at height ")#mi("{F(M)}")#text(", then one can use this to reduce the size ")#mi("{m}")#text(" of the core by one, leaving the petal size ")#mi("{k}")#text(" unchanged, just as in the proof of Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text(". So let us move on, and suppose that there is no linear relation of ")#mi("{w}")#text(" at height ")#mi("{F(M)}")#text(", but instead there is a failure of the general position hypothesis. In other words, for at least ")#tao-math("{\\left|H^{\\prime}\\right|^2 / F(M)}", block: false)#text(" pairs ")#mi("{(h,h^{\\prime}) \\in H^{\\prime} \\times H^{\\prime}}")#text(", one can find a relation of the form")

#align(center)[#tao-fit-display[#mitex("a_{1,h,h^{\\prime}} w_1 + \\ldots + a_{m,h,h^{\\prime}} w_m + b_{1,h,h^{\\prime}} v^{\\prime}_{1,h} + \\ldots + b_{k,h,h^{\\prime}} v^{\\prime}_{k,h} + c_{1,h,h^{\\prime}} v^{\\prime}_{1,h^{\\prime}} + \\ldots + c_{k,h,h^{\\prime}} v^{\\prime}_{k,h^{\\prime}} = 0")]]

#text("where the ")#mi("{a_{i,h,h^{\\prime}},b_{i,h,h^{\\prime}},c_{i,h,h^{\\prime}}}")#text(" are rationals of height at most ")#mi("{F(M)}")#text(", not all zero. The number of possible values for such rationals is bounded by some quantity depending on ")#mi("{m,k,F(M)}")#text(". Thus, by the pigeonhole principle, we can find ")#tao-math("{\\gg_{F(M),m,k} \\left|H^{\\prime}\\right|^2}", block: false)#text(" pairs (i.e. at least ")#tao-math("{c(F(M),m,k) \\left|H^{\\prime}\\right|^2}", block: false)#text(" pairs for some ")#mi("{c(F(M),m,k)>0}")#text(" depending only on ")#mi("{F(M),m,k}")#text(") such that")

#align(center)[#tao-fit-display[#mitex("a_{1} w_1 + \\ldots + a_{m} w_m + b_{1} v^{\\prime}_{1,h} + \\ldots + b_{k} v^{\\prime}_{k,h} + c_{1} v^{\\prime}_{1,h^{\\prime}} + \\ldots + c_{k} v^{\\prime}_{k,h^{\\prime}} = 0")]]

#text("for some fixed rationals ")#mi("{a_i,b_i,c_i}")#text(" of height at most ")#mi("{F(M)}")#text(". By the pigeonhole principle again, we can then find a fixed ")#mi("{h_0 \\in H^{\\prime}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("a_{1} w_1 + \\ldots + a_{m} w_m + b_{1} v^{\\prime}_{1,h} + \\ldots + b_{k} v^{\\prime}_{k,h} = u_{h_0}")]]

#text("for all ")#mi("{h}")#text(" in some subset ")#mi("{H^{\\prime\\prime}}")#text(" of ")#mi("{H^{\\prime}}")#text(" with ")#tao-math("{\\left|H^{\\prime\\prime}\\right| \\gg_{F(M),m,k} \\left|H^{\\prime}\\right|}", block: false)#text(", where")

#align(center)[#tao-fit-display[#mitex("u_{h_0} := - c_{1} v^{\\prime}_{1,h_0} - \\ldots - c_{k} v^{\\prime}_{k,h_0}.")]]

#text("If the ")#mi("{b_i}")#text(" and ")#mi("{c_i}")#text(" all vanished then we would have a linear dependence amongst the core vectors, which we already know how to deal with. So suppose that we have at least one active petal coefficient, say ")#mi("{b_k}")#text(". Then upon rearranging, we can express ")#mi("{v^{\\prime}_{k,h}}")#text(" as some rational linear combination of the original core vectors ")#mi("{w_1,\\ldots,w_m}")#text(", a new core vector ")#mi("{u_{h_0}}")#text(", and the other petals ")#mi("{v^{\\prime}_{1,h},\\ldots,v^{\\prime}_{k-1,h}}")#text(", with heights bounded by ")#mi("{\\ll_{F(M),k,m} 1}")#text(". We may thus refine ")#mi("{H^{\\prime}}")#text(" to ")#mi("{H^{\\prime\\prime}}")#text(", delete the petal vector ")#mi("{v^{\\prime}_{k,h}}")#text(", and add the vector ")#mi("{u}")#text(" to the core, thus decreasing ")#mi("{k}")#text(" by one and increasing ")#mi("{m}")#text(" by one. One still has the generation property so long as one replaces ")#mi("{M}")#text(" with a larger ")#mi("{M^{\\prime}}")#text(" depending on ")#mi("{M, F(M), k, m}")#text(".")

#text("Since each iteration of this process either reduces ")#mi("{m}")#text(" by one keeping ")#mi("{k}")#text(" fixed, or reduces ")#mi("{k}")#text(" by one increasing ")#mi("{m}")#text(", we see that after at most ")#mi("{2n}")#text(" steps, the process must terminate, when we have both the linear independence of the ")#mi("{w}")#text(" property and the general position of the ")#mi("{v^{\\prime}}")#text(" property. (Note here that we are basically performing a ")#link("http://en.wikipedia.org/wiki/Infinite_descent")[#text("proof by infinite descent")]#text(".) At that stage, one easily verifies that we have obtained all the required conclusions of the theorem. ")#mi("\\Box")

#text("As one can see, this result is a little bit trickier to prove than Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text(". Let us now see how it will translate to the nonstandard setting, and see what the nonstandard analogue of Theorem ")#link(<tao-27756f050e14a1cb1c1e>)[#text("5")]#text(" is. We will skip some details, and get to the point where we can motivate and prove this nonstandard analogue; this analogue does in fact imply Theorem ")#link(<tao-27756f050e14a1cb1c1e>)[#text("5")]#text(" by repeating the arguments from previous sections, but we will leave this as an exercise for the interested reader.")

#text("As before, the starting point is to introduce a parameter ")#mi("{K}")#text(", so that the approximate vector space ")#mi("{V_K}")#text(" now depends on ")#mi("{K}")#text(" (and becomes an actual vector space in the ultralimit ")#mi("{V}")#text("), and the parameter set ")#mi("{H_K}")#text(" now also depends on ")#mi("{K}")#text(". We will think of ")#tao-math("{\\left|H_K\\right|}", block: false)#text(" as going to infinity as ")#mi("{K \\rightarrow \\infty}")#text(", as this is the most interesting case (for bounded ")#mi("{H_K}")#text(", the result basically collapses back to Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text("). In that case, the ultralimit ")#mi("{H}")#text(" of the ")#mi("{H_K}")#text(" is a nonstandard finite set (i.e. an ultralimit of finite sets) whose (nonstandard) cardinality ")#tao-math("{\\left|H\\right|}", block: false)#text(" is an ")#emph[#text("unbounded")]#text(" nonstandard integer: it is a nonstandard integer (indeed, it is the ultralimit of the ")#tao-math("{\\left|H_K\\right|}", block: false)#text(") which is larger than any standard integer. On the other hand, ")#mi("{n}")#text(" and ")#mi("{F}")#text(" remain standard (i.e. they do not involve ")#mi("{K}")#text(").")

#text("For each ")#mi("{K}")#text(", one starts with a family ")#mi("{(v_{1,h,K},\\ldots,v_{n,h,K})_{h \\in H_K}}")#text(" of ")#mi("{n}")#text("-tuples of vectors in ")#mi("{V_K}")#text(". Taking ultralimits, one ends up with a family ")#mi("{(v_{1,h},\\ldots,v_{n,h})_{h \\in H}}")#text(" of ")#mi("{n}")#text("-tuples of vectors in ")#mi("{V}")#text(". Furthermore, for each ")#mi("{1 \\leq i \\leq n}")#text(", the maps ")#mi("{h \\mapsto v_{i,h}}")#text(" are ")#emph[#text("nonstandard")]#text(" (or ")#emph[#text("internal")]#text(") functions from ")#mi("{H}")#text(" to ")#mi("{V}")#text(", i.e. they are ultralimits of maps from ")#mi("{H_K}")#text(" to ")#mi("{V_K}")#text(". The internal nature of these maps (which is a kind of “measurability” condition on these functions) will be important later. Of course, ")#mi("{H}")#text(" and ")#mi("{V}")#text(" are also internal (being ultralimits of ")#mi("{H_K}")#text(" and ")#mi("{V_K}")#text(" respectively).")

#text("We say that a subset ")#mi("{H^{\\prime}}")#text(" of ")#mi("{H}")#text(" is ")#emph[#text("dense")]#text(" if it is an internal subset (i.e. it is the ultralimit of some subsets ")#mi("{H^{\\prime}_K}")#text(" of ")#mi("{H_K}")#text("), and if ")#tao-math("{\\left|H^{\\prime}\\right| \\geq \\epsilon \\left|H\\right|}", block: false)#text(" for some standard ")#mi("{\\epsilon > 0}")#text(" (recall that ")#tao-math("{\\left|H^{\\prime}\\right|, \\left|H\\right|}", block: false)#text(" are nonstandard integers). If an internal subset is not dense, we say that it is ")#emph[#text("sparse")]#text(", which in ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("nonstandard asymptotic notation")]#text(" is equivalent to ")#tao-math("{\\left|H^{\\prime}\\right|=o(\\left|H\\right|)}", block: false)#text(". If a statement ")#mi("{P(h)}")#text(" holds on all ")#mi("{h}")#text(" in dense set of ")#mi("{H}")#text(", we say that it holds for ")#emph[#text("many")]#text(" ")#mi("{h}")#text("; if it holds for all ")#mi("{h}")#text(" outside of a sparse set, we say it holds for ")#emph[#text("almost all")]#text(" ")#mi("{h}")#text(". These are analogous to the more familiar concepts of “holding with positive probability” and “holding almost surely” in probability theory. For instance, if ")#mi("{P(h)}")#text(" holds for many ")#mi("{h}")#text(" in ")#mi("{H}")#text(", and ")#mi("{Q(h)}")#text(" holds for almost all ")#mi("{h}")#text(" in ")#mi("{H}")#text(", then ")#mi("{P(h)}")#text(" and ")#mi("{Q(h)}")#text(" jointly hold for many ")#mi("{h}")#text(" in ")#mi("{H}")#text(". Note how all the epsilons have been neatly hidden away in this nonstandard framework.")

#text("Now we state the nonstandard analogue of Theorem ")#link(<tao-27756f050e14a1cb1c1e>)[#text("5")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Sunflower lemma, nonstandard version)")]#text(" ")#text(" Let ")#mi("{n \\geq 1}")#text(" be a (standard) integer, let ")#mi("{V}")#text(" be a (nonstandard) vector space over the standard rationals ")#mi("{{\\mathbb Q}}")#text(", and let ")#mi("{H}")#text(" be a (nonstandard) set. Let ")#mi("{(v_{1,h},\\ldots,v_{n,h})_{h \\in H}}")#text(" be a collection of ")#mi("{n}")#text("-tuples of vectors in ")#mi("{V}")#text(" indexed by ")#mi("{H}")#text(", such that all the maps ")#mi("{h \\mapsto v_{i,h}}")#text(" for ")#mi("{1 \\leq i \\leq n}")#text(" are internal. Then there exists a dense subset ")#mi("{H^{\\prime}}")#text(" of ")#mi("{H}")#text(", a bounded-dimensional subspace ")#mi("{W}")#text(" of ")#mi("{V}")#text(", a (standard) integer ")#mi("{k \\geq 0}")#text(" with ")#mi("{\\dim(W) + k \\leq n}")#text(", and a collection of “petal” vectors ")#mi("{(v^{\\prime}_{1,h},\\ldots,v^{\\prime}_{k,h})_{h \\in H^{\\prime}}}")#text(" for each ")#mi("{h \\in H^{\\prime}}")#text(", with the maps ")#mi("{h \\mapsto v^{\\prime}_{i,h}}")#text(" being internal for all ")#mi("{1 \\leq i \\leq k}")#text(", such that")

#list(
[#text("(")#mi("{W, v^{\\prime}}")#text(" generates ")#mi("{v}")#text(") Every ")#mi("{v_{j,h}}")#text(" with ")#mi("{1 \\leq j \\leq n}")#text(" and ")#mi("{h \\in H^{\\prime}}")#text(" lies in the span of ")#mi("{W}")#text(" and the ")#mi("{v^{\\prime}_{1,h},\\ldots,v^{\\prime}_{k,h}}")#text(".")],
[#text("(")#mi("{v^{\\prime}}")#text(" in general position relative to ")#mi("{W}")#text(") For almost all of the pairs ")#mi("{(h,h^{\\prime}) \\in H^{\\prime} \\times H^{\\prime}}")#text(", the vectors ")#mi("{v^{\\prime}_{1,h},\\ldots,v^{\\prime}_{k,h},v^{\\prime}_{1,h^{\\prime}},\\ldots,v^{\\prime}_{k,h^{\\prime}}}")#text(" are linearly independent modulo ")#mi("{W}")#text(" over ")#mi("{{\\mathbb Q}}")#text(".")]
)
]

#text("Of course, using Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" one could obtain a basis ")#mi("{w_1,\\ldots,w_m}")#text(" for ")#mi("{W}")#text(" with ")#mi("{m = \\dim(W)}")#text(", at which point the theorem more closely resembles Theorem ")#link(<tao-27756f050e14a1cb1c1e>)[#text("5")]#text(".")

#emph[#text("Proof:")]#text(" Define a ")#emph[#text("partial representation")]#text(" of the family ")#mi("{(v_{1,h},\\ldots,v_{n,h})}")#text(" to be a dense subset ")#mi("{H^{\\prime}}")#text(" of ")#mi("{H}")#text(", a bounded dimensional space ")#mi("{W}")#text(", a standard integer ")#mi("{k}")#text(" with ")#mi("{\\dim(W)+k \\leq n}")#text(", and a collection of ")#mi("{(v^{\\prime}_{1,h},\\ldots,v^{\\prime}_{k,h})_{h \\in H^{\\prime}}}")#text(" depending internally on ")#mi("{h}")#text(" that obeys the generation property (but not necessarily the general position property). Clearly we have at least one partial representation, namely the trivial one where ")#mi("{W}")#text(" is empty, ")#mi("{k=n}")#text(", ")#mi("{H^{\\prime} := H}")#text(", and ")#mi("{v^{\\prime}_{i,h} := v_{i,h}}")#text(". Now, among all such partial representations, let us take a representation with the minimal value of ")#mi("{k}")#text(". (Here we are of course using the ")#link("http://en.wikipedia.org/wiki/Well-ordering_principle")[#text("well-ordering property")]#text(" of the standard natural numbers.) We claim that this representation enjoys the general position property, which will give the claim.")

#text("Indeed, suppose this was not the case. Then, for many pairs ")#mi("{(h,h^{\\prime}) \\in H^{\\prime} \\times H^{\\prime}}")#text(", the vectors ")#mi("{v^{\\prime}_{1,h},\\ldots,v^{\\prime}_{k,h},v^{\\prime}_{1,h^{\\prime}},\\ldots,v^{\\prime}_{k,h^{\\prime}}}")#text(" have a linear dependence modulo ")#mi("{W}")#text(" over ")#mi("{{\\mathbb Q}}")#text(". (Actually, there is a technical “measurability” issue to address here, which I will return to later.) By symmetry and pigeonholing, we may assume that the ")#mi("{v^{\\prime}_{k,h}}")#text(" coefficient of (say) of this dependence is non-zero. (Again, there is a measurability issue here.) Applying the pigeonhole principle, one can find ")#mi("{h_0 \\in H^{\\prime}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("v^{\\prime}_{1,h},\\ldots,v^{\\prime}_{k,h},v^{\\prime}_{1,h_0},\\ldots,v^{\\prime}_{k,h_0}")]]

#text("have a linear dependence over ")#mi("{{\\mathbb Q}}")#text(" modulo ")#mi("{W}")#text(" for many ")#mi("{h}")#text(". (Again, there is a measurability issue here.)")

#text("Fix ")#mi("{h_0}")#text(". The number of possible linear combinations of ")#mi("{v^{\\prime}_{1,h_0},\\ldots,v^{\\prime}_{k,h_0}}")#text(" is countable. Because of this (and using a “countable pigeonhole principle”) that I will address below), we can find a ")#emph[#text("fixed")]#text(" rational linear combination ")#mi("{u_{h_0}}")#text(" of the ")#mi("{v^{\\prime}_{1,h_0},\\ldots,v^{\\prime}_{k,h_0}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("v^{\\prime}_{1,h},\\ldots,v^{\\prime}_{k,h}, u_{h_0}")]]

#text("have a linear dependence over ")#mi("{{\\mathbb Q}}")#text(" modulo ")#mi("{W}")#text(" for all ")#mi("{h}")#text(" in some dense subset ")#mi("{H^{\\prime\\prime}}")#text(" of ")#mi("{H^{\\prime}}")#text(". But now one can pass from ")#mi("{H^{\\prime}}")#text(" to the dense subset ")#mi("{H^{\\prime\\prime}}")#text(", delete the petal ")#mi("{v^{\\prime}_{k,h}}")#text(", and add the vector ")#mi("{u_{h_0}}")#text(" to the core space ")#mi("{W}")#text(", thus creating a partial representation with a smaller value of ")#mi("{k}")#text(", contradicting minimality, and we are done. ")#mi("\\Box")

#text("We remark here that whereas the finitary analogue of this result was proven using the method of infinite descent, the nonstandard version could instead be proven using the (equivalent) well-ordering principle. One could easily recast the nonstandard version in descent form also, but it is somewhat more difficult to cast the finitary argument using well-ordering due to the extra parameters and quantifiers in play.")

#text("Let us now address the measurability issues. The main problem here is that the property of having a linear dependence over the standard rationals ")#mi("{{\\mathbb Q}}")#text(" is not an internal property, because it requires knowledge of what the standard rationals are, which is not an internal concept in the language of vector spaces. However, for each fixed choice of rational coefficients, the property of having a specific linear dependence with those selected coefficients ")#emph[#text("is")]#text(" an internal concept (here we crucially rely on the hypothesis that the maps ")#mi("{h \\mapsto v_{i,h}}")#text(" were internal), so really what we have here is a sort of “")#mi("{\\sigma}")#text("-internal” property (a countable union of internal properties). But this is good enough for many purposes. In particular, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Countable pigeonhole principle)")]#text(" Let ")#mi("{H}")#text(" be a nonstandardly finite set (i.e. the ultralimit of finite sets ")#mi("{H_K}")#text("), and for each standard natural number ")#mi("{n}")#text(", let ")#mi("{E_n}")#text(" be an internal subset of ")#mi("{H}")#text(". Then one of the following holds:")

#list(
[#text("(Positive density) There exists a natural number ")#mi("{n}")#text(" such that ")#mi("{h \\in E_n}")#text(" for many ")#mi("{h \\in H}")#text(" (i.e. ")#mi("{E_n}")#text(" is a dense subset of ")#mi("{H}")#text(").")],
[#text("(Zero density) For almost all ")#mi("{h \\in H}")#text(", one has ")#mi("{h \\not \\in E_n}")#text(" for all ")#mi("{n}")#text(". (In other words, the (external) set ")#mi("{\\bigcup_{n \\in {\\mathbb N}} E_n}")#text(" in is contained in a sparse subset of ")#mi("{H}")#text(".)")]
)
]

#text("This lemma is sufficient to resolve all the measurability issues raised in the previous proof. It is analogous to the trivial statement in measure theory that given a countable collection of measurable subsets of a space of positive measure, either one of the measurable sets has positive measure, or else their union has measure zero (i.e. the sets fail to cover almost all of the space).")

#emph[#text("Proof:")]#text(" If any of the ")#mi("{E_n}")#text(" are dense, we are done. So suppose this is not the case. Since ")#mi("{E_n}")#text(" is a definable subset of ")#mi("{H}")#text(" which is not dense, it is sparse, thus ")#tao-math("{\\left|E_n\\right| = o(\\left|H\\right|)}", block: false)#text(". Now it is convenient to undo the ultralimit and work in the finite sets ")#mi("{H_K}")#text(" that ")#mi("{H}")#text(" is the ultralimit of. Note that each ")#mi("{E_n}")#text(", being internal, is also an ultralimit of some finite subsets ")#mi("{E_{n,K}}")#text(" of ")#mi("{H_K}")#text(".")

#text("For each standard integer ")#mi("{M > 0}")#text(", the set ")#mi("{E_1 \\cup \\ldots \\cup E_M}")#text(" is sparse in ")#mi("{H}")#text(", and in particular has density less than ")#mi("{1/M}")#text(". Thus, one can find a ")#mi("{p}")#text("-large set ")#mi("{S_M \\subset {\\mathbb N}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|E_{1,K} \\cup \\ldots \\cup E_{M,K}\\right| \\leq \\left|H_K\\right|/M", block: true)]]

#text("for all ")#mi("{K \\in S_M}")#text(". One can arrange matters so that the ")#mi("{S_M}")#text(" are decreasing in ")#mi("{M}")#text(". One then sets the set ")#mi("{E_K}")#text(" to equal ")#mi("{E_{1,K} \\cup \\ldots \\cup E_{M,K}}")#text(", where ")#mi("{M}")#text(" is the smallest integer for which ")#mi("{K \\in S_M}")#text(" (or ")#mi("{E_K}")#text(" is empty if ")#mi("{K}")#text(" lies in all the ")#mi("{S_M}")#text(", or in none), and let ")#mi("{E}")#text(" be the ultralimit of the ")#mi("{E_K}")#text(". Then we see that ")#tao-math("{\\left|E\\right| \\leq \\left|H\\right|/M}", block: false)#text(" for every standard ")#mi("{M}")#text(", and so ")#mi("{E}")#text(" is a sparse subset of ")#mi("{H}")#text(". Furthermore, ")#mi("{E}")#text(" contains ")#mi("{E_M}")#text(" for every standard ")#mi("{M}")#text(", and so we are in the zero density conclusion of the argument. ")#mi("\\Box")

#text("(Curiously, I don’t see how to prove this lemma without unpacking the limit; it doesn’t seem to follow just from, say, the ")#link("http://en.wikipedia.org/wiki/Overspill")[#text("overspill principle")]#text(". Instead, it seems to be exploiting the weak countable saturation property I mentioned in a previous post. But perhaps I missed a simple argument.)")

#heading(level: 1)[#strong[#text(" — 4. Summary — ")]]

#text("Let me summarise with a brief list of pros and cons of switching to a nonstandard framework. First, the pros:")

#list(
[#text("Many “first-order” parameters such as ")#mi("{\\epsilon}")#text(" or ")#mi("{N}")#text(" disappear from view, as do various “negligible” errors. More importantly, “second-order” parameters, such as the function ")#mi("{F}")#text(" appearing in Theorem ")#link(<tao-0e3d661d1de125ea7e32>)[#text("2")]#text(", also disappear from view. (In principle, third-order and higher parameters would also disappear, though I do not yet know of an actual finitary argument in my fields of study which would have used such parameters (with the exception of Ramsey theory, where such parameters must come into play in order to generate such enormous quantities as ")#link("http://en.wikipedia.org/wiki/Graham's_number")[#text("Graham’s number")]#text(").) As such, a lot of tedious “epsilon management” disappears.")],
[#text("Iterative (and often parameter-heavy) arguments can often be replaced by minimisation (or more generally, extremisation) arguments, taking advantage of such properties as the ")#link("http://en.wikipedia.org/wiki/Well-ordering_principle")[#text("well-ordering principle")]#text(", the ")#link("http://en.wikipedia.org/wiki/Least_upper_bound_axiom")[#text("least upper bound axiom")]#text(", or compactness.")],
[#text("The ")#link("http://en.wikipedia.org/wiki/Transfer_principle")[#text("transfer principle")]#text(" lets one use “for free” any (first-order) statement about standard mathematics in the non-standard setting (provided that all objects involved are ")#emph[#text("internal")]#text("; see below).")],
[#text("Mature and powerful theories from infinitary mathematics (e.g. linear algebra, real analysis, representation theory, topology, functional analysis, measure theory, Lie theory, ergodic theory, model theory, etc.) can be used rigorously in a nonstandard setting (as long as one is aware of the usual infinitary pitfalls, of course; see below).")],
[#text("One can formally define terms that correspond to what would otherwise only be heuristic (or heavily parameterised and quantified) concepts such as “small”, “large”, “low rank”, “independent”, “uniformly distributed”, etc.")],
[#text("The conversion from a standard result to its nonstandard counterpart, or vice versa, is fairly quick (but see below), and generally only needs to be done only once or twice per paper.")]
)

#text("Next, the cons:")

#list(
[#text("Often requires the axiom of choice, as well as a certain amount of set theory. (There are however weakened versions of nonstandard analysis that can avoid choice that are still suitable for many applications.)")],
[#text("One needs the machinery of ultralimits and ultraproducts to set up the conversion from standard to nonstandard structures.")],
[#text("The conversion usually proceeds by a proof by contradiction, which (in conjunction with the use of ultralimits) may not be particularly intuitive.")],
[#text("One cannot efficiently discern what quantitative bounds emerge from a nonstandard argument (other than by painstakingly converting it back to a standard one, or by applying the tools of ")#emph[#text("proof mining")]#text("). (On the other hand, in particularly convoluted standard arguments, the quantitative bounds are already so poor – e.g. of iterated tower-exponential type – that losing these bounds is no great loss.)")],
[#text("One has to take some care to distinguish between standard and nonstandard objects (and also between internal and external sets and functions, which are concepts somewhat analogous to measurable and non-measurable sets and functions in measurable theory). More generally, all the usual pitfalls of infinitary analysis (e.g. interchanging limits, the need to ensure measurability or continuity) emerge in this setting, in contrast to the finitary setting where they are usually completely trivial.")],
[#text("It can be difficult at first to conceptually visualise what nonstandard objects look like (although this becomes easier once one maps nonstandard analysis concepts to heuristic concepts such as “small” and “large” as mentioned earlier, thus for instance one can think of an unbounded nonstandard natural number as being like an incredibly large standard natural number).")],
[#text("It is inefficient for both nonstandard and standard arguments to coexist within a paper; this makes things a little awkward if one for instance has to cite a result from a standard mathematics paper in a nonstandard mathematics one.")],
[#text("There are philosophical objections to using mathematical structures that only exist abstractly, rather than corresponding to the “real world”. (Note though that similar objections were also raised in the past with regard to the use of, say, complex numbers, non-Euclidean geometries, or even negative numbers.)")],
[#text("Formally, there is no increase in logical power gained by using nonstandard analysis (at least if one accepts the axiom of choice); anything which can be proven by nonstandard methods can also be proven by standard ones. In practice, though, the length and clarity of the nonstandard proof may be substantially better than the standard one.")]
)

#text("In view of the pros and cons, I would not say that nonstandard analysis is suitable in all situations, nor is it unsuitable in all situations, but one needs to carefully evaluate the costs and benefits in a given setting; also, in some cases having both a finitary and infinitary proof side by side for the same result may be more valuable than just having one of the two proofs. My rule of thumb is that if a finitary argument is already spitting out iterated tower-exponential type bounds or worse in an argument, this is a sign that the argument “wants” to be infinitary, and it may be simpler to move over to an infinitary setting (such as the nonstandard setting).")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/12/13/approximate-bases-sunflowers-and-nonstandard-analysis/#comment-42817")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2009")])]

#text("Professor Tao, I am appalled by the way you define things. definitions and sometimes basic concepts lack necessary rigor. The problem I believe is you don’t even know what to make of these terms, since if you did, you would be in a position to masterfully describe them in simplistic terms without the need to compensate in rigor.")

#text("If things are pseudorandom, then they are pseudorandom, there’s no need for ” ” (quotations).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/12/13/approximate-bases-sunflowers-and-nonstandard-analysis/#comment-42819")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2009")])]

#text("To the first post: can you name some of the rigor-lacking definitions or concepts that Prof. Tao define?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/12/13/approximate-bases-sunflowers-and-nonstandard-analysis/#comment-42820")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2009")])]

#text("In mathematics, there are vague ideas which defy quantization and definition. Describing such ideas requires a great amount of effort, in absorbing and synthesizing information. Thus, the sharing of such insights provides us a great benefit. In short, I see no problem with this (purposeful) choice of didactic structure. Moreover, such descriptions of these vague ideas demonstrate mastery of the subject material rather than ineptitude.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/12/13/approximate-bases-sunflowers-and-nonstandard-analysis/#comment-42824")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2009")])]

#text("despite the downvotes of anon #1’s comments, I admittingly start to agree with various aspects. the quality deteriorated somewhat.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/12/13/approximate-bases-sunflowers-and-nonstandard-analysis/#comment-42834")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2009")])]

#text("all of you are idiots. Tao is human. Give him some slack.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/12/13/approximate-bases-sunflowers-and-nonstandard-analysis/#comment-42838")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2009")])]

#text("My thoughts on these sorts of issues are given at")

#link("https://terrytao.wordpress.com/career-advice/there%E2%80%99s-more-to-mathematics-than-rigour-and-proofs/")[#text("https://terrytao.wordpress.com/career-advice/there%E2%80%99s-more-to-mathematics-than-rigour-and-proofs/")]

#text("(for the research aspects) and")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/career-advice/talks-are-not-the-same-as-papers/")[#text("Talks are not the same as papers")]
]

#text("(for the pedagogical aspects).")

#text("Generally speaking, rigorous details of various arguments given in my blog posts can often be found in the papers referenced as links inside such posts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/12/13/approximate-bases-sunflowers-and-nonstandard-analysis/#comment-42843")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2009")])]

#text("I’m appalled that some readers dared say they’re appalled at the way Prof Tao writes his blog. I’ve been reading this blog for some time now and the quality is always top-notch. But even if the quality isn’t as high as a that of published paper, it does not matter, as I’m very grateful to Prof. Tao for taking the time to write all these blogs that explain his highly technical research papers. This is a great service to the math community that very few, perhaps none, other mathematicians have sacrificed their time to do.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/12/13/approximate-bases-sunflowers-and-nonstandard-analysis/#comment-43301")[#strong[#text("Approximate bases, sunflowers, and nonstandard analysis « A Dialogue on Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2010")]

#text("[…] January 20, 2010 Posted by Alexandre Borovik in Uncategorized. trackback Just a link to Terry […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultralimit analysis, and quantitative algebraic geometry « What’s new")]], [#link("https://terrytao.wordpress.com/2009/12/13/approximate-bases-sunflowers-and-nonstandard-analysis/#comment-43424")[#strong[#text("Ultralimit analysis, and quantitative algebraic geometry « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2010")])]

#text("[…] analysis, ultrafilters, ultralimit analysis | by Terence Tao I have blogged a number of times in the past about the relationship between finitary (or “hard”, or “quantitative”) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A computational perspective on set theory « What’s new")]], [#link("https://terrytao.wordpress.com/2009/12/13/approximate-bases-sunflowers-and-nonstandard-analysis/#comment-43932")[#strong[#text("A computational perspective on set theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2010")])]

#text("[…] mathematics (involving only finitely many points or numbers, etc.); I have explored this theme in a number of previous blog posts. So, one may ask: what is the finitary analogue of statements such as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/12/13/approximate-bases-sunflowers-and-nonstandard-analysis/#comment-463317")[#strong[#text("attack on/ of the sunflowers! | Turing Machine")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2015")]

#text("[…] 21. Approximate bases, sunflowers, and nonstandard analysis | What’s new […]")
]
