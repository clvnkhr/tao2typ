// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/09/03/oded-schramm/
// Converted to Typst by tao2typ: "2026-10-14T15:16:51.615038+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Oded Schramm", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Oded Schramm")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 September 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/")[#text("https://terrytao.wordpress.com/2008/09/03/oded-schramm/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I am very saddened (and stunned) to learn that ")#link("http://en.wikipedia.org/wiki/Oded_Schramm")[#text("Oded Schramm")]#text(", who made fundamental contributions to conformal geometry, probability theory, and mathematical physics, ")#link("http://research.microsoft.com/schramm/")[#text("died in a hiking accident")]#text(" this Monday, aged 46. (I knew him as a fellow editor of the ")#link("http://www.ams.org/jams/")[#text("Journal of the American Mathematical Society")]#text(", as well as for his mathematical research, of course.) It is a loss of both a great mathematician and a great person.")

#text("One of Schramm’s most fundamental contributions to mathematics is the introduction of the ")#link("http://en.wikipedia.org/wiki/Stochastic_Loewner_evolution")[#text("stochastic Loewner equation")]#text(" (now sometimes called the ")#emph[#text("Schramm-Loewner equation")]#text(" in his honour), together with his subsequent development of the theory of this equation with ")#link("http://en.wikipedia.org/wiki/Gregory_Lawler")[#text("Greg Lawler")]#text(" and ")#link("http://en.wikipedia.org/wiki/Wendelin_Werner")[#text("Wendelin Werner")]#text(". (This work has been recognised by a number of awards, including the Fields Medal in 2006 to Wendelin.) This equation (which I state after the jump) describes, for each choice of a parameter ")#mi("\\kappa > 0")#text(", a random (fractal) curve ")#mi("SLE(\\kappa)")#text(" in the plane; this random curve can be viewed as a nonlinear variant of ")#link("http://en.wikipedia.org/wiki/Brownian_motion")[#text("Brownian motion")]#text(", although the SLE curves tend to cross themselves much less frequently than Brownian paths do. By the nature of their construction, the ")#mi("SLE(\\kappa)")#text(" curves are ")#emph[#text("conformally invariant")]#text(": any ")#link("http://en.wikipedia.org/wiki/Conformal_map")[#text("conformal transformation")]#text(" of an ")#mi("SLE(\\kappa)")#text(" curve (respecting the boundary) gives another curve which has the same distribution as the original curve. (Brownian motion is also conformally invariant; given the close connections between Brownian motion and harmonic functions, it is not surprising that this fact is closely related to the fact that the property of a function being harmonic in the plane is preserved under conformal transformations.) Conversely, one can show that any conformally invariant random curve distribution which obeys some additional regularity and locality axioms must be of the form ")#mi("SLE(\\kappa)")#text(" for some ")#mi("\\kappa")#text(".")

#text("The amazing fact is that many other natural processes for generating random curves in the plane – e.g. ")#link("http://en.wikipedia.org/wiki/Loop-erased_random_walk")[#text("loop-erased random walk")]#text(", the boundary of Brownian motion (also known as the “Brownian frontier”), or the limit of ")#link("http://en.wikipedia.org/wiki/Percolation")[#text("percolation")]#text(" on the triangular lattice – are known or conjectured to be distributed according to ")#mi("SLE(\\kappa)")#text(" for some specific ")#mi("\\kappa")#text(" (in the above three examples, ")#mi("\\kappa")#text(" is 2, 8/3, and 6 respectively). In particular, this implies that the highly non-trivial fact that such distributions are conformally invariant, a phenomenon that had been conjectured by physicists but which only obtained rigorous mathematical proof following the work of Schramm and his coauthors.")

#text("[Update, Sep 6: A memorial blog to Oded has been set up by his Microsoft Research group ")#link("http://odedschramm.wordpress.com/")[#text("here")]#text(". See also these posts by ")#link("http://gilkalai.wordpress.com/2008/09/04/oded/")[#text("Gil Kalai")]#text(", ")#link("http://community.livejournal.com/ru_mathresearch/51228.html")[#text("Yuval Peres")]#text(", and ")#link("http://lucatrevisan.wordpress.com/2008/09/04/testing-minor-closed-properties-in-sparse-graphs/")[#text("Luca Trevisan")]#text(".]")

#metadata(none) <tao-2cce392dfe0f7cfda26a>

#text("The Loewner equation was introduced by ")#link("http://en.wikipedia.org/wiki/Charles_Loewner")[#text("Charles Loewner")]#text(" in the 1920s as a means of generating conformal maps, which he then used to make progress on the ")#link("http://en.wikipedia.org/wiki/De_Branges%27_theorem")[#text("Bieberbach conjecture")]#text(". This equation can be phrased in any simply connected domain in the complex plane (which are all conformally equivalent anyway, thanks to the ")#link("http://en.wikipedia.org/wiki/Riemann_mapping_theorem")[#text("Riemann mapping theorem")]#text("), but let us work with the upper half plane ")#mi("{\\Bbb H} = \\{ z \\in {\\Bbb C}: \\text{Im}(z) > 0 \\}")#text(" for simplicity. The starting observation is that for any ")#mi("t > 0")#text(", the map ")#mi("z \\mapsto \\sqrt{z^2 + 4t}")#text(" is a conformal map from the slit half-plane ")#mi("{\\Bbb H} \\backslash [0, 2i\\sqrt{t}]")#text(" to ")#mi("{\\Bbb H}")#text(". (Indeed, by the ")#link("http://en.wikipedia.org/wiki/Schwarz_lemma")[#text("Schwarz lemma")]#text(", this is the unique such conformal map which behaves like the identity near infinity.) Translating this, for any ")#mi("t > 0")#text(" and ")#mi("\\omega \\in {\\Bbb R}")#text(", we have a conformal map ")#mi("z \\mapsto \\sqrt{(z-w)^2 + 4t} + w")#text(" from the slit half-plane ")#mi("{\\Bbb H} \\backslash [w, w+2i\\sqrt{t}]")#text(" to ")#mi("{\\Bbb H}")#text(".")

#text("Now suppose that t=dt is infinitesimally small. Then by Taylor expansion, this conformal map is approximately given by the formula ")#mi("z \\mapsto z + dt \\frac{2}{z-w}")#text(", thus each point z moves infinitesimally by the ODE")

#align(center)[#mi("\\displaystyle \\partial_t z = \\frac{2}{z-w}")#text(".")]

#text("Infinitesimally, this ODE conformally deforms the half-plane by deleting an infinitesimal slit at w.")

#text("Now we work non-infinitesimally, letting t run from 0 to infinity, and letting ")#mi("w = w(t)")#text(" vary in continuously in time. This (formally, at least), creates a time series of conformal maps ")#mi("z(0) \\mapsto z(t)")#text(" from a half-plane ")#mi("{\\Bbb H} \\backslash K_t")#text(" with a curve ")#mi("K_t")#text(" removed to the full half-plane, which can be viewed as being formed by composing infinitely many of the preceding infinitesimal conformal transformations together. The flows are given by the ")#emph[#text("Loewner equation")]

#align(center)[#mi("\\displaystyle \\partial_t z = \\frac{2}{z-w(t)}")#text(".")]

#text("(The curve ")#mi("K_t")#text(" is basically the collection of initial data ")#mi("z(0)")#text(" for which the above ODE degenerates by time t.)")

#text("Schramm observed that if the driving function ")#mi("w(t)")#text(" was given by a multiple ")#mi("\\sqrt{\\kappa} W_t")#text(" of one-dimensional Brownian motion for some ")#mi("\\kappa > 0")#text(", then the resulting (random fractal) curves ")#mi("K_t")#text(" continue to be well-defined (despite the non-differentiability of ")#mi("w(t)")#text(") and become conformally invariant for any ")#mi("\\kappa")#text(", although for ")#mi("\\kappa > 4")#text(" the curve is no longer ")#link("http://en.wikipedia.org/wiki/Simple_curve")[#text("simple")]#text(", and for ")#mi("\\kappa \\geq 8")#text(" in fact becomes ")#link("http://en.wikipedia.org/wiki/Space-filling_curve")[#text("space-filling")]#text("). This opened the way to an enormous further literature on this subject by Lawler-Schramm-Werner and many others (see for instance this ")#link("http://www.math.cornell.edu/%7Elawler/encyclopedia.ps")[#text("survey of Lawler")]#text(").")

#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32397")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2008")])]

#text("That’s terrible news. My condolences to his family and friends. Actually the entire mathematical community deserves some condolence.")

#text("I have my own joint paper with Oded on much less important work of his that is nonetheless quite interesting. Oded was looking at what graphs can be realized in R^n by kissing spheres. (The spheres must have disjoint interiors, but they don’t have to be the same size.) It’s a standard theorem in classical geometry, also related to important work in hyperbolic geometry and complex analysis, that you can realize any planar simple graph by kissing circles in R^2. I.e., the circles are the vertices and the kissing pairs are the edges. It’s not clear what restrictions there are in R^n for n > 2, but Oded observed that there clearly are some because you can show that the average kissing number for any finite configuration is at most twice the maximum kissing number for equal-sized spheres.")

#text("Our paper shows that the average kissing number for a finite set of kissing spheres in R^3 is bounded above by a constant which is strictly less than 15, but on the other hand can be more than 12. The lower bounded was further improved slightly by David Eppstein in another paper, but Oded’s program of understanding nerves of sphere packings is still mostly open. There may well be interesting restrictions or algorithms that have not been discovered.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/42a6fc6dcb314de8a3af012e9518e7f7599b7a2870c8e259dd71e4dba8a14ade-54faa3f05f43217049f90ca38f1c29bd27e9d40eecb0a8298ed06e572795e9e3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Juan Barrios")]], [#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32402")[#strong[#text("Juan Barrios")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2008")])]

#text("I’m in shock. My condolences to his family and friends.")#linebreak()#text(" I am eager to look more of his theory and it relation with percolation theory. I was wonder the first time I take a look.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/738ab60216ef7fa7236252e2fc8735d2d932ef86f401304ced2003146f8cbb3b-19c8b885b0b640855e01a645756ffc73d41450328a2b0a3a6acf76132a9f424a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pgiacome")]], [#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32405")[#strong[#text("pgiacome")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2008")])]

#text("Bad news so youg so unliky")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa0d3acf762a0c9a8599008d14681e53cf306c34bb310b5ed07b7d32e9e137bc-9e3f08014538073240b9bad181145b4bbf76ccd7ff2a11b383f86b5afe964a37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor Kleptsyn")]], [#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32412")[#strong[#text("Victor Kleptsyn")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2008")])]

#text("Oh… My condolences to his family and friends, too…")#linebreak()#text(" Don’t know what else to say — it should not have happened! But it did…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da5ed0f30fb24bace74c45c1ce54ca18f57d7df35c31e472366a40f209a0b4bd-cf7e9e8ff70059099a7183573fb2095278da660566779168a8a1cbd0eccdefe8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ilya Kapovich")]], [#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32413")[#strong[#text("Ilya Kapovich")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2008")])]

#text("Very tragic and sad news indeed. I have never met Oded personally although we had interacted over e-mail on mathematical questions on a few occasions. Apart from his famous work on the stochastic Loewner equation, Schramm had done other first-rate work as well. I am most familiar with his 2000 paper with Mario Bonk in GAFA “Embeddings of Gromov hyperbolic spaces”. They proved there, via a clever combination of the Assouad embedding theorem and of a hyperbolic cone construction, that every word-hyperbolic group can be quasi-isometrically embedded into the standard hyperbolic n-space H^n. This was certainly an eye-opener for many group theorists and an excellent application of analytic ideas to geometric group theory.")

#text("A tragic loss for the mathematical community.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32421")[#strong[#text("Oded « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2008")]

#text("[…] account of the sad news, with short remarks on Oded as a mathematician and as a person. Terry Tao wrote a description of some of Oded works concerning two dimensional stochastic processes and SLE. Luca […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32422")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2008")])]

#text("Shocking… I have the greatest respect and appreciation for his work…deepest regrets I never met him.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32424")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2008")]

#text("[…] Oded Schramm I am very saddened (and stunned) to learn that Oded Schramm, who made fundamental contributions to conformal geometry, […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21f981115eac23de64b0e57c9b310ac1a594a81242e2a7e7141f394cac10458f-62196923690a4a2e62fd0b0bbed8d60ae479c394bd19e7c6bea25a289fcbc9c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Moskovich")]], [#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32428")[#strong[#text("Daniel Moskovich")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2008")])]

#text("The story of his death is quite frightening to me- in grad school, I had a hiking accident and was lying for hours with serious internal injuries at the bottom of an icy gully. What saved my life was that I was rescued the same day- and I still had injuries from cold which took me a long time to recover from. It was pure luck- the plan was to rescue me the next morning because of bad weather, but the Israeli Embassy put pressure on the right people. My chances of survival until morning, had I not been rescued that day, were probably close to zero- I’d have tried though, and I had plans for how to maximize my probability of survival.")#linebreak()#text(" Lots of mathematicians love climbing mountains, but it’s a dangerous pastime. I pray that we will all be safe on our hikes, and that the mathematical community will not suffer further bereavement. My condolences to his family and friends.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a2638dc415aef2a2dd42b00a4288920f372d79f9389d7ebea2120b77925f0b21-6bffb221df6658f0b7ac32594d2feecb02e740754065808f6aa689a7b13c5c37.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deane Yang")]], [#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32438")[#strong[#text("Deane Yang")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2008")])]

#text("A reporter who is writing an obituary of Oded Schramm is looking for help in describing briefly Schramm’s contributions to mathematics and science in ordinary non-technical English. I would welcome any and all attempts to do this. If you prefer to do this privately, please send your description to me at ")#link("mailto:deane.yang@yahoo.com")[#text("deane.yang@yahoo.com")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4eb78c3a97691a990f848873a225f7cde2c739a182e755ead72b304da9032ca-ca2fee0e008964cc9b48eb64466bbcdf9bb3544002d7795a7a98887a278090ff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phil Bowers")]], [#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32458")[#strong[#text("Phil Bowers")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2008")])]

#text("I have known Oded since around 1995, having worked in circle packings since 1990. Much of my and Ken Stephenson’s early work overlapped much with Oded’s. I too am stunned. My sincere condolences to his family. I am very saddened by this news. Oded was one of the most gracious persons I knew. The mathematics community has lost a great soul.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a2638dc415aef2a2dd42b00a4288920f372d79f9389d7ebea2120b77925f0b21-6bffb221df6658f0b7ac32594d2feecb02e740754065808f6aa689a7b13c5c37.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deane Yang")]], [#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32460")[#strong[#text("Deane Yang")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2008")])]

#text("Here is *my* attempt at an explanation in plain English of Schramm’s work (even though I am a mathematician, I know *nothing* about Schramm’s work beyond what I read above). *Please* criticize, constructively or not. But keep in mind that the goal is not a literally correct description but rather a poetically correct one (whatever that means).")

#text("“Schramm is best known for developing a better mathematical understanding for something known as self-similar fractal phenomena. Something, such as a curve, is said to be fractal, if it is “infinitely jagged”. In other words, it looks jagged not only to the naked eye but also no matter how much you magnify it. Physicists had observed that certain complex physical systems exhibited fractal behavior. Standard mathematical theories such as calculus, study only smooth curves and surfaces, which, when you magnify them enough, they flatten out. In recent years, mathematicians and physicists recognized that fractal curves (curves that don’t straighten out under magnification) play a more important role than realized earlier in both mathematics and the real world (think, for example, of the coastline of a continent).")

#text("Schramm introduced a new mathematical theory called “Stochastic Loewner Evolution” which explained why fractal phenomena appear in a class of systems studied by physicists. This work led to several awards to Schramm himself, as well as joint work that was cited in the awarding of the Polya Prize to Schramm, Lawler, and Werner and the Field Medal to Werner.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohamed")]], [#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32489")[#strong[#text("Mohamed")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2008")])]

#text("It is so sad to loose a great mathematician like Oded Schramm! His loss is very shocking. My condolences to his family.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32514")[#strong[#text("Oded Schramm « Almost Surely")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2008")]

#text("[…] it “stochastic Loewner evolution”). You can read more about him and his mathematics here, here and here. On a more personal note, while I didn’t know Oded very well, I did meet him […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32526")[#strong[#text("לא מדויק » ארכיון » עודד שרם ז”ל")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2008")]

#text("[…] המדלייה. בלית ברירה, אני מפנה את הקוראים הסקרנים לעמוד ההספד שכתב מישהו שבאמת מבין משהו במתמטיקה – טרי טאו, שבלוג […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32558")[#strong[#text("Memories of Oded Schramm « Memories of Oded Schramm")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2008")]

#text("[…] and this blog is to allow his friends to share their photographs and memories of him. (See also Terry Tao’s blog and Gil Kalai’s blog.) Possibly related posts: (automatically generated)Oded Schramm […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32567")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2008")])]

#text("Professor Schramm had a gentle character and rigid principles.")#linebreak()#text(" I am sorry that he is gone.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Folz")]], [#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32589")[#strong[#text("Matthew Folz")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2008")])]

#text("The Brownian frontier actually has the distribution of SLE_{8/3}, according to (for example) the survey article of Lawler you link to, page 8. It’s the Hausdorff dimension of the Brownian frontier which is 4/3, since the Hausdorff dimension of SLE_k is \\min(2,1+k/8).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-32593")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2008")])]

#text("Dear Matthew: Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-40769")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2009")])]

#text("Oded Schramm Memorial Conference")#linebreak()#text(" Probability and Geometry")#linebreak()#text(" August 30-31, 2009")

#link("http://research.microsoft.com/en-us/um/people/schramm/workshop/")[#text("http://research.microsoft.com/en-us/um/people/schramm/workshop/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/03/oded-schramm/#comment-144992")[#strong[#text("עודד שרם ז\"ל « לא מדויק")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2012")]

#text("[…] המדלייה. בלית ברירה, אני מפנה את הקוראים הסקרנים לעמוד ההספד שכתב מישהו שבאמת מבין משהו במתמטיקה – טרי טאו, שבלוג […]")
]
