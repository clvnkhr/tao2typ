// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/08/28/dodgson-condensation-from-schur-complementation/
// Converted to Typst by tao2typ: "2026-10-14T10:42:41.835892+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Dodgson condensation from Schur complementation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Dodgson condensation from Schur complementation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 August 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/08/28/dodgson-condensation-from-schur-complementation/")[#text("https://terrytao.wordpress.com/2017/08/28/dodgson-condensation-from-schur-complementation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The determinant ")#mi("{\\det_n(A)}")#text(" of an ")#mi("{n \\times n}")#text(" matrix (with coefficients in an arbitrary field) obey many useful identities, starting of course with the fundamental multiplicativity ")#mi("{\\det_n(AB) = \\det_n(A) \\det_n(B)}")#text(" for ")#mi("{n \\times n}")#text(" matrices ")#mi("{A,B}")#text(". This multiplicativity can in turn be used to establish many further identities; in particular, as shown in ")#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/")[#text("this previous post")]#text(", it implies the ")#emph[#text("Schur determinant identity")]#text(" ")#metadata(none) <tao-19396451474262011135>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\det_{n+k}\\begin{pmatrix} A & B \\\\ C & D \\end{pmatrix} = \\det_n(A) \\det_k( D - C A^{-1} B )")]]

#text("whenever ")#mi("{A}")#text(" is an invertible ")#mi("{n \\times n}")#text(" matrix, ")#mi("{B}")#text(" is an ")#mi("{n \\times k}")#text(" matrix, ")#mi("{C}")#text(" is a ")#mi("{k \\times n}")#text(" matrix, and ")#mi("{D}")#text(" is a ")#mi("{k \\times k}")#text(" matrix. The matrix ")#mi("{D - CA^{-1} B}")#text(" is known as the ")#link("https://en.wikipedia.org/wiki/Schur_complement")[#text("Schur complement")]#text(" of the block ")#mi("{A}")#text(".")

#text("I only recently discovered that this identity in turn immediately implies what I always found to be a somewhat curious identity, namely the ")#link("https://en.wikipedia.org/wiki/Dodgson_condensation")[#text("Dodgson condensation identity")]#text(" (also known as the ")#emph[#text("Desnanot-Jacobi identity")]#text(")")

#tao-aligned(keep: true)[


#tao-math("\\det_n(M) \\det_{n-2}(M^{1,n}_{1,n})  & = \\det_{n-1}( M^1_1 ) \\det_{n-1}(M^n_n)", block: true)



#tao-math(" & - \\det_{n-1}(M^1_n) \\det_{n-1}(M^n_1)", block: true)
]

#text("for any ")#mi("{n \\geq 3}")#text(" and ")#mi("{n \\times n}")#text(" matrix ")#mi("{M}")#text(", where ")#mi("{M^i_j}")#text(" denotes the ")#mi("{n-1 \\times n-1}")#text(" matrix formed from ")#mi("{M}")#text(" by removing the ")#mi("{i^{th}}")#text(" row and ")#mi("{j^{th}}")#text(" column, and similarly ")#mi("{M^{i,i^{\\prime}}_{j,j^{\\prime}}}")#text(" denotes the ")#mi("{n-2 \\times n-2}")#text(" matrix formed from ")#mi("{M}")#text(" by removing the ")#mi("{i^{th}}")#text(" and ")#mi("{(i^{\\prime})^{th}}")#text(" rows and ")#mi("{j^{th}}")#text(" and ")#mi("{(j^{\\prime})^{th}}")#text(" columns. Thus for instance when ")#mi("{n=3}")#text(" we obtain")

#align(center)[#tao-fit-display[#mitex("\\det_3 \\begin{pmatrix} a & b & c \\\\ d & e & f \\\\ g & h & i \\end{pmatrix} \\cdot e")]]

#tao-aligned(keep: true)[


#tao-math(" & = \\det_2 \\begin{pmatrix} e & f \\\\ h & i \\end{pmatrix} \\cdot \\det_2 \\begin{pmatrix} a & b \\\\ d & e \\end{pmatrix}", block: true)



#tao-math(" & - \\det_2 \\begin{pmatrix} b & c \\\\ e & f \\end{pmatrix} \\cdot \\det_2 \\begin{pmatrix} d & e \\\\ g & h \\end{pmatrix}", block: true)
]

#text("for any scalars ")#mi("{a,b,c,d,e,f,g,h,i}")#text(". (Charles Dodgson, better known by his pen name ")#link("https://en.wikipedia.org/wiki/Lewis_Carroll")[#text("Lewis Caroll")]#text(", is of course also known for writing “")#link("https://en.wikipedia.org/wiki/Alice%27s_Adventures_in_Wonderland")[#text("Alice in Wonderland")]#text("” and “")#link("https://en.wikipedia.org/wiki/Through_the_Looking-Glass")[#text("Through the Looking Glass")]#text("“.)")

#text("The derivation is not new; it is for instance noted explicitly in ")#link("http://www.ams.org/mathscinet-getitem?mr=1500275")[#text("this paper of Brualdi and Schneider")]#text(", though I do not know if this is the earliest place in the literature where it can be found. (EDIT: Apoorva Khare has pointed out to me that the ")#link("http://www.jstor.org/stable/112607")[#text("original arguments of Dodgson")]#text(" can be interpreted as implicitly following this derivation.) I thought it is worth presenting the short derivation here, though.")

#text("Firstly, by swapping the first and ")#mi("{(n-1)^{th}}")#text(" rows, and similarly for the columns, it is easy to see that the Dodgson condensation identity is equivalent to the variant ")#metadata(none) <tao-c86872dc97dd35aabbbd>

#tao-aligned(keep: true)[


#tao-math("\\det_n(M) \\det_{n-2}(M^{n-1,n}_{n-1,n})  & = \\det_{n-1}( M^{n-1}_{n-1} ) \\det_{n-1}(M^n_n)", block: true, numbering: n => [#text("(2)")])



#tao-math(" & - \\det_{n-1}(M^{n-1}_n) \\det_{n-1}(M^n_{n-1}).", block: true)
]

#text("Now write")

#align(center)[#tao-fit-display[#mitex("M = \\begin{pmatrix} A & B_1 & B_2 \\\\ C_1 & d_{11} & d_{12} \\\\ C_2 & d_{21} & d_{22} \\end{pmatrix}")]]

#text("where ")#mi("{A}")#text(" is an ")#mi("{n-2 \\times n-2}")#text(" matrix, ")#mi("{B_1, B_2}")#text(" are ")#mi("{n-2 \\times 1}")#text(" column vectors, ")#mi("{C_1, C_2}")#text(" are ")#mi("{1 \\times n-2}")#text(" row vectors, and ")#mi("{d_{11}, d_{12}, d_{21}, d_{22}}")#text(" are scalars. If ")#mi("{A}")#text(" is invertible, we may apply the Schur determinant identity repeatedly to conclude that")

#tao-aligned(keep: true)[


#tao-math("\\det_n(M)  & = \\det_{n-2}(A) \\det_2 \\begin{pmatrix} d_{11} - C_1 A^{-1} B_1 & d_{12} - C_1 A^{-1} B_2 \\\\ d_{21} - C_2 A^{-1} B_1 & d_{22} - C_2 A^{-1} B_2 \\end{pmatrix}", block: true)



#tao-math("\\det_{n-2} (M^{n-1,n}_{n-1,n})  & = \\det_{n-2}(A)", block: true)



#tao-math("\\det_{n-1}( M^{n-1}_{n-1} )  & = \\det_{n-2}(A) (d_{22} - C_2 A^{-1} B_2 )", block: true)



#tao-math("\\det_{n-1}( M^{n-1}_{n} )  & = \\det_{n-2}(A) (d_{21} - C_2 A^{-1} B_1 )", block: true)



#tao-math("\\det_{n-1}( M^{n}_{n-1} )  & = \\det_{n-2}(A) (d_{12} - C_1 A^{-1} B_2 )", block: true)



#tao-math("\\det_{n-1}( M^{n}_{n} )  & = \\det_{n-2}(A) (d_{11} - C_1 A^{-1} B_1 )", block: true)
]

#text("and the claim ")#link(<tao-c86872dc97dd35aabbbd>)[#text("(2)")]#text(" then follows by a brief calculation (and the explicit form ")#mi("{\\det_2 \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} = ad-bc}")#text(" of the ")#mi("{2 \\times 2}")#text(" determinant). To remove the requirement that ")#mi("{A}")#text(" be invertible, one can use a limiting argument, noting that one can work without loss of generality in an algebraically closed field, and in such a field, the set of invertible matrices is dense in the Zariski topology. (In the case when the scalars are reals or complexes, one can just use density in the ordinary topology instead if desired.)")

#text("The same argument gives the more general determinant identity of Sylvester")

#align(center)[#tao-fit-display[#mitex("\\det_n(M) \\det_{n-k}(M^S_S)^{k-1} = \\det_k \\left( \\det_{n-k+1}(M^{S \\backslash \\{i\\}}_{S \\backslash \\{j\\}}) \\right)_{i,j \\in S}")]]

#text("whenever ")#mi("{n > k \\geq 1}")#text(", ")#mi("{S}")#text(" is a ")#mi("{k}")#text("-element subset of ")#mi("{\\{1,\\dots,n\\}}")#text(", and ")#mi("{M^S_{S^{\\prime}}}")#text(" denotes the matrix formed from ")#mi("{M}")#text(" by removing the rows associated to ")#mi("{S}")#text(" and the columns associated to ")#mi("{S^{\\prime}}")#text(". (The Dodgson condensation identity is basically the ")#mi("{k=2}")#text(" case of this identity.)")

#text("A closely related proof of ")#link(<tao-c86872dc97dd35aabbbd>)[#text("(2)")]#text(" proceeds by elementary row and column operations. Observe that if one adds some multiple of one of the first ")#mi("{n-2}")#text(" rows of ")#mi("{M}")#text(" to one of the last two rows of ")#mi("{M}")#text(", then the left and right sides of ")#link(<tao-c86872dc97dd35aabbbd>)[#text("(2)")]#text(" do not change. If the minor ")#mi("{A}")#text(" is invertible, this allows one to reduce to the case where the components ")#mi("{C_1,C_2}")#text(" of the matrix vanish. Similarly, using elementary column operations instead of row operations we may assume that ")#mi("{B_1,B_2}")#text(" vanish. All matrices involved are now block-diagonal and the identity follows from a routine computation.")

#text("The latter approach can also prove the cute identity")

#align(center)[#tao-fit-display[#mitex("\\det_2 \\begin{pmatrix} \\det_n( X_1, Y_1, A ) & \\det_n( X_1, Y_2, A ) \\\\ \\det_n(X_2, Y_1, A) & \\det_n(X_2,Y_2, A) \\end{pmatrix} = \\det_n( X_1,X_2,A) \\det_n(Y_1,Y_2,A)")]]

#text("for any ")#mi("{n \\geq 2}")#text(", any ")#mi("{n \\times 1}")#text(" column vectors ")#mi("{X_1,X_2,Y_1,Y_2}")#text(", and any ")#mi("{n \\times n-2}")#text(" matrix ")#mi("{A}")#text(", which can for instance be found in page 7 of ")#link("http://www.ams.org/mathscinet-getitem?mr=230102")[#text("this text of Karlin")]#text(". Observe that both sides of this identity are unchanged if one adds some multiple of any column of ")#mi("{A}")#text(" to one of ")#mi("{X_1,X_2,Y_1,Y_2}")#text("; for generic ")#mi("{A}")#text(", this allows one to reduce ")#mi("{X_1,X_2,Y_1,Y_2}")#text(" to have only the first two entries allowed to be non-zero, at which point the determinants split into ")#mi("{2 \\times 2}")#text(" and ")#mi("{n -2 \\times n-2}")#text(" determinants and we can reduce to the ")#mi("{n=2}")#text(" case (eliminating the role of ")#mi("{A}")#text("). One can now either proceed by a direct computation, or by observing that the left-hand side is quartilinear in ")#mi("{X_1,X_2,Y_1,Y_2}")#text(" and antisymmetric in ")#mi("{X_1,X_2}")#text(" and ")#mi("{Y_1,Y_2}")#text(" which forces it to be a scalar multiple of ")#mi("{\\det_2(X_1,X_2) \\det_2(Y_1,Y_2)}")#text(", at which point one can test the identity at a single point (e.g. ")#mi("{X_1=Y_1 = e_1}")#text(" and ")#mi("{X_2=Y_2=e_2}")#text(" for the standard basis ")#mi("{e_1,e_2}")#text(") to conclude the argument. (One can also derive this identity from the Sylvester determinant identity but I think the calculations are a little messier if one goes by that route. Conversely, one can recover the Dodgson condensation identity from Karlin’s identity by setting ")#mi("{X_1=e_1}")#text(", ")#mi("{X_2=e_2}")#text(" (for instance) and then permuting some rows and columns.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8afd437da1e36ab156fcdc0ff4e6d28e8e48582473c360ab6e4aac8a8a94880e-11086e67d63e97b981d0240d596254a1217fc1a92c53dccae70ac8508b5737eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of André Camargo")]], [#link("https://terrytao.wordpress.com/2017/08/28/dodgson-condensation-from-schur-complementation/#comment-485551")[#strong[#text("André Camargo")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2017")])]

#text("Schur complements are closely related to the Gaussian block elimination strategy")

#mi("\\displaystyle \\overbrace{ \\left[\\begin{array}{cc} E & C \\\\ L & F  \\end{array} \\right] }^{A}  \\stackrel{G}{\\longmapsto} \\overbrace{ \\left[\\begin{array}{cc} E & C \\\\ 0 & F^{\\prime}  \\end{array} \\right] }^{A^{\\prime}},")

#text("where we use the block ")#mi("E")#text(" to produce all the zeros below it. It might be interesting to notice that")#linebreak()#text(" one can produce these zeros through thousands of other manners and, for each elimination strategy we choose,")#linebreak()#text(" a different determinantal identity of Sylvester type can be established. This fact was noticed by Mühlbach")#linebreak()#text(" ")#link("http://www.sciencedirect.com/science/article/pii/002437959090060P")[#text("http://www.sciencedirect.com/science/article/pii/002437959090060P")]#text(".")

#text("Sylvester’s identity can also be interpreted as follows: first we take the Leibniz’ formula for the determinant of ")#mi("F^{\\prime}")

#tao-math("\\displaystyle \\left|F^{\\prime}\\right| \\ = \\ \\sum\\limits_{\\sigma\\ \\ \\in \\mathfrak S} sgn(\\sigma) \\prod\\limits_{j = 1}^{n} f^{\\prime}_{j,\\sigma(j)}", block: false)

#text("and then we use that, by the Schur determinantal identity, each entry of ")#mi("F^{\\prime}")#text(" is a ratio of the minors of ")#mi("A")#text(".")#linebreak()#text(" After these replacements, we get Sylvester’s identity. If we apply this same procedure to other algebraic relation between the minors of ")#mi("F^{\\prime}")#text(" (Laplace expansions, for instance), we obtain, after replacements through the Schur determinantal identity, another identity on minors of ")#mi("A")#text(". This general principle is known as Muir’s law of extensible minors and it is proved through Schur complements in the paper of Brualdi and Schneider. This principle was established By Muir in 1881, but curiously, Muir did not use Gaussian elimination explicitly. Using other elimination estrategies than the Gaussian one, Mühlbach generalized Muir’s law.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf439e996e29d20cb552d68ffe9f964d8919f4f9773b9c41c886fb326a5a9695-66573747b7b50dc2532a1c1acd7e23c9482f9aeb4a00f437399c08ade2278ee3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aquazorcarson")]], [#link("https://terrytao.wordpress.com/2017/08/28/dodgson-condensation-from-schur-complementation/#comment-486101")[#strong[#text("aquazorcarson")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2017")])]

#text("Here is another interesting matrix identity that can be derived from Schur’s complement formula: ")#link("https://mathoverflow.net/questions/87877/jacobis-equality-between-complementary-minors-of-inverse-matrices")[#text("https://mathoverflow.net/questions/87877/jacobis-equality-between-complementary-minors-of-inverse-matrices")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8afd437da1e36ab156fcdc0ff4e6d28e8e48582473c360ab6e4aac8a8a94880e-11086e67d63e97b981d0240d596254a1217fc1a92c53dccae70ac8508b5737eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of André Camargo")]], [#link("https://terrytao.wordpress.com/2017/08/28/dodgson-condensation-from-schur-complementation/#comment-486136")[#strong[#text("André Camargo")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2017")])]

#text("Indeed. Brualdi and Schneider prove Jacobi’s identity in their paper through Schur complements. It can be also derived directly from Sylvester’s identity (see my post below).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98d192abd70f5311db8ec60dec56a48604f76cb7ff6a4cf4f5df43803680c3ff-cb5dcadf7bcf8b56cb8857c450f2fddd18645e59e478b53d2f6ab76b378a6646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2017/08/28/dodgson-condensation-from-schur-complementation/#comment-485603")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2017")])]

#text("I have always wondered what our fixation with determinants are. Matrix multiplication is just a short-hand doing one linear substitution and then another. If we have another algebra, the multiplication might look a little bit different.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/08/28/dodgson-condensation-from-schur-complementation/#comment-485607")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2017")])]

#text("If you do discover another algebra that has a comparable utility and richness as linear algebra, please do let the rest of us know. In the meantime, you might take a look at the answers to this question: ")#link("https://mathoverflow.net/questions/35988/why-were-matrix-determinants-once-such-a-big-deal")[#text("https://mathoverflow.net/questions/35988/why-were-matrix-determinants-once-such-a-big-deal")]

#text("EDIT: There are interesting variants of the determinant, such as ")#link("https://en.wikipedia.org/wiki/Pfaffian")[#text("the Pfaffian")]#text(", ")#link("https://en.wikipedia.org/wiki/Permanent_(mathematics)")[#text("the permanent")]#text(", ")#link("http://www.math.uni-frankfurt.de/~theobald/publications/tropical.pdf")[#text("the tropical determinant")]#text(", or ")#link("https://en.wikipedia.org/wiki/Immanant_of_a_matrix")[#text("immanants")]#text(", which may be thought of as arising from slightly different algebraic foundations than classical linear algebra (e.g. supercommutative algebra, tropical algebra, etc.). However, these variants, as fascinating as they are, are not nearly as broadly useful to modern mathematics as the classical determinant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/026ff8818be8771c99fb11d93e968235ebab5ef40946ea2e550dbbe25b389df3-6a2a635a11afbd5c2c7c051aa40439c5741b0b09fcb40e05c52611f92d17cb32.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Darius Mangual")]], [#link("https://terrytao.wordpress.com/2017/08/28/dodgson-condensation-from-schur-complementation/#comment-486386")[#strong[#text("John Darius Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2017")])]

#text("DAHA")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/251d74bd08278fbf4f394dfbcfabbf86e4effd495eb043ad0ace5b24bc07b765-27f751079643bf0502b46779750cb5e4843b60f0323db961d7e966a276cb7589.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Darij Grinberg")]], [#link("https://terrytao.wordpress.com/2017/08/28/dodgson-condensation-from-schur-complementation/#comment-485632")[#strong[#text("Darij Grinberg")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2017")])]

#text("If you allow the Zariski density argument (a.k.a. Weyl’s principle of irrelevance of algebraic inequalities) to assume that certain matrices are invertible, then a lot of identities like this boil down to each other. If one forbids this argument, however, the situation changes (similar to how trivially equivalent combinatorial identities can turn into completely different problems when one asks for a bijective proof). The Sylvester identity has been combinatorially proven by Berliner and Brualdi ( ")#link("http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.531.364")[#text("http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.531.364")]#text(" ); the particular case that is Dodgson condensation has been done by Zeilberger earlier ( ")#link("https://arxiv.org/abs/math/9808079v1")[#text("https://arxiv.org/abs/math/9808079v1")]#text(" ). There are other identities where such a proof remains to be found; to my knowledge, det (adj A) = (det A)^{n-1} is one of those.")

#text("Note that your proof of the “cute identity” can be made even simpler: Any row operations preserve the identity, as long as they are performed simultaneously on X_1, X_2, Y_1, Y_2 and A. Thus, we can in particular transform (X_1, X_2, A) into the identity matrix, so the only freedom remains in the vectors Y_1 and Y_2. This is spelt out in the proof of Lemma 14.2 in ")#link("http://arxiv.org/abs/1402.6178v6")[#text("http://arxiv.org/abs/1402.6178v6")]#text(" (a 134-page paper which, in a sense, is built upon this “cute identity”).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8afd437da1e36ab156fcdc0ff4e6d28e8e48582473c360ab6e4aac8a8a94880e-11086e67d63e97b981d0240d596254a1217fc1a92c53dccae70ac8508b5737eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of André Camargo")]], [#link("https://terrytao.wordpress.com/2017/08/28/dodgson-condensation-from-schur-complementation/#comment-485696")[#strong[#text("André Camargo")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2017")])]

#text("Indeed, I have been study some of these determinantal identities for a while and it turns out that many of them are equivalent to each other. For instance, the identity for the determinant of the Adjugate for a matrix ")#mi("A")#text(" of")#linebreak()#text(" size ")#mi("n")#text(" follows directly from Sylvester’s identity applied to the matrix ")#mi("\\begin{pmatrix} A^t & I \\\\ I & 0 \\end{pmatrix}")#text(" of size ")#mi("2n")#text(" (I = identity matrix). A similar reasoning shows that Sylvester’s identity is actually algebraically equivalent to Jacobi’s identity, which expresses any minor of the Adjugate in terms of the minors of ")#mi("A")#text(" (the details can be found here ")#link("http://www.sciencedirect.com/science/article/pii/S0024379515003092")[#text("http://www.sciencedirect.com/science/article/pii/S0024379515003092")]#text(".)")

#text("Actually MANY MANY determinantal identities for a matrix $A$ can be obtained through some other determinantal identity for a matrix which contains $A$ as a submatrix. In fact, Leclerc showed that most of the known determinantal identities are particular cases of an identity of Turnbull of 1909 (see the details here ")#link("http://www.sciencedirect.com/science/article/pii/S0001870883710303")[#text("http://www.sciencedirect.com/science/article/pii/S0001870883710303")]#text("). Leclerc interpreted Turnbull’s identity as the")#linebreak()#text(" associativity and anticommutativity of the second product of Peano/Cayley Algebras, but, in essence, it just compares some iterative Laplace expansions of a same determinant before and after some elimination process is performed. However, although powerful, Turnbull’s identity may not be intuitive. For instance, an example of obtaining Sylvester’s identity from Turnbull’s identity is given in Section 5 of ")#link("http://www.tandfonline.com/doi/abs/10.1080/03081087.2012.740028")[#text("http://www.tandfonline.com/doi/abs/10.1080/03081087.2012.740028")]#text(".")

#text("Just to finish: the following paper ")#link("http://www.combinatorics.org/ojs/index.php/eljc/article/view/v19i3p21/pdf")[#text("http://www.combinatorics.org/ojs/index.php/eljc/article/view/v19i3p21/pdf")]#text(" proves several determinantal identities bijectively, including Turnbull’s one. Thus, using Leclerc’s approach, it turns out that bijective proofs exist for most of the known determinantal identities.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/251d74bd08278fbf4f394dfbcfabbf86e4effd495eb043ad0ace5b24bc07b765-27f751079643bf0502b46779750cb5e4843b60f0323db961d7e966a276cb7589.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Darij Grinberg")]], [#link("https://terrytao.wordpress.com/2017/08/28/dodgson-condensation-from-schur-complementation/#comment-485827")[#strong[#text("Darij Grinberg")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2017")])]

#text("I wasn’t aware of the fact that the det (adj A) = (det A)^{n-1} formula is a particular case of the Dodgson-Muir identity. Since the latter is proven bijectively in the Berliner-Brualdi paper, this settles the question for a bijective proof of the former. Thank you!")

#text("You have answered a long-standing MO and m.se question with this, by the way… if only I could find it.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b7d3dfd36720fae49c538f476998530415bb398ead115b4b23e058ec7276828-01cfbd597bab9e45e5280ea4e3d11a3b9ef8ea6937cb717d43a7bf76510b651d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rajesh")]], [#link("https://terrytao.wordpress.com/2017/08/28/dodgson-condensation-from-schur-complementation/#comment-485710")[#strong[#text("Rajesh")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2017")])]

#text("Prof Tao :")

#text("Can you attempt this open problem of finding an almost closed form expression or if not expression but some insight into properties of first eigenfunction of p=3-Laplacian of a square domain in R^2 under periodic boundary conditions. (Some thing like the sin_p function in case of 1-D). I have computed the solution, but I need more insights than computation. Its simple structure suggest some insight may be gained into this function. Its been a long standing open problem and appreciate your insights suggestions and efforts.")

#link("https://mathoverflow.net/q/279771/14414")[#text("https://mathoverflow.net/q/279771/14414")]

#text("Regards")#linebreak()#text(" Rajesh")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b7d3dfd36720fae49c538f476998530415bb398ead115b4b23e058ec7276828-01cfbd597bab9e45e5280ea4e3d11a3b9ef8ea6937cb717d43a7bf76510b651d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rajesh")]], [#link("https://terrytao.wordpress.com/2017/08/28/dodgson-condensation-from-schur-complementation/#comment-485779")[#strong[#text("Rajesh")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2017")])]

#text("I think I have just solved this problem. Request you to please have a look at the answer to that question. Appreciate your comments.")

#text("Regards")#linebreak()#text(" Rajesh")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An update to “On the sign patterns of entrywise positivity preservers in fixed dimension” | What's new")]], [#link("https://terrytao.wordpress.com/2017/08/28/dodgson-condensation-from-schur-complementation/#comment-486788")[#strong[#text("An update to “On the sign patterns of entrywise positivity preservers in fixed dimension” | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2017")])]

#text("[…] proven relatively easy by an induction argument, relying on the Dodgson and Karlin identities from this previous post; the difficulties are largely notational in nature. Combining this result with the Jacobi-Trudi […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ebe6de4cb9de9ac0c3a5d1059f9aa668ff783d49acdacd8b4ac3c00df70150c-07a9edce3bd51963008db0afe7af1327ba78ef0a7086c351daaa344225aa3dfc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2017/08/28/dodgson-condensation-from-schur-complementation/#comment-501544")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2018")])]

#text("One geometrically intuitive way of looking at the determinant is as the volume of a box.")

#text("At some point, we learned to express this volume as the wedge product of three vectors. Let ")#mi("v_1, v_2, v_3 \\in \\mathbb{R}^3")#text(" we have the determinant formula: ")#tao-math("\\text{Vol} = \\left| v_1 \\vee v_2 \\vee v_3 \\right| = (v_1 \\times v_2) \\cdot v_3", block: false)#text(".")

#text("Even our definition of cross product is a highly remarkable thing, as the matrix entries are also vectors.")

#tao-math("v \\times w = \\left|\\begin{array}{ccc} \\mathbf{i} & \\mathbf{j} & \\mathbf{j} \\\\ v_1 & v_2 & v_3 \\\\ w_1 & w_2 & w_3 \\end{array} \\right|", block: false)
]
