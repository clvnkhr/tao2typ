// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/
// Converted to Typst by tao2typ: "2026-10-14T15:17:27.467735+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The prime number theorem in arithmetic progressions, and dueling conspiracies", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The prime number theorem in arithmetic progressions, and dueling conspiracies")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 September 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/")[#text("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A fundamental problem in analytic number theory is to understand the distribution of the prime numbers ")#mi("{\\{2,3,5,\\ldots\\}}")#text(". For technical reasons, it is convenient not to study the primes directly, but a proxy for the primes known as the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(" ")#mi("{\\Lambda: {\\mathbb N} \\rightarrow {\\mathbb R}}")#text(", defined by setting ")#mi("{\\Lambda(n)}")#text(" to equal ")#mi("{\\log p}")#text(" when ")#mi("{n}")#text(" is a prime ")#mi("{p}")#text(" (or a power of that prime) and zero otherwise. The basic reason why the von Mangoldt function is useful is that it encodes the fundamental theorem of arithmetic (which in turn can be viewed as the defining property of the primes) very neatly via the identity ")#metadata(none) <tao-3c15dc2308570c62ec4a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\log n = \\sum_{d|n} \\Lambda(d)")]]

#text(" for every natural number ")#mi("{n}")#text(".")

#text("The most important result in this subject is the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(", which asserts that the number of prime numbers less than a large number ")#mi("{x}")#text(" is equal to ")#mi("{(1+o(1)) \\frac{x}{\\log x}}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} 1 = (1+o(1)) \\frac{x}{\\log x}.")]]

#text("Here, of course, ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{x \\rightarrow \\infty}")#text(".")

#text("It is not hard to see (e.g. by ")#link("http://en.wikipedia.org/wiki/Summation_by_parts")[#text("summation by parts")]#text(") that this is equivalent to the asymptotic ")#metadata(none) <tao-a160524700113ddd3205>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{n \\leq x} \\Lambda(n) = (1+o(1)) x")]]

#text(" for the von Mangoldt function (the key point being that the squares, cubes, etc. of primes give a negligible contribution, so ")#mi("{\\sum_{n \\leq x} \\Lambda(n)}")#text(" is essentially the same quantity as ")#mi("{\\sum_{p \\leq x} \\log p}")#text("). Understanding the nature of the ")#mi("{o(1)}")#text(" term is a very important problem, with the conjectured optimal decay rate of ")#mi("{O(\\sqrt{x} \\log x)}")#text(" being equivalent to the ")#link("http://en.wikipedia.org/wiki/Riemann_hypothesis")[#text("Riemann hypothesis")]#text(", but this will not be our concern here.")

#text("The prime number theorem has several important generalisations (for instance, there are analogues for other number fields such as the ")#link("http://en.wikipedia.org/wiki/Chebotarev%27s_density_theorem")[#text("Chebotarev density theorem")]#text("). One of the more elementary such generalisations is the ")#link("http://en.wikipedia.org/wiki/Dirichlet%27s_theorem_on_arithmetic_progressions")[#text("prime number theorem in arithmetic progressions")]#text(", which asserts that for fixed ")#mi("{a}")#text(" and ")#mi("{q}")#text(" with ")#mi("{a}")#text(" coprime to ")#mi("{q}")#text(" (thus ")#mi("{(a,q)=1}")#text("), the number of primes less than ")#mi("{x}")#text(" equal to ")#mi("{a}")#text(" mod ")#mi("{q}")#text(" is equal to ")#mi("{(1+o_q(1)) \\frac{1}{\\phi(q)} \\frac{x}{\\log x}}")#text(", where ")#mi("{\\phi(q) := \\# \\{ 1 \\leq a \\leq q: (a,q)=1 \\}}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Euler%27s_totient_function")[#text("Euler totient function")]#text(":")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x: p = a \\text{ mod } q} 1 = (1+o_q(1)) \\frac{1}{\\phi(q)} \\frac{x}{\\log x}.")]]

#text("(Of course, if ")#mi("{a}")#text(" is not coprime to ")#mi("{q}")#text(", the number of primes less than ")#mi("{x}")#text(" equal to ")#mi("{a}")#text(" mod ")#mi("{q}")#text(" is ")#mi("{O(1)}")#text(". The subscript ")#mi("{q}")#text(" in the ")#mi("{o()}")#text(" and ")#mi("{O()}")#text(" notation denotes that the implied constants in that notation is allowed to depend on ")#mi("{q}")#text(".) This is a more quantitative version of ")#link("http://en.wikipedia.org/wiki/Dirichlet%27s_theorem_on_arithmetic_progressions")[#text("Dirichlet’s theorem")]#text(", which asserts the weaker statement that the number of primes equal to ")#mi("{a}")#text(" mod ")#mi("{q}")#text(" is infinite. This theorem is important in many applications in analytic number theory, for instance in ")#link("http://en.wikipedia.org/wiki/Vinogradov%27s_theorem")[#text("Vinogradov’s theorem")]#text(" that every sufficiently large odd number is the sum of three odd primes. (Imagine for instance if almost all of the primes were clustered in the residue class ")#mi("{2}")#text(" mod ")#mi("{3}")#text(", rather than ")#mi("{1}")#text(" mod ")#mi("{3}")#text(". Then almost all sums of three odd primes would be divisible by ")#mi("{3}")#text(", leaving dangerously few sums left to cover the remaining two residue classes. Similarly for other moduli than ")#mi("{3}")#text(". This does not fully rule out the possibility that Vinogradov’s theorem could still be true, but it does indicate why the prime number theorem in arithmetic progressions is a relevant tool in the proof of that theorem.)")

#text("As before, one can rewrite the prime number theorem in arithmetic progressions in terms of the von Mangoldt function as the equivalent form")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: n = a \\text{ mod } q} \\Lambda(n) = (1+o_q(1)) \\frac{1}{\\phi(q)} x.")]]

#text("Philosophically, one of the main reasons why it is so hard to control the distribution of the primes is that we do not currently have too many tools with which one can rule out “conspiracies” between the primes, in which the primes (or the von Mangoldt function) decide to correlate with some structured object (and in particular, with a totally multiplicative function) which then visibly distorts the distribution of the primes. For instance, one could imagine a scenario in which the probability that a randomly chosen large integer ")#mi("{n}")#text(" is prime is not asymptotic to ")#mi("{\\frac{1}{\\log n}}")#text(" (as is given by the prime number theorem), but instead to fluctuate depending on the phase of the complex number ")#mi("{n^{it}}")#text(" for some fixed real number ")#mi("{t}")#text(", thus for instance the probability might be significantly less than ")#mi("{1/\\log n}")#text(" when ")#mi("{t \\log n}")#text(" is close to an integer, and significantly more than ")#mi("{1/\\log n}")#text(" when ")#mi("{t \\log n}")#text(" is close to a half-integer. This would contradict the prime number theorem, and so this scenario would have to be somehow eradicated in the course of proving that theorem. In the language of ")#link("http://en.wikipedia.org/wiki/Dirichlet_series")[#text("Dirichlet series")]#text(", this conspiracy is more commonly known as a zero of the Riemann zeta function at ")#mi("{1+it}")#text(".")

#text("In the above scenario, the primality of a large integer ")#mi("{n}")#text(" was somehow sensitive to asymptotic or “Archimedean” information about ")#mi("{n}")#text(", namely the approximate value of its logarithm. In modern terminology, this information reflects the local behaviour of ")#mi("{n}")#text(" at the infinite ")#link("http://en.wikipedia.org/wiki/Place_(mathematics)")[#text("place")]#text(" ")#mi("{\\infty}")#text(". There are also potential consipracies in which the primality of ")#mi("{n}")#text(" is sensitive to the local behaviour of ")#mi("{n}")#text(" at finite places, and in particular to the residue class of ")#mi("{n}")#text(" mod ")#mi("{q}")#text(" for some fixed modulus ")#mi("{q}")#text(". For instance, given a ")#link("http://en.wikipedia.org/wiki/Dirichlet_character")[#text("Dirichlet character")]#text(" ")#mi("{\\chi: {\\mathbb Z} \\rightarrow {\\mathbb C}}")#text(" of modulus ")#mi("{q}")#text(", i.e. a ")#link("http://en.wikipedia.org/wiki/Completely_multiplicative")[#text("completely multiplicative")]#text(" function on the integers which is periodic of period ")#mi("{q}")#text(" (and vanishes on those integers not coprime to ")#mi("{q}")#text("), one could imagine a scenario in which the probability that a randomly chosen large integer ")#mi("{n}")#text(" is prime is large when ")#mi("{\\chi(n)}")#text(" is close to ")#mi("{+1}")#text(", and small when ")#mi("{\\chi(n)}")#text(" is close to ")#mi("{-1}")#text(", which would contradict the prime number theorem in arithmetic progressions. (Note the similarity between this scenario at ")#mi("{q}")#text(" and the previous scenario at ")#mi("{\\infty}")#text("; in particular, observe that the functions ")#mi("{n \\rightarrow \\chi(n)}")#text(" and ")#mi("{n \\rightarrow n^{it}}")#text(" are both totally multiplicative.) In the language of Dirichlet series, this conspiracy is more commonly known as a zero of the ")#link("http://en.wikipedia.org/wiki/Dirichlet_L-function")[#mi("{L}")#text("-function")]#text(" of ")#mi("{\\chi}")#text(" at ")#mi("{1}")#text(".")

#text("An especially difficult scenario to eliminate is that of ")#emph[#text("real characters")]#text(", such as the ")#link("http://en.wikipedia.org/wiki/Kronecker_symbol")[#text("Kronecker symbol")]#text(" ")#mi("{\\chi(n) = \\left( \\frac{n}{q} \\right)}")#text(", in which numbers ")#mi("{n}")#text(" which are quadratic nonresidues mod ")#mi("{q}")#text(" are very likely to be prime, and quadratic residues mod ")#mi("{q}")#text(" are unlikely to be prime. Indeed, there is a scenario of this form – the ")#link("http://en.wikipedia.org/wiki/Siegel_zero")[#text("Siegel zero")]#text(" scenario – which we are still not able to eradicate (without assuming powerful conjectures such as ")#link("http://en.wikipedia.org/wiki/Generalized_Riemann_hypothesis")[#text("GRH")]#text("), though fortunately Siegel zeroes are not quite strong enough to destroy the prime number theorem in arithmetic progressions.")

#text("It is difficult to prove that no conspiracy between the primes exist. However, it is not entirely impossible, because we have been able to exploit two important phenomena. The first is that there is often a “all or nothing dichotomy” (somewhat resembling the ")#emph[#text("zero-one laws")]#text(" in probability) regarding conspiracies: in the asymptotic limit, the primes can either conspire totally (or more precisely, anti-conspire totally) with a multiplicative function, or fail to conspire at all, but there is no middle ground. (In the language of Dirichlet series, this is reflected in the fact that zeroes of a meromorphic function can have order ")#mi("{1}")#text(", or order ")#mi("{0}")#text(" (i.e. are not zeroes after all), but cannot have an intermediate order between ")#mi("{0}")#text(" and ")#mi("{1}")#text(".) As a corollary of this fact, the prime numbers cannot conspire with two distinct multiplicative functions at once (by having a partial correlation with one and another partial correlation with another); thus one can use the existence of one conspiracy to exclude all the others. In other words, there is at most one conspiracy that can significantly distort the distribution of the primes. Unfortunately, this argument is ")#emph[#text("ineffective")]#text(", because it doesn’t give any control at all on what that conspiracy is, or even if it exists in the first place!")

#text("But now one can use the second important phenomenon, which is that because of symmetries, one type of conspiracy can lead to another. For instance, because the von Mangoldt function is real-valued rather than complex-valued, we have conjugation symmetry; if the primes correlate with, say, ")#mi("{n^{it}}")#text(", then they must also correlate with ")#mi("{n^{-it}}")#text(". (In the language of Dirichlet series, this reflects the fact that the zeta function and ")#mi("{L}")#text("-functions enjoy symmetries with respect to reflection across the real axis (i.e. complex conjugation).) Combining this observation with the all-or-nothing dichotomy, we conclude that the primes cannot correlate with ")#mi("{n^{it}}")#text(" for any non-zero ")#mi("{t}")#text(", which in fact leads directly to the prime number theorem ")#link(<tao-a160524700113ddd3205>)[#text("(2)")]#text(", as we shall discuss below. Similarly, if the primes correlated with a Dirichlet character ")#mi("{\\chi(n)}")#text(", then they would also correlate with the conjugate ")#mi("{\\overline{\\chi}(n)}")#text(", which also is inconsistent with the all-or-nothing dichotomy, except in the exceptional case when ")#mi("{\\chi}")#text(" is real – which essentially means that ")#mi("{\\chi}")#text(" is a quadratic character. In this one case (which is the only scenario which comes close to threatening the truth of the prime number theorem in arithmetic progressions), the above tricks fail and one has to instead exploit the algebraic number theory properties of these characters instead, which has so far led to weaker results than in the non-real case.")

#text("As mentioned previously in passing, these phenomena are usually presented using the language of Dirichlet series and complex analysis. This is a very slick and powerful way to do things, but I would like here to present the elementary approach to the same topics, which is slightly weaker but which I find to also be very instructive. (However, I will not be ")#emph[#text("too")]#text(" dogmatic about keeping things elementary, if this comes at the expense of obscuring the key ideas; in particular, I will rely on multiplicative Fourier analysis (both at ")#mi("{\\infty}")#text(" and at finite places) as a substitute for complex analysis in order to expedite various parts of the argument. Also, the emphasis here will be more on heuristics and intuition than on rigour.)")

#text("The material here is closely related to the theory of ")#emph[#text("pretentious characters")]#text(" developed ")#link("http://arxiv.org/abs/math/0503113")[#text("by Granville and Soundararajan")]#text(", as well as an ")#link("http://www.dms.umontreal.ca/%7Eandrew/PDF/PNTforaps.pdf")[#text("earlier paper of Granville")]#text(" on elementary proofs of the prime number theorem in arithmetic progressions.")

#metadata(none) <tao-d5b07b591fb6d54de93f>

#heading(level: 1)[#strong[#text(" — 1. A heuristic elementary proof of the prime number theorem — ")]]

#text("To motivate some of the later discussion, let us first give a highly non-rigorous ")#emph[#text("heuristic")]#text(" elementary “proof” of the prime number theorem ")#link(<tao-a160524700113ddd3205>)[#text("(2)")]#text(". Since we clearly have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} 1 = x + O(1)")]]

#text("one can view the prime number theorem as an assertion that the von Mangoldt function ")#mi("{\\Lambda}")#text(" “behaves like ")#mi("{1}")#text(" on the average”, ")#metadata(none) <tao-295a89c5af71c61e2351>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\Lambda(n) \\approx 1,")]]

#text(" where we will be deliberately vague as to what the “")#mi("{\\approx}")#text("” symbol means. (One can think of this symbol as denoting some sort of proximity in the ")#link("http://en.wikipedia.org/wiki/Weak_topology")[#text("weak topology")]#text(" or ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague topology")]#text(", after suitable normalisation.)")

#text("To see why one would expect ")#link(<tao-295a89c5af71c61e2351>)[#text("(3)")]#text(" to be true, we take divisor sums of ")#link(<tao-295a89c5af71c61e2351>)[#text("(3)")]#text(" to heuristically obtain ")#metadata(none) <tao-60c6cab5f16620560b29>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{d|n} \\Lambda(d) \\approx \\sum_{d|n} 1.")]]

#text(" By ")#link(<tao-3c15dc2308570c62ec4a>)[#text("(1)")]#text(", the left-hand side is ")#mi("{\\log n}")#text("; meanwhile, the right-hand side is the ")#link("http://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]#text(" ")#mi("{\\tau(n)}")#text(" of ")#mi("{n}")#text(", by definition. So we have a heuristic relationship between ")#link(<tao-295a89c5af71c61e2351>)[#text("(3)")]#text(" and the informal approximation ")#metadata(none) <tao-060a3ea9811dd512da5b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\tau(n) \\approx \\log n.")]]

#text(" In particular, we expect ")#metadata(none) <tao-0d72e3ffaa9dc6ebab30>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{n \\leq x} \\tau(n) \\approx \\sum_{n \\leq x} \\log n.")]]



#text("The right-hand side of ")#link(<tao-0d72e3ffaa9dc6ebab30>)[#text("(6)")]#text(" can be approximated using the ")#link("http://en.wikipedia.org/wiki/Integral_test")[#text("integral test")]#text(" as ")#metadata(none) <tao-4011393f356a69582a25>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\sum_{n \\leq x} \\log n = \\int_1^x \\log t\\ dt + O(\\log x ) = x \\log x - x + O(\\log x)")]]

#text(" (one can also use ")#link("http://en.wikipedia.org/wiki/Stirling%27s_formula")[#text("Stirling’s formula")]#text(" to obtain a similar asymptotic). As for the left-hand side, we write ")#mi("{\\tau(n) = \\sum_{d|n} 1}")#text(" and then make the substitution ")#mi("{n=dm}")#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau(n) = \\sum_{d,m: dm \\leq x} 1.")]]

#text("The right-hand side is the number of lattice points underneath the hyperbola ")#mi("{dm=x}")#text(", and can be counted using the ")#link("https://en.wikipedia.org/wiki/Dirichlet_hyperbola_method")[#text("Dirichlet hyperbola method")]#text(":")

#align(center)[#tao-fit-display[#mitex("\\sum_{d,m: dm \\leq x} 1 = \\sum_{d \\leq \\sqrt{x}} \\sum_{m \\leq x/d} 1 + \\sum_{m \\leq \\sqrt{x}} \\sum_{d \\leq x/m} 1 - \\sum_{d \\leq \\sqrt{x}} \\sum_{m \\leq \\sqrt{x}} 1.")]]

#text("The third sum is equal to ")#mi("{(\\sqrt{x}+O(1))^2 = x + O(\\sqrt{x})}")#text(". The second sum is equal to the first. The first sum can be computed as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq \\sqrt{x}} \\sum_{m \\leq x/d} 1 = \\sum_{d \\leq \\sqrt{x}} (\\frac{x}{d} + O(1)) = x \\sum_{d \\leq \\sqrt{x}} \\frac{1}{d} + O(\\sqrt{x});")]]

#text("meanwhile, from the ")#link("http://en.wikipedia.org/wiki/Integral_test")[#text("integral test")]#text(" and the definition of ")#link("http://en.wikipedia.org/wiki/Euler%E2%80%93Mascheroni_constant")[#text("Euler’s constant")]#text(" ")#mi("{\\gamma = 0.577\\ldots}")#text(" one has ")#metadata(none) <tao-416794700a7453941b18>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\sum_{d \\leq y} \\frac{1}{d} = \\log y + \\gamma + O(1/y)")]]

#text(" for any ")#mi("{y \\geq 1}")#text("; combining all these estimates one obtains ")#metadata(none) <tao-fa8ff100f3a0f5a4d2a8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\sum_{n \\leq x} \\tau(n) = x \\log x + (2\\gamma-1) x + O(\\sqrt{x}).")]]

#text(" Comparing this with ")#link(<tao-4011393f356a69582a25>)[#text("(7)")]#text(" we do see that ")#mi("{\\tau(n)}")#text(" and ")#mi("{\\log n}")#text(" are roughly equal “to top order” on average, thus giving some form of ")#link(<tao-060a3ea9811dd512da5b>)[#text("(5)")]#text(" and hence ")#link(<tao-60c6cab5f16620560b29>)[#text("(4)")]#text("; if one could somehow invert the divisor sum operation, one could hope to get ")#link(<tao-295a89c5af71c61e2351>)[#text("(3)")]#text(" and thus the prime number theorem.")

#text("(Looking at the next highest order terms in ")#link(<tao-4011393f356a69582a25>)[#text("(7)")]#text(", ")#link(<tao-fa8ff100f3a0f5a4d2a8>)[#text("(9)")]#text(", we see that we expect ")#mi("{\\tau(n)}")#text(" to in fact be slightly larger than ")#mi("{\\log n}")#text(" on the average, and so ")#mi("{\\Lambda(n)}")#text(" should be slightly less than ")#mi("{1}")#text(" on the average. There is indeed a slight effect of this form; for instance, it is possible (using the prime number theorem) to prove")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq y} \\frac{\\Lambda(d)}{d} = \\log y - \\gamma + o(1),")]]

#text("which should be compared with ")#link(<tao-416794700a7453941b18>)[#text("(8)")]#text(".)")

#text("One can partially translate the above discussion into the language of Dirichlet series, by transforming various arithmetical functions ")#mi("{f(n)}")#text(" to their associated Dirichlet series")

#align(center)[#tao-fit-display[#mitex("F(s) := \\sum_{n=1}^\\infty \\frac{f(n)}{n^s},")]]

#text("ignoring for now the issue of convergence of this series. By definition, the constant function ")#mi("{1}")#text(" transforms to the Riemann zeta function ")#mi("{\\zeta(s)}")#text(". Taking derivatives in ")#mi("{s}")#text(", we see (formally, at least) that if ")#mi("{f(n)}")#text(" has Dirichlet series ")#mi("{F(s)}")#text(", then ")#mi("{f(n) \\log n}")#text(" has Dirichlet series ")#mi("{-F^{\\prime}(s)}")#text("; thus, for instance, ")#mi("{\\log n}")#text(" has Dirichlet series ")#mi("{-\\zeta^{\\prime}(s)}")#text(".")

#text("Most importantly, though, if ")#mi("{f(n), g(n)}")#text(" have Dirichlet series ")#mi("{F(s), G(s)}")#text(" respectively, then their ")#link("http://en.wikipedia.org/wiki/Dirichlet_convolution")[#text("Dirichlet convolution")]#text(" ")#mi("{f * g(n) := \\sum_{d|n} f(d) g(\\frac{n}{d})}")#text(" has Dirichlet series ")#mi("{F(s) G(s)}")#text("; this is closely related to the well-known ability of the Fourier transform to convert convolutions to pointwise multiplication. Thus, for instance, ")#mi("{\\tau(n)}")#text(" has Dirichlet series ")#mi("{\\zeta(s)^2}")#text(". Also, from ")#link(<tao-3c15dc2308570c62ec4a>)[#text("(1)")]#text(" and the preceding discussion, we see that ")#mi("{\\Lambda(n)}")#text(" has Dirichlet series ")#mi("{-\\zeta^{\\prime}(s)/\\zeta(s)}")#text(" (formally, at least). This already suggests that the von Mangoldt function will be sensitive to the zeroes of the zeta function.")

#text("An integral test computation closely related to ")#link(<tao-416794700a7453941b18>)[#text("(8)")]#text(" gives the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) = \\frac{1}{s-1} + \\gamma + O(s-1)")]]

#text("for ")#mi("{s}")#text(" close to one (and ")#mi("{\\text{Re}(s) > 1}")#text(", to avoid issues of convergence). This implies that the Dirichlet series ")#mi("{-\\zeta^{\\prime}(s)/\\zeta(s)}")#text(" for ")#mi("{\\Lambda(n)}")#text(" has asymptotic")

#align(center)[#tao-fit-display[#mitex("\\frac{-\\zeta^{\\prime}(s)}{\\zeta(s)} = \\frac{1}{s-1} - \\gamma + O(s-1)")]]

#text("thus giving support to ")#link(<tao-295a89c5af71c61e2351>)[#text("(3)")]#text("; similarly, the Dirichlet series for ")#mi("{\\log n}")#text(" and ")#mi("{\\tau(n)}")#text(" have asymptotic")

#align(center)[#tao-fit-display[#mitex("-\\zeta^{\\prime}(s) = \\frac{1}{(s-1)^2} + O(1)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\zeta(s)^2 = \\frac{1}{(s-1)^2} + \\frac{2\\gamma}{s-1} + O(1)")]]

#text("which gives support to ")#link(<tao-060a3ea9811dd512da5b>)[#text("(5)")]#text(" (and is also consistent with ")#link(<tao-4011393f356a69582a25>)[#text("(7)")]#text(", ")#link(<tao-fa8ff100f3a0f5a4d2a8>)[#text("(9)")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One can connect the properties of Dirichlet series ")#mi("{F(s)}")#text(" more rigorously to asymptotics of partial sums ")#mi("{\\sum_{n \\leq x} f(n)}")#text(" by means of various transforms in Fourier analysis and complex analysis, in particular contour integration or the Hilbert transform, but this becomes somewhat technical and we will not do so here. I will remark, though, that asymptotics of ")#mi("{F(s)}")#text(" for ")#mi("{s}")#text(" close to ")#mi("{1}")#text(" are not enough, by themselves, to get really precise asymptotics for the sharply truncated partial sums ")#mi("{\\sum_{n \\leq x} f(n)}")#text(", for reasons related to the uncertainty principle; in order to control such sums one also needs to understand the behaviour of ")#mi("{F}")#text(" far away from ")#mi("{s=1}")#text(", and in particular for ")#mi("{s=1+it}")#text(" for large real ")#mi("{t}")#text(". On the other hand, the asymptotics for ")#mi("{F(s)}")#text(" for ")#mi("{s}")#text(" near ")#mi("{1}")#text(" are just about all one needs to control ")#emph[#text("smoothly")]#text(" truncated partial sums such as ")#mi("{\\sum_n f(n) \\eta(n/x)}")#text(" for suitable cutoff functions ")#mi("{\\eta}")#text(". Also, while Dirichlet series are very powerful tools, particularly with regards to understanding Dirichlet convolution identities, and controlling everything in terms of the zeroes and poles of such series, they do have the drawback that they do not easily encode such fundamental “physical space” facts as the pointwise inequalities ")#tao-math("{\\left|\\mu(n)\\right| \\leq 1}", block: false)#text(" and ")#mi("{\\Lambda(n) \\geq 0}")#text(", which are also an important aspect of the theory.")
]

#heading(level: 1)[#strong[#text(" — 2. Almost primes — ")]]

#text("One can hope to make the above heuristics precise by applying the ")#link("http://en.wikipedia.org/wiki/M%C3%B6bius_inversion_formula")[#text("Möbius inversion formula")]

#align(center)[#tao-fit-display[#mitex("1_{n=1} = \\sum_{d|n} \\mu(d)")]]

#text("where ")#mi("{\\mu(d)}")#text(" is the ")#link("http://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(", defined as ")#mi("{(-1)^k}")#text(" when ")#mi("{d}")#text(" is the product of ")#mi("{k}")#text(" distinct primes for some ")#mi("{k \\geq 0}")#text(", and zero otherwise. In terms of Dirichlet series, we thus see that ")#mi("{\\mu}")#text(" has the Dirichlet series of ")#mi("{1/\\zeta(s)}")#text(", and so can invert the divisor sum operation ")#mi("{f(n) \\mapsto \\sum_{d|n} f(d)}")#text(" (which corresponds to multiplication by ")#mi("{\\zeta(s)}")#text("):")

#align(center)[#tao-fit-display[#mitex("f(n) = \\sum_{m|n} \\mu(m) ( \\sum_{d|n/m} f(d) ).")]]

#text("From ")#link(<tao-3c15dc2308570c62ec4a>)[#text("(1)")]#text(" we then conclude ")#metadata(none) <tao-096b3764d961902778a5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\Lambda(n) = \\sum_{d|n} \\mu(d) \\log \\frac{n}{d}")]]

#text(" while from ")#mi("{\\tau(n) = \\sum_{d|n} 1}")#text(" we have ")#metadata(none) <tao-52bee9281319109ace8e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("1 = \\sum_{d|n} \\mu(d) \\tau(\\frac{n}{d}).")]]

#text(" One can now hope to derive the prime number theorem ")#link(<tao-a160524700113ddd3205>)[#text("(2)")]#text(" from the formulae ")#link(<tao-4011393f356a69582a25>)[#text("(7)")]#text(", ")#link(<tao-fa8ff100f3a0f5a4d2a8>)[#text("(9)")]#text(". Unfortunately, this doesn’t quite work: the prime number theorem is equivalent to the assertion ")#metadata(none) <tao-24a9245816c9847718fd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\sum_{n \\leq x} (\\Lambda(n)-1) = o(x),")]]

#text(" but if one inserts ")#link(<tao-096b3764d961902778a5>)[#text("(10)")]#text(", ")#link(<tao-52bee9281319109ace8e>)[#text("(11)")]#text(" into the left-hand side of ")#link(<tao-24a9245816c9847718fd>)[#text("(12)")]#text(", one obtains")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x} \\mu(d) \\sum_{m \\leq x/d} (\\log m - \\tau(m)),")]]

#text("which if one then inserts ")#link(<tao-4011393f356a69582a25>)[#text("(7)")]#text(", ")#link(<tao-fa8ff100f3a0f5a4d2a8>)[#text("(9)")]#text(" and the trivial bound ")#mi("{\\mu(d)=O(1)}")#text(", leads to")

#align(center)[#tao-fit-display[#mitex("2C x \\sum_{d \\leq x} \\frac{\\mu(d)}{d} + O(x).")]]

#text("As noted in this ")#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/")[#text("previous post")]#text(", we have ")#metadata(none) <tao-a1d9890884c1b4b960c2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left|\\sum_{d \\leq x} \\frac{\\mu(d)}{d}\\right| \\leq 1,", block: true)]]

#text(" so we only obtain a bound of ")#mi("{O(x)}")#text(" for ")#link(<tao-24a9245816c9847718fd>)[#text("(12)")]#text(" instead of ")#mi("{o(x)}")#text(". (A refinement of this argument, though, shows that the prime number theorem would follow if one had the asymptotic ")#mi("{\\sum_{n \\leq x} \\mu(n) = o(x)}")#text(", which is in fact equivalent to the prime number theorem; see ")#link("https://terrytao.wordpress.com/2009/08/30/an-elementary-inequality-involving-the-mobius-function/")[#text("the previous post")]#text(".)")

#text("We remark that if one computed ")#mi("{\\sum_{n \\leq x} \\tau(n)}")#text(" or ")#mi("{\\sum_{n \\leq x} \\Lambda(n)}")#text(" by the above methods, one would eventually be led to a variant of ")#link(<tao-a1d9890884c1b4b960c2>)[#text("(13)")]#text(", namely ")#metadata(none) <tao-17a380fcbde29a032169>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\sum_{d \\leq x} \\frac{\\mu(d)}{d} \\log \\frac{x}{d} = O(1),")]]

#text(" which is an estimate which will be useful later.")

#text("So we see that when trying to sum the von Mangoldt function ")#mi("{\\Lambda}")#text(" by elementary means, the error term ")#mi("{O(x)}")#text(" overwhelms the main term ")#mi("{x}")#text(". But there is a slight tweaking of the von Mangoldt function, the ")#emph[#text("second von Mangoldt function")]#text(" ")#mi("{\\Lambda_2}")#text(", that increases the size of the main term to ")#mi("{2x \\log x}")#text(" while keeping the error term at ")#mi("{O(x)}")#text(", thus leading to a useful estimate; the price one pays for this is that this function is now a proxy for the ")#link("http://en.wikipedia.org/wiki/Almost_prime")[#text("almost primes")]#text(" rather than the primes. This function is defined by a variant of ")#link(<tao-096b3764d961902778a5>)[#text("(10)")]#text(", namely ")#metadata(none) <tao-d082efec8581f3fac1b9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\Lambda_2(n) = \\sum_{d|n} \\mu(d) \\log^2 \\frac{n}{d}.")]]

#text(" It is not hard to see that ")#mi("{\\Lambda_2(n)}")#text(" vanishes once ")#mi("{n}")#text(" has at least three distinct prime factors (basically because the quadratic function ")#mi("{x \\mapsto x^2}")#text(" vanishes after being differentiated three or more times). Indeed, one can easily verify the identity ")#metadata(none) <tao-9278f24591f8fd30956c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\Lambda_2(n) = \\Lambda(n) \\log n + \\Lambda*\\Lambda(n)")]]

#text(" (which corresponds to the Dirichlet series identity ")#mi("{\\zeta^{\\prime\\prime}(s)/\\zeta(s) = -(-\\zeta^{\\prime}(s)/\\zeta(s))^{\\prime} + (-\\zeta^{\\prime}(s)/\\zeta(s))^2}")#text("); the first term ")#mi("{\\Lambda(n) \\log n}")#text(" is mostly concentrated on primes, while the second term ")#mi("{\\Lambda*\\Lambda(n)}")#text(" is mostly concentrated on ")#link("http://en.wikipedia.org/wiki/Semiprime")[#text("semiprimes")]#text(" (products of two distinct primes).")

#text("Now let us sum ")#mi("{\\Lambda_2(n)}")#text(". In analogy with the previous discussion, we will do so by comparing the function ")#mi("{\\log^2 n}")#text(" with something involving the divisor function. In view of ")#link(<tao-060a3ea9811dd512da5b>)[#text("(5)")]#text(", it is reasonable to try the approximation")

#align(center)[#tao-fit-display[#mitex("\\log^2 n \\approx \\tau(n) \\log n;")]]

#text("from the identity ")#metadata(none) <tao-3ca72303bc71acdaef74>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("2 \\log n = \\sum_{d|n} \\mu(d) \\tau(\\frac{n}{d}) \\log \\frac{n}{d}")]]

#text(" (which corresponds to the Dirichlet series identity ")#mi("{- 2 \\zeta^{\\prime}(s) = \\frac{1}{\\zeta(s)} -(\\zeta^2(s))^{\\prime}}")#text(") we thus expect ")#metadata(none) <tao-23bfe9bd4d05500eba88>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\Lambda_2(n) \\approx 2\\log n.")]]



#text("Now we make these heuristics more precise. From the integral test we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\log^2 n = x \\log^2 x + C_1 x \\log x + C_2 x + O(\\log^2 x)")]]

#text("while from ")#link(<tao-fa8ff100f3a0f5a4d2a8>)[#text("(9)")]#text(" and summation by parts one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\tau(n) \\log n = x \\log^2 x + C_3 x \\log x + C_4 x + O(\\sqrt{x} \\log x)")]]

#text("where ")#mi("{C_1,C_2,C_3,C_4}")#text(" are explicit absolute constants whose exact value is not important here. Thus ")#metadata(none) <tao-c432b3dedcd6852f1ab5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\sum_{n \\leq x} (\\log^2 n - \\tau(n) \\log n) = C_5 x \\log x + C_6 x + O(\\sqrt{x} \\log x)")]]

#text(" for some other constants ")#mi("{C_5, C_6}")#text(".")

#text("Meanwhile, from ")#link(<tao-d082efec8581f3fac1b9>)[#text("(15)")]#text(", ")#link(<tao-3ca72303bc71acdaef74>)[#text("(17)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} (\\Lambda_2(n) - 2\\log(n)) = \\sum_{d \\leq x} \\mu(d) \\sum_{m \\leq x/d} \\log^2 n - \\tau(n) \\log n;")]]

#text("applying ")#link(<tao-c432b3dedcd6852f1ab5>)[#text("(19)")]#text(", ")#link(<tao-a1d9890884c1b4b960c2>)[#text("(13)")]#text(", ")#link(<tao-17a380fcbde29a032169>)[#text("(14)")]#text(" we see that the right-hand side is ")#mi("{O(x)}")#text(". Computing ")#mi("{\\sum_{n \\leq x} \\log n}")#text(" by the integral test, we deduce the ")#emph[#text("Selberg symmetry formula")]#text(" ")#metadata(none) <tao-23a00161627a8ac18e30>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\sum_{n \\leq x} \\Lambda_2(n) = 2 x \\log x + O(x).")]]

#text(" One can view ")#link(<tao-23a00161627a8ac18e30>)[#text("(20)")]#text(" as the “almost prime number theorem” – the analogue of the prime number theorem for almost primes.")

#text("The fact that the almost primes have a relatively easy asymptotic, while the genuine primes do not, is a reflection of the ")#emph[#text("parity problem")]#text(" in sieve theory; see ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("this post")]#text(" for further discussion. The symmetry formula is however enough to get “within a factor of two” of the prime number theorem: if we discard the semiprimes ")#mi("{\\Lambda*\\Lambda}")#text(" from ")#link(<tao-9278f24591f8fd30956c>)[#text("(16)")]#text(", we see that ")#mi("{\\Lambda(n) \\log n \\leq \\Lambda_2(n)}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\log n \\leq 2 x \\log x + O(x)")]]

#text("which by a summation by parts argument leads to")

#align(center)[#tao-fit-display[#mitex("0 \\leq \\sum_{n \\leq x} \\Lambda(n) \\leq 2 x + O(\\frac{x}{\\log x}),")]]

#text("which is within a factor of ")#mi("{2}")#text(" of ")#link(<tao-a160524700113ddd3205>)[#text("(2)")]#text(" in some sense.")

#text("One can “twist” all of the above arguments by a Dirichlet character ")#mi("{\\chi}")#text(". For instance, ")#link(<tao-d082efec8581f3fac1b9>)[#text("(15)")]#text(" twists to")

#align(center)[#tao-fit-display[#mitex("\\Lambda_2(n) \\chi(n) = \\sum_{d|n} \\mu(d)\\chi(d) \\log^2 \\frac{n}{d} \\chi(\\frac{n}{d}).")]]

#text("On the other hand, if ")#mi("{\\chi}")#text(" is a non-principal character of modulus ")#mi("{q}")#text(", then it has mean zero on any interval with length ")#mi("{q}")#text(", and it is then not hard to establish the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq y} \\log^2 n \\chi(n) = O_q(\\log^2 y).")]]

#text("This soon leads to the twisted version of ")#link(<tao-23a00161627a8ac18e30>)[#text("(20)")]#text(": ")#metadata(none) <tao-4850247e434b138c592b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\sum_{n \\leq x} \\Lambda_2(n) \\chi(n) = O_q(x),")]]

#text(" thus almost primes are asymptotically unbiased with respect to non-principal characters.")

#text("From the multiplicative Fourier analysis of Dirichlet characters modulo ")#mi("{q}")#text(" (and the observation that ")#mi("{\\Lambda_2}")#text(" is quite small on residue classes not coprime to ")#mi("{q}")#text(") one then has an “almost prime number theorem in arithmetic progressions”:")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: n = a \\mod q} \\Lambda_2(n) = \\frac{2}{\\phi(q)} x \\log x + O_q(x).")]]

#text("As before, this lets us come within a factor of two of the actual prime number theorem in arithmetic progressions:")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: n = a \\mod q} \\Lambda(n) \\leq \\frac{2}{\\phi(q)} x + O_q(\\frac{x}{\\log x}).")]]

#text("One can also twist things by the completely multiplicative function ")#mi("{n \\mapsto n^{it}}")#text(", but with the caveat that the approximation ")#mi("{2 \\log n}")#text(" to ")#mi("{\\Lambda_2(n)}")#text(" can locally correlate with ")#mi("{n^{it}}")#text(". Thus for instance one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} (\\Lambda_2(n)-2 \\log n) \\chi(n) n^{it} = O_q(x)")]]

#text("for any fixed ")#mi("{t}")#text(" and ")#mi("{\\chi}")#text("; in particular, if ")#mi("{\\chi}")#text(" is non-principal, one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda_2(n) \\chi(n) n^{it} = O_q(x).")]]

#heading(level: 1)[#strong[#text(" — 3. The all-or-nothing dichotomy — ")]]

#text("To summarise so far, the almost primes (as represented by ")#mi("{\\Lambda_2}")#text(") are quite uniformly distributed. These almost primes can be split up into the primes (as represented by ")#mi("{\\Lambda(n) \\log n}")#text(") and the semiprimes (as represented by ")#mi("{\\Lambda*\\Lambda(n)}")#text("), thanks to ")#link(<tao-9278f24591f8fd30956c>)[#text("(16)")]#text(".")

#text("One can rewrite ")#link(<tao-9278f24591f8fd30956c>)[#text("(16)")]#text(" as a recursive formula for ")#mi("{\\Lambda}")#text(": ")#metadata(none) <tao-3598ce6f965b2481fe26>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\Lambda(n) = \\frac{1}{\\log n} \\Lambda_2(n) - \\frac{1}{\\log n} \\Lambda * \\Lambda(n).")]]

#text(" One can also twist this formula by a character ")#mi("{\\chi}")#text(" and/or a completely multiplicative function ")#mi("{n \\mapsto n^{it}}")#text(", thus for instance ")#metadata(none) <tao-669cd16498cb442216f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\Lambda \\chi(n) = \\frac{1}{\\log n} \\Lambda_2 \\chi(n) - \\frac{1}{\\log n} \\Lambda \\chi * \\Lambda \\chi(n).")]]

#text(" This recursion, combined with the uniform distribution properties on ")#mi("{\\Lambda_2}")#text(", lead to various ")#emph[#text("all-or-nothing")]#text(" dichotomies for ")#mi("{\\Lambda}")#text(". Suppose, for instance, that ")#mi("{\\Lambda \\chi}")#text(" behaves like a constant ")#mi("{c}")#text(" on the average for some non-principal character ")#mi("{\\chi}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\Lambda \\chi(n) \\approx c.")]]

#text("Then (from ")#link(<tao-060a3ea9811dd512da5b>)[#text("(5)")]#text(") we expect ")#mi("{\\Lambda \\chi * \\Lambda \\chi}")#text(" to behave like ")#mi("{c^2 \\log n}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log n} \\Lambda \\chi * \\Lambda \\chi(n) \\approx c^2.")]]

#text("On the other hand, from ")#link(<tao-4850247e434b138c592b>)[#text("(21)")]#text(", ")#mi("{\\frac{1}{\\log n} \\Lambda_2(n)}")#text(" is asymptotically uncorrelated with ")#mi("{\\chi}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log n} \\Lambda_2 \\chi \\approx 0.")]]

#text("Putting all this together, one obtains")

#align(center)[#tao-fit-display[#mitex("c \\approx -c^2")]]

#text("which suggests that ")#mi("{c}")#text(" must be either close to ")#mi("{0}")#text(", or close to ")#mi("{-1}")#text(".")

#text("Basically, the point is that there are only two equilibria for the recursion ")#link(<tao-669cd16498cb442216f0>)[#text("(23)")]#text(". One equilibrium occurs when ")#mi("{\\Lambda}")#text(" is asymptotically uncorrelated with ")#mi("{\\chi}")#text("; the other is when it is completely anti-correlated with ")#mi("{\\chi}")#text(", so that ")#mi("{\\Lambda(n)}")#text(" is supported primarily on those ")#mi("{n}")#text(" for which ")#mi("{\\chi(n)}")#text(" is close to ")#mi("{-1}")#text(". Note in the latter case ")#mi("{\\chi(n) \\approx -1}")#text(" for most primes ")#mi("{n}")#text(", and thus ")#mi("{\\chi(n) \\approx +1}")#text(" for most semiprimes ")#mi("{n}")#text(", thus leading to an equidistribution of ")#mi("{\\chi(n)}")#text(" for almost primes (weighted by ")#mi("{\\Lambda_2}")#text("). Any intermediate distribution of ")#mi("{\\Lambda \\chi}")#text(" would be inconsistent with the distribution of ")#mi("{\\Lambda_2 \\chi}")#text(". (In terms of Dirichlet series, this assertion corresponds to the fact that the ")#mi("{L}")#text("-function of ")#mi("{\\chi}")#text(" either has a zero of order ")#mi("{1}")#text(", or a zero of order ")#mi("{0}")#text(" (i.e. not a zero at all) at ")#mi("{s=1}")#text(".)")

#text("A similar phenomenon occurs when twisting ")#mi("{\\Lambda}")#text(" by ")#mi("{n^{it}}")#text("; basically, the average value of ")#mi("{(\\Lambda(n)-1) n^{it}}")#text(" must asymptotically either be close to ")#mi("{0}")#text(", or close to ")#mi("{-1}")#text("; no other asymptotic ends up being compatible with the distribution of ")#mi("{(\\Lambda_2(n)-2\\log n) n^{it}}")#text(". (Again, this corresponds to the fact that the Riemann zeta function has a zero of order ")#mi("{1}")#text(" or ")#mi("{0}")#text(" at ")#mi("{1+it}")#text(".) More generally, the average value of ")#mi("{(\\Lambda(n)-1) \\chi(n) n^{it}}")#text(" must asymptotically approach either ")#mi("{0}")#text(" or ")#mi("{-1}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can make the above heuristics precise either by using Dirichlet series (and analytic continuation, and the theory of zeroes of meromorphic functions), or by smoothing out arithmetic functions such as ")#mi("{\\Lambda \\chi}")#text(" by a suitable multiplicative convolution with a mollifier (as is basically done in elementary proofs of the prime number theorem); see also ")#link("http://arxiv.org/abs/math/0503113")[#text("the Granville-Soundararajan theory of pretentious characters")]#text(" for a closely related theory. We will not pursue these details here, however.")
]

#heading(level: 1)[#strong[#text(" — 4. Dueling conspiracies — ")]]

#metadata(none) <tao-4feefcf7f0d7745c8152>

#text("In the previous section we have seen (heuristically, at least), that the von Mangoldt function ")#mi("{\\Lambda(n)}")#text(" (or more precisely, ")#mi("{\\Lambda(n)-1}")#text(") will either have no correlation, or a maximal amount of anti-correlation, with a completely multiplicative function such as ")#mi("{\\chi(n)}")#text(", ")#mi("{n^{it}}")#text(", or ")#mi("{\\chi(n) n^{it}}")#text(". On the other hand, it is not possible for this function to maximally anti-correlate (or to ")#emph[#text("conspire")]#text(") with two such functions; thus the presence of one conspiracy excludes the presence of all others.")

#text("Suppose for instance that we had two distinct non-principal characters ")#mi("{\\chi, \\chi^{\\prime}}")#text(" for which one had maximal anti-correlation:")

#align(center)[#tao-fit-display[#mitex("\\Lambda(n) \\chi(n), \\Lambda(n) \\chi^{\\prime}(n) \\approx -1.")]]

#text("One could then combine the two statements to obtain")

#align(center)[#tao-fit-display[#mitex("\\Lambda(n) (\\chi(n) + \\chi^{\\prime}(n)) \\approx -2.")]]

#text("Meanwhile, ")#mi("{\\frac{1}{\\log n} \\Lambda_2(n)}")#text(" doesn’t correlate with either ")#mi("{\\chi}")#text(" or ")#mi("{\\chi^{\\prime}}")#text(". It will be convenient to exploit this to normalise ")#mi("{\\Lambda}")#text(", obtaining")

#align(center)[#tao-fit-display[#mitex("(\\Lambda(n) - \\frac{1}{2\\log n} \\Lambda_2(n)) (\\chi(n) + \\chi^{\\prime}(n)) \\approx -2.")]]

#text("(Note from ")#link(<tao-295a89c5af71c61e2351>)[#text("(3)")]#text(", ")#link(<tao-23bfe9bd4d05500eba88>)[#text("(18)")]#text(" that we expect ")#mi("{\\Lambda(n) - \\frac{1}{2\\log n} \\Lambda_2(n)}")#text(" to have mean zero.)")

#text("On the other hand, since ")#mi("{0 \\leq \\Lambda(n) \\log n \\leq \\Lambda_2(n)}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Lambda(n) - \\frac{1}{2\\log n} \\Lambda_2(n)\\right| \\leq \\frac{1}{2\\log n} \\Lambda_2(n)", block: true)]]

#text("and hence by the triangle inequality")

#align(center)[#tao-fit-display[#mitex("\\Lambda_2(n) |\\chi(n) + \\chi^{\\prime}(n)| \\gtrapprox 4 \\log n")]]

#text("in the sense that averages of the left-hand side should be at least as large as averages of the right-hand side. From this, ")#link(<tao-23bfe9bd4d05500eba88>)[#text("(18)")]#text(", and Cauchy-Schwarz, one thus expects")

#align(center)[#tao-fit-display[#tao-math("\\Lambda_2(n) \\left|\\chi(n) + \\chi^{\\prime}(n)\\right|^2 \\gtrapprox 8 \\log n.", block: true)]]

#text("But if one expands out the left-hand side using ")#link(<tao-23bfe9bd4d05500eba88>)[#text("(18)")]#text(", ")#link(<tao-4850247e434b138c592b>)[#text("(21)")]#text(", one only ends up with ")#mi("{4 \\log n + O_q(1)}")#text(" on the average, a contradiction for ")#mi("{n}")#text(" sufficiently large.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The above argument belongs to a family of ")#mi("{L^2}")#text("-based arguments which go by various names (")#emph[#text("almost orthogonality")]#text(", ")#emph[#mi("{TT^*}")]#text(", ")#emph[#text("large sieve")]#text(", etc.). The ")#mi("{L^2}")#text(" argument can more generally be used to establish square-summability estimates on averages such as ")#mi("{\\frac{1}{x} \\sum_{n \\leq x} \\Lambda(n) \\chi(n)}")#text(" as ")#mi("{\\chi}")#text(" varies, but we will not make this precise here.")
]

#text("As one consequence of the above arguments, one can show that ")#mi("{\\Lambda(n)}")#text(" cannot maximally anti-correlate with any non-real character ")#mi("{\\chi}")#text(", since (by the reality of ")#mi("{\\Lambda}")#text(") it would then also maximally anti-correlate with the complex conjugate ")#mi("{\\overline{\\chi}}")#text(", which is distinct from ")#mi("{\\chi}")#text(". A similar argument shows that ")#mi("{\\Lambda(n)}")#text(" cannot maximally anti-correlate with ")#mi("{n^{it}}")#text(" for any non-zero ")#mi("{t}")#text(", a fact which can soon lead to the prime number theorem, either by Dirichlet series methods, by Fourier-analytic means, or by elementary means. (Sketch of Fourier-analytic proof: ")#mi("{L^2}")#text(" methods provide ")#mi("{L^2}")#text("-type bounds on the averages of ")#mi("{\\Lambda(n) n^{it}}")#text(" in ")#mi("{t}")#text(", while the above arguments show that these averages are also small in ")#mi("{L^\\infty}")#text(". Applying ")#link(<tao-3598ce6f965b2481fe26>)[#text("(22)")]#text(" a few times to take advantage of the smoothing effects of convolution, one eventually concludes that these averages can be made arbitrarily small in ")#mi("{L^1}")#text(" asymptotically, at which point the prime number theorem follows from Fourier inversion.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" There is a slightly different argument of an ")#mi("{L^1}")#text(" nature rather than an ")#mi("{L^2}")#text(" nature (i.e. using tools such as the triangle inequality, union bound, etc.) that can also achieve similar results. For instance, suppose that ")#mi("{\\Lambda(n)}")#text(" maximally anti-correlates with ")#mi("{\\chi}")#text(" and ")#mi("{\\chi^{\\prime}}")#text(". Then ")#mi("{\\chi(n), \\chi^{\\prime}(n) \\approx -1}")#text(" for most primes ")#mi("{n}")#text(", which implies that ")#mi("{\\chi \\chi^{\\prime}(n) \\approx +1}")#text(" for most primes ")#mi("{n}")#text(", which is incompatible with the all-or-nothing dichotomy unless ")#mi("{\\chi \\chi^{\\prime}}")#text(" is principal. This is an alternate way to exclude correlation with non-real characters. Similarly, if ")#mi("{\\Lambda(n) n^{it} \\approx -1}")#text(", then ")#mi("{\\Lambda(n) n^{2it} \\approx +1}")#text(", which is also incompatible with the zero-one law; this is essentially the method underlying the standard proof of the prime number theorem (which relates ")#mi("{\\zeta(1+it)}")#text(" with ")#mi("{\\zeta(1+2it)}")#text(").")
]

#heading(level: 1)[#strong[#text(" — 5. Quadratic characters — ")]]

#text("The one difficult scenario to eliminate is that of maximal anti-correlation with a real non-principal (i.e. quadratic) character ")#mi("{\\chi}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\Lambda(n) \\chi(n) \\approx -1.")]]

#text("This scenario implies that the quantity")

#align(center)[#tao-fit-display[#mitex("L(1,\\chi) := \\sum_{n=1}^\\infty \\frac{\\chi(n)}{n}")]]

#text("vanishes. Indeed, if one starts with the identity")

#align(center)[#tao-fit-display[#mitex("\\log n \\chi(n) = \\sum_{d|n} \\Lambda \\chi(d) \\chi(\\frac{n}{d})")]]

#text("and sums in ")#mi("{n}")#text(", one sees that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\log n \\chi(n) = \\sum_{d,m: dm \\leq x} \\Lambda \\chi(d) \\chi(m).")]]

#text("The left-hand side is ")#mi("{O_q( \\log x)}")#text(" by the mean zero and periodicity properties of ")#mi("{\\chi}")#text(". To estimate the right-hand side, we use the hyperbola method and rewrite it as")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\leq M} \\chi(m) \\sum_{d \\leq x/m} \\Lambda \\chi(d) + \\sum_{d \\leq x/M} \\Lambda \\chi(d) \\sum_{M < m \\leq x/d} \\chi(m)")]]

#text("for some parameter ")#mi("{M}")#text(" (sufficiently slowly growing in ")#mi("{x}")#text(") to be optimised later. Writing ")#mi("{\\sum_{d \\leq x/m} \\Lambda \\chi(d) = (-1 + o_q(1)) x/m}")#text(" and ")#mi("{\\sum_{M < m \\leq x/d} \\chi(m) = O_q(1)}")#text(", we can express this as")

#align(center)[#tao-fit-display[#mitex("x( \\sum_{m \\leq M} \\frac{\\chi(m)}{m} + o_q(1) ) + O_q( x / M );")]]

#text("sending ")#mi("{x \\rightarrow \\infty}")#text(" (and ")#mi("{M \\rightarrow \\infty}")#text(" at a slower rate) we conclude ")#mi("{L(1,\\chi)=0}")#text(" as required.")

#text("It is remarkably difficult to show that ")#mi("{L(1,\\chi)}")#text(" does not, in fact, vanish. One way to do this is to use the ")#link("http://en.wikipedia.org/wiki/Class_number_formula")[#text("class number formula")]#text(", that relates this quantity to the class number of the quadratic number field ")#mi("{{\\Bbb Q}(\\sqrt{-d})}")#text(" associated to the conductor ")#mi("{d}")#text(" of ")#mi("{\\chi}")#text(", together with some related number-theoretic quantities. A more elementary (but significantly weaker) method proceeds by using the easily verified fact that the convolution ")#mi("{1*\\chi}")#text(" is non-negative, and is at least ")#mi("{1}")#text(" on the squares; this should be interpreted as a fact from algebraic number theory, and basically corresponds to the fact that the number of representations of an integer ")#mi("{n}")#text(" as the norm ")#mi("{x^2 + d y^2}")#text(" of an integer in ")#mi("{{\\Bbb Z}(\\sqrt{d})}")#text(" (or more generally, as the norm of an ideal in that ring) is non-negative, and is at least ")#mi("{1}")#text(" on the squares. In particular we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{1*\\chi(n)}{\\sqrt{n}} \\geq \\frac{1}{2} \\log x + O(1).")]]

#text("On the other hand, from the hyperbola method we can express the left-hand side as ")#metadata(none) <tao-14ebe56a5008e7c25110>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\sum_{d \\leq \\sqrt{x}} \\frac{\\chi(d)}{\\sqrt{d}} \\sum_{m \\leq x/d} \\frac{1}{\\sqrt{m}} + \\sum_{m < \\sqrt{x}} \\frac{1}{\\sqrt{m}} \\sum_{\\sqrt{x} < d \\leq x/m} \\frac{\\chi(d)}{\\sqrt{d}}.")]]

#text(" From the mean zero and periodicity properties of ")#mi("{\\chi}")#text(" we have ")#mi("{\\sum_{\\sqrt{x} < d \\leq x/m} \\frac{\\chi(d)}{\\sqrt{d}} = O_q( x^{-1/4} )}")#text(", so the second term in ")#link(<tao-14ebe56a5008e7c25110>)[#text("(24)")]#text(" is ")#mi("{O_q(1)}")#text(". Meanwhile, from the ")#link("http://en.wikipedia.org/wiki/Midpoint_rule")[#text("midpoint rule")]#text(", ")#mi("{\\sum_{m \\leq y} \\frac{1}{\\sqrt{m}} = 2 \\sqrt{y} - \\frac{3}{2} + O( 1 / \\sqrt{y} )}")#text(", and so the first term in ")#link(<tao-14ebe56a5008e7c25110>)[#text("(24)")]#text(" is")

#align(center)[#tao-fit-display[#tao-math("2 \\sqrt{x} \\sum_{d \\leq \\sqrt{x}} \\frac{\\chi(d)}{d} + O( \\left|\\sum_{d \\leq \\sqrt{x}} \\frac{\\chi(d)}{\\sqrt{d}}\\right| ) + O( 1 ) = 2 \\sqrt{x} L(1,\\chi) + O(1).", block: true)]]

#text("Putting all this together we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\log x + O(1) \\leq 2 \\sqrt{x} L(1,\\chi) + O_q(1),")]]

#text("which leads to a contradiction as ")#mi("{x \\rightarrow \\infty}")#text(" if ")#mi("{L(1,\\chi)}")#text(" vanishes.")

#text("Note in fact that the above argument shows that ")#mi("{L(1,\\chi)}")#text(" is positive. If one carefully computes the dependence of the above argument on the modulus ")#mi("{q}")#text(", one obtains a lower bound of the form ")#mi("{L(1,\\chi) \\geq \\exp( -q^{1/2+o(1)} )}")#text(", which is quite poor. Using a non-trivial improvement on the error term in counting lattice points under the hyperbola (or better still, by smoothing the sum ")#mi("{\\sum_{n \\leq x}}")#text("), one can improve this a bit, to ")#mi("{L(1,\\chi) \\geq q^{-O(1)}}")#text(". In contrast, the class number method gives a bound ")#mi("{L(1,\\chi) \\geq q^{-1/2+o(1)}}")#text(".")

#text("We can improve this even further for all but at most one real primitive character ")#mi("{\\chi}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Siegel’s theorem)")]#text(" For every ")#mi("{\\epsilon > 0}")#text(", one has ")#mi("{L(1,\\chi) \\gg_\\epsilon q^{-\\epsilon}}")#text(" for all but at most one real primitive character ")#mi("{\\chi}")#text(", where the implied constant is effective, and ")#mi("{q}")#text(" is the modulus of ")#mi("{\\chi}")#text(".")
]

#text("Throwing in this (hypothetical) one exceptional character, we conclude that ")#mi("{L(1,\\chi) \\gg_\\epsilon q^{-\\epsilon}}")#text(" for ")#emph[#text("all")]#text(" real primitive characters ")#mi("{\\chi}")#text(", but now the implied constant is ineffective, which is the usual way in which Siegel’s theorem is formulated (but the above nearly effective refinement can be obtained by the same methods). It is a major open problem in the subject to eliminate this exceptional character and recover an effective estimate for some ")#mi("{\\epsilon < 1/2}")#text(".")

#emph[#text("Proof:")]#text(" Let ")#mi("{\\epsilon > 0}")#text(" (which we can assume to be small), and let ")#mi("{c > 0}")#text(" be a small number depending (effectively) on ")#mi("{\\epsilon}")#text(" to be chosen later. Our task is to show that ")#mi("{L(1,\\chi) \\geq c q^{-\\epsilon}}")#text(" for all but at most one primitive real character ")#mi("{\\chi}")#text(". Note we may assume ")#mi("{q}")#text(" is large (effectively) depending on ")#mi("{\\epsilon}")#text(", as the claim follows from the previous bounds on ")#mi("{L(1,\\chi)}")#text(" otherwise.")

#text("Suppose then for contradiction that ")#mi("{L(1,\\chi) < c q^{-\\epsilon}}")#text(" and ")#mi("{L(1,\\chi^{\\prime}) < c (q^{\\prime})^{-\\epsilon}}")#text(" for two distinct primitive real characters ")#mi("{\\chi, \\chi^{\\prime}}")#text(" of (large) modulus ")#mi("{q,q^{\\prime}}")#text(" respectively.")

#text("We begin by modifying the proof that ")#mi("{L(1,\\chi)}")#text(" was positive, which relied (among other things) on the observation that ")#mi("{1 * \\chi}")#text(", and equals ")#mi("{1}")#text(" at ")#mi("{1}")#text(". In particular, one has ")#metadata(none) <tao-94f394295869a64dc20d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\sum_{n \\leq x} \\frac{1*\\chi(n)}{n^s} \\geq 1")]]

#text(" for any ")#mi("{x \\geq 1}")#text(" and any real ")#mi("{s}")#text(". (One can get slightly better bounds by exploiting that ")#mi("{1*\\chi}")#text(" is also at least ")#mi("{1}")#text(" on square numbers, as before, but this is really only useful for ")#mi("{s \\leq 1/2}")#text(", and we are now going to take ")#mi("{s}")#text(" much closer to ")#mi("{1}")#text(".)")

#text("On the other hand, one has the asymptotics")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{1}{n^s} = \\zeta(s) + \\frac{x^{1-s}}{1-s} + O( x^{-s} )")]]

#text("for any real ")#mi("{s}")#text(" close (but not equal) to ")#mi("{1}")#text(", and similarly")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\chi(n)}{n^s} = L(s,\\chi) + O( q^{O(1)} x^{-s} )")]]

#text("for any real ")#mi("{s}")#text(" close to ")#mi("{1}")#text("; similarly for ")#mi("{\\chi^{\\prime}, \\chi \\chi^{\\prime}}")#text(". From the hyperbola method, we can then conclude ")#metadata(none) <tao-864a42c4bf81be054d34>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\sum_{n \\leq x} \\frac{1*\\chi(n)}{n^s} = \\zeta(s) L(s,\\chi) + \\frac{x^{1-s}}{1-s} L(1,\\chi) + O( q^{O(1)} x^{0.5-s} )")]]

#text(" for all real ")#mi("{s}")#text(" sufficiently close to ")#mi("{1}")#text(". Indeed, one can expand the left-hand side of ")#link(<tao-864a42c4bf81be054d34>)[#text("(26)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq \\sqrt{x}} \\frac{\\chi(d)}{d^s} \\sum_{m \\leq x/d} \\frac{1}{m^s} + \\sum_{m < \\sqrt{x}} \\frac{1}{m^s} \\sum_{\\sqrt{x} < d \\leq x/m} \\frac{\\chi(d)}{d^s}")]]

#text("and the claim then follows from the previous asymptotics. (One can improve the error term by smoothing the summation, but we will not need to do so here.)")

#text("Now set ")#mi("{x = C q^{C}}")#text(" for a large absolute constant ")#mi("{C}")#text(". If ")#mi("{0.99 \\leq s < 1}")#text(", then the error term in ")#mi("{O( q^{O(1)} x^{0.5-s} )}")#text(" is then at most ")#mi("{1/2}")#text(" (say) if ")#mi("{C}")#text(" is large enough. We conclude from ")#link(<tao-94f394295869a64dc20d>)[#text("(25)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) L(s,\\chi) \\geq \\frac{1}{2} - O( \\frac{q^{O(1-s)}}{1-s} L(1,\\chi) )")]]

#text("for ")#mi("{0.99 \\leq s < 1}")#text(". Since ")#mi("{L(1,\\chi) \\leq c q^{-\\epsilon}}")#text(" and ")#mi("{c}")#text(" is assumed small (depending on ")#mi("{\\epsilon}")#text("), this implies that ")#mi("{\\zeta(s) L(s,\\chi)}")#text(" is positive in the range")

#align(center)[#tao-fit-display[#mitex("L(1,\\chi) \\ll 1-s \\ll \\epsilon")]]

#text("(this can be seen by checking the cases ")#mi("{1-s \\leq 1/\\log q}")#text(" and ")#mi("{1-s > 1/\\log q}")#text(" separately). On the other hand, ")#mi("{\\zeta(s) L(s,\\chi)}")#text(" has a simple pole at ")#mi("{s=1}")#text(" with positive residue, and is thus negative for ")#mi("{s<1}")#text(" extremely close to ")#mi("{1}")#text(". By the intermediate value theorem, we conclude that ")#mi("{L(s,\\chi)}")#text(" has a zero for some ")#mi("{s = 1 - O(L(1,\\chi))}")#text(". Conversely, it is not difficult (using summation by parts) to show that ")#mi("{L^{\\prime}(s,\\chi) = O(\\log^2 q)}")#text(" for ")#mi("{s = 1 - O( 1/\\log q )}")#text(", and so by the mean value theorem we see that the zero of ")#mi("{L(s,\\chi)}")#text(" must also obey ")#mi("{1-s \\gg L(1,\\chi) / \\log^2 q}")#text(". Thus ")#mi("{L(s,\\chi)}")#text(" has a zero for some ")#mi("{s < 1}")#text(" with ")#metadata(none) <tao-2f60014f825fa20dbc56>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("L(1,\\chi)/\\log^2 q \\ll 1-s \\ll L(1,\\chi).")]]

#text(" Similarly, ")#mi("{L(s^{\\prime},\\chi^{\\prime})}")#text(" has a zero for some ")#mi("{s^{\\prime} < 1}")#text(" with ")#metadata(none) <tao-ac021bf8bf9f8f4c3e1a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("L(1,\\chi^{\\prime})/\\log^2 q^{\\prime} \\ll 1-s^{\\prime} \\ll L(1,\\chi^{\\prime}).")]]



#text("Now, we consider the function")

#align(center)[#tao-fit-display[#mitex("f := 1 * \\chi * \\chi^{\\prime} * \\chi\\chi^{\\prime}.")]]

#text("One can also show that ")#mi("{f}")#text(" is non-negative and equals ")#mi("{1}")#text(" at ")#mi("{1}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{f(n)}{n^s} \\geq 1.")]]

#text("(The algebraic number theory interpretation of this positivity is that ")#mi("{f(n)}")#text(" is the number of representations of ")#mi("{n}")#text(" as the norm of an ideal in the ")#link("http://en.wikipedia.org/wiki/Biquadratic_field")[#text("biquadratic field")]#text(" generated by ")#mi("{\\sqrt{q}}")#text(" and ")#mi("{\\sqrt{q^{\\prime}}}")#text(".)")

#text("Also, by (a more complicated version of) the derivation of ")#link(<tao-864a42c4bf81be054d34>)[#text("(26)")]#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{f(n)}{n^s} = \\zeta(s) L(s,\\chi) L(s,\\chi^{\\prime}) L(s,\\chi\\chi^{\\prime}) + \\frac{x^{1-s}}{1-s} L(1,\\chi) L(1,\\chi^{\\prime}) L(1,\\chi\\chi^{\\prime}) + O( (qq^{\\prime})^{O(1)} x^{0.9-s} )")]]

#text("(say). Arguing as before, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) L(s,\\chi) L(s,\\chi^{\\prime}) L(s,\\chi\\chi^{\\prime}) \\geq \\frac{1}{2} - O( \\frac{(qq^{\\prime})^{O(1-s)}}{1-s} L(1,\\chi) L(1,\\chi^{\\prime})L(1,\\chi\\chi^{\\prime}) )")]]

#text("for ")#mi("{0.99 \\leq s < 1}")#text(". Using the bound ")#mi("{L(1,\\chi\\chi^{\\prime}) \\ll \\log(qq^{\\prime})}")#text(" (which can be established by summation by parts), we conclude that ")#mi("{\\zeta(s) L(s,\\chi) L(s,\\chi^{\\prime}) L(s,\\chi\\chi^{\\prime})}")#text(" is positive in the range")

#align(center)[#tao-fit-display[#mitex("L(1,\\chi) L(1,\\chi^{\\prime}) \\log(qq^{\\prime}) \\ll 1-s \\ll \\epsilon.")]]

#text("Since we already know ")#mi("{L(s,\\chi)}")#text(" and ")#mi("{L(s^{\\prime},\\chi^{\\prime})}")#text(" have zeroes for some ")#mi("{s, s^{\\prime}}")#text(" obeying ")#link(<tao-2f60014f825fa20dbc56>)[#text("(27)")]#text(", ")#link(<tao-ac021bf8bf9f8f4c3e1a>)[#text("(28)")]

#align(center)[#tao-fit-display[#mitex("\\frac{L(1,\\chi)}{\\log^2 q}, \\frac{L(1,\\chi^{\\prime})}{\\log^2 q^{\\prime}} \\ll L(1,\\chi) L(1,\\chi^{\\prime}) \\log(qq^{\\prime});")]]

#text("taking geometric means and rearranging we obtain")

#align(center)[#tao-fit-display[#mitex("L(1,\\chi) L(1,\\chi^{\\prime}) \\gg \\log(qq^{\\prime})^{-O(1)}.")]]

#text("But this contradicts the hypotheses ")#mi("{L(1,\\chi) \\leq c q^{-\\epsilon}}")#text(", ")#mi("{L(1,\\chi^{\\prime}) \\leq c (q^{\\prime})^{-\\epsilon}}")#text(" if ")#mi("{c}")#text(" is small enough. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" Siegel’s theorem leads to a version of the prime number theorem in arithmetic progressions known as the ")#link("http://en.wikipedia.org/wiki/Siegel%E2%80%93Walfisz_theorem")[#text("Siegel-Walfisz theorem")]#text(". As with Siegel’s theorem, the bounds are ineffective unless one is allowed to exclude a single exceptional modulus ")#mi("{q}")#text(" (and its multiples), in which case one has a modified prime number theorem which favours the quadratic nonresidues mod ")#mi("{q}")#text("; see ")#link("http://www.dms.umontreal.ca/%7Eandrew/PDF/PNTforaps.pdf")[#text("this paper of Granville")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" One can improve the effective bounds in Siegel’s theorem if one is allowed to exclude a larger set of bad moduli. For instance, the arguments in Section ")#link(<tao-4feefcf7f0d7745c8152>)[#text("4")]#text(" allow one to establish a bound of the form ")#mi("{L(1,\\chi) \\gg \\log^{-O(1)} q}")#text(" after excluding at most one ")#mi("{q}")#text(" in each hyper-dyadic range ")#mi("{2^{100^k} \\leq q \\leq 2^{100^{k+1}}}")#text(" for each ")#mi("{k}")#text("; one can of course replace ")#mi("{100}")#text(" by other exponents here, but at the cost of worsening the ")#mi("{O(1)}")#text(" term. (This is essentially an observation of Landau.)")
]

#heading(level: 1)[#text("Comments (35)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-41578")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2009")])]

#text("Very nice exposition!")

#text("(1) I remember reading that, before the classification of imaginary quadratic fields of class number 1 was proved, it was known that there could be at most one example in addition to the ones already known. Is that the same “at most one”?")

#text("(2) If you felt like expanding Remark 1 into a blog post, I would certainly be interested in reading it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-41581")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2009")])]

#text("(1) Yes, this is very closely related, though I think the discovery that there is at most one exceptional field of class number 1 predates Siegel’s theorem slightly. The elimination of this field is quite difficult (it can’t be done by the methods discussed here), but I don’t know many details.")

#text("(2) Actually I was already thinking of doing something along those lines, though perhaps not immediately…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-41593")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2009")])]

#text("Thanks for an excellent posting.")

#text("A minor expository point: the numbers 0 and 1 occur in the initial discussion of the “zero-one law”, in a way which (to any reader not already knowing the term) reinforces but also confuses the meaning of the term here. In the original probability context, 0 and 1 had meaning as probabilities, but in the present situation it just refers to an all-or-nothing dichotomy of possible asymptotic behaviors.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-41594")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2009")])]

#text("Hmm, that’s a fair point. It’s a shame that the term “zero-one law” is so narrowly defined, because I find it a useful phrase in other contexts. I wonder if anyone can suggest a replacement term; “all-or-nothing dichotomy” is OK, I guess, but perhaps a little clunky.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-41645")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2009")])]

#text("I’ve gone ahead and replaced “zero-one law” with “all-or-nothing dichotomy”; this is not my ideal terminology, but will serve as a placeholder until a better suggestion comes along.")

#text("I also fixed an error in which the rings ")#mi("Z[\\sqrt{q}]")#text(" and ")#mi("Z[\\sqrt{-q}]")#text(" were confused. (At some point in the future I plan to learn class field theory properly, and perhaps blog about it here; my algebraic number theory knowledge is unfortunately still rather superficial at present.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of same anon")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-41666")[#strong[#text("same anon")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2009")])]

#text("(from the anon who posted the earlier 0-1 comment)")

#text("Actually, “zero-one law” is too good a metaphor to not use. It works beautifully for any reader who already understands the meaning. Not only does it convey the idea, but seeing the term used here outside its traditional settings also suggests the idea of spreading that usage to other contexts.")

#text("The only caveat is that readers who aren’t already familiar with the idea would probably benefit if, at the first location in the essay where “0-1 law” appears, there were also:")

#text("— an aside, giving a definition or a few words of explanation (e.g., “borrowing a metaphor from the 0-1 laws of probability”);")

#text("— disambiguation, in the discussion that follows of the order of vanishing of the associated Dirichlet series being either 0 or 1 and this being an avatar of the 0-1 law, that these orders being “0” and “1” (in whichever order corresponds to the dichotomy in the 0-1 law!) is just a numerical peculiarity of this problem and is otherwise unrelated to the words in the term “zero-one law”.")

#text("I guess it also bears clarifying what a 0-1 law is, in general. I don’t think the meaning is simply that of a dichotomy, there is also some dynamics driving the outcome, asymptotically, to one of two antipodal equilibria (indeed you call the two values of $c$ “equilibria”, so maybe you share the same intuition). This is literally or tacitly true in every theorem I can remember being called a 0-1 law (in probability, random graphs, ergodic theory, information theory, etc), and it would be interesting to make a list and see whether this dynamical, asymptotic aspect is always part of the story.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-41599")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2009")])]

#text("Near the beginning, when you say that the number of primes congruent to a mod q when a is not coprime to q is O(1), you can leave out the dependence of the implied constant on q. ")#emph[#text("[Well spotted, thanks! -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cd3293b17fc4102811ce87a71f982a006bff024f4fadf65e5afe06087907fc0-4ba76bf4fed42f8a2ca5c337f3ef79cd4db842b060b6a124a522d20c80bf75fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mustafa Said")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-41608")[#strong[#text("Mustafa Said")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2009")])]

#text("One open problem in analytic number theory is to determine whether or not $\\sum_1^{\\infty} (-1)^n \\frac{n}{p_n}$ converges. Here $p_n$ denotes the $n^th$ prime. The prime number theorem gives us some information on the asymptotics of the terms in the sum, but not enough to solve the problem. Would the validity of the Riemann Hypothesis help us solve this problem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-41641")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2009")])]

#text("Hmm. I played around with this sum a bit and it seems like the convergence of this sum is equivalent to the convergence of the sum ")#mi("\\sum_{m=2}^\\infty \\frac{(-1)^{\\pi(m)}}{m \\log m}")#text(" (by using the prime number theorem and estimating the difference between ")#mi("\\frac{n}{p_n}")#text(" and ")#mi("\\frac{n+1}{p_{n+1}}")#text(" for odd and even n.) So it comes down to understanding the equidistribution of the parity of the prime counting function; roughly speaking, any quantatitative equidistribution which gains more than a log log factor should suffice. By coincidence, we happen to be studying the parity of pi(x) over at the polymath4 project, though I don’t think the methods we have currently for computing that parity are strong enough to establish this sort of equidistribution. Nevertheless it does seem plausible (though difficult to prove) that one has convergence. (If one had a sufficiently uniform and quantitative version of the Poisson statistics conjecture for prime gaps, one might be able to obtain the result; in particular, a sufficiently quantitative version of the prime tuples conjecture might suffice, thanks to Gallagher’s computations relating the two.)")

#text("The Riemann hypothesis concerns larger-scale fluctuations in the primes, whereas here it seems that fine-scale fluctuations such as prime gaps statistics are more relevant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cd3293b17fc4102811ce87a71f982a006bff024f4fadf65e5afe06087907fc0-4ba76bf4fed42f8a2ca5c337f3ef79cd4db842b060b6a124a522d20c80bf75fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mustafa Said")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-43800")[#strong[#text("Mustafa Said")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2010")])]

#text("Can you please explain your statement “any quantatitative equidistribution (of the parity of the prime counting function) which gains more than a log log factor should suffice.”")

#text("I also have another question about the parity of the prime counting")#linebreak()#text(" function:")

#text("Let $E_N = { m \\in \\mathbb{N} : \\pi(m) is even and m \\leq N}$")#linebreak()#text(" and $O_N = { m \\in \\mathbb{N} : \\pi(m) is odd and m \\leq N}")

#text("then is it true that $\\lim_{N \\to \\infty} |E_N|/|O_N| = 1$ ?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d6f0a223a0dcec06f8c222f1a86edfc20f20632006e51aee87e8852cfea65fe-13f06ca34be1779586b29a0effd8ee229752a187d2902cbeb08c40b9e2923e93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-41620")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2009")])]

#text("There are lots of ways you can use the phrase “all or nothing.” You can say all-or-nothing behavior, all-or-nothing phenomenon, all-or-nothing situation, etc. Another expression you can use in place of all or nothing is “black or white” — as in no shades of gray. One reason “all-or-nothing dichotomy” seems clunky is that it is redundant.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arithmetic Progression in finite fields")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-41668")[#strong[#text("Arithmetic Progression in finite fields")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2009")])]

#text("Professor Tao:")#linebreak()#text(" I have a particular problem that is of interest in electrical engineering. It seems to fall under the category of arithmetic progression but in finite fields.")

#text("Field field: F_{p^n} with n>1")

#text("What is the maximum N so that one can find N different polynomials")#linebreak()#text(" p_{i}(x) of degree in F_{p}[x] for i = 1,…,N so that the following")#linebreak()#text(" conditions are satisfied?")

#text("1) each p_{i}(x) has at least 2^n roots in F_{p^n} in arithmetic")#linebreak()#text(" progression. By AP what I mean is: let s be primitive element. If r is")#linebreak()#text(" root, then r, r+1, r+s, r+1+s,r+s^2, r+s^2+1, r+s^2+s,")#linebreak()#text(" r+s^2+s+1,…,r+s^(n-1)+s^(n-2)+…+1 are roots.")#linebreak()#text(" 2) If i is not j, p_{i}(x) and p_{j}(x) should have no common roots")#linebreak()#text(" from the roots in arithmetic progression.")

#text("As n increases from 0 to infinity what is the highest such N one can")#linebreak()#text(" get for each F_{p^n}?")

#text("(I could not get more than N=5 for p=5. For p=3, N=1.)")

#text("Is there any mathematician who has worked on problems involving such progressions in finite fields?")

#text("Thank you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of At the AustMS conference « What’s new")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-41681")[#strong[#text("At the AustMS conference « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2009")])]

#text("[…] follows from (for instance) Siegel’s theorem on the size of the class group, as discussed in this previous post. Ellenberg, Venkatesh, and Westerland have recently established some partial results towards the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29884bbba47c6be14a754803ce5ef4f246acbf49de864658588ee8546cbd08c4-926f96a1e80ba6c336337d531a4bb56248108c322a0061d9db8b005b0901ac97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giampiero Campa")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-41732")[#strong[#text("Giampiero Campa")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2009")])]

#text("Hi Terry,")#linebreak()#text(" first of all i am an not a Mathematician, so i’d like to apologize in advance if the language i am using is not entirely correct or appropriate.")

#text("Let me put it this way, do we “understand”, say, the Mandelbrot fractal ? I mean, yes we do have a dynamic system that generates it, but as far as i know the only way we can determine whether a point belongs to the set or not is by iterating the dynamic system. Isn’t that somehow similar to the situation that we have with prime numbers where the only way to find out if a number is prime or not is by going through the sieve ? or simply dividing the number by all its predecessors ? (which i am pretty sure it can be done with a simple 1-state nonlinear dynamic system)")

#text("In other words, are we expecting too much by saying, as you did in your first sentence, that we want to “understand the distribution of prime numbers” ?")

#text("Again, maybe these are trivial questions and i just don’t know enough number theory, in which case i apologize.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-149021")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2012")])]

#text("Somewhat like, to see if a living creature is a human being, it’s a good idea to test its DNA, but perhaps it’s not very useful for the understanding of the distribution of people in the world…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The “no self-defeating object” argument « What’s new")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-42283")[#strong[#text("The “no self-defeating object” argument « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2009")])]

#text("[…] 1 Continuing the number-theoretic theme, the “dueling conspiracies” arguments in a previous blog post can also be viewed as an instance of this type of “no-self-defeating-object”; for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erdos’ divisor bound « What’s new")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-59951")[#strong[#text("Erdos’ divisor bound « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2011")])]

#text("[…] requires one to exclude zeroes of the Riemann zeta function on the line , as discussed in this previous post), one is eventually left with the estimate , which is useless as a lower bound (and recovers only […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hilbert’s seventh problem, and powers of 2 and 3 « What’s new")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-69261")[#strong[#text("Hilbert’s seventh problem, and powers of 2 and 3 « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2011")])]

#text("[…] (The reason the Thue-Siegel-Roth theorem is ineffective is because it relies heavily on the dueling conspiracies argument, i.e. playing off multiple “conspiracies” against each other; the other results […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-103978")[#strong[#text("Number Theory: Lecture 16 « Theorem of the week")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2011")]

#text("[…] there was no known elementary proof when the first edition was written!). Terry Tao has a nice blog post discussing a number of aspects of the distribution of prime […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb462de27d1916faeb5629eb99d12d774ac8b36f1e3a37d3870f2ea4ca365c03-701c116888e455c639e2a8f17dd49317f0ee7737933c65b7673f2043a0e5973f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sumit Kumar Jha")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-139246")[#strong[#text("Sumit Kumar Jha")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2012")])]

#text("Professor Tao:")#linebreak()#text(" Your derivation of Selberg’s symmetry formula is the one which Selberg originally used in his derivation of an elementary proof of prime number theorem.")#linebreak()#text(" But in a paper by Iseki and Tatsukava, they easily derived")#linebreak()#text(" ")#mi("\\psi(x)\\log x+\\sum_{n\\leq x}\\Lambda(n)\\psi\\left(\\frac{x}{n}\\right)=2x\\log x+O(x)")#linebreak()#text(" and this is equivalent to")#linebreak()#text(" ")#mi("\\sum_{n\\leq x}\\Lambda_{2}(n)=2x\\log x+O(x)")#linebreak()#text(" where")#linebreak()#text(" ")#mi("\\Lambda_2=\\Lambda^{\\prime}+\\Lambda \\ast \\Lambda=\\mu \\ast u^{\\prime\\prime}")#linebreak()#text(" Can you help me to deduce")#linebreak()#text(" ")#mi("\\sum_{p\\leq x}\\log^2 p+\\sum_{pq \\leq x} \\log p\\log q=2x\\log x+O(x)")#linebreak()#text(" from above equation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb462de27d1916faeb5629eb99d12d774ac8b36f1e3a37d3870f2ea4ca365c03-701c116888e455c639e2a8f17dd49317f0ee7737933c65b7673f2043a0e5973f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sumit Kumar Jha")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-139249")[#strong[#text("Sumit Kumar Jha")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2012")])]

#text("Actually,")#linebreak()#text(" ")#mi("\\Lambda_{2}(n)=\\log^2 p")#text(" when ")#mi("n=p")#linebreak()#text(" ")#mi("\\Lambda_{2}(n)=\\log p\\log{\\frac{n^2}{p}}")#text(" when ")#mi("n=p^\\alpha")#linebreak()#text(" ")#mi("\\Lambda_{2}(n)=2\\log p\\log q")#text(" when ")#mi("n=p^\\alpha q^\\beta")#linebreak()#text(" but how is it that")#linebreak()#text(" ")#mi("\\Lambda_{2}(n)=0")#text(" in other cases.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-139349")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2012")])]

#text("This follows from the formula ")#mi("\\Lambda_2 = \\Lambda^{\\prime} + \\Lambda*\\Lambda")#text(" in your previous comment.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb462de27d1916faeb5629eb99d12d774ac8b36f1e3a37d3870f2ea4ca365c03-701c116888e455c639e2a8f17dd49317f0ee7737933c65b7673f2043a0e5973f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sumit Kumar Jha")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-139362")[#strong[#text("Sumit Kumar Jha")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2012")])]

#text("Professor Tao: Thanks!!")#linebreak()#text(" I am also looking forward for an article on “sieves” on your blog. Have you already written one??")#linebreak()#text(" I especially want to know about the Bomberi sieve which treats")#linebreak()#text(" ")#mi("\\Lambda_{k}=\\sum_{n|d}\\mu(d)\\log^k(\\frac{n}{d})")#text(".")#linebreak()#text(" Can you also discuss the departure from “almost primes” to “primes” namely parity problem in detail??")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heuristic limitations of the circle method « What’s new")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-143790")[#strong[#text("Heuristic limitations of the circle method « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2012")])]

#text("[…] the only thing which is strong enough to rule out a conspiracy is a conflicting conspiracy (see my previous blog post on this topic). A good example of this is Heath-Brown’s result that the existence of a Siegel zero (which […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-148836")[#strong[#text("What if primes hated to start with nine? « Secret Blogging Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2012")]

#text("[…] appeared earlier in an answer I left on MO. There is also a lot of similarity to Terry Tao’s post on conspiracies and the prime number theorem. One can think of “primes hate to start with nine” as a “conspiracy” whose […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f88144531339e5ac96b6d549077071fa58f5a8dc026f31a8f8a05212898f2363-7cce7eb1dd58ce73b721df302093a3e33e7569b7272a9c7d1996547281a4c7fe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit Nair")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-197103")[#strong[#text("Sujit Nair")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2012")])]

#text("Typo: There should be a ")#mi("O(\\sqrt{x})")#text(" instead of ")#mi("O(1)")#text(" in the rightmost term in the equation above (8)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Riemann hypothesis in various settings | What's new")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-239161")[#strong[#text("The Riemann hypothesis in various settings | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2013")])]

#text("[…] e.g. this previous blog post for more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-251160")[#strong[#text("Number Theory: Lecture 16 | Theorem of the week")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2013")]

#text("[…] there was no known elementary proof when the first edition was written!). Terry Tao has a nice blog post discussing a number of aspects of the distribution of prime […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mertens’ theorems | What's new")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-256369")[#strong[#text("Mertens’ theorems | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2013")])]

#text("[…] on the Riemann zeta function in the neighbourhood of the pole at , whereas (as discussed in this previous post) the prime number theorem requires control on the zeta function on (a neighbourhood of) the line . […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The subspace theorem approach to Siegel’s theorem on integral points on curves via nonstandard analysis | What's new")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-388659")[#strong[#text("The subspace theorem approach to Siegel’s theorem on integral points on curves via nonstandard analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2014")])]

#text("[…] an effective bound may be easily established). This is ultimately due to the reliance on the “dueling conspiracy” (or “repulsion phenomenon”) strategy. We do not as yet have a good way to rule […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Derived multiplicative functions | What's new")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-419784")[#strong[#text("Derived multiplicative functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2014")])]

#text("[…] a key role in the Erdös-Selberg elementary proof of the prime number theorem (as discussed in this previous blog post), is the top order term of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c50ed8c83619ac5d842a9eea880d0e30ea44864f258b5797dae909e6fca0762-4e29f60be9e2b2234522f86543d5e533208d31b08ab6c83844eba5151d1f8d58.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-444524")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2014")])]

#text("Prof Tao")

#text("I was wondering how exactly the summation by parts works to get equation (2) from prime number theorem ? Thanks.")

#emph[#text("[This is an instructive exercise and I recommend that you try your hand at it. You can take a look at the proof of Theorem 36 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")]#text(" for some related arguments. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-456597")[#strong[#text("The prime tuples conjecture, sieve theory, and the work of Goldston-Pintz-Yildirim, Motohashi-Pintz, and Zhang | fragments")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2015")]

#text("[…] annoyingly, the implied constant here is only ineffectively bounded with current methods; see this previous post for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klaus Roth | What's new")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-461809")[#strong[#text("Klaus Roth | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2015")])]

#text("[…] when the denominators are very different in size. (I refer to this sort of argument as a “dueling conspiracies” argument; they are strangely prevalent throughout analytic number […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d795267dbd038f1005f75af83ec936881af210cc206fb0aabdee58f50ef11c5-ac7da6c0207f69701426d14f1a4a276c63c80d722e66b4fc27d09f3e34a705c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Li")]], [#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/#comment-638002")[#strong[#text("Sam Li")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2021")])]

#text("Great post. Minor thing: The link to PlanetMath for “Dirichlet hyperbola method” has inevitably rotted.")

#emph[#text("[Corrected, thanks -T.]")]
]
