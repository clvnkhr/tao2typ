// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/
// Converted to Typst by tao2typ: "2026-10-14T11:10:07.376281+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "AI to Assist Mathematical Reasoning: A Workshop", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("AI to Assist Mathematical Reasoning: A Workshop")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 June 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/")[#text("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The ")#link("https://www.nationalacademies.org/home")[#text("National Academies of Science, Engineering, and Mathematics")]#text(" are hosting a virtual workshop on the topic of “")#link("https://www.nationalacademies.org/event/06-12-2023/ai-to-assist-mathematical-reasoning-a-workshop")[#text("AI to Assist Mathematical Reasoning")]#text("” from June 12-14. The tentative program can be ")#link("https://www.nationalacademies.org/event/06-12-2023/docs/D5DBCD07BFB3B3835BA234DD7CC8F45DED111D71E18F?noSaveAs=1")[#text("found here")]#text(". I am one of the members of the organizing committee for this workshop, together with Petros Koumoutsakos, Jordan Ellenberg, Melvin Greer, Brendan Hassett, Yann A. LeCun, Heather Macbeth, Talia Ringer, Kavitha Srinivas, and Michelle Schwalbe. There is some thematic overlap (and a few speakers in common) with the recent ")#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/")[#text("IPAM program on machine assisted proof")]#text(", though with more of a focus on the current and projected technical capabilities of machine learning algorithms for mathematics. Registration for the event is currently open at ")#link("https://www.nationalacademies.org/event/06-12-2023/ai-to-assist-mathematical-reasoning-a-workshop")[#text("the web page for the workshop")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a36aff54e2e0a56c390058a7fee0df08758bbacc2d40df76f2f8ec3e71095f23-a41a0a22d3ae663f0e0835a9ec1dfb45e97835a308006af1abce572b8b804e92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme Rocha de Rezende")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678389")[#strong[#text("Guilherme Rocha de Rezende")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2023")])]

#text("Thanks for the tips")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5fc4fc930916070f40c634c9b1c5092cf7a1b16386b2daa203d404d762a136e3-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nikita Sidorov")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678390")[#strong[#text("Nikita Sidorov")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2023")])]

#text("Sorry for the offtopic, Terry, but what is your opinion regarding Per Enflo’s recent theorem on the existence of proper closed invariant subspaces for any bounded linear operator on a separable Hilbert space?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ashok Khanna")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678391")[#strong[#text("Ashok Khanna")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2023")])]

#text("Would you be able to record these sessions as timezone (Australia) and work commitments make it difficult to watch live? Really excited to listen to these workshops!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0b12ee9eb4d6ee06585f8f500c2bd7e9752de9448ea14e4139ad2f043eb6c8c-4371435d321d49e1c2b162e3b0dd6b44bbea368f5bc8984ebec4bc1a7123efea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amadi")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678401")[#strong[#text("Amadi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2023")])]

#text("Common get out of here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678433")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2023")])]

#text("pretty sure it will be on Youtube.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678396")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2023")])]

#text("A possible drawbackof such AI assistance is to reduce human creativity (by relying on AI inteligence – therby becoming more “lazy” and degenarating creative thinking!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88ef6ab90ab98c8e2ec278d976ee6be9fd9dc7d64744bc51ae7f4582df02239f-4f065853317853faa6f6f8682a0df2c8bcb6bb754328a97b29fe0f2237e7ca2d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathematicalsilence")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678404")[#strong[#text("mathematicalsilence")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2023")])]

#text("Anonymous u could well do some creative thinking and learn how to spell … thereby generating a smidgin of credence for ur comments on ‘intelligence’ … note ‘ur’ is an AI approved … perhaps lazy … spelling of ‘your’")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678398")[#strong[#text("AI辅助数学推理：研讨会 - 偏执的码农")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2023")]

#text("[…] 详情参考 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0b12ee9eb4d6ee06585f8f500c2bd7e9752de9448ea14e4139ad2f043eb6c8c-4371435d321d49e1c2b162e3b0dd6b44bbea368f5bc8984ebec4bc1a7123efea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mathur Maynard Amadi")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678402")[#strong[#text("Mathur Maynard Amadi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2023")])]

#text("Good day, Terence Tao.")

#text("What is the difference between Laplace Geometry and Cosmic Geometry?")

#text("What is the difference between Gravitational Fields and Magnetic fields?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arman")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678408")[#strong[#text("Arman")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2023")])]

#text("Thanks PROF")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/726c1fb8ee42779b9bc7c7332835cb0bfa8e75b33ff08faab8fcbf679c263252-0f6666fbd7a83d7e9f9593a820c8ca44c1389aa7f3584a47bb424b559a38931f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arnie Bebita-Dris")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678509")[#strong[#text("Arnie Bebita-Dris")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2023")])]

#text("Thank you for this, Professor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d70d683d1ae026f44819978123ec13720eee148c71d69a69bff212e432480936-484f722bc6fb20e6218c4fc6ea487fb5af85ee27fc3155474e63ebb1c7f39724.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678511")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2023")])]

#text("Regarding proof verification.. do we need ML when we have PCP?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678557")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2023")])]

#text("Probabilistically checkable proofs are practically feasible in a few limited cases (for instance, in checking that a given large integer is a ")#link("https://en.wikipedia.org/wiki/Probable_prime")[#text("(strong) probable prime")]#text("), but for most types of mathematical statements one would like to know to be true, it would be impractical to set up a probabilistically checkable proof (the size of the probabilistically checkable proof, while in principle of “only” polynomial size in the length of the original proof, could be well beyond the capacity of current technology to create or store).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cd5c3de163183569fcabf012fe9c10f67b9b3c3470b9155987ade26ffe4a51d-76966840b29691860df1630e1a1c22f5f6407071ced5979311e04b70e2045880.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678558")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2023")])]

#text("As I understand, in many cases proofs can be broken up. In many cases, it only takes a critical statement to fail and they fail for a certain reason which (should be at least in many non-trivial cases) can be dissected into smaller chunks and verified. Of course the dissection might need human intervention.")

#text("It is extremely plausible with ‘LLM type’ techniques and with such a strategy at least tedious hw grading could be automated to find flaws and correctness in arguments or jumps in arguments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d70d683d1ae026f44819978123ec13720eee148c71d69a69bff212e432480936-484f722bc6fb20e6218c4fc6ea487fb5af85ee27fc3155474e63ebb1c7f39724.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678591")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2023")])]

#link("https://people.csail.mit.edu/dmoshkov/courses/pcp/dinur_pcp_overview.pdf")[#text("https://people.csail.mit.edu/dmoshkov/courses/pcp/dinur_pcp_overview.pdf")]#text(" states on page 4 (top) “Classical proofs of length n are converted to PCPs of")#linebreak()#text(" length n · (logn)^(O(1)) in the work of Dinur”.")

#text("Why is this too long compared to the standard latex typed proof?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad95262768b3a066b73d77a5f97e9587a7e803b04586d942c8028c8410cee8ef-4e7193d81a92a7b2c9acc03004c4ea053936bf76f62d0197c00a83841c32e073.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678613")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2023")])]

#text("Up on reading the paper a bit it appears (??) PCPs of length just n (log(n))^2 suffices. A proof of length 10MBis going to be blown up to 10GB or so which can fit in the RAM of macbook air! Why go through this ML business?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678620")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2023")])]

#text("The absolute constant in the O() notation may be non-negligible currently. But even disregarding the issue of the constant, PCPs aren’t really addressing the main issue here. The problem that needs solving isn’t that of converting a 10MB proof that could already be formally verified in a standard proof verifier such as Lean, into a 10GB PCP that can be probabilistically verified by some zero-knowledge protocol; the bottleneck is in producing the 10MB formally verifiable proof in the first place. Note that one cannot simply apply Dinur’s algorithm to, say, a 200-page proof written by a human mathematician, because at present such proofs are usually written in semi-formal mathematical English (or perhaps some other human language) and are not in a form that is easily converted into a PCP (with some rare exceptions, such as primality testing, as I mentioned previously.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad95262768b3a066b73d77a5f97e9587a7e803b04586d942c8028c8410cee8ef-4e7193d81a92a7b2c9acc03004c4ea053936bf76f62d0197c00a83841c32e073.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678662")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2023")])]

#text("“The absolute constant in the O() notation may be non-negligible currently”.. I think the length of the proof is <= n (log n)^2. There is no O() notation involved here.")

#text("But agree converting regular human proofs to a standard computer proof (SCP) before conversion to PCPs is the bottleneck. But with current status of progress in AI, is it possible this bottleneck might be progressed eventually to a non-issue (in say a decade or two)? Might it involve converting standard tomes such as classification of simple groups, EGA & SGA etc into SCPs to start with?")

#emph[#text("[I severely doubt that there is no implied constant here, since the very notion of “length of proof” depends on the encoding (e.g., binary or ASCII), up to constants. -T]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/973db1d9bc30b97e2c0451880a1e86427ea385b9cb582236392f278ea8699c80-ef07fcf3b0becbaaa640a7e908ba28b767fd196369ed1f8eef0c8b58bec951ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678612")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2023")])]

#text("This is a very topical workshop, since ChatGPT does reasonably well on math (GHOSTS datasets for mathematics: ")#link("https://arxiv.org/abs/2301.13867")[#text("https://arxiv.org/abs/2301.13867")]#text(" )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-678665")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2023")])]

#text("Thanks for organizing this workshop. A few comments:")#linebreak()#text(" * Funding sources identified: Microsoft, Google, DARPA, Simons Foundation. Why does this matter? A key worker in the field complained recently that funding had dried up for interactive theorem proving, that AMS prioritized automated theorem proving over interactive theorem proving, and that mathematicians who originate new proofs in Math departments didn’t respect people who “just” worked on mechanically verifying those proofs. The people who do Lean and Coq need support or the projects could die out.")#linebreak()#text(" * Key use case (and maybe opportunity for funding): AMS and similar should encourage and incentivize mathematicians to use Lean or Coq to formally check their new proofs. Why? (a) Wiles’ proof of FLT took several years for mathematicians to have faith in it. A formally verified proof would take 0 years and 0 faith to accept. (b) It was noted that Wiles’ proof has a lot of “weasel words” like “analogous to” for constructions. With an interactive theorem proof, Wiles’ would have been forced to make these mappings explicit. (c) Some claim that no one mathematician, including Wile, has the whole proof of FLT in their heads. Is this true? Making mathematicians “program” their proofs in Coq or Lean would help suss this out. Mathematicians already use LaTeX all the time. There is no reason they should add Coq or Lean to their toolkit for daily use.")#linebreak()#text(" * So Terry, please learn Lean and start doing some proofs in Lean. It will be a great experience for you, and that will help you guide the AI/Math field. Maybe you can do FLT? It’s been waiting for 28 years for fully automated verification. You could do it in 2 weeks. You will be modelling this for other mathematicians. There is really a huge social gap between “mathematician’s mathematicians” doing pure math for math’s sake, and people who do automated theorem proving.")#linebreak()#text(" * AI? Meh. GPT doesn’t have the necessary structure to learn this material. People didn’t really talk about what it would take to extend it. Formally verifying proofs is computationally hard, depending on the number of variables in a goal state of the proof, even when you do it directly and as efficiently as you know how.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2023/06/02/ai-to-assist-mathematical-reasoning-a-workshop/#comment-679301")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2023")])]

#text("A NY Times article came out on the workshop:")

#text("The article mentions Heather MacBeth’s introductory Lean course:")

#link("https://github.com/hrmacbeth/math2001")[#text("https://github.com/hrmacbeth/math2001")]

#text("Not to mention the classic Natural Number Game by Kevin Buzzard and Mohammad Pedramfar:")

#link("https://www.ma.imperial.ac.uk/~buzzard/xena/natural_number_game/")[#text("https://www.ma.imperial.ac.uk/~buzzard/xena/natural_number_game/")]

#text("The article also mentions concerns by Michael Harris at Columbia, who vets the conference in multiple posts and gives low marks for computer scientists imposing methodology and value judgments about approach to work on mathematicians, and expresses concerns about access to models, the source code of models, and sufficient resources to reproduce training for models; and concern that the money for this work comes mostly and ultimately from DoD and IC:")

#link("https://siliconreckoner.substack.com/p/right-on-cue-the-military-industrial")[#text("https://siliconreckoner.substack.com/p/right-on-cue-the-military-industrial")]#linebreak()#text(" ")#link("https://siliconreckoner.substack.com/p/my-shallow-thoughts-about-deep-learning")[#text("https://siliconreckoner.substack.com/p/my-shallow-thoughts-about-deep-learning")]#linebreak()#text(" ")#link("https://siliconreckoner.substack.com/p/my-shallow-thoughts-about-deep-learning-917")[#text("https://siliconreckoner.substack.com/p/my-shallow-thoughts-about-deep-learning-917")]#linebreak()#text(" ")#link("https://siliconreckoner.substack.com/p/my-shallow-thoughts-about-deep-learning-186")[#text("https://siliconreckoner.substack.com/p/my-shallow-thoughts-about-deep-learning-186")]
]
