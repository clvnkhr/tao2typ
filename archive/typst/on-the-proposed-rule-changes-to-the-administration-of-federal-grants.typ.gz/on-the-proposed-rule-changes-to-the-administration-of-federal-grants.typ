// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/06/09/on-the-proposed-rule-changes-to-the-administration-of-federal-grants/
// Converted to Typst by tao2typ: "2026-10-14T16:39:23.536742+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On the proposed rule changes to the administration of federal grants", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On the proposed rule changes to the administration of federal grants")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 June 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/06/09/on-the-proposed-rule-changes-to-the-administration-of-federal-grants/")[#text("https://terrytao.wordpress.com/2026/06/09/on-the-proposed-rule-changes-to-the-administration-of-federal-grants/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The United States Office of Management and Budget (OMB) ")#link("https://www.federalregister.gov/documents/2026/05/29/2026-10817/regulation-for-federal-financial-assistance")[#text("has proposed")]#text(" a vast and radical set of rule changes to how federal grants from all funding agencies are administered. (A summary of the key changes, by a former Senior Program Officer at the National Institutes for Health, can be found ")#link("https://elizabethginexi.substack.com/p/summary-of-key-changes-in-ombs-proposed?utm_source=post-email-title&publication_id=6018767")[#text("here")]#text(".) This is no mere tinkering at the edges of existing policy; many basic principles, such as the central role of peer review in grant-making decisions, are seriously compromised by the proposed rules, while the administrative burden of complying with grant rules are significantly increased, and hamstring the ability of funded scientists to react to new developments and forge new collaborations.")

#text("There is much to discuss in these proposals; see for instance ")#link("https://www.linkedin.com/posts/karen-saxe-5015038a_regulation-for-federal-financial-assistance-share-7467308767613763585-3xKJ/")[#text("this post by Karen Saxe")]#text(" (vice president for Government Relations at the American Mathematical Society), ")#link("https://skyandtelescope.org/astronomy-news/proposed-u-s-grant-funding-rules-spark-worry-backlash-in-astronomy/")[#text("this news item on the response from the astronomy community")]#text(", ")#link("https://arstechnica.com/science/2026/05/the-office-of-management-and-budget-tries-again-to-cripple-us-science/")[#text("this op-ed from Ars Technica")]#text(",")#link("https://www.nytimes.com/2026/06/02/us/politics/trump-budget-grants-omb-vought.html")[#text(" this article from the New York Times")]#text(", ")#link("https://www.science.org/content/article/white-house-seeks-tighten-political-oversight-grantmaking")[#text("this article from Science")]#text(", or ")#link("https://www.cnn.com/2026/06/04/climate/trump-omb-funding-rule-climate-science")[#text("this story from CNN")]#text(". I will focus here on just one of the impacts, regarding the need to maintain agility and flexibility in a competitive and rapidly changing environment.")

#text("Some types of research, particularly those closest to industrial or other real-world applications, can be planned in a predictable fashion, in which the timelines for hitting key milestones are clear, and schedules for events can be planned years in advance. However, basic research — of which pure mathematics is a quintessential example — expects (almost by definition) to discover previously unknown directions and connections that cannot be predicted perfectly at the time a research project is proposed. Many of the most striking breakthroughs in such subjects come from uncovering such expected developments and rapidly capitalizing on them – for instance, by quickly organizing seminars, workshops, or conferences on a suddenly “hot” topic.")

#text("To give just one example of this sort of serendipitous discovery, a significant portion of the foundational theory of ")#link("https://en.wikipedia.org/wiki/Compressed_sensing")[#text("compressed sensing")]#text(" was initiated from a chance meeting in 2004 between myself, ")#link("https://candes.su.domains/")[#text("Emmanuel Candes")]#text(" (a statistician) and ")#link("https://ece.gatech.edu/directory/justin-romberg")[#text("Justin Romberg")]#text(" (an electrical engineer) at a ")#link("https://www.ipam.ucla.edu/programs/long-programs/multiscale-geometry-and-analysis-in-high-dimensions/")[#text("program at the Institute for Pure and Applied Mathematics (IPAM) on multiscale geometry")]#text(". This theory – has led to notable accelerations and other improvements to a range of technologies, from MRI scans to radio interferometry to electron microscopy. The three of us, as well as the IPAM program we participated in, were all funded by grants from the National Science Foundation (NSF), but the extraordinarily fruitful collaboration was not fully anticipated in any of the proposals. (Disclosure: I now serve as director of special projects at IPAM.)")

#text("This is the type of fortuitous interaction that would be severely impacted by the proposed rule changes. Consider for instance ")#link("https://www.ecfr.gov/current/title-2/subtitle-A/chapter-II/part-200/subpart-E/subject-group-ECFRed1f39f9b3d4e72/section-200.432")[#text("Section 200.432 of the Code of Federal Regulations")]#text(", which concerns the use of grant funds to support conference costs:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("A conference means an event whose primary purpose is to disseminate technical information beyond the recipient or subrecipient and is necessary and reasonable for successful performance under the Federal award. Allowable conference costs may include the rental of facilities, speakers’ fees, attendance fees, costs of meals and refreshments, local transportation, and other items incidental to such conferences unless further restricted by the terms and conditions of the Federal award.")
]

#text("As just one of many significant rule changes proposed is ")#link("https://www.federalregister.gov/d/2026-10817/p-379")[#text("the following addendum")]#text(" to the above text:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("OMB proposes to expand § 200.432 to add a requirement that costs for attending conferences are allowable only if participation in the conference is expressly approved by the agency and included in the terms and conditions of the award. The revision would clarify that recipients are not authorized to attend conferences using Federal funds that do not serve to advance program outcomes.")
]

#text("This rule change would limit conference activity support to pre-approved plans that followed the scheduled objectives in the original proposal, which is written some time before the research takes place. However, it is the nature of novel research (particularly in fundamental sciences such as mathematics) to have serendipitous opportunities emerge that were not anticipated in the original grant proposal, such as an unexpected and exciting new connection between the problem one was initially studying, and another subfield of math or science that had previously been thought to be unrelated. Being able to react quickly to such developments, either by attending or organizing an event around them, or by inviting key researchers to visit, is essential to keep up with such breakthroughs. Requiring bureaucratic pre-approval in these circumstances would significantly hinder the ability for funded scientists to competitively take advantage of these opportunities.")

#text("An illustrative example would be the 2011 IPAM program on ")#link("https://www.ipam.ucla.edu/programs/long-programs/navigating-chemical-compound-space-for-materials-and-bio-design/")[#text("Navigating Chemical Compound Spaces")]#text(". The premise sounded like a pie-in-the-sky idea: to develop computational tools to be able to somehow travel through the almost infinite space of all possible chemical compounds in the search for a compound we need — be it to create a novel drug, a better solar cell, or stronger glass. At the time, even with projected advances in computer power, accurate prediction of chemical properties of materials was seen as a distant dream. Simulating a simple protein for even a few milliseconds with existing methods would require weeks of time and an astronomical energy budget. In addition to experts on computational mathematics and materials science, the program involved a group of people who worked in a then obscure subject called ")#emph[#text("machine learning")]#text(" (whose practical applications at the time involved such feats as deciphering human-written zip codes). Attending such a program might be regarded as out of scope for many material scientists. Yet the outcome of the program was the realization that machine learning methods could be used to learn and model the forces that govern electronic structure, molecular interactions, and ultimately determine chemical properties of materials through much faster and efficient computation. This idea was incredibly fruitful and literally changed the way electronic structure computations are done. ")#emph[#text("AlphaFold")]#text(" has become Nobel prize winning work, and AI is being used to discover new drugs. Now, 15 years later, scientists are building labs to literally navigate the chemical compound space, assisted by AI, a descendant of old machine-learning computations approaches.")

#text("These examples also illustrate the time scales involved in fundamental research and in bringing it to the point where its application becomes an engineering endeavor. Fundamental research means playing the long game, leveraging the richness and unpredictability of scientific discovery. It is not something a private company would fund, but it is the engine behind the continued technological transformation whose fruits we all enjoy. It means taking risks, going in directions that are mere hunches and educated guesses, and going there only with the expectation to find new and surprising things. But it is necessary for technological progress.")

#text("Importantly, it is unrealistic to expect that every conference attendance will result in a major and unexpected connection or breakthrough. At times, there is a slow accumulation of knowledge that suddenly produces unexpected results. It is important to understand that fundamental research operates on scales of years and decades. The ultimate effect of attending a conference cannot always be known in advance, making the pre-approval process difficult to manage. This brings in a related point: the risk-averse nature of the proposed rules. We all know that making breakthroughs requires risk-taking; behind every successful project stand several that failed. Sometimes, communication of what failed is as useful (or more!) as communication of what succeeded, and this kind of information gets shared in informal settings at workshops and conferences.")

#text("The willingness to take risks and move in unexpected directions has always been a particular strength of this country, both in science and elsewhere, as exemplified for instance by the Defence Advanced Research Projects Agency (DARPA)’s willingness to experiment with emerging technologies such as the internet, GPS systems, or high-energy lasers, long before they could be proven to be viable. The additional regulatory burdens of these proposed rule changes would cripple this capability and set back the nation’s scientific competitiveness and leadership with the technologies of the future. I encourage all stakeholders (whether individuals or organizations) to submit public comments on the proposal on ")#link("https://www.federalregister.gov/documents/2026/05/29/2026-10817/regulation-for-federal-financial-assistance#open-comment")[#text("the OMB site")]#text(" (the public comment period extends until July 13). You can also submit through the ")#link("https://fight2win.standupforscience.net/campaign/163675/")[#text("Stand Up for Science site")]#text(".")

#emph[#text("(Thanks to Kevin Klowden and Dima Shylakhtenko for feedback on an initial version of this post.)")]

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11a24b38007dc03aa218f3eb92b8e79681e6f810e378f3bfa2729b078f8609ac-505d6030ec57e5ef3a5aa385754c06d78ee8b223b1e093b26795af5b0a91bc31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rajan Anantharaman")]], [#link("https://terrytao.wordpress.com/2026/06/09/on-the-proposed-rule-changes-to-the-administration-of-federal-grants/#comment-692870")[#strong[#text("Rajan Anantharaman")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2026")])]

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0b423fadc513ac0411dd0514ea026a2d16a4135f02398c6cf3e216875f731e7-f10415d608fb7f54446cf1edbfc12d995d6764cec76d613dd19362a166d378a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Justin Bian")]], [#link("https://terrytao.wordpress.com/2026/06/09/on-the-proposed-rule-changes-to-the-administration-of-federal-grants/#comment-692876")[#strong[#text("Justin Bian")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2026")])]

#text("Thank you Professor Tao!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/06/09/on-the-proposed-rule-changes-to-the-administration-of-federal-grants/#comment-692936")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2026")])]

#text("How does one decide whether a scientist in related field serve to advance a program outcome or not? Does it say explicitly that an outcome later down the road does not count?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11a24b38007dc03aa218f3eb92b8e79681e6f810e378f3bfa2729b078f8609ac-505d6030ec57e5ef3a5aa385754c06d78ee8b223b1e093b26795af5b0a91bc31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rajan Anantharaman")]], [#link("https://terrytao.wordpress.com/2026/06/09/on-the-proposed-rule-changes-to-the-administration-of-federal-grants/#comment-692939")[#strong[#text("Rajan Anantharaman")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2026")])]

#text("Thank you")

#text("On Tue, Jun 9, 2026, 7:48 PM Rajan Anantharaman < ")#link("mailto:rajan.anantharaman@gmail.com")[#text("rajan.anantharaman@gmail.com")]#text("> wrote:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Thanks >")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/06/09/on-the-proposed-rule-changes-to-the-administration-of-federal-grants/#comment-692941")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2026")])]

#text("All of my collaborations, including my most recent one which got me my job, have happened through serendipitous meetings at conferences.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/06/09/on-the-proposed-rule-changes-to-the-administration-of-federal-grants/#comment-692957")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2026")])]

#text("Dear Professor Terry Tao. Instead of (possibly hopeless) fighting with government, why not mathematicians to re-organise the work to NOT rely on government good will at all? Fortunately, unlike physics, we do not need an expensive equipment. Our salaries are mostly covered by student’s tuition fees. Instead of research-only postdocs funded by grants, Universities may introduce fixed-term contracts with both research and teaching responsibilities, again funded by students. You are writing about conferences, but they can have registration fees sufficient to cover expenses. In parallel, the Universities can have some money (again from students) to support their staff going to conferences – travel, accommodation, and registration fee. I agree that a person without grant can attend not as many conferences as they would like, but, on the other hand, a massive save of time from writing grant applications, 4 out of 5 not funded, and then, for funded, spend huge percentage of time for various bureaucratic issues, which now increases again. I feel that, especially with new rules, the grants bring us more pain than benefits, so my not learn to live without them?")
]
