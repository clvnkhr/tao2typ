// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/
// Converted to Typst by tao2typ: "2026-10-14T15:20:58.054187+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A slightly longer Lean 4 proof tour", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A slightly longer Lean 4 proof tour")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 December 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/")[#text("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("In my ")#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/")[#text("previous post")]#text(", I walked through the task of formally deducing one lemma from another in ")#link("https://en.wikipedia.org/wiki/Lean_(proof_assistant)")[#text("Lean 4")]#text(". The deduction was deliberately chosen to be short and only showcased a small number of Lean tactics. Here I would like to walk through the process I used for a slightly longer proof I worked out recently, after seeing the following ")#link("https://twitter.com/damekdavis/status/1730983634570510819")[#text("challenge from Damek Davis")]#text(": to formalize (in a civilized fashion) the proof of the following lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma")]#text(". Let ")#mi("\\{a_k\\}")#text(" and ")#mi("\\{D_k\\}")#text(" be sequences of real numbers indexed by natural numbers ")#mi("k=0,1,\\dots")#text(", with ")#mi("a_k")#text(" non-increasing and ")#mi("D_k")#text(" non-negative. Suppose also that ")#mi("a_k \\leq D_k - D_{k+1}")#text(" for all ")#mi("k \\geq 0")#text(". Then ")#mi("a_k \\leq \\frac{D_0}{k+1}")#text(" for all ")#mi("k")#text(".")
]

#text("Here I tried to draw upon the lessons I had learned from the PFR formalization project, and to first set up a human readable proof of the lemma before starting the Lean formalization – a lower-case “blueprint” rather than the fancier ")#link("https://github.com/PatrickMassot/leanblueprint")[#text("Blueprint")]#text(" used in the PFR project. The main idea of the proof here is to use the telescoping series identity")

#mi("\\displaystyle \\sum_{i=0}^k D_i - D_{i+1} = D_0 - D_{k+1}.")

#text("Since ")#mi("D_{k+1}")#text(" is non-negative, and ")#mi("a_i \\leq D_i - D_{i+1}")#text(" by hypothesis, we have")

#mi("\\displaystyle \\sum_{i=0}^k a_i \\leq D_0")

#text("but by the monotone hypothesis on ")#mi("a_i")#text(" the left-hand side is at least ")#mi("(k+1) a_k")#text(", giving the claim.")

#text("This is already a human-readable proof, but in order to formalize it more easily in Lean, I decided to rewrite it as a chain of inequalities, starting at ")#mi("a_k")#text(" and ending at ")#mi("D_0 / (k+1)")#text(". With a little bit of pen and paper effort, I obtained")

#mi("a_k = (k+1) a_k / (k+1)")

#text("(by field identities)")

#mi("= (\\sum_{i=0}^k a_k) / (k+1)")

#text("(by the formula for summing a constant)")

#mi("\\leq (\\sum_{i=0}^k a_i) / (k+1)")

#text("(by the monotone hypothesis)")

#mi("\\leq (\\sum_{i=0}^k D_i - D_{i+1}) / (k+1)")

#text("(by the hypothesis ")#mi("a_i \\leq D_i - D_{i+1}")

#mi("= (D_0 - D_{k+1}) / (k+1)")

#text("(by telescoping series)")

#mi("\\leq D_0 / (k+1)")

#text("(by the non-negativity of ")#mi("D_{k+1}")#text(").")

#text("I decided that this was a good enough blueprint for me to work with. The next step is to formalize the statement of the lemma in Lean. For this quick project, it was convenient to use the ")#link("https://live.lean-lang.org/")[#text("online Lean playground")]#text(", rather than my local IDE, so the screenshots will look a little different from those in the previous post. (If you like, you can follow this tour in that playground, by clicking on the screenshots of the Lean code.) I start by importing Lean’s math library, and starting an example of a statement to state and prove:")

#image("../assets/57e501523e41fb26ac231e245917669f34fe6073b09847e012478e4c794aec6f-69c50dd1471bf8ba57c764869a5c3eafc06710ce89a1013a00ae12e12b18bf30.png", width: 90%)

#align(center)[
#link("https://live.lean-lang.org/#code=import%20Mathlib%0D%0A%0D%0Aexample%20(a%20D%20%3A%20%E2%84%95%20%E2%86%92%20%E2%84%9D)")[#image("../assets/b03ae3cd92f2abc62192d1a69ece47c0985e4c859c60d4a3090a1c0c8494f7c1-d5f6106e00c03aed07196c9595fbec31a4ae872aebebdb4024d9964f734ae28c.png", width: 90%)]
]

#text("Now we have to declare the hypotheses and variables. The main variables here are the sequences ")#mi("a_k")#text(" and ")#mi("D_k")#text(", which in Lean are best modeled by functions ")#raw("a")#text(", ")#raw("D")#text(" from the natural numbers ℕ to the reals ℝ. (One can choose to “hardwire” the non-negativity hypothesis into the ")#mi("D_k")#text(" by making ")#raw("D")#text(" take values in the nonnegative reals ")#mi("{\\bf R}^+")#text(" (denoted ")#raw("NNReal")#text(" in Lean), but this turns out to be inconvenient, because the laws of algebra and summation that we will need are clunkier on the non-negative reals (which are not even a group) than on the reals (which are a field). So we add in the variables:")

#align(center)[
#link("https://live.lean-lang.org/#code=import%20Mathlib%0D%0A%0D%0Aexample%20(a%20D%20%3A%20%E2%84%95%20%E2%86%92%20%E2%84%9D)")[#image("../assets/44cd1f4a11d57c776ccad00bdd8249952fb88f2bc2ea9de71ee666428dc13974-2457eb0d22115ade1f4b5e2b21b2ae5d42d6716c3c8297a2049daf94304be89d.png", width: 90%)]
]

#text("Now we add in the hypotheses, which in Lean convention are usually given names starting with ")#raw("h")#text(". This is fairly straightforward; the one thing is that the property of being monotone decreasing already has a name in Lean’s Mathlib, namely ")#raw("Antitone")#text(", and it is generally a good idea to use the Mathlib provided terminology (because that library contains a lot of useful lemmas about such terms).")

#align(center)[
#link("https://live.lean-lang.org/#code=import%20Mathlib%0D%0A%0D%0Aexample%20(a%20D%20%3A%20%E2%84%95%20%E2%86%92%20%E2%84%9D)%20(hD%20%3A%20%E2%88%80%20k%2C%20a%20k%20%E2%89%A4%20D%20k%20-%20D%20(k%2B1))%20(hpos%20%3A%20%E2%88%80%20k%2C%200%20%E2%89%A4%20D%20k)%20(ha%20%3A%20Antitone%20a)")[#image("../assets/ddef664a56bb8ab9fc62465a4587107ce9e462ea9841be53537321d8110fec08-29492b55d76c1cb858f28ec530f4c1573f185d8f74a3dd0424ec100420f6d7b7.png", width: 90%)]
]

#text("One thing to note here is that Lean is quite good at filling in implied ranges of variables. Because ")#raw("a")#text(" and ")#raw("D")#text(" have the natural numbers ℕ as their domain, the dummy variable ")#raw("k")#text(" in these hypotheses is automatically being quantified over ℕ. We ")#emph[#text("could")]#text(" have made this quantification explicit if we so chose, for instance using ")#raw("∀ k : ℕ, 0 ≤ D k")#text(" instead of ")#raw("∀ k, 0 ≤ D k")#text(", but it is not necessary to do so. Also note that Lean does not require parentheses when applying functions: we write ")#raw("D k")#text(" here rather than ")#raw("D(k)")#text(" (which in fact does not compile in Lean unless one puts a space between the ")#raw("D")#text(" and the parentheses). This is slightly different from standard mathematical notation, but is not too difficult to get used to.")

#text("This looks like the end of the hypotheses, so we could now add a colon to move to the conclusion, and then add that conclusion:")

#align(center)[
#link("https://live.lean-lang.org/#code=import%20Mathlib%0D%0A%0D%0Aexample%20(a%20D%20%3A%20%E2%84%95%20%E2%86%92%20%E2%84%9D)%20(hD%20%3A%20%E2%88%80%20k%2C%20a%20k%20%E2%89%A4%20D%20k%20-%20D%20(k%2B1))%20(hpos%20%3A%20%E2%88%80%20k%2C%200%20%E2%89%A4%20D%20k)%20(ha%20%3A%20Antitone%20a)%20%3A%20%E2%88%80%20k%2C%20a%20k%20%E2%89%A4%20D%200%20%2F%20(k%20%2B%201)")[#image("../assets/5e3ab5fcab2cf8b49a6089edebf634bbabc1a3941b3f25d0393519d1da605ac7-10bd436bade410fde7361bba5248c6c62e85f9c1eb9d3b1b8db4a97bb2e83e39.png", width: 90%)]
]

#text("This is a perfectly fine Lean statement. But it turns out that when proving a universally quantified statement such as ")#raw("∀ k, a k ≤ D 0 / (k + 1)")#text(", the first step is almost always to open up the quantifier to introduce the variable ")#raw("k")#text(" (using the Lean command ")#raw("intro k")#text("). Because of this, it is slightly more efficient to hide the universal quantifier by placing the variable ")#raw("k")#text(" in the hypotheses, rather than in the quantifier (in which case we have to now specify that it is a natural number, as Lean can no longer deduce this from context):")

#align(center)[
#link("https://live.lean-lang.org/#code=import%20Mathlib%0D%0A%0D%0Aexample%20(a%20D%20%3A%20%E2%84%95%20%E2%86%92%20%E2%84%9D)%20(hD%20%3A%20%E2%88%80%20k%2C%20a%20k%20%E2%89%A4%20D%20k%20-%20D%20(k%2B1))%20(hpos%20%3A%20%E2%88%80%20k%2C%200%20%E2%89%A4%20D%20k)%20(ha%20%3A%20Antitone%20a)%20(k%20%3A%20%E2%84%95)%20%3A%20a%20k%20%E2%89%A4%20D%200%20%2F%20(k%20%2B%201)")[#image("../assets/ffb2aab4b5749279bd8ef1e04df387356062ef85253bdf2ba890809b0fee0af4-d073643713462f92289c39957829fb7c33d966fa845812894d2a0364dd579cb4.png", width: 90%)]
]

#text("At this point Lean is complaining of an unexpected end of input: the example has been stated, but not proved. We will temporarily mollify Lean by adding a ")#raw("sorry")#text(" as the purported proof:")

#align(center)[
#link("https://live.lean-lang.org/#code=import%20Mathlib%0D%0A%0D%0Aexample%20(a%20D%20%3A%20%E2%84%95%20%E2%86%92%20%E2%84%9D)%20(hD%20%3A%20%E2%88%80%20k%2C%20a%20k%20%E2%89%A4%20D%20k%20-%20D%20(k%2B1))%20(hpos%20%3A%20%E2%88%80%20k%2C%200%20%E2%89%A4%20D%20k)%20(ha%20%3A%20Antitone%20a)%20(k%20%3A%20%E2%84%95)%20%0D%0A%20%20%3A%20a%20k%20%E2%89%A4%20D%200%20%2F%20(k%20%2B%201)%20%3A%3D%20sorry")[#image("../assets/19854c2eeac094892e6380f810bd203ad6f76c759bfea9c51345790739dbf351-4dffe386cd59f71c7e6150e56074b58f15416ce9ada1ff4a81710ecf37e50bca.png", width: 90%)]
]

#text("Now Lean is content, other than giving a warning (as indicated by the yellow squiggle under the ")#raw("example")#text(") that the proof contains a sorry.")

#text("It is now time to follow the blueprint. The Lean tactic for proving an inequality via chains of other inequalities is known as ")#raw("calc")#text(". We use the blueprint to fill in the ")#raw("calc")#text(" that we want, leaving the justifications of each step as “")#raw("sorry")#text("”s for now:")

#align(center)[
#link("https://live.lean-lang.org/#code=import%20Mathlib%0D%0A%0D%0Aopen%20Finset%20BigOperators%0D%0A%0D%0Aexample%20(a%20D%20%3A%20%E2%84%95%20%E2%86%92%20%E2%84%9D)%20(hD%20%3A%20%E2%88%80%20k%2C%20a%20k%20%E2%89%A4%20D%20k%20-%20D%20(k%2B1))%20(hpos%20%3A%20%E2%88%80%20k%2C%200%20%E2%89%A4%20D%20k)%20(ha%20%3A%20Antitone%20a)%20(k%20%3A%20%E2%84%95)%20%0D%0A%20%20%3A%20a%20k%20%E2%89%A4%20D%200%20%2F%20(k%20%2B%201)%20%3A%3D%20calc%0D%0A%20%20%20%20a%20k%20%3D%20(k%2B1)%20*%20(a%20k)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20sorry%0D%0A%20%20%20%20_%20%3D%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20a%20k)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20sorry%0D%0A%20%20%20%20_%20%E2%89%A4%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20a%20i)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20sorry%20%0D%0A%20%20%20%20_%20%E2%89%A4%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20(D%20i%20-%20D%20(i%2B1)))%20%2F%20(k%2B1)%20%20%3A%3D%20by%20sorry%0D%0A%20%20%20%20_%20%3D%20(D%200%20-%20D%20(k%2B1))%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20sorry%0D%0A%20%20%20%20_%20%E2%89%A4%20D%200%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20sorry")[#image("../assets/6afb173965700120bd493f9d40482eb3dd349d908856c3a01c32ee2df0f9b226-61012f634f0fed3fafaaedcdeab18f30ddb03f0e6c755b7ed6b1533e5eecbac6.png", width: 90%)]
]

#text("Here, we “")#raw("open")#text("“ed the ")#raw("Finset")#text(" namespace in order to easily access ")#raw("Finset")#text("‘s ")#raw("range")#text(" function, with ")#raw("range k")#text(" basically being the finite set of natural numbers ")#mi("\\{0,\\dots,k-1\\}")#text(", and also “")#raw("open")#text("“ed the ")#raw("BigOperators")#text(" namespace to access the familiar ∑ notation for (finite) summation, in order to make the steps in the Lean code resemble the blueprint as much as possible. One could avoid opening these namespaces, but then expressions such as ")#raw("∑ i in range (k+1), a i")#text(" would instead have to be written as something like ")#raw("Finset.sum (Finset.range (k+1)) (fun i ↦ a i)")#text(", which looks a lot less like like standard mathematical writing. The proof structure here may remind some readers of the “two column proofs” that are somewhat popular in American high school geometry classes.")

#text("Now we have six sorries to fill. Navigating to the first sorry, Lean tells us the ambient hypotheses, and the goal that we need to prove to fill that sorry:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/12/image-5.png")[#image("../assets/814154674dec348eb1c802809d1ca89c2056553435c954831e60d1a53f8eae48-4fcc258f130d4bc28e53e8a4053bfec40730c562781bc40b3210be4abeb580e3.png", width: 90%)]
]

#text("The ⊢ symbol here is Lean’s marker for the goal. The uparrows ↑ are coercion symbols, indicating that the natural number ")#raw("k")#text(" has to be converted to a real number in order to interact via arithmetic operations with other real numbers such as ")#raw("a k")#text(", but we can ignore these coercions for this tour (for this proof, it turns out Lean will basically manage them automatically without need for any explicit intervention by a human).")

#text("The goal here is a self-evident algebraic identity; it involves division, so one has to check that the denominator is non-zero, but this is self-evident. In Lean, a convenient way to establish algebraic identities is to use the tactic ")#raw("field_simp")#text(" to clear denominators, and then ")#raw("ring")#text(" to verify any identity that is valid for commutative rings. This works, and clears the first ")#raw("sorry")#text(":")

#align(center)[
#link("https://live.lean-lang.org/#code=import%20Mathlib%0D%0A%0D%0Aopen%20Finset%20BigOperators%0D%0A%0D%0Aexample%20(a%20D%20%3A%20%E2%84%95%20%E2%86%92%20%E2%84%9D)%20(hD%20%3A%20%E2%88%80%20k%2C%20a%20k%20%E2%89%A4%20D%20k%20-%20D%20(k%2B1))%20(hpos%20%3A%20%E2%88%80%20k%2C%200%20%E2%89%A4%20D%20k)%20(ha%20%3A%20Antitone%20a)%20(k%20%3A%20%E2%84%95)%20%0D%0A%20%20%3A%20a%20k%20%E2%89%A4%20D%200%20%2F%20(k%20%2B%201)%20%3A%3D%20calc%0D%0A%20%20%20%20a%20k%20%3D%20(k%2B1)%20*%20(a%20k)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20field_simp%3B%20ring%0D%0A%20%20%20%20_%20%3D%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20a%20k)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20sorry%0D%0A%20%20%20%20_%20%E2%89%A4%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20a%20i)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20sorry%20%0D%0A%20%20%20%20_%20%E2%89%A4%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20(D%20i%20-%20D%20(i%2B1)))%20%2F%20(k%2B1)%20%20%3A%3D%20by%20sorry%0D%0A%20%20%20%20_%20%3D%20(D%200%20-%20D%20(k%2B1))%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20sorry%0D%0A%20%20%20%20_%20%E2%89%A4%20D%200%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20sorry")[#image("../assets/b3f0d9a3d7dff7028faeffd3f2e809c6c1f915db53af7397c909b76ecd4a9f4c-dc6f82b7c6f232acbf4448059b1498fcf96340f59715fe882f74720ae1d2f502.png", width: 90%)]
]

#raw("field_simp")#text(", by the way, is smart enough to deduce on its own that the denominator ")#raw("k+1")#text(" here is manifestly non-zero (and in fact positive); no human intervention is required to point this out. Similarly for other “clearing denominator” steps that we will encounter in the other parts of the proof.")

#text("Now we navigate to the next `sorry`. Lean tells us the hypotheses and goals:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/12/image-8.png")[#image("../assets/18711ca16d1ac16841c6ddb0ef0c76b09ff2b760a9e2448341799cd264c50aa9-8005f337303ead7002ed32e9773765e264b99d1d750b9c8e70debbe4a9e7da1a.png", width: 90%)]
]

#text("We can reduce the goal by canceling out the common denominator ")#raw("↑k+1")#text(". Here we can use the handy Lean tactic ")#raw("congr")#text(", which tries to match two sides of an equality goal as much as possible, and leave any remaining discrepancies between the two sides as further goals to be proven. Applying ")#raw("congr")#text(", the goal reduces to")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/12/image-9.png")[#image("../assets/038144bbfb2050cd1dfae73c987ef00c7ea4c1656e440f327e9e35bd5e6223dd-09866873479000e994935cfbfdec7c47e61ddf08ee1e12a05c382ea4fbf7f977.png", width: 90%)]
]

#text("Here one might imagine that this is something that one can prove by induction. But this particular sort of identity – summing a constant over a finite set – is already covered by Mathlib. Indeed, searching for ")#raw("Finset")#text(", ")#raw("sum")#text(", and ")#raw("const")#text(" soon leads us to the ")#raw("Finset.sum_const")#text(" lemma here. But there is an even more convenient path to take here, which is to apply the powerful tactic ")#raw("simp")#text(", which tries to simplify the goal as much as possible using all the “")#raw("simp")#text(" lemmas” Mathlib has to offer (of which ")#raw("Finset.sum_const")#text(" is an example, but there are thousands of others). As it turns out, ")#raw("simp")#text(" completely kills off this identity, without any further human intervention:")

#align(center)[
#link("https://live.lean-lang.org/#code=import%20Mathlib%0D%0A%0D%0Aopen%20Finset%20BigOperators%0D%0A%0D%0Aexample%20(a%20D%20%3A%20%E2%84%95%20%E2%86%92%20%E2%84%9D)%20(hD%20%3A%20%E2%88%80%20k%2C%20a%20k%20%E2%89%A4%20D%20k%20-%20D%20(k%2B1))%20(hpos%20%3A%20%E2%88%80%20k%2C%200%20%E2%89%A4%20D%20k)%20(ha%20%3A%20Antitone%20a)%20(k%20%3A%20%E2%84%95)%20%0D%0A%20%20%3A%20a%20k%20%E2%89%A4%20D%200%20%2F%20(k%20%2B%201)%20%3A%3D%20calc%0D%0A%20%20%20%20a%20k%20%3D%20(k%2B1)%20*%20(a%20k)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20field_simp%3B%20ring%0D%0A%20%20%20%20_%20%3D%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20a%20k)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20congr%3B%20simp%0D%0A%20%20%20%20_%20%E2%89%A4%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20a%20i)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20sorry%20%0D%0A%20%20%20%20_%20%E2%89%A4%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20(D%20i%20-%20D%20(i%2B1)))%20%2F%20(k%2B1)%20%20%3A%3D%20by%20sorry%0D%0A%20%20%20%20_%20%3D%20(D%200%20-%20D%20(k%2B1))%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20sorry%0D%0A%20%20%20%20_%20%E2%89%A4%20D%200%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20sorry")[#image("../assets/f32eba23add1d4a2617ebcb340355b5c51de61792399f60d1617ce4390b73674-24d673677be4b72faf31d18f941df35d510779cd9883ada8b4e8d7f96dd3650e.png", width: 90%)]
]

#text("Now we move on to the next sorry, and look at our goal:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/12/image-11.png")[#image("../assets/6fbc877c9cd11b5db5af6a47d8895df018df063027d236ebb8e513e794d82384-ec6709405dbf957073edb82902f6e84a63029b169e3089504554aef0e883d89f.png", width: 90%)]
]

#raw("congr")#text(" doesn’t work here because we have an inequality instead of an equality, but there is a powerful relative ")#raw("gcongr")#text(" of ")#raw("congr")#text(" that is perfectly suited for inequalities. It can also open up sums, products, and integrals, reducing global inequalities between such quantities into pointwise inequalities. If we invoke ")#raw("gcongr with i hi")#text(" (where we tell ")#raw("gcongr")#text(" to use ")#raw("i")#text(" for the variable opened up, and ")#raw("hi")#text(" for the constraint this variable will satisfy), we arrive at a greatly simplified goal (and a new ambient variable and hypothesis):")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/12/image-12.png")[#image("../assets/fa89a9bc3e81d4867dbe094de9ad3671404b6b99fd20a19def41d2ef0ed53a55-5f5c7f97530a2ed97ebb0bb6e426ff7c52159427e5257c739f8d4287e8435610.png", width: 90%)]
]

#text("Now we need to use the monotonicity hypothesis on ")#raw("a")#text(", which we have named ")#raw("ha")#text(" here. Looking at the ")#link("https://leanprover-community.github.io/mathlib4_docs/Mathlib/Order/Monotone/Basic.html")[#text("documentation for Antitone")]#text(", one finds a lemma that looks applicable here:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/12/image-13.png")[#image("../assets/daa8de45f9d57cbb736b42045fabd72e36095fcc8ccb627db55424c35a7fbf07-d116148f1bc0000d893b99a16668b7961230241c0a48b2cc3b383df39fe53f32.png", width: 90%)]
]

#text("One can apply this lemma in this case by writing ")#raw("apply Antitone.imp ha")#text(", but because ")#raw("ha")#text(" is already of type ")#raw("Antitone")#text(", we can abbreviate this to ")#raw("apply ha.imp")#text(". (Actually, as indicated in the documentation, due to the way ")#raw("Antitone")#text(" is defined, we can even just use ")#raw("apply ha")#text(" here.) This reduces the goal nicely:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/12/image-14.png")[#image("../assets/28894a5b863ffff70c5579a1dba05d224795731d8dfdb8473849bfa752438827-301893d6589e32a7b61ed2cbeec7c99b5cfaeab651a077167fb0cb91311dc794.png", width: 90%)]
]

#text("The goal is now very close to the hypothesis ")#raw("hi")#text(". One could now look up the documentation for ")#raw("Finset.range")#text(" to see how to unpack ")#raw("hi")#text(", but as before ")#raw("simp")#text(" can do this for us. Invoking ")#raw("simp at hi")#text(", we obtain")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/12/image-15.png")[#image("../assets/fcca762af336d95dc2a8cf4f75b5fff2b4b28e306b3fda49d4c1f155dbb50ba5-2c01fa689a7058015913f8022a9f2f9c76c010516bb0f88b841648b3f1bda433.png", width: 90%)]
]

#text("Now the goal and hypothesis are very close indeed. Here we can just close the goal using the ")#raw("linarith")#text(" tactic used in the ")#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/")[#text("previous tour")]#text(":")

#align(center)[
#link("https://live.lean-lang.org/#code=import%20Mathlib%0D%0A%0D%0Aopen%20Finset%20BigOperators%0D%0A%0D%0Aexample%20(a%20D%20%3A%20%E2%84%95%20%E2%86%92%20%E2%84%9D)%20(hD%20%3A%20%E2%88%80%20k%2C%20a%20k%20%E2%89%A4%20D%20k%20-%20D%20(k%2B1))%20(hpos%20%3A%20%E2%88%80%20k%2C%200%20%E2%89%A4%20D%20k)%20(ha%20%3A%20Antitone%20a)%20(k%20%3A%20%E2%84%95)%20%0D%0A%20%20%3A%20a%20k%20%E2%89%A4%20D%200%20%2F%20(k%20%2B%201)%20%3A%3D%20calc%0D%0A%20%20%20%20a%20k%20%3D%20(k%2B1)%20*%20(a%20k)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20field_simp%3B%20ring%0D%0A%20%20%20%20_%20%3D%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20a%20k)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20congr%3B%20simp%0D%0A%20%20%20%20_%20%E2%89%A4%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20a%20i)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20gcongr%20with%20i%20hi%3B%20apply%20ha%3B%20simp%20at%20hi%3B%20linarith%0D%0A%20%20%20%20_%20%E2%89%A4%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20(D%20i%20-%20D%20(i%2B1)))%20%2F%20(k%2B1)%20%20%3A%3D%20by%20sorry%0D%0A%20%20%20%20_%20%3D%20(D%200%20-%20D%20(k%2B1))%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20sorry%0D%0A%20%20%20%20_%20%E2%89%A4%20D%200%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20sorry")[#image("../assets/4c62fc7da1aa87c6a44a7f3d0913ae28667c1625ea2c2c83ec61ad1651fe6c1d-94995b729d3e8225eda3976136b8e45a4cc7728b2ed53d58058df5af051d16c9.png", width: 90%)]
]

#text("The next sorry can be resolved by similar methods, using the hypothesis ")#raw("hD")#text(" applied at the variable ")#raw("i")#text(":")

#align(center)[
#link("https://live.lean-lang.org/#code=import%20Mathlib%0D%0A%0D%0Aopen%20Finset%20BigOperators%0D%0A%0D%0Aexample%20(a%20D%20%3A%20%E2%84%95%20%E2%86%92%20%E2%84%9D)%20(hD%20%3A%20%E2%88%80%20k%2C%20a%20k%20%E2%89%A4%20D%20k%20-%20D%20(k%2B1))%20(hpos%20%3A%20%E2%88%80%20k%2C%200%20%E2%89%A4%20D%20k)%20(ha%20%3A%20Antitone%20a)%20(k%20%3A%20%E2%84%95)%20%0D%0A%20%20%3A%20a%20k%20%E2%89%A4%20D%200%20%2F%20(k%20%2B%201)%20%3A%3D%20calc%0D%0A%20%20%20%20a%20k%20%3D%20(k%2B1)%20*%20(a%20k)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20field_simp%3B%20ring%0D%0A%20%20%20%20_%20%3D%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20a%20k)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20congr%3B%20simp%0D%0A%20%20%20%20_%20%E2%89%A4%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20a%20i)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20gcongr%20with%20i%20hi%3B%20apply%20ha%3B%20simp%20at%20hi%3B%20linarith%0D%0A%20%20%20%20_%20%E2%89%A4%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20(D%20i%20-%20D%20(i%2B1)))%20%2F%20(k%2B1)%20%20%3A%3D%20by%20gcongr%20with%20i%20hi%3B%20exact%20hD%20i%0D%0A%20%20%20%20_%20%3D%20(D%200%20-%20D%20(k%2B1))%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20sorry%0D%0A%20%20%20%20_%20%E2%89%A4%20D%200%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20sorry")[#image("../assets/cd251d25b2b1df785a8bed1bb410ee74bcd34dd0b5122209af97c3d703d2e4ff-472875cced78641921a92f5f488161865c56608a87a0f83c2c6337e2ff1a71d7.png", width: 90%)]
]

#text("Now for the penultimate sorry. As in a previous step, we can use ")#raw("congr")#text(" to remove the denominator, leaving us in this state:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/12/image-18.png")[#image("../assets/e219f16eb95ab00823f50f8597cb32817f4362f859a15ab0b07a1d293e3896d8-f29a5cd36556945e9a1d77494a4ab83fdefb885532f5d2791a95d55e571a33bd.png", width: 90%)]
]

#text("This is a telescoping series identity. One could try to prove it by induction, or one could try to see if this identity is already in Mathlib. Searching for ")#raw("Finset")#text(", ")#raw("sum")#text(", and ")#raw("sub")#text(" will ")#link("https://leanprover-community.github.io/mathlib4_docs/search.html?sitesearch=https%3A%2F%2Fleanprover-community.github.io%2Fmathlib4_docs&q=finset+sum+sub")[#text("locate the right tool")]#text(" (as the fifth hit), but a simpler way to proceed here is to use the ")#raw("exact?")#text(" tactic we saw in the ")#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/")[#text("previous tour")]#text(":")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/12/image-19.png")[#image("../assets/2ee1e80eb4fbd2de09403d0c94e0ce060b65e5b082fbcc5e8dffa01106439453-413bdc9e034a0f8a7c319e4ac84f5015b2587ac4eabd8b361393e5d01257cc48.png", width: 90%)]
]

#text("A brief check of the documentation for ")#raw("sum_range_sub'")#text(" confirms that this is what we want. Actually we can just use ")#raw("apply sum_range_sub'")#text(" here, as the ")#raw("apply")#text(" tactic is smart enough to fill in the missing arguments:")

#align(center)[
#link("https://live.lean-lang.org/#code=import%20Mathlib%0D%0A%0D%0Aopen%20Finset%20BigOperators%0D%0A%0D%0Aexample%20(a%20D%20%3A%20%E2%84%95%20%E2%86%92%20%E2%84%9D)%20(hD%20%3A%20%E2%88%80%20k%2C%20a%20k%20%E2%89%A4%20D%20k%20-%20D%20(k%2B1))%20(hpos%20%3A%20%E2%88%80%20k%2C%200%20%E2%89%A4%20D%20k)%20(ha%20%3A%20Antitone%20a)%20(k%20%3A%20%E2%84%95)%20%0D%0A%20%20%3A%20a%20k%20%E2%89%A4%20D%200%20%2F%20(k%20%2B%201)%20%3A%3D%20calc%0D%0A%20%20%20%20a%20k%20%3D%20(k%2B1)%20*%20(a%20k)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20field_simp%3B%20ring%0D%0A%20%20%20%20_%20%3D%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20a%20k)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20congr%3B%20simp%0D%0A%20%20%20%20_%20%E2%89%A4%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20a%20i)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20gcongr%20with%20i%20hi%3B%20apply%20ha%3B%20simp%20at%20hi%3B%20linarith%0D%0A%20%20%20%20_%20%E2%89%A4%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20(D%20i%20-%20D%20(i%2B1)))%20%2F%20(k%2B1)%20%20%3A%3D%20by%20gcongr%20with%20i%20hi%3B%20exact%20hD%20i%0D%0A%20%20%20%20_%20%3D%20(D%200%20-%20D%20(k%2B1))%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20congr%3B%20apply%20sum_range_sub'%0D%0A%20%20%20%20_%20%E2%89%A4%20D%200%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20sorry")[#image("../assets/562132c0f5d25a1352a40b7203e27f0d881108584dda5b5cd9d79c7dbe00f12a-aa2af5892e1927476e658125d413ae0a12d647bde7bc54bcf17433b804e68577.png", width: 90%)]
]

#text("One last ")#raw("sorry")#text(" to go. As before, we use ")#raw("gcongr")#text(" to cancel denominators, leaving us with")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/12/image-21.png")[#image("../assets/69342da63fc671ea075d98ea3b7e032c7f736b9c8924b8870450b572c0c46df9-d9e22efbdd0cdcd711799a53b11452a35b217476753daae9e4fe4525ddd51228.png", width: 90%)]
]

#text("This looks easy, because the hypothesis ")#raw("hpos")#text(" will tell us that ")#raw("D (k+1)")#text(" is nonnegative; specifically, the instance ")#raw("hpos (k+1)")#text(" of that hypothesis will state exactly this. The ")#raw("linarith")#text(" tactic will then resolve this goal once it is told about this particular instance:")

#align(center)[
#link("https://live.lean-lang.org/#code=import%20Mathlib%0D%0A%0D%0Aopen%20Finset%20BigOperators%0D%0A%0D%0Aexample%20(a%20D%20%3A%20%E2%84%95%20%E2%86%92%20%E2%84%9D)%20(hD%20%3A%20%E2%88%80%20k%2C%20a%20k%20%E2%89%A4%20D%20k%20-%20D%20(k%2B1))%20(hpos%20%3A%20%E2%88%80%20k%2C%200%20%E2%89%A4%20D%20k)%20(ha%20%3A%20Antitone%20a)%20(k%20%3A%20%E2%84%95)%20%0D%0A%20%20%3A%20a%20k%20%E2%89%A4%20D%200%20%2F%20(k%20%2B%201)%20%3A%3D%20calc%0D%0A%20%20%20%20a%20k%20%3D%20(k%2B1)%20*%20(a%20k)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20field_simp%3B%20ring%0D%0A%20%20%20%20_%20%3D%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20a%20k)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20congr%3B%20simp%0D%0A%20%20%20%20_%20%E2%89%A4%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20a%20i)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20gcongr%20with%20i%20hi%3B%20apply%20ha%3B%20simp%20at%20hi%3B%20linarith%0D%0A%20%20%20%20_%20%E2%89%A4%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20(D%20i%20-%20D%20(i%2B1)))%20%2F%20(k%2B1)%20%20%3A%3D%20by%20gcongr%20with%20i%20hi%3B%20exact%20hD%20i%0D%0A%20%20%20%20_%20%3D%20(D%200%20-%20D%20(k%2B1))%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20congr%3B%20apply%20sum_range_sub'%0D%0A%20%20%20%20_%20%E2%89%A4%20D%200%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20gcongr%3B%20linarith%20%5Bhpos%20(k%2B1)%5D")[#image("../assets/5c30abf0209206248e97056d414466d5f7de103558c5fe8f9039a50a6c9a0675-bbefabf85c408225702dbf976fbb92d4a513f49eb0eac0ef146057d86eb090c6.png", width: 90%)]
]

#text("We now have a complete proof – no more yellow squiggly line in the example. There are two warnings though – there are two variables ")#raw("i")#text(" and ")#raw("hi")#text(" introduced in the proof that Lean’s “linter” has noticed are not actually used in the proof. So we can rename them with underscores to tell Lean that we are okay with them not being used:")

#align(center)[
#link("https://live.lean-lang.org/#code=import%20Mathlib%0D%0A%0D%0Aopen%20Finset%20BigOperators%0D%0A%0D%0Aexample%20(a%20D%20%3A%20%E2%84%95%20%E2%86%92%20%E2%84%9D)%20(hD%20%3A%20%E2%88%80%20k%2C%20a%20k%20%E2%89%A4%20D%20k%20-%20D%20(k%2B1))%20(hpos%20%3A%20%E2%88%80%20k%2C%200%20%E2%89%A4%20D%20k)%20(ha%20%3A%20Antitone%20a)%20(k%20%3A%20%E2%84%95)%20%0D%0A%20%20%3A%20a%20k%20%E2%89%A4%20D%200%20%2F%20(k%20%2B%201)%20%3A%3D%20calc%0D%0A%20%20%20%20a%20k%20%3D%20(k%2B1)%20*%20(a%20k)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20field_simp%3B%20ring%0D%0A%20%20%20%20_%20%3D%20(%E2%88%91%20_i%20in%20range%20(k%2B1)%2C%20a%20k)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20congr%3B%20simp%0D%0A%20%20%20%20_%20%E2%89%A4%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20a%20i)%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20gcongr%20with%20i%20hi%3B%20apply%20ha%3B%20simp%20at%20hi%3B%20linarith%0D%0A%20%20%20%20_%20%E2%89%A4%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20(D%20i%20-%20D%20(i%2B1)))%20%2F%20(k%2B1)%20%20%3A%3D%20by%20gcongr%20with%20i%20_%3B%20exact%20hD%20i%0D%0A%20%20%20%20_%20%3D%20(D%200%20-%20D%20(k%2B1))%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20congr%3B%20apply%20sum_range_sub'%0D%0A%20%20%20%20_%20%E2%89%A4%20D%200%20%2F%20(k%2B1)%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3A%3D%20by%20gcongr%3B%20linarith%20%5Bhpos%20(k%2B1)%5D")[#image("../assets/34a9c8413dfb8b8f61b4ed48440861f76fe5a30cb14047d6eb07ad77845791e2-6befff1609b34d1c19b098e1a0c28d82d154baeb1e5aba4ce96b1350bf04059b.png", width: 90%)]
]

#text("This is a perfectly fine proof, but upon noticing that many of the steps are similar to each other, one can do a bit of “code golf” as in the ")#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/")[#text("previous tour")]#text(" to compactify the proof a bit:")

#align(center)[
#link("https://live.lean-lang.org/#code=import%20Mathlib%0D%0A%0D%0Aopen%20Finset%20BigOperators%0D%0A%0D%0Aexample%20(a%20D%20%3A%20%E2%84%95%20%E2%86%92%20%E2%84%9D)%20(hD%20%3A%20%E2%88%80%20k%2C%20a%20k%20%E2%89%A4%20D%20k%20-%20D%20(k%2B1))%20(hpos%3A%20%E2%88%80%20k%2C%200%20%E2%89%A4%20D%20k)%20(ha%20%3A%20Antitone%20a)%20(k%20%3A%20%E2%84%95)%20%3A%20a%20k%20%E2%89%A4%20D%200%20%2F%20(k%20%2B%201)%20%3A%3D%20calc%0D%0A%20%20a%20k%20%3D%20(%E2%88%91%20_i%20in%20range%20(k%2B1)%2C%20a%20k)%20%2F%20(k%2B1)%20%3A%3D%20by%20simp%3B%20field_simp%3B%20ring%0D%0A%20%20_%20%E2%89%A4%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20(D%20i%20-%20D%20(i%2B1)))%20%2F%20(k%2B1)%20%3A%3D%20by%20gcongr%20with%20i%20hi%3B%20apply%20le_trans%20_%20(hD%20i)%3B%20apply%20ha%3B%20simp%20at%20hi%3B%20linarith%0D%0A%20%20_%20%E2%89%A4%20D%200%20%2F%20(k%2B1)%20%3A%3D%20by%20gcongr%3B%20rw%20%5Bsum_range_sub'%5D%3B%20linarith%20%5Bhpos%20(k%2B1)%5D")[#image("../assets/1cff6f87c020de8345ba31b8289ec9bc0c72fa8ca72a38a95c0a322b12150550-5855418c835f8a9f02dde9e54636facbc901d7ea6985810f62a30e1a88a4fb16.png", width: 90%)]
]

#text("With enough familiarity with the Lean language, this proof actually tracks quite closely with (an optimized version of) the human blueprint.")

#text("This concludes the tour of a lengthier Lean proving exercise. I am finding the pre-planning step of the proof (using an informal “blueprint” to break the proof down into extremely granular pieces) to make the formalization process significantly easier than in the past (when I often adopted a sequential process of writing one line of code at a time without first sketching out a skeleton of the argument). (The proof here took only about 15 minutes to create initially, although for this blog post I had to recreate it with screenshots and supporting links, which took significantly more time.) I believe that a realistic near-term goal for AI is to be able to fill in automatically a significant fraction of the sorts of atomic “")#raw("sorry")#text("“s of the size one saw in this proof, allowing one to convert a blueprint to a formal Lean proof even more rapidly.")

#text("One final remark: in this tour I filled in the “")#raw("sorry")#text("“s in the order in which they appeared, but there is actually no requirement that one does this, and once one has used a blueprint to atomize a proof into self-contained smaller pieces, one can fill them in in any order. Importantly for a group project, these micro-tasks can be parallelized, with different contributors claiming whichever “")#raw("sorry")#text("” they feel they are qualified to solve, and working independently of each other. (And, because Lean can automatically verify if their proof is correct, there is no need to have a pre-existing bond of trust with these contributors in order to accept their contributions.) Furthermore, because the specification of a “")#raw("sorry")#text("” someone can make a meaningful contribution to the proof by working on an extremely localized component of it without needing the mathematical expertise to understand the global argument. This is not particularly important in this simple case, where the entire lemma is not too hard to understand to a trained mathematician, but can become quite relevant for complex formalization projects.")

#heading(level: 1)[#text("Comments (42)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82e494cbb93604545c9a4905674939e942fe943e6102f1c972d6f4672e2857bb-af836d930689c7a8bf7d6376575f8a0e200c0e826d217f3b19db103860d0df48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wdjoyner")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682417")[#strong[#text("wdjoyner")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2023")])]

#text("Thank you for the interesting post but I think there’s a typo somewhere. After “I start by importing Lean’s math library, and starting an example of a statement to state and prove:” the display is blank.")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682418")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2023")])]

#text("Re: the twitter challenge from Damek Davis.")

#text("“You’re unable to view this Post because this account owner limits who can view their Posts. Learn more”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d63d41c9cf4d921d6ceef87c9b8d0d1f57254f648e0c2e785efad352a850e419-3771e98838d83e6eca535b731538af957220cec5537ec9d1f017f45ad85aca5d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dustin G. Mixon")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682419")[#strong[#text("Dustin G. Mixon")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2023")])]

#text("In the second display, the sum of a_i should be leq D_0.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682421")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2023")])]

#text("Isn’t it Sum a_i <= D_0 rather than =")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682429")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2023")])]

#text("All rhs have / (k + 1) in common. The proof would be simpler if we prove (k+1)a_k \\le D_0 first.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682440")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2023")])]

#text("This is certainly an option. Here is ")#link("https://live.lean-lang.org/#code=import%20Mathlib%0D%0A%0D%0Aopen%20Finset%20BigOperators%0D%0A%0D%0Aexample%20(a%20D%20%3A%20%E2%84%95%20%E2%86%92%20%E2%84%9D)%20(hD%20%3A%20%E2%88%80%20k%2C%20a%20k%20%E2%89%A4%20D%20k%20-%20D%20(k%2B1))%20(hpos%3A%20%E2%88%80%20k%2C%200%20%E2%89%A4%20D%20k)%20(ha%20%3A%20Antitone%20a)%20(k%20%3A%20%E2%84%95)%20%3A%20a%20k%20%E2%89%A4%20D%200%20%2F%20(k%20%2B%201)%20%3A%3D%20by%0D%0A%20%20rw%20%5Ble_div_iff'%20(by%20positivity)%5D%0D%0A%20%20calc%0D%0A%20%20%20%20(k%2B1)%20*%20a%20k%20%3D%20%E2%88%91%20_i%20in%20range%20(k%2B1)%2C%20a%20k%20%3A%3D%20by%20simp%0D%0A%20%20%20%20_%20%E2%89%A4%20(%E2%88%91%20i%20in%20range%20(k%2B1)%2C%20(D%20i%20-%20D%20(i%2B1)))%20%3A%3D%20by%20gcongr%20with%20i%20hi%3B%20apply%20le_trans%20_%20(hD%20i)%3B%20apply%20ha%3B%20simp%20at%20hi%3B%20linarith%0D%0A%20%20%20%20_%20%E2%89%A4%20D%200%20%3A%3D%20by%20rw%20%5Bsum_range_sub'%5D%3B%20linarith%20%5Bhpos%20(k%2B1)%5D")[#text("one arrangement of the proof")]#text(" that follows that strategy; there is one “rewrite” inserted at the beginning, and an number of `congr` and `gcongr` steps that were used to remove the denominator are removed. I think it is roughly the same length and complexity in the end.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682430")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2023")])]

#text("That’s fascinating Terry. What do you see as the value of golfing the code? As someone with a background in commercial programming, I’m used to trying to make code as clear and simple as possible. To my eyes, the golfed code is significantly harder to read. But I’m not a mathematician, so I may well lack the right perspective here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682439")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2023")])]

#text("From the mathematical side, I think it comes down to the principle of “giving appropriate amounts of detail”, which I write about ")#link("https://terrytao.wordpress.com/advice-on-writing-papers/give-appropriate-amounts-of-detail/")[#text("here")]#text(". Ideally, each step in a proof should be of the natural size that a mathematician would interpret as a significant step towards resolving the problem, and all steps should be broadly of similar size. The initial blueprint, breaking up the proof into six very tiny steps, satisfies the second property but not the first in my opinion, whereas the golfed version containing three steps is a bit more consonant with the high-level description of the proof rather than the low-level one.")

#text("For large projects (and particularly for contributing to Mathlib, the largest project of all), code is often “golf”ed not so much for brevity as for compilation speed. Powerful and intuitive tactics such as `simp` that perform an extensive search as part of their execution are often replaced with much more explicit `low level` tactics that are much faster but also harder to read. (There is a tactic called `simp?` which runs `simp` but then prints the specific simp lemmas used, which can then be used for this sort of compilation golf.) Perhaps this practice also influences the default aesthetic that the Lean formalization community has regarding how to write proofs, in that they tend to favor compactified arguments over long discursive ones in their Lean code. I like the Blueprint model in which LaTeX is used to describe the human readable version of the proof, while Lean focuses on its strength, which is to describe the machine readable version, but there are links between the two.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-688343")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2025")])]

#text("Hmmm I tend to disagree with the first argument regarding the step size that a mathematician would interpret as significant since different levels of education and even just different levels of expertise among specialists tend to have a relatively different needs of detail and what would imply “good size” here. From the point of view of automation I think the optimal way forward is to have Lean provide various levels of detail according to each reader’s needs – from overviews for someone who is experienced in the particular field to more granular approach for someone who is not. I guess the “?” versions are a step in this direction already and we are not quite there but at the very least here we can conclude that the “level of golfing” correlates with the reader’s experience in the given set of arguments.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682441")[#strong[#text("A slightly longer Lean 4 proof tour – Cyber Geeks Global")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2023")]

#text("[…] Comments…Read More […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/618cf1f04f8a18eecb1f10f266821e7393feeb97598d32289f48ad8030cb9938-cfc0ce0b3d592e30da34d56ba5b8e4e05f67604304a8cea7731d51a12818b5ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682442")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2023")])]

#text("A thing I find off-putting about attempting to look at anything in Lean is the use of whacky 1970s-era computer language naming. Especially so with arbitrary and inconsistent abbreviations (abrvs, abbrevs, abs?) but also finSetSummand_unKnown_why_dothis.")#linebreak()#text(" “congr” WTF?")

#text("It’s especially difficult to navigate this salad of capitalization and arbitrary punctuation and runtgethrwds if one’s native language is not English. linear_arithmetic (better, linear-arithmetic, because normal English used by normal humans uses hypthens to join compound words) vs “linarith” or “linArith”, or God save us, “Linarith”, not only means a hell of a lot more to a casual reader, but makes it even possible for English non-adepts to *begin* to understand what’s going on, using the full words they already know because they’re actually in use in actual mathematics, aided by looking up normal words in normal dictionaries. (Yes, “linarith” is easy, but lots of other stuff, pretty much anything beyond this, really is not.)")

#text("I get that C programmers in 1970 were very concerned about every byte that the programs took up, and that naming somethign “inj” instead of “injective-functor” would save a lot of repetitive typing in the very primitive text editors of the time, but this hasn’t been the case for 40 years now … and yet computer-ese gibberish refuses to die.")

#text("I do understand that Lean itself wasn’t expressly designed for mathematics per se.")#linebreak()#text(" I get that it’s written by (and incredibly generously shared by) people completely steeped in decades of unpleasant computer language conventions. Do fish have a word for water?")#linebreak()#text(" I keep reading that Lean proofs “aren’t meant to be read” (because having computer programs, which is what Lean proofs are, be impenetrable, even at a superficial skimming level, is somehow a good thing.) But “proofs not mean to be read” are exactly what is exposed every time somebody new tries to even casually look at this formalization business.")

#text("In the end, there’s so much ancient computer programming language-ese exposed and inflicted; it’s off-putting. Trauma inflicted on each generation of computer programmers by the their preDecssrs is now inflicted more widely.")

#text("It’s truly nice that one can use finally use characters like “≺” and “⋂” and “⨂” in the future in 2023. But the “words” formed by run-together roman letters in between these familar, comprehensible operators? Oof.")

#text("Couldn’t Math_lib_hvDoneBetr? For mathematicians? It’s a tough tough slog.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682445")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2023")])]

#text("Mathlib’s naming conventions are laid out in this ")#link("https://leanprover-community.github.io/contribute/naming.html")[#text("web page")]#text(". One rationale for such conventions is to be able to quickly recognize whether a given term refers to a proposition, type, variable, or tactic (much as how in English, Capitalization is used to indicate Proper Nouns, ALLCAPS is used to indicate acronyms and initialisms, periods are used to indicate abbreviations (e.g., abbrev., etc.), ")#emph[#text("italics")]#text(" are used to denote foreign words that are used ")#emph[#text("verbatim")]#text(", and so forth). Another key motivation for encouraging a rather formal naming system here is to make it easier to find specific Mathlib routines that achieve specific tasks. For instance, to find the lemma that establishes the telescoping series formula ")#mi("\\sum_{i=0}^n f(i) - f(i+1) = f(0) - f(n+1)")#text(", I knew from the naming conventions that the formula name should probably involve `Finset`, `sum`, `sub`, and possibly also `range` or `eq`, and indeed by entering these terms into a Mathlib search engine one can readily locate `")#link("https://leanprover-community.github.io/mathlib4_docs/Mathlib/Algebra/BigOperators/Basic.html#Finset.sum_range_sub'")[#text("Finset.sum_range_sub")]#text("‘` which establishes precisely this fact. Naming this fact `telescoping_series_identity` or `Lemma 3.1.4.7` would make it more difficult to reliably locate the tool. (Though in a few years this issue may become moot, as AI-powered semantic search engines become more powerful, as well as AI-powered ways to convert Lean code into human-readable proofs.)")

#text("For personal Lean projects one can always introduce one’s own personal abbreviations to replace the default names given by Mathlib of course, much as one can add a personal set of macros to replace LaTeX’s default names for various mathematical symbols with names that one personally prefers.")

#text("Also, `congr` is an abbreviation of “congruence” (and `gcongr` is an abbreviation for “generalized congruence”). Hyphens can’t be used in a mathematical language as they are already reserved for subtraction: `linear-arithmetic` would be interpreted as the difference of `linear` and `arithmetic`.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682447")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2023")])]

#text("Thank you for making this post (all the screenshots and special Lean style must take a lot of time).")

#text("One quick question: is Lean able to look at a proof, and say, oh this proposition always works for other fields (instead of reals). Well, not very useful in this case, but hypothetically. Humans can probably spot it easily, but I wonder if you’ve had the experience that you have missed a trivial extension which was “pointed out” by Lean. Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682450")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2023")])]

#text("Well, Lean’s compiler has a “linter” that points out if a variable or hypothesis in the proposition was never actually used in the proof, so that is one simple way in which trivial extensions can be spotted. Another experience I have had is that sometimes, after a proposition has been proven, someone in the project realizes that in order to apply the proposition neatly in some other part of the project, one has to slightly modify a hypothesis in one of the proposition. Often one can just modify that hypothesis and watch what the compiler does. A surprisingly large fraction of the proof often still compiles under minor modifications, especially if the proof has not been prematurely optimized and one still uses broad tactics such as `simp` or `linarith` that don’t require precisely specifying all the steps, but instead lets the compiler automatically locate the hypotheses, parameters, and methods needed to resolve the problem. Generally the compiler will only throw a handful of errors under a minor modification, which can then be dealt with by hand (and the process may recurse for a few iterations, because of steps after the first error that the initial compiler run did not even reach), but with well-designed proofs, the process of modifying a proposition is often substantially easier than writing a proof from scratch. (Indeed it is this aspect of formalization where I think we really have a chance in the future of being in a situation where the task is *faster* to perform in a formal framework than in traditional pen-and-paper (and LaTeX) framework.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682451")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2023")])]

#text("Does it?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85fec62161e04c2ae3b028b5eccf6ff083ede62b26d23968a23e4789869f23bf-0ca208eb6faafa70367604d809ad364a6359d20b904df7c950b7bf3d3c2fa5b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony Carbery")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682453")[#strong[#text("Tony Carbery")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2023")])]

#text("At the risk of introducing a red herring to the conversation, I’d be interested if there were a Lean-type proof of the following free-standing inequality involving non-negative real numbers (or alternatively non-negative integers). We have three sequences ")#mi("a_j, b_j, c_j")#text(" (indexed by non-negative integers ")#mi("j")#text(") and one sequence ")#mi("K(i,j,k)")#text(" (indexed by triples of non-negative integers). The inequality is")

#mi("\\displaystyle \\left(\\sum K(i,j,k) a_i b_j c_k\\right)^4 \\leq A (\\sum a_i^4)   (\\sum b_j^4) (\\sum c_k^4)")

#text("where the sums are over all relevant indices, and where the quantity ")#mi("A")#text(" is given by")

#mi("\\displaystyle \\sum K(s_1, j_1, k_1)K(s_1, s_2, k_2)K(x_3, s_2, s_3) K(x_4, y_4,s_3)")

#text("where the sum is over all visible indices. (The last expression is more readily visualised by writing the four terms in a vertical stack: we contract the indices 1 and 2, in the first column, indices 2 and 3 in the second column and indices 3 and 4 in the third column. This picture makes it apparent that the inequality in question is simply the case ")#mi("n=3")#text(" of a more general family of inequalities, the case ")#mi("n=1")#text(" of such is the Cauchy–Schwarz inequality.)")

#text("I realise this question looks really artificial and horribly technical, but I’ve not been able to find a simpler model which raises the same issues.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682457")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2023")])]

#text("This is an interesting inequality – a variant of the Blakely-Roy inequality? At its current stage of development, Lean isn’t really capable of coming up with proofs on its own unless there is already a human-readable proof available already (or if a *very* short proof is available). Do you have such a human-readable proof? If so, I can take a stab at trying to formalize it. I’m guessing that the tensor power trick argument that Nets and I used to prove Lemma 2.1 of ")#link("https://arxiv.org/pdf/math/9906097.pdf")[#text("https://arxiv.org/pdf/math/9906097.pdf")]#text(" may give a proof that is not too difficult to formalize in Lean (which has no essential difficulty dealing with real analysis techniques such as the passage to a limit arising in the tensor power trick), but first (as in this post) one would have to write a human-readable proof first.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682460")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2023")])]

#text("Yes, indeed, this inequality was inspired by your paper with Nets that you mention, and can indeed be proved by the tensor power trick. I was always intrigued that I couldn’t prove it “by hand” even when restricting the inputs to range over finite collections — even in this finitistic setting a limiting argument seemed to be needed. (I was hoping that a computer would one day prove it for me without recourse to limiting arguments, and, if I’m honest, that was my real motivation in asking the question here.) The human-readable proof is available at \\url{https://www.ams.org/journals/proc/2004-132-11/S0002-9939-04-07565-3/?active=current}. Thanks for the heads up on Blakely-Roy, which I was sadly unaware of.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682462")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2023")])]

#text("Ah, I remember this paper now. One could translate that paper step by step into Lean, but it would be rather time-consuming and not all that edifying. Lean is a formal proof assistant rather than an automatic theorem prover; it can formalize existing proofs, but at the current state of development it is not all that useful in discovering new proofs.")

#text("On the other hand, I believe one can interpret your proof through the lens of entropy inequalities, and in particular through the Legendre-Fenchel formula")

#mi("\\displaystyle \\log \\sum_{x \\in S} e^{f(x)} = \\sup_X {\\bf E} f(X) + {\\bf H}[X]")

#text("for any finite set ")#mi("S")#text(" and any function ")#mi("f: S \\to {\\bf R}")#text(", where the supremum is over all ")#mi("S")#text("-valued random variables and ")#mi("{\\bf H}[X] = \\sum_{s \\in S} {\\bf P}[X=s] \\log \\frac{1}{{\\bf P}[X=s]}")#text(" is the Shannon entropy of ")#mi("X")#text(". (This formula is perhaps more familiar to you as the duality relation between the Orlicz spaces ")#mi("e^L")#text(" and ")#mi("L \\log L")#text(".) It is then possible to prove your inequality from the Shannon entropy inequalities, without explicit use of the tensor power trick. I’ll write this up in a separate blog post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/097a4d5133f182db0e69d4c8b545f1e04ffe71834194bb0c5514993838312913-be24c73e8383858c44fd3f54eca00b77b675548c40c6fb0e21384600734295e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YahyaAA1")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682606")[#strong[#text("YahyaAA1")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2023")])]

#text("Terry, it’s instructive to see how you’re evolving better strategies for working with this new(ish) proof assistant tool:")

#text("‘I am finding the pre-planning step of the proof (using an informal “blueprint” to break the proof down into extremely granular pieces) to make the formalization process significantly easier than in the past (when I often adopted a sequential process of writing one line of code at a time without first sketching out a skeleton of the argument).’")

#text("You talk of using LEAN’s “tactics”. Do you think it will soon also have “strategies”, at a higher hierarchical level, perhaps as “macros” of its tactics? And that would let us “blueprint” the proof at such a level?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682619")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2023")])]

#text("Certainly there is work in this direction, particuarly using AI tools either in a “bottom up” fashion to develop smarter “meta-tactics” that can solve in one shot problems that currently require several lines of Lean code, or in a “top down” fashion to try to break up a long argument into smaller chunks that could then be converted to a blueprint type format. See for instance “")#link("https://www.youtube.com/watch?v=CEwRMT0GpKo&ab_channel=leanprovercommunity")[#text("Sagredo")]#text("” or “")#text("LeanDojo")#text("” for some current experiments in the former direction. There is also the recent “")#link("https://github.com/google-deepmind/funsearch")[#text("FunSearch")]#text("” proof of concept which gained some attention in the popular media, which perhaps is closer to the “automatic strategy generation” approach you were suggesting.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682692")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2024")])]

#strong[#text("How is the set of natural numbers defined in Lean4?")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682693")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2024")])]

#text("For all ")#mi("x\\in N")#text(",")#linebreak()#text(" ")#mi("\\displaystyle (x+1)^2=x^2+2x+1")

#text("Also, for all ")#mi("x\\in Z")#text(", ")#mi("\\displaystyle (x+1)^2=x^2+2x+1")

#text("Are both provable in Lean 3 & 4?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682698")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2024")])]

#text("Sure, they are both easily provable by Lean’s `ring` tactic, see ")#link("https://live.lean-lang.org/#code=import%20Mathlib%0D%0A%0D%0Aexample%20(n%3A%E2%84%95)%20%3A%20(n%2B1)%5E2%20%3D%20n%5E2%20%2B%202*n%20%2B%201%20%3A%3D%20by%20ring%0D%0A%0D%0Aexample%20(n%3A%E2%84%A4)%20%3A%20(n%2B1)%5E2%20%3D%20n%5E2%20%2B%202*n%20%2B%201%20%3A%3D%20by%20ring%0D%0A")[#text("here")]#text(". The ")#link("https://leanprover-community.github.io/mathlib4_docs/Init/Prelude.html#Nat")[#text("natural numbers are defined in Lean")]#text(" as an inductive type `Nat` (or ℕ): roughly speaking, a natural number is either zero, or a successor of a natural number, and these are the only ways to produce natural numbers. (This is slightly different from the orthodox ZFC construction of the natural numbers, but ends up being functionally equivalent in practice.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682706")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2024")])]

#text("Many thanks for a crystal clear answer, more on the type theoretic foundation later. We are just now at the beginning of 2024.")

#text("For large mathematical objects, we have formalized so many kinds of objects in various proof assistants. In forseeable years, it seems that Coq, Lean, and Metamath will be ")#emph[#text("standard")]#text(" among formalized mathematics.")

#mi("\\displaystyle \\forall n\\in \\mathrm{N}.\\sum_{i=0}^{n}{n\\choose k}=2^n")

#text("How would we formalize the combinatorial proof of the above statement? Similarly, large formalization projects are struggling to do what everyday mathematicians can easily do: arithmetic topology.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682807")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2024")])]

#text("The combinatorial statement – that the powerset of a set of cardinality n decomposes as the disjoint union of the i-element subsets for ")#mi("i=0,\\dots,k")#text(" – is formalized in Lean ")#link("https://leanprover-community.github.io/mathlib4_docs/Mathlib/Data/Finset/Powerset.html#Finset.powerset_card_disjiUnion")[#text("here")]#text(", and it is not difficult to then conclude the binomial identity: see ")#link("https://live.lean-lang.org/#code=import%20Mathlib%0D%0A%0D%0Aopen%20BigOperators%20Finset%20Nat%0D%0A%0D%0Aexample%20(n%3A%E2%84%95)%20%3A%202%5En%20%3D%20%E2%88%91%20i%20in%20range%20(n%2B1)%2C%20choose%20n%20i%20%3A%3D%20by%0D%0A%20%20have%20%3A%3D%20congrArg%20card%20(powerset_card_disjiUnion%20(range%20n))%0D%0A%20%20simp_rw%20%5Bcard_disjiUnion%2C%20card_powerset%2C%20card_powersetCard%2C%20card_range%5D%20at%20this%0D%0A%20%20exact%20this")[#text("here")]#text(". (This identity is also implemented ")#link("https://leanprover-community.github.io/mathlib4_docs/Mathlib/Data/Nat/Choose/Sum.html#Nat.sum_range_choose")[#text("here")]#text(".)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682694")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2024")])]

#mi("\\mathsf{N}")#text(" is not a type.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682839")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2024")])]

#text("The Goldbach conjecture is true becase the fractional remainders after deductions of 2/P where P= prime less than sqrt:x always end leaving may primes, short, simple absolute with a clear example demonstrating just how impossible it is not to be true.")#linebreak()#text(" Every even number x is always the sum of 2 prime numbers because with every increase in value of x (always 2 integers more than the last) then all odd numbers below x/2 move one further away from x/2 and all above x/2 move one closer, so the odd numbers always pair with another odd number. So if one odd number a distance k below x/2 is a multiple of a Prime (Pn) then we can rule out it and the number a distance k above x/2 as being a prime pair. So by eliminating all multiples of P<√x we can figure out how many primes will be left over and these must pair, add together to equal x. We do this by dividing x by 2 to get the number of odd numbers below x then subtract 2 by all multiples of primes <√x which is any remaining number divided by 2/P where P is the next higher prime eg:")#linebreak()#text(" There are always more primes left over below and above x/2 after such pairings have been eliminated (as demonstrated in this example below where x=10,004 which is illustrative for all values of x) so those primes remaining must be prime pairs. So the Goldbach conjecture is definitely true.")

#text("To demonstrate that with an example let's look at a number with no prime factors to get the least possible number of possible prime pairs")#linebreak()#text(" X=10,004/2=5000")#linebreak()#text(" 5000×2/3=333.33333")#linebreak()#text(" 333.33333×2/5=2,666.6666")#linebreak()#text(" 2,666.6666×2/7=1904.76184")#linebreak()#text(" 1904.76184×2/11=346.32033 =")#linebreak()#text(" 1,558.44151-2/13=1318.6812776923 1,318.6812776923'-2/17=155.13897")#linebreak()#text(" 1,163.542303846-2/19=1,041.0641665991")#linebreak()#text(" 1,041.0641665991-2/23=950.5368477644")#linebreak()#text(" 950.5368477644-2/29=884.9825824058")#linebreak()#text(" 884.9825824058-2/31=827.8869319542")#linebreak()#text(" 827.8869319542-2/37=783.1362870353")#linebreak()#text(" 783.1362870353-2/41=744.934516936")#linebreak()#text(" 744.934516936-2/43=710.2863998692")#linebreak()#text(" 710.2863998692-2/47=680.0614466833")#linebreak()#text(" 680.0614466833-2/53=654.3998826575")#linebreak()#text(" 654.3998826575-2/59=632.2168357878")#linebreak()#text(" 632.2168357878-2/61=611.4884149423")#linebreak()#text(" 611.4884149423-2/67=593.2350294216")#linebreak()#text(" 593.2350294216-2/71=576.5241835224")#linebreak()#text(" 576.5241835224-2/73=560.7290004122")#linebreak()#text(" 560.7290004122-2/79=546.5333295157")#linebreak()#text(" 546.5333295157-2/83=533.363851696")#linebreak()#text(" 533.363851696-2/89=521.3781471635")#linebreak()#text(" 521.3781471635-2/97=510.6280822735")#linebreak()#text(" That's all primes <√x")#linebreak()#text(" Even if we were to include multiples of primes greater than <√x and even as the values of x go towards gazillions of gazillions of bazillions and beyond the figure will eventually converge to a percentage of x much higher than 2 for one Prime pair as the trend below demonstrates, note, primes above <√x are not relevant, I just include these to emphasise how impossible it is to not have prime pairs=x and the higher the value of x the greater the number of prime pairs will be left")#linebreak()#text(" 510.6280822735-2/101=500.5166350998")#linebreak()#text(" 500.5166350998-2/103=490.7978654862")#linebreak()#text(" 490.7978654862-2/107=481.624073608")#linebreak()#text(" 481.624073608-2/109=472.7869346427")#linebreak()#text(" 472.7869346427-2/113=464.419024295")#linebreak()#text(" 464.419024295-2/127=457.105338873")#linebreak()#text(" 457.105338873-2/131=450.1266314093")#linebreak()#text(" 450.1266314093-2/137=443.5554397099")#linebreak()#text(" 443.5554397099-2/139=437.1733470522")#linebreak()#text(" 437.1733470522-2/149=431.305248434")#linebreak()#text(" 431.305248434-2/151…..etc")

#text("This and my proof to the Collatz conjecture with voiceover for visually impaired are in a mathematical proof playlist on my youtube channel Sean A Gilligan maths & physics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83b40d31b9ec74d53235ab18a7c1ba30b32eba644c0755bffb34e4a69277b4d4-08287d57e5faa0325caa974b5dda55baa9cf165c3b7a5ea01b5e911f1c5a161d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lucyeinsteinbfca8f877e")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682840")[#strong[#text("lucyeinsteinbfca8f877e")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2024")])]

#text("Made an error in the previous comment and dont know how to delelete it sorry, of topic but homeless and unable to access the peer review system so puttng it here for obvious reasons. Thanks Terry")

#text("Fatigue is a killer! I made one error in this proof and it messed up all further numbers, here it is fixed. The proof to the Goldbach conjecture. Please take it with the level of seriousness it warrants and share.")

#text("The Goldbach conjecture is true, every even number x is always the sum of 2 prime numbers because with every increase in value of x (always 2 integers more than the last) then all odd numbers below x/2 move one further away from x/2 and all above x/2 move one closer, so the odd numbers always pair with another odd number. So if one odd number a distance k below x/2 is a multiple of a Prime (Pn) then we can rule out it and the number a distance k above x/2 as being a prime pair. So by eliminating all multiples of P<√x we can figure out how many primes will be left over and these must pair, add together to equal x. We do this by dividing x by 2 to get the number of odd numbers below x then subtract 2 by all multiples of primes <√x which is any remaining number divided by 2/P where P is the next higher prime eg:")#linebreak()#text(" There are always more primes left over below and above x/2 after such pairings have been eliminated (as demonstrated in this example below where x=10,004 which is illustrative for all values of x) so those primes remaining must be prime pairs. So the Goldbach conjecture is definitely true.")

#text("To demonstrate that with an example let's look at a number with no prime factors to get the least possible number of possible prime pairs")#linebreak()#text(" X=10,004/2=5002")#linebreak()#text(" 5002-2/3=5,002−((5,002)×(2/3)=")#linebreak()#text(" 1,667.3333333333-2/5=1000.4")#linebreak()#text(" 1000.4-2/7=714.5714285714")#linebreak()#text(" 714.5714285714-2/11=584.6493506493")#linebreak()#text(" 584.6493506493-2/13=494.7032967033")#linebreak()#text(" 494.7032967033-2/17=436.5029088559")#linebreak()#text(" 436.5029088559-2/19=390.5552342395")#linebreak()#text(" 390.5552342395-2/23=356.593909523")#linebreak()#text(" 356.593909523-2/29=332.0012261076")#linebreak()#text(" 332.0012261076-2/31=310.5817921652")#linebreak()#text(" 310.5817921652-2/37=293.7935871833")#linebreak()#text(" 293.7935871833-2/41=279.4621926866")#linebreak()#text(" 279.4621926866-2/43=266.4639511663")#linebreak()#text(" 266.4639511663-2/47=255.1250596273")#linebreak()#text(" 255.1250596273-2/53=245.4976988866")#linebreak()#text(" 245.4976988866-2/59=237.1757429921")#linebreak()#text(" 237.1757429921-2/61=229.3994891235")#linebreak()#text(" 229.3994891235-2/67=222.5517431795")#linebreak()#text(" 222.5517431795-2/71=216.2826799913")#linebreak()#text(" 216.2826799913-2/73=210.3571271148")#linebreak()#text(" 210.3571271148-2/79=205.0316302258")#linebreak()#text(" 205.0316302258-2/83=200.0911090155")#linebreak()#text(" 200.0911090155-2/89=195.5946795994")#linebreak()#text(" 195.5946795994-2/97=191.5617996077")#linebreak()#text(" That's less all multiples of primes <√x where x=10,004 not even allowing for some odds which are not primes to pair up, which they will and still we get a MINIMUM of around 95 prime pairs adding to x")#linebreak()#text(" Even if we were to include multiples of primes greater than <√x and even as the values of x go towards gazillions of gazillions of bazillions and beyond the figure will eventually converge to a percentage of x much higher than 2 for one Prime pair which further emphasises just how impossible it is to not have prime pairs adding to x.")

#text("This and my proof to the Collatz conjecture are also in short video format usually about 3 to 5 minutes, with voiceover for visually impaired in a mathematical proof playlist on my youtube channel Sean A Gilligan maths & physics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-682848")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2024")])]

#emph[#text("Claim")]#text(": Every infinite computably enumerable set has an infinite computable subset.")

#emph[#text("Proof")]#text(": Consider a computably enumerable set ")#mi("A\\subseteq\\Sigma^*")#text(" where ")#mi("\\Sigma=\\{0,1\\}")#text(". Define the following order in ")#mi("\\Sigma^*")#text(": for two strings ")#mi("a,b\\in\\Sigma^*")#text(", we say ")#mi("a<b")#text(" if either ")#tao-math("\\left|a\\right|<\\left|b\\right|", block: false)#text(" (where ")#tao-math("\\left|x\\right|", block: false)#text(" denotes the length of the string ")#mi("x")#text("), or ")#tao-math("\\left|a\\right|=\\left|b\\right|", block: false)#text(" and ")#mi("a<_\\mathrm{lex}b")#text(" (i.e. ")#mi("a")#text(" precedes ")#mi("b")#text(" in the usual lexicographic order).")

#text("So some computable enumerator of ")#mi("A")#text(" enumerates ")#mi("A")#text(" as a list: ")#mi("a_0,a_1,\\dots")#text(". Call an ")#mi("a_i")#text(" a ")#emph[#text("pioneer")]#text(" if either ")#mi("i=0")#text(" (well, the very first one is always a pioneer), or ")#mi("i>0")#text(" and ")#mi("\\forall j<i(a_j<a_i)")#text(" (")#mi("a_i")#text(" beats all the so-far-enumerated ones). Let ")#mi("S=\\{a_i\\in A|a_i\\ \\mathrm{is\\ a\\ pioneer}\\}")#text(". Clearly, ")#mi("S\\subseteq A")#text(".")

#mi("S")#text(" is computable by the following machine. On an input string ")#mi("x\\in\\Sigma^*")#text(", this machine just runs the enumerator of ")#mi("A")#text(". Each time the enumerator appends a string ")#mi("a_i")#text(" for ")#mi("i>=0")#text(" to the list of so-far-printed-out strings, our machine ")#emph[#text("pauses")]#text(" the enumerator to check if the last-appended string is a ")#emph[#text("pioneer")]#text(" or not. If ")#mi("a_i")#text(" is not a pioneer, our machine resumes the enumerator. If ")#mi("a_i")#text(" is a ")#emph[#text("pioneer")]#text(", our machine compares ")#mi("x")#text(" and ")#mi("a_i")#text(": if ")#mi("x=a_i")#text(", ")#strong[#text("Accept")]#text(" and halt; otherwise, if ")#mi("x>a_i")#text(" (so there’s still hope) resume the enumerator, if not, i.e. ")#mi("x<a_i")#text(", well the latest pioneer just goes further than ")#mi("x")#text(", hopeless, ")#strong[#text("Reject")]#text(" and halt.")

#text("Note that the subsequence of pioneers is strictly increasing. Eventually, the latest pioneer must be greater than ")#mi("x")#text(". So, ")#mi("x")#text(" is accepted if and only if it is a pioneer at some time in the timeline. For us, ")#mi("S")#text(" is computable.")

#emph[#text("Strictly mathematically put, we should call an index ")#mi("i")#text(" a ")]#emph[#text("pioneer index")]#text(" instead of ")#mi("a_i")#text(", but for an easy-to-understand manner, we did it as above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-684425")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2024")])]

#text("Hey Tao, just wanted to say your post has inspired me to learn Lean and I am loving it. Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-684736")[#strong[#text("Theorem Proving using Machine Learning – Lean 4 – A Guide To Mathematical Studies")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2024")]

#text("[…] Formalizing the proof of PFR in Lean4 using Blueprint: a short tour A slightly longer Lean 4 proof tour […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-685573")[#strong[#text("How the Lean language brings math to coding and coding to math - Rockstary Reviews")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2024")]

#text("[…] feature for both the mathematical and software verification communities because it eliminates the trust bottleneck. It doesn’t matter who you are; if Lean checked your proof, the whole world can build on top […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-685594")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2024")])]

#link("https://pubs.rsc.org/en/content/articlelanding/2024/dd/d3dd00077j")[#text("https://pubs.rsc.org/en/content/articlelanding/2024/dd/d3dd00077j")]

#text("Formalizing chemical physics using the Lean theorem prover")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-685698")[#strong[#text("How the Lean language brings math to coding and coding to math | My Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2024")]

#text("[…] feature for both the mathematical and software verification communities because it eliminates the trust bottleneck. It doesn’t matter who you are; if Lean checked your proof, the whole world can build on top […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-685753")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2024")])]

#text("Hi Terry,")

#text("Since I read this post, I have been meaning to ask you this: do you have any experience with the Isabelle/HOL theorem prover?")

#text("I ask because when I read your closing remarks about how AI may one day be able to close these small gaps in formal proofs, I thought to myself that Isabelle/HOL’s existing Sledgehammer tool should easily be able to tackle these gaps. And indeed, I recreated this problem in Isabelle/HOL, and found that Sledgehammer had no trouble automatically proving every step in the chain of inequalities that you laid out.")

#text("If you are interested in the current state of automatic formalization, you should play around with Isabelle/HOL and try out its Sledgehammer tool on problems like this.")

#text("While I’m sure Lean’s automation will catch up to Sledgehammer, I believe Sledgehammer is still the best automation tool currently available.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-685755")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2024")])]

#text("I also meant to add: I have really been enjoying reading about your experiences in Lean, and I would love to hear your thoughts on how various theorem provers compare (e.g. Isabelle/HOL vs. Lean).")

#text("(P.S., I may have accidentally double-posted my original comment; sorry).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ecb92b026e493b32269b85548d0ffa90ae37a3a35ee1b312d05549fddb52c258-e2ac8b29af791dc72f363ba3cc486eb11011cc303164f5e3b3e7dfb0f6b652a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of masharpe")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-686035")[#strong[#text("masharpe")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2024")])]

#text("Thanks, this was very helpful to me for learning idiomatic usage of mathlib4.")

#text("Another point where I’d be curious to learn from expert experience is regarding how to formulate definitions well. There seem to be subtly different options for how to do it, and the choice impacts all statements and proofs that depend on the definition, so it seems important to get right.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ecb92b026e493b32269b85548d0ffa90ae37a3a35ee1b312d05549fddb52c258-e2ac8b29af791dc72f363ba3cc486eb11011cc303164f5e3b3e7dfb0f6b652a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of masharpe")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-686274")[#strong[#text("masharpe")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2024")])]

#text("I also found it interesting that you reformulated the proof as an “informal blueprint” first before attempting the full formalization. It’s similar the use of pseudocode for programming, in that it’s more explicit than needed for communicating the key ideas to a human yet omits details of the target programming environment (here, Lean and mathlib). I’d imagine that the same pseudoformalization might serve as a suitable starting point for a formalization in most other formal proof systems, too.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-694070")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2026")])]

#text("“gcongr with i hi” doesn’t work anymore. I get the error “Unknown identifier `i`” .")#linebreak()#text("I use Lean version 4.32.1 .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-694079")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2026")])]

#text("Lean’s library of tactics, syntax, and methods have undergone various tweaks in the last three years. There is insufficient information provided to diagnose your specific problem, but you can try pasting your code into a modern LLM who may be able to suggest the new syntax that typechecks. (I find using a coding agent integrated into one’s IDE to be particularly convenient for such a task as it can run the typechecker automatically, but even a chatbot interface should be able to carry out this task with good accuracy nowadays.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f48342f93dda36002146ae14f58579afc04be1294ec2cc72b144ec26598af5a-4d8c50dfc9912be5e8a34e9326d69c8b13d873ef69639fcf5f5af7cec502c7b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of powerful020b56fc4e")]], [#link("https://terrytao.wordpress.com/2023/12/05/a-slightly-longer-lean-4-proof-tour/#comment-694095")[#strong[#text("powerful020b56fc4e")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2026")])]

#text("This code works :")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("import Mathlib.Data.Real.Basic")

#text("import Mathlib.Data.Finset.Basic")

#text("import Mathlib.Algebra.BigOperators.Intervals")

#text("import Mathlib.Algebra.Order.BigOperators.Group.Finset")

#text("import Mathlib.Tactic.FieldSimp")

#text("import Mathlib.Tactic.Linarith")

#text("import Mathlib.Tactic.GCongr")

#text("open Finset BigOperators")

#text("example (a D : ℕ → ℝ) (hD : ∀ k, a k ≤ D k – D (k + 1)) (hpos : ∀ k, 0 ≤ D k)")

#text("(ha : Antitone a) (k : ℕ) : a k ≤ D 0 / (k + 1) :=")

#text("calc")

#text("a k = (∑ _i ∈ range (k+1), a k) / (k+1) := by simp ; field_simp")

#text("_ ≤ (∑ i ∈ range (k+1), (D i – D (i+1))) / (k+1) := by")

#text("apply div_le_div_of_nonneg_right _ (by positivity)")

#text("exact sum_le_sum fun i hi => (ha (by simpa using hi)).trans (hD i)")

#text("_ ≤ D 0 / (k+1) := by gcongr; rw [sum_range_sub’]; linarith [hpos (k+1)]")
]
]
]
]
