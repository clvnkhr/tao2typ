// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/
// Converted to Typst by tao2typ: "2026-10-14T07:14:32.575086+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Quantum mechanics and Tomb Raider", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Quantum mechanics and Tomb Raider")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 February 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/")[#text("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("This post is derived from an interesting conversation I had several years ago with my friend Jason Newquist on trying to find some intuitive analogies for the non-classical nature of quantum mechanics. It occurred to me that this type of informal, rambling discussion might actually be rather suited to the blog medium, so here goes nothing…")

#text("Quantum mechanics has a number of weird consequences, but here we are focusing on three (inter-related) ones:")

#enum(start: 1, 
[#text("Objects can behave both like particles (with definite position and a continuum of states) and waves (with indefinite position and (in confined situations) quantised states);")],
[#text("The equations that govern quantum mechanics are deterministic, but the ")#link("http://en.wikipedia.org/wiki/Copenhagen_interpretation")[#text("standard interpretation of the solutions ")]#text("of these equations is probabilistic; and")],
[#text("If instead one ")#link("http://en.wikipedia.org/wiki/Many-worlds_interpretation")[#text("applies the laws of quantum mechanics literally")]#text(" at the macroscopic scale, then the universe itself must split into the superposition of many distinct “worlds”.")]
)

#text("In trying to come up with a classical conceptual model in which to capture these non-classical phenomena, we eventually hit upon using the idea of using computer games as an analogy. The exact choice of game is not terribly important, but let us pick ")#link("http://en.wikipedia.org/wiki/Tomb_Raider")[#text("Tomb Raider")]#text(" – a popular game from about ten years ago (back when I had the leisure to play these things), in which the heroine, ")#link("http://en.wikipedia.org/wiki/Lara_Croft")[#text("Lara Croft")]#text(", explores various tombs and dungeons, solving puzzles and dodging traps, in order to achieve some objective. It is quite common for Lara to die in the game, for instance by failing to evade one of the traps. (I should warn that this analogy will be rather violent on certain computer-generated characters.)")

#metadata(none) <tao-d04932dfc4fba99b3570>#linebreak()#text(" The thing about such games is that there is an “internal universe”, in which Lara interacts with other game elements, and occasionally is killed by them, and an “external universe”, where the computer or console running the game, together with the human who is playing the game, resides. While the game is running, these two universes run more or less in parallel; but there are certain operations, notably the “save game” and “restore game” features, which disrupt this relationship. These operations are utterly mundane to people like us who reside in the external universe, but it is an interesting thought experiment (which ")#link("http://www.theonion.com/content/node/28288")[#text("others have also proposed")]#text(" :-) ) to view them from the perspective of someone like Lara, in the internal universe. (I will eventually try to connect this with quantum mechanics, but please be patient for now.) Of course, for this we will need to presume that the Tomb Raider game is so advanced that Lara has levels of self-awareness and artificial intelligence which are comparable to our own.")

#text("Imagine first that Lara is about to navigate a tricky rolling boulder puzzle, when she hears a distant rumbling sound – the sound of her player saving her game to disk. Let us suppose that what happens next (from the perspective of the player) is the following: Lara navigates the boulder puzzle but fails, being killed in the process; then the player restores the game from the save point and then Lara successfully makes it through the boulder puzzle.")

#text("Now, how does the situation look from Lara’s point of view? At the save point, Lara’s reality diverges into a superposition of two non-interacting paths, one in which she dies in the boulder puzzle, and one in which she lives. (Yes, ")#link("http://en.wikipedia.org/wiki/Schr%C3%B6dinger%27s_cat")[#text("just like that cat")]#text(".) Her future becomes indeterministic. If she had consulted with an infinitely prescient oracle before reaching the save point as to whether she would survive the boulder puzzle, the only truthful answer this oracle could give is “50% yes, and 50% no”.")

#text("This simple example shows that the internal game universe can become indeterministic, even though the external one might be utterly deterministic. However, this example does not fully capture the weirdness of quantum mechanics, because in each one of the two alternate states Lara could find herself in (surviving the puzzle or being killed by it), she does not experience any effects from the other state at all, and could reasonably assume that she lives in a classical, deterministic universe.")

#text("So, let’s make the game a bit more interesting. Let us assume that every time Lara dies, she leaves behind a corpse in that location for future incarnations of Lara to encounter. (This type of feature was actually present in ")#link("http://en.wikipedia.org/wiki/Nethack")[#text("another game I used to play")]#text(", back in the day.) Then Lara will start noticing the following phenomenon (assuming she survives at all): whenever she navigates any particularly tricky puzzle, she usually encounters a number of corpses which look uncannily like herself. This disturbing phenomenon is difficult to explain to Lara using a purely classical deterministic model of reality; the simplest (and truest) explanation that one can give her is a “many-worlds” interpretation of reality, and that the various possible states of Lara’s existence have some partial interaction with each other. Another valid (and largely equivalent) explanation would be that every time Lara passes a save point to navigate some tricky puzzle, Lara’s “particle-like” existence splits into a “wave-like” superposition of Lara-states, which then evolves in a complicated way until the puzzle is resolved one way or the other, at which point Lara’s wave function “collapses” in a non-deterministic fashion back to a particle-like state (which is either entirely alive or entirely dead).")

#text("Now, in the real world, it is only microscopic objects such as electrons which seem to exhibit this quantum behaviour; macroscopic objects, such as you and I, do not directly experience the kind of phenomena that Lara does and we cannot interview individual electrons to find out their stories either. Nevertheless, by studying the statistical behaviour of large numbers of microscopic objects we can indirectly infer their quantum nature via experiment and theoretical reasoning. Let us again use the Tomb Raider analogy to illustrate this. Suppose now that Tomb Raider does not only have Lara as the main heroine, but in fact has a large number of playable characters, who explore a large number deadly tombs, often with fatal effect (and thus leading to multiple game restores). Let us suppose that inside this game universe there is also a scientist (let’s call her ")#link("http://en.wikipedia.org/wiki/Jacqueline_Natla")[#text("Jacqueline")]#text(") who studies the behaviour of these adventurers going through the tombs, but does not experience the tombs directly, nor does she actually communicate with any of these adventurers. Each tomb is explored by only one adventurer; regardless of whether she lives or dies, the tomb is considered “used up”.")

#text("Jacqueline observes several types of trapped tombs in her world, and gathers data as to how likely an adventurer is to survive any given type of tomb. She learns that each type of tomb has a fixed survival rate – e.g. a tomb of type A has a 20% survival rate, while a tomb of type B has a 50% survival rate – but that it seems impossible to predict with any certainty whether any given adventurer will survive any given type of tomb. So far, this is something which could be explained classically; each tomb may have a certain number of lethal traps in them, and whether an adventurer survives these traps or not may entirely be due to random chance.")

#text("But then Jacqueline encounters a mysterious “quantisation” phenomenon: the survival rate for various tombs are always one of the following numbers:")

#align(center)[#mi("100\\%, 50\\%, 33.3\\ldots\\%, 25\\%, 20\\%, \\ldots")#text(";")]

#text("in other words, the “frequency” of success for a tomb is always of the form 1/n for some integer n. This phenomenon would be difficult to explain in a classical universe, since the effects of random chance should be able to produce a continuum of survival probabilities.")

#text("Here’s what is going on. In order for Lara (say) to survive a tomb of a given type, she needs to stack together a certain number of corpses together to reach a certain switch; if she cannot attain that level of “constructive interference” to reach that switch, she dies. The type of tomb determines exactly how many corpses are needed – suppose for instance that a tomb of type A requires four corpses to be stacked together. Then the player who is playing Lara will have to let her die four times before she can successfully get through the tomb; and so from her perspective, Lara’s chances of survival are only 20%. In each possible state of the game universe, there is only one Lara which goes into the tomb, who either lives or dies; but her survival rate here is what it is because of her interaction with other states of Lara (which Jacqueline cannot see directly, as she does not actually enter the tomb).")

#text("A familiar example of this type of quantum effect is the fact that each atom (e.g. sodium or neon) can only emit certain wavelengths of light (which end up being quantised somewhat analogously to the survival probabilities above); for instance, sodium only emits yellow light, neon emits blue, and so forth. The electrons in such atoms, in order to emit such light, are in some sense clambering over skeletons of themselves to do so; the more commonly given explanation is that the electron is behaving like a wave within the confines of an atom, and thus can only oscillate at certain frequencies (similarly to how a plucked string of a musical instrument can only exhibit a certain set of wavelengths, which incidentally are also proportional to 1/n for integer n). Mathematically, this “quantisation” of frequency can be computed using the bound states of a ")#link("http://en.wikipedia.org/wiki/Schr%C3%B6dinger_equation")[#text("Schrödinger operator with potential")]#text(". (Now, I am ")#emph[#text("not")]#text(" going to try to stretch the Tomb Raider analogy so far as to try to model the Schrödinger equation! In particular, the complex phase of the wave function – which is a fundamental feature of quantum mechanics – is not easy at all to motivate in a classical setting, despite ")#link("http://en.wikipedia.org/wiki/Bohm_interpretation")[#text("some brave attempts")]#text(".)")

#text("The last thing we’ll try to get the Tomb Raider analogy to explain is why microscopic objects (such as electrons) experience quantum effects, but macroscopic ones (or even mesoscopic ones, such as large molecues) seemingly do not. Let’s assume that Tomb Raider is now a two-player co-operative game, with two players playing two characters (let’s call them Lara and ")#link("http://en.wikipedia.org/wiki/Indiana_Jones")[#text("Indiana")]#text(") as they simultaneously explore different parts of their world (e.g. via a ")#link("http://en.wikipedia.org/wiki/Split_screen_%28computer_graphics%29")[#text("split-screen display")]#text("). The players can choose to save the entire game, and then restore back to that point; this resets both Lara and Indiana back to the state they were in at that save point.")

#text("Now, this game still has the strange feature of corpses of Lara and Indiana from previous games appearing in later ones. However, we assume that Lara and Indiana are ")#emph[#text("entangled")]#text(" in the following way: if Lara is in tomb A and Indiana is in tomb B, then Lara and Indiana can each encounter corpses of their respective former selves, but only if ")#emph[#text("both")]#text(" Lara ")#emph[#text("and")]#text(" Indiana died in tombs A and B respectively in a single previous game. If in a previous game, Lara died in tomb A and Indiana died in tomb C, then this time round, Lara will not see any corpse (and of course, neither will Indiana). (This entanglement can be described a bit better by using ")#link("http://en.wikipedia.org/wiki/Tensor_product")[#text("tensor products")]#text(": rather than saying that Lara died in A and Indiana died in B, one should instead think of ")#mi("\\text{Lara } \\otimes \\text{ Indiana}")#text(" dying in ")#tao-math("\\left|A\\right> \\otimes \\left|B\\right>", block: false)#text(", which is a state which is orthogonal to ")#tao-math("\\left|A\\right> \\otimes \\left|C\\right>", block: false)#text(".) With this type of entanglement, one can see that there is going to be significantly less “quantum weirdness” going on; Lara and Indiana, adventuring separately but simultaneously, are going to encounter far fewer corpses of themselves than Lara adventuring alone would. And if there were many many adventurers entangled together exploring simultaneously, the quantum effects drop to virtually nothing, and things now look classical unless the adventurers are somehow ")#link("http://en.wikipedia.org/wiki/Bose%E2%80%93Einstein_condensate")[#text("organised to “resonate” in a special way")]#text(".")

#text("One might be able to use Tomb Raider to try ")#link("http://en.wikipedia.org/wiki/Pauli_exclusion_principle")[#text("to")]#text(" ")#link("http://en.wikipedia.org/wiki/Quantum_computer")[#text("understand")]#text(" ")#link("http://en.wikipedia.org/wiki/EPR_paradox")[#text("other")]#text(" ")#link("http://en.wikipedia.org/wiki/Bell%27s_theorem")[#text("unintuitive")]#text(" ")#link("http://en.wikipedia.org/wiki/Quantum_teleportation")[#text("aspects")]#text(" ")#link("http://en.wikipedia.org/wiki/Quantum_cryptography")[#text("of")]#text(" ")#link("http://en.wikipedia.org/wiki/Quantum_tunnelling")[#text("quantum")]#text(" ")#link("http://en.wikipedia.org/wiki/Uncertainty_principle")[#text("mechanics")]#text(", but I think I’ve already pushed the analogy far beyond the realm of reasonableness, and so I’ll stop here. :-)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (86)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-25939")[#strong[#text("Tiempo finito y logarítmico » Quantum Mario")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")]

#text("[…] Quantum mechanics and Tomb Raider propuso originalmente un concepto interesante. Al estar en el save point de un videojuego, desde el punto de vista del personaje éste se encuentra en una superposición de estados; a partir de ahí puede ser que continúe hacia caer a un pozo o hacia terminar el juego; justo como “ese gato”. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d99c3bb86549d36718915185fc39a913da43b3720205a501821d0622e8df42a7-cd87f9833cfd9346b2cbe2f2185695b2171fba614977daf7a33cac3eba686b43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Azzan")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-31881")[#strong[#text("Azzan")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2008")])]

#text("Nice example Quantum mechanics I love Tomb Raider its my best game")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46e106de4a257e31eeddff87b69493b1acfe0ef68b521d94cec38f9556f3d1cc-fe49504623aa3f0a3395308cf7c196c7ce1b4bc22e1bd6b03ee7ee7e69b95d84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ugechi peace N.")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-33867")[#strong[#text("ugechi peace N.")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2008")])]

#text("What do u mean pls help & explain more")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea7ba03671321918506334f5adf55f49f2147e3e7a0227a52bfb6dc662dfca3b-4273333249ad53d28d3ef92fb6daf52e34e26cf7886e89d76504feba0e0ac016.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Falk")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-38174")[#strong[#text("Johan Falk")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2009")])]

#text("Really cool post. Thanks a lot!")#linebreak()#text(" (It reminds me of a previous discussion about quantum suicide, ")#link("http://en.wikipedia.org/wiki/Quantum_suicide")[#text("http://en.wikipedia.org/wiki/Quantum_suicide")]#text(". Don’t try that!)")

#text("//Johan Falk, Sweden")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a3dde7aadfc56bdcba1ff3bee5e04e651b9991045645ce86e915afeb0060f551-672b7dacc288452841b5fab6573eced84e3f037e1991ac692299bcd7e024a3e9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Ford")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-38903")[#strong[#text("Daniel Ford")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2009")])]

#text("There’s a great flash game called Chronotron which relies on interacting with past incarnations of yourself to solve puzzles. I highly recommend it.")

#link("http://www.kongregate.com/games/Scarybug/chronotron")[#text("http://www.kongregate.com/games/Scarybug/chronotron")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-41104")[#strong[#text("Why is many-worlds winning the foundations debate? | Matt Leifer")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2009")]

#text("[…] every time the foundations of quantum theory are mentioned in another science blog, the comments contain […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-41105")[#strong[#text("Tao on Many-Worlds and Tomb Raider | Matt Leifer")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2009")]

#text("[…] Tao has an interesting post on why many-worlds quantum theory is like Tomb Raider. I think it’s de Broglie-Bohm theory that is more like Tomb Raider though, as you can see […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-42714")[#strong[#text("古墓丽影瀚量子力学")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2009")]

#text("[…] 原文：Quantum mechanics and Tomb Raider 作者：Terence Tao（UCLA数学系的华人教授陶哲轩） 翻译：Ross […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43ee7f59e8c05f7435cf405e7fcbc24dad7016bc9c812b913f97c800498edd6-e99fd02323c4f794870390823e17bacda31ab2026e98c69a0dccb310ac0f9679.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff Burdges")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-43354")[#strong[#text("Jeff Burdges")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2010")])]

#text("It’ll be interesting if someone devises a game to let players “experience” some of the unintuitive effects of quantum mechanics. A turn based board game would help keep the superposition small, but you’d surely want a computer tracking the superposition.")

#text("p.s. It appears a real-time strategy game ")#link("http://achrongame.com")[#text("Achron")]#text(" incorporates time travel by using the fact that such real-time strategy games are mostly just simulations using preprogramed unit behaviors. So players may edit the orders they gave at an earlier point in time, which prompts the game to rerun the simulation from that point on. Of course, the opposing player may also adjust this past commands too.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of discrete transform")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-43358")[#strong[#text("discrete transform")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2010")])]

#text("Their Resequence Engine allowing for minmax strategies must be from the future too.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-44018")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2010")])]

#text("Dear Dr.Tao..In an entirely different context can I ask you a question?")

#text("General Relativity says that mass deforms the shape of space-time. There are different shapes for the same mass that can produce this deformation.")

#text("Is there a way to construct a schrodinger type of equation whose solutions are the possible shapes for a given mass that can give rise to the same curvature in space-time?")

#text("Thanks,")#linebreak()#text(" Ganesh Raghavan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7345136be7153a213a4151d88c05c4301f3685480c8a328afb9b9be004b187b8-f2fd6b6198b794d789903191318d016bdcae8cdaf881a239c8eb6196c563bb53.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ron Maimon")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-44570")[#strong[#text("Ron Maimon")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2010")])]

#text("The analogy between a classical duplication event for a conscious observer and the quantum mechanical many-worlds interpretation is a good one, but it has philosophical fine points regarding the probability measure, which you glossed over.")

#text("It is not at all clear that you are free to conclude that the probability of survival is 1/N for N duplications. If you restore and play again, once a day, you are constantly increasing N, and so if you look at it from Lara’s point of view, should your probability of survival depend on the N on tuesday or on wednesday? What if you run on a processor that sometimes stores a backup copy in a cache, and so internally duplicates some data? Should you count that double? What if you run on 2-petahertz processor vs a 1-petahertz, should the internal probability measure include the duration of existence of the Lara copies?")

#text("The only way I know to stop being endlessly confused on this point is to formulate this positivistic way— to ask “what answers to questions that I ask will the Lara’s give” (just as Everett did for quantum mechanics). This is after all the only way to acquire data on the internal experience of the Lara’s. Then the probability measure that you observe when asking questions of Laras depends on the details of which copies of Lara you choose to ask question of, and with what probability.")

#text("For example, you could just erase all the Lara events where Lara does not survive, and only talk to survivors. In this coupling between the external and internal world, the chance of survival is certainty, since if you ask the Lara’s whether they always survive, they will answer “yes”. You could talk to all the injured Lara’s, and they would have a different opinion on the danger of the puzzle then if you talk to the uninjured ones. If you keep all the Lara’s, then the great majority would associate some risk to each puzzle, but this again depends on the selection measure for who you choose to end up communicate with. So it is not at all clear that the question of internal experience in this model world has a unique right answer.")

#text("But in quantum mechanics the probability measure does have a unique right answer: it’s psi-squared. It’s not determined by an outside agent looking in, or at least, it’s the same for all the outside agents looking in, if you take the Copenhagen interpretation and consider us to be the outside agents. The probabilities in QM are nothing like the reciprocal of an integer, and that effect, which I don’t think should be thought of as necessarily true in the Tomb Raider world, has nothing to do with what physicists call “quantization”.")

#text("There is no naive way to go from copy-counting to the probability measure of quantum mechanics, but there is a naive way of identifying classical probability with copy-counts (which is the ensemble interpretation of probabilities). The measure in quantum mechanics is determined by Hilbert space massiveness of states, by a psi-squared measure on the states, not by any naive copy-counting. It is an interesting exercise to construct a copy-counting measure which reproduces quantum mechanical psi-squared probability (that’s DeBroglie Bohm theory, since a classical probabilistic ensemble which can be given a copy-counting frequentist interpretation, and DeBroglie Bohm gives a classical probabilistic ensemble which matches quantum mechanics)")

#text("You always run into the same philosophical question when you treat a physical system as self-contained correct model of reality. you have to somehow identify the experience of observers with the mathematical objects inside the theory. When the theory is either probabilistic, quantum mechanical, or duplicates observers, the identification of the correct probability measure from copy-counting is impossible a-priori, you need additional (mild) assumptions. The assumptions for a classical probabilistic theory is that there is an ensemble “underneath it all” and the number of worlds is proportional to the classical probabilities. For QM it’s that worlds with small hilbert space norm are unlikely. For duplicative theories, it requires knowing the way in which duplicates are most likely to talk to an outside observer.")

#text("This is the sticky point for many-worlds type interpretations, and it is present in duplicating classical theories in the exact same way, or an even worse way, depending on your point of view. It’s a philosophical problem, not a physical or mathematical one, and the resolution I think works is to adopt a more Platonic philsophy regarding the relation of the computational structures in the mind to the physical objects described by wavefunctions in the world.")

#text("Unfortunately, the philosophers who discuss this field don’t often take a functionalist philosophy of mind, so they don’t really get the interesting confusions. Pauli and Einstein discussed similar things first, although Everett brought in the duplication of course.")

#text("One thing though: I don’t understand Jaques’ Distler’s comments. The noncommutativity of observables is a non-sequitor for this philosophical issue. Non-commuting observables are just what happens when you describe an orthogonal collection of states and observable-values by a matrix. I don’t see why this algebraic property should be singled out— it’s an opaque algebraic way to restate the principle of superposition and the notion of orthogonality, which are all you need for a philosophical discussion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-50750")[#strong[#text("Weird Consequences of Quantum Mechanics |")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2011")]

#text("[…] From: https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/ […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-52156")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2011")])]

#link("http://www.goorden.be/2010/12/why-your-understanding-of-quantum-mechanics-is-almost-certainly-wrong/")[#text("http://www.goorden.be/2010/12/why-your-understanding-of-quantum-mechanics-is-almost-certainly-wrong/")]

#text("After reading the above blog, I feel how much I don’t understand what I understand. Do you have any opinion professor?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8014597aa15ab4ee3aa1177cc7cd9a2bf3a81254b8fa7354cf830bebd113c5b8-38718922ae16668116814f4286915854a5037a7088afc6ca5aeb34e4d382c976.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultra Weekend")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-53249")[#strong[#text("Ultra Weekend")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2011")])]

#text("ok, I came up with a simple concept. Lets put a QRBG into a video game and see what happens. ")#link("http://ultraweekend.blogspot.com/2011/05/many-worlds-hypothesis-video-game.html")[#text("http://ultraweekend.blogspot.com/2011/05/many-worlds-hypothesis-video-game.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 1")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-145566")[#strong[#text("1")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2012")])]

#text("-1′")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-228780")[#strong[#text("Bird’s-eye views of Structure and Randomness (Series) | Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2013")]

#text("[…] Tomb raider: an analogy to quantum weirdness (adapted from “Quantum mechanics and Tomb Raider“) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-228836")[#strong[#text("Tomb raider: an analogy for quantum weirdness | Abstract Art")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2013")]

#text("[…] [1.1] Quantum mechanics and Tomb Raider […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68b80d6140e5077edac4fa733db70b8def37d29790c538ce013394aafbdb09e4-ee890e5bf0cec3601c75d0fe54ec994df35b51c8ea42c694a3b866779d057b39.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 2PG")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-272630")[#strong[#text("2PG")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2014")])]

#text("Hey Terry,")

#text("We are currently working on a cooperative game concept on quantum mechanics in a way that will assist us to build something that not only the external and internal universe has to cooperate but the 2 players that will co-ordinate and collaborate to perform various actions in to the internal environment will feel 100% brain stimulated. Not only they will need to behave as two players in 1 role but they will also have to perform hard advance estimations on possible scenarios the game will evolve.")

#text("One Example of what i mean is the game blocked out on our site ( 2pg.com ) . The two players are essentially working one against each other to block the other player “out”.")#linebreak()#text(" Given that they predict how the internal environment will behave as well as the 2nd players move’s. They manipulate inner game levers,buttons,traps to block the other guy out.")

#text("Thats a crude model and we are currently trying to realize this in a more complex scale.")

#text("Wish us luck!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7538a96a3e348d247066b1693ca8fa4fa529eeed45199b79002662a5548413e5-120660df3e9286c3cb8d6e749178fe10ce572a83986cb4e74324b2dc839551b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul J. Werbos")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-279577")[#strong[#text("Paul J. Werbos")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2014")])]

#text("It turns out that a lot of the paradoxes in quantum mechanics are a consequence of implicit classical assumptions that all noise is a function of initial conditions only (which is the effective meaning of “causality” as assumed in the classic “CHSH” theorem). At arxiv.org, I show how any of three Markov Random Field models across space-time can reproduce the observed results, even though they are local and realistic. To take this further, aside from cleanup, the REAL challenge is to actually prove stability for three-dimensional topological solitons with nonzero Higgs terms (which is claimed in a classic paper by Erich Weinberg, but not really proven), and then move on to some more realistic Lagrangians.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7353ee28fd28fa9d2f4250c0380e13ff2eadab7f8021b277acdea56f167135d-3651039d9e4b233e6ee2cedbfad293d25b7dc83c966cc198090e75aba229a97f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ผลบอล")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-460049")[#strong[#text("ผลบอล")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("What a information of un-ambiguity and preserveness of valuable knowledge regarding")#linebreak()#text(" unpredicted feelings.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5a4f3c07a682484df2bc171b89c1ab0a87112e62fed63aad85d348103bf9950f-50130b1c35243f0f908389cc34a7f89bebe4e36c21b634c4e6df66cb9a2ad8ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tyrone Vasquez")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-461482")[#strong[#text("Tyrone Vasquez")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2015")])]

#text("10/10 will play Tomb Raider to learn quantum mechanics")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8b673b0f5f8fd68741b472717dc8bbd250b58bfba25e6acdfd89140ba4da454-0162e84387e99bc2ff7bac0941538a04a75718fb34ec614fb02a7375dece8626.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cpluskx")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-486912")[#strong[#text("Cpluskx")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2017")])]

#text("I really wonder what Terence Tao thinks about the simulation argument. Are we living in a computer sim?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ad11900cdd6ce81cdfabab45342606977db3413d6479157784ab5e572ca0ee7-ef0e167b5c517a24e675a22cf07f3b6863b6a71df9f8b9f1e3d7db96362a2bd7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lorenzo Dantas")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-516592")[#strong[#text("Lorenzo Dantas")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2019")])]

#text("I was looking for Tomb Raider stuff and now I know Quantum Mechanics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5116c21b41217b38df8be7bf9bb22d7454520bd5ad1619743ce3dcaba8f04dea-1b0a6b0223d1b5f5d5ff6a0eb0648281e804deeb938c3a8e0d17fcdeab77b2cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Khalil turki")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-551766")[#strong[#text("Khalil turki")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2020")])]

#text("unbelievable !!!!")#linebreak()#text(" we just had exactly the same idea haha ​​except that I made a link between entanglement and gravitation,")#linebreak()#text(" I explain you probably already know the work of Alain Connes reference (con94) on von neumann algebra and non-commutative geometry roughly to be precise it says that the fact that observables at the quantum scale are represented by autoadjoint matrices is the source of time, if for example instead of being represented by matrix operators but by vectors then the universe would be static and “t” no longer exists: quantum uncertainty = time, so now if as you say 2 particles | A> | B> are entangled the uncertainty will be divided by 2 their proper times will be dt ‘= dt / 2 if we have an entangled network of n particles their proper times will be dt’ = dt / n now if n tends to infinity time stops and the operator projection of the network Pe = (| psy> <psy |) ^ tensorial n will tend towards the identity matrix, but there are places in the universe where time stops '' black holes '', other remarks if the ec oulement of time dt decreases the metric space time (- +++) therefore increases an element of surface ds in which there is an entangled network will be more curved than that where there is no")#linebreak()#text(" ps: I am neither a physicist nor a mathematician, I have no idea of ​​the state of science at the moment and I cannot consequently develop these ideas.")#linebreak()#text(" with all my respect and admiration, khalil")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ecd3505053e823752e133e50092b53322e52a28b1566e42b351cf4683bb37b5-71206d714602e6fa76e941616865d1b5606cc72b044287d8e45e6f273d56bfc0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.P. McCarthy")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-643493")[#strong[#text("J.P. McCarthy")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2022")])]

#text("dead link: ")#link("https://www.theonion.com/content/node/28288")[#text("https://www.theonion.com/content/node/28288")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-645877")[#strong[#text("Quantum mechanics and Tomb Raider - blog.wuyuansheng.com")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2022")]

#text("[…] 4, 2022 Quantum mechanics and Tomb Raider This post is derived from an interesting conversation I had several years ago with my friend Jason […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01c29b9b60726dd90e20796d7e61b33bb6f09ca37d073d3bf26c0b3daa75e0be-29edca2f7f7ee1e15c9739029e0245af27f267e5f678f09c3611cdbcb509aae3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tech roundup 149: a journal published by a bot - Javi López G.")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-646169")[#strong[#text("Tech roundup 149: a journal published by a bot - Javi López G.")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2022")])]

#text("[…] Quantum Mechanics and Tomb Raider […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/360362c21f4dd77a6396ffd8bc06611230f00540515ac79b938cae617c0d59ff-93326dd1fb7fdd9837314795084a52659f39a04db3bc97f40484d3f6fdc9177d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of QMechanic")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-658428")[#strong[#text("QMechanic")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2022")])]

#text("Entanglement cannot be directly demonstrated across galactic scales and times within human lifespans. Einstein’s objection was primarily about entanglement being possible across vast scales which we cannot demonstrate (as pointed out say for example across galaxies). Is it possible there is a simple enough mathematical model of nature tweakable from current quantum theory which is sufficient for the observable and experimental universe we humans live in? Such a model can allow for entanglement to fail realistically for vast distances as Einstein intended.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Special relativity and Middle-Earth | What's new")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-670538")[#strong[#text("Special relativity and Middle-Earth | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2022")])]

#text("[…] This post is an unofficial sequel to one of my first blog posts from 2007, which was entitled “Quantum mechanics and Tomb Raider“. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-670555")[#strong[#text("Special Relativity and Middle-Earth - My Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2022")]

#text("[…] This post is an unofficial sequel to one of my first blog posts from 2007, which was entitled “Quantum mechanics and Tomb Raider“. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-670561")[#strong[#text("Special Relativity and Middle-Earth - Mondaychick")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2022")]

#text("[…] This post is an unofficial sequel to one of my first blog posts from 2007, which was entitled “Quantum mechanics and Tomb Raider“. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-670585")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2022")])]

#text("Any rigorous mathematical model for physics should give precise mathematical definition for the concept of “elementary particles” and their quantitative parameters (such as rest mass, electric charge and spin) and the explanation for the numerical values of all the non-dimensional parameters (in particular the fine-structure constant!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/568684f5db9aeac3d70b8de84b68dcd2efdd4ddc853d4fe6543e7ac93c39840d-3614ea7fec54a8a445068c3f8e018d8bd7bd689328ca253001429432b75ae1c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of queensublime1da455be34")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-2/#comment-692140")[#strong[#text("queensublime1da455be34")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2026")])]

#text("sorry this is a long time ago but aside from the analogy do you actually believe in the many worlds interpretation where each and everyone and everything continously splits, apart from what the Born rule would mean, it seems hard to make sense to what anything would even mean in such a world. If the cat dies why should I care exactly the same cat is at that moment split in a world where hé lives? I mean what would anything actually mean?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f69a51654c0b439527fb75da7f18733b3714440bcb385f27199d17d9545fae4f-912b97f3c44ae005eeb4e3f9ba21fb91186fe371d3d7537d29c63688bbff4154.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave Bacon")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-5")[#strong[#text("Dave Bacon")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2007")])]

#text("Very cool post! I like it, but am a bit skeptical about pushing the quantization of probabilities over to the quantization in the Schrodigner equation, but I’ll have to think about it more.")

#text("Another interesting problem to think about in computer universes is what entities in these universes would say about predicting their future. Suppose you’ve got a run of the mill deterministic cellular automata and your a big blob in this universe. Can you predict you’re own future? You can’t because you only have access to the information in your past light cone. Now, after the fact, you’ll be able to have a consistent history of your universe, but you won’t be able to predict the future. Sort of quantum mechanical as well!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-6")[#strong[#text("Infinite Reflections » Blog Archive » Fields Medal and Blogging …")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2007")]

#text("[…] post on Lara Croft Tomb Raider and Quantum Mechanics is pretty entertaining and insightfull […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-7")[#strong[#text("The Quantum Pontiff » Post To Read While the World Spins")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2007")]

#text("[…] factors while Terrance Tao discusses some quantum mechanics based on…Tomb […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6fcb8d30c738ff426666c822fa860421cae85519b5e5a7ca833529b178b70f-1baf45cb7c9d247cddb852eb5afc1544fd649a6a89d1f5eaa22aa3084392aa95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques Distler")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-8")[#strong[#text("Jacques Distler")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2007")])]

#text("I found myself scratching my head a bit over this post.")

#text("Classical physics is no stranger to probabilities. Nor to the “quantization” of certain observables (think, e.g. of Sturm-Liouville systems). What distinguishes quantum mechanics from classical physics is non-commutativity. Observables (self-adjoint operators on Hilbert Space) don’t commute, in general. This non-cummutativity is at the heart of all interference phenomena, is responsible for the (generalized) Heisenberg Uncertainty relation (a lower bound on the product of the variances, in any quantum state, of two non-commuting observables), and all of the weird stuff we call “quantum.”")

#text("In the limit that you can neglect it, you recover classical physics (via Ehrenfest’s Theorem).")

#text("I didn’t really see how non-commutativity was captured in your Tomb-Raiders analogy. In fact, all of the phenomena sounded distinctly classical, albeit rather odd, unaccustomed as we are to dealing with the classical physics of an ENSEMBLE of Laras.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a98f4d7cff1dcea182d4d72fc5cb1273392d81a566ffe17201c120a40b56eeb-2094c1ae34fde3b4c539681e0b2f6275adea06b90414c56adbc5049634a88bf4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vish Subramanian")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-9")[#strong[#text("Vish Subramanian")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2007")])]

#text("The comment of Jacques Distler leaves me scratching my head a bit. Apparently, physics PhD’s take it upon themselves to mock mathematicians for stepping on their turf, without understanding what they say.")

#text("Anyway, its quite clear that Terry Tao is not talking about a classical ensemble of Lara’s, because the various Lara’s are interacting with each other. Its exactly the same as an electron behaving as though there were multiple slits between it and a screen – interference results.")

#text("The non-commutative property doesnt come though perfectly – its only an analogy(!), but it can be seen as follows – imagine one operator giving you the exact incarnation of a particular Lara (position), and the other one giving the final score of the game (momentum). They are non-commutative. If you measure only the final score, the incarnation that reached it is indeterminate, and if you measure only the incarnation (by playing only one game without interference), you cant be sure what the final score is.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6fcb8d30c738ff426666c822fa860421cae85519b5e5a7ca833529b178b70f-1baf45cb7c9d247cddb852eb5afc1544fd649a6a89d1f5eaa22aa3084392aa95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques Distler")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-10")[#strong[#text("Jacques Distler")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2007")])]

#text("Why the hostility, Vish?")

#text("Anyway, “interacting” with the corpses of Laras from previous games is purely classical phenomenon. The fact that “Jaqueline” doesn’t know about the corpses makes this a kind of “hidden variable theory.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-11")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2007")])]

#text("Dear Jacques,")

#text("Thanks for the comments. The model I have here is classical in the")#linebreak()#text(" external universe, but non-classical in the game universe; the point is that the hidden variables are external to the game universe. (The many-worlds interpretation is similar, by the way; it is a local hidden variable explanation of quantum mechanics, but only in the “external” setting in which one regards the entire universe as a wave function. In the")#linebreak()#text(" “internal” setting of the classical universe observed by a macroscopic")#linebreak()#text(" observer, a hidden variable explanation is impossible.)")

#text("I don’t yet have an explicit example of Bell inequality violation in the")#linebreak()#text(" game universe – which is an interesting puzzle, and I’ll think about it – but in the meantime, let me offer you a Tomb Raider analogue of the two slit experiment. Imagine a tomb with the following layout:")

#text("…Entrance…..")#linebreak()#text(" ………|………")#linebreak()#text(" .Antechamber.")#linebreak()#text(" …|………..|…")#linebreak()#text(" Door A…Door B")#linebreak()#text(" …|………..|…")#linebreak()#text(" …..Seesaw….")#linebreak()#text(" ………|………")#linebreak()#text(" …….Exit……..")

#text("Suppose that the doors are one way: on reaching the antechamber,")#linebreak()#text(" Lara has to choose one of the two doors, and on doing so, is stuck")#linebreak()#text(" on one end of the seesaw. Suppose that the seesaw is trapped in")#linebreak()#text(" such a way that one has to keep the seesaw balanced for, say,")#linebreak()#text(" five minutes before the trap is defused. Classically, this would")#linebreak()#text(" be impossible for Lara, as she is only on one side. But if she goes")#linebreak()#text(" through once, say on side A, and then dies, then when the game")#linebreak()#text(" is restored, she can go in on side B and balance herself against")#linebreak()#text(" the corpse from the previous game to defuse the trap. So she in")#linebreak()#text(" fact has a 50% chance of survival here.")

#text("But on the other hand, note that if you lock either one of the doors,")#linebreak()#text(" her survival rate drops to 0%.")

#text("This does not have an easy classical explanation within the game")#linebreak()#text(" universe, even with hidden variables, at least if you make the")#linebreak()#text(" “locality” assumption that Lara can only go through one of the two")#linebreak()#text(" one-way doors, and if you assume that the locks have no effect other")#linebreak()#text(" than to stop Lara from choosing one of the doors.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6fcb8d30c738ff426666c822fa860421cae85519b5e5a7ca833529b178b70f-1baf45cb7c9d247cddb852eb5afc1544fd649a6a89d1f5eaa22aa3084392aa95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques Distler")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-12")[#strong[#text("Jacques Distler")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2007")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I don’t yet have an explicit example of Bell inequality violation in the game universe – which is an interesting puzzle, and I’ll think about it")
]

#text("Great!")

#text("What would be clearest would be to try to rewrite this ")#link("http://groups.google.com/group/sci.physics.particle/msg/593aac097548080f")[#text("this old discussion")]#text(" of the Greenberger-Horne-Shimony-Zeilinger theorem, in terms of your “Tomb-Raiders” universe.")

#text("GHSZ really put the distinction between hidden variable theories and QM is sharp relief.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-13")[#strong[#text("It is all about me! » Blog Archive » Determinism")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2007")]

#text("[…] it but I never truly embraced it….. because I had nothing to write about. But physics and quantum mechanics in particular are bloggable. | Suppose you’ve got a run of the | mill deterministic cellular […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/738ab60216ef7fa7236252e2fc8735d2d932ef86f401304ced2003146f8cbb3b-19c8b885b0b640855e01a645756ffc73d41450328a2b0a3a6acf76132a9f424a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zerocold")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-14")[#strong[#text("zerocold")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2007")])]

#text("Great post professor Tao and welcome to the exciting word of blogosfera. I hope that you will be an example to other professional matematician to share they studies and their knowledges with the worl non only with thecnical papers on math journal. I’ve already added your feed to my rssreader.")

#text("zerocold")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terry Tao")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-15")[#strong[#text("Terry Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2007")])]

#text("Okay, I think I can get a Bell’s inequality violation now, though as in the usual Bell’s inequality the situation is complicated.")

#text("I will need two characters (Lara and Indiana), and three locations widely separated in space: Tomb A, Gate L, and Gate I. Gate L and Gate I both have two up-down switches which either character can manipulate into any of the four positions before trying to open the gate: up-up, up-down, down-up, or down-down. However, the gates are trapped: only two of the positions allow the gate to be opened safely; the other two positions will ensure that the gate electrocutes whoever is trying to open it. Lara and Indiana know that the gates are anti-symmetric: if one flips both switches then that toggles whether the gate is safe or not (e.g. if down-up is safe, then up-down electrocutes). But they do not know exactly which combinations are safe.")

#text("Lara and Indiana desperately need to open both gates, but do not know the safe combination. They believe (inaccurately, as it turns out) that inside Tomb A, there is inscribed a combination (of one of the four positions) which will safely open both gates. Their plan is to jointly go to Tomb A, find the combination, write that combination down on two piece of paper (one for Lara, one for Indiana), and then Lara and Indiana will travel separately to Gate L and Gate I to try that combination to unlock both gates. At this point, the player saves the game and play continues repeatedly from this restore point. In this particular scenario, the player actually has no control over Lara and Indiana’s actions; they are independent AI’s, following the plan described above.")

#text("Unfortunately for Lara and Indiana, the combination in Tomb A is simply a random combination – up-up, up-down, down-up, and down-down are each 25% likely to be found in tomb A. In truth, the combinations to Gate L and Gate I have been set by Jacqueline, as one of the following possible settings:")

#text("Gate L, Setting 1: opens safely on up-up or up-down, electrocutes on down-up or down-down")

#text("Gate L, Setting 2: opens safely on up-up or down-up, electrocutes on up-down or down-down")

#text("Gate I, Setting 1: Opens safely on up-up or up-down, electrocutes on down-up or down-down")

#text("Gate I, Setting 2: opens safely on up-down or down-down, electrocutes on up-up or down-up.")

#text("Jacqueline is interested in the probability that Lara and Indiana end up with the same fate, i.e.")

#text("p = Prob( (Lara and Indiana both survive) OR (Lara and Indiana both die) ).")

#text("Let’s see what this probability is in various cases.")

#text("First suppose that Gate L and Gate I are both set to setting 1, thus they open on up-* and electrocute on down-*. If Lara and Indiana find an up-* pattern in Tomb A then they both survive. In some cases they may both be electrocuted, but only if they both hold down-* codes. If Lara and Indiana later encounter corpses of themselves clutching a down-* code, they are intelligent enough to apply the opposite of that code (overriding whatever false clue they got from Tomb A) and pass through safely. As the situation is totally symmetric we see in this case that p = p_11=1.")

#text("Now suppose that Gate L and Gate I are both set to setting 2, thus Gate L is only safe for *-up and gate I is only safe for *-down. Then what happens every time the game is played is that exactly one of Lara or Indiana dies. Note that due to the entangled nature of the corpse mechanic, this means that Lara and Indiana never see any useful corpses which could save their lives. So in this case p = p_22=0.")

#text("Now suppose that Gate L is in setting 1 and Gate I is in setting 2, or vice versa. Then what happens, if Indiana and Lara see no corpses, is that they have an independent 50% chance of survival, and thus a 50% chance of meeting the same fate. On the other hand, if Indiana and Lara see corpses (and the way the mechanic works, if one of them sees a corpse, the other does also), then they will use the more intelligent negation strategy to open both gates. Thus in these cases p_12 or p_21 is _strictly_ greater than 1/2.")

#text("These facts put together violate (the CHSH form of) Bell’s inequality:")#linebreak()#text(" p_11 + p_12 + p_21 – p_22 \\not \\leq 2.")

#text("p.s. Thanks for the pointer to the GHSZ theorem, which I was unaware of. Unfortunately I will probably not have the time to try to concoct")#linebreak()#text(" an analogue for that theorem in my model…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bfc8c62fcc86607f6fce932e1fb5c24c945912e62ba2f148c95361cdbd285f5c-27b558fc3b37f76b33d40f62e3b73230d4591f0d3da190f435d55206309f9bbf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JT")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-225568")[#strong[#text("JT")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2013")])]

#text("You’d better be careful that you don’t allow nonlocality much stronger than is permitted by quantum mechanics. (For example, superluminal communication is not allowed, although this doesn’t rule out quantum nonlocality strong enough to permit quantum cryptography. However, there is the theory of “nonlocal boxes” which considers nonlocality even stronger than appears in quantum theory but still too weak to permit superluminal communication.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-390691")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2014")])]

#text("Perhaps Jacqueline is the physicist, the one doing measurements? I wasn’t sure whether the Tomb Raider game/puzzle thought experiment was flexible enough to incorporate physicists doing measurements to test Bell’s inequality. Since violation of Bell’s inequality is mentioned, I now believe an analog of spin measurements done on a prepared “entangled system” exists in the above version of a Tomb Raider game/puzzle.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44d7974df53295eff25ab94566a6586f6d7444816ee856c4597ff7d46752fbb4-ff04b3f5bd1d1909da4198b72a9edaeb26a9ae71907badaa09eac444fa2d6ee0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nc")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-16")[#strong[#text("nc")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2007")])]

#text("“Anyway, its quite clear that Terry Tao is not talking about a classical ensemble of Lara’s, because the various Lara’s are interacting with each other. Its exactly the same as an electron behaving as though there were multiple slits between it and a screen – interference results.”")

#text("The solar system would be as chaotic as a multi-electron atom if the gravitational charges (masses) of the planets were all the same (as for electrons) and if the sum or planetary masses was the sun’s mass (just as the sum of electron charges is equal to the electric charge of the nucleus). This is the 3+ body problem of classical mechanics:")

#text("‘… the ‘inexorable laws of physics’ … were never really there … Newton could not predict the behaviour of three balls … In retrospect we can see that the determinism of pre-quantum physics kept itself from ideological bankruptcy only by keeping the three balls of the pawnbroker apart.’")

#text("– Dr Tim Poston and Dr Ian Stewart, ‘Rubber Sheet Physics’ (science article, not science fiction!) in Analog: Science Fiction/Science Fact, Vol. C1, No. 129, Davis Publications, New York, November 1981.")

#text("Obviously Bohr did not know anything about this chaos in classical systems, when when coming up with complementarity and correspondence principles in the Copenhagen Interpretation. Nor did even David Bohm, who sought the Holy Grail of a potential which becomes deterministic at large scales and chaotic (due to hidden variables) at small scales.")

#text("What is interesting is that, if chaos does produce the statistical effects for multi-body phenomena (atoms with a nucleus and at least two electrons), what produces the interference/chaotic statistically describable (Schroedinger equation model) phenomena when a single photon has a choice of two slits, or when a single electron orbits a proton in hydrogen?")

#text("Quantum field theory phenomena obviously contribute to quantum chaotic effects. The loops of charges spontaneously and randomly appearing around a fermion between IR – UV cutoffs could cause chaotic deflections on the motion of even a single orbital electron:")

#text("‘… the Heisenberg formulae can be most naturally interpreted as statistical scatter relations [between virtual particles in the quantum foam vacuum and real electrons, etc.] … There is, therefore, no reason whatever to accept either Heisenberg’s or Bohr’s subjectivist interpretation …’")

#text("– Sir Karl R. Popper, Objective Knowledge, Oxford University Press, 1979, p. 303.")

#text("Yang-Mills exchange radiation is what constitutes electromagnetic fields, both of the electrons in the screen containing the double slits, and also the electromagnetic fields of the actual photon of light itself.")

#text("‘Light … “smells” the neighboring paths around it, and uses a small core of nearby space. (In the same way, a mirror has to have enough size to reflect normally: if the mirror is too small for the core of nearby paths, the light scatters in many directions, no matter where you put the mirror.)’ – R. P. Feynman, QED, Penguin, 1990, page 54.")

#text("The electrons are exchanging a net amount of gauge boson energy where you have electromagnetic forces doing work. The claim of the failure of Maxwell’s classical electromagnetism (that a spinning charge should radiate, and there should be no ground state) is due to ignoring the fact that a static electric field is simply an equilibrium of light speed radiation exchange between all charges. There could be plenty of interesting checkable mathematical results from rigorously explaining the distinction between classical and quantum results without involking speculation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-17")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2007")])]

#text("I may be suffering from all the blind spots that a father has when he praises his son, but I believe that my computer program “Quantum Fog” (mac freeware available at Apple website) is the best software ever for understanding quantum mechanics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec5f78731edc201d99268e7ee5bebd4048b4ac34c2179a7eaef3942d18742858-f9923df6c91dc1e48da7945d10b89b1991a00ed102e3db0c701993c9edb15aac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt Leifer")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-18")[#strong[#text("Matt Leifer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2007")])]

#text("Nice post! I’m a bit puzzled by your assertion that the Tomb Raider model is like many-worlds though. To me it smells more like a nonlocal hidden variable theory in the vein of Bohmian mechanics, except that the continuous nonlocal potential is replaced by instantaneous discretized loading and saving operations. One reason for saying this is that you don’t have any ambiguity over the choice of “basis” like you do in quantum theory. The “external picture” in quantum mechanics is just a “wave-vector of the universe” for which no preferred bases or probabilities exist a priori. This is a big conceptual issue with many-worlds because you require an explanation in terms of the external picture (like decoherence) of why the worlds split in the “pointer basis” rather than any other. In your model there is a fixed dead/alive “basis” in which the splitting always occurs, which is a primitive component of both the internal and external pictures, and which is put in by hand. This is analogous to the way that the position variables are put in by hand as part of the external picture in Bohmian mechanics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-20")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2007")])]

#text("A couple final remarks, and then I will have to go back to my day job :-)")

#text("It is possible to tweak the Bell inequality example I gave above to give a GHSZ type result, but only in an asymptotic limit. I doubt the model can give a non-asymptotic GHSZ result without some major rule changes, basically because the first run of any puzzle will be completely classical, even if subsequent runs are not.")

#text("Previously, I was implicitly assuming that once both Lara and Indiana make it through the game, the player stops restoring the game. But suppose now that the game is restored a large number of times regardless of whether Lara and Indiana succeed or not. Assume also that corpses stick around for a long time. Then we still have p_11 = 1 and p_22 = 0 as before, but in the 12 or 21 situations what will happen is that after a small number of game iterations, corpses will appear in both gates, and after that both Lara and Indiana can safely navigate both gates every time by using the negation trick. So asymptotically p_12 = p_21 = 1 as well. In other words, the four statements")

#text("Lara survives setting 1 iff Indiana survives setting 1")#linebreak()#text(" Lara survives setting 2 iff Indiana does not survive setting 2")#linebreak()#text(" Lara survives setting 1 iff Indiana survives setting 2")#linebreak()#text(" Lara survives setting 2 iff Indiana survives setting 1")

#text("all are true with asymptotic probability 1, even though the four statements")#linebreak()#text(" are inconsistent in a classical local hidden variable theory.")

#text("Of course, there are many fundamental ways in which this type of Tomb Raider model differs heavily from quantum mechanics. QM has a Hilbert space, a complex structure, and an evolution operator which is linear, time-reversible, and unitary. Tomb Raider has none of these, at least without massive rule changes. (For instance, Tomb Raider trivially fails to obey the no-cloning theorem.) In particular, it is the nonlinear, time irreversible nature of the game mechanic which is allowing me to construct the above examples; QM is far more rigid in this regard.")

#text("It’s also true that this Tomb Raider model does not fully capture the unintuitive nature of the many-worlds interpretation due to the presence of a canonical basis for the universal wave function. I have some thoughts as to how to capture a lack of basis that by turning the game into a massively multiplayer online game, in which each player’s version of Lara will share items and experiences with other simultaneous players, but I haven’t seriously thought it through, and as I said in the main post I think there is a serious limit as to how far this analogy can and should be pushed anyway. :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-21")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2007")])]

#text("If memory serves, Stanislaw Lem’s short story collection ")#emph[#text("The Cyberiad")]#text(" deals with many of these same issues. I will see if I still have my copy of it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1542e5d738b7a31bd5b5721c3096cd9b8b14c300334f14c6226ff1a264c83b58-74be25aec656c8490d8286205287f6a7cbe7ac875c1b050142c3fabf6a6cd7d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bob Hawkins")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-22")[#strong[#text("Bob Hawkins")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2007")])]

#text("“… she usually encounters a number of corpses which look uncannily like herself…”")

#text("Exactly this happens in the 1960 novel _Rogue Moon_ by Algis Budrys ( ")#link("http://www.amazon.com/s/ref=nb_ss_gw/103-0139294-7387843?url=search-alias%3Dstripbooks&field-keywords=Rogue+Moon")[#text("http://www.amazon.com/s/ref=nb_ss_gw/103-0139294-7387843?url=search-alias%3Dstripbooks&field-keywords=Rogue+Moon")]#text(" ).")

#text("In the novel, the process you describe mirrors the creative destruction of science — the “correct” theory is the one that isn’t killed by contrary fact. It necessarily mirrors QM, since QM is also creative destruction — the observed trajectory is the one that is not destructively interfered with by the integral over any other path.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33135481fb49cc1868fab52fbd112e1a2c4c6974490a4f599e8d55ff1d28b151-763156eb60857bf5a326e1ad4e44f9cf9b10f9732a0f856e757848d578e34700.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bee")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-23")[#strong[#text("Bee")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2007")])]

#text("Indeed, a very nice post! I used to play Tombraider a lot :-) Anyway, I just meant to remark that your explanation of branching into various histories only works if the ‘internal’ world is really completely decoupled from the ‘external’ (deterministic) world. Which it can’t be because if it were there was no branching in the first place. Whether Lara’s consciousness would be able to keep up with it or not, in the presence of a player saving her that is not decoupled from the ‘internal’ world, it would be possible for her to figure out a quite weird timeline where she’s killed, reanimated, goes back, tries again, and again, and again. The reason being that the information saved on disk lacks information and can’t be used to fully determine her future. So. I guess I’d agree with Matt that it’s more a hidden variables scenario.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-24")[#strong[#text("Tomb Raider Quantum Mechanics « The truth makes me fret.")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2007")]

#text("[…] Raider Quantum Mechanics Terry Tao explains QM with a Tomb Raider […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/806194c92c48a3add2072f867b5b336d1dfa20267634a09ce0582022f7b19ae4-80ebb535b4c0e9064227599675391f2cab3164333cfacb57058de20c7259258e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mason Porter")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-25")[#strong[#text("Mason Porter")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2007")])]

#text("Mathematicians should never give up video games. :) Among other things, they can provide good fodder for allusions in ")#emph[#text("Notices")]#text(" articles. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0ba5e9f704716da6c6c03df8a44aa256d0933fa054841feb9deae97e27eeece-cce5119b6810676ce1f73e00e2ecfa911077c241ddb483bf5cc08467cc22927a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kea")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-26")[#strong[#text("Kea")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2007")])]

#text("So I guess this comes under the heading of ")#emph[#text("related material")]#text(", which begs the question of exactly ")#emph[#text("how")]#text(" it is related to your research.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f2feb7825a5d94977138e6b9bfe6d63b46116a4c3877a2dfbed01cd4144cef4-89b76ebd127c9de48902b7ea9a9c80092152607276889162f04062654b7dc7c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Thomas")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-27")[#strong[#text("Andrew Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2007")])]

#text("A interesting article, but it didn’t really ring true for me. I felt you were trying to shoe-horn a Many Worlds interpretation into a video game analogy but the analogy just wasn’t there (corpses don’t “pile-up” each time you pass through the game, and video game physics are classical, not non-classical as you suggest).")

#text("I don’t subscripe to Many Worlds at all. How do you feel about decoherence? I think your comparison to Schrodinger’s cat and the whole Many Worlds thing doesn’t reflect the latest ideas of decoherence at the microscopic level:")

#link("http://physicsweb.org/articles/world/13/8/3")[#text("http://physicsweb.org/articles/world/13/8/3")]

#text("Your statement: “Nevertheless, by studying the statistical behaviour of large numbers of microscopic objects we can indirectly infer their quantum nature via experiment and theoretical reasoning.” Er, that’s news to me! You can see intereference effects in – say – the double slit experiment but I can’t think of any other macroscopic experiment where you can view quantum effects. Surely that’s the whole point of the classical model? I think you should elaborate on this.")

#text("There’s plenty of other work in this area. I run my own site on spacetime and quantum mechanics in a computer-simulated world:")

#link("http://www.ipod.org.uk/reality/reality_big_brother.asp")[#text("http://www.ipod.org.uk/reality/reality_big_brother.asp")]

#text("Also see the Simulism Wiki:")

#link("http://www.simulism.org/Simulism_Home")[#text("http://www.simulism.org/Simulism_Home")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f2feb7825a5d94977138e6b9bfe6d63b46116a4c3877a2dfbed01cd4144cef4-89b76ebd127c9de48902b7ea9a9c80092152607276889162f04062654b7dc7c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Thomas")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-28")[#strong[#text("Andrew Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2007")])]

#text("Just to add I think I’d agree more with Matt Leifer’s comment above that the video game simulation more closely resembles “a nonlocal hidden variable theory in the vein of Bohmian mechanics”. The simulated beings do not get to see the hidden variables, which would be represented by the inner workings of the computer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af7bc04aedb8ffe52341d781a86b60640cdcd21cb2c6a4518286deeaad54db58-c50c5f3ee6da8e4e2eb458d6635cb0c40b4688349d05b891f35ef4f9eeb6b93c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Captain Slack")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-29")[#strong[#text("Captain Slack")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2007")])]

#text("You learn something new every day. Until I read this article (here via ")#link("http://theweaselking.livejournal.com/2251485.html")[#text("The Weasel King")]#text("), I totally thought ")#link("http://z-gryphon.livejournal.com")[#text("Benjamin Hutchins")]#text(" invented Natla for ")#link("http://www.eyrie.net/NXE/")[#text("Neon Exodus Evangelion")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-31")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2007")])]

#text("Regarding the various interpretations possible for this Tomb Raider analogy (ranging from a completely classical interpretation in the external universe, to various non-classical or non-local interpretations within the game universe), it occurred to me that perhaps the QM interpretation that this analogy is closest to is the sum-over-histories model of Feynman, except that the sum operation is replaced by a non-commutative (and also nonlinear) one: past games affect the future ones via the corpse mechanic, but not vice versa. The non-commutativity and nonlinearity serve in some sense to compensate for the lack of a complex phase in this model, so that one can generate non-classical effects which are similar (though not quite identical) to those generated by quantum mechanics.")

#text("Of course, from a purely empirical point of view there is no distinction between the various equivalent interpretations so long as they predict the outcome of experimental data (which in our model would be the survival probabilities of various Tomb Raider levels) correctly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-32")[#strong[#text("Yan Feng » Quantum mechanics and Tomb Raider")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2007")]

#text("[…] just started a blog at wordpress.com. In a recent post, he drawed an analogy between computer game Tomb Raider and Quantum mechanics. Very […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-33")[#strong[#text("Pseudo-Polymath » Blog Archive » A Blog of Note")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2007")]

#text("[…] on a possible philosophical way to interpret quantum machanics classically take a gander at this post (read the comments […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-34")[#strong[#text("Digital Meadows » Blog Archive » Meccanica quantistica e Tomb Raider")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2007")]

#text("[…] Cosa si ottiene mescolando meccanica quantistica e Lara Croft? Un post (invero un po’ lungo) che cerca di spiegare in maniera comprensibile alcune teorie fisiche particolarmente oscure. Fatta la tara alle inevitabili imprecisioni e semplificazioni (di cui io, visto che non so niente di quantistica, sono comunque totalmente inconsapevole :D) resta un post estremamente stimolante: Quantum mechanics and Tomb Raider. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-35")[#strong[#text("its about time» Blog Archive » links for 2007-02-28")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2007")]

#text("[…] Quantum mechanics and Tomb Raider A lucid expanation, I love it:) (tags: quantum tombraider fun clear science) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/49064756cfcae809f407866048055831f1ceffa4b4e76cfef45dd38cc21a692a-72812eebf5c7aad6bfba0aac6421b99917360170d1672fb062d4da9b2dd51743.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petenello")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-36")[#strong[#text("petenello")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2007")])]

#text("Imagine a superposition of two quantum events. Event A: a slow moving quantum particle hits a bomb at time t1 (and Lara dies at time t1). Orthogonal event B: the slow moving quantum particle does not hit the bomb at time t1 (and Lara does not die at time t1). In general we’ll have a superposition of both situations. The interesting point is that, at time t1 +")#linebreak()#text(" epsylon, Lara knows that the other Lara already died. She does not experience any effects from the other state at all, but she can go there,")#linebreak()#text(" to find ‘her’ corpse. You do not need to ‘save’ anything, necessarily.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec5f78731edc201d99268e7ee5bebd4048b4ac34c2179a7eaef3942d18742858-f9923df6c91dc1e48da7945d10b89b1991a00ed102e3db0c701993c9edb15aac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Leifer")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-48")[#strong[#text("Matthew Leifer")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2007")])]

#text("I don’t agree about the Feynman path integral “interpretation” because it is not really an interpretation at all, just an incredibly useful calculational technique that physicists often read far too much into. To qualify as an interpretation, you have to give me a concrete statement about what things exist in reality, how measurement outcomes are accounted for, etc. Feynman doesn’t do this, and is notably adamant that his formalism shouldn’t be thought of in this way.")

#text("On the other hand, your tomb raider analogy does include Laras who are in some definite state in some definite tomb. Quantum mechanics does not include such things at the operational level, i.e. it gives no account of what is going on in reality in between measurements. In tomb raider, this would be like refusing to make any statements about whether or not any Lara exists in any given tomb until the scientist has performed her experiment. So long as you make the same experimental predictions for the scientist, this is the minimal account of the tomb raider scenario that you could give, and would be compatible with a variety of different interpretations. Since you do have definite Laras the situation is not like an operational view of quantum theory and it must be more akin to picking one interpretation or another. I still think de Broglie-Bohm is closer, but the difference of opinion may be more due to ambiguities in how to map the tomb raider analogy to quantum theory than anything deeper.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d998fec896d385414daf782efdd4ed3cadf70773d81f69020a18908b80bee13-fdf63d67517754ec99d9fdb0f6cf0102d6b9bf8db8847eae311c790d093b78fa.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-81")[#strong[#text("Mike")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2007")])]

#text("The cartoon “Reboot” used to play on the dual universe concept. The story took the viewpoint of anthropomorphized electronic elements of the computer. These elements had their own lives, but when a game began (descended from the sky in a great black block) the main characters were transformed into game elements and had to defeat the User (who was mythologized) or perish.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fce2a046ff28f2040194d26253cc68a47e65d5e426dbaac2dd5d57487ec928c0-18f9db63e5fabbb79e0fc83b19582ab26c62496a8f4c4f447641943fae1453c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kashif Javed")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-141")[#strong[#text("Kashif Javed")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2007")])]

#text("hi!")

#text("So I guess this comes under the heading of related material, which begs the question of exactly how it is related to your research.")#linebreak()#text(" ")#link("http://www.expertsitsolutions.com")[#text("http://www.expertsitsolutions.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-155")[#strong[#text("Imagine If Quantum Mechanics Ceases To Be So Esoteric? at Orbit Change Conversations")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2007")]

#text("[…] brings me to Terence Tao’s insightful post on “Quantum Mechanics and Tomb Raider”. It uses a modified Tomb Raider computer game to describe many aspects of QM: the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-227")[#strong[#text("selling waves » Blog Archive » links for 2007-04-01")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2007")]

#text("[…] Quantum mechanics and Tomb Raider Terence Tao again: “In trying to come up with a classical conceptual model in which to capture these non-classical phenomena, we eventually hit upon using the idea of using computer games as an analogy.” (tags: math quantum_mechanics tao tomb_raider mathematics physics science) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-401")[#strong[#text("Chui’s counterpoint » Blog Archive » Parallel Universes and Lara Croft")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2007")]

#text("[…] Tao explains how parallel universes and quantum mechanics can be possible by way of Tomb Raider. In trying to come up with a classical conceptual model in which to capture these non-classical pheno…. The exact choice of game is not terribly important, but let us pick Tomb Raider – a popular game […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-410")[#strong[#text("Why is many-worlds winning the foundations debate? « Quantum Quandaries")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2007")]

#text("[…] April 11, 2007 at 11:47 am | In Quantum, Philosophy, Uncategorized | Almost every time the foundations of quantum theory are mentioned in another science blog, the comments contain […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bb1858095beaaa5221f7ab3a9210f1b2c88becf9e5bbea8178a478229421821-f7b25f2cd42b30204ee403c470fada57e6bae5f0f54597a8a32fb39cef3d79c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aston")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-7304")[#strong[#text("Aston")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2007")])]

#text("nice post,I like TR")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d21f6bfe0b4f2a376284de0058014ce7a9047bad5168126a3b8a62898371da20-e37e104564f0106c0f85961bd35f4caf9ee7f1ceda36b48dd0331a527f302ad0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of estranged2")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-8094")[#strong[#text("estranged2")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2007")])]

#text("The universe inside the game is still deterministic, because the reasons for Lara’s behaviour come externally. You cannot isolate the videogame universe, because the input is external, Lara doesn’t take the decisions herself – the reasons for her behaviour lie outside. And the external reasons for her actions change based on the previous external experiences. I don’t see how that escapes determinism – the determinism just comes from outside and cannot be cut off and ignored from the system.")

#text("If the game world was really an isolated simulation without player input, things would happen like that:")

#text("1) Lara dies")#linebreak()#text(" 2) The world is destroyed and rebuild again from scratch (loading)")#linebreak()#text(" 3) 100% accurate copy of Lara and 100% accurate copy of her environment at the moment of saving is created again")#linebreak()#text(" 3) Lara starts with the same memories she had in the “save” state, makes the same mistake, dies in exactly the same way.")

#text("– Another option is if Lara’s copy (clone) had memories from her previous deaths / realities – then every time the world loads the new Lara would survive better, but that’s determinism too, based on the previous realities.")

#text("Finally, if you insist, you could throw in “chance” that distorts Lara’s logic and makes her act differently every time, but since this “chance” is just another bunch of reasons and rules, coded in the program, that’s deterministic too.")

#text("So where is the fault in my logic? I’m just an average Joe and never managed to understand this “non-determinism” stuff all the math and physic guys are talking about.")#linebreak()#text(" In all the cases where you say that there’s no determinism you’re just cutting off rules from the system and isolating it from things that it depends from.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-8098")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2007")])]

#text("Dear estranged2,")

#text("You are correct that the Tomb Raider game is deterministic if viewed from the external universe, and Lara’s multiple “lives” are treated as separate ontological entities. Similarly, quantum mechanics is deterministic if we view physical objects (including ourselves) as wavefunctions (in particular, they can be in superpositions of multiple states), and if we take a similarly “external” viewpoint of the universe – a “God’s eye view”, if you wish. In short, if you are comfortable with Lara and Schrodinger’s cat both being a superposition of the alive state and dead state at a given point in “internal time”, then you can have determinism.")

#text("The indeterminism only comes in when one tries to take a more subjective, internal viewpoint, and if we make some ontological assumptions which look plausible from this internal view but are inconsistent with the external view. Such assumptions are implicit when posing questions such as “will Lara survive this tomb?” or “is this cat alive?”. In the Tomb Raider analogy, this means that we try to take Lara’s point of view (actually, taking Jacqueline’s point of view would be more appropriate; Lara is the analogue of an elementary particle in our universe, whereas Jacqueline is the analogue of an observer). From Lara or Jacqueline’s perspective, there is no direct evidence of Lara having alternate lives (other than weird skeletons, which Jacqueline never sees anyway), and so it would be reasonable to make the classical assumption that Lara has just a single connected lifespan. One can make this assumption, but only at the cost of introducing indeterminism and other phenomena analogous to “quantum weirdness”.")

#text("Similarly, in our own universe, we can have determinism as long as we accept that all objects, including ourselves, actually exist as a superposition of multiple states, with each state of ourselves only perceiving a portion of the universe and of our bodies (or more precisely, our selves are entangled with the universe and our bodies in a non-trivial way). It is only when we insist on a classical perspective, in which there is only one classical self and only one classical universe, that we are forced to admit indeterminism (or hidden variables, which lead to some further issues such as non-locality).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d21f6bfe0b4f2a376284de0058014ce7a9047bad5168126a3b8a62898371da20-e37e104564f0106c0f85961bd35f4caf9ee7f1ceda36b48dd0331a527f302ad0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of estranged2")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-8112")[#strong[#text("estranged2")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2007")])]

#text("I see now. Thank you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/adc52df1c9733efc737c527b26b366ad93ae810673ed3b5f9639d2f570668ebb-ec2b03d74bdfd8e9f3bc4a70b3af489f06e234db1589cead6307d9fd0568a18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DavidTheAtheist")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-8245")[#strong[#text("DavidTheAtheist")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2007")])]

#text("Hmmm. Interesting")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf445dd3ded972a5d1b62126dac2900bf47db6c85c39b95626f92b945e4f092-821d2a67ec2aa6fd2150e7112d80a9cf9bad4da7b90b8dab1f324d9a6a89f5c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-8351")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2007")])]

#text("What, if anything, can we conclude from the Tomb Raider parable to support, refute, or design experiments to test “from within” the notion that we probably exist in a simulation run by dilute (circa 1 light years between particles) electron-positron ambiplasma beings 10^100 years from now, after all matter has tunneled into black holes, which have all Hawking-evaporated? I discussed this at length, with citations to Freeman Dyson and others, in:")

#text("“Human Destiny and the End of Time” [Quantum, No.39, Winter 1991/1992, Thrust Publications, 8217 Langport Terrace, Gaithersburg, MD 20877; ISSN 0198-6686")

#text("Prof. Greg Benford quoted heavily from this in his Galactic Core novels. Charles Stross is very pleased to announce the release on the web — in honor of International pixel-stained technopeasant day — of MISSILE GAP, which is shortlisted for the Locus readers’ award for best novella this year. It deals with the Simulation issue in a very clever and well-plotted way: ")#link("http://subterraneanpress.com/index.php/magazine/spring2007/fiction-missile-gap-by-charles-stross/")[#text("http://subterraneanpress.com/index.php/magazine/spring2007/fiction-missile-gap-by-charles-stross/")]#text(" see also discussion of it on his bloig here: ")#link("http://www.antipope.org/charlie/blog-static/2007/04/missile_gap.html#comments")[#text("http://www.antipope.org/charlie/blog-static/2007/04/missile_gap.html#comments")]

#text("Years later, as I mentioned on some other threads such as those of Scott Aaronson, Nick Bostrom (now at Oxford) rediscovered the concept and got great PR about it, including the front page of a recent New York Times Science section, albeit he is less careful in his citations than is typical in the Mathematics or Physics community.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf92693c2f6ce486be9fffcd101f66975a51cd63319ab62c9e5b057cc79750ea-452f6feb4d8eb235dde5afc0474412889c339b27b214e9710c72f085ebcd0718.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nacho")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-13915")[#strong[#text("Nacho")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2007")])]

#text("I don’t think you can make the analogy, because, in the case of the game (Tomb Raider) is not as simple as to say “if she died four times and the fifth time around she got out alive”, because in the case of a game where the character is manipulated by a higher being (the player), the player is aware of all the traps and deadly alternatives.")#linebreak()#text(" Lara Number Five doesen’t make alive with the same level of awareness than Lara Number One, because she know knows 4 ways she could die.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-13960")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2007")])]

#text("Dear Nacho,")

#text("In the variant of Tomb Raider that I am using as a thought experiment here, Lara has advanced AI capability, to the point where the player does not actually need to manipulate her actions (the player’s role, in fact, is largely limited to observing, saving, and restoring the game). This AI does not carry over any knowledge from previous lives, but still feels their presence due to the corpse mechanic, which is the analogue of quantum interference effects for this discussion. Lara survives the fifth attempt at the deadly trap not because of knowledge of the four failed attempts, but because of the presence of the four corpses which provides enough “constructive interference” to successfully survive the trap. The situation is somewhat analogous to how an electron in an atom can only exist in certain orbital shells, in which the net effect of quantum interference is constructive rather than destructive.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf445dd3ded972a5d1b62126dac2900bf47db6c85c39b95626f92b945e4f092-821d2a67ec2aa6fd2150e7112d80a9cf9bad4da7b90b8dab1f324d9a6a89f5c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-13989")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2007")])]

#text("Before role playing games and computer games were a major art form, this notion (survival via seeing corpses of earlier instantiations of yourself) was explored in prose.")

#text("Author Algis Budrys")#linebreak()#text(" Country United States")#linebreak()#text(" Language English")#linebreak()#text(" Genre(s) Science fiction novel")#linebreak()#text(" Publisher Gold Medal Books")#linebreak()#text(" Publication date 1960")#linebreak()#text(" Media type Print (Paperback)")#linebreak()#text(" Pages 176 pp")

#text("“Rogue Moon is largely about the discovery and investigation of a large alien artifact found on the surface of the Moon. The object eventually kills its explorers in various ways, but their deaths slowly reveal the funhouse-like course humans must take in moving through it…. [characters] weave their way through a series of bizarre landscapes containing death traps. The forms these take, and the strange actions necessary to avoid them, are similar to those found in a modern video game. Emerging from the other side, they face the final hurdle. Hawks tells Barker that they cannot return. The equipment on the Moon is too crude to transmit a man back safely, and even if it were possible, there are already identical people living their lives. All the men working on the Moon are duplicates, mostly Navy men, all volunteers…”")

#link("http://en.wikipedia.org/wiki/Rogue_Moon")[#text("http://en.wikipedia.org/wiki/Rogue_Moon")]

#text("I’ve had the pleasure of discussing this at length several times with Algis “AJ” Budrys, one of the leading author, editor, critics of Science Fiction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fz")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-20176")[#strong[#text("fz")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2007")])]

#text("Impressing post! How did you come to explain QM by TR like this, Tao?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-24741")[#strong[#text("blacksundae » Blog Archive » Quantum mechanics and Tomb Raider")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2008")]

#text("[…] Terence Tao: Imagine first that Lara is about to navigate a tricky rolling boulder puzzle, when she hears a distant rumbling sound – the sound of her player saving her game to disk. From the perspective of the player, what happens next is the following: Lara navigates the boulder puzzle but fails, being killed in the process; then the player restores the game from the save point and then Lara successfully makes it through the boulder puzzle. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e093c233e3b4fd9212414ffdc0d05387015073c746c4571d57b8c51214acf03c-5d88fa03311d8419597a0e9087ae18cdffbacff798cecbf2f817831c878cbfa6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jian")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-24783")[#strong[#text("jian")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2008")])]

#text("Why is Lara considered killed at the save point? Is it just a part of the feature of the game? I have never played that game myself. Or did I just miss something? Can someone tell me?")

#text("Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2998bcffc8177489c8ec6d6a7626fb64df094597326e49411769be46619937c-4efccc0eb0bcc79e40a4daa24a2011b51de3cdabf7598e0fec0d7b5ca610596d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JC")]], [#link("https://terrytao.wordpress.com/2007/02/26/quantum-mechanics-and-tomb-raider/comment-page-1/#comment-25683")[#strong[#text("JC")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("This player has made a video of a bunch of runs of a version of Super Mario World, stacking them together to show the branching (and he makes reference to the Many Worlds interpretation in his writeup as well):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/")[#text("Open question: deterministic UUP matrices")]
]
]
