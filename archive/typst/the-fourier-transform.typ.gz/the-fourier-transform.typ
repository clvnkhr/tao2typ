// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/
// Converted to Typst by tao2typ: "2026-10-14T07:19:46.323866+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245C, Notes 2: The Fourier transform", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245C, Notes 2: The Fourier transform")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 April 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("In these notes we lay out the basic theory of the ")#link("http://en.wikipedia.org/wiki/Fourier_transform")[#text("Fourier transform")]#text(", which is of course the most fundamental tool in ")#link("http://en.wikipedia.org/wiki/Harmonic_analysis")[#text("harmonic analysis")]#text(" and also of major importance in related fields (functional analysis, complex analysis, PDE, number theory, additive combinatorics, representation theory, signal processing, etc.). The Fourier transform, in conjunction with the ")#link("http://en.wikipedia.org/wiki/Fourier_inversion_theorem")[#text("Fourier inversion formula")]#text(", allows one to take essentially arbitrary (complex-valued) functions on a group ")#mi("{G}")#text(" (or more generally, a space ")#mi("{X}")#text(" that ")#mi("{G}")#text(" acts on, e.g. a ")#link("http://en.wikipedia.org/wiki/Homogeneous_space")[#text("homogeneous space")]#text(" ")#mi("{G/H}")#text("), and decompose them as a (discrete or continuous) superposition of much more symmetric functions on the domain, such as ")#link("http://en.wikipedia.org/wiki/Character_(mathematics)")[#text("characters")]#text(" ")#mi("{\\chi: G \\rightarrow S^1}")#text("; the precise superposition is given by ")#emph[#text("Fourier coefficients")]#text(" ")#mi("{\\hat f(\\xi)}")#text(", which take values in some dual object such as the ")#link("http://en.wikipedia.org/wiki/Pontryagin_duality")[#text("Pontryagin dual")]#text(" ")#mi("{\\hat G}")#text(" of ")#mi("{G}")#text(". Characters behave in a very simple manner with respect to translation (indeed, they are eigenfunctions of the translation action), and so the Fourier transform tends to simplify any mathematical problem which enjoys a translation invariance symmetry (or an approximation to such a symmetry), and is somehow “linear” (i.e. it interacts nicely with superpositions). In particular, Fourier analytic methods are particularly useful for studying operations such as convolution ")#mi("{f, g \\mapsto f*g}")#text(" and set-theoretic addition ")#mi("{A, B \\mapsto A+B}")#text(", or the closely related problem of counting solutions to additive problems such as ")#mi("{x = a_1 + a_2 + a_3}")#text(" or ")#mi("{x = a_1 - a_2}")#text(", where ")#mi("{a_1, a_2, a_3}")#text(" are constrained to lie in specific sets ")#mi("{A_1, A_2, A_3}")#text(". The Fourier transform is also a particularly powerful tool for solving constant-coefficient linear ODE and PDE (because of the translation invariance), and can also approximately solve some variable-coefficient (or slightly non-linear) equations if the coefficients vary smoothly enough and the nonlinear terms are sufficiently tame.")

#text("The Fourier transform ")#mi("{\\hat f(\\xi)}")#text(" also provides an important new way of looking at a function ")#mi("{f(x)}")#text(", as it highlights the distribution of ")#mi("{f}")#text(" in ")#emph[#text("frequency space")]#text(" (the domain of the frequency variable ")#mi("{\\xi}")#text(") rather than ")#emph[#text("physical space")]#text(" (the domain of the physical variable ")#mi("{x}")#text("). A given property of ")#mi("{f}")#text(" in the physical domain may be transformed to a rather different-looking property of ")#mi("{\\hat f}")#text(" in the frequency domain. For instance:")

#list(
[#text("Smoothness of ")#mi("{f}")#text(" in the physical domain corresponds to decay of ")#mi("{\\hat f}")#text(" in the Fourier domain, and conversely. (More generally, fine scale properties of ")#mi("{f}")#text(" tend to manifest themselves as coarse scale properties of ")#mi("{\\hat f}")#text(", and conversely.)")],
[#text("Convolution in the physical domain corresponds to pointwise multiplication in the Fourier domain, and conversely.")],
[#text("Constant coefficient differential operators such as ")#mi("{d/dx}")#text(" in the physical domain corresponds to multiplication by polynomials such as ")#mi("{2\\pi i \\xi}")#text(" in the Fourier domain, and conversely.")],
[#text("More generally, translation invariant operators in the physical domain correspond to multiplication by symbols in the Fourier domain, and conversely.")],
[#text("Rescaling in the physical domain by an invertible linear transformation corresponds to an inverse (adjoint) rescaling in the Fourier domain.")],
[#text("Restriction to a subspace (or subgroup) in the physical domain corresponds to projection to the dual quotient space (or quotient group) in the Fourier domain, and conversely.")],
[#text("Frequency modulation in the physical domain corresponds to translation in the frequency domain, and conversely.")]
)

#text("(We will make these statements more precise below.)")

#text("On the other hand, some operations in the physical domain remain essentially unchanged in the Fourier domain. Most importantly, the ")#mi("{L^2}")#text(" norm (or ")#emph[#text("energy")]#text(") of a function ")#mi("{f}")#text(" is the same as that of its Fourier transform, and more generally the inner product ")#mi("{\\langle f, g \\rangle}")#text(" of two functions ")#mi("{f}")#text(" is the same as that of their Fourier transforms. Indeed, the Fourier transform is a unitary operator on ")#mi("{L^2}")#text(" (a fact which is variously known as the ")#emph[#text("Plancherel theorem")]#text(" or the ")#emph[#text("Parseval identity")]#text("). This makes it easier to pass back and forth between the physical domain and frequency domain, so that one can combine techniques that are easy to execute in the physical domain with other techniques that are easy to execute in the frequency domain. (In fact, one can combine the physical and frequency domains together into a product domain known as ")#link("http://en.wikipedia.org/wiki/Phase_space")[#text("phase space")]#text(", and there are entire fields of mathematics (e.g. microlocal analysis, geometric quantisation, time-frequency analysis) devoted to performing analysis on these sorts of spaces directly, but this is beyond the scope of this course.)")

#text("In these notes, we briefly discuss the general theory of the Fourier transform, but will mainly focus on the two classical domains for Fourier analysis: the torus ")#mi("{{\\Bbb T}^d := ({\\bf R}/{\\bf Z})^d}")#text(", and the Euclidean space ")#mi("{{\\bf R}^d}")#text(". For these domains one has the advantage of being able to perform very explicit algebraic calculations, involving concrete functions such as plane waves ")#mi("{x \\mapsto e^{2\\pi i x \\cdot \\xi}}")#text(" or Gaussians ")#tao-math("{x \\mapsto A^{d/2} e^{-\\pi A \\left|x\\right|^2}}", block: false)#text(".")

#metadata(none) <tao-895e8a51527dbcc1c06f>

#strong[#text(" — 1. Generalities — ")]

#text("Let us begin with some generalities. An ")#link("http://en.wikipedia.org/wiki/Topological_group")[#text("abelian topological group")]#text(" is an abelian group ")#mi("{G = (G,+)}")#text(" with a topological structure, such that the group operations of addition ")#mi("{+: G \\times G \\rightarrow G}")#text(" and negation ")#mi("{-: G \\rightarrow G}")#text(" are continuous. (One can of course also consider abelian multiplicative groups ")#mi("{G = (G,\\cdot)}")#text(", but to fix the notation we shall restrict attention to additive groups.) For technical reasons (and in particular, in order to apply many of the results from the previous quarter) it is convenient to restrict attention to abelian topological groups which are ")#link("http://en.wikipedia.org/wiki/Locally_compact_Hausdorff_space")[#text("locally compact Hausdorff")]#text(" (LCH); these are known as ")#link("http://en.wikipedia.org/wiki/Locally_compact_group")[#text("locally compact abelian (LCA) groups")]#text(".")

#text("Some basic examples of locally compact abelian groups are:")

#list(
[#text("Finite additive groups (with the discrete topology), such as cyclic groups ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(".")],
[#text("Finitely generated additive groups (with the discrete topology), such as the standard lattice ")#mi("{{\\bf Z}^d}")#text(".")],
[#text("Tori, such as the standard ")#mi("{d}")#text("-dimensional torus ")#mi("{{\\Bbb T}^d :=({\\bf R}/{\\bf Z})^d}")#text(" with the standard topology.")],
[#text("Euclidean spaces, such the standard ")#mi("{d}")#text("-dimensional Euclidean space ")#mi("{{\\bf R}^d}")#text(" (with the standard topology, of course).")],
[#text("The rationals ")#mi("{{\\bf Q}}")#text(" are ")#emph[#text("not")]#text(" locally compact with the usual topology; but if one uses the discrete topology instead, one recovers an LCA group.")],
[#text("Another example of an LCA group, of importance in number theory, is the ")#link("http://en.wikipedia.org/wiki/Adele_ring")[#text("adele ring")]#text(" ")#mi("{{\\Bbb A}}")#text(", discussed in ")#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/")[#text("this earlier blog post")]#text(".")]
)

#text("Thus we see that locally compact abelian groups can be either discrete or continuous, and either compact or non-compact; all four combinations of these cases are of importance. The topology of course generates a Borel ")#mi("{\\sigma}")#text("-algebra in the usual fashion, as well as a space ")#mi("{C_c(G)}")#text(" of continuous, compactly supported complex-valued functions. There is a translation action ")#mi("{x \\mapsto \\tau_x}")#text(" of ")#mi("{G}")#text(" on ")#mi("{C_c(G)}")#text(", where for every ")#mi("{x \\in G}")#text(", ")#mi("{\\tau_x: C_c(G) \\rightarrow C_c(G)}")#text(" is the translation operation")

#mi("\\displaystyle \\tau_x f(y) := f(y-x).")

#text("LCA groups need not be ")#mi("{\\sigma}")#text("-compact (think of the free abelian group on uncountably many generators, with the discrete topology), but one has the following useful substitute:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" ")#metadata(none) <tao-ff368f3f2894bbcda536>#text(" Show that every LCA group ")#mi("{G}")#text(" contains a ")#mi("{\\sigma}")#text("-compact open subgroup ")#mi("{H}")#text(", and in particular is the disjoint union of ")#mi("{\\sigma}")#text("-compact sets. (")#emph[#text("Hint:")]#text(" Take a compact symmetric neighbourhood ")#mi("{K}")#text(" of the identity, and consider the group ")#mi("{H}")#text(" generated by this neighbourhood.)")
]

#text("An important notion for us will be that of a ")#emph[#text("Haar measure")]#text(": a ")#link("http://en.wikipedia.org/wiki/Radon_measure")[#text("Radon measure")]#text(" ")#mi("{\\mu}")#text(" on ")#mi("{G}")#text(" which is ")#emph[#text("translation-invariant")]#text(" (i.e. ")#mi("{\\mu(E+x) = \\mu(E)}")#text(" for all Borel sets ")#mi("{E \\subset G}")#text(" and all ")#mi("{x \\in G}")#text(", where ")#mi("{E+x := \\{ y+x: y \\in E \\}}")#text(" is the translation of ")#mi("{E}")#text(" by ")#mi("{x}")#text("). From this and the definition of integration we see that integration ")#mi("{f \\mapsto \\int_G f\\ d\\mu}")#text(" against a Haar measure (an operation known as the ")#emph[#text("Haar integral")]#text(") is also translation-invariant, thus ")#metadata(none) <tao-2b25b7eb660b45d65866>

#mi("\\displaystyle \\int_G f(y-x)\\ d\\mu(y) = \\int_G f(y)\\ d\\mu(y) \\ \\ \\ \\ \\ (1)")

#text("or equivalently ")#metadata(none) <tao-52333bde0deedeb616be>

#mi("\\displaystyle \\int_G \\tau_x f\\ d\\mu = \\int_G f\\ d\\mu \\ \\ \\ \\ \\ (2)")

#text("for all ")#mi("{f \\in C_c(G)}")#text(" and ")#mi("{x \\in G}")#text(". The trivial measure ")#mi("{0}")#text(" is of course a Haar measure; all other Haar measures are called ")#emph[#text("non-trivial")]#text(".")

#text("Let us note some non-trivial Haar measures in the four basic examples of locally compact abelian groups:")

#list(
[#text("For a finite additive group ")#mi("{G}")#text(", one can take either ")#link("http://en.wikipedia.org/wiki/Counting_measure")[#text("counting measure")]#text(" ")#mi("{\\#}")#text(" or normalised counting measure ")#mi("{\\#/\\#(G)}")#text(" as a Haar measure. (The former measure emphasises the discrete nature of ")#mi("{G}")#text("; the latter measure emphasises the compact nature of ")#mi("{G}")#text(".)")],
[#text("For finitely generated additive groups such as ")#mi("{{\\bf Z}^d}")#text(", counting measure ")#mi("{\\#}")#text(" is a Haar measure.")],
[#text("For the standard torus ")#mi("{({\\bf R}/{\\bf Z})^d}")#text(", one can obtain a Haar measure by identifying this torus with ")#mi("{[0,1)^d}")#text(" in the usual manner and then taking Lebesgue measure on the latter space. This Haar measure is a probability measure.")],
[#text("For the standard Euclidean space ")#mi("{{\\bf R}^d}")#text(", Lebesgue measure is a Haar measure.")]
)

#text("Of course, any non-negative constant multiple of a Haar measure is again a Haar measure. The converse is also true:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2 (Uniqueness of Haar measure up to scalars)")]#text(" Let ")#mi("{\\mu, \\nu}")#text(" be two non-trivial Haar measures on a locally compact abelian group ")#mi("{G}")#text(". Show that ")#mi("{\\mu, \\nu}")#text(" are scalar multiples of each other, i.e. there exists a constant ")#mi("{c>0}")#text(" such that ")#mi("{\\nu=c\\mu}")#text(". (Hint: for any ")#mi("{f, g \\in C_c(G)}")#text(", compute the quantity ")#mi("{\\int_G \\int_G g(y) f(x+y)\\ d\\mu(x) d\\nu(y)}")#text(" in two different ways.)")
]

#text("The above argument also implies a useful symmetry property of Haar measures:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Haar measures are symmetric)")]#text(" Let ")#mi("{\\mu}")#text(" be a Haar measure on a locally compact abelian group ")#mi("{G}")#text(". Show that ")#mi("{\\int_G f(-x)\\ d\\mu(x) = \\int_G f(x)\\ d\\mu(x)}")#text(" for all ")#mi("{f \\in C_c(G)}")#text(". (Hint: expand ")#mi("{\\int_G \\int_G f(y) f(x+y)\\ d\\mu(x) d\\mu(y)}")#text(" in two different ways.) Conclude that Haar measures on LCA groups are ")#emph[#text("symmetric")]#text(" in the sense that ")#mi("{\\mu(-E) = \\mu(E)}")#text(" for all measurable ")#mi("{E}")#text(", where ")#mi("{-E := \\{ -x: x \\in E \\}}")#text(" is the reflection of ")#mi("{E}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4 (Open sets have positive measure)")]#text(" Let ")#mi("{\\mu}")#text(" be a non-trivial Haar measure on a locally compact abelian group ")#mi("{G}")#text(". Show that ")#mi("{\\mu(U) > 0}")#text(" for any non-empty open set ")#mi("{U}")#text(". Conclude that if ")#mi("{f \\in C_c(G)}")#text(" is non-negative and not identically zero, then ")#mi("{\\int_G f\\ d\\mu > 0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" ")#metadata(none) <tao-30d8f60246df638abb58>#text(" Let ")#mi("{G}")#text(" be an LCA group with non-trivial Haar measure ")#mi("{\\mu}")#text(". Let ")#mi("{\\tilde L^\\infty(G)}")#text(" be the space of equivalence classes of functions ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" such that for every set ")#mi("{K}")#text(" of finite measure, the restriction of ")#mi("{f}")#text(" to ")#mi("{K}")#text(" lies in ")#mi("{L^\\infty(K)}")#text(" with a norm bounded uniformly in ")#mi("{K}")#text(", with two functions in ")#mi("{\\tilde L^\\infty(G)}")#text(" in the same equivalence class if they agree almost everywhere on every set ")#mi("{K}")#text(" of finite measure, and with the ")#mi("{\\tilde L^\\infty(G)}")#text(" norm of ")#mi("{f}")#text(" equal to the supremum of the ")#mi("{L^\\infty(K)}")#text(" norms of the restrictions. (For ")#mi("{\\sigma}")#text("-finite groups ")#mi("{G}")#text(", ")#mi("{\\tilde L^\\infty(G)}")#text(" is identical to ")#mi("{L^\\infty(G)}")#text(", but the two spaces differ slightly in general.) Show that ")#mi("{L^1(G)^*}")#text(" is identifiable with ")#mi("{\\tilde L^\\infty(G)}")#text(". (Unfortunately, ")#mi("{G}")#text(" is not always ")#mi("{\\sigma}")#text("-finite, and so the standard duality theorem from ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("Notes 3 of 245B")]#text(" does not directly apply. However, one can get around this using Exercise ")#link(<tao-ff368f3f2894bbcda536>)[#text("1")]#text(".)")
]

#text("It is a (not entirely trivial) theorem, due to André Weil, that all LCA groups have a non-trivial Haar measure. For discrete groups, one can of course take counting measure as a Haar measure. For compact groups, the result is due to Haar, and one can argue as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6 (Existence of Haar measure, compact case)")]#text(" ")#metadata(none) <tao-c33635072f01e4f83600>#text(" Let ")#mi("{G}")#text(" be a compact metrisable abelian group. For any real-valued ")#mi("{f \\in C_c(G)}")#text(", and any Borel probability measure ")#mi("{\\mu}")#text(" on ")#mi("{G}")#text(", define the ")#emph[#text("oscillation")]#text(" ")#mi("{\\text{osc}_f(\\mu)}")#text(" of ")#mi("{\\mu}")#text(" with respect to ")#mi("{f}")#text(" to be the quantity ")#mi("{\\text{osc}_f(\\mu) := \\sup_{y \\in G} \\int_G \\tau_y f\\ d\\mu(x) - \\inf_{y \\in G} \\int_G \\tau_y f\\ d\\mu(x)}")#text(".")

#list(
[#text("(a) Show that a Borel probability measure ")#mi("{\\mu}")#text(" is a Haar measure if and only if ")#mi("{\\text{osc}_f(\\mu)=0}")#text(" for all ")#mi("{f \\in C_c(G)}")#text(".")],
[#text("(b) If a sequence ")#mi("{\\mu_n}")#text(" of Borel probability measures converges in the vague topology to another Borel probability measure ")#mi("{\\mu}")#text(", show that ")#mi("{\\text{osc}_f(\\mu_n) \\rightarrow \\text{osc}_f(\\mu)}")#text(" for all ")#mi("{f \\in C_c(G)}")#text(".")],
[#text("(c) If ")#mi("{\\mu}")#text(" is a Borel probability measure and ")#mi("{f \\in C_c(G)}")#text(" is such that ")#mi("{\\text{osc}_f(\\mu) > 0}")#text(", show that there exists a Borel probability measure ")#mi("{\\mu^{\\prime}}")#text(" such that ")#mi("{\\text{osc}_f(\\mu^{\\prime}) < \\text{osc}_f(\\mu)}")#text(" and ")#mi("{\\text{osc}_g(\\mu^{\\prime}) \\leq \\text{osc}_g(\\mu)}")#text(" for all ")#mi("{g \\in C_c(G)}")#text(". (")#emph[#text("Hint:")]#text(" take ")#mi("{\\mu^{\\prime}}")#text(" to be the an average of certain translations of ")#mi("{\\mu}")#text(".)")],
[#text("(d) Given any finite number of functions ")#mi("{f_1, \\ldots,f_n \\in C_c(G)}")#text(", show that there exists a Borel probability measure ")#mi("{\\mu}")#text(" such that ")#mi("{\\text{osc}_{f_i}(\\mu)=0}")#text(" for all ")#mi("{i=1,\\ldots,n}")#text(". (")#emph[#text("Hint:")]#text(" Use Prokhorov’s theorem, see Corollary 13 of ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("245B Notes 12")]#text(". Try the ")#mi("{n=1}")#text(" case first.)")],
[#text("(e) Show that there exists a unique Haar probability measure on ")#mi("{G}")#text(". (")#emph[#text("Hint:")]#text(" One can identify each probability measure ")#mi("{\\mu}")#text(" with the element ")#mi("{(\\int_G f\\ d\\mu)_{f \\in C_c(G)}}")#text(" of the product space ")#tao-math("{\\prod_{f \\in C_c(G)} [-\\sup_{x \\in G} \\left|f(x)\\right|, \\sup_{x \\in G} \\left|f(x)\\right|]}", block: false)#text(", which is compact by ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff’s theorem")]#text(". Now use (d) and the ")#link("http://en.wikipedia.org/wiki/Finite_intersection_property")[#text("finite intersection property")]#text(".)")]
)

#text("(The argument can be adapted to the case when ")#mi("{G}")#text(" is not metrisable, but one has to replace the sequential compactness given by Prokhorov’s theorem by the topological compactness given by the Banach-Alaoglu theorem.)")
]

#text("For general LCA groups, the proof is more complicated:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7 (Existence of Haar measure, general case)")]#text(" ")#metadata(none) <tao-b215f4d39327b4937bb4>#text(" Let ")#mi("{G}")#text(" be an LCA group. Let ")#mi("{C_c(G)^+}")#text(" denote the space of non-negative functions ")#mi("{f \\in C_c(G)}")#text(" that are not identically zero. Given two ")#mi("{f,g \\in C_c(G)^+}")#text(", define a ")#emph[#mi("{g}")#text("-cover")]#text(" of ")#mi("{f}")#text(" to be an expression of the form ")#mi("{a_1 \\tau_{x_1} g + \\ldots + a_n \\tau_{x_n} g}")#text(" that pointwise dominates ")#mi("{f}")#text(", where ")#mi("{a_1,\\ldots,a_n}")#text(" are non-negative numbers and ")#mi("{x_1,\\ldots,x_n \\in G}")#text(". Let ")#mi("{(f:g)}")#text(" denote the infimum of the quantity ")#mi("{a_1+\\ldots+a_n}")#text(" for all ")#mi("{g}")#text("-covers of ")#mi("{f}")#text(".")

#list(
[#text("(a) (Finiteness) Show that ")#mi("{0 < (f:g) < +\\infty}")#text(" for all ")#mi("{f,g \\in C_c(G)^+}")#text(".")],
[#text("(b) Let ")#mi("{\\mu}")#text(" is a Haar measure on ")#mi("{G}")#text(". Show that ")#mi("{\\int_G f\\ d\\mu \\leq (f:g) (\\int_G g\\ d\\mu)}")#text(" for all ")#mi("{f,g \\in C_c(G)^+}")#text(". Conversely, for every ")#mi("{f \\in C_c(G)^+}")#text(" and ")#mi("{\\varepsilon > 0}")#text(", and any neighbourhood ")#mi("{U}")#text(" of the identity, show that there exists ")#mi("{g \\in C_c(G)^+}")#text(" supported in ")#mi("{U}")#text(" such that ")#mi("{\\int_G f\\ d\\mu \\geq (f:g) (\\int_G g\\ d\\mu) - \\varepsilon}")#text(". (Hint: ")#mi("{f}")#text(" is uniformly continuous. Take ")#mi("{g}")#text(" to be an approximation to the identity.) Thus Haar integrals are related to certain renormalised versions of the functionals ")#mi("{f \\mapsto (f:g)}")#text("; this observation underlies the strategy for construction of Haar measure in the rest of this exercise.")],
[#text("(c) (Transitivity) Show that ")#mi("{(f:h) \\leq (f:g) (g:h)}")#text(" for all ")#mi("{f,g,h \\in C_c(G)^+}")#text(".")],
[#text("(d) (Translation invariance) Show that ")#mi("{(\\tau_x f:g) = (f:g)}")#text(" for all ")#mi("{f,g \\in C_c(G)^+}")#text(" and ")#mi("{x \\in G}")#text(".")],
[#text("(e) (Sublinearity) Show that ")#mi("{(f+g:h) \\leq (f:h) + (g:h)}")#text(" and ")#mi("{(cf:g) = c(f:g)}")#text(" for all ")#mi("{f,g,h \\in C_c(G)^+}")#text(" and ")#mi("{c>0}")#text(".")],
[#text("(f) (Approximate superadditivity) If ")#mi("{f,g \\in C_c(G)^+}")#text(" and ")#mi("{\\varepsilon > 0}")#text(", show that there exists a neighbourhood ")#mi("{U}")#text(" of the identity such that ")#mi("{(f:h)+(g:h) \\leq (1+\\varepsilon) (f+g:h)}")#text(" whenever ")#mi("{h \\in C_c(G)^+}")#text(" is supported in ")#mi("{U}")#text(". (")#emph[#text("Hint:")]#text(" ")#mi("{f, g, f+g}")#text(" are all uniformly continuous. Take a ")#mi("{h}")#text("-cover of ")#mi("{f+g}")#text(" and multiply the weight ")#mi("{a_i}")#text(" at ")#mi("{x_i}")#text(" by weights such as ")#mi("{f(x_i)/(f(x_i)+g(x_i)-\\varepsilon)}")#text(" and ")#mi("{g(x_i)/(f(x_i)+g(x_i)-\\varepsilon)}")#text(".)")]
)

#text("Next, fix a reference function ")#mi("{f_0 \\in C_c(G)^+}")#text(", and define the functional ")#mi("{I_g: C_c(G)^+ \\rightarrow {\\bf R}^+}")#text(" for all ")#mi("{g \\in C_c(G)^+}")#text(" by the formula ")#mi("{I_g(f) := (f:g) / (f_0:g)}")#text(".")

#list(
[#text("(g) Show that for any fixed ")#mi("{f}")#text(", ")#mi("{I_g(f)}")#text(" ranges in the compact interval ")#mi("{[(f_0:f)^{-1}, (f:f_0)]}")#text("; thus ")#mi("{I_g}")#text(" can be viewed as an element of the product space ")#mi("{\\prod_{f \\in C_c(G)^+} [(f_0:f)^{-1}, (f:f_0)]}")#text(", which is compact by ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff’s theorem")]#text(".")],
[#text("(h) From (d), (e) we have the translation-invariance property ")#mi("{I_g(\\tau_x f) = I_g(f)}")#text(", the homogeneity property ")#mi("{I_g(cf) = c I_g(f)}")#text(", and the sub-additivity property ")#mi("{I_g(f+f^{\\prime}) \\leq I_g(f)+I_g(f^{\\prime})}")#text(" for all ")#mi("{g,f,f^{\\prime} \\in C_c(G)^+}")#text(", ")#mi("{x \\in G}")#text(", and ")#mi("{c>0}")#text("; we also have the normalisation ")#mi("{I_g(f_0)=1}")#text(". Now show that for all ")#mi("{f_1,\\ldots,f_n,f^{\\prime}_1,\\ldots,f^{\\prime}_n \\in C_c(G)^+}")#text(" and ")#mi("{\\varepsilon > 0}")#text(", there exists ")#mi("{g \\in C_c(G)^+}")#text(" such that ")#mi("{I_g(f_i+f^{\\prime}_i) \\geq I_g(f_i)+I_g(f^{\\prime}_i)-\\varepsilon}")#text(" for all ")#mi("{i=1,\\ldots,n}")#text(".")],
[#text("(i) Show that there exists a unique Haar measure ")#mi("{\\mu}")#text(" on ")#mi("{G}")#text(" with ")#mi("{\\mu(f_0)=1}")#text(". (")#emph[#text("Hint:")]#text(" Use (h) and the ")#link("http://en.wikipedia.org/wiki/Finite_intersection_property")[#text("finite intersection property")]#text(" to obtain a translation-invariant positive linear functional on ")#mi("{C_c(G)}")#text(", then use the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem")]#text(".)")]
)
]

#text("Now we come to a fundamental notion, that of a ")#link("http://en.wikipedia.org/wiki/Character_(mathematics)")[#text("character")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 8 (Characters)")]#text(" Let ")#mi("{G}")#text(" be a LCA group. A ")#emph[#text("multiplicative character")]#text(" ")#mi("{\\chi}")#text(" is a continuous function ")#mi("{\\chi: G \\rightarrow S^1}")#text(" to the unit circle ")#tao-math("{S^1 := \\{ z \\in {\\bf C}: \\left|z\\right|=1\\}}", block: false)#text(" which is a homomorphism, i.e. ")#mi("{\\chi(x+y)=\\chi(x) \\chi(y)}")#text(" for all ")#mi("{x,y \\in G}")#text(". An ")#emph[#text("additive character")]#text(" or ")#emph[#text("frequency")]#text(" ")#mi("{\\xi: x \\mapsto \\xi \\cdot x}")#text(" is a continuous function ")#mi("{\\xi: G \\rightarrow {\\bf R}/{\\bf Z}}")#text(" which is a homomorphism, thus ")#mi("{\\xi \\cdot (x+y) = \\xi \\cdot x + \\xi \\cdot y}")#text(" for all ")#mi("{x,y \\in G}")#text(". The set of all frequencies ")#mi("{\\xi}")#text(" is called the ")#emph[#text("Pontryagin dual")]#text(" of ")#mi("{G}")#text(" and is denoted ")#mi("{\\hat G}")#text("; it is clearly an abelian group. A multiplicative character is called ")#emph[#text("non-trivial")]#text(" if it is not the constant function ")#mi("{1}")#text("; an additive character is called ")#emph[#text("non-trivial")]#text(" if it is not the constant function ")#mi("{0}")#text(".")
]

#text("Multiplicative characters and additive characters are clearly related: if ")#mi("{\\xi \\in \\hat G}")#text(" is an additive character, then the function ")#mi("{x \\mapsto e^{2\\pi i \\xi \\cdot x}}")#text(" is a multiplicative character, and conversely every multiplicative character arises uniquely from an additive character in this fashion.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" ")#metadata(none) <tao-4b33669b37ff728c1ec4>#text(" Let ")#mi("{G}")#text(" be an LCA group. We give ")#mi("{\\hat G}")#text(" the topology of local uniform convergence on compact sets, thus the topology on ")#mi("{\\hat G}")#text(" are generated by sets of the form ")#tao-math("{\\{ \\xi \\in \\hat G: \\left|\\xi \\cdot x - \\xi_0 \\cdot x\\right| < \\varepsilon \\text{ for all } x \\in K \\}}", block: false)#text(" for compact ")#mi("{K \\subset G}")#text(", ")#mi("{\\xi_0 \\in \\hat G}")#text(", and ")#mi("{\\varepsilon > 0}")#text(". Show that this turns ")#mi("{\\hat G}")#text(" into an LCA group. (")#emph[#text("Hint:")]#text(" Show that for any neighbourhood ")#mi("{U}")#text(" of the identity in ")#mi("{G}")#text(", the sets ")#mi("{\\{ \\xi \\in \\hat G: \\xi \\cdot x \\in [-\\varepsilon,\\varepsilon] \\text{ for all } x \\in U \\}}")#text(" for ")#mi("{0 < \\varepsilon < 1/4}")#text(" (say) are compact.) Furthermore, if ")#mi("{G}")#text(" is discrete, show that ")#mi("{\\hat G}")#text(" is compact.")
]

#text("The Pontryagin dual can be computed easily for various classical LCA groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" ")#metadata(none) <tao-7bd2606643a99b6b8641>#text(" Let ")#mi("{d \\geq 1}")#text(" be an integer.")

#list(
[#text("(a) Show that the Pontryagin dual ")#mi("{\\widehat{{\\bf Z}^d}}")#text(" of ")#mi("{{\\bf Z}^d}")#text(" is identifiable as an LCA group with ")#mi("{({\\bf R}/{\\bf Z})^d}")#text(", by identifying each ")#mi("{\\xi \\in ({\\bf R}/{\\bf Z})^d}")#text(" with the frequency ")#mi("{x \\mapsto \\xi \\cdot x}")#text(" given by the dot product.")],
[#text("(b) Show that the Pontryagin dual ")#mi("{\\widehat{{\\bf R}^d}}")#text(" of ")#mi("{{\\bf R}^d}")#text(" is identifiable as an LCA group with ")#mi("{{\\bf R}^d}")#text(", by identifying each ")#mi("{\\xi \\in {\\bf R}^d}")#text(" with the frequency ")#mi("{x \\mapsto \\xi \\cdot x}")#text(" given by the dot product.")],
[#text("(c) Show that the Pontryagin dual ")#mi("{\\widehat{({\\bf R}/{\\bf Z})^d}}")#text(" of ")#mi("{({\\bf R}/{\\bf Z})^d}")#text(" is identifiable as an LCA group with ")#mi("{{\\bf Z}^d}")#text(", by identifying each ")#mi("{\\xi \\in {\\bf Z}^d}")#text(" with the frequency ")#mi("{x \\mapsto \\xi \\cdot x}")#text(" given by the dot product.")],
[#text("(d) (Contravariant functoriality) If ")#mi("{\\phi: G \\rightarrow H}")#text(" is a continuous homomorphism between LCA groups, show that there is a continuous homomorphism ")#mi("{\\phi^*: \\hat H \\rightarrow \\hat G}")#text(" between their Pontryagin duals, defined by ")#mi("{\\phi^*(\\xi) \\cdot x := \\xi \\cdot \\phi(x)}")#text(" for ")#mi("{\\xi \\in \\hat H}")#text(" and ")#mi("{x \\in G}")#text(".")],
[#text("(e) [NOTE: This sub-question requires the full strength of the Pontryagin duality theorem to prove for arbitrary LCA groups, and should be skipped for this course.] If ")#mi("{H}")#text(" is a closed subgroup of an LCA group ")#mi("{G}")#text(" (and is thus also LCA), show that ")#mi("{\\hat H}")#text(" is identifiable with ")#mi("{\\hat G/H^\\perp}")#text(", where ")#mi("{H^\\perp}")#text(" is the space of all frequencies ")#mi("{\\xi \\in \\hat G}")#text(" which annihilate ")#mi("{H}")#text(" (i.e. ")#mi("{\\xi \\cdot x = 0}")#text(" for all ")#mi("{x \\in H}")#text(").")],
[#text("(f) If ")#mi("{G, H}")#text(" are LCA groups, show that ")#mi("{\\widehat{G \\times H}}")#text(" is identifiable as an LCA group with ")#mi("{\\hat G \\times \\hat H}")#text(".")],
[#text("(g) Show that the Pontryagin dual of a finite abelian group ")#mi("{G}")#text(" is identifiable with itself. (")#emph[#text("Hint:")]#text(" first do this for cyclic groups ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(", identifying ")#mi("{\\xi \\in {\\bf Z}/N{\\bf Z}}")#text(" with the additive character ")#mi("{x \\mapsto x \\xi/N}")#text("), then use the ")#link("http://en.wikipedia.org/wiki/Finitely_generated_abelian_group")[#text("classification of finite abelian groups")]#text(".) Note that this identification is not unique.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" ")#metadata(none) <tao-3122e173d2bfbba9c050>#text(" Let ")#mi("{G}")#text(" be an LCA group with non-trivial Haar measure ")#mi("{\\mu}")#text(", and let ")#mi("{\\chi: G \\rightarrow S^1}")#text(" be a measurable function such that ")#mi("{\\chi(x) \\chi(y) = \\chi(x+y)}")#text(" for almost every ")#mi("{x,y \\in G}")#text(". Show that ")#mi("{\\chi}")#text(" is equal almost everywhere to a multiplicative character ")#mi("{\\tilde \\chi}")#text(" of ")#mi("{G}")#text(". (")#emph[#text("Hint:")]#text(" on the one hand, ")#mi("{\\tau_x \\chi = \\chi(-x) \\chi}")#text(" a.e. for almost every ")#mi("{x}")#text(". On the other hand, ")#mi("{\\tau_x \\chi}")#text(" depends continuously on ")#mi("{x}")#text(" in, say, the local ")#mi("{L^1}")#text(" topology.)")
]

#text("In the remainder of this section, ")#mi("{G}")#text(" is a fixed LCA group with a non-trivial Haar measure ")#mi("{\\mu}")#text(".")

#text("Given an absolutely integrable function ")#mi("{f \\in L^1(G)}")#text(", we define the ")#emph[#text("Fourier transform")]#text(" ")#mi("{\\hat f: \\hat G \\rightarrow {\\bf C}}")#text(" by the formula")

#mi("\\displaystyle \\hat f(\\xi) := \\int_G f(x) e^{-2\\pi i \\xi \\cdot x}\\ d\\mu(x).")

#text("This is clearly a linear transformation, with the obvious bound")

#tao-math("\\displaystyle \\sup_{\\xi \\in \\hat G} \\left|\\hat f(\\xi)\\right| \\leq \\left\\|f\\right\\|_{L^1(G)}.", block: false)

#text("It converts translations into frequency modulations: indeed, one easily verifies that ")#metadata(none) <tao-bcf2b8a7060e50f8d60e>

#mi("\\displaystyle \\widehat{\\tau_{x_0} f}(\\xi) = e^{-2\\pi i \\xi \\cdot x_0} \\hat f(\\xi) \\ \\ \\ \\ \\ (3)")

#text("for any ")#mi("{f \\in L^1(G)}")#text(", ")#mi("{x_0 \\in G}")#text(", and ")#mi("{\\xi \\in \\hat G}")#text(". Conversely, it converts frequency modulations to translations: one has ")#metadata(none) <tao-271b80703cde2fc214f0>

#mi("\\displaystyle \\widehat{\\chi_{\\xi_0} f}(\\xi) = \\hat f(\\xi-\\xi_0) \\ \\ \\ \\ \\ (4)")

#text("for any ")#mi("{f \\in L^1(G)}")#text(" and ")#mi("{\\xi_0,\\xi \\in \\hat G}")#text(", where ")#mi("{\\chi_{\\xi_0}}")#text(" is the multiplicative character ")#mi("{\\chi_{\\xi_0}: x \\mapsto e^{2\\pi i \\xi_0 \\cdot x}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Riemann-Lebesgue lemma)")]#text(" ")#metadata(none) <tao-ee946c9c7144b49943b6>#text(" If ")#mi("{f \\in L^1(G)}")#text(", show that ")#mi("{\\hat f: \\hat G \\rightarrow {\\bf C}}")#text(" is continuous. Furthermore, show that ")#mi("{\\hat f}")#text(" goes to zero at infinity in the sense that for every ")#mi("{\\varepsilon > 0}")#text(" there exists a compact subset ")#mi("{K}")#text(" of ")#mi("{\\hat G}")#text(" such that ")#tao-math("{\\left|\\hat f(\\xi)\\right| \\leq \\varepsilon}", block: false)#text(" for ")#mi("{\\xi \\not \\in K}")#text(". (")#emph[#text("Hint:")]#text(" First show that there exists a neighbourhood ")#mi("{U}")#text(" of the identity in ")#mi("{G}")#text(" such that ")#tao-math("{\\left\\| \\tau_x f - f \\right\\|_{L^1(G)} \\leq \\varepsilon^2}", block: false)#text(" (say) for all ")#mi("{x \\in U}")#text(". Now take the Fourier transform of this fact.) Thus the Fourier transform maps ")#mi("{L^1(G)}")#text(" continuously to ")#mi("{C_0(\\hat G)}")#text(", the space of continuous functions on ")#mi("{\\hat G}")#text(" which go to zero at infinity; the decay at infinity is known as the ")#link("http://en.wikipedia.org/wiki/Riemann-Lebesgue_lemma")[#text("Riemann-Lebesgue lemma")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Let ")#mi("{G}")#text(" be an LCA group with non-trivial Haar measure ")#mi("{\\mu}")#text(". Show that the topology of ")#mi("{\\hat G}")#text(" is the weakest topology such that ")#mi("{\\hat f}")#text(" is continuous for every ")#mi("{f \\in L^1(G)}")#text(".")
]

#text("Given two ")#mi("{f,g \\in L^1(G)}")#text(", recall that the ")#link("http://en.wikipedia.org/wiki/Convolution")[#text("convolution")]#text(" ")#mi("{f*g: G \\rightarrow {\\bf C}}")#text(" is defined as")

#mi("\\displaystyle f*g(x) := \\int_G f(y) g(x-y)\\ d\\mu(y).")

#text("From ")#link("http://en.wikipedia.org/wiki/Young%27s_inequality")[#text("Young’s inequality")]#text(" (Exercise 25 of ")#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/")[#text("Notes 1")]#text(") we know that ")#mi("{f*g}")#text(" is defined a.e., and lies in ")#mi("{L^1(G)}")#text("; indeed, we have")

#tao-math("\\displaystyle \\left\\|f*g\\right\\|_{L^1(G)} \\leq \\left\\|f\\right\\|_{L^1(G)} \\left\\|g\\right\\|_{L^1(G)}.", block: false)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" ")#metadata(none) <tao-757d1728ede288eecad9>#text(" Show that the operation ")#mi("{f, g \\mapsto f*g}")#text(" is a bilinear, continuous, commutative, and associative operation on ")#mi("{L^1(G)}")#text(". As a consequence, the Banach space ")#mi("{L^1(G)}")#text(" with the convolution operation as “multiplication” operation becomes a ")#link("http://en.wikipedia.org/wiki/Banach_algebra")[#text("commutative Banach algebra")]#text(". If we also define ")#mi("{f^*(x) := \\overline{f(-x)}}")#text(" for all ")#mi("{f \\in L^1(G)}")#text(", this turns ")#mi("{L^1(G)}")#text(" into a ")#link("http://en.wikipedia.org/wiki/B*-algebra")[#text("Banach ")#mi("{*}")#text("-algebra")]#text(".")

#text("For ")#mi("{f, g \\in L^1(G)}")#text(", show that ")#metadata(none) <tao-cea619a64897d8addf5c>

#mi("\\displaystyle \\widehat{f*g}(\\xi) = \\hat f(\\xi) \\hat g(\\xi) \\ \\ \\ \\ \\ (5)")

#text("for all ")#mi("{\\xi \\in \\hat G}")#text("; thus the Fourier transform converts convolution to pointwise product.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" Let ")#mi("{G, H}")#text(" be LCA groups with non-trivial Haar measures ")#mi("{\\mu, \\nu}")#text(" respectively, and let ")#mi("{f \\in L^1(G)}")#text(", ")#mi("{g \\in L^1(H)}")#text(". Show that the tensor product ")#mi("{f \\otimes g \\in L^1(G \\times H)}")#text(" (with product Haar measure ")#mi("{\\mu \\times \\nu}")#text(") has a Fourier transform of ")#mi("{\\hat f \\otimes \\hat g}")#text(", where we identify ")#mi("{\\widehat{G \\times H}}")#text(" with ")#mi("{\\hat G \\times \\hat H}")#text(" as per Exercise ")#link(<tao-7bd2606643a99b6b8641>)[#text("10")]#text("(f). Informally, this exercise asserts that the Fourier transform commutes with tensor products. (Because of this fact, the ")#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/")[#text("tensor power trick")]#text(" is often available when proving results about the Fourier transform on general groups.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16 (Convolution and Fourier transform of measures)")]#text(" If ")#mi("{\\nu \\in M(G)}")#text(" is a finite Radon measure on an LCA group ")#mi("{G}")#text(" with non-trivial Haar measure ")#mi("{\\mu}")#text(", define the ")#emph[#text("Fourier-Stieltjes transform")]#text(" ")#mi("{\\hat \\nu: \\hat G \\rightarrow {\\bf C}}")#text(" by the formula ")#mi("{\\hat \\nu(\\xi) := \\int_G e^{-2\\pi i \\xi \\cdot x}\\ d\\nu(x)}")#text(" (thus for instance ")#mi("{\\hat{\\mu_f} = \\hat f}")#text(" for any ")#mi("{f \\in L^1(G)}")#text("). Show that ")#mi("{\\hat \\nu}")#text(" is a bounded continuous function on ")#mi("{\\hat G}")#text(". Given any ")#mi("{f \\in L^1(G)}")#text(", define the convolution ")#mi("{f*\\nu: G \\rightarrow {\\bf C}}")#text(" to be the function")

#mi("\\displaystyle f*\\nu(x) := \\int_G f(x-y)\\ d\\nu(y)")

#text("and given any finite Radon measure ")#mi("{\\rho}")#text(", let ")#mi("{\\nu*\\rho: G \\rightarrow {\\bf C}}")#text(" be the measure")

#mi("\\displaystyle \\nu*\\rho(E) := \\int_G \\int_G 1_E(x+y)\\ d\\nu(x) d\\rho(y).")

#text("Show that ")#mi("{f*\\nu \\in L^1(G)}")#text(" and ")#mi("{\\widehat{f*\\nu}(\\xi) = \\hat f(\\xi) \\hat \\nu(\\xi)}")#text(" for all ")#mi("{\\xi \\in\\hat G}")#text(", and similarly that ")#mi("{\\nu*\\rho}")#text(" is a finite measure and ")#mi("{\\widehat{\\nu*\\rho}(\\xi) = \\hat \\nu(\\xi) \\hat \\rho(\\xi)}")#text(" for all ")#mi("{\\xi \\in \\hat G}")#text(". Thus the convolution and Fourier structure on ")#mi("{L^1(G)}")#text(" can be extended to the larger space ")#mi("{M(G)}")#text(" of finite Radon measures.")
]

#strong[#text(" — 2. The Fourier transform on compact abelian groups — ")]

#text("In this section we specialise the Fourier transform to the case when the locally compact group ")#mi("{G}")#text(" is in fact compact, thus we now have a compact abelian group ")#mi("{G}")#text(" with non-trivial Haar measure ")#mi("{\\mu}")#text(". This case includes that of finite groups, together with that of the tori ")#mi("{({\\bf R}/{\\bf Z})^d}")#text(".")

#text("As ")#mi("{\\mu}")#text(" is a Radon measure, compact groups ")#mi("{G}")#text(" have finite measure. It is then convenient to normalise the Haar measure ")#mi("{\\mu}")#text(" so that ")#mi("{\\mu(G)=1}")#text(", thus ")#mi("{\\mu}")#text(" is now a probability measure. For the remainder of this section, we will assume that ")#mi("{G}")#text(" is a compact abelian group and ")#mi("{\\mu}")#text(" is its (unique) Haar probability measure, as given by Exercise ")#link(<tao-c33635072f01e4f83600>)[#text("6")]#text(".")

#text("A key advantage of working in the compact setting is that multiplicative characters ")#mi("{\\chi: G \\rightarrow S^1}")#text(" now lie in ")#mi("{L^2(G)}")#text(" and ")#mi("{L^1(G)}")#text(". In particular, they can be integrated:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 17")]#text(" Let ")#mi("{\\chi}")#text(" be a multiplicative character. Then ")#mi("{\\int_G \\chi\\ d\\mu}")#text(" equals ")#mi("{1}")#text(" when ")#mi("{\\chi}")#text(" is trivial and ")#mi("{0}")#text(" when ")#mi("{\\chi}")#text(" is non-trivial. Equivalently, for ")#mi("{\\xi \\in \\hat G}")#text(", we have ")#mi("{\\int_G e^{2\\pi i \\xi \\cdot x}\\ d\\mu = \\delta_0(\\xi)}")#text(", where ")#mi("{\\delta}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Kronecker_delta")[#text("Kronecker delta function")]#text(" at ")#mi("{0}")#text(".")
]

#emph[#text("Proof:")]#text(" The claim is clear when ")#mi("{\\chi}")#text(" is trivial. When ")#mi("{\\chi}")#text(" is non-trivial, there exists ")#mi("{x \\in G}")#text(" such that ")#mi("{\\chi(x) \\neq 1}")#text(". If one then integrates the identity ")#mi("{\\tau_x \\chi = \\chi(-x) \\chi}")#text(" using ")#link(<tao-52333bde0deedeb616be>)[#text("(2)")]#text(" one obtains the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Show that the Pontryagin dual ")#mi("{\\hat G}")#text(" of a compact abelian group ")#mi("{G}")#text(" is discrete (compare with Exercise ")#link(<tao-4b33669b37ff728c1ec4>)[#text("9")]#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" ")#metadata(none) <tao-ea5fb5b95745d62863a8>#text(" Show that the Fourier transform of the constant function ")#mi("{1}")#text(" is the Kronecker delta function ")#mi("{\\delta_0}")#text(" at ")#mi("{0}")#text(". More generally, for any ")#mi("{\\xi_0 \\in \\hat G}")#text(", show that the Fourier transform of the multiplicative character ")#mi("{x \\mapsto e^{2\\pi i \\xi_0 \\cdot x}}")#text(" is the Kronecker delta function ")#mi("{\\delta_{\\xi_0}}")#text(" at ")#mi("{\\xi_0}")#text(".")
]

#text("Since the pointwise product of two multiplicative characters is again a multiplicative character, and the conjugate of a multiplicative character is also a multiplicative character, we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 20")]#text(" The space of multiplicative chararacters is an orthonormal set in the complex Hilbert space ")#mi("{L^2(G)}")#text(".")
]

#text("Actually, one can say more:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 21 (Plancherel theorem for compact abelian groups)")]#text(" ")#metadata(none) <tao-944be4b0ac4d685844cd>#text(" Let ")#mi("{G}")#text(" be a compact abelian group with probability Haar measure ")#mi("{\\mu}")#text(". Then the space of multiplicative characters is an orthonormal ")#emph[#text("basis")]#text(" for the complex Hilbert space ")#mi("{L^2(G)}")#text(".")
]

#text("The full proof of this theorem will have to wait until later notes, once we have developed the ")#link("http://en.wikipedia.org/wiki/Spectral_theorem")[#text("spectral theorem")]#text(", though see Exercise ")#link(<tao-09e000ca3fe7b2fb9120>)[#text("56")]#text(" below. However, we can work out some important special cases here.")

#list(
[#text("When ")#mi("{G}")#text(" is a torus ")#mi("{G = {\\Bbb T}^d = ({\\bf R}/{\\bf Z})^d}")#text(", the multiplicative characters ")#mi("{x \\mapsto e^{2\\pi i \\xi \\cdot x}}")#text(" separate points (given any two ")#mi("{x,y \\in G}")#text(", there exists a character which takes different values at ")#mi("{x}")#text(" and at ")#mi("{y}")#text("). The space of finite linear combinations of multiplicative characters (i.e. the space of ")#link("http://en.wikipedia.org/wiki/Trigonometric_polynomial")[#text("trigonometric polynomials")]#text(") is then an algebra closed under conjugation that separates points and contains the unit ")#mi("{1}")#text(", and thus by the ")#link("http://en.wikipedia.org/wiki/Stone-Weierstrass_theorem")[#text("Stone-Weierstrass theorem")]#text(", is dense in ")#mi("{C(G)}")#text(" in the uniform (and hence in ")#mi("{L^2}")#text(") topology, and is thus dense in ")#mi("{L^2(G)}")#text(" (in the ")#mi("{L^2}")#text(" topology) also.")],
[#text("The same argument works when ")#mi("{G}")#text(" is a cyclic group ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(", using the multiplicative characters ")#mi("{x \\mapsto e^{2\\pi i \\xi x / N}}")#text(" for ")#mi("{\\xi \\in {\\bf Z}/N{\\bf Z}}")#text(". As every finite abelian group is isomorphic to the product of cyclic groups, we also obtain the claim for finite abelian groups.")],
[#text("Alternatively, when ")#mi("{G}")#text(" is finite, one can argue by viewing the linear operators ")#mi("{\\tau_x: C_c(G) \\rightarrow C_c(G)}")#text(" as ")#tao-math("{\\left|G\\right| \\times \\left|G\\right|}", block: false)#text(" ")#link("http://en.wikipedia.org/wiki/Unitary_matrix")[#text("unitary matrices")]#text(" (in fact, they are ")#link("http://en.wikipedia.org/wiki/Permutation_matrix")[#text("permutation matrices")]#text(") for each ")#mi("{x \\in G}")#text(". The spectral theorem for unitary matrices allows each of these matrices to be diagonalised; as ")#mi("{G}")#text(" is abelian, the matrices commute and so one can ")#emph[#text("simultaneously")]#text(" diagonalise these matrices. It is not hard to see that each simultaneous eigenvector of these matrices is a multiple of a character, and so the characters span ")#mi("{L^2(G)}")#text(", yielding the claim. (The same argument will in fact work for arbitrary compact abelian groups, once we obtain the spectral theorem for unitary operators.)")]
)

#text("If ")#mi("{f \\in L^2(G)}")#text(", the inner product ")#mi("{\\langle f, \\chi_\\xi\\rangle_{L^2(G)}}")#text(" of ")#mi("{f}")#text(" with any multiplicative character ")#mi("{\\chi_\\xi: x \\mapsto e^{2\\pi i \\xi \\cdot x}}")#text(" is just the Fourier coefficient ")#mi("{\\hat f(\\xi)}")#text(" of ")#mi("{f}")#text(" at the corresponding frequency. Applying the general theory of orthonormal bases (see ")#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/")[#text("Notes 5")]#text("), we obtain the following consequences:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 22 (Plancherel theorem for compact abelian groups, again)")]#text(" Let ")#mi("{G}")#text(" be a compact abelian group with probability Haar measure ")#mi("{\\mu}")#text(".")

#list(
[#text("(Parseval identity) For any ")#mi("{f \\in L^2(G)}")#text(", we have ")#tao-math("{\\left\\|f\\right\\|_{L^2(G)}^2 = \\sum_{\\xi \\in \\hat G} \\left|\\hat f(\\xi)\\right|^2}", block: false)#text(".")],
[#text("(Parseval identity, II) For any ")#mi("{f,g \\in L^2(G)}")#text(", we have ")#mi("{\\langle f, g \\rangle_{L^2(G)} = \\sum_{\\xi \\in \\hat G} \\hat f(\\xi) \\overline{\\hat g(\\xi)}}")#text(".")],
[#text("(Unitarity) Thus the Fourier transform is a ")#link("http://en.wikipedia.org/wiki/Unitary_operator")[#text("unitary transformation")]#text(" from ")#mi("{L^2(G)}")#text(" to ")#mi("{\\ell^2(\\hat G)}")#text(".")],
[#text("(Inversion formula) For any ")#mi("{f \\in L^2(G)}")#text(", the series ")#mi("{x \\mapsto \\sum_{\\xi \\in \\hat G} \\hat f(\\xi) e^{2\\pi i \\xi \\cdot x}}")#text(" converges unconditionally in ")#mi("{L^2(G)}")#text(" to ")#mi("{f}")#text(".")],
[#text("(Inversion formula, II) For any sequence ")#mi("{(c_\\xi)_{\\xi \\in \\hat G}}")#text(" in ")#mi("{\\ell^2(\\hat G)}")#text(", the series ")#mi("{x \\mapsto \\sum_{\\xi \\in \\hat G} c_\\xi e^{2\\pi i \\xi \\cdot x}}")#text(" converges unconditionally in ")#mi("{L^2(G)}")#text(" to a function ")#mi("{f}")#text(" with ")#mi("{c_\\xi}")#text(" as its Fourier coefficients.")]
)
]

#text("We can record here a textbook application of the ")#link("http://en.wikipedia.org/wiki/Riesz-Thorin_theorem")[#text("Riesz-Thorin interpolation theorem")]#text(" from the ")#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/")[#text("previous notes")]#text(". Observe that the Fourier transform map ")#mi("{{\\mathcal F}: f \\mapsto \\hat f}")#text(" maps ")#mi("{L^2(G)}")#text(" to ")#mi("{\\ell^2(\\hat G)}")#text(" with norm ")#mi("{1}")#text(", and also trivially maps ")#mi("{L^1(G)}")#text(" to ")#mi("{\\ell^\\infty(\\hat G)}")#text(" with norm ")#mi("{1}")#text(". Applying the interpolation theorem, we conclude the ")#emph[#text("Hausdorff-Young inequality")]#text(" ")#metadata(none) <tao-02b9fee20b66a5d1fe46>

#tao-math("\\displaystyle \\left\\| \\hat f \\right\\|_{\\ell^{p^{\\prime}}(\\hat G)} \\leq \\left\\|f\\right\\|_{L^p(G)} \\ \\ \\ \\ \\ (6)", block: false)

#text("for all ")#mi("{1 \\leq p \\leq 2}")#text(" and all ")#mi("{f \\in L^p(G)}")#text("; in particular, the Fourier transform maps ")#mi("{L^p(G)}")#text(" to ")#mi("{\\ell^{p^{\\prime}}(\\hat G)}")#text(", where ")#mi("{p^{\\prime}}")#text(" is the dual exponent of ")#mi("{p}")#text(", thus ")#mi("{1/p+1/p^{\\prime}=1}")#text(". It is remarkably difficult (though not impossible) to establish the inequality ")#link(<tao-02b9fee20b66a5d1fe46>)[#text("(6)")]#text(" without the aid of the Riesz-Thorin theorem. (For instance, one could use the Marcinkiewicz interpolation theorem combined with the tensor power trick.) The constant ")#mi("{1}")#text(" cannot be improved, as can be seen by testing ")#link(<tao-02b9fee20b66a5d1fe46>)[#text("(6)")]#text(" with the function ")#mi("{f=1}")#text(" and using Exercise ")#link(<tao-ea5fb5b95745d62863a8>)[#text("19")]#text(". By combining ")#link(<tao-02b9fee20b66a5d1fe46>)[#text("(6)")]#text(" with Hölder’s inequality, one concludes that ")#metadata(none) <tao-0e2945f6cde0e7ae8cba>

#tao-math("\\displaystyle \\left\\| \\hat f \\right\\|_{\\ell^q(\\hat G)} \\leq \\left\\|f\\right\\|_{L^p(G)} \\ \\ \\ \\ \\ (7)", block: false)

#text("whenever ")#mi("{2 \\leq q \\leq \\infty}")#text(" and ")#mi("{\\frac{1}{p}+\\frac{1}{q} \\leq 1}")#text(". These are the optimal hypotheses on ")#mi("{p,q}")#text(" for which ")#link(<tao-0e2945f6cde0e7ae8cba>)[#text("(14)")]#text(" holds, though we will not establish this fact here.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" ")#metadata(none) <tao-50abc04dbf19d8a9ebcd>#text(" If ")#mi("{f, g \\in L^2(G)}")#text(", show that the Fourier transform of ")#mi("{fg \\in L^1(G)}")#text(" is given by the formula")

#mi("\\displaystyle \\widehat{fg}(\\xi) = \\sum_{\\eta \\in \\hat G} \\hat f(\\eta) \\hat g(\\xi - \\eta).")

#text("Thus multiplication is converted via the Fourier transform to convolution; compare this with ")#link(<tao-cea619a64897d8addf5c>)[#text("(5)")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24 (Hardy-Littlewood majorant property)")]#text(" Let ")#mi("{p \\geq 2}")#text(" be an even integer. If ")#mi("{f, g \\in L^p(G)}")#text(" are such that ")#tao-math("{\\left|\\hat f(\\xi)\\right| \\leq \\hat g(\\xi)}", block: false)#text(" for all ")#mi("{\\xi \\in \\hat G}")#text(" (in particular, ")#mi("{\\hat g}")#text(" is non-negative), show that ")#tao-math("{\\left\\|f\\right\\|_{L^p(G)} \\leq \\left\\|g\\right\\|_{L^p(G)}}", block: false)#text(". (Hint: use Exercise ")#link(<tao-50abc04dbf19d8a9ebcd>)[#text("23")]#text(" and the Plancherel identity.) The claim fails for all other values of ")#mi("{p}")#text(", a ")#link("http://www.ams.org/mathscinet-getitem?mr=352874")[#text("result of Fournier")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" In this exercise and the next two, we will work on the torus ")#mi("{{\\Bbb T} = {\\bf R}/{\\bf Z}}")#text(" with the probability Haar measure ")#mi("{\\mu}")#text(". The Pontryagin dual ")#mi("{\\hat {\\Bbb T}}")#text(" is identified with ")#mi("{{\\bf Z}}")#text(" in the usual manner, thus ")#mi("{\\hat f(n) = \\int_{{\\bf R}/{\\bf Z}} f(x) e^{-2\\pi i nx}\\ dx}")#text(" for all ")#mi("{f \\in L^1({\\Bbb T})}")#text(". For every integer ")#mi("{N > 0}")#text(" and ")#mi("{f \\in L^1({\\Bbb T})}")#text(", define the ")#emph[#text("partial Fourier series")]#text(" ")#mi("{S_N f}")#text(" to be the expression")

#mi("\\displaystyle S_N f(x) := \\sum_{n=-N}^N \\hat f(n) e^{2\\pi i nx}.")

#list(
[#text("Show that ")#mi("{S_N f = f * D_N}")#text(", where ")#mi("{D_N}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Dirichlet_kernel")[#text("Dirichlet kernel")]#text(" ")#mi("{D_N(x) := \\frac{\\sin(2\\pi(N+1/2)x)}{\\sin(\\pi x)}}")#text(".")],
[#text("Show that ")#tao-math("{\\left\\|D_N\\right\\|_{L^1({\\Bbb T})} \\geq c \\log N}", block: false)#text(" for some absolute constant ")#mi("{c>0}")#text(". Conclude that the operator norm of ")#mi("{S_N}")#text(" on ")#mi("{C({\\Bbb T})}")#text(" (with the uniform norm) is at least ")#mi("{c \\log N}")#text(".")],
[#text("Conclude that there exists a continuous function ")#mi("{f}")#text(" such that the partial Fourier series ")#mi("{S_N f}")#text(" does not converge uniformly. (")#emph[#text("Hint:")]#text(" use the ")#link("http://en.wikipedia.org/wiki/Uniform_boundedness_principle")[#text("uniform boundedness principle")]#text(".) This is despite the fact that ")#mi("{S_N f}")#text(" must converge to ")#mi("{f}")#text(" in ")#mi("{L^2}")#text(" norm, by the Plancherel theorem. (Another example of non-uniform convergence of ")#mi("{S_N f}")#text(" is given by the ")#link("http://en.wikipedia.org/wiki/Gibbs_phenomenon")[#text("Gibbs phenomenon")]#text(".)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" We continue the notational conventions of the preceding exercise. For every integer ")#mi("{N > 0}")#text(" and ")#mi("{f \\in L^1({\\Bbb T})}")#text(", define the ")#emph[#text("Césaro-summed partial Fourier series")]#text(" ")#mi("{C_N f}")#text(" to be the expression")

#mi("\\displaystyle C_N f(x) := \\frac{1}{N} \\sum_{n=0}^{N-1} D_n f(x).")

#list(
[#text("Show that ")#mi("{C_N f = f * F_N}")#text(", where ")#mi("{F_N}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Fej%C3%A9r_kernel")[#text("Fejér kernel")]#text(" ")#mi("{F_N(x) := \\frac{1}{N} (\\frac{\\sin(\\pi Nx)}{\\sin(\\pi x)})^2}")#text(".")],
[#text("Show that ")#tao-math("{\\left\\|F_N\\right\\|_{L^1({\\Bbb T})} = 1}", block: false)#text(". (Hint: what is the Fourier coefficient of ")#mi("{F_N}")#text(" at zero?)")],
[#text("Show that ")#mi("{C_N f}")#text(" converges uniformly to ")#mi("{f}")#text(" for every ")#mi("{f \\in C({\\Bbb T})}")#text(". (Thus we see that Césaro averaging improves the convergence properties of Fourier series.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" ")#metadata(none) <tao-9a0202d06ccbd63e7b9d>#text(" ")#emph[#text("Carleson’s inequality")]#text(" asserts that for any ")#mi("{f \\in L^2({\\Bbb T})}")#text(", one has the weak-type inequality")

#tao-math("\\displaystyle \\left\\| \\sup_{N>0} \\left|S_N f(x)\\right| \\right\\|_{L^{2,\\infty}({\\Bbb T})} \\leq C \\left\\|f\\right\\|_{L^2({\\Bbb T})}", block: false)

#text("for some absolute constant ")#mi("{C}")#text(". Assuming this (deep) inequality, establish ")#link("http://en.wikipedia.org/wiki/Convergence_of_Fourier_series#Convergence_almost_everywhere")[#text("Carleson’s theorem")]#text(" that for any ")#mi("{f \\in L^2({\\Bbb T})}")#text(", the partial Fourier series ")#mi("{S_N f(x)}")#text(" converge for almost every ")#mi("{x}")#text(" to ")#mi("{f(x)}")#text(". (Conversely, a ")#link("http://www.ams.org/mathscinet-getitem?mr=125392")[#text("general principle of Stein")]#text(", analogous to the uniform boundedness principle, allows one to deduce Carleson’s inequality from Carleson’s theorem. A ")#link("http://www.ams.org/mathscinet-getitem?mr=38:6296")[#text("later result of Hunt")]#text(" extends Carleson’s theorem to ")#mi("{L^p({\\Bbb T})}")#text(" for any ")#mi("{p > 1}")#text(", but a famous example of Kolmogorov shows that almost everywhere convergence can fail for ")#mi("{L^1({\\Bbb T})}")#text(" functions; in fact the series may diverge pointwise everywhere.)")
]

#strong[#text(" — 3. The Fourier transform on Euclidean spaces — ")]

#text("We now turn to the Fourier transform on the Euclidean space ")#mi("{{\\bf R}^d}")#text(", where ")#mi("{d \\geq 1}")#text(" is a fixed integer. From Exercise ")#link(<tao-7bd2606643a99b6b8641>)[#text("10")]#text(" we can identify the Pontryagin dual of ")#mi("{{\\bf R}^d}")#text(" with itself, and then the Fourier transform ")#mi("{\\hat f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" of a function ")#mi("{f \\in L^1({\\bf R}^d)}")#text(" is given by the formula ")#metadata(none) <tao-74e10d395491765abe72>

#mi("\\displaystyle \\hat f(\\xi) := \\int_{{\\bf R}^d} f(x) e^{-2\\pi i \\xi \\cdot x}\\ dx. \\ \\ \\ \\ \\ (8)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 28")]#text(" One needs the Euclidean inner product structure on ")#mi("{{\\bf R}^d}")#text(" in order to identify ")#mi("{\\hat{{\\bf R}^d}}")#text(" with ")#mi("{{\\bf R}^d}")#text(". Without this structure, it is more natural to identify ")#mi("{\\hat{{\\bf R}^d}}")#text(" with the dual space ")#mi("{({\\bf R}^d)^*}")#text(" of ")#mi("{{\\bf R}^d}")#text(". (In the language of physics, one should interpret frequency as a ")#link("http://en.wikipedia.org/wiki/Covector")[#text("covector")]#text(" rather than a vector.) However, we will not need to consider such subtleties here. In other areas of mathematics than harmonic analysis, the normalisation of the Fourier transform (particularly with regard to the positioning of the sign ")#mi("{-}")#text(" and the factor ")#mi("{2\\pi}")#text(") is sometimes slightly different from that presented here. For instance, in PDE, the factor of ")#mi("{2\\pi}")#text(" is often omitted from the exponent in order to slightly simplify the behaviour of differential operators under the Fourier transform (at the cost of introducing factors of ")#mi("{2\\pi}")#text(" in various identities, such as the Plancherel formula or inversion formula).")
]

#text("In Exercise ")#link(<tao-ee946c9c7144b49943b6>)[#text("12")]#text(" we saw that if ")#mi("{f}")#text(" was in ")#mi("{L^1({\\bf R}^d)}")#text(", then ")#mi("{\\hat f}")#text(" was continuous and decayed to zero at infinity. One can improve both the regularity and decay on ")#mi("{\\hat f}")#text(" by strengthening the hypotheses on ")#mi("{f}")#text(". We need two basic facts:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29 (Decay transforms to regularity)")]#text(" Let ")#mi("{1 \\leq j \\leq d}")#text(", and suppose that ")#mi("{f, x_j f}")#text(" both lie in ")#mi("{L^1({\\bf R}^d)}")#text(", where ")#mi("{x_j}")#text(" is the ")#mi("{j^{th}}")#text(" coordinate function. Show that ")#mi("{\\hat f}")#text(" is continuously differentiable in the ")#mi("{\\xi_j}")#text(" variable, with")

#mi("\\displaystyle \\frac{\\partial}{\\partial \\xi_j} \\hat f(\\xi) = -2\\pi i \\widehat{x_j f}(\\xi).")

#text("(")#emph[#text("Hint:")]#text(" The main difficulty is to justify differentiation under the integral sign. Use the fact that the function ")#mi("{x \\mapsto e^{ix}}")#text(" has a derivative of magnitude ")#mi("{1}")#text(", and is hence Lipschitz by the fundamental theorem of calculus. Alternatively, one can show first that ")#mi("{\\hat f(\\xi)}")#text(" is the indefinite integral of ")#mi("{-2\\pi i \\widehat{x_j f}}")#text(" and then use the fundamental theorem of calculus.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30 (Regularity transforms to decay)")]#text(" ")#metadata(none) <tao-948755bbc7af121e1874>#text(" Let ")#mi("{1 \\leq j \\leq d}")#text(", and suppose that ")#mi("{f \\in L^1({\\bf R}^d)}")#text(" has a derivative ")#mi("{\\frac{\\partial f}{\\partial x_j}}")#text(" in ")#mi("{L^1({\\bf R}^d)}")#text(", for which one has the fundamental theorem of calculus")

#mi("\\displaystyle f(x_1,\\ldots,x_n) = \\int_{-\\infty}^{x_j} \\frac{\\partial f}{\\partial x_j}(x_1,\\ldots,x_{j-1},t,x_{j+1},\\ldots,x_n)\\ dt")

#text("for almost every ")#mi("{x_1,\\ldots,x_n}")#text(". (This is equivalent to ")#mi("{f}")#text(" being absolutely continuous in ")#mi("{x_j}")#text(" for almost every ")#mi("{x_1,\\ldots,x_{j-1},x_{j+1},\\ldots,x_n}")#text(".) Show that")

#mi("\\displaystyle \\widehat{\\frac{\\partial f}{\\partial x_j}}(\\xi) = 2\\pi i \\xi_j \\hat f(\\xi).")

#text("In particular, conclude that ")#tao-math("{\\left|\\xi_j\\right| \\hat f(\\xi)}", block: false)#text(" goes to zero as ")#tao-math("{\\left|\\xi\\right| \\rightarrow \\infty}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 31")]#text(" Exercise ")#link(<tao-948755bbc7af121e1874>)[#text("30")]#text(" shows that ")#emph[#text("Fourier transforms diagonalise differentiation")]#text(": (constant-coefficient) differential operators such as ")#mi("{\\frac{\\partial}{\\partial x_j}}")#text(", when viewed in frequency space, become nothing more than multiplication operators ")#mi("{\\hat f(\\xi) \\mapsto 2\\pi i \\xi_j \\hat f(\\xi)}")#text(". (Multiplication operators are the continuous analogue of ")#link("http://en.wikipedia.org/wiki/Diagonal_matrix")[#text("diagonal matrices")]#text(".) It is because of this fact that the Fourier transform is extremely useful in PDE, particularly in constant-coefficient linear PDE, or perturbations thereof.")
]

#text("It is now convenient to work with a class of functions which has an infinite amount of both regularity and decay.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 32 (Schwartz class)")]#text(" A ")#emph[#text("rapidly decreasing function")]#text(" is a measurable function ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" such that ")#tao-math("{\\left|x\\right|^n f(x)}", block: false)#text(" is bounded for every non-negative integer ")#mi("{n}")#text(". A ")#link("http://en.wikipedia.org/wiki/Schwartz_space")[#text("Schwartz function")]#text(" is a smooth function ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" such that all derivatives ")#mi("{\\partial_{x_1}^{n_1} \\ldots \\partial_{x_d}^{n_d} f}")#text(" are rapidly decreasing. The space of all Schwartz functions is denoted ")#mi("{{\\mathcal S}({\\bf R}^d)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 33")]#text(" Any smooth, compactly supported function ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is a Schwartz function. The gaussian functions ")#metadata(none) <tao-3b8d14199277153e41ea>

#tao-math("\\displaystyle f(x) = A e^{2\\pi i \\theta} e^{2\\pi i \\xi_0 \\cdot x} e^{-\\pi \\left|x - x_0\\right|^2 / R^2} \\ \\ \\ \\ \\ (9)", block: false)

#text("for ")#mi("{A \\in {\\bf R}}")#text(", ")#mi("{\\theta \\in {\\bf R}/{\\bf Z}}")#text(", ")#mi("{x_0, \\xi_0 \\in {\\bf R}^d}")#text(" are also Schwartz functions.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34")]#text(" Show that the seminorms")

#tao-math("\\displaystyle \\left\\|f\\right\\|_{k,n} := \\sup_{x \\in {\\bf R}^n} \\left|x\\right|^n \\left|\\nabla^k f(x)\\right|", block: false)

#text("for ")#mi("{k,n \\geq 0}")#text(", where we think of ")#mi("{\\nabla^k f(x)}")#text(" as a ")#mi("{d^k}")#text("-dimensional vector (or, if one wishes, a rank ")#mi("{k}")#text(" ")#mi("{d}")#text("-dimensional tensor), give ")#mi("{{\\mathcal S}({\\bf R}^d)}")#text(" the structure of a ")#link("http://en.wikipedia.org/wiki/Fr%C3%A9chet_space")[#text("Fréchet space")]#text(". In particular, ")#mi("{{\\mathcal S}({\\bf R}^d)}")#text(" is a topological vector space.")
]

#text("Clearly, every Schwartz function is both smooth and rapidly decreasing. The following exercise explores the converse:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35")]

#list(
[#text("Give an example to show that not all smooth, rapidly decreasing functions are Schwartz.")],
[#text("Show that if ")#mi("{f}")#text(" is a smooth, rapidly decreasing function, and all derivatives of ")#mi("{f}")#text(" are bounded, then ")#mi("{f}")#text(" is Schwartz. (Hint: use Taylor’s theorem with remainder.)")]
)
]

#text("One of the reasons why the Schwartz space is convenient to work with is that it is closed under a wide variety of operations. For instance, the derivative of a Schwartz function is again a Schwartz function, and that the product of a Schwartz function with a polynomial is again a Schwartz function. Here are some further such closure properties:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36")]#text(" Show that the product of two Schwartz functions is again a Schwartz function. Moreover, show that the product map ")#mi("{f, g \\mapsto fg}")#text(" is continuous from ")#mi("{{\\mathcal S}({\\bf R}^d) \\times {\\mathcal S}({\\bf R}^d)}")#text(" to ")#mi("{{\\mathcal S}({\\bf R}^d)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" Show that the convolution of two Schwartz functions is again a Schwartz function. Moreover, show that the convolution map ")#mi("{f, g \\mapsto f*g}")#text(" is continuous from ")#mi("{{\\mathcal S}({\\bf R}^d) \\times {\\mathcal S}({\\bf R}^d)}")#text(" to ")#mi("{{\\mathcal S}({\\bf R}^d)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38")]#text(" ")#metadata(none) <tao-a031a9ff80a32b7e6e40>#text(" Show that the Fourier transform of a Schwartz function is again a Schwartz function. Moreover, show that the Fourier transform map ")#mi("{{\\mathcal F}: f \\mapsto \\hat f}")#text(" is continuous from ")#mi("{{\\mathcal S}({\\bf R}^d)}")#text(" to ")#mi("{{\\mathcal S}({\\bf R}^d)}")#text(".")
]

#text("The other important property of the Schwartz class is that it is dense in many other spaces:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39")]#text(" Show that ")#mi("{{\\mathcal S}({\\bf R}^d)}")#text(" is dense in ")#mi("{L^p({\\bf R}^d)}")#text(" for every ")#mi("{1 \\leq p < \\infty}")#text(", and is also dense in ")#mi("{C_0({\\bf R}^d)}")#text(" (with the uniform topology). (Hint: one can either use the Stone-Weierstrass theorem, or convolutions with approximations to the identity.)")
]

#text("Because of this density property, it becomes possible to establish various estimates and identities in spaces of rough functions (e.g. ")#mi("{L^p}")#text(" functions) by first establishing these estimates on Schwartz functions (where it is easy to justify operations such as differentiation under the integral sign) and then taking limits.")

#text("Having defined the Fourier transform ")#mi("{{\\mathcal F}: {\\mathcal S}({\\bf R}^d) \\rightarrow {\\mathcal S}({\\bf R}^d)}")#text(", we now introduce the ")#emph[#text("adjoint Fourier transform")]#text(" ")#mi("{{\\mathcal F}^*: {\\mathcal S}({\\bf R}^d) \\rightarrow {\\mathcal S}({\\bf R}^d)}")#text(" by the formula")

#mi("\\displaystyle {\\mathcal F}^* F(x) := \\int_{{\\bf R}^d} e^{2\\pi i \\xi \\cdot x} F(\\xi)\\ d\\xi")

#text("(note the sign change from ")#link(<tao-74e10d395491765abe72>)[#text("(8)")]#text("). We will shortly demonstrate that the adjoint Fourier transform is also the inverse Fourier transform: ")#mi("{{\\mathcal F}^* = {\\mathcal F}^{-1}}")#text(".")

#text("From the identity ")#metadata(none) <tao-c6f93a81b0281e0e042a>

#mi("\\displaystyle {\\mathcal F}^* f = \\overline{{\\mathcal F} \\overline{f}} \\ \\ \\ \\ \\ (10)")

#text("we see that ")#mi("{{\\mathcal F}^*}")#text(" obeys much the same propeties as ")#mi("{{\\mathcal F}}")#text("; for instance, it is also continuous from ")#mi("{{\\mathcal S}({\\bf R}^d)}")#text(" to ")#mi("{{\\mathcal S}({\\bf R}^d)}")#text(". It is also the adjoint to ")#mi("{{\\mathcal F}}")#text(" in the sense that")

#mi("\\displaystyle \\langle {\\mathcal F} f, g \\rangle_{L^2({\\bf R}^d)} = \\langle f, {\\mathcal F}^* g \\rangle_{L^2({\\bf R}^d)}")

#text("for all ")#mi("{f, g \\in {\\mathcal S}({\\bf R}^d)}")#text(".")

#text("Now we show that ")#mi("{{\\mathcal F}^*}")#text(" inverts ")#mi("{{\\mathcal F}}")#text(". We begin with an easy preliminary result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40")]#text(" ")#metadata(none) <tao-1e34bb4cc3f4bd39829b>#text(" For any ")#mi("{f, g \\in {\\mathcal S}({\\bf R}^d)}")#text(", establish the identity ")#mi("{{\\mathcal F}^* {\\mathcal F}( f * g ) = f * {\\mathcal F}^* {\\mathcal F} g}")#text(".")
]

#text("Next, we perform a computation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 41 (Fourier transform of Gaussians)")]#text(" ")#metadata(none) <tao-6f78b0c434b2b52e1a21>#text(" Let ")#mi("{r > 0}")#text(". Show that the Fourier transform of the gaussian function ")#tao-math("{g_r(x) := r^{-d} e^{-\\pi \\left|x\\right|^2/r^2}}", block: false)#text(" is ")#tao-math("{\\hat g_r(\\xi) = e^{-\\pi r^2 \\left|\\xi\\right|^2}}", block: false)#text(". (")#emph[#text("Hint:")]#text(" Reduce to the case ")#mi("{d=1}")#text(" and ")#mi("{r=1}")#text(", then complete the square and use contour integration and the classical identity ")#mi("{\\int_{-\\infty}^\\infty e^{-\\pi x^2}\\ dx = 1}")#text(".) Conclude that ")#mi("{{\\mathcal F}^* {\\mathcal F} g_r = g_r}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42")]#text(" ")#metadata(none) <tao-8ae81b10a8b8cd8542f4>#text(" With ")#mi("{g_r}")#text(" as in the previous exercise, show that ")#mi("{f*g_r}")#text(" converges in the Schwartz space topology to ")#mi("{f}")#text(" as ")#mi("{r \\rightarrow 0}")#text(" for all ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(". (")#emph[#text("Hint:")]#text(" First show convergence in the uniform topology, then use the identities ")#mi("{\\frac{\\partial}{\\partial x_j} (f * g ) = (\\frac{\\partial}{\\partial x_j} f) * g}")#text(" and ")#mi("{x_j (f*g) = (x_j f) * g + f * (x_j g)}")#text(" for ")#mi("{f,g \\in {\\mathcal S}({\\bf R}^d)}")#text(".)")
]

#text("From Exercises ")#link(<tao-1e34bb4cc3f4bd39829b>)[#text("40")]#text(", ")#link(<tao-6f78b0c434b2b52e1a21>)[#text("41")]#text(" we see that")

#mi("\\displaystyle {\\mathcal F}^* {\\mathcal F}( f*g_r ) = f*g_r")

#text("for all ")#mi("{r > 0}")#text(" and ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(". Taking limits as ")#mi("{r \\rightarrow 0}")#text(" using Exercises ")#link(<tao-a031a9ff80a32b7e6e40>)[#text("38")]#text(", ")#link(<tao-8ae81b10a8b8cd8542f4>)[#text("42")]#text(" we conclude that")

#mi("\\displaystyle {\\mathcal F}^* {\\mathcal F} f = f")

#text("for all ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(", or in other words we have the Fourier inversion formula ")#metadata(none) <tao-2187d9a2102ae12c1cb6>

#mi("\\displaystyle f(x) = \\int_{{\\bf R}^d} \\hat f(\\xi) e^{2\\pi i \\xi \\cdot x}\\ d\\xi \\ \\ \\ \\ \\ (11)")

#text("for all ")#mi("{x \\in{\\bf R}^d}")#text(". From ")#link(<tao-c6f93a81b0281e0e042a>)[#text("(10)")]#text(" we also have")

#mi("\\displaystyle {\\mathcal F} {\\mathcal F}^* f = f.")

#text("Taking inner products with another Schwartz function ")#mi("{g}")#text(", we obtain ")#emph[#text("Parseval’s identity")]

#mi("\\displaystyle \\langle {\\mathcal F} f, {\\mathcal F} g \\rangle_{L^2({\\bf R}^d)} = \\langle f, g \\rangle_{L^2({\\bf R}^d)}")

#text("for all ")#mi("{f, g \\in {\\mathcal S}({\\bf R}^d)}")#text(", and similarly for ")#mi("{{\\mathcal F}^*}")#text(". In particular, we obtain ")#emph[#text("Plancherel’s identity")]

#tao-math("\\displaystyle \\left\\| {\\mathcal F} f \\right\\|_{L^2({\\bf R}^d)} = \\left\\| f \\right\\|_{L^2({\\bf R}^d)} = \\left\\|{\\mathcal F}^* f\\right\\|_{L^2({\\bf R}^d)}", block: false)

#text("for all ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(". We conclude that")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 43 (Plancherel’s theorem for ")#mi("{{\\bf R}^d}")#text(")")]#text(" The Fourier transform operator ")#mi("{{\\mathcal F}: {\\mathcal S} \\rightarrow {\\mathcal S}}")#text(" can be uniquely extended to a unitary transformation ")#mi("{{\\mathcal F}: L^2({\\bf R}^d) \\rightarrow L^2({\\bf R}^d)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 44")]#text(" Show that the Fourier transform on ")#mi("{L^2({\\bf R}^d)}")#text(" given by Plancherel’s theorem agrees with the Fourier transform on ")#mi("{L^1({\\bf R}^d)}")#text(" given by ")#link(<tao-74e10d395491765abe72>)[#text("(8)")]#text(" on the common domain ")#mi("{L^2({\\bf R}^d) \\cap L^1({\\bf R}^d)}")#text(". Thus we may define ")#mi("{\\hat f}")#text(" for ")#mi("{f \\in L^1({\\bf R}^d)}")#text(" or ")#mi("{f \\in L^2({\\bf R}^d)}")#text(" (or even ")#mi("{f \\in L^1({\\bf R}^d)+L^2({\\bf R}^d)}")#text(" without any ambiguity (other than the usual identification of any two functions that agree almost everywhere).")
]

#text("Note that it is certainly possible for a function ")#mi("{f}")#text(" to lie in ")#mi("{L^2({\\bf R}^d)}")#text(" but not in ")#mi("{L^1({\\bf R}^d)}")#text(" (e.g. the function ")#tao-math("{(1+\\left|x\\right|)^{-d}}", block: false)#text("). In such cases, the integrand in ")#link(<tao-74e10d395491765abe72>)[#text("(8)")]#text(" is not absolutely integrable, and so this formula does not define the Fourier transform of ")#mi("{f}")#text(" directly. Nevertheless, one can recover the Fourier transform via a limiting version of ")#link(<tao-74e10d395491765abe72>)[#text("(8)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 45")]#text(" Let ")#mi("{f \\in L^2({\\bf R}^d)}")#text(". Show that the partial Fourier integrals ")#tao-math("{\\xi \\mapsto \\int_{\\left|x\\right| \\leq R} f(x) e^{-2\\pi i \\xi \\cdot x}\\ dx}", block: false)#text(" converge in ")#mi("{L^2({\\bf R}^d)}")#text(" to ")#mi("{\\hat f}")#text(" as ")#mi("{R \\rightarrow \\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 46")]#text(" It is a famous open question whether the partial Fourier integrals of an ")#mi("{L^2({\\bf R}^d)}")#text(" function also converge pointwise almost everywhere for ")#mi("{d \\geq 2}")#text(". For ")#mi("{d=1}")#text(", this is essentially the celebrated theorem of Carleson mentioned in Exercise ")#link(<tao-9a0202d06ccbd63e7b9d>)[#text("27")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 47 (Heisenberg uncertainty principle)")]#text(" Let ")#mi("{d=1}")#text(". Define the ")#emph[#text("position operator")]#text(" ")#mi("{X: {\\mathcal S}({\\bf R}) \\rightarrow {\\mathcal S}({\\bf R})}")#text(" and ")#emph[#text("momentum operator")]#text(" ")#mi("{D: {\\mathcal S}({\\bf R}) \\rightarrow {\\mathcal S}({\\bf R})}")#text(" by the formulae")

#mi("\\displaystyle Xf(x) := x f(x); \\quad Df(x) := \\frac{-1}{2\\pi i} \\frac{d}{dx} f(x).")

#text("Establish the identities ")#metadata(none) <tao-e4225382969de14bd8f9>

#mi("\\displaystyle {\\mathcal F} D = X {\\mathcal F}; \\quad {\\mathcal F} X = - {\\mathcal F} D; \\quad DX - XD = \\frac{-1}{2\\pi i} \\ \\ \\ \\ \\ (12)")

#text("and the formal self-adjointness relationships")

#mi("\\displaystyle \\langle Xf, g \\rangle_{L^2({\\bf R})} = \\langle f, Xg \\rangle_{L^2({\\bf R})}; \\quad \\langle Df, g \\rangle_{L^2({\\bf R})} = \\langle f, Dg \\rangle_{L^2({\\bf R})}")

#text("and then establish the inequality")

#tao-math("\\displaystyle \\left\\| Xf \\right\\|_{L^2({\\bf R})} \\left\\| Df\\right\\|_{L^2({\\bf R})} \\geq \\frac{1}{4\\pi} \\left\\|f\\right\\|_{L^2({\\bf R})}^2.", block: false)

#text("(")#emph[#text("Hint:")]#text(" start with the obvious inequality ")#mi("{\\langle (a X + i b D) f, (aX + i bD) f \\rangle_{L^2({\\bf R})} \\geq 0}")#text(" for real numbers ")#mi("{a,b}")#text(", and optimise in ")#mi("{a}")#text(" and ")#mi("{b}")#text(".) If ")#tao-math("{\\left\\|f\\right\\|_{L^2({\\bf R})} = 1}", block: false)#text(", deduce the ")#emph[#text("Heisenberg uncertainty principle")]

#tao-math("\\displaystyle [ \\int_{\\bf R} (\\xi - \\xi_0)^2 \\left|\\hat f(\\xi)\\right|^2\\ d\\xi]^{1/2} [ \\int_{\\bf R} (x - x_0)^2 \\left|f(x)\\right|^2\\ dx]^{1/2} \\geq \\frac{1}{4\\pi}", block: false)

#text("for any ")#mi("{x_0,\\xi_0 \\in {\\bf R}}")#text(". (")#emph[#text("Hint:")]#text(" one can use the translation and modulation symmetries ")#link(<tao-bcf2b8a7060e50f8d60e>)[#text("(3)")]#text(", ")#link(<tao-271b80703cde2fc214f0>)[#text("(4)")]#text(" of the Fourier transform to reduce to the case ")#mi("{x_0=\\xi_0=0}")#text(".) Classify precisely the ")#mi("{f, x_0, \\xi_0}")#text(" for which equality occurs.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 48")]#text(" For ")#mi("{x_0,\\xi_0 \\in {\\bf R}^d}")#text(" and ")#mi("{R > 0}")#text(", define the ")#emph[#text("gaussian wave packet")]#text(" ")#mi("{g_{x_0,\\xi_0,R}}")#text(" by the formula")

#tao-math("\\displaystyle g_{x_0,\\xi_0,R}(x) := 2^{d/2} R^{-d/2} e^{2\\pi i \\xi_0 \\cdot x} e^{- \\pi \\left|x-x_0\\right|^2 / R^2}.", block: false)

#text("These wave packets are normalised to have ")#mi("{L^2}")#text(" norm one, and their Fourier transform is given by ")#metadata(none) <tao-72e1e97c0aff57fb7438>

#mi("\\displaystyle \\hat g_{x_0,\\xi_0,R} = e^{2\\pi i \\xi_0 \\cdot x_0} g_{\\xi_0,-x_0,1/R}. \\ \\ \\ \\ \\ (13)")

#text("Informally, ")#mi("{g_{x_0,\\xi_0,R}}")#text(" is localised to the region ")#mi("{x = x_0 + O(R)}")#text(" in physical space, and to the region ")#mi("{\\xi = \\xi_0 + O(1/R)}")#text(" in frequency space; observe that this is consistent with the uncertainty principle. These packets “almost diagonalise” the position and momentum operators ")#mi("{X, D}")#text(" in the sense that (taking ")#mi("{d=1}")#text(" for simplicity)")

#mi("\\displaystyle X g_{x_0,\\xi_0,R} \\approx x_0 g_{x_0,\\xi_0,R}; \\quad D g_{x_0,\\xi_0,R} \\approx \\xi_0 g_{x_0,\\xi_0,R}")

#text("(where the errors terms are morally of the form ")#mi("{O(R g_{x_0,\\xi_0,R})}")#text(" and ")#mi("{O( R^{-1} g_{x_0,\\xi_0,R})}")#text(" respectively). Of course, the non-commutativity of ")#mi("{D}")#text(" and ")#mi("{X}")#text(" as evidenced by the last equation in ")#link(<tao-e4225382969de14bd8f9>)[#text("(12)")]#text(" shows that exact diagonalisation is impossible. Nevertheless it is useful, at an intuitive level at least, to view these wave-packets as a sort of (overdetermined) basis for ")#mi("{L^2({\\bf R})}")#text(" that approximately diagonalises ")#mi("{X}")#text(" and ")#mi("{D}")#text(" (as well as other formal combinations ")#mi("{a(X,D)}")#text(" of these operators, such as differential operators or ")#link("http://en.wikipedia.org/wiki/Pseudo-differential_operator")[#text("pseudodifferential operators")]#text("). Meanwhile, the Fourier transform morally maps the point ")#mi("{(x_0,\\xi_0)}")#text(" in phase space to ")#mi("{(\\xi_0,-x_0)}")#text(", as evidenced by ")#link(<tao-72e1e97c0aff57fb7438>)[#text("(13)")]#text(" or ")#link(<tao-e4225382969de14bd8f9>)[#text("(12)")]#text("; it is the model example of the more general class of ")#link("http://en.wikipedia.org/wiki/Fourier_integral_operator")[#text("Fourier integral operators")]#text(", which morally move points in phase space around by ")#link("http://en.wikipedia.org/wiki/Canonical_transformation")[#text("canonical transformations")]#text(". The study of these types of objects (which are of importance in linear PDE) is known as ")#emph[#text("microlocal analysis")]#text(", and is beyond the scope of this course.")
]

#text("The proof of the Hausdorff-Young inequality ")#link(<tao-02b9fee20b66a5d1fe46>)[#text("(6)")]#text(" carries over to the Euclidean space setting, and gives ")

#tao-math("\\displaystyle \\left\\|\\hat f\\right\\|_{L^{p^{\\prime}}({\\bf R}^d)} \\leq \\left\\|f\\right\\|_{L^p({\\bf R}^d)} \\ \\ \\ \\ \\ (14)", block: false)

#text("for all ")#mi("{1 \\leq p \\leq 2}")#text(" and all ")#mi("{f \\in L^p({\\bf R}^d)}")#text("; in particular the Fourier transform is bounded from ")#mi("{L^p({\\bf R}^d)}")#text(" to ")#mi("{L^{p^{\\prime}}({\\bf R}^d)}")#text(". The constant of ")#mi("{1}")#text(" on the right-hand side of ")#link(<tao-0e2945f6cde0e7ae8cba>)[#text("(14)")]#text(" turns out to not be optimal in the Euclidean setting, in contrast to the compact setting; the sharp constant is in fact ")#mi("{(p^{1/p} / (p^{\\prime})^{1/p^{\\prime}})^{d/2}}")#text(", a ")#link("http://www.ams.org/mathscinet-getitem?mr=385456")[#text("result of Beckner")]#text(". (The fact that this constant cannot be improved can be seen by using the gaussians from Exercise ")#link(<tao-6f78b0c434b2b52e1a21>)[#text("41")]#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 49 (Entropy uncertainty principle)")]#text(" For any ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(" with ")#tao-math("{\\left\\|f\\right\\|_{L^2({\\bf R}^d)}=1}", block: false)#text(", show that")

#tao-math("\\displaystyle \\int_{{\\bf R}^d} \\left|f(x)\\right|^2 \\log \\frac{1}{\\left|f(x)\\right|^2}\\ dx + \\int_{{\\bf R}^d} \\left|\\hat f(\\xi)\\right|^2 \\log \\frac{1}{\\left|\\hat f(\\xi)\\right|^2}\\ d\\xi \\geq 0.", block: false)

#text("(")#emph[#text("Hint:")]#text(" differentiate (!) ")#link(<tao-0e2945f6cde0e7ae8cba>)[#text("(14)")]#text(" in ")#mi("{p}")#text(" at ")#mi("{p=2}")#text(", where one has equality in ")#link(<tao-0e2945f6cde0e7ae8cba>)[#text("(14)")]#text(".) Using Beckner’s improvement to ")#link(<tao-02b9fee20b66a5d1fe46>)[#text("(6)")]#text(", improve the right-hand side to the optimal value of ")#mi("{d \\log(e/2)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 50 (Fourier transform under linear changes of variable)")]#text(" ")#metadata(none) <tao-097251c9c332242c61eb>#text(" Let ")#mi("{L: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" be an invertible linear transformation. If ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(" and ")#mi("{f_L(x) := f(Lx)}")#text(", show that the Fourier transform of ")#mi("{f_L}")#text(" is given by the formula")

#tao-math("\\displaystyle \\hat f_L(\\xi) = \\frac{1}{\\left|\\det L\\right|} \\hat f( (L^*)^{-1} \\xi )", block: false)

#text("where ")#mi("{L^*: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" is the adjoint operator to ")#mi("{L}")#text(". Verify that this transformation is consistent with ")#link(<tao-0e2945f6cde0e7ae8cba>)[#text("(14)")]#text(", and indeed shows that the exponent ")#mi("{p^{\\prime}}")#text(" on the left-hand side cannot be replaced by any other exponent. (One can also establish this latter claim by dimensional analysis.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 51")]#text(" As a corollary of Exercise ")#link(<tao-097251c9c332242c61eb>)[#text("50")]#text(", observe that if ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(" is spherically symmetric (thus ")#mi("{f = f \\circ L}")#text(" for all rotation matrices ")#mi("{L}")#text(") then ")#mi("{\\hat f}")#text(" is spherically symmetric also.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 52 (Fourier transform intertwines restriction and projection)")]#text(" Let ")#mi("{1 \\leq r \\leq d}")#text(", and let ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(". We express ")#mi("{{\\bf R}^d}")#text(" as ")#mi("{{\\bf R}^r \\times {\\bf R}^{d-r}}")#text(" in the obvious manner.")

#list(
[#text("(Restriction becomes projection) If ")#mi("{g \\in {\\mathcal S}({\\bf R}^r)}")#text(" is the restriction ")#mi("{g(x) := f(x,0)}")#text(" of ")#mi("{f}")#text(" to ")#mi("{{\\bf R}^r \\equiv {\\bf R}^r \\times \\{0\\}}")#text(", show that ")#mi("{\\hat g(\\xi) = \\int_{{\\bf R}^{d-r}} \\hat f(\\xi,\\eta)\\ d\\eta}")#text(" for all ")#mi("{\\xi \\in {\\bf R}^r}")#text(".")],
[#text("(Projection becomes restriction) If ")#mi("{h \\in {\\mathcal S}({\\bf R}^r)}")#text(" is the projection ")#mi("{h(x) := \\int_{{\\bf R}^{d-r}} f(x,y)\\ dy}")#text(" of ")#mi("{f}")#text(" to ")#mi("{{\\bf R}^r \\equiv {\\bf R}^d / {\\bf R}^{d-r}}")#text(", show that ")#mi("{\\hat h(\\xi) = \\hat f(\\xi,0)}")#text(" for all ")#mi("{\\xi \\in {\\bf R}^r}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 53 (Fourier transform on large tori)")]#text(" Let ")#mi("{L > 0}")#text(", and let ")#mi("{({\\bf R}/L{\\bf Z})^d}")#text(" be the torus of length ")#mi("{L}")#text(" with Lebesgue measure ")#mi("{dx}")#text(" (thus the total measure of this torus is ")#mi("{L^d}")#text(". We identify the Pontryagin dual of this torus with ")#mi("{\\frac{1}{L} \\cdot {\\bf Z}^d}")#text(" in the usual manner, thus we have the Fourier coefficients")

#mi("\\displaystyle \\hat f(\\xi) := \\int_{({\\bf R}/L{\\bf Z})^d} f(x) e^{-2\\pi i \\xi \\cdot x}\\ dx")

#text("for all ")#mi("{f \\in L^1(({\\bf R}/L{\\bf Z})^d)}")#text(" and ")#mi("{\\xi \\in \\frac{1}{L} \\cdot {\\bf Z}^d}")#text(".")

#list(
[#text("Show that for any ")#mi("{f \\in L^2(({\\bf R}/L{\\bf Z})^d)}")#text(", the Fourier series ")#mi("{\\frac{1}{L^d} \\sum_{\\xi \\in \\frac{1}{L} \\cdot {\\bf Z}^d} \\hat f(\\xi) e^{2\\pi i \\xi \\cdot x}}")#text(" converges unconditionally in ")#mi("{L^2(({\\bf R}/L{\\bf Z})^d)}")#text(".")],
[#text("Use this to give an alternate proof of the Fourier inversion formula ")#link(<tao-2187d9a2102ae12c1cb6>)[#text("(11)")]#text(" in the case where ")#mi("{f}")#text(" is smooth and compactly supported.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 54 (Poisson summation formula)")]#text(" Let ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(". Show that the function ")#mi("{F: ({\\bf R}/{\\bf Z})^d \\rightarrow {\\bf C}}")#text(" defined by ")#mi("{F( x + {\\bf Z}^d ) := \\sum_{n \\in{\\bf Z}^d} f(x+n)}")#text(" has Fourier transform ")#mi("{\\hat F(\\xi) = \\hat f(\\xi)}")#text(" for all ")#mi("{\\xi \\in {\\bf Z}^d \\subset {\\bf R}^d}")#text(" (note the two different Fourier transforms in play here). Conclude the ")#link("http://en.wikipedia.org/wiki/Poisson_summation_formula")[#text("Poisson summation formula")]

#mi("\\displaystyle \\sum_{n \\in {\\bf Z}^d} f(n) = \\sum_{m \\in {\\bf Z}^d} \\hat f(m).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 55")]#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be a compactly supported, absolutely integrable function. Show that the function ")#mi("{\\hat f}")#text(" is real-analytic. Conclude that it is not possible to find a non-trivial ")#mi("{f \\in L^1({\\bf R}^d)}")#text(" such that ")#mi("{f}")#text(" and ")#mi("{\\hat f}")#text(" are both compactly supported.")
]

#strong[#text(" — 4. The Fourier transform on general groups (optional) — ")]

#text("The field of ")#emph[#text("abstract harmonic analysis")]#text(" is concerned, among other things, with extensions of the above theory to more general groups, for instance arbitrary LCA groups. One of the ways to proceed is via Gelfand theory, which for instance can be used to show that the Fourier transform is at least injective:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 56 (Fourier analysis via Gelfand theory)")]#text(" ")#metadata(none) <tao-09e000ca3fe7b2fb9120>#text(" (Optional) In this exercise we use the Gelfand theory of commutative Banach *-algebras (see ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("245B Notes 12")]#text(") to establish some basic facts of Fourier analysis in general groups. Let ")#mi("{G}")#text(" be an LCA group. We view ")#mi("{L^1(G)}")#text(" as a commutative Banach *-algebra ")#mi("{L^1(G)}")#text(" (see Exercise ")#link(<tao-757d1728ede288eecad9>)[#text("14")]#text(").")

#list(
[#text("(a) If ")#mi("{f \\in L^1(G)}")#text(" is such that ")#tao-math("{\\liminf_{n \\rightarrow \\infty} \\left\\| f^{*n} \\right\\|_{L^1(G)}^{1/n} > 0}", block: false)#text(", where ")#mi("{f^{*n} = f * \\ldots * f}")#text(" is the convolution of ")#mi("{n}")#text(" copies of ")#mi("{f}")#text(", show that there exists a non-zero complex number ")#mi("{z}")#text(" such that the map ")#mi("{g \\mapsto f*g - zg}")#text(" is not invertible on ")#mi("{L^1(G)}")#text(". (")#emph[#text("Hint:")]#text(" If ")#mi("{L^1(G)}")#text(" contains a unit, one can use Exercise 35 of ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("245B Notes 12")]#text("; otherwise, adjoin a unit.)")],
[#text("(b) If ")#mi("{f}")#text(" and ")#mi("{z}")#text(" are as in (a), show that there exists a character ")#mi("{\\lambda: L^1(G) \\rightarrow {\\bf C}}")#text(" (in the sense of Banach *-algebras, see Definition 16 of ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("245B Notes 12")]#text(") such that ")#mi("{f*g-zg}")#text(" lies in the kernel of ")#mi("{\\lambda}")#text(" for all ")#mi("{g \\in L^1(G)}")#text(". Conclude in particular that ")#mi("{\\lambda(f)}")#text(" is non-zero.")],
[#text("(c) If ")#mi("{\\lambda: L^1(G) \\rightarrow {\\bf C}}")#text(" is a character, show that there exists a multiplicative character ")#mi("{\\chi: G \\rightarrow S^1}")#text(" such that ")#mi("{\\lambda(f) = \\langle f, \\chi \\rangle}")#text(" for all ")#mi("{f \\in L^1(G)}")#text(". (You will need Exercise ")#link(<tao-30d8f60246df638abb58>)[#text("5")]#text(" and Exercise ")#link(<tao-3122e173d2bfbba9c050>)[#text("11")]#text(".)")],
[#text("(d) For any ")#mi("{f\\in L^1(G)}")#text(" and ")#mi("{g \\in L^2(G)}")#text(", show that ")#tao-math("{\\left|f*g*g^*(0)\\right| \\leq \\left|f*f^**g*g^*(0)\\right|^{1/2} \\left|g*g^*(0)\\right|^{1/2}}", block: false)#text(", where ")#mi("{0}")#text(" is the group identity and ")#mi("{f^*(x) := \\overline{f(-x)}}")#text(" is the conjugate of ")#mi("{f}")#text(". (")#emph[#text("Hint:")]#text(" the inner product ")#mi("{\\langle f_1, f_2 \\rangle_g := f_1 * f_2^* * g * g^*(0)}")#text(" is positive semi-definite.)")],
[#text("(e) Show that if ")#mi("{f \\in L^1(G)}")#text(" is not identically zero, then there exists ")#mi("{\\xi \\in \\hat G}")#text(" such that ")#mi("{\\hat f(\\xi) \\neq 0}")#text(". (")#emph[#text("Hint:")]#text(" first find ")#mi("{g \\in L^2(G)}")#text(" such that ")#mi("{f*g*g^*(0) \\neq 0}")#text(" and ")#mi("{g*g^*(0) \\neq 0}")#text(", and conclude using (d) repeatedly that ")#tao-math("{\\liminf_{n \\rightarrow \\infty} \\left\\| (f*f^*)^{*n} \\right\\|_{L^1(G)}^{1/n} > 0}", block: false)#text(". Then use (a), (b), (c).) Conclude that the Fourier transform is injective on ")#mi("{L^1(G)}")#text(". (The image of ")#mi("{L^1(G)}")#text(" under the Fourier transform is then a Banach *-algebra known as the ")#emph[#text("Wiener algebra")]#text(", and is denoted ")#mi("{A(\\hat G)}")#text(".)")],
[#text("(f) Prove Theorem ")#link(<tao-944be4b0ac4d685844cd>)[#text("21")]#text(".")]
)
]

#text("It is possible to use arguments similar to those in Exercise ")#link(<tao-09e000ca3fe7b2fb9120>)[#text("56")]#text(" to characterise positive measures on ")#mi("{\\hat G}")#text(" in terms of continuous functions on ")#mi("{G}")#text(", leading to ")#link("http://en.wikipedia.org/wiki/Bochner%27s_theorem")[#text("Bochner’s theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 57 (Bochner’s theorem)")]#text(" Let ")#mi("{\\phi \\in C(G)}")#text(" be a continuous function on an LCA group ")#mi("{G}")#text(". Then the following are equivalent:")

#list(
[#text("(a) ")#mi("{\\sum_{n=1}^N \\sum_{m=1}^N c_n \\overline{c_m} \\phi( x_n - x_m ) \\geq 0}")#text(" for all ")#mi("{x_1,\\ldots,x_N \\in G}")#text(" and ")#mi("{c_1,\\ldots,c_N \\in {\\bf C}}")#text(".")],
[#text("(b) There exists a non-negative finite Radon measure ")#mi("{\\nu}")#text(" on ")#mi("{\\hat G}")#text(" such that ")#mi("{\\phi(x) = \\int_{\\hat G} e^{2\\pi i \\xi \\cdot x}\\ d\\nu(\\xi)}")#text(".")]
)
]

#text("Functions obeying either (a) or (b) are known as ")#emph[#text("positive-definite functions")]#text(". The space of such functions is denoted ")#mi("{B(G)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 58")]#text(" Show that (b) implies (a) in Bochner’s theorem. (The converse implication is significantly harder, reprising much of the machinery in Exercise ")#link(<tao-09e000ca3fe7b2fb9120>)[#text("56")]#text(", but with ")#mi("{\\phi}")#text(" taking the place of ")#mi("{g*g^*}")#text(": see ")#link("http://www.ams.org/mathscinet-getitem?mr=1038803")[#text("Rudin’s book")]#text(" for details.)")
]

#text("Using Bochner’s theorem, it is possible to show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 59 (Plancherel’s theorem for LCA groups)")]#text(" Let ")#mi("{G}")#text(" be an LCA group with non-trivial Haar measure ")#mi("{\\mu}")#text(". Then there exists a non-trivial Haar measure ")#mi("{\\nu}")#text(" on ")#mi("{\\hat G}")#text(" such that the Fourier transform on ")#mi("{L^1(G) \\cap L^2(G)}")#text(" can be extended continuously to a unitary transformation from ")#mi("{L^2(G)}")#text(" to ")#mi("{L^2(\\hat G)}")#text(". In particular we have the Plancherel identity")

#tao-math("\\displaystyle \\int_G \\left|f(x)\\right|^2\\ d\\mu(x) = \\int_{\\hat G} \\left|\\hat f(\\xi)\\right|^2\\ d\\nu(\\xi)", block: false)

#text("for all ")#mi("{f \\in L^2(G)}")#text(", and the Parseval identity")

#mi("\\displaystyle \\int_G f(x) \\overline{g(x)}\\ d\\mu(x) = \\int_{\\hat G} \\hat f(\\xi) \\overline{\\hat g(\\xi)}\\ d\\nu(\\xi)")

#text("for all ")#mi("{f,g \\in L^2(G)}")#text(". Furthermore, the inversion formula")

#mi("\\displaystyle f(x) = \\int_{\\hat G} \\hat f(\\xi) e^{2\\pi i \\xi \\cdot x}\\ d\\nu(\\xi)")

#text("is valid for ")#mi("{f}")#text(" in a dense subclass of ")#mi("{L^2(G)}")#text(" (in particular, it is valid for ")#mi("{f \\in L^1(G) \\cap B(G)}")#text(").")
]

#text("Again, see ")#link("http://www.ams.org/mathscinet-getitem?mr=1038803")[#text("Rudin’s book")]#text(" for details. A related result is that of ")#link("http://en.wikipedia.org/wiki/Pontryagin_dual")[#text("Pontryagin duality")]#text(": if ")#mi("{\\hat G}")#text(" is the Pontryagin dual of an LCA group ")#mi("{G}")#text(", then ")#mi("{G}")#text(" is the Pontryagin dual of ")#mi("{\\hat G}")#text(". (Certainly, every element ")#mi("{x \\in G}")#text(" defines a character ")#mi("{\\hat x: \\xi \\mapsto \\xi \\cdot x}")#text(" on ")#mi("{\\hat G}")#text(", thus embedding ")#mi("{G}")#text(" into ")#mi("{\\hat{\\hat G}}")#text(" via the ")#link("http://en.wikipedia.org/wiki/Gelfand_transform")[#text("Gelfand transform")]#text("; the non-trivial fact is that this embedding is in fact surjective.) One can use Pontryagin duality to convert various properties of LCA groups into other properties on LCA groups. For instance, we have already seen that ")#mi("{\\hat G}")#text(" is compact (resp. discrete) if ")#mi("{G}")#text(" is discrete (resp. compact); with Pontryagin duality, the implications can now also be reversed. As another example, one can show that ")#mi("{\\hat G}")#text(" is connected (resp. torsion-free) if and only if ")#mi("{G}")#text(" is torsion-free (resp. connected). We will not prove these assertions here.")

#text("It is natural to ask what happens for non-abelian locally compact groups ")#mi("{G = (G,\\cdot)}")#text(". One can still build non-trivial Haar measures (the proof sketched out in Exercise ")#link(<tao-b215f4d39327b4937bb4>)[#text("7")]#text(" extends without difficulty to the non-abelian setting), though one must now distinguish between left-invariant and right-invariant Haar measures. (The two notions are equivalent for some classes of groups, notably compact groups, but not in general. Groups for which the two notions of Haar measures coincide are called ")#emph[#text("unimodular")]#text(".) However, when ")#mi("{G}")#text(" is non-abelian then there are not enough multiplicative characters ")#mi("{\\chi: G \\rightarrow S^1}")#text(" to have a satisfactory Fourier analysis. (Indeed, such characters must annihilate the commutator group ")#mi("{[G,G]}")#text(", and it is entirely possible for this commutator group to be all of ")#mi("{G}")#text(", e.g. if ")#mi("{G}")#text(" is ")#link("http://en.wikipedia.org/wiki/Simple_group")[#text("simple")]#text(" and non-abelian.) Instead, one must generalise the notion of a multiplicative character to that of a ")#emph[#text("unitary representation")]#text(" ")#mi("{\\rho: G \\rightarrow U(H)}")#text(" from ")#mi("{G}")#text(" to the group of unitary transformations on a complex Hilbert space ")#mi("{H}")#text("; thus the Fourier coefficients ")#mi("{\\hat f(\\rho)}")#text(" of a function will now be operators on thisl Hilbert space ")#mi("{H}")#text(", rather than complex numbers. When ")#mi("{G}")#text(" is a compact group, it turns out to be possible to restrict attention to finite-dimensional representations (thus one can replace ")#mi("{U(H)}")#text(" by the matrix group ")#mi("{U(n)}")#text(" for some ")#mi("{n}")#text("). The analogue of the Pontryagin dual ")#mi("{\\hat G}")#text(" is then the collection of (irreducible) finite-dimensional unitary representations of ")#mi("{G}")#text(", up to isomorphism. There is an analogue of the Plancherel theorem in this setting, closely related to the ")#link("http://en.wikipedia.org/wiki/Peter-Weyl_theorem")[#text("Peter-Weyl theorem")]#text(" in representation theory. We will not discuss these topics here, but refer the reader instead to any representation theory text.")

#text("The situation for non-compact non-abelian groups (e.g. ")#mi("{SL_2({\\bf R})}")#text(") is significantly more subtle, as one must now consider infinite-dimensional representations as well as finite-dimensional ones, and the inversion formula can become quite non-trivial (one has to decide what “weight” each representation should be assigned in that formula). At this point it seems unprofitable to work in the category of locally compact groups, and specialise to a more structured class of groups, e.g. algebraic groups. The representation theory of such groups is a massive subject and well beyond the scope of this course.")

#strong[#text(" — 5. Relatives of the Fourier transform (optional) — ")]

#text("There are a number of other Fourier-like transforms used in mathematics, which we will briefly survey here. Firstly, there are some rather trivial modifications one can make to the definition of Fourier transform, for instance by replacing the complex exponential ")#mi("{e^{2\\pi i x}}")#text(" by trigonometric functions such as ")#mi("{\\sin(x)}")#text(" and ")#mi("{\\cos(x)}")#text(", or moving around the various factors of ")#mi("{2\\pi}")#text(", ")#mi("{i}")#text(", ")#mi("{-1}")#text(", etc. in the definition. In this spirit, we have the ")#link("http://en.wikipedia.org/wiki/Laplace_transform")[#text("Laplace transform")]#text(" ")#metadata(none) <tao-73c1dbe53567b57878a1>

#mi("\\displaystyle {\\mathcal L} f(t) :=\\int_0^\\infty f(s) e^{-st}\\ ds \\ \\ \\ \\ \\ (15)")

#text("of a measurable function ")#mi("{f: [0,+\\infty) \\rightarrow {\\bf R}}")#text(" with some reasonable growth at infinity, where ")#mi("{t > 0}")#text(". Roughly speaking, the Laplace transform is “the Fourier transform without the ")#mi("{i}")#text("” (cf. ")#link("http://en.wikipedia.org/wiki/Wick_rotation")[#text("Wick rotation")]#text("), and so has the (mild) advantage of being definable in the realm of real-valued functions rather than complex-valued functions. It is particularly well suited for studying ODE on the half-line ")#mi("{[0,+\\infty)}")#text(" (e.g. initial value problems for a finite-dimensional system). The Laplace transform and Fourier transform can be unified by allowing the ")#mi("{t}")#text(" parameter in ")#link(<tao-73c1dbe53567b57878a1>)[#text("(15)")]#text(" to vary in the right-half plane ")#mi("{\\{ t \\in {\\bf C}: \\text{Re}(t) \\geq 0 \\}}")#text(".")

#text("When the Fourier transform is applied to a spherically symmetric function ")#tao-math("{f(x) := F(\\left|x\\right|)}", block: false)#text(" on ")#mi("{{\\bf R}^d}")#text(", then the Fourier transform is also spherically symmetric, given by the formula ")#tao-math("{\\hat f(\\xi) = G(\\left|\\xi\\right|)}", block: false)#text(" where ")#mi("{G}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Hankel_transform")[#text("Fourier-Bessel transform")]#text(" (or ")#emph[#text("Hankel transform")]#text(")")

#mi("\\displaystyle G(r) := 2\\pi r^{-(d-2)/2} \\int_0^\\infty F(s) J_{(d-2)/2}(2\\pi r s) s^{d/2}\\ ds")

#text("where ")#mi("{J_\\nu}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Bessel_function")[#text("Bessel function of the first kind")]#text(" with index ")#mi("{\\nu}")#text(". In practice, one can then analyse the Fourier-analytic behaviour of spherically symmetric functions in terms of one-dimensional Fourier-like integrals by using various asymptotic expansions of the Bessel function.")

#text("There is a relationship between the ")#mi("{d}")#text("-dimensional Fourier transform and the one-dimensional Fourier transform, provided by the ")#link("http://en.wikipedia.org/wiki/Radon_transform")[#text("Radon transform")]#text(", defined for ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(" (say) by the formula")

#mi("\\displaystyle {\\mathcal R}f( \\omega, t ) := \\int_{x \\cdot \\omega = t} f")

#text("where ")#mi("{\\omega \\in S^{d-1}}")#text(", ")#mi("{t \\in {\\bf R}}")#text(", and the integration is with respect to ")#mi("{d-1}")#text("-dimensional measure. Indeed one checks that the ")#mi("{d}")#text("-dimensional Fourier transform of ")#mi("{f}")#text(" at ")#mi("{r \\omega}")#text(" for some ")#mi("{r > 0}")#text(" and ")#mi("{\\omega \\in S^{d-1}}")#text(" is nothing more than the one-dimensional Fourier coefficient of the function ")#mi("{t \\mapsto {\\mathcal R} f(\\omega,t)}")#text(" at ")#mi("{r}")#text(". The Radon transform is often used in scattering theory and related areas of analysis, geometry, and physics.")

#text("In analytic number theory, a multiplicative version of the Fourier-Laplace transform is often used, namely the ")#link("http://en.wikipedia.org/wiki/Mellin_transform")[#text("Mellin transform")]

#mi("\\displaystyle {\\mathcal M} f(s) := \\int_0^\\infty x^s f(x)\\frac{dx}{x}.")

#text("(Note that ")#mi("{\\frac{dx}{x}}")#text(" is a Haar measure for the ")#emph[#text("multiplicative")]#text(" group ")#mi("{{\\bf R}^+ = (0,+\\infty)}")#text(".) To see the relation with the Fourier-Laplace transform, write ")#mi("{f(x) = F(\\log x)}")#text(", then the Mellin transform becomes")

#mi("\\displaystyle {\\mathcal M} f(s) = \\int_{\\bf R} e^{st} f(t)\\ dt.")

#text("Many functions of importance in analytic number theory, such as the ")#link("http://en.wikipedia.org/wiki/Gamma_function")[#text("Gamma function")]#text(" or the ")#link("http://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("zeta function")]#text(", can be expressed neatly in terms of Mellin transforms.")

#text("In electrical engineering and signal processing, the ")#link("http://en.wikipedia.org/wiki/Z-transform")[#text("z-transform")]#text(" is often used, transforming a sequence ")#mi("{c = (c_n)_{n=-\\infty}^\\infty}")#text(" of complex numbers to a formal Laurent series")

#mi("\\displaystyle {\\mathcal Z} c(z) := \\sum_{n=-\\infty}^\\infty c_n z^n")

#text("(some authors use ")#mi("{z^{-n}}")#text(" instead of ")#mi("{z^n}")#text(" here). If one makes the substitution ")#mi("{z = e^{2\\pi i nx}}")#text(" then this becomes a (formal) Fourier series expansion on the unit circle. If the sequence ")#mi("{c_n}")#text(" is restricted to only be non-zero for non-negative ")#mi("{n}")#text(", and does not grow too quickly as ")#mi("{n \\rightarrow \\infty}")#text(", then the ")#mi("{z}")#text("-transform becomes holomorphic on the unit disk, thus providing a link between Fourier analysis and complex analysis. For instance, the standard formula")

#tao-math("\\displaystyle c_n = \\frac{1}{2\\pi i} \\int_{\\left|z\\right|=1} \\frac{f(z)}{z^{n+1}}\\ dz", block: false)

#text("for the Taylor coefficients of a holomorphic function ")#mi("{f(z) = \\sum_{n=0}^\\infty c_n z^n}")#text(" at the origin can be viewed as a version of the Fourier inversion formula for the torus ")#mi("{{\\bf R}/{\\bf Z}}")#text(". Just as the Fourier or Laplace transforms are useful for analysing differential equations in continuous settings, the ")#mi("{z}")#text("-transform is useful for analysing difference equations in discrete settings. The ")#mi("{z}")#text("-transform is of course also very similar to the method of ")#link("http://en.wikipedia.org/wiki/Generating_function")[#text("generating functions")]#text(" in combinatorics and probability.")

#text("In probability theory one also considers the ")#link("http://en.wikipedia.org/wiki/Characteristic_function_(probability_theory)")[#text("characteristic function")]#text(" ")#mi("{{\\Bbb E}(e^{itX})}")#text(" of a real-valued random variable ")#mi("{X}")#text("; this is essentially the Fourier transform of the probability distribution of ")#mi("{X}")#text(". Just as the Fourier transform is useful for understanding convolutions ")#mi("{f*g}")#text(", the characteristic function is useful for understanding sums ")#mi("{X_1+X_2}")#text(" of independent random variables.")

#text("We have briefly touched upon the role of Gelfand theory in the general theory of the Fourier transform. Indeed, one can view the Fourier transform as the special case of the ")#link("http://en.wikipedia.org/wiki/Gelfand_transform")[#text("Gelfand transform")]#text(" for Banach *-algebras, which we already discussed in ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("245B Notes 12")]#text(".")

#text("The ")#link("http://en.wikipedia.org/wiki/Fast_Fourier_transform")[#text("Fast Fourier Transform")]#text(" (FFT) is not, strictly speaking, a variant of the Fourier transform, but rather is an efficient algorithm for ")#emph[#text("computing")]#text(" the Fourier transform")

#mi("\\displaystyle \\hat f(\\xi) = \\frac{1}{N} \\sum_{n=0}^{N-1} f(x) e^{-2\\pi i \\xi x/N}")

#text("on a cyclic group ")#mi("{{\\bf Z}/N{\\bf Z} \\equiv \\{0,\\ldots,N-1\\}}")#text(", when ")#mi("{N}")#text(" is large but composite. Note that a brute force computation of this transform for all ")#mi("{N}")#text(" values of ")#mi("{\\xi}")#text(" would require about ")#mi("{O(N^2)}")#text(" addition and multiplication operations. The FFT algorithm, in contrast, takes only ")#mi("{O(N \\log N)}")#text(" operations, and is based on reducing the FFT for a large ")#mi("{N}")#text(" to FFT for smaller ")#mi("{N}")#text(". For instance, suppose ")#mi("{N}")#text(" is even, say ")#mi("{N=2M}")#text(", then observe that")

#mi("\\displaystyle \\hat f(\\xi) = \\frac{1}{2} ( \\hat f_0(\\xi) + e^{-2\\pi i \\xi / N } \\hat f_1(\\xi) )")

#text("where ")#mi("{f_0, f_1: {\\bf Z}/M{\\bf Z} \\rightarrow {\\bf C}}")#text(" are the functions ")#mi("{f_j(x) := f(2x+j)}")#text(". Thus one can obtain the Fourier transform of the length ")#mi("{N}")#text(" vector ")#mi("{f}")#text(" from the Fourier transforms of the two length ")#mi("{M}")#text(" vectors ")#mi("{f_0, f_1}")#text(" after about ")#mi("{O(N)}")#text(" operations. Iterating this we see that we can indeed compute ")#mi("{\\hat f}")#text(" in ")#mi("{O( N \\log N )}")#text(" operations, at least in the model case when ")#mi("{N}")#text(" is a power of two; the general case has a similar but more complicated analysis.")

#text("In many situations (particularly in ergodic theory), it is desirable not to perform Fourier analysis on a group ")#mi("{G}")#text(" directly, but instead on another space ")#mi("{X}")#text(" that ")#mi("{G}")#text(" acts on. Suppose for instance that ")#mi("{G}")#text(" is a compact abelian group, with probability Haar measure ")#mi("{dg}")#text(", which acts in a measure-preserving (and measurable) fashion on a probability space ")#mi("{(X,\\mu)}")#text(". Then one can decompose any ")#mi("{f \\in L^2(X)}")#text(" into Fourier components ")#mi("{f = \\sum_{\\xi \\in \\hat G} f_\\xi}")#text(", where ")#mi("{f_\\xi(x) := \\int_G e^{-2\\pi i \\xi \\cdot g} f(g x)\\ dg}")#text(", where the series is unconditionally convergent in ")#mi("{L^2(X)}")#text(". The reason for doing this is that each of the ")#mi("{f_\\xi}")#text(" behaves in a simple way with respect to the group action, indeed one has ")#mi("{f_\\xi( g x ) = e^{2\\pi i \\xi \\cdot g} f_\\xi(x)}")#text(" for (almost) all ")#mi("{g \\in G, x \\in X}")#text(". This decomposition is closely related to the decomposition in representation theory of a given representation into irreducible components. Perhaps the most basic example of this type of operation is the decomposition of a function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" into even and odd components ")#mi("{\\frac{f(x)+f(-x)}{2}}")#text(", ")#mi("{\\frac{f(x)-f(-x)}{2}}")#text("; here the underlying group is ")#mi("{{\\bf Z}/2{\\bf Z}}")#text(", which acts on ")#mi("{{\\bf R}}")#text(" by reflections, ")#mi("{gx := (-1)^g x}")#text(".")

#text("The operation of converting a square matrix ")#mi("{A = (a_{ij})_{1 \\leq i,j \\leq n}}")#text(" of numbers into eigenvalues ")#mi("{\\lambda_1,\\ldots,\\lambda_n}")#text(" or singular values ")#mi("{\\sigma_1,\\ldots,\\sigma_n}")#text(" can be viewed as a sort of non-commutative generalisation of the Fourier transform. (Note that the eigenvalues of a ")#link("http://en.wikipedia.org/wiki/Circulant_matrix")[#text("circulant matrix")]#text(" are essentially the Fourier coefficients of the first row of that matrix.) For instance, the identity ")#tao-math("{\\sum_{i=1}^n \\sum_{j=1}^n \\left|a_{ij}\\right|^2 = \\sum_{k=1}^n \\sigma_k^2}", block: false)#text(" can be viewed as a variant of the Plancherel identity. More generally, there are close relationships between spectral theory and Fourier analysis (as one can already see from the connection to Gelfand theory). For instance, in ")#mi("{{\\bf R}^d}")#text(" and ")#mi("{{\\Bbb T}^d}")#text(", one can view Fourier analysis as the spectral theory of the gradient operator ")#mi("{\\nabla}")#text(" (note that the characters ")#mi("{e^{2\\pi i \\xi \\cdot x}}")#text(" are joint eigenfunctions of ")#mi("{\\nabla}")#text("). As the gradient operator is closely related to the Laplacian ")#mi("{\\Delta}")#text(", it is not surprising that Fourier analysis is also closely related to the spectral theory of the Laplacian, and in particular to various operators built using the Laplacian (e.g. resolvents, heat kernels, wave operators, Schrödinger operators, Littlewood-Paley projections, etc.). Indeed, the spectral theory of the Laplacian can serve as a partial substitute for the Fourier transform in situations in which there is not enough symmetry to exploit Fourier-analytic techniques (e.g. on a manifold with no translation symmetries).")

#text("Finally, there is an analogue of the Fourier duality relationship between an LCA group ")#mi("{G}")#text(" and its Pontryagin dual ")#mi("{\\hat G}")#text(" in algebraic geometry, known as the ")#link("http://en.wikipedia.org/wiki/Mukai-Fourier_transform")[#text("Fourier-Mukai transform")]#text(", which relates an ")#link("http://en.wikipedia.org/wiki/Abelian_variety")[#text("abelian variety")]#text(" ")#mi("{X}")#text(" to its ")#link("http://en.wikipedia.org/wiki/Dual_abelian_variety")[#text("dual")]#text(" ")#mi("{\\hat X}")#text(", and transforms ")#link("http://en.wikipedia.org/wiki/Coherent_sheaf")[#text("coherent sheaves")]#text(" on the former to coherent sheaves on the latter. This transform obeys many of the algebraic identities that the Fourier transform does, although it does not seem to have much of the analytic structure.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (190)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-555407")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2020")])]

#text("In Exercise 10, could you elaborate a bit what one needs to show in order to show “identifiable”? The solutions seem to be given, what else is one supposed to show?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-555601")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2020")])]

#text("The exercise asks to show that the given identification is an isomorphism of LCA groups (so the identification need to be group isomorphisms and also topological homeomorphisms).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-555412")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2020")])]

#text("Something is missing in Line 3 of Exercise 9.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 2: Some connections with the Fourier transform | What's new")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-620192")[#strong[#text("246B, Notes 2: Some connections with the Fourier transform | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2021")])]

#text("[…] the space of tempered distributions, but we will not pursue this direction here; see for instance these lecture notes of mine for a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-622510")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2021")])]

#text("Is there a way to see (or understand the reason behind coining) these terms “frequency space”, “physical space” ?")

#emph[#text("[See ")#link("https://en.wikipedia.org/wiki/Frequency_domain")[#text("https://en.wikipedia.org/wiki/Frequency_domain")]#text(" and ")#link("https://en.wikipedia.org/wiki/Time-domain")[#text("https://en.wikipedia.org/wiki/Time-domain")]#text(" in signal processing (in image processing one uses spatial domains instead of time domains). -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-630257")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2021")])]

#text("Let ")#mi("f(x)=1_{[a,b]}(x)")#text(" be the characteristic function of the interval ")#mi("[a,b]\\subset [-\\pi,\\pi]")#text(". Suppose ")#mi("0<\\frac{b-a}{2}<\\pi")#text(". This is an example given in Stein-Shakarchi’s Fourier Analysis that one has a Fourier series that converges for every ")#mi("x")#text(" but does not converge absolutely for any ")#mi("x")#text(". The absolute convergence boils down to the series")

#tao-math("\\displaystyle \\sum_{n\\ge 1} \\frac{\\left|\\sin(n\\alpha)\\right|}{n}", block: false)

#text("where ")#mi("\\alpha=(b-a)/2")#text(". How can one show that ")#tao-math("\\left|\\sin(n\\alpha)\\right|\\geq C>0", block: false)#text(" uniformly for many ")#mi("n")#text(" so that the series above is divergent?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-630270")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2021")])]

#tao-math("\\left|\\sin(n\\alpha)\\right|=1", block: false)#text(" for infinitely many n, and we know ")#mi("\\sum\\frac{1}{n}")#text(" diverges.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-630327")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2021")])]

#text("When ")#mi("\\alpha")#text(" is a rational multiple of ")#mi("\\pi")#text(" this follows from the periodicity of ")#mi("\\sin(n\\alpha)")#text(". For irrational ")#mi("\\alpha")#text(" one can either use the ")#link("https://en.wikipedia.org/wiki/Equidistribution_theorem")[#text("equidistribution theorem")]#text(", or lower bound the sum by ")#mi("\\sum_{n \\geq 1} \\frac{\\sin(n\\alpha)^2}{n} = \\sum_{n \\geq 1} \\frac{1}{2n} - \\frac{\\cos(2n\\alpha)}{n}")#text(" and use either summation by parts or Fourier analysis to show that the second sum on the RHS converges while the first sum diverges.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-630706")[#strong[#text("J.")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2021")])]

#text("The sawtooth function defined by ")#mi("f(x)=(\\pi-x)/2")#text(" on the interval ")#mi("(0,2\\pi)")#text(" with ")#mi("f(0)=0")#text(" and extended by periodicity to all of ")#mi("\\mathbb{R}")#text(" is used to demonstrate the Gibbs phenomenon in Stein-Shakarchi. The Fourier series is given by ")#mi("\\sum_{n=1}^\\infty\\frac{\\sin nx}{n}")#text(". Working with the Riemann sum, one can show that the partial sum ")#mi("S_N(f)(\\pi/N)\\to \\int_0^\\pi\\frac{\\sin t}{t}\\;dt")#text(" as the page linked at the end of Exercise 25 shows.")

#text("Alternatively, if one works with the Dirichlet kernel, then")#linebreak()#text(" ")#mi("\\displaystyle  S_N(f)(x)=\\frac12\\int_0^x(D_N(t)-1)\\;dt")#linebreak()#text(" How can one give a uniform (in ")#mi("y\\in(0,\\pi]")#text(") bound for")#linebreak()#text(" ")#tao-math("\\left|\\sin y \\left(\\frac{1}{M\\sin\\frac{y}{M}}-\\frac{1}{y}\\right)\\right|", block: false)#linebreak()#text(" to show")#linebreak()#text(" ")#mi("\\displaystyle \\int_0^\\pi \\sin y \\left(\\frac{1}{M\\sin\\frac{y}{M}}-\\frac{1}{y}\\right)\\;dy\\to0")#linebreak()#text(" as ")#mi("M=N+1/2\\to\\infty")#text("?")

#emph[#text("[One can use the upper bound ")#mi("\\sin y \\leq y")#text(" for ")#mi("0 \\leq y \\leq \\pi")#text(", and the lower bound ")#mi("\\sin y \\geq cy")#text(" for small ")#mi("y")#text(" and some positive constant ")#mi("c")#text(" (for instance one has ")#mi("\\sin y \\geq \\frac{2}{\\pi} y")#text(" for ")#mi("0 \\leq y \\leq \\pi/2")#text("). -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-634444")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2021")])]

#text("If one considers the Fourier series of a periodic function ")#mi("f")#text(" on a closed interval, one can approximate the function by its first ")#mi("n")#text(" modes. This looks similar to the low-rank matrix approximation by SVD: ")#link("https://en.wikipedia.org/wiki/Singular_value_decomposition#Separable_models")[#text("https://en.wikipedia.org/wiki/Singular_value_decomposition#Separable_models")]

#text("Are there any connections between these two notions? Can the matrix approximation be viewed as Fourier series in some sense?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-634697")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2021")])]

#text("Yes; in the case when a matrix is a circulant matrix, the eigenvalues are the Fourier coefficients of the first row, and low rank approximations of the matrix correspond to partial Fourier series of that row.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-639460")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2022")])]

#text("Dear Prof. Tao:")#linebreak()#text(" You mentioned in the beginning of the notes that “Characters behave in a very simple manner with respect to translation (indeed, they are eigenfunctions of the translation action)”. How to see characters as the eigenfunctions of the translation?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-669325")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2022")])]

#text("Can the condition of being $\\latex L^1$ be relaxed to improperly integrable (e.g., the limit ")#mi("\\lim_{\\epsilon\\to0+}\\int_{\\epsilon}^{2\\pi}f(x)dx")#text(" exists) in the Riemann-Lebesgue lemma?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-669393")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2022")])]

#text("Don’t see why not. If the improper integral exists, then it also belongs to ")#mi("L^1")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-669436")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2022")])]

#text("The existence of ")#mi("\\lim_{\\epsilon\\to0+}\\int_{\\epsilon}^{2\\pi}f(x)dx")#text(" is NOT the same as that of ")#mi("\\lim_{\\epsilon\\to0+}\\int_{\\epsilon}^{2\\pi}|f(x)|dx")#text(" .")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6308aa7f6d65f5d412ee6ac224e36005670678d9d45c5b2a78a0ea6c8b2cf787-d205cf1d6740711231ab7b484f42e53651ac130e9db2c0328f96ae8266035737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of djmati11")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-678738")[#strong[#text("djmati11")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2023")])]

#text("Did the proof of Theorem 21 using spectral theorem appear anytime later on the blog? I have been unable to find it.")

#text("I tried to prove it myself, but it’s no longer as straightforward as in the finite-dimensional case, since operators can have continuous spectrum.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-678746")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2023")])]

#text("See for instance Exercise 22 of ")#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/")[#text("these later notes of mine")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-689626")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2026")])]

#text("In the compact case, one has a very concrete notion of orthogonality, as in Corollary~20: the multiplicative characters form an orthonormal set in the Hilbert space ")#mi("L^2(G)")#text(".")

#text("When ")#mi("G")#text(" is not compact (for instance ")#mi("G=\\mathbf{R}")#text("), is there a meaningful analogue of this orthogonality principle? More specifically, in what sense—if any—can the characters still be regarded as “orthogonal,” given that they no longer belong to ")#mi("L^2(G)")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-691540")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2026")])]

#text("Plancherel’s theorem would be the natural extension of this orthogonality principle to arbitrary locally compact abelian groups. (In non-compact settings, it is no longer so convenient to work with individual characters, but rather weighted linear combinations of such characters, i.e., (inverse) Fourier transforms.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-691543")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2026")])]

#text("I am still trying to understand concretely what replaces the pointwise orthogonality of characters in the non-compact case.")

#text("When one expands the inner product ")#mi("\\langle f, g \\rangle")#text(", an integral of the form")#linebreak()#mi("\\int_{\\mathbf{R}} e^{i(\\xi-\\eta)x}\\,dx")#linebreak()#text("appears, which at a purely formal level behaves like ")#mi("\\delta(\\xi-\\eta)")#text(".")

#text("Can one think of the role of this object as providing the underlying mechanism behind the Plancherel identity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-691544")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2026")])]

#text("Yes, one can view the Plancherel theorem on ")#mi("{\\bf R}")#text(" (and the associated Fourier inversion formula) as being equivalent to the identity ")#mi("\\int_{\\bf R} e^{2\\pi i(\\xi-\\eta) x}\\ dx = \\delta(\\xi-\\eta)")#text(" (as well as the dual identity ")#mi("\\int_{\\bf R} e^{-2\\pi i \\xi (x-y)}\\ d\\xi = \\delta(x-y)")#text("), both of which can be interpreted rigorously in the language of (tempered) distributions.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83895e75e71d6359c22ffbedf04122e437a0393241bdef58ad9de6d14ed7f03d-55297acf99110a8f404e8438b5c86c338fa5718c2c08dda1611360f49508a198.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bubbu0129")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-3/#comment-692664")[#strong[#text("bubbu0129")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2026")])]

#text("Two minor typos: In Exercise 26, the definition of the Fejér kernel should be ")#mi("F_n = 1/N \\cdots")#text("; In Exercise 27, the partial Fourier series of ")#mi("f")#text(" should be ")#mi("S_n f")#text(" (or ")#mi("D_n * f")#text("), to maintain consistency of notation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-127978")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2012")])]

#text("For Exercise 4, I can see how the assumptions imply that every compact set has zero measure. If G is sigma-compact, then we can cover G with countably many compact sets and come to the desired conclusion.")

#text("However, if G is not assumed to be sigma-compact, I don’t see why the fact that every compact set has zero measure would imply that the Haar measure in question is 0.")

#text("In other words, why can’t there exist a locally compact group with nontrivial Haar measures vanishing on every compact set?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-127983")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2012")])]

#text("Haar measures are (by definition) Radon measures, and thus inner regular. In particular, if they vanish on compact sets, they vanish everywhere.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-128080")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2012")])]

#text("For Exercise 8, I see how to prove local compactness when G is sigma-compact (invoking the Arzela-Ascoli theorem to deduce sequential compactness), but how does one handle the case when G is not sigma-compact? It seems that there is no Arzela-Ascoli to appeal to here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-128117")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2012")])]

#text("In the non-sigma-compact case one can use Tychonoff’s theorem instead of Arzela-Ascoli to obtain the desired compactness. The point is that the equicontinuity allows one to upgrade the product topology to the locally uniform topology.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-128211")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2012")])]

#text("In the definition of the Fourier transform, you write:")

#text("“In the remainder of this section, ")#mi("G")#text(" is a fixed LCA group with a non-trivial Haar measure ")#mi("\\mu")#text(".")

#text("Given an absolutely integrable function ")#mi("f \\in L^1(G)")#text(", we define the Fourier transform ")#mi("\\hat f: \\hat G \\rightarrow {\\bf C}")#text(" by the formula")

#mi("\\displaystyle \\hat f(\\xi) := \\int_G f(x) e^{-2\\pi i \\xi \\cdot x}\\ d\\mu(x).")#text("”")

#text("That is the Fourier transform formula for R^n, but I think here you mean to write the general formula for a LCA group i.e.")

#mi("\\displaystyle \\hat f(\\xi) := \\int_G f(x) \\overline{\\xi(x)} \\ d\\mu(x)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-128214")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2012")])]

#text("The action of ")#mi("\\xi")#text(" on ")#mi("x")#text(" is, by convention, denoted ")#mi("\\xi \\cdot x")#text(" instead of ")#mi("\\xi(x)")#text(" (see Definition 1), precisely in order to align the notation in the general LCA case with the Euclidean cases.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-128215")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2012")])]

#text("In this case, wouldn’t you want the formula to be")

#mi("\\displaystyle \\hat f(\\xi) := \\int_G f(x) \\overline{\\xi \\cdot x} \\ d\\mu(x)")

#text("rather than")

#mi("\\displaystyle \\hat f(\\xi) := \\int_G f(x) e^{-2\\pi i \\xi \\cdot x}\\ d\\mu(x) \\ ?")

#text("For example, if $\\latex G = \\mathbb{R}$ and we fix a character $\\latex \\xi_t(x) = e^{2 \\pi i tx}$ with the notation $\\latex \\xi \\cdot x = \\xi(x)$, then the formula that you have currently written would give")

#mi("\\displaystyle \\hat f(\\xi) := \\int_G f(x) e^{-2\\pi i {e^{2 \\pi i tx}}}\\ d\\mu(x)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-128217")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2012")])]

#text("Oh, I see. You write ")#mi("\\xi")#text(" to denote an additive character, rather than a multiplicative one. I think this makes more sense now.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-128569")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2012")])]

#text("Typo: “Corollary 3 The space of multiplicative chararacters…” should be “characters”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-128612")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2012")])]

#text("It seems that, lurking behind the formulation of the Plancherel theorem for compact groups, is the claim that a compact group has at most countably many characters. How does one see this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-128619")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2012")])]

#text("Compact metrisable groups have countably many characters, but in general a compact group may have uncountably many characters (e.g. an uncountable power of the unit circle). But this does not really cause any difficulty (one has to sum over uncountable index sets rather than countable ones in the Plancherel theorem, but in practice at most countably many of the summands are non-zero).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/535b8982adda52a880c72db15536b13f320f6cdc7d45a5fbbbf58a9095dde90d-bb5820a5c297e6e30da8807c8bdc1a4192224b1f1e5b1647554b8a04a7d394e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alabair")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-142175")[#strong[#text("alabair")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2012")])]

#text("Dear Professor,")#linebreak()#text(" My sincere thanks for this post which I qualified it as a true jewel.")#linebreak()#text(" my question is if it’s possible to define white noise probability space and white noise analysis by using the theorem 8(Bochner theorem) in LCA group G or more simply in a Lie group as is done by Bernt Øksendal in the book:” Malliavin Calculus for Lévy Processes with Applications for Finance”. I pain to choose a positive-definite functions to have a white noise probability measure. I think we must have something like:")#linebreak()#text(" $\\latex e^{-\\frac{1}{2}||\\phi||^2}$.")

#text("My deep apologies for the inconvenience caused if my question seems too silly.")#linebreak()#text(" With respect.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/535b8982adda52a880c72db15536b13f320f6cdc7d45a5fbbbf58a9095dde90d-bb5820a5c297e6e30da8807c8bdc1a4192224b1f1e5b1647554b8a04a7d394e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alabair")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-142215")[#strong[#text("alabair")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2012")])]

#text("Reblogged this on ")#link("http://alabair.wordpress.com/2012/05/09/63/")[#text("Alabair's Weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11334cee31284c052d43f7890abc43d7bae9aecf8097f0ab458a67fd58abcd89-ef76909ccfc3f362ef2a5855c59f9302524dd371a303dfc80557bbb8980f1830.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jurito")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-148264")[#strong[#text("Jurito")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2012")])]

#text("Dear prof. Tao,")#linebreak()#text(" I need a question regarding Exercise 11 (Riemann-Lebesgue lemma). I see how to finish the proof once the statement from your hint is prove. To prove the statement it is enough to prove it in the case where f is continuous (because of density of continuous functions in L1). I have to prove that")

#text("\\int | f(x-y) – f(x) | dx < epsilon, for all y in some open neighbourhood U of identity")

#text("This sounds trivial, but I don't see a correct argument. Of course, it seems that dominated convergence theorem should do the job, but one needs to have a sequence of ys converging to identitiy in order to properly use it. However, I don't see how to get desired set U from this argument.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-148266")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2012")])]

#text("Use the fact that continuous, compactly supported functions are uniformly continuous.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11334cee31284c052d43f7890abc43d7bae9aecf8097f0ab458a67fd58abcd89-ef76909ccfc3f362ef2a5855c59f9302524dd371a303dfc80557bbb8980f1830.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jurito")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-148273")[#strong[#text("Jurito")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2012")])]

#text("That was my second idea. The problem with that one was that G is not necessarily metrisable. Of course, I see how I would define uniform convergence for functions on general topological groups, but I don’t see how to adapt proof that continuous function with compact support implies uniformity. Could you recommend some reference for this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-148284")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2012")])]

#text("Write out the proof in full in the metrisable case (including the proof that continuous functions on compact sets are uniformly continuous). Try not to refer to the metric directly, but rely instead on balls. Then, replace the balls by more general open neighbourhoods.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11334cee31284c052d43f7890abc43d7bae9aecf8097f0ab458a67fd58abcd89-ef76909ccfc3f362ef2a5855c59f9302524dd371a303dfc80557bbb8980f1830.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jurito")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-148265")[#strong[#text("Jurito")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2012")])]

#text("Oh, and I also need a bit of help with proving that Fourier transform of every L1 function is continuous (first part of the same Exercise). It seems to rely on fact that most of the L1 mass of f comes from a compact set. Is this true and how to prove it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-150158")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2012")])]

#text("Dear Professor Tao: You mentioned ” The poset-theoretic concepts seem to be more related to the operations of integration and differentiation, or convolution and deconvolution, than to the Fourier transform – thus they are more like Fourier multipliers than Fourier transforms.” Is there a good reference to understand what you are informing here? I am not a professional mathematician but an engineer. Is there a reference that I could access??")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/535b8982adda52a880c72db15536b13f320f6cdc7d45a5fbbbf58a9095dde90d-bb5820a5c297e6e30da8807c8bdc1a4192224b1f1e5b1647554b8a04a7d394e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alabair")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-233786")[#strong[#text("alabair")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Dear Professor,")#linebreak()#text(" Can you give a probabilistic version of Bochner-(Milnos) theorem’s, in order to define the white noise process taking values in Lie group for exemple. As it was done in B. øksendal, white noise process is defined in the ")#mi("\\mathbb{R}^d")#text(" case.")#linebreak()#text(" Thank’s")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e867149d493a7150ab468a9a18def5708e9a34e3daffea9e77fbd0c5b527493-c4d479d2f4ed77509b0d1c303fd1a48de36baaca9f793217e845cbd5a158163b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rajeshd007")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-456589")[#strong[#text("rajeshd007")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2015")])]

#link("http://mathoverflow.net/q/208867/14414")[#text("http://mathoverflow.net/q/208867/14414")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e867149d493a7150ab468a9a18def5708e9a34e3daffea9e77fbd0c5b527493-c4d479d2f4ed77509b0d1c303fd1a48de36baaca9f793217e845cbd5a158163b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rajeshd007")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-456590")[#strong[#text("rajeshd007")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2015")])]

#text("Dear Prof. Tao,")

#text("I wish you had mentioned about the jump discontinuties and Fourier transform, in this article. Does this deviate from the article. Do Jump discontinuties are being studied by any one in the generalized setup of Fourier transform on groups/harmonic analasys. Appreciate any references.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5e2dd02545b191f779b9f037effee6f462d3e378d472ea477a266af4ce4a8bf-6e1e3d4ae0531c062046fa7f9238576d091166d6b1c132f91e7a8bec135ecb17.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 杜鹏")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-465279")[#strong[#text("杜鹏")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2016")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Do you have some opinion about this problem ")#link("http://mathoverflow.net/questions/228379/interpret-fourier-transform-as-limit-of-fourier-series")[#text("http://mathoverflow.net/questions/228379/interpret-fourier-transform-as-limit-of-fourier-series")]#linebreak()#text(" on mathoverflow?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-465973")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2016")])]

#text("Dear Prof. Tao,")

#text("In Exercise 7. (b) (existence of Haar measure),")#linebreak()#text(" can one just take g as the given f for the second claim?")#linebreak()#text(" Then the number (f:g) is surely greater or equal to 1.")#linebreak()#text(" Even we don`t need any epsilon concession.")#linebreak()#text(" Something`s strange.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-466020")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2016")])]

#text("Dear Prof. Tao,")

#text("In Exercise 7 (the existence of Haar measure, general case),")

#text("I am trying to prove the second statement of (b), with the idea that")#linebreak()#text(" we cover the support of f by finitely many translations U_{i} (i=1, …, n) of U the open neighborhood of the identity. We may assume that this U possesses the nice property about the uniform continuity of f.")

#text("Up to now all are good but I have some troubles in dealing with inequalities.")#linebreak()#text(" I guess that we have to cover K by U_{i}`s nicely (assuming the minimality of n, for instance). Am I right? Or, could you give me more hints?")

#text("Best")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-466028")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2016")])]

#text("Firstly, there is an erratum to this exercise that I forgot to update here, which is that the function ")#mi("g")#text(" should be supported in a small neighbourhood ")#mi("U")#text(" of the identity, but you have already chosen ")#mi("g")#text(" in the spirit intended. Actually this part (b) turns out to be a bit trickier than the subsequent parts of the exercise (which do not directly depend on (b), but for which (b) serves as motivation). I may separate it off into a separate exercise in a subsequent edition of the textbook that these notes are based off of.")

#text("We can normalise ")#mi("\\int_G g\\ d\\mu = 1")#text(". The point is that one can approximate the function ")#mi("f(x)")#text(" (using the uniform continuity of ")#mi("f")#text(") by the convolution integral ")#mi("\\int_G f(y) \\tau_y g(x)\\ d\\mu(y)")#text(", and this integral can in turn be approximated (using the uniform continuity of both ")#mi("f")#text(" and ")#mi("g")#text(") by a “Riemann sum” ")#mi("\\sum_j \\int_{U_j} f(y) \\tau_{y_j} g(x) d\\mu(y)")#text(" for some partition of ")#mi("G")#text(" into sets ")#mi("U_1,U_2,\\dots")#text(", where ")#mi("y_j")#text(" is a point in $U_j$. This uniformly approximates ")#mi("f")#text(" by a suitable combination of shifts of ")#mi("g")#text(", but isn’t quite a majorisation. To achieve the majorisation, we can apply a similar uniform approximation to some bump function that equals (say) ")#mi("1")#text(" on the support of ")#mi("f")#text(", and add a small multiple of that approximation to the previous approximation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-466120")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2016")])]

#text("If ")#mi("\\xi\\in \\hat G")#text(" is an additive character, then the function ")#mi("x\\mapsto e^{2\\pi i\\xi\\cdot x}")#text(" is a multiplicative character. This can be checked directly. Why ")#emph[#text("conversely every multiplicative character arises uniquely from an additive character in this fashion")]#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-466133")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2016")])]

#text("The map ")#mi("e: {\\bf R}/{\\bf Z} \\to S^1")#text(" that sends ")#mi("\\theta")#text(" to ")#mi("e^{2\\pi i \\theta}")#text(" is a homeomorphism.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-466121")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2016")])]

#text("Do you have a hint for Exercise 9a (e.g. d=1)? I have no idea how to approach it by using the definition of the Pontryagin dual.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-466134")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2016")])]

#text("A homomorphism ")#mi("\\phi: {\\bf Z} \\to G")#text(" from ")#mi("{\\bf Z}")#text(" to any group ")#mi("G")#text(" is completely determined by its value ")#mi("\\phi(1)")#text(" at the generator ")#mi("1")#text(". (This case of Pontryagin duality corresponds to the operation of forming a Fourier series out of a discrete sequence of coefficients, also known as the z-transform in electrical engineering.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-466122")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2016")])]

#text("When doing Fourier transform to functions on ")#mi("\\bf{R}")#text(", one gets functions on ")#mi("\\bf{R}")#text(". This corresponds to Exercise 9 (b). When doing Fourier transform to functions on ")#mi("\\bf{R/Z}")#text(", (or functions on bounded intervals), one gets the Fourier coefficients which are functions on ")#mi("\\bf{Z}")#text(". This corresponds to Exercise 9(c). These two cases appear in the undergraduate Fourier Analysis course. Would you explain what is the case in Ex 9(a) (probably also in the context of an undergraduate Fourier Analysis course)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-469808")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2016")])]

#text("Assuming the Fourier inversion theorem (")#mi("\\mathcal{F}\\mathcal{F}^*f=f")#text(" for ")#mi("f\\in\\mathcal{S}(\\bf{R})")#text(") is true in the one-dimensional case, can one directly show that it is true for the general ")#mi("d")#text(" dimensional case?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-469810")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2016")])]

#text("Yes; the ")#mi("d")#text("-dimensional Fourier transform is the composition of ")#mi("d")#text(" one-dimensional Fourier transforms (applied in each variable separately, and composed in an arbitrary order), and similarly for the adjoint Fourier transform.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-470114")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2016")])]

#text("I’m confused about the topology on ")#mi("\\mathcal{S}")#text(". On the one hand, it is not a normed vector space but a seminormed space, though it has a metrizable topology. One the other hand, in the setting of Theorem 7, ")#mi("\\mathcal{S}\\subset L^2")#text(" is a normed vector space with the L^2 norm ")#mi("\\|\\|_{L^2}")#text(". How should one really understand the structure of ")#mi("\\mathcal{S}")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-470133")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2016")])]

#text("In Exercise 30, what is ")#mi("C_0(\\mathbb{R})")#text("? Do you mean continuous functions with compact support (or decaying to ")#mi("0")#text(" at infinity)? I don’t find the definition of it in this note.")

#emph[#text("[")#mi("C_0")#text(" is defined in Exercise 11. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc2dd4ebeefc8f65e28a9c9451011d784b1081d92dd66b32a550061eaa39c9a7-355f8ffe79f68f85468dad0c9a96b005398fdabe28bcea7a6de74736a6df92bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-470664")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2016")])]

#text("Dear Prof. Tao,")

#text("is there an elegant solution to exercise 9 (e)? One needs to show, that every character of the closed subgroup ")#mi("H")#text(" can be extended to ")#mi("G")#text(", but I don’t see how this can be done without further methods.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-470698")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2016")])]

#text("Yes, you’re right, this part of the exercise is non-trivial and requires Pontryagin duality.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/202d782a6c674aa1165885d1d44fcd3a3e7b152494211611df5675be7148eb65-e22cc6b6e986a928a5769a8644a8c792914a9da8ee7f8c0fff3f4d82eeffa2c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-473557")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2016")])]

#text("Dear Prof Tao,")

#text("actual computation of fourier transforms can be tricky, for example, is there a way, or possible approach to compute the fourier transform of: exp(-icosx)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-473561")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2016")])]

#text("Well, an exact formula for the Fourier transform is usually too unrealistic of an expectation (for much the same reason as most indefinite integrals do not have any explicit closed form). However, the ")#link("https://en.wikipedia.org/wiki/Stationary_phase_approximation")[#text("method of stationary phase")]#text(" (and its older sibling, the ")#link("https://en.wikipedia.org/wiki/Method_of_steepest_descent")[#text("method of steepest descent")]#text(") can be used to obtain asymptotics for many Fourier transforms, and this suffices for many applications in analysis and PDE.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98d192abd70f5311db8ec60dec56a48604f76cb7ff6a4cf4f5df43803680c3ff-cb5dcadf7bcf8b56cb8857c450f2fddd18645e59e478b53d2f6ab76b378a6646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jhon Manugal")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-473647")[#strong[#text("Jhon Manugal")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2016")])]

#mi("e^{iz \\, \\sin x} = \\sum_{m = - \\infty}^\\infty J_m(z) \\, e^{i m x}")

#link("https://en.wikipedia.org/wiki/Bessel_function#Properties")[#text("https://en.wikipedia.org/wiki/Bessel_function#Properties")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-478335")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2017")])]

#text("In the LHS (according to the above Wikipedia article) ")#mi("\\sin x")#text(" should be ")#mi("\\cos x")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-478336")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2017")])]

#text("Correction: according to the Wikipedia article on the Jacobi-Anger expansion, if ")#mi("\\sin x")#text(" in the LHS is replaced by ")#mi("\\cos x")#text(" then the coefficients ")#mi("J_m(z)")#text(" in the RHS should be multiplied by ")#mi("i^m")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-478178")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2017")])]

#text("To anyone who reads this,")#linebreak()#text(" In Exercise 43 of the proof of Plancherel theorem for compact case via Gelfand theory, I don`t see where the compactness is critically used. Can anybody tell me this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-478397")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2017")])]

#text("Corollary 3 breaks down in the non-compact case (the characters do not even lie in ")#mi("L^2")#text(", in fact, as the Haar measure now has infinite measure.) Also, ")#mi("L^2(G)")#text(" no longer embeds into ")#mi("L^1(G)")#text(". Theorem 4 is basically Corollary 3 combined with the injectivity of the Fourier transform on ")#mi("L^1(G)")#text("; the latter is indeed true for all LCA groups, which is the main conclusion of Exercise 43.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-478324")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2017")])]

#text("How can we see Fourier analysis as Laplacian in spectral theory, in the last paragraph? Is there any reference?")

#emph[#text("[See e.g. ")#link("http://www.sciencedirect.com/science/article/pii/0022123689900049")[#text("http://www.sciencedirect.com/science/article/pii/0022123689900049")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-478468")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2017")])]

#text("“For the standard torus ")#mi("{({\\bf R}/{\\bf Z})^d}")#text(", one can obtain a Haar measure by identifying this torus with ")#mi("{[0,1)^d}")#text(" in the usual manner and then taking Lebesgue measure on the latter space. This Haar measure is a probability measure.”")

#text("Would you elaborate what “identifying” means here? And what is the “usual manner” you are referring to?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-478513")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2017")])]

#mi("[0,1)^d")#text(" is a ")#link("https://en.wikipedia.org/wiki/Fundamental_domain")[#text("fundamental domain")]#text(" for the torus ")#mi("({\\bf R}/{\\bf Z})^d")#text(", so in particular there is a bijection ")#mi("\\iota: ({\\bf R}/{\\bf Z})^d \\to [0,1)^d")#text(" that can be used to perform the identification. Thus, for instance, the Haar measure of a set ")#mi("E \\subset ({\\bf R}/{\\bf Z})^d")#text(" can be defined as the Lebesgue measure of ")#mi("\\iota(E)")#text(". (One has to check that this is indeed a Haar measure, but this is not too difficult.)")

#text("Alternatively, one can identify (= give an explicit one-to-one correspondence between) functions from ")#mi("({\\bf R}/{\\bf Z})^d")#text(" to (say) the complex numbers ")#mi("{\\bf C}")#text(" with functions ")#mi("f")#text(" from ")#mi("{\\bf R}^d")#text(" to ")#mi("{\\bf C}")#text(" that are ")#mi("{\\bf Z}^d")#text("-periodic (thus ")#mi("f(x+n) = f(x)")#text(" whenever ")#mi("x \\in {\\bf R}^d")#text(" and ")#mi("n \\in {\\bf Z}^d")#text("). The integral of such a function against Haar measure is then the same as ")#mi("\\int_{[0,1)^d} f(x)\\ dx")#text(" (many other formulae for this integral are also available, e.g. ")#mi("\\lim_{N \\to \\infty} \\frac{1}{(2N)^d} \\int_{[-N,N]^d} f(x)\\ dx")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/760ddd8bad27c570c5995a8ca954c5a38fd4fac69f38771b25a6b6db36d6b11e-4ad57592ce78782880a2c818635ada04dd6ba4cba69ace173598d068d4466749.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Romain Viguier")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-478526")[#strong[#text("Romain Viguier")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2017")])]

#text("i see what you mean by Haar measure, but there is too many dimensions that are in each other and find")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-478931")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2017")])]

#text("Let ")#mi("m")#text(" be the Lebesgue measure on ")#mi("[0,1)")#text(". How should one should the inner regularity for ")#mi("\\mu:=m\\circ\\iota")#text("?")

#mi("\\displaystyle m(\\iota(E))=\\sup\\{m(\\iota(K))\\:K\\subset E, K\\textrm{ compact in } {\\bf R}/{\\bf Z}\\}.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-478938")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2017")])]

#text("This follows easily from the inner regularity of Lebesgue measure (it may help to divide into two cases, e.g. ")#mi("E \\subset [0.1, 0.9] \\text{ mod } 1")#text(", and ")#mi("E \\subset [0.6, 1.4] \\text{ mod } 1")#text(", and then glue the two cases together). Alternatively one can apply the Riesz representation theorem starting with the functional from ")#mi("C({\\bf R}/{\\bf Z})")#text(" to ")#mi("{\\bf R}")#text(" that takes a function ")#mi("f: {\\bf R}/{\\bf Z} \\to {\\bf R}")#text(" to its mean ")#mi("\\int_0^1 f(x \\text{ mod } 1)\\ dx")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-478945")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2017")])]

#text("Thanks for the comment! I would be interested in seeing a little bit more details. Now I don’t see how to build up a clear connection between compact sets in ")#mi("{\\bf R}/{\\bf Z}")#text(" and those in the fundamental domain ")#mi("[0,1)")#text(" (which is not homeomorphic to ")#mi("{\\bf R}/{\\bf Z}")#text("), which should give the desired inner regularity. For instance, let ")#mi("E =[0.2, 0.8] \\text{ mod } 1")#text(". Then clearly by the inner regularity of Lebesgue measure, one has")

#text("$displaystyle m(\\iota(E))=\\sup\\{m(K)\\:K\\subset \\iota(E), K\\textrm{ compact in } [0,1)\\}.$")

#text("However, how can one show that")

#text("$displaystyle m(\\iota(E))=\\sup\\{m(\\iota(K))\\:K\\subset E, K\\textrm{ compact in } {\\bf R}/{\\bf Z}\\}?$")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/760ddd8bad27c570c5995a8ca954c5a38fd4fac69f38771b25a6b6db36d6b11e-4ad57592ce78782880a2c818635ada04dd6ba4cba69ace173598d068d4466749.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Romain Viguier")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-478519")[#strong[#text("Romain Viguier")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2017")])]

#text("Let A and B be 2 set such as the cartesian product A x B is in the form : f(A) f(B) and f(A) \\bigcup f(B).")#linebreak()#text(" We can decompose f(a) as following : f(A) = f(a1) \\times f(ai) \\times … \\times \\infty. These functions are local horizontal asymptotes.")#linebreak()#text(" In the same way, one has f(b1) \\times f(bi) \\times … \\times \\infty. These functions are local vertical asymptotes.")#linebreak()#text(" For all a and all b, we have a space whish is defined as this :")#linebreak()#text(" lim \\stackrel{\\rightarrow}{0} f(a) \\times lim \\stackrel{\\rightarrow}{0} f(b) \\cong")#linebreak()#text(" \\phi with \\phi a coefficient of proportionality wish is the relation between the local to the global.")#linebreak()#text(" Thus, we have N \\Rightarrow C \\Rightarrow N an infinity of time.")#linebreak()#text(" For exemple : if E = [ \\sum \\phi ], then E \\times E = C.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/760ddd8bad27c570c5995a8ca954c5a38fd4fac69f38771b25a6b6db36d6b11e-4ad57592ce78782880a2c818635ada04dd6ba4cba69ace173598d068d4466749.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Romain Viguier")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-478520")[#strong[#text("Romain Viguier")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2017")])]

#text("* f(A) \\propto f(B) at the beginning")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-478990")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2017")])]

#text("In Definition 1, ")#mi("S^1")#text(" and ")#mi("{\\bf R}/{\\bf Z}")#text(" have the same topological structure as well as the group structure. Does this imply that the multiplicative character and the additive character are actually the same thing in some sense?")

#emph[#text("[They are related to each other by an isomorphism of topological groups, but strictly speaking they are still distinct characters. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-478994")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2017")])]

#text("Under the Definition 1, it is said that the connection is given by the map ")#mi("x\\mapsto e^{2\\pi i\\xi\\cdot x}")#text(", the notation is a little confusing. Isn’t ")#mi("\\xi\\cdot x")#text(" an element of ")#mi("{\\bf R}/{\\bf Z}")#text("? Then what does ")#mi("e^{2\\pi i\\xi\\cdot x}")#text(" mean?")

#emph[#text("[The function ")#mi("\\theta \\mapsto e^{2\\pi i \\theta}")#text(" is ")#mi("1")#text("-periodic, so it descends from a function from ")#mi("{\\bf R}")#text(" to ")#mi("{\\bf C}")#text(", to a function from ")#mi("{\\bf R}/{\\bf Z}")#text(" to ")#mi("{\\bf C}")#text(", and it is a common “abuse of notation” to identify the two functions. -T]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-478993")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2017")])]

#text("A topological space is compact if and only if any collection of its closed sets having the finite intersection property has non-empty intersection. In Exercise 6e, since one can identify each probability measure ")#mi("\\mu")#text(" wit an element of the product space, I guess the nonempty-ness of the intersection some collection of closed sets implies the desired Haar measure. However, I don’t understand what collection of closed sets to consider. How does it have anything to do with (d)?")

#emph[#text("[Part (a) describes the Haar measure elements of the product space as the intersection of a family of closed sets, each of which will be nonempty thanks to (d). -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-478995")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2017")])]

#text("For Exercise 9, I’m not quite sure how the identification of LCA groups should be shown. For instance, in 9a, the (set) bijection is given already. Then one shows (i) the bijection is a (topology) homeomorphism (ii) the bijection is a (group) isomorphism. Would (i) and (ii) together be enough? (Does one need to prove further that the topological structure and group structure are “compatible” (the group operations are continuous) or it just follows from (i) and (ii)? )")

#emph[#text("[Yes, this is enough (assuming that one has already demonstrated that at least one of the spaces is a topological group) -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-478996")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2017")])]

#text("Is the topology in Exercise 8 for the Pontryagin dual a “canonical” one (does one have other choice?) so that all the exercise (e.g. Exercise 11) in this post use this one?")

#emph[#text("[Yes – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-483213")[#strong[#text("Legendre transform – foreXiv")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2017")]

#text("[…] Fourier transform for understanding translationally invariant systems?” can be answered by something like “Translationally invariant operations in the spatial domain correspond to multiplication in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-497954")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2018")])]

#text("To prove Theorem 7 using Exercise 30, I believe the bounded linear transformation theorem is needed (")#link("https://en.wikipedia.org/wiki/Continuous_linear_extension")[#text("https://en.wikipedia.org/wiki/Continuous_linear_extension")]#text(") or one needs to repeat essentially the argument of the whole proof. (To my knowledge, I don’t know if there is another way to do it.) Was it proved or mentioned somewhere in the course notes or do you assume it as a trivial fact?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-498013")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2018")])]

#text("In Exercise 30, suppose ")#mi("f")#text(" is in ")#mi("L^p")#text(" for two different ")#mi("p")#text("‘s, say ")#mi("f\\in L^1\\cap L^2")#text(". Can one find a sequence ")#mi("f_k")#text(" in ")#mi("\\mathcal{S}")#text(" so that the sequence converges to ")#mi("f")#text(" in ")#emph[#text("both")]#text(" the ")#mi("L^1")#text(" norm and the ")#mi("L^2")#text(" norm?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-498051")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2018")])]

#text("Yes; this is a good exercise for you to work out.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-498092")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2018")])]

#text("If one uses an approximation to the identity, ")#mi("\\phi_n\\in C_c^\\infty")#text(", then")#linebreak()#text(" ")#mi("\\displaystyle \\phi_n*f\\to f")#linebreak()#text(" in both ")#mi("L^1")#text(" and ")#mi("L^2")#text(" for ")#mi("f\\in L^1\\cap L^2")#text(". This seems to be quite close to what one wants here. But there is no guarantee that")#linebreak()#text(" ")#mi("\\displaystyle \\phi_n*f\\in \\mathcal{S}.")#linebreak()#text(" :-(")

#text("On the other hand, since ")#mi("f\\in L^1")#text(", there exists ")#mi("g\\in C_c")#text(" so that ")#tao-math("\\left\\|f-g\\right\\|_1\\leq\\epsilon", block: false)#text(" and ")#tao-math("\\left\\|\\phi_n*g-g\\right\\|_1<\\epsilon", block: false)#text(". So one can approximate ")#mi("f\\in L^1")#text(" by")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\|f-\\phi_n*g\\right\\|_1\\leq 2\\epsilon.", block: false)#linebreak()#text(" where ")#mi("\\phi_n*g\\in C_c^\\infty")#text(".")

#text("Since ")#mi("f\\in L^2")#text(" as well, similarly one has")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\|f-\\phi_n*h\\right\\|_2\\leq 2\\epsilon", block: false)#linebreak()#text(" where ")#mi("\\phi_n*h\\in C_c^\\infty")#text(". But then one has two different sequences, ")#mi("\\phi_n*h")#text(" and ")#mi("\\phi_n*g")#text(". :-(")#linebreak()#text(" Is there a way to \"combine\" them together?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-498016")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2018")])]

#text("Denote the ")#mi("L^1")#text(" Fourier transform definition as ")#mi("\\hat f")#text(" and the ")#mi("L^2")#text(" version by Plancherel as ")#mi("\\mathcal{F}f")#text(". If ")#mi("f\\in \\mathcal{S}")#text(" then these two versions agree.")

#text("In Exercise 34, suppose I can find a sequence ")#mi("f_k")#text(" in the Schwartz space ")#mi("\\mathcal{S}")#text(" that ")#mi("f_k\\to f")#text(" in both the ")#mi("L^1")#text(" and ")#mi("L^2")#text(" norms. Then I can conclude that ")#mi("\\hat{f_k}\\to\\hat{f}")#text(" uniformly and ")#mi("\\hat{f_k}\\to \\mathcal{F}f")#text(" in ")#mi("L^2")#text(" by continuity. But these two modes of convergence are different… How can one conclude that")#linebreak()#text(" ")#mi("\\hat{f}=\\mathcal{F}f")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-498052")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2018")])]

#text("There are several ways to proceed here. One is to observe that both modes of convergence are stronger than distributional convergence, which has unique limits. Another is to upgrade the L^2 convergence to pointwise almost everywhere convergence by passing to a subsequence.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-498025")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2018")])]

#text("Wolff made an argument in his notes on harmonic analysis that if one can show that")

#mi("\\displaystyle \\int \\hat f\\psi = \\int f\\hat\\psi")#linebreak()#text(" for ")#mi("f\\in L^1\\cap L^2")#text(" and ")#mi("\\psi\\in\\mathcal{S}")#text(", then one can conclude that this is also true for ")#mi("f\\in L^2")#text(" and ")#mi("\\psi\\in\\mathcal{S}")#text(" by Plancherel theorem. Can anyone elaborate the implication?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-498054")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2018")])]

#text("Hint: ")#mi("L^1 \\cap L^2")#text(" is dense in ")#mi("L^2")#text(", and inner products with ")#mi("\\psi")#text(" or ")#mi("\\hat \\psi")#text(" are continuous in the ")#mi("L^2")#text(" topology.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e68e5a0aa39dbc932596a1b6caee5a64508bef626e002e7fc8c08840633ac04-5d653baf02edff20eea2678b8816e31deeff1a6325f4fb34afb36e4c99af81d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Ramond")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-503705")[#strong[#text("Paul Ramond")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2018")])]

#text("Dear Pr Tao")

#text("Thank you for this great note. I am concerned about the Heisenberg uncertainty principle, Ex 36, the very last equation. Shouldn’t the whole integrand be squared, as it is the L_2 norm ?")#linebreak()#text(" Besides, can you give a reference as to how to optimize with respect to a and b in this exercise ? I don’t know how to start, and not sure what it means actually.")

#text("Thank you again.")

#text("– Paul R.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-503710")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2018")])]

#text("Thanks for the correction! Examples of optimisation can be found in the previous blog post ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-504360")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2018")])]

#text("In (8), is the minus sign purely from the convention? Remark1 says something about the constant ")#mi("2\\pi")#text(". I’m wondering if there is any particular reason one puts a minus sign in the exponent in the definition (8).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-504366")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2018")])]

#text("The sign is mostly a convention. I prefer to have the minus sign in the Fourier transform so that it does not appear in the inverse Fourier transform, so that the Fourier inversion formula becomes a device for representing a function ")#mi("f(x)")#text(" as a superposition of plane waves ")#mi("e^{2\\pi i x \\xi}")#text(" without the minus sign present.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-507323")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2018")])]

#text("(I’m not good at English, so there may be many English mistakes.)")

#text("Dear Professor Tao,")

#text("In Exercise 5, how can I prove that the dual of L^1 is L^(infinity)?")

#text("I used exercise 1 and took coset decomposition of G, and used duality theorem, I could get elements of the L^(infinity) space over each coset of G, but couldn’t prove that they are glued together to the element of the L^(infinity) space over G.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-507476")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2018")])]

#text("Ah, this is a subtlety I had not previously realised… the question was not correct as stated, one needs to replace ")#mi("L^\\infty(G)")#text(" by a “local” version in which one works with functions ")#mi("f: G \\to {\\bf C}")#text(" (not necessarily globally measurable!) whose restriction to every finite measure set lies in ")#mi("L^\\infty")#text(" (with uniform bounds on the norm), and with two such functions declared equivalent if they agree locally almost everywhere (a.e. on every finite measure subset). I’ve reworded the exercise accordingly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509031")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2018")])]

#text("In Wolff’s Lecture notes on Harmonic Analysis (Chapter 4), when discussing")#linebreak()#text(" the Fourier transform of the function")

#tao-math("\\displaystyle h_a(x)=\\frac{\\Gamma(a/2)}{\\pi^{a/2}}\\left|x\\right|^{-a}", block: false)

#text("the author claims without proof the following:")

#text("for ")#mi("\\phi\\in\\mathcal{S}(\\mathbb{R}^n)")#text(", where ")#mi("\\mathcal{S}")#text(" denotes the Schwartz space, the map")

#tao-math("\\displaystyle z\\mapsto \\int \\left|x\\right|^{-z}\\phi(x)\\ dx", block: false)

#text("is analytic in the “indicated regime” (It is unclear in Wolff’s notes where the “indicated regime” is.), which may be done by using the dominated convergence theorem to justify complex differentiation under the integral sign.")

#text("How would you apply the dominated convergence theorem here? Can one find a dominated function to bound")

#tao-math("\\displaystyle \\int \\big|\\left|x\\right|^{-z}(-\\log \\left|x\\right|)\\phi(x)\\big|\\ dx\\ ?", block: false)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509047")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2018")])]

#text("Sure (as long as ")#mi("\\sigma^{\\prime} \\leq \\mathrm{Re}(z) \\leq \\sigma")#text(" for some ")#mi("\\sigma^{\\prime} \\leq \\sigma < n")#text("), one can just use ")#tao-math("(\\left|x\\right|^{-\\sigma} + \\left|x\\right|^{-\\sigma^{\\prime}}) \\left|\\log \\left|x\\right|\\right| \\left|\\phi(x)\\right|", block: false)#text(" as the dominating function. Actually it is slightly easier to use Morera's theorem to establish analyticity, as one can then appeal to Fubini's theorem rather than trying to justify differentiation under the integral sign.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509256")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2018")])]

#text("In your 247A notes2(")#link("http://www.math.ucla.edu/~tao/247a.1.06f/notes2.pdf")[#text("http://www.math.ucla.edu/~tao/247a.1.06f/notes2.pdf")]#text("), in the discussion of the Hausdorff-Young inequality (page 21), the following function is considered:")

#mi("\\displaystyle \\phi(x)=e_{\\tau}(x)g_\\tau(x)")

#text("where ")#mi("g")#text(" is the standard Gaussian ")#tao-math("g(x):=e^{-\\pi\\left|x\\right|^2}", block: false)#text(" and ")#mi("e_\\tau(x)=e^{2\\pi i x\\cdot \\tau}")#text(", ")#mi("g_\\tau(x)=g(x-\\tau)")#text(". (I consider only one term in the definition of ")#mi("f")#text(" and take ")#mi("\\tau=nv")#text(".)")

#text("I got that the Fourier transform is given by")#linebreak()#text(" ")#tao-math("\\displaystyle \\hat{\\phi}(\\xi) = \\widehat{g_\\tau}(\\xi-\\tau) =e^{-2\\pi i\\tau\\cdot(\\xi-\\tau)}\\hat{g}(\\xi-\\tau) =e^{-2\\pi i\\tau\\cdot(\\xi-\\tau)} e^{-\\pi \\left|\\xi-\\tau\\right|^2}", block: false)

#text("which is different from your calculation:")

#tao-math("\\displaystyle \\hat{\\phi}(\\xi) =e^{-2\\pi i\\tau\\cdot\\xi} e^{-\\pi \\left|\\xi-\\tau\\right|^2}", block: false)

#text("I tried several times but cannot find my mistakes. Where did I go wrong?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509266")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2018")])]

#text("Ah, there is a phase correction that needs to be inserted. If one inserts a factor of ")#tao-math("e^{\\pi i \\left|\\tau\\right|^2}", block: false)#text(" in the summand for ")#mi("f")#text(" (and for ")#mi("{\\mathcal F}")#text(") then the rest of the discussion can proceed without difficulty.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509339")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("I think you mean a factor of ")#tao-math("e^{-\\pi i \\left|\\tau\\right|^2}", block: false)#text("? The calculation in the previous comment shows that")#linebreak()#text(" if")#linebreak()#text(" ")#tao-math("\\displaystyle \\phi(x)=e_\\tau(x) g_\\tau(x) e^{-\\pi i \\left|\\tau\\right|^2}", block: false)#linebreak()#text(" then")#linebreak()#text(" ")#tao-math("\\displaystyle \\hat{\\phi}(\\xi)  =e^{-2\\pi i\\tau\\cdot(\\xi-\\tau)} e^{-\\pi \\left|\\xi-\\tau\\right|^2} e^{-\\pi i \\left|\\tau\\right|^2} =e^{-2\\pi i\\tau\\cdot(\\xi)} e^{-\\pi \\left|\\xi-\\tau\\right|^2} e^{\\pi i \\left|\\tau\\right|^2} =\\overline{\\phi(\\xi)}", block: false)#linebreak()#text(" So the summand for ")#mi("f")#text(" and its Fourier transform still have the desired properties.")

#emph[#text("[Ah, you are right; I had made a sign error. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509340")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("By translation invariance and the triangle inequality, one can show that")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\|f\\right\\|_p\\lesssim N^{1/p}", block: false)#linebreak()#text(" for ")#mi("p=1")#text(". In order to establish the estimate for all ")#mi("p")#text(" one needs the case for ")#mi("p=\\infty")#text(" as well. But applying triangle inequality again one gets")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\|f\\right\\|_\\infty\\lesssim N", block: false)#linebreak()#text(" which is different from the desired bound")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\|f\\right\\|_\\infty\\lesssim N^{1/\\infty}=1.", block: false)#linebreak()#text(" Intuitively, since ")#tao-math("\\left|nv-x\\right|", block: false)#text(" can not be zero for all ")#mi("n")#text(", one should expect that")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\|f\\right\\|_\\infty\\lesssim N", block: false)#linebreak()#text(" would be an overkill.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509346")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("For any given ")#mi("x")#text(", the arithmetic progression ")#mi("nv-x")#text(" is only close to zero for at most one value of ")#mi("n")#text("; indeed, if ")#mi("n_0")#text(" is the integer that minimises ")#tao-math("\\left|nv-x\\right|", block: false)#text(", then we have ")#tao-math("\\left|nv-x\\right| \\gtrsim \\left|n-n_0\\right| v", block: false)#text(" for all the other values of ")#mi("n")#text(", by the triangle inequality. So the sum ")#mi("g(x-nv)")#text(" is highly convergent (thanks the rapid decay of the Gaussian) giving the required bound of O(1).")

#text("(As a general rule of thumb, one expects rapidly decreasing functions such as the gaussian to behave in the same fashion as compactly supported functions, in that estimates that are true for the latter tend to also be true for the former. The intuition to have is not that “")#mi("g(x)")#text(" is non-zero everywhere”, but rather “")#mi("g(x)")#text(" is negligible unless ")#mi("x=O(1)")#text("“.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509365")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("In this argument (and the whole proof for showing ")#tao-math("\\left\\|f\\right\\|_p\\sim_p N^{1/p}", block: false)#text("), it seems that one only needs ")#tao-math("\\left|v\\right|>0", block: false)#text(". Where does one need ")#tao-math("\\left|v\\right|", block: false)#text(" be large?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509369")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("If ")#mi("v")#text(" is too small, one runs into the danger that the various summands in ")#mi("f")#text(" may start interfering with each other, leading to an ")#mi("L^2")#text(" norm that is unexpectedly small due to cancellation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509411")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("How can one calculate ")#tao-math("\\left\\|f\\right\\|_2", block: false)#text(" by hand and thus establish the lower bound?")

#tao-math("\\displaystyle \\left|f(x)\\right|^2 =\\sum_{n=1}^Ne^{-2\\pi\\left|nv-x\\right|^2} +\\sum_{1\\leq m,n\\leq N;\\\\m\\neq n}e^{-\\pi(\\left|nv-x\\right|^2+\\left|mv-x\\right|^2)}e^{i(\\beta_n-\\beta_m)}=:I+J", block: false)#linebreak()#text(" where")#linebreak()#text(" ")#mi("\\displaystyle \\beta_n=\\pi(nv)\\cdot(2x-nv)")#linebreak()#text(" Without $J$ (but unfortunately it is there), one could immediately conclude by translation invariance that")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\|f\\right\\|_2^2\\sim N", block: false)#linebreak()#text(" and hence the desired lower bound:")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\|f\\right\\|_2^2\\gtrsim N.", block: false)#linebreak()#text(" How could the magnitude of $v$ cause cancellation in $I+J$?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509412")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("If ")#mi("n \\neq m")#text(", then ")#tao-math("\\left|nv-x\\right|^2 + \\left|mv-x\\right|^2 \\to \\infty", block: false)#text(" as ")#mi("v \\to \\infty")#text(".")

#text("I recommend you draw some pictures to sketch what all the functions look like here; it should then become visually obvious why the ")#mi("L^p")#text(" norms should be what they are predicted to be, and why having ")#mi("v")#text(" large would be advantageous.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509417")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("True that when ")#mi("n\\neq m")#text(", ")#tao-math("\\left|nv-x\\right|^2+\\left|mv-x\\right|^2\\to\\infty", block: false)#text(" as ")#tao-math("\\left|v\\right|\\to\\infty", block: false)#text(". But this is also true for ")#mi("n=m")#text(" as well?")

#text("I guess you meant that")#linebreak()#text(" ")#tao-math("\\displaystyle \\int_{\\mathbf{R}^d}\\left|f(x)\\right|^2\\ dx = I+J", block: false)#linebreak()#text(" where")#linebreak()#text(" ")#tao-math("\\displaystyle I=\\int \\sum_{n=1}^Ne^{-2\\pi\\left|nv-x\\right|^2} =\\sum \\int e^{-2\\left|x\\right|^2}\\sim N", block: false)#linebreak()#text(" and")#linebreak()#text(" ")#tao-math("\\displaystyle J=\\sum_{1\\leq m,n\\leq N;\\\\m\\neq n}\\int e^{-\\pi(\\left|nv-x\\right|^2+\\left|mv-x\\right|^2)}e^{i(\\beta_n-\\beta_m)} =(?)\\sum_{n\\neq m} \\int e^{-\\pi(\\left|nv-x\\right|^2+\\left|mv-x\\right|^2)}\\to 0", block: false)#linebreak()#text(" as ")#tao-math("\\left|v\\right|\\to\\infty", block: false)#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509426")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("By the triangle inequality,")#linebreak()#text(" ")#tao-math("\\displaystyle \\left|nv-x\\right| =\\big{\\left|\\left|nv-n_0v\\right|-\\left|n_0v-x\\right| \\right|}\\gtrsim_x \\left|n-n_0\\right| \\cdot \\left|v\\right|.", block: false)#linebreak()#text(" How did you get rid of the dependent of ")#mi("\\gtrsim_x")#text(" on ")#mi("x")#text("? Or the triangle inequality is used differently?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509435")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#tao-math("\\left|n-n_0\\right| v = \\left|nv - n_0 v\\right| \\leq \\left|nv-x\\right| + \\left|n_0v-x\\right| \\leq 2 \\left|nv-x\\right|", block: false)#text(".")

#text("Seriously, I recommend drawing pictures.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509532")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2018")])]

#text("Thanks for the suggestion!")

#text("One can use Mathematica to do the job of sketching. I plotted the function ")#mi("x\\mapsto f(x;v,N)")#text(" where")

#tao-math("\\displaystyle f(x;v,N):=\\sum_{n=1}^Ne^{-\\pi\\left|nv-x\\right|^2}e^{\\pi i(nv)\\cdot(2x-nv)}", block: false)

#text("for various values of ")#mi("v")#text(" and ")#mi("N")#text(".")

#text("For fixed ")#mi("N")#text(" (being large), one can see that the graph of the function looks very much like a summation of functions that have (")#mi("N")#text(") disjoint supports. The bigger ")#mi("v")#text(" is, the larger distance between the “supports” (the place where the function takes non-negligible values) of the ")#mi("N")#text(" functions in the summand, which matches intuitively that")

#tao-math("\\displaystyle \\left\\|f\\right\\|_p\\sim_p N^{1/p}", block: false)

#text("While one can indeed observe that those “supports” interfered with each other when ")#tao-math("\\left|v\\right|", block: false)#text(" is small, I don’t see how exactly small ")#tao-math("\\left|v\\right|", block: false)#text(" could “fail” the proof of")

#tao-math("\\displaystyle \\left\\|f\\right\\|_2\\gtrsim N^{1/2}", block: false)

#text("if one calculates directly the ")#mi("L^2")#text(" norm.")

#text("Could you give an example that has “unexpectedly small L^2 norm” you mentioned in the previous comment (")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/#comment-509369")[#text("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/#comment-509369")]#text(")?")

#text("(It seems that ")#tao-math("\\left\\|f(x;v,N)\\right\\|_2\\to \\|f(x;0,N\\|_2\\sim N^{1/2}", block: false)#text(" as ")#tao-math("\\left|v\\right|\\to 0", block: false)#text(" and I don’t observe any “cancellation”.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509539")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2018")])]

#text("The type of cancellation that could potentially happen would for instance occur in the sum ")#tao-math("e^{-\\pi \\left|x\\right|^2} - e^{-\\pi \\left|x-v\\right|^2}", block: false)#text(", whose ")#mi("L^2")#text(" norm becomes very small as ")#mi("v")#text(" is nonzero. Now, the function ")#mi("f")#text(" might not actually exhibit this sort of cancellation, but actually proving this when ")#mi("v")#text(" is small is non-trivial, whereas there is no difficulty in doing so when ")#mi("v")#text(" is large due to the essentially disjoint supports.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509397")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("Wolff gave three different arguments in his notes demonstrating the failure of Hausdorff-Young for ")#mi("p>2")#text(". The first one is the following “most elementary” one (which appears as an “exercise” in Wolff’s notes):")

#text("There exists a sequence of Schwartz functions ")#mi("\\{\\phi_n\\}")#text(" so that")

#text("(1). Each ")#mi("\\phi_n")#text(" has the same ")#mi("L^p")#text(" norm.")

#text("(2). Each ")#mi("\\hat{\\phi_n}")#text(" has the same ")#mi("L^{p^{\\prime}}")#text(" norm.")

#text("(3). The supports of the ")#mi("\\hat{\\phi_n}")#text(" are disjoint.")

#text("(4). The supports of the ")#mi("\\phi_n")#text(" are “essentially disjoint”:")

#tao-math("\\displaystyle \\left\\|\\sum_{n=1}^N \\phi_n\\right\\|_p^p\\sim \\sum_{n=1}^N\\left\\|\\phi_n\\right\\|_p^p\\sim N", block: false)#linebreak()#text(" uniformly in ")#mi("N")#text(" (which, I guess, means that ")#mi("\\sim")#text(" is ")#mi("\\sim_p")#text(" and does not depends on ")#mi("N")#text(").")

#text("Can one adapt the example in the previous comment (denoted as ")#mi("f=\\sum \\psi_n")#text(") to get one that satisfies (1)–(4)?")

#text("The difficulty is in (3): ")#tao-math("\\psi_n=e_(nv)(x) g_(nv)(x) e^{-\\pi i \\left|nv\\right|^2}", block: false)#text(" do not have disjoint supports; on the other hand, if one uses a ")#mi("C_c^\\infty")#text(" function instead of the standard Gaussian in the construction of ")#mi("\\hat{\\phi_n}")#text(", then (1)–(3) could be resolved but one has the difficulty in calculating the inverse Fourier transform of ")#mi("\\hat{\\phi_n}")#text(" and getting (4).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509317")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("In a discussion of the Khinchin’s inequality in your notes on the restriction conjecture (")#link("https://arxiv.org/pdf/math/0311181.pdf")[#text("https://arxiv.org/pdf/math/0311181.pdf")]#text("), things boil down to proving")

#tao-math("\\displaystyle E(\\left|\\sum_{k=1}^N\\varepsilon_ka_k\\right|^p)^{1/p}\\sim_p 1.", block: false)

#text("You first show by direct calculation that for ")#mi("p=2")#text(",")#linebreak()#text(" ")#tao-math("\\displaystyle E(\\left|\\sum_{k=1}^N\\varepsilon_ka_k\\right|^p)^{1/p}= 1,", block: false)#linebreak()#text(" which implies by Holder that for ")#mi("0<p\\leq 2")#text(",")#linebreak()#text(" ")#tao-math("\\displaystyle E(\\left|\\sum_{k=1}^N\\varepsilon_ka_k\\right|^p)^{1/p}\\leq 1.", block: false)#linebreak()#text(" You then show the upper bound for ")#mi("2<p<\\infty")#text(":")#linebreak()#text(" ")#tao-math("\\displaystyle E(\\left|\\sum_{k=1}^N\\varepsilon_ka_k\\right|^p)^{1/p}\\lesssim_p 1.", block: false)

#text("How do you use the log-convexity of the ")#mi("L^p")#text(" norm to show the lower bound")

#tao-math("\\displaystyle E(\\left|\\sum_{k=1}^N\\varepsilon_ka_k\\right|^p)^{1/p}\\gtrsim_p 1\\ ?", block: false)

#text("(Have you ever published this set of notes? Something is missing in the arxiv version. For instance, part of the picture on page 8 is gone.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509326")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("The log convexity lower bounds the ")#mi("L^2")#text(" norm by a combination of an ")#mi("L^q")#text(" norm for some ")#mi("q < 2")#text(" and an ")#mi("L^p")#text(" norm for ")#mi("p > 2")#text(". Since one has an exact formula (actually just a lower bound is needed) for the ")#mi("L^2")#text(" norm and an upper bound for the ")#mi("L^q")#text(" norm, one deduces a lower bound for the ")#mi("L^p")#text(" norm. (If one prefers, one can think in the contrapositive: if the ")#mi("L^p")#text(" norm were small, then the ")#mi("L^2")#text(" norm would also have to be small by interpolation with the ")#mi("L^q")#text(" norm, contradicting the formula one has for that norm.)")

#text("The notes were supposed to be published in the Park City Proceedings series, but unfortunately this particular issue had technical difficulties getting published.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509906")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("In Wolff’s notes on the stationary phase method (based on which are the 247AB notes), in the discussion of the function")#linebreak()#text(" ")#mi("\\displaystyle I(\\lambda)=\\int e^{-\\pi i\\lambda\\phi(x)}a(x)\\ dx,\\quad a\\in C_c^\\infty(\\mathbf{R}^d),")#linebreak()#text(" where the author discussed the nondegenerate critical point case, he made a quantitative argument that")#linebreak()#text(" ")#tao-math("\\displaystyle e^{\\pi i\\lambda^{-1}\\langle T^{-1}\\xi,\\xi\\rangle} =\\sum_{j=0}^N\\frac{(\\pi i\\lambda^{-1}\\langle T^{-1}\\xi,\\xi\\rangle)^j}{j!} +O(\\frac{\\left|\\xi\\right|^{2N+2}}{\\lambda^{N+1}})", block: false)#linebreak()#text(" “uniformly” in ")#mi("\\xi")#text(" and ")#mi("\\lambda")#text(" and accordingly")

#tao-math("\\displaystyle \\int \\hat{a}(\\xi)e^{\\pi i\\lambda^{-1}\\langle T^{-1}\\xi,\\xi\\rangle}\\ d\\xi =\\int\\hat{a}(\\xi)(1+\\sum_{j=1}^N\\frac{(\\pi i\\lambda^{-1}\\langle T^{-1}\\xi,\\xi\\rangle)^j}{j!})\\ d\\xi \\\\ +O(\\int |\\hat{a}(\\xi)|\\frac{\\left|\\xi\\right|^{2N+2}}{\\lambda^{N+1}} \\ d\\xi)", block: false)

#text("How can one make sense of the “uniform” big-O in ")#mi("\\xi")#text(" and ")#mi("\\lambda")#text("? One can see that the remainder term is dominated by")#linebreak()#text(" ")#tao-math("\\displaystyle \\frac{\\left|\\xi\\right|^{2N+2}}{\\lambda^{N+1}}", block: false)#linebreak()#text(" when ")#tao-math("\\left|\\xi\\right|", block: false)#text(" is small (and ")#mi("\\lambda")#text(" being big). But how could it be uniformly true for ")#emph[#text("all")]#text(" ")#mi("\\xi\\in\\mathbf{R}^d")#text(" (and thus justify the later integral)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509911")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("I do not have these notes handy, but presumably Wolff is implicitly restricting ")#mi("\\xi,\\lambda")#text(" to the range of interest, namely ")#mi("\\xi")#text(" in the support of ")#mi("\\hat a")#text(" and ")#mi("\\lambda")#text(" large.")

#text("More generally, one does not need to halt one’s reading comprehension every time there is a line that you can’t quite justify. I wrote about these sorts of “compilation errors” and how to avoid them at ")#link("https://plus.google.com/u/0/114134834346472219368/posts/TGjjJPUdJjk")[#text("https://plus.google.com/u/0/114134834346472219368/posts/TGjjJPUdJjk")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509913")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("Incidentally, I read the linked post on Google Buzz before posting the comment and I was searching on this list on Tricki: ")#link("http://www.tricki.org/article/Estimating_integrals")[#text("http://www.tricki.org/article/Estimating_integrals")]

#text("(Wolff’s has been available online: ")#link("http://www.math.ubc.ca/~ilaba/wolff/notes_march2002.pdf")[#text("http://www.math.ubc.ca/~ilaba/wolff/notes_march2002.pdf")]#text(")")

#text("I was trying to give an argument directly showing that")#linebreak()#text(" ")#mi("\\displaystyle \\int \\hat{a}(\\xi) \\sum_{j=N+1}^\\infty\\frac{(\\pi i\\lambda^{-1}\\langle T^{-1}\\xi,\\xi\\rangle)^j}{j!}\\ d\\xi =O(\\lambda^{-(N+1)}),")#linebreak()#text(" which is “what the author is trying to do”. But I somehow ended up with needing the argument in Wolff’s notes.")

#text("If ")#mi("\\hat{a}")#text(" has compact support, then this is fine. But ")#mi("a\\in C_c^\\infty(\\mathbf{R}^d)")#text(" (as mentioned in the comment) only implies that ")#mi("\\hat{a}")#text(" is Schwartz. On the other hand, the tail")#linebreak()#text(" ")#mi("\\displaystyle  \\sum_{j=N+1}^\\infty\\frac{(\\pi i\\lambda^{-1}\\langle T^{-1}\\xi,\\xi\\rangle)^j}{j!}")#linebreak()#text(" contains ")#tao-math("\\left|\\xi\\right|^m", block: false)#text(" with ")#emph[#text("arbitrarily large")]#text(" ")#mi("m")#text(". So I was not convinced that")#linebreak()#text(" ")#tao-math("\\displaystyle \\int \\hat{a}(\\xi) \\sum_{j=N+1}^\\infty\\frac{(\\pi i\\lambda^{-1}\\langle T^{-1}\\xi,\\xi\\rangle)^j}{j!}\\ d\\xi=\\int |\\hat{a}(\\xi)|O(\\frac{\\left|\\xi\\right|^{2N+2}}{\\lambda^{N+1}}) \\ d\\xi", block: false)#linebreak()#text(" which would give the desired order in ")#mi("\\lambda")#text(" using the Schwartz norm in ")#mi("\\hat{a}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-509918")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2018")])]

#text("I think here one should use ")#link("https://en.wikipedia.org/wiki/Taylor%27s_theorem#Estimates_for_the_remainder")[#text("Taylor’s theorem with remainder")]#text(", rather than the infinite series version of Taylor’s theorem. (It is here that the “i” in the exponential becomes important, as it keeps all the derivatives of ")#mi("x \\mapsto e^{ix}")#text(" bounded, in contrast to ")#mi("x \\mapsto e^x")#text("; this is an important distinction that is difficult to see purely at the Taylor series level.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-549506")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2020")])]

#text("The link is now not working due to the close of google plus. Do you still have it somewhere?")

#emph[#text("[ Now at ")#link("https://terrytao.wordpress.com/advice-on-writing-papers/on-compilation-errors-in-mathematical-reading-and-how-to-resolve-them/")[#text("https://terrytao.wordpress.com/advice-on-writing-papers/on-compilation-errors-in-mathematical-reading-and-how-to-resolve-them/")]#text(" -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-510806")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2019")])]

#text("The proof of the Tomas-Stein restriction theorem in Wolff’s notes (")#link("http://www.math.ubc.ca/~ilaba/wolff/notes_march2002.pdf")[#text("http://www.math.ubc.ca/~ilaba/wolff/notes_march2002.pdf")]#text(") uses the convolution of a Schwartz function and a measure that has compact support:")#linebreak()#text(" ")#mi("\\displaystyle \\phi * \\mu(x):=\\int \\phi(x-y)d\\mu(y)")#linebreak()#text(" But the group ")#mi("G")#text(" as in Exercise 16 is not written out explicitly and later the following integral is used:")#linebreak()#text(" ")#tao-math("\\displaystyle \\int_? (1+2^j\\left|\\xi-\\eta\\right|)^{-N}\\ d\\sigma(\\eta)", block: false)#linebreak()#text(" where ")#mi("\\mu=\\sigma")#text(" is the surface measure for the sphere in ")#mi("\\mathbf{R}^n")#text(".")

#text("It seems by the context that ")#mi("G")#text(" should be “a” unit sphere. But where should be the center of the sphere?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-510865")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2019")])]

#text("The group here is ")#mi("{\\bf R}^n")#text("; the sphere is not a group. (But of course, the surface measure on the sphere would assign a zero measure to the portion of ")#mi("{\\bf R}^n")#text(" outside of the sphere.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-516618")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2019")])]

#text("I may misunderstand something: one can write ")#mi("S^2=SO(3)/SO(2)")#text("; why “the sphere is not a group”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-516636")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2019")])]

#text("A quotient ")#mi("G/K")#text(" of two groups only has a natural group structure in the case when ")#mi("K")#text(" is a normal subgroup of ")#mi("K")#text(". Otherwise it is simply a set (though it can inherit a topology or a sigma algebra from ")#mi("G")#text(" by the usual quotient construction, and under reasonable compactness-type conditions one can also inherit a Haar measure).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-510877")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2019")])]

#text("Thanks for the comment! Then one should understand the integral in the previous comment as")#linebreak()#text(" ")#tao-math("\\displaystyle \\int_S(1+2^j\\left|\\xi-\\eta\\right|)^{-N}\\, d\\sigma(\\eta)", block: false)#linebreak()#text(" where $S\\subset \\mathbf{R}^n$ is the unit sphere centered ")#emph[#text("at the origin")]#text(". But I can’t make sense of the latter estimates:")#linebreak()#text(" ")#tao-math("\\displaystyle \\left|\\widehat{K_j}(\\xi)\\right| \\leq C_N\\int(1+2^j\\left|\\xi-\\eta\\right|)^{-N}\\, d\\sigma(\\eta) \\\\ \\leq C_N 2^{jn} \\bigg( \\int_{D(\\xi, 2^{-j})}(1+2^j\\left|\\xi-\\eta\\right|)^{-N}\\, d\\sigma(\\eta)\\\\ +\\sum_{k\\geq 0}\\int_{D(\\xi,2^{k+1-j})\\setminus D(\\xi,2^{k-j})} (1+2^j\\left|\\xi-\\eta\\right|)^{-N}\\, d\\sigma(\\eta) \\bigg)", block: false)

#text("Reading around the context of the notes one can see that")#linebreak()#text(" ")#tao-math("\\displaystyle D(x,r):=\\{y:\\left|x-y\\right|\\le r\\},\\quad  \\sigma(D(x,r))\\lesssim r^{n-1}.", block: false)#linebreak()#text(" It seems that ")#mi("D(x,r)")#text(" should be a ball in ")#mi("\\mathbf{R}^{n-1}")#text(".")

#text("How can one make sense of the canonical measure ")#mi("\\sigma")#text(", which is originally defined for the sphere ")#mi("S\\subset\\mathbf{R}^{n}")#text(", “evaluating” on the ball ")#mi("D(x,r)")#text(" in ")#mi("\\mathbf{R}^{n-1}")#text(", and thus make sense of the second inequality above?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-510907")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2019")])]

#text("I would imagine ")#mi("D(x,r)")#text(" would be a ball in ")#mi("{\\bf R}^n")#text(", which contains the sphere ")#mi("S^{n-1}")#text(". If one wishes one could replace ")#mi("D(x,r)")#text(" with ")#mi("D(x,r) \\cap S^{n-1}")#text(" since ")#mi("\\sigma")#text(" assigns zero mass to the complement of ")#mi("S^{n-1}")#text(" in ")#mi("{\\bf R}^n")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20461bf0527a77c5b60a453f45624b43692f1e69341290937aa67f0a24d8a180-eafc59f2a81b6e0a4371bfc4504a25f8286b6232f17a9ec34f120e4d07c8c9dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-513679")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2019")])]

#text("Dear Prof Tao,")

#text("Thanks a lot for your notes. I think that there might be a typo in Exercise 42. The formula in the hint should read x_j (f*g)= (x_j f)*g+f*(x_j g). This is the only way that I can get to show that the left hand side converges uniformly to x_j f, when g=g_r, as r tends to zero.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-516616")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2019")])]

#text("For a (nice enough) function ")#mi("f")#text(" on the circle ")#mi("S^1")#text(", one can write ")#mi("f")#text(" as a Fourier series. For a function on an ellipse, can one do the similar thing?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-516617")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2019")])]

#text("This may be a rather elementary dumb question that I cannot find on Google. How many “symmetric” figures on the 2D plane can be captured by the notion of homogeneous spaces?")

#text("Of course one can write ")#mi("S^1=SO(2)/SO(1)")#text(". How about ellipses? Or a square? A rectangle?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-516619")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2019")])]

#text("To put it in another way, if one proves a result for any homogeneous space ")#mi("G/K")#text(" such that ")#mi("G")#text(" is compact Hausdorff and ")#mi("K")#text(" is closed topological groups, how many interesting “real” examples of the space ")#mi("G/K")#text(" are there on ")#mi("\\mathbf{R}^2")#text(" and ")#mi("\\mathbf{R}^3")#text(" besides the unit circle and the sphere?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-516637")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2019")])]

#text("Well, it depends on what you mean by “real” or “interesting”. Technically, any homogeneous space ")#mi("G/K")#text(" of cardinality less than or equal to the continuum can be embedded by some set-theoretic function into ")#mi("{\\bf R}^2")#text(" or ")#mi("{\\bf R}^3")#text(", and any homogeneous space that is a smooth manifold can be embedded smoothly into a sufficiently high dimensional Euclidean space (Whitney embedding theorem). But in addition to the circle and sphere, other quadric surfaces can be viewed as quotients. For instance the unit hyperboloid can be viewed as a quotient ")#mi("SO(2,1) / SO(2)")#text(". An ellipsoid ")#mi("\\{ x: Q(x) = 1\\}")#text(" associated to some positive definite form ")#mi("Q")#text(" can be viewed as a quotient ")#mi("SO_Q(3) / SO_Q(2)")#text(", where ")#mi("SO_Q(3)")#text(" is the group of three-dimensional unimodular linear transformations preserving ")#mi("Q")#text(", and ")#mi("SO_Q(2)")#text(" is the stabiliser of some point on the ellipse in ")#mi("SO_Q(3)")#text(". An elliptic curve in Weierstrass form is almost a group inside ")#mi("{\\bf R}^2")#text(" (though one has to add the point at infinity), though a real elliptic curve can also be identified with either one or two circles which can also be embedded into ")#mi("{\\bf R}^2")#text(" if desired. Then of course there are the finite examples; for instance, the vertices of a regular polyhedron can be viewed as a homogeneous space formed by quotienting the symmetry group of the polyhedron by the stabiliser of a vertex.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Peter-Weyl theorem, and non-abelian Fourier analysis on compact groups | What's new")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-2/#comment-518332")[#strong[#text("The Peter-Weyl theorem, and non-abelian Fourier analysis on compact groups | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2019")])]

#text("[…] homomorphisms into the unit circle ), known as the Pontryagin dual of . (See for instance my lecture notes on the Fourier transform.) Conversely, the Peter-Weyl theorem can be used to deduce the Plancherel theorem for compact […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-37985")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("Dear Prof. Tao,")

#text("In exercise 30, do you mean that Schwartz class is dense in continuous compactly supported functions? I think this is not true.")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-37986")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("in equation (10), on the right hand side, is it f or F? I think it should be F.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-37987")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("in (14), the left hand side is it ")#mi("\\hat f")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-37990")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("Thanks for the corrections! The Schwartz class is dense both in ")#mi("C_0({\\Bbb R}^d)")#text(" (the space of continuous functions going to zero at infinity), as well as in the subspace ")#mi("C_c({\\Bbb R}^d)")#text(" (compactly supported continuous functions) in the uniform topology, although in the latter case one of course has to intersect the Schwartz space with ")#mi("C_c")#text(" (which gives ")#mi("C^\\infty_c({\\Bbb R}^d)")#text(", the space of smooth compactly supported functions).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38007")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("Thanks for the notes!")

#text("In the FFT paragraph, probably you meant “operations” in “… takes only ")#mi("{O(N \\log N)}")#text(" algorithms”. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38011")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2009")])]

#text("wonderful notes. Just a small remark: the Latin plural form of “torus” is “tori”, not “torii” :) ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/15bf1294c648aa5273bc4c9e7ac4ae60f8fed3c557865e88e8c1443043347889-748cc305b47ed05c386cbfca0f97ec8e0de6bc78607fe523fb463f7e4a97f7bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hunter")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38024")[#strong[#text("Hunter")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2009")])]

#text("These notes are a pleasure to read. The characterization of the topology on G hat in exercise 8 as generated by certain sets seems to have a few missing characters? Also, the second G in exercise 11 should have a hat. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a718fe0ae1ce222ea33275174bc93b6011081a9ba6d690bd7cf9c39f0317e62a-6170224188d25c8da1133b3e3d9c851d6c93c48eb9e4532aaaf759d38dceb8b4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mfrasca")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38025")[#strong[#text("mfrasca")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2009")])]

#text("In exercise 8 and toward the end of the notes there seem to be a couple of formulas that do not parse.")

#text("Marco")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/390517060033239b9bf4fdf38be68020e8c3713bc59523c096d8f998664e0bbe-8a87dc77dc8f1db8ed403dfd640cfca3565b7b89c4f53fa7c5cbd2c0bed27bd8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38078")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2009")])]

#text("There’s a strong superficial similarity between the Fourier transform and its inverse and similar inverse pairs in combinatorics, e.g. the binomial transforms, the Stirling transforms, and Mobius inversion. If the Fourier transform is essentially group-theoretic and Mobius inversion is essentially poset-theoretic, how do we unify the two approaches? In more concrete terms:")

#text("– In what sense is the Fourier transform a use of the principle of inclusion-exclusion, or")#linebreak()#text(" – In what sense is the principle of inclusion-exclusion a Fourier transform?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38081")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2009")])]

#text("Dear Qiaochu,")

#text("I think they are not quite the same thing; the Fourier transform of a function of a spatial variable becomes a function in a dual frequency variable, whereas partial summation and Mobius inversion (or related concepts, such as inclusion-exclusion) stay exclusively in the spatial domain. The poset-theoretic concepts seem to be more related to the operations of integration and differentiation, or convolution and deconvolution, than to the Fourier transform – thus they are more like Fourier ")#emph[#text("multipliers")]#text(" than Fourier ")#emph[#text("transforms")]#text(".")

#text("I don’t see a way to properly formalise this analogy, though – Fourier analysis really requires some sort of underlying translation symmetry to be effective, and I don’t see that sort of symmetry in the poset world.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38162")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2009")])]

#text("Dear Prof. Tao,")

#text("in the paragraph after corollary 5, G in little l2 and l(infinity) should be G^.")

#text("in your notes is p’ always conjugate of p?")

#text("thanks")

#emph[#text("[Corrected and clarified, thanks, – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08edac3c1ba7fd9837efea66136c65256434d86e121db5dd69fcbd1022f0e945-9fabbe62d37250bce5030405ae4cf685005021e23cb30a46efdcf903e88a6418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of joseph")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38213")[#strong[#text("joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2009")])]

#text("Hi, I’m sorry to bother you. My major is math and I ‘m also interested in physics. But my time is not adequate for learning two subjects. So what physics modules are useful to be a mathematician? Esp. studying analysis or geometry? Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxbaroi")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38218")[#strong[#text("maxbaroi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2009")])]

#text("I believe there’s a typo in 9a. I think you wanted to say to identiy each ")#mi("\\xi \\in {(\\mathbb{R} \\backslash \\mathbb{Z})}^d")

#emph[#text("[Corrected, thanks – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38223")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2009")])]

#text("Also, I just went on your UCLA site, and you listed in your previous teaching section the link text says you taught 254B not 245B in Winter 09. ")#emph[#text("[Corrected, thanks – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/302297467e4854e24f695bc9f2f0a3c18b3ed1b0b91020f21aa0961d8ee724dd-9ca368b2e9b3d2608523897525712084c7cd9c4296572e7982c6fa26dec69bf9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous joe")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38226")[#strong[#text("anonymous joe")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2009")])]

#text("Nice article! Could you also post something on “Eigen Vectors” in a future article perhaps?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38228")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2009")])]

#text("Dear joe,")

#text("I am not planning to teach linear algebra in the near future, but you can have a look at my lecture notes on the topic from 2002 at")

#link("http://www.math.ucla.edu/~tao/resource/general/115a.3.02f/")[#text("http://www.math.ucla.edu/~tao/resource/general/115a.3.02f/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38229")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2009")])]

#text("Hi Prof. Tao,")

#text("What are you going to teach just after that course? If you announce it before, we can read some books and prepare ourself.")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38230")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2009")])]

#text("My next class is going to be in Winter of 2010. It is a topics course in analysis; I have not yet decided what I will lecture on, but I am thinking to do something involving random matrices.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38231")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2009")])]

#text("Thank you very much Prof. Tao.")

#text("Would you please recommend any book or lecture notes on it ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08edac3c1ba7fd9837efea66136c65256434d86e121db5dd69fcbd1022f0e945-9fabbe62d37250bce5030405ae4cf685005021e23cb30a46efdcf903e88a6418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of joseph")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38237")[#strong[#text("joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2009")])]

#text("Hi,")#linebreak()#text(" I am curious that can two cont. functions have the same divergent Fourier series? Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38238")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2009")])]

#text("Joseph,")

#text("By subtracting the two Fourier series, one can reformulate the question as; can a continuous (or more generally L^1) function have an identically vanishing Fourier series? While it’s true that the partial sums of the Fourier expansion of a L^1 function can behave badly (for example, diverge everywhere), we can “fix” this in several ways. For example, if F_n is the Fejer kernel (see ")#link("http://en.wikipedia.org/wiki/Fejer_kernel")[#text("http://en.wikipedia.org/wiki/Fejer_kernel")]#text("), then F_n * f converges to f in L^1 norm (as well as almost everywhere). It is easy to see from this that if the Fourier series of f is identically zero, f must be identically zero.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38239")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2009")])]

#text("The previous comments, and exercise 22, made me think of the following question. In several of your papers you briefly mention the problem of establishing pointwise convergence for ")#mi("f \\in L^2 (\\mathbb{R}^d)")#text(", (i.e. Carleson’s theorem in 2 and more dimensions). Of course, this is an endpoint case of the maximal Bochner-Riesz maximal conjecture. In fact, you touch on this problem in both your work on the previously mentioned conjecture, as well as your work on multilinear operators. I’ve often been curious, why does this problem lie out of the reach of current technology? It seems the issues here will be different than, say, that in the tri-linear Hilbert transform, since there is no quadratic modulation invariance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38241")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2009")])]

#text("Dear anonymous @ 12:40pm,")

#text("Perhaps the best place where this issue is discussed is Lacey’s survey paper at ")#link("http://arxiv.org/abs/math/0307008")[#text("http://arxiv.org/abs/math/0307008")]#text(" . The time-frequency technology that is used to (say) reduce the bilinear Hilbert transform to that of bounding certain paraproducts associated to “trees”, seems to similarly reduce the problem of two-dimensional pointwise convergence to that of understanding (more complicated variants of) the lacunary maximal operator")

#tao-math("\\sup_{k > 0} \\left|\\int_{\\left|\\xi\\right| \\leq 1 +2^{-k}} \\hat f(\\xi) e^{2\\pi i x \\cdot \\xi}\\ dx\\right|", block: false)#text(",")

#text("i.e. the supremum of a lacunary family of disk multipliers. In order to control this, it is not enough to know the size (e.g. in $L^p$) of each individual disk multiplier; one must also know how each multiplier is distributed (the enemy is if they are each large in different regions of space, thus causing the sup to be enormous). Unfortunately our Bochner-Riesz technology is still quite poor at controlling the spatial distribution of disk multipliers (there are some conjectures in this direction, most notably a weighted conjecture of Stein, but progress is still very partial here, and also there are a variety of logarithmic losses which could be quite fatal when applying these conjectured estimates to the Carleson problem). But the problem may not be totally out of reach, and it is conceivable that finer endpoint control on the size and distribution of Bochner-Riesz and Kakeya type operators will help.")

#text("Separately to this, there is also a technical combinatorial problem, which is that the combinatorics of organising time-frequency tiles into trees is not well understood in higher dimensions, in which tiles now have some eccentricity in both physical space and frequency space. There are however some advances in understanding how to organise eccentric tiles, in particular in the recent work of Lie on the quadratic one-dimensional Carleson operator, and of Lacey and Li on the vector fields differentiation problem. So this may be more of a technical issue than a fundamental one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245C, Notes 3: Distributions « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38242")[#strong[#text("245C, Notes 3: Distributions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2009")])]

#text("[…] is not a test function, but is instead just a Schwartz function. (Indeed, by Exercise 46 of Notes 2, it is not possible to find a non-trivial test function whose Fourier transform is again a test […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d10259e569f7948fb426f219171f06e13dc570f262d4c1ae121b4b024a8b1608-030659b4e829203ccdf0062ebabb0491445396a52c856fea3b1d5e19b723499e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ObsessiveMathsFreak")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38251")[#strong[#text("ObsessiveMathsFreak")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2009")])]

#text("Despite its great usefulness, the Fast Fourier transform is not without cost. The terrible unspoken secret of the FFT is that it does not in fact compute or approximate the FT of the function. Rather, it computes the Fourier transform of a quite different, albeit closely related, function.")

#text("The nature of this relation is a quite complicated series of delta function multiplications, truncations, cutoffs and convolutions. The book “The fast Fourier transform and its applications” by E. Brigham, has a very good description of the relationship between the discrete and continuous Fourier transforms, with pictures!")

#text("While this may not seem very serious, it becomes so when taking the Fourier transforms of multivariate functions. When moving to two dimensions, the implicit truncations, convolutions and multiplications in the FFT process will introduce fairly serious artefact’s in the computed FFT that can make it fairly unusable for analytical purposes. You’re often a lot better off computing the continuous Fourier transform numerically in some case(This is in fact feasible on modern desktops).")

#text("Speaking for myself, I can say that discovery of this fact was a cause of some dismay.")

#text("This is all aside form the fact that the standard FFT is rather awkward to use when it comes to analysis, as it ignores the normal and frequency domains of the problem, treating the transform as a transformation of one flat array to another, making it quite difficult to translate the produced transforms into something with analytical meaning.")

#text("So the FFT, while undoubtedly necessary in many areas, is not quite sufficient in others.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0537b6430c9c57681f1965b0d938dccc1de0477155e5981bccb3d68c304ad191-ddbc1bfc7232cf298bf9a4498593ac4bd27c31a95f9d1d74b51ab6195422a470.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manuel Moreira")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38303")[#strong[#text("Manuel Moreira")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2009")])]

#text("Dear Prof, Tao,")

#text("The Fourier and generalized functions, were a really nice.")

#text("Cheer and thank,")

#text("Manuel")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0a87b3fec46afe842f92eb960501811684e370e0800c95e8d879e3f695007da-0c99844b6c34e9fa6e0d42bf1bc1042b40378c842b8e0f64c05e6599eb86b92e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Takis Konstantopoulos")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38489")[#strong[#text("Takis Konstantopoulos")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2009")])]

#text("Dear Terry,")

#text("Thanks for the excellent notes. Can I ask a question? How do you write formulas on this blog (apparently you use LaTeX directly?) Several months ago I ")#link("http://gowers.wordpress.com/2008/02/01/removing-the-magic-from-stirlings-formula/#comment-1394")[#text("tried to post")]#text(" something on Tim Gowers’ blog but failed miserably and then had to ")#link("http://gowers.wordpress.com/2008/02/01/removing-the-magic-from-stirlings-formula/#comment-1395")[#text("link a pdf file")]#text(". I am wondering whether there is something special about this type of blog you are writing on or whether it can be done on other blogs (e.g. blogspot).")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-38492")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2009")])]

#text("Dear Takis,")

#text("Please see my “about” page")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/about/")[#text("About")]
]

#text("for details.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-39580")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2009")])]

#text("Dear Prof Tao,")

#text("I have a question regarding probability theory but it has relation with Fourier transfrom.")

#text("Let X be a random variable and ")#mi("\\phi(t)")#text(" be its characteristic function, i.e Fourier transform of its distribution.")

#text("if ")#mi("\\phi(t)")#text(" is differentiable, is ")#mi("\\phi^{\\prime}(t)")#text(" again a characteristic function of a random variable? Which one?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-39584")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2009")])]

#text("Dear Jeff,")

#text("I think ")#mi("\\phi(t)")#text(" may not be a characteristic function of some random variable, because $\\phi^{‘}(0)=E[X]$ (assuming that ")#mi("\\phi")#text(" is the characteristic function of ")#mi("X")#text(") is not necessarily equal to 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jeff")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-39586")[#strong[#text("jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2009")])]

#text("Dear PDE beginner,")

#text("excuse me I did not understand your argument,")

#text("could you please explain more?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-39587")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2009")])]

#text("I think each characteristic funtion ")#mi("\\phi")#text(" of a random variable ")#mi("X")#text(" has the property ")#mi("\\phi(0)=1")#text(". Because ")#mi("\\phi^{^{\\prime}}(0)=i E[X]")#text(", which can be some value other than $1$, ")#mi("\\phi^{^{\\prime}}")#text(" is not a characteristic function.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jeff")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-39602")[#strong[#text("jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2009")])]

#text("One of my friend said that ”yes it is, think about Radon- Nykodm theorem” but now your argument seems reasonable, I am really confused.")#linebreak()#text(" I hope that Prof Tao explain and clarify that question.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-39844")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2009")])]

#text("Dear Professor Tao:")#linebreak()#text(" In Exercise 7, (b) I guess what you mean is ")#mi("\\int_G fd\\mu \\geq (f:g) (\\int_G g\\ dm) - \\varepsilon")#text(".")

#text("In exercise 7 (f). I think the weights in the end are something like ")#mi("f(x_i)/(f(x_i)+g(x_i)-\\varepsilon)")#text(" for some ")#mi("\\varepsilon")#text(".")

#text("don’t know if I’m right.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-39853")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2009")])]

#text("Dear Liuxiaochuan,")

#text("Thanks for the corrections! But compactness is not needed in exercise 8. (Note that the larger U gets, the smaller the dual set ")#mi("\\{ \\xi \\in \\hat G: \\xi \\cdot x \\in [-\\varepsilon,\\varepsilon] \\forall x \\in U\\}")#text(" gets.)")

#text("For Exercise 10, Lusin’s theorem does not work directly, because the continuity is only obtained on a restriction of the character to a set of strictly smaller measure. (Note that there certainly exist measurable functions which are discontinuous at every point, e.g. the indicator function of the rationals.) The hint asks for you to exploit the continuity of the map ")#mi("x \\mapsto \\tau_x \\chi")#text(" from ")#mi("G")#text(" to ")#mi("L^1_{loc}(G)")#text(", which can be done by approximating ")#mi("\\tau_x")#text(" locally by a continuous function in ")#mi("L^1")#text(".")

#text("(An alternate proof (which is essentially equivalent) proceeds by using the Steinhaus theorem.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-39845")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2009")])]

#text("Dear Professor Tao:")

#text("In exercise 8, does U in the hint has to be a compact neighborhood of the identity to make it work?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-39849")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2009")])]

#text("Dear professor Tao:")

#text("About exercise 10,I didn’t quite get the hint. I want to know if what we want to do is just prove the continuity of ")#mi("\\chi")#text(". If so, then will the following be correct?")

#text("Use the Lusin Theorem to show there are at least one point x where f is continuous, then we prove from the condition that if f is continuous at one point, then it is continuous everywhere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-39855")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2009")])]

#text("Dear Professor Tao ：")#linebreak()#text(" there is a small correction:")#linebreak()#text(" in (4), the left-hand side should be ")#mi("\\chi_{\\xi_0} \\widehat f (\\xi)")

#text("Again about exercise 8, although I noticed that the larger U gets, the smaller the dual set ")#mi("\\{ \\xi \\in \\hat G: \\xi \\cdot x \\in [-\\varepsilon,\\varepsilon] \\forall x \\in U\\}")#text(" gets, I still tried using countable many of sets of the form ")#tao-math("\\{\\xi\\in G: \\left| \\xi\\cdot x-\\xi_0 \\cdot x \\right|< \\varepsilon \\forall x\\in K\\}", block: false)#text(" to cover the set, which cann't be reduced to finite many ones.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-39857")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2009")])]

#text("Dear Liuxiaochuan,")

#text("Actually, I think (4) is correct as it stands.")

#text("In a Hausdorff space, the intersection of uncountably many compact sets is still compact.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efd6b81b008b5be884fff088080be9ca0b858d90d12f69f48994cfd348117505-2409187bc0a691b2efdba862e563b018c9cc25d31c8de5f9f3b0c726b421fe91.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iqbal")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-39860")[#strong[#text("Iqbal")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2009")])]

#text("Hello")#linebreak()#text(" I am glad I found this website. I am trying to understand your paper titled “Near Optimal Signal Recovery…..Strategies?”. On page 7, you present a geometric picture of the problem which I don’t understand. Forgive me for my lack of background knowledge but if you can suggest a good reference to strengthen my background for my understanding,I will be very grateful. I have just started my research on Compressed Sensing and am having trouble in the understanding.")

#text("Thanks")#linebreak()#text(" Iqbal")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-39880")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2009")])]

#text("Dear Iqbal,")

#text("Several tutorials, background references, etc. can be found at")

#link("http://dsp.rice.edu/cs")[#text("http://dsp.rice.edu/cs")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benford’s law, Zipf’s law, and the Pareto distribution « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-39866")[#strong[#text("Benford’s law, Zipf’s law, and the Pareto distribution « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2009")])]

#text("[…] for all integers , where the left-hand side denotes the proportion of data for which lies between and for some integer . Suppose now that we generalise Benford’s law to the continuous Benford’s law, which asserts that (1) is true for all real numbers . Then it is not hard to show that a statistic obeys the continuous Benford’s law if and only if its dilate does, and similarly with replaced by any other constant growth factor. (This is easiest seen by observing that (1) is equivalent to asserting that the fractional part of is uniformly distributed.) In fact, the continuous Benford law is the only distribution for the quantities on the left-hand side of (1) with this scale-invariance property; this fact is a special case of the general fact that Haar measures are unique (see e.g. these lecture notes). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-39889")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2009")])]

#text("Dear Professor Tao:")

#text("Is it correct in understanding that multiplier and symbol are same thing and that the order of symbol can be negative?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-39916")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2009")])]

#text("The two terms are sometimes used synonymously, though I prefer to use the term “multiplier” (or more precisely, “Fourier multiplier operator”) to refer to the operator ")#mi("T_m")#text(", and “symbol” to refer to the function ")#mi("m")#text(". The two concepts are then related by the formula ")#mi("\\widehat{T_m f} = m \\hat f")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-39995")[#strong[#text("Some examples of graded algebras « Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2009")]

#text("[…] the direct sum is replaced by an integral.) For more details, see Terence Tao’s notes on the Fourier transform. With (the circle group), (the circle), and we recover the usual gradation on the space of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1de735fa27a69a8efe44ff56d5e17917d2a5dbf93881626187879849dc9c239-76f06f3a3d2ea44d49c3b6253babead8b129d6205db6034382ea04835d035fd1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabriel")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-40887")[#strong[#text("Gabriel")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2009")])]

#text("Dear Prof. Tao,")

#text("Thank you very much for posting this notes. They were a very nice resume. Reading them the following question came to my mind:")

#text("Given a function ")#mi("f(x)")#text(" in ")#mi("L^{\\infty}([-\\pi,\\pi])")#text(" or more generally in ")#mi("\\cap_{p\\geq 1}{L^{p}([-\\pi,\\pi])}")#text(" consider ")#mi("\\widehat{f}")#text(" its Fourier Series. Let ")#mi("k\\geq 1")#text(" and let us define")#linebreak()#text(" ")#mi("\\mathbb{Z}_{0}^{k}=\\{(m_1,\\ldots,m_k)\\in\\mathbb{Z}^{k}\\,:\\, m_1+\\ldots +m_k=0\\}")#text(". We are interested to know if the following series converges:")

#tao-math("\\phi_k:=\\sum_{(m_1,\\ldots,m_k)\\in\\mathbb{Z}_{0}^{k}}{\\prod_{i=1}^{k}{\\left|\\widehat{f}(m_i)\\right|}}<\\infty.", block: false)

#text("The case ")#mi("k=1")#text(" it is trivial and ")#mi("k=2")#text(" is essentially Parseval's identity. What can be said about ")#mi("k\\geq 3")#text(" ? Does this series converges for all ")#mi("k")#text(" ?")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-40889")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2009")])]

#text("This series diverges without additional regularity assumptions on f. Consider for instance a random sign function at scale 1/N for some N, i.e. a function of the form ")#mi("f(x) = \\sum_{n=0}^{N-1} \\epsilon_n 1_{[n/N, (n+1)/N)}")#text(" for some iid signs ")#mi("\\epsilon_n")#text(". This function is bounded in every ")#mi("L^p")#text(" space, but Khintchine’s inequality tells us that the first N Fourier coefficients of this function are of size ")#mi("1/\\sqrt{N}")#text(" on the average, which will lead to divergence of the above sum for ")#mi("k \\geq 3")#text(" in the limit ")#mi("N \\to \\infty")#text(". (One can formalise this divergence by creating a suitable linear combination of the above examples over all N, or appealing to the uniform boundedness principle.)")

#text("More generally, random sign patterns are one of two the fundamental counterexamples in Fourier analysis (the others being rescaled bump functions). Most of the more sophisticated counterexamples are some combination of the two (e.g. the unboundedness of the disc multiplier stems from random combinations of bump functions rescaled to tubes forming a Besicovitch set).")

#text("Note however that if the absolute values of the Fourier transform are on the outside, then ")#mi("\\phi_k")#text(" is essentially the k^th moment of f, which is finite. Thus we see that there is significant cancellation between the Fourier coefficients of f that is lost when one only considers magnitude information.")

#text("Incidentally, this type of divergence is the main reason why the trilinear Hilbert transform cannot be controlled by existing time-frequency analysis techniques (which are based on magnitudes of various wave packet coefficients, ignoring phase information), whereas the bilinear Hilbert transform can. (See ")#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/")[#text("my earlier blog post")]#text(" on this.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-41947")[#strong[#text("Integral Transforms and Partial Differential Equations « Stevethemathsman's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2009")]

#text("[…] at the above links. An interesting discussion of the Fourier transform is on Terry Tao’s blog here esp is you have seen LCA groups […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-42091")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2009")])]

#text("Dear Prof. Tao,")

#text("I have some some (possibly) trivilal questions about the section 1, because I didn’t systematically learn group theory before and no people around me are working on group theory.")

#text("1. Excerse 1: ")#mi("G:= (\\mathbb R^{\\mathbb R},+)")#text(" is a LCA group. According to the hint, we can take ")#mi("[-1,1]^{\\mathbb R}")#text(", which is a compact neighbourhood of identity ")#mi("0")#text(". But ")#mi("[-1,1]^{\\mathbb R}")#text(" generates ")#mi("G")#text(".")

#text("2. Exercise 8: I don’t know how to prove that ‘If ")#mi("G")#text(" is discrete, then ")#mi("\\hat G")#text(" is compact’. I also don’t know how to prove Exercise 16, which is vice versa of Exerecise 16.")

#text("By the way, there seem some typos:")

#text("1. Exercise 7 (f), ")#mi("H")#text(" should be ")#mi("h")#text(".")

#text("2. Exercise 8, The ")#mi("G")#text(" in the ")#mi("\\{\\cdots\\}")#text(" should be ")#mi("\\hat G")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-42105")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2009")])]

#text("Thanks for the corrections!")

#text("Regarding ")#mi("[-1,1]^{\\Bbb R}")#text(": this set is compact but not a neighbourhood (if one endows ")#mi("{\\Bbb R}^{\\Bbb R}")#text(" with the product topology), or a neighbourhood but not compact (if one instead uses the box topology). Also, it doesn’t generate all the functions ")#mi("f: {\\Bbb R} \\to {\\Bbb R}")#text(" in ")#mi("{\\Bbb R}^{\\Bbb R}")#text(", but only those functions that are bounded.")

#text("To show that the dual of a discrete group G is compact, note that the topology on ")#mi("\\hat G")#text(" is compatible with the product topology on ")#mi("({\\Bbb R}/{\\Bbb Z})^G")#text(".")

#text("The main tool used to prove Exercise 16 is Lemma 2.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-42855")[#strong[#text("Functoriality « Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2009")]

#text("[…] A basic reason to be interested in locally compact Hausdorff spaces is that, if we in addition allow the algebras to be over instead of over , we recover Pontryagin duality. One constructs a C*-algebra which generalizes the group algebra of a locally compact Hausdorff abelian group , and the spectrum of this algebra is the dual group . However, I’m not sure of the technical details, so I’ll just refer to this post of Terence Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: The central limit theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-43111")[#strong[#text("254A, Notes 2: The central limit theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#text("[…] make the characteristic function defined on the dual space instead of on itself; see for instance my notes on the Fourier transform in general locally compact abelian groups. But we will not need to care about this subtlety in our […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The uncertainty principle « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-45690")[#strong[#text("The uncertainty principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2010")])]

#text("[…] Pontryagin group duality A (locally compact Hausdorff) abelian group can be described either by listing its elements , or by listing the characters (i.e. continuous homomorphisms from to the unit circle, or equivalently elements of ). The connection between the two is the focus of abstract harmonic analysis. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e955662e0578322c4387c33d1544995345aa79ec5c6527335ccbc41484560e3-521297dbe43cdacc3699e13fd5b00ab7c6e204396daf4de04f45b10f84989a11.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a.s")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-49742")[#strong[#text("a.s")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2011")])]

#text("Just a minor typo:")#linebreak()#text(" Exercise 3, dx should be replaced by $\\mu(dx)$")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ac1b2c0c904a32ebca147520068b9f3f7059437fd6275e1803c130bac86e024-dd343ef652ca906001ba89022e403911010f649895fc1327599851ac68b3b895.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wenying Gan")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-52451")[#strong[#text("Wenying Gan")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2011")])]

#text("Dear Prof. Tao:")

#text("I think there is a typo in Ex 20. For the Dirichlet kernel in Ex20 part 1, it should be ")#mi("D_N(x):= \\frac{sin(2 \\pi (N+1/2)x)}{sin \\pi x}")

#text("Wenying")

#emph[#text("[Corrected, thanks (and a related error for the Fejer kernel on the next exercise has also been corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-53358")[#strong[#text("局部紧群上的Fourier分析 « Fight with Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2011")]

#text("[…] Tao The Fourier transform […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gleason’s lemma « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-56086")[#strong[#text("Gleason’s lemma « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2011")])]

#text("[…] be a non-trivial left-invariant Haar measure on (see for instance this previous blog post for a construction of Haar measure on locally compact groups). We then form the convolution , with […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3: Haar measure and the Peter-Weyl theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-87126")[#strong[#text("254A, Notes 3: Haar measure and the Peter-Weyl theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2011")])]

#text("[…] more precisely the unique constant function that is an average of translates of . See Exercise 6 of these notes for further discussion (the post there focuses on the abelian case, but the argument extends to the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 2: Cayley graphs and Kazhdan’s property (T) « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/comment-page-1/#comment-113288")[#strong[#text("254B, Notes 2: Cayley graphs and Kazhdan’s property (T) « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2011")])]

#text("[…] Now we turn to the higher-dimensional cases . The idea is to first use Fourier analysis to understand the action of various simpler subgroups of acting on a space with approximately invariant vectors, and obtain non-trivial vectors that are invariant with respect to those simpler subgroups. Then, we will use an asymptotic conjugation trick of Mautner to boost this invariance up to increasingly larger groups, until we obtain a non-trivial vector invariant under the whole group . (As such, this section will presuppose some familiarity with Fourier analysis, as reviewed for instance in this blog post.) […]")
]
