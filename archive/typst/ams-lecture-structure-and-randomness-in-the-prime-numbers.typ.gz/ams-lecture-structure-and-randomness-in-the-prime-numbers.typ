// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/
// Converted to Typst by tao2typ: "2026-10-14T16:35:07.691555+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "AMS lecture: Structure and randomness in the prime numbers", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("AMS lecture: Structure and randomness in the prime numbers")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 January 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/")[#text("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This week I am in San Diego for the ")#link("http://www.ams.org/amsmtgs/2109_intro.html")[#text("annual joint mathematics meeting")]#text(" of the ")#link("http://en.wikipedia.org/wiki/American_Mathematical_Society")[#text("American Mathematical Society")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Mathematical_Association_of_America")[#text("Mathematical Association of America")]#text(". I am giving two talks here. One is a ")#link("http://www.ams.org/amsmtgs/2109_program_tuesday.html#2109:BULLETIN")[#text("lecture")]#text(" (for the AMS “Current Events” Bulletin) on recent developments (by Martel-Merle, Merle-Raphael, and others) on stability of solitons; I will post on that lecture at some point in the near future, once the survey paper associated to that lecture is finalised.")#linebreak()#text(" The other, which I am presenting here, is an address on “")#link("http://www.ams.org/amsmtgs/tao.html")[#text("structure and randomness in the prime numbers")]#text("“. Of course, I’ve talked about this general topic many times before, (e.g. at ")#link("https://terrytao.wordpress.com/2007/12/04/milliman-lecture-i-additive-combinatorics-and-the-primes/")[#text("my Simons lecture at MIT")]#text(", ")#link("https://terrytao.wordpress.com/2007/04/05/simons-lecture-i-structure-and-randomness-in-fourier-analysis-and-number-theory/")[#text("my Milliman lecture at U. Washington")]#text(", and ")#link("https://terrytao.wordpress.com/2007/03/13/article-in-the-new-york-times-and-maths-education/")[#text("my Science Research Colloquium at UCLA")]#text("), and I have given similar talks to the one here – which focuses on my original ")#link("http://front.math.ucdavis.edu/math.NT/0404188")[#text("2004 paper with Ben Green")]#text(" on long arithmetic progressions in the primes – about a dozen or so times. As such, this particular talk has probably run its course, and so I am “retiring” it by posting it here.")

#text("p.s. At this meeting, ")#link("http://en.wikipedia.org/wiki/Endre_Szemer%C3%A9di")[#text("Endre Szemerédi")]#text(" was awarded the 2008 ")#link("http://en.wikipedia.org/wiki/Leroy_P._Steele_Prize")[#text("Steele prize for a seminal contribution to research")]#text(", for his landmark paper establishing what is now known as ")#link("http://www.scholarpedia.org/article/Szemeredi%27s_Theorem")[#text("Szemerédi’s theorem")]#text(", which underlies the result I discuss in this talk. This prize is richly deserved – congratulations Endre! [The AMS and MAA also awarded prizes to several dozen other mathematicians, including many mentioned previously on this blog; rather than list them all here, let me just point you to their ")#link("http://www.ams.org/ams/prizebooklet-2008.pdf")[#text("prize booklet")]#text(".]")

#metadata(none) <tao-d92eb025dde9c0e644b5>

#text("My talk concerns the subject of ")#emph[#text("additive prime number theory")]#text(" – which, roughly speaking, is the theory of additive patterns contained inside the prime numbers ")#mi("{\\mathcal P} = \\{2,3,5,7,11,\\ldots\\}")#text(". This is a very old subject in mathematics; for instance, the ")#link("http://en.wikipedia.org/wiki/Twin_prime_conjecture")[#text("twin prime conjecture")]#text(", which asserts that there are infinitely many patterns of the form ")#mi("n, n+2")#text(" in the primes, may have been considered in one form or another by Euclid (although the modern version of the conjecture probably dates to Brun’s 1915 paper, who showed the first non-trivial progress towards the problem). It remains open today, although there are some important partial results. Another well-known conjecture in the subject is the ")#link("http://en.wikipedia.org/wiki/Goldbach%27s_weak_conjecture")[#text("odd Goldbach conjecture")]#text(" (dating from 1742), which asserts that every odd number n greater than 5 is the sum of three primes. A famous ")#link("http://en.wikipedia.org/wiki/Vinogradov's_theorem")[#text("theorem of Vinogradov")]#text(" asserts that this conjecture is true for all sufficiently large n; Vinogradov’s original argument did not explicitly say how large is “sufficiently large”, but later authors did quantify the argument; currently, ")#link("http://www.ams.org/mathscinet-getitem?mr=1932763")[#text("it is known that")]#text(" the odd Goldbach conjecture is true for all odd ")#mi("n > 10^{1346}")#text(". (The conjecture is ")#link("http://www.ams.org/mathscinet-getitem?mr=1451327")[#text("also known")]#text(" for all odd ")#mi("5 < n < 10^{20}")#text(", by a completely different method. :-) ).")

#text("In this talk, I will present the following result of myself and Ben Green in this subject:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("http://en.wikipedia.org/wiki/Green%E2%80%93Tao_theorem")[#strong[#text("Green-Tao Theorem")]]#text(". The prime numbers ")#mi("{\\mathcal P} = \\{2,3,5,7,\\ldots\\}")#text(" contain arbitrarily long arithmetic progressions.")
]

#text("More specifically, I want to talk about three basic ingredients in the proof, and how they come together to prove the theorem:")

#enum(start: 1, 
[#text("Random models for the primes;")],
[#text("Sieve theory and almost primes;")],
[#text("Szemerédi’s theorem on arithmetic progressions.")]
)

#heading(level: 1)[#text("— Random models for the primes —")]

#text("One of the most fundamental results in this field is the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(", which asserts that the number of primes less than any large integer N is asymptotically equal to ")#mi("(1+o(1)) \\frac{N}{\\log N}")#text(" as N goes to infinity. This theorem is proven by using the ")#link("http://en.wikipedia.org/wiki/Euler_product")[#text("Euler product ")]#text("formula")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) = \\sum_{n=1}^\\infty \\frac{1}{n^s}  = \\prod_p (1 - \\frac{1}{p^s})^{-1}")]]

#text("which relates the primes to the ")#link("http://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("Riemann zeta function")]#text(" ")#mi("\\zeta(s)")#text(". [Incidentally, this formula, if rewritten using the ")#link("http://en.wikipedia.org/wiki/Geometric_series")[#text("geometric series formula")]#text(" as")

#mi("\\sum_{n=1}^\\infty \\frac{1}{n^s} = \\prod_p (1 + \\frac{1}{p^s} + \\frac{1}{p^{2s}} + \\ldots)")

#text("is a restatement (via ")#link("http://en.wikipedia.org/wiki/Generating_function")[#text("generating functions")]#text(") of the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_arithmetic")[#text("fundamental theorem of arithmetic")]#text("; if instead one rewrites it as")

#align(center)[#tao-fit-display[#mitex("(1-\\frac{1}{2^s}) (1-\\frac{1}{3^s}) (1-\\frac{1}{5^s}) \\ldots \\times \\sum_{n=1}^\\infty \\frac{1}{n^s} = 1")]]

#text("one can view this as a restatement of (a variant of) the ")#link("http://en.wikipedia.org/wiki/Sieve_of_Eratosthenes")[#text("sieve of Eratosthenes")]#text(".] By combining this formula with some non-trivial facts about the Riemann zeta function (and in particular, in the zeroes of that function), one can eventually obtain the prime number theorem.")

#text("One way to view the prime number theorem is as follows: if one picks an integer n from 1 to N at random, then that number n has a probability of ")#mi("\\frac{1+o(1)}{\\log N}")#text(" of being prime.")

#text("With this in mind, one can propose the following heuristic “proof” of the twin prime conjecture:")

#enum(start: 1, 
[#text("Take a large number N, and let n be a randomly chosen integer from 1 to N. By the prime number theorem, the event that n is prime has probability ")#mi("\\text{Prob}(n \\text{ is prime}) = \\frac{1+o(1)}{\\log N}")#text(".")],
[#text("By another application of the prime number theorem, the event that n+2 is prime also has probability ")#mi("\\text{Prob}(n+2 \\text{ is prime}) = \\frac{1+o(1)}{\\log N}")#text(". (The shift by 2 causes some additional correction terms, but these can be easily absorbed into the o(1) term.)")],
[#text("Assuming these two events are independent, we conclude ")#mi("\\text{Prob}(n, n+2 \\text{ both prime}) = (\\frac{1+o(1)}{\\log N})^2")#text(". In other words, the number of twin primes less than N is ")#mi("(1+o(1)) \\frac{N}{\\log^2 N}")#text(".")],
[#text("Since ")#mi("(1+o(1)) \\frac{N}{\\log^2 N}")#text(" goes to infinity as N goes to infinity, there are infinitely many twin primes.")]
)

#text("Unfortunately, this argument doesn’t work. One way to see this is to observe that the same argument could be trivially modified to imply that there are infinitely many pairs of ")#emph[#text("adjacent")]#text(" primes n, n+1, which is clearly absurd.")

#text("OK, so the above argument is broken; can we fix it? Well, we can try to accomodate the above objection. Why is it absurd to have infinitely many pairs of adjacent primes? Ultimately, it is because of the obvious fact that the prime numbers are all odd (with one exception). In contrast, the above argument was implicitly using a ")#emph[#text("random model")]#text(" for the primes (first proposed by Cramer) in which every integer from 1 to N – odd or even – had an equal chance of ")#mi("\\frac{1+o(1)}{\\log N}")#text(" of being prime; this model is clearly at odds with the parity structure of the primes. But we can repair this by replacing the above random model with a more sophisticated model in which parity is taken into account. More precisely, we observe that a randomly chosen odd number from 1 to N has a probability of ")#mi("\\frac{2+o(1)}{\\log N}")#text(" of being prime, while a randomly chosen even number has a probability of ")#mi("\\frac{0+o(1)}{\\log N}")#text(" (one can be more precise than this, of course). In the language of probability theory, we have the ")#link("http://en.wikipedia.org/wiki/Conditional_probability")[#text("conditional probabilities")]

#tao-aligned(keep: true)[


#tao-math("\\text{Prob}( n \\text{ is prime } | n \\text{ is odd})  & = \\frac{2+o(1)}{\\log N}", block: true)



#tao-math("\\text{Prob}( n \\text{ is prime } | n \\text{ is even})  & = \\frac{0+o(1)}{\\log N}", block: true)
]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("\\text{Prob}( n+2 \\text{ is prime } | n \\text{ is odd}) = \\frac{2+o(1)}{\\log N}")]]

#align(center)[#mi("\\text{Prob}( n+2 \\text{ is prime } | n \\text{ is even}) = \\frac{0+o(1)}{\\log N}")#text(".")]

#text("Now, instead of assuming that the events “n is prime” and “n+2 is prime” are absolutely independent, let us assume that they are ")#emph[#text("conditionally")]#text(" independent, relative to the parity of n. Then we conclude that")

#tao-aligned(keep: true)[


#tao-math("\\text{Prob}( n, n+2 \\text{ both prime } | n \\text{ is odd})  & = \\frac{4+o(1)}{\\log^2 N}", block: true)



#tao-math("\\text{Prob}( n, n+2 \\text{ both prime } | n \\text{ is even})  & = \\frac{0+o(1)}{\\log^2 N}", block: true)
]

#text("and a little computation (using the ")#link("http://en.wikipedia.org/wiki/Law_of_total_probability")[#text("law of total probability")]#text(") then shows that the number of twin primes less than N is now ")#mi("(2+o(1)) \\frac{N}{\\log^2 N}")#text(", which still goes to infinity, and so we recover the twin prime conjecture again. Or do we?")

#text("Well, the above random model is still flawed. It now correctly asserts that there are extremely few pairs n,n+1 of adjacent primes, but it also erroneously predicts that there are infinitely many triplets of primes of the form n, n+2, n+4, when in fact there is only one – 3,5,7 – since exactly one of n, n+2, n+4 must be divisible by 3. But we can refine the random model further by taking mod 3 structures into account as well as mod 2 structures. Indeed, if we partition the integers from 1 to N using both the mod 2 partition and the mod 3 partition, we obtain the six residue classes ")#mi("\\{ 1\\leq n \\leq N: n=i \\text{ mod } 6\\}")#text(" for i=0,1,2,3,4,5. From the prime number theorem in arithmetic progressions (a common generalisation of the prime number theorem and ")#link("http://en.wikipedia.org/wiki/Dirichlet's_theorem_on_arithmetic_progressions")[#text("Dirichlet’s theorem")]#text(") one can show that")

#align(center)[#mi("\\text{Prob}(n \\text{ is prime}| n = i \\text{ mod } 6 ) = \\frac{3+o(1)}{\\log N}")#text(" for i=1,5")]

#text("and")

#align(center)[#mi("\\text{Prob}(n \\text{ is prime}| n = i \\text{ mod } 6 ) = \\frac{0+o(1)}{\\log N}")#text(" for i=0,2,3,4")]

#text("and by repeating the previous analysis, the predicted count of twin primes less than N now drops from ")#mi("(2+o(1))\\frac{N}{\\log^2 N}")#text(" to ")#mi("(1.5 +o(1))\\frac{N}{\\log^2 N}")#text(".")

#text("Now, it turns out that this model is still not correct – it fails to account for the mod 5 structure of the primes. But it is not hard to incorporate that structure into this model also, which revises the twin prime count downward a bit to ")#mi("(1.40625 +o(1))\\frac{N}{\\log^2 N}")#text(". And then the mod 7 structure also changes the predicted number of twin primes a little bit more, and so on and so forth. But one notices that as one continues to input in all this structural information about the primes, the predicted count of twin primes begins to converge to a limit, namely ")#mi("(2\\Pi_2 + o(1))\\frac{N}{\\log^2 N} \\approx 1.32 \\frac{N}{\\log^2 N}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\Pi_2 := \\prod_{p \\geq 3, \\text{ prime}} (1 - \\frac{1}{(p-1)^2}) = 0.66016\\ldots")]]

#text("is known as the ")#link("http://mathworld.wolfram.com/TwinPrimesConstant.html")[#text("twin prime constant")]#text(". More generally, Hardy and Littlewood proposed a general conjecture, now known as the ")#emph[#text("Hardy-Littlewood prime k-tuples conjecture")]#text(", that predicted asymptotic counts for a general class of additive patterns in the primes; this conjecture (and further refinements) would imply the twin prime conjecture, Vinogradov’s theorem, my theorem with Ben Green, and many other results and conjectures in the subject also.")

#text("Roughly speaking, these conjectures assert that apart from the “obvious” structure in the primes, arising from the prime number theorem and from the local behaviour of the primes mod 2, mod 3, etc., there are no other structural patterns in the primes, and so the primes behave “pseudorandomly” once all the obvious structures are taken into account. The conjectures are plausible, and backed up by a significant amount of numerical evidence; unfortunately, nobody knows how to enforce enough pseudorandomness in the primes to make the conjectures rigorously proven. (One cannot simply take limits of the above random models as one inputs more and more mod p information, because the o(1) error terms grow rapidly and soon overwhelm the main term that one is trying to understand.) The problem is that the primes may well contain “exotic structures” or “conspiracies”, beyond the obvious structures listed above, which could further distort things like the twin prime count, perhaps so much so that only finitely many twin primes remain. This seems extremely unlikely, but we can’t rule it out completely yet; how can one disprove a conspiracy?")

#text("Some numerics may help illustrate what I mean by the primes becoming random after the mod 2, mod 3, etc. structures are “taken into account” (though I should caution against reading ")#emph[#text("too")]#text(" much into such small-scale computations, as there are many opportunities in small data sets for random coincidences or transient phenomena to create misleading artefacts). Here are the first few natural numbers, with the primes in red, the odd numbers in the starred columns, and the even numbers in dotted columns:")

#list(
[#raw("*  .  *  .  *  .  *  .  *  .  *  .  *  .", block: true)],
[#raw("1  2  3  4  5  6  7  8  9  10 11 12 13 14", block: true)],
[#raw("15 16 17 18 19 20 21 22 23 24 25 26 27 28", block: true)],
[#raw("29 30 31 32 33 34 35 36 37 38 39 40 41 42", block: true)],
[#raw("43 44 45 46 47 48 49 50 51 52 53 54 55 56", block: true)]
)

#text("[Ignore the bullet points; they are a hack to deal with an annoying formatting bug.] It is then clear that the primes have mod 2 structure; they cluster in the odd numbers rather than the even numbers, and are thus distributed quite non-randomly. But suppose we “zoom in” on the odd numbers, discarding the even numbers:")

#list(
[#raw("*  .  *  .  *  .  *  .  *  .  *  .  *  .  *  .", block: true)],
[#raw("1  3  5  7  9  11 13 15 17 19 21 23 25 27 29 31", block: true)],
[#raw("33 35 37 39 41 43 45 47 49 51 53 55 57 59 61 63", block: true)],
[#raw("65 67 69 71 73 75 77 79 81 83 85 87 89 91 93 95", block: true)]
)

#text("Then it seems that there is no further parity structure; the starred columns (which have numbers which are 1 mod 4) and the dotted columns (which have numbers which are 3 mod 4), seem equally likely to contain primes. (Indeed, this is a proven fact, being a special case of the prime number theorem in arithmetic progressions.) But look what happens if we highlight the mod 3 structure instead:")

#list(
[#raw("*  .     *  .     *  .     *  .", block: true)],
[#raw("1  3  5  7  9  11 13 15 17 19 21 23", block: true)],
[#raw("25 27 29 31 33 35 37 39 41 43 45 47", block: true)],
[#raw("49 51 53 55 57 59 61 63 65 67 69 71", block: true)],
[#raw("73 75 77 79 81 83 85 87 89 91 93 95", block: true)]
)

#text("Then the dotted columns (whose entries are 0 mod 3) are devoid of primes other than 3 itself. But if we instead zoom into (say) the starred columns (whose entries are 1 mod 3), we eliminate the mod 3 structure, making the remaining primes more randomly distributed:")

#list(
[#raw("*               .   *               .", block: true)],
[#raw("1   7   13  19  25  31  37  43  49  55", block: true)],
[#raw("61  67  73  79  85  91  97  103 109 115", block: true)],
[#raw("121 127 133 139 145 151 157 163 169 175", block: true)]
)

#text("Now the primes exhibit obvious mod 5 structure (the dotted columns, whose entries are 0 mod 5, have no primes) but look fairly randomly distributed otherwise. Indeed, if we zoom in to (say) the 1 mod 5 residue class, which are the starred columns above, there seems to be very little structure at all:")

#list(

)

#list(
[#raw("            .", block: true)],
[#raw("1   31  61  91  121 151 181", block: true)],
[#raw("211 241 271 301 331 361 391", block: true)],
[#raw("421 451 481 511 541 571 601", block: true)],
[#raw("631 661 691 721 751 781 811\r\n", block: true)]
)

#text("Apart from the dotted column, which has all entries divisible by 7 and thus not prime, the primes seem fairly randomly distributed. In the above examples I always zoomed into the residue class 1 mod p for p=2,3,5,…, but if one picks other residue classes (other than 0 mod p, of course), one also sees the primes become increasingly randomly distributed, with no obvious pattern within each class (and no obvious relation between pairs of classes, triplets of classes, etc.). One can view the prime k-tuples conjecture as a precise formalisation of this assertion of increasing random distribution. (In my paper with Ben, we rely quite crucially on this zooming in trick to improve the pseudorandomness of the almost primes, referring to it as the “W-trick”.)")

#text("— Sieve theory and almost primes —")

#text("We have talked about random models for the primes, which seem to be very accurate, but difficult to rigorously justify. However, there is a closely related concept to a prime, namely an ")#link("http://en.wikipedia.org/wiki/Almost_prime")[#text("almost prime")]#text(", for which we ")#emph[#text("can ")]#text("show the corresponding random models to be accurate, by the elementary yet surprisingly useful technique of ")#link("http://en.wikipedia.org/wiki/Sieve_theory")[#text("sieve theory")]#text(".")

#text("The most elementary sieve of all is the ")#link("http://en.wikipedia.org/wiki/Sieve_of_Eratosthenes")[#text("sieve of Eratosthenes")]#text(". This sieve uncovers (or “sifts out”) all the prime numbers in a given range, say between N/2 and N for some large number N, by starting with all the integers in this range, and then discarding all the multiples of 2, then the multiples of 3, the multiples of 5 and so forth. After all multiples of prime numbers less than ")#mi("\\sqrt{N}")#text(" are discarded, the remaining set is precisely the set of primes between N/2 and N.")

#text("It is tempting to use this sieve to count patterns in primes, such as twin primes. After all, it is easy to count how many twins there are in the integers from N/2 to N; if one then throws out all the multiples of 2, it is still straightforward to count the number of twins remaining. Similarly if one then throws out multiples of 3, of 5, and so forth; not surprisingly, the computations here bear some resemblance to those used to predict twin prime counts from the random models just mentioned. However, as with the random models, the error terms begin to accumulate rapidly, and one loses control of these counts long before one reaches the end of the sieve. More advanced sieves (in which one does not totally exclude the multiples of small numbers, but instead adjusts the “weight” or “score” of a number upward or downward depending on its factors) can improve matters significantly, but even the best sieves still only work if one stops sieving well before the ")#mi("\\sqrt{N}")#text(" mark (sieve levels such as ")#mi("N^{1/4}")#text(" are typical). (The reason for this has to do with the ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("parity problem")]#text(", which I will not discuss further here.)")

#text("I like to think of the sieving process as being analogous to carving out a sculpture (analogous to the primes) from a block of granite (analogous to the integers) . To begin with, one uses crude tools (such as a mallet) to remove large, simple pieces from the block; but after a while, one has to make finer and finer adjustments, replacing the mallet by a chisel, and then by a pick, removing lots and lots of very small pieces, until the final sculpture is complete. Initially, the structure is simple enough that one can easily pick out patterns (such as twins, or arithmetic progressions); but there is the (highly unlikely) possibility that the many small sets removed at the end are just distributed perversely enough to knock out all the patterns one discerns in the initial stage of the process.")

#text("Because we cannot exclude this possibility, sieve theory alone does not seem to able to count patterns in primes. However, we can stop the sieve at an earlier level. If we do so, we obtain good counts of patterns, not in primes, but in the larger set of almost primes – which, for the purposes of this talk, one can think of as being defined as those numbers with no small factors (e.g. no factors less than ")#mi("N^\\varepsilon")#text(" for some ")#mi("\\varepsilon > 0")#text("). (This is an oversimplification – one needs to use the weights mentioned above – but it will suffice for this discussion.) Then it turns out that (to oversimplify some more), everything we want to show about the primes, we can show about the almost primes. For instance, it was ")#link("http://en.wikipedia.org/wiki/Chen%27s_theorem")[#text("shown by Chen")]#text(" that there are infinitely many twins ")#mi("n,n+2")#text(", one of which is a prime and the other is the product of at most two primes. Similarly, given any k, one can show using sieve theory that there are infinitely many arithmetic progressions of length k, each element of which has at most ")#mi("O_k(1)")#text(" prime factors. More generally, the almost primes behave the way we expect the primes to; distributed pseudorandomly, after taking into account the obvious structures (for instance, almost primes, like the primes, tend to be almost all coprime to 2, coprime to 3, etc.)")

#text("Unfortunately, there is still a gap between finding patterns in the almost primes and finding patterns in the primes themselves, because the primes are only a subset of the almost primes. For instance, while the number of primes less than N is roughly ")#mi("N/\\log N")#text(", the number of numbers less than N with no factors less than (say) ")#mi("N^{1/100}")#text(" is (very) roughly ")#mi("100 N/\\log N")#text(". Thus the primes only form a small fraction of the almost primes.")

#heading(level: 1)[#text("— Szemerédi’s theorem on arithmetic progressions —")]

#text("Thus far, we have discussed the general problem of how to find patterns in sets such as the primes or almost primes. This problem in general seems to be very difficult, because we do not know how structured or pseudorandom the primes are. There is however one type of pattern which is special – it necessarily shows up in just about any kind of set – structured or random. This type of set is an ")#emph[#text("arithmetic progression")]#text(". In fact, we have the following important theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("http://www.scholarpedia.org/article/Szemeredi%27s_Theorem")[#strong[#text("Szemerédi’s theorem")]]#text(": Let ")#mi("A \\subset {\\Bbb Z}")#text(" be a set of integers of positive upper density (which means that ")#tao-math("\\lim\\sup_{N \\to \\infty} \\frac{1}{2N+1} \\left|A \\cap \\{-N,\\ldots,N\\}\\right| > 0", block: false)#text("). Then A contains arbitrarily long arithmetic progressions.")
]

#text("This is a remarkable theorem: it says that if one picks any set of integers at all, so long as it is large enough to occupy a positive fraction of all integers, that is enough to guarantee the existence of arithmetic progressions of any length inside that set. This is in contrast with just about any other pattern, such as twins: for instance, the multiples of three have positive density, but contain no twins.")

#text("There are several proofs of this difficult theorem known. It would be too technical to discuss any of them here in detail, but ")#emph[#text("very")]#text(" roughly speaking, all the proofs proceed by dividing the set A into “structured” components (such as sets which are periodic) and “pseudorandom” components (which, roughly, are those components for which the random model gives accurate predictions). One can show that the structured components always generate a lot of arithmetic progressions, and that the pseudorandom components do not significantly disrupt this number of progressions.")

#text("Unfortunately, Szemerédi’s theorem does not apply to the primes, because they have zero density. (There are some quantitative versions of that theorem that apply to some sets of zero density, but they are not yet strong enough to directly deal with sets as sparse as the primes.)")

#heading(level: 1)[#text("— Putting it all together —")]

#text("To summarise: random models predict arbitrarily long progressions in the primes, but we cannot verify these models. Sieve theory does let us establish long progressions in the almost primes, but the primes are only a fraction of the almost primes. Szemerédi’s theorem gives progressions, but only for sets of positive density within the integers.")

#text("To proceed, we exploit the fact that the primes have positive ")#emph[#text("relative ")]#text("density inside the almost primes, by the following argument (inspired, incidentally, by Furstenberg’s ergodic-theoretic proof of Szemerédi’s theorem). We conjecture that the primes obey a certain random model, in which the only structure present being mod p structure for small p. If this is the case, then we are done. If not, it means that there is some specific obstruction to pseudorandomness in the primes, much as the mod 2 or mod 3 obstructions we discussed earlier prevented the most naive random models of the primes from being accurate. We don’t know exactly what that obstruction is, but it turns out that it is possible nevertheless to use that obstruction to modify the random model for the primes to be more accurate, much as we used the mod 2 and mod 3 information previously. We then repeat this process, locating obstructions to pseudorandomness and incorporating them into our random model, until no major obstructions remain. (This can be done after only a bounded number of steps, because one can show (with some effort) that each addition to the random model increases its “energy” by a certain amount, and one can show that the total amount of energy in the model must stay bounded.) As a consequence we know that we can model the primes accurately (at least for the purposes of counting arithmetic progressions) by ")#emph[#text("some")]#text(" random model. [I have not precisely defined what I mean here by “random model”, but very roughly speaking, any such model consists of a partition (or ")#link("http://en.wikipedia.org/wiki/Sigma-algebra")[#mi("\\sigma")#text("-algebra")]#text(") of the integers from 1 to N into a bounded number of sets, a specified density for the primes on each such set, and an assumption that the primes behave on each set like a random set with the specified density. Readers familiar with the ")#link("http://en.wikipedia.org/wiki/Szemeredi_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(" may see a parallel here.]")

#text("The above procedure does not give a very tractable formula for what this model is. However, because the primes are a dense subset of the almost primes, which behave like a random subset of the integers, one can show (by a “comparison principle”, and oversimplifying somewhat) that the primes must then behave like a random subset of a dense subset B of the integers. But then Szemerédi’s theorem applies, and shows that this set B contains plenty of progressions; a random subset of B will then also contain many progressions, and thus the primes will also.")

#text("[A simplified version of the above argument, using game theory instead of the above ergodic theory-motivated approach, was recently obtained by Reingold, Trevisan, Tulsiani, and Vadhan.]")

#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of km")]], [#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/#comment-23475")[#strong[#text("km")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2008")])]

#text("Hi Terry,")

#text("This is off the topic.")

#text("What is your view on solving the Riemann hypothesis? You wrote on solving the Navier-Stokes Millennium Prize problem some time ago.")#linebreak()#text(" Could you also write on the possible approaches in your mind that could tackle the Riemann hypothesis?")

#text("Thanks.")#linebreak()#text(" km")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5a96c1210bb1055434b8166e460d8e9308d56070151b691ba6ce3ac65b5fc1e4-9961310b488fe9662af8cc2aa2912a2d1704caac70020f8e2d0b8128ca702427.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron")]], [#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/#comment-23494")[#strong[#text("Aaron")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2008")])]

#text("It would be great if you could post video recordings of lectures when possible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/#comment-23673")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2008")])]

#text("Dear km: I actually haven’t thought seriously about RH since some very naive attempts at it in graduate school. It’s possible that one could approach this problem by finding out more structure in the zeta function, but my (somewhat uninformed) opinion is that zeta is inherently a rather pseudorandom object (except of course for its obvious structural properties such as meromorphicity, asymptotics, and the functional equation), and it may be better to return to the prime number side of things, for instance by locating a new proof of the prime number theorem, or finding a way to exclude Siegel zeroes and obtain a more effective prime number theorem in arithmetic progressions. But it’s hard to see how current methods can hope to get the type of power gain in the error terms for prime statistics which would be needed for the full RH; some radically new idea would be needed for that, probably.")

#text("Dear Aaron: I don’t believe these lectures were recorded on video.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca640c7f60206dfdc2e877f639343f2704f64dfe284fd6ab57277171df2e223e-e09bfd82b885450a84386bc766a113e6e8f028f94ba8370cc22353e894244428.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shubhendu Trivedi")]], [#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/#comment-120499")[#strong[#text("Shubhendu Trivedi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2012")])]

#text("Dear Prof. Tao,")

#text("It might not be the same event, but the material on this post (RH, Szemeredi’s Theorem, Green-Tao Theorem) seems to be the same as on this video (including the title):")#linebreak()
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d06a1da18a50ebc7a9bfb52c1488f8b1a998309feb22dce5101294227f315c7-850f082c8d3a111855639dec6fb204547f5e05cffd889ab402a4d777c019ede9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni")]], [#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/#comment-23987")[#strong[#text("Giovanni")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2008")])]

#text("Dear Terence")

#text("I’m not a very mathematician, but I’m very interesting about Your Blog.")

#text("Then, I’m not undestand about arithmetic function o(1) or in general o(n).")

#text("Please can You explain me the definition?.")

#text("Best Regards")#linebreak()#text(" Giovanni")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/927b5d43d7b9c716986ffbcf8744112135a73af9a6adac81c5a2524a7662baed-7dc7bfe2252f25957b54848265da7f0c2b88b77d6ba7b28c8419362f26f919b1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris")]], [#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/#comment-24012")[#strong[#text("Chris")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2008")])]

#text("Dear Terence,")

#text("thanks for the illuminating article.. i do a lot of ring sieve theory, basically wrapping integers around a spiral of base B.")

#text("there’s some neat things you can find about the ring sieves, such as the really pretty geometry that results when you are demodulating things such as RSA encrypted information, structures that are two primes multiplied with each other.")

#text("anyways, i noticed that there’s a really interesting base, 24. It is the last base that the powers of the primes all occur as remainder 1 modulo 24. Could this be helpful in your investigations on the ‘pick’ level of the structure you mention?")

#text("chris.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/#comment-24176")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2008")])]

#text("Dear Giovanni,")

#text("The o() notation is part of Landau notation, more popularly known as “big-O” and “little-O” notation:")

#link("http://en.wikipedia.org/wiki/Big_O_notation")[#text("http://en.wikipedia.org/wiki/Big_O_notation")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of circadian rhythm")]], [#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/#comment-24294")[#strong[#text("circadian rhythm")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2008")])]

#text("Dear km,")#linebreak()#text(" Recent experience with big results suggests that first someone should")#linebreak()#text(" come up with a programme. I would first read what De Branges has to")#linebreak()#text(" say on the matter. Though this might require a lot of night reading.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b5596cf6b4291dd5ab33b31acb9009ae12f8e8c00dcf2024268564706892646-00ee431873189849b8e26ff77769fe49c4aec8670c8df1b145d3c9f8f4867e69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kadhirvel")]], [#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/#comment-31661")[#strong[#text("Kadhirvel")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2008")])]

#text("Please follow the link below for fact about primes")

#link("http://kadiprimality.blogspot.com/")[#text("http://kadiprimality.blogspot.com/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marker lectures II, “Linear equations in primes” « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/#comment-33571")[#strong[#text("Marker lectures II, “Linear equations in primes” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2008")])]

#text("[…] My first lecture, “Long arithmetic progressions in primes”, is similar to my AMS lecture on the same topic and so I am not reposting it here. The second lecture, the notes for which begin after the fold, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dad858138d940faa9c39e32cabc24dc086f062d087aca38f23804c8f77fe6aa9-53e11d3f6a235265649f9edc512afcf76e0d0e82de8a27c43048414c1cf4fe1f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paddy Ganti")]], [#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/#comment-33593")[#strong[#text("Paddy Ganti")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2008")])]

#text("[Terence] I have just ‘discovered’ you yesterday and really love what I you did so far.")#linebreak()#text(" I was naieve enough to try a similar approach (the mod p one) at my grad school. You can view my output of survery work here: ise.gmu.edu/~paddy/CSIS.ppt where I have an alternative version of mod 3 approach as “Every prime other than 3 has to be of the firm sqrt(1+24n)” and then trying to prove that there will be atleast one such thing between n and 2n..")

#text("[Aaron] This video link will be appropriate for you: ")#link("http://video.google.com/googleplayer.swf?docid=7691494040933085582&hl=en")[#text("http://video.google.com/googleplayer.swf?docid=7691494040933085582&hl=en")]#text(" as it contains the same gist laid out in the article.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of More Mahler lectures « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/#comment-41231")[#strong[#text("More Mahler lectures « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2009")])]

#text("[…] Recent progress in additive prime number theory. This is an updated and reformatted version of my AMS lecture on this topic. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heuristic limitations of the circle method « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/#comment-143788")[#strong[#text("Heuristic limitations of the circle method « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2012")])]

#text("[…] the prediction (7) by a multiplicative constant known as the twin prime constant; see for instance this previous blog post for more discussion. Our analysis here is focused on orders of growth in rather than on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The probabilistic heuristic justification of the ABC conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/#comment-172290")[#strong[#text("The probabilistic heuristic justification of the ABC conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2012")])]

#text("[…] However, there is a standard way to correct for these local correlations; see for instance in this previous blog post. As it turns out, these local correlations ultimately alter the prediction for the asymptotic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90be308eed25ee97422b84bb02b87e52566d4e296322a811776b8ebbfeb5cf46-92174fba00f66eede65dbb894aba8b12eabf1776e9882fcc866f44f1799e58b2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathtuition88")]], [#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/#comment-255378")[#strong[#text("mathtuition88")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2013")])]

#text("Reblogged this on ")#link("http://mathtuition88.com/2013/12/04/ams-lecture-structure-and-randomness-in-the-prime-numbers/")[#text("Singapore Maths Tuition")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/381f43135545986200712f05bdea1248f732561d981a3bedb59c9606734eca05-6071fd7255dc2dc3cfe34b4717111edc63fc626958a8ddb601d254afd37d4023.gif", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Saman Ranjbar")]], [#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/#comment-365960")[#strong[#text("Saman Ranjbar")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2014")])]

#text("terry can i ask something .what happen if we have a way for finding all prime numbers?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/#comment-451504")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2015")])]

#text("Dear Prof, Tao")#linebreak()#text(" I am asking if there is a mathematical poof that the event: (p is a prime and p+2 is also a prime) occurs inependentely from the previous couples of twin primes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67c854637d9f39d895a594ce873c97eaa99800ba101acf16525f2cbbfca2f365-e3872974876f9454dcf6c892196b39f4fe7dc832022508bf10e0e7f32dc6204d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ollev")]], [#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/#comment-456548")[#strong[#text("Ollev")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2015")])]

#text("Dear Sir, as far as i know the rhyhtm of primes has been easily solved about 5 years ago by Johan Oldekamp, a Dutch man. Here is the link")

#link("http://www.pateo.nl/PDF/PrimeRhythm.pdf")[#text("Click to access PrimeRhythm.pdf")]
]
