// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/
// Converted to Typst by tao2typ: "2026-10-14T15:18:15.599127+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The structure of approximate groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The structure of approximate groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 October 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/")[#text("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#link("http://www.math.u-psud.fr/~breuilla/indexgb.html")[#text("Emmanuel Breuillard")]#text(", ")#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(", and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1110.5008")[#text("The structure of approximate groups")]#text("“, submitted to ")#link("http://www.springer.com/mathematics/journal/10240")[#text("Pub. IHES")]#text(". We had announced the main results of this paper in various forums (including ")#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/")[#text("this blog")]#text(") for a few months now, but it had taken some time to fully write up the paper and put in various refinements and applications.")

#text("As announced previously, the main result of this paper is what is a (virtually, qualitatively) complete description of finite approximate groups in an arbitrary (local or global) group ")#mi("{G}")#text(". For simplicity let us work in the much more familiar setting of global groups, although our results also apply (but are a bit more technical to state) in the local group setting.")

#text("Recall that in a global group ")#mi("{G = (G,\\cdot)}")#text(", a ")#mi("{K}")#text("-approximate group is a symmetric subset ")#mi("{A}")#text(" of ")#mi("{G}")#text(" containing the origin, with the property that the product set ")#mi("{A \\cdot A}")#text(" is covered by ")#mi("{K}")#text(" left-translates of ")#mi("{A}")#text(". Examples of ")#mi("{O(1)}")#text("-approximate groups include genuine groups, convex bodies in a bounded dimensional vector space, small balls in a bounded dimensional Lie group, large balls in a discrete nilpotent group of bounded rank or step, or generalised arithmetic progressions (or more generally, coset progressions) of bounded rank in an abelian group. Specialising now to finite approximate groups, a key example of such a group is what we call a ")#emph[#text("coset nilprogression")]#text(": a set of the form ")#mi("{\\pi^{-1}(P)}")#text(", where ")#mi("{\\pi: G^{\\prime} \\rightarrow N}")#text(" is a homomorphism with finite kernel from a subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" to a nilpotent group ")#mi("{N}")#text(" of bounded step, and ")#mi("{P = P(u_1,\\ldots,u_r;N_1,\\ldots,N_r)}")#text(" is a ")#emph[#text("nilprogression")]#text(" with a bounded number of generators ")#mi("{u_1,\\ldots,u_r}")#text(" in ")#mi("{N}")#text(" and some lengths ")#mi("{N_1,\\ldots,N_r \\gg 1}")#text(", where ")#mi("{P(u_1,\\ldots,u_r;N_1,\\ldots,N_r)}")#text(" consists of all the words involving at most ")#mi("{N_1}")#text(" copies of ")#mi("{u_1^{\\pm 1}}")#text(", ")#mi("{N_2}")#text(" copies of ")#mi("{u_2^{\\pm 1}}")#text(", and so forth up to ")#mi("{N_r}")#text(" copies of ")#mi("{u_r^{\\pm 1}}")#text(". One can show (by some nilpotent algebra) that all such coset nilprogressions are ")#mi("{O(1)}")#text("-approximate groups so long as the step and the rank ")#mi("{r}")#text(" are bounded (and if ")#mi("{N_1,\\ldots,N_r}")#text(" are sufficiently large).")

#text("Our main theorem (which was essentially conjectured independently by Helfgott and by Lindenstrauss) asserts, roughly speaking, that coset nilprogressions are essentially the only examples of approximate groups.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Let ")#mi("{A}")#text(" be a ")#mi("{K}")#text("-approximate group. Then ")#mi("{A^4}")#text(" contains a coset nilprogression ")#mi("{P}")#text(" of rank and step ")#mi("{O_K(1)}")#text(", such that ")#mi("{A}")#text(" can be covered by ")#mi("{O_K(1)}")#text(" left-translates of ")#mi("{P}")#text(".")
]

#text("In the torsion-free abelian case, this result is essentially ")#link("http://www.ams.org/mathscinet-getitem?mr=360496")[#text("Freiman’s theorem")]#text(" (with an alternate proof ")#link("http://www.ams.org/mathscinet-getitem?mr=1281447")[#text("by Ruzsa")]#text("); for general abelian case, it is due to Green and Ruzsa. Various partial results in this direction for some other groups (e.g. free groups, nilpotent groups, solvable groups, or simple groups of Lie type) are also known; see ")#link("https://terrytao.wordpress.com/2007/03/02/open-question-noncommutative-freiman-theorem/")[#text("these")]#text(" ")#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/")[#text("previous")]#text(" ")#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/")[#text("blog posts")]#text(" for a summary of several of these results.")

#text("This result has a number of applications to geometric growth theory, and in particular to variants of ")#link("http://en.wikipedia.org/wiki/Gromov's_theorem_on_groups_of_polynomial_growth")[#text("Gromov’s theorem of groups of polynomial growth")]#text(", which asserts that a finitely generated group is of polynomial growth if and only if it is virtually nilpotent. The connection lies in the fact that if the balls ")#mi("{B_S(R)}")#text(" associated to a finite set of generators ")#mi("{S}")#text(" has polynomial growth, then some simple volume-packing arguments combined with the pigeonhole principle will show that ")#mi("{B_S(R)}")#text(" will end up being a ")#mi("{O(1)}")#text("-approximate group for many radii ")#mi("{R}")#text(". In fact, since our theorem only needs a ")#emph[#text("single")]#text(" approximate group to obtain virtually nilpotent structure, we are able to obtain some new strengthenings of Gromov’s theorem. For instance, if ")#mi("{A}")#text(" is any ")#mi("{K}")#text("-approximate group in a finitely generated group ")#mi("{G}")#text(" that contains ")#mi("{B_S(R_0)}")#text(" for some set of generators ")#mi("{S}")#text(" and some ")#mi("{R_0}")#text(" that is sufficiently large depending on ")#mi("{K}")#text(", our theorem implies that ")#mi("{G}")#text(" is virtually nilpotent, answering a ")#link("http://mathoverflow.net/questions/11091/generalization-of-gromovs-theorem-on-polynomial-growth")[#text("question of Petrunin")]#text(". Among other things, this gives an alternate proof of a recent ")#link("http://arxiv.org/abs/1105.5955")[#text("result of Kapovitch and Wilking")]#text(" (see also ")#link("http://www.ams.org/mathscinet-getitem?mr=1405949")[#text("this previous paper of Cheeger and Colding")]#text(") that a compact manifold of bounded diameter and Ricci curvature at least ")#mi("{-\\epsilon}")#text(" necessarily has a virtually nilpotent fundamental group if ")#mi("{\\epsilon}")#text(" is sufficiently small (depending only on dimension). The main point here is that no lower bound on the injectivity radius is required. Another application is a “Margulis-type lemma”, which asserts that if a metric space ")#mi("{X}")#text(" has “bounded packing” (in the sense that any ball of radius (say) ")#mi("{4}")#text(" is covered by a bounded number of balls of radius ")#mi("{1}")#text("), and ")#mi("{\\Gamma}")#text(" is a group of isometries on ")#mi("{X}")#text(" that acts discretely (i.e. every orbit has only finitely many elements (counting multiplicity) in each bounded set), then the near-stabiliser ")#mi("{\\{ \\gamma \\in \\Gamma: d(\\gamma x, x) \\leq \\epsilon \\}}")#text(" of a point ")#mi("{x}")#text(" is virtually nilpotent if ")#mi("{\\epsilon}")#text(" is small enough depending on the packing constant.")

#text("There are also some variants and refinements to the main theorem proved in the paper, such as an extension to local groups, and also an improvement on the bound on the rank and step from ")#mi("{O_K(1)}")#text(" to ")#mi("{O(\\log K)}")#text(" (but at the cost of replacing ")#mi("{A^4}")#text(" in the theorem with ")#mi("{A^{O(1)}}")#text(").")

#text("I’ll be discussing the proof of the main theorem in detail in the next few ")#link("https://terrytao.wordpress.com/category/teaching/254a-hilberts-fifth-problem/")[#text("lecture notes of my current graduate course")]#text(". The full proof is somewhat lengthy (occupying about 50 pages of the 90-page paper), but can be summarised in the following steps:")

#enum(start: 1, 
[#text("(Hrushovski) Take an arbitrary sequence ")#mi("{A_n}")#text(" of finite ")#mi("{K}")#text("-approximate groups, and show that an appropriate limit ")#mi("{A}")#text(" of such groups can be “modeled” in some sense by an open bounded subset of a locally compact group. (The precise definition of “model” is technical, but “macroscopically faithful representation” is a good first approximation.) As discussed in the ")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("previous lecture notes")]#text(", we use an ultralimit for this purpose; the ")#link("http://arxiv.org/abs/0909.2190")[#text("paper of Hrushovski")]#text(" where this strategy was first employed also considered more sophisticated model-theoretic limits. To build a locally compact topology, Hrushovski used some tools from definability theory; in our paper, we instead use a combinatorial lemma ")#link("http://arxiv.org/abs/0912.0306")[#text("of Sanders")]#text(" (closely related to a ")#link("http://arxiv.org/abs/1003.2978")[#text("similar result of Croot and Sisask")]#text(".)")],
[#text("(Gleason-Yamabe) The locally compact group can in turn be “modeled” by a Lie group (possibly after shrinking the group, and thus the ultralimit ")#mi("{A}")#text(", slightly). (This result arose from the solution to Hilbert’s fifth problem, as discussed ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("here")]#text(". For our extension to local groups, we use a recent local version of the Gleason-Yamabe theorem, ")#link("http://www.ams.org/mathscinet-getitem?mr=2680491")[#text("due to Goldbring")]#text(".)")],
[#text("(Gleason) Using the escape properties of the Lie model, construct a norm ")#mi("{\\| \\|}")#text(" (and thus a left-invariant metric ")#mi("{d}")#text(") on the ultralimit approximate group ")#mi("{A}")#text(" (and also on the finitary groups ")#mi("{A_n}")#text(") that obeys a number of good properties, such as a commutator estimate ")#tao-math("{\\left\\| [g,h]\\right\\| \\ll \\left\\|g\\right\\| \\left\\|h\\right\\|}", block: false)#text(". (This is modeled on an analogous construction used in the theory of Hilbert’s fifth problem, as discussed in ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("this previous set of lecture notes")]#text(".) This norm is essentially an ")#emph[#text("escape norm")]#text(" associated to (a slight modification) of ")#mi("{A}")#text(" or ")#mi("{A_n}")#text(".")],
[#text("(Jordan-Bieberbach-Frobenius) We now take advantage of the finite nature of the ")#mi("{A_n}")#text(" by locating the non-trivial element ")#mi("{e}")#text(" of ")#mi("{A_n}")#text(" with minimal escape norm (but one has to first quotient out the elements of zero escape norm first). The commutator estimate mentioned previously ensures that this element is essentially “central” in ")#mi("{A_n}")#text(". One can then quotient out a progression ")#mi("{P(e;N)}")#text(" generated by this central element (reducing the dimension of the Lie model by one in the process) and iterates the process until the dimension of the model drops to zero. Reversing the process, this constructs a coset nilprogression inside ")#mi("{A_n^4}")#text(". This argument is based on the classic proof of Jordan’s theorem due to Bieberbach and Frobenius, as discussed in ")#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/")[#text("this blog post")]#text(".")]
)

#text("One quirk of the argument is that it requires one to work in the category of local groups rather than global groups. (This is somewhat analogous to how, in the standard proofs of Freiman’s theorem, one needs to work with the category of Freiman homomorphisms, rather than group homomorphisms.) The reason for this arises when performing the quotienting step in the Jordan-Bieberbach-Frobenius leg of the argument. The obvious way to perform this step (and the thing that we tried first) would be to quotient out by the entire cyclic group ")#mi("{\\langle e \\rangle}")#text(" generated by the element ")#mi("{e}")#text(" of minimal escape norm. However, it turns out that this doesn’t work too well, because the group quotiented out is so “large” that it can create a lot of torsion in the quotient. In particular, elements which used to have positive escape norm, can now become trapped in the quotient of ")#mi("{A_n}")#text(", thus sending their escape norm to zero. This leads to an inferior conclusion (in which a coset nilprogression is replaced by a more complicated tower of alternating extensions between central progressions and finite groups, similar to the towers encountered in ")#link("https://terrytao.wordpress.com/2009/06/21/freimans-theorem-for-solvable-groups/")[#text("my previous paper on this topic")]#text("). To prevent this unwanted creation of torsion, one has to truncate the cyclic group ")#mi("{\\langle e \\rangle}")#text(" before it escapes ")#mi("{A_n}")#text(", so that one quotients out by a geometric progression ")#mi("{P(e;N)}")#text(" rather than the cyclic group. But the operation of quotienting out by a ")#mi("{P(e;N)}")#text(", which is a local group rather than a global one, cannot be formalised in the category of global groups, but only in the category of local groups. Because of this, we were forced to carry out the entire argument using the language of local groups. As it turns out, the arguments are ultimately more natural in this setting, although there is an initial investment of notation required, given that global group theory is much more familiar and well-developed than local group theory.")

#text("One interesting feature of the argument is that it does not use much of the existing theory of Freiman-type theorems, instead building the coset nilprogression directly from the geometric properties of the approximate group. In particular, our argument gives a new proof of Freiman’s theorem in the abelian case, which largely avoids Fourier analysis (except through the use of the theory of Hilbert’s fifth problem, which uses the Peter-Weyl theorem (or, in the abelian case, Pontryagin duality), which is basically a version of Fourier analysis).")

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Proof mining and approximate groups, announcement | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-96319")[#strong[#text("Proof mining and approximate groups, announcement | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2011")])]

#text("[…] 25.10: Today a new post of Tao announces the submission on arxiv of the paper by him, Emmanuel Breuillard and Ben Green, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-96437")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2011")])]

#text("The link to the “result of Kapovitch and Wilking” points to the paper you uploaded.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c814c1d1d60f9ae9f0b4a8c3504a7a93b917da52dfe8beb620236cfd1cf6f2-1419c9047be3748241f842e416768704afe8c7b54074f2f5d60a234b69b0ba09.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Colin Reid")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-96499")[#strong[#text("Colin Reid")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2011")])]

#text("What results are there like this when A is infinite? I am wondering if approximate group theory can be used to prove any interesting statements about how a commensurated (‘approximately normal’) subgroup H of an infinite group G is related to the normal closure of H in G, or about the ‘group-like’ structure of G/H.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-96532")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2011")])]

#text("For infinite approximate groups (such as open precompact approximate groups in a locally compact group) some of the machinery indicated above seems to go through (in particular, the “Hrushovski”, “Gleason-Yamabe”, and “Gleason” components of the argument look likely to extend to this setting). However, the final step of the argument (what I called the “Jordan-Bieberbach-Frobenius” step) relies crucially on finiteness at this point. One of my students is looking at the extent to which these arguments can be carried over to the infinite setting though.")

#text("Your question about commensurated subgroups is an interesting one. At first glance, there does not seem to be an easy way to insert approximate groups into the situation: even if all conjugates gHg^{-1} are boundedly commensurate with H, this does not seem to imply that the union ")#mi("A := \\bigcup_{g \\in G} gHg^{-1}")#text(" has good doubling properties (and in any event A could be huge relative to H). The general principle in this theory is that approximate closure by conjugation, by itself, is not enough to get the strongest structural properties; one also needs approximate closure by products as well. (This “product-conjugation” phenomenon comes up in the theory of approximate linear groups, particularly in the work of Helfgott, Pyber-Szabo, and Ben, Emmanuel, and myself, and also (in a somewhat different way) in the work of Larsen and Pink.) But this could be an artificial problem, caused by the limitations of our current methods, rather than by what types of theorems in this area are actually true.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-98690")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2011")])]

#text("Hi Terry –")

#text("Congratulations on a nice result. As should be clear from my remarks in section 1 of ")#link("http://arxiv.org/abs/0807.2027")[#text("http://arxiv.org/abs/0807.2027")]#text(" , my “conjecture” (“It is tempting to guess that…”) involved a rather stronger statement on the rate of growth of sets A. In your terms – in theorem 1, I really hope that, where you have O_K(1), one should have K^O(1).")

#text("Now, it is true that (as Pyber showed, and as again I said in math:0807.2027) this stronger conjecture is not true in the symmetric group or in Lie groups of unbounded rank. Still, I feel that")#linebreak()#text(" (a) one should be able to prove this in all subgroups of SL_n(K), K a field,")#linebreak()#text(" (b) one should be able to prove slightly qualified versions of the K^O(1) statement in greater generality.")

#text("Thus I must say I still regard the conjecture as open. It is my understanding that there are people working on (a).")

#text("What do you think about (b), in full generality? I’ve developed by now some intuition for both linear algebraic groups and permutation groups, but funny things might in principle happen when many groups are put together, for example.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-98773")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2011")])]

#text("I agree that (a) (assuming n bounded, of course) should definitely be true, and should appear at some point (though I am not directly working on this problem). I don’t yet have enough intuition to make a guess about (b), other than to say that the permutation group case needs to be studied much more intensively to see how to obtain polynomially strong positive results in the absence of algebraic group theory (and in particular, without the very convenient maximal tori lying around to cleanly slice up approximate groups). Certainly the methods in this paper completely fail to give polynomial bounds; even ignoring all the ultrafilters, the very first step in the program (using the Sanders lemma) already concedes an exponential in the doubling constant which should not be present (indeed, if one combines (b) with a (presumably true) nilpotent version of Sanders’ Freiman-Bogulybov theorem, this loss should be quasipolynomial at worst). On the other hand, the final part of the argument (involving what we call “strong approximate groups”) is somewhat polynomially quantitative, and it may be able to obtain a version of (b) for strong approximate groups. But we have no idea how to reduce from approximate groups to strong approximate groups without using the whole Hilbert’s 5th problem machinery.")

#text("Another possibility is to replace the doubling, tripling, or approximate group condition by a stronger polynomial growth condition, something like |A^k| \\leq k^{log K} |A|, pushing the problem much closer to the situation of Gromov’s theorem so that geometric group theory techniques become available (e.g. harmonic functions, a la Kleiner). Indeed, this is how Ben and I initially thought that the approximate groups conjecture would be solved (instead, we obtained polynomial growth of (a large chunk of) approximate groups as a corollary of the main theorem, rather than a key component of the proof).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-98789")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2011")])]

#text("I wouldn’t say that maximal tori are exactly what is missing. Rather, what we don’t have in permutation groups yet is any sort of dimensional analysis – how do we stick three copies of a centraliser in different directions, say?")

#text("As you may know, centralisers do play a role in my proof with Akos on permutation groups. (The approximate version of the orbit-stabiliser theorem is valid for any action of any group.) It is just that we were forced to arrange matters so that we obtained a reduction to a trivial centraliser – that is, the centraliser of a set of elements generating a doubly transitive group. (Such a centraliser contains only the identity.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-100121")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2011")])]

#text("I have a question: once you proved theorem 1, import a Carnot-Caratheodory type metric (from the nilpotent group) on the coset nilprogression (it makes sense because the CC metric is intimately related to the generating set of the nilprogression). The question is: does this (quasi)-metric have a meaning in terms of the approximate group?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-100137")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2011")])]

#text("If one gives each generator ")#mi("u_i")#text(" in the coset nilprogression a “norm” of ")#mi("1/N_i")#text(" (and each element in the torsion group H a norm of 0) and uses this to define a weighted word metric (which is a discrete counterpart to the Carnot-Caratheodory metric), then the approximate group A is essentially the unit ball in this metric, and A^m is essentially the ball of radius m. So this metric would play a role in the geometric structure of A^m in the limit ")#mi("m \\to \\infty")#text(".")

#text("But when studying the internal structure of an approximate group A (rather than the growth properties of the iterated product sets ")#mi("A^m")#text("), the weighted word metric is comparable to the naive Euclidean metric (viewing elements of the nilprogression in “exponential coordinates of the second kind” ")#mi("u_1^{n_1} \\ldots u_r^{n_r}")#text(" (assuming that the generators ")#mi("u_1,\\ldots,u_r")#text(" obey a certain technical closure condition with respect to commutators, analogous to that used to define a Malcev basis, see our paper for details), and coordinatising such an element by the r-tuple ")#mi("(n_1/N_1,\\ldots,n_r/N_r)")#text("), or to the metric given by the escape norm. This is analogous to how the Carnot-Caratheodory metric on a Lie group (using a spanning set of vector fields) is comparable to the Riemannian metric at small scales.")

#text("In our arguments, it is the internal structure which is far more important than the asymptotic structure (and this is the main reason why we are able to extend our analysis to the local group case); the asymptotic structure is only obtained as a corollary once the internal structure is understood. It is conceivable that there is another approach to the classification of approximate groups that proceeds via studying the asymptotic structure first; the paper of Green and Ruzsa handling the abelian case is an instance of this, but it relies very much on the abelian fact that for an abelian approximate group A, the iterates A^m grow polynomially in m rather than exponentially. Such a statement is now known to be true in the nonabelian case too (after first passing from A to a dense subset) by means of our structure theorem, but we do not know of a direct way to establish this fact.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-100170")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2011")])]

#text("Thank you for the answer, very interesting! A Gleason metric is a CC metric if and only if the nilpotent group is abelian, because of the commutator estimate.")

#text("Concerning local groups, they are natural objects since Lie. I used them for dilatation structures (or dilation structures) and noticed (very roughly) that they seem strange to westerners and well-known to easterners (but see Olver as counterexample). There was a gap in the proof of one result, where I used for local groups a Siebert result which characterizes connected contractive groups. Glad to see later that Van den Dries and Goldbring paper “Locally compact contractive local groups” arxiv:0909.4565 provides Siebert theorem for local groups.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tou")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-100473")[#strong[#text("tou")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2011")])]

#text("Dear Professor Tao.")#linebreak()#text(" Congratulations for this nice result.Looks like you have completed some major projects of yours. If it is possible, could you say something about your major future plans please?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 9: Applications of the structural theory of approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-104881")[#strong[#text("254A, Notes 9: Applications of the structural theory of approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2011")])]

#text("[…] large, or if is placed in a certain “normal form”, details of which may be found in this paper), a coset nilprogression of rank and step will be an -approximate group, thus giving a partial […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The microstructure of approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-111731")[#strong[#text("254A, Notes 8: The microstructure of approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2011")])]

#text("[…] must be replaced by the local version of this theorem, due to Goldbring); details can be found in this recent paper of Emmanuel Breuillard, Ben Green, and myself, but will only be sketched […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Approximate algebraic structures, emergent algebras | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-114044")[#strong[#text("Approximate algebraic structures, emergent algebras | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2011")])]

#text("[…] algebra can also be seen as an approximate algebraic structure! But in a different sense than approximate groups. The operations themselves are approximately associative, for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A nilpotent Freiman dimension lemma « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-117588")[#strong[#text("A nilpotent Freiman dimension lemma « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2011")])]

#text("[…] remark that our previous paper established a similar result, in which the dimension bound was improved to , but at the cost of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-117595")[#strong[#text("A nilpotent Freiman dimension lemma | t1u")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2011")]

#text("[…] remark that our previous paper established a similar result, in which the dimension bound was improved to , but at the cost of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, addendum: Some notes on nilprogressions « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-133749")[#strong[#text("254A, addendum: Some notes on nilprogressions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2012")])]

#text("[…] groups, and use it to prove the above proposition, which turns out to be a bit tricky. (In my paper with Breuillard and Green, we avoid the need for this proposition by restricting attention to a special type of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec2e562f9e0cbbea8748b9102e416a5f4aa944d2320e2dc55e604dbdd3ede6de-4e7a381651b25620449fcdacefef2f8a03e061a4ca1c3fce8c70010c4e15b92e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mac özeti")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-137326")[#strong[#text("mac özeti")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2012")])]

#text("Thank you for the answer, very interesting! A Gleason metric is a CC metric if and only if the nilpotent group is abelian, because of the commutator estimate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A geometric viewpoint on computation? | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-143717")[#strong[#text("A geometric viewpoint on computation? | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2012")])]

#text("[…] the profound resemblance between geometrical results of Gromov on groups with polynomial growth and combinatorial results of Breuillard, Gree, Tao on approximate groups? In both cases a nilpotent structure emerges from considering larger and larger scales. The word […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Approximate groupoids again « chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-212074")[#strong[#text("Approximate groupoids again « chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2013")])]

#text("[…] Here is the path I would like to pursue further. The notion of approximate groupoid (see here for the definition) is not complete, because it is flattened, i.e. the set of arrows should be seen as a set of variables. What I think is that the correct notion of approximate groupoid is a polynomial functor over groupoids (precisely a specific family of such functors). The category Grpd is cartesian closed, so it has an associated model of (typed) lambda calculus. By using this observation I could apply emergent algebra techniques (under the form of my graphic lambda calculus, which was developed with — and partially funded by – this application in mind) to approximate groupoids and hope to obtain streamlined proofs of Breuillard-Green-Tao type results. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Small doubling in groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-215443")[#strong[#text("Small doubling in groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2013")])]

#text("[…] have Lie structure; this connection was first observed and exploited by Hrushovski, and then used by Breuillard, Green, and myself to obtain the analogue of Freiman’s theorem for an arbitrary nonabelian […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carry propagation-free number systems and a kind of approximate groups (I) | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-225242")[#strong[#text("Carry propagation-free number systems and a kind of approximate groups (I) | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2013")])]

#text("[…] (that’s what qualifies as a kind of an approximate group). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Additive limits | What's new")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-429518")[#strong[#text("Additive limits | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2014")])]

#text("[…] is likely that this theorem can be extended to the noncommutative setting, using the noncommutative Freiman theorem of Emmanuel Breuillard, Ben Green, and myself, but I have not attempted to do so here; in a separate direction, there should be extensions that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Inverse theorems for sets and measures of polynomial growth | What's new")]], [#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/#comment-457048")[#strong[#text("Inverse theorems for sets and measures of polynomial growth | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2015")])]

#text("[…] we gave a fairly explicit quantitative bound on how large needed to be). A little more recently, with Breuillard and Green, the condition was weakened to , that is to say it sufficed to have polynomial relative growth at […]")
]
