// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/06/11/random-matrices-universality-of-local-spectral-statistics-of-non-hermitian-matrices/
// Converted to Typst by tao2typ: "2026-10-14T15:18:26.058010+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Random matrices: Universality of local spectral statistics of non-Hermitian matrices", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Random matrices: Universality of local spectral statistics of non-Hermitian matrices")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 June 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/06/11/random-matrices-universality-of-local-spectral-statistics-of-non-hermitian-matrices/")[#text("https://terrytao.wordpress.com/2012/06/11/random-matrices-universality-of-local-spectral-statistics-of-non-hermitian-matrices/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://users.math.yale.edu/public_html/People/vuha.html")[#text("Van Vu")]#text(" and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1206.1893")[#text("Random matrices: Universality of local spectral statistics of non-Hermitian matrices")]#text("“. The main result of this paper is a “Four Moment Theorem” that establishes universality for local spectral statistics of ")#emph[#text("non-Hermitian")]#text(" matrices with independent entries, under the additional hypotheses that the entries of the matrix decay exponentially, and match moments with either the real or complex gaussian ensemble to fourth order. This is the non-Hermitian analogue of a long string of recent results establishing universality of local statistics in the Hermitian case (as discussed for instance in this ")#link("https://terrytao.wordpress.com/2012/02/02/random-matrices-the-universality-phenomenon-for-wigner-ensembles/")[#text("recent survey of Van and myself")]#text(", and also in several other places).")

#text("The complex case is somewhat easier to describe. Given a (non-Hermitian) random matrix ensemble ")#mi("{M_n}")#text(" of ")#mi("{n \\times n}")#text(" matrices, one can arbitrarily enumerate the (geometric) eigenvalues as ")#mi("{\\lambda_1(M_n),\\ldots,\\lambda_n(M_n) \\in {\\bf C}}")#text(", and one can then define the ")#mi("{k}")#text("-point correlation functions ")#mi("{\\rho^{(k)}_n: {\\bf C}^k \\rightarrow {\\bf R}^+}")#text(" to be the symmetric functions such that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf C}^k} F(z_1,\\ldots,z_k) \\rho^{(k)}_n(z_1,\\ldots,z_k)\\ dz_1 \\ldots dz_k")]]

#align(center)[#tao-fit-display[#mitex("= {\\bf E} \\sum_{1 \\leq i_1 < \\ldots < i_k \\leq n} F(\\lambda_1(M_n),\\ldots,\\lambda_k(M_n)).")]]

#text("In the case when ")#mi("{M_n}")#text(" is drawn from the complex gaussian ensemble, so that all the entries are independent complex gaussians of mean zero and variance one, it is a ")#link("http://www.ams.org/mathscinet-getitem?mr=173726")[#text("classical result of Ginibre")]#text(" that the asymptotics of ")#mi("{\\rho^{(k)}_n}")#text(" near some point ")#mi("{z \\sqrt{n}}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" and ")#mi("{z \\in {\\bf C}}")#text(" is fixed are given by the determinantal rule ")#metadata(none) <tao-f2f8357240f916793bfc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\rho^{(k)}_n(z\\sqrt{n} + w_1,\\ldots,z\\sqrt{n}+w_k) \\rightarrow \\text{det}( K(w_i,w_j) )_{1 \\leq i,j \\leq k}")]]

#text("for ")#tao-math("{\\left|z\\right| < 1}", block: false)#text(" and")

#align(center)[#tao-fit-display[#mitex("\\rho^{(k)}_n(z\\sqrt{n} + w_1,\\ldots,z\\sqrt{n}+w_k) \\rightarrow 0")]]

#text("for ")#tao-math("{\\left|z\\right| > 1}", block: false)#text(", where ")#mi("{K}")#text(" is the reproducing kernel")

#align(center)[#tao-fit-display[#tao-math("K(z,w) := \\frac{1}{\\pi} e^{-\\left|z\\right|^2/2 - \\left|w\\right|^2/2 + z \\overline{w}}.", block: true)]]

#text("(There is also an asymptotic for the boundary case ")#tao-math("{\\left|z\\right|=1}", block: false)#text(", but it is more complicated to state.) In particular, we see that ")#tao-math("{\\rho^{(k)}_n(z \\sqrt{n}) \\rightarrow \\frac{1}{\\pi} 1_{\\left|z\\right| \\leq 1}}", block: false)#text(" for almost every ")#mi("{z}")#text(", which is a manifestation of the well-known ")#emph[#text("circular law")]#text(" for these matrices; but the circular law only captures the macroscopic structure of the spectrum, whereas the asymptotic ")#link(<tao-f2f8357240f916793bfc>)[#text("(1)")]#text(" describes the microscopic structure.")

#text("Our first main result is that the asymptotic ")#link(<tao-f2f8357240f916793bfc>)[#text("(1)")]#text(" for ")#tao-math("{\\left|z\\right|<1}", block: false)#text(" also holds (in the sense of vague convergence) when ")#mi("{M_n}")#text(" is a matrix whose entries are independent with mean zero, variance one, exponentially decaying tails, and which all match moments with the complex gaussian to fourth order. (Actually we prove a stronger result than this which is valid for all bounded ")#mi("{z}")#text(" and has more uniform bounds, but is a bit more technical to state.) An analogous result is also established for real gaussians (but now one has to separate the correlation function into components depending on how many eigenvalues are real and how many are strictly complex; also, the limiting distribution is more complicated, being described by Pfaffians rather than determinants). Among other things, this allows us to partially extend some known results on complex or real gaussian ensembles to more general ensembles. For instance, ")#link("http://www.ams.org/mathscinet-getitem?mr=2095933")[#text("there is a central limit theorem of Rider")]#text(" which establishes a central limit theorem for the number of eigenvalues of a complex gaussian matrix in a mesoscopic disk; from our results, we can extend this central limit theorem to matrices that match the complex gaussian ensemble to fourth order, provided that the disk is small enough (for technical reasons, our error bounds are not strong enough to handle large disks). Similarly, extending some results ")#link("http://www.ams.org/mathscinet-getitem?mr=1231689")[#text("of Edelman-Kostlan-Shub")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2430570")[#text("of Forrester-Nagao")]#text(", we can show that for a matrix matching the real gaussian ensemble to fourth order, the number of real eigenvalues is ")#mi("{\\sqrt{\\frac{2n}{\\pi}} + O(n^{1/2-c})}")#text(" with probability ")#mi("{1-O(n^{-c})}")#text(" for some absolute constant ")#mi("{c>0}")#text(".")

#text("There are several steps involved in the proof. The first step is to apply the ")#emph[#text("Girko Hermitisation trick")]#text(" to replace the problem of understanding the spectrum of a non-Hermitian matrix, with that of understanding the spectrum of various Hermitian matrices. The two identities that realise this trick are, firstly, ")#link("http://en.wikipedia.org/wiki/Jensen's_formula")[#text("Jensen’s formula")]

#tao-aligned(keep: true)[


#tao-math("\\log \\left|\\det(M_n-z_0)\\right|  & = - \\sum_{1 \\leq i \\leq n: \\lambda_i(M_n) \\in B(z_0,r)} \\log \\frac{r}{\\left|\\lambda_i(M_n)-z_0\\right|}", block: true)



#tao-math(" & + \\frac{1}{2\\pi} \\int_0^{2\\pi} \\log \\left|\\det(M_n-z_0-re^{i\\theta})\\right|\\ d\\theta", block: true)
]

#text("that relates the local distribution of eigenvalues to the log-determinants ")#tao-math("{\\log \\left|\\det(M_n-z_0)\\right|}", block: false)#text(", and secondly the elementary identity")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|\\det(M_n - z)\\right| = \\frac{1}{2} \\log\\left|\\det W_{n,z}\\right| + \\frac{1}{2} n \\log n", block: true)]]

#text("that relates the log-determinants of ")#mi("{M_n-z}")#text(" to the log-determinants of the Hermitian matrices")

#align(center)[#tao-fit-display[#mitex("W_{n,z} := \\frac{1}{\\sqrt{n}} \\begin{pmatrix} 0 & M_n -z \\\\ (M_n-z)^* & 0 \\end{pmatrix}.")]]

#text("The main difficulty is then to obtain concentration and universality results for the Hermitian log-determinants ")#tao-math("{\\log\\left|\\det W_{n,z}\\right|}", block: false)#text(". This turns out to be a task that is analogous to the task of obtaining concentration for Wigner matrices (as we did in ")#link("https://terrytao.wordpress.com/2012/01/24/random-matrices-sharp-concentration-of-eigenvalues/")[#text("this recent paper")]#text("), as well as central limit theorems for log-determinants of Wigner matrices (as we did in ")#link("https://terrytao.wordpress.com/2011/11/28/a-central-limit-theorem-for-the-determinant-of-a-wigner-matrix/")[#text("this other recent paper")]#text("). In both of these papers, the main idea was to use the Four Moment Theorem for Wigner matrices (which can now be proven relatively easily by a combination of the local semi-circular law and resolvent swapping methods), combined with (in the latter paper) a central limit theorem for the gaussian unitary ensemble (GUE). This latter task was achieved by using the convenient ")#link("http://www.ams.org/mathscinet-getitem?mr=761763")[#text("Trotter normal form")]#text(" to tridiagonalise a GUE matrix, which has the effect of revealing the determinant of that matrix as the solution to a certain linear stochastic difference equation, and one can analyse the distribution of that solution via such tools as the martingale central limit theorem.")

#text("The matrices ")#mi("{W_{n,z}}")#text(" are somewhat more complicated than Wigner matrices (for instance, the semi-circular law must be replaced by a distorted Marchenko-Pastur law), but the same general strategy works to obtain concentration and universality for their log-determinants. The main new difficulty that arises is that the analogue of the Trotter norm for gaussian random matrices is not tridiagonal, but rather ")#link("http://en.wikipedia.org/wiki/Hessenberg_matrix")[#text("Hessenberg")]#text(" (i.e. upper-triangular except for the lower diagonal). This ultimately has the effect of expressing the relevant determinant as the solution to a ")#emph[#text("nonlinear")]#text(" stochastic difference equation, which is a bit trickier to solve for. Fortunately, it turns out that one only needs good lower bounds on the solution, as one can use the second moment method to upper bound the determinant and hence the log-determinant (following a classical computation of Turan). This simplifies the analysis on the equation somewhat.")

#text("While this result is the first local universality result in the category of random matrices with independent entries, there are still two limitations to the result which one would like to remove. The first is the moment matching hypotheses on the matrix. Very recently, one of the ingredients of our paper, namely the local circular law, was proved without moment matching hypotheses ")#link("http://arxiv.org/abs/1206.1449")[#text("by Bourgade, Yau, and Yin")]#text(" (provided one stays away from the edge of the spectrum); however, as of this time of writing the other main ingredient – the universality of the log-determinant – still requires moment matching. (The standard tool for obtaining universality without moment matching hypotheses is the heat flow method (and more specifically, the local relaxation flow method), but the analogue of Dyson Brownian motion in the non-Hermitian setting appears to be somewhat intractible, being a coupled flow on both the eigenvalues and eigenvectors rather than just on the eigenvalues alone.)")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/06/11/random-matrices-universality-of-local-spectral-statistics-of-non-hermitian-matrices/#comment-147076")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2012")])]

#text("This is quite amazing! I thought it would be decades before one can do that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c74dfdb3015cd87785bfcb8e277286773c67ad27d04f8f8bf0a67f5e100cb470-b16e0d7fe54fc6da98f8ed50c9d2fc2ee0fb2f5ed2e17e6e29d53dab75a4062f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dimensions in Mathematics")]], [#link("https://terrytao.wordpress.com/2012/06/11/random-matrices-universality-of-local-spectral-statistics-of-non-hermitian-matrices/#comment-150914")[#strong[#text("Dimensions in Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2012")])]

#text("I agree. Great research here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d07cb00b06ce6d9090f6f3d86dc7301feab77228c3267e25fe36f3fe4cc63d25-16415a462a3ec6316f23b993ef995526b0f8dd4a986eb150d2f2d341a72dea2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/06/11/random-matrices-universality-of-local-spectral-statistics-of-non-hermitian-matrices/#comment-165707")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2012")])]

#text("I am interested in the long left-tail distribution of the largest eigenvalue of a Wigner matrix. Can one apply similar methods stated in this passage to the study of largest eigenvalue of a Wigner matrix? One application can be calculate the probability of positive definite Wigner matrix.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Local universality of zeroes of random polynomials | What's new")]], [#link("https://terrytao.wordpress.com/2012/06/11/random-matrices-universality-of-local-spectral-statistics-of-non-hermitian-matrices/#comment-238972")[#strong[#text("Local universality of zeroes of random polynomials | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2013")])]

#text("[…] paper “Local universality of zeroes of random polynomials“. This paper is a sequel to our previous work on local universality of eigenvalues of (non-Hermitian) random matrices with inde…. One can re-interpret these previous results as a universality result for a certain type of random […]")
]
