// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/
// Converted to Typst by tao2typ: "2026-10-14T16:38:52.270304+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Climbing the cosmic distance ladder (book announcement)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Climbing the cosmic distance ladder (book announcement)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 October 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/")[#text("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Several years ago, I developed a public lecture on the ")#link("https://en.wikipedia.org/wiki/Cosmic_distance_ladder")[#text("cosmic distance ladder")]#text(" in astronomy from a historical perspective (and emphasising the role of mathematics in building the ladder). I previously blogged about the lecture ")#link("https://terrytao.wordpress.com/2010/10/10/the-cosmic-distance-ladder-ver-4-1/")[#text("here")]#text("; the most recent version of the slides can be found ")#link("https://terrytao.wordpress.com/wp-content/uploads/2020/10/cosmic-distance-ladder.pdf")[#text("here")]#text(". Recently, I have begun working with ")#link("https://medium.com/@Polcamilla")[#text("Tanya Klowden")]#text(" (a long time friend with a background in popular writing on a variety of topics, ")#link("https://medium.com/search?q=klowden%20astronomy")[#text("including astronomy")]#text(") to expand the lecture into a popular science book, with the tentative format being non-technical chapters interspersed with some more mathematical sections to give some technical details. We are still in the middle of the writing process, but we have produced ")#link("https://terrytao.wordpress.com/wp-content/uploads/2020/10/sample_chapter.pdf")[#text("a sample chapter")]#text(" (which deals with what we call the “fourth rung” of the distance ladder – the distances and orbits of the planets – and how the work of Copernicus, Brahe, Kepler and others led to accurate measurements of these orbits, as well as ")#link("https://en.wikipedia.org/wiki/Kepler%27s_laws_of_planetary_motion")[#text("Kepler’s famous laws of planetary motion")]#text("). As always, any feedback on the chapter is welcome. (Due to various pandemic-related uncertainties, we do not have a definite target deadline for when the book will be completed, but presumably this will occur sometime in the next year.)")

#text("The book is currently under contract with Yale University Press. My coauthor Tanya Klowden can be reached at ")#link("mailto:tklowden@gmail.com")[#text("tklowden@gmail.com")]#text(".")

#heading(level: 1)[#text("Comments (56)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/124f2317c08c4d35f23785e647ba4da7ea5b54e91cc0b97f90495f7b029a8950-52e8d46162151a102d40dcda946c298a4443f49577a98fe9dd24447fc7395ac3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zeraoulia Rafik")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594827")[#strong[#text("zeraoulia Rafik")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2020")])]

#text("That is an interesting topic , I have to ask about stars locations , Is there any mathematical law to predict the exact location of starts in the space ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nick kerr")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594828")[#strong[#text("nick kerr")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2020")])]

#text("Awesome! “what what” –> “with what”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594831")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2020")])]

#text("Astronomy (as any physical science) developed from the desire to find mathematical patterns among the accumulated observational data.")#linebreak()#text(" It is possible that there is an ultimate mathematical theory with the potential to explain every possible observational data.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/231ef4d752e87b208e9e89aa8ce71814e0f1f700a99a2b309700c57f1f4dec2a-fde8794cca4343eb2f8b8bd019c4d6bd1211bac3e4597bd9ec6e7174d3e4ba84.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Smart")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594832")[#strong[#text("Robert Smart")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2020")])]

#text("You’d be wise to run your book past the Renaissance Mathematicus (")#link("https://thonyc.wordpress.com/")[#text("https://thonyc.wordpress.com/")]#text("). He’s very strong on how Science is a team effort, not (just) individual geniuses. This is an important message for kids wanting to go into Science. Or you can read his blogs on “The emergence of modern astronomy – a complex mosaic”, currently up to Part XLVI.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594836")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2020")])]

#text("Kindly read Cultural Foundations of Mathematics by C K Raju before writing anything on this topic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594850")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")])]

#text("I don’t believe reading Hindutva propaganda is a valuable endeavor for Mr. Tao. I’m certain his time would be better spent elsewhere.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62ed8bf98a451ca8f856eef31226e33d181d94fa0abb130914a0a8cad46c0b63-40e14a48686b59776e65484355afde69e2f2cfa714bd16f1065d00068632140a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curious")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594838")[#strong[#text("Curious")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2020")])]

#text("On the very first paragraph – the vedas referred to the planets as demons. Any opinion on this? This reference is before the Greek connection to India. The question of precession of equinoxes is claimed to be tabulated long before the greeks ")#link("https://en.wikipedia.org/wiki/Ayan%C4%81%E1%B9%83%C5%9Ba")[#text("https://en.wikipedia.org/wiki/Ayan%C4%81%E1%B9%83%C5%9Ba")]#text(" though for the purpose of astrology not for the purpose of knowing as in the Greek culture. Any evidence certain things could have been known prior to Greeks in different cultures?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4734140d75448931d2959640a0e7d5834d1c1414fc5b39f214d9949a357aad80-0ff663b7a9d5b31683c59ecc76604f878a904846e8af7377c396a77f1191657d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Globules")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594841")[#strong[#text("Globules")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2020")])]

#text("Thanks, this was interesting. Here are a few things I noticed while reading it:")

#raw("\nintroduced to the Plato’s writings  =>  introduced to Plato’s writings\n\nhe found life in Greece following the Council of Ferrara-Florence uncomfortable.\n\n  I had to parse this a couple of times.  How about:\n\n    he found life in Greece uncomfortable, following the Council of Ferrara-Florence.\n\nand at it was at Tübingen  =>  and it was at Tübingen\n\nHe studied under the instruction of the renowned mathematician\n\n  How about just:\n\n    He studied under the renowned mathematician\n\nwithin short order and quickly brought him  =>  within short order, which quickly brought him\n\nand getting them to press himself before Kepler would be able to do so  =>  and getting them to press before Kepler would be able to do so\n\nto give a good approximation the orbit of the Earth  =>  to give a good approximation to the orbit of the Earth\n\nthe velocity of the a planet around the Sun  =>  the velocity of a planet around the Sun\n\nthey make possible them to be only interesting curiosities  =>  they make possible to be only interesting curiosities\n\nin this plane with respect an arbitrarily chosen pair  =>  in this plane with respect to an arbitrarily chosen pair\n\nIn Tychonic model, the Sun  =>  In the Tychonic model, the Sun\n", block: true)

#text("– Globules")

#emph[#text("[Thanks for the corrections! – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594843")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2020")])]

#text("free time around his his professional duties.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1350937afaaa59b7306d2c749bd371b15a0fb9780056f6ad94d359d104117de7-692e2b446acd293011d26af7cdf279c931231319a377eb4e40756e76e7474bce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of uglyowlspotting")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594845")[#strong[#text("uglyowlspotting")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")])]

#text("I read these pages with pleasure. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc5ff249339fccfe6a90f64282930eaaca7b0eb8cbc82bfabf936691c9971742-2b8cbb7eee158dba51104b1ff1b1554848139c9441ee4917aca9c1099b31a961.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Climbing the cosmic distance ladder: Terence Tao book announcement – Hacker News Robot")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594851")[#strong[#text("Climbing the cosmic distance ladder: Terence Tao book announcement – Hacker News Robot")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/")[#text("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6dbbd771747c33fc9d38003065747b146e06c0eeff6a46db3de9f69a91566aa7-0bf39d1a1efe85a56c5f2d7201a77eaff5886f726f5065e03efcf912317398b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Santhosh")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594852")[#strong[#text("Aaron Santhosh")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")])]

#text("Hope it comes out quick… Astronomy always intrests me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d88a9046b284586f6b31d14364660118874f2643df05ebee608979e61f869f2c-7ab6c2cc629856adcc4a735835a26f501486d9fae2fb836e4913251f9fb0bb57.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594858")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")])]

#text("Kepler was lucky the planets of the solar system are well behaved. Not all exoplanets follow Kepler’s laws. See “Non-Keplerian Dynamics” ")#link("https://arxiv.org/abs/1006.3834")[#text("https://arxiv.org/abs/1006.3834")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30ccca0a58f4d4058bbb2a4e1904c77e594eec302a67337822cd914595c4ea52-658c3c60d8ac78b6cf87fb58bf414802a7a5c42fecac9681d00162252e7d7f04.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594864")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")])]

#text("I enjoyed reading the sample chapter. Thank you for writing it. I am looking forward to the book.")

#text("Here is one additional (see Globules comment) small mistake I noticed:")

#text("[…] draw upon our modern heliocentric understanding of the solar system. to more easily picture […] -> comma instead of period")#linebreak()#text(" […] draw upon our modern heliocentric understanding of the solar system, to more easily picture […]")

#emph[#text("[Thanks for the correction – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8070b2fb9df5fa0721a557f1a992156ea62ce7db36cf05b61a245798931d71fd-1468eb39a8288faab32eb3ab4918f5dbf70f828b0da276ee4393864c992c9a77.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594879")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")])]

#text("> Other astronomersand mathematicians quietly mourned his death but it was not until an ambitiousEnglishman named Isaac Newton set about proving Kepler’s principles that theworld began to realize that Kepler had given us something of far more gravitythan even Tycho Brahe’s observational masterpiece.")

#text("Thank you for the chapter, it was a fantastic read. Looking forward to the full publishing of this book!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5a18fec8b170c311bfce72d88abb1d0d9f85afb10e7c2bad5dfef6579818ffc-a765fc2e0cd13dab52c1578c650dd8196939d5e7243ee4192c1d621731d48b5c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meinte37")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594881")[#strong[#text("meinte37")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")])]

#text("More figures (than the 1) would be most welcome!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d08234f97311997ba051bcc1e08e7aef9a7eea7f69a2900d33e6e0a9804e23c-fdb632cf7d7d17b8fcd4d48cded88e8274f7bd70015530c870a11be50cf91bde.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Cohen")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594884")[#strong[#text("Martin Cohen")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")])]

#text("A suggested change:")#linebreak()#text(" ” an ice skater spins faster when pulling her arms closer to her body”")#linebreak()#text(" should be")#linebreak()#text(" “ice skaters spin faster when pulling their arms closer to their body”.")

#emph[#text("[Thanks, we will reword this line. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594900")[#strong[#text("Terry Tao and Climbing the cosmic distance ladder – The nth Root")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")]

#text("[…] Several years ago, I developed a public lecture on the cosmic distance ladder in astronomy from a historical perspective (and emphasising the role of mathematics in building the ladder). I previously blogged about the lecture here; the most recent version of the slides can be found here. Recently, I have begun working with Tanya Klowden (a long time friend with a background in popular writing on a variety of topics, including astronomy) to expand the lecture into a popular science book, with the tentative format being non-technical chapters interspersed with some more mathematical sections to give some technical details. … (What’s new) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b71017f3ba0f543c5044556f27512e72972ffa9e69a8bf9184eadd8f7695b8bf-bea05fabd012afb0eff4e8714fccbbf0a0ed5d4690e1d374727fd01c1f9ac003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Ruxton")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594923")[#strong[#text("Michael Ruxton")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")])]

#text("proof reader-like comments, possibly reported by others")

#text("far beyond what Aristarchus has laid out => far beyond what Aristarchus had laid out")#linebreak()#text(" laboratory on his uncle’s estates at the dissolute Herrevad Abbey => uncle’s estate")#linebreak()#text(" mutual respect and driving curiosity lead to each => led each")#linebreak()#text(" you almost might not realize it growing within you => you almost might")#linebreak()#text(" not realize it is growing within you")#linebreak()#text(" He realized that since this change in velocity was inversely proportional")#linebreak()#text(" to the distance from the Sun, that he should be able to measure => from the Sun, he should be able to measure")#linebreak()#text(" not the only time he nearly invented calculus to solve a problem and the other occasion => to solve a problem, and the")

#emph[#text("[Thanks for the corrections – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b71017f3ba0f543c5044556f27512e72972ffa9e69a8bf9184eadd8f7695b8bf-bea05fabd012afb0eff4e8714fccbbf0a0ed5d4690e1d374727fd01c1f9ac003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Ruxton")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-595000")[#strong[#text("Michael Ruxton")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("the true period (also known as the sidereal period) of Mars is given by => of Mars given by")

#emph[#text("[Thanks for the correction – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594938")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")])]

#text("What a wonderful read! The chestnut metaphor could possibly be supplemented by a little hint to Grothendieck? I like the elliptic cake very much. Great read, thank you for putting it out!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4fccbb46b8fe0277313b098e11e8cfd887ef8b683abfde3cb4d0e08e3c0c92d-3d950d32f0087723dce391e639e3832362dfd2b3eed5e3afe7940b70e0021ea1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hrm oin")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594969")[#strong[#text("hrm oin")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")])]

#text("“Many years later, Alexander Grothendieck was to be born on one of these planets”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594973")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")])]

#text("This is a great idea! A couple of corrections:")

#text("1. On page 25, “It was not until the fifteenth century, however, that a monk")#linebreak()#text(" named Bessarion …” — the word “however” seems misplaced since you are continuing the idea of the previous sentence rather than contradicting it. Maybe “In was indeed not until the fifteenth century that a monk named Bessarion …”")

#text("2. On page 31, you claim that NASA was spending 2% of the US GDP on the Apollo project. But NASA’s total budget has never exceeded 1% of the GDP. See for example the second slide of ")#link("https://www.lpi.usra.edu/exploration/multimedia/NASABudgetHistory.pdf")[#text("this presentation")]#text(".")

#text("The nominal cost of the Apollo program was $25B-$28B (about half of NASA’s total budget during the program), which was indeed roughly 3% of the US GDP at the time, but the spending was spread over many years.")

#text("3. At the very end, when you discuss Kepler’s third law, note that if we know that the acceleration created by the inverse square law does not depend on the mass of the planet, then Kepler’s third law follows from consideration of units: we have a constant of units ")#mi("\\frac{[\\textrm{acceleration}]}{[R^2]}")#text(", and would like to form a timescale from the constant and a length scale.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594974")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")])]

#text("Of course I got the units wrong: the units of the _constant_ are ")#mi("[\\textrm{acceleration}][R^2] = [L]^3[T]^{-2}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-595036")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("Thanks for this! I rechecked my sources and I see the error; the Apollo program at one point reached about 2% of federal outlays, but as you note did not reach 2% of GDP.")

#text("I’ll find some way to make a brief mention of dimensional analysis into the discussion of Kepler’s third law, though it’s hard to present the notion of units in a manner that is both concise and mathematically correct.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-595850")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2020")])]

#text("Dimensional analysis of physical units is very helpful. But it is important to note that such dimensional analysis becomes meaningless for dimensionless(!) “natural units” which are defined by absolute physical constants (e.g. Planck’s units which are used in string theory).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Linton")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594979")[#strong[#text("Chris Linton")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2020")])]

#text("You might be interested in")

#text("in which I have written about the mathematical development of our understanding of the solar system")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-594981")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("P. 28, l. -3: There is overflow into the margin. Therefore, a rewording of the sentence would probably be a good idea.")

#emph[#text("[The final typesetting is likely to be completely different from that in the draft. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13adaff32d54f3bdf4caf53abe3d7d7661f47307b45be7dfe4a21eeb122bc96c-30478c564e1d0b5eb16035de2a3eae50d90ef7462ef80bb9d6ab9ae482bb19a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Radu Zaharopol")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-595425")[#strong[#text("Radu Zaharopol")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2020")])]

#text("Dear Terry,")

#text("I would like to buy the book when it appears. Please keep me posted about the title, when, and where it will appear.")

#text("Yours, Radu")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39675712bb8e68cd858ed69229848c7f16fc5b2727220a10cda0cd5aac376641-30607e521510b9e427ed3017653bf1778b4aa9350896e4edd437862252bd8abb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-595431")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2020")])]

#text("Awesome slides! Are there any similar popular presentations where you or others instead go down the distance ladder to progressively zoom in on compounds, molecules, atoms, protons, quarks, etc.?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e746757fef5ffc61672a0c8e51ba78e567196481cb990119278e951979a5355-db7ff2a6176f0b9c4ea1670b0576d6b53122c41993e9623bbcc2262ab252783d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ion Simbotin")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-595436")[#strong[#text("Ion Simbotin")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2020")])]

#text("The cosmic distance ladder is a fascinating subject and I’m sure your new book will be wonderful. The slides of your talk are definitely satisfying and pass the critical test of giving plenty of credit to Aristarchus; it warms my heart just to see his name mentioned. However, regarding his method for measuring the Earth-Sun distance by making use of the half-moon, with the right angle, etc, it should be remarked that it is rendered useless in practice (despite being a good/correct idea on paper). Sufice it to say that, when the subject was tackled again more seriously after the invention of the telescope, they went straight to using the transit of Venus (instead of the half-moon right-angle idea) for figuring out the distance to the Sun. Unfortunately, it seems that all astronomy textbooks gloss over the nitty-gritty details of this particular idea, which is such a missed opportunity for truly appreciating astronomy with all that entails. In fact, it is quite remarkable (astonishing?) that no amount of technology can make the original idea work (exaggerating slightly to make/force my point). And even if it worked a little better, the Earth-Sun distance would have to rely on the Earth-Moon distance (which remained somewhat shaky/inaccurate for a while). This particular rung (Earth-Moon) is a bit separate and we can bypass it (thankfully) and go straight for the solar system, which is what they did since the 1600s. Modern technology does give us the ability to go back and measure the Earth-Moon distance very precisely, but we don’t rely on this special rung to redo the next rung, and the next, and so on.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/faf5907e93a0671e219db1830637fe07df16be8300106375d2579b6d55e31284-5065c5cd37c418f9be50c7cfb4d6c311e9a9b3b65f8a75ff43b5c34a3669e637.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oliver Knill")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-595509")[#strong[#text("Oliver Knill")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2020")])]

#text("thanks for the chapter, it was a page turner. The Kepler-Brahe drama is also displayed well in the book “Heavenly intrigue” by Joshua and Anne-Lee Gilder. This would make for a great movie. For the chestnut metaphor on page 35, it reminds of “Recoltes de Semailles” of Grothendieck who used the soaking nut picture in comparison to his “rising sea” metaphor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b71017f3ba0f543c5044556f27512e72972ffa9e69a8bf9184eadd8f7695b8bf-bea05fabd012afb0eff4e8714fccbbf0a0ed5d4690e1d374727fd01c1f9ac003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Ruxton")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-595689")[#strong[#text("Michael Ruxton")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2020")])]

#text("Since people are making book recommendations, I read Richard Panek’s book Seeing and Believing a few months ago and thoroughly enjoyed it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd366d60058a5a463c592880db8bcad746981d9cf730e5e200b2aa3963f3eb6a-8cd11ef2cf4d09d96bc08e5ac907ccc87b4f84cbadc84a240767b5f7fbc22aff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Sánchez Terraf")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-595797")[#strong[#text("Pedro Sánchez Terraf")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2020")])]

#text("Dear Terry, I’m half a way in the reading and I’m enjoying it very much.")#linebreak()#text(" I add some questions/comments that might have not been posted before.")

#text("– At the bottom of p.27, should it read “*whose* star”?")#linebreak()#text(" – Footnote on p.30: perhaps a comma right after “own good” would make that long phrase easier on the reader.")#linebreak()#text(" – On p.31, there are 3 occurrences of “lavish” and derivatives; and one more on p.32. Perhaps a synonym would be of service.")

#text("I might be back when I reach the end")

#text("Thank you for sharing this!")

#emph[#text("[Thanks for the corrections and suggestions – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf0926511e042ba2b35f6c785dcb8d42b9d7b711a51094669980f7311e6a7fe-05fb367d18e897cf3d3354cdc13d77eb3cbec5e291e20602a13b2aabfc15cb85.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Giammona")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-596504")[#strong[#text("James Giammona")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2020")])]

#text("This looks like it will be a wonderful book! I’m very excited for it to come out.")

#text("(I also have given lectures on the cosmic distance ladder, Hubble’s law, and the CMB to high school physics classes to help instill the idea that one can ask how scientists came up with the Universe being 13.7 GYa and that stars and galaxies are light years away, and can understand the answers.)")#linebreak()#text(" I had some comments and suggestions for Ch 4. (Also, I’m surprised that this chapter didn’t include the modern base of the cosmic distance ladder, which IIRC comes from timing radio pulses off of Venus.)")

#text("– Is it possible to include an image of the Babylonian cuneiform tablet records?")

#text("– Perhaps you could mention that the 24 hr day, and 60 min in an hour, 60 seconds in a min come from the Babylonians beyond saying “the Babylonian records gave rise to calendar and timekeeping systems so accurate that many elements continue to be used in our systems today.”")

#text("– What time period did Eudoxus live relative to the Babylonians, the same time? Centuries later? Perhaps including (birth-death) dates along with new names would be helpful to contextualize when these developments are occurring. (Although, it seems it was perhaps a deliberate decision to not include them.)")

#text("– I’m glad you mention the connection of epicycles to Fourier series in the mathematical notes at the end. There is a great blog post that first highlighted this connection to me which then makes an analogy with neural networks today: https://wenhaosun.github.io/blog/wenhaosun-blog/2019-12-04-Geocentric-vs-Heliocentric/")

#text("– Perhaps you could include an image or reconstruction of the Antikythera mechanism?")

#text("– Is there more you could say about this bootstrapping method that Kepler used to refine his orbital predictions? Does it now have a name or is it a more standard procedure? Also, perhaps a diagram would be helpful for explaining this procedure and for acquainting new readers with the properties of ellipses.")

#text("– Finally, the discussion of royal patronage for observatories and astrology reminds me of the thesis of the book The Long Space Age by Alexander MacDonald which argues that the Cold War Space Race was preceded by state and private competition to fund larger and more elaborate astronomical observatories. Interesting to see this pattern extended much further back in time!")

#text("Once again, this is overall a fantastic work and I enjoy the pacing, tone, and level of detail. Best of luck!")

#emph[#text("[Thanks for the suggestions! Radio measurements of the planets will be mentioned in the chapter following this one, alongside measurements of the transit of Venus and parallax methods. The Antikythera mechanism more naturally will fit in some earlier chapters that are more focused on the efforts of the ancient Greeks. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c399ce8553ab0189a79fc58e77d07acc1bc8a0dd3a87b51087bbaf8af36f79c3-4136d45621f8e09d08291849616f1dcc9fb4c43a24ce23b32c989009634683bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Math - Update")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-596689")[#strong[#text("Math - Update")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2020")])]

#text("Reblogged this on ")#link("https://iluminacion235matematica.wordpress.com/2020/10/18/climbing-the-cosmic-distance-ladder-book-announcement/")[#text("ILUMINACIÓN MATEMÁTICA")]#text(" and commented:")#linebreak()#text(" Kepler´s Dreams and mines…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a17bceb8b9d537d6fa03b1605c6f58a12e4e9dbab1f74e1733c03706c5ea74d2-9512a9089640b798dc6cd38251e9cd6fd8e8ff6a83dad877f3539c21e63235df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony O'Connor")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-596905")[#strong[#text("Tony O'Connor")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2020")])]

#text("Thank you for posting this fascinating article. A brief comment on the remark that Copernicus was a priest. Owen Gingerich in “Copernicus, a very short introduction” states definitely that Copernicus was a not a priest ( p 2 & 8). Dava Sobel states that only a few of the canons at Frauenberg were ordained as priests. Although a canon these days would very likely be a priest it seems that in medieval Poland they were more like church administrators. There is also a lengthy article by Edward Rosen “Copernicus was not a priest” (Proc American Philosophical Society, vol 104, p 635-661, 1960) which traces the different claims that have been made about Copernicus’s status. He seems to be saying that this claim comes from misunderstandings over the years.")

#emph[#text("[The subsequent discussion in the text emphasizes that Copernicus’s role in the church was indeed as a bureaucrat and expert in")#linebreak()#text(" church law -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1c0877f8b07bd5ab234616528da0cfc48db5055fdaa794a3f6c9db58a9fe72d-13ce79eb6e52b7960f50c39e0e737eec3f61e9609e7b8f5ff38de63153c3d33a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Heinzl")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-597646")[#strong[#text("Tom Heinzl")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2020")])]

#text("Well written and captivating indeed! Some minor comments:")#linebreak()#text(" (i) The plural of focus is foci (not focii, p.38, 1st paragraph, 3 times).")#linebreak()#text(" (ii) Physics Nobelist Steven Weinberg covers similar material in a similar style (focus on history with maths in technical appendices) in his book “To Explain the World”. He also states that “Copernicus never became a priest” (p.147).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a98d20754f8295451c9dca2b4d8a80219f1b9580f5d286eb322856ed7a75dba7-b137dafc8142cb6cf0c739fa5f3d88bfecc35eadabd561b13c690f796bfd9097.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sabino Lamonaca")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-603021")[#strong[#text("Sabino Lamonaca")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2020")])]

#text("Very interesting")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-603091")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2020")])]

#text("Dear Pro Terry,")#linebreak()#text(" Now is november. The weather is very cold.What do you have anything new to “warm” all colleagues on this forum?")#linebreak()#text(" We really thank you first.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ad3a8331bcdc1bbb0c2393348eac563d1390114c4414fd272e325e2390a794f-94a24e071e9ed4d8256ee439289f36609135e3e17509e10c81ba4ddfe8107f05.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roland")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-603341")[#strong[#text("Roland")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2020")])]

#text("“Regiomontanus” is Latin for “the man from Königsberg”, the (Bavarian) place of birth of Johannes Müller. This name was used only after his death the first time by Philipp Melanchthon (ironically, Melanchthon ist Greek for “black earth”, his birthname “Schwartzerdt”), see also ")#link("https://de.wikipedia.org/wiki/Regiomontanus")[#text("https://de.wikipedia.org/wiki/Regiomontanus")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/204b3113a26232586e8b080b306837a23eac3a9f4a984b7fbc419b914af04cc0-28223c551c0a3cfdacd78a8cf2f71b8071f1d5df0ea651d6e9945722e620843a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank De Geeter")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-604430")[#strong[#text("Frank De Geeter")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2020")])]

#text("Thank you for this wonderful treat. It made a very good read, and also had emotional value for me, since most of the stuff that is covered was taught to me by my granddad, more than 50 years ago. He copied (by hand!) several entries on astronomy from an encyclopaedia owned by an uncle of mine. He kindled a lifelong interest in the sciences and mathematics in me. I became a physician and the closest I came to mathematical genius was by attending the lectures on medical physiology by none other than Jean Bourgain’s father (who, incidentally, during one of his lectures declared his son was mad). Anyway, I could be a typical member of the audience that the forthcoming book will target.")

#text("What follows is a list of typo’s that I discovered in the sample text as well as more fundamental remarks on content (mainly things that I did not understand quite well). Forgive me if they already have been signaled – I had no time to read all the responses. P means page, p is the number of the paragraph on a given page, and l the line in that paragraph.")

#text("P22, p1, l12. I was confused by ‘fixed’, since l6 states that the celestial sphere gently rotates.")#linebreak()#text(" P24, p5, l5. ‘but fortunately we can draw’ instead of ‘but we can fortunately draw’")#linebreak()#text(" P24, p5, l6. ‘To’ instead of ‘to’")#linebreak()#text(" P25, p1, l2. ‘orbits the Earth’instead of ‘orbits around the Earth’")#linebreak()#text(" P25, p3, l4. ‘to Plato’s’ instead of ‘to the Plato’s’")#linebreak()#text(" P27, p2, l7. I did not understand why the sidereal period would be very nearly insignificant under the geocentric model. It would be my understanding that the difference between sidereal and synodic periods is insignificant in the geocentric model.")#linebreak()#text(" P28, p3, l8. ‘and it’ instead of ‘and at it’")#linebreak()#text(" P33, p2, l12. No sure that ‘Apogee’ needs a capital letter")#linebreak()#text(" P33, p4, l3. ‘lead each’ instead of ‘lead to each’")#linebreak()#text(" P34, p2, l5. ‘with Kepler not to let all his work’ instead of ‘with Kepler to not let all his work’")#linebreak()#text(" P34, p4, l14. ‘right’ instead of ‘right’?")#linebreak()#text(" P35, p2, l6. ‘to a somewhat’ instead of ‘to somewhat minor’")#linebreak()#text(" P36, p3. Is partly repetitive of the preceding paragraph: the moving vantage point is already discussed there.")#linebreak()#text(" P37, p1. I am still puzzled which are the angles and sides considered in the reasoning. I would presume that the side is between the Sun and Mars, but which angles are used and were known to Kepler. Perhaps this could be further addressed in the mathematical section. Illustrations, such as in your talk, would be enlightening.")#linebreak()#text(" P37, p2, l9-10. ‘angular velocity’ instead of ‘angle of velocity’. ‘the difference in angular velocity between the two planets’ instead of ‘the difference in angle of velocity of the two planets’")#linebreak()#text(" P37, p3, l14. ‘approximation for the’ instead of ‘approximation the’")#linebreak()#text(" P38, p1, l1, l4 and l6. ‘foci’ instead of ‘focii’")#linebreak()#text(" P38, p2, l4. Perhaps better ‘inner part of the ellipse’ instead of ‘center of the ellipse’")#linebreak()#text(" P40, p2, l4. ‘possible to’ instead of ‘possible them to’")#linebreak()#text(" P40, p4, l8. ‘respect to an’ instead of ‘respect an’")#linebreak()#text(" P41, p2. The derivation of E could be easier from its definition; the derivation as given is ‘backwards’ from formula (4.1), whereas that formula itself follows from the definition of angular velocity")#linebreak()#text(" P43, p1, l3. ‘In the Tychonic model’ instead of ‘In Tychonic model’")#linebreak()#text(" P43, p2, 6. I was utterly confused by the ‘uninhabited point’. Of course, I can see that for the mathematical description of a movement, it is immaterial whether or not a rotating point represents a celestial body. But surely, commuting the terms of equation (4.8) cannot make vanish the Sun.")

#emph[#text("[Thanks, these corrections will be incorporated into the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a98d20754f8295451c9dca2b4d8a80219f1b9580f5d286eb322856ed7a75dba7-b137dafc8142cb6cf0c739fa5f3d88bfecc35eadabd561b13c690f796bfd9097.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sabino Lamonaca")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-604548")[#strong[#text("Sabino Lamonaca")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2020")])]

#text("Where will it be possible to buy the book?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-604786")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2020")])]

#text("If the universe can be modelled by compact 4D manifold, the simplest candidates for its topology are S^4 (4D sphere) or RP^4 (the 4D real projective space – which is non-orientable!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-606795")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2020")])]

#text("P.23")#linebreak()#text(" which constellation -> which of them (or, which Zodiacal constellation)?")

#text("“the Moon wobbles through the same ecliptic…”: “wobbles” is a bit vague. Somehow clarify that you’re talking about transverse rather than longitudinal displacements relative to a uniform cycle around the ecliptic.")

#text("“Mostly, the planets moved in an east to west direction along the ecliptic, but occasionally they would slow and reverse direction, moving west to east in retrograde motion for a while before resuming their east to west travel again.”: I think “east” and “west” need to be swapped here (as a check: a solar day is longer than a sidereal day because from noon to noon, Earth has to rotate eastward about 360+1 degrees relative to the fixed stars to “catch up” with the one-degree *eastward* apparent movement of the Sun over the previous day. And the planets’ dominant direction relative to the fixed stars is the same as that of the Sun).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-606850")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2020")])]

#text("P.24:")#linebreak()#text(" own number of spheres -> own set of spheres?")

#text("“Aristotle went on to make further modifications, primarily adding “unrolling” spheres to cancel out the motion of an inner sphere from impacting the next one out”:")#linebreak()#text(" Per ")#link("https://www.mpiwg-berlin.mpg.de/Preprints/P289.PDF")[#text("Aristotle’s unwinding spheres")]#text(" the unrolling spheres were just a means to enable all planets’ spheres to be connected in one big system. If you still think them worth mentioning, you might want to do so in an aside, something like:")#linebreak()#text(" “Aristotle went on to make further modifications, primarily integrating all of the planets’ spheres into a single connected system (this involved adding “unrolling” spheres to cancel the motions of the spheres carrying each planet so that the motion of the next planet would be unaffected by that of the previous planet).“")

#text("Last line: system. to more -> system to more")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0af7321c0fbc98e22a4e051a64754a5a575c7abd834b82069ff7b4835296d704-915ac645f728ba696c6e75ab9450cf526ede80d99928d6c6ac4664dcca172686.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Someone who doesn't know")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-607554")[#strong[#text("Someone who doesn't know")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2020")])]

#text("Hello World. This is really a great article. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-607678")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2020")])]

#text("P. 25:")#linebreak()#text(" para 2: using extensive use of epicycles -> making extensive use of epicycles")#linebreak()#text(" para 2: a major shift -> the next major shift?")#linebreak()#text(" para 3: There were several unlikely things that -> Several unlikely things")#linebreak()#text(" P. 26:")#linebreak()#text(" para 3: only published one other book in his lifetime -> only published one book other than De revolutionibus (about which more below) in his lifetime [Kepler’s major work hadn’t yet been mentioned]")#linebreak()#text(" P.27:")#linebreak()#text(" para 1, “He did, of course, write out his heliocentric model…”: Assumes the reader knows what a heliocentric model is, and that Copernicus had developed one. Will those points be covered in earlier chapters, and if not, are these safe assumptions?")#linebreak()#text(" para 1: better refine -> refine")#linebreak()#text(" para 2, “[synodic period] is simply the amount of time it takes for a planet to return to the same place in the sky.”: I don’t think this is right. Synodic period of a planet is the time between successive conjunctions or successive oppositions of that planet relative to the Earth and Sun. The planet will in general not be in the same place in the sky as viewed from Earth at those two times.")

#text("I’ll stop here as I feel I may be overly flooding your comments section. Thanks for the great and enjoyable read!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/097a4d5133f182db0e69d4c8b545f1e04ffe71834194bb0c5514993838312913-be24c73e8383858c44fd3f54eca00b77b675548c40c6fb0e21384600734295e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YahyaAA1")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-607793")[#strong[#text("YahyaAA1")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2020")])]

#text("An informative read – thanks!")

#text("Brief comments: Some sentences are too complex to parse easily. You might simplify them by separating the ideas they connect into separate sentences. Perhaps with another sentence to make the connection!")

#text("On page 27, the definitions of the sidereal and synodic periods don’t clarify the difference between the two. As a test, could a naïve reader use these definitions to say which is longer?")

#text("On page 28, you could simplify “If you have ever taken a basic physics class, you will have learned …” to “If you ever take a basic physics class, you will learn …”?")

#text("Page 39 has this: “… his thoughtful and detailed consideration")#linebreak()#text(" on these subjects _calls back to_ his excitement over the Platonic solids …”, where perhaps “… _recalls_ …” would read better.")

#text("Some minutiae: Other commenters have probably caught all the typos I found, but I didn’t see these mentioned:")#linebreak()#text(" Page 37, “to give a good approximation the | orbit …” seems to need an “of” before “the | orbit …”.")#linebreak()#text(" Page 38: “the velocity of the a | planet …” has a superfluous “the”.")#linebreak()#text(" Page 40 has an extra “them” in the sentence: “Most other astronomers, even his good friend Galileo Galilei, regarded the three laws and the mathematical model of our solar system they make possible them to be only interesting curiosities about the heavens.”")

#text("I look forward to the eventual publication of your book.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1f9cbd7d075d2e43dcef45f25eeb7b13c9466e3d6fa00f809c14227cba8d169-5366d2d96fc198e9cf1db92531bb01bf7a27fab8d571c96db437bf281d0e6882.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Somers")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-622764")[#strong[#text("James Somers")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2021")])]

#text("If anyone here is interested, a group of us have crowdsourced a few dynamic illustrations for this chapter over at ")#link("https://observablehq.com/@jsomers/we-need-more-tiny-knowledge-projects-heres-one")[#text("https://observablehq.com/@jsomers/we-need-more-tiny-knowledge-projects-heres-one")]#text(".")

#text("The illustrations attempt to give a flavor for what it would be like to contemplate the night sky as Kepler once did—showing the peculiar motion of the “wandering stars” against the rest of the night sky.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3eb1589aa0c2727d1e1d0c79b70b25882a84d8bddcc508f9dff0b97dd18420f-e94e85f65cb8bfeefc73c4f36c1fa2baf9609830283e1ac69e3c8387f7974400.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor Kleptsyn")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-638175")[#strong[#text("Victor Kleptsyn")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2021")])]

#text("Thank you very much for these slides!")

#text("I have one question concerning Aristarchus’ “step to the Moon”. Namely, there are two ways to determine the size of Earth’s umbra at the Moon’s orbit:")#linebreak()#text(" – by measuring the time the Moon can stay inside the shadow (the one you mention in your talk)")#linebreak()#text(" – by looking at the Earth’s shadow on the Moon when the Moon is _partially_ covered by it and comparing the apparent radii of the Moon and of the shadow; that’s what’s mentioned here (sorry for a reference in Russian) : ")#link("https://elementy.ru/nauchno-populyarnaya_biblioteka/431102/Geometriya_zvezdnogo_neba")[#text("https://elementy.ru/nauchno-populyarnaya_biblioteka/431102/Geometriya_zvezdnogo_neba")]#text(" .")

#text("The first one is easier to be measured with better precision, but requires a history of observations (to find the longest eclipse). The second one could be done with just one eclipse, so Aristarchus definitely could do it himself, but is difficult technically (radius 2R and radius 3R circle traces are not that much different, though one can imagine some kind of a “measuring device” to distinguish between these).")

#text("Is there any reference to how Aristarchus have measured this quotient? I have tried to check his “On the Sizes and Distances of the Sun and Moon”, but unless I have missed something, he starts with declaring this quotient as one of six hypothesis at the very beginning, namely, as his hypothesis 5: “Size of the shadow is twice the size of the moon” (e.g., in a French translation here — ")#link("https://gallica.bnf.fr/ark:/12148/bpt6k62820h/f9.item.texteImage")[#text("https://gallica.bnf.fr/ark:/12148/bpt6k62820h/f9.item.texteImage")]#text(" ). And I didn’t find any discussion on that afterwards…")

#text("Again, thank you very much!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-638414")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2021")])]

#text("This appears to be an educated guess; Heath’s ” Aristarchus of Samos, the Ancient Copernicus” on ")#link("https://archive.org/details/aristarchusofsam00heat/page/329/mode/2up")[#text("page 329")]#text(" attributes this reconstruction to page 225 of Tannery’s “Recherches sur l’histoire de l’astronomie ancienne”, but I unfortunately do not have access to this latter manuscript.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-643420")[#strong[#text("Philosophy of science and the blockchain: A book review – Windows On Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2022")]

#text("[…] (The right graph is adapted from Terry Tao’s excellent cosmic distance ladder presentation; I was happy to hear Tao is planning to turn it into a popular science book.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-644081")[#strong[#text("A book review – Windows On Theory |")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2022")]

#text("[…] (The right graph is adapted from Terry Tao’s excellent cosmic distance ladder presentation; I was happy to hear Tao is planning to turn it into a popular science book.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Climbing the cosmic distance ladder: launching an instagram | What's new")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-686509")[#strong[#text("Climbing the cosmic distance ladder: launching an instagram | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2024")])]

#text("[…] found to be a far richer story than what I was aware of when I first gave those lectures. We had previously released a sample chapter on this blog back in 2020. The project had stalled for a few years for a number of reasons (including some […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Climbing the cosmic distance ladder: another sample chapter | What's new")]], [#link("https://terrytao.wordpress.com/2020/10/10/climbing-the-cosmic-distance-ladder-book-announcement/#comment-689112")[#strong[#text("Climbing the cosmic distance ladder: another sample chapter | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2025")])]

#text("[…] years ago, I announced a popular science book project with Tanya Klowden on the cosmic distance ladder, in which we […]")
]
