// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/
// Converted to Typst by tao2typ: "2026-10-14T15:17:03.223368+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A reading seminar on density Hales-Jewett", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A reading seminar on density Hales-Jewett")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 February 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/")[#text("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("As part of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("polymath1 project")]#text(", I would like to set up a reading seminar on this blog for the following three papers and notes:")

#enum(start: 1, 
[#text("H. Furstenberg, Y. Katznelson, “")#link("http://math.stanford.edu/~katznel/hj43.pdf")[#text("A density version of the Hales-Jewett theorem for k=3")]#text("“, Graph Theory and Combinatorics (Cambridge, 1988). Discrete Math. 75 (1989), no. 1-3, 227–241.")],
[#text("R. McCutcheon, “")#link("http://www.msci.memphis.edu/~randall/preprints/HJk3.pdf")[#text("The conclusion of the proof of the density Hales-Jewett theorem for k=3")]#text("“, unpublished.")],
[#text("H. Furstenberg, Y. Katznelson, “")#link("http://math.stanford.edu/~katznel/dhj12.pdf")[#text("A density version of the Hales-Jewett theorem")]#text("“, J. Anal. Math. 57 (1991), 64–119.")]
)

#text("As I understand it, paper #1 begins the proof of DHJ(3) (the k=3 version of density Hales-Jewett), but the proof is not quite complete, and the notes in #2 completes the proof using ideas from both paper #1 and paper #3. Paper #3, of course, does DHJ(k) for all k. For the purposes of the polymath1 project, though, I think it would be best if we focus exclusively on k=3.")

#text("While this seminar is of course related in content to the main discussion threads in the polymath1 project, I envision this to be a more sedate affair, in which we go slowly through various sections of various papers, asking questions of each other along the way, and presenting various bits and pieces of the proof. The papers require a certain technical background in ergodic theory in order to understand, but my hope is that if enough other people (in particular, combinatorialists) ask questions here (and “naive” or “silly” questions are ")#emph[#text("strongly")]#text(" encouraged) then we should be able to make a fair amount of the arguments here accessible. I also hope that some ergodic theorists who have been intending to read these papers already, but didn’t get around to it, will join with reading the papers with me.")

#text("This is the first time I am trying something like this, and so we shall be using the carefully thought out protocol known as “making things up as we go along”. My initial plan is to start understanding the “big picture” (in particular, to outline the general strategy of proof), while also slowly going through the key stages of that proof in something resembling a linear order. But I imagine that the focus may change as the seminar progresses.")

#text("I’ll start the ball rolling with some initial impressions of paper #1 in the comments below. As with other threads in this project, I would like all comments to come with a number and title, starting with 600 and then incrementing (the numbers 1-599 being reserved by other threads in this project).")

#heading(level: 1)[#text("Comments (38)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35702")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("600. Initial impressions of paper #1")

#text("Paper #1 outlines a proof of DHJ(3): given any ")#mi("\\delta > 0")#text(", that any subset A of ")#mi("{}[3]^n = \\{0,1,2\\}^n")#text(" of density at least ")#mi("\\delta")#text(" contains a combinatorial line if n is sufficiently large depending on ")#mi("\\delta")#text(". (The paper refers to combinatorial lines as “HJ sequences”, and ")#mi("{}[3]^n")#text(" as ")#mi("\\Omega_n")#text(", but I am translating to be more compatible with the notation already used in other threads.) It proceeds by first reducing the problem to one concerning a family of measurable sets on a probability space, indexed by words, and for which there is a family of (non-commuting!) measure-preserving transformations relating these sets to each other. This reduction is performed in Proposition 3.1.")

#text("A key point in this reduction is that a certain “stationarity” property is obtained on this family of sets. To obtain this stationarity, one needs a version of the Carlson-Simpson theorem, which seems to be an infinitary strengthening of the colouring Hales-Jewett theorem. (It looks vaguely reminiscent of Hindman’s theorem; presumably there is a relation.)")

#text("With the above reductions, the game is now to show that a certain triple intersection of three sets has positive measure (Theorem B). This is not actually done in paper #1, but is covered in #2 or #3. In #1, the simpler (but still non-trivial) result is shown that all pairwise intersections of the three sets can simultaneously have positive measure (Theorem 4.1). (It would be interesting to see what the combinatorial analogue of this weaker statement is. Getting just one of the pairs to have positive measure sounds similar to the “DHJ(2.5)” I formulated in ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1853")[#text("my comment 130")]#text(", which turns out to be equivalent to DHJ(2) and thus an easy consequence of Sperner’s theorem.)")

#text("The proof of Theorem 4.1 is established from some soft functional analysis results about IP-systems of unitary operators in Section 5.")

#text("In Section 6, there is a discussion of what is needed to establish the full strength of Theorem B, and I guess this is completed in #2.")

#text("My initial plan is to go to Section 3 and start understanding the equivalence between the combinatorial problem and the ergodic theory one. There seems to be several stages to this equivalence; a relatively easy correspondence between a combinatorial problem and an ergodic problem without stationarity, and then the reduction to the stationary case which requires the Carlson-Simpson type theorems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35708")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("601. Proposition 3.1")

#text("Proposition 3.1 of paper #1 equates the combinatorial statement DHJ(3) with various more ergodic-flavoured versions of the same statement. There are three main statements in this equivalence, (a), (b), and (c). (There are also minor variants (a*), (b*), (c*) of (a), (b), and (c), but I think we won’t need to focus on them too much.)")

#text("DHJ(3)(a) is the combinatorial version of DHJ(3), i.e. for any ")#mi("\\delta > 0")#text(" and for n sufficiently large depending on ")#mi("\\delta")#text(", every subset of ")#mi("{}[3]^n")#text(" of density at least ")#mi("\\delta")#text(" contains a combinatorial line.")

#text("DHJ(3)(b) is a preliminary ergodic version of DHJ(3). Define a ")#emph[#mi("{}[3]^n")#text("-system")]#text(" to be a collection of subsets ")#mi("(E_w)_{w \\in [3]^n}")#text(" in some probability space ")#mi("(X, {\\mathcal X}, \\mu)")#text(", indexed by strings in ")#mi("{}[3]^n")#text(".")

#strong[#text("DHJ(3)(b)")]#text(": If ")#mi("\\delta > 0")#text(" and n is sufficiently large depending on ")#mi("\\delta")#text(", and ")#mi("(E_w)_{w \\in [3]^n}")#text(" is a ")#mi("{}[3]^n")#text("-system with all sets ")#mi("E_x")#text(" having measure ")#mi("\\mu(E_w)")#text(" greater than or equal to ")#mi("\\delta")#text(", then there exists a combinatorial line ")#mi("w^0, w^1, w^2")#text(" such that ")#mi("E_{w^0} \\cap E_{w^1} \\cap E_{w^2} \\neq \\emptyset")#text(".)")

#text("This can be stated in a probabilistic language: if A is a ")#emph[#text("random")]#text(" subset of ")#mi("{}[3]^n")#text(" with the property that each element w of ")#mi("{}[3]^n")#text(" belongs to A with probability at least ")#mi("\\delta")#text(", then with positive probability, A contains a combinatorial line. (Indeed, just take A to be the set of those ")#mi("w \\in [3]^n")#text(" for which ")#mi("E_w")#text(" holds.)")

#text("To deduce DHJ(3)(b) from DHJ(3)(a), observe from linearity of expectation that the expected density of A is at least ")#mi("\\delta")#text(", and so A has density at least ")#mi("\\delta/2")#text(" (say) with positive probability.")

#text("To deduce DHJ(3)(a) from DHJ(3)(b), one can use random averaging arguments (as discussed for instance in ")#link("http://gowers.wordpress.com/2009/02/08/dhj-quasirandomness-and-obstructions-to-uniformity/#comment-2120")[#text("comment 460")]#text("). [Paper #1 uses a somewhat different derivation of this implication which I will skip here.] To recap that argument briefly: we pick a medium integer m between 1 and n, and pick a random m-dimensional subspace inside ")#mi("{}[3]^n")#text(". Pulling back the dense subset A of ")#mi("{}[3]^n")#text(" to ")#mi("{}[3]^m")#text(", we get a random subset A’ of ")#mi("{}[3]^m")#text(" with each point lying in A’ with probability at least ")#mi("\\delta/2")#text(" (say), if n is large enough depending on m. The claim then follows.")

#text("DHJ(3)(c) is DHJ(3)(b) with an additional stationarity hypothesis thrown in, and will be discussed subsequently.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35714")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("602.")

#text("Dear Terry,")

#text("I think it’s a very interesting idea to have an online reading seminar. Of course, it requires us to do the reading, which is quite a big investment to make, and presumably why you envisage a sedate affair. I think what would be most useful to me is basically what you encourage: rather than reading the paper very carefully and then explaining bits I understand here, I would prefer to try to use this post and its associated comments to read the paper sloppily and present my very partial understanding, or even complete misunderstanding, in the hope that others will be able to say, “Yes, you’re getting there — what you need to grasp next is this,” or “No, that’s not quite it — if that were the case then so would this be but it clearly isn’t,” and things like that. So when I get a moment, I’ll try to skim-read Randall’s paper and give some kind of initial reaction to it. I haven’t yet looked at it at all, but my eventual aim would be to obtain some kind of non-ergodic understanding of the proof. (Here I mean non-ergodic in the shallow sense of trying to explain things without getting completely into the ergodic language, rather than in the deep sense of genuinely doing without ergodic theory.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zugzwang trebuchet")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35716")[#strong[#text("zugzwang trebuchet")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("603.")

#text("Hi gowers,")#linebreak()#text(" Why not work out the ergodic details here?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35724")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("604.")

#text("I’m going to try to restate proposition 3.1 to see if I understand it. If I get it right, this will probably be redundant with commment 601 above, but if I get it wrong, it will be one of those naive quesitons Terry asked for.")

#text("Prop. 3.1 says that six things are equivalent, called (a), (a*), (b), (b*), (c) and (c*). In each case, the unstarred version is a uniform variant on the starred version. So the starred version will say “If we have a sequence ")#mi("A_n")#text(" where lim sup (some measure of the size of ")#mi("A_n")#text(")")#mi(">0")#text(" then…” while the unstarred version will say “For every ")#mi("\\epsilon >0")#text(", there is an integer ")#mi("N")#text(" such that, if ")#mi("n>N")#text(" and (some measure of the size of ")#mi("A_n")#text(") ")#mi("> \\epsilon")#text(" then…”.")

#text("We’re going to concentrate on the unstarred versions.")

#text("(a) is what we’re trying to prove. For every ")#mi("\\epsilon")#text(", there is an ")#mi("N")#text(" such that any subset of ")#mi("{}[3]^N")#text(" of cardinatliy more that ")#mi("\\epsilon 3^N")#text(" contains a combinatorial line.")

#text("(b) says that we can’t break (a) by a random construction. Suppose we had some random process, like drawing ping pong balls out of a bag. The set of balls is called ")#mi("X")#text(", and the probaility that an individual ball ")#mi("x \\in X")#text(" is drawn will be ")#mi("\\mu(x)")#text(". For each ball ")#mi("x")#text(", our process produces a particular subset of ")#mi("{}[3]^n")#text(", which I will denote ")#mi("A(x)")#text(". Confusingly (to me), H and K use the opposite indexing; for each ")#mi("w \\in [3]^N")#text(", they write ")#mi("B_{w}")#text(" for the set of all ")#mi("x")#text(" such that ")#mi("w \\in A(x)")#text(", but they don’t have a notation for ")#mi("A(x)")#text(".")

#text("For fixed ")#mi("\\epsilon")#text(", if ")#mi("N")#text(" is large enough, the following holds: is long as the probability of any particular element ")#mi("w")#text(" of ")#mi("{}[3]^N")#text(" being in ")#mi("A(x)")#text(" is at least ")#mi("\\epsilon")#text(", then there will be some particular combiantorial line which occurs in ")#mi("A(x)")#text(" with nonzero probablity.")

#text("Some comments:")

#text("Notice that (b)’s framework is general enough to destroy any probabilistic construction I might attempt. In particular, there is no hypothesis that the events “")#mi("w_1")#text(" is in ")#mi("A(x)")#text("” and “")#mi("w_2")#text(" is in ")#mi("A(x)")#text("” are independent in any way.")

#text("The only kind of probabilistic construction I could imagine which would violate the hypotheses of (a) is a process which, although they produce sets of density ")#mi("\\geq \\epsilon")#text(", have much lower probability of including certain particular elements of ")#mi("{}[3]^N")#text(". However, the problem is so symmetric that I see no reason that this would help. Presumably, the proof of (b)–>(a) is to make this idea rigorous.")

#text("Finally, I described things above with a finite collection of ping pong balls, each with a positive probability. H and K phrase things in terms of a general measure space. I assume this generality will be helpful, although it seems pointless so far.")

#text("Whew, that’s long! I’ll save condition (c) for later, asI need to get going now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35735")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("605.")

#text("Dear Tim: Well, I don’t really have an organised plan as to where this will go, but I would like to get as many contributions (from as many backgrounds) as possible, to take full advantage of ")#link("http://en.wikipedia.org/wiki/Metcalfe%27s_law")[#text("Metcalfe’s law")]#text(". So if some people read slowly and carefully, others comment loosely and freely, and yet others translate from ergodic theory to combinatorics or back, I think that will be an instructive mix. (One advantage of an internet-based seminar, as opposed to a physical one, is that one can have multiple concurrent discussions on different aspects of a paper without too much confusion.)")

#text("Incidentally, the McCutcheon notes rely heavily on paper #1, so I think it is best to start with that paper first, though it may still be valuable to skim through #2 at this preliminary stage nevertheless.")

#text("Dear David: Welcome! I’m glad you took the initiative to jump in (there is no roster or anything for this seminar :-). Please don’t worry about redundancy – in fact, I think the more perspectives we have on an individual component of the argument, the better.")

#text("Regarding the implication of (b) from (a), I can give you a simpler version of it, in which we are not looking for combinatorial lines in ")#mi("{}[3]^n")#text(", but rather algebraic lines ")#mi("(x,x+r,x+2r)")#text(" in ")#mi("{}({\\Bbb Z}/3{\\Bbb Z})^n")#text("; the analogue of DHJ(3) here is called “Roth’s theorem in ")#mi("({\\Bbb Z}/3{\\Bbb Z})^n")#text("“. Given a (deterministic) set A in ")#mi("({\\Bbb Z}/3{\\Bbb Z})^n")#text(" of density at least ")#mi("\\delta")#text(", we can define a random set A(x) in ")#mi("({\\Bbb Z}/3{\\Bbb Z})^n")#text(" by setting ")#mi("A(x) := A+x")#text(" where x is a random element of ")#mi("({\\Bbb Z}/3{\\Bbb Z})^n")#text(". Note that each element w of ")#mi("({\\Bbb Z}/3{\\Bbb Z})^n")#text(" will lie in A(x) with probability at least ")#mi("\\delta")#text(", and if A(x) contains an algebraic line with positive probability, then A certainly contains an algebraic line also. So in this case the deduction of (a) from (b) is pretty simple.")

#text("This doesn’t work in the DHJ setting because combinatorial lines are not translation invariant, but one can do a somewhat different trick, embedding ")#mi("{}[3]^m")#text(" randomly in ")#mi("{}[3]^n")#text(" in a combinatorial line-preserving manner, rather than by translating ")#mi("{}[3]^n")#text(" randomly back to ")#mi("{}[3]^n")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35738")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("606. Stationarity")

#text("In Proposition 3.1(b), the ")#mi("{}[3]^n")#text("-system ")#mi("(E_w)_{w \\in [3]^n}")#text(" (which is called ")#mi("(B_w)_{w \\in \\Omega_n}")#text(" in the notation of #1, and is equivalent to the notion of a random subset A(x) of ")#mi("{}[3]^n")#text(" as discussed in Speyer.604), has no structure other than having every set ")#mi("E_w")#text(" be large. But the deepest part of Proposition 3.1 is a reduction to a special type of ")#mi("{}[3]^n")#text("-system, namely a ")#emph[#text("stationary")]#text(" ")#mi("{}[3]^n")#text("-system. This is a system where the sets ")#mi("E_w \\subset X")#text(" take the form")

#mi("E_{w} = U_w^{-1} E_\\emptyset")#text(", (1)")

#text("where")

#mi("U_{w_1 \\ldots w_n} := U_1^{w_1} U_2^{w_2} \\ldots U_n^{w_n}")#text(", (2)")

#mi("E_\\emptyset \\subset X")#text(" is a set, and the ")#mi("U_i^j: X \\to X")#text(" for ")#mi("1 \\leq i \\leq n")#text(" and ")#mi("j=0,1,2")#text(" are measure-preserving invertible transformations on X. [These transformations are ")#emph[#text("not")]#text(" assumed to commute with each other, and this is apparently a significant technical difficulty in the rest of the argument.]")

#text("Clearly, if (1) holds, and ")#mi("E_\\emptyset")#text(" has measure at least ")#mi("\\delta")#text(", then all the ")#mi("E_w")#text(" have measure at least ")#mi("\\delta")#text(". So DHJ(3)(b) certainly implies")

#strong[#text("DHJ(3)(c):")]#text(" If ")#mi("\\delta > 0")#text(" and n is sufficiently large depending on ")#mi("\\delta")#text(", and ")#mi("(E_w)_{w \\in [3]^n}")#text(" is a stationary ")#mi("{}[3]^n")#text("-system with ")#mi("E_\\emptyset")#text(" having measure at least ")#mi("\\delta")#text(", then there exists a combinatorial line ")#mi("(w^0, w^1, w^2)")#text(" such that ")#mi("E_{w^0} \\cap E_{w^1} \\cap E_{w^2}")#text(" has positive measure.")

#text("The non-trivial fact is that DHJ(3)(c) also implies DHJ(3)(b). I guess I’ll try to discuss that in future comments.")

#text("It is tempting to try to describe stationarity in terms of a measure-preserving action on X by the free group ")#mi("F_3")#text(" on three generators ")#mi("e^0, e^1, e^2")#text(", but this isn’t quite right, because the ")#mi("U_i^j")#text(" are not constant in i. But if one adds a discrete time variable i, thus replacing X with ")#mi("{\\Bbb Z} \\times X")#text(", then one can recover a measure-preserving action ")#mi("(T_g: {\\Bbb Z} \\times X \\to {\\Bbb Z} \\times X)_{g \\in F_3}")#text(" of ")#mi("F_3")#text(", with each generator ")#mi("e^j")#text(", ")#mi("j=0,1,2")#text(" of ")#mi("F_3")#text(" mapping ")#mi("(i,x)")#text(" to ")#mi("(i-1, U_i^j x)")#text(" for ")#mi("i \\in {\\Bbb Z}")#text(" and ")#mi("x \\in X")#text(" (here we have to define ")#mi("U_i^j")#text(" for non-positive i in some arbitrary fashion, e.g. setting these transformations to be the identity). With this action, and embedding ")#mi("{}[3]^n")#text(" inside ")#mi("F_3")#text(" by identifying a string ")#mi("w_1 \\ldots w_n")#text(" with the group element ")#mi("e^{w_1} \\ldots e^{w_n}")#text(", one can rewrite (1), (2) as")

#mi("\\{n\\} \\times E_w = T_w^{-1} ( \\{0\\} \\times E_\\emptyset )")#text(" (3)")

#text("and so the task is to show that there exists a combinatorial line ")#mi("(w^0, w^1, w^2)")#text(" such that")

#mi("T_{w^0}^{-1} ( \\{0\\} \\times E_\\emptyset ) \\cap T_{w^1}^{-1} ( \\{0\\} \\times E_\\emptyset ) \\cap T_{w^2}^{-1} ( \\{0\\} \\times E_\\emptyset ) \\neq \\emptyset")#text(". (4)")

#text("At this stage I do not know whether this group action perspective is useful, although it does make the problem look a little bit like simpler ergodic recurrence theorems. For instance, Roth’s theorem is equivalent to the assertion that if T acts in a measure-preserving way on a probability space X, then for every set E of positive measure, there exists an arithmetic progression ")#mi("(w^0, w^1, w^2)")#text(" of integers such that")

#mi("(T^{w^0})^{-1}(E) \\cap (T^{w^1})^{-1}(E) \\cap (T^{w^2})^{-1}(E) \\neq \\emptyset")#text(". (5)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35741")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("I would be interested in this seminar. I have downloaded the three papers and will be looking at them in the next few days along with the comments here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35742")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("607. Stationarity cont.")

#text("Welcome, Kristal! Feel free to jump in and contribute with any questions, comments, or suggestions, even if (or especially if) they overlap with those already in this post.")

#text("One small comment, continuing 606: it appears that the stationarity gives quite strong constraints on the ")#mi("E_w")#text(". Most obviously, they are all forced to have the same measure, but there are other constraints too. For instance, if n=2, then ")#mi("E_{00} \\cap E_{10}")#text(" has to have the same measure as ")#mi("E_{02} \\cap E_{12}")#text(", since the latter set can be obtained from the former set by applying the measure-preserving ")#mi("(U_2^2)^{-1} U_2^0")#text(". To put it another way, the random set ")#mi("A(x) \\subset [3]^2")#text(" is just as likely to contain the pair (0,0), (1,0) as it is to contain the pair (0,2), (1,2).")

#text("More generally, stationarity seems to be saying that if one looks at a slice ")#mi("A(x) \\cap ([3]^{n-m} \\times \\{ w_{n-m+1} \\ldots w_n \\})")#text(" of ")#mi("A(x)")#text(" formed by freezing the last m positions of A(x), that the distribution of that slice (or more precisely, the identification of that slice with a subset of ")#mi("{}[3]^{n-m}")#text(") is in fact independent of the choice of the frozen coordinates")#linebreak()#text(" ")#mi("w_{n-m+1},\\ldots,w_n")#text(". (This would explain the terminology “stationary”.) I do not know yet whether this property already captures the full strength of stationarity, or whether stationarity in fact says something more.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35744")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("608. Symmetry breaking")

#text("I wanted to repeat a remark of ")#link("http://gowers.wordpress.com/2009/02/01/a-combinatorial-approach-to-density-hales-jewett/#comment-1729")[#text("Austin.54")]#text(" here: the original formulation DHJ(3)(a) of the problem, together with its probabilistic variant DHJ(3)(b), are invariant under permutation of the indices in [n], but the notion of stationarity is not invariant (being dependent on the ordering of the indices), and so DHJ(3)(c) has “broken” the permutation symmetry. There is nothing particularly harmful about this – the standard proofs of colouring Hales-Jewett also break symmetry, for instance – but it seems like a noteworthy point nonetheless.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35752")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("609: My first dumb question: In (b) and (c), would it add any generality to allow the measure space ")#mi("X")#text(" to depend on ")#mi("n")#text("? When I think of sampling methods I might use, it seems natural to me to use different sample spaces ")#mi("X_n")#text(" for different ")#mi("n")#text(". But I suspect that I could use ")#mi("\\prod_{n=1}^{\\infty} X_n")#text(" as my sample space, and thus reduce to H and K’s set up.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ac37fbdbbdae869cfb50c097ed6b4abe0013fff31895b0aef6a8388c5fee6fd-e421180bd8bbc33c3a8a125452f672f2ae6447b797315717878e0edf7d8e07f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Randall")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35757")[#strong[#text("Randall")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("610: Fixed some typos I found on an airplane today and put a better version up. The most potentially confusing of these were in Lemma 1 (continued), the first display on page 4 and in the definition of \\delta on page 6. There may be others so please speak up if you see anything that looks incongruous.")

#text("The notion of stationarity is more familiar for (linear) processes. If (X_i) are random variables taking values say in {a,b,…,z}, then we call (X_i) a process and we say that the process is stationary if the probability that X_1X_2X_3=”cat” is the same as the probability that X_17X_18X_19=”cat” (for all cats and all shifts).")

#text("In the current setup, you can view the sets B_w as random variables X_w taking values in {0,1}. Stationarity says: take any finite set of words. Call that set I. The probability of seeing a certain pattern of 0s and 1s in the random variables X_w, w in I, is exactly the same as the probability of seeing the same pattern of 0s and 1s in the random variables X_wv, w in I, where v is any word. Here “v” plays the role 16 did in the cat example, the pattern of 0s and 1s plays the role of “cat”, and I plays the role of {1,2,3}.")

#text("I can certainly sympathize with the sentiment that it seems quite unclear what 3.1 can possibly do to help. It gives you some measure preserving transformations, but nothing resembling honest ergodic theory, really, because although there are measure preserving transformations around, they don’t even constitute an action (as Terry pointed out). I guess the thing to do at this early stage is just have faith….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35758")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("611: the measure space X")

#text("David, I think you’re right, the actual choice of space X is more or less irrelevant. In a lot of these problems one can take the Cantor space ")#mi("\\{0,1\\}^{\\Bbb Z}")#text(" (or the unit interval) as a universal space (note that any countably generated probability space can be lifted up to either of these two spaces).")

#text("One of the philosophies of probability theory, by the way, is to try to hide the underlying space X as much as possible; thus one talks about events E and their probabilities, random variables and their expectations and correlations, etc. without explicit mention of the probability space and probability measure, etc. It’s like studying a manifold or variety through its ring of functions rather than by looking at its constituent points. It has the advantage that one can concatenate any number of random processes together (e.g. flip infinitely many coins, and then pull balls out of urns infinitely often, etc.) without having to think about what happens to the underlying probability space.")

#text("In ergodic theory, though, one often takes almost the opposite view: one starts with an abstract measure space X (with some groups acting on it) and then creates some factors Y of that space which often have a very explicit algebraic structure (e.g. they are the homogeneous space for some Lie group). One then studies the geometry and dynamics of that space Y from a very concrete point of view, thus moving from the category of abstract measure spaces and measure preserving transformations to something much more algebraic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35770")[#strong[#text("DHJ — possible proof strategies « Gowers’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")]

#text("[…] is his comment 460, which again is responded to by other comments. Terry has also begun an online reading seminar on the Furstenberg-Katznelson proof, using not just the original paper of Furstenberg and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35789")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("612. Hindman’s theorem is a special case of one of their versions of the Carlson-Simpson theorem according to the paper.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35800")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("613. Stationarity II")

#text("DHJ(3)(c) finds combinatorial lines in stationary ")#mi("{}[3]^n")#text("-systems ")#mi("(U_w^{-1} E)_{w \\in [3]^n}")#text(". It turns out to be convenient to eliminate the role of n, and instead work with stationary ")#mi("{}[3]^\\omega")#text("-systems ")#mi("(U_w^{-1} E)_{w \\in [3]^\\omega}")#text(", where ")#mi("{}[3]^\\omega := \\bigcup_{n=0}^\\infty [3]^n")#text(" is the space of all words of finite length with alphabet {0,1,2}. (Paper #1 uses the notation ")#mi("\\Omega^f")#text(" for ")#mi("{}[3]^\\omega")#text(".) It is clear that DHJ(3)(c) implies")

#strong[#text("DHJ(3)(c*)")]#text(": If ")#mi("(U_w^{-1} E)_{w \\in [3]^\\omega}")#text(" is a stationary ")#mi("{}[3]^\\omega")#text("-system, with E having positive measure, then there is a combinatorial line ")#mi("(w^0,w^1,w^2)")#text(" such that ")#mi("U_{w^0}^{-1} E \\cap U_{w^1}^{-1} E \\cap U_{w^2}^{-1} E \\neq \\emptyset")#text(".")

#text("In a similar spirit, DHJ(3)(b) is easily seen to be equivalent to")

#strong[#text("DHJ(3)(b*)")]#text(": If ")#mi("(E_w)_{w \\in [3]^\\omega}")#text(" is a ")#mi("{}[3]^\\omega")#text("-system, with the ")#mi("E_w")#text(" having measure uniformly bounded away from zero, then there is a combinatorial line ")#mi("(w^0,w^1,w^2)")#text(" such that ")#mi("E_{w^0} \\cap E_{w^1} \\cap E_{w^2} \\neq \\emptyset")#text(".")

#text("To finish the proof of Proposition 3.1, we need to deduce DHJ(3)(b*) from DHJ(3)(c*). Broadly speaking, the idea is to start with a ")#mi("{}[3]^\\omega")#text("-system and repeatedly use Carlson-Simpson-type Ramsey theorems to pass to subsystems in which become increasingly stationary.")

#text("A ")#mi("{}[3]^\\omega")#text("-system can be viewed as a collection of random sets ")#mi("A_n(x) \\subset [3]^n")#text(", one for each n. As noted already in 610, stationarity implies that ")#mi("A_n(x) \\times \\{v\\}")#text(" has the same distribution as ")#mi("A_{n+m}(x) \\cap ([3]^n \\times \\{v\\})")#text(" for all n and all words ")#mi("v \\in [3]^m")#text(", where of course we identify ")#mi("{}[3]^{n+m}")#text(" with ")#mi("{}[3]^n \\times [3]^m")#text(" in the obvious manner.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35801")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("614. A possible simplification")

#text("It appears to me that one can in fact get stationarity for free (and avoid invoking the Carlson-Simpson theorem here). The basic observation is that when one deduces DHJ(3)(b) from DHJ(3)(a) by using a random m-dimensional subspace inside ")#mi("{}[3]^n")#text(", the random set obtained in this fashion already is essentially stationary by construction. I’ll write up the details on the wiki and report back here when I’m done.")

#text("(This does not completely eliminate the need for Carlson-Simpson, though, as such results are also used later in the paper.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb1d8446676d949e89097cf27329a580ed6d562bd0686aec6dcdd6045bdef0d8-73b22f07ca53ff4748ee5f4f9e1a982399d30a09e97c405260463d0b8d5de987.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan O'Donnell")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35812")[#strong[#text("Ryan O'Donnell")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("615. Let me try to recap Terry’s points, passing from DHJ(3)(a) to DHJ(3)(c), in my own language.")

#text("Let ")#mi("A \\subseteq \\{0,1,2\\}^n")#text(" be a given set of density ")#mi("\\delta")#text(".")

#text("Let ")#mi("m = m(\\delta, n)")#text(" be some moderate integer; perhaps ")#mi("n^{1/3}")#text(" when ")#mi("\\delta")#text(" is a “constant”.")

#text("Let ")#mi("S \\subseteq [n]")#text(" be a random subset of cardinality ")#mi("m")#text(". Imagine choosing a “random restriction” ")#mi("x")#text(" to the coordinates ")#mi("\\overline{S} = [n] \\setminus S")#text(". I.e., ")#mi("x \\in \\{0,1,2\\}^{\\overline{S}}")#text(" is chosen uniformly at random.")

#text("Then ")#mi("A")#text(" induces a probability distribution on subsets of ")#mi("\\{0,1,2\\}^S")#text(". Call the induced subset ")#mi("A_x \\subseteq \\{0,1,2\\}^S")#text(".")

#text("Let ")#mi("y")#text(" denote a string in ")#mi("\\{0,1,2\\}^S")#text(". I will use the notation “")#mi("(x,y)")#text("” for the string in ")#mi("\\{0,1,2\\}^n")#text(" gotten by appropriately piecing ")#mi("x")#text(" and ")#mi("y")#text(" together.")

#text("We claim that for *each* string ")#mi("y \\in \\{0,1,2\\}^S")#text(", the probability (over choice of ")#mi("x")#text(") that ")#mi("y \\in A_x")#text(" is at least ")#mi("\\delta/2")#text(". On one hand, note that ")#mi("(x,y)")#text(" is *not* a uniformly distributed string in ")#mi("\\{0,1,2\\}^n")#text(". For example, if ")#mi("y")#text(" is the all-0’s string, then the distribution on ")#mi("(x,y)")#text(" is slightly biased towards those strings with more 0’s.")

#text("Still if ")#mi("m")#text(" is “small enough” then the distribution will be very close to uniform (except around the “extreme slices” of ")#mi("\\{0,1,2\\}^{n}")#text(", but ")#mi("A")#text(" has almost all its density outside these slices anyway). And this should prove the claim with a minimum of calculations.")

#text("At this point we’re at DHJ(3)(b); on to DHJ(3)(c). “Stationarity” here would seem to be that for any further restriction ")#mi("z")#text(" to coordinates ")#mi("S^{\\prime} \\subseteq S")#text(", the resulting distribution on the set ")#mi("A_{(x,z)}")#text(" (a subset of ")#mi("\\{0,1,2\\}^{S \\setminus S^{\\prime}}")#text(") is the same.")

#text("Again, this is not true, but it should be “almost” true. And it seems like we’re only going for “almost stationarity”, not “stationarity” anyway.")

#text("In fact, it seems to me that whereas “(almost) stationarity” importantly involves an *ordering* on the coordinates ")#mi("S")#text(", it seems this argument doesn’t really. I.e., ")#mi("S^{\\prime}")#text(" need not be a “suffix” of ")#mi("S")#text(" or anything.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35816")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("616.")

#text("Thanks Ryan, this fleshes out what I was trying to say.")

#text("I’ve started a running “combinatorial translation” of paper #1 on the wiki at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Furstenberg-Katznelson_argument")[#text("http://michaelnielsen.org/polymath1/index.php?title=Furstenberg-Katznelson_argument")]

#text("It’s likely to evolve in unstable ways over time (in particular, I am likely to overhaul the notation as I understand more of the big picture) but hopefully will eventually settle down.")

#text("As you note, the random sampling construction gives additional stationarity properties beyond those used in Paper #1. In particular, the random sets ")#mi("A_m \\subset [3]^m")#text(" are also stationary wrt permutations of the index set [m]. It’s not clear whether this additional symmetry could be useful though (it might even be harmful, because later parts of the proof may need to break this symmetry and so trying to hold on to it may be counterproductive).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35817")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("617. Recap")

#text("I’m now going to try to recapitulate the previous discussion in light of the new simplification, thus moving away from the presentation in Paper #1. (I guess I am changing the rules a little bit here from a “reading seminar” to a “revisionist seminar”, but I said that the rules would be made up as we went along. :-) ) I will try to keep the wiki page above current with the latest revision of thinking.")

#text("Let ")#mi("A^{(n)}")#text(" be a dense line-free subset of ")#mi("[3]^n")#text(", where n is very large. For every small integer m, we can then form a random line-free subset ")#mi("A^{(n)}_m \\subset [3]^m")#text(" by randomly embedding ")#mi("[3]^m")#text(" inside ")#mi("[3]^n")#text(" (by picking m random positions for the wildcards, and then picking the frozen positions randomly), and then pulling ")#mi("A^{(n)}")#text(" back by this map. One can think of ")#mi("A^{(n)}_m")#text(" as a random variable taking values in the power set ")#mi("X_m := 2^{[3]^m}")#text(", so its probability distribution is a probability measure ")#mi("\\mu^{(n)}_m")#text(" on ")#mi("X_m")#text(".")

#text("By construction, ")#mi("A^{(n)}_m")#text(" is stationary with respect to the permutation group ")#mi("S_m")#text(" of [m], i.e. ")#mi("(X_m,\\mu^{(n)}_m)")#text(" is invariant wrt the action of ")#mi("S_m")#text(". Also, for any word ")#mi("w \\in [3]^r")#text(", the ")#emph[#text("slicing map")]#text(" ")#mi("U_{m+r}^w: X_{m+r} \\to X_m")#text(" defined by")

#mi("U_{m+r}^w(A_{m+r}) := \\{ v \\in [3]^m: vw \\in A_{m+r} \\}")

#text("is ")#emph[#text("almost stationary")]#text(" in the sense that for fixed m, r, and w, the random variables ")#mi("A^{(n)}_m")#text(" and ")#mi("U_{m+r}^w(A^{(n)}_{m+r})")#text(" have asymptotically the same distribution in the limit ")#mi("n \\to \\infty")#text(".")

#text("Taking a subsequence limit as ")#mi("n \\to \\infty")#text(" (and using the Helly selection principle, a.k.a. the vague sequential compactness of probability measures), we can then find random line-free sets ")#mi("A_m \\subset [3]^m")#text(" (or equivalently, a probability measure ")#mi("\\mu_m")#text(" on ")#mi("X_m")#text(") which is stationary with respect to the permutation groups ")#mi("S_m")#text(" acting on ")#mi("X_m")#text(", and also with respect to the slicing maps ")#mi("U_{m+r}^w: X_{m+r} \\to X_m")#text(". Also, if the ")#mi("A^{(n)}")#text(" all have density at least ")#mi("\\delta")#text(", then so do the ")#mi("A_m")#text(": in particular, ")#mi("A_0")#text(" will be non-empty with probability at least ")#mi("\\delta")#text(", which implies that for any ")#mi("v \\in [3]^m")#text(", that ")#mi("v\\in A_m")#text(" with probability at least ")#mi("\\delta")#text(" also.")

#text("This is all very well and good, but there is one minor technical problem which will cause difficulty in later parts of paper #1: the slicing maps ")#mi("U_{m+r}^w: X_{m+r} \\to X_m")#text(" are not invertible. We would like to upgrade them to be invertible (thus upgrading the semigroupoid of transformations ")#mi("U_{m+r}^w")#text(" to a groupoid), thus giving us DHJ(3)(c*) in its full strength. This can be done, but requires extending the measure spaces ")#mi("X_m")#text(" a bit (or, in probabilistic language, adding a whole bunch of “dice” or “random number generators”). I plan to talk about this in a later comment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35821")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("618. Inversion of maps")

#text("There is a simple lemma that says that any finite probability-preserving surjective map can be inverted if one throws in a random number generator that draws uniformly from [0,1]. More precisely:")

#strong[#text("Lemma")]#text(" Let ")#mi("U: X \\to Y")#text(" be a surjective map from one finite probability space to another which preserves the probability measure (in the sense that U pushes the probability measure on X forward to the probability measure on Y). Then one can lift this map to an ")#emph[#text("invertible")]#text(" measure-preserving map ")#mi("\\tilde U: X \\times[0,1] \\to Y \\times[0,1]")#text(", with product measure.")

#text("I prove this lemma in the wiki notes, but let’s just illustrate this with the simplest example: the non-injective map from the two-element space {a,b} (with probability 1/2 of each) to the one-element space {c}. One invertible lift of this map is the map ")#mi("\\tilde U: \\{a,b\\} \\times [0,1] \\to \\{c\\} \\times [0,1]")#text(" which maps (a,t) to (c,t/2) and (b,t) to (c,(t+1)/2). Many other choices are possible; this lift is not unique.")

#text("Applying this lift to all of the generators ")#mi("U_{m+1}^0, U_{m+1}^1, U_{m+1}^2: X_{m+1} \\to X_m")#text(", we can now find probability spaces ")#mi("\\tilde X_m := X_m \\times [0,1]")#text(" and invertible measure-preserving maps ")#mi("\\tilde U_{m+1}^i: \\tilde X_{m+1} \\to \\tilde X_m")#text(" that commute with the slicing maps ")#mi("U_{m+1}^i: X_{m+1} \\to X_m")#text(". Concatenating these maps then give us more invertible measure-preserving maps ")#mi("\\tilde U_{m+r}^w: \\tilde X_{m+r} \\to \\tilde X_m")#text(" for all words w of length r. We are now basically in the situation of DHJ(3)(c*), which the rest of Paper #1 aims to prove. (It’s slightly different because we’ve “graded” the underlying probability space X, replacing it with a sequence ")#mi("X_m")#text(" of probability spaces, but I don’t think this will make much of a difference.)")

#text("[Remark: the lemma here is my interpretation of Lemma 3.2 in Paper #1; the statement there is false as stated, but can be repaired by throwing in the [0,1] as is done above.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35824")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("619.")

#text("A frivolous comment, for the combinatorially minded: the Lemma in 618 is in some sense a continuous version of (a special case of) Hall’s marriage theorem, and serves much the same purpose (viz. conjuring up a bunch of artificial but useful perfect matchings out of thin air).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb1d8446676d949e89097cf27329a580ed6d562bd0686aec6dcdd6045bdef0d8-73b22f07ca53ff4748ee5f4f9e1a982399d30a09e97c405260463d0b8d5de987.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan O'Donnell")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35825")[#strong[#text("Ryan O'Donnell")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("620. Inversion of maps.")

#text("I’m getting slightly lost in notation and also slightly lost because I don’t quite know where this is going. However it seems to me that we might not eventually need a completely general Lemma like the one in Terry.618. Some natural randomized-inverse map might work in our context; e.g., tack on a random substring from ")#mi("{}[3]^r")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35827")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("621. Inversion of maps")

#text("Sorry about the notation shifting – I also don’t fully know where we are going either, and this I think is reflected in the notation…")

#text("We’re not inverting a map from ")#mi("[3]^{m+r}")#text(" to ")#mi("[3]^m")#text(", but rather a map from ")#mi("2^{[3]^{m+r}}")#text(" to ")#mi("2^{[3]^m}")#text(" (which, I guess, is induced by an embedding of ")#mi("[3]^m")#text(" in ")#mi("[3]^{m+r}")#text("). Given a word w of length r, and a set ")#mi("A_{m+r} \\subset [3]^{m+r}")#text(", we have the slice ")#mi("U_{m+r}^w(A_{m+r}) \\subset [3]^m")#text(", defined as")

#mi("U_{m+r}^w(A_{m+r}) := \\{ x \\in A_m: xw \\in A_{m+r} \\}")#text(".")

#text("Stationarity tells us that if we take the random set ")#mi("A_{m+r} \\subset [3]^{m+r}")#text(" and look at a slice ")#mi("U_{m+r}^w(A_{m+r})")#text(" of it (think of w as fixed), one gets back something with the same distribution as the random set ")#mi("A_m \\subset [3]^m")#text(". But one cannot initially invert this procedure: starting with the random set ")#mi("A_m \\subset [3]^m")#text(", one cannot ")#emph[#text("deterministically")]#text(" lift it back to a set in ")#mi("[3]^{m+r}")#text(" that has the same distribution as ")#mi("A_{m+r}")#text(" (and which agrees with to ")#mi("A_m")#text(" on the slice) – there is not enough entropy in the domain and too much in the range. But one can do this once one has a random number generator, which I am modeling by a uniform distribution on [0,1] – this gives us an infinite amount of entropy on both sides and removes the obstruction to invertibility, as per “Hilbert’s hotel”. (One has to take care that one only performs “reversible computations” in order to maintain invertibility, but this is a minor technical detail.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb1d8446676d949e89097cf27329a580ed6d562bd0686aec6dcdd6045bdef0d8-73b22f07ca53ff4748ee5f4f9e1a982399d30a09e97c405260463d0b8d5de987.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan O'Donnell")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35837")[#strong[#text("Ryan O'Donnell")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("622. Understood, I’m just thinking that since we got to ")#mi("{}[3]^m")#text(" in the first place by making a large random restriction, perhaps we can “remember” this and “unrestrict” ")#mi("r")#text(" coordinates later. Just guessing… I’m probably being too speculative right now. Best to see where the next parts of the arguments go.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35846")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("623. Oh, that’s an interesting idea. The artificial nature of the transformations used in the Furstenberg-Katznelson argument bothered me a bit, and this would be a much more natural way to do it. I don’t quite see how to set it up so that everything is completely reversible (i.e. the relevant maps ")#mi("U_{m+r}^w")#text(" are invertible), so that entropy is neither created nor destroyed, but I can imagine that it is possible.")

#text("I’ve read a little further into the paper (an interesting experiment, reading a paper collaboratively a small fragment at a time). With the above revisionist notation, we now have a sequence ")#mi("(X_m,\\mu_m)")#text(" of probability spaces and invertible measure-preserving maps ")#mi("U_{m+r}^w: X_{m+r} \\to X_m")#text(" for all words w, obeying a semigroup law. The claim is now that for every set ")#mi("E \\subset X_0")#text(" of positive measure, that there exists a combinatorial line ")#mi("w^0,w^1,w^2")#text(" in some cube ")#mi("[3]^n")#text(" for some n such that the triple intersection of ")#mi("(U_n^{w^0})^{-1}(E)")#text(", ")#mi("(U_n^{w^1})^{-1}(E)")#text(", and ")#mi("(U_n^{w^2})^{-1}(E)")#text(" has positive measure (or equivalently, that the random set ")#mi("A_n \\subset [3]^n")#text(" contains the line ")#mi("w^0,w^1,w^2")#text(" with positive probability).")

#text("In Paper #1, a somewhat weaker result is proven, namely there exists a line ")#mi("w^0, w^1, w^2")#text(", such that the three ")#emph[#text("pairwise")]#text(" intersections of ")#mi("(U_n^{w^0})^{-1}(E)")#text(", ")#mi("(U_n^{w^1})^{-1}(E)")#text(", and ")#mi("(U_n^{w^2})^{-1}(E)")#text(" have positive measure (thus the random set ")#mi("A_n")#text(" will contain any two of the points on this line with positive probability). The notes in #2 finish the job to get all three points on the line. This weaker statement is already not obvious to me combinatorially – it’s some sort of triple version of the DHJ(2.5) statement we discussed back around 130 or so. (I think it is asserting the existence of a positive r for any dense ")#mi("A \\subset [3]^n")#text(" with r wildcards such that for each ij=01,12,20, there exists a combinatorial line which intersects A in the i and j position.) I think I’ll ask it at the 500 thread to see if anyone can come up with a combinatorial proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35873")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")])]

#text("624. Compactification of the string space")

#text("I’ve scanned through the rest of the paper, and it seems like one has no choice but to start understanding the statement of the Carlson-Simpson theorem (and its variants) before progressing much further, although one can at least take these statements as “black boxes”. This theorem is an infinite-dimensional version of the colouring Hales-Jewett theorem, but to state it properly, we need some notation.")

#text("I’m using ")#mi("[3]^n := \\{0,1,2\\}^n")#text(" for the strings of length n, and ")#mi("[3]^\\omega := \\bigcup_{n=1}^\\infty")#text(" for the finite length strings.")

#text("We can give ")#mi("[3]^\\omega")#text(" a “3-adic” metric by defining the distance between two distinct strings x, y (possibly of different length) to be ")#mi("d(x,y) := 3^{-l}")#text(", where l is the first digit at which x and y differ (or terminate).")

#text("The metric space ")#mi("[3]^\\omega")#text(" is totally bounded but incomplete. One can complete it by attaching the space ")#mi("[3]^\\infty")#text(" of infinite strings. The space ")#mi("[3]^\\omega \\cup [3]^\\infty")#text(" is totally bounded and complete, with ")#mi("[3]^\\omega")#text(" as a dense subspace, thus ")#mi("[3]^\\omega \\cup [3]^\\infty")#text(" is a compactification of ")#mi("[3]^\\omega")#text(". (Roughly, one can think of ")#mi("[3]^\\omega")#text(" as being like the terminating decimals base 3 in ")#mi("[0,1]")#text(", and ")#mi("[3]^\\omega \\cup [3]^\\infty")#text(" as being like the entire interval ")#mi("[0,1]")#text(".)")

#text("[Paper #1 uses ")#mi("\\Omega_n, \\Omega^f, \\Omega")#text(" in place of ")#mi("[3]^n, [3]^\\omega, [3]^\\infty")#text(".]")

#text("Let X be a compact metric space. Observe that a map ")#mi("F: [3]^\\omega \\to X")#text(" is uniformly continuous if and only if it extends to a continuous map ")#mi("F: [3]^\\omega \\cup [3]^\\infty \\to X")#text(". One can think of a uniformly continuous F as an operation that takes a string as input and spits out a point in X as output, but is increasingly insensitive to fluctuations in the ")#mi("n^{th}")#text(" and higher digits as ")#mi("n \\to \\infty")#text(".")

#text("Of course, not every map on ")#mi("[3]^{\\omega}")#text(" is continuous. (A good example of a discontinuous map: the map ")#mi("F: [3]^{\\omega} \\to \\{0,1\\}")#text(" that counts the parity of the number of 1s in the string.) But the Carlson-Simpson theorem is an assertion that every map F from ")#mi("[3]^\\omega")#text(" to a compact set (or a finite set) becomes uniformly continuous when restricted to an “infinite-dimensional combinatorial subspace”. This allows one to extend F at some key points ")#mi("\\omega")#text(" of ")#mi("[3]^\\infty")#text(". The proof is going to proceed by taking the shift maps ")#mi("\\tilde U^{w^i}_r")#text(" (viewed as unitary operators) and taking a suitable limit (in the weak operator topology) as ")#mi("w^i \\to \\omega")#text(" and working with the limiting operators (which turn out to be orthogonal projections). I don’t know yet why this is going to be a useful thing to do.")

#text("In a subsequent comment I will state the Carlson-Simpson theorem properly, both in the finite colouring version (which is the standard formulation) and in the compact version (which is the version preferred by paper #1).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb1d8446676d949e89097cf27329a580ed6d562bd0686aec6dcdd6045bdef0d8-73b22f07ca53ff4748ee5f4f9e1a982399d30a09e97c405260463d0b8d5de987.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan O'Donnell")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35918")[#strong[#text("Ryan O'Donnell")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("625. In the analysis of boolean functions there is general intuition of continuous/measurable functions vs. discontinuous/nonmeasurable functions. Roughly, the former are those functions which are “asymptotically noise stable” (in the sense of Benjamini-Kalai-Schramm: ")#link("http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.48.2927")[#text("http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.48.2927")]#text(" ) or have “analogue” functions on Gaussian space or the sphere. I wonder if this viewpoint will be helpful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35921")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("626. Colouring theorems I: finitary theorems")

#text("In this post and the next I want to describe a square of four Ramsey theorems: two finitary theorems, and two infinitary theorems. It is the latter which is used in Paper #1.")

#text("The first finitary theorem is the ")#strong[#text("colouring Hales-Jewett theorem")]#text(". The k=3 version of this theorem asserts that if [3]^n is partitioned into c colour classes, and n is sufficiently large depending on c, then one of the colour classes contains a combinatorial line.")

#text("Iterating this theorem, we conclude that [3]^n is partitioned into c colour classes, and n is sufficiently large depending on c, m, then one of the colour classes contains an m-dimensional combinatorial subspace.")

#text("The second finitary theorem is the ")#strong[#text("Graham-Rothschild theorem")]#text(". The k=3 version of this theorem asserts that if, instead of colouring the vertices of [3]^n as in Hales-Jewett, one colours the ")#emph[#text("combinatorial lines")]#text(" in [3]^n, partitioning the space of all such lines into c colours, then (if n is sufficiently large depending on c, m) one can find an m-dimensional combinatorial subspace in which all lines in that space have the same colour.")

#text("Recall that a combinatorial line can be viewed as a string of 0s, 1s, 2s, and a wildcard *, with the wildcard appearing at least once (e.g. 01*2* is a combinatorial line). Identifying the wildcard with the symbol 3, we can thus view a combinatorial line as a point in ")#mi("[4]^n")#text(" containing at least one 4. Thus one can rephrase the k=3 Graham-Rothschild theorem in another way:")

#strong[#text("Graham-Rothschild theorem")]#text(". If the vertices of [4]^n are partitioned into c colour classes, then (if n is sufficiently large depending on m, c) there is an m-dimensional subspace (with none of the fixed coordinates equal to 3) such that all points in this subspace (with at least one coordinate equal to 3) have the same colour.")

#text("Written this way, Graham-Rothschild looks a lot like colouring Hales-Jewett, and it is in fact possible to deduce the latter from the former (the precise deduction escapes me right now, though).")

#text("The k=1 version of the Graham-Rothschild theorem implies Folkman’s theorem: if the positive integers are finitely coloured, then for any m, one can find m positive integers such that all finite sums of those integers (other than the trivial sum 0) have the same colour. This can be shown by considering the colouring on ")#mi("[2]^n \\backslash \\{0\\}")#text(" that colours a vertex by the colour given to the number of 1s on that vertex.")

#text("In the next comment I describe the infinitary strengthenings of the colouring Hales-Jewett and the Graham-Rothschild theorems, which are the Carlson-Simpson theorem and Carlson’s theorem respectively.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35923")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("627. Colouring theorems II. Infinitary theorems")

#text("The infinitary strengthening of the Hales-Jewett theorem is the Carlson-Simpson theorem. To define it, I need some notation. Define an ")#emph[#text("infinite-dimensional combinatorial subspace")]#text(" of ")#mi("[3]^\\omega")#text(" to be an object indexed by an infinite string of 0s, 1s, 2s, and an infinite number of wildcards ")#mi("*_1, *_2, *_3, \\ldots")#text(", where each wildcard ")#mi("*_i")#text(" appears in a non-empty consecutive block ")#mi("I_i")#text(", with each ")#mi("I_i")#text(" appearing to the left of ")#mi("I_{i+1}")#text(". For instance, the following string describes an infinite-dimensional combinatorial subspace:")

#mi("2110*_1 *_1 03012 *_2 *_2 *_2 2221111 *_3 201 *_4 *_4 \\ldots")

#text("This gives an embedding of ")#mi("[3]^\\omega")#text(" into ")#mi("[3]^\\omega")#text(" by mapping any n-digit string into the string formed from the above infinite string by substituting these digits into the first n wildcards ")#mi("*_1,\\ldots,*_n")#text(", and then truncating everything after ")#mi("I_n")#text(". For instance, in the above example, 20 maps to")

#mi("21102203012000")#text(".")

#strong[#text("Carlson-Simpson theorem")]#text(" If ")#mi("[3]^\\omega")#text(" is finitely coloured, then one of the colour classes contains an infinite-dimensional combinatorial subspace.")

#text("This theorem implies the colouring Hales-Jewett theorem but is significantly stronger, in particular it does not seem to be deducible solely from the colouring Hales-Jewett theorem (much as the infinite pigeonhole principle cannot be deduced from its finite counterpart).")

#text("It implies a compact version:")

#strong[#text("Carlson-Simpson theorem, compact version")]#text(" If ")#mi("F: [3]^\\omega \\to X")#text(" is a map from ")#mi("[3]^\\omega")#text(" into a compact metric space X, then there exists a infinite-dimensional combinatorial subspace ")#mi("\\phi: [3]^\\omega \\to [3]^\\omega")#text(" such that ")#mi("F \\circ \\phi: [3]^\\omega \\to X")#text(" is uniformly continuous (i.e. it extends continuously to the compactification ")#mi("[3]^\\omega \\cup [3]^\\infty")#text(").")

#text("It is not hard to see that the two versions are equivalent (one has to cover the compact metric space by an increasingly fine mesh of small balls, which can then be used to colour ")#mi("[3]^\\omega")#text("). In paper #1 it is remarked that the compact case is in fact slightly easier to prove than the finite colouring case (I suppose that the induction is somehow cleaner.)")

#text("In a similar spirit, the Graham-Rothschild theorem has the following infinitary generalisation:")

#strong[#text("Carlson’s theorem")]#text(" Suppose that the combinatorial lines in ")#mi("[3]^\\omega")#text(" are finitely coloured. Then there is an infinite-dimensional combinatorial subspace on which all lines have the same colour.")

#text("Or equivalently:")

#strong[#text("Carlson’s theorem")]#text(" Suppose that ")#mi("[4]^\\omega")#text(" is finitely coloured. Then there is an infinite-dimensional combinatorial subspace with no fixed coordinate equal to 3, such that any element of this space with at least one 3 has the same colour.")

#text("Again, there is a compact version:")

#strong[#text("Carlson’s theorem")]#text(" Suppose that ")#mi("F: [4]^\\omega \\to X")#text(" is a map into a compact metric space X. Then there is an infinite-dimensional combinatorial subspace with no fixed coordinate equal to 3, such that the restriction of F to this space is uniformly continuous on those points with at least one 3.")

#text("As I understand it, Carlson’s theorem was discovered independently by Carlson and by Furstenberg-Katznelson.")

#text("The k=1 case of Carlson’s theorem is essentially Hindman’s theorem (the infinitary generalisation of Folkman’s theorem). Given that the cleanest proof of Hindman’s theorem involves idempotent ultrafilters, I would imagine that this is how Carlson’s theorem is also proved. Needless to say, such theorems are not easily finitisable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-35954")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2009")])]

#text("628. Convergence to an orthogonal projection")

#text("Recall that our objective is to show that, given any system of measure-preserving transformations ")#tao-math("U^w_{m+\\left|w\\right|}: X_{m+\\left|w\\right|} \\to X_m", block: false)#text(" obeying a groupoid law, and any set ")#mi("E \\subset X_0")#text(" of positive measure, that there exists a combinatorial line ")#mi("w = (w^0, w^1, w^2)")#text(" in some ")#mi("[3]^n")#text(" such that ")#mi("(U^{w^i}_n)^{-1}(E) \\cap (U^{w^j}_n)^{-1}(E)")#text(" has positive measure for ij=01,12,20.")

#text("The measure of ")#mi("(U^{w^i}_n)^{-1}(E) \\cap (U^{w^j}_n)^{-1}(E)")#text(" can also be written as")

#mi("\\langle 1_E, U^{w^i}_n (U^{w^j}_n)^{-1} 1_E \\rangle_{L^2(X_0)},")#text(" (1)")

#text("where we let measure-preserving transformations ")#mi("T: X \\to X")#text(" act on functions ")#mi("f: X \\to {\\Bbb R}")#text(" in the usual manner, ")#mi("Tf := f \\circ T^{-1}")#text(".")

#text("The key claim is")

#strong[#text("Claim")]#text(" There exists a sequence of combinatorial lines ")#mi("w_m = (w_m^0, w_m^1, w_m^2) \\in [3]^{n_m}")#text(" such that for each ij=01,12,20, the unitary operators ")#mi("U^{w^i_m}_{n_m} (U^{w^j_m}_{n_m})^{-1}")#text(" converge in the weak operator topology to orthogonal projections ")#mi("P_{ij}")#text(".")

#text("Indeed, if this claim held, then (1) for the word ")#mi("w_m")#text(" would converge as ")#mi("m \\to \\infty")#text(" to")

#tao-math("\\langle 1_E, P_{ij} 1_E \\rangle = \\left\\| P_{ij} 1_E \\right\\|_{L^2}^2.", block: false)

#text("On the other hand, since")

#mi("\\langle 1, U^{w^i_m}_{n_m} (U^{w^j_m}_{n_m})^{-1} 1_E \\rangle = \\mu_0(E),")

#text("we must have ")#mi("\\langle 1, P_{ij} 1_E \\rangle = \\mu_0(E) > 0")#text(" and hence ")#tao-math("\\left\\|P_{ij} 1_E \\right\\|_{L^2} > 0", block: false)#text(", and so (1) is positive for sufficiently large m.")

#text("The main tool in proving the claim is the Carlson-Simpson theorem.")

#text("This is a somewhat infinitary argument; at present I do not see what the combinatorial analogue of it will be.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-36040")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2009")])]

#text("629. The invertible maps ")#mi("U_{m+1}^j")#text(" and group structure")

#text("I am beginning to understand a bit better the strange collection of invertible measure-preserving transformations ")#mi("U_{m+1}^j: X_{m+1} \\to X_m")#text(" that appear in the papers 1, 2, 3, which in turn generate the compound maps ")#tao-math("U_{m+\\left|w\\right|}^w: X_{m+\\left|w\\right|} \\to X_m", block: false)#text(".")

#text("Firstly, as Ryan proposed in 622, there is a nice probabilistic interpretation of these transformations that does not require the artificial device of introducing a new source of randomness, such as the uniform probability measure on [0,1]. Roughly speaking, one can view each ")#mi("X_m")#text(" as the space of random m-dimensional combinatorial subspaces in ")#mi("[3]^n")#text(", where each of the m wildcards ")#mi("*_1, \\ldots, *_m")#text(" appear exactly once, plus some additional data which is a bit tricky to describe cleanly (details are ")#link("http://michaelnielsen.org/polymath1/index.php?title=Furstenberg_correspondence_principle")[#text("on the wiki")]#text(").")

#text("The transformation ")#mi("U_{m+1}^j: X_{m+1} \\to X_m")#text(" for j=1,2,3 is the map that takes the random m+1-dimensional subspace to an m-dimensional slice, formed by replacing the final wildcard ")#mi("*_{m+1}")#text(" with j.")

#text("To invert this transformation (i.e. extending an m-dimensional subspace with an m+1-dimensional one), what one would like to do is start with the random m-dimensional subspace, search the fixed coordinates randomly for an instance of j, and replace this j with a wildcard ")#mi("*_{m+1}")#text(". Of course, this is a random map rather than a deterministic one; so what one has to do is to “roll the dice in advance” and store the choices of fixed coordinates one would use to extend the transformation as part of the data used to define an element of ")#mi("X_m")#text(". In fact one needs to roll the dice once for every element of the free group ")#mi("F_3")#text(" on three generators, representing all the future possibilities of extending and contracting the space.")

#text("The construction actually gives more than the invertible maps ")#tao-math("U_{m+\\left|w\\right|}^w : X_{m+\\left|w\\right|} \\to X_m", block: false)#text("; it also gives a permutation action on each ")#mi("X_n")#text(", and one can multiply all the ")#mi("X_n")#text(" to get an honest-to-goodness measure-preserving group action ")#mi("U_w: X \\to X")#text(" of the free group ")#mi("F_3")#text(", rather than this funny groupoid action that Furstenberg and Katznelson use. However (as was pointed out all the way back in Austin.6), all this additional structure is actually a hindrance to the proof, because one has to let go of it in order to take advantage of the powerful Ramsey theorems available such as Carlson’s theorem.")

#text("I still feel that there should be some clean algebraic substitute for the concept of a group action that can clarify conceptually the dynamics of this system, but I do not yet know what it should be (something like a semi-groupoid action). The key thing seems to be that the structure one has generates lots of “IP-systems”, which I will discuss next.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-36041")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2009")])]

#text("630. An IP convergence lemma")

#text("Let ")#mi("U_1, U_2, \\ldots \\in G")#text(" be a sequence of group elements, then we can define ")#mi("U_\\alpha \\in G")#text(" for any finite set ")#mi("\\alpha")#text(" of natural numbers by the formula")

#mi("U_{\\{a_1,\\ldots,a_n\\}} := U_{a_1} \\ldots U_{a_n}")

#text("when ")#mi("a_1 < \\ldots < a_n")#text(". The ")#mi("U_\\alpha")#text(" form an ")#emph[#text("IP-system")]#text(", which means that they have the restricted multiplicativity property")

#mi("U_\\alpha U_\\beta = U_{\\alpha \\cup \\beta}")

#text("whenever ")#mi("\\alpha")#text(" is to the left of ")#mi("\\beta")#text(". (This is an example of the “semi-groupoid action” concept I am struggling to formalise in a clean algebraic fashion.)")

#text("If G has a topology on it, we say that the IP-system ")#mi("U_\\alpha")#text(" converges to a limit ")#mi("U \\in G")#text(" if every neighbourhood of U contains the ")#mi("U_\\alpha")#text(" “for sufficiently large ")#mi("\\alpha")#text("“, which means that the least element ")#mi("\\min(\\alpha)")#text(" of ")#mi("\\alpha")#text(" is sufficiently large.")

#text("Hindman’s theorem is equivalent to the claim that any IP-system in a compact metrisable space has a convergent sub-IP-system (I will not define what a sub-IP-system is here; again, I do not feel that I have that the correct algebraic formalism for all this yet.).")

#text("The following lemma is the key in Paper #1 (together with Carlson’s theorem, which has a similar flavour to Hindman’s theorem) to proving the claim in 628:")

#strong[#text("Lemma.")]#text(" Let ")#mi("U_\\alpha")#text(" be an IP system of unitary operators on a separable Hilbert space H that converges (in the weak operator topology) to a limit P. Then P is an orthogonal projection.")

#text("[Note that the weak operator topology on the operators with norm at most 1 on H is compact metrisable.]")

#text("Proof. Since the ")#mi("U_\\alpha")#text(" have operator norm at most 1, P has norm at most 1 as well. Since the only idempotents of norm at most 1 are the orthogonal projections, it suffices to show that ")#mi("P^2 = P")#text(".")

#text("Let ")#mi("v \\in H")#text(". Then ")#mi("U_\\alpha^* v")#text(" converges weakly to ")#mi("P^* v")#text(" as ")#mi("\\alpha \\to \\infty")#text(". But for fixed ")#mi("\\alpha")#text(", $U^*_\\beta U_\\alpha^* v$ converges weakly to ")#mi("P^* U_\\alpha^* v")#text(" as ")#mi("\\beta \\to \\infty")#text("; thus")

#mi("\\lim_{\\alpha \\to \\infty} \\lim_{\\beta \\to \\infty} U^*_\\beta U^*_\\alpha v = (P^*)^2 v")#text(",")

#text("where the limits are in the weak sense. On the other hand, using the IP property, the limit on the left is ")#mi("P^* v")#text(". Thus ")#mi("P^* = (P^*)^2")#text(" and so P is idempotent.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-36084")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2009")])]

#text("631. An informal combinatorial translation of the ergodic proof of DHJ(2)")

#text("I’m beginning to understand (though still in a somewhat fuzzy, informal way) what the ergodic argument in Paper #1 would translate to in purely combinatorial terms. For simplicity I’ll start with DHJ(2) – the claim that any dense subset ")#mi("A")#text(" of ")#mi("[2]^n")#text(" contains a combinatorial line.")

#text("Let m be an integer that grows slowly with n (think of m as being like ")#mi("\\lfloor \\log \\log n \\rfloor")#text(", for instance), and let V be a random m-dimensional combinatorial subspace of ")#mi("[2]^n")#text(", where I will be deliberately vague as to what distribution V is drawn from here. One can use this random subspace V to create various real-valued random variables f(V) which depend only on what A is doing on V. For instance, one could consider the indicator random variable ")#mi("1_{E_0}(V)")#text(", which equals 1 when the bottom corner of V (formed by sending all m wildcards to 0) lies in A; one could consider the random variable ")#mi("d(V)")#text(" that measures the density of A in V; and so forth.")

#text("Now, the random subspace V has a lot of fixed coordinates, and so with very high probability it’s going to have a lot of fixed 0s and fixed 1s (about n/2 of each). Let V’ be the random subspace parallel to V formed by taking one of the fixed 0s at random and flipping it to a 1. Then every random variable f(V) that is associated to V has a “shifted” version f(V’). Note that we expect V’ to have almost the same distribution as V, and so f(V) and f(V’) should also have about the same distribution; this is a ")#emph[#text("stationarity")]#text(" property. However, this does not mean that f(V) and f(V’) are necessarily close to each other.")

#text("There are two fundamental types of random variable:")

#text("* A random variable f(V) is ")#emph[#text("periodic")]#text(" if f(V’) and f(V) are close, thus ")#tao-math("{\\Bbb E} \\left|f(V) - f(V^{\\prime})\\right|", block: false)#text(" is small.")

#text("* A random variable f(V) is ")#emph[#text("mixing")]#text(" if f(V’) and f(V) are uncorrelated, thus ")#mi("{\\Bbb E} f(V) f(V^{\\prime})")#text(" is small.")

#text("Examples: any constant random variable is periodic. If the set A has “low influence” (which means that flipping a bit from 0 to 1 is unlikely to affect membership in A) then every random variable f(V) is in fact periodic. At the other extreme, if A is a random set of a fixed density ")#mi("\\delta")#text(", then any random variable f(V) of mean zero will be mixing, and only the constants will be periodic.")

#text("Now, here is the basic fact (modulo some lies):")

#strong[#text("Fact")]#text(". Every random variable f(V) can be decomposed (uniquely) into a periodic random variable Pf(V) and a mixing random variable (1-P)f(V). Furthermore, the periodic random variables and mixing random variables are always uncorrelated (i.e. orthogonal to each other).")

#text("This fact is a heavily disguised version of the lemma in 630, and can also be viewed as a sort of “IP mean ergodic theorem”. It is not quite true as stated; to be true, one has to redefine V’ to not be formed by flipping just one fixed coordinate of V, but by flipping an unspecified but bounded number of fixed coordinates. (The number of digits to flip will be determined by a Ramsey-type theorem, such as Folkman’s theorem, Graham-Rothschild, etc. The Ramsey theorem will also tell us what distribution V is to be drawn from, and in particular how many times each wildcard will appear.).")

#text("Assume this fact. Now we can prove DHJ(2). If we let ")#mi("1_{E_0}(V)")#text(" be the event that the bottom left corner of V lies in A, it suffices to show that")

#mi("{\\Bbb E} 1_{E_0}(V) 1_{E_0}(V^{\\prime})")

#text("is large.")

#text("Observe that the claim would be easy if ")#mi("1_{E_0}(V)")#text(" was periodic, since then ")#mi("1_{E_0}(V) \\approx 1_{E_0}(V^{\\prime})")#text(". The claim would also be easy if ")#mi("1_{E_0}(V)")#text(" was mixing, since then the two random variables ")#mi("1_{E_0}(V), 1_{E_0}(V^{\\prime})")#text(" would be roughly independent. In general, the Fact tells us that we are in a combination of the two situations. Splitting both ")#mi("1_{E_0}(V)")#text(" and ")#mi("1_{E_0}(V^{\\prime})")#text(" into periodic and mixing components, we get four terms, three of which are small, leaving us with")

#mi("{\\Bbb E} P 1_{E_0}(V) P 1_{E_0}(V^{\\prime}) \\approx {\\Bbb E} P 1_{E_0}(V)^2")#text(". (1)")

#text("But observe that the mixing function ")#mi("(1-P) 1_{E_0}(V)")#text(" is orthogonal to the periodic function 1, and thus has zero expectation. Since ")#mi("1_{E_0}(V)")#text(" has expectation ")#mi("\\delta")#text(", we conclude that ")#mi("P 1_{E_0}(V)")#text(" has expectation ")#mi("\\delta")#text(", and so (by Cauchy Schwarz) the expression (1) is large, and we are done.")

#text("In my next comment I will try to indicate how DHJ(3) works in some special cases. Here there is not just one projection P, but now three separate projections P, reflecting interchange between 0 and 1, 1 and 2, or 2 and 0. Things are relatively easy when one of the projections is extreme (either everything is periodic, or only the constants are periodic), but the case in which all projections are intermediate (so some random variables are periodic and others are mixing) is quite tricky.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-36085")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2009")])]

#text("632. Some special cases of DHJ(3)")

#text("Now we move from k=2 to k=3. Again, we consider an m-dimensional random subspace V of ")#mi("[3]^n")#text(". Instead of a single companion subspace V’, we now have three spaces ")#mi("V_{0 \\to 1}, V_{1 \\to 2}, V_{2 \\to 0}")#text(", formed from V by flipping a fixed 0 to a 1, or a fixed 1 to a 2, or a fixed 2 to a 0. We can then define the notion of a random variable f(V) being 01-periodic or 01-mixing (resp. 12-periodic or 12-mixing, etc.) by comparing f(V) with ")#mi("f(V_{0 \\to 1})")#text(", etc. We then get decompositions ")#mi("f(V) = P_{01} f(V) + (1-P_{01})f(V)")#text(" into 01-periodic and 01-mixing components, etc.")

#text("What makes life difficult here is that the three orthogonal projections ")#mi("P_{01}, P_{12}, P_{20}")#text(" can be in general position with respect to each other (in particular, they need not commute). But things are simpler when one of the orthogonal projections is trivial.")

#text("At one extreme, consider the case when ")#mi("P_{12}")#text(" (say) is the identity – in other words, that ")#emph[#text("every")]#text(" random variable f(V) is 12-periodic. This is basically saying that the original set A is essentially insensitive to flipping a 1 to 2 or vice versa. Because of this, we can basically identify 1 and 2 together and reduce the k=3 problem to the k=2 problem.")

#text("A more non-trivial case is the other extreme, in which ")#mi("P_{12}")#text(" is the expectation operator – i.e. every random variable f(V) of expectation zero is 12-periodic, or equivalently, f(V) and g(V_{1 \\to 2}) are independent for every f, g.")

#text("Now let f(V), g(V), h(V) be random variables. We claim that if f is 01-mixing OR if g is 20-mixing, then")

#mi("{\\Bbb E} h(V) f(V_{0 \\to 1}) g(V_{0 \\to 2}) \\approx 0")#text(", (1)")

#text("where ")#mi("V_{0 \\to 2}")#text(" is defined by taking the ")#emph[#text("same")]#text(" digit that was flipped from 0 to 1 in the definition of ")#mi("V_{0 \\to 1}")#text(", and flipping it to 2 instead.")

#text("To show this, it suffices (by a certain “IP van der Corput lemma”, which one should think of as a variant of Cauchy-Schwarz) to eliminate h and show that")

#mi("{\\Bbb E} f(V_{00 \\to 01}) g(V_{00 \\to 02}) f(V_{00 \\to 11}) g(V_{00 \\to 22}) \\approx 0")#text(" (2)")

#text("where the ")#mi("V_{00 \\to ij}")#text(" are formed by choosing two of the fixed 0s of V and flipping them to i and j (and it is the same two digits being flipped for all four of the ")#mi("V_{00 \\to ij}")#text(").")

#text("The triviality of ")#mi("P_{12}")#text(" (or more precisely, a variant of this with m replaced by m+1) can then be used to show that the random variables ")#mi("f(V_{00 \\to 01}) f(V_{00 \\to 11})")#text(" and ")#mi("g(V_{00 \\to 02}) g(V_{00 \\to 22})")#text(", because these random variables involve parallel m+1-dimensional subspaces which differ from each other by flipping a single 1 to a 2. Assuming this, we can simplify the expression in (2) to")

#mi("[{\\Bbb E} f(V_{00 \\to 01}) f(V_{00 \\to 11})] [{\\Bbb E} g(V_{00 \\to 02}) g(V_{00 \\to 22})]")#text(".")

#text("But one of these factor vanishes since f is 01 mixing or g is 20 mixing, and we are done.")

#text("For general f, g, we can now use the Fact from the previous comment to obtain the “generalised von Neumann theorem”.")

#mi("{\\Bbb E} h(V) f(V_{0 \\to 1}) g(V_{0 \\to 2}) \\approx  {\\Bbb E} h(V) P_{01} f(V) P_{02} g(V)")#text(".")

#text("Now we can prove DHJ(3). It suffices to show that")

#mi("{\\Bbb E} 1_{E_0}(V) 1_{E_0}(V_{0 \\to 1}) 1_{E_0}(V_{0 \\to 2})")

#text("is large. Using the generalised von Neumann theorem, this expression can be rewritten as")

#mi("{\\Bbb E} 1_{E_0}(V) P_{01} 1_{E_0}(V) P_{20} 1_{E_0}(V)")#text(".")

#text("But, as we saw in 631, ")#mi("P_{01} 1_{E_0}")#text(" has positive inner product with ")#mi("1_{E_0}")#text(". Furthermore ")#mi("P_{01} 1_{E^{\\prime}}")#text(" has positive inner product with ")#mi("1_{E^{\\prime}}")#text(" for any subset E’ of ")#mi("E_0")#text(" of positive measure. One can check that ")#mi("P_{01}")#text(" is monotone, and so ")#mi("P_{01} 1_{E_0}")#text(" has positive inner product with ")#mi("1_{E^{\\prime}}")#text(" for any ")#mi("E^{\\prime}")#text(" of positive measure; thus ")#mi("P_{01} 1_{E_0}")#text(" is positive almost surely on ")#mi("E_0")#text(" (indeed, ")#mi("P_{01} 1_{E_0}")#text(" is the conditional expectation of ")#mi("E_0")#text(" to a certain factor), and similarly for ")#mi("P_{20} 1_{E_0}")#text(", and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-36156")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2009")])]

#text("633. Thread moving")

#text("I have now got an informal combinatorial translation of Paper #2 on the wiki at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Furstenberg-Katznelson_argument")[#text("http://michaelnielsen.org/polymath1/index.php?title=Furstenberg-Katznelson_argument")]

#text("and it is now being discussed on the 800 thread at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://gowers.wordpress.com/2009/02/23/brief-review-of-polymath1/")[#text("Brief review of polymath1")]
]

#text("so I am now moving discussion of this paper over to that thread.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4ad6c18186ffa1aab4aadbb6437ddfdfd03ffdb28fa7b75fb5a4b74dadd060d-b17876bb6ed44b4eb4e6f409d6e9c2e04bf2fd6789fad7fda897a642de72445e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath proposal: bounded gaps between primes | The polymath blog")]], [#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-232500")[#strong[#text("Polymath proposal: bounded gaps between primes | The polymath blog")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2013")])]

#text("[…] 2 of this project could be run as an online reading seminar, similar to the online reading seminar of the Furstenberg-Katznelson paper that was part of the Polymath1 project. It would likely focus on the second half of Zhang’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/11/a-reading-seminar-on-density-hales-jewett/#comment-450099")[#strong[#text("There Are Many Primes | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2015")]

#text("[…] . This led to a new multidimensional formulation with Yitzhak Katznelson, and the two later proved positive-density versions of the Hales-Jewett […]")
]
