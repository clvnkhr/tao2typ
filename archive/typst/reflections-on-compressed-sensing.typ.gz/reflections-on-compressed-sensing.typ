// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/05/25/reflections-on-compressed-sensing/
// Converted to Typst by tao2typ: "2026-10-14T07:22:11.624253+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Reflections on compressed sensing", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Reflections on compressed sensing")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 May 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/05/25/reflections-on-compressed-sensing/")[#text("https://terrytao.wordpress.com/2009/05/25/reflections-on-compressed-sensing/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This post should have appeared several months ago, but I didn’t have a link to the newsletter at the time, and I subsequently forgot about it until now. -T.]")]

#text("Last year, ")#link("http://www.acm.caltech.edu/~emmanuel/")[#text("Emmanuel Candés")]#text(" and I were two of the recipients of the 2008 ")#link("http://www.itsoc.org/society/itpaper_awd.htm")[#text("IEEE Information Theory Society Paper Award")]#text(", for our paper “")#link("http://arxiv.org/abs/math.CA/0410542")[#text("Near-optimal signal recovery from random projections: universal encoding strategies?")]#text("” published in IEEE Inf. Thy.. (The other recipient is ")#link("http://www-stat.stanford.edu/~donoho/")[#text("David Donoho")]#text(", for the closely related paper “")#link("http://www-stat.stanford.edu/~donoho/Reports/2004/CompressedSensing091604.pdf")[#text("Compressed sensing")]#text("” in the same journal.) These papers helped initiate the modern subject of ")#emph[#text("compressed sensing")]#text(", which I have talked about ")#link("https://terrytao.wordpress.com/tag/compressed-sensing/")[#text("earlier on this blog")]#text(", although of course they also built upon a number of important precursor results in signal recovery, high-dimensional geometry, Fourier analysis, linear programming, and probability. As part of our response to this award, Emmanuel and I wrote a short piece commenting on these developments, entitled “")#link("http://www.itsoc.org/publications/newsletters/itNL1208.pdf/at_download/file")[#text("Reflections on compressed sensing")]#text("“, which appears in the Dec 2008 issue of the IEEE Information Theory newsletter. In it we place our results in the context of these precursor results, and also mention some of the many active directions (theoretical, numerical, and applied) that compressed sensing is now developing in.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d673d9b3e9ff664b048a243397f1756f4cfaee98f073b4186a1396d6da741ac-38cab0c5d213f9c1aa1f47d8a8c3a19490ed36bd7997a03dda17e6c9535e88b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Carron")]], [#link("https://terrytao.wordpress.com/2009/05/25/reflections-on-compressed-sensing/#comment-39054")[#strong[#text("Igor Carron")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2009")])]

#text("Dear Terry,")

#text("Thanks to you and Emmanuel for the plug about the blog in the newsletter!")

#text("Igor.")#linebreak()#text(" ")#link("http://nuit-blanche.blogspot.com")[#text("http://nuit-blanche.blogspot.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of weiyu")]], [#link("https://terrytao.wordpress.com/2009/05/25/reflections-on-compressed-sensing/#comment-40752")[#strong[#text("weiyu")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2009")])]

#text("just one simple question from the paper “Near Optimal Signal Recovery from Random Projections:Universal Encoding Strategies?”")

#text("For the Fourier ensemble, in order for the R.I.P conditions to hold, can we get the sparsity level, namely the cardinality of the signal support, be linearly growing with the problem dimension N, if we allow the number of freuqnecy sample grow linearly with the problem dimension N? In the paper, we can have N/log(N) growth, can we get rid of this constraint?")

#text("Many thanks for the reply.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/25/reflections-on-compressed-sensing/#comment-40807")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2009")])]

#text("In the Gaussian case, this can be achieved; see for instance my joint paper with Candes, Rudelson, and Vershynin at ")#link("http://www.math.ucla.edu/~tao/preprints/FOCS05.pdf")[#text("http://www.math.ucla.edu/~tao/preprints/FOCS05.pdf")]#text(" (though the observation probably predates the explicit introduction of the RIP concept).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/25/reflections-on-compressed-sensing/#comment-55624")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2011")])]

#text("In reading the proof of the UUP for the Fourier matrix from the “Universal Encoding Strategy paper”, ")#link("http://ieeexplore.ieee.org/stamp/stamp.jsp?tp=&arnumber=4016283")[#text("http://ieeexplore.ieee.org/stamp/stamp.jsp?tp=&arnumber=4016283")]

#text("two questions:")

#text("1. In the definition of the set {J_0,…,J_1} (right above Eq. (7.48) in the IEEE version), should the N^2 in the definition be N^{-2}?")

#text("2. In the telescoping expansion below Eq. (7.48). Is the expansion written in the right way. In this expansion, f_{J_{0}} was subtracted twice. Was there a typo there?")

#text("Thank you very much for your reply, which will greatly help understanding of this paper.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/05/25/reflections-on-compressed-sensing/#comment-56597")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2011")])]

#text("Yes, there should be a minus sign in both cases (N^2 should be N^{-2}, and the telescoping series should have its sign reversed.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5a8d8a42cb43f7ea95c96c0a8ce2a5a379192140266c5abacbfd2db11379f63a-a62d799208375798cd5d12f9f7241931d3654f93d9c7364adacff904aa568a5c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2009/05/25/reflections-on-compressed-sensing/#comment-109009")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2011")])]

#text("Dear Terry,")

#text("In your paper “Decoding by Linear Programming” you wish to recover an input vector ")#mi("f \\in \\textbf{R}^{n}")#text(" from corrupted measurements ")#mi("y = Af+e")#text(". Can one change ")#mi("f")#text(" to be a square matrix? In other words, could you also ask given corrupted measurements can you recover an input matrix?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d40b48710e4189605d9a9c27bbc3104fa2cd4b225a17762a9eb5217d3fbe06b-76f371325380d2e47295a6ae7b5db97b7cb32f26109090f4e09dd92e8045f907.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/25/reflections-on-compressed-sensing/#comment-175513")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2012")])]

#text("Recently, I published a paper on the super robustness at:")

#link("http://arxiv.org/abs/1208.1810")[#text("http://arxiv.org/abs/1208.1810")]

#text("Is there any insight on the relation between our approach and GGD used in compressive sensing? The main goal of our approach was to do pattern matching.")

#text("Any suggestions to extend the results to more general transformation than translation estimation?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/25/reflections-on-compressed-sensing/#comment-175901")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2012")])]

#text("Sorry for the typo: “GGD used in compressive sensing” should read “GGD=based approaches used in compressive sensing”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/25/reflections-on-compressed-sensing/#comment-176482")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2012")])]

#text("Mathematically, compressive sensing and super robustness of location estimation studied in ")#link("http://arxiv.org/abs/1208.1810")[#text("http://arxiv.org/abs/1208.1810")]#text(" are all related to a linear system ")#emph[#text("A=BC")]#text(". The difference is that in compressive sensing, ")#emph[#text("A")]#text(" and ")#emph[#text("B")]#text(" are all reliable but there are not enough equations to solve ")#emph[#text("C")]#text(", thus a “good guess” is generated using linear programming based on some kind of mathematics assumption; in the super robustness of location estimation, ")#emph[#text("A")]#text(" and ")#emph[#text("B")]#text(" contains a lot of noise or majority of the data in ")#emph[#text("A")]#text(" and ")#emph[#text("B")]#text(" are not reliable, the paper presents an approach how to generate a reliable ")#emph[#text("C")]#text(" from the very noisy data.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/25/reflections-on-compressed-sensing/#comment-244020")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2013")])]

#text("The newsletter is missing from the website. Could Professor Tao help upload a direct link to the newsletter article here? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d673d9b3e9ff664b048a243397f1756f4cfaee98f073b4186a1396d6da741ac-38cab0c5d213f9c1aa1f47d8a8c3a19490ed36bd7997a03dda17e6c9535e88b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Carron")]], [#link("https://terrytao.wordpress.com/2009/05/25/reflections-on-compressed-sensing/#comment-246509")[#strong[#text("Igor Carron")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2013")])]

#text("Anonymous,")

#text("It is here: ")#link("http://www-stat.stanford.edu/~candes/papers/itNL1208.pdf")[#text("http://www-stat.stanford.edu/~candes/papers/itNL1208.pdf")]

#text("Igor.")
]
