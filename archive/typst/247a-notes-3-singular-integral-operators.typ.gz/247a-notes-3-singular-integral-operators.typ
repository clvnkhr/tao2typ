// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/27/247a-notes-3-singular-integral-operators/
// Converted to Typst by tao2typ: "2026-10-29T13:25:54.683638+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "247A, Notes 3: Singular integral operators", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("247A, Notes 3: Singular integral operators")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/27/247a-notes-3-singular-integral-operators/")[#text("https://terrytao.wordpress.com/2026/10/27/247a-notes-3-singular-integral-operators/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-29 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#heading(level: 1)[#strong[#text(" — 1. The Hilbert transform — ")]]

#text("In this set of notes we begin the theory of ")#link("https://en.wikipedia.org/wiki/Singular_integral")[#text("singular integral operators")]#text(" – operators which are almost integral operators, except that their kernel ")#mi("{K(x,y)}")#text(" just barely fails to be integrable near the diagonal ")#mi("{x=y}")#text(". (This is in contrast to, say, fractional integral operators such as ")#tao-math("{Tf(y) := \\int_{{\\bf R}^d} \\frac{1}{\\left|x-y\\right|^{d-s}} f(x)\\ dx}", block: false)#text(", whose kernels go to infinity at the diagonal but remain locally integrable.) These operators arise naturally in complex analysis, Fourier analysis, and also in PDE (in particular, they include the ")#link("https://en.wikipedia.org/wiki/Pseudo-differential_operator")[#text("zeroth order pseudodifferential operators")]#text(" as a special case, about which more will be said later). It is here for the first time that we must make essential use of ")#emph[#text("cancellation")]#text(": cruder tools such as Schur’s test which do not take advantage of the sign of the kernel will not be effective here.")

#text("Before we turn to the general theory, let us study one of the simplest non-trivial singular integral operators, the ")#link("https://en.wikipedia.org/wiki/Hilbert_transform")[#text("Hilbert transform")]#text(" ")#metadata(none) <tao-bd36e2455121f8ffec77>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("H f (x) := p.v. \\frac{1}{\\pi} \\int_{\\bf R} \\frac{f(x-t)}{t}\\ dt := \\lim_{\\varepsilon \\rightarrow 0} \\frac{1}{\\pi} \\int_{\\left|t\\right| > \\varepsilon} \\frac{f(x-t)}{t}\\ dt.", block: true)]]

#text(" ")#text(" It is not immediately obvious that ")#mi("{Hf(x)}")#text(" is well-defined even for nice functions ")#mi("{f}")#text(". But if ")#mi("{f}")#text(" is ")#mi("{C^1}")#text(" and compactly supported, then we can restrict the integral to a compact interval ")#mi("{t \\in [-R,R]}")#text(" for some large ")#mi("{R}")#text(" (depending on ")#mi("{x}")#text(" and ")#mi("{f}")#text("), and use symmetry to write")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|t\\right| > \\varepsilon} \\frac{f(x-t)}{t}\\ dt = \\int_{\\varepsilon < \\left|t\\right| < R} \\frac{f(x-t)-f(x)}{t}\\ dt.", block: true)]]

#text("The mean-value theorem then shows that ")#mi("{\\frac{f(x-t)-f(x)}{t}}")#text(" is uniformly bounded on the interval ")#mi("{t \\in [-R,R]}")#text(" for fixed ")#mi("{f,x}")#text(", and so the limit actually exists from the dominated convergence theorem. A variant of this argument shows that ")#mi("{Hf}")#text(" is also well-defined for ")#mi("{f}")#text(" in the Schwartz class, though it does not map the Schwartz class to itself. Indeed it is not hard to see that we have the asymptotic")

#align(center)[#tao-fit-display[#tao-math("\\lim_{\\left|x\\right| \\rightarrow \\infty} x Hf(x) = \\frac{1}{\\pi} \\int_{\\bf R} f", block: true)]]

#text("for such functions, and so if ")#mi("{f}")#text(" has non-zero mean then ")#mi("{Hf}")#text(" only decays like ")#tao-math("{1/\\left|x\\right|}", block: false)#text(" at infinity. In particular, we already see that ")#mi("{H}")#text(" is not bounded on ")#mi("{L^1}")#text(". However, we do see that ")#mi("{H}")#text(" at least maps the Schwartz class to ")#mi("{L^2({\\bf R})}")#text(".")

#text("Let us first make comment on some algebraic properties of the Hilbert transform. It commutes with translations")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Trans}_{x_0} f(x) := f(x-x_0)")]]

#text("and ")#mi("{L^p}")#text("-normalized dilations")

#tao-aligned(keep: true)[


#tao-math("\\mathrm{Dil}^p_\\lambda f(x)  & := \\lambda^{-1/p} f(x/\\lambda):", block: true)

#metadata(none) <tao-2dd738febcb1a0e6a9dd>

#tao-math("H \\mathrm{Trans}_{x_0}  & = \\mathrm{Trans}_{x_0} H; \\quad \\mathrm{Dil}^p_\\lambda H = H \\mathrm{Dil}^p_\\lambda.", block: true, numbering: n => [#text("(2)")])
]

#text("In fact, it is essentially the only such operator:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Let ")#mi("{T: \\mathcal{S}({\\bf R}) \\rightarrow C^0({\\bf R})}")#text(" be a continuous linear operator which maps Schwartz functions to bounded continuous functions, and which commutes with translations and dilations as in ")#link(<tao-2dd738febcb1a0e6a9dd>)[#text("(2)")]#text(". Show that ")#mi("{T}")#text(" is a linear multiple of the Hilbert transform and the identity. (Hint: first establish the existence of a distribution ")#mi("{K \\in \\mathcal{S}({\\bf R})^*}")#text(" such that ")#mi("{Tf(x) = \\langle K, \\mathrm{Trans}_{-x} f \\rangle}")#text(" for all ")#mi("{f \\in \\mathcal{S}({\\bf R})}")#text(", and such that ")#mi("{K}")#text(" is homogeneous of degree ")#mi("{-1}")#text(". Restrict the action of ")#mi("{K}")#text(" to Schwartz functions on ")#mi("{{\\bf R}^+}")#text(" or ")#mi("{{\\bf R}^-}")#text(" and show that ")#mi("{K}")#text(" is a constant multiple of ")#mi("{1/x}")#text(" on these functions.) (The claim is also true if we relax ")#mi("{C^0({\\bf R})}")#text(" to ")#mi("{\\mathcal{S}({\\bf R})^*}")#text(", the space of distributions, but this is a little trickier to prove.)")
]

#text("It is also formally skew-adjoint:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" If ")#mi("{f,g \\in C^1({\\bf R})}")#text(" are compactly supported, show that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} H f(x) \\overline{g(x)}\\ dx = - \\int_{\\bf R} f(x) \\overline{H g(x)}\\ dx.")]]
]

#text("The Hilbert transform is connected to complex analysis (and in particular to Cauchy integrals) by the ")#link("https://en.wikipedia.org/wiki/Sokhotski%E2%80%93Plemelj_theorem")[#text("Plemelj formulae")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Plemelj formulae)")]#text(" Let ")#mi("{f \\in C^1({\\bf R})}")#text(" obey a qualitative decay bound ")#mi("{f(x) = O_f( \\langle x \\rangle^{-1} )}")#text(" (say – these conditions are needed just to make ")#mi("{Hf}")#text(" well-defined). Then for any ")#mi("{x \\in {\\bf R}}")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\lim_{\\varepsilon \\rightarrow 0} \\int_{\\bf R} \\frac{f(y)}{y - (x \\pm i\\varepsilon)}\\ dy = \\frac{\\pm f(x) + i H f(x)}{2}.")]]
]

#emph[#text("Proof:")]#text(" By translation invariance we can take ")#mi("{x=0}")#text(". By taking complex conjugates we may assume that the ")#mi("{\\pm}")#text(" sign is ")#mi("{+}")#text(". Our task is then to show that")

#align(center)[#tao-fit-display[#tao-math("\\lim_{\\varepsilon \\rightarrow 0} \\frac{1}{2\\pi i} \\int_{\\bf R} \\frac{f(y)}{y - i\\varepsilon}\\ dy - \\frac{1}{2} f(0) - \\frac{i}{2\\pi} \\int_{\\left|y\\right| > \\varepsilon} \\frac{f(y)}{-y}\\ dy = 0.", block: true)]]

#text("Multiplying by ")#mi("{2\\pi i}")#text(" and making the change of variables ")#mi("{y = \\varepsilon w}")#text(", we reduce to showing")

#align(center)[#tao-fit-display[#tao-math("\\lim_{\\varepsilon \\rightarrow 0} \\int_{\\bf R} f(\\varepsilon w) \\left(\\frac{1}{w - i} - 1_{\\left|w\\right| > 1} \\frac{1}{w} \\right)\\ dw - \\pi i f(0) = 0.", block: true)]]

#text("Direct computation shows that the expression in parentheses is absolutely integrable and")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\bf R} \\left(\\frac{1}{w - i} - 1_{\\left|w\\right| > 1} \\frac{1}{w} \\right) = \\pi i.", block: true)]]

#text("So we reduce to showing that")

#align(center)[#tao-fit-display[#tao-math("\\lim_{\\varepsilon \\rightarrow 0} \\int_{\\bf R} (f(\\varepsilon w)-f(0)) \\left(\\frac{1}{w - i} - 1_{\\left|w\\right| > 1} \\frac{1}{w} \\right)\\ dw = 0.", block: true)]]

#text("The claim then follows from dominated convergence. ")#mi("\\Box")

#text("Now suppose that ")#mi("{f}")#text(" not only obeys the hypotheses of the Plemelj formulae, but also extends holomorphically to the upper half-plane ")#mi("{\\{ z \\in {\\bf C}: \\mathrm{Im}(z) \\geq 0 \\}}")#text(" and obeys the decay bound ")#mi("{f(z) = O_f( \\langle z \\rangle^{-1} )}")#text(" in this region. Then Cauchy’s theorem gives")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\lim_{\\varepsilon \\rightarrow 0} \\int_{\\bf R} \\frac{f(y)}{y - (x + i\\varepsilon)}\\ dy = f(x)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi i} \\lim_{\\varepsilon \\rightarrow 0} \\int_{\\bf R} \\frac{f(y)}{y - (x - i\\varepsilon)}\\ dy = 0")]]

#text("and thus by either of the Plemelj formulae we see that ")#mi("{Hf = -if}")#text(" in this case. In particular, comparing real and imaginary parts we conclude that ")#mi("{\\mathrm{Im}(f) = H \\mathrm{Re}(f)}")#text(" and ")#mi("{\\mathrm{Re}(f) = - H \\mathrm{Im}(f)}")#text(". Thus for reasonably decaying holomorphic functions on the upper half-plane, the real and imaginary parts of the boundary value are connected via the Hilbert transform. In particular this shows that such functions are uniquely determined by just the real part of the boundary value.")

#text("The above discussion also strongly suggests the identity ")#mi("{H^2 = -1}")#text(". This can be made more manifest by the following Fourier representation of the Hilbert transform.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" If ")#mi("{f \\in \\mathcal{S}({\\bf R})}")#text(", then")

#metadata(none) <tao-64da817f607e940546c5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\widehat{Hf}(\\xi) = -i \\mathrm{sgn}(\\xi) \\hat f(\\xi)")]]

#text("for (almost every) ")#mi("{\\xi \\in {\\bf R}}")#text(". (Recall that ")#mi("{Hf}")#text(" lies in ")#mi("{L^2}")#text(" and so its Fourier transform is defined via density by Plancherel’s theorem.)")
]

#emph[#text("Proof:")]#text(" Let us first give a non-rigorous proof of this identity. Morally speaking we have")

#align(center)[#tao-fit-display[#mitex("Hf = f * \\frac{1}{\\pi x}")]]

#text("and so since Fourier transforms ought to interchange convolution and product")

#align(center)[#tao-fit-display[#mitex("\\widehat{Hf}(\\xi) = \\hat f(\\xi) \\widehat{\\frac{1}{\\pi x}}(\\xi).")]]

#text("On the other hand we have")

#align(center)[#tao-fit-display[#mitex("\\widehat{1}(\\xi) = \\delta(\\xi)")]]

#text("so on integrating this (using the relationship between differentiation and multiplication) we get")

#align(center)[#tao-fit-display[#mitex("\\widehat{\\frac{1}{-2\\pi i x}}(\\xi) = \\frac{1}{2} \\mathrm{sgn}(\\xi)")]]

#text("and the claim follows.")

#text("Now we turn to the rigorous proof. As the Hilbert transform is odd, a symmetry argument allows one to reduce to the case ")#mi("{\\xi > 0}")#text(". It then suffices to show that ")#mi("{\\frac{- f + iH f}{2}}")#text(" has vanishing Fourier transform in this half-line. Define the Cauchy integral operator")

#align(center)[#tao-fit-display[#mitex("{\\mathcal C}_{\\varepsilon} f(x) = \\frac{1}{2\\pi i} \\int_{\\bf R} \\frac{f(y)}{y - (x - i\\varepsilon)}\\ dy.")]]

#text("The Plemelj formulae show that these converge pointwise to ")#mi("{\\frac{-f+iHf}{2}}")#text(" as ")#mi("{\\varepsilon \\rightarrow 0}")#text("; since ")#mi("{f}")#text(" is Schwartz, it is also not hard to show via dominated convergence that they also converge in ")#mi("{L^2}")#text(". Thus by the ")#mi("{L^2}")#text(" boundedness of the Fourier transform it suffices to show that each of the ")#mi("{{\\mathcal C}_\\varepsilon f}")#text(" also have vanishing Fourier transform on the half-line.")

#text("This is part of a more general phenomenon, that functions which extend holomorphically to the upper half-space in a controlled manner tend to have vanishing Fourier transform on ")#mi("{{\\bf R}^-}")#text(", while those which extend to the lower half-space have vanishing Fourier transform on ")#mi("{{\\bf R}^+}")#text(". Thus there is a close relationship between holomorphic extension and distribution of the Fourier transform.")

#text("Fix ")#mi("{\\varepsilon > 0}")#text(" (we could rescale ")#mi("{\\varepsilon}")#text(" to be, say, ")#mi("{1}")#text(", but we will not have need of this normalization). We can truncate and define")

#align(center)[#tao-fit-display[#tao-math("{\\mathcal C}_{\\varepsilon,R} f(x) = \\frac{1}{2\\pi i} \\int_{\\bf R} \\frac{f(y)}{y - (x - i\\varepsilon)} 1_{\\left|y-x\\right| < R}\\ dy;", block: true)]]

#text("more dominated convergence shows that ")#mi("{{\\mathcal C}_{\\varepsilon,R} f}")#text(" converges to ")#mi("{{\\mathcal C}_{\\varepsilon} f}")#text(" in ")#mi("{L^2}")#text(" as ")#mi("{R \\rightarrow +\\infty}")#text(" and so it will suffice to show that the Fourier coefficients of ")#mi("{{\\mathcal C}_{\\varepsilon,R} f}")#text(" converge pointwise to zero as ")#mi("{R \\rightarrow +\\infty}")#text(" on the half-line ")#mi("{\\xi > 0}")#text(". From Fubini’s theorem we easily compute")

#align(center)[#tao-fit-display[#tao-math("\\widehat{{\\mathcal C}_{\\varepsilon,R} f}(\\xi) = \\frac{1}{2\\pi i} \\hat f(\\xi) \\int_{\\bf R} \\frac{e^{-2\\pi i y \\xi}}{-(y - i\\varepsilon)} 1_{\\left|y\\right| < R}\\ dy;", block: true)]]

#text("but then by shifting the contour to the lower semicircle of radius ")#mi("{R}")#text(" and then letting ")#mi("{R \\rightarrow \\infty}")#text(" we obtain the claim. ")#mi("\\Box")

#text("From this proposition and Plancherel’s theorem we conclude that ")#mi("{H}")#text(" is an isometry:")

#align(center)[#tao-fit-display[#tao-math("\\left\\|H f \\right\\|_{L^2({\\bf R})} = \\left\\|f\\right\\|_{L^2({\\bf R})} \\text{ for all } f \\in \\mathcal{S}({\\bf R}).", block: true)]]

#text("Because of this, ")#mi("{H}")#text(" has a unique dense extension to ")#mi("{L^2({\\bf R})}")#text(", and (by another application of Plancherel’s theorem to justify taking the limit) the formula ")#link(<tao-64da817f607e940546c5>)[#text("(3)")]#text(" is valid for all ")#mi("{f \\in L^2({\\bf R})}")#text(". There is still the question of whether the original definition is valid for ")#mi("{f \\in L^2({\\bf R})}")#text(", or in other words whether the sequence of functions")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\pi} \\int_{\\left|t\\right| > \\varepsilon} \\frac{f(x-t)}{t}\\ dt", block: true)]]

#text("(note that Cauchy–Schwarz ensures that the integrand is absolutely integrable) converges as ")#mi("{\\varepsilon \\rightarrow 0}")#text(" to ")#mi("{Hf}")#text(" for ")#mi("{f \\in L^2({\\bf R})}")#text(", and in what sense this convergence holds. It turns out that the convergence is true both pointwise almost everywhere and in the ")#mi("{L^2({\\bf R})}")#text(" metric sense, and in fact it follows from variants of the Calderón–Zygmund theory presented in this notes, but we shall not do so here (as it may be covered in the participating student seminar).")

#text("From ")#link(<tao-64da817f607e940546c5>)[#text("(3)")]#text(" we also see that we do indeed have the identity ")#mi("{H^2 = -1}")#text(" on ")#mi("{L^2({\\bf R})}")#text(", and that ")#mi("{H}")#text(" is indeed skew-adjoint on ")#mi("{L^2({\\bf R})}")#text(" (")#mi("{H^* = -H}")#text("); in particular, ")#mi("{H}")#text(" is unitary.")

#text("Let us briefly mention why the Hilbert transform is also connected to the theory of partial Fourier integrals, via the modulation operators")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Mod}_N f(x) := e^{2\\pi i Nx} f(x).")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5")]#text(" ")#metadata(none) <tao-3aaad54f1dfef2decf01>#text(" Let ")#mi("{f \\in L^2({\\bf R})}")#text(" and ")#mi("{N_+, N_- \\in {\\bf R}}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\int_{-N_-}^{N_+} \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi = \\frac{i}{2} (\\mathrm{Mod}_{N_+} H \\mathrm{Mod}_{-N_+} f - \\mathrm{Mod}_{-N_-} H \\mathrm{Mod}_{N_-} f).")]]
]

#emph[#text("Proof:")]#text(" By limiting arguments (and because everything is continuous on ")#mi("{L^2({\\bf R})}")#text(") it suffices to verify this identity for ")#mi("{f}")#text(" in the Schwartz class. But then the claim follows by taking the Fourier transform of both sides and using ")#link(<tao-64da817f607e940546c5>)[#text("(3)")]#text(". ")#mi("\\Box")

#text("It is thus clear that in order to address the question of the extent to which the partial Fourier integrals ")#mi("{\\int_{-N_-}^{N_+} \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi }")#text(" actually converges back to ")#mi("{f}")#text(", we will need to understand the properties of the Hilbert transform, and in particular its boundedness properties.")

#text("The formula ")#link(<tao-64da817f607e940546c5>)[#text("(3)")]#text(" suggests that ")#mi("{H}")#text(" behaves “like” multiplication by ")#mi("{\\pm i}")#text(" in some sense; informally, ")#mi("{H}")#text(" behaves like ")#mi("{-i}")#text(" for positive frequency functions and ")#mi("{+i}")#text(" for negative frequency functions. Now multiplication by ")#mi("{\\pm i}")#text(" is a fairly harmless operation – it is bounded on every normed vector space – so one might expect ")#mi("{H}")#text(" to similarly be bounded on more normed spaces than just ")#mi("{L^2({\\bf R})}")#text("; in particular, it might be bounded on ")#mi("{L^p({\\bf R})}")#text(". This is indeed the case for ")#mi("{1 < p < \\infty}")#text(", and we now turn to the theory which will generate such bounds.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Demonstrate by example that the Hilbert transform is not bounded on ")#mi("{L^1({\\bf R})}")#text(" or ")#mi("{L^\\infty({\\bf R})}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 2. Calderón–Zygmund theory — ")]]

#text("In the Hilbert transform, we have an operator which is bounded on ")#mi("{L^2({\\bf R})}")#text(", and we wish to extend this boundedness to other ")#mi("{L^p({\\bf R})}")#text(" spaces as well. This is of course not automatic – the “enemy” is that the operator might map a broad shallow function into a tall narrow function of comparable ")#mi("{L^2}")#text(" norm (which will increase the ")#mi("{L^p}")#text(" norms markedly for all ")#mi("{p > 2}")#text("), or conversely map a tall narrow function down to a broad shallow function of comparable ")#mi("{L^2}")#text(" norm (which will increase the ")#mi("{L^p}")#text(" norms markedly for ")#mi("{p < 2}")#text("). It turns out that these two phenomena are more or less dual to each other, and so when working with an operator which is “comparable” to its adjoint (which is for instance the case with the skew-adjoint Hilbert transform, ")#mi("{H^* = -H}")#text(") eliminating one of these enemies will automatically remove the other.")

#text("For operators such as the Hilbert transform, there are at least two approaches to exclude these scenarios. One is to exploit the phenomenon that if ")#mi("{f}")#text(" is not too large locally, then ")#mi("{Hf}")#text(" also doesn’t fluctuate too much locally; this prevents the “broad shallow to tall narrow” enemy which blocks boundedness for large ")#mi("{p}")#text(". The dual approach is to show that if ")#mi("{f}")#text(" is localized and fluctuating, then ")#mi("{Hf}")#text(" is also localized; this prevents the “tall narrow to broad shallow” enemy which blocks boundedness for small ")#mi("{p}")#text(". (There are also more algebraic methods, relying on explicit formulae for things like the ")#mi("{L^4}")#text(" norm of ")#mi("{Hf}")#text(", or of the size of level sets of ")#mi("{H1_E}")#text(" for various sets ")#mi("{E}")#text(", but we will not discuss those here as they do not extend well to the more general class of singular kernels considered here.)")

#text("We shall first discuss the latter approach, which is the traditional approach to the subject, and return to the former approach later. We shall generalize from the Hilbert transform to a useful wider class of operators, which are integral operators “away from the diagonal”. To motivate this concept, observe that if ")#mi("{f \\in L^2({\\bf R})}")#text(" is compactly supported and ")#mi("{y}")#text(" lies outside of the support of ")#mi("{f}")#text(", then")

#align(center)[#tao-fit-display[#mitex("Hf(y) = \\int_{\\bf R} \\frac{1}{\\pi(y-x)} f(x)\\ dx,")]]

#text("the point being that the integral is now absolutely convergent, Thus while ")#mi("{H}")#text(" is not, strictly speaking, an integral operator of the type studied in preceding sections, it can be described as such as long as one avoids the diagonal ")#mi("{x=y}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 7 (Singular kernels)")]#text(" A ")#emph[#text("singular kernel")]#text(" is a function ")#mi("{K: {\\bf R}^d \\times {\\bf R}^d \\rightarrow {\\bf C}}")#text(" (defined away from the diagonal ")#mi("{x=y}")#text(") which obeys the decay estimate")

#metadata(none) <tao-854391e53e480b621e0b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|K(x,y)\\right| \\lesssim \\left|x-y\\right|^{-d}", block: true)]]

#text("for ")#mi("{x \\neq y}")#text(" and the Hölder-type regularity estimates")

#metadata(none) <tao-c16ecf95fcaae6b03016>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("K(x,y^{\\prime}) = K(x,y) + O\\left( \\frac{\\left|y-y^{\\prime}\\right|^\\sigma}{\\left|x-y\\right|^{d+\\sigma}} \\right) \\text{ whenever } \\left|y-y^{\\prime}\\right| \\leq \\frac{1}{2} \\left|x-y\\right|", block: true)]]

#text("and")

#metadata(none) <tao-5fd48b02a4abd5240452>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("K(x^{\\prime},y) = K(x,y) + O\\left( \\frac{\\left|x-x^{\\prime}\\right|^\\sigma}{\\left|x-y\\right|^{d+\\sigma}} \\right) \\text{ whenever } \\left|x-x^{\\prime}\\right| \\leq \\frac{1}{2} \\left|x-y\\right|", block: true)]]

#text("for some ")#emph[#text("Hölder exponent")]#text(" ")#mi("{0 < \\sigma \\leq 1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 8")]#text(" In one dimension, ")#mi("{\\frac{1}{x-y}}")#text(" and ")#tao-math("{\\frac{1}{\\left|x-y\\right|}}", block: false)#text(" are both singular kernels. In higher dimensions, the kernel ")#tao-math("{K(x,y) := \\Omega\\left(\\frac{x-y}{\\left|x-y\\right|}\\right) / \\left|x-y\\right|^d}", block: false)#text(" is a singular kernel whenever ")#mi("{\\Omega: S^{d-1} \\rightarrow {\\bf C}}")#text(" is a Hölder-continuous function.")
]

#text("The regularity estimates may seem strange at first sight, although the fundamental theorem of calculus shows that these estimates would follow (with ")#mi("{\\sigma=1}")#text(") from the estimates")

#align(center)[#tao-fit-display[#tao-math("\\nabla_x K(x,y), \\nabla_y K(x,y) = O( \\left|x-y\\right|^{-d-1} );", block: true)]]

#text("given that the gradient of ")#tao-math("{\\left|x-y\\right|^{-d}}", block: false)#text(" is ")#tao-math("{O( \\left|x-y\\right|^{-d-1} )}", block: false)#text(", these estimates are then consistent with ")#link(<tao-854391e53e480b621e0b>)[#text("(4)")]#text(" but of course do not follow from it. In most applications one can take ")#mi("{\\sigma = 1}")#text(" (in which case the Hölder type conditions become Lipschitz type conditions). It is more desirable ")#link(<tao-c16ecf95fcaae6b03016>)[#text("(5)")]#text(", ")#link(<tao-5fd48b02a4abd5240452>)[#text("(6)")]#text(" for large ")#mi("{\\sigma}")#text(" than for small ")#mi("{\\sigma}")#text(" (note in particular that the ")#mi("{\\sigma=0}")#text(" version of the estimate already follows from ")#link(<tao-854391e53e480b621e0b>)[#text("(4)")]#text("). It is possible to weaken the Hölder type conditions further, but there are few applications that require such a weakening and so we shall stay with the Hölder condition. The factor ")#mi("{\\frac{1}{2}}")#text(" is not significant; it is not hard to show that the regularity conditions are equivalent to the condition in which ")#mi("{\\frac{1}{2}}")#text(" is replaced by any other constant strictly between zero and one.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 9 (Calderón–Zygmund operators)")]#text(" A ")#emph[#text("Calderón–Zygmund operator")]#text(" (CZO) is a linear operator ")#mi("{T: L^2({\\bf R}^d) \\rightarrow L^2({\\bf R}^d)}")#text(" which is bounded on ")#mi("{L^2({\\bf R}^d)}")#text(",")

#align(center)[#tao-fit-display[#tao-math("\\left\\|Tf\\right\\|_{L^2({\\bf R}^d)} \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R}^d)},", block: true)]]

#text("and such that there exists a singular kernel ")#mi("{K}")#text(" for which")

#align(center)[#tao-fit-display[#mitex("Tf(y) = \\int_{{\\bf R}^d} K(x,y) f(x)\\ dx")]]

#text("whenever ")#mi("{f \\in L^2({\\bf R}^d)}")#text(" is compactly supported, and ")#mi("{y}")#text(" lies outside of the support of ")#mi("{f}")#text(".")
]

#text("It is not hard to see that ")#mi("{T}")#text(" uniquely determines ")#mi("{K}")#text(". However the converse is not true; for instance, given any bounded function ")#mi("{b: {\\bf R}^d \\rightarrow {\\bf C}}")#text(", the physical space multiplier ")#mi("{Tf := bf}")#text(" is a CZO with kernel ")#mi("{0}")#text(". However, this is the only source of ambiguity; see Exercise ")#link(<tao-8845886be6cbcf285d18>)[#text("18")]#text(". A CZO is an example of a ")#emph[#text("singular integral operator")]#text("; the kernel ")#mi("{K}")#text(" just barely fails to be locally integrable (Schur’s test, for instance, encounters a logarithmic divergence), and so there is a singularity in the integration which must be understood in order to analyze ")#mi("{T}")#text(" correctly. In particular, not all singular kernels ")#mi("{K}")#text(" lead to an CZO, due to possible failure of ")#mi("{L^2}")#text(" boundedness. We will return to the question of working out which kernels do give CZOs later.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" As with the theory of the Hardy–Littlewood maximal function, one can define CZOs on more general homogeneous spaces than ")#mi("{{\\bf R}^d}")#text(", but we will not do so here for sake of concreteness.")
]

#text("By convention, we allow all implied constants in what follows to depend on the Hölder exponent ")#mi("{\\sigma}")#text(" and on the implied constants in ")#link(<tao-854391e53e480b621e0b>)[#text("(4)")]#text(", ")#link(<tao-c16ecf95fcaae6b03016>)[#text("(5)")]#text(", ")#link(<tao-5fd48b02a4abd5240452>)[#text("(6)")]#text(" and the operator norm bound on ")#mi("{T}")#text(". (One could try to formalize things by imposing a norm on CZOs with a given exponent ")#mi("{\\sigma}")#text(", but this gets a bit confusing and is largely unnecessary since one mostly deals with just a single CZO at a time.)")

#text("The Hilbert transform is thus a CZO, with kernel ")#mi("{K(x,y) = \\frac{1}{\\pi(y-x)}}")#text(". We will discuss other examples of CZOs, such as the Riesz transforms, Hörmander–Mikhlin multipliers, and pseudodifferential operators of order zero, later on.")

#text("The Hilbert transform was skew-adjoint, translation-invariant, and scale-invariant. In general, CZOs are neither. However, the ")#emph[#text("class")]#text(" of CZOs is self-adjoint (and skew-adjoint), translation-invariant, and scale-invariant; if ")#mi("{T}")#text(" is a CZO then so is ")#mi("{T^*}")#text(", and the translates ")#mi("{\\mathrm{Trans}_{x_0} T \\mathrm{Trans}_{-x_0}}")#text(" and dilates ")#mi("{\\mathrm{Dil}^p_{1/\\lambda} T \\mathrm{Dil}^p_\\lambda}")#text(" of ")#mi("{T}")#text(" are also CZOs uniformly in ")#mi("{\\lambda > 0}")#text(" and ")#mi("{x_0 \\in {\\bf R}^d}")#text(". (What happens to the kernels ")#mi("{K}")#text(" in each case?)")

#text("Now we formalize the key phenomenon alluded to earlier, that CZOs map fluctuating localized functions to nearly localized functions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11")]#text(" ")#metadata(none) <tao-2374d91794b79f4fb4ec>#text(" Let ")#mi("{B = B(x_0,r)}")#text(" be a ball in ")#mi("{{\\bf R}^d}")#text(", let ")#mi("{T}")#text(" be a CZO, and let ")#mi("{f \\in L^1(B)}")#text(" have mean zero, thus ")#mi("{\\int_B f = 0}")#text(". Then we have the pointwise bound")

#align(center)[#tao-fit-display[#tao-math("\\left|Tf(y)\\right| \\lesssim_d \\frac{r^{\\sigma}}{\\left|y-x_0\\right|^{d+\\sigma}} \\int_B |f| \\text{ for all } y \\not \\in 2B.", block: true)]]

#text("In particular, we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Tf \\right\\|_{L^1({\\bf R}^d \\backslash 2B )} \\lesssim_d \\left\\|f\\right\\|_{L^1(B)}.", block: true)]]
]

#emph[#text("Proof:")]#text(" We remark that we could use the translation and scaling symmetries of CZOs to normalize ")#mi("{(x_0,r) =(0,1)}")#text(", but we shall not do so here. For ")#mi("{y \\not \\in 2B}")#text(" we can use the mean zero hypothesis to obtain")

#align(center)[#tao-fit-display[#mitex("Tf(y) = \\int_B K(x,y) f(x)\\ dx = \\int_B [ K(x,y) - K(x_0,y) ] f(x)\\ dx,")]]

#text("and the first claim then follows from ")#link(<tao-c16ecf95fcaae6b03016>)[#text("(5)")]#text(" and the triangle inequality. The second claim of course follows from the first (recall we allow our implied constants to depend on ")#mi("{\\sigma}")#text(" and ")#mi("{d}")#text("). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 12")]#text(" Observe that the argument also gives the slightly more general estimate")

#metadata(none) <tao-af1b7d044d3d13adf06c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("Tf(y) = K(x_0,y) \\int_B f + O\\left( \\frac{r^{\\sigma}}{\\left|y-x_0\\right|^{d+\\sigma}} \\int_B \\left|f\\right| \\right) \\text{ for all } y \\not \\in 2B", block: true)]]

#text("when the mean zero condition ")#mi("{\\int_B f = 0}")#text(" is dropped.")
]

#text("This lemma asserts that ")#mi("{T}")#text(" is sort of bounded on ")#mi("{L^1}")#text(" – but only when the input function is localized and mean zero, and as long as one doesn’t look too closely at the region near the support of the function. This extremely conditional ")#mi("{L^1}")#text(" boundedness is a far cry from true ")#mi("{L^1}")#text(" boundedness; indeed, it is not hard to show that ")#mi("{L^1}")#text(" boundedness can fail. However, Lemma ")#link(<tao-2374d91794b79f4fb4ec>)[#text("11")]#text(", combined with the Calderón–Zygmund decomposition from the previous section (which decomposes any function into a bounded part and a lot of localized, fluctuating parts) is strong enough to obtain the weak-type boundedness instead.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 13")]#text(" All CZOs are of weak type ")#mi("{(1,1)}")#text(", with an operator norm of ")#mi("{O_d(1)}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{f \\in L^1({\\bf R}^d) \\cap L^2({\\bf R}^d)}")#text(" (the ")#mi("{L^2}")#text(" condition ensuring that ")#mi("{T}")#text(" is well-defined), let ")#mi("{T}")#text(" be a CZO, and let ")#mi("{\\lambda > 0}")#text(". Our task is to show that")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ \\left|Tf\\right| \\geq \\lambda \\}\\right| \\lesssim_d \\frac{\\left\\|f\\right\\|_{L^1({\\bf R}^d)}}{\\lambda}.", block: true)]]

#text("We spend scaling and homogeneity symmetries to normalize ")#tao-math("{\\left\\|f\\right\\|_{L^1({\\bf R}^d)}}", block: false)#text(" and ")#mi("{\\lambda}")#text(" to both be ")#mi("{1}")#text("; this avoids a certain amount of book-keeping regarding these factors later. Applying the Calderón–Zygmund decomposition, we can split ")#mi("{f = g + \\sum_{Q \\in \\mathcal{Q}} b_Q}")#text(", where the “good” function ")#mi("{g}")#text(" obeys the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_{L^1({\\bf R}^d)}, \\left\\|g\\right\\|_{L^\\infty({\\bf R}^d)} \\lesssim_d 1,", block: true)]]

#text("each ")#mi("{b_Q}")#text(" is supported on ")#mi("{Q}")#text(", has mean zero, and has the ")#mi("{L^1}")#text(" bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\|b_Q \\right\\|_{L^1({\\bf R}^d)} \\lesssim_d \\left|Q\\right|,", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\sum_{Q \\in \\mathcal{Q}} \\left|Q\\right| \\lesssim_d 1.", block: true)]]

#text("Now since ")#mi("{Tf = Tg + \\sum_{Q \\in \\mathcal{Q}} T b_Q}")#text(", we can split")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ \\left|Tf\\right| \\geq 1 \\}\\right| \\leq \\left| \\{ \\left|Tg\\right| \\geq 1/2 \\}\\right| + \\left| \\{ \\sum_{Q \\in \\mathcal{Q}} \\left|Tb_Q\\right| \\geq 1/2 \\}\\right|.", block: true)]]

#text("For the first term, we exploit the ")#mi("{L^2}")#text(" boundedness of ")#mi("{T}")#text(" via Chebyshev’s inequality and log-convexity of Hölder norms:")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ \\left|Tg\\right| \\geq 1/2 \\}\\right| \\lesssim_d \\left\\|Tg\\right\\|_{L^2({\\bf R}^d)}^2 \\lesssim_d \\left\\|g\\right\\|_{L^2({\\bf R}^d)}^2 \\lesssim_d \\left\\|g\\right\\|_{L^1({\\bf R}^d)} \\left\\|g\\right\\|_{L^\\infty({\\bf R}^d)} \\lesssim_d 1.", block: true)]]

#text("For the second term, we cannot rely on ")#mi("{L^2}")#text(" bounds because the ")#mi("{b_Q}")#text(" have no reason to be bounded in ")#mi("{L^2}")#text(". But the mean zero condition, combined with Lemma ")#link(<tao-2374d91794b79f4fb4ec>)[#text("11")]#text(", shows that each ")#mi("{Tb_Q}")#text(" has ")#mi("{L^1}")#text(" bounds outside of a dilate ")#mi("{CQ}")#text(" of ")#mi("{Q}")#text(" (for some fixed constant ")#mi("{C}")#text(" depending only on ")#mi("{d}")#text(");")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Tb_Q \\right\\|_{L^1({\\bf R}^d \\backslash CQ)} \\lesssim_d \\left\\|b_Q \\right\\|_{L^1(Q)} \\lesssim_d |Q|.", block: true)]]

#text("(Actually one could take ")#mi("{C}")#text(" arbitrarily close to ")#mi("{1}")#text(" by iterating ")#link(<tao-c16ecf95fcaae6b03016>)[#text("(5)")]#text(", ")#link(<tao-5fd48b02a4abd5240452>)[#text("(6)")]#text(" to obtain a variant of Lemma ")#link(<tao-2374d91794b79f4fb4ec>)[#text("11")]#text(", but we will not do so here.).")

#text("Restricting to the common domain ")#mi("{{\\bf R}^d \\backslash \\bigcup_{Q \\in \\mathcal{Q}} CQ}")#text(" and summing in ")#mi("{Q}")#text(" using the triangle inequality we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{Q \\in \\mathcal{Q}} Tb_Q \\right\\|_{L^1({\\bf R}^d \\backslash \\bigcup_{Q \\in \\mathcal{Q}} CQ)} \\lesssim_d \\sum_{Q \\in \\mathcal{Q}} \\left|Q\\right| \\lesssim_d 1", block: true)]]

#text("and hence by Chebyshev")

#align(center)[#tao-fit-display[#tao-math("\\left|\\left\\{ x \\in {\\bf R}^d \\backslash \\bigcup_{Q \\in \\mathcal{Q}} CQ: \\left|\\sum_{Q \\in \\mathcal{Q}} Tb_Q\\right| \\geq \\frac{1}{2} \\right\\}\\right| \\lesssim_d 1.", block: true)]]

#text("This still leaves the question of what happens in the exceptional set ")#mi("{\\bigcup_{Q \\in \\mathcal{Q}} CQ}")#text(". But here is the great advantage of weak-type estimates: we can tolerate arbitrarily bad behavior as long as it is localized to small sets. Indeed we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\bigcup_{Q \\in \\mathcal{Q}} CQ\\right| \\leq \\sum_{Q \\in \\mathcal{Q}} \\left|CQ\\right| \\lesssim_d \\sum_{Q \\in \\mathcal{Q}} \\left|Q\\right| \\lesssim_d 1.", block: true)]]

#text("Putting it all together, we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ \\left|Tf\\right| \\geq 1 \\}\\right| \\lesssim_d 1", block: true)]]

#text("as desired. ")#mi("\\Box")

#text("Combining this with Marcinkiewicz interpolation and the ")#mi("{L^2}")#text(" boundedness hypothesis gives that all CZOs are of strong-type ")#mi("{(p,p)}")#text(" for ")#mi("{1 < p \\leq 2}")#text(". The self-adjointness of the CZOs ")#emph[#text("as a class")]#text(" then gives the same statement for ")#mi("{2 \\leq p < \\infty}")#text(", thus we have proven")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 14")]#text(" ")#metadata(none) <tao-ee2c824064e426becdf2>#text(" CZOs are of strong type ")#mi("{(p,p)}")#text(" for all ")#mi("{1 < p < \\infty}")#text(", with an operator norm of ")#mi("{O_{d,p}(1)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 15")]#text(" We thus see that the localizing properties of the singular kernel ")#mi("{K}")#text(" allow one to automatically leverage ")#mi("{L^2}")#text(" boundedness into ")#mi("{L^p}")#text(" boundedness for ")#mi("{1 < p < \\infty}")#text(". In fact there is nothing particularly special about ")#mi("{L^2}")#text(" here (Exercise ")#link(<tao-9fc58f1abf0d4f134609>)[#text("19")]#text("). But in practice ")#mi("{L^2}")#text(" boundedness is easier to obtain than other types of boundedness.")
]

#text("In particular, we see that the Hilbert transform is bounded on ")#mi("{L^p({\\bf R})}")#text(" for ")#mi("{1 < p < \\infty}")#text(" (or more precisely, it is bounded on a dense subclass, and thus has a unique bounded extension). This does not by itself directly settle the question of whether the formula ")#link(<tao-bd36e2455121f8ffec77>)[#text("(1)")]#text(" makes sense for ")#mi("{L^p}")#text(" functions in a norm or pointwise convergence sense (for that, one needs bounds on the truncated Hilbert transforms and the maximal truncated maximal Hilbert transforms), though it does lend confidence that this is the case. However, we can now easily conclude an analogous claim for the inversion formula.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 16")]#text(" Let ")#mi("{1 < p < \\infty}")#text(", and for every ")#mi("{N > 0}")#text(" let ")#mi("{S_N}")#text(" be the Dirichlet summation operator, defined on Schwartz functions ")#mi("{f \\in \\mathcal{S}({\\bf R})}")#text(" by")

#align(center)[#tao-fit-display[#mitex("S_N f(x) := \\int_{-N}^N \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi.")]]

#text("Then ")#mi("{S_N}")#text(" extends uniquely to a bounded operator on ")#mi("{L^p({\\bf R})}")#text(", and ")#mi("{S_N f}")#text(" converges in ")#mi("{L^p}")#text(" norm to ")#mi("{f}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(" for all ")#mi("{f \\in L^p({\\bf R})}")#text(".")
]

#emph[#text("Proof:")]#text(" From Proposition ")#link(<tao-3aaad54f1dfef2decf01>)[#text("5")]#text(" we obtain the identity")

#align(center)[#tao-fit-display[#mitex("S_N f = \\frac{i}{2} (\\mathrm{Mod}_{N} H \\mathrm{Mod}_{-N} f - \\mathrm{Mod}_{-N} H \\mathrm{Mod}_{N} f)")]]

#text("and so the ")#mi("{S_N}")#text(" are uniformly bounded on ")#mi("{L^p({\\bf R})}")#text(" as desired. (Note however that the ")#mi("{S_N}")#text(" are not CZOs, since modulation does not preserve the CZO class.) Since ")#mi("{S_N f}")#text(" converges in ")#mi("{L^p}")#text(" norm to ")#mi("{f}")#text(" for Schwartz functions (by dominated convergence), the claim then follows by the usual limiting arguments. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 17")]#text(" The corresponding question about pointwise almost-everywhere convergence is the ")#link("https://en.wikipedia.org/wiki/Carleson%27s_theorem")[#text("Carleson–Hunt theorem")]#text(", which is quite difficult. When ")#mi("{p=1}")#text(" an ")#link("https://zbmath.org/?q=an:49.0205.02")[#text("example of Kolmogorov")]#text(" shows that both norm convergence and almost-everywhere convergence can fail. In higher dimensions, the norm convergence for ")#mi("{p=2}")#text(" is true by Plancherel’s theorem, but a surprising ")#link("https://zbmath.org/?q=an:0234.42009")[#text("result of Fefferman")]#text(" shows that it fails for ")#mi("{p \\neq 2}")#text(". The almost everywhere convergence problem remains open (and is considered very difficult) in higher dimensions.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" ")#metadata(none) <tao-8845886be6cbcf285d18>#text(" Let ")#mi("{T}")#text(" and ")#mi("{T^{\\prime}}")#text(" be two CZOs with the same kernel ")#mi("{K}")#text(". Show that there exists a bounded function ")#mi("{b \\in L^\\infty({\\bf R}^d)}")#text(" such that ")#mi("{Tf = T^{\\prime} f + bf}")#text(" for all ")#mi("{f \\in L^2({\\bf R}^d)}")#text(". (Hint: by subtraction we can assume ")#mi("{T^{\\prime}=0}")#text(" and ")#mi("{K=0}")#text(". Now observe that ")#mi("{E \\mapsto \\langle T 1_E, 1_E \\rangle}")#text(" is an absolutely continuous measure, and use the Radon–Nikodym theorem.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" ")#metadata(none) <tao-9fc58f1abf0d4f134609>#text(" Show that if we redefine the notion of a CZO by weakening the hypothesis of ")#mi("{L^2({\\bf R}^d)}")#text(" boundedness, to merely being of restricted weak-type ")#mi("{(p_0,p_0)}")#text(" for some ")#mi("{1 < p_0 < \\infty}")#text(", then Corollary ")#link(<tao-ee2c824064e426becdf2>)[#text("14")]#text(" remains unchanged (but with an operator norm of ")#mi("{O_{p_0}(1)}")#text(" instead of ")#mi("{O(1)}")#text(". In particular this apparent expansion of the notion of a CZO does not in fact increase the class of CZOs (up to changes in the implied constants).")
]

#heading(level: 1)[#strong[#text(" — 3. Bounded mean oscillation — ")]]

#text("Let us now study what a CZO ")#mi("{T}")#text(" does on the endpoint space ")#mi("{L^\\infty({\\bf R}^d)}")#text(". At first glance things are rather bad; not only is ")#mi("{T}")#text(" unbounded on ")#mi("{L^\\infty({\\bf R}^d)}")#text(" in general, ")#mi("{T}")#text(" is not even known yet to be defined on a dense subset of ")#mi("{L^\\infty({\\bf R}^d)}")#text(". Nevertheless, a closer inspection of things will show that ")#mi("{T}")#text(" actually does have a fairly reasonable definition on ")#mi("{L^\\infty({\\bf R}^d)}")#text(", up to constants.")

#text("Let us try to define ")#mi("{Tf}")#text(" for ")#mi("{f \\in L^\\infty({\\bf R}^d)}")#text(" directly. A naive implementation of the kernel formula")

#align(center)[#tao-fit-display[#mitex("Tf(y) = \\int_{{\\bf R}^d} K(x,y) f(x)\\ dx")]]

#text("runs into problems both for ")#mi("{x}")#text(" near ")#mi("{y}")#text(", and ")#mi("{x}")#text(" near infinity, since the decay ")#link(<tao-854391e53e480b621e0b>)[#text("(4)")]#text(" is not strong enough to give absolute integrability in either case. Localizing ")#mi("{f}")#text(" to be supported away from ")#mi("{y}")#text(" helps with the first problem, but not the second. But suppose we instead looked at the difference ")#mi("{Tf(y) - Tf(y^{\\prime})}")#text(" between ")#mi("{Tf}")#text(" at two values. Then we formally have")

#align(center)[#tao-fit-display[#mitex("Tf(y) - Tf(y^{\\prime}) = \\int_{{\\bf R}^d} (K(x,y) - K(x,y^{\\prime})) f(x)\\ dx.")]]

#text("Now ")#link(<tao-c16ecf95fcaae6b03016>)[#text("(5)")]#text(" implies that for fixed ")#mi("{y,y^{\\prime}}")#text(", the expression ")#mi("{K(x,y) - K(x,y^{\\prime})}")#text(" decays like ")#tao-math("{\\left|x\\right|^{-d-\\sigma}}", block: false)#text(" as ")#mi("{x \\rightarrow \\infty}")#text(", and so the integral will be absolutely integrable as long as ")#mi("{f}")#text(" vanishes near ")#mi("{y}")#text(" and ")#mi("{y^{\\prime}}")#text(". At the other extreme, if ")#mi("{f}")#text(" is compactly supported, then it lies in ")#mi("{L^2({\\bf R}^d)}")#text(" and there is no difficulty defining ")#mi("{Tf(y)-Tf(y^{\\prime})}")#text(" (up to the usual measure zero ambiguities).")

#text("Motivated by this, let us make the following definitions. We say that two functions ")#mi("{f, g: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" are ")#emph[#text("equivalent modulo a constant")]#text(" if there exists a complex number ")#mi("{C}")#text(" such that ")#mi("{f(x)-g(x) = C}")#text(" for almost every ")#mi("{x}")#text("; this is of course an equivalence relation. Given ")#mi("{f \\in L^\\infty({\\bf R}^d)}")#text(", we define ")#mi("{Tf}")#text(" to be the equivalence class associated to the function")

#align(center)[#tao-fit-display[#mitex("Tf(y) := T(f1_B)(y) + \\int_{{\\bf R}^d \\backslash B} (K(x,y)-K(x,0)) f(x)\\ dx")]]

#text("where ")#mi("{B = B_y}")#text(" is any ball which contains both ")#mi("{y}")#text(" and ")#mi("{0}")#text("; it is not hard to see that the right-hand side is well-defined (in particular, the integral is absolutely convergent) and is independent (modulo a constant) of the choice of ")#mi("{B}")#text(", and that ")#mi("{T}")#text(" remains linear. One can also check that this definition is consistent (modulo a constant) with the existing definition of ")#mi("{T}")#text(" on ")#mi("{L^2({\\bf R}^d)}")#text(" (or on ")#mi("{L^p({\\bf R}^d)}")#text(") on the common domain of definition (i.e. ")#mi("{L^2({\\bf R}^d) \\cap L^\\infty({\\bf R}^d)}")#text(" or ")#mi("{L^p({\\bf R}^d) \\cap L^\\infty({\\bf R}^d)}")#text(").")

#text("Because ")#mi("{Tf}")#text(" is only defined modulo a constant, we cannot meaningfully control it in standard norms such as ")#mi("{L^p}")#text(". However, there is a norm which is suitable for this type of function.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 20 (Bounded mean oscillation)")]#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be a function defined modulo a constant. The ")#mi("{\\mathrm{BMO}}")#text(" (or ")#link("https://en.wikipedia.org/wiki/Bounded_mean_oscillation")[#text("Bounded Mean Oscillation")]#text(") norm of ")#mi("{f}")#text(" is defined as")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{\\mathrm{BMO}} := \\sup_{B} \\frac{1}{\\left|B\\right|} \\int_B \\left| f - \\frac{1}{\\left|B\\right|} \\int_B f \\right|", block: true)]]

#text("where ")#mi("{B}")#text(" ranges over all balls. Note that if one shifts ")#mi("{f}")#text(" by a constant, the ")#mi("{\\mathrm{BMO}}")#text(" norm is unchanged, so this norm is well-defined for functions defined modulo constants. We denote by ")#mi("{\\mathrm{BMO}({\\bf R}^d)}")#text(" the space of all functions with finite ")#mi("{\\mathrm{BMO}}")#text(" norm, modulo constants.")
]

#text("It is not hard to verify that this is indeed a norm (but note that one has to quotient out by constants before this is the case!), and that ")#mi("{\\mathrm{BMO}({\\bf R}^d)}")#text(" is a Banach space. One can also easily check using the triangle inequality that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|B\\right|} \\int_B \\left| f - \\frac{1}{\\left|B\\right|} \\int_B f \\right| \\sim \\inf_c \\frac{1}{\\left|B\\right|} \\int_B \\left|f-c\\right|", block: true)]]

#text("where ")#mi("{c}")#text(" ranges over constants; thus the statement ")#tao-math("{\\left\\|f\\right\\|_\\mathrm{BMO} \\lesssim A}", block: false)#text(" is equivalent (up to changes in the implied constant) to the assertion that for any ball ")#mi("{B}")#text(" there exists a constant ")#mi("{c_B}")#text(" such that ")#tao-math("{\\frac{1}{\\left|B\\right|} \\int_B \\left|f-c_B\\right| \\lesssim A}", block: false)#text(", thus ")#mi("{f}")#text(" deviates from ")#mi("{c_B}")#text(" by at most ")#mi("{A}")#text(" on the average.")

#text("It is not hard to see that ")#mi("{\\mathrm{BMO}({\\bf R}^d)}")#text(" contains ")#mi("{L^\\infty({\\bf R}^d)}")#text(", and that ")#tao-math("{\\left\\|f\\right\\|_{\\mathrm{BMO}({\\bf R}^d)} \\lesssim \\left\\|f\\right\\|_{L^\\infty({\\bf R}^d)}}", block: false)#text(". But it also contains unbounded functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Verify that the function ")#tao-math("{\\log\\left|x\\right|}", block: false)#text(" is in ")#mi("{\\mathrm{BMO}({\\bf R}^d)}")#text(".")
]

#text("The primary significance of ")#mi("{\\mathrm{BMO}}")#text(" for Calderón–Zygmund theory is that it can serve as a substitute for ")#mi("{L^\\infty}")#text(", on which CZOs are often ill-behaved. Consider for instance the Hilbert transform applied (formally) to the signum function ")#mi("{\\mathrm{sgn}}")#text(". The resulting function is not bounded, but lies in ")#mi("{\\mathrm{BMO}}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Verify that using the previous definitions, ")#tao-math("{H \\mathrm{sgn} = \\frac{2}{\\pi} \\log \\left|x\\right|}", block: false)#text(" modulo constants.")
]

#text("This phenomenon applies more generally to all CZOs:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 23 (CZOs map ")#mi("{L^\\infty}")#text(" to ")#mi("{\\mathrm{BMO}}")#text(")")]#text(" ")#metadata(none) <tao-d0afe5ed2bd67151d4dd>#text(" Let ")#mi("{T}")#text(" be a CZO and ")#mi("{f \\in L^\\infty({\\bf R}^d)}")#text(". Then ")#mi("{Tf \\in \\mathrm{BMO}({\\bf R}^d)}")#text(" and")

#align(center)[#tao-fit-display[#tao-math("\\left\\|Tf\\right\\|_{\\mathrm{BMO}({\\bf R}^d)} \\lesssim_d \\left\\|f\\right\\|_{L^\\infty({\\bf R}^d)}.", block: true)]]
]

#emph[#text("Proof:")]#text(" We can normalize ")#tao-math("{\\left\\|f\\right\\|_{L^\\infty({\\bf R}^d)} = 1}", block: false)#text(". By definition of the ")#mi("{\\mathrm{BMO}}")#text(" norm, it suffices to show that for every ball ")#mi("{B}")#text(" there exists a constant ")#mi("{c_B}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|B\\right|} \\int_B \\left|Tf - c_B\\right| \\lesssim_d 1.", block: true)]]

#text("By translation and dilation symmetry we may take ")#mi("{B = B(0,1)}")#text(". We split ")#mi("{Tf = T(f 1_{2B}) + T(f 1_{{\\bf R}^d \\backslash 2B})}")#text(". Since ")#mi("{T}")#text(" is bounded on ")#mi("{L^2}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T(f 1_{2B}) \\right\\|_{L^2({\\bf R}^d)} \\lesssim_d \\left\\|f 1_{2B} \\right\\|_{L^2({\\bf R}^d)} \\lesssim_d 1", block: true)]]

#text("and hence by Hölder (or Cauchy–Schwarz)")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|B\\right|} \\int_B \\left|T(f1_{2B})\\right| \\lesssim_d 1.", block: true)]]

#text("This deals with the “local” part of ")#mi("{Tf}")#text(". For the “global” part, observe that for ")#mi("{x \\in B}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("T(f 1_{{\\bf R}^d \\backslash 2B})(x) = \\int_{\\left|y\\right| \\geq 2} (K(x,y)-K(0,y)) f(y) + c", block: true)]]

#text("for some arbitrary constant ")#mi("{c}")#text(". But by ")#link(<tao-5fd48b02a4abd5240452>)[#text("(6)")]#text(" we have ")#tao-math("{K(x,y)-K(0,y) = O( \\left|y\\right|^{-d-\\sigma})}", block: false)#text("; since ")#mi("{f}")#text(" is bounded by ")#mi("{O(1)}")#text(", we thus see that ")#mi("{T(f 1_{{\\bf R}^d \\backslash 2B})(x) = c + O(1)}")#text(", and so")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|B\\right|} \\int_B \\left|T(f 1_{{\\bf R}^d \\backslash 2B}) - c\\right| \\lesssim_d 1.", block: true)]]

#text("Adding the two facts, we obtain the claim. ")#mi("\\Box")

#text("In order to exploit this proposition, we need to understand to what extent BMO bounds on a function control its size. The basic insight here is that BMO bounds are “almost as good as” ")#mi("{L^\\infty}")#text(" control for many purposes, despite the logarithmically unbounded members of BMO such as ")#tao-math("{\\log \\left|x\\right|}", block: false)#text(".")

#text("Let us first work informally. Let ")#mi("{f}")#text(" be a real-valued BMO function, normalized so that ")#tao-math("{\\left\\|f\\right\\|_{\\mathrm{BMO}({\\bf R}^d)} = 1}", block: false)#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\int_B \\left|f - \\frac{1}{\\left|B\\right|} \\int_B f\\right| \\leq \\left|B\\right|", block: true)]]

#text("for all balls ")#mi("{B}")#text(". By Markov’s inequality, this means that")

#metadata(none) <tao-3eee7e474cae60f9c74b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left|\\left\\{ x \\in B: \\left|f(x) - \\frac{1}{\\left|B\\right|} \\int_B f\\right| \\geq \\lambda \\right\\}\\right| \\leq \\left|B\\right|/\\lambda", block: true)]]

#text("for any ")#mi("{\\lambda > 0}")#text(". Note that this bound is only non-trivial for ")#mi("{\\lambda > 1}")#text(", otherwise the trivial bound of ")#tao-math("{\\left|B\\right|}", block: false)#text(" is superior. It asserts, for instance, that ")#mi("{f}")#text(" only exceeds its average by (say) ")#mi("{10}")#text(" on at most ")#mi("{10\\%}")#text(" of any given ball.")

#text("It turns out that one can iterate the above fact to give far better estimates in the limit ")#mi("{\\lambda \\rightarrow \\infty}")#text(" that ")#link(<tao-3eee7e474cae60f9c74b>)[#text("(8)")]#text(" initially suggests. This is because of a basic principle in harmonic analysis: bad behavior on a small exceptional set (such as ")#mi("{10\\%}")#text(" of any given ball) can often be iterated away if we know that the exceptional sets are small ")#emph[#text("at every scale")]#text(". Roughly speaking, this principle allows us to say that ")#mi("{f}")#text(" only exceeds its average by ")#mi("{20}")#text(" on at most ")#mi("{10\\%}")#text(" of ")#mi("{10\\%}")#text(" of a given ball (i.e. on at most ")#mi("{1\\%}")#text(" of the ball), ")#mi("{f}")#text(" exceeds its average by ")#mi("{30}")#text(" on at most ")#mi("{0.1\\%}")#text(", and so forth, leading to a bound of the form ")#link(<tao-3eee7e474cae60f9c74b>)[#text("(8)")]#text(" which tails off exponentially in ")#mi("{\\lambda}")#text(" rather than polynomially. More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 24 (John–Nirenberg inequality)")]#text(" Let ")#mi("{f \\in \\mathrm{BMO}({\\bf R}^d)}")#text(". Then for any ball ")#mi("{B}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\left\\{ x \\in B: \\left|f(x) - \\frac{1}{\\left|B\\right|} \\int_B f\\right| \\geq \\lambda \\left\\|f\\right\\|_{\\mathrm{BMO}({\\bf R}^d)} \\right\\}\\right| \\lesssim_d e^{-c_d \\lambda} \\left|B\\right|", block: true)]]

#text("for all ")#mi("{\\lambda > 0}")#text(" and some constant ")#mi("{c_d > 0}")#text(" depending only on ")#mi("{d}")#text(".")
]

#emph[#text("Proof:")]#text(" We can normalize ")#tao-math("{\\left\\|f\\right\\|_{\\mathrm{BMO}({\\bf R}^d)}=1}", block: false)#text(". For each ")#mi("{\\lambda > 0}")#text(" let ")#mi("{A(\\lambda)}")#text(" denote the best constant for which we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\left\\{ x \\in B: f(x) \\geq \\frac{1}{\\left|B\\right|} \\int_B f + \\lambda \\right\\}\\right| \\leq A(\\lambda) \\left|B\\right|", block: true)]]

#text("whenever ")#mi("{B}")#text(" is a ball and ")#mi("{f}")#text(" is a real-valued function with BMO norm ")#mi("{1}")#text(". From ")#link(<tao-3eee7e474cae60f9c74b>)[#text("(8)")]#text(" and the trivial bound of ")#tao-math("{\\left|B\\right|}", block: false)#text(" we have the bounds")

#align(center)[#tao-fit-display[#mitex("A(\\lambda) \\leq \\min(1, 1/\\lambda)")]]

#text("and our task is to somehow iterate this to obtain the improved estimate")

#align(center)[#tao-fit-display[#mitex("A(\\lambda) \\lesssim_d e^{-c_d \\lambda}.")]]

#text("We shall do this by a variant of the Calderón–Zygmund decomposition. We’ll need a moderately large quantity ")#mi("{\\lambda_0 > 0}")#text(" to be chosen later, and assume that ")#mi("{\\lambda > \\lambda_0}")#text(". Let ")#mi("{B}")#text(" be any ball, and let ")#tao-math("{F := \\max\\left( \\left(f - \\frac{1}{\\left|B\\right|} \\int_B f\\right) 1_{2B}, 0 \\right)}", block: false)#text(". Then we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|F\\right\\|_{L^1({\\bf R}^d)} \\leq \\int_{2B} \\left|f - \\frac{1}{\\left|B\\right|} \\int_B f\\right| \\lesssim \\left|2B\\right| \\left\\| f\\right\\|_{\\mathrm{BMO}({\\bf R}^d)} \\lesssim_d |B|.", block: true)]]

#text("We consider the set ")#mi("{E := B \\cap \\{ MF > \\lambda_0 \\}}")#text(". Let ")#mi("{\\varepsilon > 0}")#text(" be small, and let ")#mi("{K}")#text(" be any compact set in ")#mi("{E}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|E \\backslash K\\right| \\leq \\varepsilon.", block: true)]]

#text("Applying the Vitali type covering lemma as in the proof of the Hardy–Littlewood maximal inequality (one can also use the Whitney decomposition or Calderón–Zygmund decomposition here) we can cover")

#align(center)[#tao-fit-display[#mitex("K \\subset \\bigcup_n B_n")]]

#text("where ")#mi("{B_n}")#text(" are a finite collection of balls intersecting ")#mi("{K}")#text(" such that ")#tao-math("{\\frac{1}{\\left|B_n\\right|} \\int_{B_n} F \\sim_d \\lambda_0}", block: false)#text(" and")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\left|B_n\\right| \\lesssim_d \\left\\|F\\right\\|_{L^1({\\bf R}^d)}/\\lambda_0 \\leq \\left|B\\right|/\\lambda_0.", block: true)]]

#text("Note that as")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|B_n\\right|} \\int_{B_n} F \\leq \\frac{\\left\\|F\\right\\|_{L^1({\\bf R}^d)}}{\\left|B_n\\right|} \\lesssim_d \\frac{\\left|B\\right|}{\\left|B_n\\right|}", block: true)]]

#text("we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|B_n\\right| \\lesssim_d \\left|B\\right| / \\lambda_0.", block: true)]]

#text("Since ")#mi("{B_n}")#text(" intersects ")#mi("{K}")#text(", which is contained in ")#mi("{B}")#text(", we can conclude that ")#mi("{B_n \\subset 2B}")#text(" if we choose ")#mi("{\\lambda_0}")#text(" large enough.")

#text("Observe that ")#mi("{F}")#text(" is pointwise bounded almost everywhere by ")#mi("{MF}")#text(" (by the Lebesgue differentiation theorem), and so")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ x \\in B: \\left|F(x)\\right| \\geq \\lambda \\}\\right| = \\left| \\{ x \\in B: \\left|F(x)\\right| \\geq \\lambda, MF \\geq \\lambda_0 \\} \\right| \\leq \\sum_n \\left|\\{ x \\in B: \\left|F(x)\\right| \\geq \\lambda\\} \\cap B_n\\right| + \\varepsilon.", block: true)]]

#text("On the other hand, on each ")#mi("{B_n}")#text(" we see that ")#tao-math("{f = \\frac{1}{\\left|B\\right|} \\int_B f + O(F)}", block: false)#text(", and hence")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|B_n\\right|} \\int_{B_n} f = \\frac{1}{\\left|B\\right|} \\int_B f + O\\left(\\frac{1}{\\left|B_n\\right|} \\int_{B_n} F\\right) = \\frac{1}{\\left|B\\right|} \\int_B f + O( \\lambda_0 )", block: true)]]

#text("and so by definition of ")#mi("{A}")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ x\\in B: \\left|F(x)\\right| \\geq \\lambda \\} \\cap B_n\\right| \\leq \\left|\\left\\{ x \\in B_n: \\left|f(x) - \\frac{1}{\\left|B\\right|} \\int_B f\\right| \\geq \\lambda - O(\\lambda_0) \\right\\}\\right| \\leq A( \\lambda - O(\\lambda_0) ) |B_n|.", block: true)]]

#text("Summing this we conclude")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ x \\in B: \\left|F(x)\\right| \\geq \\lambda\\}\\right| \\leq A( \\lambda - O(\\lambda_0) )\\sum_n \\left|B_n\\right| + \\varepsilon \\lesssim_d A( \\lambda - O(\\lambda_0) ) \\left|B\\right| / \\lambda_0 + \\varepsilon.", block: true)]]

#text("Since ")#mi("{\\varepsilon}")#text(" is arbitrary we can remove it. Taking suprema over all ")#mi("{B}")#text(" and ")#mi("{f}")#text(" we conclude the recursive inequality")

#align(center)[#tao-fit-display[#mitex("A(\\lambda) \\lesssim_d A( \\lambda - O(\\lambda_0) ) /\\lambda_0.")]]

#text("Taking ")#mi("{\\lambda_0}")#text(" sufficiently large depending on ")#mi("{d}")#text(", and iterating starting from the trivial bound ")#mi("{A(\\lambda) \\leq 1}")#text(", we obtain the claim. ")#mi("\\Box")

#text("Using the distributional characterization of the ")#mi("{L^p}")#text(" norms, we conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 25 (Alternate characterization of BMO norm)")]#text(" ")#metadata(none) <tao-c5a6bd63b8de0ddd09d2>#text(" For any ")#mi("{1 \\leq p < \\infty}")#text(" and all locally integrable ")#mi("{f}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sup_B \\left(\\frac{1}{\\left|B\\right|} \\int_B \\left|f-\\frac{1}{\\left|B\\right|} \\int_B f\\right|^p\\right)^{1/p} \\sim_{p,d} \\sup_B \\inf_c \\left(\\frac{1}{\\left|B\\right|} \\int_B \\left|f-c\\right|^p\\right)^{1/p} \\sim_{p,d} \\left\\|f\\right\\|_{\\mathrm{BMO}({\\bf R}^d)}.", block: true)]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Prove this corollary.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" ")#metadata(none) <tao-a08c925fed8ffd1710d3>#text(" Show that Corollary ")#link(<tao-c5a6bd63b8de0ddd09d2>)[#text("25")]#text(" is in fact true for all ")#mi("{0 < p < \\infty}")#text(".")
]

#text("One consequence of this corollary, when combined with the Calderón–Zygmund decomposition, is that the ")#mi("{\\mathrm{BMO}}")#text(" norm serves as a substitute for the ")#mi("{L^\\infty}")#text(" norm as far as log-convexity of Hölder norms is concerned:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 28")]#text(" ")#metadata(none) <tao-33ee04c684762fe55613>#text(" Let ")#mi("{0 < p < q < \\infty}")#text(" and ")#mi("{f \\in L^p({\\bf R}^d) \\cap \\mathrm{BMO}({\\bf R}^d)}")#text(". Then ")#mi("{f \\in L^q({\\bf R}^d)}")#text(" and")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^q({\\bf R}^d)} \\lesssim_{p,q,d} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}^{p/q} \\left\\|f\\right\\|_{\\mathrm{BMO}({\\bf R}^d)}^{1-p/q}.", block: true)]]
]

#emph[#text("Proof:")]#text(" By rescaling one can normalize ")#tao-math("{\\left\\|f\\right\\|_{L^p({\\bf R}^d)} = \\left\\|f\\right\\|_{\\mathrm{BMO}({\\bf R}^d)} = 1}", block: false)#text(". Let us understand the size of the distribution function ")#tao-math("{\\left|\\{ \\left|f\\right| \\geq \\lambda \\}\\right|}", block: false)#text(". From the ")#mi("{L^p}")#text(" bound we already have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ \\left|f\\right| \\geq \\lambda \\}\\right| \\leq \\lambda^{-p}.", block: true)]]

#text("We can get a better bound for large ")#mi("{\\lambda}")#text(" as follows. Applying the ")#mi("{L^p}")#text(" version of the Calderón–Zygmund decomposition at level ")#mi("{1}")#text(", we can find a collection of disjoint dyadic cubes ")#mi("{Q}")#text(" with ")#tao-math("{\\sum_Q \\left|Q\\right| \\lesssim_d 1}", block: false)#text(", such that ")#tao-math("{\\left|f\\right| \\leq 1}", block: false)#text(" almost everywhere outside of ")#mi("{\\bigcup_Q Q}")#text(", and such that ")#tao-math("{\\frac{1}{\\left|Q\\right|} \\int_Q \\left|f\\right|^p \\lesssim_d 1}", block: false)#text(" on each cube ")#mi("{Q}")#text(". If we let ")#mi("{B}")#text(" be a ball containing ")#mi("{Q}")#text(" of comparable diameter, we then easily verify that ")#tao-math("{\\frac{1}{\\left|B\\right|} \\int_B \\left|f\\right|^p \\lesssim_d 1}", block: false)#text(" also, and thus ")#tao-math("{\\frac{1}{\\left|B\\right|} \\int_B f = O(1)}", block: false)#text(". From the John–Nirenberg inequality we thus see that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ x \\in B: \\left|f(x)\\right| \\geq \\lambda \\}\\right| \\lesssim_d e^{-c_d \\lambda} \\left|B\\right|", block: true)]]

#text("for ")#mi("{\\lambda}")#text(" large enough; summing over ")#mi("{B}")#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ \\left|f(x)\\right| \\geq \\lambda \\}\\right| \\lesssim_d e^{-c_d \\lambda}", block: true)]]

#text("for large ")#mi("{\\lambda}")#text(". Combining this with the ")#mi("{L^p}")#text(" bound for small ")#mi("{\\lambda}")#text(" and using the distributional formula for the ")#mi("{L^q}")#text(" norm we obtain the claim. ")#mi("\\Box")

#text("Because of this, we can also use ")#mi("{\\mathrm{BMO}}")#text(" as a substitute for ")#mi("{L^\\infty}")#text(" for real interpolation purposes. For instance, let ")#mi("{T}")#text(" be a CZO and ")#mi("{2 < p < \\infty}")#text(". It is now easy to check that ")#mi("{T}")#text(" is restricted type ")#mi("{(p,p)}")#text(". Indeed, for any sub-step function ")#mi("{f}")#text(" of height ")#mi("{H}")#text(" and width ")#mi("{W}")#text(", the boundedness on ")#mi("{L^2}")#text(" gives")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T f\\right\\|_{L^2({\\bf R}^d)} \\lesssim HW^{1/2}", block: true)]]

#text("and Proposition ")#link(<tao-d0afe5ed2bd67151d4dd>)[#text("23")]#text(" gives")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T f\\right\\|_{\\mathrm{BMO}({\\bf R}^d)} \\lesssim_d H", block: true)]]

#text("and so Lemma ")#link(<tao-33ee04c684762fe55613>)[#text("28")]#text(" gives")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T f\\right\\|_{L^p({\\bf R}^d)} \\lesssim_{p,d} H W^{1/p}", block: true)]]

#text("for ")#mi("{2 < p < \\infty}")#text(", which is the restricted type. Further interpolation then gives strong type. (Note that these arguments are essentially the dual of those which establish weak-type ")#mi("{(p,p)}")#text(" for ")#mi("{1 \\leq p < 2}")#text("; in particular, note how the Calderón–Zygmund decomposition continues to make an appearance.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29 (Lacunary exponential sums lie in BMO)")]#text(" ")#metadata(none) <tao-6866b00707ab48540b44>#text(" Let ")#mi("{(\\xi_n)_{n \\in {\\bf Z}}}")#text(" be a sequence of non-zero frequencies in ")#mi("{{\\bf R}}")#text(" which are ")#emph[#text("lacunary")]#text(" in the sense that ")#tao-math("{\\left|\\xi_{n}\\right| \\sim 2^n}", block: false)#text(" for all ")#mi("{n}")#text(". Let ")#mi("{(c_n)_{n \\in {\\bf Z}}}")#text(" be a sequence of complex numbers which obeys the ")#mi("{l^2}")#text(" bound ")#tao-math("{\\sum_n \\left|c_n\\right|^2 \\lesssim 1}", block: false)#text(". To avoid issues of convergence let us assume that only finitely many of the ")#mi("{c_n}")#text(" are non-zero. Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be the exponential sum")

#align(center)[#tao-fit-display[#mitex("f(x) := \\sum_n c_n e^{2\\pi i \\xi_n x}.")]]

#text("If ")#mi("{I}")#text(" is an interval in ")#mi("{{\\bf R}}")#text(", and ")#mi("{\\phi_I: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a bump function adapted to ")#mi("{I}")#text(", establish the local ")#mi("{L^2}")#text(" estimate")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\bf R} \\phi_I(x) \\left|f(x) - c_I\\right|^2\\ dx \\lesssim \\left|I\\right|", block: true)]]

#text("for some constant ")#mi("{c_I}")#text(". (Hints: split the ")#mi("{n}")#text(" summation into the high frequencies where ")#tao-math("{2^n \\geq \\left|I\\right|^{-1}}", block: false)#text(", and the low frequencies where ")#tao-math("{2^n < \\left|I\\right|^{-1}}", block: false)#text(". For the high frequencies, forget about ")#mi("{c_I}")#text(" and expand out the sum, using some good estimate on the Fourier transform of ")#mi("{\\phi_I}")#text(". For the low frequencies, choose ")#mi("{c_I}")#text(" in order to obtain some cancellation and then use the triangle inequality.) Conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{\\mathrm{BMO}({\\bf R})} \\lesssim 1.", block: true)]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30 (Dyadic BMO)")]#text(" ")#metadata(none) <tao-f8bdff3fb98849eac918>#text(" Given any ")#mi("{\\Omega \\subset {\\bf R}^d}")#text(" and any locally integrable ")#mi("{f: \\Omega \\rightarrow {\\bf C}}")#text(", define the dyadic BMO norm ")#tao-math("{\\left\\|f\\right\\|_{\\mathrm{BMO}_\\Delta(\\Omega)}}", block: false)#text(" of ")#mi("{f}")#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{\\mathrm{BMO}_\\Delta(\\Omega)} = \\sup_{Q \\subset \\Omega} \\frac{1}{\\left|Q\\right|} \\int_Q \\left|f - \\frac{1}{\\left|Q\\right|} \\int_Q f\\right|", block: true)]]

#text("where ")#mi("{Q}")#text(" ranges over all dyadic cubes inside ")#mi("{\\Omega}")#text(". Show that we have the John–Nirenberg inequality")

#align(center)[#tao-fit-display[#tao-math("\\left| \\left\\{ f \\in Q: \\left|f - \\frac{1}{\\left|Q\\right|} \\int_Q f\\right| \\geq \\lambda \\right\\} \\right| \\lesssim e^{-c \\lambda / \\left\\|f\\right\\|_{\\mathrm{BMO}_\\Delta(\\Omega)}} \\left|Q\\right|", block: true)]]

#text("for all ")#mi("{\\lambda > 0}")#text(" and all ")#mi("{Q \\subset {\\bf R}^d}")#text(", and in particular")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{\\mathrm{BMO}_\\Delta(\\Omega)} \\sim_p \\sup_{Q \\subset \\Omega} \\left(\\frac{1}{\\left|Q\\right|} \\int_Q \\left|f - \\frac{1}{\\left|Q\\right|} \\int_Q f\\right|^p\\right)^{1/p}", block: true)]]

#text("for all ")#mi("{1 \\leq p < \\infty}")#text(". (As in Exercise ")#link(<tao-a08c925fed8ffd1710d3>)[#text("27")]#text(", this extends to ")#mi("{0 < p < 1}")#text(" as well.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31 (BMO and dyadic BMO)")]#text(" ")#metadata(none) <tao-0f27e1c3e3fbf06a3a4c>#text(" For any locally integrable ")#mi("{f}")#text(" in ")#mi("{{\\bf R}^d}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{\\mathrm{BMO}_\\Delta({\\bf R}^d)} \\lesssim_d \\left\\|f\\right\\|_{\\mathrm{BMO}({\\bf R}^d)}", block: true)]]

#text("but that the converse inequality is not true. On the other hand, if we let ")#mi("{{\\mathcal D}_{d,\\alpha}}")#text(" be the shifted dyadic meshes from the previous week’s notes, and set ")#mi("{\\mathrm{BMO}_{\\Delta,\\alpha}}")#text(" to be the associated shifted dyadic BMO norms, show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{\\mathrm{BMO}({\\bf R}^d)} \\sim_d \\sum_\\alpha \\left\\|f\\right\\|_{\\mathrm{BMO}_{\\Delta,\\alpha}({\\bf R}^d)}.", block: true)]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32 (John–Nirenberg via Bellman functions)")]#text(" ")#metadata(none) <tao-b401b5d0d249f4187369>#text(" Let ")#mi("{V: [0,1] \\rightarrow {\\bf R}}")#text(" be the function ")#mi("{V(x) := 10 - (x-2)^2}")#text(". Use a Bellman function approach to establish the John–Nirenberg type inequality")

#align(center)[#tao-fit-display[#tao-math("\\left| \\left\\{ x \\in I: f(x) - \\frac{1}{\\left|I\\right|} \\int_I f \\geq \\lambda \\right\\}\\right| \\leq C_0 |I| V\\left( \\frac{\\left\\|f-\\frac{1}{\\left|I\\right|} \\int_I f \\right\\|_{L^2(I)}^2}{\\left|I\\right|} \\right) e^{-\\varepsilon \\lambda}", block: true)]]

#text("for some absolute constants ")#mi("{C_0, \\varepsilon > 0}")#text(", all intervals ")#mi("{I}")#text(", and all functions ")#mi("{f: I \\rightarrow {\\bf R}}")#text(" with ")#tao-math("{\\left\\|f\\right\\|_{\\mathrm{BMO}_\\Delta(I)} \\leq 1}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33 (Sharp function, I)")]#text(" ")#metadata(none) <tao-6fbba5df964b7049f1f5>#text(" For any locally integrable function ")#mi("{f:{\\bf R}^d \\rightarrow {\\bf C}}")#text(", define the function ")#mi("{f^\\sharp: {\\bf R}^d \\rightarrow {\\bf R}^+}")#text(" as")

#align(center)[#tao-fit-display[#tao-math("f^\\sharp(x) := \\sup_{B \\ni x} \\frac{1}{\\left|B\\right|} \\int_B \\left|f-\\frac{1}{\\left|B\\right|} \\int_B f\\right|", block: true)]]

#text("where the supremum ranges over all balls containing ")#mi("{x}")#text(". In particular we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f^\\sharp \\right\\|_{L^\\infty({\\bf R}^d)} = \\left\\|f\\right\\|_{\\mathrm{BMO}({\\bf R}^d)}.", block: true)]]

#text("Show that we have the pointwise bound")

#align(center)[#tao-fit-display[#tao-math("\\left|f^\\sharp\\right| \\lesssim_d Mf.", block: true)]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34 (Sharp function, II)")]#text(" ")#metadata(none) <tao-c7c58bd6007672362da2>#text(" Let ")#mi("{f}")#text(" be locally integrable, let ")#mi("{\\varepsilon, \\lambda > 0}")#text(", and let ")#mi("{B}")#text(" be any ball on which ")#mi("{Mf(x) \\lesssim \\lambda}")#text(" for at least one ")#mi("{x \\in B}")#text(", and such that ")#mi("{f^\\sharp(y) \\leq \\varepsilon \\lambda}")#text(" for at least one ")#mi("{y \\in B}")#text(". Use the Hardy–Littlewood maximal inequality to show that for any sufficiently large ")#mi("{K \\gg 1}")#text(", that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ x \\in B: Mf \\geq K \\lambda \\}\\right| \\lesssim_d \\frac{\\varepsilon}{K} |B|.", block: true)]]

#text("From this and a Vitali covering lemma or Calderón–Zygmund decomposition argument, conclude the ")#emph[#text("good ")#mi("{\\lambda}")#text(" inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ Mf \\geq K \\lambda \\text{ and } f^\\sharp \\leq \\varepsilon \\lambda \\}\\right| \\lesssim_d \\frac{\\varepsilon}{K} \\left|\\{ Mf \\geq \\lambda \\}\\right|", block: true)]]

#text("and then (by taking ")#mi("{K}")#text(" large, and ")#mi("{\\varepsilon}")#text(" very small) show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^p({\\bf R}^d)} \\sim_{p,d} \\left\\| Mf \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{p,d} \\left\\|f^\\sharp\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("for all ")#mi("{1 < p < \\infty}")#text(" and ")#mi("{f \\in L^p({\\bf R}^d)}")#text(". Use this to give an alternate proof of Lemma ")#link(<tao-33ee04c684762fe55613>)[#text("28")]#text(".")
]

#heading(level: 1)[#strong[#text(" — 4. Multiplier theory — ")]]

#text("An important subclass of CZOs are given by certain types of ")#emph[#text("Fourier multipliers")]#text(". (We also have ")#emph[#text("spatial multipliers")]#text(" ")#mi("{m(X): f(x) \\mapsto m(x) f(x)}")#text(", but their behavior is much more elementary to analyze thanks to Hölder’s inequality; for instance, a spatial multiplier ")#mi("{m(X)}")#text(" is bounded on ")#mi("{L^p}")#text(" if and only if the symbol ")#mi("{m}")#text(" is in ")#mi("{L^\\infty}")#text(", and indeed the operator norm of the former is the sup norm of the latter.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 35")]#text(" If ")#mi("{m:{\\bf R}^d \\rightarrow {\\bf C}}")#text(" is a tempered distribution we define the ")#emph[#text("Fourier multiplier")]#text(" ")#mi("{m(D): \\mathcal{S}({\\bf R}^d) \\rightarrow \\mathcal{S}({\\bf R}^d)^*}")#text(" on Schwartz functions ")#mi("{f \\in \\mathcal{S}({\\bf R}^d)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\widehat{m(D) f}(\\xi) = m(\\xi) \\hat f(\\xi).")]]

#text("We refer to the function ")#mi("{m}")#text(" as the ")#emph[#text("symbol")]#text(" of the multiplier ")#mi("{m(D)}")#text(".")
]

#text("Note that if ")#mi("{f}")#text(" is Schwartz, then so is ")#mi("{\\hat f}")#text(", and that is enough to make ")#mi("{m \\hat f}")#text(" a tempered distribution, and so ")#mi("{m(D) f}")#text(" is well-defined as a tempered distribution. If ")#mi("{m}")#text(" is bounded, we observe from Plancherel’s identity that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| m(D) f \\right\\|_{L^2({\\bf R}^d)} \\leq \\left\\|m\\right\\|_{L^\\infty({\\bf R}^d)} \\left\\|f\\right\\|_{L^2({\\bf R}^d)}", block: true)]]

#text("and hence the Fourier multiplier extends continuously to all of ")#mi("{L^2}")#text(" in this case. Indeed it is not hard to show that in fact")

#align(center)[#tao-fit-display[#tao-math("\\left\\|m(D) \\right\\|_{L^2({\\bf R}^d) \\rightarrow L^2({\\bf R}^d)} = \\left\\|m\\right\\|_{L^\\infty({\\bf R}^d)}.", block: true)]]

#text("The partial derivative operator ")#mi("{\\frac{\\partial}{\\partial x_j}}")#text(" is a Fourier multiplier with symbol ")#mi("{2\\pi i \\xi_j}")#text(". More generally, any constant-coefficient differential operator ")#mi("{P(\\nabla)}")#text(", where ")#mi("{P: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is a polynomial, has symbol ")#mi("{P(2\\pi i \\xi)}")#text("; thus one can formally view ")#mi("{D}")#text(" in ")#mi("{m(D)}")#text(" as representing the vector-valued operator ")#mi("{D = \\frac{1}{2\\pi i} \\nabla}")#text(". The translation operator ")#mi("{\\mathrm{Trans}_{x_0}}")#text(" is a Fourier multiplier with symbol ")#mi("{e^{-2\\pi i x_0 \\cdot \\xi}}")#text(", thus we formally have ")#mi("{\\mathrm{Trans}_{x_0} = e^{-2\\pi i D \\cdot x_0} = e^{-x_0 \\cdot \\nabla}}")#text(". A convolution operator ")#mi("{T: f \\mapsto f*K}")#text(", with ")#mi("{K}")#text(" a distribution, is a Fourier multiplier with symbol ")#mi("{m = \\hat K}")#text("; conversely, every Fourier multiplier is a convolution operator with the distribution ")#mi("{K = \\check m}")#text(". The Hilbert transform is a Fourier multiplier with symbol ")#mi("{-i \\mathrm{sgn}(\\xi)}")#text(", thus ")#mi("{H = -i\\mathrm{sgn}(D)}")#text(".")

#text("Let ")#mi("{1 \\leq p \\leq \\infty}")#text(". We say that ")#mi("{m}")#text(" is an ")#mi("{L^p}")#text(" multiplier if ")#mi("{m(D)}")#text(" extends to a bounded linear operator on ")#mi("{L^p({\\bf R}^d)}")#text(", and in that case denote ")#tao-math("{\\left\\|m\\right\\|_{M^p}}", block: false)#text(" to be the ")#mi("{L^p}")#text(" operator norm of ")#mi("{m}")#text(" on ")#mi("{M^p}")#text(". Thus for instance the ")#mi("{M^2}")#text(" norm is the same as the ")#mi("{L^\\infty}")#text(" norm. At first glance, it seems one can say quite a lot about these quantities; for instance, since the adjoint of ")#mi("{m(D)}")#text(" is easily seen to be ")#mi("{\\overline{m}(D)}")#text(", which has the same ")#mi("{L^p}")#text(" operator norm as ")#mi("{m(D)}")#text(", we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|m\\right\\|_{M^p({\\bf R}^d)}= \\left\\|\\overline{m}\\right\\|_{M^p({\\bf R}^d)} = \\left\\|m\\right\\|_{M^{p^{\\prime}}({\\bf R}^d)}", block: true)]]

#text("and thus by Riesz–Thorin interpolation")

#align(center)[#tao-fit-display[#tao-math("\\left\\|m\\right\\|_{L^\\infty({\\bf R}^d)} = \\left\\|m\\right\\|_{M^2({\\bf R}^d)} \\leq \\left\\|m\\right\\|_{M^p({\\bf R}^d)}", block: true)]]

#text("and so all ")#mi("{L^p}")#text(" multipliers are bounded (though the converse turns out to be false, as we shall see later). The space ")#mi("{M^p}")#text(" of ")#mi("{L^p}")#text(" multipliers turns out to be a Banach algebra, thus the ")#mi("{M^p}")#text(" norm is a Banach space norm and furthermore")

#align(center)[#tao-fit-display[#tao-math("\\left\\|m_1 m_2 \\right\\|_{M^p({\\bf R}^d)} \\leq \\left\\|m_1\\right\\|_{M^p({\\bf R}^d)} \\left\\|m_2\\right\\|_{M^p({\\bf R}^d)}.", block: true)]]

#text("One can also show (from the symmetries of the Fourier transform) that the ")#mi("{M^p}")#text(" norm is invariant under translations, modulations, and ")#mi("{L^\\infty}")#text(" dilations:")

#metadata(none) <tao-cbd31fe312a05a4718b4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left\\| \\mathrm{Trans}_{x_0} m \\right\\|_{M^p({\\bf R}^d)} = \\left\\|\\mathrm{Mod}_{\\xi_0} m\\right\\|_{M^p({\\bf R}^d)} = \\left\\| \\mathrm{Dil}^\\infty_\\lambda m \\right\\|_{M^p({\\bf R}^d)} = \\left\\|m\\right\\|_{M^p({\\bf R}^d)}.", block: true)]]

#text("The dilation invariance can be generalized: given any invertible linear transformation ")#mi("{L: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" we can check that")

#metadata(none) <tao-358624e930c745eab4a4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left\\| m \\circ L \\right\\|_{M^p({\\bf R}^d)} = \\left\\|m\\right\\|_{M^p({\\bf R}^d)}.", block: true)]]

#text("Because of the translation invariance, the same is true if ")#mi("{L}")#text(" is an affine transformation rather than a linear one.")

#text("Thus for instance, by modulating the Hilbert transform we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 1_{[\\xi_0,+\\infty)} \\right\\|_{M^p({\\bf R})} \\lesssim_p 1", block: true)]]

#text("for ")#mi("{1 < p < \\infty}")#text(", which by Riemann–Stieltjes integration and Minkowski’s inequality shows that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| m \\right\\|_{M^p({\\bf R})} \\lesssim_p \\left\\| m \\right\\|_{BV({\\bf R})}", block: true)]]

#text("when ")#mi("{m}")#text(" has bounded variation, where")

#align(center)[#tao-fit-display[#tao-math("\\left\\| m \\right\\|_{BV({\\bf R})} := \\left\\|m\\right\\|_{L^\\infty({\\bf R})} + \\sup_{\\xi_1 < \\ldots < \\xi_N} \\sum_{j=1}^{N-1} |m(\\xi_{j+1}) - m(\\xi_j)|.", block: true)]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36")]#text(" ")#metadata(none) <tao-805487266d4de2f9df14>#text(" Show that if ")#mi("{T}")#text(" is a bounded linear operator on ")#mi("{L^2({\\bf R}^d)}")#text(" which commutes with translations, then it is a Fourier multiplier operator with bounded symbol.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" ")#metadata(none) <tao-b804d0b78b82ddd4d45a>#text(" Let ")#mi("{m: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" and ")#mi("{m^{\\prime}: {\\bf R}^{d^{\\prime}} \\rightarrow {\\bf C}}")#text(" be ")#mi("{L^p}")#text(" multipliers. Show that the tensor product ")#mi("{m \\otimes m^{\\prime}: {\\bf R}^{d + d^{\\prime}} \\rightarrow {\\bf C}}")#text(" is also an ")#mi("{L^p}")#text(" multiplier with")

#align(center)[#tao-fit-display[#tao-math("\\left\\| m \\otimes m^{\\prime} \\right\\|_{M^p({\\bf R}^{d+d^{\\prime}})} = \\left\\| m \\right\\|_{M^p({\\bf R}^{d})} \\left\\| m^{\\prime} \\right\\|_{M^p({\\bf R}^{d^{\\prime}})}.", block: true)]]

#text("(Hint: it may help to first establish the cases when ")#mi("{m \\equiv 1}")#text(" or ")#mi("{m^{\\prime} \\equiv 1}")#text(".)")
]

#text("For ")#mi("{M^1}")#text(" or ")#mi("{M^\\infty}")#text(", it is also not hard to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| m \\right\\|_{M^1({\\bf R}^d)} = \\left\\|m\\right\\|_{M^\\infty({\\bf R}^d)} = \\left\\| \\check m \\right\\|_{L^1({\\bf R}^d)}", block: true)]]

#text("whenever the inverse Fourier transform of ")#mi("{m}")#text(" is absolutely integrable; with a little more work one can also show that ")#mi("{m(D)}")#text(" is unbounded on ")#mi("{L^1}")#text(" and ")#mi("{L^\\infty}")#text(" when ")#mi("{\\check m}")#text(" does not lie in ")#mi("{L^1({\\bf R}^d)}")#text(", although this is a little tricky. Thus for ")#mi("{1 \\leq p \\leq \\infty}")#text(" we have (by Riesz–Thorin again)")

#align(center)[#tao-fit-display[#tao-math("\\left\\| m \\right\\|_{L^\\infty({\\bf R}^d)} \\leq \\left\\|m\\right\\|_{M^p({\\bf R}^d)} \\leq \\left\\| \\check m \\right\\|_{L^1({\\bf R}^d)}.", block: true)]]

#text("One consequence of this is that if ")#mi("{m}")#text(" is a bump function adapted to ")#mi("{L(\\Omega)}")#text(" for some fixed bounded domain ")#mi("{\\Omega}")#text(" and some arbitrary affine linear transformation ")#mi("{L}")#text(", then ")#mi("{m}")#text(" is an ")#mi("{M^p}")#text(" multiplier with ")#tao-math("{\\left\\|m\\right\\|_{M^p({\\bf R}^d)} = O_{d,\\Omega}(1)}", block: false)#text(" for all ")#mi("{1 \\leq p \\leq \\infty}")#text(".")

#text("Suppose a multiplier ")#mi("{m}")#text(" on ")#mi("{{\\bf R}^d}")#text(" does not depend on the final coordinate ")#mi("{\\xi_d}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("m(\\xi_1,\\ldots,\\xi_d) = \\tilde m(\\xi_1,\\ldots,\\xi_{d-1})")]]

#text("for some ")#mi("{\\tilde m: {\\bf R}^{d-1} \\rightarrow {\\bf C}}")#text(". Then the ")#mi("{d}")#text("-dimensional Fourier multiplier ")#mi("{m(D)}")#text(" and the ")#mi("{d-1}")#text("-dimensional Fourier multiplier ")#mi("{\\tilde m(D)}")#text(" are related by the identity")

#align(center)[#tao-fit-display[#mitex("[m(D) f]_{x_d} = \\tilde m(D) [f_{x_d}]")]]

#text("for all ")#mi("{x_d \\in {\\bf R}}")#text(" and Schwartz ")#mi("{f \\in \\mathcal{S}({\\bf R}^d)}")#text(", where ")#mi("{f_{x_d}: {\\bf R}^{d-1} \\rightarrow {\\bf C}}")#text(" is the slice")

#align(center)[#tao-fit-display[#mitex("f_{x_d}(x_1,\\ldots,x_{d-1}) := f(x_1,\\ldots,x_d).")]]

#text("From this and Fubini’s theorem one easily verifies that if ")#mi("{\\tilde m}")#text(" is in ")#mi("{M^p({\\bf R}^{d-1})}")#text(", then ")#mi("{m}")#text(" is in ")#mi("{M^p({\\bf R}^d)}")#text(" with")

#metadata(none) <tao-8fa1dddd53606ceb933c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left\\|m\\right\\|_{M^p({\\bf R}^d)} = \\left\\|\\tilde m\\right\\|_{M^p({\\bf R}^{d-1})}.", block: true)]]

#text("Of course, most multipliers ")#mi("{m}")#text(" on ")#mi("{{\\bf R}^d}")#text(" do depend on the final coordinate ")#mi("{\\xi_d}")#text(". Nevertheless we can obtain a partial generalization of ")#link(<tao-8fa1dddd53606ceb933c>)[#text("(11)")]#text(" for these more general multipliers:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 38 (De Leeuw’s theorem)")]#text(" If ")#mi("{m \\in M^p({\\bf R}^d)}")#text(" is continuous, then ")#tao-math("{\\left\\|m_{\\xi_d}\\right\\|_{M^p({\\bf R}^{d-1})} \\leq \\left\\|m\\right\\|_{M^p({\\bf R}^d)}}", block: false)#text(" for any ")#mi("{\\xi_d}")#text(".")
]

#emph[#text("Proof:")]#text(" By translation invariance we can take ")#mi("{\\xi_d = 0}")#text(". For any ")#mi("{\\lambda > 0}")#text(", let ")#mi("{L_\\lambda: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" be the linear transformation")

#align(center)[#tao-fit-display[#mitex("L(\\xi_1,\\ldots,\\xi_d) := (\\xi_1,\\ldots,\\xi_{d-1},\\xi_d/\\lambda),")]]

#text("then by ")#link(<tao-358624e930c745eab4a4>)[#text("(10)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| m \\circ L_\\lambda \\right\\|_{M^p({\\bf R}^d)} = \\left\\|m\\right\\|_{M^p({\\bf R}^d)}.", block: true)]]

#text("Now we send ")#mi("{\\lambda \\rightarrow \\infty}")#text(". We observe from the hypothesis that ")#mi("{m}")#text(" is continuous that ")#mi("{m \\circ L_\\lambda \\rightarrow m \\circ L_\\infty}")#text(" pointwise, where ")#mi("{L_\\infty}")#text(" is the (non-invertible) projection")

#align(center)[#tao-fit-display[#mitex("L_\\infty(\\xi_1,\\ldots,\\xi_d) = (\\xi_1,\\ldots,\\xi_{d-1},0).")]]

#text("On the other hand, from ")#link(<tao-8fa1dddd53606ceb933c>)[#text("(11)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|m \\circ L_\\infty\\right\\|_{M^p({\\bf R}^d)} = \\left\\| m_0 \\right\\|_{M^p({\\bf R}^{d-1})}.", block: true)]]

#text("So to conclude the theorem it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|m \\circ L_\\infty\\right\\|_{M^p({\\bf R}^d)} \\leq \\limsup_{\\lambda \\rightarrow \\infty} \\left\\|m \\circ L_\\lambda\\right\\|_{M^p({\\bf R}^d)}.", block: true)]]

#text("This can be achieved by a weak convergence argument. (As usual, weak convergence preserves upper bounds, but does not necessarily preserve lower bounds (cf. Fatou’s lemma).) If ")#mi("{f, g}")#text(" are Schwartz functions, we see from Hölder’s inequality that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle m \\circ L_\\lambda(D) f, g \\rangle\\right| \\leq \\left\\|m \\circ L_\\lambda\\right\\|_{M^p({\\bf R}^d)} \\left\\|f\\right\\|_{L^p({\\bf R}^d)} \\left\\|g\\right\\|_{L^{p^{\\prime}}({\\bf R}^d)}.", block: true)]]

#text("Taking limit superior as ")#mi("{\\lambda \\rightarrow \\infty}")#text(" and using Plancherel and dominated convergence on the left-hand side (using the pointwise convergence, as well as the boundedness of ")#mi("{m}")#text(") we conclude")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle m \\circ L_\\infty(D) f, g \\rangle\\right| \\leq \\limsup_{\\lambda \\rightarrow \\infty} \\left\\|m \\circ L_\\lambda\\right\\|_{M^p({\\bf R}^d)} \\left\\|f\\right\\|_{L^p({\\bf R}^d)} \\left\\|g\\right\\|_{L^{p^{\\prime}}({\\bf R}^d)}.", block: true)]]

#text("Using the converse to Hölder’s inequality we obtain the claim. ")#mi("\\Box")

#text("One consequence of de Leeuw’s theorem is that we expect multiplier theory on higher dimensions to be harder than multiplier theory for lower dimensions.")

#text("One can view de Leeuw’s theorem as a ")#emph[#text("transference theorem")]#text(", transferring a bound on one space (")#mi("{{\\bf R}^d}")#text(") to another (")#mi("{{\\bf R}^{d-1}}")#text("), basically by exploiting the fact that there was a projection from ")#mi("{{\\bf R}^d}")#text(" to ")#mi("{{\\bf R}^{d-1}}")#text(". For a result of similar flavor, see Exercise ")#link(<tao-57ab8071a34591af34bd>)[#text("39")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39 (Transference theorem for ")#mi("{{\\bf Z}^d}")#text(")")]#text(" ")#metadata(none) <tao-57ab8071a34591af34bd>#text(" If ")#mi("{m: {\\bf Z}^d \\rightarrow {\\bf C}}")#text(" is bounded, define the multiplier ")#mi("{m(D)}")#text(" on ")#mi("{L^2({\\bf T}^d)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\widehat{m(D) f}(\\xi) := m(\\xi) \\hat f(\\xi) \\text{ for } \\xi \\in {\\bf Z}^d")]]

#text("where we use the Fourier transform on the torus ")#mi("{{\\bf T}^d := {\\bf R}^d/{\\bf Z}^d}")#text(",")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) := \\int_{{\\bf T}^d} e^{-2\\pi i x \\cdot \\xi} f(x)\\ dx.")]]

#text("We then define ")#tao-math("{\\left\\|m\\right\\|_{M^p({\\bf Z}^d)}}", block: false)#text(" to be the ")#mi("{L^p({\\bf T}^d)}")#text(" operator norm of ")#mi("{m(D)}")#text(".")

#text("Let ")#mi("{m: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be continuous and an ")#mi("{M^p({\\bf R}^d)}")#text(" multiplier for some ")#mi("{1 \\leq p \\leq \\infty}")#text(". Show that ")#tao-math("{\\left\\| m|_{{\\bf Z}^d} \\right\\|_{M^p({\\bf Z}^d)} \\leq \\left\\|m\\right\\|_{M^p({\\bf R}^d)}}", block: false)#text(". (Hint: take functions ")#mi("{f, g \\in C^\\infty({\\bf T}^d)}")#text(", extend them periodically to ")#mi("{{\\bf R}^d}")#text(", multiply them by some cutoff to ")#mi("{1}")#text(" (such as ")#tao-math("{e^{-\\varepsilon \\left|x\\right|^2}}", block: false)#text("), apply ")#mi("{m(D)}")#text(" on ")#mi("{{\\bf R}^d}")#text(", and use some appropriate limiting argument (and possibly a Poisson summation formula) to get down to ")#mi("{{\\bf T}^d}")#text(".)")
]

#text("Despite these encouraging initial results, it appears very difficult to decide in general whether any given multiplier ")#mi("{m}")#text(" lies in ")#mi("{M^p}")#text(" or not for any ")#mi("{1 < p < \\infty}")#text(" other than ")#mi("{p=2}")#text(". For instance, the question of determining the precise values of ")#mi("{p}")#text(" and ")#mi("{\\delta}")#text(" for which the multiplier ")#tao-math("{m^\\delta(\\xi) := \\max(1-\\left|\\xi\\right|^2,0)^\\delta}", block: false)#text(" is an ")#mi("{L^p({\\bf R}^d)}")#text(" multiplier is not fully resolved in three and higher dimensions; this problem is known as the ")#emph[#text("Bochner–Riesz conjecture")]#text(", which we will not discuss in detail here. Broadly speaking, the difficulty with the Bochner–Riesz conjecture is that the symbol ")#mi("{m^\\delta}")#text(" is singular on a large, curved set (in this case, the sphere), which necessarily leads to some delicate and still incompletely understood geometric issues (most notably the Kakeya conjecture, which we will also not discuss here).")

#text("However, one can do a lot better if the multiplier has no singularities, or is only singular at one point (such as the origin). For instance, if ")#mi("{m}")#text(" is Schwartz, then ")#mi("{\\check m}")#text(" is definitely in ")#mi("{L^1}")#text(", and so ")#mi("{m}")#text(" lies in ")#mi("{M^p}")#text(" for all ")#mi("{1 \\leq p \\leq \\infty}")#text(". Note from ")#link(<tao-cbd31fe312a05a4718b4>)[#text("(9)")]#text(" that any dilate, translate, and/or modulation of a Schwartz function is then also in ")#mi("{M^p}")#text(" uniformly in the dilation, translation, and modulation parameters.")

#text("Now we address multipliers which only have singularities at the origin.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 40 (Hörmander–Mikhlin multiplier theorem)")]#text(" Let ")#mi("{m: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" obey the ")#emph[#text("homogeneous symbol estimates of order ")#mi("{0}")]

#metadata(none) <tao-592372bb39bc1c652ceb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left|\\nabla^k m(\\xi)\\right| \\lesssim \\left|\\xi\\right|^{-k}", block: true)]]

#text("for all ")#mi("{\\xi \\neq 0}")#text(" and ")#mi("{0 \\leq k \\leq d+2}")#text(". (In particular ")#tao-math("{\\left\\|m\\right\\|_{L^\\infty({\\bf R}^d)} \\lesssim 1}", block: false)#text(".) Then ")#mi("{m}")#text(" is a CZO, and we have ")#tao-math("{\\left\\|m\\right\\|_{M^p({\\bf R}^d)} \\lesssim_{p,d} 1}", block: false)#text(" for all ")#mi("{1 < p < \\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 41")]#text(" It is possible to use less regularity than ")#mi("{d+2}")#text(" derivatives here, but in practice this type of control is sufficient for many applications. The conditions ")#link(<tao-592372bb39bc1c652ceb>)[#text("(12)")]#text(" are essentially asserting that ")#mi("{m}")#text(" is smooth and does not oscillate on each annulus ")#tao-math("{2^j \\leq \\left|\\xi\\right| \\leq 2^{j+1}}", block: false)#text(", although it essentially allows different annuli to behave independently. For instance, if ")#mi("{\\psi_j}")#text(" is a bump function adapted to the annulus ")#tao-math("{2^j \\leq \\left|\\xi\\right| \\leq 2^{j+1}}", block: false)#text(", and ")#mi("{\\varepsilon_j \\in \\{-1,+1\\}}")#text(" are arbitrary signs, then ")#mi("{\\sum_j \\varepsilon_j \\psi_j}")#text(" obeys the homogeneous symbol estimates of order ")#mi("{0}")#text(" uniformly in the choice of ")#mi("{\\varepsilon_j}")#text(".")
]

#emph[#text("Proof:")]#text(" The multiplier ")#mi("{m(D)}")#text(" is already bounded on ")#mi("{L^2({\\bf R}^d)}")#text(". Formally, we know that ")#mi("{m(D)}")#text(" is a convolution operator: ")#mi("{m(D) f = f * \\check m}")#text(", but we run into the formal difficulty that ")#mi("{\\check m}")#text(" need not be locally integrable. To compute things rigorously it is convenient to use the Littlewood–Paley decomposition. Let ")#mi("{\\phi: {\\bf R}^d \\rightarrow {\\bf R}^+}")#text(" be a fixed bump function which equals one on the ball ")#mi("{B(0,1)}")#text(" and is supported on the ball ")#mi("{B(0,2)}")#text(", and write")

#align(center)[#tao-fit-display[#mitex("\\psi_j(\\xi) := \\phi(\\xi/2^j) - \\phi(\\xi/2^{j-1})")]]

#text("for ")#mi("{j \\in {\\bf Z}}")#text(". Then we have the partition of unity")

#align(center)[#tao-fit-display[#mitex("1 = \\sum_{j \\in {\\bf Z}} \\psi_j(\\xi)")]]

#text("for almost every ")#mi("{\\xi}")#text(", and hence we have the pointwise convergent sum")

#align(center)[#tao-fit-display[#mitex("m = \\sum_{j \\in {\\bf Z}} m_j")]]

#text("where ")#mi("{m_j := \\psi_j m}")#text(". Using Plancherel and dominated convergence we conclude that")

#align(center)[#tao-fit-display[#mitex("m(D) f = \\sum_{j \\in {\\bf Z}} m_j(D) f")]]

#text("for all ")#mi("{f \\in L^2({\\bf R}^d)}")#text(", where the sum is conditionally convergent in the ")#mi("{L^2}")#text(" sense. In particular for any ")#mi("{f, g \\in L^2({\\bf R}^d)}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\langle m(D) f, g \\rangle = \\sum_{j \\in {\\bf Z}} \\langle m_j(D) f, g \\rangle")]]

#text("where the sum is at least conditionally convergent (indeed by Parseval one can show that it is absolutely convergent). Now let us assume that ")#mi("{f,g}")#text(" are also bounded and compactly supported with disjoint supports. We can write")

#align(center)[#tao-fit-display[#mitex("\\langle m_j(D) f, g \\rangle = \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} K_j(y-x) f(x) g(y)\\ dx dy")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("K_j(x) = \\check m_j(x) = \\int_{{\\bf R}^d} m_j(\\xi) e^{2\\pi i x \\cdot \\xi}\\ d\\xi.")]]

#text("One can justify these formulae via the Fourier inversion formula and Fubini’s theorem using the fact that ")#mi("{f, g, m_j}")#text(" are bounded with compact support; we omit the details. Now observe that ")#mi("{m_j}")#text(" is supported on the annulus ")#tao-math("{\\left|\\xi\\right| \\sim 2^j}", block: false)#text(", and multiple applications of the Leibnitz rule give us the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|\\nabla^k m_j(\\xi)\\right| \\lesssim_{k,d} 2^{-jk}", block: true)]]

#text("for ")#mi("{0 \\leq k \\leq d+2}")#text(". From the ")#mi("{k=0}")#text(" case of this bound and the triangle inequality we obtain the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|K_j(x)\\right| \\lesssim_d 2^{dj};", block: true)]]

#text("on the other hand, by integrating by parts ")#mi("{k}")#text(" times (using the identity ")#tao-math("{e^{2\\pi i x \\cdot \\xi} = \\left(\\frac{x}{2\\pi i \\left|x\\right|^2} \\cdot \\nabla_\\xi\\right)^{k} e^{2\\pi i x \\cdot \\xi}}", block: false)#text(") we obtain the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|K_j(x)\\right| \\lesssim_d 2^{dj} 2^{-jk} \\left|x\\right|^{-k}", block: true)]]

#text("for ")#mi("{k=0,\\ldots,d+2}")#text(", and hence")

#align(center)[#tao-fit-display[#tao-math("\\left|K_j(x)\\right| \\lesssim_d \\min( 2^{dj}, 2^{dj} 2^{-j(d+2)} \\left|x\\right|^{-(d+2)} ) = \\left|x\\right|^{-d} \\min( (2^j \\left|x\\right|)^d, (2^j \\left|x\\right|)^{-2} ).", block: true)]]

#text("Also, we can compute gradients")

#align(center)[#tao-fit-display[#mitex("\\nabla K_j(x) = (2\\pi i \\xi m_j)^\\vee(x) = \\int_{{\\bf R}^d} 2\\pi i \\xi m_j(\\xi) e^{2\\pi i x \\cdot \\xi}\\ d\\xi.")]]

#text("The additional ")#mi("{2\\pi i \\xi}")#text(" factor essentially just contributes an extra factor of ")#mi("{2^j}")#text(" to the analysis, and we end up with")

#align(center)[#tao-fit-display[#tao-math("\\left|\\nabla K_j(x)\\right| \\lesssim_d \\min( 2^{dj}, 2^{dj} 2^{-j(d+2)} \\left|x\\right|^{-(d+2)} ) = \\left|x\\right|^{-d-1} \\min( (2^j \\left|x\\right|)^{d+1}, (2^j \\left|x\\right|)^{-1} ).", block: true)]]

#text("These estimates are enough to show that away from a neighborhood of ")#mi("{x=0}")#text(", the series ")#mi("{\\sum_{j \\in {\\bf Z}} K_j}")#text(" is convergent in ")#mi("{C^1_{\\mathrm{loc}}}")#text(" to a kernel ")#mi("{K: {\\bf R}^d \\backslash \\{0\\} \\rightarrow {\\bf C}}")#text(" obeying the bounds")

#metadata(none) <tao-658447540603e4b7eaf8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left|K(x)\\right| \\lesssim_d \\left|x\\right|^{-d}; \\quad \\left|\\nabla K(x)\\right| \\lesssim_d \\left|x\\right|^{-d-1}", block: true)]]

#text("and by Fubini’s theorem we have")

#metadata(none) <tao-23a2bea0ea71b8860f0a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\langle m(D) f, g \\rangle = \\int_{{\\bf R}^d} \\int_{{\\bf R}^d} K(y-x) f(x) g(y)\\ dx dy")]]

#text("when ")#mi("{f,g}")#text(" are bounded with disjoint support. By a monotone convergence argument (noting that ")#mi("{m(D)}")#text(" is bounded on ")#mi("{L^2}")#text(") the same is true when ")#mi("{f,g}")#text(" are ")#mi("{L^2}")#text(" with compact support.")

#text("The bounds ")#link(<tao-658447540603e4b7eaf8>)[#text("(13)")]#text(" (and the fundamental theorem of calculus) ensure that ")#mi("{K(y-x)}")#text(" is a singular kernel, and ")#link(<tao-23a2bea0ea71b8860f0a>)[#text("(14)")]#text(" shows that ")#mi("{m(D)}")#text(" is a CZO with kernel ")#mi("{K}")#text(". Thus, by Corollary ")#link(<tao-ee2c824064e426becdf2>)[#text("14")]#text(", ")#mi("{m(D)}")#text(" is of strong-type ")#mi("{(p,p)}")#text(" with an operator norm of ")#mi("{O_p(1)}")#text(" for all ")#mi("{1 < p < \\infty}")#text(", and the claim follows. ")#mi("\\Box")

#text("Note that the Hörmander–Mikhlin multiplier theorem includes the ")#mi("{L^p}")#text(" boundedness of the Hilbert transform for ")#mi("{1 < p < \\infty}")#text(" as a special case, since the multiplier ")#mi("{m(\\xi) = i \\mathrm{sgn}(\\xi)}")#text(" certainly obeys the symbol estimates. Another useful instance of the theorem is to conclude that the homogeneous fractional derivative operators ")#tao-math("{\\left|\\nabla\\right|^{it} = \\left|2\\pi D\\right|^{it}}", block: false)#text(", with symbol ")#tao-math("{m(\\xi) = \\left|2\\pi \\xi\\right|^{it}}", block: false)#text(" and ")#mi("{t}")#text(" real, are also bounded on ")#mi("{L^p({\\bf R}^d)}")#text(", with an operator norm of ")#mi("{O_d( \\langle t \\rangle^{d+2} )}")#text(" (in particular, it grows at most polynomially in ")#mi("{t}")#text("). This fact turns out to be very useful when one wishes to use Stein interpolation involving fractional differentiation operators ")#tao-math("{\\left|\\nabla\\right|^z}", block: false)#text(". A similar argument also applies to the inhomogeneous fractional derivative operators ")#mi("{\\langle \\nabla \\rangle^{it} = \\langle 2\\pi D \\rangle^{it}}")#text(" with symbol ")#mi("{\\langle 2\\pi \\xi \\rangle^{it}}")#text(". (The factor of ")#mi("{2\\pi}")#text(" is of course irrelevant here and the same results hold if this factor is dropped. Indeed, in PDE it is customary to drop the ")#mi("{2\\pi}")#text(" from the definition of the Fourier transform so as not to see these factors then arise from differential operators.)")

#text("Another example of multipliers covered by this theorem are the ")#emph[#text("Riesz transforms")]#text(" ")#tao-math("{R_j := iD_j/\\left|D\\right| = \\partial_{x_j}/\\left|\\nabla\\right|}", block: false)#text(" for ")#mi("{j=1,\\ldots,d}")#text(", with symbol ")#tao-math("{i\\xi_j/\\left|\\xi\\right|}", block: false)#text(". These symbols are easily verified to obey the homogeneous symbol estimates and are thus in ")#mi("{M^p({\\bf R}^d)}")#text(" with norm ")#mi("{O_d(1)}")#text(" for all ")#mi("{1 < p < \\infty}")#text(". The significance of the Riesz transforms is that they connect general second order derivatives to the Laplacian; indeed from Fourier analysis we quickly see that")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial^2}{\\partial x_j \\partial x_k} f = - R_j R_k \\Delta f")]]

#text("for all ")#mi("{1 \\leq j,k \\leq d}")#text(" and Schwartz ")#mi("{f}")#text(". In particular, since ")#mi("{R_j R_k}")#text(" is bounded on ")#mi("{L^p}")#text(", we obtain the ")#emph[#text("elliptic regularity estimate")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nabla^2 f \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{d,p} \\left\\| \\Delta f \\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("for all Schwartz ")#mi("{f}")#text(" and all ")#mi("{1 < p < \\infty}")#text(". In a similar vein, we can show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nabla^k f \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{d,p,k} \\left\\| \\left|\\nabla\\right|^k f \\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("for any ")#mi("{k \\geq 0}")#text(", Schwartz ")#mi("{f}")#text(", and ")#mi("{1 < p < \\infty}")#text(", where ")#tao-math("{\\left|\\nabla\\right|^k = \\left|2\\pi D\\right|^k}", block: false)#text(" is the Fourier multiplier with symbol ")#tao-math("{\\left|2\\pi \\xi\\right|^k}", block: false)#text(".")

#text("More generally, any multiplier which is homogeneous of degree zero (thus ")#mi("{m(\\lambda \\xi) = m(\\xi)}")#text(" for all ")#mi("{\\lambda > 0}")#text("), and smooth on the sphere ")#mi("{S^{d-1}}")#text(", obeys the homogeneous symbol estimates and is thus in ")#mi("{M^p}")#text(" for all ")#mi("{1 < p < \\infty}")#text(".")

#text("The Fourier multipliers covered by the Hörmander–Mikhlin multiplier theorem are essentially special cases of the ")#emph[#text("pseudodifferential operators of order ")#mi("{0}")]#text(", which we shall discuss in later notes.")

#heading(level: 1)[#strong[#text(" — 5. Vector-valued analogues — ")]]

#text("In the above discussion we considered only scalar-valued (complex-valued) functions, and scalar-valued operators with scalar kernels ")#mi("{K}")#text(". However, it is possible to generalize basically all of the above discussion to vector-valued cases, in which the functions take values in a Hilbert space, and the kernel takes values in the bounded linear operators from one Hilbert space to another. We rapidly present these generalizations here; as it turns out only some notational changes need to be made. We will then give an important application of this generalization, namely the ")#emph[#text("Littlewood–Paley inequality")]#text(".")

#text("Let ")#mi("{H}")#text(" be a Hilbert space. For ")#mi("{p < \\infty}")#text(", we let ")#mi("{L^p(X \\rightarrow H)}")#text(" be the space of measurable functions ")#mi("{f: X \\rightarrow H}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\int_X \\left\\|f(x)\\right\\|_H^p\\ d\\mu(x) < \\infty,", block: true)]]

#text("where of course we identify functions which agree almost everywhere as before. We also define ")#mi("{L^\\infty(X \\rightarrow H)}")#text(" in the usual manner. One can (rather laboriously) rederive most of the scalar ")#mi("{L^p}")#text(" theory to this vector-valued case (mostly by replacing absolute values with ")#mi("{H}")#text(" norms, and any scalar form ")#mi("{f \\overline{g}}")#text(" with the inner product ")#mi("{\\langle f, g \\rangle_H}")#text("). For instance, one can verify the duality relationship")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^p(X \\rightarrow H)} = \\sup \\{ \\int_X \\langle f(x), g(x) \\rangle_H\\ d\\mu(x): \\left\\|g\\right\\|_{L^{p^{\\prime}}(X \\rightarrow H)} \\leq 1 \\}", block: true)]]

#text("whenever ")#mi("{1 \\leq p \\leq \\infty}")#text(" and ")#mi("{f \\in L^p(X \\rightarrow H)}")#text(". Also, the real interpolation theory continues to be valid in this setting (the basic reason being that the layer-cake decompositions, which depend only on the magnitude of the underlying function, continue to be valid).")

#text("Observe that if ")#mi("{f: X \\rightarrow H}")#text(" is absolutely integrable on some set ")#mi("{E}")#text(", thus ")#tao-math("{\\int_E \\left\\|f(x)\\right\\|_H\\ d\\mu(x) < \\infty}", block: false)#text(", then one can define the vector-valued integral ")#mi("{\\int_E f(x)\\ d\\mu(x) \\in H}")#text(" in several ways, for instance by using duality")

#align(center)[#tao-fit-display[#mitex("\\langle \\int_E f(x)\\ d\\mu(x), g\\rangle_H := \\int_E \\langle f(x), g \\rangle_H \\ d\\mu(x).")]]

#text("In particular, for locally integrable vector-valued functions ")#mi("{f}")#text(", we can compute averages ")#tao-math("{\\frac{1}{\\left|B\\right|} \\int_B f}", block: false)#text(" for balls or cubes ")#mi("{B}")#text(".")

#text("Let ")#mi("{B(H \\rightarrow H^{\\prime})}")#text(" denote the bounded linear operators of ")#mi("{H}")#text(" to ")#mi("{H^{\\prime}}")#text(", with the usual operator norm.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 42 (Vector-valued singular kernels)")]#text(" Let ")#mi("{H, H^{\\prime}}")#text(" be Hilbert spaces. A ")#emph[#text("singular kernel from ")#mi("{H}")#text(" to ")#mi("{H^{\\prime}}")]#text(" is a function ")#mi("{K: {\\bf R}^d \\times {\\bf R}^d \\rightarrow B(H \\rightarrow H^{\\prime})}")#text(" (defined away from the diagonal ")#mi("{x=y}")#text(") which obeys the decay estimate")

#metadata(none) <tao-91b96eac94642a571134>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left\\|K(x,y)\\right\\|_{B(H \\rightarrow H^{\\prime})} \\lesssim \\left|x-y\\right|^{-d}", block: true)]]

#text("for ")#mi("{x \\neq y}")#text(" and the Hölder-type regularity estimates")

#metadata(none) <tao-d9847e9e8a86e536755c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left\\| K(x,y^{\\prime}) - K(x,y) \\right\\|_{B(H \\rightarrow H^{\\prime})} = O\\left( \\frac{\\left|y-y^{\\prime}\\right|^\\sigma}{\\left|x-y\\right|^{d+\\sigma}} \\right) \\text{ whenever } \\left|y-y^{\\prime}\\right| \\leq \\frac{1}{2} \\left|x-y\\right|", block: true)]]

#text("and")

#metadata(none) <tao-c665176cae2e7a05f219>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\left\\| K(x^{\\prime},y) - K(x,y) \\right\\|_{B(H \\rightarrow H^{\\prime})} = O\\left( \\frac{\\left|x-x^{\\prime}\\right|^\\sigma}{\\left|x-y\\right|^{d+\\sigma}} \\right) \\text{ whenever } \\left|x-x^{\\prime}\\right| \\leq \\frac{1}{2} \\left|x-y\\right|", block: true)]]

#text("for some ")#emph[#text("Hölder exponent")]#text(" ")#mi("{0 < \\sigma \\leq 1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 43 (Vector-valued Calderón–Zygmund operators)")]#text(" A ")#emph[#text("Calderón–Zygmund operator")]#text(" (CZO) from ")#mi("{H}")#text(" to ")#mi("{H^{\\prime}}")#text(" is a linear operator ")#mi("{T: L^2({\\bf R}^d \\rightarrow H) \\rightarrow L^2({\\bf R}^d \\rightarrow H^{\\prime})}")#text(" which is bounded,")

#align(center)[#tao-fit-display[#tao-math("\\left\\|Tf\\right\\|_{L^2({\\bf R}^d \\rightarrow H^{\\prime})} \\lesssim \\left\\|f\\right\\|_{L^2({\\bf R}^d \\rightarrow H)},", block: true)]]

#text("and such that there exists a singular kernel ")#mi("{K}")#text(" from ")#mi("{H}")#text(" to ")#mi("{H^{\\prime}}")#text(" for which")

#align(center)[#tao-fit-display[#mitex("Tf(y) = \\int_{{\\bf R}^d} K(x,y) f(x)\\ dx")]]

#text("whenever ")#mi("{f \\in L^2({\\bf R}^d \\rightarrow H)}")#text(" is compactly supported, and ")#mi("{y}")#text(" lies outside of the support of ")#mi("{f}")#text(". Note that the integral here is an absolutely convergent Hilbert space-valued integral.")
]

#text("One can then repeat the derivation of Corollary ")#link(<tao-ee2c824064e426becdf2>)[#text("14")]#text(" more or less verbatim to show that vector-valued Calderón–Zygmund operators continue to be bounded from ")#mi("{L^p({\\bf R}^d \\rightarrow H)}")#text(" to ")#mi("{L^p({\\bf R}^d \\rightarrow H^{\\prime})}")#text(" with bound ")#mi("{O_{d,p}(1)}")#text(". Note that the constants never depend on the dimension of ")#mi("{H}")#text(" and ")#mi("{H^{\\prime}}")#text(", and indeed this dimension may be infinite.")

#text("An important application of vector-valued Calderón–Zygmund theory is the ")#emph[#text("Littlewood–Paley inequality")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 44 (Upper Littlewood–Paley inequality)")]#text(" ")#metadata(none) <tao-41623cab9c346ed0f6ae>#text(" For each integer ")#mi("{j}")#text(", let ")#mi("{\\psi_j: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be a bump function adapted to an annulus ")#tao-math("{\\{ \\xi: \\left|\\xi\\right| \\sim 2^j \\}}", block: false)#text(". Then for any ")#mi("{1 < p < \\infty}")#text(" and ")#mi("{f \\in L^p({\\bf R}^d)}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_{j \\in {\\bf Z}} \\left|\\psi_j(D) f\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{p,d} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("and for any ")#mi("{f_j \\in L^p({\\bf R}^d)}")#text(" for ")#mi("{j \\in {\\bf Z}}")#text(" we have")

#metadata(none) <tao-be2702389457d26f8f8d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\left\\| \\sum_{j \\in {\\bf Z}} \\psi_j(D) f_j \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{p,d} \\left\\| (\\sum_{j \\in {\\bf Z}} \\left|f_j\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("where the sum in the left is conditionally convergent in ")#mi("{L^p}")#text(".")
]

#emph[#text("Proof:")]#text(" By monotone convergence it suffices to prove the claim assuming that only finitely many of the ")#mi("{\\psi_j}")#text(" are non-zero. (This step is not strictly necessary, but it lets us avoid unnecessary technicalities in what follows.) It suffices to prove the first claim, as the second follows from a standard duality argument.")

#text("We consider the vector-valued operator ")#mi("{T: L^2({\\bf R}^d) \\rightarrow L^2({\\bf R}^d; l^2({\\bf Z}))}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("T f := ( \\psi_j(D) f )_{j \\in {\\bf Z}},")]]

#text("thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\|Tf(x)\\right\\|_{l^2({\\bf Z})} = (\\sum_{j \\in {\\bf Z}} \\left|\\psi_j(D) f(x)\\right|^2)^{1/2}.", block: true)]]

#text("Since ")#tao-math("{\\sum_j \\left|\\psi_j\\right|^2 = O(1)}", block: false)#text(", we quickly see from Plancherel’s theorem that ")#mi("{T}")#text(" is strong-type ")#mi("{(2,2)}")#text(" with operator norm ")#mi("{O(1)}")#text(". Next, we observe that ")#mi("{T}")#text(" has a vector-valued kernel")

#align(center)[#tao-fit-display[#mitex("K(x,y) = ( \\check \\psi_j( y-x ) )_{j \\in {\\bf Z}}")]]

#text("where we identify such vectors with operators from ")#mi("{{\\bf C}}")#text(" to ")#mi("{l^2({\\bf Z})}")#text(" in the obvious manner. But as in the proof of the Hörmander–Mikhlin multiplier theorem we have")

#align(center)[#tao-fit-display[#tao-math("\\check \\psi_j (x) = O\\left( \\frac{1}{\\left|x\\right|^d} \\min( (2^j \\left|x\\right|)^d, (2^j \\left|x\\right|)^{-2} ) \\right)", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\nabla \\check \\psi_j (x) = O\\left( \\frac{1}{\\left|x\\right|^{d+1}} \\min( (2^j \\left|x\\right|)^{d+1}, (2^j \\left|x\\right|)^{-1} ) \\right)", block: true)]]

#text("from which we easily verify ")#link(<tao-91b96eac94642a571134>)[#text("(15)")]#text(", ")#link(<tao-d9847e9e8a86e536755c>)[#text("(16)")]#text(", ")#link(<tao-c665176cae2e7a05f219>)[#text("(17)")]#text(". The claim then follows from the vector-valued analogue of Corollary ")#link(<tao-ee2c824064e426becdf2>)[#text("14")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 45 (Two-sided Littlewood–Paley inequality)")]#text(" For each integer ")#mi("{j}")#text(", let ")#mi("{\\psi_j: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be a bump function adapted to an annulus ")#tao-math("{\\{ \\xi: \\left|\\xi\\right| \\sim 2^j \\}}", block: false)#text(". Suppose also that ")#tao-math("{\\sum_j \\left|\\psi_j\\right|^2 \\sim 1}", block: false)#text(". Then for any ")#mi("{1 < p < \\infty}")#text(" and ")#mi("{f \\in L^p({\\bf R}^d)}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_{j \\in {\\bf Z}} \\left|\\psi_j(D) f\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R}^d)} \\sim_{p,d} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}.", block: true)]]
]

#emph[#text("Proof:")]#text(" By density (and the preceding proposition) it suffices to prove this when ")#mi("{f}")#text(" is Schwartz.")

#text("From the preceding proposition we already have the upper bound; the task is to establish the lower bound. Let ")#mi("{\\tilde \\psi_j}")#text(" be bump functions adapted to a slightly wider annulus than ")#mi("{\\psi_j}")#text(", which equal ")#mi("{1}")#text(" on the support of ")#mi("{\\psi_j}")#text(". Writing")

#align(center)[#tao-fit-display[#tao-math("\\varphi_j := \\tilde \\psi_j \\frac{\\psi_j}{\\sum_j \\left|\\psi_j\\right|^2}", block: true)]]

#text("we verify that ")#mi("{\\varphi_j}")#text(" is also adapted to the same annulus as ")#mi("{\\psi_j}")#text(", and that we have the partition of unity ")#mi("{1 = \\sum_j \\varphi_j \\psi_j}")#text(". This leads to the identity")

#align(center)[#tao-fit-display[#mitex("f = \\sum_j \\varphi_j(D) \\psi_j(D) f")]]

#text("when ")#mi("{f}")#text(" is Schwartz, and hence by ")#link(<tao-be2702389457d26f8f8d>)[#text("(18)")]#text(" we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^p({\\bf R}^d)} \\lesssim_{p,d} \\left\\| (\\sum_j \\left|\\psi_j(D) f\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("as desired. ")#mi("\\Box")

#text("The quantity ")#tao-math("{(\\sum_{j \\in {\\bf Z}} \\left|\\psi_j(D) f\\right|^2)^{1/2}}", block: false)#text(" is known as a ")#emph[#text("Littlewood–Paley square function")]#text(" of ")#mi("{f}")#text(". One can view ")#mi("{\\psi_j(D) f}")#text(" as the component of ")#mi("{f}")#text(" whose frequencies have magnitude ")#mi("{\\sim 2^j}")#text(". The point of the inequality is that even though each component ")#mi("{\\psi_j(D) f}")#text(" may individually oscillate, no cancellation occurs between the components in the square function. This makes the square function more amenable than the original function ")#mi("{f}")#text(" when it comes to analyze operators (such as differential or pseudodifferential operators) which treat each frequency component in a different way.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 46 (Continuous Littlewood–Paley inequality)")]#text(" ")#metadata(none) <tao-a1646e793fe3dca0615c>#text(" For every ")#mi("{t > 0}")#text(", let ")#mi("{\\psi_t: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be a function obeying the estimates")

#align(center)[#tao-fit-display[#tao-math("\\left|\\nabla^j \\psi_t(\\xi)\\right| \\lesssim_d t^{-j} \\min( (\\left|\\xi\\right|/2^j)^{-\\varepsilon}, (\\left|\\xi\\right|/2^j)^{\\varepsilon} )", block: true)]]

#text("for all ")#mi("{0 \\leq j \\leq d+2}")#text(", all ")#mi("{\\xi \\in {\\bf R}^d}")#text(", and some ")#mi("{\\varepsilon > 0}")#text(" (independent of ")#mi("{t}")#text("). Conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\left(\\int_0^\\infty \\left|\\psi_t(D) f\\right|^2 \\frac{dt}{t}\\right)^{1/2} \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{p,d} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("for ")#mi("{f \\in L^p({\\bf R}^d)}")#text(". If we also have the pointwise bound ")#tao-math("{\\int_0^\\infty \\left|\\psi_t\\right|^2 \\frac{dt}{t} \\sim 1}", block: false)#text(", improve this bound to")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\left(\\int_0^\\infty \\left|\\psi_t(D) f\\right|^2 \\frac{dt}{t}\\right)^{1/2} \\right\\|_{L^p({\\bf R}^d)} \\sim_{p,d} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}.", block: true)]]
]

#heading(level: 1)[#strong[#text(" — 5.1. An alternate approach via Khintchine’s inequality — ")]]

#text("One can avoid dealing with vector-valued CZOs by instead using randomized signs as a substitute. The key tool is the following inequality, which roughly speaking asserts that a random walk with steps ")#mi("{x_1,\\ldots,x_N}")#text(" is extremely likely to have magnitude about ")#tao-math("{(\\sum_{j=1}^N \\left|x_j\\right|^2)^{1/2}}", block: false)#text(", and can be viewed as a variant of the law of large numbers:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 47 (Khintchine’s inequality for scalars)")]#text(" Let ")#mi("{x_1,\\ldots,x_N}")#text(" be complex numbers, and let ")#mi("{\\epsilon_1,\\ldots,\\epsilon_N \\in \\{-1,1\\}}")#text(" be independent random signs, drawn from ")#mi("{\\{-1,1\\}}")#text(" with the uniform distribution. Then for any ")#mi("{0 < p < \\infty}")

#align(center)[#tao-fit-display[#tao-math("( \\mathop{\\bf E} \\left|\\sum_{j=1}^N \\epsilon_j x_j\\right|^p )^{1/p} \\sim_p (\\sum_{j=1}^N \\left|x_j\\right|^2)^{1/2}.", block: true)]]
]

#emph[#text("Proof:")]#text(" By the triangle inequality it suffices to prove this when the ")#mi("{x_j}")#text(" are real. When ")#mi("{p=2}")#text(" we observe that")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E} \\left|\\sum_{j=1}^N \\epsilon_j x_j\\right|^2 = \\mathop{\\bf E} \\sum_{1 \\leq j,j^{\\prime} \\leq N} \\epsilon_j \\epsilon_{j^{\\prime}} x_j x_{j^{\\prime}} = \\sum_{j=1}^N x_j^2", block: true)]]

#text("since ")#mi("{\\epsilon_j \\epsilon_{j^{\\prime}}}")#text(" has expectation ")#mi("{0}")#text(" when ")#mi("{j \\neq j^{\\prime}}")#text(" and ")#mi("{1}")#text(" when ")#mi("{j=j^{\\prime}}")#text(". This proves the claim for ")#mi("{p=2}")#text(". By Hölder’s inequality this gives the upper bound for ")#mi("{p \\leq 2}")#text(" and the lower bound for ")#mi("{p \\geq 2}")#text(". Hölder also shows us that the lower bound for ")#mi("{p \\leq 2}")#text(" will follow from the upper bound for ")#mi("{p \\geq 2}")#text(", so it remains to prove the upper bound for ")#mi("{p \\geq 2}")#text(".")

#text("We will use the “exponential moment method”. We normalize ")#tao-math("{\\sum_{j=1}^N \\left|x_j\\right|^2 = 1}", block: false)#text(". Now consider the expression")

#align(center)[#tao-fit-display[#mitex("\\begin{array}{rl}  \\mathop{\\bf E} \\exp \\sum_{j=1}^N \\epsilon_j x_j &= \\mathop{\\bf E} \\prod_{j=1}^N \\exp \\epsilon_j x_j \\\\ &= \\prod_{j=1}^N \\mathop{\\bf E} \\exp \\epsilon_j x_j \\\\ &= \\prod_{j=1}^N \\cosh x_j. \\end{array}")]]

#text("A comparison of Taylor series reveals the inequality")

#align(center)[#tao-fit-display[#mitex("\\cosh x_j \\leq \\exp (x_j^2 / 2)")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\exp \\sum_{j=1}^N \\epsilon_j x_j \\leq \\exp \\sum_{j=1}^N x_j^2 / 2 \\lesssim 1.")]]

#text("By Markov’s inequality we conclude")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf P}( \\sum_{j=1}^N \\epsilon_j x_j \\geq \\lambda ) \\lesssim e^{-\\lambda}")]]

#text("and hence (by the symmetry of the ")#mi("{\\epsilon_j}")#text(")")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf P}( \\left|\\sum_{j=1}^N \\epsilon_j x_j\\right| \\geq \\lambda ) \\lesssim e^{-\\lambda}.", block: true)]]

#text("The claim then follows from the distributional representation of the ")#mi("{L^p}")#text(" norm. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 48")]#text(" It is instructive to prove Khintchine’s inequality directly for even exponents such as ")#mi("{p=4}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 49 (Khintchine’s inequality for functions)")]#text(" Let ")#mi("{f_1,\\ldots,f_N \\in L^p(X)}")#text(" for some ")#mi("{0 < p < \\infty}")#text(", and let ")#mi("{\\epsilon_1,\\ldots,\\epsilon_N \\in \\{-1,1\\}}")#text(" be independent random signs, drawn from ")#mi("{\\{-1,1\\}}")#text(" with the uniform distribution. Then for any ")#mi("{0 < p < \\infty}")

#align(center)[#tao-fit-display[#tao-math("( \\mathop{\\bf E} \\left\\|\\sum_{j=1}^N \\epsilon_j f_j\\right\\|_{L^p(X)}^p )^{1/p} \\sim_p \\left\\| (\\sum_{j=1}^N \\left|f_j\\right|^2)^{1/2} \\right\\|_{L^p(X)}.", block: true)]]
]

#emph[#text("Proof:")]#text(" Apply the above inequality to the sequence ")#mi("{f_1(x),\\ldots,f_N(x)}")#text(" for each ")#mi("{x \\in X}")#text(" and then take ")#mi("{L^p}")#text(" norms of both sides. ")#mi("\\Box")

#text("This gives the following alternate proof of Proposition ")#link(<tao-41623cab9c346ed0f6ae>)[#text("44")]#text(". Once again we may restrict to only finitely many of the ")#mi("{\\psi_j}")#text(" being non-zero. Observe that for arbitrary choices of signs ")#mi("{\\epsilon_j \\in \\{-1,1\\}}")#text(", that the sum ")#mi("{\\sum_j \\epsilon_j \\psi_j}")#text(" obeys the homogeneous symbol estimates of order ")#mi("{0}")#text(". Thus by the Hörmander–Mikhlin theorem we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_j \\epsilon_j \\psi_j(D) f \\right\\|_{L^p({\\bf R}^d)}^p \\lesssim_{p,d} \\left\\|f\\right\\|_{L^p({\\bf R}^d)}^p", block: true)]]

#text("for ")#mi("{1 < p < \\infty}")#text(". Taking expectations and using Khintchine’s inequality we obtain the claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 50 (Chernoff’s inequality)")]#text(" ")#metadata(none) <tao-312b1434e5fadbe2ecc7>#text(" If ")#mi("{x_1,\\ldots,x_N}")#text(" are complex numbers of magnitude at most one, establish the inequality")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf P}( \\left|\\sum_{j=1}^N \\epsilon_j x_j\\right| \\geq \\lambda (\\sum_{j=1}^N \\left|x_j\\right|^2)^{1/2} ) \\lesssim e^{-\\lambda^2/4}", block: true)]]

#text("for all ")#tao-math("{0 < \\lambda \\leq 2 (\\sum_{j=1}^N \\left|x_j\\right|^2)^{1/2}}", block: false)#text(". (Hint: look at ")#mi("{\\exp( t \\sum_{j=1}^N \\epsilon_j x_j )}")#text(" for a real parameter ")#mi("{t}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 51 (Marcinkiewicz–Zygmund vector extension)")]#text(" ")#metadata(none) <tao-6afc5aa1e91af2454cfd>#text(" Let ")#mi("{T}")#text(" be a linear operator on ")#mi("{L^p({\\bf R}^d)}")#text(" with operator norm ")#mi("{1}")#text(". Show that for any functions ")#mi("{f_1,f_2,\\ldots \\in L^p({\\bf R}^d)}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_{n=1}^\\infty \\left|T f_n\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R}^d)} \\lesssim_p \\left\\| (\\sum_{n=1}^\\infty \\left|f_n\\right|^2)^{1/2} \\right\\|_{L^p({\\bf R}^d)}.", block: true)]]

#text("(Hint: reduce to finite summation and use Khintchine’s inequality.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 52 (BMO Littlewood–Paley inequality)")]#text(" ")#metadata(none) <tao-8ba4287b7c6654d78cf8>#text(" For each integer ")#mi("{j}")#text(", let ")#mi("{f_j \\in L^\\infty({\\bf R}^d)}")#text("; assume that all but finitely many of the ")#mi("{f_j}")#text(" are non-zero. Let ")#mi("{\\psi_j}")#text(" be as in Proposition ")#link(<tao-41623cab9c346ed0f6ae>)[#text("44")]#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_j \\psi_j(D) f_j \\right\\|_{\\mathrm{BMO}({\\bf R}^d)} \\lesssim_d \\left\\| (\\sum_j \\left|f_j\\right|^2)^{1/2} \\right\\|_{L^\\infty({\\bf R}^d)}.", block: true)]]

#text("(It is possible to remove the hypothesis that finitely many of the ")#mi("{f_j}")#text(" are non-zero, but then some care must be taken to define ")#mi("{\\sum_j \\psi_j(D) f_j}")#text("; in particular it will only be defined modulo a constant.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 53 (Zygmund’s inequality)")]#text(" ")#metadata(none) <tao-fa5133b2c17c93c75ece>#text(" For each positive integer ")#mi("{n}")#text(", let ")#mi("{\\xi_n}")#text(" be an integer with ")#tao-math("{\\left|\\xi_n\\right| \\sim 2^n}", block: false)#text(", and let ")#mi("{c_n}")#text(" be a complex number with ")#tao-math("{\\sum_n \\left|c_n\\right|^2}", block: false)#text(" finite. Show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| c_n e^{2\\pi i \\xi_nx} \\right\\|_{e^{L^2}({\\bf T})} \\sim (\\sum_n \\left|c_n\\right|^2)^{1/2}", block: true)]]

#text("and in particular that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| c_n e^{2\\pi i \\xi_nx} \\right\\|_{L^p({\\bf T})} \\sim_p (\\sum_n \\left|c_n\\right|^2)^{1/2}", block: true)]]

#text("for all ")#mi("{2 \\leq p < \\infty}")#text(". Dually, for any ")#mi("{f \\in L \\log^{1/2} L({\\bf T})}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("(\\sum_n \\left|\\hat f(\\xi_n)\\right|^2)^{1/2} \\lesssim \\left\\|f\\right\\|_{L \\log^{1/2} L({\\bf T})}", block: true)]]

#text("and in particular that")

#align(center)[#tao-fit-display[#tao-math("(\\sum_n \\left|\\hat f(\\xi_n)\\right|^2)^{1/2} \\lesssim_p \\left\\|f\\right\\|_{L^p({\\bf T})}", block: true)]]

#text("for all ")#mi("{1 < p \\leq\\infty}")#text(".")
]

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/27/247a-notes-3-singular-integral-operators/comment-page-1/#comment-698867")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2026")])]

#text("Prof. Tao:")

#emph[#text("Then Cauchy’s theorem gives …=f(x+iε), ")]#text("should be f(x).")

#emph[#text("[Corrected, thanks – T.]/")]

#emph[#text("Applying the Vitali type covering lemma as in the proof of the Hardy–Littlewood maximal inequality")]#text(", I’m stuck here – I don’t understand why the Vitali type covering lemma works here and in the proof of the Hardy–Littlewood maximal inequality, and I also don’t want to treat the Hardy–Littlewood maximal inequality as a black box. Why are they both suitable for being proved using the Vitali covering lemma?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/27/247a-notes-3-singular-integral-operators/comment-page-1/#comment-698879")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("You can choose, for every x in K, a ball B_x for which $|B_x|^{-1} \\int_{B_x} |F| > \\lambda_0$. These balls cover K. Then select a finite subcover of K using compactness of K, and select balls as in the proof of the Vitali covering lemma: start by selecting the largest ball, keep removing remaining balls that intersect the already chosen balls, choose the next largest one, etc. Then you obtain a subcollection with the properties described in the notes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c275452b756f7ead63273293dd93f003296273a9f9c5e771e60b0f0c780931cd-e1a4b89b77edd374a12c4f7494b6824987eb17e043293646e437282540511366.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jesusasit")]], [#link("https://terrytao.wordpress.com/2026/10/27/247a-notes-3-singular-integral-operators/comment-page-1/#comment-698893")[#strong[#text("jesusasit")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("Reading your notes end to end, Professor. Of course, barely following, but mesmerized by the elegance of the equivalences, substitutions and lifts, and especially by the oscillatory, almost liminal nature that I can somehow visualize in them.")

#text("Would any of this be worth exploring in hyperbolic spaces, perhaps with hypercomplex-valued fibers?")

#text("I’m asking because, with AI guidance, I’m exploring an extension of my connection Laplacian Lean formalization towards covariant Riesz transforms and Littlewood–Paley spectral decompositions.")

#text("For context, this is my still-evolving Lean formalization: ")#link("https://github.com/jesusvilela/connection_laplacian_lean?utm_source=chatgpt.com")[#text("https://github.com/jesusvilela/connection_laplacian_lean")]
]
