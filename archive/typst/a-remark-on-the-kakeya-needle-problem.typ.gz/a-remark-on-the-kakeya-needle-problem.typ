// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/
// Converted to Typst by tao2typ: "2026-10-14T16:35:30.160123+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A remark on the Kakeya needle problem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A remark on the Kakeya needle problem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 December 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/")[#text("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In 1917, Soichi Kakeya posed the following problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("http://en.wikipedia.org/wiki/Kakeya_set")[#strong[#text("Kakeya needle problem.")]]#text(" What is the least amount of area required to continuously rotate a unit line segment in the plane by a full rotation (i.e. by ")#mi("360^\\circ")#text(")?")
]

#text("In 1928, Besicovitch showed that given any ")#mi("\\varepsilon > 0")#text(", there exists a planar set of area at most ")#mi("\\varepsilon")#text(" within which a unit needle can be continuously rotated; the proof relies on the construction of what is now known as a ")#link("http://en.wikipedia.org/wiki/Kakeya_conjecture#Besicovitch_sets")[#text("Besicovitch set")]#text(" – a set of measure zero in the plane which contains a unit line segment in every direction. So the answer to the Kakeya needle problem is “zero”.")

#text("I was recently asked (by Claus Dollinger) whether one can take ")#mi("\\varepsilon = 0")#text("; in other words,")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Question.")]#text(" Does there exist a set of measure ")#emph[#text("zero")]#text(" within which a unit line segment can be continuously rotated by a full rotation?")
]

#text("This question does not seem to be explicitly answered in the literature. In the papers of ")#link("http://www.ams.org/mathscinet-getitem?mr=14688")[#text("von Alphen")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=275287")[#text("of Cunningham")]#text(", it is shown that it is possible to continuously rotate a unit line segment inside a set of arbitrarily small measure and of uniformly bounded diameter; this result is of course implied by a positive answer to the above question (since continuous functions on compact sets are bounded), but the converse is not true.")

#text("Below the fold, I give the answer to the problem… but perhaps readers may wish to make a guess as to what the answer is first before proceeding, to see how good their real analysis intuition is. (To partially prevent spoilers for those reading this post via RSS, I will be whitening the text; you will have to highlight the text in order to see it. Unfortunately, I do not know how to white out the LaTeX in such a way that it is visible upon highlighting, so RSS readers may wish to stop reading right now; but I suppose one can view the LaTeX as supplying hints to the problem, without giving away the full solution.)")

#text("[")#emph[#text("Update")]#text(", March 13: a non-whitened version of this article can be found as part of ")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/01/whatsnew.pdf")[#text("this book")]#text(".]")

#heading(level: 1)[#metadata(none) <tao-798ff1dfe614c5591f89>#text("— Solution —")]

#text("The answer to the question is …")#text(" ")#text("no")#text(".")#linebreak()

#text("To see this, let ")#mi("E \\subset {\\Bbb R}^2")#text(" be a set in the plane within which a unit line segment can be continuously rotated. This means that there exists a continuous map ")#mi("l: t \\mapsto l(t)")#text(" from times ")#mi("t \\in [0,1]")#text(" to unit line segments ")#mi("l(t) \\subset E")#text(". We can parameterise each such line segment as")

#align(center)[#tao-fit-display[#mitex("l(t) = \\{ (x(t) + s \\cos \\omega(t),y(t) + s \\sin \\omega(t) ): -0.5 \\leq s \\leq 0.5 \\}")]]

#text("where ")#mi("x, y, \\omega: [0,1] \\to {\\Bbb R}")#text(" are continuous functions.")

#align(center)[#emph[#text("[ Adding some padding here, ")]]

#align(center)[#emph[#text("to disguise the length of the proof,")]]

#align(center)[#emph[#text("and also because from this point onwards,")]]

#align(center)[#emph[#text("it’s pretty obvious that ")]]

#align(center)[#emph[#text("we are proving that ")]]

#align(center)[#emph[#text("the answer to the question is negative,")#linebreak()#text(" ")]]

#align(center)[#emph[#text("rather than trying to build an example. ]")]]

#text("Recall that on a compact set, all continuous functions are uniformly continuous. In particular, there exists ")#mi("\\varepsilon > 0")#text(" such that")

#align(center)[#tao-math("\\left|x(t)-x(t^{\\prime})\\right|, \\left|y(t)-y(t^{\\prime})\\right|, \\left|\\omega(t)-\\omega(t^{\\prime})\\right| \\leq 0.001", block: false)#text(" (1)")#linebreak()]

#text("(say) whenever ")#mi("t, t^{\\prime} \\in [0,1]")#text(" are such that ")#tao-math("\\left|t-t^{\\prime}\\right| \\leq \\varepsilon", block: false)#text(".")

#text("Fix this ")#mi("\\varepsilon")#text(". Observe that ")#mi("\\omega(t)")#text(" cannot be a constant function of t, otherwise the needle would never rotate. We conclude that there must exist ")#mi("t_0, t_1 \\in [0,1]")#text(" with ")#tao-math("\\left|t_0-t_1\\right| \\leq \\varepsilon", block: false)#text(" and ")#mi("\\omega(t_0) \\neq \\omega(t_1)")#text(".")

#text("Without loss of generality, we may assume that ")#mi("t_0 < t_1")#text(" and ")#mi("x(t_0)=y(t_0)=\\omega(t_0)=0")#text(".")

#align(center)[#emph[#text("[ A little more padding,")]]

#align(center)[#emph[#text("again to disguise ")]]

#align(center)[#emph[#text("the length of the proof. ]")]]

#text("Now let a be any real number between -0.4 and +0.4. From (1) we see that for any ")#mi("t_0 \\leq t \\leq t_1")#text(", the line l(t) intersects the line x=a in some point ")#mi("(a, y_a(t))")#text(", which must therefore lie in E. Furthermore, ")#mi("y_a(t)")#text(" varies continuously in t. By the intermediate value theorem, we conclude that the interval between ")#mi("(a,y_a(t_0))")#text(" and ")#mi("(a,y_a(t_1))")#text(" lies in E. Taking unions over all a between -0.4 and +0.4, we see that E contains a non-trivial sector, and thus has non-zero area. The claim follows.")

#strong[#text("Remark. ")]#text("A variant of this argument shows a stronger statement, namely that for any fixed c>0, any set E whose measure is sufficiently small (depending on c) within which a unit line segment can be rotated by at least c, must have a diameter of at least 2-c. (A similar point was already made in the Cunningham paper referenced above.) ")#mi("\\diamond")#linebreak()

#linebreak()

#linebreak()

#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8a5af20c50a7d7724a4ba118259f1acbfae79ce228188cc91911d7da24ccadd9-294703c515e4321a4d100bc42d11f010d32d2bbd3c6ed7c1e90d35305338cc68.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous Rex")]], [#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-34535")[#strong[#text("Anonymous Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2008")])]

#text("Attempting to use white, too: Is the gist of the argument simply that “you must rotate the needle”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8a5af20c50a7d7724a4ba118259f1acbfae79ce228188cc91911d7da24ccadd9-294703c515e4321a4d100bc42d11f010d32d2bbd3c6ed7c1e90d35305338cc68.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous Rex")]], [#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-34536")[#strong[#text("Anonymous Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2008")])]

#text("Sorry, WordPress filtered out my whitening HTML. In any case, happy new year! Thank you for another great year of this blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/51e00527bc2f8bdbf9ef08ad838cc6f20a3f0aa9aeb5c480835ce1c2cf23deb7-76a093204f4903be03544ab7e978a4e7c0d898d6dd1944d02b00412b3fdf296c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michael  john hung")]], [#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-34538")[#strong[#text("michael  john hung")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2008")])]

#text("This possibly is a dynamic plane, from the plane’s characteristics, I think rotation that can be use by a depth analysis, if the times of rotation , the algebra is more likely to find a formula to solve this problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-34544")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2008")])]

#text("Dear Terry, but how do you white out the tex itself in such a way that it is visible upon highlighting? This is a cool idea.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-34578")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2009")])]

#text("Dear Gil,")

#text("I don’t know how to pull it off for the TeX, but for the text, I simply change the text colour to white (this can be done on using the second row of the various buttons offered by the wordpress visual editor, which can be opened up after clicking on one of the buttons on the first row).")

#text("As for the TeX, I tried colouring the text white, which did make it invisible, but then highlighting did not reveal the TeX. (One can still hover the mouse over the image to get the raw TeX source, but one may as well just in plain text in that case.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/743ec659e95a03c26d192883fa7bbe7647704868ea113c827a627daa82ded8e0-dbc98e08ce176ef4ec67b629e09f1f3d2786817a4f2ebdb07194ca7cd341d047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil")]], [#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-34584")[#strong[#text("Gil")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2009")])]

#text("Thanks Terry. I will try it next time I ask a riddle.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/712b13b10cf634809566720090af68af2fa43f60bd0447da1a214c67a0305d0e-3c80186d184c38a83f5932238a679b0146e84c7afb11688fd7127d34e0b42b28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mugwump")]], [#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-34609")[#strong[#text("mugwump")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2009")])]

#text("Neat. And elementary too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9daa8798e2f584d3e1bc313af396c60b94c2d1be3b4fd0d7acb7d5cf5d708469-0d49bad43476ba280ad205e61a794696af5aeaa5c2568dd60e25a3b10959d9ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Toby O'Neil")]], [#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-35224")[#strong[#text("Toby O'Neil")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2009")])]

#text("Hi")

#text("Although it is not possible to rotate a needle ")#emph[#text("continuously")]#text(" in a set of plane measure zero, it is possible to do it using a Baire-1 function (a pointwise limit of continuous functions). It’s not terribly difficult to see this provided one is familiar with using the method of duality for constructing Besicovitch sets.")

#text("The details are written up in a short note available from ")#link("http://arxiv.org/abs/0901.3456")[#text(" arXiv:0901.3456v1")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/19076f1be432e2d3271e62d3a688f713ecbd409fedc2b7584731bffbbb523c93-dc883af6035cd3ad593be6d740dc601dd0124dd22985684ceb1645a0abae028d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sutanu Roy")]], [#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-36187")[#strong[#text("Sutanu Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2009")])]

#text("Dear Sir Terence Tao,")

#text("Can you give me some source link of application of kakeya Needle problem?")#linebreak()#text(" I read your paper “from rotating needle…”.")#linebreak()#text(" But I need a complete proof of Fefferman’s Theorem using Kakeya.")#linebreak()#text(" you just mentioned the outline there.")#linebreak()#text(" can you please suggest me a detailed proof of that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-36194")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2009")])]

#text("Dear Sutanu,")

#text("You can try Fefferman’s original paper,")

#text("Fefferman, Charles The multiplier problem for the ball. Ann. of Math. (2) 94 (1971), 330–336.")

#text("or Tom Wolff’s book on harmonic analysis,")

#text("Wolff, Thomas H. Lectures on harmonic analysis. With a foreword by Charles Fefferman and preface by Izabella Łaba. Edited by Łaba and Carol Shubin. University Lecture Series, 29. American Mathematical Society, Providence, RI, 2003. x+137 pp. ISBN: 0-8218-3449-5")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/19076f1be432e2d3271e62d3a688f713ecbd409fedc2b7584731bffbbb523c93-dc883af6035cd3ad593be6d740dc601dd0124dd22985684ceb1645a0abae028d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sutanu Roy")]], [#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-36204")[#strong[#text("Sutanu Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2009")])]

#text("Dear Sir Terence Tao,")

#text("Thanks for giving me the links. It will help me a lot to find what I wanted.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Just a passerby")]], [#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-36637")[#strong[#text("Just a passerby")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2009")])]

#text("The Solution Section looks ugly because the author only hid the plain text without the compiled math symbols…:~")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-38159")[#strong[#text("Kakeya Sets in R^2 « Matthew’s Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2009")]

#text("[…] it moves within the planar set K, and in fact, this is closer to the precise problem Kakeya asked. Terry Tao addresses this analog using only the usual tools and language of analysis that should make sense to any fluent veteran of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Recent progress on the Kakeya conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-38691")[#strong[#text("Recent progress on the Kakeya conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2009")])]

#text("[…] a unit line segment by ?) is that a unit needle can be rotated in arbitrarily small area (see this previous blog post of mine for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-39180")[#strong[#text("Kakeya猜想的最新进展 « Junfli’s Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2009")]

#text("[…] 给定一个上的紧子集")#mi("Esubset mathbb R^n")#text(", 它包含所有方向的单位向量。猜想的Hausdorff维枢和Minkowski维数为。 这个包含各个方向单位向量的集合就是Kakeya集。Besicovitch已经证明当时，Kakeya集可以具有任意小Letesgue测度；实际上，它的Lebesgue测度可以使0。这也就是说Kakeya针问题（在一个平面上转动一个单位线段化过的最小面积是多少）的解是这个集合的面积可以是任意小（详细讨论点击进入）。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed7571e22dd00bf24cffea80472f8ec320b3401a0109c7102a69fdd9742ebf1a-920070984b07e652b6bea948f42739208e48678997192cf26684f0fd5c47963d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Punting in clearings of arbitrarily small Lebesgue measure | Complex Projective 4-Space")]], [#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-248601")[#strong[#text("Punting in clearings of arbitrarily small Lebesgue measure | Complex Projective 4-Space")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2013")])]

#text("[…] be obtained, i.e. there is no set of zero Lebesgue measure in which we can rotate a punt (c.f. this proof by Terence Tao). There are, however, measure-zero fractal sets obeying the strictly weaker property […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/575c12bb99c649382d8a8e3ecdb8c9ef83868e2d5356d0c2d9b806fcff8119cd-af2fe4f90c96f7d0e0c165a50631470e0b059348bb0552da3f2e0406994c2b92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-476892")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2017")])]

#text("Check out Charles Fefferman’s solution simply by typing “Yhe kikaya needle into you tube,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-601160")[#strong[#text("Moving Sofas in the Apocalypse | 3 Quarks Daily")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2020")]

#text("[…] [5] See here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb93277246d27483db84dbdf8b958efe326e092bd255e477b90b7e0ecb44ab12-86f20ba181a3633c7728b3039c49825d1088a9248cab6746d91b450b369d6de0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kakeya 转针问题 & 何为维度 – 南外数学逻辑与生活社")]], [#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/#comment-637985")[#strong[#text("Kakeya 转针问题 & 何为维度 – 南外数学逻辑与生活社")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2021")])]

#text("[…] 为什么 Kakeya 集的大小 >0 — ")#link("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/")[#text("https://terrytao.wordpress.com/2008/12/31/a-remark-on-the-kakeya-needle-problem/")]#text(" […]")
]
