// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/
// Converted to Typst by tao2typ: "2026-10-14T16:35:05.534997+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Hilbert’s nullstellensatz", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Hilbert’s nullstellensatz")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 November 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/")[#text("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I had occasion recently to look up the proof of ")#link("http://en.wikipedia.org/wiki/Nullstellensatz")[#text("Hilbert’s nullstellensatz")]#text(", which I haven’t studied since cramming for my algebra qualifying exam as a graduate student. I was a little unsatisfied with the proofs I was able to locate – they were fairly abstract and used a certain amount of algebraic machinery, which I was terribly rusty on – so, as an exercise, I tried to find a more computational proof that avoided as much abstract machinery as possible. I found a proof which used only the ")#link("http://en.wikipedia.org/wiki/Extended_Euclidean_algorithm")[#text("extended Euclidean algorithm")]#text(" and high school algebra, together with an induction on dimension and the obvious observation that any non-zero polynomial of one variable on an algebraically closed field has at least one non-root. It probably isn’t new (in particular, it might be related to the standard model-theoretic proof of the nullstellensatz, with the Euclidean algorithm and high school algebra taking the place of ")#link("http://en.wikipedia.org/wiki/Quantifier_elimination")[#text("quantifier elimination")]#text("), but I thought I’d share it here anyway.")

#text("Throughout this post, F is going to be a fixed ")#link("http://en.wikipedia.org/wiki/Algebraically_closed_field")[#text("algebraically closed field")]#text(" (e.g. the complex numbers ")#mi("{\\Bbb C}")#text("). I’d like to phrase the nullstellensatz in a fairly concrete fashion, in terms of the problem of solving a set of simultaneous polynomial equations ")#mi("P_1(x) = \\ldots = P_m(x) = 0")#text(" in several variables ")#mi("x = (x_1,\\ldots,x_d) \\in F^d")#text(" over F, thus ")#mi("P_1,\\ldots,P_m \\in F[x]")#text(" are polynomials in d variables. One obvious obstruction to solvability of this system is if the equations one is trying to solve are ")#emph[#text("inconsistent")]#text(" in the sense that they can be used to imply 1=0. In particular, if one can find polynomials ")#mi("Q_1,\\ldots,Q_m \\in F[x]")#text(" such that ")#mi("P_1 Q_1 + \\ldots + P_m Q_m = 1")#text(", then clearly one cannot solve ")#mi("P_1(x)=\\ldots=P_m(x)=0")#text(". The ")#emph[#text("weak nullstellensatz")]#text(" asserts that this is, in fact, the only obstruction:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Weak nullstellensatz")]#text(". Let ")#mi("P_1,\\ldots,P_m \\in F[x]")#text(" be polynomials. Then exactly one of the following statements holds:")

#enum(start: 1, 
[#text("The system of equations ")#mi("P_1(x)=\\ldots=P_m(x)=0")#text(" has a solution ")#mi("x \\in F^d")#text(".")],
[#text("There exist polynomials ")#mi("Q_1,\\ldots,Q_m \\in F[x]")#text(" such that ")#mi("P_1 Q_1 + \\ldots + P_m Q_m = 1")#text(".")]
)
]

#text("Note that the hypothesis that F is algebraically closed is crucial; for instance, if F is the reals, then the equation ")#mi("x^2+1=0")#text(" has no solution, but there is no polynomial ")#mi("Q(x)")#text(" such that ")#mi("(x^2+1) Q(x) = 1")#text(".")

#text("Like many results of the “The only obstructions are the obvious obstructions” type, the power of the nullstellensatz lies in the ability to take a hypothesis about ")#emph[#text("non-existence")]#text(" (in this case, non-existence of solutions to ")#mi("P_1(x)=\\ldots=P_m(x)=0")#text(") and deduce a conclusion about ")#emph[#text("existence")]#text(" (in this case, existence of ")#mi("Q_1,\\ldots,Q_m")#text(" such that ")#mi("P_1 Q_1 + \\ldots + P_m Q_m = 1")#text("). The ability to get “something from nothing” is clearly going to be both non-trivial and useful. In particular, the nullstellensatz offers an important correspondence between ")#link("http://en.wikipedia.org/wiki/Algebraic_geometry")[#text("algebraic geometry")]#text(" (the conclusion 1 is an assertion that a certain ")#link("http://en.wikipedia.org/wiki/Algebraic_variety")[#text("algebraic variety")]#text(" is empty) and ")#link("http://en.wikipedia.org/wiki/Commutative_algebra")[#text("commutative algebra")]#text(" (the conclusion 2 is an assertion that a certain ")#link("http://en.wikipedia.org/wiki/Ideal_%28ring_theory%29")[#text("ideal")]#text(" is non-proper).")

#text("Now suppose one is trying to solve the more complicated system ")#mi("P_1(x)=\\ldots=P_d(x)=0; R(x) \\neq 0")#text(" for some polynomials ")#mi("P_1,\\ldots,P_d, R")#text(". Again, any identity of the form ")#mi("P_1 Q_1 + \\ldots + P_m Q_m = 1")#text(" will be an obstruction to solvability, but now more obstructions are possible: any identity of the form ")#mi("P_1 Q_1 + \\ldots + P_m Q_m = R^r")#text(" for some non-negative integer r will also obstruct solvability. The ")#emph[#text("strong nullstellensatz")]#text(" asserts that this is the only obstruction:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Strong nullstellensatz")]#text(". Let ")#mi("P_1,\\ldots,P_m, R \\in F[x]")#text(" be polynomials. Then exactly one of the following statements holds:")

#enum(start: 1, 
[#text("The system of equations ")#mi("P_1(x)=\\ldots=P_m(x)=0")#text(", ")#mi("R(x) \\neq 0")#text(" has a solution ")#mi("x \\in F^d")#text(".")],
[#text("There exist polynomials ")#mi("Q_1,\\ldots,Q_m \\in F[x]")#text(" and a non-negative integer r such that ")#mi("P_1 Q_1 + \\ldots + P_m Q_m = R^r")#text(".")]
)
]

#text("Of course, the weak nullstellensatz corresponds to the special case in which R=1. The strong nullstellensatz is usually phrased instead in terms of ideals and radicals, but the above formulation is easily shown to be equivalent to the usual version (modulo ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_basis_theorem")[#text("Hilbert’s basis theorem")]#text(").")

#text("One could consider generalising the nullstellensatz a little further by considering systems of the form ")#mi("P_1(x)=\\ldots=P_m(x)=0, R_1(x),\\ldots,R_n(x) \\neq 0")#text(", but this is not a significant generalisation, since all the ")#link("http://en.wikipedia.org/wiki/Inequation")[#text("inequations")]#text(" ")#mi("R_1(x) \\neq 0, \\ldots, R_n(x) \\neq 0")#text(" can be concatenated into a single inequation ")#mi("R_1(x) \\ldots R_n(x) \\neq 0")#text(". The presence of the exponent r in conclusion (2) is a little annoying; to get rid of it, one needs to generalise the notion of an algebraic variety to that of a ")#link("http://en.wikipedia.org/wiki/Scheme_%28mathematics%29")[#text("scheme")]#text(" (which is worth doing for several other reasons too, in particular one can now work over much more general objects than just algebraically closed fields), but that is a whole story in itself (and one that I am not really qualified to tell).")

#text("[")#emph[#text("Update")]#text(", Nov 26: It turns out that my approach is more complicated than I first thought, and so I had to revise the proof quite a bit to fix a certain gap, in particular making it significantly messier than my first version. On the plus side, I was able to at least eliminate any appeal to ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_basis_theorem")[#text("Hilbert’s basis theorem")]#text(", so in particular the proof is now manifestly effective (but with terrible bounds). In any case, I am keeping the argument here in case it has some interest.]")

#align(center)[#metadata(none) <tao-47bcdc52fb750e29a90f>]

#heading(level: 1)[#text("— The base case ")#mi("d=1")#text(" —")]

#text("I had initially posted here an attempted proof of the weak nullstellensatz by induction on dimension, and then deduced the strong nullstellensatz from the weak via a lifting trick of Zariski (the key observation being that the inequation ")#mi("x \\neq 0")#text(" was equivalent to the solvability of the equation ")#mi("xy-1 = 0")#text(" for some y). But I realised that my proof of the weak nullstellensatz was incorrect (it required the strong nullstellensatz in one lower dimension as the inductive hypothesis), and so now I am proceeding by establishing the strong nullstellensatz directly.")

#text("We shall induct on the dimension d (i.e. the number of variables in the system of equations).")

#text("The case d=0 is trivial, so we use the d=1 case as the base case, thus ")#mi("P_1, \\ldots, P_m, R")#text(" are all polynomials of one variable. This case follows easily from the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_algebra")[#text("fundamental theorem of algebra")]#text(", but it will be important for later purposes to instead use a more ")#emph[#text("algorithmic")]#text(" proof in which the coefficients of the polynomials ")#mi("Q_1,\\ldots,Q_m")#text(" required for (2) are obtained from the coefficients of ")#mi("P_1, \\ldots, P_m, R")#text(" in an explicitly computable fashion (using only the operations of addition, subtraction, multiplication, division, and branching on whether a given field element is zero or non-zero). In particular, one does not need to locate roots of polynomials in order to construct ")#mi("Q_1,\\ldots,Q_m")#text(" (although one will of course need to do so to locate a solution x to (1)). [It is likely that one could get these sorts of computability properties on ")#mi("Q_1,\\ldots,Q_m")#text(" “for free” from Galois theory, but I have not attempted to do so.] It is however instructive to secretly apply the fundamental theorem of algebra throughout the proof which follows, to clarify what is going on.")

#text("Let us say that a collection ")#mi("(P_1,\\ldots,P_m; R)")#text(" of polynomials ")#emph[#text("obeys the nullstellensatz")]#text(" if at least one of (1) and (2) is true. It is clear that (1) and (2) cannot both be true, so to prove the nullstellensatz it suffices to show that every collection ")#mi("(P_1,\\ldots,P_m; R)")#text(" obeys the nullstellensatz.")

#text("We can of course throw away any of the ")#mi("P_i")#text(" that are identically zero, as this does not affect whether ")#mi("(P_1,\\ldots,P_m;R)")#text(" obeys the nullstellensatz. If none of the ")#mi("P_i")#text(" remain, then we are in case (1), because the polynomial R has at most finitely many zeroes, and because an algebraically closed field must be infinite. So suppose that we have some non-zero ")#mi("P_i")#text(". We repeatedly use the ")#link("http://en.wikipedia.org/wiki/Extended_Euclidean_algorithm")[#text("extended Euclidean algorithm")]#text(" to locate the greatest common divisor D(x) of the remaining ")#mi("P_i")#text(". Note that this algorithm automatically supplies for us some polynomials ")#mi("Q_1(x),\\ldots,Q_m(x)")#text(" such that")

#align(center)[#mi("P_1(x) Q_1(x) + \\ldots + P_m(x) Q_m(x) = D(x)")#text(".")]

#text("Because of this, we see that ")#mi("(P_1,\\ldots,P_m;R)")#text(" obeys the nullstellensatz if and only if ")#mi("(D;R)")#text(" obeys the nullstellensatz. So we have effectively reduced to the case m=1.")

#text("Now we apply the extended Euclidean algorithm again, this time to D and R, to express the gcd D’ of D and R as a combination D’ = D A + R B, and also to factor D = D’ S and R = D’ T for some polynomials A, B, S, T with AS + BT = 1. A little algebra then shows that one has a solution to the problem")

#align(center)[#tao-fit-display[#mitex("D(x) = 0; R(x) \\neq 0")]]

#text("whenever one has a solution to the problem")

#align(center)[#mi("S(x) = 0; D^{\\prime}(x) \\neq 0")#text(".")]

#text("Also, if some power of D’ is a multiple of S, then some power of R is a multiple of D. Thus we see that if (S; D’) obeys the nullstellensatz, then (D; R) does also. But we see that the net degree of S and D’ is less than the net degree of D and R unless R is constant, so by infinite descent we may reduce to that case. If R is zero then we are clearly in case (2), so we may assume R is non-zero. If D is constant then we are again in case (2), so assume that D is non-constant. But then as the field is algebraically closed, D has at least one root, and so we are in case (1). This completes the proof of the d=1 case.")

#text("For the inductive step, it is important to remark that the above proof is ")#emph[#text("algorithmic")]#text(" in the sense that a computer which was given the coefficients for ")#mi("P_1,\\ldots,P_m,R")#text(" as inputs could apply a finite number of arithmetic operations (addition, subtraction, multiplication, division), as well as a finite number of branching operations based on whether a given variable was zero or non-zero, in order to output either")

#enum(start: 1, 
[#text("the coefficients of a non-constant polynomial D with the property that any root x of D would solve (1);")],
[#text("the coefficients of a non-zero polynomial R with the property that any non-root x of R would solve (1); or")],
[#text("the coefficients of polynomials ")#mi("Q_1,\\ldots,Q_m")#text(" which solved (2) for some specific r.")]
)

#text("In most cases, the number of branching operations is rather large (see for instance the example of solving two linear equations below). There is however one simple case in which only one branching is involved, namely when m=2, R=1, and ")#mi("P_1, P_2")#text(" are ")#link("http://en.wikipedia.org/wiki/Monic_polynomial")[#text("monic")]#text(". In this case, we have an identity of the form")

#align(center)[#tao-fit-display[#mitex("P_1 S_1 + P_2 S_2 = \\text{Res}(P_1,P_2)")]]

#text("where ")#mi("S_1,S_2")#text(" are polynomials (whose coefficients are polynomial combinations of the coefficients of ")#mi("P_1")#text(" and ")#mi("P_2")#text(" and ")#mi("\\text{Res}(P_1,P_2) \\in F")#text(" is the ")#link("http://en.wikipedia.org/wiki/Resultant")[#text("resultant")]#text(" of ")#mi("P_1")#text(" and ")#mi("P_2")#text(", which is another polynomial combination of the coefficients of ")#mi("P_1")#text(" and ")#mi("P_2")#text(". If the resultant is non-zero then we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\text{Res}(P_1,P_2)} S_1 P_1 + \\frac{1}{\\text{Res}(P_1,P_2)} S_2 P_2  = 1")]]

#text("and so the system is unsolvable (we are in case (2)); otherwise, the system is solvable.")

#heading(level: 1)[#text("— The inductive case ")#mi("d>1")#text(" —")]

#text("Now we do the inductive case, when ")#mi("d \\geq 2")#text(" and the claim has already been proven for d-1. The basic idea is to view the system (1) not as a system of equations in d unknowns, but as a d-1-dimensional family of systems in one unknown. We will then apply the d=1 theory to each system in that family and use the algorithmic nature of that theory to glue everything together properly.")

#text("We write the variable ")#mi("x \\in F^d")#text(" as ")#mi("x = (y, t)")#text(" for ")#mi("y \\in F^{d-1}")#text(" and ")#mi("t \\in F")#text(". The ring F[x] of polynomials in d variables can thus be viewed as a ring F[y][t] of polynomials in one variable t, in which the coefficients lie in the ring F[y].")

#text("Let I be the ideal in F[x] generated by ")#mi("P_1,\\ldots,P_m")#text(". We either need to solve the system")

#align(center)[#mi("P_1(y,t) = \\ldots = P_m(y,t) = 0")#text("; ")#mi("R(y,t) \\neq 0")#text(" (1)")]

#text("or show that")

#align(center)[#mi("R^r = 0 \\text{ mod } I")#text(" for some r. (2)")]

#text("We assume that no solution to (1) exists, and use this to synthesise a relation of the form (2).")

#text("Let ")#mi("y \\in F^{d-1}")#text(" be arbitrary. We can view the polynomials ")#mi("P_1(y,t),\\ldots,P_m(y,t), R(y,t)")#text(" as polynomials in F[t], whose coefficients lie in F but happen to depend in a polynomial fashion on y. To emphasise this, we write ")#mi("P_{j,y}(t)")#text(" for ")#mi("P_j(y,t)")#text(" and ")#mi("R_{y}(t)")#text(" for ")#mi("R(y,t)")#text(". Then by hypothesis, there is no t for which")

#align(center)[#mi("P_{1,y}(t) = \\ldots = P_{m,y}(t) = 0")#text("; ")#mi("R_{y}(t) \\neq 0")#text(".")]

#text("To motivate the strategy, let us consider the easy case when ")#mi("R = 1")#text(", m=2, and ")#mi("P_1")#text(", ")#mi("P_2")#text(" are monic polynomials in t. Then by our previous discussion, the above system is solvable for any fixed y precisely when ")#mi("\\text{Res}(P_{1,y}, P_{2,y})")#text(" is zero. So either the equation ")#mi("\\text{Res}(P_{1,y}, P_{2,y}) = 0")#text(" has a solution, in which case we are in case (1), or it does not. But in the latter case, by applying the nullstellensatz at one lower dimension we see that ")#mi("\\text{Res}(P_{1,y}, P_{2,y})")#text(" must be constant in y. But recall that the resultant is a linear combination ")#mi("P_{1,y} S_{1,y} + P_{2,y} S_{2,y}")#text(" of ")#mi("P_{1,y}")#text(" and ")#mi("P_{2,y}")#text(", where the polynomials ")#mi("S_{1,y}")#text(" and ")#mi("S_{2,y}")#text(" depend polynomially on ")#mi("P_{1,y}")#text(" and ")#mi("P_{2,y}")#text(" and thus on y itself. Thus we end up in case (2), and the induction closes in this case.")

#text("Now we turn to the general case. Applying the d=1 analysis, we conclude that there exist polynomials ")#mi("Q_{1,y},\\ldots,Q_{m,y} \\in F[t]")#text(" of t, and an ")#mi("r = r_{y} \\geq 0")#text(", such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("P_{1,y}(t) Q_{1,y}(t) + \\ldots + P_{m,y}(t) Q_{m,y}(t) = R^{r_{y}}_{y}(t).")]]

#text("Now, if the exponent ")#mi("r_{y}")#text(" was constant in y, and the coefficients of ")#mi("Q_{1,y},\\ldots,Q_{m,y}")#text(" depended polynomially on y, we would be in case (2) and therefore done.")

#text("It is not difficult to make ")#mi("r_{y}")#text(" constant in y. Indeed, we observe that the degrees of ")#mi("P_{1,y}(t),\\ldots,P_{m,y}(t)")#text(" are bounded uniformly in y. Inspecting the d=1 analysis, we conclude that the exponent ")#mi("r_{y}")#text(" returned by that algorithm is then also bounded uniformly in y. We can always raise the value of ")#mi("r_{y}")#text(" by multiplying both sides of (3) by ")#mi("R_{y}")#text(", and so we can make ")#mi("r = r_{y}")#text(" independent of y, thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("P_1(y,t)  Q_{1,y}(t) + \\ldots + P_m(y,t) Q_{m,y}(t) = R^r(y,t).")]]

#text("Now we need to work on the Q’s. Unfortunately, the coefficients on Q are not polynomial in y; instead, they are ")#emph[#text("piecewise rational")]#text(" in y. Indeed, by inspecting the algorithm used to prove the d=1 case, we see that the algorithm makes a finite number of branches, depending on whether certain polynomial expressions T(y) of y are zero or non-zero. At the end of each branching path, the algorithm returns polynomials ")#mi("Q_{1,y},\\ldots,Q_{m,y}")#text(" whose coefficients were rational combinations of the coefficients of ")#mi("P_{1,y},\\ldots,P_{m,y}")#text(" and are thus rational functions of x. Furthermore, all the division operations are by polynomials T(y) which were guaranteed to be non-zero by some stage of the branching process, and so the net denominator of any of these coefficients is some product of the T(y) that are guaranteed non-zero.")

#text("An example might help illustrate what’s going on here. Suppose m=2, that R = 1, and ")#mi("P_1(y,t), P_2(y,t)")#text(" is linear in t, thus")

#align(center)[#tao-fit-display[#mitex("P_{1,y}(t) = a(y) + t b(y); P_{2,y}(t) = c(y) + t d(y)")]]

#text("for some polynomials ")#mi("a,b,c,d \\in F[y]")#text(". To find the gcd of ")#mi("P_{1,y}")#text(" and ")#mi("P_{2,y}")#text(" for a given y, which determines the solvability of the system ")#mi("P_{1,y}(t)=P_{2,y}(t)=0")#text(", the Euclidean algorithm branches as follows:")

#enum(start: 1, 
[#text("If b(y) is zero, then")

#enum(start: 1, 
[#text("If a(y) is zero, then")

#enum(start: 1, 
[#text("If d(y) is non-zero, then ")#mi("0  P_{1,y} + \\frac{1}{d(y)} P_{2,y}")#text(" is the gcd (and the system is solvable).")],
[#text("Otherwise, if d(y) is zero, then")

#enum(start: 1, 
[#text("If c(y) is non-zero, then ")#mi("0 P_{1,y} + \\frac{1}{c(y)} P_{2,y} = 1")#text(" is the gcd (and the system is unsolvable).")],
[#text("Otherwise, if c(y) is zero, then ")#mi("0 P_{1,y} + 0 P_{2,y}")#text(" is the gcd (and the system is solvable).")]
)]
)],
[#text("Otherwise, if a(y) is non-zero, then ")#mi("\\frac{1}{a(y)} P_{1,y} + 0 P_{2,y} = 1")#text(" is the gcd (and the system is unsolvable).")]
)],
[#text("Otherwise, if b(y) is non-zero, then")

#enum(start: 1, 
[#text("If a(y)d(y)-b(y)c(y) is non-zero, then ")#mi("\\frac{d(y)}{a(y) d(y)-b(y)c(y)} P_{1,y} - \\frac{b(y)}{a(y) d(y)-b(y)c(y)} P_{2,y} = 1")#text(" is the gcd (and the system is unsolvable).")],
[#text("Otherwise, if a(y)d(y)-b(y)c(y) is zero, then ")#mi("\\frac{1}{b(y)} P_{1,y} + 0 P_{2,y}")#text(" is the gcd (and the system is solvable).")]
)]
)

#text("So we see that even in the rather simple case of solving two linear equations in one unknown, there is a moderately complicated branching tree involved. Nevertheless, there are only finitely many branching paths. Some of these paths may be ")#emph[#text("infeasible")]#text(", in the sense that there do not exist any ")#mi("y \\in F^{d-1}")#text(" which can follow these paths. But given any feasible path, say one in which the polynomials ")#mi("S_1(y),\\ldots,S_a(y)")#text(" are observed to be zero, and ")#mi("T_1(y),\\ldots,T_b(y)")#text(" are observed to be non-zero, we know (since we are assuming no solution to (1)) that the algorithm creates an identity of the form (4) in which the coefficients of ")#mi("Q_{1,y},\\ldots,Q_{m,y}")#text(" are rational polynomials in y, whose denominators are products of ")#mi("T_1,\\ldots,T_b")#text(". We may thus clear denominators (enlarging r if necessary) and obtain an identity of the form")

#mi("P_1(y,t) U_1(y,t) + \\ldots + P_m(y,t) U_m(y,t) = (T_1(y) \\ldots T_b(y) R(y))^r")#text(" (5)")

#text("for some polynomials ")#mi("U_1,\\ldots,U_m")#text(". This identity holds whenever y is such that ")#mi("S_1(y),\\ldots,S_a(y)")#text(" are zero and ")#mi("T_1(y),\\ldots,T_b(y)")#text(" are non-zero. But an inspection of the algorithm shows that the only reason we needed ")#mi("T_1(y),\\ldots,T_b(y)")#text(" to be non-zero was in order to divide by these numbers; if we clear denominators throughout, we thus see that we can remove these constraints and deduce that (5) holds whenever ")#mi("S_1(y),\\ldots,S_a(y)")#text(" are zero. Further inspection of the algorithm then shows that even if ")#mi("S_1(y),\\ldots,S_a(y)")#text(" are non-zero, this only introduces additional terms to (5) which are combinations (over ")#mi("F[y,t]")#text(") of ")#mi("S_1, \\ldots, S_a")#text(". Thus, for any feasible path, we obtain an identity in F[y,t] of the form")

#align(center)[#tao-fit-display[#mitex("P_1 U_1 + \\ldots + P_m U_m = (T_1 \\ldots T_b R)^r + S_1 V_1 + \\ldots + S_a V_a")]]

#text("for some polynomials ")#mi("U_1,\\ldots,U_m,V_1,\\ldots,V_a \\in F[y,t]")#text(". In other words, we see that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("(T_1 \\ldots T_b R)^r = 0 \\text{ mod } I, S_1, \\ldots, S_a")]]

#text("for any feasible path.")

#text("Now what we need to do is fold up the branching tree and simplify the relations (5) until we obtain (2). More precisely, we claim that (5) holds (for some r) not only for complete feasible paths (in which we follow the branching tree all the way to the end), but for ")#emph[#text("partial")]#text(" feasible paths, in which we branch some of the way and then stop in a place where at least one ")#mi("y \\in F^{d-1}")#text(" can solve all the constraints branched on so far. In particular, the empty feasible path will then give (2).")

#text("To prove this claim, we induct backwards on the length of the partial path. So suppose we have some partial feasible path, which required ")#mi("S_1(y),\\ldots,S_a(y)")#text(" to be zero and ")#mi("T_1(y),\\ldots,T_b(y)")#text(" to be non-zero in order to get here. If this path is complete, then we are already done, so suppose there is a further branching, say on a polynomial ")#mi("W(y)")#text(". At least one of the cases ")#mi("W(y)=0")#text(" and ")#mi("W(y) \\neq 0")#text(" must be feasible; and so we now divide into three cases.")

#strong[#text("Case 1: ")#mi("W(y)=0")#text(" is feasible and ")#mi("W(y) \\neq 0")#text(" is infeasible")]#text(". If we follow the ")#mi("W(y)=0")#text(" path and use the inductive hypothesis, we obtain a constraint")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("(T_1 \\ldots T_b R)^r = 0 \\text{ mod } I, S_1, \\ldots, S_a, W")]]

#text("for some r. On the other hand, since ")#mi("W(y) \\neq 0")#text(" is infeasible, we see that the problem")

#align(center)[#tao-fit-display[#mitex("S_1(y) = \\ldots = S_a(y) = 0; T_1 \\ldots T_b W(y) \\neq 0")]]

#text("has no solution. Since the nullstellensatz is assumed to hold for dimension d-1, we conclude that")

#align(center)[#mi("(T_1 \\ldots T_b W)^{r^{\\prime}} = 0 \\text{ mod } S_1,\\ldots,S_a")#text(".")]

#text("for some r’. If we then raise (6) to the power r’ by ")#mi("(T_1 \\ldots T_b R)^{r^{\\prime}}")#text(" to eliminate the role of W, we conclude (5) (for rr’+r’) as required.")

#strong[#text("Case 2: ")#mi("W(y)=0")#text(" is infeasible and ")#mi("W(y) \\neq 0")#text(" is feasible")]#text(". If we follow the ")#mi("W(y) \\neq 0")#text(" path, we obtain a constraint")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("(T_1 \\ldots T_b W R)^{r^{\\prime\\prime}} = 0 \\text{ mod } I, S_1, \\ldots, S_a")]]

#text("for some r”, while the infeasibility of the ")#mi("W(y)=0")#text(" path means that there is no solution to")

#align(center)[#tao-fit-display[#mitex("S_1(y) = \\ldots = S_a(y) = W(y) = 0; T_1 \\ldots T_b(y) \\neq 0")]]

#text("and so by the nullstellensatz in dimension d-1 we have")

#align(center)[#tao-fit-display[#mitex("(T_1 \\ldots T_b)^{r^{\\prime\\prime\\prime}} = W Z \\text{ mod } S_1,\\ldots,S_a")]]

#text("for some polynomial Z and some r”’. If we then multiply (7) by ")#mi("Z^{r^{\\prime\\prime}}")#text(" to eliminate W, we obtain (5) as desired (for r”+r”’).")

#strong[#text("Case 3: ")#mi("W(y)=0")#text(" and ")#mi("W(y) \\neq 0")#text(" are both feasible")]#text(".")

#text("In this case we obtain the constraints (6) and (7). We rewrite (6) in the form")

#mi("(T_1 \\ldots T_b R)^{r} = W Z \\text{ mod } S_1,\\ldots,S_a")

#text("for some Z, and then multiply (7) by ")#mi("Z^r")#text(" to eliminate W and obtain (5) as desired (for r + r”).")

#text("This inductively establishes (5) for all partial branching paths, leading eventually to (2) as desired.")

#heading(level: 1)[#text("Comments (43)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-17076")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2007")])]

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-17192")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2007")])]

#text("Hi Terence,")

#text("I found the ")#link("http://en.wikipedia.org/wiki/Chinese_remainder_theorem")[#text(" Chinese remainder theorem ")]#text(" to be linked to the extended Euclidean algorithm.")#linebreak()#text(" There was this caveat in the section ‘A constructive algorithm to find the solution’: “These sets however will produce the same solution i.e. 11 modulo 60.”")

#text("Is this a reason for the discarded, ancient base 60 system?")

#text("In turn the Chinese remainder theorem is linked to “One may consider the ring of integers mod n, where n is squarefree” in ")#link("http://en.wikipedia.org/wiki/Idempotence")[#text(" Idempotence ")]#text(".")#linebreak()#text(" This wiki page ends with: “But the probability distributions associated with eigenstates are idempotents. To see this we might consider a given eigenstate. Now as time progresses, only the phase changes. So the absolute square yields a probability distribution P which is a constant with respect to time. In this case the function f simply allows a random amount of time to pass, so that P=f(P)=f(f(P)), etc.”")

#text("This may be a means of relating nilpotents to idempotents?")

#text("[I apologize for bringing a physics and engineering discussion into your blog, but I remain curious as to why these related mathematical oriented disciplines appear to emphasize different concepts.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Hahn-Banach theorem, Menger’s theorem, and Helly’s theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-18347")[#strong[#text("The Hahn-Banach theorem, Menger’s theorem, and Helly’s theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2007")])]

#text("[…] Helly’s theorem, linear programming, Menger’s theorem, minimax theorem, separation theorem In the previous post, I discussed how an induction on dimension approach could establish Hilbert’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b20f6cde4398d1f9268e08d66ff9679668d4c67a5e94cc80fa2dfe15c328092-d073a0f938eb8acf2ac6319da933e324ae73b331b55ff48af996f5486bc719a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jens Gottschalk")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-18371")[#strong[#text("Jens Gottschalk")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2007")])]

#text("Hi Terence!")

#text("“The presence of the exponent r in conclusion (2) is a little annoying; to get rid of it, one needs to generalise the notion of an algebraic variety to that of a scheme”")

#text("This sounds interesting! I’m not very familiar with schemes, but I would be very glad if you or somebody else could explain the connection between this exponent and the notion of schemes.")

#text("You wrote that this could be a whole story itself, but maybe somebody wants to write one or two words about it here.")

#text("Thank you in advance and the best regards to you and all the other readers of this great blog!")

#text("Jens")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-18695")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2007")])]

#text("That’s funny, because only a month ago I was looking at precisely the same problem: there must be a reasonably elementary proof of the (weak) Nullstellensatz (I am teaching an undergraduate-level algebraic geometry class, so I certainly wanted to avoid too much algebra).")

#text("I soon realized that the problem was not quite as elementary as I’d hoped, but there was a very nice proof by Arrondo published in the Monthly in 2006, that uses only resultants and Noether normalization. It’s only two pages long, I think it’s about as easy as it gets. I’m happy to share the reference with your readers.")

#link("http://www.mat.ucm.es/~arrondo/publications.html")[#text("http://www.mat.ucm.es/~arrondo/publications.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-18733")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2007")])]

#text("Dear Jens: I don’t work with schemes on a regular basis, so I am not well placed to answer your question. But one viewpoint that I learned from a friend, which appeals to my background in analysis, is to think of schemes (in, say, ")#mi("{\\Bbb R}^n")#text(", for sake of discussion, though I guess one has to take a little care here as ")#mi("{\\Bbb R}")#text(" is not algebraically closed) as “infinitesimally thickened” varieties. An (affine) variety is the intersection of various zero loci ")#mi("\\{ x \\in {\\Bbb R}^n: P(x) = 0 \\}")#text(" of polynomials; you can think of an (affine) scheme as the intersection of near-zero loci ")#tao-math("\\{ x \\in {\\Bbb R}^n: \\left|P(x)\\right| \\leq \\varepsilon \\}", block: false)#text(", where ")#mi("\\varepsilon")#text(" is an infinitesimal. Instead of looking at the functions which vanish on the zero locus, one then looks at functions which are of size ")#mi("O(\\varepsilon)")#text(" (locally, at least) on the near-zero locus. For instance, the scheme ")#tao-math("\\{ x \\in {\\Bbb R}: \\left|x^2\\right| \\leq \\varepsilon \\}", block: false)#text(" is an infinitesimal thickening of the origin ")#mi("\\{0\\}")#text(" which is “fatter” than than the scheme ")#tao-math("\\{ x \\in {\\Bbb R}: \\left|x\\right| \\leq \\varepsilon \\}", block: false)#text("; the polynomial ")#mi("x")#text(" “vanishes” on the latter but not the former, while ")#mi("x^2")#text(" vanishes on both schemes. So schemes carry some information about multiplicity of vanishing which algebraic varieties do not; in particular they can distinguish between the vanishing of a polynomial ")#mi("Q")#text(" and the vanishing of a power ")#mi("Q^r")#text(" of that polynomial. This kind of viewpoint is sort of specific to fields such as ")#mi("{\\Bbb R}")#text(" and ")#mi("{\\Bbb C}")#text(" though, which have good notions of infinitesimals; I don’t know how to interpret schemes like this over, say, fields of finite characteristic.")

#text("Dear Anonymous: thanks for the reference! It is a nice argument; it proceeds by induction on dimension, as with my own argument, but with the neat additional trick of randomly rotating (or skewing) the variety first to prepare it for the projection to one lower dimension. I’m quite fond of random projection arguments in combinatorics, and it’s nice to see one come up in algebra too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-18807")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2007")])]

#text("One of the simple ways of looking at infinitesimals in the scheme framework over a general field (or any commutative ring), and why they can be useful, is the following :")

#text("Let ")#mi("D")#text(" be the ring ")#mi("D=k[\\epsilon]/(\\epsilon^2)")#text(", where ")#mi("\\epsilon")#text(" is seen as an indeterminate. This is often called the ring of “dual numbers” over ")#mi("k")#text(". It has the property that ")#mi("\\epsilon")#text(" is non-zero, but ")#mi("\\epsilon^2=0")#text(", so ")#mi("\\epsilon")#text(" is “infinitesimal of the first order”.")

#text("Now take any ")#mi("k")#text("-algebra ")#mi("A")#text(", say ")#mi("A=k[X_1,....,X_r]/I")#text(" for concreteness, where ")#mi("I")#text(" is some ideal.")

#text("Then look at ")#mi("k")#text("-linear ring homomorphisms ")#mi("d:A\\rightarrow D")#text(".")

#text("Writing ")#mi("d(a)=x(a)+\\epsilon t(a)")#text(", for uniquely defined ")#mi("x(a)")#text(" and ")#mi("t(a)")#text(", we find by writing out the conditions that (1) ")#mi("d(I)=0")#text(", and (2) ")#mi("d(ab)=d(a)d(b)")#text(", that to give ")#mi("d")#text(" is equivalent to giving a pair ")#mi("(x,t)")#text(" where")

#text("(1) ")#mi("x")#text(" is a ring homomorphism ")#mi("A\\rightarrow k")#text(", which means nothing else than an assignation of variables ")#mi("X_i\\mapsto x_i")#text(" so that ")#mi("(x_1,...,x_r)\\in k^r")#text(" is a solution of the equations defined by the ideal ")#mi("I")#text(";")

#text("(2) ")#mi("t")#text(" is a ")#mi("k")#text("-linear map ")#mi("A\\rightarrow k")#text(", with ")#mi("t(I)=0")#text(", such that")

#mi("t(ab)=x(b)t(a)+x(a)t(b)")

#text("or in other words, ")#mi("t")#text(" is a derivation “at the point ")#mi("x")#text("“. Intuitively, ")#mi("t")#text(" is a vector tangent (at the point ")#mi("x")#text(") to the zero set ")#mi("V")#text(" in ")#mi("k^r")#text(" defined by the polynomial equations in the ideal ")#mi("I")#text(".")

#text("This means that the set ")#mi("T(A)")#text(" of all homomorphisms ")#mi("d:A\\rightarrow D")#text(" can be seen naturally as being the whole tangent “bundle” of ")#mi("V")#text(" (quotes because there might be singularities where this bundle is not as nicely behaved as the differential geometry analogy would suggest). Intuitively, it is the same to give a point on ")#mi("V")#text(" with coordinates in the ring of dual numbers, or to give a tangent vector to ")#mi("V")#text(".")

#text("As hint that this is useful, one may note that if we have a ")#mi("k")#text("-linear ring homomorphism ")#mi("A_1\\rightarrow A_2")#text(", we immediately obtain by composition an induced map ")#mi("T(A_2)\\rightarrow T(A_1)")#text(", where ")#mi("T(A)")#text(" is ")#mi("Hom(A,D)")#text(", and this corresponds geometrically to the association of the tangent map ")#mi("T(f): T(V)\\rightarrow T(W)")#text(" to a (polynomial) map ")#mi("f:V\\rightarrow W")#text(" between their zero sets (in the reverse direction because ")#mi("A")#text(" corresponds to functions on ")#mi("V")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-20466")[#strong[#text("The Nullstellensatz and Partitions of Unity « Secret Blogging Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2007")]

#text("[…] Tao has a nice post explaining how to prove the Nullstellensatz by bulldozing forward in the most straightforward […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-20842")[#strong[#text("Affine Varieties « Rigorous Trivialities")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2007")]

#text("[…] two facts which seem fairly straightforward, are in fact rather difficult to prove (here is a proof that Tao wrote up), and are essential to algebraic geometry. The first tells us that we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/997ad3a4c566f9696adfcd15b596aba4e1409447c8888295922d43483c0ba972-3f9af0841366a2b99285fd7b5bcbb147625debb6d2bc6ddcd9658abb65d55849.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SriRam")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-27180")[#strong[#text("SriRam")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2008")])]

#text("“The presence of the exponent r in conclusion (2) is a little annoying; to get rid of it, one needs to generalise the notion of an algebraic variety to that of a scheme”")

#text("Continuing on the above topic (by Jens) I would be very interested in having the reference where ")#mi("R = \\sum_{i=1}^m P_i(\\mathbf{x}) Q_i(\\mathbf{x})")#text(" can be proved using schemes.")

#text("Here is the context: I have a bunch of cubic polynomials ")#mi("F=\\{f_1, f_2 ... f_k \\} f_{k+1}")#text(". I want to prove that ")#mi("f_{k+1}")#text(" is independent of ")#mi("F")#text(". Also, in my problem setting I can check at as many points, ")#mi("\\mathbf{x}")#text(" as possible (at say W points, for some natural number W) that ")#mi("\\text{rank}([\\nabla f_1 \\nabla f_2 ... \\nabla f_{k+1}]) < (k+1)")#text(".")

#text("For that, I would like to prove: If ")#mi("f_{k+1}")#text(" is dependent on ")#mi("F")#text(" then ")#mi("\\text{rank}([\\nabla f_1 \\nabla f_2 ... \\nabla f_{k+1}]) < (k+1)")#text(".")

#text("In this proof by contradiction, suppose ")#mi("f_{k+1}")#text(" is dependent. Then ")#mi("f_{k+1}")#text(" vanishes wherever ")#mi("F")#text(" is zero (mutual zero) (Note that this is an assumption I make because of “dependence”. And the fact that experimentally at a lot of points it is true). By Hilbert’s Nullstellensatz, ")#mi("\\exists r, P_i(x)")#text(" s.t. ")#mi("f_{k+1}^r = \\sum_{i=1}^{m} P_i(x) f_i(x)")#text(" .")#linebreak()#text(" Differentiating on both sides we get, ")#mi("r f_{k+1}^{r-1} \\nabla f_{k+1} = \\sum_{i=1}^k (P_i(x) \\nabla f_i(x) + f_i(x) \\nabla P_i(x))")#text(".")

#text("Evaluating it at points ")#mi("F=0")#text(", I get ")#mi("r f_{k+1}^{r-1} \\nabla f_{k+1} = \\sum_{i=1}^k P_i(x) \\nabla f_i(x)")#text(", which would have nicely proved the result ")#mi("\\text{rank}([\\nabla f_1 \\nabla f_2 ... \\nabla f_{k+1}]) < (k+1)")#text(", except that we are not sure if ")#mi("P_i(x) = 0 \\forall i")#text(" between 1 and k.")

#text("In which case I dont get any result as it becomes ")#mi("0 = \\sum_{i=1}^k (0 \\nabla f_i)")#text(".")

#text("However, in case the exponent is not there, I will get")#linebreak()#text(" ")#mi("\\nabla f_{k+1} = \\sum_{i=1}^k P_i(x) f_i")#text(" which will give my result.")

#text("Any reference to prove / solve the above issue would be great.")

#text("Thanks in advance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f5141e5675ab3ea9ead83cef65628a8bbaea414269f4d0a8e379c1bc8608a52-7023cd6d088b86f0c884545b9f75616ce04a33d1af94a2a0a6ac2eb83d080909.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of My Conjecture « Reasonable Deviations")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-29882")[#strong[#text("My Conjecture « Reasonable Deviations")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2008")])]

#text("[…] Hilbert’s nullstellensatz Possibly related posts: (automatically generated)Existence of God […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-31827")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2008")])]

#text("This is late, but you might find Munshi’s proof of the Nullstellensatz interesting. It’s at ")#link("http://www.math.uchicago.edu/~may/PAPERS/MunshiFinal2.pdf")[#text("http://www.math.uchicago.edu/~may/PAPERS/MunshiFinal2.pdf")]

#text("It avoids harder results in commutative algebra such as Noether’s normalization theorem, and instead introduces the idea of a “flow” to prove the intersection of a maximal ideal in R[x_1, …, x_n] and R is nonempty. The proof of the weak nullstellensatz follows easily this and the strong form follows from the standard Rabinowitsch argument.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Infinite fields, finite fields, and the Ax-Grothendieck theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-36429")[#strong[#text("Infinite fields, finite fields, and the Ax-Grothendieck theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2009")])]

#text("[…] there exists a finitary algebraic obstruction that witnesses this lack of solution (see also my blog post on this topic). Specifically, suppose for contradiction that we can find a polynomial which is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68ebda7c695b5c530882b310c38c6f62d48877478a6797985d2938fcea3200e8-4376f443e394f3a6e2aaec4bef74211ec02136ff651e84839ec23d21c4c4b68b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hilbert Nullstellensatz « A Mind for Madness")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-38357")[#strong[#text("Hilbert Nullstellensatz « A Mind for Madness")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2009")])]

#text("[…] Tao proves it in a way I’ve never […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a8cdabab1b0ae0edb59304dd66982dde2efb5f3457f45132f613dbbeac1fc54-da7019131c011a75b89cf4e5d6fdd49a284d7be19e4615f455c898a9ac6a0ab1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wuzhengpeng")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-39696")[#strong[#text("wuzhengpeng")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2009")])]

#text("Dear Prof. Tao,")

#text("I have a trivial question about the proof. How to “eliminate the role of W” in the case 1? Because RHS of (6) is linear about “W”, maybe r’ power of both sides could eliminate the role of W?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-39708")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2009")])]

#text("Yes, one has to raise (6) to the power r’ first; thanks for the correction!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-40126")[#strong[#text("Why simple modules are often finite-dimensional, I « Delta Epsilons")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2009")]

#text("[…] Actually proving the Nullstellensatz could make another interesting algebraic post. For now, I’ll recommend David Speyer’s interpretation of it, and Terence Tao’s elementary proof. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-41744")[#strong[#text("On Hilbert’s Nullstellensatz (a non HW post) « Math840's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2009")]

#text("[…] Click on the Link […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reading seminar: “Stable group theory and approximate subgroups”, by Ehud Hrushovski « What’s new")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-41844")[#strong[#text("Reading seminar: “Stable group theory and approximate subgroups”, by Ehud Hrushovski « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2009")])]

#text("[…] the -definable sets are the boolean combinations of algebraic sets; this fact is closely related to Hilbert’s nullstellensatz (and can be proven by quantifier elimination). Similarly, in the language of ordered rings, if is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-42556")[#strong[#text("The weak Nullstellensatz and affine varieties « Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2009")]

#text("[…] weak Nullstellensatz and affine varieties November 27, 2009 Hilbert’s Nullstellensatz is a basic but foundational theorem in commutative algebra that has been discussed on the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The uncertainty principle « What’s new")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-45721")[#strong[#text("The uncertainty principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2010")])]

#text("[…] zero locus cuts out . The fundamental connection between the two perspectives is given by the nullstellensatz, which then leads to many of the basic fundamental theorems in classical algebraic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5fa4a1bfa3364ebb73b4c2a567b919a6af29efe92594723524c293c922a6aa4-5ca57b837313863df1356bc9fb1f1d5f4d92c5e8e24665382c724e73cf208287.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Corwin")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-46245")[#strong[#text("David Corwin")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2010")])]

#text("At ")#link("http://mathoverflow.net/questions/33563/intuition-for-model-theoretic-proof-of-the-nullstellensatz/33576#33576")[#text("http://mathoverflow.net/questions/33563/intuition-for-model-theoretic-proof-of-the-nullstellensatz/33576#33576")]#text(", I believe I have developed an elementary and algorithmic proof of the Nullstellensatz, based largely off of a certain exposition of a model theoretic proof of it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8af99fb3e14d34034c662c3d571d60449f16a91564f5af82f1acc388dd0efdde-39a5ce216ac347e76a34db4de5d4255537be8eca35e60e3983c687d7e85a9ad1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J. M. Almira")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-51854")[#strong[#text("J. M. Almira")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2011")])]

#text("Hi! Perhaps you will find interesting my paper on Nullstellensatz at Rendiconti del Circolo Matematico di Torino. The proof is elementary and, I hope, well motivated and easy to follow. You can download it from:")

#link("http://seminariomatematico.dm.unito.it/rendiconti/65-3.html")[#text("http://seminariomatematico.dm.unito.it/rendiconti/65-3.html")]

#text("Yours,")

#text("J. M. Almira")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-52827")[#strong[#text("Lien résultant-résidu? « Exercices Aléatoires")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2011")]

#text("[…] lu ici que un résultat sur le résultant du type , avec res=résultant non […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polynomial bounds via nonstandard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-55009")[#strong[#text("Polynomial bounds via nonstandard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2011")])]

#text("[…] elimination theory (somewhat similar, actually, to approach I took to the nullstellensatz in my own blog post). She also notes that one could also establish the result through the machinery of Gr” obner […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-133730")[#strong[#text("Drei Sätze von Hilbert Ⅱ « Fight with Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2012")]

#text("[…] 这种形式的零点定理在算法理论中很有用处。这里是一个基于算法精神的初等证明。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qualitative probability theory, types, and the group chunk and group configuration theorems | What's new")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-251375")[#strong[#text("Qualitative probability theory, types, and the group chunk and group configuration theorems | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2013")])]

#text("[…] elimination of quantifiers in algebraically closed fields, the existence of which follows from Hilbert’s nullstellensatz) that a set is definable if and only if it is the union of a finite number of disjoint […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-272509")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("For ")#mi("d=1")#text(", one can explicitly give the coefficient ")#mi("Q_i")#text(" in the weak nullstellensatz. Can this be done generally for ")#mi("d>1")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-272613")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2014")])]

#text("I’m lost in the case ")#mi("d>1")#text(". It seems that when ")#mi("P_i")#text(" are not monomial, the calculation becomes rather complicated. Would you sketch your strategy for example how to find ")#mi("Q_i")#text(" for ")#mi("Q_1(t^2+x^2-2)+Q_2(tx-1)+Q_3(t^3+5tx^2+1)=1")#text(" in ")#mi("{\\Bbb C}[x,t]")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-272623")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2014")])]

#text("The idea is to freeze all but one variable t, use the 1D theory for each choice of frozen parameters, and then glue things back together. For instance, one can set x to be (say) 57, and use the 1D theory to locate ")#mi("Q_1(t), Q_2(t), Q_3(t)")#text(" such that ")#mi("Q_1(t) (t^2+57^2-2) + Q_2(t) (57t - 1) + Q_3(t) (t^3+5t \\times 57^2 + 1) = 1")#text(". This will be a branching process, depending on whether various expressions involving 57 vanish or not. This eventually gives a rather messy piecewise polynomial-in-57 formula for the ")#mi("Q_i")#text(" in terms of a branching tree that branches depending on the vanishing or non-vanishing of various polynomials involving 57. One then has to use the algorithm described at the end of the post to collapse the tree and get genuine polynomials ")#mi("Q_i")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-272660")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2014")])]

#text("Hmm, so the principle is to reduce the problem to which one can apply the 1D theory. I tried by Mathematica as the following :")

#text("In[35]:= f1[t_, x_] := t^2 + x^2 – 2")

#text("In[36]:= f2[t_, x_] := t*x – 1")#linebreak()#text(" f3[t_, x_] := t^3 + 5*t*x^2 + 1")

#text("In[38]:= g1 = Expand[-(x*t)*f1[t, x]]")

#text("Out[38]= 2 t x – t^3 x – t x^3")

#text("In[39]:= g2 = Expand[(-4*x^2 – 2)*f2[t, x]]")

#text("Out[39]= 2 – 2 t x + 4 x^2 – 4 t x^3")

#text("In[40]:= g3 = Expand[x*f3[t, x]]")

#text("Out[40]= x + t^3 x + 5 t x^3")

#text("In[41]:= g4 = g1 + g2 + g3")

#text("Out[41]= 2 + x + 4 x^2")

#text("In[42]:= g5 = Expand[x^2*f1[t, x] – (t*x + 1)*f2[t, x]]")

#text("Out[42]= 1 – 2 x^2 + x^4")

#text("In[43]:= PolynomialExtendedGCD[g4, g5, x]")

#text("Out[43]= {1, {(352 – 82 x – 142 x^2 + 47 x^3)/1225, (521 – 188 x)/")#linebreak()#text(" 1225}}")

#text("I did it by trial and error to reduce the three polynomials in two variables to two polynomials in one variable and then use the 1D theory. I’m not sure if this is in the same spirit of your algorithm.")

#text("Using the notations in your algorithm, what we get by setting ")#mi("x=57")#text(" is ")#mi("Q_{1,57}(t), Q{2,57}(t), Q{3,57}(t)")#text(". Do we need to set other parameters, (say) ")#mi("x=7")#text(" to get ")#mi("Q_{1,7}(t), Q{2,7}(t), Q{3,7}(t)")#text(" and then go to the procedure which you call “folding up the branching tree”, or we just find ")#mi("Q_{1,x}, Q_{2,x}, Q_{3,x}")#text(" “abstractly”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ff93f4e7e15999ef94c77de9b661b79bc05b2e0408a9d62a698e2753f94207-2973badff05aece490148e8bea3c8f572310e327a9bf689a7107707af2c8142e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of isomorphismes")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-389927")[#strong[#text("isomorphismes")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2014")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Note that the hypothesis that F is algebraically closed is crucial; for instance, if F is the reals, then the equation x^2+1=0 has no solution, but there is no polynomial Q(x) such that (x^2+1) Q(x) = 1.")
]

#text("I get that $1 \\over x^2+1$ is not a polynomial, but couldn’t you represent it with an infinite series and then ${x^2 + 1 \\over x^2 + 1} = 1$ identically everywhere?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-390268")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2014")])]

#text("Well, one can certainly work with the field of formal power series instead of the smaller ring of polynomials, but then one can no longer easily detect vanishing, which is the whole point of the Nullstellensatz. For instance, ")#mi("1-x")#text(" can be formally inverted by the power series ")#mi("1 + x + x^2 + \\dots")#text(" despite the fact that it vanishes at ")#mi("x=1")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0aad52508fd489ecb214c89b2b9bda916d2eafd41f3c172ff4a8d2c899823ded-ef03a8070ee48aec5777da9eb0058413a735db54ecacab24c7ef6b3cfbedf9f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Timothy P Keller ( Tim )")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-449367")[#strong[#text("Timothy P Keller ( Tim )")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2015")])]

#text("I have been reading Pfister’s ‘Quadratic Forms with Applications to Algebraic Geometry and Topology’. Chapter 4 has a really neat proof")#linebreak()#text(" of the Nullstellensatz in the homogeneous case. Unfortunately, the statement of his result ( Theorem 1.3 ) is false – but only due to a technicality –")

#text("The theorem is stated for K a p-field ( an algebraically closed field, e.g. the complex numbers, is automatically a p-field ), and R the polynomial ring over K in n + 1 variables, and f_1 , …, f_n are homogeneous polynomials ,")#linebreak()#text(" where for all i , p does not divide the degree of f_i.")

#text("The conclusion is that f_1, …, f_n have a common zero in K^(n+1), other than the trivial one.")

#text("For C , and R = C[X,Y], take f_1 = X, and f_2 = Y, and it’s clear the result does not hold. What’s the problem ? If one takes I = ( X,Y), then")#linebreak()#text(" M = R/I is isomorphic to C, i.e. dim_C ( M ) = 0. I think the result must")#linebreak()#text(" contain the condition that dim_C ( M ) > 0.")

#text("What do you think?")

#text("It’s a really neat ( thoroughly un-geometric, for better or worse ) proof,")#linebreak()#text(" and I would like to understand it thoroughly.")

#text("Thanks, Tim")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e6d77e00751b7b05cf84a246d3dbbb6d0b3cf52504cc77c059fd52a562b5926-26325bb98b2e94726b18fa8785ccc978eed9fa5b1e44e7b03082f5ae0c1ef163.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samin Riasat")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-467631")[#strong[#text("Samin Riasat")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2016")])]

#text("Reblogged this on ")#link("https://sriasat.wordpress.com/2016/04/08/hilberts-nullstellensatz/")[#text("Samin Riasat's Blog")]#text(" and commented:")#linebreak()#text(" Leaving it here because I want to study this at some point.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-481096")[#strong[#text("Lưu lại đề đọc sau")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2017")]

#text("[…] ")#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/")[#text("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-492236")[#strong[#text("The Nullstellensatz (again) | Mark Sapir")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2018")]

#text("[…] to do a blog post on the proof of Hilbert Nullstellensatz (another attempt is Terry Tao’s blog). Since I am lecturing in a few days on the Nullstellensatz, I decided to find the easiest proof, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08c57b5f8b0d2224810c448d299125adc8d30f04285d879f0b8d563a6dbaa449-a77e48610f9d0e3edac0a67795e88eee890cb01ede29505e8e79ba46549866ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Sapir")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-492399")[#strong[#text("Mark Sapir")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2018")])]

#text("Hi Terry, There is another blog post with a proof of that theorem: ")#link("https://marksapir.wordpress.com/2018/02/06/the-nullstellensatz-again/")[#text("https://marksapir.wordpress.com/2018/02/06/the-nullstellensatz-again/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-509095")[#strong[#text("Nullstellensatz – chikurin")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2018")]

#text("[…] It starts with Nullstellensatz. I am going to follow my notes, Atiyah-Macdonald, and Eisenbud. This post from Terry Tao is also a nice reading. Warning: This post would be very dry, because I don’t […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dfbab5bcafa1340c6b24b834af41aebb215e782fb9a03601688bf29b997e50cc-3aad51f470719caa4dffbab1acfa1940cc4d65362a689765966742d3149c9d4b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Devendra")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-553297")[#strong[#text("Devendra")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2020")])]

#text("It’s still not concrete. I learnt this theorem when I was 19years of age. This was the occasion of the first mathematics programme in india. And i was the first indian to travel some 1800kms from my native place for the starting of this programme. It’s nothing like what a hilbert some 100yrs back and in these days the medalists have gone through during their student lives. I was quite unaware of the fact that mathematics would have taken such an industrial form. And there existed division of labour in society everywhere which has entered even mathematics. And with passage of time this led to precisely what can be called the perversion of labour. All professors started abusing me when i asked them what all those theorems simply meant in concrete forms. Only later did I come to find out that they all had gone to universities, which are nothing more than shops, at the cost of their father’s money. I was a scholarship winner but all my money was ” eaten away” by the elders in the Indian system. A knowledge of general statements generally blights the beauty which one is blessed with. Universities never serve the purpose which they profess.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 247B, Notes 4: almost everywhere convergence of Fourier series | What's new")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-564649")[#strong[#text("247B, Notes 4: almost everywhere convergence of Fourier series | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")])]

#text("[…] there exists a finitary algebraic obstruction that witnesses this lack of solution (see also my blog post on this topic). Specifically, suppose for contradiction that we can find a polynomial which is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cae8e4951733b1a22479f14a0d6316b8c372862265cb223145fbf7734e997518-841746463bcc2eac243a84add13669488cf551158e69533634b47fe01fa1d020.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ¿En dónde está el cero? – El paraíso de Cantor")]], [#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-624725")[#strong[#text("¿En dónde está el cero? – El paraíso de Cantor")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2021")])]

#text("[…] T., 2021. Hilbert’s nullstellensatz. [online] Terrence Tao’s Blog. Available at: <")#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/&gt")[#text("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/&gt")]#text("; [Accessed 8 March […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/#comment-685459")[#strong[#text("Hilbert’s Nullstellensatz – eryanghsu")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2024")]

#text("[…] Hilbert’s nullstellensatz […]")
]
