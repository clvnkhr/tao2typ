// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/05/02/quasirandom-groups-and-a-cheap-version-of-the-brauer-fowler-theorem/
// Converted to Typst by tao2typ: "2026-10-14T09:30:18.729950+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Quasirandom groups and a cheap version of the Brauer-Fowler theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Quasirandom groups and a cheap version of the Brauer-Fowler theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 May 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/05/02/quasirandom-groups-and-a-cheap-version-of-the-brauer-fowler-theorem/")[#text("https://terrytao.wordpress.com/2013/05/02/quasirandom-groups-and-a-cheap-version-of-the-brauer-fowler-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Suppose that ")#mi("{G = (G,\\cdot)}")#text(" is a finite group of even order, thus ")#tao-math("{\\left|G\\right|}", block: false)#text(" is a multiple of two. By ")#link("http://en.wikipedia.org/wiki/Cauchy%27s_theorem_(group_theory)")[#text("Cauchy’s theorem")]#text(", this implies that ")#mi("{G}")#text(" contains an ")#link("http://en.wikipedia.org/wiki/Involution_(mathematics)")[#text("involution")]#text(": an element ")#mi("{g}")#text(" in ")#mi("{G}")#text(" of order two. (Indeed, if no such involution existed, then ")#mi("{G}")#text(" would be partitioned into doubletons ")#mi("{\\{g,g^{-1}\\}}")#text(" together with the identity, so that ")#tao-math("{\\left|G\\right|}", block: false)#text(" would be odd, a contradiction.) Of course, groups of odd order have no involutions ")#mi("{g}")#text(", thanks to Lagrange’s theorem (since ")#mi("{G}")#text(" cannot split into doubletons ")#mi("{\\{ h, hg \\}}")#text(").")

#text("The classical ")#link("http://en.wikipedia.org/wiki/Brauer-Fowler_theorem")[#text("Brauer-Fowler theorem")]#text(" asserts that if a group ")#mi("{G}")#text(" has many involutions, then it must have a large non-trivial subgroup:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Brauer-Fowler theorem)")]#text(" ")#metadata(none) <tao-0b5005202223684c9544>#text(" Let ")#mi("{G}")#text(" be a finite group with at least ")#tao-math("{\\left|G\\right|/n}", block: false)#text(" involutions for some ")#mi("{n > 1}")#text(". Then ")#mi("{G}")#text(" contains a proper subgroup ")#mi("{H}")#text(" of index at most ")#mi("{n^2}")#text(".")
]

#text("This theorem (which is Theorem 2F in ")#link("http://www.ams.org/mathscinet-getitem?mr=74414")[#text("the original paper of Brauer and Fowler")]#text(", who in fact manage to sharpen ")#mi("{n^2}")#text(" slightly to ")#mi("{n(n+2)/2}")#text(") has a number of quick corollaries which are also referred to as “the” Brauer-Fowler theorem. For instance, if ")#mi("{g}")#text(" is a an involution of a group ")#mi("{G}")#text(", and the centraliser ")#mi("{C_G(g) := \\{ h \\in G: gh = hg\\}}")#text(" has order ")#mi("{n}")#text(", then clearly ")#mi("{n \\geq 2}")#text(" (as ")#mi("{C_G(g)}")#text(" contains ")#mi("{1}")#text(" and ")#mi("{g}")#text(") and the conjugacy class ")#mi("{\\{ aga^{-1}: a \\in G \\}}")#text(" has order ")#tao-math("{\\left|G\\right|/n}", block: false)#text(" (since the map ")#mi("{a \\mapsto aga^{-1}}")#text(" has preimages that are cosets of ")#mi("{C_G(g)}")#text("). Every conjugate of an involution is again an involution, so by the Brauer-Fowler theorem ")#mi("{G}")#text(" contains a subgroup of order at least ")#tao-math("{\\max( n, \\left|G\\right|/n^2)}", block: false)#text(". In particular, we can conclude that every group ")#mi("{G}")#text(" of even order contains a proper subgroup of order at least ")#tao-math("{\\left|G\\right|^{1/3}}", block: false)#text(".")

#text("Another corollary is that the size of a simple group of even order can be controlled by the size of a centraliser of one of its involutions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2 (Brauer-Fowler theorem)")]#text(" ")#metadata(none) <tao-6f1f51c4e4cc1dae1c75>#text(" Let ")#mi("{G}")#text(" be a finite simple group with an involution ")#mi("{g}")#text(", and suppose that ")#mi("{C_G(g)}")#text(" has order ")#mi("{n}")#text(". Then ")#mi("{G}")#text(" has order at most ")#mi("{(n^2)!}")#text(".")
]

#text("Indeed, by the previous discussion ")#mi("{G}")#text(" has a proper subgroup ")#mi("{H}")#text(" of index less than ")#mi("{n^2}")#text(", which then gives a non-trivial permutation action of ")#mi("{G}")#text(" on the coset space ")#mi("{G/H}")#text(". The kernel of this action is a proper normal subgroup of ")#mi("{G}")#text(" and is thus trivial, so the action is faithful, and the claim follows.")

#text("If one assumes the ")#link("http://en.wikipedia.org/wiki/Feit%E2%80%93Thompson_theorem")[#text("Feit-Thompson theorem")]#text(" that all groups of odd order are solvable, then Corollary ")#link(<tao-6f1f51c4e4cc1dae1c75>)[#text("2")]#text(" suggests a strategy (first proposed by Brauer himself in 1954) to prove ")#link("http://en.wikipedia.org/wiki/Classification_of_finite_simple_groups")[#text("the classification of finite simple groups")]#text(" (CFSG) by induction on the order of the group. Namely, assume for contradiction that the CFSG failed, so that there is a counterexample ")#mi("{G}")#text(" of minimal order ")#tao-math("{\\left|G\\right|}", block: false)#text(" to the classification. This is a non-abelian finite simple group; by the Feit-Thompson theorem, it has even order and thus has at least one involution ")#mi("{g}")#text(". Take such an involution and consider its centraliser ")#mi("{C_G(g)}")#text("; this is a proper subgroup of ")#mi("{G}")#text(" of some order ")#tao-math("{n < \\left|G\\right|}", block: false)#text(". As ")#mi("{G}")#text(" is a minimal counterexample to the classification, one can in principle describe ")#mi("{C_G(g)}")#text(" in terms of the CFSG by factoring the group into simple components (via a ")#link("http://en.wikipedia.org/wiki/Composition_series")[#text("composition series")]#text(") and applying the CFSG to each such component. Now, the “only” thing left to do is to verify, for each isomorphism class of ")#mi("{C_G(g)}")#text(", that all the possible simple groups ")#mi("{G}")#text(" that could have this type of group as a centraliser of an involution obey the CFSG; Corollary ")#link(<tao-6f1f51c4e4cc1dae1c75>)[#text("2")]#text(" tells us that for each such isomorphism class for ")#mi("{C_G(g)}")#text(", there are only finitely many ")#mi("{G}")#text(" that could generate this class for one of its centralisers, so this task should be doable ")#emph[#text("in principle")]#text(" for any given isomorphism class for ")#mi("{C_G(g)}")#text(". That’s all one needs to do to prove the classification of finite simple groups!")

#text("Needless to say, this program turns out to be far more difficult than the above summary suggests, and the actual proof of the CFSG does not quite proceed along these lines. However, a significant portion of the argument ")#emph[#text("is")]#text(" based on a generalisation of this strategy, in which the concept of a centraliser of an involution is replaced by the more general notion of a normaliser of a ")#mi("{p}")#text("-group, and one studies not just a single normaliser but rather the entire family of such normalisers and how they interact with each other (and in particular, which normalisers of ")#mi("{p}")#text("-groups commute with each other), motivated in part by the theory of ")#link("http://en.wikipedia.org/wiki/Tits_building")[#text("Tits buildings")]#text(" for Lie groups which dictates a very specific type of interaction structure between these ")#mi("{p}")#text("-groups in the key case when ")#mi("{G}")#text(" is a (sufficiently high rank) finite simple group of Lie type over a field of characteristic ")#mi("{p}")#text(". See the ")#link("http://www.ams.org/mathscinet-getitem?mr=2778190")[#text("text of Aschbacher, Lyons, Smith, and Solomon")]#text(" for a more detailed description of this strategy.")

#text("The Brauer-Fowler theorem can be proven by a nice application of character theory, of the type discussed in ")#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/")[#text("this recent blog post")]#text(", ultimately based on analysing the alternating tensor power of representations; I reproduce a version of this argument (taken from ")#link("http://www.ams.org/mathscinet-getitem?mr=2270898")[#text("this text of Isaacs")]#text(") below the fold. (The original argument of Brauer and Fowler is more combinatorial in nature.) However, I wanted to record a variant of the argument that relies not on the fine properties of characters, but on the cruder theory of ")#emph[#text("quasirandomness")]#text(" for groups, the modern study of which was initiated ")#link("http://www.ams.org/mathscinet-getitem?mr=2410393")[#text("by Gowers")]#text(", and is discussed for instance in ")#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/")[#text("this previous post")]#text(". It gives the following slightly weaker version of Corollary ")#link(<tao-6f1f51c4e4cc1dae1c75>)[#text("2")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3 (Weak Brauer-Fowler theorem)")]#text(" ")#metadata(none) <tao-382d365e0f23a016e82a>#text(" Let ")#mi("{G}")#text(" be a finite simple group with an involution ")#mi("{g}")#text(", and suppose that ")#mi("{C_G(g)}")#text(" has order ")#mi("{n}")#text(". Then ")#mi("{G}")#text(" can be identified with a subgroup of the unitary group ")#mi("{U_{4n^3}({\\bf C})}")#text(".")
]

#text("One can get an upper bound on ")#tao-math("{\\left|G\\right|}", block: false)#text(" from this corollary using ")#link("https://en.wikipedia.org/wiki/Jordan%E2%80%93Schur_theorem")[#text("Jordan’s theorem")]#text(", but the resulting bound is a bit weaker than that in Corollary ")#link(<tao-6f1f51c4e4cc1dae1c75>)[#text("2")]#text(" (and the best bounds on Jordan’s theorem require the CFSG!).")

#emph[#text("Proof:")]#text(" Let ")#mi("{A}")#text(" be the set of all involutions in ")#mi("{G}")#text(", then as discussed above ")#tao-math("{\\left|A\\right| \\geq \\left|G\\right|/n}", block: false)#text(". We may assume that ")#mi("{G}")#text(" has no non-trivial unitary representation of dimension less than ")#mi("{4n^3}")#text(" (since such representations are automatically faithful by the simplicity of ")#mi("{G}")#text("); thus, in the language of quasirandomness, ")#mi("{G}")#text(" is ")#mi("{4n^3}")#text("-quasirandom, and is also non-abelian. We have the basic convolution estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\|1_A * 1_A * 1_A - \\frac{\\left|A\\right|^3}{\\left|G\\right|} \\right\\|_{\\ell^\\infty(G)} \\leq (4n^3)^{-1/2} \\left|G\\right|^{1/2} \\left|A\\right|^{3/2}", block: true)]]

#text("(see Exercise 10 from ")#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/")[#text("this previous blog post")]#text("). In particular,")

#align(center)[#tao-fit-display[#tao-math("1_A * 1_A * 1_A(0) \\geq \\frac{\\left|A\\right|^3}{\\left|G\\right|} - (4n^3)^{-1/2} \\left|G\\right|^{1/2} \\left|A\\right|^{3/2} \\geq \\frac{1}{2n^3} \\left|G\\right|^2", block: true)]]

#text("and so there are at least ")#tao-math("{\\left|G\\right|^2/2n^3}", block: false)#text(" pairs ")#mi("{(g,h) \\in A \\times A}")#text(" such that ")#mi("{gh \\in A^{-1} = A}")#text(", i.e. involutions ")#mi("{g,h}")#text(" whose product is also an involution. But any such involutions necessarily commute, since")

#align(center)[#tao-fit-display[#mitex("g (gh) h = g^2 h^2 = 1 = (gh)^2 = g (hg) h.")]]

#text("Thus there are at least ")#tao-math("{\\left|G\\right|^2/2n^3}", block: false)#text(" pairs ")#mi("{(g,h) \\in G \\times G}")#text(" of non-identity elements that commute, so by the pigeonhole principle there is a non-identity ")#mi("{g \\in G}")#text(" whose centraliser ")#mi("{C_G(g)}")#text(" has order at least ")#tao-math("{\\left|G\\right|/2n^3}", block: false)#text(". This centraliser cannot be all of ")#mi("{G}")#text(" since this would make ")#mi("{g}")#text(" central which contradicts the non-abelian simple nature of ")#mi("{G}")#text(". But then the ")#link("https://en.wikipedia.org/wiki/Quasiregular_representation")[#text("quasiregular representation")]#text(" of ")#mi("{G}")#text(" on ")#mi("{G/C_G(g)}")#text(" has dimension at most ")#mi("{2n^3}")#text(", contradicting the quasirandomness. ")#mi("\\Box")

#metadata(none) <tao-5361cc269293afd5e227>

#heading(level: 1)[#strong[#text(" — 1. Character-based proof — ")]]

#text("Now we give the character-based proof of Theorem ")#link(<tao-0b5005202223684c9544>)[#text("1")]#text(", following ")#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/")[#text("Isaacs")]#text(". We assume familiarity with the basic theory of ")#link("https://en.wikipedia.org/wiki/Character_(mathematics)")[#text("characters")]#text(", as reviewed in ")#link("https://terrytao.wordpress.com/2013/04/12/the-theorems-of-frobenius-and-suzuki-on-finite-groups/")[#text("this recent blog post")]#text(".")

#text("Let ")#mi("{G}")#text(" be a finite group, and let ")#mi("{\\chi = \\chi_\\rho}")#text(" be a character of ")#mi("{G}")#text(" associated to some finite-dimensional unitary representation ")#mi("{\\rho: G \\rightarrow U(V)}")#text(", thus ")#mi("{\\chi(g) = \\text{tr} \\rho(g)}")#text(". We can then consider the tensor square representation ")#mi("{\\rho \\otimes \\rho: G \\rightarrow U(V \\otimes V)}")#text(" defined in the usual manner:")

#align(center)[#tao-fit-display[#mitex("\\rho \\otimes \\rho(g) (x \\otimes y) = (\\rho(g) x) \\otimes (\\rho(g) y).")]]

#text("One easily checks that this representation has character")

#align(center)[#tao-fit-display[#mitex("\\chi_{\\rho \\otimes \\rho}(g) = \\chi_\\rho(g)^2.")]]

#text("On the other hand, the tensor square representation splits into the symmetric part ")#mi("{\\text{Sym}^2 \\rho: G \\rightarrow U(\\text{Sym}^2 V)}")#text(" and the alternating part ")#mi("{\\text{Alt}^2 \\rho: G \\rightarrow U(\\text{Alt}^2 V)}")#text(", since the ")#link("https://en.wikipedia.org/wiki/Symmetric_algebra")[#text("symmetric")]#text(" and ")#link("https://en.wikipedia.org/wiki/Exterior_algebra")[#text("alternating")]#text(" portions of the tensor square are preserved by the action of ")#mi("{G}")#text(". Thus we have a splitting")

#align(center)[#tao-fit-display[#mitex("\\chi_\\rho(g)^2 = \\chi_{\\text{Sym}^2 \\rho}(g) + \\chi_{\\text{Alt}^2 \\rho}(g);")]]

#text("in particular, taking inner products with the trivial character ")#mi("{1}")#text(" (i.e. computing the dimension of the invariant component of all representations listed above) we conclude that ")#metadata(none) <tao-560c48d6c73e72bde5e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("0 \\leq \\mathop{\\bf E}_{g \\in G} \\chi_{\\text{Alt}^2 \\rho}(g) \\leq \\mathop{\\bf E}_{g \\in G} \\chi(g)^2,")]]

#text("noting that the right-hand side vanishes if ")#mi("{\\chi}")#text(" is not real (so that ")#mi("{\\chi}")#text(" is orthogonal to ")#mi("{\\overline{\\chi}}")#text("). On the other hand, we can compute the character of ")#mi("{\\text{Alt}^2 \\rho}")#text(" explicitly using an orthonormal basis ")#mi("{e_1,\\ldots,e_n}")#text(" for ")#mi("{V}")#text(", which induces an orthonormal basis ")#mi("{\\frac{1}{\\sqrt{2}} (e_i \\otimes e_j - e_j \\otimes e_i)}")#text(", ")#mi("{1 \\leq i < j \\leq n}")#text(" for ")#mi("{\\text{Alt}^2 V}")#text(". Then the character ")#mi("{\\chi_{\\text{Alt}^2 \\rho}(g)}")#text(" is equal to")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq i < j \\leq n} \\langle \\rho(g) e_i, e_i \\rangle \\langle \\rho(g) e_j, e_j \\rangle - \\langle \\rho(g) e_i, e_j \\rangle \\langle \\rho(g) e_j, e_i \\rangle")]]

#text("which after some algebra (using symmetry to eliminate the constraint ")#mi("{i < j}")#text(" and noting that ")#mi("{\\rho(g) \\rho(g) = \\rho(g^2)}")#text(") simplifies to")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\chi(g)^2 - \\frac{1}{2} \\chi(g^2).")]]

#text("Inserting this back into ")#link(<tao-560c48d6c73e72bde5e5>)[#text("(1)")]#text(" we obtain the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{g \\in G} \\chi(g^2)\\right| \\leq \\mathop{\\bf E}_{g \\in G} \\chi(g)^2.", block: true)]]

#text("In particular, if ")#mi("{\\chi}")#text(" is irreducible, its ")#mi("{L^2(G)^G}")#text(" norm is ")#mi("{1}")#text(" and we conclude the following bound of Frobenius and Schur: ")#metadata(none) <tao-6528462d267b618aaff4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|\\mathop{\\bf E}_{g \\in G} \\chi(g^2)\\right| \\leq 1.", block: true)]]

#text("(Indeed, this argument shows that the expression ")#mi("{\\mathop{\\bf E}_{g \\in G} \\chi(g^2)}")#text(" is either ")#mi("{-1}")#text(", ")#mi("{0}")#text(", or ")#mi("{1}")#text(" and vanishes unless ")#mi("{\\chi}")#text(" is real, although we will not need these additional facts here.) Now from the orthogonality of irreducible characters we have ")#metadata(none) <tao-eeea394806ada3056899>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sum_{\\chi \\in \\hat G} \\chi(g^2) \\chi(1) = \\left|G\\right| 1_{g^2 = 1}", block: true)]]

#text("so if we average this in ")#mi("{g}")#text(" and use ")#link(<tao-6528462d267b618aaff4>)[#text("(2)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("1 + \\left|G\\right|/n \\leq \\sum_{\\chi \\in \\hat G} \\chi(1)", block: true)]]

#text("since ")#mi("{g^2=1}")#text(" for at least ")#tao-math("{1 + \\left|G\\right|/n}", block: false)#text(" values of ")#mi("{g}")#text(". On the other hand, from ")#link(<tao-eeea394806ada3056899>)[#text("(3)")]#text(" we have the well known identity")

#align(center)[#tao-fit-display[#tao-math("\\left|G\\right| = \\sum_{\\chi \\in \\hat G} \\chi(1)^2", block: true)]]

#text("so from Cauchy-Schwarz (after subtracting off the trivial character) we have")

#align(center)[#tao-fit-display[#tao-math("(\\left|G\\right|-1)/n^2 \\leq \\sum_{\\chi \\in \\hat G \\backslash 1} 1.", block: true)]]

#text("But the right-hand side is the number of non-trivial conjugacy classes of ")#mi("{G}")#text(", so by the pigeonhole principle there is a non-trivial conjugacy class with cardinality at most ")#mi("{n^2}")#text(", which gives a centraliser of order at least ")#tao-math("{\\left|G\\right|/n^2}", block: false)#text(", as required.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2013/05/02/quasirandom-groups-and-a-cheap-version-of-the-brauer-fowler-theorem/#comment-227485")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2013")])]

#text("There’s a slightly cleaner way to compute the character of the exterior square of a representation: the exterior square is a functor, so it suffices to compute the trace of the action of a linear map ")#mi("T : V \\to V")#text(" on the exterior square. Let ")#mi("e_1, ... e_n")#text(" be a basis of ")#mi("V")#text(" with respect to which ")#mi("T")#text(" is upper-triangular with diagonal entries ")#mi("\\lambda_1, ... \\lambda_n")#text(", so ")#mi("\\text{tr}(T) = \\sum \\lambda_i")#text(". Then ")#mi("e_i \\wedge e_j : i < j")#text(" is a basis of ")#mi("\\Lambda^2(V)")#text(" with respect to which ")#mi("T")#text(" is upper-triangular with diagonal entries ")#mi("\\lambda_i \\lambda_j")#text(", and ")#mi("\\sum_{i < j} \\lambda_i \\lambda_j = \\frac{(\\sum \\lambda_i)^2 - \\sum (\\lambda_i^2)}{2}")#text(" is a standard symmetric function identity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/05/02/quasirandom-groups-and-a-cheap-version-of-the-brauer-fowler-theorem/#comment-227941")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2013")])]

#text("Good point (and as we are working in the unitary setting, we can even take ")#mi("T")#text(" to be diagonal rather than upper triangular).")

#text("I now realise that this identity is the first non-trivial case of the more general ")#link("http://ncatlab.org/nlab/show/Schur+function")[#text("connection between Schur polynomials and Schur functors")]#text("; I was vaguely aware of this connection in a different context, but didn’t realise its relevance here until now.")
]
]
