// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/02/23/closing-the-green-gap-from-the-mathematics-of-the-landscape-function-to-lower-electricity-costs-for-households/
// Converted to Typst by tao2typ: "2026-10-14T15:21:03.868007+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Closing the “green gap”: from the mathematics of the landscape function to lower electricity costs for households", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Closing the “green gap”: from the mathematics of the landscape function to lower electricity costs for households")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 February 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/02/23/closing-the-green-gap-from-the-mathematics-of-the-landscape-function-to-lower-electricity-costs-for-households/")[#text("https://terrytao.wordpress.com/2025/02/23/closing-the-green-gap-from-the-mathematics-of-the-landscape-function-to-lower-electricity-costs-for-households/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("I recently returned from the ")#link("https://www.simonsfoundation.org/event/simons-collaboration-on-the-localization-of-waves-annual-meeting-2025/")[#text("2025 Annual Meeting")]#text(" of the ")#link("https://cse.umn.edu/wave")[#text("“Localization of Waves” collaboration")]#text(" (supported ")#link("https://www.simonsfoundation.org/2018/07/24/foundation-announces-simons-collaboration-on-localization-of-waves/")[#text("by the Simons Foundation")]#text(", with additional ")#link("https://www.nsf.gov/awardsearch/showAward?AWD_ID=1839077")[#text("related support from the NSF")]#text("), where I learned (from ")#link("https://cse.umn.edu/wave/svitlana-mayboroda")[#text("Svitlana Mayboroda")]#text(", the director of the collaboration as well as one of the principal investigators) of a remarkable statistic: net electricity consumption by residential customers in the US has actually experienced a slight decrease in recent years:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2025/02/screenshot-2025-02-22-150812.png")[#image("../assets/c7c655c5d5b4952bf239878c578cae26dd5f75c753c12ee4fc84c811c03351f7-0efc47225bcd70dfcf270ca7c0478c718c9827e091810447fd34f1be13d12449.png", width: 90%)]
]

#text("The decrease is ")#link("https://www.eia.gov/totalenergy/data/monthly/pdf/mer.pdf")[#text("almost entirely due")]#text(" to ")#link("https://www.energy.gov/eere/ssl/led-adoption-report")[#text("gains in lighting efficiency")]#text(" in households, and particularly the transition from incandescent (and compact fluorescent) light bulbs to LED light bulbs:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2025/02/screenshot-2025-02-22-150837.png")[#image("../assets/95e1ec96c98faf161a6e5ebb134a61923af6b83deb6ba3d0ec4e7630f9f93a9e-3e1e4c7652ce25c468a897f6c144d88b8fe7dcf7e83d0a863a6bd8f0eca85247.png", width: 90%)]
]

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2025/02/screenshot-2025-02-22-151817.png")[#image("../assets/cd636f5409dd060ab7b50b0a464c7a3ec5337276e579d56157e57243c5dd8b4b-f9d204dc9b924b6ca37e33640c65f00f75d4b9f9208cf998fc400c22cbe8fbdf.png", width: 90%)]
]

#text("Annual energy savings from this switch to consumers in the US were ")#link("https://www.energy.gov/eere/ssl/led-adoption-report")[#text("already estimated to be")]#text(" $14.7 billion in 2020 – or several hundred dollars per household – and are projected to increase, even in the current inflationary era, with the cumulative savings across the US ")#link("https://www.energy.gov/eere/ssl/ssl-forecast-report")[#text("estimated to reach")]#text(" $890 billion by 2035.")

#text("What I also did not realize before this meeting is the role that recent advances in pure mathematics – and specifically, the development of the “landscape function” that was a primary focus of this collaboration – played in accelerating this transition. This is not to say that this piece of mathematics was solely responsible for these developments; but, as I hope to explain here, it was certainly part of the research and development ecosystem in both academia and industry, spanning multiple STEM disciplines and supported by both ")#link("https://www.simonsfoundation.org/2018/07/24/foundation-announces-simons-collaboration-on-localization-of-waves/")[#text("private")]#text(" and ")#link("https://www.nsf.gov/awardsearch/showAward?AWD_ID=1839077")[#text("public")]#text(" funding. This application of the landscape function was already ")#link("https://www.quantamagazine.org/mathematicians-tame-rogue-waves-lighting-up-future-of-leds-20170822/")[#text("reported upon by Quanta magazine")]#text(" at the very start of this collaboration back in 2017; but it is only in the last few years that the mathematical theory has been incorporated into the latest LED designs and led to actual savings at the consumer end.")

#text("LED lights are made from layers of semiconductor material (e.g., Gallium nitride or Indium gallium nitride) arranged in a particular fashion. When enough of a voltage difference is applied to this material, electrons are injected into the “n-type” side of the LED, while ")#link("https://en.wikipedia.org/wiki/Electron_hole")[#text("holes of electrons")]#text(" are injected into the “p-type” side, creating a current. In the active layer of the LED, these electrons and holes recombine in the quantum wells of the layer, generating radiation (light) via the mechanism of ")#link("https://en.wikipedia.org/wiki/Electroluminescence")[#text("electroluminescence")]#text(". The brightness of the LED is determined by the current, while the power consumption is the product of the current and the voltage. Thus, to improve energy efficiency, one seeks to design LEDs to require as little voltage as possible to generate a target amount of current.")

#text("As it turns out, the efficiency of an LED, as well as the spectral frequencies of light they generate, depend in many subtle ways on the precise geometry of the chemical composition of the semiconductors, the thickness of the layers, the geometry of how the layers are placed atop one another, the temperature of the materials, and the amount of disorder (impurities) introduced into each layer. In particular, in order to create quantum wells that can efficiently trap the electrons and holes together to recombine to create light of a desired frequency, it is useful to introduce a certain amount of disorder into the layers in order to take advantage of the phenomenon of ")#link("https://en.wikipedia.org/wiki/Anderson_localization")[#text("Anderson localization")]#text(". However, one cannot add too much disorder, lest the electron states become fully bound and the material behaves too much like an insulator to generate appreciable current.")

#text("One can of course make empirical experiments to measure the performance of various proposed LED designs by fabricating them and then testing them in a laboratory. But this is an expensive and painstaking process that does not scale well; one cannot test thousands of candidate designs this way to isolate the best performing ones. So, it becomes desirable to perform numerical simulations of these designs instead, which – if they are sufficiently accurate and computationally efficient – can lead to a much shorter and cheaper design cycle. (In the near future one may also hope to accelerate the design cycle further by incorporating machine learning and AI methods; but these techniques, while promising, are still not fully developed at the present time.)")

#text("So, how can one perform numerical simulation of an LED? By the ")#link("https://en.wikipedia.org/wiki/Semiclassical_physics")[#text("semiclassical approximation")]#text(", the wave function ")#mi("{\\psi_i}")#text(" of an individual electron should solve the time-independent Schrödinger equation")

#mi("\\displaystyle -\\frac{\\hbar^2}{2m_e} \\Delta \\psi_i + E_c \\psi_i = E_i \\psi_i,")

#text("where ")#mi("{\\psi}")#text(" is the wave function of the electron at this energy level, and ")#mi("{E_c}")#text(" is the conduction band energy. The behavior of hole wavefunctions follows a similar equation, governed by the valence band energy ")#mi("{E_v}")#text(" instead of ")#mi("{E_c}")#text(". However, there is a complication: these band energies are not solely coming from the semiconductor, but also contain a contribution ")#mi("{\\mp e \\varphi}")#text(" that comes from electrostatic effects from the electrons and holes, and more specifically by solving the Poisson equation")

#mi("\\displaystyle \\mathrm{div}( \\varepsilon_r \\nabla \\varphi ) = \\frac{e}{\\varepsilon_0} (n-p + N_A^+ - N_D^-)")

#text("where ")#mi("{\\varepsilon_r}")#text(" is the dielectric constant of the semiconductor, ")#mi("{n,p}")#text(" are the carrier densities of electrons and holes respectively, ")#mi("{N_A^+}")#text(", ")#mi("{N_D^-}")#text(" are further densities of ionized acceptor and donor atoms, and ")#mi("{\\hbar, m_e, e, \\varepsilon_0}")#text(" are physical constants. This equation looks somewhat complicated, but is mostly determined by the carrier densities ")#mi("{n,p}")#text(", which in turn ultimately arise from the probability densities ")#tao-math("{\\left|\\psi_i\\right|^2}", block: false)#text(" associated to the eigenfunctions ")#mi("{\\psi_i}")#text(" via the ")#link("https://en.wikipedia.org/wiki/Born_rule")[#text("Born rule")]#text(", combined with ")#link("https://en.wikipedia.org/wiki/Fermi%E2%80%93Dirac_statistics")[#text("the Fermi-Dirac distribution from statistical mechanics")]#text("; for instance, the electron carrier density ")#mi("{n}")#text(" is given by the formula")

#tao-math("\\displaystyle n = \\sum_i \\frac{\\left|\\psi_i\\right|^2}{1 + e^{(E_i - E_{Fn})/k_B T}},", block: false)

#text("with a similar formula for ")#mi("{p}")#text(". In particular, the net potential ")#mi("{E_c}")#text(" depends on the wave functions ")#mi("{\\psi_i}")#text(", turning the Schrödinger equation into a nonlinear self-consistent ")#link("https://en.wikipedia.org/wiki/Hartree_equation")[#text("Hartree-type equation")]#text(". From the wave functions one can also compute the current, determine the amount of recombination between electrons and holes, and therefore also calculate the light intensity and absorption rates. But the main difficulty is to solve for the wave functions ")#mi("{\\psi_i}")#text(" for the different energy levels of the electron (as well as the counterpart for holes).")

#text("One could attempt to solve this nonlinear system iteratively, by first proposing an initial candidate for the wave functions ")#mi("{\\psi_i}")#text(", using this to obtain a first approximation for the conduction band energy ")#mi("{E_c}")#text(" and valence band energy ")#mi("{E_v}")#text(", and then solving the Schrödinger equations to obtain a new approximation for ")#mi("{\\psi_i}")#text(", and repeating this process until it converges. However, the regularity of the potentials ")#mi("{E_c, E_v}")#text(" plays an important role in being able to solve the Schrödinger equation. (The Poisson equation, being elliptic, is relatively easy to solve to high accuracy by standard methods, such as finite element methods.) If the potential ")#mi("{E_c}")#text(" is quite smooth and slowly varying, then one expects the wave functions ")#mi("{\\psi_i}")#text(" to be quite delocalizated, and for traditional approximations such as the ")#link("https://en.wikipedia.org/wiki/WKB_approximation")[#text("WKB approximation")]#text(" to be accurate.")

#text("However, in the presence of disorder, such approximations are no longer valid. As a consequence, traditional methods for numerically solving these equations had proven to be too inaccurate to be of practical use in simulating the performance of a LED design, so until recently one had to rely primarily on slower and more expensive empirical testing methods. One real-world consequence of this was the “")#link("https://compoundsemiconductor.net/article/101325/Getting_To_Grips_With_The_Green_Gap")[#text("green gap")]#text("“; while reasonably efficient LED designs were available in the blue and red portions of the spectrum, there was not a suitable design that gave efficient output in the green spectrum. Given that many applications of LED lighting required white light that was balanced across all visible colors of the spectrum, this was a significant impediment to realizing the energy-saving potential of LEDs.")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2025/02/screenshot-2025-02-22-165816.png")[#image("../assets/c1f9ea62ce070a2f7b41b8a1a50f468dfa1e86dae5a87ec4412f07b530752514-50f007d54b9e4a30613200cc1102bbc80c6b5c1f230adadb8baf9d4fd0b8ca30.png", width: 90%)]
]

#text("Here is where the landscape function comes in. This function started as a purely mathematical discovery: when solving a Schrödinger equation such as")

#mi("\\displaystyle -\\Delta \\phi + V \\phi = E \\phi")

#text("(where we have now suppressed all physical constants for simplicity), it turns out that the behavior of the eigenfunctions ")#mi("{\\phi}")#text(" at various energy levels ")#mi("{E}")#text(" is controlled to a remarkable extent by the ")#emph[#text("landscape function")]#text(" ")#mi("{u}")#text(", defined to be the solution to the equation")

#mi("\\displaystyle -\\Delta u + V u = 1.")

#text("As discussed in this ")#link("https://terrytao.wordpress.com/2021/01/06/the-effective-potential-of-an-m-matrix/")[#text("previous blog post")]#text(" (discussing a paper on this topic I wrote with some of the members of this collaboration), one reason for this is that the Schrödinger equation can be transformed after some routine calculations to")

#mi("\\displaystyle -\\frac{1}{u^2} \\mathrm{div}( u^2 \\nabla (\\phi/u)) + \\frac{1}{u} (\\phi/u) = E (\\phi/u),")

#text("thus making ")#mi("{\\frac{1}{u}}")#text(" an effective potential for the Schrödinger equation (and ")#mi("{u^2}")#text(" also being the coefficients of an effective geometry for the equation). In practice, when ")#mi("{V}")#text(" is a disordered potential, the effective potential ")#mi("{1/u}")#text(" tends to be behave like a somewhat “smoothed out” or “homogenized” version of ")#mi("{V}")#text(" that exhibits superior numerical performance. For instance, the classical ")#link("https://en.wikipedia.org/wiki/Weyl_law")[#text("Weyl law")]#text(" predicts (assuming a smooth confining potential ")#mi("{V}")#text(") that the density of states up to energy ")#mi("{E}")#text(" – that is to say, the number of bound states up to ")#mi("{E}")#text(" – should asymptotically behave like ")#tao-math("{\\frac{1}{(2\\pi)^2}\\left|\\{ (x,\\xi): \\xi^2 + V(x) \\leq E\\}\\right|}", block: false)#text(". This is accurate at very high energies ")#mi("{E}")#text(", but when ")#mi("{V}")#text(" is disordered, it tends to break down at low and medium energies. However, the landscape function makes a prediction ")#tao-math("{\\frac{1}{(2\\pi)^2}\\left|\\{ (x,\\xi): \\xi^2 + 1/u(x) \\leq E\\}\\right|}", block: false)#text(" for this density of states that is significantly more accurate in practice in these regimes, with a mathematical justification (up to multiplicative constants) of this accuracy obtained in ")#link("https://arxiv.org/abs/1909.10558")[#text("this paper of David, Filoche, and Mayboroda")]#text(". More refined predictions (again with some degree of theoretical support from mathematical analysis) can be made on the local integrated density of states, and with more work one can then also obtain approximations for the carrier density functions ")#mi("{n,p}")#text(" mentioned previously in terms of the energy band level functions ")#mi("{E_c}")#text(", ")#mi("{E_v}")#text(". As the landscape function ")#mi("{u}")#text(" is relatively easy to compute (coming from solving a single elliptic equation), this gives a very practical numerical way to carry out the iterative procedure described previously to model LEDs in a way that has proven to be both numerically accurate, and significantly faster than empirical testing, leading to a significantly more rapid design cycle.")

#text("In particular, recent advances in LED technology have largely closed the “green gap” by introducing designs that incorporate “")#mi("{V}")#text("-defects”: ")#mi("{V}")#text("-shaped dents in the semiconductor layers of the LED that create lateral carrier injection pathways and modify the internal electric field, enhancing hole transport into the active layer. The ability to accurately simulate the effects of these defects has allowed researchers to ")#link("https://www.energy.gov/sites/default/files/2023-05/bto-peer-2023-36418-solutions-droop-ucsb-speck.pdf")[#text("largely close this gap")]#text(":")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2025/02/screenshot-2025-02-22-171741.png")[#image("../assets/87846249541f06d9b537d0153ee97dd9375d3236f3c81717b9e59ed330df816c-129b2a247a23c9268e2c2b40a9ce652f32810c72cd75a106d2d3cca0e7671521.png", width: 90%)]
]

#text("My understanding is that the major companies involved in developing LED lighting are now incorporating landscape-based methods into their own proprietary simulation models to achieve similar effects in commercially produced LEDs, which should lead to further energy savings in the near future.")

#text("Thanks to Svitlana Mayboroda and Marcel Filoche for detailed discussions, comments, and corrections of the material here.")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/23/closing-the-green-gap-from-the-mathematics-of-the-landscape-function-to-lower-electricity-costs-for-households/#comment-687264")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("Prof, thank you for yet interesting and insightful article. Readable and fun to read, too. Many thanks again.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/23/closing-the-green-gap-from-the-mathematics-of-the-landscape-function-to-lower-electricity-costs-for-households/#comment-687265")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("yay for LEDs")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/23/closing-the-green-gap-from-the-mathematics-of-the-landscape-function-to-lower-electricity-costs-for-households/#comment-687267")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2025")])]

#text("I can say, you do not have any parallel personality. The world is indebted to have a true mathematician and more than that a contributor, like you.")

#text("With Best Regards,")

#text("Prof. Ashok Kumar")

#text("INDIA-201013")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/23/closing-the-green-gap-from-the-mathematics-of-the-landscape-function-to-lower-electricity-costs-for-households/#comment-687368")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("These kind of savings are better than the Trumped up Musky savings proposed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e6fbef28dc794fa8908428dc895764b062a7c69555058573e8976b77bdc11848-0f8d3d6106e10b9f6aa85894525bcd8256f85d7db571acc39e00a1c8e453cb8c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelnhowes")]], [#link("https://terrytao.wordpress.com/2025/02/23/closing-the-green-gap-from-the-mathematics-of-the-landscape-function-to-lower-electricity-costs-for-households/#comment-687370")[#strong[#text("michaelnhowes")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2025")])]

#text("This is fascinating! Thank you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/23/closing-the-green-gap-from-the-mathematics-of-the-landscape-function-to-lower-electricity-costs-for-households/#comment-687426")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2025")])]

#text("This is a fascinating post, beautifully illustrating how abstract mathematical tools like the landscape function can have tangible, real-world impact, leading to significant energy savings. It’s inspiring to see such elegant theory contribute to everyday improvements.")

#text("Reading this, I was reminded of another pivotal moment in LED development: the creation of the blue LED by Shuji Nakamura. While this post rightly celebrates the power of sophisticated mathematical approaches, Nakamura’s story highlights a different, yet equally crucial, path to innovation. His breakthrough wasn’t rooted in high-level theory, but in a deep, almost tradesman-like mastery of the manufacturing process and equipment. He, as some accounts suggest, even took on what might have been seen as a ‘lowly’ role, deeply immersing himself in the practical tools of the trade to overcome seemingly insurmountable engineering challenges.")

#text("Just as a rainbow needs the full spectrum of colors to be complete and illuminate the world, humanity needs both the soaring heights of abstract theory and the grounded expertise of practical mastery to solve the complex problems we face. Both approaches, like the different colors of light, bring unique and vital strengths to the task of innovation and progress.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/02/23/closing-the-green-gap-from-the-mathematics-of-the-landscape-function-to-lower-electricity-costs-for-households/#comment-687507")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2025")])]

#text("Read it as closing the green card gap. May be you should do a posting on the mathematics of green card gap.")
]
