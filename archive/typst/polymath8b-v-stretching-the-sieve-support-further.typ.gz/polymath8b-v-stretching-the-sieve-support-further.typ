// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/
// Converted to Typst by tao2typ: "2026-10-14T09:35:28.347386+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath8b, V: Stretching the sieve support further", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath8b, V: Stretching the sieve support further")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 January 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/")[#text("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is the fifth thread for the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8b project")]#text(" to obtain new bounds for the quantity")

#align(center)[#tao-fit-display[#mitex("H_m := \\liminf_{n \\rightarrow\\infty} (p_{n+m} - p_n),")]]

#text("either for small values of ")#mi("{m}")#text(" (in particular ")#mi("{m=1,2}")#text(") or asymptotically as ")#mi("{m \\rightarrow \\infty}")#text(". The previous thread may be found ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/")[#text("here")]#text(". The currently best known bounds on ")#mi("{H_m}")#text(" can be found at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("the wiki page")]#text(" (which has recently returned to full functionality, after a partial outage). In particular, the upper bound for ")#mi("{H_1}")#text(" has been shaved a little from ")#mi("{272}")#text(" to ")#mi("{270}")#text(", and we have very recently achieved the bound ")#mi("{H_1 \\leq 8}")#text(" on the generalised Elliott-Halberstam conjecture GEH, formulated as Conjecture 1 of ")#link("http://www.ams.org/mathscinet-getitem?mr=834613")[#text("this paper of Bombieri, Friedlander, and Iwaniec")]#text(". We also have explicit bounds for ")#mi("{H_m}")#text(" for ")#mi("{m \\leq 5}")#text(", both with and without the assumption of the Elliott-Halberstam conjecture, as well as slightly sharper asymptotics for the upper bound for ")#mi("{H_m}")#text(" as ")#mi("{m \\rightarrow \\infty}")#text(".")

#text("The basic strategy for bounding ")#mi("{H_m}")#text(" still follows the general paradigm first laid out by Goldston, Pintz, Yildirim: given an admissible ")#mi("{k}")#text("-tuple ")#mi("{(h_1,\\dots,h_k)}")#text(", one needs to locate a non-negative sieve weight ")#mi("{\\nu: {\\bf Z} \\rightarrow {\\bf R}^+}")#text(", supported on an interval ")#mi("{[x,2x]}")#text(" for a large ")#mi("{x}")#text(", such that the ratio ")#metadata(none) <tao-b3deb173436f3977aca4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{\\sum_{i=1}^k \\sum_n \\nu(n) 1_{n+h_i \\text{ prime}}}{\\sum_n \\nu(n)}")]]

#text("is asymptotically larger than ")#mi("{m}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text("; this will show that ")#mi("{H_m \\leq h_k-h_1}")#text(". Thus one wants to locate a sieve weight ")#mi("{\\nu}")#text(" for which one has good lower bounds on the numerator and good upper bounds on the denominator.")

#text("One can modify this paradigm slightly, for instance by adding the additional term ")#mi("{\\sum_n \\nu(n) 1_{n+h_1,\\dots,n+h_k \\text{ composite}}}")#text(" to the numerator, or by subtracting the term ")#mi("{\\sum_n \\nu(n) 1_{n+h_1,n+h_k \\text{ prime}}}")#text(" from the numerator (which allows one to reduce the bound ")#mi("{h_k-h_1}")#text(" to ")#mi("{\\max(h_k-h_2,h_{k-1}-h_1)}")#text("); however, the numerical impact of these tweaks have proven to be negligible thus far.")

#text("Despite a number of experiments with other sieves, we are still relying primarily on the Selberg sieve")

#align(center)[#tao-fit-display[#mitex("\\nu(n) := 1_{n=b\\ (W)} 1_{[x,2x]}(n) \\lambda(n)^2")]]

#text("where ")#mi("{\\lambda(n)}")#text(" is the divisor sum")

#align(center)[#tao-fit-display[#mitex("\\lambda(n) := \\sum_{d_1|n+h_1, \\dots, d_k|n+h_k} \\mu(d_1) \\dots \\mu(d_k) f( \\frac{\\log d_1}{\\log R}, \\dots, \\frac{\\log d_k}{\\log R})")]]

#text("with ")#mi("{R = x^{\\theta/2}}")#text(", ")#mi("{\\theta}")#text(" is the level of distribution (")#mi("{\\theta=1/2-}")#text(" if relying on Bombieri-Vinogradov, ")#mi("{\\theta=1-}")#text(" if assuming Elliott-Halberstam, and (in principle) ")#mi("{\\theta = \\frac{1}{2} + \\frac{13}{540}-}")#text(" if using Polymath8a technology), and ")#mi("{f: [0,+\\infty)^k \\rightarrow {\\bf R}}")#text(" is a smooth, compactly supported function. Most of the progress has come by enlarging the class of cutoff functions ")#mi("{f}")#text(" one is permitted to use.")

#text("The baseline bounds for the numerator and denominator in ")#link(<tao-b3deb173436f3977aca4>)[#text("(1)")]#text(" (as established for instance in ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")[#text("this previous post")]#text(") are as follows. If ")#mi("{f}")#text(" is supported on the simplex")

#align(center)[#tao-fit-display[#mitex("{\\cal R}_k := \\{ (t_1,\\dots,t_k) \\in [0,+\\infty)^k: t_1+\\dots+t_k < 1 \\},")]]

#text("and we define the mixed partial derivative ")#mi("{F: [0,+\\infty)^k \\rightarrow {\\bf R}}")#text(" by")

#align(center)[#tao-fit-display[#mitex("F(t_1,\\dots,t_k) = \\frac{\\partial^k}{\\partial t_1 \\dots \\partial t_k} f(t_1,\\dots,t_k)")]]

#text("then the denominator in ")#link(<tao-b3deb173436f3977aca4>)[#text("(1)")]#text(" is ")#metadata(none) <tao-31c87172062561fd29a8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\frac{Bx}{W} (I_k(F) + o(1))")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("B := (\\frac{W}{\\phi(W) \\log R})^k")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("I_k(F) := \\int_{[0,+\\infty)^k} F(t_1,\\dots,t_k)^2\\ dt_1 \\dots dt_k.")]]

#text("Similarly, the numerator of ")#link(<tao-b3deb173436f3977aca4>)[#text("(1)")]#text(" is ")#metadata(none) <tao-993e4ac10a2072b16b1d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\frac{Bx}{W} \\frac{2}{\\theta} (\\sum_{j=1}^m J^{(m)}_k(F) + o(1))")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("J_k^{(m)}(F) := \\int_{[0,+\\infty)^{k-1}} (\\int_0^\\infty F(t_1,\\ldots,t_k)\\ dt_m)^2\\ dt_1 \\dots dt_{m-1} dt_{m+1} \\dots dt_k.")]]

#text("Thus, if we let ")#mi("{M_k}")#text(" be the supremum of the ratio")

#align(center)[#tao-fit-display[#mitex("\\frac{\\sum_{m=1}^k J_k^{(m)}(F)}{I_k(F)}")]]

#text("whenever ")#mi("{F}")#text(" is supported on ")#mi("{{\\cal R}_k}")#text(" and is non-vanishing, then one can prove ")#mi("{H_m \\leq h_k - h_1}")#text(" whenever")

#align(center)[#tao-fit-display[#mitex("M_k > \\frac{2m}{\\theta}.")]]

#text("We can improve this baseline in a number of ways. Firstly, with regards to the denominator in ")#link(<tao-b3deb173436f3977aca4>)[#text("(1)")]#text(", if one upgrades the Elliott-Halberstam hypothesis ")#mi("{EH[\\theta]}")#text(" to the generalised Elliott-Halberstam hypothesis ")#mi("{GEH[\\theta]}")#text(" (currently known for ")#mi("{\\theta < 1/2}")#text(", thanks ")#link("http://www.ams.org/mathscinet-getitem?mr=422179")[#text("to Motohashi")]#text(", but conjectured for ")#mi("{\\theta < 1}")#text("), the asymptotic ")#link(<tao-31c87172062561fd29a8>)[#text("(2)")]#text(" holds under the more general hypothesis that ")#mi("{F}")#text(" is supported in a polytope ")#mi("{R}")#text(", as long as ")#mi("{R}")#text(" obeys the inclusion ")#metadata(none) <tao-c3701bab47a9e42b3642>

#tao-aligned(keep: true)[


#tao-math("R + R  & \\subset \\bigcup_{m=1}^k \\{ (t_1,\\ldots,t_k) \\in [0,+\\infty)^k:", block: true, numbering: n => [#text("(4)")])



#tao-math("t_1+\\dots+t_{m-1}+t_{m+1}+\\dots+t_k  & < 2; t_m < 2/\\theta \\} \\cup \\frac{2}{\\theta} \\cdot {\\cal R}_k;", block: true)
]

#text("examples of polytopes ")#mi("{R}")#text(" obeying this constraint include the modified simplex")

#tao-aligned(keep: true)[


#tao-math("{\\cal R}^{\\prime}_k  & := \\{ (t_1,\\ldots,t_k) \\in [0,+\\infty)^k: t_1+\\dots+t_{m-1}+t_{m+1}+\\dots+t_k < 1", block: true)



#tao-math("\\text{ for all } 1  & \\leq m \\leq k \\},", block: true)
]

#text("the prism")

#align(center)[#tao-fit-display[#mitex("{\\cal R}_{k-1} \\times [0, 1/\\theta)")]]

#text("the dilated simplex")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\theta} \\cdot {\\cal R}_k")]]

#text("and the truncated simplex")

#align(center)[#tao-fit-display[#mitex("\\frac{k}{k-1} \\cdot {\\cal R}_k \\cap [0,1/\\theta)^k.")]]

#text("See ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/")[#text("this previous post")]#text(" for a proof of these claims.")

#text("With regards to the numerator, the asymptotic ")#link(<tao-993e4ac10a2072b16b1d>)[#text("(3)")]#text(" is valid whenever, for each ")#mi("{1 \\leq m \\leq k}")#text(", the marginals ")#mi("{\\int_0^\\infty F(t_1,\\ldots,t_k)\\ dt_m}")#text(" vanish outside of ")#mi("{{\\cal R}_{k-1}}")#text(". This is automatic if ")#mi("{F}")#text(" is supported on ")#mi("{{\\cal R}_k}")#text(", or on the slightly larger region ")#mi("{{\\cal R}^{\\prime}_k}")#text(", but is an additional constraint when ")#mi("{F}")#text(" is supported on one of the other polytopes ")#mi("{R}")#text(" mentioned above.")

#text("More recently, we have obtained a more flexible version of the above asymptotic: if the marginals ")#mi("{\\int_0^\\infty F(t_1,\\ldots,t_k)\\ dt_m}")#text(" vanish outside of ")#mi("{(1+\\varepsilon) \\cdot {\\cal R}_{k-1}}")#text(" for some ")#mi("{0 < \\varepsilon < 1}")#text(", then the numerator of ")#link(<tao-b3deb173436f3977aca4>)[#text("(1)")]#text(" has a ")#emph[#text("lower bound")]#text(" of")

#align(center)[#tao-fit-display[#mitex("\\frac{Bx}{W} \\frac{2}{\\theta} (\\sum_{j=1}^m J^{(m)}_{k,\\varepsilon}(F) + o(1))")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("J_{k,\\varepsilon}^{(m)}(F) := \\int_{(1-\\varepsilon) \\cdot {\\cal R}_{k-1}} (\\int_0^\\infty F(t_1,\\ldots,t_k)\\ dt_m)^2\\ dt_1 \\dots dt_{m-1} dt_{m+1} \\dots dt_k.")]]

#text("A proof is given ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261207")[#text("here")]#text(". Putting all this together, we can conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Suppose we can find ")#mi("{0 \\leq \\varepsilon < 1}")#text(" and a function ")#mi("{F}")#text(" supported on a polytope ")#mi("{R}")#text(" obeying ")#link(<tao-c3701bab47a9e42b3642>)[#text("(4)")]#text(", not identically zero and with all marginals ")#mi("{\\int_0^\\infty F(t_1,\\ldots,t_k)\\ dt_m}")#text(" vanishing outside of ")#mi("{(1+\\varepsilon) \\cdot {\\cal R}_{k-1}}")#text(", and with")

#align(center)[#tao-fit-display[#mitex("\\frac{\\sum_{m=1}^k J_{k,\\varepsilon}^{(m)}(F)}{I_k(F)} > \\frac{2m}{\\theta}.")]]

#text("Then ")#mi("{GEH[\\theta]}")#text(" implies ")#mi("{H_m \\leq h_k-h_1}")#text(".")
]

#text("In principle, this very flexible criterion for upper bounding ")#mi("{H_m}")#text(" should lead to better bounds than before, and in particular we have now established ")#mi("{H_1 \\leq 8}")#text(" on GEH.")

#text("Another promising direction is to try to improve the analysis at medium ")#mi("{k}")#text(" (more specifically, in the regime ")#mi("{k \\sim 50}")#text("), which is where we are currently at without EH or GEH through numerical quadratic programming. Right now we are only using ")#mi("{\\theta=1/2}")#text(" and using the baseline ")#mi("{M_k}")#text(" analysis, basically for two reasons:")

#list(
[#text("We do not have good numerical formulae for integrating polynomials on any region more complicated than the simplex ")#mi("{{\\cal R}_k}")#text(" in medium dimension.")],
[#text("The estimates ")#mi("{MPZ^{(i)}[\\varpi,\\delta]}")#text(" produced by Polymath8a involve a ")#mi("{\\delta}")#text(" parameter, which introduces additional restrictions on the support of ")#mi("{F}")#text(" (conservatively, it restricts ")#mi("{F}")#text(" to ")#mi("{[0,\\delta^{\\prime}]^k}")#text(" where ")#mi("{\\delta^{\\prime} := \\frac{\\delta}{1/4+\\varpi}}")#text(" and ")#mi("{\\theta = 1/2 + 2 \\varpi}")#text("; it should be possible to be looser than this (as was done in Polymath8a) but this has not been fully explored yet). This then triggers the previous obstacle of having to integrate on something other than a simplex.")]
)

#text("However, these look like solvable problems, and so I would expect that further unconditional improvement for ")#mi("{H_1}")#text(" should be possible.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (145)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262414")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("I’m struggling to understand the nature of the current obstacle to exploring the dilated simplex in the BV setting. Terry noted in ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258264")[#text("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258264")]#text(" that no combinatorially-explosive dissection of that polytope was needed for this calculation, and Pace implied in ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258471")[#text("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258471")]#text(" that it was relatively straightforward, but that’s the last I’ve seen. Has a previously-overlooked obstacle emerged? I had thought it was just a matter of getting around to it, but Terry’s description above (“We do not have good numerical formulae…”) implies a deeper issue. Could someone please clarify? – thanks in advance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262427")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("On my end, the obstacle is that even for moderately sized ")#mi("k")#text(" the polynomial ")#mi("(f(2-e_1)^k e_k)_{1,\\ldots, k}")#text(" is hard to work with (especially when multiplying two such polynomials together and integrating).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262438")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("I see – thanks. How big, at present, is “moderately sized” in this sense? – is it possible to work your way up from very small k far enough to give the chance of discerning a trend?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262471")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("That’s a good question, which I don’t know the answer to. At present, I’m going to focus on the small k computations, but I may come back to this later.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/678a96f92d8a2f7ccb467bc350dfc6865a6f18d08028d29b337fc056cb51fbd5-c7cb2f7bb9d5f4be0bae0efaf88e854188e3cc69eeb3e150f68b429bdf6a1186.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reid Atcheson")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262472")[#strong[#text("Reid Atcheson")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("Would it be helpful if the basis formed an orthogonal system on the simplex? Such a basis has been in use by the spectral methods community for a while, and has an analytic recurrence formula in terms of 1D Jacobi polynomials. The details of these posts are otherwise too advanced for my full comprehension.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262476")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("Good question! The problem though is that there are two quadratic forms (or, if one wishes, inner products) one has to work with – one associated to the denominator (which is the usual inner product on the simplex) and one associated to the numerator (which is more complicated, basically an inner product on the marginals of the original function). One could pick a basis which diagonalises one of these two quadratic forms, but unless the basis is very cleverly chosen, the other quadratic form would not be in any particularly simple form. So it would likely only lead to a modest gain in performance at best.")

#text("Of course, if we found a basis for which the numerator and denominator were simultaneously diagonalised, or nearly so, this would indeed be a game-changer, but this may be unlikely. For instance, in the k=2 case, the extremal function is explicitly computable as ")#mi("\\frac{1}{M_2-1+x} + \\frac{1}{M_2-1+y} + \\frac{1}{2M_2-1} \\log \\frac{M_2-x}{M_2-1+x} \\frac{M_2-y}{M_2-1+y}")#text(", which does not look like it has a particularly simple representation in any natural basis that comes to mind, which suggests that one cannot simplify the optimisation problem too much by working in a standard basis.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262430")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("It seems (as remarked in a previous comment) that the only obstacle is that the (repeated) partial derivatives are generating many monomials from a single one (so a careful choice of the basis functions is needed in order to have low complexity integrals – needed for the numerical optimization program.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262446")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("As I understand, the only regularity condition on ")#mi("F")#text(" is its square integrability which implies, for the one dimensional sieve that ")#mi("f")#text(" needs only to be absolutely continuous. So there is a possibility that by imposing ")#mi("C^1")#linebreak()#text(" – smoothness condition on ")#mi("f")#text(" we don’t get the true optimal value.")#linebreak()#text(" For example, in the ")#mi("M_{k, \\epsilon}")#text(" derivation, I explicitly assumed the continuity of ")#mi("f^{\\prime}")#text(" at ")#mi("t = 1- \\epsilon")#text(" but if ")#mi("f^{\\prime}")#text(" is allowed to have a jump at that point, perhaps a better solution exists…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262448")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("I think that any rough candidate for f can be regularised into a smooth one while only perturbing f and its derivatives infinitesimally in L^2 type norms, which should not lead to any change in the supremum of the ratio being optimised over.")

#text("I would expect that even for rough extremisers, one should still have the Euler-Lagrange equation ")#mi("(af^{\\prime})^{\\prime} + \\lambda bf = 0")#text(" hold in a distributional sense (i.e. using weak derivatives). As a is continuous and bounded away from zero and b only has jump discontinuities, this suggests to me that f’ should remain continuous for the extremiser.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262460")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("I agree! (I think that the needed properties are that a is absolutely continuous and non-vanishing inside the interval, and that b is measurable and bounded.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262494")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("The Euler-Lagrange equation for the ")#mi("M_{k,\\epsilon,1}^{1 D}")#text(" variational problem is quite interesting (coupling four sub-intervals) and seems to be analytically solvable (I need to check the details.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262501")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("I’m a little confused by Theorem 1. Previously, we were allowed to take the support of F to be the polytope ")#mi("\\{ (t_1,\\dots,t_k): t_1,\\dots,t_k \\leq 1/\\theta; t_1+\\dots+t_k \\leq 1+\\varepsilon \\}")#text(" which doesn’t seem to satisfy condition (4).")

#text("In the theorem, perhaps the support should be ")#mi("(1+\\varepsilon)R")#text(" (rather than just ")#mi("R")#text("), still for a region ")#mi("R")#text(" satisfying (4)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262502")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("Or rather, ")#mi("(1+\\varepsilon)R\\cap [0,2/\\theta]^k")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262506")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("This polytope obeys (4) as long as ")#mi("\\varepsilon \\leq 1/(k-1)")#text(". Basically, the point is that full sum ")#mi("t_1+\\dots+t_k")#text(" is ")#mi("\\frac{k}{k-1}")#text(" times the average of the partial sums ")#mi("t_1 + \\dots + t_{m-1} + t_{m+1} + \\dots + t_k")#text(" for ")#mi("m=1,\\dots,k")#text(", so that if ")#mi("t_1+\\dots+t_k < 2k/(k-1)")#text(", then at least one of the partial sums ")#mi("t_1 + \\dots + t_{m-1} + t_{m+1} + \\dots + t_k")#text(" will be less than 2. (Actually, I think the fact that this polytope works originated from a comment of yours: ")#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257443")[#text("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257443")]#text(" .)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262633")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("You are right, I see what I was missing now.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262637")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("Two small remarks:")

#text("Firstly, strictly speaking our new results rely on the “generalised” Elliott-Halberstam hypothesis (GEH) rather than the original Elliott-Halberstam hypothesis, namely the EH type distribution result for a general class of Dirichlet convolutions ")#mi("\\alpha \\ast \\beta")#text(" as opposed to just for the von Mangoldt function. (A precise statement of GEH can be found as Conjecture 1 of ")#link("http://link.springer.com/article/10.1007/BF02399204")[#text("this paper of Bombieri, Friedlander, and Iwaniec")]#text("; the Bombieri-Vinogradov analogue of GEH was first established ")#link("http://www.ams.org/mathscinet-getitem?mr=422179")[#text("by Motohashi")]#text(".) If one only has EH rather than GEH, one can still take ")#mi("\\theta=1-")#text(", but the function F is now constrained to the original simplex ")#mi("{\\cal R}_k")#text(", so one cannot do better than ")#mi("M_k")#text(" with our current bag of tricks. But I think GEH is close enough to EH (especially when viewed relative to the presumed difficulty of EH) that this is not too much of a “cheat”.")

#text("Secondly, as mentioned previously in ")#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253452")[#text("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253452")]#text(" , the fact that we now can get k=4 on (generalised) EH means that we have a twin prime/Goldbach dichotomy on GEH: either the twin prime conjecture is true, or every large multiple of six lies within 2 of the sum of two primes (and thus large even natural number lies within 4 of the sum of two primes), by consideration of the tuple n, n+2, N-n, N-n-2, which is admissible when N is a multiple of 6.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262641")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("Does the remark on page 12 of James’ preprint allow us to use ")#mi("\\mathcal{R}_{k}^{\\prime}")#text(" under EH, or do we need GEH there as well?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262648")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("That remark shows that to treat the numerator in (1) one can live on ")#mi("{\\cal R}^{\\prime}_k")#text(" (indeed the same argument shows that one can control the numerator as long as all marginals of F live on ")#mi("{\\cal R}_{k-1}")#text("), but the issue is with control of the denominator (Lemma 5.1 in James’s paper, rather than Lemma 5.2) which, in order to go beyond ")#mi("\\frac{1}{\\theta} \\cdot {\\cal R}_k")#text(", needs EH for other divisor sums than the von Mangoldt function.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262646")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("A variant on the second remark: on GEH, either the twin prime conjecture is true, or there are infinitely many ")#link("http://en.wikipedia.org/wiki/Cunningham_chain")[#text("Cunningham chains")]#text(" of length 2, as can be seen by consideration of the admissible tuple n-1, n+1, 2n-1, 2n+1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262656")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("Oops, I withdraw that assertion: if, for instance, it is n-1 and 2n+1 that are simultaneously prime then one doesn’t get either a twin prime or a Cunningham chain.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1addf66c828222a64b02337fe343c1d82ca0beb7725d1cf4292d27e33f9608f-a7cc4c4624a4048c133a96a95b85d622a70a731ac54f35a22f3da0f80150effa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jmc")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262652")[#strong[#text("jmc")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("In that previous comment, you sketched two similar statements (about “prime gaps” on the one hand, and “bounded Goldbach” on the other) , and there you said that *at least one* of them is true (logical OR). Now you say it is a dichotomy (*either* one *or* the other, exclusive OR). Where does this difference come from?")

#text("And do I understand you correctly that this implies that the Twin Prime Conjecture and the Goldbach Conjecture cannot be both true?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262654")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("Sorry, I misspoke; it should be “disjunction” rather than “dichotomy”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262668")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("Another variant on the second remark (this one, hopefully, more correct than the previous variant): on GEH, either the twin prime conjecture is true, or every multiple N of 6 lies within two of a ")#link("http://arxiv.org/abs/1305.6289")[#text("Polignac number")]#text(" (a number that is the difference of two consecutive primes infinitely often). This comes from consideration of the admissible tuple n, n+2, n+N, n+N+2. (To force the two primes to be consecutive, one needs some additional arguments of Pintz in the paper linked above, first to force all four members of the tuple to be almost prime (by counting in the Selberg sieve the contribution for a given member to not be almost prime), and then to use an additional upper bound sieve to eliminate the contribution of those n for which there is an additional prime between two elements of the tuple.)")

#text("If we end up achieving k=3 rather than k=4, one would imagine that even more results of this type will become available.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262678")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("Terry: does the need to go beyond von Mangoldt have any impact on the anticipated difficulty of adapting MPZ to the current context?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262680")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("Good question! I don’t foresee any difficulties extending the MPZ results from von Mangoldt to the specific convolutions (basically, sums of the form ")#mi("\\alpha \\ast 1")#text(") needed to generate the various prisms in (4) above; the Type I/II sums should already suffice here, and in fact there might be a little bit of gain over the von Mangoldt numerology due to the smoothness of one of the convolution factors. But actually it is all probably moot, because we get “for free” the simplex ")#mi("\\frac{1}{\\theta} \\cdot {\\cal R}_k")#text(" in (4) (coming from the fact that the constant function 1 has level of distribution 1 for trivial reasons) and unconditionally, we have to keep ")#mi("\\theta")#text(" close to 1/2 (at best we can do 1/2+13/540 currently) and this should give us plenty of room for the support of F. (But even with F restricted to ")#mi("{\\cal R}_k")#text(", we should be able to beat the current value k=54 of k with the MPZ estimates we have, once we have some idea of how to numerically handle the truncation.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262685")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("Since by theorem 1 above, in order to have ")#mi("k = 4")#text(" we may relax GEH to ")#mi("GEH[\\theta]")#text(" for any “good” ")#mi("\\theta")#text(" satisfying ")#mi("\\theta > 2/M_{4, \\epsilon, \\theta}")#text(" it would be interesting to get (as small as possible) such “good” ")#mi("\\theta")#text(".")#linebreak()#text(" Moreover, If for some such “good” ")#mi("\\theta")#text(", ")#mi("GEH[\\theta]")#text(" is implied by EH than we have ")#mi("k = 4")#text(" under EH.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262744")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("Yes, our criteria are open, so any result that uses ")#mi("EH[1]")#text(" actually uses ")#mi("EH[1-c]")#text(" for some absolute constant ")#mi("c>0")#text(", and similarly for GEH. (In the original Goldston-Pintz-Yildirim paper, they observe that the bound ")#mi("H_1 \\leq 16")#text(" on EH actually just needs ")#mi("EH[0.97096\\dots]")#text(", see page 12). So there is some residual value in pushing the various M_k type values beyond 2, as any increase will presumably decrease the amount of EH one needs. (Also, accurate values of M_k may help with trying to extrapolate to medium-sized k.)")

#text("It is conceivable that EH could imply GEH for the type of sequences we actually use – they are something like convolutions of truncated Mobius functions and 1. It looks a bit unlikely though; the best I could reasonably expect is that one could replace GEH by an EH for a family of von Mangoldt-like functions (e.g. functions whose Dirichlet series has some nice properties). Given that GEH is already stated in the literature, it may be simplest just to use it as is, and not try too hard to replace it with other unproven conjectures.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262647")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("It seems that ")#mi("EH[\\theta]")#text(" in theorem 1 above, should be modified. (with similar modifications in the list of records.)")

#emph[#text("[Good point – I’ve changed the text accordingly.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262717")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("The timeline of bounds should also be modified to include the GEH.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262662")[#strong[#text("Polymath 8 – a Success! | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")]

#text("[…] are infinitely many primes of bounded gap below 16. Maynard improved it to 12. Polymath8b have just improved it further to 8. (The unconditional bound for gaps stands now on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262714")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("I may be missing something obvious here, but in the world records table I’m not seeing why M_k,epsilon has an exact value of 2 for k=2. How does the lower bound of 2 arise here when it doesn’t for the original M_2? – and what is the optimum epsilon for this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262721")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("Ah, good point; in truth the only lower bound for ")#mi("M_{2,\\varepsilon}")#text(" computed so far is the value 1.385.. for M_2. Presumably one can do better than this, but one should not be able to get all the way to 2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262737")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("Thanks. Eytan posted something about M_2,epsilon (")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262267")[#text("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262267")]#text(") that I don’t think received any followup yet – maybe that’s a place to start?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262961")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2014")])]

#text("In theorem 1 above, I suggest to include also the case ")#mi("\\epsilon = 0")#text(".")

#emph[#text("[Done – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262962")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2014")])]

#text("For purposes of large k asymptotics, I now have the upper bound")

#mi("M_{k,\\varepsilon} \\leq \\frac{k}{k-1} ( \\log k + (1+\\varepsilon) \\log \\frac{2k}{k+1} ) = \\log k + O(1)")

#text("so one does not get a substantial gain in the large k regime from the epsilon flexibility.")

#text("To see this, we define the weight ")#mi("w_k(t_1,\\dots,t_k)")#text(" to be ")#mi("1 - t_1 - \\dots - t_{k-1} + (k-1) t_k")#text(" when ")#mi("t_1+\\dots+t_k \\leq 1")#text(", and to be ")#mi("\\frac{1}{1+\\varepsilon}( 1+\\varepsilon-t_1-\\dots-t_{k-1}+(k-1)t_k )")#text(" when ")#mi("1 < t_1+\\dots+t_k \\leq 1+\\varepsilon")#text(", and similarly define ")#mi("w_1,\\ldots,w_{k-1}")#text(" by cyclic permutations. Observe that the ")#mi("w_i")#text(" are nonnegative and")

#mi("w_1 + \\ldots + w_k = k")

#text("on the simplex ")#mi("(1+\\varepsilon) \\cdot {\\cal R}_k")#text(". Thus, for F on this simplex we have by Cauchy-Schwarz")

#mi("(\\int_0^{1+\\varepsilon-t_1-\\dots-t_{k-1}} F\\ dt_k)^2 \\leq (\\int_0^{1+\\varepsilon-t_1-\\dots-t_{k-1}} F^2 w_k\\ dt_k) (\\int_0^{1+\\varepsilon-t_1-\\dots-t_{k-1}} w_k^{-1}\\ dt_k).")

#text("If ")#mi("t_1+\\dots+t_{k-1} \\leq 1-\\varepsilon")#text(", then setting ")#mi("a = 1 - t_1-\\dots-t_{k-1}")

#mi("\\int_0^{1+\\varepsilon-t_1-\\dots-t_{k-1}} w_k^{-1}\\ dt_k = \\int_0^a \\frac{dt_k}{a+(k-1)t_k} + (1+\\varepsilon) \\int_a^{a+\\varepsilon} \\frac{dt_k}{a+\\varepsilon+(k-1)t_k}")#linebreak()#text(" ")#mi("= \\frac{\\log k}{k-1} + \\frac{1+\\varepsilon}{k-1} \\log \\frac{k(a+\\varepsilon)}{ka+\\varepsilon}")#linebreak()#text(" ")#mi("\\leq \\frac{\\log k}{k-1} + \\frac{1+\\varepsilon}{k-1} \\log \\frac{2k}{k+1}")

#text("since ")#mi("a \\geq \\varepsilon")#text(". Integrating we get")

#mi("J_{k,\\varepsilon}^{(k)}(F) \\leq (\\int F^2 w_k\\ dt_1 \\dots dt_k) ( \\frac{\\log k}{k-1} + \\frac{1+\\varepsilon}{k-1} \\log \\frac{2k}{k+1} )")

#text("and summing over cyclic permutations one gets the claim.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262970")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2014")])]

#text("By using ")#mi("R = (1/ \\theta) \\mathcal R_k")#text(", in order to satisfy the marginals vanishing constraints, we may take any ")#mi("1 +\\epsilon")#text(" in the interval ")#mi("[1, 1/\\theta]")#text(". Since the upper bound for ")#mi("M_k")#text(" is quite tight, the additive gain is lower bounded by about ")#mi("\\log 2")#text(", and upper bounded by about ")#mi("(1 + \\epsilon) \\log 2 \\leq \\log 2 /\\theta")#text(".")#linebreak()#text(" For ")#mi("\\theta = 1/2")#text(", this additive gain is in ")#mi("[\\log 2, 2 \\log 2]")#text(". This implies (approximately) the reduction of the unconditional current ")#mi("k = 54")#text(" by a factor between 2 and 4. (i.e. unconditional ")#mi("k \\in [14, 27]")#text(" !)")#linebreak()#text(" (but perhaps this is too optimistic …)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262975")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2014")])]

#text("The above analysis is indeed optimistic because the vanishing marginals constraints should reduce ")#mi("M_{k, \\epsilon}")#text(" – making its upper bound less tight than the bound for ")#mi("M_k")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263106")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2014")])]

#text("By taking ")#mi("R = (1+\\epsilon) \\mathcal R_k")#text(" (i.e. making ")#mi("R")#text(" dependent on ")#mi("\\epsilon")#text(" for any ")#mi("1+\\epsilon")#text(" in ")#mi("[1,  1/\\theta]")#text("), the vanishing marginals condition is automatically satisfied with the same conclusion (not necessarily optimistic) as above on the possible reduction of unconditional ")#mi("k")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263145")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2014")])]

#text("Eytan: isn’t there still also the constraint that epsilon must not exceed 1/(k-1)?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263157")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2014")])]

#text("This constraint is only needed in the EH case ")#mi("\\theta=1")#text(". In general, one can take advantage of the additional region ")#mi("\\frac{2}{\\theta} \\cdot {\\cal R}_k")#text(" at the end of (4), which makes the polytope ")#mi("R = \\{ (t_1,\\dots,t_k) \\in [0,1/\\theta)^k: t_1+\\dots+t_k \\leq 1+\\varepsilon \\}")#text(" admissible for any ")#mi("\\varepsilon \\leq \\max( \\frac{1}{k-1}, \\frac{1}{\\theta}-1 )")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263161")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2014")])]

#text("According to theorem 1 above, it is only restricted to be in ")#mi("[0, 1)")#text(" (the earlier restriction to ")#mi("[0, 1/(k-1)]")#text(" is for the truncated simplex – the last example above – in order to satisfy the vanishing marginals condition for that particular choice of ")#mi("R")#text(".)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263567")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("Perhaps an explicit lower bound on ")#mi("M_{k, \\epsilon}")#text(" may be derived from this upper bound (as done for the ")#mi("M_k")#text(" case). Such a bound may be used to improve the current values of ")#mi("H_m")#text(" for ")#mi("m \\ge 2")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263718")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("If the optimal ")#mi("\\epsilon")#text(" is (for large k) proportional to ")#mi("\\frac{1}{k \\log k}")#text(" for ")#mi("\\theta = 1/2")#text(", then the additive gain of the upper bound on ")#mi("M_{k,  \\epsilon, 1/2}")#text(" is upper bounded by about ")#mi("\\log 2")#text(" – implying reduction of the unconditional current ")#mi("k=54")#text(" by a factor of about ")#mi("2")#text(" at most.")#linebreak()#text(" (This gain due to the ")#mi("\\epsilon")#text(" flexibility, is still without using the vanishing marginals flexibility,)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262966")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2014")])]

#text("The definition of ")#mi("\\mathcal R_k")#text(" above should be for a closed simplex.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263162")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2014")])]

#text("I’ve been somewhat inconsistent on this. For the purposes of optimising M_k etc., it does not matter whether the simplex is closed or open; but for some of the compactness arguments in the previous post, it is convenient to assume that the function F is compactly supported inside the open simplex (i.e. it vanishes near the boundary of the simplex). Of course, even if F doesn’t vanish at the simplex, one can perturb it infinitesimally to vanish near the simplex (and to make it smooth) without significantly affecting the Rayleigh quotient, so this is only a minor technicality.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263174")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2014")])]

#text("I made this comment because in the page on the variational problem, ")#mi("{\\cal R}_k")#text(" was defined as the closed simplex. Moreover, since ")#mi("F")#text(" is needed only to be in ")#mi("L^2(R)")#text(", its vanishing on the boundary is not really needed.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263186")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2014")])]

#text("Following Aubrey’s recommendation, I computed the bounds we get using the simplex ")#mi("\\mathcal{R}_{3,\\varepsilon}^{\\prime}:=\\{(x,y,z)\\in [0,1]^3\\ :\\ x+y,y+z,x+z\\leq 1+\\varepsilon;\\ x+y+z\\leq 3/2\\}")#text(" where no marginal conditions need to be considered. Using degree 11 polynomials and taking ")#mi("\\varepsilon=18/100")#text(", we get ")#mi("M_{3,0.18,1}^{\\prime}\\geq 1.9527")#text(". To make the obvious comparison, taking degree 11 we have ")#mi("M_{3}^{\\prime}\\geq 1.8429")#text(" without playing the epsilon trick. This is still a very good increase, although not nearly as nice as when we were considering the gain that the epsilon trick gave over the original simplex ")#mi("\\mathcal{R}_{3}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263188")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2014")])]

#text("Many thanks Pace. Is that the best epsilon, though? – previously for R you used 0.18 for k=4 but 0.243 for k=3. Is it just coincidence that the best value for R’_3 is the same as for R_4 ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263190")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2014")])]

#text("It is approximately the best value of ")#mi("\\varepsilon")#text(" for the new simplex ")#mi("\\mathcal{R}_{3,\\varepsilon}^{\\prime}")#text(". (The closeness of the two epsilon values is accidental I think.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263191")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2014")])]

#text("Since this polytope is contained in ")#mi("(3/2) \\mathcal R_3")#text(", it seems better (and seemingly easier) to take the enlarged simplex ")#mi("R = (1+\\epsilon) \\mathcal R_3")#text(" and optimize over ")#mi("\\epsilon \\in [0, 3/2)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263196")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2014")])]

#text("Optimizing over ")#mi("R=(1+\\varepsilon)\\mathcal{R}_3")#text(" is indeed easier (and this was the computation I did previously for ")#mi("M_{3,\\varepsilon,1}")#text("), but it is not better. Indeed, it is exactly because the new computation is harder that we get better results. The new simplex contains ")#mi("R")#text(" for any fixed ")#mi("\\varepsilon")#text(" and thus yields better numerics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263213")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2014")])]

#text("I can see now that the three constraints are added especially to get rid of the vanishing marginals condition! Can you please give some data (as function of the maximal degree) of ")#mi("M^{\\prime}_{3, \\epsilon}")#text(" (for optimized ")#mi("\\epsilon")#text(") ? (it may help estimating its limit.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263217")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2014")])]

#text("It would also be interesting to know whether the optimal epsilon varies with the maximal degree.")

#text("Additionally, in Terry’s original description of the epsilon idea there were k distinct epsilons, but so far all computations have assumed just one. Might it be worth playing around a bit with (for example) making all but one of the epsilons zero, bearing in mind Terry’s observation about M”_3 collapsing to M”_2 ?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263237")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2014")])]

#text("There is no reason for the optimal epsilon to remain fixed. For unsymmetrical regions ")#mi("R")#text(" it seems that several epsilons should give better results.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263197")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2014")])]

#text("I should also point out that ")#mi("\\varepsilon\\in [0,1/2)")#text(" not ")#mi("[0,3/2)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263210")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2014")])]

#text("Thanks for the correction! (in addition, the simplex ")#mi("(1+\\epsilon) \\mathcal R_3")#text(" should be truncated by the unit cube).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263474")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("I’m recording a Fourier-analytic way to think about the “epsilon” trick allowing us to push the support of F out to ")#mi("1+\\varepsilon")#text(" times the simplex, at the cost of only getting a lower bound coming from ")#mi("1-\\varepsilon")#text(" times the simplex.")

#text("For simplicity I’ll deal with “denominator” sums ")#mi("\\sum_n \\nu(n)")#text(" rather than “numerator” sums ")#mi("\\nu_n \\nu(n) 1_{n+h_i \\text{ prime}}")#text(", even though it is the latter for which the epsilon trick is actually useful for our application. (This gives us an additional factor of ")#mi("1/\\theta")#text(" to play with, because 1 has better distribution properties than the von Mangoldt function. As mentioned previously, the Selberg sieve ")#mi("\\nu")#text(" can be written Fourier-analytically as")

#mi("(\\sum_{d_1,\\dots,d_k} \\lambda_{d_1,\\dots,d_k} c_{d_1}(n+h_1) \\dots c_{d_k}(n+d_k))^2")

#text("for some coefficients ")#mi("\\lambda_{d_1,\\dots,d_k}")#text(", where ")#mi("c_q(n) := \\sum_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} e_q(an)")#text(" is a Ramanujan sum. From a Fourier perspective, ")#mi("c_q")#text(" is supported on the fractions ")#mi("a/q")#text(" with ")#mi("(a,q)=1")#text(", so each summand ")#mi("\\lambda_{d_1,\\dots,d_k} c_{d_1}(n+h_1) \\dots c_{d_k}(n+d_k))^2")#text(" is supported in those reduced fractions with denominator ")#mi("d_1 \\dots d_k")#text(".")

#text("In the baseline approach, we require ")#mi("F")#text(" to be supported in ")#mi("\\frac{1}{\\theta} \\cdot {\\cal R}_k")#text(", which makes ")#mi("d_1 \\dots d_k")#text(" less than ")#mi("\\sqrt{x}")#text(". As such, different reduced fractions with different denominators ")#mi("d_1 \\dots d_k")#text(" are separated by at least ")#mi("1/x")#text(", which allows for the Plancherel theorem (or the large sieve inequality) to get good L^2 control on the sum of the ")#mi("\\lambda_{d_1,\\dots,d_k} c_{d_1}(n+h_1) \\dots c_{d_k}(n+d_k)")#text(", i.e. to control ")#mi("\\sum_n \\nu(n)")#text(". (This connection between the Selberg sieve and the large sieve is well known, see e.g. the recent book by Friedlander and Iwaniec.)")

#text("Now suppose we enlarge the support of ")#mi("F")#text(" to ")#mi("(1+\\varepsilon) \\frac{1}{\\theta} \\cdot {\\cal R}_k")#text(", then the products ")#mi("d_1 \\dots d_k")#text(" can now be as large as ")#mi("\\sqrt{x}^{1+\\varepsilon}")#text(". This means that two different fractions ")#mi("a/q, a^{\\prime}/q^{\\prime}")#text(" can be as close as ")#mi("\\frac{1}{x^{1+\\varepsilon}}")#text(", which is bad for the large sieve inequality. However, observe that if one of the fractions, say a/q, has denominator less than ")#mi("\\sqrt{x}^{1-\\varepsilon}")#text(", then it still stays a distance at least ")#mi("1/x")#text(" from the other fractions in this Farey sequence. (Incidentally, this inhomogeneity in the Farey sequence is a crucial ingredient in the Montgomery-Vaughan large sieve inequalities that appeared tangentially in Polymath8a.) Because of this, if one focuses on just the “major arc” contributions to the L^2 norm that come from the neighbourhood of fractions of denominator at most ")#mi("\\sqrt{x}^{1-\\varepsilon}")#text(", the large sieve inequality still works efficiently and gives a lower bound on the full L^2 norm that comes from square-integrating F on ")#mi("(1-\\varepsilon)\\cdot{\\cal R}_k")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263489")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("Does it means that ")#mi("F")#text(" can be supported on")#linebreak()#text(" ")#mi("R = \\frac{1+\\epsilon}{\\theta} \\mathcal R_k")#text(" without satisfying the inclusion condition (4)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263494")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("Unfortunately, this argument only gives lower bounds rather than upper bounds, which makes it suitable for bounding the numerator of (1), but not the denominator. I have been trying to see if one can also get good upper bounds in the regime ")#mi("R = \\frac{1+\\varepsilon}{\\theta} {\\cal R}_k")#text(" but it looks very difficult, one has to somehow extract subtle cancellations from the minor arcs. For k=2 it may be that automorphic methods can do something, but for k>2 it looks very daunting.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263500")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("There is a cheap scaling trick to convert any good cutoff function F for the M_k problem to a cutoff for the ")#mi("M_{k,\\varepsilon}")#text(", just by scaling it by ")#mi("1+\\varepsilon")#text(". The upshot is that")

#mi("\\displaystyle M_{k,\\varepsilon} \\geq k (1+\\varepsilon) \\frac{ \\int_{t_1+\\dots+t_{k-1} < \\frac{1-\\varepsilon}{1+\\varepsilon}} (\\int F\\ dt_k)^2}{\\int_{{\\cal R}_k} F^2}")

#text("for any symmetric F supported on the original simplex ")#mi("{\\cal R}_k")#text(". It seems that one should be able to compute the integral ")#mi("\\int_{t_1+\\dots +t_{k-1} < r} (\\int F\\ dt_k)^2")#text(" as a polynomial function of r without much difficulty for a given polynomial F, so that one can the numerically optimise ")#mi("(1+\\varepsilon) \\int_{t_1+\\dots+t_{k-1} < \\frac{1-\\varepsilon}{1+\\varepsilon}} (\\int F\\ dt_k)^2")#text(" in ")#mi("\\varepsilon")#text(" for a given F. So one could optimise for M_k to find a good candidate F, and then apply this procedure to see if one gets any additional improvement in epsilon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263511")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("A possible difficulty is that for the ")#mi("M_{k, \\epsilon}")#text(" problem, ")#mi("F")#text(" is supported on a truncated simplex (so the marginals are, in general, only piecewise polynomials.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263512")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("Oops, this is indeed an issue, if one is dealing with (the more interesting quantity) ")#mi("M_{k,\\varepsilon,1}")#text(" rather than ")#mi("M_{k,\\varepsilon}")#text(". One can fix it by truncating F to ")#mi("[0,\\frac{1}{1+\\varepsilon}]")#text(", but this makes the denominator and numerator significantly more complicated, unfortunately.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263520")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("Well… is ")#mi("\\theta=1")#text(" really “more interesting” any more? Arguably, the only outstanding question in the ")#mi("\\theta=1")#text(" setting is whether ")#mi("M^{\\prime\\prime}_{3,\\varepsilon,1}")#text(" can surpass 2, and after Pace’s recent result for ")#mi("M^{\\prime}_{3,\\varepsilon,1}")#text(" it’s looking awfully likely that it will, even without any additional ideas. (I guess there is also the question of whether k can be reduced to 4 or 3 without having to resort to GEH rather than EH, but I’m not sure that any of the current directions are leading that way anyway.) Accordingly I would argue that we have now come to a point where the unconditional setting is more of a focus than the [G]EH setting – especially since the k predicted to be achievable from current ideas in the unconditional setting seems to be in the teens or twenties, which may be approaching the regime in which the computational methods currently being applied to k=3 or 4 are conceivably applicable. Thus, the obvious question arises: can this new trick work for M”_k, or is it limited to M_k ? If it can work for M”_k, it seems that it could be a great short-cut to determining good values for ")#mi("M^{\\prime\\prime}_{k,\\varepsilon,1/2}")#text(" for low two-digit k.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263557")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("Fair enough. As a first data point, I applied the above rescaling to the k=2 explicit optimiser for M_2, to get a lower bound of 1.690608 for ")#mi("M_{2,\\varepsilon,1/2}")#text(" with ")#mi("\\varepsilon=0.36")#text(".")

#raw("\nM2 := evalf(1/(1-LambertW(exp(-1))));\nf := 1/(M2 - 1+ x) + log( (M2-x)/(M2-1+x) ) / (2*M2 - 1);\ndenominator := evalf(int( f^2, x=0..1));\nnumerator := M2 * (1+eps) * int( f^2, x=0..(1-eps)/(1+eps) );\nratio := numerator/denominator;\nevalf(subs(eps=0.36,ratio));\n")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263560")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("Nice!")

#text("Many thanks also for the new columns in the Selberg wiki page table (which is getting a bit wide; maybe it could be reformatted to show upper bounds below the corresponding lower bounds, rather than beside them?).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263561")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("Conjecture: the best epsilon for M_k is 0.72/k, and the best for M’_k is 0.72/(k+1). I have no prediction in relation to M” !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263601")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("I should have noted that this conjectured relation is independent of theta. Perhaps four data points (namely [k.theta] = [3,1], [4,1], [2,1/2] for M and [3,1] for M’) is too few to make such a stretch, but, well, maybe not :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263617")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("Some back of the envelope calculations suggest that asymptotically the best value of epsilon is proportional to ")#mi("\\frac{1}{k \\log k}")#text(", basically because if one considers the truncated tensor product functions F that show up in the asymptotic analysis, then they are concentrated at a distance about ")#mi("\\frac{1}{k \\log k}")#text(" from the boundary of the simplex (this is the quantity ")#mi("1-k\\mu")#text(" in the asymptotic analysis, and is also comparable to ")#mi("\\sqrt{k\\sigma^2}")#text("), and so it becomes highly counterproductive to shrink the simplex beyond that distance. So unfortunately, one does not get to significantly improve the current bound ")#mi("M_k = \\frac{k}{k-1} \\log k - O(1)")#text(" with the epsilon trick in the large k regime (indeed, this calculation suggests that the value of k only improves by an unimpressive O(1) for a fixed value of m).")

#text("I also see now why there is ")#emph[#text("some")]#text(" gain to be had by increasing epsilon away from zero, even if this gain decays fairly rapidly in k; the marginal function ")#mi("\\int F\\ dt_k")#text(" vanishes to first order as one approaches the boundary of the simplex ")#mi("{\\cal R}_{k-1}")#text(", simply because the length of interval ")#mi("[0, 1-t_1-\\dots-t_{k-1}]")#text(" that one is integrating on shrinks to zero. (I am implicitly assuming here that F is bounded, but from Cauchy-Schwarz one can see a similar vanishing in an L^2 sense if F is just assumed to be square-integrable.) Because of this, the cost of retracting the ")#mi("J_k(F)")#text(" integrals by an epsilon is only cubic in epsilon (if F is bounded, or slightly better than linear if F is just assumed square-integrable). So the gain coming from dilating by ")#mi("1+\\varepsilon")#text(" outweighs the loss in shrinking the simplex by ")#mi("\\frac{1-\\varepsilon}{1+\\varepsilon}")#text(" if ")#mi("\\varepsilon")#text(" is small enough.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263626")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("Does this take account of the differences between M, M’, M” ? I notice that k+1/k – namely, the ratio between the only so-far-computed pair of best epsilons for M_k and M’_k for the same theta – is precisely the ratio of volume between R’_k and R_k for that k (namely k=3). Going out on a major limb I’m predicting on this basis that the best epsilon for M”_k (with theta=1/2, and with R being the dilated simplex with edge 2) will be ")#mi("0.72/(2^{k-1})")#text(". I’m not clear as to what is entailed in determining the optimal epsilon in a given context – maybe it is easy enough that a prediction is not useful – but I’m putting it out there in case it is.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263628")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("Bah – apologies – I obviously misstated those volumes. The prediction of the best epsilon for ")#mi("M^{\\prime\\prime}_{k,\\varepsilon,1/2}")#text(" based on volume of R and extrapolating from M and M’ should be ")#mi("0.72/(k*(2^k))")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263799")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("Actually, a little more thought results in the much more optimistic suspicion that the best epsilon for ")#mi("M^{\\prime\\prime}_{k,\\varepsilon,1/2}")#text(" (with R’’ being the dilated simplex of edge 2) converges to half that of ")#mi("M_{k,\\varepsilon,1/2}")#text(" as k increases – in other words, to 0.36/k based on existing data points (though I certainly don’t exclude the possibility that there is a ")#mi("\\log k")#text(" factor as Terry suggests). This is based on realising that the ratio of volumes ")#mi("R^{\\prime}_k/R_k")#text(" is actually ")#mi("k/(k-1)")#text(", not ")#mi("(k+1)/k")#text(", and running with the same idea as above.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263533")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("I think that there is a possibility that the optimal ")#mi("F")#text(" for ")#mi("M_{k, \\epsilon}")#text(" (or any other truncated simplex on which ")#mi("F")#text(" is supported) or its marginals can be non-smooth (or even discontinuous) on certain hyperplanes (determined by the truncating constraints) which may result by slow convergence of ")#mi("L^2")#text("– polynomial approximation to the optimal ")#mi("F")#text(".")#linebreak()#text(" A possible fix is to use piecewise polynomial approximation to the optimal ")#mi("F")#text(" (where the polytope partition for the piecewise polynomial approximation is determined so that ")#mi("F")#text(" and its marginals should be polynomials on each predetermined subdomain.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263545")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")])]

#text("The above suggestion for piecewise polynomial approximation was given only to solve a possible problem of slow convergence (wrt polynomial degree) of ")#mi("M_{k, \\epsilon}")#text(" due to possible non-smoothness of the optimal ")#mi("F")#text(".")#linebreak()#text(" This is without vanishing marginal constraints (which obviously may added as needed.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263826")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("In the wiki page on the variational problem, ")#mi("M^{\\prime}_{k, \\epsilon \\theta}")#text(" and ")#mi("M^{\\prime\\prime}_{k, \\epsilon, \\theta}")#text(" should also be defined.")

#emph[#text("[Done – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263839")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("It seems that ")#mi("M^{\\prime}_{3, 0.18 ,1}")#text(" as computed by Pace is for ")#mi("F")#text(" supported on a somewhat larger domain (i.e. ")#mi("\\mathcal R^{\\prime}_{3, \\epsilon}")#text(") than the one appearing in the wiki page.")

#emph[#text("[Smaller, actually; there was an additional restriction to ")#mi("\\frac{k}{k-1} \\cdot {\\cal R}_k")#text(" which I forgot to put on the wiki, but is now there (though for ")#mi("\\varepsilon \\leq 1/(k-1)")#text(" it has no effect). -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263854")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("In this definition, is it possible to relax the factor ")#mi("\\frac{k}{k-1}")#text(" to the maximal ")#mi("\\epsilon")#text(" (i.e. ")#mi("\\max (\\frac{k}{k-1}, 1/\\theta)")#text(")?")

#emph[#text("[Yes; I’ve adjusted the definition of ")#mi("M^{\\prime}_{k,\\varepsilon,\\theta}")#text(" accordingly. -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263864")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("Typographical comment: For “GEH”, “MPZ”, ect., the letters should be upright. In math mode this means typing it as, say “")#mi("\\mathrm{GEH}")#text("”.")

#text("P.S. This project is really interesting to follow as a non-mathematician.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263901")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("I’m nearly ready to write the code to compute the M_3 value over the half-cube cut out by the plane ")#mi("x+y+z\\leq 3/2")#text(". I’ve created a file with some pretty pictures which helped me write down the necessary components of the calculation. The basic picture came from Terry’s decomposition that he found using his son’s toys. (I need to get my own sons similar toys!) You can find the file at: ")#link("http://www.math.byu.edu/~pace/HalfCube.pdf")[#text("http://www.math.byu.edu/~pace/HalfCube.pdf")]

#text("I wanted to make this available so as to get a double-check on all of the integral formulas. (I’m also planning to double-check these decompositions tonight. I keep finding minor errors, so there is no guarantee it is correct yet.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263924")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("Nice pictures! I’ll double-check the computations later today. One simple checksum is to make sure that I(1) is equal to 1/2, and more generally that I(F) is independent of epsilon if F is a polynomial independent of epsilon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263925")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("First error I found:")

#text("The second marginal condition should instead read:")

#mi("\\int_{z=0}^{1+\\varepsilon-x}F_{C_{xyz}}(x,y,z) + \\int_{z=1+\\varepsilon-x}^{3/2-x-y}F_{A_x}(x,y,z)\\ dz")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263928")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("Silly error: in the I-integral section I left some squares off integrands.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263969")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("Everything else seems to check out – it’s remarkably complicated, though!")

#text("This partition should technically exhaust a dense class of F when the degree is large enough, but convergence may be slow. One reason to suspect this is that variational arguments (using Lagrange multipliers) tell us that the optimal F should be of the form ")#mi("F(x,y,z) = G(x,y) + G(y,z) + G(z,x)")#text(" where ")#mi("G")#text(" is supported on the weirdly disconnected region ")#mi("\\{ (x,y): x+y \\leq 1-\\varepsilon \\} \\cup \\{ (x,y) \\in [0,1]^2: 1+\\varepsilon \\leq x+y \\leq 3/2 \\}")#text(". This suggests jump discontinuities when ")#mi("x+y, y+z, z+x=1 \\pm \\varepsilon")#text(". The discontinuities associated to ")#mi("1+\\varepsilon")#text(" are already accounted for by the partition, but the discontinuities associated to ")#mi("1-\\varepsilon")#text(" are not, which does not bode well for polynomial approximation.")

#text("On the other hand, we only need to scrape together a gain of less than 0.05, so we may not need further subdivision. If that becomes necessary, it may be worthwhile to collapse to a (messy) two-dimensional problem, and write everything in terms of G instead of F. One side benefit of this is that the domain partitioning will be easier to visualise.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263973")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("I think that such slow convergence must be sublinear (e.g. like a negative power of the maximal degree). Fortunately, we don’t need to get very close to the limit (unless it is very close to 2.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264127")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("3D Jump discontinuity on a plane may lead to an even slower convergence than jump discontinuity at a point in the 1D case. (e.g. the M-value approximation error may decay as a negative fractional power of the polynomial degree !)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263920")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("Pace: Nice picture! I have two questions:")#linebreak()#text(" 1. Do you intend to compute ")#mi("M^{\\prime\\prime}_3, \\epsilon ,1")#text(" (not ")#mi("M_3")#text(")?")#linebreak()#text(" 2. Why do you take ")#mi("\\epsilon")#text(" in ")#mi("[0, 1/6]")#text(" (instead of ")#mi("[0, 1/2]")#text(")?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263923")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("1. I intend to compute the M value we get using ")#mi("\\theta=1")#text(", using the epsilon expansion trick, on the stated half-cube. I don’t know if ")#mi("M_{3,\\varepsilon,1}^{\\prime\\prime}")#text(" is the correct notation or not.")

#text("2. The decomposition in the file slightly changes in the regime ")#mi("\\varepsilon \\in [1/6,1/2]")#text(". If we need a larger ")#mi("\\varepsilon")#text(", I can work out the change in decomposition, but I doubt that we will need to do this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263930")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("The definition of ")#mi("M^{\\prime\\prime}_{k, \\epsilon, \\theta}")#text(" (including the range of ")#mi("\\epsilon")#text(" is in the wiki page on the variational problem (by now we have many types of M values!)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263937")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("It seems that the optimal polynomials on the various polytope pieces are not necessarily symmetric (I don’t see any reason for that), so by removing (if needed) the (simplifying) symmetric polynomial constraint, we have the potential to make further improvement to the M-value.")#linebreak()#text(" Note also that the optimal ")#mi("\\epsilon")#text(" should increase because of the added flexibility from vanishing marginals (implying another improvement by increasing the range of ")#mi("\\epsilon")#text(" to ")#mi("[0, 1/2]")#text(" if needed.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263962")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2014")])]

#text("All of the symmetry follows by an averaging argument (see, for example, the argument given on page 17 of Maynard’s preprint).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264113")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("I agree that the symmetry follows from this argument (also with the presence of the additional constraints) and that the optimal ")#mi("F")#text(" can be represented as a symmetrical sum of functions of two variables.")#linebreak()#text(" Note, however, that all such conclusions are dependent on the (seemingly plausible, yet unproved!) existence of an optimal solution in L^2 for the (constrained) variational problem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264170")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("Actually I found an argument that shows that symmetric functions suffice even without the existence of an extremiser. Let’s work in the original simplex for simplicity, thus ")#mi("M_k")#text(" is the supremum of ")#mi("\\sum_{m=1}^k J_k^{(m)}(F) / I_k(F)")#text(" for non-trivial F. In particular, the quadratic form")

#mi("F \\mapsto M_k I_k(F) -\\sum_{m=1}^k J_k^{(m)}(F)")

#text("is positive semi-definite, and is thus associated to a positive semi-definite inner product and norm. If ")#mi("F_n")#text(" is an extremising sequence for ")#mi("M_k")#text(", normalised so that ")#mi("I_k(F_n)=1")#text(", then ")#mi("F_n")#text(" goes to zero in this semi-definite norm, as does any reflection of ")#mi("F_n")#text(" caused by permuting the coordinates. Also note that by replacing ")#mi("F_n")#text(" with ")#tao-math("\\left|F_n\\right|", block: false)#text(" if necessary, one can take ")#mi("F_n")#text(" to be non-negative. Applying the triangle inequality for semi-definite inner products, we conclude that the symmetrisation of ")#mi("F_n")#text(" also goes to zero, while staying bounded away from zero in L^2 by non-negativity. So the symmetrisations are also an extremising sequence, and so it suffices to extremise over symmetric functions.")

#text("The situation is a little trickier with vanishing marginals because we can’t force non-negativity, but I think the argument shows that the only competitor to a symmetric extremising sequence would be an antisymmetric extremising sequence (corresponding to some other irreducible representation of the permutation group) which looks very unlikely, but I don’t see how to formally exclude it.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264177")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("Nice argument ! (obviously it depends on the symmetry of the domain and the constraints).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264254")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("It should also be remarked that the supremum ")#mi("M_k")#text(" is not attained (which is the interesting case!) If and only if the above quadratic form is positive definite.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264204")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("Calculus of variations (and Lagrange multipliers) tell us that any symmetric extremiser F to a three-dimensional problem such as M_3, M’_3, M”_3, ")#mi("M^{\\prime\\prime}_{3,\\varepsilon,1}")#text(", etc. must have the form ")#mi("F(x,y,z) =G(x,y) + G(y,z) + G(z,x)")#text(". In terms of polynomials, this means that the only monomials ")#mi("x^a y^b z^c")#text(" one expects F to have are those in which at least one of a,b,c is zero. So for degree D, the number of monomials in play should be O(D^2) rather than O(D^3), which may end up being a significant speed boost that allows us to explore higher degrees (at the cost of some accuracy, because if one caps the degree there might be a little bit of need to use the monomials that don’t show up in the true extremiser).")

#text("It might be worth testing the idea of restricting to monomials of just two of the three variables in the M_3 and M’_3 problems (and maybe M”_3, if the code is already available for easy modification) to see if any significant improvements in performance are obtained by doing this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264211")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("Great idea! Does this type of argument also work for larger k? If so, it could be a big help in finding the k for which ")#mi("M^{\\prime\\prime}_{k,\\varepsilon,1/2}")#text(" reaches 4, even if it turns out not to be needed to make ")#mi("M^{\\prime\\prime}_{3,\\varepsilon,1}")#text(" reach 2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264233")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("I also think that this is a good idea to select only monomials with the right properties. Moreover (following your previous suggestion) is it possible to iterate this idea (by inserting the new structured solution in Euler-Lagrange equation) to infer a greater structure for the solution (and consequently a smaller class of allowed monomials)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264256")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("James and I discussed this a bit in the first Polymath thread. Unfortunately things get very messy and there isn’t an obvious dimensional reduction.")

#text("Let’s work on the M_3 problem for simplicity, so one is looking at the eigenfunction equation")

#mi("M_3 F(x,y,z) = G(x,y) + G(y,z) + G(z,x)")#text(" (1)")

#text("where")

#mi("G(x,y) = \\int_0^{1-x-y} F(x,y,z)\\ dz")#text(" (2)")

#text("is the marginal distribution. This writes the three-variable function F in terms of the two-variable function G. If we substitute in this ansatz into (2), we get")

#mi("M_3 G(x,y) = (1-x-y) G(x,y) + \\int_0^{1-x-y} G(y,z)\\ dz + \\int_0^{1-x-y} G(z,x)\\ dz")

#text("but this doesn’t seem to allow one to easily express G in terms of one-variable functions.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264206")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("Pace, let me add my praise for this awesome document.")

#text("Speaking of symmetry of F, am I right in saying that it is still open whether a symmetric R” is optimal? I’m presuming that you went with the truncated simplex rather than the prism because the simplifications afforded by symmetry outweigh the need to use 13 components rather than 7, but if the truncated simplex fails to make it to M”=2 then maybe it’s worth also looking at the prism? Or is there another reason not to – for example, does the seven-component dissection of the prism no longer work when epsilon is introdced?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264210")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("Well, once Pace’s code is running one can test the epsilon=0 case and see whether M”_3 for the symmetric polytope is any better or worse than M”_3 for the prism (which James computed to be about 1.914); this may give some indication of whether it is better to switch to the prism. (In that case, it may also make sense to have at least two independent epsilons rather than one, given the reduced symmetry of the prism.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264217")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("Right. Indeed, if it’s different (either better or worse), and if this isn’t all rendered moot by success with the truncated simplex, there’s probably a case for exploring other half-cubes so as to ensure that the optimal one is being used. I guess the obvious third one that is “as different as possible” from either the prism or the truncated simplex would be the one bounded by the plane x+y+2z = 2.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264262")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("It took a while, but I got the code working. Contrary to my hopes, the symmetric half-cube apparently gives worse numerics than the prism. For ")#mi("\\varepsilon =0")#text(" and taking all polynomial pieces of degree 4, we only get ")#mi("M_{3,0,1}^{\\prime\\prime}\\geq 1.902626")#text(".")

#text("The calculation gets slow very quickly as the total degree increases. For example, with degree 5 it takes 35 minutes to show ")#mi("M_{3,1/6,1}^{\\prime\\prime}\\geq 1.9562")#text(". It appears that the optimal epsilon is close to 1/6. So we could probably get better numbers going a little past this epsilon, using a slightly different decomposition. However, since the values we are getting are so far away from 2 (indeed, they are barely better than the bounds for ")#mi("M_{3,\\varepsilon,1}^{\\prime}")#text(") I don’t think it is worth the effort. We probably want to focus on a different polytope.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264268")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("Well, that’s a bit disappointing, but I guess we just have to roll with it.")

#text("So the next thing to try would be the prism. Here, F would be supported on ")#mi("\\{ (x,y,z): x+y \\leq 1; z \\leq 1 \\}")#text(" with marginal ")#mi("\\int F(x,y,z)\\ dy")#text(" supported on ")#mi("x+z \\leq 1+\\varepsilon_2")#text(" and ")#mi("\\int F(x,y,z)\\ dz")#text(" supported on ")#mi("y+z \\leq 1+\\varepsilon_1")#text(" for some ")#mi("0 \\leq \\varepsilon_1, \\varepsilon_2 \\leq 1")#text(". (There is no point enlarging the simplex for the third marginal ")#mi("\\int F(x,y,z)\\ dz")#text(" since it is already constrained to ")#mi("x+y \\leq 1")#text(".) Our task is now to maximise the ratio")

#mi("\\displaystyle (\\int_{y+z \\leq 1-\\varepsilon_1} (\\int F\\ dx)^2\\ dy dz + \\int_{x+z \\leq 1-\\varepsilon_2} (\\int F\\ dy)^2\\ dx dz")

#mi("\\displaystyle  + \\int_{x+y \\leq 1} (\\int F\\ dz)^2\\ dx dy) / \\int F^2\\ dx dy dz.")

#text("One nice thing here is that in the limit ")#mi("\\varepsilon_1 = 0")#text(", ")#mi("\\varepsilon_2 \\to 1")#text(", the ratio approaches 2, as can be seen by taking F to be the indicator function of the box ")#mi("[0,\\varepsilon_2] \\times [0, 1-\\varepsilon_2] \\times [0,\\varepsilon_2]")#text(". So we are guaranteed to hit at least 2, and we only need an epsilon more than this! (But it’s not that simple; I think this limit is a local maximum, and we need a separate local maximum to beat this local maximum. Still, it’s a good sign…)")

#text("Actually, a simpler intermediate thing to calculate would be ")#mi("M^{\\prime}_{3,\\varepsilon_1,\\varepsilon_2,0,1}")#text(", in which F is supported in ")#mi("\\{ (x,y,z) \\in [0,1]^3: y+z \\leq 1+\\varepsilon_1, x+z \\leq 1+\\varepsilon_2, x+y \\leq 1\\}")#text(" but the numerator is as before. This is also guaranteed to be at least 2 by the same example as above.")

#text("Note that we’ve broken all the symmetry here, and so will have to work with all the monomials, which may cost us a bit performancewise. On the other hand, the number of polytopes involved in the decomposition may be a bit smaller than in the symmetric case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264275")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("I’ll do this next. Might be in a day or two, given that I have to write my lecture for tomorrow, etc…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264273")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("Sped up the code a bit. With degree 6, we get ")#mi("M_{3,1/6,1}^{\\prime\\prime}\\geq 1.95744")#text(", and it takes about 10 minutes.")

#text("Given the recent comments, I also looked at what happens when restricting to monomials where only two variables occur. It appears that there is very little loss. For instance, doing degree 6 with this restriction we get ")#mi("M_{3,1/6,1}^{\\prime\\prime}\\geq 1.95743")#text(", and it takes about 3 minutes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264286")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("The very small improvement from degree 5 to degree 6 suggests that either")

#text("1. Even for these small degrees, the lower bound is very close to the limit.")

#text("or")

#text("2. The convergence is very slow (e.g. sub-linear) because of possible discontinuities of the optimal ")#mi("F")#text(" (or some of its small order derivatives) on certain planes.")

#text("It seems to me that the second possibility is the right one (so the limit can be larger than 2 but one needs a very large degree to come close to it!), but of course, given the M-values as a function of the degree, it is not difficult to verify the convergence type (i.e. linear with some stable rate, or sub-linear).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264299")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("If it is helpful at all, I get 1.95866 for degree 7 and 1.958774 for degree 8 (using the restriction I mentioned to monomials with only two variables). That is as far as I plan to compute on this simplex.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264311")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("Assuming linear convergence, the last two estimated rates (using the divided differences method) are about 0.98 and 0.093 (far from being stable!) which seems to rule out the linear convergence type, indicating that we have the problem of sub-linear convergence! (probably due to discontinuities of the optimal ")#mi("F")#text("). A possible fix (as previously remarked) is to refine the polytope decomposition such that the discontinuities should appear only on the boundaries of the polytopes (this may be simplified to polygonal partition by using the two variables representation of ")#mi("F")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264314")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("Well, but the difference between d=5 and 6 is almost the same as between d=6 and 7… I’m not optimistic. (Degree 8 is so much closer to 7 than 7 is to 6 or 6 to 5 that I’m actually tempted to ask whether there’s a typo for d=8 and it should be 1.959774.) What’s worse is that the value for epsilon=0, d=4 is not all that much smaller for the truncated simplex than for the prism, suggesting that the prism won’t get us beyond about 1.97. The main remaining sliver of hope seems to be that allowing two epsilons would improve things, but it’s looking pretty forlorn to me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264318")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2014")])]

#text("It seems that the only way to retain linear convergence (with stable rate) is to identify the potential (planar) sets of discontinuities of the optimal ")#mi("F")#text(" and refine the partition accordingly (to keep all discontinuities on the boundaries of the polytopes).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264474")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("It is important to observe that the very slow convergence of M” lower bounds for degrees ")#mi("d = 5, 6, 7, 8")#text(" with FIXED ")#mi("\\epsilon = 1/6")#text(" still has unstable(!) rate (which is uncharacteristic of sub-linear convergence whose rate should tend to 1) – indicating that these degrees are still in a transitional interval (well below the final stage of convergence with stable rates.)")

#text("In addition to possible discontinuities of the optimal F in the interior of some polytopes, this strange behavior may be explained by")

#text("1. The optimal ")#mi("\\epsilon")#text(" should be optimized for each degree.")

#text("2. More importantly, note that the optimal F can be approximated using a restricted class of monomials of order ")#mi("O(d^2)")#text(" for each degree ")#mi("d")#text(", it means that (effectively) there are only ")#mi("O(d^2)")#text(" degrees of freedom with ")#mi("O(d^2)")#text(" (vanishing marginals) constraints in the optimization program. The number of constraints may be reduced to")#linebreak()#text(" ")#mi("O(d)")#text(" by adapting the constraints to the particular class of ")#mi("O(d^2)")#text(" allowed monomials. It seems (since the number of polytopes is relatively large) that only for sufficiently large degree ")#mi("d")#text(", the remaining effective number of degrees of freedom (i.e. after subtracting the number of constraints) should give a regular (i.e. stable rate) convergence behavior.")

#text("3. Implementation errors.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264516")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("I thought its worth mentioning that (at least on the assumption my code was working as intended) when I looked at the 4-variable prism I also encountered rather erratic convergence. The convergence was good on ")#mi("R^{\\prime}")#text(", but not on the polytopes outside of it with the vanishing conditions. For very small degrees (say 4 or less) the vanishing marginals gave very few degrees of freedom, and so there wasn’t much benefit. Even for higher degree (I think I went up to degree 9) the convergence didn’t seem regular enough to predict what it might be converging to.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264511")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("I performed the computation for ")#mi("M_{3,\\varepsilon_1,\\varepsilon_2,0,1}^{\\prime}")#text(" on the simplex ")#mi("\\{ (x,y,z) \\in [0,1]^3: y+z \\leq 1+\\varepsilon_1, x+z \\leq 1+\\varepsilon_2, x+y \\leq 1\\}")#text(".")

#text("As expected, when ")#mi("\\varepsilon_1=1,\\varepsilon_2=0")#text(" the value is going to 2 pretty quickly. For degrees 1 to 6, we get the values 1.7549, 1.8540, 1.9029, 1.9308, 1.9481, 1.9597.")

#text("For degree 1, to within jumps of 1/100 there is a local maximum when ")#mi("\\varepsilon_1=\\varepsilon_2= 17/100")#text(", which gives the value 1.90704. Similarly for degree 2, the local maximum is when ")#mi("(\\varepsilon_1,\\varepsilon_2)=(17/100,18/100)")#text(" or ")#mi("(18/100,17/100)")#text(". I wasn’t sure if this meant that the local maximum had split in two, or whether my partition was not fine enough. So taking jumps of 1/1000, we get that the local max is at ")#mi("(174/1000,174/1000)")#text(", giving a value of 1.910399.")

#text("By degree 4, this position starts losing ground to the “corner” epsilon values, ")#mi("(1,0),(0,1)")#text(". I’ll keep running the calculations and keep you posted if I notice anything new.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264514")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("I should mention that this computation is in the domain where ")#mi("\\varepsilon_1+\\varepsilon_2\\leq 1")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264529")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("At least we have a slightly better record (even without the vanishing marginals flexibility!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264546")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("Thanks for this, Pace! It’s good to see various intuitions about the epsilon behaviour confirmed, namely the local maxima at (1,0), (0,1) (which, unfortunately, I don’t think we can directly use to try to beat 2), and the competing maxima in which the epsilons are equal and comparable to 1/6. So perhaps for the M” calculation we can focus on the ")#mi("\\varepsilon_1=\\varepsilon_2")#text(" case (abandoning the corners (1,0), (0,1)), which allows one to take symmetric polynomials and thus perhaps speed up the calculations a little bit. (The Lagrange multiplier argument is also still in force, allowing one to restrict attention to monomials with one exponent vanishing.)")

#text("On the other hand, we are starting from ")#mi("M^{\\prime}_{3,\\varepsilon,\\varepsilon,0,1} \\approx 1.910399")#text(" here, which is further back than ")#mi("M^{\\prime}_{3,\\varepsilon,\\varepsilon,\\varepsilon,1} \\approx 1.9527")#text(" that we had in the fully symmetric case. This makes sense – we only have two of the three epsilons in play, so the improvement over ")#mi("M^{\\prime}_3 \\approx 1.8429")#text(" had to be smaller by a third or so, which is indeed the case – but is still a little unnerving; we have to somehow make up for it with the rest of the prism, which we suspect from the M”_k evidence to be a little better than the extra space in the symmetric polytope (1.914 vs 1.902), but will it be enough? From the scant evidence we have so far, it looks like a bit of a long shot, but we should at least get a clearer picture of whether the prism or the symmetric polytope is superior, even if both may end up falling short of the goal. (Frustrating, though, that we only need a 2% improvement in our bounds to get to H_1 <= 6 on GEH!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264569")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("Hm – I think it might be premature to restrict to the single-epsilon case when considering the prism, since it may be that the local maximum for M’ has the epsilons equal only because M’ is symmetric. It’s good, though, that with M’ the local maximum is evident when d=1: since low-degree calculations are fast, maybe any promising local maxima with M” can be identified when d=1 or 2 with both epsilons ranging freely and then explored for higher degree in the context of performance-enhancing pre-set constraints on the epsilons.")

#text("Also, I’m not seeing why the epsilons need to sum to at most 1. Is there a clear reason? If there is, but if it can be determined that violating that constraint would be a win, I guess one potential way forward would be to explore whether Terry’s original concept that introduced epsilon can be enhanced to allow a larger sum-of-epsilons.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264594")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("Here M’ is not symmetric (or, more precisely, it is only symmetric when ")#mi("\\varepsilon_1=\\varepsilon_2")#text(".")

#text("The restriction to the sum being at most 1 was because in the other case we get a different decomposition of the prism. I can do that case as well, and probably will a bit later.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264602")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("Or even more precisely, the polytope on which M’ is computed is not symmetric. Although, it is symmetric in the sense that switching the roles of the epsilons gives the same numerics. Did you have a candidate polytope without this property that you wanted me to try?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264668")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("Well, I was thinking that since the base-case prism (with no epsilons) is asymmetric, the maximum M may involve unequal epsilons whose disparity in some sense “cancels out” the asymmetry of the base case. I’m not seeing that this is nullified by your point about switching the roles of the epsilons. As for other polytopes, I’m not sure – I think I need a better understanding of your reasoning on this point first.")

#text("However, actually I think having the sum-of-epsilons exceed 1 seems by far the most promising option as things stand – there seems no obvious reason (someone please say if there is one) why we would expect (1,0) to give better performance that (1,0.1) for example.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264673")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("The prism ")#mi("\\{ x+y \\leq 1, z \\leq 1 \\}")#text(" has partial symmetry – it is symmetric with respect to swapping x and y, but not with respect to swapping z with either x or y. The x-y symmetry corresponds to swapping ")#mi("\\varepsilon_1")#text(" and ")#mi("\\varepsilon_2")#text(", so we have the symmetry ")#mi("M^{\\prime\\prime}_{3,\\varepsilon_1,\\varepsilon_2,0,1} = M^{\\prime\\prime}_{3,\\varepsilon_2,\\varepsilon_1,0,1}")#text(".")

#text("Also note that ")#mi("M^{\\prime\\prime}_{3,1,\\varepsilon_2,0,1} \\leq 2 = M^{\\prime\\prime}_{3,1,0,0,1}")#text(". Indeed, with ")#mi("\\varepsilon_1=1")#text(", ")#mi("J^{(1)}_{3,\\varepsilon_1}(F)=0")#text(", and so we are now just maximising ")#mi("J^{(2)}_{3,\\varepsilon_2}(F) + J^{(3)}_3(F) / I_3(F)")#text(" subject to ")#mi("\\int F\\ dy")#text(" being supported on ")#mi("x+z \\leq 1+\\varepsilon_2")#text(". At this point, there is no interaction between different ")#mi("x = const")#text(" slices of F, and the problem decouples into two-dimensional ones. Indeed, if we define ")#mi("F_x(y,z) := F(x,y,z)")#text(" to be the slice of ")#mi("F")#text(", then from Fubini’s theorem we have")

#mi("J^{(2)}_{3,\\varepsilon_2}(F) = \\int_0^{1-\\varepsilon_2} J^{(1)}_{2,\\varepsilon_2+x}(F_x)\\ dx")

#mi("J^{(3)}_{3,0}(F) = \\int_0^{1} J^{(2)}_{2,x}(F_x)\\ dx")

#text("and")

#mi("I_3(F) = \\int_0^1 I_2(F_x)\\ dx")

#text("and from Cauchy-Schwarz one has")

#mi("J^{(1)}_{2,\\varepsilon_2+x}(F_x) + J^{(2)}_{2,x}(F_x) \\leq 2 I_2(F_x)")

#text("giving the bound ")#mi("M^{\\prime\\prime}_{3,1,\\varepsilon_2,0,1} \\leq 2")#text(".")

#text("In the number-theoretic setting, when trying to get at least two of n,n+2,n+6 prime, setting ")#mi("\\varepsilon_1=1")#text(" forgoes any chance of forcing n to be prime, so one is left with the k=2 problem of getting n+2,n+6 prime, for which we know we cannot get more than one prime at a time due to the parity problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264879")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2014")])]

#text("Many thanks Terry – that does seem to robustly eliminate the option of a win near the corners. As for the partial symmetry, though, I still don’t see that the swappability of the epsilons tells us for sure that equal epsilons will always be optimal – I think a saddleback situation (where the best equal-epsilons value can be beaten by increasing one epsilon and decreasing the other) is hard to exclude for asymmetric (even if partially symmetric) base case (i.e. epsilon=0) choices of R”.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264615")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("A little more data. For degrees 4, 5, 6, 7, the optimal values in the symmetric case when ")#mi("\\varepsilon_1=\\varepsilon_2")#text(" are (to within 1/1000) 0.183, 0.183, 0.189, 0.184. The corresponding M values are 1.916121, 1.916198, 1.917474, 1.917865. I do not know the reason for the jump when the degree is 6.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264620")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("This is a relatively small jump (both in the epsilons and the M-values), but the convergence rate is still unstable.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264574")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("In the wiki page, the current lower bound for ")#mi("M^{\\prime\\prime}_3")#text("(prism) should be 2 (due to the corners local maxima.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264576")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("Actually, that’s a lower bound for ")#mi("M^{\\prime\\prime}_{3,\\varepsilon_1,\\varepsilon_2,0,1}")#text(" (prism) rather than ")#mi("M^{\\prime\\prime}_3")#text(" (prism), because one has to set one of the epsilons equal to 1 rather than 0.")

#text("When one of the epsilons is really big, say ")#mi("\\varepsilon_1")#text(", then one is getting almost no benefit at all from the corresponding marginal, in this case ")#mi("J_{3,\\varepsilon_1}^{(1)}(F) = \\int_{y+z \\leq 1-\\varepsilon_1} (\\int F\\ dx)^2\\ dy dz")#text(", as it decays quadratically as ")#mi("\\varepsilon_1")#text(" approaches 1. On the other hand, the constraint ")#mi("y+z \\leq 1+\\varepsilon_2")#text(" (for the marginal at least) should also cost something quadratic as compared to ")#mi("y,z \\leq 1")#text(". My feeling is that the cost outweighs the benefit, which seems to be corroborated by Pace’s most recent numerics, and that one should focus on the epsilon values closer to 1/6, which is what we have been seeing in all other analyses.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264577")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("It seems that this lower bound in the wiki page is still without the several epsilons flexibility.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264614")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("For k=2 one can get a lower bound of 2 without epsilons, but I don’t see how to do it for k=3, because when all three marginals are restricted to the simplex ")#mi("{\\cal R}_2")#text(", one cannot create an example that is (an infinitesimally thickened version of) the indicator of the unit square ")#mi("[0,1]^2")#text(", which is the 2D extremiser. One can do this though if two of the three epsilons are set to zero and the third is set to 1.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264896")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2014")])]

#text("I just realised that there is a version of the epsilon trick that can be used to reduce the denominator in our key ratio (1) by an amount that is exponentially small in k – but for our k=3 problem, an exponentially small gain in k is more or less exactly what we need! The idea goes back to the observation of James back in ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251757")[#text("Nov 20")]#text(" that we should be able to subtract off the contribution to ")#mi("\\sum_n \\nu(n)")#text(" when all of the ")#mi("n+h_i")#text(" are composite. On ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261034")[#text("Jan 2")]#text(" I managed to make James’s idea quantitative in the BV case by multiplying ")#mi("\\nu")#text(" by ")#mi("1 - \\sum_{p_1,\\ldots,p_k: p_i|n+h_i; p_1 \\ldots p_k \\leq x^{1/2}} \\frac{\\log p_i}{\\log x}")#text(" (which is a non-negative weight that equals one unless all of the n+h_i are composite), but in order to absorb this new factor I needed the extra room available in the BV case (basically, the ability to stretch the sieve into ")#mi("2 \\cdot {\\cal R}_k")#text(" instead of ")#mi("{\\cal R}_k")#text(").")

#text("However, the epsilon trick (or more precisely, a variant of something that I had tried in ")#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256865")[#text("Dec 14")]#text(" that ended up not working, because I was only enforcing one compositeness condition ")#mi("p_1|n+h_1")#text(" rather than all k compositeness conditions ")#mi("p_i|n+h_i")#text(". Namely, we will work with the sieve")

#mi("\\nu^{\\prime}(n) := \\nu(n) (1 - \\sum_{p_1,\\ldots,p_k: p_i|n+h_i} \\frac{\\log p_i}{\\log 3x})")#linebreak()#text(" ")#mi("+ \\sum_{p_1,\\dots,p_k: p_i|n+h_i} \\frac{\\log p_i}{\\log 3x} \\nu_{p_1,\\dots,p_k}(x)")

#text("where ")#mi("\\nu")#text(" is the usual Selberg sieve")

#mi("\\nu(n) = ( \\sum_{d_i|n+h_i} \\mu(d_1) \\dots \\mu(d_k) f( \\frac{\\log d_1}{\\log R}, \\dots, \\frac{\\log d_k}{\\log R} ) )^2")

#text("with ")#mi("R=x^{1/2-}")#text(" (in the EH case) and f obeying the usual conditions (e.g. supported on the prism R with marginals supported on various simplices)")

#text("and")

#mi("\\nu_{p_1,\\dots,p_k}(n) = ( \\sum_{d_i|n+h_i} \\mu(d_1) \\dots \\mu(d_k) f_{p_1,\\dots,p_k}( \\frac{\\log d_1}{\\log R}, \\dots, \\frac{\\log d_k}{\\log R} ) )^2")

#text("with ")#mi("f_{p_1,\\dots,p_k}")#text(" obeying similar constraints to f but also obeying the compatibility condition ")#mi("f(t_1,\\dots,t_k) = f_{p_1,\\dots,p_k}(t_1,\\dots,t_k)")#text(" when ")#mi("(t_1+\\frac{\\log p_1}{\\log R}, \\dots, t_k + \\frac{\\log p_k}{\\log R})")#text(" pokes outside of the polytope R.")

#text("Note that ")#mi("\\nu^{\\prime}")#text(" is still non-negative (basically because ")#mi("\\sum_{p|n} \\frac{\\log p}{\\log 3x} \\leq 1")#text(" when ")#mi("n \\leq 3x")#text("). Also, ")#mi("\\nu")#text(" and ")#mi("\\nu^{\\prime}")#text(" agree unless all of the n+h_i are composite, so replacing one by the other has no effect on the numerator of (1), only the denominator. For the denominator we can take advantage of the epsilon trick: the first term in the formula for ")#mi("\\nu^{\\prime}")#text(" contains divisor sums that correspond to points outside of the prism, but they are exactly canceled by the corresponding divisor sums from the second term in the formula for ")#mi("\\nu^{\\prime}")#text(". So one can still obtain an asymptotic for the denominator in (1). In the case ")#mi("f_{p_1,\\dots,p_k}=f")#text(", we have ")#mi("\\nu^{\\prime}=\\nu")#text(" and we recover the old bound (for, say, ")#mi("M^{\\prime\\prime}_{3,\\varepsilon_1,\\varepsilon_2,\\varepsilon_3,1}")#text(", since this trick seems to be compatible with all our previous tricks), but we should be able to squeeze an additional gain (hopefully at least 2%!) by optimising each of the ")#mi("f_{p_1,\\ldots,p_k}")#text(" separately (as was done in the numerator epsilon trick from ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261207")[#text("Jan 3")]#text(".) I’ll try to work out the details for the next blog post (which we are due for in any case).")

#text("If this works out, it will be rather satisfying: by throwing “everything except the kitchen sink” at the EH problem (advanced numerics, moving from EH to GEH to enlarge the sieve support, polytope decomposition, and using the epsilon trick for both the numerator and denominator), to get an essentially optimal-for-the-method bound of ")#mi("H_1 \\leq 6")#text(". (There is still the very remote chance of getting ")#mi("H_1 \\leq 4")#text(" by also throwing in the “kitchen sink” of bounding the probability that n,n+6 are both prime, but this looks like it would need a huge improvement on M_3 beyond 2 that we are not close to getting at all.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264911")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2014")])]

#text("Ah, I got overly optimistic, and this idea has the same issue that my Dec 14 idea had – the Euler-Lagrange equation for optimising ")#mi("\\nu_{p_1,\\dots,p_k}")#text(" turns out to be a consequence of (or more precisely, an iterated difference of) the Euler-Lagrange equation for ")#mi("\\nu")#text(", so that the optimal choice for ")#mi("\\nu_{p_1,\\dots,p_k}")#text(" is the same as the optimal choice of ")#mi("\\nu")#text(" and so no improvement is obtained in the end. Somehow the Selberg sieve is already optimised in these directions and there is no further fat to trim here.")

#text("Ah well, back to the drawing board…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264915")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2014")])]

#text("Here is an idea that doesn’t improve the optimal value for ")#mi("M^{\\prime\\prime}_{3,\\varepsilon_1,\\varepsilon_2,0,1}")#text(", but may help approach that value faster. Right now, we are partitioning the big polytope R into pieces, consisting of a big piece R’ plus a lot of smaller pieces with various marginal properties, putting polynomials on each piece, and optimising a large quadratic program, which gets slow in higher degree. But somehow the R’ piece, which is easier to optimise over, is dominant, with the other polytopes only adding small additional contributions. So perhaps we could weight our algorithm towards the R’ piece, for instance by first doing a preliminary low-degree optimisation to obtain a first guess for the optimal F that is a low degree polynomial in all polytope components, and then performing a further optimisation by replacing the R’ piece by a high degree polynomial while keeping the other terms fixed. The point is that the R’ component has no vanishing marginal conditions and so has a cleaner and faster optimisation. As we expect some discontinuities within the R’ region, this may help accelerate the convergence.")

#text("A variant of this approach (which, now that I think about it, is probably superior) is to do a single optimisation, but with R’ allowed to have high degree while the other pieces have lower degree; again the point is that we don’t lose any degrees of freedom by increasing the degree on R’ because there are no vanishing marginal conditions there.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264931")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2014")])]

#text("I had thought about doing this earlier, but for some reason never gave it a try. My code already allows for this approach. Since the polytopes are already entered (and quadruple checked!) for the symmetric half-plane let me give you some numerics there. Throughout, I’m limiting the degree to 4 on all the non-R’ polytopes, and also assuming that every monomial involves only two variables. I let d denote the degree used on the R’ part. I find an epsilon which gives a higher value for M” than two surrounding epsilon values (so I’m not showing their are no other local maxs [in the given mesh], but that seems likely).")

#text("d=6, epsilon=0.160, M”=1.957334, single run 21 seconds")#linebreak()#text(" d=7, epsilon=0.158, M”=1.958612, single run 31 seconds")#linebreak()#text(" d=8, epsilon=0.157, M”=1.958656, single run 51 seconds")#linebreak()#text(" d=9, epsilon=0.162, M”=1.959200, single run 1 minute 20 seconds")#linebreak()#text(" d=10, epsilon=0.160, M”=1.959633, single run 3 minutes")

#text("My next goal is to run similar computations for the prism. I still have to work out the J-integral decompositions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264965")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2014")])]

#text("Pace: I suggest to check if degree 4 outside R’ is sufficient (i.e. enough degrees of freedom are left outside R’ after satisfying the marginal constraints).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-264938")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2014")])]

#text("At least we know that without the vanishing marginals condition, the Euler-Lagrange equation implies that the optimal ")#mi("F")#text(" (which is proportional to ")#mi("\\mathcal L_k F")#text(") should be absolutely continuous on ")#mi("R")#text(", thus (using standard results of L^2 polynomial approximation theory) is it possible to estimate the rate of convergence (as a function of the polynomial degree) to the M-value?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-265050")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2014")])]

#text("I think I stumbled onto something we had missed. I computed ")#mi("M_{3,0,0,0,1}^{\\prime\\prime}")#text(" on the prism and got 1.894793, which is below what happens on the symmetric half-cube, and also below James’ computation on the same prism. I believe that the discrepancy between these values may have arisen from the fact that I used a different decomposition of the prism than James did. I think he may have used the decomposition that Terry described earlier, while I used the same decomposition (with epsilons added) except that I combined the ")#mi("D_3,D_3^{\\prime}")#text(" components into one component (since that reduces the number of integrals needed a little, but preserves the convexity of each component).")

#text("If this holds true, it would suggest that the symmetric half-cube is actually the right place to look for the best local maximum (which is what my intuition suggested initially). It also confirms what a few people have asserted; there is some gain to be had from breaking some of the convex components of the symmetric half-cube decomposition into smaller pieces, and optimizing polynomial approximations on those pieces. Especially if we take into account the calculus of variations (Lagrange multipliers) information.")

#text("I have to admit that these calculations are a lot of fun, but I may have to put further work off until early next week. If I have time then I’ll start testing this by breaking ")#mi("\\mathcal{R}_3^{\\prime}")#text(" into different pieces and redoing the computations. There are two obvious options I see. First, simply break the simplex into the six pieces given from the symmetry. The second is to think in terms of the support of the G functions arising from Lagrange multipliers that Terry described above. These supports overlap, but it shouldn’t be hard to write down the integrals using the given support.")

#text("By the way, on the prism [with my decomposition] I get that with degree 4 approximations on all components and with the two epsilons equal, the optimal epsilon is 0.156 and we get ")#mi("M_{3,0.156,0.156,0,1}^{\\prime\\prime}\\geq 1.936708")#text(", which is worse than what we find on the symmetric half-cube.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-265056")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2014")])]

#text("Interesting! So an inefficient polytope partitioning costs us about 0.02 for ")#mi("M^{\\prime\\prime}_{3,1}")#text(" for the prism; if we had been losing the same amount for the ")#mi("M^{\\prime\\prime}_{3,\\varepsilon,1}")#text(" for the symmetric polytope, we could get up to 1.98 or so – about halfway to our goal (Zeno’s paradox, once again…). Then it could come down to the wire as we refine the degree and partition into even more pieces than before…")

#text("I guess this is all consistent with the strange convergence behaviour that we’ve been experiencing.")

#text("I’ve begun working out the two-dimensional formulation, writing everything in terms of the G(x,y) function, which is supported on the disjoint union of a triangle ")#mi("\\{ x+y \\leq 1-\\varepsilon \\}")#text(" and the trapezoid ")#mi("\\{ (x,y) \\in [0,1]^2: 1+\\varepsilon \\leq x+y \\leq 3/2 \\}")#text(". Here, it turns out that the vanishing marginal conditions can be reformulated as a formula for G on the trapezoid in terms of G on the triangle, so the only independent variable is the value of G on the triangle. The naive thing to do is to then set G to be polynomial (and symmetric) on the entire triangle, but actually it’s looking like there are some mild singularities, and so to get the most optimal results one should partition into quite a lot of pieces (a preliminary analysis suggests that there are singularities on the lines ")#mi("x,y = 1/2. 1/2+\\varepsilon, 1/2+2\\varepsilon, 1-\\varepsilon")#text(", and also ")#mi("x+y=1/2")#text("). This looks like a scary number of singularities, but in some sense that’s a good thing: the more singularities there are, the worse we expect our current numerics to be, and so the more hope there is that we can do better by using a better adapted partition!")

#text("I think I will use the next blog post to talk about the two-dimensional formulation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-265178")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2014")])]

#text("In the two-dimensional formulation, the continuity (but not necessarily smoothness) properties of the function G(x,y) should also be imposed by appropriate (minimal) system of additional constraints.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-265208")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2014")])]

#text("After looking at the eigenfunction equation ")#mi("M^{\\prime}_3 F = {\\mathcal L}_3 F")#text(" for the (putative) ")#mi("{\\cal R}^{\\prime}_3")#text(" extremiser, I think that F is continuous and piecewise smooth, with lack of differentiability at the interior faces coming from taking an edge on the boundary of ")#mi("{\\cal R}^{\\prime}_3")#text(" (specifically, one of the three edges joining (1,0,0), (0,1,0), or (0,0,1) to (1/2,1/2,1/2)) and extending them in one of the coordinate directions, so the interior singularities should lie on the trapezoid with corners (1,0,0), (1/2,1/2,1/2), (0,0,0), (0,1/2,1/2) (plus the two reflections). I haven’t worked out exactly how this decomposes R’_3 though. On the two-dimensional side, this suggests that G(x,y) is continuous and piecewise smooth on the triangle ")#mi("x+y \\leq 1")#text(", with a lack of differentiability on the bisecting line joining (0,0) with (1/2,1/2). I guess the continuity and singularity can be detected once we have located good near-extremisers. (Continuity means that we have some interior matching conditions which we should probably enforce when we work on the more difficult ")#mi("M^{\\prime\\prime}_{3,\\varepsilon,1}")#text(" problem.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-265166")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2014")])]

#text("I woke up with two questions, one technical and one numerical.")

#text("Question 1: Suppose that we achieved good enough numerics to pull off the trick of passing from ")#mi("H_1\\leq 6")#text(" to ")#mi("H_1\\leq 4")#text(". Would similar methods allow us to look at the admissible 3-tuple ")#mi("(n,n+6,n+12)")#text(" and allow us to conclude that there are infinitely many prime gaps of size exactly 6? I know that Maynard’s sieve treats all admissible ")#mi("k")#text("-tuples the same, but I wasn’t sure if the same is true of the trick of forcing the endpoints not simultaneously prime.")

#text("This would seem to overcome the parity problem for the pair ")#mi("(n,n+6)")#text(", so would seem to preclude the ability to pass from ")#mi("H_1\\leq 6")#text(" to ")#mi("H_1\\leq 4")#text(".")

#text("Question 2: We easily got ")#mi("M_{4\\varepsilon,1}^{\\prime}\\geq 2")#text(", using a linear polynomial on a trivial decomposition, so there is a lot of room for improvement. What sort of bound would we need to push this to in order to play the game of forcing ")#mi("n,n+8")#text(" not simultaneously prime?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-265206")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2014")])]

#text("Oh, very nice observation! I agree that your Q1 argument shows that the parity problem blocks us from reaching ")#mi("H_1 \\leq 4")#text(" by our methods.")

#text("For Q2, the heuristic I’ve been using is that the probability ")#mi("P_{h_i}")#text(" that a given member ")#mi("n+h_i")#text(" is prime should be ")#mi("\\frac{M_k}{2k}")#text(", and that the probability ")#mi("P_{h_i,h_j}")#text(" that two of the ")#mi("n+h_i,n+h_j")#text(" are prime is bounded above by ")#mi("2 P_{h_i} P_{h_j}")#text(" (the 2 being there for parity reasons). So if one starts with ")#mi("(n,n+8,n+16,n+24)")#text(" and deletes the three pairs which are separated by distance 16 or 24, we would get a prime pair separated by 8 if")

#mi("4 \\frac{M_4}{8} - 3 \\times 2 (\\frac{M_4}{8} )^2 > 1")

#text("which is in fact not attainable. The corresponding calculation for k=3 gives the condition")

#mi("3 \\frac{M_3}{6} - 2 (\\frac{M_3}{6} )^2 > 1")

#text("which requires ")#mi("M_3 > 3")#text(", which is also blocked by parity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-265215")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2014")])]

#text("I like that heuristic! If I’m computing correctly, for the tuple ")#mi("(n,n+2,n+6,n+8)")#text(", to get ")#mi("H_1\\leq 6")#text(" we would need something like ")#mi("M_4\\geq 2.35")#text(". That seems quite doable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-265265")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2014")])]

#text("I’m not all that optimistic that it is. Presumably the best comparison we have to work from is the d=1 values for the basic simplex R_4 with and without epsilon, which are 1.820 and 2.0023 differing by 0.28, so adding epsilon into the high-degree R” mix we may be lucky to get beyond 1.951 (James’s best number for the prism without epsilon), plus 0.28 (see above), plus 0.02 (the benefit of the symmetric half-cube over the prism – though for k=4 it’s also very possible that the prism will beat the symmetric polytope because in contrast to k=3 the prism is a factor of 9/7 larger), plus an unknown but probably modest quantity because James’s 1.951 was for the relatively small d=5.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-265235")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2014")])]

#text("Here is a more formal Selberg-style argument that we can’t get ")#mi("H_1 \\leq 4")#text(" from a sieve-theoretic analysis of the tuple (n,n+2,n+6) (the same argument would work for other tuples as well). It relies on an unproven hypothesis (the Mobius pseudorandomness conjecture), but this conjecture is widely believed, and indeed one would not even be trying to use sieve theoretic methods to produce twin primes etc. if one did not already believe this conjecture!")

#text("Let us informally call a “divisor sum” some function of the form ")#mi("\\nu(n) = 1_{x \\leq n \\leq 2x} \\sum_{d_1|n, d_2|n+2, d_3|n+6} \\lambda_{d_1,d_2,d_3}")#text(" where ")#mi("\\lambda_{d_1,d_2,d_3}")#text(" are some coefficients and ")#mi("d_1,d_2,d_3")#text(" are restricted to not be too large (how large depends on what polytope we are using and what distribution hypothesis we would like to assume; I ignore these issues here). We normalise these sums so that ")#mi("\\sum_n \\nu(n)")#text(" is comparable to 1 (this is not our usual normalisation, being more of a “probability theoretic” normalisation, but never mind this). Our basic sieve-theoretic strategy is to obtain upper and lower bounds for quantities of the form")

#mi("\\sum_n \\nu(n), \\sum_n \\nu(n) 1_{n \\text{ prime}}, \\sum_n \\nu(n) 1_{n+2 \\text{ prime}}, \\sum_n \\nu(n) 1_{n+6 \\text{ prime}}")#text(" (*)")

#text("and hope to parlay this into a proof that at least one of the pairs (n,n+2), (n+2,n+6) are simultaneously prime, giving a proof of ")#mi("H_1 \\leq 4")#text(". (We are of course also interested in auxiliary quantities such as ")#mi("\\sum_n \\nu(n) 1_{n,n+6 \\text{ both prime}}")#text(", but we can’t control these directly; the only way we can proceed within sieve theory is to upper bound this quantity by something like ")#mi("\\sum_n \\nu^{\\prime}(n) 1_{n \\text{ both prime}}")#text(" for some other divisor sum ")#mi("\\nu^{\\prime}")#text(", so that it becomes of the form in (*). [Basically, even GEH only allows one to asymptotically control sums with at most one copy of the von Mangoldt function in them; asymptotics for sums such as ")#mi("\\sum_n \\Lambda(n) \\Lambda(n+2)")#text(", which basically count twin primes, are out of reach even on GEH, with the only option being to get upper or lower bounds by some combination of sums (*) for which asymptotics are available, together with the non-negativity properties of sieves.]")

#text("Now, the Mobius pseudorandomness conjectures predict that the sieve ")#mi("\\nu(n)")#text(" is asymptotically orthogonal to the Mobius functions ")#mi("\\mu(n), \\mu(n+2), \\mu(n+6)")#text(", thus for instance ")#mi("\\sum_n \\nu(n) \\mu(n+6) = o(1)")#text(". (This is because we expect the Mobius function to exhibit significant cancellation on even very short arithmetic progressions.) The same pseudorandomness heuristic also predicts ")#mi("\\nu(n)")#text(" is asymptotically orthogonal to products ")#mi("\\mu(n)\\mu(n+2), \\mu(n) \\mu(n+6), \\mu(n+2) \\mu(n+6), \\mu(n)\\mu(n+2)\\mu(n+6)")#text(".")

#text("What about ")#mi("\\nu(n) 1_{n \\text{ prime}}")#text("? This function is no longer orthogonal to ")#mi("\\mu(n)")#text(", since of course ")#mi("\\mu(n)")#text(" is ")#mi("-1")#text(" when n is prime, but from Mobius pseudorandomness we still expect this function to be orthogonal to higher products ")#mi("\\mu(n)\\mu(n+2), \\mu(n) \\mu(n+6), \\mu(n+2) \\mu(n+6), \\mu(n)\\mu(n+2)\\mu(n+6)")#text(", because the constraint that n is prime can kill at most one of the two or more Mobius factors that are present.")

#text("In particular, if one introduces the weight function")

#mi("a(n) := (1 - \\mu(n) \\mu(n+2)) (1 - \\mu(n+2) \\mu(n+6)) = 1 - \\mu(n)\\mu(n+2) - \\mu(n+2) \\mu(n+6) + \\mu(n) \\mu(n+6)")

#text("(ignoring the case when n+2 is not squarefree, which can be sieved out by the W-trick (or else we replace Mobius with the Liouville function)), we see that a and 1 are indistinguishable for the purposes of correlations (*), thus for instance")

#mi("\\sum_n \\nu(n) 1_{n+6 \\text{ prime}} = \\sum_n a(n) \\nu(n) 1_{n+6 \\text{ prime}} + o(1).")

#text("Also, observe that the weight sequence ")#mi("a(n)")#text(" is non-negative; it equals 4 when ")#mi("n+2")#text(" has the opposite Mobius function to both ")#mi("n")#text(" and ")#mi("n+6")#text(", and is zero otherwise. Because of this, any sieve-theoretic manipulation we perform on the sums (*) to produce lots of tuples ")#mi("n, n+2, n+6")#text(" with a desired property as weighted by the constant function ")#mi("1(n)=1")#text(", will also produce lots of tuples with the same property as weighted by the function ")#mi("a(n)")#text(". For instance, if we can get a lower bound for ")#mi("\\sum_n \\nu(n) 1_{n,n+2 \\text{ or } n+2,n+6 \\text{ prime}}")#text(" by some clever combination of asymptotics for (*) (and exploiting non-negativity), we should also be able to get the same lower bound for ")#mi("\\sum_n a(n) \\nu(n) 1_{n,n+2 \\text{ or } n+2,n+6 \\text{ prime}}")#text(". In particular, we would find an n in the support of a(n) for which either n,n+2 are both prime, or n+2,n+6 are both prime. But this contradicts the support of a, which forces n+2 to have a Mobius function of opposing sign to both n and n+6. So we cannot use sieve theory to force the event “n,n+2 both prime or n+2,n+6 both prime”, which indicates that we cannot establish ")#mi("H_1 \\leq 4")#text(" through a sieve-theoretic analysis of the tuple n,n+2,n+6.")

#text("EDIT: The intuition here is that sieve theory cannot prevent the two “conspiracies” ")#mi("\\mu(n) = - \\mu(n+2)")#text(" and ")#mi("\\mu(n+6) = -\\mu(n+2)")#text(" from simultaneously occurring for (almost) all n for which n, n+2, n+6 are almost prime. (Of course, formally two applications of shifted versions of ")#mi("\\mu(n)=-\\mu(n+2)")#text(" would imply ")#mi("\\mu(n+6)=+\\mu(n+2)")#text(", contradicting what I just said, but the space of n for which n,n+2,n+6 are almost prime is not shift-invariant, and one cannot force incompatibility this way. Alternatively, one can consider conspiracies in which ")#mi("\\mu(n)=\\mu(n+6)=-\\mu(n+2)")#text(" for “almost all sufficiently large n with ")#mi("n = 5\\ (6)")#text(", which I believe cannot be ruled out by any easy “local” argument, and would mean that prime gaps less than 6 occur extremely infrequently.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8b, VI: A low dimensional variational problem | What's new")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-265295")[#strong[#text("Polymath8b, VI: A low dimensional variational problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2014")])]

#text("[…] for small values of (in particular ) or asymptotically as . The previous thread may be found here. The currently best known bounds on can be found at the wiki page (which has recently returned to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8b, VII: Using the generalised Elliott-Halberstam hypothesis to enlarge the sieve support yet further | What's new")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-268542")[#strong[#text("Polymath8b, VII: Using the generalised Elliott-Halberstam hypothesis to enlarge the sieve support yet further | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2014")])]

#text("[…] smooth compactly supported functions. We use this as a replacement for the denominator estimate in this previous blog post, we obtain the criteria described […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-270479")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2014")])]

#text("In the numerator of (1), the outer summation index should be ")#mi("i")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
