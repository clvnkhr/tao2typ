// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/16/let-the-diners-into-the-kitchen/
// Converted to Typst by tao2typ: "2026-10-14T15:21:20.037965+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Let the Diners Into the Kitchen", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Let the Diners Into the Kitchen")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/16/let-the-diners-into-the-kitchen/")[#text("https://terrytao.wordpress.com/2026/09/16/let-the-diners-into-the-kitchen/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://www.noahgian.com/")[#text("Noah Giansiracusa")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("Imagine a tech company announces new robot workers that can prepare food better than human chefs. If you think of dining out as sitting at a table and having your meal brought out to you, this sounds like an excellent development. Let’s replace the humans in the kitchen with these bots and enjoy higher quality food!")

#text("But what if the restaurant’s patrons are invited inside the kitchen to see how the food is made and are explained what’s involved. They learn how techniques from around the globe have been passed down for generations. How cooking is both an art and a science, constrained by rules and patterns but rich with creativity at its heart. How ingredients are thoughtfully procured from farms and distributors with an eye toward locality, seasonality, and sustainability—ensuring long-term production is not sacrificed for short-term convenience. How menus are crafted to balance familiarity with ingenuity. How young chefs learn from experienced ones by working alongside them. How food is among the most timeless, universal ways humans have for connecting with each other.")

#text("What if, in other words, dining out is more like watching an episode of the hit TV show ")#emph[#text("The Bear")]#text("? I think it’s fair to say that this is a dining experience the public would think twice about giving up to automation.")

#metadata(none) <tao-af4543032baf9b5eb4c0>

#text("Unfortunately, most people outside of math think all we do is serve up problem solutions on a platter. They don’t know that math is about human understanding, not just mechanically establishing truths. That it is one of the longest running shared stories in human history, one that has transformed society and is treasured by its adherents. That it is a precious social endeavor, not a speedbump on the road to lucrative tech IPOs.")

#text("That’s because we haven’t done enough to bring the public inside our mathematical kitchens. Perhaps we haven’t even put enough effort into sharing the human side of math with each other—at least, not publicly.")

#text("Ask yourself if the following scenario rings familiar, not necessarily in its details but in its broad contours. While picking your kid up from an after-school activity, you learn that one of the other parents is also a mathematician. What starts as friendly banter develops into a research collaboration. You’re in different fields but have found a topic of mutual interest and realize that by combining your backgrounds you can provide a new perspective on an old problem. Before long, you have an innovative joint result together.")

#text("When chatting with colleagues, you eagerly share the amusing origin story to this theorem. When giving seminar talks, you downplay the serendipity but still gesture at it. Then in your formal write-up—that is to say, in the research paper, the one truly public record of this result—the human backstory is not mentioned. All that readers see is the theorem and proof, whose ideas are stripped down to a series of checkable lemmas and calculations, preceded by an introduction that aims to convince an anonymous referee the problem is important.")

#text("You’ve written for precision, clarity, and efficiency, maximizing the likelihood that the paper is accepted into a research journal. In doing, so you’ve minimized the humanity of your work. You’ve kept your reader out of the kitchen.")

#text("To reassert our role in math and reclaim the human value of math while Silicon Valley threatens to take these away from us, I believe we must radically embrace and expose the human side of math. We must do so now, before it is too late. This can take a variety of forms. I suggest a few here and leave you to surface others.")

#list(
[#strong[#text("Blogging.")]#text(" This is a great way to share behind-the-scenes aspects of math by letting readers into your own private kitchen, so to speak. You can discuss what’s happening in math, share your perspective on others’ results, tell the story behind you own results, reflect on your life as a mathematician, and much more. There are many excellent blogs by mathematicians already, but there’s always room for more. If you’re not up for starting one, visit others and leave comments. The more we publicly engage each other, the more society will see that mathematics is a living, breathing community.")],
[#strong[#text("Write op-eds.")]#text(" This isn’t for everyone, but it’s worth considering. It is a powerful way to speak directly to people outside of mathematics and show them that we matter. The best opportunity here is when there’s an event in the news that you could use your math background to help unpack for audiences. Don’t just target big name national newspapers; local or special interest outlets have real impact too and might especially appreciate the expertise you provide. I am happy to offer op-ed guidance and feedback—please don’t hesitate to contact me!")],
[#strong[#text("Social media.")]#text(" I say this with a slight shudder, but social media is a convenient and productive way of building community and showing the world who we are and what we do. Keep in mind there are many platforms and content formats, and that audiences generally like accessibility and relatability. That means a post doesn’t need to be a polished piece of writing; it could be a video of you walking your dog in the afternoon while talking about your favorite math moment from your day.")],
[#strong[#text("Rethink the research paper.")]#text(" This suggestion might push the envelope a bit further, but here goes. Since research papers are the standard currency in math, a currency that is being rapidly devalued by AI, perhaps we should find ways to inject more humanity into them. For instance, we could add a “backstory” section to our papers explaining the human elements that went into the collaboration/project/result. Or a “digestion” suggestion offering an informal human-centric interpretation of the main result(s). I don’t know, I’m just thinking out loud here. But a useful guiding principle could be to think of what you can provide that an AI cannot, or would not.")]
)

#text("The Bourbaki movement focused attention away from informality in math, training us to be clear and concise. We are in a different era now. Math is not adapting to confront imprecision and gaps in arguments; it is adapting to confront AI. To put the matter bluntly: The more we act and write like robots, the more we hand our profession over to them. The details of how best to resist this are not obvious, but the overarching strategy is. We must show the world the human side of math. We must let people into our mathematical kitchens.")

#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d0e4b2744f1cc3033c3cb46f8c7cde5f42138af1e697fa38a01dcec33bc7765-7702686990bbf5a8eda97aaba2c23cd8a278ff9c4888fdfca2b1e85838e0f61a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/09/16/let-the-diners-into-the-kitchen/#comment-695413")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("How the general public imagines higher mathematics is heavily influenced by mass media. A movie or a big news story reaches far more people than a blog, but the mainstream reporting about Navier-Stokes mostly reinforces the problem-serving image, and film depictions of mathematicians are even worse. What can be done about this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/16/let-the-diners-into-the-kitchen/#comment-695416")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("We need a handful of Martin Gardners!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2d6129781a7e49365a02f5833609a6ca7eeb9fe31288a179443e07db186a736-4b8b3e78620c4b0e55dc8f3fa0aed23e027fcdfa289fabbc2978026e71751e4c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mordechai Rorvig")]], [#link("https://terrytao.wordpress.com/2026/09/16/let-the-diners-into-the-kitchen/#comment-695424")[#strong[#text("Mordechai Rorvig")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("I just had a comment chewed up by failed login permissions, and it was already a little frustrated, but now it’s going to be even more frustrated, so here it goes:")

#text("I’m tired of the recurring feeling of this and other recent posts with reactions to AI in math that they are all really missing the point, or at least overcomplicating it, even if they are all well-intended.")

#text("It is clear to anyone from the outside of mathematics that the chief purpose of professional mathematics is *caring about humans*: Giving people a job, allowing them to take care of themselves and their family, giving them interesting things they can do, and so on.")

#text("Of course, as this poster writes, mathematics provides for many other human values, like understanding; personal satisfaction; fostering human connection, and so on. But to say that AI is threatening these values or displacing them, or distracting from them, is like saying, “Oh look, I think that giant tsunami is possibly going to wreck the new extension to our living room.”")

#text("Like most modern professions, mathematicians are completely buried in the details of their own work and have seemingly forgotten about their devil’s bargain, where they get to take it for granted that they get to be cared for—unlike countless others—so long as they spin their wheels as fast as they can within the established minimal societal parameters of their running rooms.")

#text("Elite mathematicians have forgotten (or possibly never learned) what it means that they can now be taken down a peg, that someone else can come along and say, “Hey, I can now do your job—your only choice now is do this for fun.”")

#text("What we need to focus on is whether AI in math is going to allow for society to take better care of humans—like providing more jobs, or better jobs—or whether it’s going to take worse care—like eliminating jobs—or even worse (e.g. terminators). It’s time to stop forgetting that the point of math is really found in the ideas of basic human ethics, things that people have conveniently mainly been allowed to ignore, not in, “Oh I liked algebra better than analysis because blah blah blah.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/16/let-the-diners-into-the-kitchen/#comment-695475")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("I would agree with this, especially this part :")

#text("“But to say that AI is threatening these values or displacing them, or distracting from them, is like saying, “Oh look, I think that giant tsunami is possibly going to wreck the new extension to our living room.”")

#text("Like most modern professions, mathematicians are completely buried in the details of their own work and have seemingly forgotten about their devil’s bargain, where they get to take it for granted that they get to be cared for—unlike countless others—so long as they spin their wheels as fast as they can within the established minimal societal parameters of their running rooms.”")

#text("And add a more negative comment.")

#text("Mathematics has been a huge, HUGE source of empowerment to companies and governments to help automate work, or reinforce their control over people, and, often, remove agency from people.")

#text("(I’m not saying this as if it is a strict negative or anything, but mathematics is rarely talked about in this manner, instead cherry-picking the indisputable benefits of, say, statistics applied to medical research, or the like).")

#text("Many craftspeople jobs replaced by automated/machine over decades, computers playing an even more active role at automating other tasks.")

#text("This job-replacing automation -especially computer-related- has the effect of dehumanizing work, in the same way bureaucratic management of human affairs does.")

#text("[Aside : From the blog post : ‘most people outside of math think all we do is serve up problem solutions on a platter’")

#text("Mathematics books and papers are terse, dry, often feel like the human personality (outside of their mathematics’ outlook) is as removed as possible. They provide knowledge which to many people using mathematics down the line helps serve up solutions on a platter. It is not (to the layman) the best example of deeply human work. And mathematics research’ human components don’t always shine through to others.]")

#text("(I am grossly oversimplifying all this, of course. And mathematicians often work on problems that have no immediate applications, unlike engineers, so their contribution is not as obvious.")

#text("But the techniques developed often do have applications or can shake up the world, and that’s the vested interest from external backers and why you get funding, most structures funding mathematics directly or indirectly didn’t really care whether Fermat’s Last Theorem was true, they fund research for the applications of the techniques developed, and the hope for some big new engineering fields to emerge).")

#text("Where were the mathematicians when prior job automation and human replacing happened ?")

#text("A lot of them were being paid to develop techniques and ideas -indirectly- keep automating people out of their jobs, or to develop techniques that would be used to dehumanize further down the line.")

#text("And only when AI comes knocking at *their* door, theirs, mind you, no such effort was made to support artists being driven out of work when gen AI kicked off. Art being an incredibly human experience, on top of that.")

#text("But unlike artists, many of whom outright refused to make use of gen AI altogether, or at least as long as they reasonably could, here, several of the blog posts written by mathematicians regarding recent developments are written with AI, or drafted with AI before being rewritten, or touched up with AI (beyond technical format touch ups). The disconnect is quite strange to read.")

#text("I believe that it is disingenuous to take a critical look at a technology, a craft, or a specific piece of knowledge removed from its context, the society that produced it.")

#text("Advanced mathematics, and AI techniques, don’t exist in a vacuum. They can only emerge in a society that actively supports their development, and finds said development culturally appropriate, and funds it. This is quite different from artistic expression, which seems pretty universal as far as human tribes/societies/villages go.")

#text("Yet the current discourse, all the while using different kinds of AI for many different purposes, seems to behave as if mathematicians can have the convenient things about AI without the much much much nastier things. And mathematicians mostly seem to care about protecting their own turf, very little has been said in the past few years about the destruction of knowledge and crafts caused by AI, about the gigantic problems that will be caused by appropriation of water and the energy costs, about exploiting humans without informed consent, about exploiting humans for training AI, …")

#text("I could go on.")

#text("No. AI is a problem when it interferes with mathematicians’ higher purpose of being (relative to average workers) well-paid at furthering the boundaries of human knowledge in a way they understand. That’s when they draw the line.")

#text("I don’t mean to bash on this blog post in particular, and I personally enjoy mathematics.")

#text("But the reality is this : a culture indifferent, or adverse to some forms of humanness was what was necessary to develop AI, and coercion/manipulation was necessary for AI to become this powerful and be this developed. No way most humans would have given informed consent to many AI-related things with enough informed knowledge in advance of the consequences.")

#text("As well-placed as the intentions are, and as much as I personally sympathize with the sentiment regarding recent AI-related mathematical ‘breakthroughs’, throwing your hands up and talking about the human quality of mathematics after doing little to nothing for years about the well-discussed dangers of AI to specific human endeavors is not likely to change much, and is unlikely to attract that much sympathy from most of the rest of the world who has had to suffer through worse earlier.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/16/let-the-diners-into-the-kitchen/#comment-695564")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("I think this comment raised an excellent point, and I agree with it.")

#text("For the defence of the “inaction” of mathematical community regarding the harmful impact of AI on human society, it can be traced partly to these aspects:")

#enum(start: 1, 
[#text("The current development of AI is so fast, and it bypasses human perception. It is like to see a supersonic jet plane flying across the sky with our eyes. We see but we do not perceive.")],
[#text("Many mathematicians, including myself, are those people who are slow in understanding things, even slower in taking actions.")]
)

#text("For 1, it is like we feel the impact when the supersonic sound wave hits our ears, which seems to be our current situation.")

#text("For 2, there is no excuse of this. We can just say that now is the earliest time to act.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/16/let-the-diners-into-the-kitchen/#comment-695638")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("Regarding 1),")

#text("I would agree that the development of AI is so fast that its ability to replace/supersede/completely transform fields such as programming and mathematics was not obvious to anticipate or to realize how quickly things were/are moving.")

#text("However, its")

#text("-dehumanizing aspects")#linebreak()#text("– ecological devastation")#linebreak()#text("– energy and water appropriation aspects")#linebreak()#text("– theft of human work, ")#linebreak()#text("– appropriation of knowledge/risks of decaying knowledge transmission/hampering child learning")#linebreak()#text("– new scamming possibilities ")#linebreak()#text("– shaky moral and ethical grounds")#linebreak()#text("– exploitation of low-paid workers in various countries to train models")#linebreak()#text("– and the aforementioned shakeup regarding professional artistic content (both from a production/productivity and from a moral/philosophical/ethical), …")

#text("have all already had quite a lot of public discourse over the past 5 years or so. Other professional activities like translation were shaken up even earlier, I believe.")

#text("Regarding 2),")

#text("I find it hard to believe that individuals presumed well-educated and supposedly quite well-fitted in terms of brainpower (honed through regular use, too !) are ‘slow at understanding things’, whatever that means.")

#text("I think the answer lies elsewhere for many of them. Possibly, as the first comment alludes : ")#linebreak()#text("‘being buried in the details of their own work’ and not really looking at the world through, say, other professions’ lenses.")

#text("[Unrelated, but it is possible that the current development of AI in mathematics might lead to the need for more applied mathematicians.")

#text("Suppose current models became productive enough to churn out new results at a rate that becomes quite difficult to keep up with. Some might be marginal results, others might be powerful enough to completely shake up the world within a few years of applied engineering work.")

#text("(Example from the podcast ‘wading through AI, episode 9 : Shannon’s results on information theory impacted the whole world within a generation. The Erdos unit distance problem might not have such a meaningful impact over time. Episodes 9 and 10 are probably a particularly interesting listen for mathematicians).")

#text("It’s quite easy to imagine governments or even large-scale mercenary-like corporations employing applied mathematicians to sift through new results and try and see how they can turn into inventions.")

#text("All this behind closed doors and keeping a tight lid on new discoveries, as it might give their owner a HUGE edge to spy/increase control/wage economical war/appropriate resources/develop military technology over neighbors and competitors. It’d be like the difference between a country having the internet at their disposal and another not having it.")

#text("(I am glossing over many things, but I hope it is obvious to ‘slow to understand’ mathematicians that that’s what they would do -or possibly are already trying to do- with such technology).")

#text("The role of people able to understand/validate the power of those new results, and turn them into something humanly digestible to send to production would be immensely valuable. Perhaps that is where mathematics is headed in the near future.")

#text("This idea sounds both quite naive and quite plausible.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/16/let-the-diners-into-the-kitchen/#comment-695427")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("> How the general public imagines higher mathematics is heavily influenced by mass media.")

#text("I think the media portrayal of higher math is downstream of our own culture. If “human understanding” is the key point")#linebreak()#text("of mathematics, then there would be a Fields-medal equivalent of for math communication (and 3Blue1Brown would be the most celebrated “mathematician” and not a “math communicator”. Why are math research papers published in journals which are not open access? Or as Noah says above, why are math research papers lacking in, well, humanity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d0e4b2744f1cc3033c3cb46f8c7cde5f42138af1e697fa38a01dcec33bc7765-7702686990bbf5a8eda97aaba2c23cd8a278ff9c4888fdfca2b1e85838e0f61a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/09/16/let-the-diners-into-the-kitchen/#comment-695435")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("First of all, for over a decade nearly all math papers (at least in English) has been posted on the arXiv prior to publication. Everyone knows the journal system has been in neeed of reform for a long time. So you’re just wrong about open access.")

#text("Second, there are a ")#strong[#text("lot")]#text(" of people in the mathematics community (eg David Bessis) who think that the professional hierarchy of mathematical work was always stupid and disingenuous. Putting problem-solving at the apex was due to (1) wanting “objective” evaluative criteria and (2) laziness. Telling funders that you’re working on some problem with some “application” is a lot easier than explaining why a given subfield is mathematically interesting and how it fits into a larger picture.")

#text("But recent developments are exposing how shortsighted that approach was. We screwed up, and now we have to fix it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/16/let-the-diners-into-the-kitchen/#comment-695528")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Apart from the bit about open access journals (aren’t most articles available on the arxiv anyway?), I agree. I think what’s happening here is that the community always valued theorem-proving skills more than this “human understanding” that’s being talked about, and the entire profession was structured around theorem proving. Which isn’t necessarily a bad thing, and probably was the fastest way to advance theoretical math. But it puts them in an awkward position now that computers got the theorem proving skills way faster than anyone expected. The title of David Bessis’s blog post “The fall of the theorem-proving economy” perfectly captures this.")

#text("There are indeed similarities with what happened to artists and writers. The problem is that while people care about art and writing coming from humans, the same may not apply to math. I think mathematicians should reflect less on what AI will do to their profession and more on what AI will do to humanity in general. If anyone can be discarded because an AI does their job better than them, nobody is going to win here.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/16/let-the-diners-into-the-kitchen/#comment-695484")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("I was so inspired by Simon Singh’s book about Wiles-Taylor’s Fermat proof. Obviously no one would read a book (probably AI “written” anyway) about an AI proof.")

#text("We are dealing with a gigantic intellectual property theft. The argument is that humans, too, read and learn.")

#text("But humans can’t read every book and don’t get prompts from researchers that reveal directions.")

#text("There is no fundamental reason why training a machine on the entire output of humanity is legal. Humans are obviously allowed to breathe, but we begin to regulate reduce oxygen consumption for machines.")

#text("This world is not for the benefit of machines or their owners. The IP angle that has been pursued by the NYT for example should probably be pursued by tenured professors, too.")

#text("I realize that it is probably easier to work on mathematics in a state of mind that is non-confrontational, but this is an exceptional situation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/16/let-the-diners-into-the-kitchen/#comment-695586")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("This blog reminds me of a teaching evaluation that Prof Ralston at UCLA was laughing about receiving in the 90s. It said “Prof Ralston should not waste so much time in class proving Theorems– We believe him.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f563bddef1ea6c900459b818043ae43f59604042e090bc80cd98e994ab2ad2d-855eee57d6ce545af19e1c1d482f30e9f9ca47a674424b7182685751495a71c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of davidmfisher")]], [#link("https://terrytao.wordpress.com/2026/09/16/let-the-diners-into-the-kitchen/#comment-695720")[#strong[#text("davidmfisher")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("This post and some of the comments begin a discussion that I find oddly lacking in almost all discussion of aI and mathematics. AI is making it uncomfortably clear that we have not literally for decades done a very good job of defining what research in mathematics is for and why society at large should care about it. Maybe we have never done that. Various small attempts are made but nothing cohesive emerges. To say that the idea of eventual application is what drives the modern mathematical enterprise seems at best far fetched. It certainly is not what leads most mathematicians into mathematics, nor does it play much, if any, role in the directions of work we choose collectively to value.")
]
