// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/
// Converted to Typst by tao2typ: "2026-10-14T16:37:47.998412+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "275A, Notes 1: Integration and expectation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("275A, Notes 1: Integration and expectation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 October 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/")[#text("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In ")#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")[#text("Notes 0")]#text(", we introduced the notion of a ")#link("https://en.wikipedia.org/wiki/Measure_(mathematics)#measure_space")[#text("measure space")]#text(" ")#mi("{\\Omega = (\\Omega, {\\mathcal F}, \\mu)}")#text(", which includes as a special case the notion of a ")#link("https://en.wikipedia.org/wiki/Probability_space")[#text("probability space")]#text(". By selecting one such probability space ")#mi("{(\\Omega,{\\mathcal F},\\mu)}")#text(" as a ")#link("https://en.wikipedia.org/wiki/Sample_space")[#text("sample space")]#text(", one obtains a model for random events and random variables, with ")#link("https://en.wikipedia.org/wiki/Event_(probability_theory)")[#text("random events")]#text(" ")#mi("{E}")#text(" being modeled by measurable sets ")#mi("{E_\\Omega}")#text(" in ")#mi("{{\\mathcal F}}")#text(", and ")#link("https://en.wikipedia.org/wiki/Random_variable")[#text("random variables")]#text(" ")#mi("{X}")#text(" taking values in a measurable space ")#mi("{R}")#text(" being modeled by measurable functions ")#mi("{X_\\Omega: \\Omega \\rightarrow R}")#text(". We then defined some basic operations on these random events and variables:")

#list(
[#text("Given events ")#mi("{E,F}")#text(", we defined the ")#link("https://en.wikipedia.org/wiki/Logical_conjunction")[#text("conjunction")]#text(" ")#mi("{E \\wedge F}")#text(", the ")#link("https://en.wikipedia.org/wiki/Logical_disjunction")[#text("disjunction")]#text(" ")#mi("{E \\vee F}")#text(", and the complement ")#mi("{\\overline{E}}")#text(". For countable families ")#mi("{E_1,E_2,\\dots}")#text(" of events, we similarly defined ")#mi("{\\bigwedge_{n=1}^\\infty E_n}")#text(" and ")#mi("{\\bigvee_{n=1}^\\infty E_n}")#text(". We also defined the empty event ")#mi("{\\emptyset}")#text(" and the sure event ")#mi("{\\overline{\\emptyset}}")#text(", and what it meant for two events to be equal.")],
[#text("Given random variables ")#mi("{X_1,\\dots,X_n}")#text(" in ranges ")#mi("{R_1,\\dots,R_n}")#text(" respectively, and a measurable function ")#mi("{F: R_1 \\times \\dots \\times R_n \\rightarrow S}")#text(", we defined the random variable ")#mi("{F(X_1,\\dots,X_n)}")#text(" in range ")#mi("{S}")#text(". (As the special case ")#mi("{n=0}")#text(" of this, every deterministic element ")#mi("{s}")#text(" of ")#mi("{S}")#text(" was also a random variable taking values in ")#mi("{S}")#text(".) Given a relation ")#mi("{P: R_1 \\times \\dots \\times R_n \\rightarrow \\{\\text{true}, \\text{false}\\}}")#text(", we similarly defined the event ")#mi("{P(X_1,\\dots,X_n)}")#text(". Conversely, given an event ")#mi("{E}")#text(", we defined the indicator random variable ")#mi("{1_E}")#text(". Finally, we defined what it meant for two random variables to be equal.")],
[#text("Given an event ")#mi("{E}")#text(", we defined its probability ")#mi("{{\\bf P}(E)}")#text(".")]
)

#text("These operations obey various axioms; for instance, the boolean operations on events obey the axioms of a ")#link("https://en.wikipedia.org/wiki/Boolean_algebra_(structure)")[#text("Boolean algebra")]#text(", and the probability function ")#mi("{E \\mapsto {\\bf P}(E)}")#text(" obeys the ")#link("https://en.wikipedia.org/wiki/Probability_axioms")[#text("Kolmogorov axioms")]#text(". However, we will not focus on the axiomatic approach to probability theory here, instead basing the foundations of probability theory on the sample space models as discussed in ")#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")[#text("Notes 0")]#text(". (But see ")#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/")[#text("this previous post")]#text(" for a treatment of one such axiomatic approach.)")

#text("It turns out that almost all of the other operations on random events and variables we need can be constructed in terms of the above basic operations. In particular, this allows one to safely ")#emph[#text("extend")]#text(" the sample space in probability theory whenever needed, provided one uses an extension that respects the above basic operations; this is an important operation when one needs to add new sources of randomness to an existing system of events and random variables, or to couple together two separate such systems into a joint system that extends both of the original systems. We gave a simple example of such an extension in the previous notes, but now we give a more formal definition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1")]#text(" Suppose that we are using a probability space ")#mi("{\\Omega = (\\Omega, {\\mathcal F}, \\mu)}")#text(" as the model for a collection of events and random variables. An ")#emph[#text("extension")]#text(" of this probability space is a probability space ")#mi("{\\Omega^{\\prime} = (\\Omega^{\\prime}, {\\mathcal F}^{\\prime}, \\mu^{\\prime})}")#text(", together with a measurable map ")#mi("{\\pi: \\Omega^{\\prime} \\rightarrow \\Omega}")#text(" (sometimes called the ")#emph[#text("factor map")]#text(") which is probability-preserving in the sense that ")#metadata(none) <tao-d92f43dbe69f86f7a5d8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\mu^{\\prime}( \\pi^{-1}(E) ) = \\mu(E)")]]

#text(" for all ")#mi("{E \\in {\\mathcal F}}")#text(". (")#emph[#text("Caution")]#text(": this does ")#emph[#text("not")]#text(" imply that ")#mi("{\\mu(\\pi(F)) = \\mu^{\\prime}(F)}")#text(" for all ")#mi("{F \\in {\\mathcal F}^{\\prime}}")#text(" – why not?)")

#text("An event ")#mi("{E}")#text(" which is modeled by a measurable subset ")#mi("{E_\\Omega}")#text(" in the sample space ")#mi("{\\Omega}")#text(", will be modeled by the measurable set ")#mi("{E_{\\Omega^{\\prime}} := \\pi^{-1}(E_\\Omega)}")#text(" in the extended sample space ")#mi("{\\Omega^{\\prime}}")#text(". Similarly, a random variable ")#mi("{X}")#text(" taking values in some range ")#mi("{R}")#text(" that is modeled by a measurable function ")#mi("{X_\\Omega: \\Omega \\rightarrow R}")#text(" in ")#mi("{\\Omega}")#text(", will be modeled instead by the measurable function ")#mi("{X_{\\Omega^{\\prime}} := X_\\Omega \\circ \\pi}")#text(" in ")#mi("{\\Omega^{\\prime}}")#text(". We also allow the extension ")#mi("{\\Omega^{\\prime}}")#text(" to model additional events and random variables that were not modeled by the original sample space ")#mi("{\\Omega}")#text(" (indeed, this is one of the main reasons why we perform extensions in probability in the first place).")
]

#text("Thus, for instance, the sample space ")#mi("{\\Omega^{\\prime}}")#text(" in Example 3 of the ")#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")[#text("previous post")]#text(" is an extension of the sample space ")#mi("{\\Omega}")#text(" in that example, with the factor map ")#mi("{\\pi: \\Omega^{\\prime} \\rightarrow \\Omega}")#text(" given by the first coordinate projection ")#mi("{\\pi(i,j) := i}")#text(". One can verify that all of the basic operations on events and random variables listed above are unaffected by the above extension (with one caveat, see remark below). For instance, the conjunction ")#mi("{E \\wedge F}")#text(" of two events can be defined via the original model ")#mi("{\\Omega}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("(E \\wedge F)_\\Omega := E_\\Omega \\cap F_\\Omega")]]

#text("or via the extension ")#mi("{\\Omega^{\\prime}}")#text(" via the formula")

#align(center)[#tao-fit-display[#mitex("(E \\wedge F)_{\\Omega^{\\prime}} := E_{\\Omega^{\\prime}} \\cap F_{\\Omega^{\\prime}}.")]]

#text("The two definitions are consistent with each other, thanks to the obvious set-theoretic identity")

#align(center)[#tao-fit-display[#mitex("\\pi^{-1}( E_\\Omega \\cap F_\\Omega ) = \\pi^{-1}(E_\\Omega) \\cap \\pi^{-1}(F_\\Omega).")]]

#text("Similarly, the assumption ")#link(<tao-d92f43dbe69f86f7a5d8>)[#text("(1)")]#text(" is precisely what is needed to ensure that the probability ")#mi("{\\mathop{\\bf P}(E)}")#text(" of an event remains unchanged when one replaces a sample space model with an extension. We leave the verification of preservation of the other basic operations described above under extension as exercises to the reader.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" There is one minor exception to this general rule if we do not impose the additional requirement that the factor map ")#mi("{\\pi}")#text(" is surjective. Namely, for non-surjective ")#mi("{\\pi}")#text(", it can become possible that two events ")#mi("{E, F}")#text(" are unequal in the original sample space model, but become equal in the extension (and similarly for random variables), although the converse never happens (events that are equal in the original sample space always remain equal in the extension). For instance, let ")#mi("{\\Omega}")#text(" be the discrete probability space ")#mi("{\\{a,b\\}}")#text(" with ")#mi("{p_a=1}")#text(" and ")#mi("{p_b=0}")#text(", and let ")#mi("{\\Omega^{\\prime}}")#text(" be the discrete probability space ")#mi("{\\{ a^{\\prime}\\}}")#text(" with ")#mi("{p^{\\prime}_{a^{\\prime}}=1}")#text(", and non-surjective factor map ")#mi("{\\pi: \\Omega^{\\prime} \\rightarrow \\Omega}")#text(" defined by ")#mi("{\\pi(a^{\\prime}) := a}")#text(". Then the event modeled by ")#mi("{\\{b\\}}")#text(" in ")#mi("{\\Omega}")#text(" is distinct from the empty event when viewed in ")#mi("{\\Omega}")#text(", but becomes equal to that event when viewed in ")#mi("{\\Omega^{\\prime}}")#text(". Thus we see that extending the sample space by a non-surjective factor map can identify previously distinct events together (though of course, being probability preserving, this can only happen if those two events were already almost surely equal anyway). This turns out to be fairly harmless though; while it is nice to know if two given events are equal, or if they differ by a non-null event, it is almost never useful to know that two events are unequal if they are already almost surely equal. Alternatively, one can add the additional requirement of surjectivity in the definition of an extension, which is also a fairly harmless constraint to impose (this is what I chose to do in ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("this previous set of notes")]#text(").")
]

#text("Roughly speaking, one can define probability theory as the study of those properties of random events and random variables that are model-independent in the sense that they are preserved by extensions. For instance, the cardinality ")#tao-math("{\\left|E_\\Omega\\right|}", block: false)#text(" of the model ")#mi("{E_\\Omega}")#text(" of an event ")#mi("{E}")#text(" is ")#emph[#text("not")]#text(" a concept within the scope of probability theory, as it is not preserved by extensions: continuing Example 3 from ")#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")[#text("Notes 0")]#text(", the event ")#mi("{E}")#text(" that a die roll ")#mi("{X}")#text(" is even is modeled by a set ")#mi("{E_\\Omega = \\{2,4,6\\}}")#text(" of cardinality ")#mi("{3}")#text(" in the original sample space model ")#mi("{\\Omega}")#text(", but by a set ")#mi("{E_{\\Omega^{\\prime}} = \\{2,4,6\\} \\times \\{1,2,3,4,5,6\\}}")#text(" of cardinality ")#mi("{18}")#text(" in the extension. Thus it does not make sense in the context of probability theory to refer to the “cardinality of an event ")#mi("{E}")#text("“.")

#text("On the other hand, the supremum ")#mi("{\\sup_n X_n}")#text(" of a collection of random variables ")#mi("{X_n}")#text(" in the extended real line ")#mi("{[-\\infty,+\\infty]}")#text(" is a valid probabilistic concept. This can be seen by manually verifying that this operation is preserved under extension of the sample space, but one can also see this by defining the supremum in terms of existing basic operations. Indeed, note from Exercise 24 of ")#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")[#text("Notes 0")]#text(" that a random variable ")#mi("{X}")#text(" in the extended real line is completely specified by the threshold events ")#mi("{(X \\leq t)}")#text(" for ")#mi("{t \\in {\\bf R}}")#text("; in particular, two such random variables ")#mi("{X,Y}")#text(" are equal if and only if the events ")#mi("{(X \\leq t)}")#text(" and ")#mi("{(Y \\leq t)}")#text(" are surely equal for all ")#mi("{t}")#text(". From the identity")

#align(center)[#tao-fit-display[#mitex("(\\sup_n X_n \\leq t) = \\bigwedge_{n=1}^\\infty (X_n \\leq t)")]]

#text("we thus see that one can completely specify ")#mi("{\\sup_n X_n}")#text(" in terms of ")#mi("{X_n}")#text(" using only the basic operations provided in the above list (and in particular using the countable conjunction ")#mi("{\\bigwedge_{n=1}^\\infty}")#text(".) Of course, the same considerations hold if one replaces supremum, by infimum, limit superior, limit inferior, or (if it exists) the limit.")

#text("In this set of notes, we will define some further important operations on scalar random variables, in particular the ")#emph[#text("expectation")]#text(" of these variables. In the sample space models, expectation corresponds to the notion of integration on a measure space. As we will need to use both expectation and integration in this course, we will thus begin by quickly reviewing the basics of integration on a measure space, although we will then translate the key results of this theory into probabilistic language.")

#text("As the finer details of the Lebesgue integral construction are not the core focus of this probability course, some of the details of this construction will be left to exercises. See also Chapter 1 of Durrett, or ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")[#text("these previous blog notes")]#text(", for a more detailed treatment.")

#metadata(none) <tao-e746fff4cb42419c5de4>

#heading(level: 1)[#strong[#text(" — 1. Integration on measure spaces — ")]]

#text("Let ")#mi("{(\\Omega, {\\mathcal F}, \\mu)}")#text(" be a measure space, and let ")#mi("{f}")#text(" be a measurable function on ")#mi("{\\Omega}")#text(", taking values either in the reals ")#mi("{{\\bf R}}")#text(", the non-negative extended reals ")#mi("{[0,+\\infty]}")#text(", the extended reals ")#mi("{[-\\infty,+\\infty]}")#text(", or the complex numbers ")#mi("{{\\bf C}}")#text(". We would like to define the integral ")#metadata(none) <tao-c52b68c8c966d1d3759b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\int_\\Omega f\\ d\\mu")]]

#text(" of ")#mi("{f}")#text(" on ")#mi("{\\Omega}")#text(". (One could make the integration variable explicit, e.g. by writing ")#mi("{\\int_\\Omega f(\\omega)\\ d\\mu(\\omega)}")#text(", but we will usually not do so here.) When integrating a reasonably nice function (e.g. a continuous function) on a reasonably nice domain (e.g. a box in ")#mi("{{\\bf R}^n}")#text("), the ")#link("https://en.wikipedia.org/wiki/Riemann_integral")[#text("Riemann integral")]#text(" that one learns about in undergraduate calculus classes suffices for this task; however, for the purposes of probability theory, we need the much more general notion of a ")#link("https://en.wikipedia.org/wiki/Lebesgue_integral")[#text("Lebesgue integral")]#text(" in order to properly define ")#link(<tao-c52b68c8c966d1d3759b>)[#text("(2)")]#text(" for the spaces ")#mi("{\\Omega}")#text(" and functions ")#mi("{f}")#text(" we will need to study.")

#text("Not every measurable function can be integrated by the Lebesgue integral. There are two key classes of functions for which the integral exists and is well behaved:")

#list(
[#emph[#text("Unsigned")]#text(" measurable functions ")#mi("{f: \\Omega \\rightarrow [0,+\\infty]}")#text(", that take values in the non-negative extended reals ")#mi("{[0,+\\infty]}")#text("; and")],
[#emph[#text("Absolutely integrable")]#text(" functions ")#mi("{f: \\Omega \\rightarrow {\\bf R}}")#text(" or ")#mi("{f: \\Omega \\rightarrow {\\bf C}}")#text(", which are scalar measurable functions whose absolute value ")#tao-math("{\\left|f\\right|}", block: false)#text(" has a finite integral: ")#mi("{\\int_\\Omega |f|\\ d\\mu < \\infty}")#text(". (Sometimes we also allow absolutely integrable functions to attain an infinite value ")#mi("{\\infty}")#text(", so long as they only do so on a set of measure zero.)")]
)

#text("One could in principle extend the Lebesgue integral to slightly more general classes of functions, e.g. to sums of absolutely integrable functions and unsigned functions. However, the above two classes already suffice for most applications (and as a general rule of thumb, it is dangerous to apply the Lebesgue integral to functions that are not unsigned or absolutely integrable, unless you really know what you are doing).")

#text("We will construct the Lebesgue integral in the following four stages. First, we will define the Lebesgue integral just for ")#link("https://en.wikipedia.org/wiki/Simple_function")[#text("unsigned simple functions")]#text(" – unsigned measurable functions that take on only finitely many values. Then, by a limiting procedure, we extend the Lebesgue integral to unsigned functions. After that, by decomposing a real absolutely integrable function into unsigned components, we extend the integral to real absolutely integrable functions. Finally, by taking real and imaginary parts, we extend to complex absolutely integrable functions. (This is not the only order in which one could perform this construction; for instance, in Durrett, one first constructs integration of bounded functions on finite measure support before passing to arbitrary unsigned functions.)")

#text("First consider an unsigned simple function ")#mi("{f: \\Omega \\rightarrow [0,+\\infty]}")#text(", thus ")#mi("{f}")#text(" is measurable and only takes values at a finite number of values. Then we can express ")#mi("{f}")#text(" as a finite linear combination (in ")#mi("{[0,+\\infty]}")#text(") of indicator functions. Indeed, if we enumerate the values that ")#mi("{f}")#text(" takes as ")#mi("{a_1,\\dots,a_n \\in [0,+\\infty]}")#text(" (avoiding repetitions) and setting ")#mi("{E_i := \\{ \\omega \\in \\Omega: f(\\omega) = a_i \\}}")#text(" for ")#mi("{i=1,\\dots,n}")#text(", then it is clear that")

#align(center)[#tao-fit-display[#mitex("f = \\sum_{i=1}^n a_i 1_{E_i}.")]]

#text("(It should be noted at this point that the operations of addition and multiplication on ")#mi("{[0,+\\infty]}")#text(" are defined by setting ")#mi("{+\\infty + a = a + \\infty = +\\infty}")#text(" for all ")#mi("{a \\in [0,+\\infty]}")#text(", and ")#mi("{a \\cdot +\\infty = +\\infty \\cdot a = \\infty}")#text(" for all ")#emph[#text("positive")]#text(" ")#mi("{a \\in (0,+\\infty]}")#text(", but that ")#mi("{0 \\cdot +\\infty = +\\infty \\cdot 0}")#text(" is defined to equal ")#mi("{0}")#text(". To put it another way, multiplication is defined to be continuous from below, rather than from above: ")#mi("{a \\cdot b = \\lim_{x \\rightarrow a^-, y \\rightarrow b^-} x \\cdot y}")#text(". One can verify that the commutative, associative, and distributive laws continue to hold on ")#mi("{[0,+\\infty]}")#text(", but we caution that the cancellation laws do ")#emph[#text("not")]#text(" hold when ")#mi("{+\\infty}")#text(" is involved.)")

#text("Conversely, given any coefficients ")#mi("{a_1,\\dots,a_n \\in [0,+\\infty]}")#text(" (not necessarily distinct) and measurable sets ")#mi("{E_1,\\dots,E_n}")#text(" in ")#mi("{{\\mathcal F}}")#text(" (not necessarily disjoint), the sum ")#mi("{\\sum_{i=1}^n a_i 1_{E_i}}")#text(" is an unsigned simple function.")

#text("A single simple function can be decomposed in multiple ways as a linear combination of unsigned simple functions. For instance, on the real line ")#mi("{{\\bf R}}")#text(", the function ")#mi("{2 \\times 1_{[0,1)} + 1 \\times 1_{[1,3)}}")#text(" can also be written as ")#mi("{1 \\times 1_{[0,1)} + 1 \\times 1_{[0,3)}}")#text(" or as ")#mi("{2 \\times 1_{[0,1)} + 1 \\times 1_{[1,2)} + 1 \\times 1_{[2,3)}}")#text(". However, there is an invariant of all these decompositions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Suppose that an unsigned simple function ")#mi("{f}")#text(" has two representations as the linear combination of indicator functions:")

#align(center)[#tao-fit-display[#mitex("f = \\sum_{i=1}^n a_i 1_{E_i} = \\sum_{j=1}^m b_j 1_{F_j},")]]

#text("where ")#mi("{n,m}")#text(" are nonnegative integers, ")#mi("{a_1,\\dots,a_n,b_1,\\dots,b_m}")#text(" lie in ")#mi("{[0,+\\infty]}")#text(", and ")#mi("{E_1,\\dots,E_n,F_1,\\dots,F_m}")#text(" are measurable sets. Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^n a_i \\mu(E_i) = \\sum_{j=1}^m b_j \\mu(F_j).")]]

#text("(")#emph[#text("Hint:")]#text(" first handle the special case where the ")#mi("{F_j}")#text(" are all disjoint and non-empty, and each of the ")#mi("{E_i}")#text(" is expressible as the union of some subcollection of the ")#mi("{F_j}")#text(". Then handle the general case by considering the atoms of the finite boolean algebra generated by ")#mi("{E_i}")#text(" and ")#mi("{F_j}")#text(".)")
]

#text("We capture this invariant by introducing the ")#emph[#text("simple integral")]#text(" ")#mi("{\\text{Simp} \\int_{\\Omega} f\\ d\\mu}")#text(" of an unsigned simple function by the formula")

#align(center)[#tao-fit-display[#mitex("\\text{Simp} \\int_\\Omega f\\ d\\mu := \\sum_{i=1}^n a_i \\mu(E_i)")]]

#text("whenever ")#mi("{f}")#text(" admits a decomposition ")#mi("{f = \\sum_{i=1}^n a_i 1_{E_i}}")#text(". The above exercise is then precisely the assertion that the simple integral is well-defined as an element of ")#mi("{[0,+\\infty]}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Let ")#mi("{f, g: \\Omega \\rightarrow [0,+\\infty]}")#text(" be unsigned simple functions, and let ")#mi("{c \\in [0,+\\infty]}")#text(".")

#list(
[#text("(i) (Linearity) Show that")

#align(center)[#tao-fit-display[#mitex("\\text{Simp} \\int_\\Omega f+g\\ d\\mu = \\text{Simp} \\int_\\Omega f\\ d\\mu + \\text{Simp} \\int_\\Omega g\\ d\\mu")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\text{Simp} \\int_\\Omega cf\\ d\\mu = c \\text{Simp} \\int_\\Omega f\\ d\\mu.")]]],
[#text("(ii) Show that if ")#mi("{f}")#text(" and ")#mi("{g}")#text(" are equal almost everywhere, then")

#align(center)[#tao-fit-display[#mitex("\\text{Simp} \\int_\\Omega f\\ d\\mu = \\text{Simp} \\int_\\Omega g\\ d\\mu.")]]],
[#text("(iii) Show that ")#mi("{\\text{Simp} \\int_\\Omega f\\ d\\mu \\geq 0}")#text(", with equality if and only if ")#mi("{f}")#text(" is zero almost everywhere.")],
[#text("(iv) (Monotonicity) If ")#mi("{f \\leq g}")#text(" almost everywhere, show that ")#mi("{\\text{Simp} \\int_\\Omega f\\ d\\mu \\leq \\text{Simp} \\int_\\Omega g\\ d\\mu}")#text(".")],
[#text("(v) (Markov inequality) Show that ")#mi("{\\mu( \\{ \\omega: f(\\omega) \\geq t \\} ) \\leq \\frac{1}{t} \\text{Simp} \\int_\\Omega f\\ d\\mu}")#text(" for any ")#mi("{0 < t < \\infty}")#text(".")]
)
]

#text("Now we extend from unsigned simple functions to more general unsigned functions. If ")#mi("{f: \\Omega \\rightarrow [0,+\\infty]}")#text(" is an unsigned measurable function, we define the ")#emph[#text("unsigned integral")]#text(" ")#mi("{\\int_\\Omega f\\ d\\mu}")#text(" as ")#metadata(none) <tao-df65e7b4f08bb34916e4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\int_\\Omega f\\ d\\mu = \\sup_{0 \\leq g \\leq f} \\text{Simp} \\int_\\Omega g\\ d\\mu")]]

#text(" where the supremum is over all unsigned simple functions such that ")#mi("{0 \\leq g(\\omega) \\leq f(\\omega)}")#text(" for all ")#mi("{\\omega \\in \\Omega}")#text(".")

#text("Many of the properties of the simple integral carry over to the unsigned integral easily:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Let ")#mi("{f, g: \\Omega \\rightarrow [0,+\\infty]}")#text(" be unsigned measurable functions, and let ")#mi("{c \\in [0,+\\infty]}")#text(".")

#list(
[#text("(i) (Superadditivity) Show that")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega f+g\\ d\\mu \\geq \\int_\\Omega f\\ d\\mu + \\int_\\Omega g\\ d\\mu")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega cf\\ d\\mu = c \\int_\\Omega f\\ d\\mu.")]]],
[#text("(ii) Show that if ")#mi("{f}")#text(" and ")#mi("{g}")#text(" are equal almost everywhere, then")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega f\\ d\\mu = \\int_\\Omega g\\ d\\mu.")]]],
[#text("(iii) Show that ")#mi("{\\int_\\Omega f\\ d\\mu \\geq 0}")#text(", with equality if and only if ")#mi("{f}")#text(" is zero almost everywhere.")],
[#text("(iv) (Monotonicity) If ")#mi("{f \\leq g}")#text(" almost everywhere, show that ")#mi("{\\int_\\Omega f\\ d\\mu \\leq \\int_\\Omega g\\ d\\mu}")#text(".")],
[#text("(v) (Markov inequality) Show that ")#mi("{\\mu( \\{ \\omega: f(\\omega) \\geq t \\} ) \\leq \\frac{1}{t} \\int_\\Omega f\\ d\\mu}")#text(" for any ")#mi("{0 < t < \\infty}")#text(". In particular, if ")#mi("{\\int_\\Omega f\\ d\\mu < \\infty}")#text(", then ")#mi("{f}")#text(" is finite almost everywhere.")],
[#text("(vi) (Compatibility with simple integral) If ")#mi("{f}")#text(" is simple, show that ")#mi("{\\int_\\Omega f\\ d\\mu = \\text{Simp} \\int_\\Omega f\\ d\\mu}")#text(".")],
[#text("(vii) (Compatibility with measure) For any measurable set ")#mi("{E}")#text(", show that ")#mi("{\\int_\\Omega 1_E\\ d\\mu = \\mu(E)}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" ")#metadata(none) <tao-fa79d4746c21cd960a17>#text(" If ")#mi("{(\\Omega, (p_\\omega)_{\\omega \\in \\Omega})}")#text(" is a discrete probability space (with the associated probability measure ")#mi("{\\mu}")#text("), and ")#mi("{f: \\Omega \\rightarrow [0,+\\infty]}")#text(" is a function, show that")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega f\\ d\\mu = \\sum_{\\omega \\in\\Omega} f(\\omega) p_\\omega.")]]

#text("(Note that the condition ")#mi("{\\sum_{\\omega \\in \\Omega} p_\\omega = 1}")#text(" in the definition of a discrete probability space is not required to prove this identity.)")
]

#text("The observant reader will notice that the linearity property of simple functions has been weakened to superadditivity. This can be traced back to a breakdown of symmetry in the definition ")#link(<tao-df65e7b4f08bb34916e4>)[#text("(3)")]#text("; the unsigned simple integral of ")#mi("{f}")#text(" is defined via approximation from below, but not from above. Indeed the opposite claim ")#metadata(none) <tao-079cdc52e64462dfac51>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\int_\\Omega f\\ d\\mu \\stackrel{?}{=} \\inf_{g \\geq f} \\text{Simp} \\int_\\Omega g\\ d\\mu")]]

#text(" can fail. For a counterexample, take ")#mi("{\\Omega}")#text(" to be the discrete probability space ")#mi("{\\{1,2,3,\\dots\\}}")#text(" with probabilities ")#mi("{p_n := 2^{-n}}")#text(", and let ")#mi("{f: \\Omega \\rightarrow [0,+\\infty]}")#text(" be the function ")#mi("{f(n)=n}")#text(". By Exercise ")#link(<tao-fa79d4746c21cd960a17>)[#text("6")]#text(" we have ")#mi("{\\int_\\Omega f\\ d\\mu = \\sum_{n=1}^\\infty n2^{-n} = 2}")#text(". On the other hand, any simple function ")#mi("{g}")#text(" with ")#mi("{g \\geq f}")#text(" must equal ")#mi("{+\\infty}")#text(" on a set of positive measure (why?) and so the right-hand side of ")#link(<tao-079cdc52e64462dfac51>)[#text("(4)")]#text(" can be infinite. However, one can get around this difficulty under some further assumptions on ")#mi("{f}")#text(", and thus recover full linearity for the unsigned integral:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7 (Linearity of the unsigned integral)")]#text(" Let ")#mi("{(\\Omega, {\\mathcal F}, \\mu)}")#text(" be a measure space.")

#list(
[#text("(i) Let ")#mi("{f: \\Omega \\rightarrow [0,+\\infty]}")#text(" be an unsigned measurable function which is both bounded (i.e., there is a finite ")#mi("{M}")#text(" such that ")#tao-math("{\\left|f(\\omega)\\right| \\leq M}", block: false)#text(" for all ")#mi("{\\omega \\in \\Omega}")#text(") and has finite measure support (i.e., there is a measurable set ")#mi("{E}")#text(" with ")#mi("{\\mu(E) < \\infty}")#text(" such that ")#mi("{f(\\omega)=0}")#text(" for all ")#mi("{\\omega \\in \\Omega \\backslash E}")#text("). Show that ")#link(<tao-079cdc52e64462dfac51>)[#text("(4)")]#text(" holds for this function ")#mi("{f}")#text(".")],
[#text("(ii) Establish the additivity property")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega f+g\\ d\\mu =\\int_\\Omega f\\ d\\mu + \\int_\\Omega g\\ d\\mu")]]

#text("whenever ")#mi("{f, g: \\Omega \\rightarrow [0,+\\infty]}")#text(" are unsigned measurable functions that are bounded with finite measure support.")],
[#text("(iii) Show that")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega \\min(f,n)\\ d\\mu \\rightarrow \\int_\\Omega f\\ d\\mu")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" whenever ")#mi("{f: \\Omega \\rightarrow [0,+\\infty]}")#text(" is unsigned measurable.")],
[#text("(iv) Using (iii), extend (ii) to the case where ")#mi("{f,g}")#text(" are unsigned measurable functions with finite measure support, but are not necessarily bounded.")],
[#text("(v) Show that")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega f 1_{f \\geq 1/n}\\ d\\mu \\rightarrow \\int_\\Omega f\\ d\\mu")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" whenever ")#mi("{f: \\Omega \\rightarrow [0,+\\infty]}")#text(" is unsigned measurable.")],
[#text("(vi) Using (iii) and (v), show that (ii) holds for any unsigned measurable ")#mi("{f,g}")#text(" (which are not necessarily bounded or of finite measure support).")]
)
]

#text("Next, we apply the integral to absolutely integrable functions. We call a scalar function ")#mi("{f: \\Omega \\rightarrow {\\bf R}}")#text(" or ")#mi("{f: \\Omega \\rightarrow {\\bf C}}")#text(" ")#emph[#text("absolutely integrable")]#text(" if it is measurable and the unsigned integral ")#mi("{\\int_\\Omega |f|\\ d\\mu}")#text(" is finite. A real-valued absolutely integrable function ")#mi("{f}")#text(" can be expressed as the difference ")#mi("{f = f_1 - f_2}")#text(" of two ")#emph[#text("unsigned")]#text(" absolutely integrable functions ")#mi("{f_1,f_2}")#text("; indeed, one can check that the choice ")#mi("{f_1 := \\max(f,0)}")#text(" and ")#mi("{f_2 := \\max(-f,0)}")#text(" work for this. Conversely, any difference ")#mi("{f_1 - f_2}")#text(" of unsigned absolutely integrable functions ")#mi("{f_1,f_2}")#text(" is absolutely integrable (this follows from the triangle inequality ")#tao-math("{\\left|f_1-f_2\\right| \\leq \\left|f_1\\right|+\\left|f_2\\right|}", block: false)#text("). A single absolutely integrable function ")#mi("{f}")#text(" may be written as a difference ")#mi("{f_1-f_2}")#text(" of unsigned absolutely integrable functions in more than one way, for instance we might have")

#align(center)[#tao-fit-display[#mitex("f = f_1 - f_2 = g_1 - g_2")]]

#text("for unsigned absolutely integrable functions ")#mi("{f_1,f_2,g_1,g_2}")#text(". But when this happens, we can rearrange to obtain")

#align(center)[#tao-fit-display[#mitex("f_1 + g_2 = g_1 + f_2")]]

#text("and thus by linearity of the unsigned integral")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega f_1\\ d\\mu + \\int_\\Omega g_2\\ d\\mu = \\int_\\Omega g_1\\ d\\mu + \\int_\\Omega f_2\\ d\\mu.")]]

#text("By the absolute integrability of ")#mi("{f_1,f_2,g_1,g_2}")#text(", all the integrals are finite, so we may rearrange this identity as")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega f_1\\ d\\mu - \\int_\\Omega f_2\\ d\\mu = \\int_\\Omega g_1\\ d\\mu - \\int_\\Omega g_2\\ d\\mu.")]]

#text("This allows us to define the ")#link("https://en.wikipedia.org/wiki/Lebesgue_integration")[#text("Lebesgue integral")]#text(" ")#mi("{\\int_\\Omega f\\ d\\mu \\in {\\bf R}}")#text(" of a real-valued absolutely integrable function ")#mi("{f}")#text(" to be the expression")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega f\\ d\\mu := \\int_\\Omega f_1\\ d\\mu - \\int_\\Omega f_2\\ d\\mu")]]

#text("for any given decomposition ")#mi("{f = f_1-f_2}")#text(" of ")#mi("{f}")#text(" as the difference of two unsigned absolutely integrable functions. Note that if ")#mi("{f}")#text(" is both unsigned and absolutely integrable, then the unsigned integral and the Lebesgue integral of ")#mi("{f}")#text(" agree (as can be seen by using the decomposition ")#mi("{f = f - 0}")#text("), and so there is no ambiguity in using the same notation ")#mi("{\\int_\\Omega f\\ d\\mu}")#text(" to denote both integrals. (By the same token, we may now drop the modifier ")#mi("{\\text{Simp}}")#text(" from the simple integral of a simple unsigned ")#mi("{f}")#text(", which we may now also denote by ")#mi("{\\int_\\Omega f\\ d\\mu}")#text(".)")

#text("The Lebesgue integral also enjoys good linearity properties:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Let ")#mi("{f, g: \\Omega \\rightarrow {\\bf R}}")#text(" be real-valued absolutely integrable functions, and let ")#mi("{c \\in {\\bf R}}")#text(".")

#list(
[#text("(i) (Linearity) Show that ")#mi("{f+g}")#text(" and ")#mi("{cf}")#text(" are also real-valued absolutely integrable functions, with")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega f+g\\ d\\mu = \\int_\\Omega f\\ d\\mu + \\int_\\Omega g\\ d\\mu")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega cf\\ d\\mu = c \\int_\\Omega f\\ d\\mu.")]]

#text("(For the second relation, one may wish to first treat the special cases ")#mi("{c>0}")#text(" and ")#mi("{c=-1}")#text(".)")],
[#text("(ii) Show that if ")#mi("{f}")#text(" and ")#mi("{g}")#text(" are equal almost everywhere, then")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega f\\ d\\mu = \\int_\\Omega g\\ d\\mu.")]]],
[#text("(iii) Show that ")#mi("{\\int_\\Omega |f|\\ d\\mu \\geq 0}")#text(", with equality if and only if ")#mi("{f}")#text(" is zero almost everywhere.")],
[#text("(iv) (Monotonicity) If ")#mi("{f \\leq g}")#text(" almost everywhere, show that ")#mi("{\\int_\\Omega f\\ d\\mu \\leq\\int_\\Omega g\\ d\\mu}")#text(".")],
[#text("(v) (Markov inequality) Show that ")#tao-math("{\\mu( \\{ \\omega: \\left|f(\\omega)\\right| \\geq t \\} ) \\leq \\frac{1}{t} \\int_\\Omega |f|\\ d\\mu}", block: false)#text(" for any ")#mi("{0 < t < \\infty}")#text(".")]
)
]

#text("Because of part (ii) of the above exercise, we can extend the Lebesgue integral to real-valued absolutely integrable functions that are only defined and real-valued almost everywhere, rather than everywhere. In particular, we can apply the Lebesgue integral to functions that are sometimes infinite, so long as they are only infinite on a set of measure zero, and the function is absolutely integrable everywhere else.")

#text("Finally, we extend to complex-valued functions. If ")#mi("{f: \\Omega \\rightarrow {\\bf C}}")#text(" is absolutely integrable, observe that the real and imaginary parts ")#mi("{\\text{Re} f, \\text{Im} f: \\Omega \\rightarrow {\\bf C}}")#text(" are also absolutely integrable (because ")#tao-math("{\\left|\\text{Re} f\\right|, \\left|\\text{Im} f\\right| \\leq \\left|f\\right|}", block: false)#text("). We then define the (complex) Lebesgue integral ")#mi("{\\int_\\Omega f\\ d\\mu \\in {\\bf C}}")#text(" of ")#mi("{f}")#text(" in terms of the real Lebesgue integral by the formula")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega f\\ d\\mu := \\int_\\Omega \\text{Re}(f)\\ d\\mu + i \\int_\\Omega \\text{Im}(f)\\ d\\mu.")]]

#text("Clearly, if ")#mi("{f}")#text(" is real-valued and absolutely integrable, then the real Lebesgue integral and the complex Lebesgue integral of ")#mi("{f}")#text(" coincide, so it does not create ambiguity to use the same symbol ")#mi("{\\int_\\Omega f\\ d\\mu}")#text(" for both concepts. It is routine to extend the linearity properties of the real Lebesgue integral to its complex counterpart:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Let ")#mi("{f, g: \\Omega \\rightarrow {\\bf C}}")#text(" be complex-valued absolutely integrable functions, and let ")#mi("{c \\in {\\bf C}}")#text(".")

#list(
[#text("(i) (Linearity) Show that ")#mi("{f+g}")#text(" and ")#mi("{cf}")#text(" are also complex-valued absolutely integrable functions, with")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega f+g\\ d\\mu = \\int_\\Omega f\\ d\\mu + \\int_\\Omega g\\ d\\mu")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega cf\\ d\\mu = c \\int_\\Omega f\\ d\\mu.")]]

#text("(For the second relation, one may wish to first treat the special cases ")#mi("{c \\in {\\bf R}}")#text(" and ")#mi("{c = i}")#text(".)")],
[#text("(ii) Show that if ")#mi("{f}")#text(" and ")#mi("{g}")#text(" are equal almost everywhere, then")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega f\\ d\\mu = \\int_\\Omega g\\ d\\mu.")]]],
[#text("(iii) Show that ")#mi("{\\int_\\Omega |f|\\ d\\mu \\geq 0}")#text(", with equality if and only if ")#mi("{f}")#text(" is zero almost everywhere.")],
[#text("(iv) (Markov inequality) Show that ")#tao-math("{\\mu( \\{ \\omega: \\left|f(\\omega)\\right| \\geq t \\} ) \\leq \\frac{1}{t} \\int_\\Omega |f|\\ d\\mu}", block: false)#text(" for any ")#mi("{0 < t < \\infty}")#text(".")]
)
]

#text("We record a simple, but incredibly fundamental, inequality concerning the Lebesgue integral:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10 (Triangle inequality)")]#text(" If ")#mi("{f: \\Omega \\rightarrow {\\bf C}}")#text(" is a complex-valued absolutely integrable function, then")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_\\Omega f\\ d\\mu\\right| \\leq \\int_\\Omega |f|\\ d\\mu.", block: true)]]
]

#emph[#text("Proof:")]#text(" We have")

#tao-aligned(keep: true)[


#tao-math("\\text{Re} \\int_\\Omega f\\ d\\mu  & = \\int_\\Omega \\text{Re} f\\ d\\mu", block: true)



#tao-math(" & \\leq \\int_\\Omega |f|\\ d\\mu.", block: true)
]

#text("This looks weaker than what we want to prove, but we can “")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("amplify")]#text("” this inequality to the full strength triangle inequality as follows. Replacing ")#mi("{f}")#text(" by ")#mi("{e^{i\\theta} f}")#text(" for any real ")#mi("{\\theta}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\text{Re} e^{i\\theta} \\int_\\Omega f\\ d\\mu \\leq \\int_\\Omega |f|\\ d\\mu.")]]

#text("Since we can choose the phase ")#mi("{e^{i\\theta}}")#text(" to make the expression ")#mi("{e^{i\\theta} \\int_\\Omega f\\ d\\mu}")#text(" equal to ")#tao-math("{\\left|\\int_\\Omega f\\ d\\mu\\right|}", block: false)#text(", the claim follows. ")#mi("\\Box")

#text("Finally, we observe that the Lebesgue integral extends the Riemann integral, which is particularly useful when it comes to actually ")#emph[#text("computing")]#text(" some of these integrals:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" If ")#mi("{f: [a,b] \\rightarrow {\\bf C}}")#text(" is a Riemann integrable function on a compact interval ")#mi("{[a,b]}")#text(", show that ")#mi("{f}")#text(" is also absolutely integrable, and that the Lebesgue integral ")#mi("{\\int_{[a,b]} f\\ dm}")#text(" (with ")#mi("{m}")#text(" Lebesgue measure restricted to ")#mi("{[a,b]}")#text(") coincides with the Riemann integral ")#mi("{\\int_a^b f(x)\\ dx}")#text(". Similarly if ")#mi("{f}")#text(" is Riemann integrable on a box ")#mi("{[a_1,b_1] \\times \\dots \\times [a_n,b_n]}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 2. Expectation of random variables — ")]]

#text("We now translate the above notions of integration on measure spaces to the probabilistic setting.")

#text("A random variable ")#mi("{X}")#text(" taking values in the unsigned extended real line ")#mi("{[0,+\\infty]}")#text(" is said to be ")#emph[#text("simple")]#text(" if it takes on at most finitely many values. Equivalently, ")#mi("{X}")#text(" can be expressed as a finite unsigned linear combination")

#align(center)[#tao-fit-display[#mitex("X = \\sum_{i=1}^n a_i 1_{E_i}")]]

#text("of indicator random variables, where ")#mi("{a_1,\\dots,a_n \\in [0,+\\infty]}")#text(" are unsigned and ")#mi("{E_i}")#text(" are events. We then define the ")#emph[#text("simple expectation")]#text(" ")#mi("{\\text{Simp} {\\bf E} X \\in [0,+\\infty]}")#text(" of ")#mi("{X}")#text(" to be the quantity")

#align(center)[#tao-fit-display[#mitex("\\text{Simp} {\\bf E} X := \\sum_{i=1}^n a_i {\\bf P}(E_i),")]]

#text("and checks that this definition is independent of the choice of decomposition of ")#mi("{X}")#text(" into indicator functions. Observe that if we model the random variable ")#mi("{X}")#text(" using a probability space ")#mi("{\\Omega}")#text(", then the simple expectation of ")#mi("{X}")#text(" is precisely the simple integral of the corresponding unsigned simple function ")#mi("{X_\\Omega}")#text(".")

#text("Next, given an arbitrary unsigned random variable ")#mi("{X}")#text(" taking values in ")#mi("{[0,+\\infty]}")#text(", modeled by a probability space ")#mi("{\\Omega}")#text(" one defines its (unsigned) ")#emph[#text("expectation")]#text(" ")#mi("{{\\bf E} X \\in [0,+\\infty]}")#text(" as")

#align(center)[#tao-fit-display[#mitex("{\\bf E} X := \\sup_{0\\leq Y \\leq X} \\text{Simp} {\\bf E} Y")]]

#text("where ")#mi("{Y}")#text(" ranges over all simple unsigned random variables modeled by the same space ")#mi("{\\Omega}")#text(" such that ")#mi("{0 \\leq Y \\leq X}")#text(" is surely true. There is a subtle issue that this definition might in principle depend on the choice of ")#mi("{\\Omega}")#text(" (because this affects the pool of available simple unsigned random variables ")#mi("{Y}")#text("), but this is not the case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" ")#metadata(none) <tao-77f2f036726eaa17f75c>#text(" Let ")#mi("{X}")#text(" be a random variable taking values in ")#mi("{[0,+\\infty]}")#text(", and let ")#mi("{Y}")#text(" be a simple unsigned random variable such that ")#mi("{0 \\leq Y \\leq X}")#text(" is surely true. Show that there exists a function ")#mi("{f: [0,+\\infty] \\rightarrow [0,+\\infty]}")#text(" taking on finitely many values such that ")#mi("{Y \\leq f(X) \\leq X}")#text(" is surely true. Conclude in particular that the above definition of expectation does not depend on the choice of model ")#mi("{\\Omega}")#text(".")
]

#text("The expectation extends the simple expectation (thus ")#mi("{{\\bf E} X = \\text{Simp} {\\bf E} X}")#text(" for all simple unsigned ")#mi("{X}")#text("), and in terms of a probability space model ")#mi("{\\Omega}")#text(", the expectation ")#mi("{{\\bf E} X}")#text(" is precisely the unsigned integral of ")#mi("{X_\\Omega}")#text(". The expectation of a random variable is also often referred to as the ")#emph[#text("mean")]#text(", particularly in applications connected to statistics. In some literature ")#mi("{{\\bf E} X}")#text(" is also called the ")#emph[#text("expected value")]#text(" of ")#mi("{X}")#text(", but this is a somewhat misleading term as often one expects ")#mi("{X}")#text(" to deviate above or below ")#mi("{{\\bf E} X}")#text(".")

#text("A scalar random variable ")#mi("{X}")#text(" is said to be ")#emph[#text("absolutely integrable")]#text(" if ")#tao-math("{{\\bf E} \\left|X\\right| < \\infty}", block: false)#text(", thus for instance any bounded random variable is absolutely integrable. If ")#mi("{X}")#text(" is real-valued and absolutely integrable, we define its expectation by the formula")

#align(center)[#tao-fit-display[#mitex("{\\bf E} X := {\\bf E} X_1 - {\\bf E} X_2")]]

#text("where ")#mi("{X = X_1 - X_2}")#text(" is any representation of ")#mi("{X}")#text(" as the difference of unsigned absolutely integrable random variables ")#mi("{X_1,X_2}")#text("; one can check that this definition does not depend on the choice of representation and is thus well-defined. For complex-valued absolutely integrable ")#mi("{X}")#text(", we then define")

#align(center)[#tao-fit-display[#mitex("{\\bf E} X := {\\bf E} \\text{Re} X + i {\\bf E} \\text{Im} X.")]]

#text("In all of these cases, the expectation of ")#mi("{X}")#text(" is equal to the integral of the representation ")#mi("{X_\\Omega}")#text(" of ")#mi("{X}")#text(" in any probability space model; in the case that ")#mi("{\\Omega}")#text(" is given by a discrete probability model, one can check that this definition of expectation agrees with the one given in Notes 0. Using the former fact, we can translate the properties of integration already established to the probabilistic setting:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 13")]

#list(
[#text("(i) (Unsigned linearity) If ")#mi("{X,Y}")#text(" are unsigned random variables, and ")#mi("{c}")#text(" is a deterministic unsigned quantity, then ")#mi("{{\\bf E}(X+Y) = {\\bf E} X + {\\bf E} Y}")#text(" and ")#mi("{{\\bf E} cX = c {\\bf E} X}")#text(". (Note that these identities hold even when ")#mi("{X,Y}")#text(" are not absolutely integrable.)")],
[#text("(ii) (Complex linearity) If ")#mi("{X,Y}")#text(" are absolutely integrable random variables, and ")#mi("{c}")#text(" is a deterministic complex quantity, then ")#mi("{X+Y}")#text(" and ")#mi("{cX}")#text(" are also absolutely integrable, with ")#mi("{{\\bf E}(X+Y) = {\\bf E} X + {\\bf E} Y}")#text(" and ")#mi("{{\\bf E} cX = c {\\bf E} X}")#text(".")],
[#text("(iii) (Compatibility with probability) If ")#mi("{E}")#text(" is an event, then ")#mi("{{\\bf E} 1_E = {\\bf P}(E)}")#text(". In particular, ")#mi("{{\\bf E} 1 = 1}")#text(".")],
[#text("(iv) (Almost sure equivalence) If ")#mi("{X, Y}")#text(" are unsigned (resp. absolutely integrable) and ")#mi("{X=Y}")#text(" almost surely, then ")#mi("{{\\bf E} X = {\\bf E} Y}")#text(".")],
[#text("(v) If ")#mi("{X}")#text(" is unsigned or absolutely integrable, then ")#tao-math("{{\\bf E} \\left|X\\right| \\geq 0}", block: false)#text(", with equality if and only if ")#mi("{X=0}")#text(" almost surely.")],
[#text("(vi) (Monotonicity) If ")#mi("{X,Y}")#text(" are unsigned or real-valued absolutely integrable, and ")#mi("{X \\leq Y}")#text(" almost surely, then ")#mi("{{\\bf E} X \\leq {\\bf E} Y}")#text(".")],
[#text("(vii) (Markov inequality) If ")#mi("{X}")#text(" is unsigned or absolutely integrable, then ")#tao-math("{{\\bf P}(\\left|X\\right| \\geq t) \\leq \\frac{1}{t} {\\bf E} \\left|X\\right|}", block: false)#text(" for any deterministic ")#mi("{t>0}")#text(".")],
[#text("(viii) (Triangle inequality) If ")#mi("{X}")#text(" is absolutely integrable, then ")#tao-math("{\\left|{\\bf E} X\\right| \\leq {\\bf E} \\left|X\\right|}", block: false)#text(".")]
)
]

#text("As before, we can use part (iv) to define expectation of scalar random variables ")#mi("{X}")#text(" that are only defined and finite almost surely, rather than surely.")

#text("From Exercise ")#link(<tao-77f2f036726eaa17f75c>)[#text("12")]#text(", the notion of expectation is automatically probabilistic in the same sense. Because of this, we will be easily able to manipulate expectations of random variables without having to explicitly mention an underlying probability space ")#mi("{\\Omega}")#text(", and so one will now see such spaces fade from view starting from this point in the course.")

#heading(level: 1)[#strong[#text(" — 3. Exchanging limits with integrals or expectations — ")]]

#text("When performing analysis on measure spaces, it is important to know if one can interchange a limit with an integral:")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega \\lim_{n \\rightarrow \\infty} f_n\\ d\\mu \\stackrel{?}{=} \\lim_{n \\rightarrow \\infty} \\int_\\Omega f_n\\ d\\mu.")]]

#text("Similarly, in probability theory, we often wish to interchange a limit with an expectation:")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\lim_{n \\rightarrow \\infty} X_n \\stackrel{?}{=} \\lim_{n \\rightarrow \\infty} {\\bf E} X_n.")]]

#text("Of course, one needs the integrands or random variables to be either unsigned or absolutely integrable, and the limits to be well-defined to have any hope of doing this. Naively, one could hope that limits and integrals could always be exchanged when the expressions involved are well-defined, but this is unfortunately not the case. In the case of integration on, say, the real line ")#mi("{{\\bf R}}")#text(" using Lebesgue measure ")#mi("{m}")#text(", we already see four key examples:")

#list(
[#text("(Moving bump example) Take ")#mi("{f_n := 1_{[n,n+1]}}")#text(". Then ")#mi("{\\int_{\\bf R} \\lim_{n \\rightarrow \\infty} f_n\\ dm = 0}")#text(", but ")#mi("{\\lim_{n \\rightarrow \\infty} \\int_{\\bf R} f_n\\ dm = 1}")#text(".")],
[#text("(Spreading bump example) Take ")#mi("{f_n := \\frac{1}{n} 1_{[0,n]}}")#text(". Then ")#mi("{\\int_{\\bf R} \\lim_{n \\rightarrow \\infty} f_n\\ dm = 0}")#text(", but ")#mi("{\\lim_{n \\rightarrow \\infty} \\int_{\\bf R} f_n\\ dm = 1}")#text(".")],
[#text("(Concentrating bump example) Take ")#mi("{f_n := n 1_{[0,1/n]}}")#text(". Then ")#mi("{\\int_{\\bf R} \\lim_{n \\rightarrow \\infty} f_n\\ dm = 0}")#text(", but ")#mi("{\\lim_{n \\rightarrow \\infty} \\int_{\\bf R} f_n\\ dm = 1}")#text(".")],
[#text("(Receding infinity example) Take ")#mi("{f_n := 1_{[n,\\infty)}}")#text(". Then ")#mi("{\\int_{\\bf R} \\lim_{n \\rightarrow \\infty} f_n\\ dm = 0}")#text(", but ")#mi("{\\lim_{n \\rightarrow \\infty} \\int_{\\bf R} f_n\\ dm = +\\infty}")#text(".")]
)

#text("In all these examples, the limit of the integral exceeds the integral of the limit; by replacing ")#mi("{f_n}")#text(" with ")#mi("{-f_n}")#text(" in the first three examples (which involve absolutely integrable functions) one can also build examples where the limit of the integral is less than the integral of the limit. Most of these examples rely on the infinite measure of the real line and thus do not directly have probabilistic analogues, but the concentrating bump example involves functions that are all supported on the unit interval ")#mi("{[0,1]}")#text(" and thus also poses a problem in the probabilistic setting.")

#text("Nevertheless, there are three important cases in which we can relate the limit (or, in the case of Fatou’s lemma, the limit inferior) of the integral to the integral of the limit (or limit inferior). Informally, they are:")

#list(
[#text("(")#link("https://en.wikipedia.org/wiki/Fatou%27s_lemma")[#text("Fatou’s lemma")]#text(") For ")#emph[#text("unsigned")]#text(" ")#mi("{f_n}")#text(", the integral of the limit inferior cannot exceed the limit inferior of the integral. “Limits (or more precisely, limits inferior) can destroy (unsigned) mass, but cannot create it.”")],
[#text("(")#link("https://en.wikipedia.org/wiki/Monotone_convergence_theorem")[#text("Monotone convergence theorem")]#text(") For unsigned ")#emph[#text("monotone increasing")]#text(" ")#mi("{f_n}")#text(", the limit of the integral equals the integral of the limit.")],
[#text("(")#link("https://en.wikipedia.org/wiki/Dominated_convergence_theorem")[#text("Dominated convergence theorem")]#text(") For ")#mi("{f_n}")#text(" that are uniformly ")#emph[#text("dominated")]#text(" by an absolutely integrable function, the limit of the integral equals the integral of the limit.")]
)

#text("These three results then have analogues for convergence of random variables. We will also mention a fourth useful tool in that setting, which allows one to exchange limits and expectations when one controls a higher moment. There are a few more such general results allowing limits to be exchanged with integrals or expectations, but my advice would be to work out such exchanges by hand rather than blindly cite (possibly incorrectly) an additional convergence theorem beyond the four mentioned above, as this is safer and will help strengthen one’s intuition on the situation.")

#text("We now state and prove these results more explicitly.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 14 (Fatou’s lemma)")]#text(" Let ")#mi("{(\\Omega, {\\mathcal F}, \\mu)}")#text(" be a measure space, and let ")#mi("{f_1, f_2, \\dots: \\Omega \\rightarrow [0,+\\infty]}")#text(" be a sequence of unsigned measurable functions. Then")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega \\liminf_{n \\rightarrow \\infty} f_n\\ d\\mu \\leq \\liminf_{n \\rightarrow \\infty} \\int_\\Omega f_n\\ d\\mu.")]]
]

#text("An equivalent form of this lemma is that if one has")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega f_n\\ d\\mu \\leq M")]]

#text("for some ")#mi("{M}")#text(" and all sufficiently large ")#mi("{n}")#text(", then one has")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega \\liminf_{n \\rightarrow \\infty} f_n\\ d\\mu \\leq M")]]

#text("as well. That is to say, if the original unsigned functions ")#mi("{f_n}")#text(" eventually have “mass” less than or equal to ")#mi("{M}")#text(", then the limit (inferior) ")#mi("{\\liminf_{n \\rightarrow \\infty} f_n}")#text(" also has “mass” less than or equal to ")#mi("{M}")#text(". The limit may have substantially less mass, as the four examples above show, but it can never have ")#emph[#text("more")]#text(" mass (asymptotically) than the functions that comprise the limit. Of course, one can replace limit inferior by limit in the left or right hand side if one knows that the relevant limit actually exists (but one cannot replace limit inferior by limit superior if one does not already have convergence, see Example ")#link(<tao-a68357552b136db35b86>)[#text("16")]#text(" below). On the other hand, it is essential that the ")#mi("{f_n}")#text(" are unsigned for Fatou’s lemma to work, as can be seen by negating one of the first three key examples mentioned above.")

#emph[#text("Proof:")]#text(" By definition of the unsigned integral, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega g\\ d\\mu \\leq \\liminf_{n \\rightarrow \\infty} \\int_\\Omega f_n\\ d\\mu")]]

#text("whenever ")#mi("{g}")#text(" is an unsigned simple function with ")#mi("{g \\leq \\liminf_{n \\rightarrow \\infty} f_n}")#text(". At present, ")#mi("{g}")#text(" is allowed to take the infinite ")#mi("{+\\infty}")#text(", but it suffices to establish this claim for ")#mi("{g}")#text(" that only take finite values, since the claim then follows for possibly infinite-valued ")#mi("{g}")#text(" by applying the claim with ")#mi("{g}")#text(" replaced by ")#mi("{\\min(g,N)}")#text(" and then letting ")#mi("{N}")#text(" go to infinity.")

#text("Multiplying by ")#mi("{1-\\varepsilon}")#text(", it thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("(1-\\varepsilon) \\int_\\Omega g\\ d\\mu \\leq \\liminf_{n \\rightarrow \\infty} \\int_\\Omega f_n\\ d\\mu")]]

#text("for any ")#mi("{0 < \\varepsilon < 1}")#text(" and any unsigned ")#mi("{g}")#text(" as above.")

#text("We can write ")#mi("{g}")#text(" as the sum ")#mi("{g = \\sum_{i=1}^k a_i 1_{E_i}}")#text(" for some strictly positive finite ")#mi("{a_i}")#text(" and disjoint ")#mi("{E_i}")#text("; we allow the ")#mi("{a_i}")#text(" and the measures ")#mi("{\\mu(E_i)}")#text(" to be infinite. On each ")#mi("{E_i}")#text(", we have ")#mi("{\\liminf_{n \\rightarrow \\infty} f_n > (1-\\varepsilon) a_i}")#text(". Thus, if we define")

#align(center)[#tao-fit-display[#mitex("E_{i,N} := \\{ \\omega \\in E_i: f_n(\\omega) \\geq (1-\\varepsilon) a_i \\text{ for all } n \\geq N \\}")]]

#text("then the ")#mi("{E_{i,N}}")#text(" increase to ")#mi("{E_i}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(": ")#mi("{\\bigcup_{N=1}^\\infty E_{i,N} = E_i}")#text(". By continuity from below (Exercise 23 of ")#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")[#text("Notes 0")]#text("), we thus have")

#align(center)[#tao-fit-display[#mitex("\\mu(E_{i,N}) \\rightarrow \\mu(E_i)")]]

#text("as ")#mi("{N \\rightarrow \\infty}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("f_N \\geq \\sum_{i=1}^k (1-\\varepsilon) a_i 1_{E_{i,N}}")]]

#text("we conclude upon integration that")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega f_N\\ d\\mu \\geq \\sum_{i=1}^k (1-\\varepsilon) a_i \\mu( E_{i,N} )")]]

#text("and thus on taking limit inferior")

#align(center)[#tao-fit-display[#mitex("\\liminf_{N \\rightarrow \\infty} \\int_\\Omega f_N\\ d\\mu \\geq \\sum_{i=1}^k (1-\\varepsilon) a_i \\mu( E_i).")]]

#text("But the right-hand side is ")#mi("{(1-\\varepsilon) \\int_\\Omega g\\ d\\mu}")#text(", and the claim follows. ")#mi("\\Box")

#text("Of course, Fatou’s lemma may be phrased probabilistically:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 15 (Fatou’s lemma for random variables)")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be a sequence of unsigned random variables. Then")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\liminf_{n \\rightarrow \\infty} X_n \\leq \\liminf_{n \\rightarrow \\infty} {\\bf E} X_n.")]]
]

#text("As a corollary, if ")#mi("{X_1,X_2,\\dots}")#text(" are unsigned and converge almost surely to a random variable ")#mi("{Y}")#text(", then")

#align(center)[#tao-fit-display[#mitex("{\\bf E} Y \\leq \\liminf_{n \\rightarrow \\infty} {\\bf E} X_n.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 16")]#text(" ")#metadata(none) <tao-a68357552b136db35b86>#text(" We now give an example to show that limit inferior cannot be replaced with limit superior in Fatou’s lemma. Let ")#mi("{X}")#text(" be drawn uniformly at random from ")#mi("{[0,1]}")#text(", and for each ")#mi("{n}")#text(", let ")#mi("{X_n}")#text(" be the ")#mi("{n^{th}}")#text(" binary digit of ")#mi("{X}")#text(", thus ")#mi("{X_n = 1}")#text(" when ")#mi("{2^n X}")#text(" has odd integer part, and ")#mi("{X_n =0}")#text(" otherwise. (There is some ambiguity with the binary expansion when ")#mi("{X}")#text(" is a terminating binary decimal, but this event almost surely does not occur and can thus be safely ignored.) One has ")#mi("{{\\bf E} X_n = \\frac{1}{2}}")#text(" for all ")#mi("{n}")#text(" (why?). It is then easy to see that ")#mi("{\\liminf_{n \\rightarrow \\infty} X_n}")#text(" is almost surely ")#mi("{0}")#text(" (which is consistent with Fatou’s lemma) but ")#mi("{\\limsup_{n \\rightarrow \\infty} X_n}")#text(" is almost surely ")#mi("{1}")#text(" (so Fatou’s lemma fails if one replaces limit inferior with limit superior).")
]

#text("Next, we establish the monotone convergence theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 17 (Monotone convergence theorem)")]#text(" Let ")#mi("{(\\Omega, {\\mathcal F}, \\mu)}")#text(" be a measure space, and let ")#mi("{f_1, f_2, \\dots: \\Omega \\rightarrow [0,+\\infty]}")#text(" be a sequence of unsigned measurable functions which is monotone increasing, thus ")#mi("{f_n(\\omega) \\leq f_{n+1}(\\omega)}")#text(" for all ")#mi("{n}")#text(" and ")#mi("{\\omega \\in \\Omega}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega \\lim_{n \\rightarrow \\infty} f_n\\ d\\mu = \\lim_{n \\rightarrow \\infty} \\int_\\Omega f_n\\ d\\mu.")]]
]

#text("Note that the limits exist on both sides because monotone sequences always have limits. Indeed the limit in either side is equal to the supremum. The receding infinity example shows that it is important that the functions here are monotone increasing rather than monotone decreasing. We also observe that it is enough for the ")#mi("{f_n}")#text(" to be increasing almost everywhere rather than everywhere, since one can then modify the ")#mi("{f_n}")#text(" on a set of measure zero to be increasing everywhere, which does not affect the integrals on either side of this theorem.")

#emph[#text("Proof:")]#text(" From Fatou’s lemma we already have")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega \\lim_{n \\rightarrow \\infty} f_n\\ d\\mu \\leq \\lim_{n \\rightarrow \\infty} \\int_\\Omega f_n\\ d\\mu.")]]

#text("On the other hand, from monotonicity we see that")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega \\lim_{n \\rightarrow \\infty} f_n\\ d\\mu \\geq \\int_\\Omega f_m\\ d\\mu")]]

#text("for any natural number ")#mi("{m}")#text(", and on taking limits as ")#mi("{m \\rightarrow \\infty}")#text(" we obtain the claim. ")#mi("\\Box")

#text("Note that continuity from below for measures (Exercise 23.3 of ")#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")[#text("Notes 0")]#text(" can be viewed as the special case of the monotone convergence theorem when the functions ")#mi("{f_n}")#text(" are all indicator functions.)")

#text("An important corollary of the monotone convergence theorem is that one can freely interchange infinite sums with integrals for unsigned functions, that is to say")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega \\sum_{n=1}^\\infty g_n\\ d\\mu = \\sum_{n=1}^\\infty \\int_\\Omega g_n\\ d\\mu")]]

#text("for any unsigned ")#mi("{g_1,g_2,\\dots: \\Omega \\rightarrow [0,+\\infty]}")#text(" (not necessarily monotone). Indeed, to see this one simply applies the monotone convergence theorem to the partial sums ")#mi("{f_N := \\sum_{n=1}^N g_n}")#text(".")

#text("We of course can translate this into the probabilistic context:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 18 (Monotone convergence theorem for random variables)")]#text(" Let ")#mi("{0 \\leq X_1 \\leq X_2 \\leq \\dots}")#text(" be a monotone non-decreasing sequence of unsigned random variables. Then")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\lim_{n \\rightarrow \\infty} X_n = \\lim_{n \\rightarrow \\infty} {\\bf E} X_n.")]]

#text("Similarly, for any unsigned random variables ")#mi("{Y_1,Y_2,\\dots}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\sum_{n=1}^\\infty Y_n = \\sum_{n=1}^\\infty {\\bf E} Y_n.")]]
]

#text("Again, it is sufficient for the ")#mi("{X_n}")#text(" to be non-decreasing almost surely. We note a basic but important corollary of this theorem, namely the (first) ")#link("https://en.wikipedia.org/wiki/Borel%E2%80%93Cantelli_lemma")[#text("Borel-Cantelli lemma")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 19 (Borel-Cantelli lemma)")]#text(" Let ")#mi("{E_1,E_2,\\dots}")#text(" be a sequence of events with ")#mi("{\\sum_n {\\bf P}(E_n) < \\infty}")#text(". Then almost surely, at most finitely many of the events ")#mi("{E_n}")#text(" hold; that is to say, one has ")#mi("{\\sum_n 1_{E_n} < \\infty}")#text(" almost surely.")
]

#emph[#text("Proof:")]#text(" From the monotone convergence theorem, we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\sum_n 1_{E_n} = \\sum_n {\\bf E} 1_{E_n} = \\sum_n {\\bf P}(E_n) < \\infty.")]]

#text("By Markov’s inequality, this implies that ")#mi("{\\sum_n 1_{E_n}}")#text(" is almost surely finite, as required. ")#mi("\\Box")

#text("As the above proof shows, the Borel-Cantelli lemma is almost a triviality if one has the machinery of expectation (or integration); but it is remarkably hard to prove the lemma without that machinery, and it is an instructive exercise to attempt to do so.")

#text("We will develop a partial converse to the above lemma (the “second” Borel-Cantelli lemma) in a subsequent set of notes. For now, we give a crude converse in which we assume not only that the ")#mi("{{\\bf P}(E_n)}")#text(" sum to infinity, but they are in fact uniformly bounded from below:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Let ")#mi("{E_1,E_2,\\dots}")#text(" be a sequence of events with ")#mi("{\\inf_n {\\bf P}(E_n) > 0}")#text(". Show that with positive probability, an infinite number of the ")#mi("{E_n}")#text(" hold; that is to say, ")#mi("{\\mathop{\\bf P}( \\sum_n 1_{E_n} = \\infty ) > 0}")#text(". (")#emph[#text("Hint:")]#text(" if ")#mi("{{\\bf P}(E_n) \\geq \\delta > 0}")#text(" for all ")#mi("{n}")#text(", establish the lower bound ")#mi("{\\mathop{\\bf P}( \\sum_{n \\leq N} 1_{E_n} \\geq \\delta N/2 ) \\geq \\delta/2}")#text(" for all ")#mi("{N}")#text(". Alternatively, one can apply Fatou’s lemma to the random variables ")#mi("{1_{\\overline{E_n}}}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Let ")#mi("{p_1,p_2,\\dots \\in [0,1]}")#text(" be a sequence such that ")#mi("{\\sum_{n=1}^\\infty p_n = +\\infty}")#text(". Show that there exist a sequence of events ")#mi("{E_1,E_2,\\dots}")#text(" modeled by some probability space ")#mi("{\\Omega}")#text(", such that ")#mi("{{\\bf P}(E_n)=p_n}")#text(" for all ")#mi("{n}")#text(", and such that almost surely infinitely many of the ")#mi("{E_n}")#text(" occur. Thus we see that the hypothesis ")#mi("{\\sum_{n=1}^\\infty {\\bf P}(E_n) < \\infty}")#text(" in the Borel-Cantelli lemma cannot be relaxed.")
]

#text("Finally, we give the dominated convergence theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 22 (Dominated convergence theorem)")]#text(" Let ")#mi("{(\\Omega, {\\mathcal F}, \\mu)}")#text(" be a measure space, and let ")#mi("{f_1, f_2, \\dots: \\Omega \\rightarrow {\\bf C}}")#text(" be measurable functions which converge pointwise to some limit. Suppose that there is an unsigned absolutely integrable function ")#mi("{g: \\Omega \\rightarrow [0,+\\infty]}")#text(" which ")#emph[#text("dominates")]#text(" the ")#mi("{f_n}")#text(" in the sense that ")#tao-math("{\\left|f_n(\\omega)\\right| \\leq \\left|g(\\omega)\\right|}", block: false)#text(" for all ")#mi("{n}")#text(" and all ")#mi("{\\omega}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega \\lim_{n \\rightarrow \\infty} f_n\\ d\\mu = \\lim_{n \\rightarrow \\infty} \\int_\\Omega f_n\\ d\\mu.")]]

#text("In particular, the limit on the right-hand side exists.")
]

#text("Again, it will suffice for ")#mi("{g}")#text(" to dominate each ")#mi("{f_n}")#text(" almost everywhere rather than everywhere, as one can upgrade this to everywhere domination by modifying each ")#mi("{f_n}")#text(" on a set of measure zero. Similarly, pointwise convergence can be replaced with pointwise convergence almost everywhere. The domination of each ")#mi("{f_n}")#text(" by a single function ")#mi("{g}")#text(" implies that the integrals ")#mi("{\\int_\\Omega |f_n|\\ d\\mu}")#text(" are uniformly bounded in ")#mi("{n}")#text(", but this latter condition is not sufficient by itself to guarantee interchangeability of the limit and integral, as can be seen by the first three examples given at the start of this section.")

#emph[#text("Proof:")]#text(" By splitting into real and imaginary parts, we may assume without loss of generality that the ")#mi("{f_n}")#text(" are real-valued. As ")#mi("{g}")#text(" is absolutely integrable, it is finite almost everywhere; after modification on a set of measure zero we may assume it is finite everywhere. Let ")#mi("{f}")#text(" denote the pointwise limit of the ")#mi("{f_n}")#text(". From Fatou’s lemma applied to the unsigned functions ")#mi("{g-f_n}")#text(" and ")#mi("{g+f_n}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega g-f\\ d\\mu \\leq \\liminf_{n \\rightarrow \\infty} \\int_\\Omega g-f_n\\ d\\mu")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega g+f\\ d\\mu \\leq \\liminf_{n \\rightarrow \\infty} \\int_\\Omega g+f_n\\ d\\mu")]]

#text("Rearranging this (taking crucial advantage of the finite nature of the ")#mi("{\\int_\\Omega g\\ d\\mu}")#text(", and hence ")#mi("{\\int_\\Omega f\\ d\\mu}")#text(" and ")#mi("{\\int_\\Omega f_n\\ d\\mu}")#text("), we conclude that")

#align(center)[#tao-fit-display[#mitex("\\limsup_{n \\rightarrow \\infty} \\int_\\Omega f_n\\ d\\mu \\leq \\int_\\Omega f\\ d\\mu \\leq \\liminf_{n \\rightarrow\\infty} \\int_\\Omega f_n\\ d\\mu")]]

#text("and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 23")]#text(" Amusingly, one can use the dominated convergence theorem to give an (extremely indirect) proof of the divergence of the harmonic series ")#mi("{\\sum_{n=1}^\\infty \\frac{1}{n}}")#text(". For, if that series was convergent, then the function ")#mi("{\\sum_{n=1}^\\infty \\frac{1}{n} 1_{[n-1,n]}}")#text(" would be absolutely integrable, and the spreading bump example described above would contradict the dominated convergence theorem. (Expert challenge: see if you can deconstruct the above argument enough to lower bound the rate of divergence of the harmonic series ")#mi("{\\sum_{n=1}^\\infty \\frac{1}{n}}")#text(".)")
]

#text("We again translate the above theorem to the probabilistic context:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 24 (Dominated convergence theorem for random variables)")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be scalar random variables which converge almost surely to a limit ")#mi("{X}")#text(". Suppose there is an unsigned absolutely integrable random variable ")#mi("{Y}")#text(" such that ")#tao-math("{\\left|X_n\\right| \\leq Y}", block: false)#text(" almost surely for each ")#mi("{n}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} {\\bf E} X_n = {\\bf E} X.")]]
]

#text("As a corollary of the dominated convergence theorem for random variables we have the ")#emph[#text("bounded convergence theorem")]#text(": if ")#mi("{X_1,X_2,\\dots}")#text(" are scalar random variables that converge almost surely to a limit ")#mi("{X}")#text(", and are almost surely bounded in magnitude by a uniform constant ")#mi("{M}")#text(", then we have")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} {\\bf E} X_n = {\\bf E} X.")]]

#text("(In Durrett, the bounded convergence theorem is proven first, and then used to establish Fatou’s theorem and the dominated and monotone convergence theorems. The order in which one establishes these results – which are all closely related to each other – is largely a matter of personal taste.) A closely related corollary (which can also be established directly is that if ")#mi("{X_n}")#text(" are scalar absolutely integrable random variables that converge ")#emph[#text("uniformly")]#text(" to ")#mi("{X}")#text(" (thus, for each ")#mi("{\\varepsilon>0}")#text(" there is ")#mi("{N>0}")#text(" such that ")#tao-math("{\\left|X_n-X\\right| \\leq \\varepsilon}", block: false)#text(" is surely true for all ")#mi("{n \\geq N}")#text("), then ")#mi("{{\\bf E} X_n}")#text(" converges to ")#mi("{{\\bf E} X}")#text(".")

#text("A further corollary of the dominated convergence theorem is that one has the identity")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\sum_n Y_n = \\sum_n {\\bf E} Y_n")]]

#text("whenever ")#mi("{Y_n}")#text(" are scalar random variables with ")#tao-math("{\\sum_n \\left|Y_n\\right|}", block: false)#text(" absolutely integrable (or equivalently, that ")#tao-math("{\\sum_n {\\bf E} \\left|Y_n\\right|}", block: false)#text(" is finite).")

#text("Another useful variant of the dominated convergence theorem is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 25 (Convergence for random variables with bounded moment)")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be scalar random variables which converge almost surely to a limit ")#mi("{X}")#text(". Suppose there is ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{M>0}")#text(" such that ")#tao-math("{{\\bf E} \\left|X_n\\right|^{1+\\varepsilon} \\leq M}", block: false)#text(" for all ")#mi("{n}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} {\\bf E} X_n = {\\bf E} X.")]]
]

#text("This theorem fails for ")#mi("{\\varepsilon=0}")#text(", as the concentrating bump example shows. The case ")#mi("{\\varepsilon=1}")#text(" (that is to say, bounded second moment ")#tao-math("{{\\bf E} \\left|X_n\\right|^2}", block: false)#text(") is already quite useful. The intuition here is that concentrating bumps are in some sense the ")#emph[#text("only")]#text(" obstruction to interchanging limits and expectations, and these can be eliminated by hypotheses such as a bounded higher moment hypothesis or a domination hypothesis.")

#emph[#text("Proof:")]#text(" By taking real and imaginary parts we may assume that the ")#mi("{X_n}")#text(" (and hence ")#mi("{X}")#text(") are real-valued. For any natural number ")#mi("{m}")#text(", let ")#mi("{X_n^{[m]}}")#text(" denote the truncation ")#mi("{X_n^{[m]} := \\max(\\min(X_n,m),-m)}")#text(" of ")#mi("{X_n}")#text(" to the interval ")#mi("{[-m,m]}")#text(", and similarly define ")#mi("{X^{[m]} := \\max(\\min(X,m),-m)}")#text(". Then ")#mi("{X_n^{[m]}}")#text(" converges pointwise to ")#mi("{X^{[m]}}")#text(", and hence by the bounded convergence theorem")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\infty} {\\bf E} X_n^{[m]} = {\\bf E} X^{[m]}.")]]

#text("On the other hand, we have")

#align(center)[#tao-fit-display[#tao-math("\\left|X_n - X_n^{[m]}\\right| \\leq m^{-\\varepsilon} \\left|X_n\\right|^{1+\\varepsilon}", block: true)]]

#text("(why?) and thus on taking expectations and using the triangle inequality")

#align(center)[#tao-fit-display[#mitex("{\\bf E} X_n = {\\bf E} X_n^{[m]} + O( m^{-\\varepsilon} M )")]]

#text("where we are using the asymptotic notation ")#mi("{O(X)}")#text(" to denote a quantity bounded in magnitude by ")#mi("{CX}")#text(" for an absolute constant ")#mi("{C}")#text(". Also, from Fatou’s lemma we have")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|X\\right|^{1+\\varepsilon} \\leq M", block: true)]]

#text("so we similarly have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} X = {\\bf E} X^{[m]} + O( m^{-\\varepsilon} M )")]]

#text("Putting all this together, we see that")

#align(center)[#tao-fit-display[#mitex("\\liminf_{n \\rightarrow \\infty} {\\bf E} X_n, \\limsup_{n \\rightarrow \\infty} {\\bf E} X_n = {\\bf E} X + O( m^{-\\varepsilon} M ).")]]

#text("Sending ")#mi("{m \\rightarrow \\infty}")#text(", we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 26")]#text(" The essential point about the condition ")#tao-math("{{\\bf E} \\left|X_n\\right|^{1+\\varepsilon}}", block: false)#text(" was that the function ")#mi("{x \\mapsto x^{1+\\varepsilon}}")#text(" grew faster than linearly as ")#mi("{x \\rightarrow \\infty}")#text(". One could accomplish the same result with any other function with this property, e.g. a hypothesis such as ")#tao-math("{{\\bf E} |X_n| \\log \\left|X_n\\right| \\leq M}", block: false)#text(" would also suffice. The most natural general condition to impose here is that of ")#link("https://en.wikipedia.org/wiki/Uniform_integrability")[#text("uniform integrability")]#text(", which encompasses the hypotheses already mentioned, but we will not focus on this condition here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27 (Scheffé’s lemma)")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be a sequence of absolutely integrable scalar random variables that converge almost surely to another absolutely integrable scalar random variable ")#mi("{X}")#text(". Suppose also that ")#tao-math("{{\\bf E} \\left|X_n\\right|}", block: false)#text(" converges to ")#tao-math("{{\\bf E} \\left|X\\right|}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". Show that ")#tao-math("{{\\bf E} \\left|X-X_n\\right|}", block: false)#text(" converges to zero as ")#mi("{n \\rightarrow \\infty}")#text(". (")#emph[#text("Hint:")]#text(" there are several ways to prove this result, known as ")#link("https://en.wikipedia.org/wiki/Scheff%C3%A9%E2%80%99s_lemma")[#text("Scheffe’s lemma")]#text(". One is to split ")#mi("{X_n}")#text(" into two components ")#mi("{X_n = X_{n,1} + X_{n,2}}")#text(", such that ")#mi("{X_{n,1}}")#text(" is dominated by ")#tao-math("{\\left|X\\right|}", block: false)#text(" but converges almost surely to ")#mi("{X}")#text(", and ")#mi("{X_{n,2}}")#text(" is such that ")#tao-math("{\\left|X_n\\right| = \\left|X_{n,1}\\right| + \\left|X_{n,2}\\right|}", block: false)#text(". Then apply the dominated convergence theorem.)")
]

#heading(level: 1)[#strong[#text(" — 4. The distribution of a random variable — ")]]

#text("We have seen that the expectation of a random variable is a special case of the more general notion of Lebesgue integration on a measure space. There is however another way to think of expectation as a special case of integration, which is particularly convenient for ")#emph[#text("computing")]#text(" expectations. We first need the following definition.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 28")]#text(" Let ")#mi("{X}")#text(" be a random variable taking values in a measurable space ")#mi("{R = (R, {\\mathcal B})}")#text(". The ")#link("https://en.wikipedia.org/wiki/Probability_distribution")[#text("distribution")]#text(" of ")#mi("{X}")#text(" (also known as the ")#emph[#text("law")]#text(" of ")#mi("{X}")#text(") is the probability measure ")#mi("{\\mu_X}")#text(" on ")#mi("{R}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\mu_X(S) := {\\bf P}( X \\in S )")]]

#text("for all measurable sets ")#mi("{S \\in {\\mathcal B}}")#text("; one easily sees from the Kolmogorov axioms that this is indeed a probability measure.")
]

#text("In the language of measure theory, the distribution ")#mi("{\\mu_X}")#text(" on ")#mi("{S}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Pushforward_measure")[#text("push-forward")]#text(" of the probability measure ")#mi("{{\\bf P}}")#text(" on the sample space ")#mi("{\\Omega}")#text(" by the model ")#mi("{X_\\Omega: \\Omega \\rightarrow R}")#text(" of ")#mi("{X}")#text(" on that sample space.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 29")]#text(" If ")#mi("{X}")#text(" only takes on at most countably many values (and if every point in ")#mi("{R}")#text(" is measurable), then the distribution ")#mi("{\\mu_X}")#text(" is the discrete measure that assigns each point ")#mi("{a}")#text(" in the range of ")#mi("{X}")#text(" a measure of ")#mi("{{\\bf P}(X=a)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 30")]#text(" If ")#mi("{X}")#text(" is a real random variable with cumulative distribution function ")#mi("{F}")#text(", then ")#mi("{\\mu_X}")#text(" is the Lebesgue-Stieltjes measure associated to ")#mi("{F}")#text(". For instance, if ")#mi("{X}")#text(" is drawn uniformly at random from ")#mi("{[0,1]}")#text(", then ")#mi("{\\mu_X}")#text(" is Lebesgue measure restricted to ")#mi("{[0,1]}")#text(". In particular, two scalar variables are equal in distribution if and only if they have the same cumulative distribution function.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 31")]#text(" If ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are the results of two separate rolls of a fair die (as in Example 3 of ")#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")[#text("Notes 0")]#text("), then ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are equal in distribution, but are not equal as random variables.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 32")]#text(" ")#metadata(none) <tao-12901dece9ce1f866e4a>#text(" In the converse direction, given a probability measure ")#mi("{\\mu}")#text(" on a measurable space ")#mi("{(R, {\\mathcal B})}")#text(", one can always build a probability space model and a random variable ")#mi("{X}")#text(" represented by that model whose distribution is ")#mi("{\\mu}")#text(". Indeed, one can perform the “tautological” construction of defining the probability space model to be ")#mi("{\\Omega := (R, {\\mathcal B}, \\mu)}")#text(", and ")#mi("{X: \\Omega \\rightarrow R}")#text(" to be the identity function ")#mi("{X(\\omega) := \\omega}")#text(", and then one easily checks that ")#mi("{\\mu_X = \\mu}")#text(". Compare with Corollaries 26 and 29 of ")#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")[#text("Notes 0")]#text(". Furthermore, one can view this tautological model as a “base” model for random variables of distribution ")#mi("{\\mu}")#text(" as follows. Suppose one has a random variable ")#mi("{X}")#text(" of distribution ")#mi("{\\mu}")#text(" which is modeled by some other probability space ")#mi("{\\Omega^{\\prime} := (\\Omega^{\\prime}, {\\mathcal F}^{\\prime}, \\mu^{\\prime})}")#text(", thus ")#mi("{X_{\\Omega^{\\prime}}: \\Omega^{\\prime} \\rightarrow R}")#text(" is a measurable function such that")

#align(center)[#tao-fit-display[#mitex("\\mu(S) = {\\bf P}(X \\in S) = \\mu^{\\prime}( \\{ \\omega^{\\prime} \\in \\Omega^{\\prime}: X_{\\Omega^{\\prime}}(\\omega^{\\prime}) \\in S \\})")]]

#text("for all ")#mi("{S \\in {\\mathcal B}}")#text(". Then one can view the probability space ")#mi("{\\Omega^{\\prime}}")#text(" as an extension of the tautological probability space ")#mi("{\\Omega = (R, {\\mathcal B}, \\mu)}")#text(" using ")#mi("{X_{\\Omega^{\\prime}}}")#text(" as the factor map.")
]

#text("We say that two random variables ")#mi("{X,Y}")#text(" are ")#emph[#text("equal in distribution")]#text(", and write ")#mi("{X \\stackrel{d}{=} Y}")#text(", if they have the same law: ")#mi("{\\mu_X = \\mu_Y}")#text(", that is to say ")#mi("{{\\bf P}(X \\in S) = {\\bf P}(Y \\in S)}")#text(" for any measurable set ")#mi("{S}")#text(" in the range. This definition makes sense even when ")#mi("{X,Y}")#text(" are defined on different sample spaces. Roughly speaking, the distribution captures the “size” and “shape” of the random variable, but not its “location” or how it relates to other random variables. We also say that ")#mi("{Y}")#text(" is a ")#emph[#text("copy")]#text(" of ")#mi("{X}")#text(" if they are equal in distribution. For instance, the two dice rolls in Example 3 of ")#link("https://terrytao.wordpress.com/2015/09/29/275a-notes-0-foundations-of-probability-theory/")[#text("Notes 0")]#text(" are copies of each other.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 33 (Change of variables formula)")]#text(" Let ")#mi("{X}")#text(" be a random variable taking values in a measurable space ")#mi("{R = (R, {\\mathcal B})}")#text(". Let ")#mi("{f: R \\rightarrow {\\bf R}}")#text(" or ")#mi("{f: R \\rightarrow {\\bf C}}")#text(" be a measurable scalar function (giving ")#mi("{{\\bf R}}")#text(" or ")#mi("{{\\bf C}}")#text(" the Borel ")#mi("{\\sigma}")#text("-algebra of course) such that either ")#mi("{f \\geq 0}")#text(", or that ")#tao-math("{{\\bf E} \\left|f(X)\\right| < \\infty}", block: false)#text(". Then")

#align(center)[#tao-fit-display[#mitex("{\\bf E} f(X) = \\int_R f(x)\\ d\\mu_X(x).")]]
]

#text("Thus for instance, if ")#mi("{X}")#text(" is a real random variable, then")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|X\\right| = \\int_{\\bf R} |x|\\ d\\mu_X(x),", block: true)]]

#text("and more generally")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|X\\right|^p = \\int_{\\bf R} \\left|x\\right|^p\\ d\\mu_X(x)", block: true)]]

#text("for all ")#mi("{0 < p < \\infty}")#text("; furthermore, if ")#mi("{X}")#text(" is unsigned or absolutely integrable, one has")

#align(center)[#tao-fit-display[#mitex("{\\bf E} X = \\int_{\\bf R} x\\ d\\mu_X(x).")]]

#text("The point here is that the integration is not over some unspecified sample space ")#mi("{\\Omega}")#text(", but over a very explicit domain, namely the reals; we have “changed variables” to integrate over ")#mi("{{\\bf R}}")#text(" instead over ")#mi("{\\Omega}")#text(", with the distribution ")#mi("{\\mu_X}")#text(" representing the “Jacobian” factor that typically shows up in such change of variables formulae.")

#text("If ")#mi("{X}")#text(" is a scalar variable that only takes on at most countably many values ")#mi("{x_1,x_2,\\dots}")#text(", the change of variables formula tells us that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} X = \\sum_i x_i {\\bf P}(X=x_i)")]]

#text("if ")#mi("{X}")#text(" is unsigned or absolutely integrable.")

#emph[#text("Proof:")]#text(" First suppose that ")#mi("{f}")#text(" is unsigned and only takes on a finite number ")#mi("{a_1,\\dots,a_n}")#text(" of values. Then")

#align(center)[#tao-fit-display[#mitex("f(X) = \\sum_{i=1}^n a_i 1_{f(X)=a_i}")]]

#text("and hence")

#tao-aligned(keep: true)[


#tao-math("{\\bf E} f(X)  & = \\sum_{i=1}^n a_i {\\bf P}(f(X)=a_i)", block: true)



#tao-math(" & = \\sum_{i=1}^n a_i \\mu_X( \\{ x: f(x) = a_i\\} )", block: true)



#tao-math(" & = \\int_R \\sum_{i=1}^n a_i 1_{f(x)=a_i}\\ d\\mu_X(x)", block: true)



#tao-math(" & = \\int_R f(x)\\ d\\mu_X(x)", block: true)
]

#text("as required.")

#text("Next, suppose that ")#mi("{f}")#text(" is unsigned but can take on infinitely many values. We can express ")#mi("{f}")#text(" as the monotone increasing limit of functions ")#mi("{f_n}")#text(" that only take a finite number of values; for instance we can define ")#mi("{f_n(x)}")#text(" to be ")#mi("{f(x)}")#text(" rounded down to the largest multiple of ")#mi("{1/n}")#text(" less than both ")#mi("{n}")#text(" and ")#mi("{f(x)}")#text(". By the preceding computation, we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} f_n(X) = \\int_R f_n(x)\\ d\\mu_X(x),")]]

#text("and on taking limits as ")#mi("{n \\rightarrow \\infty}")#text(" using the monotone convergence theorem we obtain the claim in this case.")

#text("Now suppose that ")#mi("{f}")#text(" is real-valued with ")#tao-math("{{\\bf E} \\left|f(X)\\right| < \\infty}", block: false)#text(". We write ")#mi("{f = f_1 - f_2}")#text(" where ")#mi("{f_1 := \\max(f,0)}")#text(" and ")#mi("{f_2 := -\\min(f,0)}")#text(", then we have ")#mi("{{\\bf E} f_1(X), {\\bf E} f_2(X) < \\infty}")#text(" and")

#align(center)[#tao-fit-display[#mitex("{\\bf E} f_i(X) = \\int_{\\bf R} f_i(x)\\ d\\mu_X(x)")]]

#text("for ")#mi("{i=1,2}")#text(". Subtracting these two identities together, we obtain the claim.")

#text("Finally, the case of complex-valued ")#mi("{f}")#text(" with ")#tao-math("{{\\bf E} \\left|f(X)\\right| < \\infty}", block: false)#text(" follows from the real-valued case by taking real and imaginary parts. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 34")]#text(" Let ")#mi("{X}")#text(" be the uniform distribution on ")#mi("{[0,1]}")#text(", then")

#align(center)[#tao-fit-display[#mitex("{\\bf E} f(X) = \\int_0^1 f(x)\\ dx")]]

#text("for any Riemann integrable ")#mi("{f}")#text("; thus for instance")

#align(center)[#tao-fit-display[#mitex("{\\bf E} X^p = \\frac{1}{p+1}")]]

#text("for any ")#mi("{0 < p < \\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 35")]#text(" An alternate way to prove the change of variables formula is to observe that the formula is obviously true when one uses the tautological model ")#mi("{(R, {\\mathcal B}, \\mu_X)}")#text(" for ")#mi("{X}")#text(", and then the claim follows from the model-independence of expectation and the observation from Remark ")#link(<tao-12901dece9ce1f866e4a>)[#text("32")]#text(" that any other model for ")#mi("{X}")#text(" is an extension of the tautological model.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36")]#text(" Let ")#mi("{f: {\\bf R} \\rightarrow [0,+\\infty]}")#text(" be a measurable function with ")#mi("{\\int_{\\bf R} f(x)\\ dx = 1}")#text(". If one defines ")#mi("{m_f(E)}")#text(" for any Borel subset ")#mi("{E}")#text(" of ")#mi("{{\\bf R}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("m_f(E) := \\int_E f(x)\\ dx,")]]

#text("show that ")#mi("{m_f}")#text(" is a probability measure on ")#mi("{{\\bf R}}")#text(" with Stieltjes measure function ")#mi("{F(t) = \\int_{-\\infty}^t f(x)\\ dx}")#text(". If ")#mi("{X}")#text(" is a real random variable with probability distribution ")#mi("{m_f}")#text(" (in which case we call ")#mi("{X}")#text(" a random variable with an ")#link("https://en.wikipedia.org/wiki/Absolute_continuity#Absolute_continuity_of_measures")[#text("absolutely continuous")]#text(" distribution, and ")#mi("{f}")#text(" the ")#link("https://en.wikipedia.org/wiki/Probability_density_function")[#text("probability density function")]#text(" (PDF) of ")#mi("{X}")#text("), show that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} G(X) = \\int_{\\bf R} G(x) f(x)\\ dx")]]

#text("when either ")#mi("{G: {\\bf R} \\rightarrow [0,+\\infty]}")#text(" is an unsigned measurable function, or ")#mi("{G: {\\bf R} \\rightarrow {\\bf C}}")#text(" is measurable with ")#mi("{G(X)}")#text(" absolutely integrable (or equivalently, that ")#mi("{\\int_{\\bf R} |G(x)| f(x)\\ dx < \\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" Let ")#mi("{X}")#text(" be a real random variable with the probability density function ")#mi("{x \\mapsto \\frac{1}{\\sqrt{2\\pi}} e^{-x^2/2}}")#text(" of the standard normal distribution. Establish the ")#emph[#text("Stein identity")]

#align(center)[#tao-fit-display[#mitex("{\\bf E} X F(X) = {\\bf E} F^{\\prime}(X)")]]

#text("whenever ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a continuously differentiable function with ")#mi("{F}")#text(" and ")#mi("{F^{\\prime}}")#text(" both of polynomial growth (i.e., there exist constants ")#mi("{C, A > 0}")#text(" such that ")#tao-math("{\\left|F(t)\\right|, \\left|F^{\\prime}(t)\\right| \\leq C (1+\\left|t\\right|)^A}", block: false)#text(" for all ")#mi("{t \\in {\\bf R}}")#text("). There is a robust converse to this identity which underpins the basis of ")#link("https://en.wikipedia.org/wiki/Stein%27s_method")[#text("Stein’s method")]#text(", discussed in ")#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/")[#text("this previous blog post")]#text(". Use this identity recursively to establish the identities")

#align(center)[#tao-fit-display[#mitex("{\\bf E} X^k = 0")]]

#text("when ")#mi("{k}")#text(" is an odd natural number and")

#align(center)[#tao-fit-display[#mitex("{\\bf E} X^k = (k-1) (k-3) \\dots 1 = \\frac{k!}{2^{k/2} (k/2)!}")]]

#text("when ")#mi("{k}")#text(" is an even natural number. (This quantity is also known as the ")#link("https://en.wikipedia.org/wiki/Double_factorial")[#text("double factorial")]#text(" ")#mi("{(k-1)!!}")#text(" of ")#mi("{k-1}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38")]#text(" Let ")#mi("{X}")#text(" be a real random variable with cumulative distribution function ")#mi("{F_X(x) := {\\bf P}(X \\leq x)}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} e^{tX} = \\int_{\\bf R} (1-F_X(x)) t e^{tx}\\ dx")]]

#text("for all ")#mi("{t > 0}")#text(". If ")#mi("{X}")#text(" is nonnegative, show that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} X^p = \\int_0^\\infty (1-F_X(x)) p x^{p-1}\\ dx")]]

#text("for all ")#mi("{p>0}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 5. Some basic inequalities — ")]]

#text("The change of variables formula allows us, in principle at least, to compute the expectation ")#mi("{{\\bf E} X}")#text(" of a scalar random variable as an integral. In very simple situations, for instance when ")#mi("{X}")#text(" has one of the standard distributions (e.g. uniform, gaussian, binomial, etc.), this allows us to compute such expectations exactly. However, once one gets to more complicated situations, one usually does not expect to be able to evaluate the required integrals in closed form. In such situations, it is often more useful to have some general ")#emph[#text("inequalities")]#text(" concerning expectation, rather than ")#emph[#text("identities")]#text(".")

#text("We therefore record here for future reference some basic inequalities concerning expectation that we will need in the sequel. We have already seen the triangle inequality ")#metadata(none) <tao-0a3f13c673af2389ecb9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left|{\\bf E} X\\right| \\leq {\\bf E} \\left|X\\right|", block: true)]]

#text(" for absolutely integrable ")#mi("{X}")#text(", and the ")#link("https://en.wikipedia.org/wiki/Markov%27s_inequality")[#text("Markov inequality")]#text(" ")#metadata(none) <tao-43cedaa98924112f2f89>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("{\\bf P}(\\left|X\\right| \\geq t) \\leq \\frac{1}{t} {\\bf E} \\left|X\\right|", block: true)]]

#text(" for arbitrary scalar ")#mi("{X}")#text(" and ")#mi("{t>0}")#text(" (note the inequality is trivial if ")#mi("{X}")#text(" is not absolutely integrable). Applying the triangle inequality to the difference ")#mi("{X-Y}")#text(" of two absolutely integrable random variables ")#mi("{X,Y}")#text(", we obtain the variant ")#metadata(none) <tao-ab80d83dbd444bdd9a7b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left|{\\bf E} X - {\\bf E} Y\\right| \\leq {\\bf E} |X-Y|.", block: true)]]

#text(" Thus, for instance, if ")#mi("{X_n}")#text(" is a sequence of absolutely integrable scalar random variables which converges in ")#mi("{L^1}")#text(" to another absolutely integrable random variable ")#mi("{X}")#text(", in the sense that ")#tao-math("{{\\bf E} \\left|X_n-X\\right| \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", then ")#mi("{{\\bf E} X_n \\rightarrow {\\bf E} X}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")

#text("Similarly, applying the Markov inequality to the quantity ")#tao-math("{\\left|X - {\\bf E} X\\right|^2}", block: false)#text(" we obtain the important ")#link("https://en.wikipedia.org/wiki/Chebyshev%27s_inequality")[#text("Chebyshev inequality")]#text(" ")#metadata(none) <tao-4dc5ee0d2ddd582fe968>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("{\\bf P}(\\left|X - {\\bf E} X\\right| \\geq t) \\leq \\frac{1}{t^2} \\text{Var}(X)", block: true)]]

#text(" for absolutely integrable ")#mi("{X}")#text(" and ")#mi("{t>0}")#text(", where the ")#link("https://en.wikipedia.org/wiki/Variance")[#text("Variance")]#text(" ")#mi("{\\text{Var}(X)}")#text(" of ")#mi("{X}")#text(" is defined as")

#align(center)[#tao-fit-display[#tao-math("\\text{Var}(X) := {\\bf E}( \\left|X - {\\bf E} X\\right|^2 ).", block: true)]]

#text("Next, we record")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 39 (Jensen’s inequality)")]#text(" If ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a convex function, ")#mi("{X}")#text(" is a real random variable with ")#mi("{X}")#text(" and ")#mi("{f(X)}")#text(" both absolutely integrable, then")

#align(center)[#tao-fit-display[#mitex("f( {\\bf E} X ) \\leq {\\bf E} f(X).")]]
]

#emph[#text("Proof:")]#text(" Let ")#mi("{x_0}")#text(" be a real number. Being convex, the graph of ")#mi("{f}")#text(" must be supported by some line at ")#mi("{(x_0,f(x_0))}")#text(", that is to say there exists a slope ")#mi("{c}")#text(" (depending on ")#mi("{x_0}")#text(") such that ")#mi("{f(x) \\ge f(x_0) + c(x-x_0)}")#text(" for all ")#mi("{x \\in {\\bf R}}")#text(". (If ")#mi("{f}")#text(" is differentiable at ")#mi("{x_0}")#text(", one can take ")#mi("{c}")#text(" to be the derivative of ")#mi("{f}")#text(" at ")#mi("{x_0}")#text(", but one always has a supporting line even in the non-differentiable case.) In particular")

#align(center)[#tao-fit-display[#mitex("f(X) \\geq f(x_0) + c(X-x_0).")]]

#text("Taking expectations and using linearity of expectation, we conclude")

#align(center)[#tao-fit-display[#mitex("{\\bf E} f(X) \\geq f(x_0) + c({\\bf E} X - x_0 )")]]

#text("and the claim follows from setting ")#mi("{x_0 := {\\bf E} X}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40 (Complex Jensen inequality)")]#text(" Let ")#mi("{f: {\\bf C} \\rightarrow {\\bf R}}")#text(" be a convex function (thus ")#mi("{f((1-t)z+tw) \\leq (1-t)f(z) + tf(w)}")#text(" for all complex ")#mi("{z,w}")#text(" and all ")#mi("{0 \\leq t \\leq 1}")#text(", and let ")#mi("{X}")#text(" be a complex random variable with ")#mi("{X}")#text(" and ")#mi("{f(X)}")#text(" both absolutely integrable. Show that")

#align(center)[#tao-fit-display[#mitex("f( {\\bf E} X ) \\leq {\\bf E} f(X).")]]
]

#text("Note that the triangle inequality ")#tao-math("{\\left|{\\bf E} X\\right| \\leq {\\bf E} \\left|X\\right|}", block: false)#text(" is the special case of Jensen’s inequality (or the complex Jensen’s inequality, if ")#mi("{X}")#text(" is complex-valued) corresponding to the convex function ")#tao-math("{f(x) := \\left|x\\right|}", block: false)#text(" on ")#mi("{{\\bf R}}")#text(" (or ")#tao-math("{f(z) := \\left|z\\right|}", block: false)#text(" on ")#mi("{{\\bf C}}")#text("). Another useful example is")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E} X\\right|^2 \\leq {\\bf E} \\left|X\\right|^2.", block: true)]]

#text("Applying Jensen’s inequality to the convex function ")#mi("{f: x \\mapsto e^x}")#text(" and the random variable ")#mi("{X = \\log Y}")#text(" for some ")#mi("{Y>0}")#text(", we obtain the ")#link("https://en.wikipedia.org/wiki/Inequality_of_arithmetic_and_geometric_means")[#text("arithmetic mean-geometric mean inequality")]

#align(center)[#tao-fit-display[#mitex("\\exp( {\\bf E} \\log Y ) \\leq {\\bf E} Y")]]

#text("assuming that ")#mi("{Y>0}")#text(" and ")#mi("{Y,\\log Y}")#text(" are absolutely integrable.")

#text("As a related application of convexity, observe from the convexity of the function ")#mi("{x \\mapsto e^x}")#text(" that")

#align(center)[#tao-fit-display[#mitex("e^{tx + (1-t)y} \\leq t e^x + (1-t) e^y")]]

#text("for any ")#mi("{0 \\leq t \\leq 1}")#text(" and ")#mi("{x,y \\in {\\bf R}}")#text(". This implies in particular ")#link("https://en.wikipedia.org/wiki/Young%27s_inequality")[#text("Young’s inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left|X\\right| \\left|Y\\right| \\leq \\frac{1}{p} \\left|X\\right|^p + \\frac{1}{q} \\left|Y\\right|^q", block: true)]]

#text("for any scalar ")#mi("{X,Y}")#text(" and any exponents ")#mi("{1 < p,q < \\infty}")#text(" with ")#mi("{\\frac{1}{p} + \\frac{1}{q}=1}")#text("; note that this inequality is also trivially true if one or both of ")#tao-math("{\\left|X\\right|, \\left|Y\\right|}", block: false)#text(" are infinite. Taking expectations, we conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|X\\right| \\left|Y\\right| \\leq \\frac{1}{p} {\\bf E} \\left|X\\right|^p + \\frac{1}{q} {\\bf E} \\left|Y\\right|^q", block: true)]]

#text("if ")#mi("{X,Y}")#text(" are scalar random variables and ")#mi("{1 < p, q < \\infty}")#text(" are deterministic exponents with ")#mi("{\\frac{1}{p} + \\frac{1}{q}=1}")#text(". In particular, if ")#tao-math("{\\left|X\\right|^p, \\left|Y\\right|^q}", block: false)#text(" are absolutely integrable, then so is ")#mi("{XY}")#text(", and")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E} X Y\\right| \\leq \\frac{1}{p} {\\bf E} \\left|X\\right|^p + \\frac{1}{q} {\\bf E} \\left|Y\\right|^q.", block: true)]]

#text("We can amplify this inequality as follows. Multiplying ")#mi("{X}")#text(" by some ")#mi("{0 < \\lambda < \\infty}")#text(" and dividing ")#mi("{Y}")#text(" by the same ")#mi("{\\lambda}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E} X Y\\right| \\leq \\frac{\\lambda^p}{p} {\\bf E} \\left|X\\right|^p + \\frac{\\lambda^{-q}}{q} {\\bf E} \\left|Y\\right|^q;", block: true)]]

#text("optimising the right-hand side in ")#mi("{\\lambda}")#text(", we obtain (after some algebra, and after disposing of some edge cases when ")#mi("{X}")#text(" or ")#mi("{Y}")#text(" is almost surely zero) the important ")#link("https://en.wikipedia.org/wiki/H%C3%B6lder%27s_inequality")[#text("Hölder inequality")]#text(" ")#metadata(none) <tao-6e45386daeb0b86da1ac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left|{\\bf E} X Y\\right| \\leq ({\\bf E} \\left|X\\right|^p)^{1/p} ({\\bf E} \\left|Y\\right|^q)^{1/q}", block: true)]]

#text(" which we can write as")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E} X Y\\right| \\leq \\left\\| X\\right\\|_p \\left\\|Y\\right\\|_q", block: true)]]

#text("where we use the notation")

#align(center)[#tao-fit-display[#tao-math("\\left\\|X\\right\\|_p := ({\\bf E} \\left|X\\right|^p)^{1/p}", block: true)]]

#text("for ")#mi("{0 < p < \\infty}")#text(". Using the convention")

#align(center)[#tao-fit-display[#tao-math("\\left\\|X\\right\\|_\\infty := \\inf \\{ M: \\left|X\\right| \\leq M \\text{ a. s.} \\}", block: true)]]

#text("(thus ")#tao-math("{\\left\\|X\\right\\|_\\infty}", block: false)#text(" is the essential supremum of ")#tao-math("{\\left|X\\right|}", block: false)#text("), we also see from the triangle inequality that the Hölder inequality applies in the boundary case when one of ")#mi("{p,q}")#text(" is allowed to be ")#mi("{\\infty}")#text(" (so that the other is equal to ")#mi("{1}")#text("):")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E} X Y\\right| \\leq \\left\\| X\\right\\|_1 \\left\\|Y\\right\\|_\\infty, \\left\\|X\\right\\|_\\infty \\left\\|Y\\right\\|_1.", block: true)]]

#text("The case ")#mi("{p=q=2}")#text(" is the important ")#link("https://en.wikipedia.org/wiki/Cauchy%E2%80%93Schwarz_inequality")[#text("Cauchy-Schwarz inequality")]#text(" ")#metadata(none) <tao-3b8b91c75627bee566dc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left|{\\bf E} X Y\\right| \\leq \\left\\| X\\right\\|_2 \\left\\|Y\\right\\|_2,", block: true)]]

#text(" valid whenever ")#mi("{X,Y}")#text(" are ")#emph[#text("square-integrable")]#text(" in the sense that ")#tao-math("{\\left\\|X\\right\\|_2, \\left\\|Y\\right\\|_2}", block: false)#text(" are finite.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 41")]#text(" Show that the expressions ")#tao-math("{\\left\\|X\\right\\|_p}", block: false)#text(" are non-decreasing in ")#mi("{p}")#text(" for ")#mi("{p \\in (0,+\\infty]}")#text(". In particular, if ")#tao-math("{\\left\\|X\\right\\|_p}", block: false)#text(" is finite for some ")#mi("{p}")#text(", then it is automatically finite for all smaller values of ")#mi("{p}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42")]#text(" For any square-integrable ")#mi("{X}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}(X \\neq 0) \\geq \\frac{ ({\\bf E} \\left|X\\right|)^2}{{\\bf E}(\\left|X\\right|^2)}.", block: true)]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 43")]#text(" If ")#mi("{1 < p < \\infty}")#text(" and ")#mi("{X,Y}")#text(" are scalar random variables with ")#tao-math("{\\left\\|X\\right\\|_p, \\left\\|Y\\right\\|_p < \\infty}", block: false)#text(", use Hölder’s inequality to establish that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|X\\right| \\left|X+Y\\right|^{p-1} \\leq \\left\\|X\\right\\|_p \\left\\|X+Y\\right\\|_p^{p-1}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|Y\\right| \\left|X+Y\\right|^{p-1} \\leq \\left\\|Y\\right\\|_p \\left\\|X+Y\\right\\|_p^{p-1}", block: true)]]

#text("and then conclude the ")#link("https://en.wikipedia.org/wiki/Minkowski_inequality")[#text("Minkowski inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left\\|X+Y\\right\\|_p \\leq \\left\\|X\\right\\|_p + \\left\\|Y\\right\\|_p.", block: true)]]

#text("Show that this inequality is also valid at the endpoint cases ")#mi("{p=1}")#text(" and ")#mi("{p=\\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 44")]#text(" If ")#mi("{X}")#text(" is non-negative and square-integrable, and ")#mi("{0 \\leq \\theta \\leq 1}")#text(", establish the ")#link("https://en.wikipedia.org/wiki/Paley%E2%80%93Zygmund_inequality")[#text("Paley-Zygmund inequality")]

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( X > \\theta {\\bf E}(X) ) \\geq (1-\\theta)^2 \\frac{({\\bf E} X)^2}{{\\bf E}(\\left|X\\right|^2)}.", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" use the Cauchy-Schwarz inequality to upper bound ")#mi("{{\\bf E} X 1_{X > \\theta {\\bf E} X}}")#text(" in terms of ")#tao-math("{{\\bf E} \\left|X\\right|^2}", block: false)#text(" and ")#mi("{{\\bf P}( X > \\theta {\\bf E}(X) )}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 45")]#text(" Let ")#mi("{X}")#text(" be a non-negative random variable that is almost surely bounded but not identically zero, show that")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf P}( X \\geq \\frac{1}{2} \\mathop{\\bf E} X) \\geq \\frac{1}{2} \\frac{\\mathop{\\bf E} X}{\\left\\|X\\right\\|_\\infty}.", block: true)]]
]

#heading(level: 1)[#text("Comments (93)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-681663")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" By far what I can get is for a compact interval ")#mi("[-n, n]")#text(", we have ")#mi("\\int_{[-n, n]} \\alpha(x)\\ dF_X(x) = \\int_{[-n, n]} (1 - F_X(x))\\ d\\alpha(x)")#text(", where ")#mi("\\alpha(x) = e^{tx}")#text(". Can you give some further direction on your earlier comment of “approximating the exponential function by a piecewise constant function and use dominated convergence to justify passing to the limit” ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-681812")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2023")])]

#text("take square root")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-681823")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2023")])]

#text("Can you elaborate?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-681786")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" For Exercise 38, I see the way proceed by using Tonelli’s theorem to get the identity ")#mi("{\\mathbf E}X = \\int_{[0, +\\infty]} {\\mathbf P}(X \\geq x)\\ dx")#text(" for non-negative ")#mi("X")#text(". But to evaluate the LHS ")#mi("\\int_{\\mathbf R} e^{tx}\\ d\\mu_X(x)")#text(" by definition to get the RHS ")#mi("\\int_{\\mathbf R} (1 - F_X(x))\\ dx")#text(", I tried to define the approximating p.c function to be the largest integer multiple of ")#mi("1/n")#text(" smaller than both ")#mi("n")#text(" and ")#mi("e^{tx}")#text(", but struggles to continue by this approach. Can you provide some further hint on this method?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3654189dd67ef2873d98bf28cb99ce604ef4bc258233e13ea0e6985b543bc8d6-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Han Bing")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-681787")[#strong[#text("Han Bing")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2023")])]

#text("Also, above Exercise 41, the sentence “thus ")#tao-math("{\\left\\|X\\right\\|_\\infty}", block: false)#text(" is the essential supremum of ")#mi("{X}")#text("” should be “thus ")#tao-math("{\\left\\|X\\right\\|_\\infty}", block: false)#text(" is the essential supremum of ")#tao-math("\\left|{X}\\right|", block: false)#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3654189dd67ef2873d98bf28cb99ce604ef4bc258233e13ea0e6985b543bc8d6-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Han Bing")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-681811")[#strong[#text("Han Bing")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" To evaluate ")#mi("\\int_{\\bf R} e^{tx}\\ d\\mu_X(x)")#text(" by approximating p.c function in Exercise 38 to get ")#mi("\\int_{\\bf R} (1 - F_X(x))te^{tx}\\ dx")#text(", can we define the p.c function to be ")#mi("f_n(x) := e^{k_x}")#text(", where ")#mi("k_x")#text(" is the largest integer multiple of ")#mi("1/n")#text(" smaller than ")#mi("\\min(n, tx)")#text(" when ")#mi("x > 0")#text(", and ")#mi("k_x")#text(" is the smallest integer multiple of ")#mi("-1/n")#text(" smaller than ")#mi("\\min(-n, tx)")#text(" when ")#mi("x < 0")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3654189dd67ef2873d98bf28cb99ce604ef4bc258233e13ea0e6985b543bc8d6-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Han Bing")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-681824")[#strong[#text("Han Bing")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2023")])]

#text("Dear prof Tao:")#linebreak()#text(" Can you elaborate further on how to define the approximating function of ")#mi("e^{tx}")#text(" in Exercise 38?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cc5c5b58984fd8189ecbd929d29b01a826651e0c09b23f3bd634be13eedaaa9-d6d1d5cfe1043cacae035da57d5d17ba965c8e55b19bbe97d948d36de7810dd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Convergence of mean from almost sure convergence in a super-linear bounded mean setting | Aditya Guha Roy's weblog")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-682385")[#strong[#text("Convergence of mean from almost sure convergence in a super-linear bounded mean setting | Aditya Guha Roy's weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2023")])]

#text("[…] the special case, when is the function one obtains the much useful Theorem 25 from this blogpost by professor Terence Tao. In fact, Proposition 1 above was motivated by the ensuing remark after […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0b59950ea598d14fbfc183e2fbfdd1331644e5ac23dc317a47e86ea093c7111-3cb0a7e82e888c2d8b45a7c1db5daeddff1025c7838c5ea61f03b534e8f8549f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of carlossaul")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-686961")[#strong[#text("carlossaul")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2024")])]

#text("I think there’s a small typo when simple functions are introduced and operations on $latex [0,\\infty]$ are defined. Specifically, I think it should say ")#mi("a\\cdot+\\infty=+\\infty\\cdot a=+\\infty")#text(" for all ")#mi("a\\in(0,\\infty]")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0b59950ea598d14fbfc183e2fbfdd1331644e5ac23dc317a47e86ea093c7111-3cb0a7e82e888c2d8b45a7c1db5daeddff1025c7838c5ea61f03b534e8f8549f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of carlossaul")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-686975")[#strong[#text("carlossaul")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2024")])]

#text("Exercise 12 can be used to conclude that the definition of expectation does not depend on the choice of model for our random variable. Does this mean that we get the same value if we consider an extension of our probability space as defined in Definition 1? Are there any operations, other than extension, to construct a model that can represent a given random variable or event?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-686979")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2024")])]

#text("Yes, expectation is preserved under extension of the model. Any tool that constructs a measure space can in principle be used to construct a given random variable or event; for instance, to model an infinite number of independent random variables, the Kolmogorov extension theorem is a popular choice.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-689208")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2025")])]

#text("Prof, Tao,")

#text("Why do you choose the notation EX instead of the “function” notation E(X)? Is it just your personal preference? The reason why I ask about this is that: when you write down things like EXF(X) = EF'(X), I think adding some brackets may be more readable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-689212")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2025")])]

#text("It is an unspoken convention in mathematics to often omit parentheses when the operation being applied is linear. Thus, for instance, we write ")#mi("\\Delta f")#text(" instead of ")#mi("\\Delta(f)")#text(" for the Laplacian of ")#mi("f")#text(", ")#mi("\\int f\\ d\\mu")#text(" instead of ")#mi("\\int(f, d\\mu)")#text(" for the integral of ")#mi("f")#text(" with respect to a measure ")#mi("\\mu")#text(", ")#mi("\\sum_n f(n)")#text(" instead of ")#mi("\\sum (n \\mapsto f(n))")#text(" for the summation of a function ")#mi("f")#text(", and ")#mi("{\\bf E} X")#text(" instead of ")#mi("{\\bf E}(X)")#text(" for the expectation of ")#mi("X")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-689220")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2025")])]

#text("Though I think while one can certainly write ")#mi("\\int f+g d\\mu")#text(", one would use ")#mi("\\mathbf{E}(X+Y)")#text(" instead of ")#mi("\\mathbf{E}X+Y")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-689257")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2025")])]

#text("Dear Dr Tao,")

#text("Some typos I found: (1) …and the “probabilility” function… should be “probability”. (2) in Exercise 40, random variabels should be random variables.")

#text("I’d like to ask: Could you provide us for the intuitive understanding of Borel-Cantelli Lemma and the Markov Inequality? In measure theory I think these two techniques appear a lot but I don’t know when to use them. Am I missing something?")

#emph[#text("[See Section 1.1 “The first moment method” of my book “")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("Additive Combinatorics")]#text("” with Van Vu. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-691928")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2026")])]

#text("Dr. Tao,")

#emph[#text("The distribution captures the “size” and “shape” of the random variable, but not its “location” or how it relates to other random variables.")]

#text("How could one formalize this intuition?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-691930")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2026")])]

#text("I am ")#link("https://gemini.google.com/share/4cd955260b25")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-692214")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2026")])]

#metadata(none) <tao-a79a5595ec30e9b5f62f>

#text("Dear Prof. Tao,")

#metadata(none) <tao-e4e1fe8184f1002b741e>

#text("In the example of Jensen’s inequality, you mentioned that Jensen’s inequality can be used to derive the triangle inequality, the AM-GM inequality, Young’s inequality, Hölder’s inequality, the Cauchy-Schwarz inequality, and others. I would like to ask: what exactly does Jensen’s inequality convey that makes it the starting point for so many inequalities?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-692218")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2026")])]

#text("I am ")#link("https://claude.ai/share/84cf6394-6567-4e88-902c-b81006a4140d")[#text("outsourcing this question to an AI")]#text(". I will add that Jensen’s inequality is a very convenient way to utilize the property of ")#emph[#text("convexity")]#text(", which we have learned over the last century or so to be an absolutely fundamental concept in the theory of inequalities in general.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-2/#comment-692224")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2026")])]

#text("Thanks for the additional comment.")

#text("I would also like to ask that: Shannon entropy H(X) can be interpreted as a measure of information, while H(X) is also convex/concave. Was it merely a coincidence that Shannon chose convexity to characterize/model this measure of information when he defined it?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d340339cbc25e13afb404a68620ca4c9ced5a72939928744cf39de9cb22e6de9-b1f3d2c41974b8626397d605e8f85022ee2e3b1ffa07472e344413487c82c7d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pauljung")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460081")[#strong[#text("pauljung")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("Great notes so far. You have a stray * appearing as f*(omega) in the first bullet of Exercise 7. In the same exercise, second bullet, I think you want equality instead of greater or equal. In Proposition 12 (i), do you not need that X and Y are integrable?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d340339cbc25e13afb404a68620ca4c9ced5a72939928744cf39de9cb22e6de9-b1f3d2c41974b8626397d605e8f85022ee2e3b1ffa07472e344413487c82c7d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pauljung")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460083")[#strong[#text("pauljung")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("By the way, I like your statement about Probability Theory being the study of random events which are model-independent. M. Loeve’s Vol. I (pg 173) has a similar take on this view.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460087")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("Great notes! One small correction: in the proof of theorem 16, you should have LHS >= RHS in the second displayed equation.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e41a655a43fd81844baa8c4f3ca019946f619b05e1629676fc0ef441fc8e775-727dab67ebceb17c501056072241b00fde24bbfdceb166aeb0301d41e8f6543e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PerryZhao")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460093")[#strong[#text("PerryZhao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("Reblogged this on ")#link("https://perryzhao.wordpress.com/2015/10/04/275a-notes-1-integration-and-expectation/")[#text("木秀于林")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d340339cbc25e13afb404a68620ca4c9ced5a72939928744cf39de9cb22e6de9-b1f3d2c41974b8626397d605e8f85022ee2e3b1ffa07472e344413487c82c7d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pauljung")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460094")[#strong[#text("pauljung")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("Ignore my comment about Proposition 12, I didn’t realize unsigned there meant nonnegative.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460102")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2015")])]

#text("Professor – it looks like your informal heuristic for Fatou is backwards.")

#emph[#text("[Looks like it is in the right direction to me – could you elaborate? -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460116")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2015")])]

#text("Sure – in your informal heuristic bullet list you state:")

#text("“For unsigned {f_n}, the limit inferior of the integral cannot exceed the integral of the limit inferior”")

#text("but the inequality in Fatou actually goes the other way.")

#emph[#text("[Got it now. Corrected, thanks -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8371d943e11f2ee5630e1ad2f23ac18b7fbfc6e7f7e523227453d483bd27ebf-8dc2eb16c022b6652f932e7b7c23a69facf039f182263717919a45eb31c25dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Gonzales")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460104")[#strong[#text("David Gonzales")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2015")])]

#text("Exercise 9(iv) talks about monotonicity of complex functions $f$ and $g$, which isn’t defined so should probably be changed.")

#emph[#text("[Oops, that should have been deleted, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c495b53d97a26934220e7827b2f8c18b57d8a75fddc0ce21294128319cf68f3-7e262babac0d4c72dcbc923a33c143a2133a4d3cdd310b61bdecf57de155c8d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jennifer")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460106")[#strong[#text("Jennifer")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2015")])]

#text("Thanks for providing these great notes for self-study! Do you by any chance also share pdf versions of them?")

#emph[#text("[One should be able to print to PDF (with headers and sidebar removed) from the “Print” feature on your browser. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460181")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2015")])]

#text("The very first bullet has a typo: wrong notation for the sure event. Thanks for the notes, and also for the pre-work that surely went into creating them.")

#emph[#text("[Actually, I am using ")#mi("\\overline{\\emptyset}")#text(" (the complement of the empty event) to denote the sure event. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Not A Music Expert")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460237")[#strong[#text("Not A Music Expert")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2015")])]

#text("What kind of music do you listen to?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460242")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2015")])]

#text("I am going to go out on a limb here and say a lot of these complications arise from the non-compactness of ")#mi("\\mathbb{R}")#text(" ? Markov’s inequality is essentially the pigeonhole principle. Can the same be said of Chebyshev inequality? Or even Hölder inequality?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c4a5346f2dc69972940208c449b56b75620b5999ce9a4f27d37061eb8f6fe06-a02437a46d4fb76627fb142fdb635d4f4813516d42f4fde706a99a151b8ce115.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan McNeive")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460454")[#strong[#text("Ryan McNeive")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2015")])]

#text("Thanks (as always) for these great notes!")

#text("I wanted to ask about a typo. In the proof of Fatou’s lemma, on the RHS of the last three equations, surely the sum should be from 1 to n rather than 1 to N? Unless I am very confused.")

#emph[#text("[One can use the symbol ")#mi("n")#text(" in place of ")#mi("N")#text(" here (thus replacing ")#mi("f_N")#text(", ")#mi("E_{i,N}")#text(" by ")#mi("f_n, E_{i,n}")#text(" respectively) if desired. I chose not to do so as this makes the definition of ")#mi("E_{i,n}")#text(" a bit confusing unless one also changes the symbol ")#mi("n")#text(" appearing there to some other symbol. -T.]")]

#emph[#text("[Added, Oct 14: oh, I see the problem now, I had used n for two unrelated things. Fixed now, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 2: Product measures and independence | What's new")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460455")[#strong[#text("275A, Notes 2: Product measures and independence | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2015")])]

#text("[…] the previous set of notes, we constructed the measure-theoretic notion of the Lebesgue integral, and used this to set up the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad9c0864e68d25433df6aa119c7808a1da8842d767d78d3e358d63d16d47108a-f72844400c5ff076544cea6cf2e86bb85d88719cf5b04f1ffda470619b5d25d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460515")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2015")])]

#text("Above exercise 3, isn’t there a mistake in {1 \\times 1_{[0,2)} + 1 \\times 1_{[1,3)}? Perhaps it should be {1 \\times 1_{[0,1)} + 1 \\times 1_{[0,3)}?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad9c0864e68d25433df6aa119c7808a1da8842d767d78d3e358d63d16d47108a-f72844400c5ff076544cea6cf2e86bb85d88719cf5b04f1ffda470619b5d25d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460519")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2015")])]

#text("I think there is still a typo in the second indicator function: ")#mi("1_{[1,3)}")#text(" instead of ")#mi("1_{[0,3]}")#text(".")

#emph[#text("[Corrected, thanks -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460608")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2015")])]

#text("Should the second centered equation in Theorem 23, be ")#tao-math("\\leq 2m^{-\\varepsilon} \\left|X_{n}\\right|^{1 + \\varepsilon}", block: false)#text("? The 2 comes from considering the events ")#mi("\\omega")#text(" such that ")#tao-math("\\left|X_{n}^{[m]}(\\omega)\\right| = m", block: false)#text(" and for these ")#mi("\\omega")#text(", ")#tao-math("\\left|m^{\\varepsilon}X_{n}(\\omega) - m^{1 + \\varepsilon}\\right| \\leq m^{\\varepsilon}\\left|X_{n}(\\omega) - m\\right| \\leq 2\\left|X_{n}(\\omega)\\right|^{1 + \\varepsilon}.", block: false)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460612")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2015")])]

#text("The factor of 2 is unnecessary; one has the pointwise bound ")#tao-math("\\left|X_n - X_n^{[m]}\\right| \\leq \\left|X_n\\right|", block: false)#text(" when ")#tao-math("\\left|X_n\\right| \\geq m", block: false)#text(" (checking the cases ")#mi("X_n \\geq m")#text(" and ")#mi("X_n \\leq -m")#text(" separately) and ")#tao-math("\\left|X_n - X_n^{[m]}\\right|=0", block: false)#text(" otherwise.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/746863bc34d8fefbe2b2f82325b0841a52b8353f001b7f5448e3ce16efbe52e4-c6a8acdf4e8514444632e322d604268f40521f079bcf637d4e0e254edc126a88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L.")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460620")[#strong[#text("L.")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2015")])]

#text("In the proof of the Fatou’s lemma, why do we need the ")#mi("1-\\varepsilon")#text(" “modification”? There is at least one point that I am not sure: since the ")#mi("a_i")#text(" are allowed to be ")#mi("+\\infty")#text(", we should have ")#mi("\\lim\\inf_{n \\to \\infty} f_n \\geq (1 - \\varepsilon) a_i")#text(" on ")#mi("E_i")#text(" (instead of strict inequality in the note). But we know that on ")#mi("E_i")#text(", ")#mi("\\lim\\inf_{n \\to \\infty} f_n \\geq a_i")#text(". Now if we define ")#mi("E_{i,N} := \\{ \\omega \\in E_i: f_n(\\omega) \\geq a_i \\text{ for all } n \\geq N \\}")#text(", then we have ")#mi("\\bigcup_{N=1}^{\\infty} E_{i,N} = \\bigcup_{N=1}^{\\infty} \\bigcap_{n=N}^{\\infty} \\{ \\omega \\in E_i: f_n(\\omega) \\geq a_i \\}")#text(", which is equal to ")#mi("\\{ \\omega \\in E_i: \\lim\\inf_{n \\to \\infty} f_n \\geq a_i \\} = E_i")#text(". The ")#mi("E_{i,N}")#text(" are still increasing to ")#mi("E_i")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460626")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2015")])]

#text("Ah, I did not treat the case when some of the ")#mi("a_i")#text(" were infinite; I’ve fixed the proof to address this.")

#text("One needs strict inequality in the bound ")#mi("\\liminf_{n \\to \\infty} f_n > (1-\\varepsilon) a_i")#text(" to ensure that ")#mi("f_n > (1-\\varepsilon) a_i")#text(" for sufficiently large n. The bound ")#mi("\\liminf_{n \\to \\infty} f_n \\geq a_i")#text(" does not ensure that ")#mi("f_n \\geq a_i")#text(" for even a single choice of ")#mi("n")#text(" (for instance, the ")#mi("f_n")#text(" could be increasing and converge to ")#mi("a_i")#text(" in the limit).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/746863bc34d8fefbe2b2f82325b0841a52b8353f001b7f5448e3ce16efbe52e4-c6a8acdf4e8514444632e322d604268f40521f079bcf637d4e0e254edc126a88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L.")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-460646")[#strong[#text("L.")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2015")])]

#text("Oh, I see the point. Thanks very much for your comments.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 4: The central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-461362")[#strong[#text("275A, Notes 4: The central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2015")])]

#text("[…] this and the Paley-Zygmund inequality (Exercise 39 of Notes 1) we also get some lower bound for of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-462149")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2015")])]

#text("Is Chebyshev inequality (8) optimal in the sense that if the first two moments of a random variable ")#mi("X")#text(" are given with a threshold ")#mi("t>0")#text(", then (8) can be made arbitrarily close to equality by an appropriate selection of a probability distribution for ")#mi("X")#text(" (depending of course on the given expectation and variance of ")#mi("X")#text(" and the given threshold ")#mi("t>0")#text(") ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-462152")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2015")])]

#text("Yes, this can be seen by experimenting with Bernoulli type random variables (e.g. ones which attain a threshold ")#mi("t")#text(" with some probability ")#mi("p/2")#text(", ")#mi("-t")#text(" with probability ")#mi("p/2")#text(", and ")#mi("0")#text(" with probability ")#mi("1-p")#text(", for various choices of parameters ")#mi("p,t")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-462161")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2015")])]

#text("Thank you! Let me add some comments:")

#text("1. If ")#mi("X")#text(" has mean ")#mi("\\mu")#text(" and variance ")#mi("\\sigma^2")#text(", without loss of generality we may assume that ")#mi("\\mu = 0")#text(" and if the standard deviation ")#mi("\\sigma")#text(" and the threshold ")#mi("t")#text(" are given, consider the two cases:")

#text("(i) ")#mi("t < \\sigma")#text(": In this case the RHS of (8) is greater than 1, so (8) is trivial")#linebreak()#text(" but not(!) optimal.")

#text("(ii) ")#mi("\\sigma \\leq t")#text(": In this case (using your suggestion) choose ")#mi("t_0 > t")#text(" and denote ")#mi("p := \\sigma^2 / t_0^2")#text(" (which is less than 1) . If ")#mi("X")#text(" attain ")#mi("t_0")#text(" with probability ")#mi("p/2")#text(", ")#mi("-t_0")#text(" with probability ")#mi("p/2")#text(", and ")#mi("0")#text(" with probability ")#mi("1-p")#text(", then ")#mi("X")#text(" has zero mean and (from this choice of ")#mi("p")#text(") variance ")#mi("\\sigma^2")#text(" – as required. Moreover, (8) will be ")#mi("p= \\sigma^2/t_0^2 \\leq \\sigma^2 / t^2")#text(".")#linebreak()#text(" Hence (by choosing ")#mi("t_0")#text(" arbitrarily close to ")#mi("t")#text(") Chebyshev inequality (8) an be made arbitrarily close to equality (i.e. (8) is optimal in this case.)")

#text("2. Interestingly, this idea can be applied also for the one-sided chebyshev inequality (Chebyshev-Cantelli inequality):")

#mi("P(X - \\mu  >  t) \\leq \\sigma^2 /(\\sigma^2 + t^2)")

#text("Where ")#mi("\\mu := E(X), \\sigma^2 := Var(X)")#text(" and ")#mi("t > 0")#text(".")#linebreak()#text(" Choose ")#mi("t_0 > t")#text(" and define")#linebreak()#text(" ")#mi("p:= \\sigma^2 /(sigma^2 + t_0^2)")#text(".")

#text("If ")#mi("X")#text(" attain ")#mi("t_0")#text(" with probability ")#mi("p")#text(" and")#linebreak()#text(" ")#mi("t_1 := -\\sigma^2/t_0")#text(" with probability ")#mi("1-p")#text(", it follows that")#linebreak()#text(" ")#mi("E(X) = p t_0 +(1-p) t_1 =0")#text(" and")#linebreak()#text(" ")#mi("E(X^2)=p t_0^2 +(1-p)t_1^2 =\\sigma^2")#text(" – as required.")

#text("Moreover, the one-sided Chebyshev inequality will be")

#mi("p:=\\sigma^2/(\\sigma^2 + t_0^2) \\leq \\sigma^2/(\\sigma^2 +t^2)")

#text("Hence (by choosing ")#mi("t_0")#text(" arbitrarily close to ")#mi("t")#text(") the one-sided Chebyshev inequality is also optimal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-462203")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2015")])]

#text("It is interesting to observe that for case (i) above (for which Chebyshev inequality (8) is non-optimal), the optimal bound on the LHS of (8) is the trivial bound 1. To see that, we use a simplified version of the proof of case (ii) above, in which the random variable ")#mi("X")#text(" attain ")#mi("\\sigma")#text(" with probability ")#mi("1/2")#text(" and ")#mi("-\\sigma")#text(" with probability ")#mi("1/2")#text(". This gives ")#mi("E(X) = 0, Var(X) = \\sigma^2")#text(" (as required) and ")#mi("1")#text(" as the probability in the LHS of (8).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-462397")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2015")])]

#text("Hi Terry, there’s a small typo at the end of the proof dominated convergence theorem (Theorem 21). The final equation is missing integral signs.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8371d943e11f2ee5630e1ad2f23ac18b7fbfc6e7f7e523227453d483bd27ebf-8dc2eb16c022b6652f932e7b7c23a69facf039f182263717919a45eb31c25dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-462598")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2015")])]

#text("Just before Exercise 3, there is “can also be written as {1 \\times 1_{[0,1)} + 1 \\times 1_{[1,3)}}”, but the last subscript is probably meant to be ")#mi("[0,3)")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8371d943e11f2ee5630e1ad2f23ac18b7fbfc6e7f7e523227453d483bd27ebf-8dc2eb16c022b6652f932e7b7c23a69facf039f182263717919a45eb31c25dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-462601")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2015")])]

#text("‘real-valuked’ to ‘real-valued’ (it’s somewhere in the middle)")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8371d943e11f2ee5630e1ad2f23ac18b7fbfc6e7f7e523227453d483bd27ebf-8dc2eb16c022b6652f932e7b7c23a69facf039f182263717919a45eb31c25dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-462602")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2015")])]

#text("Forgotten subscript:")#linebreak()#text(" \\displaystyle {\\bf E} f_i(X) = \\int{\\bf R} f_i(x)\\ d\\mu_X(x)")#linebreak()#text(" should be:")#linebreak()#text(" \\displaystyle {\\bf E} f_i(X) = \\int_{\\bf R} f_i(x)\\ d\\mu_X(x)")#linebreak()#text(" (just after valuked)")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-464559")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2015")])]

#text("Below Remark 31, “… for any measurable set {R} in the range…” should read “… any measurable set {S}..”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-464873")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2016")])]

#text("Just a small typo, I guest. In the proof of Theorem 32, when the general case is considered and the functions f_n are considered, there is a missed expectation before letting n to infinite. Should be")

#mi("{\\bf E}f_{n}(X)=\\int_{\\bf R}f_{n}(x)\\,d\\mu_{X}(x)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-464880")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2016")])]

#text("In exercise 37 I get the integrals with ")#mi("(1-F_{X})")#text(" instead of just ")#mi("F_{X}")#text(" in both cases. Maybe there is a typo here.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d1a03e0888240ec9c3575ca57b4baec067a8e98b443c34f7ea41e446aa3e187-70df25ca72e0cb73832d6e64c23699db6c7f07f072bc2fe7367be499edaae7dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sebastien Zany")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-471250")[#strong[#text("Sebastien Zany")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2016")])]

#text("Thanks for these notes!")

#text("Is entropy not a probabilistic concept? If not, then how should we think about it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-471318")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2016")])]

#text("There are several different notions of entropy used in mathematics, not all of which are directly tied to probability. But the ")#link("https://en.wikipedia.org/wiki/Entropy_(information_theory)")[#text("Shannon entropy")]#text(" ")#mi("H(X)")#text(" of a discrete random variable ")#mi("X")#text(" is a probabilistic concept, since it can be expressed in terms of probabilities as ")#mi("H(X) = \\sum_x {\\bf P}(X=x) \\log \\frac{1}{{\\bf P}(X=x)}")#text(" (with the convention that ")#mi("0 \\log \\frac{1}{0} = 0")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-474389")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2016")])]

#text("I’m a little confused about the summary at the very beginning of this note. In Notes 0, a measure space ")#mi("\\Omega=(\\Omega,\\mathcal{F},\\mu)")#text(" was introduced to ")#emph[#text("model")]#text(" some randomness (an “abstract” probability space). And this abstract probability space is a triple ")#mi("(V,\\mathcal{G},\\bf{P})")#text(" which satisfies Kolmogrov’s three axioms. The difference between the concrete model ")#mi("\\Omega= (\\Omega,\\mathcal{F},\\mu)")#text(" and the abstract probability space ")#mi("V=(V,\\mathcal{G},\\bf{P})")#text(" that ")#mi("\\Omega")#text(" models is that")

#text("(1)")#mi("\\Omega= (\\Omega,\\mathcal{F},\\mu)")#text(" is a measure space where ")#mi("\\mathcal{F}")#text(" is a (concrete) ")#mi("\\sigma")#text("-algebra ")#emph[#text("on")]#text(" ")#mi("\\Omega")#text(";")

#text("(2)while in ")#mi("V=(V,\\mathcal{G},\\bf{P})")#text(", it does not have to be a measure space and the “event space” ")#mi("\\mathcal{G}")#text(" is an abstract ")#mi("\\sigma")#text("-algebra and hence do not have to be a collection of subsets of ")#mi("V")#text(".")

#text("Shouldn’t we have ")#mi("V")#text(" first so that we can talk about we models ")#mi("V")#text(" using a model ")#mi("\\Omega")#text("? Why do you define the “conjunction”, “disjunction” and the “probability” ")#mi("\\bf{P}")#text(" of an event ")#mi("E\\in\\mathcal{G}")#text(" ")#emph[#text("after")]#text(" a model ")#mi("\\Omega")#text(" is given? (Why is this not a circular argument?) Shouldn’t all these be defined first?")

#text("Are you in fact abstracting thing out from a concrete model ")#mi("(\\Omega,\\mathcal{F},\\mu)")#text(" to get an abstract probability space ")#mi("(V,\\mathcal{G},\\bf{P})")#text(", like we can get an abstract real space ")#mi("W")#text(" out of a concrete real space ")#mi("\\mathbb{R}^2:=\\{(x,y)\\mid x,y\\in\\mathbb{R}\\}")#text(", and one can actually define an abstract probability space ")#mi("(V,\\mathcal{G},\\bf{P})")#text(" without given any model ")#mi("(\\Omega,\\mathcal{F},\\mu)")#text(" in the first place?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-474393")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2016")])]

#text("Yes, if one wants to, one can define abstract probability spaces first without reference to concrete measure spaces and only then talk about their representations by concrete measure spaces. This is discussed in Section 4 of Notes 0. But from a pedagogical point of view this is undesirable as this delays the point in the course where one actually does probability, rather than foundations of probability. This is one reason why most texts compress the foundations by working entirely with concrete probability spaces and not abstract ones (somewhat similarly to how in a first undergraduate linear algebra class, vectors are often _defined_ to be rows or columns of numbers, rather than as elements of an abstract vector space, in order to get on with the linear algebra rather than the foundations of linear algebra).")

#text("For the purposes of actually doing probability, the only relevant features of the concept of an abstract probability space are that (a) it can be modeled by at least one concrete probability space, and (b) the basic probabilistic notions (e.g. boolean operations, probability of an event, whether two events are equal etc.) are independent of the model. The existence of such a concept can be guaranteed by the formal definition of an abstract probability space as an abstract sigma algebra equipped with an abstract probability measure (or by the other alternative definitions of this concept in Section 4 of Notes 0). But one could also proceed by defining concrete probability spaces first, and defining an abstraction of that space to be anything isomorphic to the events of that space together with their probabilities and boolean operations; this would suffice for most practical purposes, and is basically the approach taken in Notes 0 before Section 4.")

#text("Incidentally, while the 1933 text of Kolmogorov does use a concrete sigma algebra (or, in the language of that era, a field of sets) to model the event space, it is clear from his writing that he would have used an abstraction of this if was available at the time (e.g. on page 1 of your linked translation he writes “what the elements of this set represent is of no importance”). One reason for this is that the correct axiomatisation of an abstract sigma algebra was not identified and justified until the work of Loomis and Sikorski in 1947, which was many years after the original text of Kolmogorov.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-474390")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2016")])]

#text("Right after Definition 27, I think you mean “the distribution ")#mi("{\\mu_X}")#text(" on ")#mi("{S}")#text(" is the push-forward of the probability measure ")#mi("{\\bf{P}}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: The central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-478161")[#strong[#text("254A, Notes 2: The central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("[…] this and the Paley-Zygmund inequality (Exercise 42 of Notes 1) we also get some lower bound for of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/421d1bc187822d1a425403c66768a0e4bc4bb7ae836128fffed2def83958afbc-32201946d05599d122add0dd8f4faf3cd32916378a0cb7d2554da8d3199319d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of haonanz")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-489339")[#strong[#text("haonanz")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2017")])]

#text("Hello Prof. Tao, may I ask if you could provide a counter example where two unsigned functions that the integral is strictly superadditive? Based on the construction, I will assume the counter example would be either function to be unbounded value or unbounded support, but I just could not come up with an explicit one. Thanks,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-489564")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2017")])]

#text("There is no such counterexample for measurable functions; see Exercise 7(vi). In the nonmeasurable case, a simple example would be given when ")#mi("\\Omega")#text(" is a two-element space ")#mi("\\{a,b\\}")#text(" with the trivial algebra ")#mi("\\{ \\emptyset, \\{a,b\\}\\}")#text(" and the obvious probability measure with ")#mi("f = 1_{\\{a\\}}")#text(" and ")#mi("g = 1_{\\{b\\}}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e5a71b3846a0d53393b3cce0889c10a2f0468197d7fb7fc3611cb26f39c83f8-af9fb91df879030f37d9c5c9a22f274383eb31fc646f74ec3cb1ef2c249bc641.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Weibo Shu")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-511546")[#strong[#text("Weibo Shu")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2019")])]

#text("Dear Pro. Tao:")#linebreak()#text(" I have some questions about remark 25, you say any function ")#tao-math("g(\\left|X\\right|)", block: false)#text(" which satisfies that ")#tao-math("lim_{X \\to \\infty}{g(\\left|X\\right|)/\\left|X\\right|} \\to \\infty", block: false)#text(" is ok to substitute the condition in theorem 24. But I am a little skeptical, since I can only get ")#tao-math("E(\\left|X_n\\right|I_{\\left|X_n\\right|>m}) < E(g(\\left|X_n\\right|)I_{X_n > m})", block: false)#text(" by this condition (here we can adjust m to make N arbitrary big). Without ")#tao-math("g(\\left|X_n\\right|) \\geq 0", block: false)#text(", I can’t amplify ")#tao-math("E(g(\\left|X_n\\right|)I_{\\left|X_n\\right|>m})", block: false)#text(" to ")#tao-math("E(g(\\left|X_n\\right|))", block: false)#text(". consequently, the inequality can’t become ")#tao-math("E(\\left|X_n\\right|I_{\\left|X_n\\right|>m})<\\frac{M}{N}", block: false)#text(". Hence I can't deduce the uniform integrability.")#linebreak()#text(" is there anything wrong with my statement?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-511564")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2019")])]

#emph[#text("[Regarding LaTeX formatting: wordpress interprets text between the < and > signs as HTML rather than LaTeX. For a workaround, see the discussion in ")#link("https://terrytao.wordpress.com/about/")[#text("https://terrytao.wordpress.com/about/")]#text(" . I have repaired the issues in this particular comment.]")]

#text("If ")#tao-math("\\lim_{X \\to \\infty} g(\\left|X\\right|)/\\left|X\\right| \\to \\infty", block: false)#text(", then for any ")#mi("N")#text(" there exists ")#mi("m")#text(" such that $g(|X|)/|X| \\geq N$ whenever ")#tao-math("\\left|X\\right| \\geq m", block: false)#text(", which implies that ")#tao-math("\\left|X_n\\right| 1_{\\left|X_n\\right| > m} \\leq \\frac{1}{N} g(\\left|X_n\\right|) 1_{\\left|X_n\\right| > m}", block: false)#text(". (Here of course ")#mi("g")#text(" should be understood to take values in the positive reals.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e5a71b3846a0d53393b3cce0889c10a2f0468197d7fb7fc3611cb26f39c83f8-af9fb91df879030f37d9c5c9a22f274383eb31fc646f74ec3cb1ef2c249bc641.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Weibo Shu")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-511613")[#strong[#text("Weibo Shu")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2019")])]

#text("Thanks for your reply. I know ")#tao-math("g(\\left|X_n\\right|)", block: false)#text(" is positive when ")#tao-math("\\left|X_n\\right| \\geq m", block: false)#text(", but I don’t know whether it’s positive on the whole positive real line. However, I want to amplify ")#tao-math("E(g(\\left|X_n\\right|)1_{\\left|X_n\\right| \\geq m})", block: false)#text(" to ")#tao-math("E(g(\\left|X_n\\right|))", block: false)#text(" for the purpose of proving {")#mi("X_n")#text("} is uniform integrable. That’s because ")#tao-math("E(g(\\left|X_n\\right|))", block: false)#text(" is uniform bounded (that’s the condition of theorem 24) but ")#tao-math("E(g(\\left|X_n\\right|)1_{\\left|X_n\\right| \\geq m})", block: false)#text(" is not necessarily uniform bounded.")

#text("what I want to do is ‘")#tao-math("E(\\left|X_n\\right|1_{\\left|X_n\\right| \\geq m}) \\leq \\frac{1}{N} E(g(\\left|X_n\\right|)1_{\\left|X_n\\right| \\geq m}) \\leq \\frac{1}{N} E(g(\\left|X_n\\right|)) \\leq \\frac{M}{N}", block: false)#text("‘ , but without ")#tao-math("g(\\left|x\\right|)", block: false)#text(" is non-negative on the positive real line, the second ")#mi("\\leq")#text(" can’t be hold.")

#text("An example is ")#tao-math("g(\\left|x\\right|)=\\left|x\\right|log\\left|x\\right|", block: false)#text(", though it’s non-negative when ")#tao-math("\\left|x\\right| \\geq 1", block: false)#text(", it’s negative when ")#tao-math("\\left|x\\right|", block: false)#text(" less than 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-511648")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2019")])]

#tao-math("{\\bf E}(g(\\left|X\\right|))", block: false)#text(" is bounded if and only if ")#tao-math("{\\bf E}( C + g(\\left|X\\right|) )", block: false)#text(" is bounded, for any bounded ")#mi("C")#text(". So, as long as ")#mi("g")#text(" is bounded from below by ")#mi("-C")#text(", one can make ")#mi("g")#text(" nonnegative without difficulty.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e5a71b3846a0d53393b3cce0889c10a2f0468197d7fb7fc3611cb26f39c83f8-af9fb91df879030f37d9c5c9a22f274383eb31fc646f74ec3cb1ef2c249bc641.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Weibo Shu")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-511746")[#strong[#text("Weibo Shu")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2019")])]

#text("So, I think we at least need the condition g is bounded from below by a constant C. Since there is a function which is not bounded from below but still satisfies that ")#tao-math("E(g(\\left|X\\right|))", block: false)#text(" is bounded.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e5a71b3846a0d53393b3cce0889c10a2f0468197d7fb7fc3611cb26f39c83f8-af9fb91df879030f37d9c5c9a22f274383eb31fc646f74ec3cb1ef2c249bc641.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Weibo Shu")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-511631")[#strong[#text("Weibo Shu")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2019")])]

#text("Hi, Prof.Tao, I have some confusion about exercise 37.")

#text("(a) may the condition be ‘")#mi("F_X(x) = P(X \\leq x)")#text("‘ rather than ‘")#mi("F_X(xt) = P(X \\leq x)")#text("‘ ?")

#text("(b) in question (1), I can rewrite the right part as ‘")#mi("\\int_R (1-F_X(x))de^{tx}")#text(" since ")#mi("te^{tx}")#text(" is the radon-nikodym derivative of ")#mi("e^{tx}")#text(" . But I can’t further rewrite it as : ")#mi("\\int_R (1-F_X(x))de^{tx}= (1-F_X(x))e^{tx}|_{- \\infty}^{+ \\infty}-\\int_R e^{tx}d(1-F_X(x))=0+\\int_R e^{tx}dF_X(x)=E( e^{tX} )")#text(". That’s because F_X(x) is not necessarily absolutely continuous. Hence the first equality can’t be hold. The same condition happens in question (2). So my question is if we need an extra condition that F_X(x) is absolutely continuous? if not, how to prove the final equality?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-511649")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2019")])]

#text("The typo is now corrected.")

#text("Integration by parts for the Riemann-Stieltjes integral does not require absolute continuity; bounded variation is sufficient.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-514542")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2019")])]

#text("Dear Prof. Tao, I have a confusion on last paragraph of section 2.")#linebreak()#text(" I think invariance of expectation isn’t trivial, since concrete probability space is defined first and then abstract space is. Let (Omega, F, P) be the original probability space and (Omega’, F’, P’) a extension of it.")#linebreak()#text(" Then pull back sigma field on (Omega’) can be coarser than F’, so there can be simple random variables modeled by (Omega’) which cannot be modeled by (Omega).")#linebreak()#text(" Thus extension of original probability space makes abstract probability space bigger, so where to take supremum to calculate expectation is unclear to me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-514615")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2019")])]

#text("Ooh, that is a subtle point I had not noticed. The invariance is indeed slightly non-trivial (though not terribly difficult once one knows what to do to resolve it) and I have added an exercise to address it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6216a76a0d5193327586ff5af8d767a94b7888ae066ae5587268c92dd0dd9d7-2c5e21767869320b2221faeb9e99045db9ecaf47cd8bf4aa18206f3df4625120.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-629489")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2021")])]

#text("Hello Professor, Exercise 41 seems to be inconsistent with the definition of Lp norms for vectors. In particular, ||v||_{1} \\geq ||v||_{\\infty} while here ||X||_p is non-decreasing for increasing p. Should we think of these as two different types of Lp norms?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-629575")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2021")])]

#mi("L^p(X,\\mu)")#text(" norms are non-decreasing in ")#mi("p")#text(" when the measure ")#mi("\\mu")#text(" has total mass at most one (which is the case in this probabilistic setting), but are non-increasing in ")#mi("p")#text(" when all non-empty sets have measure at least one (which is the case of ")#mi("\\ell^p")#text(" norms for vectors). For more general measure spaces one does not have monotonicity, but still has log convexity in ")#mi("p")#text(" from Holder’s inequality.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84e213380af91c3169b14eea5df3a2eb4cc323da240ee658d82a1e8ed9d9732e-c0ef6f984eeb07ce1ba19ddaea16b15116c439246b0cfe7e745c329f2fa02242.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-629564")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2021")])]

#text("In the third to last equation for the proof of Fatou’s lemma, the upper limit of the sum should be k and not N.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84e213380af91c3169b14eea5df3a2eb4cc323da240ee658d82a1e8ed9d9732e-c0ef6f984eeb07ce1ba19ddaea16b15116c439246b0cfe7e745c329f2fa02242.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-629805")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2021")])]

#text("The second equation of exercise 43 should be ||Y||_p not ||X||_p.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-641760")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2022")])]

#text("Why would one call the example in Remark 2 an “extension”? After all, ")#mi("\\Omega^{\\prime}")#text(" is smaller then ")#mi("\\Omega")#text(".")

#text("Can it be replaced with one that ")#mi("\\Omega^{\\prime}")#text(" is larger than ")#mi("\\Omega")#text(" (with ")#mi("\\pi")#text(" still being non-surjective)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-641765")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2022")])]

#text("This is an extension in which some points in the base sample space ")#mi("\\Omega")#text(" have no lifts whatsoever to the extension ")#mi("\\Omega^{\\prime}")#text(", making the extension potentially smaller; this of course does not happen in the surjective case. But one can certainly have non-surjective extensions that are larger than the base, for instance one can take a further extension ")#mi("\\Omega^{\\prime} \\times \\Omega^{\\prime\\prime}")#text(" of ")#mi("\\Omega^{\\prime}")#text(" (and hence of ")#mi("\\Omega")#text(") by taking the product of ")#mi("\\Omega^{\\prime}")#text(" with another probability space ")#mi("\\Omega^{\\prime\\prime}")#text(" of arbitrarily large cardinality.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-677919")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2023")])]

#text("In Definition 1, I think you missed mentioning that the factor map ")#mi("\\pi")#text(" should be surjective.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-677924")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2023")])]

#text("Excuse my comment above; I just saw that you made the point in Remark 2.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-680652")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2023")])]

#text("Dear professor Tao, are the functions ")#mi("f")#text(" and ")#mi("g")#text(" in Exercise 5 not only unsigned but measurable as well? The notion of unsigned integral is defined in terms of measurable function, as is done in Exercise 1.4.36 of your measure theory text.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-680854")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" I believe that the first sentence below Exercise 8 should be : “Because of part (ii) of the above exercise…” instead.")#linebreak()#text(" ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-680891")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2023")])]

#text("Also, can you elaborate a little more on why the other form of Fatou’s Lemma is indeed equivalent to the original form? Thank you professor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-680919")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2023")])]

#text("I Think I get it now. The case where ")#mi("\\liminf_{n \\rightarrow \\infty} \\int_{\\Omega} f_n\\ d\\mu = +\\infty")#text(" is trivial, so we let ")#mi("M = \\liminf_{n \\rightarrow \\infty} \\int_{\\Omega} f_n\\ d\\mu")#text(" be finite. By monotonicity, ")#mi("\\int_{\\Omega} F_N\\ d\\mu \\leq \\int_{\\Omega} f_n\\ d\\mu")#text(" for all ")#mi("n \\geq N")#text(", suggesting in particular that ")#mi("\\int_{\\Omega} F_N\\ d\\mu \\leq \\inf_{n \\geq N} \\int_{\\Omega} f_n\\ d\\mu \\leq M")#text(". Applying the second form to ")#mi("F_N")#text(" then gives the desired result.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-681077")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" May I ask where the extra term ")#mi("O( m^{-\\varepsilon} M )")#text(" on the RHS of the last display of Theorem 25 comes from? It seems that ")#mi("\\liminf_{n \\rightarrow \\infty} \\mathbf{E}\\bf{X}_n = \\liminf_{n \\rightarrow \\infty}{\\bf E} X_n^{[m]} +  O( m^{-\\varepsilon} M ) = {\\bf E} X^{[m]} +  O( m^{-\\varepsilon} M ) = {\\bf E} \\bf X")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-681176")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" On the part that says if ")#mi("{X}")#text(" is a scalar variable that only takes on at most countably many values, the change of variables formula tells us that")

#mi("\\displaystyle {\\bf E} X = \\sum_i x_i {\\bf P}(X=x_i)")

#text("It seems in this case that the expectation can be calculated directly by definition or the dominated convergence theorem. Why does")

#mi("\\displaystyle {\\bf E} X = \\sum_i x_i {\\bf P}(X=x_i)")

#text("also give the sum and how does it simplify our calculation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-681178")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2023")])]

#text("I mean why does the change of variable formula")#linebreak()#text(" ")#mi("\\displaystyle {\\bf E} X = \\int_{\\bf R} x\\ d\\mu_X(x)")#text(" also gives the sum?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-681186")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2023")])]

#text("By monotone convergence, ")#mi("\\int_{\\bf R} x d\\mu_X(x) = \\sum_i \\int_{\\bf R} x 1_{x=x_i}\\ d\\mu_X(x) = \\sum_i x_i \\mu_X(x_i) = \\sum_i x_i {\\bf P}(X=x_i)")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-681227")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" In the proof of Theorem 33 shouldn’t ")#mi("f_2")#text(" be ")#mi("-\\min(f, 0)")#text(" if we express ")#mi("f")#text(" as the difference of the (magnitude) of its’ positive and negative parts?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-681292")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" Can you give some further hint on how the condition of ")#mi("{F}")#text(" and ")#mi("{F^{\\prime}}")#text(" both of polynomial growth in Exercise 37 could be used to prove the identity?")

#emph[#text("[Try integration by parts on some compact interval such as ")#mi("[-R, R]")#text(". The polynomial growth hypothesis can then be used to justify passage to the limit ")#mi("R \\to \\infty")#text(". -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-681309")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2023")])]

#text("If we let ")#mi("G: \\mathbf{R} \\rightarrow \\mathbf{R}")#text(" be such that ")#mi("G(x) := xF(x)")#text(", I can see that the fact that ")#mi("F")#text(" is of polynomial growth means that ")#mi("G(x)e^{-x^2/2} \\rightarrow 0")#text(" as ")#mi("x \\rightarrow \\infty")#text(", so it should allow us to conclude that ")#mi("G(X)")#text(" is absolutely integrable, but I’m not sure how to establish it rigorously using only the facts presented in the notes so far.")

#emph[#text(" One can show that ")#mi("G(x) e^{-x^2/2}")#text(" goes to infinity faster than any polynomial, e.g., faster than ")#mi("(1+x^2)^{-1}")#text(", which suffices for the purposes of establishing absolute integrability. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-681372")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" For part 1 of Exercise 38, do you expect one to derive the fact that the derivative of CDF is PDF, following by Exercise 36, or is there some other preferable way that uses the facts presented so far?")

#emph[#text("[There are multiple ways to proceed. For instance, one can use the Fubini–Tonelli theorem, or one can approximate the exponential function by a piecewise constant function and use dominated convergence to justify passing to the limit. For this problem a PDF is not assumed to exist (except in a distributional or measure theoretic sense), so care would have to be taken if one wished to proceed by that route. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-681496")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2023")])]

#text("Thank you so much for your patient explanation, professor.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-681522")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" Regarding your last comment on Exercise 38, how can one choose the approximating p.c function of the exponential function? By the change of variables formula we want ")#mi("\\int_{\\bf R} e^{tx}\\ d\\mu_X(x) = \\int_{\\bf R} (1-F_X(x)) t e^{tx}\\ dx")#text(", are you suggesting evaluating the LHS by first principle?")

#emph[#text("[Yes, that is one way to proceed. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/comment-page-1/#comment-681611")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2023")])]

#text("To evaluate the LHS of ")#mi("\\int_{\\bf R} e^{tx}\\ d\\mu_X(x) = \\int_{\\bf R} (1 - F_X(x))te^{tx}\\ dx")#text(" in Exercise 38, I get ")#mi("\\int_{[-n, n]} e^{tx}\\ d\\mu_X(x) = \\int_{[-n, n]} e^{tx}\\ dF_X(x)")#text(" for compact interval ")#mi("[-n, n]")#text(", but I struggle to find a way to evaluate this integral by definition to get the RHS, can you give some further hint? Thank you professor.")
]
