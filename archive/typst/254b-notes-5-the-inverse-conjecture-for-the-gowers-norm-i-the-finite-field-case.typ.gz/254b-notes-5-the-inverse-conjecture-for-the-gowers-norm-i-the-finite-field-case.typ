// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/05/20/254b-notes-5-the-inverse-conjecture-for-the-gowers-norm-i-the-finite-field-case/
// Converted to Typst by tao2typ: "2026-10-14T15:17:46.718525+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254B, Notes 5: The inverse conjecture for the Gowers norm I.  The finite field case", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254B, Notes 5: The inverse conjecture for the Gowers norm I.  The finite field case")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 May 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/05/20/254b-notes-5-the-inverse-conjecture-for-the-gowers-norm-i-the-finite-field-case/")[#text("https://terrytao.wordpress.com/2010/05/20/254b-notes-5-the-inverse-conjecture-for-the-gowers-norm-i-the-finite-field-case/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In ")#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/")[#text("Notes 3")]#text(", we saw that the number of additive patterns in a given set was (in principle, at least) controlled by ")#emph[#text("the Gowers uniformity norms")]#text(" of functions associated to that set.")

#text("Such norms can be defined on any finite additive group (and also on some other types of domains, though we will not discuss this point here). In particular, they can be defined on the finite-dimensional vector spaces ")#mi("{V}")#text(" over a finite field ")#mi("{{\\bf F}}")#text(".")

#text("In this case, the Gowers norms ")#mi("{U^{d+1}(V)}")#text(" are closely tied to the space ")#mi("{\\text{Poly}_{\\leq d}(V \\rightarrow {\\bf R}/{\\bf Z})}")#text(" of polynomials of degree at most ")#mi("{d}")#text(". Indeed, as noted in Exercise 20 of ")#link("https://terrytao.wordpress.com/2010/05/08/254b-lecture-notes-4-equidistribution-of-polynomials-over-finite-fields/")[#text("Notes 4")]#text(", a function ")#mi("{f: V \\rightarrow {\\bf C}}")#text(" of ")#mi("{L^\\infty(V)}")#text(" norm ")#mi("{1}")#text(" has ")#mi("{U^{d+1}(V)}")#text(" norm equal to ")#mi("{1}")#text(" if and only if ")#mi("{f = e(\\phi)}")#text(" for some ")#mi("{\\phi \\in \\text{Poly}_{\\leq d}(V \\rightarrow {\\bf R}/{\\bf Z})}")#text("; thus polynomials solve the “")#mi("{100\\%}")#text(" inverse problem” for the trivial inequality ")#tao-math("{\\left\\|f\\right\\|_{U^{d+1}(V)} \\leq \\left\\|f\\right\\|_{L^\\infty(V)}}", block: false)#text(". They are also a crucial component of the solution to the “")#mi("{99\\%}")#text(" inverse problem” and “")#mi("{1\\%}")#text(" inverse problem”. For the former, we will soon show:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (")#mi("{99\\%}")#text(" inverse theorem for ")#mi("{U^{d+1}(V)}")#text(")")]#text(" ")#metadata(none) <tao-8c1f1046219ddd216a02>#text(" Let ")#mi("{f: V \\rightarrow {\\bf C}}")#text(" be such that ")#tao-math("{\\left\\|f\\right\\|_{L^\\infty(V)}}", block: false)#text(" and ")#tao-math("{\\left\\|f\\right\\|_{U^{d+1}(V)} \\geq 1-\\epsilon}", block: false)#text(" for some ")#mi("{\\epsilon > 0}")#text(". Then there exists ")#mi("{\\phi \\in \\text{Poly}_{\\leq d}(V \\rightarrow {\\bf R}/{\\bf Z})}")#text(" such that ")#tao-math("{\\left\\| f - e(\\phi)\\right\\|_{L^1(V)} = O_{d, {\\bf F}}( \\epsilon^c )}", block: false)#text(", where ")#mi("{c = c_d > 0}")#text(" is a constant depending only on ")#mi("{d}")#text(".")
]

#text("Thus, for the Gowers norm to be almost completely saturated, one must be very close to a polynomial. The converse assertion is easily established:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Converse to ")#mi("{99\\%}")#text(" inverse theorem for ")#mi("{U^{d+1}(V)}")#text(")")]#text(" If ")#tao-math("{\\left\\|f\\right\\|_{L^\\infty(V)} \\leq 1}", block: false)#text(" and ")#tao-math("{\\left\\|f-e(\\phi)\\right\\|_{L^1(V)} \\leq \\epsilon}", block: false)#text(" for some ")#mi("{\\phi \\in \\text{Poly}_{\\leq d}(V \\rightarrow {\\bf R}/{\\bf Z})}")#text(", then ")#tao-math("{\\left\\|F\\right\\|_{U^{d+1}(V)} \\geq 1 - O_{d,{\\bf F}}( \\epsilon^c )}", block: false)#text(", where ")#mi("{c = c_d > 0}")#text(" is a constant depending only on ")#mi("{d}")#text(".")
]

#text("In the ")#mi("{1\\%}")#text(" world, one no longer expects to be close to a polynomial. Instead, one expects to ")#emph[#text("correlate")]#text(" with a polynomial. Indeed, one has")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Converse to the ")#mi("{1\\%}")#text(" inverse theorem for ")#mi("{U^{d+1}(V)}")#text(")")]#text(" If ")#mi("{f: V \\rightarrow {\\bf C}}")#text(" and ")#mi("{\\phi \\in \\text{Poly}_{\\leq d}(V \\rightarrow {\\bf R}/{\\bf Z})}")#text(" are such that ")#tao-math("{\\left|\\langle f, e(\\phi) \\rangle_{L^2(V)}\\right| \\geq \\epsilon}", block: false)#text(", where ")#mi("{\\langle f, g \\rangle_{L^2(V)} := {\\bf E}_{x \\in G} f(x) \\overline{g(x)}}")#text(", then ")#tao-math("{\\left\\|f\\right\\|_{U^{d+1}(V)} \\geq \\epsilon}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" From the definition of the ")#mi("{U^1}")#text(" norm (equation (18) from ")#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/")[#text("Notes 3")]#text("), the monotonicity of the Gowers norms (Exercise 19 of ")#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/")[#text("Notes 3")]#text("), and the polynomial phase modulation invariance of the Gowers norms (Exercise 21 of ")#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/")[#text("Notes 3")]#text("), one has")

#tao-aligned(keep: true)[


#tao-math("\\left|\\langle f, e(\\phi) \\rangle\\right|  & = \\left\\| f e(-\\phi) \\right\\|_{U^1(V)}", block: true)



#tao-math(" & \\leq \\left\\|f e(-\\phi) \\right\\|_{U^{d+1}(V)}", block: true)



#tao-math(" & = \\left\\|f\\right\\|_{U^{d+1}(V)}", block: true)
]

#text("and the claim follows. ")#mi("\\Box")

#text("In the high characteristic case ")#mi("{\\text{char}({\\bf F}) > d}")#text(" at least, this can be reversed:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (")#mi("{1\\%}")#text(" inverse theorem for ")#mi("{U^{d+1}(V)}")#text(")")]#text(" ")#metadata(none) <tao-76f5c27d49afeeb5a673>#text(" Suppose that ")#mi("{\\text{char}({\\bf F}) > d \\geq 0}")#text(". If ")#mi("{f: V \\rightarrow {\\bf C}}")#text(" is such that ")#tao-math("{\\left\\|f\\right\\|_{L^\\infty(V)} \\leq 1}", block: false)#text(" and ")#tao-math("{\\left\\|f\\right\\|_{U^{d+1}(V)} \\geq \\epsilon}", block: false)#text(", then there exists ")#mi("{\\phi \\in \\text{Poly}_{\\leq d}(V \\rightarrow {\\bf R}/{\\bf Z})}")#text(" such that ")#tao-math("{\\left|\\langle f, e(\\phi) \\rangle_{L^2(V)}\\right| \\gg_{\\epsilon,d,{\\bf F}} 1}", block: false)#text(".")
]

#text("This result is sometimes referred to as the ")#emph[#text("inverse conjecture for the Gowers norm")]#text(" (in high, but bounded, characteristic). For small ")#mi("{d}")#text(", the claim is easy:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Verify the cases ")#mi("{d=0,1}")#text(" of this theorem. (")#emph[#text("Hint:")]#text(" to verify the ")#mi("{d=1}")#text(" case, use the Fourier-analytic identities ")#tao-math("{\\left\\|f\\right\\|_{U^2(V)} = (\\sum_{\\xi \\in \\hat V} \\left|\\hat f(\\xi)\\right|^4)^{1/4}}", block: false)#text(" and ")#tao-math("{\\left\\|f\\right\\|_{L^2(V)} = (\\sum_{\\xi \\in \\hat V} \\left|\\hat f(\\xi)\\right|^2)^{1/2}}", block: false)#text(", where ")#mi("{\\hat V}")#text(" is the space of all homomorphisms ")#mi("{\\xi: x \\mapsto \\xi \\cdot x}")#text(" from ")#mi("{V}")#text(" to ")#mi("{{\\bf R}/{\\bf Z}}")#text(", and ")#mi("{\\hat f(\\xi) := \\mathop{\\bf E}_{x \\in V} f(x) e(-\\xi \\cdot x)}")#text(" are the Fourier coefficients of ")#mi("{f}")#text(".)")
]

#text("This conjecture for larger values of ")#mi("{d}")#text(" are more difficult to establish. The ")#mi("{d=2}")#text(" case of the theorem was established ")#link("http://www.ams.org/mathscinet-getitem?mr=2391635")[#text("by Ben Green and myself")]#text(" in the high characteristic case ")#mi("{\\text{char}({\\bf F}) > 2}")#text("; the low characteristic case ")#mi("{\\text{char}({\\bf F}) = d = 2}")#text(" was independently and simultaneously established ")#link("http://www.ams.org/mathscinet-getitem?mr=240247")[#text("by Samorodnitsky")]#text(". The cases ")#mi("{d>2}")#text(" in the high characteristic case was established in two stages, firstly using a modification of the Furstenberg correspondence principle, due to ")#link("http://arxiv.org/abs/0810.5527")[#text("Ziegler and myself")]#text(". to convert the problem to an ergodic theory counterpart, and then using a modification of the methods of ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("Host-Kra")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2257397")[#text("Ziegler")]#text(" to solve that counterpart, as done in ")#link("http://arxiv.org/abs/0901.2602")[#text("this paper of Bergelson, Ziegler, and myself")]#text(".")

#text("The situation with the low characteristic case in general is still unclear. In the high characteristic case, we saw from ")#link("https://terrytao.wordpress.com/2010/05/08/254b-lecture-notes-4-equidistribution-of-polynomials-over-finite-fields/")[#text("Notes 4")]#text(" that one could replace the space of non-classical polynomials ")#mi("{\\text{Poly}_{\\leq d}(V \\rightarrow {\\bf R}/{\\bf Z})}")#text(" in the above conjecture with the essentially equivalent space of classical polynomials ")#mi("{\\text{Poly}_{\\leq d}(V \\rightarrow {\\bf F})}")#text(". However, as we shall see below, this turns out not to be the case in certain low characteristic cases (a fact first observed ")#link("http://arxiv.org/abs/0711.3388")[#text("by Lovett, Meshulam, and Samorodnitsky")]#text(", and independently ")#link("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/")[#text("by Ben Green and myself")]#text("), for instance if ")#mi("{\\text{char}({\\bf F}) = 2}")#text(" and ")#mi("{d \\geq 3}")#text("; this is ultimately due to the existence in those cases of non-classical polynomials which exhibit no significant correlation with classical polynomials of equal or lesser degree. This distinction between classical and non-classical polynomials appears to be a rather non-trivial obstruction to understanding the low characteristic setting; it may be necessary to obtain a more complete theory of non-classical polynomials in order to fully settle this issue.")

#text("The inverse conjecture has a number of consequences. For instance, it can be used to establish the analogue of Szemerédi’s theorem in this setting:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Szemerédi’s theorem for finite fields)")]#text(" ")#metadata(none) <tao-f13e7604737eddf552e3>#text(" Let ")#mi("{{\\bf F} = {\\bf F}_p}")#text(" be a finite field, let ")#mi("{\\delta > 0}")#text(", and let ")#mi("{A \\subset {\\bf F}^n}")#text(" be such that ")#tao-math("{\\left|A\\right| \\geq \\delta \\left|{\\bf F}^n\\right|}", block: false)#text(". If ")#mi("{n}")#text(" is sufficiently large depending on ")#mi("{p,\\delta}")#text(", then ")#mi("{A}")#text(" contains an (affine) line ")#mi("{\\{ x, x+r, \\ldots, x+(p-1)r\\}}")#text(" for some ")#mi("{x,r \\in {\\bf F}^n}")#text(" with ")#mi("{ r\\neq 0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Use Theorem ")#link(<tao-f13e7604737eddf552e3>)[#text("4")]#text(" to establish the following generalisation: with the notation as above, if ")#mi("{k \\geq 1}")#text(" and ")#mi("{n}")#text(" is sufficiently large depending on ")#mi("{p,\\delta}")#text(", then ")#mi("{A}")#text(" contains an affine ")#mi("{k}")#text("-dimensional subspace.")
]

#text("We will prove this theorem in two different ways, one using a density increment method, and the other using an energy increment method. We discuss some other applications below the fold.")

#metadata(none) <tao-0b8f39ee0dc7d9ea119b>

#heading(level: 1)[#strong[#text(" — 1. The ")#mi("{99\\%}")#text(" inverse theorem — ")]]

#text("We now prove Proposition ")#link(<tao-8c1f1046219ddd216a02>)[#text("1")]#text(". Results of this type for general ")#mi("{d}")#text(" appear in ")#link("http://www.ams.org/mathscinet-getitem?mr=2080792")[#text("this paper of Alon, Kaufman, Krivelevich, Litsyn, and Ron")]#text(" (see also ")#link("http://www.ams.org/mathscinet-getitem?mr=1798076")[#text("this paper of Sudan, Trevisan, and Vadhan")]#text(" for a precursor result), the ")#mi("{d=1}")#text(" case was treated previously by ")#link("http://www.ams.org/mathscinet-getitem?mr=1248868")[#text("by Blum, Luby, and Rubinfeld")]#text(". The argument here is ")#link("http://arxiv.org/abs/0810.5527")[#text("due to Tamar Ziegler and myself")]#text(". The argument has a certain “cohomological” flavour (comparing cocycles with coboundaries, determining when a closed form is exact, etc.). Indeed, the inverse theory can be viewed as a sort of “additive combinatorics cohomology”.")

#text("Let ")#mi("{{\\bf F}, V, d, f, \\epsilon}")#text(" be as in the theorem. We let all implied constants depend on ")#mi("{d, {\\bf F}}")#text(". We use the symbol ")#mi("{c}")#text(" to denote various positive constants depending only on ")#mi("{d}")#text(". We may assume ")#mi("{\\epsilon}")#text(" is sufficiently small depending on ")#mi("{d, {\\bf F}}")#text(", as the claim is trivial otherwise.")

#text("The case ")#mi("{d=0}")#text(" is easy, so we assume inductively that ")#mi("{d \\geq 1}")#text(" and that the claim has been already proven for ")#mi("{d-1}")#text(".")

#text("The first thing to do is to make ")#mi("{f}")#text(" unit magnitude. One easily verifies the crude bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^{d+1}(V)}^{2^{d+1}} \\leq \\left\\|f\\right\\|_{L^1(V)}", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^1(V)} \\geq 1-O( \\epsilon ).", block: true)]]

#text("Since ")#tao-math("{\\left|f\\right| \\leq 1}", block: false)#text(" pointwise, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{x \\in V} 1 - \\left|f(x)\\right| = O(\\epsilon).", block: true)]]

#text("As such, ")#mi("{f}")#text(" differs from a function ")#mi("{\\tilde f}")#text(" of unit magnitude by ")#mi("{O(\\epsilon)}")#text(" in ")#mi("{L^1}")#text(" norm. By replacing ")#mi("{f}")#text(" with ")#mi("{\\tilde f}")#text(" and using the triangle inequality for the Gowers norm (changing ")#mi("{\\epsilon}")#text(" and worsening the constant ")#mi("{c}")#text(" in Proposition ")#link(<tao-8c1f1046219ddd216a02>)[#text("1")]#text(" if necessary), we may assume without loss of generality that ")#tao-math("{\\left|f\\right|=1}", block: false)#text(" throughout, thus ")#mi("{f = e(\\psi)}")#text(" for some ")#mi("{\\psi: V \\rightarrow {\\bf R}/{\\bf Z}}")#text(".")

#text("Since")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^{d+1}(V)}^{2^{d+1}} = \\mathop{\\bf E}_{h \\in V} \\left\\| e( \\partial_h \\psi ) \\right\\|_{U^d(V)}^{2^d}", block: true)]]

#text("we see from Markov’s inequality that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| e(\\partial_h \\psi ) \\right\\|_{U^d(V)} \\geq 1 - O(\\epsilon^c)", block: true)]]

#text("for all ")#mi("{h}")#text(" in a subset ")#mi("{H}")#text(" of ")#mi("{V}")#text(" of density ")#mi("{1-O(\\epsilon^c)}")#text(". Applying the inductive hypothesis, we see that for each such ")#mi("{h}")#text(", we can find a polynomial ")#mi("{\\phi_h \\in \\text{Poly}_{\\leq d-1}(V \\rightarrow {\\bf R}/{\\bf Z})}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| e( \\partial_h \\psi ) - e(\\phi_h ) \\right\\|_{L^1(V)} = O(\\epsilon^c).", block: true)]]

#text("Now let ")#mi("{h,k \\in H}")#text(". Using the cocycle identity")

#align(center)[#tao-fit-display[#mitex("e( \\partial_{h+k} \\psi ) = e(\\partial_h \\phi) T^h e(\\partial_k \\phi)")]]

#text("where ")#mi("{T^h}")#text(" is the shift operator ")#mi("{T^h f(x) := f(x+h)}")#text(", we see using Hölder’s inequality that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| e( \\partial_{h+k} \\psi ) - e(\\phi_h T^h \\phi_k) \\right\\|_{L^1(V)} = O(\\epsilon^c).", block: true)]]

#text("On the other hand, ")#mi("{\\phi_h T^h \\phi_k}")#text(" is a polynomial of order ")#mi("{d}")#text(". Also, since ")#mi("{H}")#text(" is so dense, every element ")#mi("{l}")#text(" of ")#mi("{V}")#text(" has at least one representation of the form ")#mi("{l=h+k}")#text(" for some ")#mi("{h,k \\in H}")#text(" (indeed, out of all ")#tao-math("{\\left|V\\right|}", block: false)#text(" possible representations ")#mi("{l=h+k}")#text(", ")#mi("{h}")#text(" or ")#mi("{k}")#text(" can fall outside of ")#mi("{H}")#text(" for at most ")#tao-math("{O(\\epsilon^c \\left|V\\right|)}", block: false)#text(" of these representations). We conclude that for every ")#mi("{l \\in V}")#text(" there exists a polynomial ")#mi("{\\phi^{\\prime}_l \\in \\text{Poly}_{\\leq d}(V \\rightarrow {\\bf R}/{\\bf Z})}")#text(" such that ")#metadata(none) <tao-56486663a0524f94b141>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| e( \\partial_l \\psi ) - e(\\phi^{\\prime}_l ) \\right\\|_{L^1(V)} = O(\\epsilon^c).", block: true)]]

#text("The new polynomial ")#mi("{\\phi^{\\prime}_l}")#text(" supercedes the old one ")#mi("{\\phi_l}")#text("; to reflect this, we abuse notation and write ")#mi("{\\phi_l}")#text(" for ")#mi("{\\phi^{\\prime}_l}")#text(". Applying the cocycle equation again, we see that ")#metadata(none) <tao-a2052ddf9e8c0c3d01cb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| e( \\phi_{h+k} ) - e( \\phi_h T^h \\phi_k ) \\right\\|_{L^1(V)} = O(\\epsilon^c)", block: true)]]

#text("for all ")#mi("{h,k \\in V}")#text(". Applying the rigidity of polynomials (Exercise 14 from ")#link("https://terrytao.wordpress.com/2010/05/08/254b-lecture-notes-4-equidistribution-of-polynomials-over-finite-fields/")[#text("Notes 4")]#text("), we conclude that")

#align(center)[#tao-fit-display[#mitex("\\phi_{h+k} = \\phi_h T^h \\phi_k + c_{h,k}")]]

#text("for some constant ")#mi("{c_{h,k} \\in {\\bf R}/{\\bf Z}}")#text(". From ")#link(<tao-a2052ddf9e8c0c3d01cb>)[#text("(2)")]#text(" we in fact have ")#mi("{c_{h,k}=O(\\epsilon^c)}")#text(" for all ")#mi("{h,k \\in V}")#text(".")

#text("The expression ")#mi("{c_{h,k}}")#text(" is known as a ")#emph[#mi("{2}")#text("-coboundary")]#text(" (see ")#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/")[#text("this blog post")]#text(" for more discussion). To eliminate it, we use the finite characteristic to discretise the problem as follows. First, we use the cocycle identity")

#align(center)[#tao-fit-display[#mitex("\\prod_{j=0}^{p-1} e( T^{jh} \\partial_h \\psi ) = 1")]]

#text("where ")#mi("{p}")#text(" is the characteristic of the field. Using ")#link(<tao-56486663a0524f94b141>)[#text("(1)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\prod_{j=0}^{p-1} e( T^{jh} \\phi_h ) - 1 \\right\\|_{L^1(V)} = O(\\epsilon^c).", block: true)]]

#text("On the other hand, ")#mi("{T^{jh} \\phi_h}")#text(" takes values in some coset of a finite subgroup ")#mi("{C}")#text(" of ")#mi("{{\\bf R}/{\\bf Z}}")#text(" (depending only on ")#mi("{p,d}")#text("), by Lemma 1 of ")#link("https://terrytao.wordpress.com/2010/05/08/254b-lecture-notes-4-equidistribution-of-polynomials-over-finite-fields/")[#text("Notes 4")]#text(". We conclude that this coset must be a shift of ")#mi("{C}")#text(" by ")#mi("{O(\\epsilon^c)}")#text(". Since ")#mi("{\\phi_h}")#text(" itself takes values in some coset of a finite subgroup, we conclude that there is a finite subgroup ")#mi("{C^{\\prime}}")#text(" (depending only on ")#mi("{p,d}")#text(") such that each ")#mi("{\\phi_h}")#text(" takes values in a shift of ")#mi("{C^{\\prime}}")#text(" by ")#mi("{O(\\epsilon^c)}")#text(".")

#text("Next, we note that we have the freedom to shift each ")#mi("{\\phi_h}")#text(" by ")#mi("{O(\\epsilon^c)}")#text(" (adjusting ")#mi("{c_{h,k}}")#text(" accordingly) without significantly affecting any of the properties already established. Doing so, we can thus ensure that all the ")#mi("{\\phi_h}")#text(" take values in ")#mi("{C^{\\prime}}")#text(" itself, which forces ")#mi("{c_{h,k}}")#text(" to do so also. But since ")#mi("{c_{h,k} = O(\\epsilon^c)}")#text(", we conclude that ")#mi("{c_{h,k} = 0}")#text(" for all ")#mi("{h,k}")#text(", thus ")#mi("{\\phi_h}")#text(" is a perfect cocycle:")

#align(center)[#tao-fit-display[#mitex("\\phi_{h+k} = \\phi_h T^h \\phi_k.")]]

#text("We may thus integrate ")#mi("{\\phi_h}")#text(" and write ")#mi("{\\phi_h = \\partial_h \\Phi}")#text(", where ")#mi("{\\Phi(x) := \\phi_x(0)}")#text(". Thus ")#mi("{\\partial_h \\Phi}")#text(" is a polynomial of degree ")#mi("{d-1}")#text(" for each ")#mi("{h}")#text(", thus ")#mi("{\\Phi}")#text(" itself is a polynomial of degree ")#mi("{d}")#text(". From ")#link(<tao-56486663a0524f94b141>)[#text("(1)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{x \\in V} e( \\partial_h (\\psi - \\Phi) ) = 1 + O( \\epsilon^c )")]]

#text("for all ")#mi("{h \\in V}")#text("; averaging in ")#mi("{V}")#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x \\in V} e( \\psi - \\Phi )\\right|^2 = 1 + O( \\epsilon^c )", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| e(\\psi) - e(\\Phi) \\right\\|_{L^1(V)} = O(\\epsilon^c)", block: true)]]

#text("and Proposition ")#link(<tao-8c1f1046219ddd216a02>)[#text("1")]#text(" follows.")

#text("One consequence of Proposition ")#link(<tao-8c1f1046219ddd216a02>)[#text("1")]#text(" is that the property of being a classical polynomial of a fixed degree ")#mi("{d}")#text(" is ")#emph[#text("locally testable")]#text(", which is a notion of interest in theoretical computer science. More precisely, suppose one is given a large finite vector space ")#mi("{V}")#text(" and two functions ")#mi("{\\phi_1, \\phi_2: V \\rightarrow {\\bf F}}")#text(". One is told that one of the functions ")#mi("{\\phi_1, \\phi_2}")#text(" is a classical polynomial of degree at most ")#mi("{d}")#text(", while the other is quite far from being such a classical polynomial, in the sense that every polynomial of degree at most ")#mi("{d}")#text(" will differ with that polynomial on at least ")#mi("{\\epsilon}")#text(" of the values in ")#mi("{V}")#text(". The task is then to decide with a high degree of confidence which of the functions is a polynomial and which one is not, without inspecting too many of the values of ")#mi("{\\phi_1}")#text(" or ")#mi("{\\phi_2}")#text(".")

#text("This can be done as follows. Pick ")#mi("{x,h_1,\\ldots,h_{d+1} \\in V}")#text(" at random, and test whether the identities")

#align(center)[#tao-fit-display[#mitex("\\partial_{h_1} \\ldots \\partial_{h_{d+1}} \\phi_1(x) = 0")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\partial_{h_1} \\ldots \\partial_{h_{d+1}} \\phi_2(x) = 0")]]

#text("hold; note that one only has to inspect ")#mi("{\\phi_1, \\phi_2}")#text(" at ")#mi("{2^{d+1}}")#text(" values in ")#mi("{V}")#text(" for this. If one of these identities fails, then that function must not be polynomial, and so one has successfully decided which of the functions is polynomials. We claim that the probability that the identity fails for the non-polynomial function is at least ")#mi("{\\delta}")#text(" for some ")#mi("{\\delta \\gg_{d,{\\bf F}} \\epsilon^{O_{d,{\\bf F}}(1)}}")#text(", and so if one iterates this test ")#mi("{O_\\delta(1)}")#text(" times, one will be able to successfully solve the problem with probability arbitrarily close to ")#mi("{1}")#text(". To verify the claim, suppose for contradiction that the identity only failed at most ")#mi("{\\delta}")#text(" of the time for the non-polynomial (say it is ")#mi("{\\phi_2}")#text("); then ")#tao-math("{\\left\\| e(\\phi_2)\\right\\|_{U^{d+1}(V)} \\geq 1-O(\\delta)}", block: false)#text(", and thus by Proposition ")#link(<tao-8c1f1046219ddd216a02>)[#text("1")]#text(", ")#mi("{\\phi_2}")#text(" is very close in ")#mi("{L^1}")#text(" norm to a polynomial; rounding that polynomial to a root of unity we thus see that ")#mi("{\\phi_2}")#text(" agrees with high accuracy to a classical polynomial, which leads to a contradiction if ")#mi("{\\delta}")#text(" is chosen suitably.")

#heading(level: 1)[#strong[#text(" — 2. A partial counterexample in low characteristic — ")]]

#text("We now show a distinction between classical polynomials and non-classical polynomials that causes the inverse conjecture to fail in low characteristic if one insists on using classical polynomials. For simplicity we restrict attention to the characteristic two case ")#mi("{{\\bf F} = {\\bf F}_2}")#text(". We will use an argument of Alon and Beigel, reproduced in ")#link("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/")[#text("this paper of Green and myself")]#text(". A different argument (with stronger bounds) appears in ")#link("http://arxiv.org/abs/0711.3388")[#text("this paper of Lovett, Meshulam, and Samorodnitsky")]#text(".")

#text("We work in a standard vector space ")#mi("{V = {\\bf F}^n}")#text(", with standard basis ")#mi("{e_1,\\ldots,e_n}")#text(" and coordinates ")#mi("{x_1,\\ldots,x_n}")#text(". Among all the classical polynomials on this space are the ")#emph[#text("symmetric polynomials")]

#align(center)[#tao-fit-display[#mitex("S_m := \\sum_{1 \\leq i_1 < \\ldots < i_m \\leq n} x_{i_1} \\ldots x_{i_m},")]]

#text("which play a special role.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" ")#metadata(none) <tao-956fc30bfe11b61e7962>#text(" Let ")#mi("{L: V \\rightarrow {\\bf N}}")#text(" be the digit summation function ")#mi("{L := \\# \\{ 1 \\leq i \\leq n: x_i = 1 \\}}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("S_m = \\binom{L}{m} \\text{ mod } 2.")]]

#text("Establish ")#link("http://en.wikipedia.org/wiki/Lucas%27_theorem")[#text("Lucas’ theorem")]

#align(center)[#tao-fit-display[#mitex("S_m = S_{2^{j_1}} \\ldots S_{2^{j_r}}")]]

#text("where ")#mi("{m = 2^{j_1} + \\ldots + 2^{j_r}}")#text(", ")#mi("{j_1 > \\ldots>j_r}")#text(" is the binary expansion of ")#mi("{m}")#text(". Show that ")#mi("{S_{2^j}}")#text(" is the ")#mi("{2^j}")#text(" binary coefficient of ")#mi("{L}")#text(", and conclude that ")#mi("{S_m}")#text(" is a function of ")#mi("{L \\text{ mod } 2^{j_1}}")#text(". (")#emph[#text("Note:")]#text(" These results are closely related to the well-known fact that ")#link("http://en.wikipedia.org/wiki/Pascal's_triangle")[#text("Pascal’s triangle")]#text(" modulo ")#mi("{2}")#text(" takes the form of an infinite ")#link("http://en.wikipedia.org/wiki/Sierpinski_gasket")[#text("Sierpinski gasket")]#text(".)")
]

#text("We define an ")#emph[#text("an affine coordinate subspace")]#text(" to be a translate of a subspace of ")#mi("{V}")#text(" generated by some subset of the standard basis vectors ")#mi("{e_1,\\ldots,e_n}")#text(". To put it another way, an affine coordinate subspace is created by freezing some of the coordinates, but letting some other coordinates be arbitrary.")

#text("Of course, not all classical polynomials come from symmetric polynomials. However, thanks to an application of Ramsey’s theorem observed by Alon and Biegel, this is true on coordinate subspaces:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (Ramsey’s theorem for polynomials)")]#text(" ")#metadata(none) <tao-6cc61c7e47feff94898b>#text(" Let ")#mi("{P: {\\bf F}^n \\rightarrow {\\bf F}}")#text(" be a polynomial of degree at most ")#mi("{d}")#text(". Then one can partition ")#mi("{{\\bf F}^n}")#text(" into affine coordinate subspaces of dimension ")#mi("{W}")#text(" at least ")#mi("{\\omega_d(n)}")#text(", where ")#mi("{\\omega_d(n) \\rightarrow \\infty}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" for fixed ")#mi("{d}")#text(", such that on each such subspace ")#mi("{W}")#text(", ")#mi("{P}")#text(" is equal to a linear combination of the symmetric polynomials ")#mi("{S_0, S_1, \\ldots, S_d}")#text(".")
]

#emph[#text("Proof:")]#text(" We induct on ")#mi("{d}")#text(". The claim is trivial for ")#mi("{d=0}")#text(", so suppose that ")#mi("{d \\geq 1}")#text(" and the claim has already been proven for smaller ")#mi("{d}")#text(". The degree ")#mi("{d}")#text(" term ")#mi("{P_d}")#text(" of ")#mi("{P}")#text(" can be written as")

#align(center)[#tao-fit-display[#mitex("P_d = \\sum_{\\{i_1,\\ldots,i_d\\} \\in E} x_{i_1} \\ldots x_{i_d}")]]

#text("where ")#mi("{E}")#text(" is a ")#mi("{d}")#text("-uniform ")#link("http://en.wikipedia.org/wiki/Hypergraph")[#text("hypergraph")]#text(" on ")#mi("{\\{1,\\ldots,n\\}}")#text(", i.e. a collection of ")#mi("{d}")#text("-element subsets of ")#mi("{\\{1,\\ldots,n\\}}")#text(". Applying ")#link("http://en.wikipedia.org/wiki/Ramsey's_theorem")[#text("Ramsey’s theorem")]#text(" (for hypergraphs), one can find a subcollection ")#mi("{j_1,\\ldots,j_m}")#text(" of indices with ")#mi("{m \\geq \\omega_d(n)}")#text(" such that ")#mi("{E}")#text(" either has no edges in ")#mi("{\\{j_1,\\ldots,j_m\\}}")#text(", or else contains all the edges in ")#mi("{\\{j_1,\\ldots,j_m\\}}")#text(". We then foliate ")#mi("{{\\bf F}^n}")#text(" into the affine subspaces formed by translating the coordinate subspace generated by ")#mi("{e_{j_1},\\ldots,e_{j_m}}")#text(". By construction, we see that on each such subspace, ")#mi("{P}")#text(" is equal to either ")#mi("{0}")#text(" or ")#mi("{S_d}")#text(" plus a polynomial of degree ")#mi("{d-1}")#text(". The claim then follows by applying the induction hypothesis (and noting that the linear span of ")#mi("{S_0,\\ldots,S_{d-1}}")#text(" on an affine coordinate subspace is equivariant with respect to translation of that subspace). ")#mi("\\Box")

#text("Because of this, if one wants to concoct a function which is almost orthogonal to all polynomials of degree at most ")#mi("{d}")#text(", it will suffice to build a function which is almost orthogonal to the symmetric polynomials ")#mi("{S_0,\\ldots,S_d}")#text(" on all affine coordinate subspaces of moderately large size. Pursuing this idea, we are led to")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6 (Counterexample to classical inverse conjecture)")]#text(" Let ")#mi("{d \\geq 1}")#text(", and let ")#mi("{f: {\\bf F}_2^n \\rightarrow S^1}")#text(" be the function ")#mi("{f := e(L/2^d)}")#text(", where ")#mi("{L}")#text(" is as in Exercise ")#link(<tao-956fc30bfe11b61e7962>)[#text("4")]#text(". Then ")#mi("{L/2^d \\text{ mod } 1}")#text(" is a non-classical polynomial of degree at most ")#mi("{d}")#text(", and so ")#tao-math("{\\left\\|f\\right\\|_{U^{d+1}({\\bf F}_2^n)} = 1}", block: false)#text("; but one has")

#align(center)[#tao-fit-display[#mitex("\\langle f, e(\\phi) \\rangle_{L^2({\\bf F}_2^n)} = o_{n \\rightarrow \\infty; d}(1)")]]

#text("uniformly for all classical polynomials ")#mi("{\\phi}")#text(" of degree less than ")#mi("{2^{d-1}}")#text(", where ")#mi("{o_{n \\rightarrow \\infty; d}(1)}")#text(" is bounded in magnitude by a quantity that goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(" for each fixed ")#mi("{d}")#text(".")
]

#emph[#text("Proof:")]#text(" We first prove the polynomiality of ")#mi("{L/2^d \\text{ mod } 1}")#text(". Let ")#tao-math("{x \\mapsto \\left|x\\right|}", block: false)#text(" be the obvious map from ")#mi("{{\\bf F}_2}")#text(" to ")#mi("{\\{0,1\\}}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("L = \\sum_{i=1}^n |x_i|.")]]

#text("By linearity, it will suffice to show that each function ")#tao-math("{\\left|x_i\\right| \\text{ mod } 2^d}", block: false)#text(" is a polynomial of degree at most ")#mi("{d}")#text(". But one easily verifies that for any ")#mi("{h \\in {\\bf F}_2^n}")#text(", ")#tao-math("{\\partial_h \\left|x_i\\right|}", block: false)#text(" is equal to zero when ")#mi("{h_i=0}")#text(" and equal to ")#tao-math("{1-2\\left|x_i\\right|}", block: false)#text(" when ")#mi("{h_i=1}")#text(". Iterating this observation ")#mi("{d}")#text(" times, we obtain the claim.")

#text("Now let ")#mi("{\\phi}")#text(" be a classical polynomial of degree less than ")#mi("{2^{d-1}}")#text(". By Lemma ")#link(<tao-6cc61c7e47feff94898b>)[#text("5")]#text(", we can partition ")#mi("{{\\bf F}_2^n}")#text(" into affine coordinate subspaces ")#mi("{W}")#text(" of dimension at least ")#mi("{\\omega_d(n)}")#text(" such that ")#mi("{\\phi}")#text(" is a linear combination of ")#mi("{S_0,\\ldots,S_{2^{d-1}-1}}")#text(" on each such subspace. By the pigeonhole principle, we thus can find such a ")#mi("{W}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle f, e(\\phi) \\rangle_{L^2({\\bf F}_2^n)}\\right| \\leq \\left|\\langle f, e(\\phi) \\rangle_{L^2(W)}\\right|.", block: true)]]

#text("On the other hand, from Exercise ")#link(<tao-956fc30bfe11b61e7962>)[#text("4")]#text(", the function ")#mi("{\\phi}")#text(" on ")#mi("{W}")#text(" depends only on ")#mi("{L \\text{ mod } 2^{d-1}}")#text(". Now, as ")#mi("{\\text{dim}(W) \\rightarrow \\infty}")#text(", the function ")#mi("{L \\text{ mod } 2^d}")#text(" (which is essentially the distribution function of a simple random walk of length ")#mi("{\\text{dim}(V)}")#text(" on ")#mi("{{\\bf Z}/2^d{\\bf Z}}")#text(") becomes equidistributed; in particular, for any ")#mi("{a \\in {\\bf Z}/2^d{\\bf Z}}")#text(", the function ")#mi("{f}")#text(" will take the values ")#mi("{e(a/2^d)}")#text(" and ")#mi("{-e(a/2^d)}")#text(" with asymptotically equal frequency on ")#mi("{W}")#text(", whilst ")#mi("{\\phi}")#text(" remains unchanged. As such we see that ")#tao-math("{\\left|\\langle f, e(\\phi) \\rangle_{L^2(W)}\\right| \\rightarrow 0}", block: false)#text(" as ")#mi("{\\text{dim}(W) \\rightarrow \\infty}")#text(", and thus as ")#mi("{n \\rightarrow \\infty}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" With the same setup as the previous proposition, show that ")#tao-math("{\\left\\|e(S_{2^{d-1}}/2)\\right\\|_{U^{d+1}({\\bf F}_2^n)} \\gg 1}", block: false)#text(", but that ")#mi("{\\langle e( S^{2^{d-1}}/2 ), e(\\phi) \\rangle_{L^2({\\bf F}_2^n)} = o_{n \\rightarrow \\infty; d}(1)}")#text(" for all classical polynomials ")#mi("{\\phi}")#text(" of degree less than ")#mi("{2^{d-1}}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 3. The ")#mi("{1\\%}")#text(" inverse theorem: sketches of a proof — ")]]

#text("The proof of Theorem ")#link(<tao-76f5c27d49afeeb5a673>)[#text("3")]#text(" is rather difficult once ")#mi("{d \\geq 2}")#text("; even the ")#mi("{d=2}")#text(" case is not particularly easy. However, the arguments still have the same cohomological flavour encountered in the ")#mi("{99\\%}")#text(" theory. We will not give full proofs of this theorem here, but indicate some of the main ideas.")

#text("We begin by discussing (quite non-rigorously) the significantly simpler (but still non-trivial) ")#mi("{d=2}")#text(" case, established ")#link("http://www.ams.org/mathscinet-getitem?mr=2391635")[#text("by Ben Green and myself")]#text(". Unsurprisingly, we will take advantage of the ")#mi("{d=1}")#text(" case of the theorem as an induction hypothesis.")

#text("Let ")#mi("{V = {\\bf F}^n}")#text(" for some field ")#mi("{{\\bf F}}")#text(" of characteristic greater than ")#mi("{2}")#text(", and ")#mi("{f}")#text(" be a function with ")#tao-math("{\\left\\|f\\right\\|_{L^\\infty(V)} \\leq 1}", block: false)#text(" and ")#tao-math("{\\left\\|f\\right\\|_{U^3(V)} \\gg 1}", block: false)#text(". We would like to show that ")#mi("{f}")#text(" correlates with a quadratic phase function ")#mi("{e(\\phi)}")#text(" (due to the characteristic hypothesis, we may take ")#mi("{\\phi}")#text(" to be classical), in the sense that ")#tao-math("{\\left|\\langle f, e(\\phi) \\rangle_{L^2(V)}\\right| \\gg 1}", block: false)#text(".")

#text("We expand ")#tao-math("{\\left\\|f\\right\\|_{U^3(V)}^8}", block: false)#text(" as ")#tao-math("{\\mathop{\\bf E}_{h \\in V} \\left\\| \\Delta_h f \\right\\|_{U^2(V)}^4}", block: false)#text(". By the pigeonhole principle, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\Delta_h f \\right\\|_{U^2(V)} \\gg 1", block: true)]]

#text("for “many” ")#mi("{h\\in V}")#text(", where by “many” we mean “a proportion of ")#mi("{\\gg 1}")#text("“. Applying the ")#mi("{U^2}")#text(" inverse theorem, we conclude that for many ")#mi("{h}")#text(", that there exists a linear polynomial ")#mi("{\\phi_h: V \\rightarrow {\\bf F}}")#text(" (which we may as well take to be classical) such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle \\Delta_h f, e(\\phi_h) \\rangle_{L^2(V)}\\right| \\gg 1.", block: true)]]

#text("This should be compared with the ")#mi("{99\\%}")#text(" theory. There, we were able to force ")#mi("{\\Delta_h f}")#text(" close to ")#mi("{e(\\phi_h)}")#text(" for most ")#mi("{h}")#text("; here, we only have the weaker statement that ")#mi("{\\Delta_h f}")#text(" ")#emph[#text("correlates")]#text(" with ")#mi("{e(\\phi_h)}")#text(" for ")#emph[#text("many")]#text(" (not ")#emph[#text("most")]#text(") ")#mi("{h}")#text(". Still, we will keep going. In the ")#mi("{99\\%}")#text(" theory, we were able to assume ")#mi("{f}")#text(" had magnitude ")#mi("{1}")#text(", which made the cocycle equation ")#mi("{\\Delta_{h+k} f = (\\Delta_h f) T^h \\Delta_k f}")#text(" available; this then forced an approximate cocycle equation ")#mi("{\\phi_{h+k} \\approx \\phi_h + T^h \\phi_k}")#text(" for most ")#mi("{h,k}")#text(" (indeed, we were able to use this trick to upgrade “most” to “all”).")

#text("This doesn’t quite work in the ")#mi("{1\\%}")#text(" case. Firstly, ")#mi("{f}")#text(" need not have magnitude exactly equal to ")#mi("{1}")#text(". This is not a terribly serious problem, but the more important difficulty is that correlation, unlike the property of being close, is not transitive or multiplicative: just because ")#mi("{\\Delta_h f}")#text(" correlates with ")#mi("{e(\\phi_h)}")#text(", and ")#mi("{T^h \\Delta_k f}")#text(" correlates with ")#mi("{T^h e(\\phi_k)}")#text(", one cannot then conclude that ")#mi("{\\Delta_{h+k} f = (\\Delta_h f) T^h \\Delta_k f}")#text(" correlates with ")#mi("{e(\\phi_h) T^h e(\\phi_k)}")#text("; and even if one had this, and if ")#mi("{\\Delta_{h+k} f}")#text(" correlated with ")#mi("{e(\\phi_{h+k})}")#text(", one could not conclude that ")#mi("{e(\\phi_{h+k})}")#text(" correlated with ")#mi("{e(\\phi_h) T^h e(\\phi_k)}")#text(".")

#text("Despite all these obstacles, it is still possible to extract something resembling a cocycle equation for the ")#mi("{\\phi_h}")#text(", by means of the Cauchy-Schwarz inequality. Indeed, we have the following remarkable observation of Gowers:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7 (Gowers’ Cauchy-Schwarz argument)")]#text(" ")#metadata(none) <tao-3c3543a21a7ca358a170>#text(" Let ")#mi("{V}")#text(" be a finite additive group, and let ")#mi("{f: V \\rightarrow {\\bf C}}")#text(" be a function, bounded by ")#mi("{1}")#text(". Let ")#mi("{H \\subset V}")#text(" be a subset with ")#tao-math("{\\left|H\\right| \\gg \\left|V\\right|}", block: false)#text(", and suppose that for each ")#mi("{h \\in H}")#text(", suppose that we have a function ")#mi("{\\chi_h: V \\rightarrow {\\bf C}}")#text(" bounded by ")#mi("{1}")#text(", such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle \\Delta_h f, \\chi_h \\rangle_{L^2(V)}\\right| \\gg 1", block: true)]]

#text("uniformly in ")#mi("{h}")#text(". Then there exist ")#tao-math("{\\gg \\left|V\\right|^3}", block: false)#text(" quadruples ")#mi("{h_1,h_2,h_3,h_4 \\in H}")#text(" with ")#mi("{h_1+h_2=h_3+h_4}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x \\in V} \\chi_{h_1}(x) \\chi_{h_2}(x+h_1-h_4) \\overline{\\chi_{h_3}}(x) \\overline{\\chi_{h_4}}(x+h_1-h_4)\\right| \\gg 1", block: true)]]

#text("uniformly among the quadruples.")
]

#text("We shall refer to quadruples ")#mi("{(h_1,h_2,h_3,h_4)}")#text(" obeying the relation ")#mi("{h_1+h_2=h_3+h_4}")#text(" as ")#emph[#text("additive quadruples")]#text(".")

#emph[#text("Proof:")]#text(" We extend ")#mi("{\\chi_h}")#text(" to be zero when ")#mi("{h}")#text(" lies outside of ")#mi("{H}")#text(". Then we have")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{h \\in V} \\left|\\langle \\Delta_h f, \\chi_h \\rangle_{L^2(V)}\\right|^2 \\gg 1.", block: true)]]

#text("We expand the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{h,x,k \\in V} f(x+h) \\overline{f(x)} f(x+k) \\overline{f(x+h+k)} \\overline{\\chi_h(x)} \\chi_h(x+k);")]]

#text("setting ")#mi("{y := x+h}")#text(", this becomes")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{k,x,y \\in V} \\Delta_k f(x) \\overline{\\Delta_k f(y)} \\overline{\\Delta_k \\chi_{y-x}(x)}.")]]

#text("From the pigeonhole principle, we conclude that for many values of ")#mi("{k}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x,y \\in V} \\Delta_k f(x) \\overline{\\Delta_k f(y)} \\overline{\\Delta_k \\chi_{y-x}(x)}\\right| \\gg 1.", block: true)]]

#text("Performing Cauchy-Schwarz once in ")#mi("{x}")#text(" and once in ")#mi("{y}")#text(" to eliminate the ")#mi("{f}")#text(" factors, and then re-averaging in ")#mi("{k}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{k \\in V} \\mathop{\\bf E}_{x,x^{\\prime},y,y^{\\prime} \\in V} \\overline{\\Delta_k \\chi_{y-x}(x)} \\Delta_k \\chi_{y^{\\prime}-x}(x) \\Delta_k \\chi_{y-x^{\\prime}}(x^{\\prime}) \\overline{\\Delta_k \\chi_{y^{\\prime}-x^{\\prime}}(x^{\\prime})} \\gg 1.")]]

#text("Setting ")#mi("{(h_1,h_2,h_3,h_4)}")#text(" to be the additive quadruple ")#mi("{(y^{\\prime}-x, y-x^{\\prime}, y-x, y^{\\prime}-x^{\\prime})}")#text(" we obtain")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{h_1+h_2=h_3+h_4} \\mathop{\\bf E}_{k,x \\in V} \\Delta_k \\chi_{h_1}(x) \\Delta_k \\chi_{h_2}(x+h_1-h_4) \\Delta_k \\overline{\\chi_{h_3}}(x) \\Delta_k \\overline{\\chi_{h_4}}(x+h_1-h_4)")]]

#align(center)[#tao-fit-display[#mitex("\\gg 1.")]]

#text("Performing the ")#mi("{k, x}")#text(" averages we obtain")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{h_1+h_2=h_3+h_4} \\left|\\mathop{\\bf E}_{x \\in V} \\chi_{h_1}(x) \\chi_{h_2}(x+h_1-h_4) \\overline{\\chi_{h_3}}(x) \\overline{\\chi_{h_4}}(x+h_1-h_4)\\right|^2 \\gg 1,", block: true)]]

#text("and the claim follows (note that for the quadruples obeying the stated lower bound, ")#mi("{h_1,h_2,h_3,h_4}")#text(" must lie in ")#mi("{H}")#text("). ")#mi("\\Box")

#text("Applying this lemma to our current situation, we find many additive quadruples ")#mi("{(h_1,h_2,h_3,h_4)}")#text(" for which")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x \\in V} e( \\phi_{h_1}(x) + \\phi_{h_2}(x+h_1-h_4) - \\phi_{h_3}(x) - \\phi_{h_4}(x+h_1-h_4) )\\right| \\gg 1.", block: true)]]

#text("In particular, by the equidistribution theory in ")#link("https://terrytao.wordpress.com/2010/05/08/254b-lecture-notes-4-equidistribution-of-polynomials-over-finite-fields/")[#text("Notes 4")]#text(", the polynomial ")#mi("{\\phi_{h_1} + \\phi_{h_2} - \\phi_{h_3} - \\phi_{h_4}}")#text(" is low rank.")

#text("The above discussion is valid in any value of ")#mi("{d \\geq 2}")#text(", but is particularly simple when ")#mi("{d=2}")#text(", as the ")#mi("{\\phi_h}")#text(" are now linear, and so ")#mi("{\\phi_{h_1} + \\phi_{h_2} - \\phi_{h_3} - \\phi_{h_4}}")#text(" is now ")#emph[#text("constant")]#text(". Writing ")#mi("{\\phi_h(x) = \\xi_h \\cdot x + \\theta_h}")#text(" for some ")#mi("{\\xi_h \\in V}")#text(" using the standard dot product on ")#mi("{V}")#text(", and some (irrelevant) constant term ")#mi("{\\theta_h \\in {\\bf F}}")#text(", we conclude that ")#metadata(none) <tao-93a307331ed950f172f1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\xi_{h_1} + \\xi_{h_2} = \\xi_{h_3} + \\xi_{h_4}")]]

#text("for many additive quadruples ")#mi("{h_1,h_2,h_3,h_4}")#text(".")

#text("We now have to solve an additive combinatorics problem, namely to classify the functions ")#mi("{h \\mapsto \\xi_h}")#text(" from ")#mi("{V}")#text(" to ")#mi("{V}")#text(" which are “")#mi("{1\\%}")#text(" affine linear” in the sense that the property ")#link(<tao-93a307331ed950f172f1>)[#text("(3)")]#text(" holds for many additive quadruples; equivalently, the graph ")#mi("{\\{ (h, \\xi_h): h \\in H \\}}")#text(" in ")#mi("{V \\times V}")#text(" has high “additive energy”, defined as the number of additive quadruples that it contains. An obvious example of a function with this property is an affine-linear function ")#mi("{\\xi_h = Mh + \\xi_0}")#text(", where ")#mi("{M: V \\rightarrow V}")#text(" is a linear transformation and ")#mi("{\\xi_0 \\in V}")#text(". As it turns out, this is essentially the only example:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8 (Balog-Szemerédi-Gowers-Freiman theorem for vector spaces)")]#text(" Let ")#mi("{H \\subset V}")#text(", and let ")#mi("{h \\mapsto \\xi_h}")#text(" be a map from ")#mi("{H}")#text(" to ")#mi("{V}")#text(" such that ")#link(<tao-93a307331ed950f172f1>)[#text("(3)")]#text(" holds for ")#tao-math("{\\gg \\left|V\\right|^3}", block: false)#text(" additive quadruples in ")#mi("{H}")#text(". Then there exists an affine function ")#mi("{h \\mapsto Mh + \\xi_0}")#text(" such that ")#mi("{\\xi_h = Mh + \\xi_0}")#text(" for ")#tao-math("{\\gg \\left|V\\right|}", block: false)#text(" values of ")#mi("{h}")#text(" in ")#mi("{H}")#text(".")
]

#text("This proposition is a consequence of standard results in additive combinatorics, in particular the Balog-Szemerédi-Gowers lemma and Freiman’s theorem for vector spaces; see Section 11.3 of ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van")]#text(" for further discussion. The proof is elementary but a little lengthy and would take us too far afield, so we simply assume this proposition for now and keep going. We conclude that ")#metadata(none) <tao-f9b7e0c39aaeffb56e35>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|\\mathop{\\bf E}_{x \\in V} \\Delta_h f(x) e( Mh \\cdot x ) e( \\xi_0 \\cdot x )\\right| \\gg 1", block: true)]]

#text("for many ")#mi("{h \\in V}")#text(".")

#text("The most difficult term to deal with here is the quadratic term ")#mi("{Mh \\cdot x}")#text(". To deal with this term, suppose temporarily that ")#mi("{M}")#text(" is symmetric, thus ")#mi("{Mh \\cdot x = Mx \\cdot h}")#text(". Then (since we are in odd characteristic) we can ")#emph[#text("integrate")]#text(" ")#mi("{Mh \\cdot x}")#text(" as")

#align(center)[#tao-fit-display[#mitex("Mh \\cdot x = \\partial_h ( \\frac{1}{2} Mx \\cdot x ) - \\frac{1}{2} M h \\cdot h")]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x \\in V} f(x+h) e( \\frac{1}{2} M(x+h) \\cdot (x+h) ) \\overline{f(x)} e( - \\frac{1}{2} Mx \\cdot x ) e( \\xi_0 \\cdot x )\\right| \\gg 1", block: true)]]

#text("for many ")#mi("{h \\in H}")#text(". Taking ")#mi("{L^2}")#text(" norms in ")#mi("{h}")#text(", we conclude that the ")#mi("{U^2}")#text(" inner product between two copies of ")#mi("{f(x) e( \\frac{1}{2} Mx \\cdot x)}")#text(" and two copies of ")#mi("{f(x) e( \\frac{1}{2} Mx \\cdot x) e(-\\xi_0 \\cdot x)}")#text(". Applying the ")#mi("{U^2}")#text(" Cauchy-Schwarz-Gowers inequality, followed by the ")#mi("{U^2}")#text(" inverse theorem, we conclude that ")#mi("{f(x) e(\\frac{1}{2} Mx \\cdot x)}")#text(" correlates with ")#mi("{e(\\phi)}")#text(" for some linear phase, and thus ")#mi("{f}")#text(" itself correlates with ")#mi("{e(\\psi)}")#text(" for some quadratic phase.")

#text("This argument also works (with minor modification) when ")#mi("{M}")#text(" is ")#emph[#text("virtually symmetric")]#text(", in the sense that there exist a bounded index subspace of ")#mi("{V}")#text(" such that the restriction of the form ")#mi("{Mh \\cdot x}")#text(" to ")#mi("{V}")#text(" is symmetric, by foliating into cosets of that subspace; we omit the details. On the other hand, if ")#mi("{M}")#text(" is not virtually symmetric, there is no obvious way to “integrate” the phase ")#mi("{e(Mh \\cdot x)}")#text(" to eliminate it as above. (Indeed, in order for ")#mi("{Mh \\cdot x}")#text(" to be “exact” in the sense that it is the “derivative” of something (modulo lower order terms), e.g. ")#mi("{Mh \\cdot x \\approx \\partial_h \\Phi}")#text(" for some ")#mi("{\\Phi}")#text(", it must first be “closed” in the sense that ")#mi("{\\partial_k(Mh \\cdot x) \\approx \\partial_h(Mk \\cdot x)}")#text(" in some sense, since we have ")#mi("{\\partial_h \\partial_k = \\partial_k \\partial_h}")#text("; thus we again see the emergence of cohomological concepts in the background.)")

#text("To establish the required symmetry on ")#mi("{M}")#text(", we return to Gowers’ Cauchy-Schwarz argument from Lemma ")#link(<tao-3c3543a21a7ca358a170>)[#text("7")]#text(", and tweak it slightly. We start with ")#link(<tao-f9b7e0c39aaeffb56e35>)[#text("(4)")]#text(" and rewrite it as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x \\in V} f(x+h) f^{\\prime}(x) e(Mh \\cdot x)\\right| \\gg 1", block: true)]]

#text("where ")#mi("{f^{\\prime}(x) := \\overline{f(x)} e(\\xi_0 \\cdot x)}")#text(". We square-average this in ")#mi("{h}")#text(" to obtain")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x,y,h \\in V} f(x+h) f^{\\prime}(x) \\overline{f(y+h)} \\overline{f^{\\prime}(y)} e(Mh \\cdot (x-y))\\right| \\gg 1.", block: true)]]

#text("Now we make the somewhat unusual substitution ")#mi("{z=x+y+h}")#text(" to obtain")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x,y,z \\in V} f(z-y) f^{\\prime}(x) \\overline{f(z-x)} \\overline{f^{\\prime}(y)} e(M(z-x-y) \\cdot (x-y))\\right| \\gg 1.", block: true)]]

#text("Thus there exists ")#mi("{z}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x,y \\in V} f(z-y) f^{\\prime}(x) \\overline{f(z-x)} \\overline{f^{\\prime}(y)} e(M(z-x-y) \\cdot (x-y))\\right| \\gg 1.", block: true)]]

#text("We collect all terms that depend only on ")#mi("{x}")#text(" (and ")#mi("{z}")#text(") or only on ")#mi("{y}")#text(" (and ")#mi("{z}")#text(") to obtain")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x,y \\in V} f_{z,1}(x) f_{z,2}(y) e(M x \\cdot y - M y \\cdot x)\\right| \\gg 1", block: true)]]

#text("for some bounded functions ")#mi("{f_{z,1}, f_{z,2}}")#text(". Eliminating these functions by two applications of Cauchy-Schwarz, we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{x,y,x^{\\prime},y^{\\prime} \\in V} e(M (x-x^{\\prime}) \\cdot (y-y^{\\prime}) - M (y-y^{\\prime}) \\cdot (x-x^{\\prime}))\\right| \\gg 1", block: true)]]

#text("or, on making the change of variables ")#mi("{a := x-x^{\\prime}, b := y-y^{\\prime}}")#text(",")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{a,b \\in V} e(M a \\cdot b - Mb \\cdot a )\\right| \\gg 1.", block: true)]]

#text("Using equidistribution theory, this means that the quadratic form ")#mi("{(a,b) \\mapsto M a \\cdot b - M b \\cdot a}")#text(" is low rank, which easily implies that ")#mi("{M}")#text(" is virtually symmetric.")

#text("Now we turn to the general ")#mi("{d}")#text(" case. In principle, the above argument should still work, say for ")#mi("{d=3}")#text(". The main sticking point is that instead of dealing with a vector-valued function ")#mi("{h \\mapsto \\xi_h}")#text(" that is approximately linear in the sense that ")#link(<tao-93a307331ed950f172f1>)[#text("(3)")]#text(" holds for many additive quadruples, in the ")#mi("{d=3}")#text(" case one is now faced with a \\xi_{h_1}")

#align(center)[#tao-fit-display[#mitex("M_{h_1} + M_{h_2} = M_{h_3} + M_{h_4} + LR_{h_1,h_2,h_3,h_4}")]]

#text("for many additive quadruples ")#mi("{h_1,h_2,h_3,h_4}")#text(", where the matrix ")#mi("{LR_{h_1,h_2,h_3,h_4}}")#text(" has bounded rank. With our current level of additive combinatorics technology, we are not able to deal properly with this bounded rank error (the main difficulty being that the set of low rank matrices has no good “doubling” properties). Because of this obstruction, no generalisation of the above arguments to higher ")#mi("{d}")#text(" has been found.")

#text("There is however another approach, based ultimately on the ergodic theory work ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("of Host-Kra")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2257397")[#text("of Ziegler")]#text(", that can handle the general ")#mi("{d}")#text(" case, which was worked out in two papers, one by ")#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/")[#text("myself and Ziegler")]#text(", and one ")#link("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/")[#text("by Bergelson, Ziegler, and myself")]#text(". It turns out that it is convenient to phrase these arguments in the language of ergodic theory. However, in order not to have to introduce too much additional material, I will try to describe the arguments here in the case ")#mi("{d=3}")#text(" without explicitly using ergodic theory notation. To do this, though, I will have to sacrifice a lot of rigour and only work with some illustrative special cases rather than the general case, and also use somewhat vague terminology (e.g. “general position” or “low rank”).")

#text("To simplify things further, we will establish the ")#mi("{U^3}")#text(" inverse theorem only for a special type of function, namely a quartic phase ")#mi("{e( \\phi )}")#text(", where ")#mi("{\\phi: V \\rightarrow {\\bf F}}")#text(" is a classical polynomial of degree ")#mi("{4}")#text(". (A good example to keep in mind is the symmetric polynomial phase ")#mi("{e(S_2/2)}")#text(", though one has to take some care with this example due to the low characteristic.) The claim to show then is that if ")#tao-math("{\\left\\|e(\\phi)\\right\\|_{U^3(V)} \\gg 1}", block: false)#text(", then ")#mi("{e(\\phi)}")#text(" correlates with a cubic phase. In the high characteristic case ")#mi("{p > 4}")#text(", this result can be handled by equidistribution theory. Indeed, since")

#align(center)[#tao-fit-display[#tao-math("\\left\\|e(\\phi)\\right\\|_{U^3(V)}^8 = \\mathop{\\bf E}_{x,h_1,h_2,h_3,h_4} e( \\partial_{h_1} \\partial_{h_2} \\partial_{h_3} \\partial_{h_4} \\phi(x) ),", block: true)]]

#text("that theory tells us that the quartic polynomial ")#mi("{(x,h_1,h_2,h_3,h_4) \\mapsto \\partial_{h_1} \\partial_{h_2} \\partial_{h_3} \\partial_{h_4} \\phi(x)}")#text(" is low rank. On the other hand, in high characteristic one has the Taylor expansion")

#align(center)[#tao-fit-display[#mitex("\\phi(x) = \\frac{1}{4!} \\partial_x \\partial_x \\partial_x \\partial_x \\phi(0) + Q(x)")]]

#text("for some cubic function ")#mi("{Q}")#text(" (as can be seen for instance by decomposing into monomials). From this we easily conclude that ")#mi("{\\phi}")#text(" itself has low rank (i.e. it is a function of boundedly many cubic (or lower degree) polynomials), at which point it is easy to see from Fourier analysis that ")#mi("{e(\\phi)}")#text(" will correlate with the exponential of a polynomial of degree at most ")#mi("{3}")#text(".")

#text("Now we present a different argument that relies slightly less on the quartic nature of ")#mi("{\\phi}")#text("; it is a substantially more difficult argument, and we will skip some steps here to simplify the exposition, but the argument happens to extend to more general situations. As ")#tao-math("{\\left\\|e(\\phi)\\right\\|_{U^3} \\gg 1}", block: false)#text(", we have ")#tao-math("{\\left\\| \\Delta_h e(\\phi) \\right\\|_{U^2} \\gg 1}", block: false)#text(" for many ")#mi("{h}")#text(", thus by the inverse ")#mi("{U^2}")#text(" theorem, ")#mi("{\\Delta_h e(\\phi) = e(\\partial_h \\phi)}")#text(" correlates with a quadratic phase. Using equidistribution theory, we conclude that the cubic polynomial ")#mi("{\\partial_h \\phi}")#text(" is low rank.")

#text("At present, the low rank property for ")#mi("{\\partial_h \\phi}")#text(" is only true for many ")#mi("{h}")#text(". But from the cocycle identity ")#metadata(none) <tao-ddd02a0345ad6d42b737>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\partial_{h+k} \\phi = \\partial_h \\phi + T^h \\partial_k \\phi,")]]

#text("we see that if ")#mi("{\\partial_h \\phi}")#text(" and ")#mi("{\\partial_k \\phi}")#text(" are both low rank, then so is ")#mi("{\\partial_{h+k} \\phi}")#text("; thus the property of ")#mi("{\\partial_h \\phi}")#text(" being low rank is in some sense preserved by addition. Using this and a bit of additive combinatorics, one can conclude that ")#mi("{\\partial_h \\phi}")#text(" is low rank for all ")#mi("{h}")#text(" in a bounded index subspace of ")#mi("{V}")#text("; restricting to that subspace, we will now assume that ")#mi("{\\partial_h \\phi}")#text(" is low rank for ")#emph[#text("all")]#text(" ")#mi("{h \\in V}")#text(". Thus we have")

#align(center)[#tao-fit-display[#mitex("\\partial_h \\phi = F_h( \\vec Q_h )")]]

#text("where ")#mi("{\\vec Q_h}")#text(" is some bounded collection of quadratic polynomials for each ")#mi("{h}")#text(", and ")#mi("{F_h}")#text(" is some function. To simplify the discussion, let us pretend that ")#mi("{\\vec Q_h}")#text(" in fact consists of just a single quadratic ")#mi("{Q_h}")#text(", plus some linear polynomials ")#mi("{\\vec L_h}")#text(", thus ")#metadata(none) <tao-2ad3db485e6826204060>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\partial_h \\phi = F_h( Q_h, \\vec L_h )")]]

#text("There are two extreme cases to consider, depending on how ")#mi("{Q_h}")#text(" depends on ")#mi("{h}")#text(". Consider first a “core” case when ")#mi("{Q_h = Q}")#text(" is independent of ")#mi("{h}")#text(". Thus ")#metadata(none) <tao-44162b0c77ee3b59a24a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\partial_h \\phi = F_h( Q, \\vec L_h )")]]

#text("If ")#mi("{Q}")#text(" is low rank, then we can absorb it into the ")#mi("{L_h}")#text(" factors, so suppose instead thaat ")#mi("{Q}")#text(" is high rank, and thus equidistributed even after fixing the values of ")#mi("{L_h}")#text(".")

#text("The function ")#mi("{\\partial_h \\phi}")#text(" is cubic, and ")#mi("{Q}")#text(" is a high rank quadratic. Because of this, the function ")#mi("{F^{\\prime}(Q,L_h)}")#text(" must be at most linear in the ")#mi("{Q}")#text(" variable; this can be established by another application of equidistribution theory, see Section 8 of ")#link("http://arxiv.org/abs/0711.3191")[#text("this paper of Ben and myself")]#text("; thus one can factorise")

#align(center)[#tao-fit-display[#mitex("\\partial_h \\phi = Q F^{\\prime}_h( L_h ) + F^{\\prime\\prime}_h(L_h)")]]

#text("for some functions ")#mi("{F^{\\prime}_h, F^{\\prime\\prime}_h}")#text(". In fact, as ")#mi("{\\partial_h \\phi}")#text(" is cubic, ")#mi("{F^{\\prime}_h}")#text(" must be linear, while ")#mi("{F^{\\prime\\prime}_h}")#text(" is cubic.")

#text("By comparing the ")#mi("{Q}")#text(" coefficients ")#mi("{F^{\\prime\\prime}_h(L_h)}")#text(" in the cocycle equation ")#link(<tao-ddd02a0345ad6d42b737>)[#text("(5)")]#text(", we see that the function ")#mi("{\\rho_h := F^{\\prime\\prime}_h(L_h)}")#text(" is itself a cocycle:")

#align(center)[#tao-fit-display[#mitex("\\rho_{h+k} = \\rho_h + T^h \\rho_k.")]]

#text("As a consequence, we have ")#mi("{\\rho_h = \\partial_h R}")#text(" for some function ")#mi("{R: V \\rightarrow {\\bf R}/{\\bf Z}}")#text(". Since ")#mi("{\\rho_h}")#text(" is linear, ")#mi("{R}")#text(" is quadratic; thus we have ")#metadata(none) <tao-7d601f9d20703a97b8cb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\partial_h \\phi = Q \\partial_h R + F^{\\prime\\prime}_h(L_h).")]]

#text("With a high characteristic assumption ")#mi("{p > 2}")#text(", one can ensure ")#mi("{R}")#text(" is classical. We will assume that ")#mi("{R}")#text(" is high rank, as this is the most difficult case.")

#text("Suppose first that ")#mi("{Q=R}")#text(". In high characteristic, one can then integrate ")#mi("{Q \\partial_h Q}")#text(" by expressing this as ")#mi("{\\partial_h (\\frac{1}{2} Q^2 )}")#text(" plus lower order terms, thus ")#mi("{\\partial_h (\\phi - \\frac{1}{2} Q^2 )}")#text(" is an order ")#mi("{1}")#text(" function in the sense that it is a function of a bounded number of linear functions. In particular, ")#mi("{e( \\partial_h (\\phi - \\frac{1}{2} Q^2 ) )}")#text(" has a large ")#mi("{U^2}")#text(" norm for all ")#mi("{h}")#text(", which implies that ")#mi("{e( \\phi - \\frac{1}{2} Q^2 )}")#text(" has a large ")#mi("{U^3}")#text(" norm, and thus correlates with a quadratic phase. Since ")#mi("{e( \\frac{1}{2} Q^2 )}")#text(" can be decomposed by Fourier analysis into a linear combination of quadratic phases, we conclude that ")#mi("{e(\\phi)}")#text(" correlates with a quadratic phase and one is thus done in this case.")

#text("Now consider the other extreme, in which ")#mi("{Q}")#text(" and ")#mi("{R}")#text(" lie in general position. Then, if we differentiate ")#link(<tao-7d601f9d20703a97b8cb>)[#text("(8)")]#text(" in ")#mi("{k}")#text(", we obtain one has")

#align(center)[#tao-fit-display[#mitex("\\partial_k \\partial_h \\phi = \\partial_k Q \\partial_h R + Q \\partial_k \\partial_h R + \\partial_k Q (\\partial_k \\partial_h R) + \\partial_k F^{\\prime\\prime}_h(L_h),")]]

#text("and then anti-symmetrising in ")#mi("{k,h}")#text(" one has")

#align(center)[#tao-fit-display[#mitex("0 = \\partial_k Q \\partial_h R - \\partial_h Q \\partial_k R + (\\partial_k Q - \\partial_h Q) \\partial_k \\partial_h R + \\partial_k F^{\\prime\\prime}_h(L_h) - \\partial_h F^{\\prime\\prime}_k(L_h).")]]

#text("If ")#mi("{Q}")#text(" and ")#mi("{R}")#text(" are unrelated, then the linear forms ")#mi("{\\partial_k Q, \\partial_k R}")#text(" will typically be in general position with respect to each other and with ")#mi("{L_h}")#text(", and similarly ")#mi("{\\partial_h Q, \\partial_h R}")#text(" will be in general position with respect to each other and with ")#mi("{L_k}")#text(". From this, one can show that the above equation is not satisfiable generically, because the mixed terms ")#mi("{\\partial_k Q \\partial_h R - \\partial_h Q \\partial_k R}")#text(" cannot be cancelled by the simpler terms in the above expression.")

#text("An interpolation of the above two arguments can handle the case in which ")#mi("{Q_h}")#text(" does not depend on ")#mi("{h}")#text(". Now we consider the other extreme, in which ")#mi("{Q_h}")#text(" varies in ")#mi("{h}")#text(", so that ")#mi("{Q_h}")#text(" and ")#mi("{Q_k}")#text(" are in general position for generic ")#mi("{h,k}")#text(", and similarly for ")#mi("{Q_h}")#text(" and ")#mi("{Q_{h+k}}")#text(", or for ")#mi("{Q_k}")#text(" and ")#mi("{Q_{h+k}}")#text(". (Note though that we cannot simultaneously assume that ")#mi("{Q_h, Q_k, Q_{h+k}}")#text(" are in general position; indeed, ")#mi("{Q_h}")#text(" might vary linearly in ")#mi("{h}")#text(", and indeed we expect this to be the basic behaviour of ")#mi("{Q_h}")#text(" here, as was observed in the preceding argument.)")

#text("To analyse this situation, we return to the cocycle equation ")#link(<tao-ddd02a0345ad6d42b737>)[#text("(5)")]#text(", which currently reads ")#metadata(none) <tao-30de18cc4ea2bf4601b4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("F_{h+k}( Q_{h+k}, \\vec L_{h+k} ) = F_{h}( Q_{h}, \\vec L_{h} ) + T^h F_{k}( Q_{k}, \\vec L_{k} ).")]]

#text("Because any two of ")#mi("{Q_{h+k}, Q_h, Q_k}")#text(" can be assumed to be in general position, one can show using equidistribution theory that the above equation can only be satisfied when the ")#mi("{F_h}")#text(" are linear in the ")#mi("{Q_h}")#text(" variable, thus")

#align(center)[#tao-fit-display[#mitex("\\partial_h \\phi = Q_h F^{\\prime}_h(\\vec L_h) + F^{\\prime\\prime}_h(\\vec L_h)")]]

#text("much as before. Furthermore, the coefficients ")#mi("{F^{\\prime}_h(\\vec L_h)}")#text(" must now be (essentially) constant in ")#mi("{h}")#text(" in order to obtain ")#link(<tao-30de18cc4ea2bf4601b4>)[#text("(9)")]#text(". Absorbing this constant into the definition of ")#mi("{Q_h}")#text(", we now have")

#align(center)[#tao-fit-display[#mitex("\\partial_h \\phi = Q_h + F^{\\prime\\prime}_h(\\vec L_h).")]]

#text("We will once again pretend that ")#mi("{\\vec L_h}")#text(" is just a single linear form ")#mi("{L_h}")#text(". Again we consider two extremes. If ")#mi("{L_h = L}")#text(" is independent of ")#mi("{h}")#text(", then by passing to a bounded index subspace (the level set of ")#mi("{L}")#text(") we now see that ")#mi("{\\partial_h \\phi}")#text(" is quadratic, hence ")#mi("{\\phi}")#text(" is cubic, and we are done. Now suppose instead that ")#mi("{L_h}")#text(" varies in ")#mi("{h}")#text(", so that ")#mi("{L_h, L_k}")#text(" are in general position for generic ")#mi("{h, k}")#text(". We look at the cocycle equation again, which now tells us that ")#mi("{F^{\\prime\\prime}_h(\\vec L_h)}")#text(" obeys the ")#emph[#text("quasicocycle")]#text(" condition")

#align(center)[#tao-fit-display[#mitex("Q_{h,k} + F^{\\prime\\prime}_{h+k}(\\vec L_{h+k}) = F^{\\prime\\prime}_{h}(\\vec L_{h}) + T^h F^{\\prime\\prime}_{k}(\\vec L_{k})")]]

#text("where ")#mi("{Q_{h,k} := Q_{h+k} - Q_h - T^h Q_k}")#text(" is a quadratic polynomial. With any two of ")#mi("{L_h, L_k, L_{h+k}}")#text(" in general position, one can then conclude (using equidistribution theory) that ")#mi("{F^{\\prime\\prime}_h, F^{\\prime\\prime}_k, F^{\\prime\\prime}_{h+k}}")#text(" are quadratic polynomials. Thus ")#mi("{\\partial_h \\phi}")#text(" is quadratic, and ")#mi("{\\phi}")#text(" is cubic as before. This completes the heuristic discussion of various extreme model cases; the general case is handled by a rather complicated combination of all of these special case methods, and is best performed in the framework of ergodic theory (in particular, the idea of extracting out the coefficient of a key polynomial, such as the coerfficient ")#mi("{F^{\\prime}_h(L_h)}")#text(" of ")#mi("{Q}")#text(", is best captured by the ergodic theory concept of ")#emph[#text("vertical differentiation")]#text("); see ")#link("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/")[#text("this paper of Bergelson, Ziegler, and myself")]#text(".")

#heading(level: 1)[#strong[#text(" — 4. Consequences of the Gowers inverse conjecture — ")]]

#text("We now discuss briefly some of the consequences of the Gowers inverse conjecture, beginning with Szemerédi’s theorem in vector fields (Theorem ")#link(<tao-f13e7604737eddf552e3>)[#text("4")]#text("). We will use the density increment method (an energy increment argument is also possible, but is more complicated; see ")#link("https://terrytao.wordpress.com/2010/02/12/an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/")[#text("this paper")]#text("). Let ")#mi("{A \\subset V = {\\bf F}^n}")#text(" be a set of density at least ")#mi("{\\delta}")#text(" containing no lines. This implies that the ")#mi("{p}")#text("-linear form")

#align(center)[#tao-fit-display[#mitex("\\Lambda(1_A,\\ldots,1_A) := \\mathop{\\bf E}_{x, r \\in {\\bf F}^n} 1_A(x) \\ldots 1_A(x+(p-1)r)")]]

#text("has size ")#mi("{o(1)}")#text(". On the other hand, as this pattern has complexity ")#mi("{p-2}")#text(", one has from ")#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/")[#text("Notes 3")]#text(" the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Lambda(f_0, \\ldots,f_{p-1})\\right| \\leq \\sup_{0 \\leq j \\leq p-1} \\left\\|f_j\\right\\|_{U^{p-1}(V)}", block: true)]]

#text("whenever ")#mi("{f_0,\\ldots,f_{p-1}}")#text(" are bounded in magnitude by ")#mi("{1}")#text(". Splitting ")#mi("{1_A = \\delta + (1_A - \\delta)}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\Lambda(1_A,\\ldots,1_A) = \\delta^p + O_p( \\left\\|1_A-\\delta\\right\\|_{U^{p-1}(V)} )", block: true)]]

#text("and thus (for ")#mi("{n}")#text(" large enough)")

#align(center)[#tao-fit-display[#tao-math("\\left\\|1_A-\\delta\\right\\|_{U^{p-1}(V)} \\gg_{p,\\delta} 1.", block: true)]]

#text("Applying Theorem ")#link(<tao-76f5c27d49afeeb5a673>)[#text("3")]#text(", we find that there exists a polynomial ")#mi("{\\phi}")#text(" of degree at most ")#mi("{p-2}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle 1_A-\\delta, e(\\phi) \\rangle\\right| \\gg_{p,\\delta} 1.", block: true)]]

#text("To proceed we need the following analogue of Proposition 5 of ")#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/")[#text("Notes 2")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6 (Fragmenting a polynomial into subspaces)")]#text(" Let ")#mi("{\\phi: {\\bf F}^n \\rightarrow {\\bf F}}")#text(" be a classical polynomial of degree ")#mi("{d < p}")#text(". Show that one can partition ")#mi("{V}")#text(" into affine subspaces ")#mi("{W}")#text(" of dimension at least ")#mi("{n^{\\prime}(n,d,p)}")#text(", where ")#mi("{n^{\\prime} \\rightarrow \\infty}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" for fixed ")#mi("{d,p}")#text(", such that ")#mi("{\\phi}")#text(" is constant on each ")#mi("{W}")#text(". (")#emph[#text("Hint:")]#text(" Induct on ")#mi("{d}")#text(", and use Exercise 6 of ")#link("https://terrytao.wordpress.com/2010/05/08/254b-lecture-notes-4-equidistribution-of-polynomials-over-finite-fields/")[#text("Notes 4")]#text(" repeatedly to find a good initial partition into subspaces on which ")#mi("{\\phi}")#text(" has degree at most ")#mi("{d-1}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Use the previous exercise to complete the proof of Theorem ")#link(<tao-f13e7604737eddf552e3>)[#text("4")]#text(". (")#emph[#text("Hint:")]#text(" mimic the density increment argument from ")#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/")[#text("Notes 2")]#text(".)")
]

#text("By using the inverse theorem in place of the Fourier-analytic analogue in Lemma 7 of ")#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/")[#text("Notes 2")]#text(", one obtains the following regularity lemma, analogous to Theorem 10 of ")#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/")[#text("Notes 2")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (Strong arithmetic regularity lemma)")]#text(" ")#metadata(none) <tao-cea564368b8dda0e97ae>#text(" Suppose that ")#mi("{\\text{char}({\\bf F}) = p > d \\geq 0}")#text(". Let ")#mi("{f: V \\rightarrow [0,1]}")#text(", let ")#mi("{\\epsilon > 0}")#text(", and let ")#mi("{F: {\\bf R}^+ \\rightarrow {\\bf R}^+}")#text(" be an arbitrary function. Then we can decompose ")#mi("{f = f_{str} + f_{sml} + f_{psd}}")#text(" and find ")#mi("{1 \\leq M = O_{\\epsilon,F,d,p}(1)}")#text(" such that")

#list(
[#text("(Nonnegativity) ")#mi("{f_{str}, f_{str}+f_{sml}}")#text(" take values in ")#mi("{[0,1]}")#text(", and ")#mi("{f_{sml}, f_{psd}}")#text(" have mean zero;")],
[#text("(Structure) ")#mi("{f_{str}}")#text(" is a function of ")#mi("{M}")#text(" classical polynomials of degree at most ")#mi("{d}")#text(";")],
[#text("(Smallness) ")#mi("{f_{sml}}")#text(" has an ")#mi("{L^2(V)}")#text(" norm of at most ")#mi("{\\epsilon}")#text("; and")],
[#text("(Pseudorandomness) One has ")#tao-math("{\\left\\| f_{psd} \\right\\|_{U^{d+1}(V)} \\leq 1/F(M)}", block: false)#text(" for all ")#mi("{\\alpha \\in {\\bf R}}")#text(".")]
)
]

#text("For a proof, see ")#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/")[#text("this paper of mine")]#text(". The argument is similar to that appearing in Theorem 10 of ")#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/")[#text("Notes 2")]#text(", but the discrete nature of polynomials in bounded characteristic allows one to avoid a number of technical issues regarding measurability.")

#text("This theorem can then be used for a variety of applications in additive combinatorics. For instance, it gives the following variant of a ")#link("http://www.ams.org/mathscinet-getitem?mr=2138068")[#text("result of Bergelson, Host, and Kra")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10 (Bergelson-Host-Kra type result)")]#text(" Let ")#mi("{p > 4 \\geq k}")#text(", let ")#mi("{{\\bf F} = {\\bf F}_p}")#text(", and let ")#mi("{A \\subset {\\bf F}^n}")#text(" with ")#tao-math("{\\left|A\\right| \\geq \\delta \\left|{\\bf F}^n\\right|}", block: false)#text(", and let ")#mi("{\\epsilon > 0}")#text(". Then for ")#tao-math("{\\gg_{\\delta,\\epsilon,p} \\left|{\\bf F}^n\\right|}", block: false)#text(" values of ")#mi("{h \\in {\\bf F}^n}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ x \\in {\\bf F}^n: x, x+h, \\ldots, x+(k-1)h \\in A \\}\\right| \\geq (\\delta^k - \\epsilon) |{\\bf F}^n|.", block: true)]]
]

#text("Roughly speaking, the idea is to apply the regularity lemma to ")#mi("{f := 1_A}")#text(", discard the contribution of the ")#mi("{f_{sml}}")#text(" and ")#mi("{f_{psd}}")#text(" errors, and then control the structured component using the equidistribution theory from ")#link("https://terrytao.wordpress.com/2010/05/08/254b-lecture-notes-4-equidistribution-of-polynomials-over-finite-fields/")[#text("Notes 4")]#text(". A proof of this result can be found in ")#link("http://www.ams.org/mathscinet-getitem?mr=2359469")[#text("this paper of Ben Green")]#text("; see also ")#link("https://terrytao.wordpress.com/2010/02/12/an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/")[#text("this paper of Ben and myself")]#text(" for an analogous result in ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(". Curiously, the claim fails when ")#mi("{4}")#text(" is replaced by any larger number; this is essentially an observation of Ruzsa that appears in the appendix of ")#link("http://www.ams.org/mathscinet-getitem?mr=2138068")[#text("the paper of Bergelson, Host, and Kra")]#text(".")

#text("The above regularity lemma (or more precisely, a close relative of this lemma) was also used ")#link("http://arxiv.org/abs/1002.2208")[#text("by Gowers and Wolf")]#text(" to determine the true complexity of a linear system:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 11 (Gowers-Wolf theorem)")]#text(" Let ")#mi("{\\Psi = (\\psi_1,\\ldots,\\psi_t)}")#text(" be a collection of linear forms with integer coefficients, with no two forms being linearly dependent. Let ")#mi("{{\\bf F}}")#text(" have sufficiently large characteristic, and suppose that ")#mi("{f_1,\\ldots,f_t: {\\bf F}^n \\rightarrow {\\bf C}}")#text(" are functions bounded in magnitude by ")#mi("{1}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Lambda_\\Psi(f_1,\\ldots,f_t)\\right| \\geq \\delta", block: true)]]

#text("where ")#mi("{\\Lambda_\\Psi}")#text(" was the form defined in ")#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/")[#text("Notes 3")]#text(". Then for each ")#mi("{1 \\leq i \\leq t}")#text(" there exists a classical polynomial ")#mi("{\\phi_i}")#text(" of degree at most ")#mi("{d}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle f_i, e(\\phi_i) \\rangle_{L^2({\\bf F}^n)}\\right| \\gg_{d,\\Psi,\\delta} 1,", block: true)]]

#text("where ")#mi("{d}")#text(" is the true complexity of the system ")#mi("{\\Psi}")#text(" defined in ")#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/")[#text("Notes 3")]#text(". This ")#mi("{d}")#text(" is best possible.")
]

#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mads")]], [#link("https://terrytao.wordpress.com/2010/05/20/254b-notes-5-the-inverse-conjecture-for-the-gowers-norm-i-the-finite-field-case/#comment-45119")[#strong[#text("Mads")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2010")])]

#text("Prof. Tao,")

#text("I was wondering if it might be “better” to give interactive references to, i.e., theorems on MathWorld instead of on Wikipedia? (For example in Exercise 4 in this post.)")

#text("By the way; thank you for al the interessting entries in this blog! It is ‘gold’ for an amateur matmematician like myself.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 6: The inverse conjecture for the Gowers norm II. The integer case « What’s new")]], [#link("https://terrytao.wordpress.com/2010/05/20/254b-notes-5-the-inverse-conjecture-for-the-gowers-norm-i-the-finite-field-case/#comment-45207")[#strong[#text("254B, Notes 6: The inverse conjecture for the Gowers norm II. The integer case « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2010")])]

#text("[…] inverse conjecture for the Gowers norm, nilsequences, polynomial maps | by Terence Tao In Notes 5, we saw that the Gowers uniformity norms on vector spaces in high characteristic were controlled […]")
]
