// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/
// Converted to Typst by tao2typ: "2026-10-14T09:37:21.569932+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Stickiness, graininess, planiness, and a sum-product approach to the Kakeya problem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Stickiness, graininess, planiness, and a sum-product approach to the Kakeya problem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 May 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/")[#text("https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is a blog version of ")#link("https://www.ipam.ucla.edu/abstract/?tid=11846&pcode=CCGWS3")[#text("a talk I recently gave")]#text(" at ")#link("https://www.ipam.ucla.edu/schedule.aspx?pc=ccgws3")[#text("the IPAM workshop on “The Kakeya Problem, Restriction Problem, and Sum-product Theory”")]#text(".")

#text("Note: the discussion here will be highly non-rigorous in nature, being extremely loose in particular with asymptotic notation and with the notion of dimension. Caveat emptor.")

#text("One of the most infamous unsolved problems at the intersection of geometric measure theory, incidence combinatorics, and real-variable harmonic analysis is the ")#link("http://en.wikipedia.org/wiki/Kakeya_set#Kakeya_conjecture")[#text("Kakeya set conjecture")]#text(". We will focus on the following three-dimensional case of the conjecture, stated informally as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Kakeya conjecture)")]#text(" Let ")#mi("{E}")#text(" be a subset of ")#mi("{{\\bf R}^3}")#text(" that contains a unit line segment in every direction. Then ")#mi("{\\text{dim}(E) = 3}")#text(".")
]

#text("This conjecture is not precisely formulated here, because we have not specified exactly what type of set ")#mi("{E}")#text(" is (e.g. measurable, Borel, compact, etc.) and what notion of dimension we are using. We will deliberately ignore these technical details in this post. It is slightly more convenient for us here to work with lines instead of unit line segments, so we work with the following slight variant of the conjecture (which is essentially equivalent):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2 (Kakeya conjecture, again)")]#text(" Let ")#mi("{{\\cal L}}")#text(" be a family of lines in ")#mi("{{\\bf R}^3}")#text(" that meet ")#mi("{B(0,1)}")#text(" and contain a line in each direction. Let ")#mi("{E}")#text(" be the union of the restriction ")#mi("{\\ell \\cap B(0,2)}")#text(" to ")#mi("{B(0,2)}")#text(" of every line ")#mi("{\\ell}")#text(" in ")#mi("{{\\cal L}}")#text(". Then ")#mi("{\\text{dim}(E) = 3}")#text(".")
]

#text("As the space of all directions in ")#mi("{{\\bf R}^3}")#text(" is two-dimensional, we thus see that ")#mi("{{\\cal L}}")#text(" is an (at least) two-dimensional subset of the four-dimensional space of lines in ")#mi("{{\\bf R}^3}")#text(" (actually, it lies in a compact subset of this space, since we have constrained the lines to meet ")#mi("{B(0,1)}")#text("). One could then ask if this is the only property of ")#mi("{{\\cal L}}")#text(" that is needed to establish the Kakeya conjecture, that is to say if any subset of ")#mi("{B(0,2)}")#text(" which contains a two-dimensional family of lines (restricted to ")#mi("{B(0,2)}")#text(", and meeting ")#mi("{B(0,1)}")#text(") is necessarily three-dimensional. Here we have an easy counterexample, namely a plane in ")#mi("{B(0,2)}")#text(" (passing through the origin), which contains a two-dimensional collection of lines. However, we can exclude this case by adding an additional axiom, leading to what one might call a “strong” Kakeya conjecture:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 3 (Strong Kakeya conjecture)")]#text(" ")#metadata(none) <tao-fb650f5de515112174c7>#text(" Let ")#mi("{{\\cal L}}")#text(" be a two-dimensional family of lines in ")#mi("{{\\bf R}^3}")#text(" that meet ")#mi("{B(0,1)}")#text(", and assume the ")#emph[#text("Wolff axiom")]#text(" that no (affine) plane contains more than a one-dimensional family of lines in ")#mi("{{\\cal L}}")#text(". Let ")#mi("{E}")#text(" be the union of the restriction ")#mi("{\\ell \\cap B(0,2)}")#text(" of every line ")#mi("{\\ell}")#text(" in ")#mi("{{\\cal L}}")#text(". Then ")#mi("{\\text{dim}(E) = 3}")#text(".")
]

#text("Actually, to make things work out we need a more quantitative version of the Wolff axiom in which we constrain the metric entropy (and not just dimension) of lines that lie ")#emph[#text("close")]#text(" to a plane, rather than exactly ")#emph[#text("on")]#text(" the plane. However, for the informal discussion here we will ignore these technical details. Families of lines that lie in different directions will obey the Wolff axiom, but the converse is not true in general.")

#text("In 1995, ")#link("http://www.ams.org/mathscinet-getitem?mr=1363209")[#text("Wolff established")]#text(" the important lower bound ")#mi("{\\text{dim}(E) \\geq 5/2}")#text(" (for various notions of dimension, e.g. Hausdorff dimension) for sets ")#mi("{E}")#text(" in Conjecture ")#link(<tao-fb650f5de515112174c7>)[#text("3")]#text(" (and hence also for the other forms of the Kakeya problem). However, there is a key obstruction to going beyond the ")#mi("{5/2}")#text(" barrier, coming from the possible existence of ")#emph[#text("half-dimensional (approximate) subfields")]#text(" of the reals ")#mi("{{\\bf R}}")#text(". To explain this problem, it easiest to first discuss the complex version of the strong Kakeya conjecture, in which all relevant (real) dimensions are doubled:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 4 (Strong Kakeya conjecture over ")#mi("{{\\bf C}}")#text(")")]#text(" ")#metadata(none) <tao-9568261903d3c5cb21c4>#text(" Let ")#mi("{{\\cal L}}")#text(" be a four (real) dimensional family of complex lines in ")#mi("{{\\bf C}^3}")#text(" that meet the unit ball ")#mi("{B(0,1)}")#text(" in ")#mi("{{\\bf C}^3}")#text(", and assume the ")#emph[#text("Wolff axiom")]#text(" that no four (real) dimensional (affine) subspace contains more than a two (real) dimensional family of complex lines in ")#mi("{{\\cal L}}")#text(". Let ")#mi("{E}")#text(" be the union of the restriction ")#mi("{\\ell \\cap B(0,2)}")#text(" of every complex line ")#mi("{\\ell}")#text(" in ")#mi("{{\\cal L}}")#text(". Then ")#mi("{E}")#text(" has real dimension ")#mi("{6}")#text(".")
]

#text("The argument of Wolff can be adapted to the complex case to show that all sets ")#mi("{E}")#text(" occuring in Conjecture ")#link(<tao-9568261903d3c5cb21c4>)[#text("4")]#text(" have real dimension at least ")#mi("{5}")#text(". Unfortunately, this is sharp, due to the following fundamental counterexample:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Heisenberg group counterexample)")]#text(" Let ")#mi("{H \\subset {\\bf C}^3}")#text(" be the ")#link("http://en.wikipedia.org/wiki/Heisenberg_group")[#text("Heisenberg group")]

#align(center)[#tao-fit-display[#mitex("H = \\{ (z_1,z_2,z_3) \\in {\\bf C}^3: \\text{Im}(z_1) = \\text{Im}(z_2 \\overline{z_3}) \\}")]]

#text("and let ")#mi("{{\\cal L}}")#text(" be the family of complex lines")

#align(center)[#tao-fit-display[#mitex("\\ell_{s,t,\\alpha} := \\{ (\\overline{\\alpha} z + t, z, sz + \\alpha): z \\in {\\bf C} \\}")]]

#text("with ")#mi("{s,t \\in {\\bf R}}")#text(" and ")#mi("{\\alpha \\in {\\bf C}}")#text(". Then ")#mi("{H}")#text(" is a five (real) dimensional subset of ")#mi("{{\\bf C}^3}")#text(" that contains every line in the four (real) dimensional set ")#mi("{{\\cal L}}")#text("; however each four real dimensional (affine) subspace contains at most a two (real) dimensional set of lines in ")#mi("{{\\cal L}}")#text(". In particular, the strong Kakeya conjecture over the complex numbers is false.")
]

#text("This proposition is proven by a routine computation, which we omit here. The group structure on ")#mi("{H}")#text(" is given by the group law")

#align(center)[#tao-fit-display[#mitex("(z_1,z_2,z_3) \\cdot (w_1,w_2,w_3) = (z_1 + w_1 + z_2 \\overline{w_3} - z_3 \\overline{w_2}, z_2 +w_2, z_3+w_3),")]]

#text("giving ")#mi("{E}")#text(" the structure of a ")#mi("{2}")#text("-step simply-connected nilpotent Lie group, isomorphic to the usual Heisenberg group over ")#mi("{{\\bf R}^2}")#text(". Note that while the Heisenberg group is a counterexample to the complex strong Kakeya conjecture, it is not a counterexample to the complex form of the original Kakeya conjecture, because the complex lines ")#mi("{{\\cal L}}")#text(" in the Heisenberg counterexample do not point in distinct directions, but instead only point in a three (real) dimensional subset of the four (real) dimensional space of available directions for complex lines. For instance, one has the one real-dimensional family of parallel lines")

#align(center)[#tao-fit-display[#mitex("\\ell_{0,t,0} = \\{ (t, z, 0): z \\in {\\bf C}\\}")]]

#text("with ")#mi("{t \\in {\\bf R}}")#text("; multiplying this family of lines on the right by a group element in ")#mi("{H}")#text(" gives other families of parallel lines, which in fact sweep out all of ")#mi("{{\\cal L}}")#text(".")

#text("The Heisenberg counterexample ultimately arises from the “half-dimensional” (and hence ")#link("http://en.wikipedia.org/wiki/Degree_of_a_field_extension")[#text("degree")]#text(" two) subfield ")#mi("{{\\bf R}}")#text(" of ")#mi("{{\\bf C}}")#text(", which induces an involution ")#mi("{z \\mapsto \\overline{z}}")#text(" which can then be used to define the Heisenberg group ")#mi("{H}")#text(" through the formula")

#align(center)[#tao-fit-display[#mitex("H = \\{ (z_1,z_2,z_3) \\in {\\bf C}^3: z_1 - \\overline{z_1} = z_2 \\overline{z_3} - z_3 \\overline{z_2} \\}.")]]

#text("Analogous Heisenberg counterexamples can also be constructed if one works over finite fields ")#mi("{{\\bf F}_{q^2}}")#text(" that contain a “half-dimensional” subfield ")#mi("{{\\bf F}_q}")#text("; we leave the details to the interested reader. Morally speaking, if ")#mi("{{\\bf R}}")#text(" in turn contained a subfield of dimension ")#mi("{1/2}")#text(" (or even a subring or “approximate subring”), then one ought to be able to use this field to generate a counterexample to the strong Kakeya conjecture over the reals. Fortunately, such subfields do not exist; this was a conjecture of ")#link("http://www.ams.org/mathscinet-getitem?mr=186782")[#text("Erdos and Volkmann")]#text(" that was proven ")#link("http://www.ams.org/mathscinet-getitem?mr=1948103")[#text("by Edgar and Miller")]#text(", and more quantitatively ")#link("http://www.ams.org/mathscinet-getitem?mr=1982147")[#text("by Bourgain")]#text(" (answering a ")#link("http://www.ams.org/mathscinet-getitem?mr=1856956")[#text("question of Nets Katz and myself")]#text("). However, this fact is not entirely trivial to prove, being a key example of the ")#link("http://link.springer.com/chapter/10.1007%2F978-3-642-39286-3_4")[#text("sum-product phenomenon")]#text(".")

#text("We thus see that to go beyond the ")#mi("{5/2}")#text(" dimension bound of Wolff for the 3D Kakeya problem over the reals, one must do at least one of two things:")

#list(
[#text("(a) Exploit the distinct directions of the lines in ")#mi("{{\\mathcal L}}")#text(" in a way that goes beyond the Wolff axiom; or")],
[#text("(b) Exploit the fact that ")#mi("{{\\bf R}}")#text(" does not contain half-dimensional subfields (or more generally, intermediate-dimensional approximate subrings).")]
)

#text("(The situation is more complicated in higher dimensions, as there are more obstructions than the Heisenberg group; for instance, in four dimensions quadric surfaces are an important obstruction, as discussed in ")#link("http://www.ams.org/mathscinet-getitem?mr=2225076")[#text("this paper of mine")]#text(".)")

#text("Various partial or complete results on the Kakeya problem over various fields have been obtained through route (a) or route (b). For instance, in 2000, ")#link("http://www.ams.org/mathscinet-getitem?mr=1804528")[#text("Nets Katz, Izabella Laba and myself")]#text(" used route (a) to improve Wolff’s lower bound of ")#mi("{5/2}")#text(" for Kakeya sets very slightly to ")#mi("{5/2+10^{-10}}")#text(" (for a weak notion of dimension, namely upper Minkowski dimension). In 2004, ")#link("http://www.ams.org/mathscinet-getitem?mr=2053599")[#text("Bourgain, Katz, and myself")]#text(" established a sum-product estimate which (among other things) ruled out approximate intermediate-dimensional subrings of ")#mi("{{\\bf F}_p}")#text(", and then pursued route (b) to obtain a corresponding improvement ")#mi("{5/2+\\epsilon}")#text(" to the Kakeya conjecture over finite fields of prime order. The analogous (discretised) sum-product estimate over the reals was established ")#link("http://www.ams.org/mathscinet-getitem?mr=1982147")[#text("by Bourgain")]#text(" in 2003, which in principle would allow one to extend the result of Katz, Laba and myself to the strong Kakeya setting, but this has not been carried out in the literature. Finally, in 2009, ")#link("http://www.ams.org/mathscinet-getitem?mr=2525780")[#text("Dvir used route (a)")]#text(" and introduced the polynomial method (as discussed previously ")#link("https://terrytao.wordpress.com/2013/10/25/algebraic-combinatorial-geometry-the-polynomial-method-in-arithmetic-combinatorics-incidence-combinatorics-and-number-theory/")[#text("here")]#text(") to completely settle the Kakeya conjecture in finite fields.")

#text("Below the fold, I present a heuristic argument of Nets Katz and myself, which in principle would use route (b) to establish the full (strong) Kakeya conjecture. In broad terms, the strategy is as follows:")

#enum(start: 1, 
[#text("Assume that the (strong) Kakeya conjecture fails, so that there are sets ")#mi("{E}")#text(" of the form in Conjecture ")#link(<tao-fb650f5de515112174c7>)[#text("3")]#text(" of dimension ")#mi("{3-\\sigma}")#text(" for some ")#mi("{\\sigma>0}")#text(". Assume that ")#mi("{E}")#text(" is “optimal”, in the sense that ")#mi("{\\sigma}")#text(" is as large as possible.")],
[#text("Use the optimality of ")#mi("{E}")#text(" (and suitable non-isotropic rescalings) to establish strong forms of standard structural properties expected of such sets ")#mi("{E}")#text(", namely “stickiness”, “planiness”, “local graininess” and “global graininess” (we will roughly describe these properties below). Heuristically, these properties are constraining ")#mi("{E}")#text(" to “behave like” a putative Heisenberg group counterexample.")],
[#text("By playing all these structural properties off of each other, show that ")#mi("{E}")#text(" can be parameterised locally by a one-dimensional set which generates a counterexample to Bourgain’s sum-product theorem. This contradiction establishes the Kakeya conjecture.")]
)

#text("Nets and I have had an informal version of argument for many years, but were never able to make a satisfactory theorem (or even a partial Kakeya result) out of it, because we could not rigorously establish anywhere near enough of the necessary structural properties (stickiness, planiness, etc.) on the optimal set ")#mi("{E}")#text(" for a large number of reasons (one of which being that we did not have a good notion of dimension that did everything that we wished to demand of it). However, there is beginning to be movement in these directions (e.g. in this ")#link("http://arxiv.org/abs/1402.0518")[#text("recent result of Guth")]#text(" using the polynomial method obtaining a weak version of local graininess on certain Kakeya sets). In view of this (and given that neither Nets or I have been actively working in this direction for some time now, due to many other projects), we’ve decided to distribute these ideas more widely than before, and in particular on this blog.")

#metadata(none) <tao-9885c9064518fe14a42f>

#heading(level: 1)[#strong[#text(" — 1. Stickiness — ")]]

#text("Let ")#mi("{E}")#text(" be a set of the form in Conjecture ")#link(<tao-fb650f5de515112174c7>)[#text("3")]#text(" that has a “minimal dimension” ")#mi("{3-\\sigma}")#text(" for some ")#mi("{\\sigma>0}")#text(", whatever that means. (If the infimal dimension cannot be attained exactly, it may be enough to work with a set ")#mi("{E}")#text(" whose dimension is sufficiently close to the infimum.)")

#text("The first step – and, somewhat annoyingly, the one for which we have been least able to make rigorous – is to establish a property on the family of lines ")#mi("{{\\mathcal L}}")#text(" that is known as “stickiness”, which roughly speaking asserts that each line in ")#mi("{{\\mathcal L}}")#text(" is close to as many other lines in ")#mi("{{\\mathcal L}}")#text(" as is permitted by dimensionality considerations. Indeed, if one places a suitable metric on the space of lines in ")#mi("{{\\bf R}^3}")#text(" (or more precisely, on the compact portion of that space consisting of lines that meet ")#mi("{B(0,1)}")#text("), then stickiness asserts that ")#mi("{{\\mathcal L}}")#text(" is “genuinely two-dimensional” in the sense that for any scale ")#mi("{0 < \\rho < 1}")#text(", ")#mi("{{\\mathcal L}}")#text(" should be covered by about ")#mi("{\\rho^{-2}}")#text(" balls of radius ")#mi("{\\rho}")#text(" (where we ignore all logarithmic factors in the scale, and also pretend for simplicity that all sets under consideration are roughly “uniform” in the sense that the multiplicities and other combinatorial statistics of the set are essentially constant across the set; there are standard techniques such as dyadic pigeonholing that often allow one to reduce to this case, but we will ignore these technical issues here). In particular, if one has two scales ")#mi("{0 < \\delta < \\rho < 1}")#text(", then each of the ")#mi("{\\rho}")#text("-balls covering ")#mi("{{\\mathcal L}}")#text(" should essentially contain about ")#mi("{(\\rho/\\delta)^2}")#text(" of the ")#mi("{\\delta^{-2}}")#text(" ")#mi("{\\delta}")#text("-balls covering ")#mi("{{\\mathcal L}}")#text(".")

#text("In ")#link("http://www.ams.org/mathscinet-getitem?mr=1804528")[#text("my previous paper with Nets and Izabella")]#text(", we were able to establish such stickiness for sets ")#mi("{E}")#text(" of dimension close to the Wolff exponent ")#mi("{5/2}")#text(" by using an x-ray estimate established in a ")#link("http://www.ams.org/mathscinet-getitem?mr=1681585")[#text("separate paper of Wolff")]#text(", but we do not know how to establish stickiness more generally, and I view this as the largest single obstacle to making this program to attack the Kakeya conjecture a success.")

#text("Translating the stickiness property back into the physical space ")#mi("{{\\bf R}^3}")#text(", we find that the ")#mi("{\\delta}")#text("-neighbourhood ")#mi("{E_\\delta}")#text(" of ")#mi("{E}")#text(" should consist of the union of about ")#mi("{\\delta^{-2}}")#text(" ")#mi("{\\delta}")#text("-tubes ")#mi("{T_\\delta}")#text(" (that is, solid cylinders of length ")#mi("{1}")#text(" and radius ")#mi("{\\delta}")#text("), and similarly the larger ")#mi("{\\rho}")#text("-neighbourhood ")#mi("{E_\\rho}")#text(" should consist of the union of about ")#mi("{\\rho^{-2}}")#text(" ")#mi("{\\rho}")#text("-tubes ")#mi("{T_\\rho}")#text(". We’ll refer to the ")#mi("{\\delta}")#text("-tubes ")#mi("{T_\\delta}")#text(" as “thin tubes” and ")#mi("{\\rho}")#text("-tubes ")#mi("{T_\\rho}")#text(" as “fat” tubes. Each thin tube ")#mi("{T_\\delta}")#text(" should lie in essentially one parent fat tube ")#mi("{T_\\rho}")#text(", and conversely each fat tube ")#mi("{T_\\rho}")#text(" should essentially contain about ")#mi("{(\\rho/\\delta)^2}")#text(" thin tubes ")#mi("{T_\\delta}")#text(".")

#text("This creates a somewhat self-similar structure to the set ")#mi("{E}")#text(" as follows. Let ")#mi("{{\\bf T}_\\rho}")#text(" denote the collection of fat tubes. Then for each fat tube ")#mi("{T_\\rho \\in {\\bf T}_\\rho}")#text(", we can form the subset ")#mi("{E_\\delta[T_\\rho]}")#text(" of ")#mi("{E_\\delta}")#text(" by taking the union of all the thin tubes inside of ")#mi("{T_\\rho}")#text(", thus we have the decomposition")

#align(center)[#tao-fit-display[#mitex("E_\\delta = \\bigcup_{T_\\rho \\in {\\bf T}_\\rho} E_\\delta[T_\\rho].")]]

#text("This is very much not a disjoint union; indeed, the strong overlap of the ")#mi("{E_\\delta[T_\\rho]}")#text(" is going to be an important source for the other structural properties we will suppose ")#mi("{E}")#text(" to have.")

#text("AS ")#mi("{E}")#text(" has dimension ")#mi("{3-\\sigma}")#text(", we expect ")#mi("{E_\\delta}")#text(" to be essentially the union of about ")#mi("{\\delta^{-3+\\sigma}}")#text(" ")#mi("{\\delta}")#text("-cubes ")#mi("{Q_\\delta}")#text(", and ")#mi("{E_\\rho}")#text(" to be the union of about ")#mi("{\\rho^{-3+\\sigma}}")#text(" ")#mi("{\\rho}")#text("-cubes ")#mi("{Q_\\rho}")#text(". Thus, each large cube ")#mi("{Q_\\rho}")#text(" should contain about ")#mi("{(\\rho/\\delta)^{3-\\sigma}}")#text(" small cubes ")#mi("{Q_\\delta}")#text(". This in turn implies that each fat tube ")#mi("{T_\\rho}")#text(" should contain about ")#mi("{(\\rho/\\delta)^{3-\\sigma} \\times (1/\\rho)}")#text(" small cubes, and so we expect the volume ")#tao-math("{\\left|E_\\delta \\cap T_\\rho\\right|}", block: false)#text(" of ")#mi("{E_\\delta \\cap T_\\rho}")#text(" to be ")#metadata(none) <tao-d86d3e078b518355dc4e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|E_\\delta \\cap T_\\rho\\right| \\approx (\\rho/\\delta)^{3-\\sigma} \\times (1/\\rho) \\times \\delta^3.", block: true)]]

#text("Now consider the set ")#mi("{E_\\delta[T_\\rho]}")#text(", which is a subset of ")#mi("{E_\\delta \\cap T_\\rho}")#text(", so that ")#metadata(none) <tao-e8946d753ee69fbebe1f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|E_\\delta[T_\\rho]\\right| \\leq \\left|E_\\delta \\cap T_\\rho\\right|.", block: true)]]

#text("The set ")#mi("{E_\\delta[T_\\rho]}")#text(" is the union of about ")#mi("{(\\rho/\\delta)^2}")#text(" ")#mi("{\\delta}")#text("-tubes inside a ")#mi("{\\rho}")#text("-tube. If we perform a non-isotropic scaling to rescale a ")#mi("{\\rho}")#text("-tube to become a ")#mi("{1}")#text("-tube, then the ")#mi("{\\delta}")#text("-tubes rescale to be ")#mi("{(\\delta/\\rho)}")#text("-tubes, and we obtain a rescaled set ")#mi("{\\tilde E_\\delta[T_\\rho]}")#text(" with ")#metadata(none) <tao-7ae199c3bb068ec906d1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|\\tilde E_\\delta[T_\\rho]\\right| = \\rho^{-2} |E_\\delta[T_\\rho]|.", block: true)]]

#text("This set is the union of about ")#mi("{(\\rho/\\delta)^{-2}}")#text(" ")#mi("{(\\delta/\\rho)}")#text("-tubes obeying the Wolff axiom, and so by definition of ")#mi("{\\sigma}")#text(" should have volume at least ")#mi("{(\\delta/\\rho)^\\sigma}")#text(": ")#metadata(none) <tao-11953e0c41f4abcb8e61>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|\\tilde E_\\delta[T_\\rho]\\right| \\gtrapprox (\\delta/\\rho)^\\sigma.", block: true)]]

#text("The estimates ")#link(<tao-d86d3e078b518355dc4e>)[#text("(1)")]#text("–")#link(<tao-11953e0c41f4abcb8e61>)[#text("(4)")]#text(" fit together in a perfect circle, forcing all of the inequalities to be approximate equalities; thus we heuristically have that ")#mi("{\\tilde E_\\delta[T_\\rho]}")#text(" to be an optimal Kakeya configuration (much like ")#mi("{E_\\delta}")#text(" or ")#mi("{E_\\rho}")#text("), and to have ")#metadata(none) <tao-887f2f5432c997876497>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("E_\\delta[T_\\rho] \\approx E_\\delta \\cap T_\\rho")]]

#text("for every fat tube ")#mi("{T_\\rho}")#text(". Informally, we have an affine self-similar structure: the portion of ")#mi("{E_\\delta}")#text(" inside every ")#mi("{\\rho}")#text("-tube is a rescaled version of ")#mi("{E_{\\rho/\\delta}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" Let us return to the complex setting, and take ")#mi("{E}")#text(" to be the Heisenberg group ")#mi("{H}")#text(" (with ")#mi("{\\sigma=1/2}")#text("), so that ")#metadata(none) <tao-6bdb262b0201799aefb0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("E_\\delta \\approx \\{ (z_1,z_2,z_3): z_1,z_2,z_3 = O(1), \\text{Im}(z_1) = \\text{Im}(z_2 \\overline{z_3}) + O(\\delta) \\}.")]]

#text("The Heisenberg group contains the line ")#mi("{\\{ (0,0,z): z \\in {\\bf C} \\}}")#text(", so the set ")#mi("{\\{ (z_1,z_2,z_3): z_1,z_2 = O(\\rho); z_3 = O(1) \\}}")#text(" would essentially be a ")#mi("{\\rho}")#text("-tube ")#mi("{T_\\rho}")#text(" in ")#mi("{E_\\rho}")#text(", and")

#tao-aligned(keep: true)[


#tao-math("E_\\delta \\cap T_\\rho  & \\approx E_\\delta[T_\\rho]", block: true)



#tao-math(" & \\approx \\{ (z_1,z_2,z_3): z_1,z_2 = O(\\rho); z_3 = O(1); \\text{Im}(z_1) = \\text{Im}(z_2 \\overline{z_3}) + O(\\delta) \\}.", block: true)
]

#text("Applying the rescaling")

#align(center)[#tao-fit-display[#mitex("(w_1,w_2,w_3) = (\\frac{\\rho}{\\delta} z_1, \\frac{\\rho}{\\delta} z_2, z_3)")]]

#text("we then have")

#tao-aligned(keep: true)[


#tao-math("\\tilde E_\\delta[T_\\rho]  & \\approx \\{ (w_1,w_2,w_3): w_1,w_2,w_3 = O(1);", block: true)



#tao-math("\\text{Im}(w_1)  & = \\text{Im}(w_2 \\overline{w_3}) + O(\\delta/\\rho) \\}", block: true)
]

#text("so in this case we have essentially perfect self-similarity: ")#metadata(none) <tao-1ae2a436722d0c5d6aee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\tilde E_\\delta[T_\\rho] \\approx E_{\\delta/\\rho}.")]]
]

#heading(level: 1)[#strong[#text(" — 2. Planiness and local graininess — ")]]

#text("The next stage is fairly well understood, being mapped out in ")#link("http://www.ams.org/mathscinet-getitem?mr=1804528")[#text("my previous paper with Nets and Izabella")]#text(". We now take ")#mi("{\\rho = \\sqrt{\\delta}}")#text(". From ")#link(<tao-887f2f5432c997876497>)[#text("(5)")]#text(" we know that if a ")#mi("{\\rho}")#text("-cube ")#mi("{Q_\\rho}")#text(" lies in a ")#mi("{\\rho}")#text("-tube ")#mi("{T_\\rho}")#text(", then")

#align(center)[#tao-fit-display[#mitex("E_\\delta \\cap Q_\\rho \\approx E_\\delta[T_\\rho] \\cap Q_\\rho.")]]

#text("On the other hand, with the choice ")#mi("{\\rho=\\sqrt{\\delta}}")#text(", elementary geometry reveals that ")#mi("{E_\\delta[T_\\rho] \\cap Q_\\rho}")#text(" is essentially the union of ")#mi("{\\sqrt{\\delta} \\times \\delta}")#text("-tubes oriented to be parallel to ")#mi("{T_\\rho}")#text(". We conclude that ")#mi("{E_\\delta \\cap Q_\\rho}")#text(" resembles the union of ")#mi("{\\sqrt{\\delta} \\times \\delta}")#text("-tubes oriented parallel to ")#mi("{T_\\rho}")#text(". But if ")#mi("{T^{\\prime}_\\rho}")#text(" is another ")#mi("{\\rho}")#text("-tube passing through ")#mi("{Q_\\rho}")#text(", then ")#mi("{E_\\delta \\cap Q_\\rho}")#text(" must also resemble ")#mi("{\\sqrt{\\delta} \\times \\delta}")#text("-tubes oriented parallel to ")#mi("{T^{\\prime}_\\rho}")#text(". If ")#mi("{T_\\rho, T^{\\prime}_\\rho}")#text(" are widely separated in angle (which we can morally ensure through a “bilinear reduction”, which we will not discuss here), this forces the following ")#emph[#text("local graininess property")]#text(": for every ")#mi("{\\rho}")#text("-cube, ")#mi("{E_\\delta \\cap Q_\\rho}")#text(" resembles the union of ")#mi("{\\sqrt{\\delta} \\times \\sqrt{\\delta} \\times \\delta}")#text(" parallel slabs (or “local grains”); since ")#mi("{E_\\delta \\cap Q_\\rho}")#text(" contains about ")#mi("{(\\rho/\\delta)^{3-\\delta}}")#text(" ")#mi("{\\delta}")#text("-cubes, we see that the number of such slabs is about ")#mi("{(1/\\sqrt{\\delta})^{1-\\sigma}}")#text(".")

#text("Local graininess also forces coarse-scale ")#emph[#text("planiness")]#text(": the ")#mi("{\\rho}")#text("-tubes passing through ")#mi("{Q_\\rho}")#text(" must all essentially lie within ")#mi("{\\rho}")#text(" of a common plane, parallel to the plane in which the local grains are oriented. The reason for this is that if the tubes were any less coplanar than this, then there would be local graininess in more than one direction, and this would start forcing ")#mi("{E_\\delta}")#text(" to contain cubes that are much larger than ")#mi("{\\delta}")#text(" in size, contradicting the ")#mi("{3-\\sigma}")#text("-dimensionality of ")#mi("{E}")#text(".")

#text("Rescaling ")#mi("{\\rho}")#text(" to be ")#mi("{\\delta}")#text(", we then conclude fine-scale planiness: the ")#mi("{\\delta}")#text("-tubes passing through a ")#mi("{\\delta}")#text("-cube in ")#mi("{E_\\delta}")#text(" all essentially lie within ")#mi("{\\delta}")#text(" of a common plane.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" We return to the complex Heisenberg group from the previous example. The intersection of ")#mi("{E_\\delta}")#text(" with the (complex) ")#mi("{\\rho}")#text("-cube ")#mi("{Q_\\rho = \\{ (z_1,z_2,z_3): z_1,z_2,z_3 = O(\\sqrt{\\delta}) \\}}")#text(" takes the form")

#align(center)[#tao-fit-display[#mitex("E_\\delta \\cap Q_\\rho \\approx \\{ (z_1,z_2,z_3): z_1,z_2,z_3 = O(\\sqrt{\\delta}); \\text{Im}(z_1) = O(\\delta) \\}")]]

#text("which is the union of about ")#mi("{\\delta^{-1/2}}")#text(" ")#mi("{\\sqrt{\\delta}\\times\\sqrt{\\delta}\\times\\delta}")#text(" (complex) slabs of the form ")#metadata(none) <tao-d218de9577feaff52f08>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\{ (z_1,z_2,z_3): z_1,z_2,z_3 = O(\\sqrt{\\delta}); z_1 = x + O(\\delta) \\}")]]

#text("where ")#mi("{x}")#text(" ranges over a ")#mi("{\\delta}")#text("-separated subset of the real interval ")#mi("{[-\\sqrt{\\delta},\\sqrt{\\delta}]}")#text(". This illustrates the local graininess of the Heisenberg group in one cube ")#mi("{Q_\\rho}")#text("; local graininess in other cubes can then be established by applying the group law (or by direct computation).")

#text("Similarly, the lines in the Heisenberg group passing through the origin ")#mi("{(0,0,0)}")#text(" take the form")

#align(center)[#tao-fit-display[#mitex("\\ell_{s,0,0} := \\{ (0, z, sz): z \\in {\\bf C} \\}")]]

#text("with ")#mi("{s \\in {\\bf R}}")#text(", which all lie in the complex plane ")#mi("{\\{ (0,z_2,z_3): z_2,z_3 \\in {\\bf C} \\}}")#text(". Thus, (many of) the ")#mi("{\\delta}")#text("-tubes passing through the ")#mi("{\\delta}")#text("-cube")

#align(center)[#tao-fit-display[#mitex("Q_\\delta = \\{ (z_1,z_2,z_3): z_1,z_2,z_3 = O(\\delta) \\}")]]

#text("take the form")

#align(center)[#tao-fit-display[#mitex("\\{ (z_1,z_2,z_3): z_1 = O(\\delta); z_2 = O(1); z_3 = s z_2 + O(\\delta) \\}")]]

#text("for some real ")#mi("{s = O(1)}")#text(", and these lie within ")#mi("{O(\\delta)}")#text(" of the same complex plane, exhibiting planiness at scale ")#mi("{\\delta}")#text(" (and similarly at other scales, such as ")#mi("{\\rho}")#text("); note also the relevant plane ")#mi("{\\{ (0,z_2,z_3): z_2,z_3 \\in {\\bf C} \\}}")#text(" is parallel to the slabs ")#link(<tao-d218de9577feaff52f08>)[#text("(8)")]#text(". Again, by the group law, a similar geometry holds at other points of ")#mi("{E}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One should also be able to establish a weak form of planiness via the ")#link("http://www.ams.org/mathscinet-getitem?mr=2275834")[#text("multilinear Kakeya estimate of Bennett, Carbery, and myself")]#text(". Recently, ")#link("http://arxiv.org/abs/1402.0518")[#text("Guth has used the polynomial method")]#text(" to also establish a weak form of local graininess. One may hope that a sufficient development of these new techniques may reduce the need to establish strong stickiness properties in this argument, which is currently the largest missing technical piece needed to make the argument rigorous.")
]

#heading(level: 1)[#strong[#text(" — 3. Global graininess — ")]]

#text("By applying a non-isotropic rescaling, we can add a further structural property to the stickiness, planiness, and graininess properties already obtained. Namely, take ")#mi("{\\rho=\\sqrt{\\delta}}")#text(" again and consider a single ")#mi("{\\rho}")#text("-tube ")#mi("{T_\\rho}")#text(" in ")#mi("{E_\\rho}")#text(", which we will normalise to be")

#align(center)[#tao-fit-display[#mitex("T_\\rho = \\{ (x,y,z): x,y = O(\\sqrt{\\delta}); z = O(1) \\}.")]]

#text("Applying the rescaling ")#mi("{(x^{\\prime},y^{\\prime},z^{\\prime}) := (x/\\sqrt{\\delta}, y/\\sqrt{\\delta}, z)}")#text(", we obtain a rescaled set ")#mi("{\\tilde E_\\rho := \\tilde E_\\delta[T_\\rho]}")#text(", which as discussed before obeys similar properties to ")#mi("{E_{\\rho}}")#text(", and in particular should continue to have the sticky, plany, and grainy properties that the original set ")#mi("{E_\\rho}")#text(" had. Now consider a cube ")#mi("{Q_\\rho}")#text(" in ")#mi("{T_\\rho}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("Q_\\rho = \\{ (x,y,z): x,y = O(\\sqrt{\\delta}); z = z_0 + O(\\sqrt{\\delta}) \\}")]]

#text("for some ")#mi("{z_0 = O(1)}")#text(". By local graininess, ")#mi("{E_\\delta \\cap Q_\\rho}")#text(" is the union of ")#mi("{\\sqrt{\\delta} \\times \\sqrt{\\delta} \\times \\rho}")#text(" slabs oriented in some plane parallel to ")#mi("{T_\\rho}")#text("; thus we have some slope ")#mi("{f(z_0)}")#text(" with the property that ")#mi("{E_\\delta \\cap Q_\\rho}")#text(" is the union of about ")#mi("{(1/\\rho)^{1-\\sigma}}")#text(" sets of the form")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y,z): x,y = O(\\sqrt{\\delta}); z = z_0 + O(\\sqrt{\\delta}); x - f(z_0) y = x_0 \\sqrt{\\delta} + O(\\delta) \\}")]]

#text("for various ")#mi("{x_0 = O(1)}")#text(". Rescaling this, we conclude that the horizontal slice")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y): (x,y,z_0) \\in \\tilde E_\\rho \\}")]]

#text("of ")#mi("{\\tilde E_\\rho}")#text(" is the union of about ")#mi("{(1/\\rho)^{1-\\sigma}}")#text(" rectangles of the form")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y): x,y = O(1); x-f(z_0) y = x_0 + O(\\rho) \\}")]]

#text("for various ")#mi("{x_0=O(1)}")#text(". We refer to this property as ")#emph[#text("global graininess")]#text(" at scale ")#mi("{\\rho}")#text(". Relabeling ")#mi("{\\rho}")#text(" as ")#mi("{\\delta}")#text(" again, we arrive at a set ")#mi("{\\tilde E_\\delta}")#text(" that obeys the same stickiness, planiness, and local graininess property as ")#mi("{E_\\delta}")#text(", but also obeys the global graininess property that for every ")#mi("{z_0=O(1)}")#text(", the slice")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y): (x,y,z_0) \\in \\tilde E_\\delta \\}")]]

#text("is the union of about ")#mi("{(1/\\delta)^{1-\\sigma}}")#text(" rectangles (or “global grains”) of the form")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y): x,y = O(1); x-f(z_0) y = x_0 + O(\\delta) \\}")]]

#text("for various ")#mi("{x_0=O(1)}")#text(", and some function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(". Some multiscale analysis lets one establish some additional “stickiness” properties on ")#mi("{f}")#text(", which roughly speaking means that ")#mi("{f}")#text(" behaves like a mostly Lipschitz function, but we will not discuss this further here. We also note that the local and global grains have to be compatible, in the sense that the local grains are parallel to the global grains when they meet, for reasons similar to the compatibility of the planes and local grains mentioned previously. In particular, the planes must also be compatible with the global grains.")

#text("Note that we have broken the rotational symmetry of the Kakeya problem here by performing a rescaling that privileges the vertical ")#mi("{z}")#text(" axis over the horizontal ")#mi("{x,y}")#text(" directions; one cannot expect to have global graininess in every orientation, only in an orientation that one designates to be the horizontal.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" We continue the running example of the Heisenberg group. Due to the perfect self-similarity ")#link(<tao-1ae2a436722d0c5d6aee>)[#text("(7)")]#text(", we essentially have ")#mi("{\\tilde E_\\delta = E_\\delta}")#text(", so that ")#mi("{E_\\delta}")#text(" already has the desired global graininess property. And indeed, from ")#link(<tao-6bdb262b0201799aefb0>)[#text("(6)")]#text(" we see that for any ")#mi("{z_1=O(1)}")#text(", the set")

#align(center)[#tao-fit-display[#mitex("\\{ (z_1,z_2): (z_1,z_2,z_0) \\in E_\\delta \\}")]]

#text("is of the form")

#align(center)[#tao-fit-display[#mitex("\\{ (z_1,z_2): z_1,z_2 = O(1), \\text{Im}(z_1 - \\overline{z_0} z_2) = O(\\delta) \\},")]]

#text("and is thus the union of about ")#mi("{\\delta^{-1}}")#text(" complex rectangles of the form")

#align(center)[#tao-fit-display[#mitex("\\{ (z_1,z_2): z_1,z_2 = O(1), z_1 - f(z_0) z_2 = x_0 + O(\\delta) \\}")]]

#text("with ")#mi("{x_0 = O(1)}")#text(" purely imaginary and ")#mi("{f(z_0) := \\overline{z_0}}")#text(". In particular, ")#mi("{z_0=0}")#text(", the global grains are oriented along the ")#mi("{z_2}")#text(" axis, which is compatible with the planes and local grains at ")#mi("{(0,0,0)}")#text(", which are oriented along the ")#mi("{z_2,z_3}")#text(" plane. Similarly at other locations on the Heisenberg group, thanks to the group law.")
]

#heading(level: 1)[#strong[#text(" — 4. Reduction to a 2D structure — ")]]

#text("Now we put together all the various structures that we have. Consider a single global grain of ")#mi("{E_\\delta}")#text(", which we normalise to be at the slice ")#mi("{z_0=0}")#text(" and to be the rectangle")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y): x = O(\\delta); y = O(1) \\},")]]

#text("so that ")#mi("{f(0)=0}")#text(". We will work in a ")#mi("{\\sqrt{\\delta}}")#text("-neighbourhood of this grain, namely a “fat grain”")

#align(center)[#tao-fit-display[#mitex("G = \\{ (x,y,z): x,z = O(\\sqrt{\\delta}); y = O(1) \\}.")]]

#text("By global graininess, the ")#mi("{z=0}")#text(" slice of ")#mi("{E_\\delta \\cap G}")#text(" takes the form ")#metadata(none) <tao-769a4e6d0003189c7e96>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\{ (x,y): x \\in \\sqrt{\\delta} A; y = O(1) \\}")]]

#text("for some set ")#mi("{A \\subset [-O(1),O(1)]}")#text(" in the real line which is the union of ")#mi("{(1/\\sqrt{\\delta})^{1-\\sigma}}")#text(" ")#mi("{\\sqrt{\\delta}}")#text("-intervals. Meanwhile local graininess forces the ")#mi("{y=0}")#text(" slice")

#align(center)[#tao-fit-display[#mitex("\\{ (x,z): (x,0,z) \\in E_\\delta \\cap G \\}")]]

#text("of ")#mi("{E_\\delta \\cap G}")#text(" to be the union of parallel ")#mi("{\\delta \\times \\sqrt{\\delta}}")#text("-rectangles aligned with the ")#mi("{y}")#text("-axis, which we can renormalise (by a shear respecting the ")#mi("{z_0=0}")#text(" slice) to be vertically oriented; to be compatible with ")#link(<tao-769a4e6d0003189c7e96>)[#text("(9)")]#text(", we see that this slice must be equal to ")#metadata(none) <tao-a12e45b23513ff84c050>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\{ (x,z): x \\in \\sqrt{\\delta} A; z = O(\\sqrt{\\delta}) \\}.")]]

#text("Now we consider a horizontal slice")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y): (x,y,\\sqrt{\\delta} z_0) \\in E_\\delta \\cap G \\}")]]

#text("of ")#mi("{E_\\delta \\cap G}")#text(" for some ")#mi("{z_0=O(1)}")#text(". By global graininess (and stickiness of ")#mi("{f}")#text("), this slice is the union of rectangles of the form")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y): x = O(\\sqrt{\\delta}); y = O(1); x-\\sqrt{\\delta} \\tilde f(z_0) y = \\sqrt{\\delta} x_0 + O(\\delta) \\}")]]

#text("for various ")#mi("{x_0=O(1)}")#text(", where ")#mi("{\\tilde f(z_0) := \\frac{1}{\\sqrt{\\delta}} f( \\sqrt{\\delta} z_0)}")#text(" is a rescaled version of ")#mi("{f}")#text(" (and in particular should have similar stickiness properties to ")#mi("{f}")#text("). To be compatible with ")#link(<tao-a12e45b23513ff84c050>)[#text("(10)")]#text(", we conclude that this slice must in fact essentially take the form ")#metadata(none) <tao-ec6aded56b9556c0fac4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\{ (x,y): x = O(\\sqrt{\\delta}); y = O(1); x-\\sqrt{\\delta} \\tilde f(z_0) y \\in \\sqrt{\\delta} A \\}.")]]

#text("Finally, we consider a vertical slice")

#align(center)[#tao-fit-display[#mitex("\\{ (x,z): (x,y_0,z) \\in E_\\delta \\cap G \\}")]]

#text("of ")#mi("{E_\\delta \\cap G}")#text(" for some ")#mi("{y_0 = O(1)}")#text(". By local graininess, this slice is the union of rectangles of the form")

#align(center)[#tao-fit-display[#mitex("\\{ (x,z): x,z = O(\\sqrt{\\delta}); x - g(y_0) z = \\sqrt{\\delta} x_0 + O(\\delta) \\}")]]

#text("for some slope function ")#mi("{g(y_0)}")#text(", which one can argue to also be sticky. In order to be compatible with ")#link(<tao-769a4e6d0003189c7e96>)[#text("(9)")]#text(", this slice must in fact essentially take the form")

#align(center)[#tao-fit-display[#mitex("\\{ (x,z): x,z = O(\\sqrt{\\delta}); x - g(y_0) z \\in \\sqrt{\\delta} A \\}.")]]

#text("For this to be compatible with ")#link(<tao-ec6aded56b9556c0fac4>)[#text("(11)")]#text(", we obtain the crucial “zero-curvature” property")

#align(center)[#tao-fit-display[#mitex("\\{ x + \\tilde f(z) y - g(y) z: x \\in A; y,z = O(1) \\} \\approx A")]]

#text("or in sum set notation ")#metadata(none) <tao-475a54d2b7705bf08abd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("A + \\{ \\tilde f(z) y - g(y) z: y,z = O(1) \\} \\approx A.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4")]#text(" In the running example of the Heisenberg group, ")#mi("{A}")#text(" is the “half-dimensional set”")

#align(center)[#tao-fit-display[#mitex("A = \\{ z: z = O(1); \\text{Re}(z)=0 \\}")]]

#text("and ")#mi("{\\tilde f(z) = \\overline{z}, g(y) = \\overline{y}}")#text(" are complex conjugation, so that ")#mi("{A}")#text(" and ")#mi("{\\{ \\tilde f(z) y - g(y) z: y,z = O(1) \\}}")#text(" are bounded subsets of the imaginary axis.")
]

#text("We can write ")#link(<tao-475a54d2b7705bf08abd>)[#text("(12)")]#text(" as a two-dimensional assertion")

#align(center)[#tao-fit-display[#mitex("A + F \\cdot G \\approx A")]]

#text("where ")#mi("{F, G}")#text(" are the one-dimensional graphs in ")#mi("{{\\bf R}^2}")#text(" given by")

#align(center)[#tao-fit-display[#mitex("F(z) := \\{ (\\tilde f(z), z): z = O(1) \\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("G(y) := \\{ (y, -g(y)): y = O(1) \\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("F \\cdot G = \\{ v \\cdot w: v \\in F, w \\in G \\}")]]

#text("with ")#mi("{\\cdot}")#text(" denoting the dot product on ")#mi("{{\\bf R}^2}")#text(". Recall that ")#mi("{A}")#text(" is basically the ")#mi("{\\rho}")#text("-neighbourhood of a ")#mi("{1-\\sigma}")#text("-dimensional set.")

#heading(level: 1)[#strong[#text(" — 5. Reduction to a 1D structure — ")]]

#text("We have just eliminated one dimension from the three-dimensional Kakeya problem. Now we eliminate one more dimension, to reduce to a one-dimensional problem.")

#text("The sets ")#mi("{F, G}")#text(" are one-dimensional. Viewed in polar coordinates, we can (heuristically, at least) assume that for some ")#mi("{0\\leq \\theta \\leq 1}")#text(", there is a ")#mi("{\\theta}")#text("-dimensional family of rays through the origin, such that ")#mi("{F}")#text(" meets each such ray in a ")#mi("{1-\\theta}")#text("-dimensional set. Standard projection theorems (or double counting) then tell us that for a typical ray in this ")#mi("{\\theta}")#text("-dimensional family, the projection of the one-dimensional set ")#mi("{G}")#text(" to such a ray should have dimension at least ")#mi("{\\theta}")#text(". Because of this, we can conclude that ")#mi("{F \\cdot G}")#text(" should contain a product set ")#mi("{BC}")#text(", where ")#mi("{B, C}")#text(" are bounded non-empty subsets of ")#mi("{{\\bf R}}")#text(" of dimensions ")#mi("{\\theta}")#text(" and ")#mi("{1-\\theta}")#text(" respectively. If ")#mi("{\\theta}")#text(" is too close to zero or one, this already makes ")#mi("{F \\cdot G}")#text(" of dimension larger than ")#mi("{A}")#text(", a contradiction, so we may assume that ")#mi("{\\theta}")#text(" is bounded away from zero and one. Dropping the discretisations and informally moving back to the continuous setting, we thus have the one-dimensional setup ")#metadata(none) <tao-ba7816bf8f01cfea4141>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("A + B \\cdot C \\approx A")]]

#text("with")

#align(center)[#tao-fit-display[#mitex("0 < \\text{dim}(A), \\text{dim}(B), \\text{dim}(C) < 1")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\text{dim}(B) + \\text{dim}(C) = 1.")]]

#heading(level: 1)[#strong[#text(" — 6. Contradicting the sum-product theorem — ")]]

#text("Finally, we use some additive combinatorics manipulations (inspired by some finite field ")#link("http://www.ams.org/mathscinet-getitem?mr=2059656")[#text("arguments of Bourgain")]#text(") to reduce to a setting ruled out by Bourgain’s sum-product theorem.")

#text("From iterating ")#link(<tao-ba7816bf8f01cfea4141>)[#text("(13)")]#text(", we expect all iterated sumsets ")#mi("{B \\cdot C + \\dots + B \\cdot C}")#text(" to have dimension bounded above by ")#mi("{\\text{dim}(A)}")#text(", and thus bounded away from ")#mi("{1}")#text(". Stabilising this, we thus expect ")#mi("{B \\cdot C}")#text(" to be contained in (a translate of) an approximate group ")#mi("{H}")#text(" in the real line with")

#align(center)[#tao-fit-display[#mitex("0 < \\text{dim}(H) < 1.")]]

#text("Ignoring the translate, we thus see that ")#mi("{B}")#text(" is contained in ")#mi("{c^{-1} H}")#text(" for all ")#mi("{c \\in C}")#text(" (removing those portions of ")#mi("{C}")#text(" that are too close to zero, if needed).")

#text("Now let ")#mi("{\\mu}")#text(" be a probability measure supported on ")#mi("{B}")#text(", then the Fourier transform ")#mi("{\\hat \\mu}")#text(" should be essentially one on the set ")#mi("{c H^\\perp}")#text(", where ")#mi("{H^\\perp}")#text(" is some sort of dual approximate group to ")#mi("{H}")#text("; thus ")#mi("{\\hat \\mu}")#text(" should be about ")#mi("{1}")#text(" on ")#mi("{C H^\\perp}")#text(", which is a set of dimension at least ")#mi("{\\text{dim}(C)}")#text(". On the other hand, Plancherel’s theorem tells us that the spectrum ")#mi("{\\text{Spec}(\\mu) = \\{ \\hat \\mu \\approx 1 \\}}")#text(" has dimension at most ")#mi("{1 - \\text{dim}(B) = \\text{dim}(C)}")#text(". Thus we have")

#align(center)[#tao-fit-display[#mitex("\\text{Spec}(\\mu) \\approx C H^\\perp \\approx C \\xi")]]

#text("for any ")#mi("{\\xi \\in H^\\perp}")#text(". Iterating this, we conclude that iterated product sets ")#mi("{(H^\\perp)^k = H^\\perp \\cdot \\dots \\cdot H^\\perp}")#text(" should be contained inside a dilate of ")#mi("{\\text{Spec}(\\mu)}")#text(". On the other hand, we also expect ")#mi("{\\text{Spec}(\\mu)}")#text(" be approximately closed under addition, and so the iterated sum-product sets ")#mi("{k (H^\\perp)^k}")#text(" should also be contained inside a dilate of ")#mi("{\\text{Spec}(\\mu)}")#text(" and thus have dimension bounded away from zero. In particular, these iterated sum-product sets must stabilise at some set ")#mi("{E}")#text(" with ")#mi("{0 < \\text{dim}(E) < 1}")#text(" and ")#mi("{\\text{dim}(E+E), \\text{dim}(E \\cdot E) \\approx \\text{dim}(E)}")#text("; but this more or less directly contradicts the ")#link("http://www.ams.org/mathscinet-getitem?mr=1982147")[#text("sum-product theorem of Bourgain")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/#comment-327847")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2014")])]

#text("“In view of this (and given that neither Nets or I have been actively working in this direction for some time now, due to many other projects), we’ve decided to distribute these ideas more widely than before, and in particular on this blog. ” Maybe on polymath?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/#comment-329528")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2014")])]

#text("Fan,")

#text("I was thinking the same, but perhaps someone else would take it up, if Terry doesn’t.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3ff748c2f21cacf6537e4181aa7cef4538601b37c283a70fdfe67ac4de627a4-a01538c1c2cb7fd7e4176c404738575211a498329f504230f17155723d5ff1cc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/#comment-334489")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2014")])]

#text("I’m definitely a novice here, but I have a thought for a project in this direction that might be amenable to the polymath approach. Namely, we may be able to see what happens if we go through the reasoning in this post, and take stock of what could be useful to improve the Katz-Laba-Tao result. For example:")#linebreak()#text(" What kind of improvements to stickiness estimates would be useful? How might Guth’s “local graininess” arguments help?")#linebreak()#text(" If it’s not clear how Guth’s results help, can we at least work with a plausible strengthening of them?")

#text("The idea being that instead of actually trying to “make progress”, we can use the arguments explained here to present a new set of directions for work on the Kakeya problem. Maybe this is a project best pursued by individual researchers, or best not pursued at all, but I thought I’d sketch an idea of what a polymath might look like.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d99d2d6e57877e1c3646332e6664c4a2e6fd3d04076748e77151a75e7793d900-104842cede0b2ef9095e6d10a02d30489430494ae81f72433244d7ab82449764.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/#comment-330521")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2014")])]

#text("I think a Polymath about this problem is a great idea.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/#comment-332164")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2014")])]

#text("What are the obstructions to carrying out an argument in this spirit to obtain something close to the full 3-d Kakeya conjecture in finite fields (as opposed to “just” the Bourgain-Katz-Tao $5/2+\\delta$ estimate)? It seems that many of the multi-scale issues (such as those related to stickiness which you consider the most serious obstruction) should be absent in that setting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/#comment-332380")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2014")])]

#text("It’s precisely the absence of multi-scale analysis that makes this entire line of argument useless in finite fields; what we are doing here is basically to repeatedly rescale or “Taylor expand” the Kakeya set until one arrives at a quadratic structure, namely (12) or (13). As far as I can tell, no analogue of these rescalings are available in finite fields (except possibly in the case of finite fields with lots and lots of subfields, e.g. ")#mi("F_{2^n}")#text(", although I haven’t thought too carefully about this).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf321d2381e42eadefd8656eac9e6e7b6d3ff9a7151d5d15179969026eac88b8-6feb69172594a33a6fb9335aa62951fddf7db2d141a6be16bbeb13cf2f217a2a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of murphmath")]], [#link("https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/#comment-332838")[#strong[#text("murphmath")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2014")])]

#text("A p-adic variant might be a reasonable alternative. Thickened lines over Z_p correspond to “lines” over Z/p^k. In this setting the combinatorics are very nice. For instance, if you consider the quotient map from (Z/p^2)^3 to (Z/p)^3, lines over Z/p lift to “fat lines” over Z/p^2, with each (“thin”) line over Z/p^2 belonging to a unique “fat line”. Rescaling by 1/p turns the family of thin lines belonging to a single fat line into a family of lines over Z/p.")

#text("Since there are good incidence theorems available over Z/p, you might be able to get good stickiness results (e.g. I(P,L)<|P|^{1/3}|L| under \"true 3D\" conditions on L is in Guth's class notes, which is like a strong x-ray estimate; this was proven by Elekes, Kaplan, and Sharir over R, but they use the Szemeredi-Trotter theorem in part of the argument, while Guth just uses degree reduction).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8eb9586f53da42fb5c246ee154627be3ac768a94aea3ed795218517d23e2b975-0602426bdbdee2609cc6eb54aad14f97eef7b701b63b89cf96bfeed1dff5e860.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anton Rasmussen")]], [#link("https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/#comment-491470")[#strong[#text("Anton Rasmussen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2018")])]

#text("Just wanted to post that the link to the video was broken; but, I was able to hunt it down via WebArchive to the following link:")#link("https://ipam.wistia.com/medias/hhsl7oam61")[#text("https://ipam.wistia.com/medias/hhsl7oam61")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/#comment-539536")[#strong[#text("The largest clique in the Paley Graph: unexpected significant progress and surprising connections. | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2020")]

#text("[…] Of course, the sum-product phenomena is a huge area with amazing applications (See, here, here, here, and here; I recall that Jean Bourgain referred to it as a gold mine or something like that). Now, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/#comment-681813")[#strong[#text("A New Proof Moves The Needle On A Sticky Geometry Problem • OopsWTF")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2023")]

#text("[…] 2014—more than a decade after Katz and Tao attempted to prove the Kakeya conjecture—Tao posted an outline of their approach on his blog, giving other mathematicians the chance to try it out for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/#comment-681816")[#strong[#text("A New Proof Moves the Needle on a Sticky Geometry Problem – Over View – Your Daily News Source")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2023")]

#text("[…] 2014—more than a decade after Katz and Tao attempted to prove the Kakeya conjecture—Tao posted an outline of their approach on his blog, giving other mathematicians the chance to try it out for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/#comment-681817")[#strong[#text("A Up to date Proof Strikes the Needle on a Sticky Geometry Plight – I NEWS ps")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2023")]

#text("[…] than a decade after Katz and Tao tried to converse the Kakeya conjecture—Tao posted a primary stage concept of their functionality on his weblog, giving assorted mathematicians the likelihood to take dangle of a glimpse at it out […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The three-dimensional Kakeya conjecture, after Wang and Zahl | What's new")]], [#link("https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/#comment-687398")[#strong[#text("The three-dimensional Kakeya conjecture, after Wang and Zahl | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2025")])]

#text("[…] in the sticky case, loosely following a strategy of Nets Katz and myself that I discussed in this previous blog post from over a decade ago. I will not discuss this portion of the argument further here, referring the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/#comment-693406")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2026")])]

#text("The links to your IPAM talk at the beginning appear to be broken. This one is working:")

#link("https://www.ipam.ucla.edu/abstract/?tid=11846&pcode=CCGWS3")[#text("https://www.ipam.ucla.edu/abstract/?tid=11846&pcode=CCGWS3")]

#emph[#text("[Link updated, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/05/07/stickiness-graininess-planiness-and-a-sum-product-approach-to-the-kakeya-problem/#comment-693602")[#strong[#text("Hong Wang Wins 2026 Fields Medal, The Third Woman Ever - AP News")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")]

#text("[…] learn a 2014 weblog put up by the UCLA mathematician Terence Tao laying out a proof strategy that Tao and Katz had developed however by no means pursued. The strategy appeared promising, so […]")
]
