// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/
// Converted to Typst by tao2typ: "2026-10-14T15:20:08.605589+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath15, tenth thread: numerics update", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath15, tenth thread: numerics update")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 September 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/")[#text("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is the tenth “research” thread of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("Polymath15 project")]#text(" to upper bound the ")#link("https://en.wikipedia.org/wiki/De_Bruijn%E2%80%93Newman_constant")[#text("de Bruijn-Newman constant")]#text(" ")#mi("{\\Lambda}")#text(", continuing ")#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/")[#text("this post")]#text(". Discussion of the project of a non-research nature can continue for now in ")#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/")[#text("the existing proposal thread")]#text(". Progress will be summarised at ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("this Polymath wiki page")]#text(".")

#text("Most of the progress since the last thread has been on the numerical side, in which the various techniques to numerically establish zero-free regions to the equation ")#mi("H_t(x+iy)=0")#text(" have been streamlined, made faster, and extended to larger heights than were previously possible. The best bound for ")#mi("\\Lambda")#text(" now depends on the height to which one is willing to assume the Riemann hypothesis. Using the conservative verification up to height (slightly larger than) ")#mi("3 \\times 10^{10}")#text(", which has been confirmed by independent work of ")#link("http://www.ams.org/journals/mcom/2017-86-307/S0025-5718-2017-03198-7/")[#text("Platt et al.")]#text(" and ")#link("http://numbers.computation.free.fr/Constants/Miscellaneous/zetazeros1e13-1e24.pdf")[#text("Gourdon-Demichel")]#text(", the best bound remains at ")#mi("\\Lambda \\leq 0.22")#text(". Using the verification up to height ")#mi("2.5 \\times 10^{12}")#text(" claimed by Gourdon-Demichel, this improves slightly to ")#mi("\\Lambda \\leq 0.19")#text(", and if one assumes the Riemann hypothesis up to height ")#mi("5 \\times 10^{19}")#text(" the bound improves to ")#mi("\\Lambda \\leq 0.11")#text(", contingent on a numerical computation that is still underway. (See the table below the fold for more data of this form.) This is broadly consistent with the expectation that the bound on ")#mi("\\Lambda")#text(" should be inversely proportional to the logarithm of the height at which the Riemann hypothesis is verified.")

#text("As progress seems to have stabilised, it may be time to transition to the writing phase of the Polymath15 project. (There are still some interesting research questions to pursue, such as numerically investigating the zeroes of ")#mi("H_t")#text(" for negative values of ")#mi("t")#text(", but the writeup does not necessarily have to contain every single direction pursued in the project. If enough additional interesting findings are unearthed then one could always consider writing a second paper, for instance.")

#text("Below the fold is the detailed progress report on the numerics by Rudolph Dwars and ")#link("https://kommonmann.wordpress.com/contact/")[#text("Kalpesh Muchhal")]#text(".")

#metadata(none) <tao-58de71f36897bafeb50f>

#heading(level: 1)[#strong[#text(" — Quick recap — ")]]

#text("The effectively bounded and normalised, Riemann-Siegel type asymptotic approximation for ")#mi("H_t(x+yi)")#text(":")

#align(center)[#tao-fit-display[#mitex("\\frac{H_t(x+yi)}{B_0(x+yi)} = ABB_{eff}(x + iy)+ \\mathcal{O}_{\\le}(e_A+e_B + e_{C,0})")]]

#text("enables us to explore its complex zeros and to establish zero-free regions. By choosing a promising combination ")#mi("y_0")#text(" and ")#mi("t_0")#text(", and then numerically and analytically showing that the right-hand side doesn’t vanish in the rectangular shaped “canopy” ")#mi("x=0 \\dots \\infty, t = t_0, y=y_0 \\dots 1")#text(" (or a point on the blue hyperbola), a new DBN upper bound ")#mi("\\Lambda")#text(" will be established. Summarized in this visual:")

#image("../assets/d5a8b42bcb9f792a54b5f667c452d1be224b68865877e39e25bed21982225497-2eb735e3cf375252bfd08d3705052f94dcae7ab193f0a9cdaafc5bce2b75005d.png", width: 90%, alt: "numerics1")

#heading(level: 1)[#strong[#text("— The Barrier approach —")]]

#text("To verify that ")#mi("ABB_{eff} \\ne 0")#text(" in such a rectangular strip, we have adopted the so-called Barrier-approach that comprises of three stages (illustrated in a picture below):")

#image("../assets/c15478d296f51f05f7884d13dfa77312e9e561fe137bd8a7f5b096e22e608d0e-1c4d1132872dc40a580f569a3fe1cb07fa47e27c8af03e2b0380baf0a373f20a.png", width: 90%, alt: "numerics2")

#enum(start: 1, 
[#text("Use the numerical verification work of the RH already done by others. Independent teams have now verified the RH up to ")#mi("X=6 \\times 10^{10}")#text(", and a single study took it up to ")#mi("X=5 \\times 10^{12}")#text(". This work allows us to rule out, up to a certain ")#mi("X")#text(", that a complex zero has flown through the critical strip into any defined canopy. To also cover the x-domains that lie beyond these known verifications, we have to assume the RH up to ")#mi("X")#text(". This will then yield a ")#mi("\\Lambda")#text(" that is conditional on this assumption.")],
[#text("Complex zeros could also have horizontally flown into the ‘forbidden tunnel’ at high velocity. To numerically verify this hasn’t occurred, a Barrier needs to be introduced at ")#mi("X")#text(" and checked for any zeros having flown around, through or over it.")],
[#text("Verifying the range ")#mi("X \\leq x < \\infty")#text(" (or ")#mi("N_a \\leq N < \\infty")#text(") is done through testing that the lower bound of ")#mi("ABB_{eff}")#text(" always stays higher than the upper bound of the error terms. This has to be done numerically up to a certain point ")#mi("N=N_b")#text(", after which analytical proof takes over.")]
)

#text("So, new numerical computations are required to verify that both the Barrier at ")#mi("X")#text(" and the non-analytical part of the range ")#mi("N_a \\leq N \\leq  N_b")#text(" are zero-free for a certain choice of ")#mi("t_0, y_0")#text(".")

#heading(level: 1)[#strong[#text(" — Verifying the Barrier is zero-free —")]]

#text("So, how to numerically verify that the Barrier is zero-free?")

#enum(start: 1, 
[#text("The Barrier is required to have two nearby screens at ")#mi("X")#text(" and ")#mi("X+1")#text(" to ensure that no complex zeros could fly around it. Hence, it has the 3D structure: ")#mi("X \\dots X+1, y_0 \\dots 1, 0 \\dots t_0")#text(".")],
[#text("For the numerical verification that the Barrier is zero-free, it is treated as a ‘pile’ of ")#mi("x, y")#text(" rectangles. For each rectangle the winding number is computed using the argument principle and Rouché’s theorem.")],
[#text("For each rectangle, the number of mesh points required is decided using the ")#tao-math("\\left|\\frac{\\partial f}{\\partial z}\\right|", block: false)#text("-derivative, and the t-step is decided using the ")#tao-math("\\left|\\frac{\\partial f}{\\partial t}\\right|", block: false)#text("-derivative.")]
)

#image("../assets/899da2e1c7530b2c717f3ed10722173ab546f06ea19c7bf291ad190b18c400d2-36fb56c76f9e00b88d49346dc3366b2453dc2da1f0c84ea57327cc26a66d4228.png", width: 90%, alt: "numerics3")

#align(center)[#text("Optimizations used for the barrier computations")]

#list(
[#text("To efficiently calculate all required mesh points of ")#mi("ABB_{eff}")#text(" on the rectangle sides, we used a pre-calculated stored sum matrix that is Taylor expanded in the ")#mi("x, y")#text(" and ")#mi("t")#text("-directions. The resulting polynomial is used to calculate the required mesh points. The formula for the stored sum matrix:")]
)

#align(center)[#tao-fit-display[#mitex("\\mathrm{mat}(I \\times J) = {\\frac {1}{i!\\,j!\\,{4}^{j}}\\sum _{h=1}^{N}{h}^{i/2x-1/2} \\left( \\ln \\left( 2\\,{\\frac {h}{N}} \\right) \\right) ^{i+2\\,j}}")]]

#text("with ")#mi("i=0 \\dots I")#text(" and ")#mi("j=0 \\dots J")#text(", where ")#mi("I")#text(" and ")#mi("J")#text(" are the number of Taylor expansion terms required to achieve the required level of accuracy (in our computations we used 20 digits and an algorithm to automatically determine ")#mi("I")#text(" and ")#mi("J")#text(").")

#list(
[#text("We found that a more careful placement of the Barrier at an ")#mi("X+\\epsilon")#text(" makes a significant difference in the computation time required. A good location is where ")#mi("ABB_{eff}")#text(" has a large relative magnitude. Since ")#mi("ABB_{eff}")#text(" retains some Euler product structure, such locations can be quickly guessed by evaluating a certain euler product upto a small number of primes, for multiple X candidates in an X range.")],
[#text("Since ")#tao-math("\\left|\\frac{\\partial f}{\\partial z}\\right|", block: false)#text(" and ")#tao-math("\\left|\\frac{\\partial f}{\\partial t}\\right|", block: false)#text(" have smooth i.e. non-oscillatory behavior, using conservative numeric integrals with the Lemma 9.3 summands, ")#mi("\\textrm{summand}_{n=1} + \\int_{1}^{N} \\textrm{summand dn}")#text(", instead of the actual summation is feasible, and is significantly faster (the time complexity of estimation becomes independent of ")#mi("N")#text(")")],
[#text("Using a fixed mesh for a rectangle contour (can change from rectangle to rectangle) allows for vectorized computations and is significantly faster than using an adaptive mesh. To determine the number of mesh points, it is assumed that ")#mi("\\min ABB_{eff}^{mesh}")#text(" will stay above 1 (which is expected given the way the X location has been chosen, and is later verified after ")#mi("ABB_{eff}")#text(" has been computed at all the mesh points). The number is chosen as ")#tao-math("\\bigg{\\left\\lceil \\left|\\frac{\\partial f}{\\partial z}\\right| \\right\\rceil}", block: false)],
[#text("Since ")#mi("\\min(ABB_{eff}^{mesh})")#text(" for the above fixed mesh generally comes way above 1, the ")#mi("ABB_{eff}")#text(" lower bound along the entire contour (not just on the mesh points) is higher than what would be the case with an adaptive mesh. This property is used to obtain a larger t-step while moving in the t-direction")]
)

#align(center)[#tao-fit-display[#tao-math("t_{next} = t_{curr} + \\frac{\\min ABB_{eff}^{mesh} - 0.5}{\\big{\\left\\lceil \\left|\\frac{\\partial f}{\\partial t}\\right| \\right\\rceil}}", block: true)]]

#heading(level: 1)[#strong[#text(" — Verifying the range ")#mi("N_a \\leq N \\leq N_b")#text(" —")]]

#text("This leaves us with ensuring the range ")#mi("N_a \\leq N \\leq N_b")#text(" (where ")#mi("N_a")#text(" is the value of ")#mi("N")#text(" corresponding to the barrier ")#mi("X")#text(") is zero-free through checking that for each ")#mi("N")#text(", the ")#mi("ABB_{eff}")#text(" lower bound always exceeds the upper bound of the error terms.")

#enum(start: 1, 
[#text("From theory, two lower bounds are available: the Lemma-bound (eq. 80 in the ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/Writeup/debruijn.pdf")[#text("writeup")]#text(") and an approximate Triangle bound (eq. 79 in the ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/Writeup/debruijn.pdf")[#text("writeup")]#text("). Both bounds can be ‘mollified’ by choosing an increasing number of primes (to a certain extent) until the bound is sufficiently positive.")],
[#text("The Lemma bound is used to find the number of ‘mollifiers’ required to make the bound positive at ")#mi("N_a")#text(". We found that using primes ")#mi("2,3,5,7")#text(" was the max. number of primes still allowing an acceptable computational performance.")],
[#text("The approximate Triangle bound evaluates faster and is used to establish the mollified (either 0 primes or only prime 2) ")#mi("N_b")#text(" end point before the analytical lower bound takes over.")],
[#text("The Lemma-bound is then also used to calculate that for each ")#mi("N")#text(" in ")#mi("[N_a, N_b]")#text(", the lower bound stays sufficiently above the error terms. The Lemma bound only needs to be verified for the line segment ")#mi("y=y_0, t=t_0, N_a \\leq N(x) \\leq N_b")#sub[#text(",")]#text(" since the Lemma bound monotonically increases when ")#mi("y")#text(" goes to 1.")]
)

#image("../assets/4ddb5b930f6b81d15fd499fb3a0d69e2d9dfb3c08d6762aff7388a75fe6f195b-484de81e4d8db1a1f8bfb9aeaf24b351c0f67cf36e8d7373860e07e6d95491bf.png", width: 90%, alt: "numerics4")

#align(center)[#text("Optimizations used for Lemmabound calculations")]

#list(
[#text("To speed up computations a fast “sawtooth” mechanism has been developed. This only calculates the minimally required incremental Lemma bound terms and only induces a full calculation when the incremental bound goes below a defined threshold (that is sufficiently above the error bounds).")]
)

#tao-aligned(keep: true)[


#tao-math("\\left|f_{N_{min}}\\right|  & \\geq \\frac{1}{\\sum_{d=1}^D \\frac{\\left|\\lambda_d\\right|}{d^{\\sigma_{N_{min}}}}} \\left(1 - \\left|\\gamma_{N_{min}}\\right| - \\sum\\limits_{n=2}^{DN_{min}} \\frac{g(n,N_{min},N_{max})}{n^{\\sigma_{N_{min}}}} \\right)", block: true)



#tao-math(" & - \\left|\\gamma_{N_{min}}\\right| \\sum_{n=1}^{N_{min}} \\frac{b_n^t (n^{\\left|\\kappa\\right|} - 1)}{n^{\\sigma_{N_{min}}-y}}", block: true)



#tao-math("\\left|f_{N+1}\\right|  & := \\left|f_{N}\\right| - \\frac{1}{\\sum_{d=1}^D \\frac{\\left|\\lambda_d\\right|}{d^{\\sigma_{N+1}}}} \\sum\\limits_{1 \\leq d \\leq D:d|D}(\\sum\\limits_{n=dN+1}^{dN+d} \\frac{g(n,N_{min},N_{max})}{n^{\\sigma_{N+1}}}) - \\left|\\gamma_{N+1}\\right| \\frac{b_{N+1}^t ({(N+1)}^{\\left|\\kappa\\right|} - 1)}{(N+1)^{\\sigma_{N+1}-y}}", block: true)
]

#text("where")

#align(center)[#tao-fit-display[#tao-math("g(n,N,N_{max}) = \\max(\\frac{1-\\left|\\gamma\\right|_{N_{max}}}{1+\\left|\\gamma\\right|_{N_{max}}} \\left|\\beta_{n,N} + \\alpha_{n,N}\\right|,", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\beta_{n,N} - \\alpha_{n,N}\\right|, \\left|\\beta_{n,N} - \\left|\\frac{\\gamma_{N_{max}}}{\\gamma_{N}}\\right| \\alpha_{n,N}\\right|)", block: true)]]

#text("(as presented within section 9 of the ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/Writeup/debruijn.pdf")[#text("writeup")]#text(", pg. 42)")

#heading(level: 1)[#strong[#text(" — Software used —")]]

#text("To accommodate the above, he following software has been developed in both ")#strong[#text("pari/gp")]#text(" (")#link("https://pari.math.u-bordeaux.fr/")[#text("https://pari.math.u-bordeaux.fr")]#text(") and ")#strong[#text("ARB")]#text(" (")#link("http://arblib.org/")[#text("http://arblib.org")]#text("):")

#text("For verifying the Barrier:")

#list(
[#emph[#text("Barrier_Location_Optimizer")]#text(" to find the optimal ")#mi("X, X+1")#text(" location to place the Barrier.")],
[#emph[#text("Stored_Sums_Generator")]#text(" to generate in matrix form, the coefficients of the Taylor polynomial. This is one-off activity for a given ")#mi("X")#text(", post which the coefficients can be used for winding number computations in different ")#mi("y")#text(" and ")#mi("t")#text(" ranges.")],
[#emph[#text("Winding_Number_Calculator")]#text(" to verify that no complex zeros passed the Barrier.")]
)

#text("For verifying the ")#mi("N_a \\leq N \\leq N_b")#text(" range:")

#list(
[#emph[#text("N")]#sub[#emph[#text("b")]]#emph[#text("_Location_Finder")]#text(" for the number of mollifiers to make the bound positive.")],
[#emph[#text("Lemmabound_calculator")]#emph[#text(" ")]#text("Firstly, different mollifiers are tried to see which one gives a sufficiently positive bound at ")#mi("N_a")#text(". Then the calculator can be used with that mollifier to evaluate the bound for each ")#mi("N")#text(" in ")#mi("[N_a,N_b]")#text(". The ")#mi("[N_a,N_b]")#text(" range can also be broken up into sub-ranges, which can then be tackled with different mollifiers.")],
[#emph[#text("LemmaBound_Sawtooth_calculator")]#text(" to verify each incrementally calculated Lemma bound stays above the error bounds. Generally this script and the Lemmabound calculator script are substitutes for each other, although the latter may also be used for some initial portion of the N range.")]
)

#text("Furthermore we have developed software to compute:")

#list(
[#mi("ABB_{eff}")#text(" as ")#tao-math("\\left|\\frac{A+B}{B_0}\\right|", block: false)#text(" and/or ")#tao-math("\\left|\\frac{A+B-C}{B_0}\\right|", block: false)#text(".")],
[#text("the exact ")#mi("H_t(x+iy)")#text(" value (using the bounded version of the 3")#super[#text("rd")]#text(" integral approach).")]
)

#text("The software supports parallel processing through multi-threading and grid computing.")

#heading(level: 1)[#strong[#text(" — Results achieved —")]]

#text("For various combinations of ")#mi("y_0, t_0")#text(", these are the numerical outcomes:")

#image("../assets/43e8fdb5c5087abf88f7b57342ad7b54dd90db6fe07c4d7b196af155164c16a2-69bc4a8e858450f381b28aaff838e238022b371851763cd05c56c410a42b4c44.png", width: 90%, alt: "numerics5")

#text("The numbers suggest that we now have numerically verified that ")#mi("\\Lambda \\le 0.22")#text(" (even at two different Barrier locations). Also, conditionally on the RH being verified up to various ")#mi("x > 6 \\times 10^{10}")#text(", we have now reached a ")#mi("\\Lambda \\le 0.12")#text(". We are cautiously optimistic, that the tools available right now, do even bring a conditional ")#mi("\\Lambda \\le 0.10")#text(" within reach of computation.")

#heading(level: 1)[#strong[#text(" — Timings for verifying DBN ")#mi("\\le 0.22")#text(" —")]]

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#strong[#text("Procedure")]],
table.cell(colspan: 1, rowspan: 1)[#strong[#text("Timings")]],
table.cell(colspan: 1, rowspan: 1)[#text("Stored sums generation at X=6*10^10 + 83951.5")],
table.cell(colspan: 1, rowspan: 1)[#text("42 sec")],
table.cell(colspan: 1, rowspan: 1)[#text("Winding number check in the barrier for t=[0,0.2], y=[0.2,1]")],
table.cell(colspan: 1, rowspan: 1)[#text("42 sec")],
table.cell(colspan: 1, rowspan: 1)[#text("Lemma bounds using incremental method for N=[69098, 250000] and a 4-prime mollifier {2,3,5,7}")],
table.cell(colspan: 1, rowspan: 1)[#text("118 sec")],
table.cell(colspan: 1, rowspan: 1)[#text("Overall Timings")],
table.cell(colspan: 1, rowspan: 1)[#text("~200 sec")]
)

#text("Remarks:")

#list(
[#emph[#text("Timings to be multiplied by a factor of ~3.2 for each incremental order of magnitude of x.")]],
[#emph[#text("Parallel processing significantly improves speed (e.g. Stored sums was done in < 7 sec).")]],
[#emph[#text("Mollifier 2 analytical bound at ")#mi("N=250,000, y=0.2, t=0.2")#text(" is ")#mi("~ 0.098")#text(".")]]
)

#heading(level: 1)[#strong[#text(" — Links to computational results and software used: —")]]

#emph[#text("Numerical results achieved:")]

#list(
[#text("Stored sums ")#link("https://github.com/km-git-acc/dbn_upper_bound/tree/master/output/storedsums")[#text("https://github.com/km-git-acc/dbn_upper_bound/tree/master/output/storedsums")]],
[#text("Winding numbers ")#link("https://github.com/km-git-acc/dbn_upper_bound/tree/master/output/windingnumbers")[#text("https://github.com/km-git-acc/dbn_upper_bound/tree/master/output/windingnumbers")]]
)

#list(
[#text("Lemmabound N_a…N_b ")#link("https://github.com/km-git-acc/dbn_upper_bound/tree/master/output/eulerbounds")[#text("https://github.com/km-git-acc/dbn_upper_bound/tree/master/output/eulerbounds")]]
)

#emph[#text("Software scripts used:")]

#list(
[#text("ARB-software ")#link("https://github.com/km-git-acc/dbn_upper_bound/tree/master/dbn_upper_bound/arb")[#text("https://github.com/km-git-acc/dbn_upper_bound/tree/master/dbn_upper_bound/arb")]],
[#text("pari/gp-software ")#link("https://github.com/km-git-acc/dbn_upper_bound/tree/master/dbn_upper_bound/pari")[#text("https://github.com/km-git-acc/dbn_upper_bound/tree/master/dbn_upper_bound/pari")]]
)

#heading(level: 1)[#text("Comments (113)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a71065fa39da240dc08c835893d8e1afdccc908b75e83ce7f813f3a0b1efc11a-d7d86f3db4db1e0d4039cbed3f02ef0d5483e1767686ab66ff3e02b6ddff9535.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of scienaimer")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-504637")[#strong[#text("scienaimer")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2018")])]

#text("Thanks😄, I admire you so much")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505983")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2018")])]

#text("Please don’t forget to take that ceremonial bow when you think his or speak his name… :-)")

#text("P.S. And trust me, he is a bit overrated too.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-506248")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2018")])]

#text("On the other hand, Prof. T. Tao has established a first-rate and evolving website on mathematics (")#link("https://terrytao.wordpress.com")[#text("https://terrytao.wordpress.com")]#text("), and it may be the best on the worldwide internet. Thank you very much! :-)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-504654")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2018")])]

#text("Is it possible to reduce the computational complexity by making the width of the barrier variable (not necessarily 1) and choosing a “good” value for it ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-504655")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2018")])]

#text("The barrier can be reduced in area by a factor of about two (at the cost of replacing its rectangular shape with a region bounded by two straight lines and a parabola), but it can’t be made arbitrarily small (at least with the current arguments). The reason why the barrier needs to be somewhat thick is because one needs to ensure that the complex zeroes (paired with their complex conjugates) on the right of the barrier cannot exert an upward force on any complex zero above the real axis to the left of the barrier; this is to prevent the bad scenario of a complex zero swooping in under the barrier at high velocity, and then being pulled up by zeroes still to the right of the barrier to end up having an imaginary part above ")#mi("y_0")#text(" at the test time ")#mi("t_0")#text(". If the barrier is too thin, then a zero just to the left of it could be pulled up strongly by a zero just to the right and a little bit higher, to an extent that cannot be counteracted by the complex conjugate of the zero to the right. (Though, as I write this, I realise that also the complex conjugate of the zero on the left would also be helpful in pulling the zero down. This may possibly help reduce the size of the barrier a little bit further, although it still can’t be made arbitrarily thin. I’ll try to make a back-of-the-envelope calculation on this shortly. EDIT: ah, I remember the problem now… if one has _many_ zeroes on the right of the barrier trying to pull the zero on the left up, they can overwhelm the effect of the complex conjugate of that zero, so one can’t exploit that conjugate unless one also has some quantitative control on how many zeroes there are just to the right of the barrier.)")

#text("My understanding is that verification that the barrier is zero-free has not been the major bottleneck in computations, with the numerical verification of a large rectangular zero-free region to the right of the barrier at time ")#mi("t_0")#text(" being the more difficult challenge, but perhaps the situation is different at very large heights (I see for instance that there is one choice of parameters in which the rectangular region is in fact completely absent).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-504658")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2018")])]

#text("If we use the Euler 2 analytic bound, and try to maintain the trend of the dbn constant decreasing by 0.01 or more for every order of magnitude change in X, without having to validate any rightward rectangular region, we find such good t0,y0 combinations only till X=10^19.")

#text("For example, for X=10^20, we don’t find a combination which could give dbn <= 0.11 by itself (although 0.1125 is manageable), and validating an extra region becomes necessary. We could instead assume a new such trend starts at X=10^20 and ends at X=10^22 with dbn going from 0.12 to 0.10.")

#text("If we validate a rightward rectangular region at these heights, it does take significant time. Here, the stored sums generation also takes substantial time (for eg. the 10^19 stored sums took about 30 processor-days (although quite parallelized)). We can choose a larger X to eliminate or reduce the rectangular region but at the cost of more time for the stored sums.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/644708a37ad48d1e5cbd2d36dedfa9c0ff955e0805dc868d5e897da67e7b7dc7-94d2ea3a8a07e14c36ae8110096e78c755a5494a0ae9d746642939e3495301d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of curious")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-504657")[#strong[#text("curious")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2018")])]

#text("With unbounded computation capability and infinite time is there a lower bound on ")#mi("\\Lambda")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-504663")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2018")])]

#text("Well, it’s now a theorem that ")#mi("\\Lambda \\geq 0")#text(", and the Riemann hypothesis is now known to be equivalent to ")#mi("\\Lambda=0")#text(", so it is unlikely that this lower bound will ever be improved :)")

#text("Conversely, in the unlikely event that we were able to numerically locate a violation of the Riemann hypothesis, that is to say a zero of ")#mi("H_0")#text(" off the real line, one could hopefully use some of the numerical methods to calculate ")#mi("H_t")#text(" developed here to also locate failure of the Riemann hypothesis at or near this location for some positive values of ")#mi("t")#text(" as well. This would then give a positive lower bound to ")#mi("\\Lambda")#text(". But I doubt this scenario will ever come to pass. (I doubt that RH will ever be disproven, but if it is, my guess is that the disproof will come more from analytic considerations than from numerically locating a counterexample, which might be of an incredibly large size (e.g., comparable to Skewes number).)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-506162")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2018")])]

#text("Your arguments/doubts against the truth of the Riemann Hypothesis are fictional, and therefore, they should be ignored…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-504659")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2018")])]

#text("In step 4 (of “verifying the range”), the meaning of “the line ")#mi("y_0,  t_0")#text("” is not clear.")

#emph[#text("[Text clarified – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-504667")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2018")])]

#text("It seems that ")#mi("y = t_0")#text(" should be ")#mi("t = t_0")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f08df640879b8442f3c50563938a718334512c5cb12c7bc7b44bae9cd61e15f-7cfb0de7874561af90a84d72bcab617ca35196555256f618d5e1117c9b3c33aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-504661")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2018")])]

#text("It is possible to prove that ")#mi("\\Lambda \\geq 0")#text(" using the zero-free regions method? For example, prove that ")#mi("\\Lambda \\geq \\varepsilon")#text(" for every positive ")#mi("\\varepsilon")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b71017f3ba0f543c5044556f27512e72972ffa9e69a8bf9184eadd8f7695b8bf-bea05fabd012afb0eff4e8714fccbbf0a0ed5d4690e1d374727fd01c1f9ac003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-504664")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2018")])]

#text("What you are asking for is a proof that the Riemann hypothesis fails.")#linebreak()#text(" RH implies lambda <= 0.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9b797259b6696fba2cd75ae71f95db4be37994d34c4bada8ba0c2b733411ca2-4d5eeb7b74358cf0282ecdaddfbc851bc81680e99326fdf29eeb59b4e871d50d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-504665")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2018")])]

#text("Sorry… i wanted to say ")#mi("\\Lambda \\leq 0")#text(". I wasn’t pay atention. Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-504666")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2018")])]

#text("As I think I mentioned in the previous thread, establishing an upper bound ")#mi("\\Lambda \\leq \\varepsilon")#text(" is roughly comparable in difficulty to verifying the Riemann hypothesis up to height ")#mi("\\exp(C/\\varepsilon)")#text(" for some absolute constant ")#mi("C")#text(". The computational difficulty of this task is in turn of the order of ")#mi("\\exp(C^{\\prime}/\\varepsilon)")#text(" for some other absolute constant ")#mi("C^{\\prime}")#text(". So the method can in principle obtain any upper bound of the form ")#mi("\\Lambda \\leq \\varepsilon")#text(" (assuming of course that RH is true), but the time complexity grows exponentially with the reciprocal of the desired upper bound ")#mi("\\varepsilon")#text(". My feeling is that absent any major breakthrough on RH, these exponential type bounds are here to stay, although one may be able to improve the values of ")#mi("C")#text(" and ")#mi("C^{\\prime}")#text(" somewhat.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-506163")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2018")])]

#text("“… major breakthrough on RH…” Hah! RH is true!… And your acceptance of this fact will be your personal breakthrough!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/644708a37ad48d1e5cbd2d36dedfa9c0ff955e0805dc868d5e897da67e7b7dc7-94d2ea3a8a07e14c36ae8110096e78c755a5494a0ae9d746642939e3495301d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of curious")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-504669")[#strong[#text("curious")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2018")])]

#text("Does the ")#mi("\\exp(C/\\epsilon)")#text(" behavior come from proposition 10.1? Also you say it is unlikely to beat ")#mi("\\log T\\Lambda=O(1)")#text(" and perhaps it would be nice to state the best behavior if it is beaten to ")#mi("\\log T\\Lambda=o(1)")#text(" and what is the unlikely event that would trigger?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-504671")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2018")])]

#text("See my previous comment on this at ")#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501625")[#text("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501625")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe0ef876daa22fb724efbaa7c962b52d6334dec420920635dd68181527d2d492-9cd33212bfc809c0c4dd901da1651b7446a896e94ae70c7ae696149a8b6f2587.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505111")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("Stay tuned:")#linebreak()#text(" ")#link("https://www.newscientist.com/article/2180406-famed-mathematician-claims-proof-of-160-year-old-riemann-hypothesis/")[#text("https://www.newscientist.com/article/2180406-famed-mathematician-claims-proof-of-160-year-old-riemann-hypothesis/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505117")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2018")])]

#text("Such claim from him seems really promising …")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505212")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2018")])]

#text("Dear Prof. Tao,")

#text("Are you aware of any details on the supposed proof of the RH by Atiyah?")

#text("Best,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sylvainjulien")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505224")[#strong[#text("sylvainjulien")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2018")])]

#text("There’s a question on Mathoverflow with a link towards a preprint by Sir Michael : ")#link("https://mathoverflow.net/questions/311254/is-there-an-error-in-the-pre-print-published-by-atiyah-with-his-proof-of-the-rie")[#text("https://mathoverflow.net/questions/311254/is-there-an-error-in-the-pre-print-published-by-atiyah-with-his-proof-of-the-rie")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eae988277ab5af26a6868faf07ff52f678d6d4e55bf19dbae4de9ccc10f05921-36880b05d4b5563fa1a528f8c5decdf570948629ea58099fd0532ef22820807e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sha_bi_a_ti_ya")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505239")[#strong[#text("sha_bi_a_ti_ya")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2018")])]

#text("hi, the link does not work any more.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505237")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2018")])]

#text("The papers are out and basically it seems that there is a consensus among the experts that the proof is incorrect (e.g. ")#link("https://motls.blogspot.com/2018/09/nice-try-but-i-am-now-99-confident-that.html")[#text("https://motls.blogspot.com/2018/09/nice-try-but-i-am-now-99-confident-that.html")]#text(").")

#text("I would really like to read a comment on this from prof. Tao.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8db163ee2080530d530ad01e00b4f831e42348d8e0c11cecb9c0298815b6a4f0-c5d8d8d6496d0e650b45f0d3097ff78f97b9aeaca6fce1792c38496673e0c2d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of think")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505240")[#strong[#text("think")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2018")])]

#text("Motls is no expert.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505244")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2018")])]

#text("Dear prof. Tao,")

#text("I suggest to delete this discussion on the claimed proof as irrelevant to this post.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505247")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2018")])]

#text("How is a possible proof of RH not relevant to a bound on the roots of zeta function? Once there is a proof of RH being true, \\Lambda = 0 and there is no need for the numerics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505776")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2018")])]

#text("Interestingly, for some comments above, the “authomatic dislike” is missing.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505250")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2018")])]

#text("Given the situation, I believe it would not be particularly constructive or appropriate for me to comment directly on this recent announcement of Atiyah. However, regarding the more general question of evaluating proposed attacks on RH (or GRH), I can refer readers to the ")#link("https://vimeo.com/album/5303404/video/282760852")[#text("recent talk of Peter Sarnak")]#text(" (slides available ")#link("https://aimath.org/wp-content/uploads/bristol-2018-slides/Sarnak-talk.pdf")[#text("here")]#text(") entitled “Commentary and comparisons of some approaches to GRH”. A sample quote: “99% of the ‘proofs’ of RH that are submitted to the Annals … can be rejected on the basis that they only use the functional equation [amongst the known properties of ")#mi("\\zeta")#text(", excluding basic properties such as analytic continuation and growth bounds]”. The reason for this is (as has been known since the work ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1574345")[#text("of Davenport")]#text(" ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1574931")[#text("and Heilbronn")]#text(") that there are many examples of zeta-like functions (e.g., linear combinations of L-functions) which enjoy a functional equation and similar analyticity and growth properties to zeta, but which have zeroes off of the critical line. Thus, any proof of RH must somehow use a property of zeta which has no usable analogue for the Davenport-Heilbronn examples (or the many subsequent counterexamples produced after their work, see e.g., this ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3425881")[#text("recent paper of Vaughan")]#text(" for a more up-to-date discussion). (For instance, the proof might use in an essential way the Euler product formula for zeta, as the Davenport-Heilbronn examples do not enjoy such a product formula.)")

#text("Another “barrier” to proofs of RH that was mentioned in Sarnak’s talk is also worth stating explicitly here. Many analysis-based attacks on RH would, if they were successful, not only establish that all the non-trivial zeroes lie on the critical line, but would also force them to be simple. This is because analytic methods tend to be robust with respect to perturbations, and one can infinitesimally perturb a meromorphic function with a repeated zero on the critical line to have zeroes off the critical line (cf. the “dynamics of zeroes” discussions in this Polymath15 project). However, while the zeroes of zeta are believed to be simple, there are many examples of L-functions with a repeated zero at 1/2 (particularly if one believes in BSD and related conjectures). So any proof of RH must either fail to generalise to L-functions, or be non-robust with respect to infinitesimal perturbations of the zeta function. (For instance, in Deligne’s proof of the RH for function fields, the main way this barrier is evaded is through the use of the tensor power trick, which is not robust with respect to infinitesimal perturbations. This proof also evades the first barrier by relying in essential fashion on the Grothendieck-Lefschetz trace formula, which is not available in usable form for Davenport-Heilbronn type examples, even over function fields.)")

#text("(I also spoke at ")#link("https://aimath.org/rh2018/")[#text("this meeting")]#text(", on the topic of the de Bruijn-Newman constant and (in part) on Polymath15; my talk can be found ")#link("https://vimeo.com/album/5303404/video/280813299")[#text("here")]#text(", and the remaining lectures may be found ")#link("https://vimeo.com/album/5303404")[#text("here")]#text(", with slides ")#link("https://aimath.org/rh2018/lecture-slides/")[#text("here")]#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505252")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2018")])]

#text("On the other hand, Hamburger’s theorem (1921) shows that ")#mi("\\zeta")#text(" is determined (up to a multiplicative constant) by its functional equation, having Dirichlet series representation, finitely many singularities and growth conditions. So in addition to the functional equation and Dirichlet series representation not much more information is needed for a proof of RH.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505256")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2018")])]

#text("This is true insofar as one restricts attention just to RH rather than GRH. But at the GRH level one needs the functional equation not just for the Dirichlet series, but for all twists of the Dirichlet series, in order to recover an L-function (or at least to evade the Davenport-Heilbronn type counterexamples). So any purported proof of RH that relies only on the functional equation and the Dirichlet series representation must either fundamentally break down when one attempts to extend it to GRH (i.e., it must use some special property of zeta not shared by other L-functions, such as the specific numeric parameters that appear in the gamma factors of the zeta functional equation as opposed to all other functional equations, which by the way is the case for Hamburger’s theorem), or must naturally incorporate the functional equation for the twists as well. (One could possibly imagine the latter occurring if the argument had a highly “adelic” flavour, for instance.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aula")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505293")[#strong[#text("Aula")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2018")])]

#text("Since Deligne managed to prove one special case of GRH, it’s a pretty obvious idea to try to generalize his proof to other cases. However it seems that no one has been able to do so, which suggests that function fields really are a very special case of GRH. Why is that?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505295")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2018")])]

#text("Well, the function field case is more like half of all cases (if one considers the function field case and number field case to be of equal “size”); Deligne proved GRH not only for the analogue of the zeta function and Dirichlet L-functions (which are actually quite easy), or for curves (which was first done by Weil), but in fact proved GRH for all varieties and more generally for “pure” l-adic sheaves. (See my previous blog post on this at ")#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/")[#text("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/")]#text(" .)")

#text("Probably the most obvious thing that the function field case has but the number field case seems to lack is the Frobenius map, which is linked to L-functions in the function field case via the Grothendieck-Lefschetz trace formula. But people have certainly searched for ways to extend these methods to number field settings, most prominently Connes and his co-authors (see e.g., ")#link("https://vimeo.com/album/5303404/video/282879987")[#text("his recent talk")]#text(" (slides available ")#link("https://heilbronn.ac.uk/wp-content/uploads/2018/07/Connes-Talk.pdf")[#text("here")]#text("), at the same conference as the previously linked talks). Connes identifies the apparent lack of a (Hirzebruch-)Riemann-Roch theorem for number fields as the key obstacle to making this strategy work.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-506368")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2018")])]

#text("Since RH is generally regarded as the most important open conjecture in mathematics (with many claimed proofs), it seems that any accepted proof of it should also be formalized.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-506587")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2018")])]

#text("Some recently claimed proofs of RH (with some remarks)")#linebreak()#text(" ")#link("http://www.maths.ex.ac.uk/~mwatkins/zeta/RHproofs.htm")[#text("http://www.maths.ex.ac.uk/~mwatkins/zeta/RHproofs.htm")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/516179d324fb758d0a49eb09fb6f029b9f6f6316757cb10ab15c10fa9bc87804-a4030ffd2319cb3a44cdbc03abe1d790228107f4f6f93d372485167327c041ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kirill kapitonets")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-644693")[#strong[#text("kirill kapitonets")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2022")])]

#text("Dear prof. Tao,")

#text("Let me make a few comments about the aspects of Peter Sarnak’s speech that you have cited.")

#text("The Davenport and Heilbronn functions differ significantly from the Riemann Zeta functions, although one and the other correspond to the functional equation. This difference lies in the concept of linear dependence, i.e. the ability to express the values of a function on one line parallel to the critical line and some other line also parallel to the critical line, i.e. with different values of the real part of the complex variable. For the Davenport and Heilbronn functions, such a linear dependence is true for any two values of a real variable, which does not contradict the functional equation, while for the Riemann Zeta function, such a linear dependence is established by the functional equation only for lines symmetric with respect to the critical line, therefore, on all other lines parallel to the critical line, the values of the Riemann Zeta function are linearly independent. This linear independence leads to a special property of the Riemann Zeta function – the values of the Riemann Zeta function on rational lines parallel to the critical line, i.e. taken at different rational values of the real part of a complex variable, form the basis of a Hilbert space, and the Davenport and Heilbronn function does not have this property. Therefore, in this case, it is not the functional equation that is important, but the linear independence, which is described above.")

#text("Now as for the second remark about simple zeros. Some considerations suggest that it is necessary to move from a function of a complex variable to a function of a real variable. To do this, it is enough to take the real part of the Riemann Zeta function, domnazhaya it by a known multiplier, which is used to obtain the function of a real variable on the critical line to calculate the zeros of the Riemann zeta function. This function is sometimes called the Hardy function. Then using the properties of the Riemann Zeta function to have linearly independent values on lines parallel to the critical line, we obtain a generalized Hardy function that also has linearly independent values on lines parallel to the critical line. Consequently, the generalized Hardy function on rational lines parallel to the critical line, i.e. taken at different rational values of the real part of a complex variable, form the basis of a Hilbert space over the field of real numbers. Further, some considerations allow us to assert that the functions that make up the basis of a Hilbert space over a field of real numbers have all simple real zeros (they inherit this property from real orthogonal polynomials, which are elements of the best approximation in a Hilbert space). Thus, the property of linear independence of the values of the Riemann Zeta function on lines parallel to the critical line and not satisfying the functional equation is responsible for the property of zeros of the Riemann Zeta function – they are all simple and of course all lie on the critical line, because The Hardy function belongs to the Hilbert space basis.")

#text("Let me ask you what you think about this?")

#text("Maybe it’s a double, because I don’t see the first message.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8db163ee2080530d530ad01e00b4f831e42348d8e0c11cecb9c0298815b6a4f0-c5d8d8d6496d0e650b45f0d3097ff78f97b9aeaca6fce1792c38496673e0c2d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of think")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505271")[#strong[#text("think")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2018")])]

#text("Is it possible RH is true but not GRH and may be is there possibility in that case your reasoning might fall short?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505277")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2018")])]

#text("This is theoretically possible, but (a) it goes against the experience of the last century or so, in which virtually every property that has been established for the zeta function eventually ends up having an analogue for other L-functions (possibly with some additional subtleties), and (b) as I said above, it would mean that any proof of RH would at some point have to rely in some crucial fashion on a property of the zeta function that has no usable analogue for L-functions (i.e., it must use an exception to (a)), since otherwise it would extend to a proof of GRH, which we are assuming for this discussion to be false. Again, this is theoretically possible – certainly I could imagine for instance that there would be an argument that can handle degree 1 L-functions such as zeta or Dirichlet L-functions, but not higher degree L-functions – but many attacks on RH would not be able to make such fine distinctions between zeta and other L-functions, e.g., arguments that are primarily based on complex analysis methods. (The only exception I could see is if the argument really used the specific value of the numerical exponents and other parameters of the zeta functional equation in some key fashion, so that the argument would break down completely if these parameters were replaced by those for some other L-function. Hamburger’s theorem, mentioned above, is one case in which this occurs.)")

#text("EDIT: my previous discussion on the ")#link("https://plus.google.com/+TerenceTao27/posts/78aoEHoPhpS")[#text("distinction between local errors in a proof and global errors in a proof")]#text(" is relevant here. A local error is something like “The derivation of equation (23) on page 17 is not valid” or “The proposed definition of a pseudosimplicial hypercomplex in Definition 3.1 is ambiguous”. A global error is something like “this proof, if it worked, would also show that all meromorphic functions obeying the functional equation must verify the Riemann hypothesis, which is known not to be the case”. A good proof should not only be written in a way to avoid local errors, but also should be consciously striving to avoid global ones as well, otherwise it immediately becomes suspicious (even if the specific local error that the global error indicates must exist has not yet been located).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8db163ee2080530d530ad01e00b4f831e42348d8e0c11cecb9c0298815b6a4f0-c5d8d8d6496d0e650b45f0d3097ff78f97b9aeaca6fce1792c38496673e0c2d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of think")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505290")[#strong[#text("think")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2018")])]

#text("Not sure if there is a relation but from ")#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/")[#text("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/")]#text(" even RH seems to be barely so. Any non-negativity statement like this holds for GRH?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505291")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2018")])]

#text("It seems that the “barely so” result for the “de-Bruijn” deformation ")#mi("H_t")#text(" for ")#mi("H_0")#text(" is “too rigid” for the deformation parameter ")#mi("t")#text(", so perhaps the “epsilon of room” principle indicates that it may be useful to make the deformation more flexible by using several deformation parameters (")#mi("t, t_1")#text(", say) instead of the single parameter t.")#linebreak()#text(" This may be used to get some desirable properties of the more general deformation. Such a desirable property is to rigorously bound the zeros velocities of ")#mi("H_{t, t_1}")#text(" by using instead of the classical heat equation (which has unbounded propagation velocities) by a similar version of “relativistic heat equation” (with a small parameter of second order time derivative corresponding to a “wave equation” which should give the desired upper bound on the propagation velocity).See e.g.")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Relativistic_heat_conduction")[#text("https://en.wikipedia.org/wiki/Relativistic_heat_conduction")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505294")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2018")])]

#text("I am actually planning to ask a graduate student to look into this question.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505324")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2018")])]

#text("Is it possible to refine de Bruijn deformation ")#mi("H_t")#text(" of ")#mi("H_0")#text(" to a more general (two parametric) deformation ")#mi("H_{t, t^{\\prime}}")#text(" such that")

#text("(i) ")#mi("H_{t, t^{\\prime}}")#text(" converges locally uniformly to ")#mi("H_0")#text(" as ")#mi("(t, t^{\\prime})")#text(" tend to ")#mi("(0, 0)")#text(".")

#text("(ii) For each ")#mi("t, t^{\\prime} > 0")#text(" there is ")#mi("X(t, t^{\\prime})")#text(" such that ")#mi("H_{t, t^{\\prime}}(x+i y) \\neq 0")#text(" whenever ")#mi("x > X(t, t^{\\prime})")#text(" and ")#mi("y > 0")#text(".")

#text("(iii) The threshold ")#mi("X{t, t^{\\prime}}")#text(" is effectively computable.")

#text("Such a generalized deformation may be derived from a relativistic version of the heat equation. It seems that if there is a sequence of deformation parameters ")#mi("(t_n, t^{\\prime}_n)")#text(" converging to ")#mi("(0, 0)")#text(" with a corresponding sequence of thresholds ")#mi("X(t_n, t^{\\prime}_n)")#text(" uniformly bounded by some absolute constant M, then property (i) would imply that ")#mi("H_0(x + i y) \\neq 0")#text(" whenever ")#mi("x > M")#text(" and ")#mi("y > 0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505510")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("A similar “deformation approach” to RH is to represent the kernel ")#mi("\\Phi")#text(" (which gives ")#mi("H_0")#text(" as its Fourier transform) as a limit of a suitable sequence of kernels whose Fourier transforms have only real zeros and are converging locally uniformly to ")#mi("H_0")#text(" – implying that H_0 has also only real zeros. This “kernel deformation approach” appears in Shi’s recent arxiv paper")

#link("https://arxiv.org/pdf/1706.08868.pdf")[#text("Click to access 1706.08868.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505571")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2018")])]

#text("A more detailed description of the “kernel deformation approach” to RH is as follows")

#text("Since ")#mi("2 H_0(z) = \\int_{\\mathbb{R}} \\Phi(u) e^{i z u} d u")#text(" , where ")#mi("H_0")#text(" is entire with its double-exponentially decaying “generating kernel” ")#mi("\\Phi")#text(", the basic idea is to construct a sequence of “approximating kernels” ")#mi("\\Phi_n")#text(" to ")#mi("\\Phi")#text(" whose Fourier transforms")#linebreak()#text(" ")#mi("F_n(z) := \\int_{\\mathbb{R}} \\Phi_n(u) e^{i z u} d u")#text(" should be")

#text("(i) well-defined and analytic in the horizontal strip ")#tao-math("\\left|y\\right| < 1", block: false)#text(".")#linebreak()#text(" (ii) converging locally uniformly to ")#mi("2 H_0")#text(" in this strip.")#linebreak()#text(" (iii) have only real zeros in this strip.")

#text("Clearly, the above properties imply that ")#mi("H_0")#text(" has only real zeros!")

#text("Remarks:")

#text("1. A sufficient condition for property (i) is")

#tao-math("\\int_{\\mathbb{R}} |\\Phi_n(u)| e^{\\left|u\\right|} d u < \\infty", block: false)#text(" for each ")#mi("n")

#text("2. A sufficient condition for property (ii) is")

#tao-math("\\lim_{n \\to \\infty} \\int_{\\mathbb{R}} |\\Phi_n(u) -\\Phi(u)| e^{\\left|u\\right|} d  u=0", block: false)

#text("which follows from the simple estimate (in the strip ")#tao-math("\\left|y\\right| < 1", block: false)#text(")")

#tao-math("\\left|F_n(z) - 2 H_0(z)\\right| \\leq \\int_{\\mathbb{R}} \\left|\\Phi_n(u)-\\Phi(u)\\right| \\left|e^{i z u}\\right| d u", block: false)

#tao-math("\\leq \\int_{\\mathbb{R}} |\\Phi_n(u) - \\Phi(u)| e^{\\left|u\\right|} d u", block: false)

#text("3. It seems that satisfying property (iii) is the most difficult part in the construction (or \"design\") of such kernels ")#mi("\\Phi_n")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eae988277ab5af26a6868faf07ff52f678d6d4e55bf19dbae4de9ccc10f05921-36880b05d4b5563fa1a528f8c5decdf570948629ea58099fd0532ef22820807e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sha_bi_a_ti_ya")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505576")[#strong[#text("sha_bi_a_ti_ya")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2018")])]

#text("bro, are you mr. shi?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505512")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("I am not sure I fully understand your set of hypotheses, but it appears that ")#mi("H_{t,t^{\\prime}} := H_t")#text(" already obeys the properties you state (but with the threshold not bounded uniformly in ")#mi("t,t^{\\prime}")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505536")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("Yes, it is true for the one-parameter deformation ")#mi("H_t")#text(", but perhaps the extra flexibility of the two-parametric deformation ")#mi("H_{t, t^{\\prime}}")#text(" may be sufficient to have a suitable sequence of such deformations converging locally uniformly to ")#mi("H_0")#text(" while keeping their corresponding thresholds uniformly bounded?")#linebreak()#text(" Moreover, if the deformation ")#mi("H_{t, t^{\\prime}}")#text(" is generated from a relativistic version of the heat equation (with bounded propagation velocity), is it possible that their zeros velocities are also uniformly bounded?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81c7ee47219767de6af71eb6b5313e9894d7c3914be6d57431ae7e1b00c157a1-a1e079dc8e5844fbe1b13fa79adf07f02d1892bfbe1b6c1e95a39cc933de0cdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vznvzn")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505351")[#strong[#text("vznvzn")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2018")])]

#text("led from an offhand remark/ tip by a commenter on RJLs recent blog on atiyah attack, now delighted/ excited/ exhilarated to see this hard core empirical/ computational/ numerical work into RH and hope that the word gets out, there are apparently multiple trolls on my blog who reject my own similar inquiries into collatz on spurious grounds. does anyone know of a great survey ref on RH numerical work or more widely in number theories? have found a few of my own over the years but have to go hunt down some of these new refs. ")#link("https://vzn1.wordpress.com/2015/12/29/select-refs-and-big-tribute-to-empirical-cs-math/")[#text("https://vzn1.wordpress.com/2015/12/29/select-refs-and-big-tribute-to-empirical-cs-math/")]

#text("re Atiyah attack, spent a lot of time researching that from many angles, this is a pov written from an outsider looking in on all the insiders. ")#link("https://vzn1.wordpress.com/2018/09/26/atiyah-riemann-attack-post-mortem-autopsy-primes-torch-carried-on/")[#text("https://vzn1.wordpress.com/2018/09/26/atiyah-riemann-attack-post-mortem-autopsy-primes-torch-carried-on/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505363")[#strong[#text("Terence Tao vs Riemann Hypothesis, polymath 15 computational/ algorithmic number crunching attack, counterpoint to recent Atiyah episode - Nevin Manimala's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2018")]

#text("[…] by /u/vznvzn [link] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505364")[#strong[#text("Atiyah Riemann attack/ post mortem/ autopsy, Primes torch carried on | Turing Machine")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2018")]

#text("[…] thx everyone! from a comment on RJLs blog about \"number crunching Riemann\", Terence Tao/ Polymath15 is working on a very cool numerical attack. more vindication for numerical approaches. reddit likes […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505467")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2018")])]

#text("More information on Todd function (appearing in Atiyah claimed proof for RH) and on the closely related Hirzebruch functional equation can be found in Bunkova’s recent arxiv paper")

#link("https://arxiv.org/pdf/1803.01398.pdf")[#text("Click to access 1803.01398.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505744")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2018")])]

#text("In the writeup, it seems that in the RHS of (33) the argument of the logarithmic derivative should be ")#mi("z")#text(" (instead of ")#mi("z_j")#text(").")#linebreak()#text(" In addition, the proof of claim (i) (in the following rows) can be simplified by observing that the Hadamard product for ")#mi("H_t")#text(" is locally uniformly convergent – implying that its logarithmic derivative is also locally uniformly convergent – so the logarithmic derivative can be computed termwise and the claim follows (without relying on growth estimates.)")

#emph[#text("[Thanks, the LaTeX source has now been updated (and the PDF will be updated in due course). -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505763")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2018")])]

#text("Since ")#mi("H_0")#text(" can be represented as the Fourier transform of a (fast decaying) strictly positive definite function ")#mi("\\Phi")#text(", it is therefore a positive definite function on ")#mi("\\mathbb {R}")#text(" (such positive definite functions are characterised by Bochner’s theorem as Fourier transforms of positive functions.)")#linebreak()#text(" Is it possible that ")#mi("H_0")#text(" represents the correlation function of a stationary continuous-time random process on ")#mi("\\mathbb{R}")#text(" with ")#mi("\\Phi")#text(" as its corresponding power spectral density? (which may explain the empirical connection of the distribution of ")#mi("H_0")#text(" zeros to the distribution of eigenvalues of large random Hermitian matrices.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505900")[#strong[#text("Watching Over the Zeroes | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2018")]

#text("[…] results toward the RH. A PolyMath project on bounding from above has achieved , and a bound of is known to follow if and when the RH is verified for up to . There was previously a lower bound , a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505980")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2018")])]

#text("Since ")#mi("\\Phi_t(u) := e^{t u^2} \\Phi (u)")#text(" is the integral kernel representing ")#mi("H_t(z)")#text(", it seems desirable to understand in terms of the kernel ")#mi("\\Phi_t")#text(" why it makes some zeros of ")#mi("H_t")#text(" non-real for ")#mi("t  0")#text(". (i.e. which property of the kernel is changing at the threshold ")#mi("t = 0")#text(" ?)")#linebreak()#text(" It is known from a classical paper (1918) of Polya that if the kernel is even, INCREASING function for ")#mi("u > 0")#text(" and compactly supported, its Fourier transform (which is a finite cosine transform) is an entire function with only real zeros. If the kernel function is DECREASING (as in the case of ")#mi("\\Phi")#text("), its Fourier transform may have non-real zeros (there are some results connecting its convexity properties to the zeros distribution of its Fourier transform). Since the derivative of ")#mi("\\Phi")#text(" (as any even function) is zero at the origin, is it possible that its second derivative at the origin is also zero – which would make ")#mi("\\Phi_t")#text(" CONVEX at the origin ")#mi("u = 0")#text(" for ")#mi("t > 0")#text(", but CONCAVE for ")#mi("t < 0")#text(" ?")#linebreak()#text(" (thereby explaining its convexity \"transition\" at the origin ")#mi("u=0")#text(" for ")#mi("t = 0")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-505981")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2018")])]

#text("Correction: in the fourth line it should be “for ")#mi("t < 0")#text("\" (i.e. \"<\" is missing)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-508542")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2018")])]

#text("What about Atiyah’s proof of Riemann Hypothesis? There are 100 percent of chance that his demonstration are wrong?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509211")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2018")])]

#text("From reading between the lines on the internet, it sadly looks like his proof is so nonsensical that it cannot be described without implying that he suffers from some sort of neurodegenerative disorder. If you want to avoid the appearance of making a remote amateur diagnosis of his medical condition then you have to talk around it by referring obliquely to “the situation” and by listing known barriers to proofs in general instead of explaining his proof in particular.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-508583")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2018")])]

#text("Is there any update on polymath15? In particular, I have seen that the writeup-directory has not been changed for 3 weeks. Is there something that other people, who potentially have not been involved, could contribute on the writing part? For example, some final proof-reading etc? Would be nice to get some updates from the involved researchers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-508595")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2018")])]

#text("I’m not as involved as the authors of the numerics report, but I’ve been casually involved in the past and I still read the mailing list occasionally. There are three main reasons that I’ve decreased my participation in the project. One is that I wasn’t able to follow the details of “a pre-calculated stored sum matrix that is Taylor expanded” and I don’t know if it’s rigorously proved or if it’s heuristics or what. I assume this is my fault for not understanding. Secondly the project shifted towards looking at negative values of t. I’m not going to tell other people what to work on, but it looked out of scope for this project. Thirdly the active research on this project currently appears to be numerically extending the number of zeros checked on the critical line which I think is way outside this scope of this project. If you can prove a result that has a dependency on how many zeros have been checked then I feel like that’s enough. You don’t have to keep trying to check more zeros, except as a spinoff project. I’m not trying to be negative or discouraging, I think this is a great project and the people working on it are great, I’m just giving an update from my own perspective and explaining why my own participation has declined.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-508638")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2018")])]

#text("The main thing missing from the writeup currently is basically a detailed explanation of the numerics used (in particular the stored sum thing you allude to). Once I have a block of time in which I can verify some of the code I should be able to fill that in, and then one just needs some proofreading and polishing before one can submit the writeup which would I think close off the original goal of Polymath15, though the secondary goals of exploring negative t and seeing if one can expand (or reconfirm) the range of numerical verification of RH are also interesting. The (extraordinarily busy) quarter has just ended for me, so after this AIM workshop that I am at this week concludes, I should be able to finally have that block of time…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-508994")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2018")])]

#text("Here is a quick update from the numerics team. Since September we have progressed work along three lines:")

#text("1) In our quest to further reduce the DBN-constant below ")#mi("0.22")#text(", i.e. the domain where results will be conditional on RH-verification up to a certain height, we found a new approach. The table under ‘results achieved’ in the OP of the 10th thread, has an interesting row (the 3rd from below) where for a carefully chosen combination of ")#mi("y_0, t_0")#text(", the Triangle bound ")#mi("N_b")#text(" is already positive at the location of the Barrier. This implies ")#mi("N_a=N_b")#text(", hence no further computations are required after the Barrier has been ‘cleared’ from any zeros having passed through it. This brought us to the idea to find those ")#mi("x, y_0, t_0")#text(" combinations for which the Triangle bound just becomes (and stays) positive and then to place the Barrier at an optimal location just beyond the derived x-value. This approach, combined with having access to a powerful grid-computing environment (Boinc), allowed us to numerically prove a conditional DBN of ")#mi("\\le 0.10")#text(". ")#link("https://drive.google.com/file/d/1F_3xeHzVwbcMjtkOU4ZZ95aQIqRpPD9N/view?usp=sharing")[#text("Here")]#text(" is the table with the results achieved.")

#text("2) Since these results are conditional on the RH and we had gained access to the powerful grid environment, we decided to explore the previous verification work done on the RH (Brent, Hugh, Riele/Lune, Wedeniwski, Gourdon, Platt, etc.). This to see whether existing algorithms might be replicated in the modern ARB-software (")#link("http://arblib.org")[#text("http://arblib.org")]#text(") and thereby maybe stretch the verified heights a bit further. The current status is that we have produced scripts to count the zeros on the critical line as well as to count those in the strip (via Turing’s method). Using grid computing, this probably brings verification up till the first ")#mi("10^{11}")#text(" zeros (")#mi("x = 3 \\times 10^{10}")#text(" within reach. This is the same height as Platt’s achieved and the one used for our unconditional DBN=0.22 proof. Beyond this level, the ‘factor 10’ increments quickly require much more advanced techniques than the classical Riemann-Siegel formula to evaluate ")#mi("Z(s)")#text(". This is where the various Odlyzko-Schönhage algorithms kick in and given their complexity these should clearly be left to the experts in this field. So, we probably will only complete a verification run up till ")#mi("10^{11}")#text(" and then ‘return’ from this brief out-of-the-project-scope subroutine.")

#text("3) Our third work stream focuses on the visualisation of the trajectories of the real and complex zeros in the (larger) negative t-domain. We have struggled for a while to get to a stable function to adequately explore this territory. The only tool currently available that remains valid at larger negative ")#mi("t")#text(", is this integral,")

#mi("H_t(z) =  \\frac{1}{8\\sqrt{\\pi}}\\int^{k}_{-k} \\xi\\left(\\frac{1+iz}{2} + \\sqrt{t}\\, v \\right) e^{-v^2} \\mathrm{d}v")

#text("and its first derivative:")

#mi("H_t^{^{\\prime}}(z) = \\dfrac{i}{8\\sqrt{\\pi\\,t}}\\int_{-k}^{k}\\,\\xi\\left(\\frac{1+i\\,z}{2}+\\sqrt{t} v\\right) e^{-v^2} v\\,\\mathrm{d}v")

#text("These integrals quickly become difficult to evaluate at more negative ")#mi("t")#text(". After some experiments we found that approaching the integral by a sum of rectangles with ")#mi("k")#text(" and the rectangle widths as key parameters. This approach made it more effectively controllable, however negative t smaller than -100 remain a stretch. The $latexH_t$-derivative is obtained almost for ‘free’ and this makes it suitable for root finding (e.g. through contour integration and the Newton-Raphson method). We are currently running the root-finder scripts and expect to post the visuals here in the next few days and bring it to a close.")

#text("On top of these three work streams we have also produced some visuals and graphs for the write-up. We acknowledge that a more detailed explanation is still required about the inner workings of the software used (especially to ensure the proof for the DBN=0.22 case is rigorous) and we should be able to compose that final piece soonest.")

#text("Re-reading the project’s ‘Terms of Reference’ stated at the start of this series of Polymath15 threads, it looks like we are almost exactly on plan (‘let’s run it for a year’) and all goals seem to have been realised :-)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509100")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2018")])]

#text("Below are some visuals about the trajectories of real and complex zeros of ")#mi("H_t(x+iy)")#text(" at negative ")#mi("t")#text(":")

#link("https://drive.google.com/file/d/1XQLGRzkt-s4uI7JiiJF_jC5007TlW2kY/view?usp=sharing")[#text("PPT")]

#link("https://drive.google.com/file/d/13a1wAsyf99DR272XmMKpRFC2ZoEWYJBq/view?usp=sharing")[#text("PDF")]

#text("Some regular patterns seem to emerge in the trajectories of both the real and the complex zeros. The regularity in the complex zeros seems to increase the further away they move from the real axis. It appears as if they are ‘lining themselves up’ on a curve that increases with ")#mi("x")#text(" and there doesn’t seem to exist a supremum on their imaginary parts for a certain ")#mi("-t")#text(".")

#text("Assuming the complex zeros indeed behave as they do, would the following reasoning be correct?")#linebreak()#text(" 1) We know there is a minimum falling speed for the imaginary parts of the zeros when travelling to the real line.")#linebreak()#text(" 2) So, we also know that the trajectories of these ‘furthest away’ zeros will theoretically have to travel the longest path possible, compared to all zeros closer to the real line, before they collide with their conjugates.")#linebreak()#text(" 3) Therefore, when we would calculate this slowest path possible for a specific ‘outer’ zero at a certain ")#mi("x, -t")#text(" and find it becomes real before ")#mi("t=0")#text(", then we would have verified the RH up to that ")#mi("x")#text(".")

#link("https://drive.google.com/file/d/1BR-WXDDMxb_QCgL7fWzc1bMvnKYJ1NJ7/view?usp=sharing")[#text("This picture ")]#text("aims to illustrate the thought.")

#text("In any case, it could be interesting to better understand where the regularity in these outer curves comes from. Assuming that all information about the behaviour of ")#mi("H_t(z)")#text(" originates from ")#mi("H_0(z)")#text(" (as the integrand suggests), somehow the complexity at ")#mi("t=0")#text(" has to ‘fade out’ when we move back in time (as it also does when moving forward in time). Maybe ‘notorious trouble maker’ ")#mi("\\zeta(s)")#text(" in the Riemann ")#mi("\\xi(s)")#text("-function loses some of its dominance when ")#mi("t")#text(" becomes more negative. This could simply be caused by some cancellation occurring in the integration process, but maybe also be due to the increased domination of the factor ")#mi("\\pi^{-\\frac{s}{2}} \\,\\Gamma\\left(\\frac{s}{2}\\right)")#text(". Have not yet explored this deeper, but welcome any thoughts on this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509105")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2018")])]

#text("Thanks for this, this is very interesting! Particularly how the zeroes seem to organise into families that peel off the real line at a regular rate and then arrange themselves into smooth curves as t becomes increasingly negative; it shows that the “gaseous state” becomes less chaotic as one moves to increasingly negative times, which goes against my intuition of there being an “Arrow of time” in which the system becomes more ordered as t increases (and so more disordered as t decreases). I don’t immediately have any plausible explanation for this phenomenon, but it suggests that there is an alternate formula or approximation for ")#mi("H_t")#text(" in this region that would make these patterns more visible asymptotically. Alternatively, there could be some sort of “travelling wave” solutions to the equation for the dynamics of zeroes, supported on unions of smooth curves, that for some reason behaves like an attractor for the dynamics as ")#mi("t \\to -\\infty")#text(", in the same way that the “solid state” of an arithmetic progression on the real line is an attractor as ")#mi("t \\to +\\infty")#text(".")

#text("Presumably these phenomena can be explained analytically in the end (so in particular they would arise from applying the heat flow to any function that looked vaguely like the Riemann xi function)… but there is a tiny chance that this is instead an arithmetic phenomenon special to the zeta function, which would be incredibly exciting and unexpected. (But this seems to be rather unlikely though.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509111")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2018")])]

#text("You mention in the slides that the A+B approximation starts breaking down once t goes below -8 or so. I wonder if things improve (in the regime where y is somewhat large, say larger than 10, or if t is highly negative) if one uses a “B” approximation only, in which one extends the B summation to infinity and shrinks the A summation down to nothing, thus")

#mi("\\frac{H_t(x+iy)}{B_t(x+iy)} \\approx \\sum_{n=1}^\\infty \\frac{b_n^t}{n^{s_*}}.")

#text("My conjecture is that this has a wider regime of accuracy than the Riemann-Siegel type formula (it is closer to the formula Brad and I used in our own paper, though we only used it in the regime where ")#mi("y > \\frac{-t}{2} \\log \\frac{x}{4\\pi}")#text(" in which the ")#mi("n=1")#text(" term dominates and there are no zeroes; when y is too small and t is too close to zero the series stops converging absolutely and is likely not very accurate).")

#text("I still haven’t figured out where these patterns are coming from though. I have a vague feeling that one might be able to see things more clearly if one normalises y by dividing it by the factor ")#mi("\\frac{-t}{2} \\log \\frac{x}{4\\pi}")#text(" mentioned previously; it may be that the curved lines one sees in the plots become nearly straight then. (It might be slightly better to use ")#mi("\\frac{x}{4\\pi} + \\frac{t}{16}")#text(" instead of ")#mi("\\frac{x}{4\\pi}")#text(", though probably the difference is pretty negligible – it’s the difference between the “toy” approximation and the “eff” approximation on the wiki.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509113")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2018")])]

#text("Actually it looks like the correct normalisation is not ")#mi("y / (-\\frac{t}{2} \\log \\frac{x}{4\\pi})")#text(", but rather ")#mi("\\frac{1}{2} \\log \\frac{x}{4\\pi} + \\frac{1+y}{t}")#text(". It looks like the points on the curves are coming from when adjacent elements in the ")#mi("\\frac{b_n^t}{n^{s_*}}")#text(" series are cancelling each other, thus the points on the outermost curve should be coming from the solutions to the equation")

#mi("\\displaystyle \\frac{b_2^t}{2^{s_*}} = - \\frac{b_1^t}{1^{s_*}}")

#text("the second set of points should be coming from")

#mi("\\displaystyle \\frac{b_3^t}{3^{s_*}} = - \\frac{b_2^t}{2^{s_*}}")

#text("and so forth. From taking absolute values, then logarithms, it looks like the solutions to")

#mi("\\displaystyle \\frac{b_{n+1}^t}{(n+1)^{s_*}} = - \\frac{b_n^t}{n^{s_*}}")

#text("asymptotically lie on the curve")

#mi("\\displaystyle \\frac{1}{2} \\log \\frac{x}{4\\pi} + \\frac{1+y}{t} = \\frac{1}{2} \\log n + \\frac{1}{2} \\log(n+1)")

#text("or equivalently")

#mi("\\displaystyle y = \\frac{-t}{2} \\log \\frac{x}{4\\pi n(n+1)} - 1")

#text("if I did my calculations correctly (and it seems to fit well with the graphics in your slides). Basically what seems to be happening is that for very large values of y and negative values of t, only two adjacent terms in the B-series dominate, though which two terms dominate depends on exactly where one is in (t,x,y) space, which is where all the different curves come from.")

#text("EDIT: the number of zeroes on or near the ")#mi("n^{th}")#text(" curve up to height ")#mi("x")#text(" should be approximately ")#mi("\\frac{x}{4\\pi} \\log \\frac{n+1}{n}")#text(", as compared with the total number of zeroes up to that height, which is about ")#mi("\\frac{x}{4\\pi} \\log \\frac{x}{4\\pi}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6525d7cd9db10f0f8b9a18fa0e62f21ac78916ee3eed4debea5956daeaf030-72219f07d23f0f1bc893af77a76e1cfd99cff0d2c3626a52796f2e15ac6c7e88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509117")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2018")])]

#text("I am sorry for such a naive question: Is your explanation specifically for the zeta function, or generally valid for a large number of functions as a consequence from the heat equation?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509119")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2018")])]

#text("From my calculations it seems that this phenomena should occur for any heat flow applied to a Dirichlet series, where the curves are coming from the regions where two adjacent terms in the (heat flowed) Dirichlet series dominate all the other terms, and periodically cancel each other out. This is actually somewhat related to an existing project of one of my graduate students, so I am thinking of getting him to look into this more.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509118")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2018")])]

#text("Actually, if these asymptotics can be made rigorous, they should lead to a much simpler proof of the non-negativity ")#mi("\\Lambda \\geq 0")#text(" of the de Bruijn-Newman constant, bypassing all the ODE analysis (and also the theory around the pair correlation conjecture) in my paper with Brad. I might get one of my graduate students to look into this further.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509151")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2018")])]

#text("Is it possible to apply such asymptotic to show that a “generalized de Bruijn-Newman constant” is nonnegative for a (possibly large) class of Dirichlet series (e.g. L functions) ?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509168")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2018")])]

#text("Your formula for the curves fits the patterns of the complex zeros very well ! They seem to even serve like an upper bound on the y-values of the zeros (at least visually up to x=1000).")

#link("https://drive.google.com/file/d/1uMsz5gZSD6HbaiPAcFN5ZMWPesdu0g3d/view?usp=sharing")[#text("Curving the zeros")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509227")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2018")])]

#text("Not that it matters too much, but if one uses the eff approximation instead of the toy approximation, one gets the slightly different curves")

#mi("\\displaystyle \\frac{b_n^t}{n^{\\mathrm{Re} s_*}} = \\frac{b_{n+1}^t}{(n+1)^{\\mathrm{Re} s_*}}")

#text("or equivalently")

#mi("\\displaystyle y = - t (\\mathrm{Re} \\alpha(\\frac{1+y+ix}{2}) - \\log \\sqrt{n(n+1)}) - 1")

#text("which might be a slightly better fit to the zeroes than the simpler curves described above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509269")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2018")])]

#text("Keen to try the eff-approximation, however struggled with the ")#mi("y")#text(" appearing on both sides of the equation. What would the best way to evaluate such equations?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509278")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2018")])]

#text("Iteration should work: start with an initial guess for ")#mi("y")#text(" (e.g. coming from the toy curve), and insert that in the RHS of the equation for the true curve to obtain a better approximant for y, As the alpha function varies slowly with y, thus should converge very rapidly after just a handful of iterations.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509268")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2018")])]

#text("We have now some clear indications that the complex zeros organise themselves “into families that peel off the real line at a regular rate”. The question then is what drives the regularity on the ‘peeling off’ process, i.e. what is it that frequently ‘beats the drum’ to start off a new curve of complex zeros, i.e. a new ")#mi("n, n+1")#text("-pair starts to dominate at a certain ")#mi("(x,-t)")#text("?")

#text("Could this have something to do with the patterns in the real zeros and then in particular with those regular vertical trajectories that don’t seem to originate from a collision between conjugates a ‘long time ago’. When we put ")#mi("y=0")#text(" in the (toy-model) formula for the n-curves, this yields the following equation:")

#mi("x=4 \\exp\\left(-\\frac{2}{t}\\right)\\pi\\,n(n+1)")

#link("https://drive.google.com/file/d/1NBZZ9EfwNNYyzfahD6RrK7_Sh-isakMC/view?usp=sharing")[#text("Plotting this ")]#text(" for ")#mi("n = 1..6")#text(" gives a set of curves whose spacings seem to match the spacings between these regular vertical trajectories’. It then appears that these originally straight curves have been ‘bended backwards’ by the pressures of the always larger number of real zeros that reside on on their right than on their left. Or is there a much simpler explanation for this?")

#text("Although the plot is not quite convincing yet, intuitively these vertical lines seem ideal candidates to serve as the starting point (y=0 case) for an incremental complex curve (next n). The regular patterns in the ‘local minima of complex pair collisions’ between them, are then simply induced by the first, second, etc. zero being ‘born’ on that new curve (going back in time).")

#text("These vertical real trajectories seem different from the others. Could there be a way to derive that these vertical lines must have been real forever? If so, then combined with the adage ‘once real, real forever’ and the infinite number of n-curves when ")#mi("x \\rightarrow \\infty")#text(", this might then provide an alternative way to proof Hardy & Littlewood’s theorem that there is an infinite number of zeros on the critical line.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509283")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2018")])]

#text("I don’t yet have a good explanation for the unusual patterns at the real axis yet; I am still lacking a plausible and tractable approximation to ")#mi("H_t(x)")#text(" in this regime (in particular, the approximation that led to the ")#mi("y = -\\frac{t}{2} \\log \\frac{x}{4\\pi n(n+1)} - 1")#text(" curves is completely inaccurate here). Am still working on it. The only thing I have so far is that the variable ")#mi("x+\\pi t/4")#text(" may be slightly better to plot than ")#mi("x")#text(" (it should straighten all the slanted lines in the plot).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509291")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2018")])]

#text("Actually, would it be possible to plot t versus ")#mi("\\sqrt{\\frac{x}{4\\pi} + \\frac{t}{16}}")#text(" for the real zeroes? My calculations are beginning to tell me that the fractional part of ")#mi("\\sqrt{\\frac{x}{4\\pi} + \\frac{t}{16}}")#text(" is somehow relevant (this is essentially the “")#mi("p")#text("” quantity in the ")#mi("C_0(p)")#text(" term of the eff expansion), though I’m not exactly sure how yet. (There’s also something funny going on near the line ")#mi("\\frac{x}{4\\pi} + \\frac{t}{16} = 0")#text(" that I also don’t understand; I guess the plot I’m asking for only makes sense for the zeroes to the right of this line.)")

#text("ADDED LATER: A plot of ")#mi("t/x")#text(" versus ")#mi("\\sqrt{\\frac{x}{4\\pi} + \\frac{t}{16}}")#text(" might be even more informative (it should make a lot of the diagonal line trends horizontal).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509306")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("Here’s the ")#link("https://drive.google.com/file/d/14AvIEiSFlVqElolVgszse3oZwYgObve2/view?usp=sharing")[#text(" plot")]#text(".")

#text("Lines are indeed straightening out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509323")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("Thanks! Looks like the long curves arise roughly when ")#mi("\\sqrt{\\frac{x}{4\\pi} + \\frac{t}{16}}")#text(" is close to a half-integer, and the next family of loops come when one is close to an integer. A bit surprised that there is still appreciable drift though, there must be a lower order correction.")

#text("I am closing in on a way to plausibly approximate ")#mi("H_t(x)")#text(" when x is large and t is large and negative (basically by expressing ")#mi("H_t")#text(" as an integral of the zeta function on the critical line against something roughly gaussian and doing a lot of Taylor expansion and discarding terms which look to be of lower order). This plot will likely be quite helpful in checking the calculations and in suggesting where the most interesting regions of t,x space are. (The calculations are currently incomplete, but I was already seeing the expressions ")#mi("t/x")#text(" and ")#mi("\\sqrt{\\frac{x}{4\\pi} + \\frac{t}{16}}")#text(" show up a lot, which is why I requested the plot.)")

#text("I’m getting hints from the calculations that the theta function might start playing a role. Certainly there is a faint resemblance between the latest plot and some of the imagery at ")#link("https://en.wikipedia.org/wiki/Theta_function")[#text("https://en.wikipedia.org/wiki/Theta_function")]#text(" …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509338")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("Ah, the drift is coming because one should be using")

#tao-math("\\displaystyle u:= \\frac{\\left|t\\right|}{\\frac{x}{4\\pi} + \\frac{t}{16}}", block: false)

#text("as the vertical coordinate rather than t/x. The resulting plot should, I think, be approximately 1-periodic in the horizontal direction; in fact I think that the plot of")

#tao-math("\\displaystyle (N,u) := ( \\sqrt{\\frac{x}{4\\pi} + \\frac{t}{16}}, \\frac{\\left|t\\right|}{\\frac{x}{4\\pi} + \\frac{t}{16}})", block: false)

#text("should (assuming I have not made any sign errors) asymptotically coincide with the zeroes of the theta function")

#mi("\\displaystyle \\sum_{n=-\\infty}^\\infty e^{-\\frac{un(n+1)}{16} - \\frac{\\pi i n(n+1)}{2} + 2\\pi i (n+1/2) N} = e^{-\\pi i N} \\theta_{10}(N, \\frac{iu}{16 \\pi} - \\frac{1}{2} )")#linebreak()#text(" (which one can check to be a real-valued function, 1-periodic in N). I wrote a heuristic derivation of this relationship on the wiki at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem#Large_negative_values_of_.5Bmath.5Dt.5B.2Fmath.5D")[#text("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem#Large_negative_values_of_.5Bmath.5Dt.5B.2Fmath.5D")]#text(" . For large values of u, the zeroes should occur when N is close to a half-integer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509329")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("Is it possible that the appearance of theta functions is an indication for the existence of some (still unknown) asymptotic expansion for ")#mi("H_t(x)")#text(" (where ")#mi("x, -t")#text(" are large) ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509342")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("Amazing!")

#link("https://drive.google.com/file/d/1OHho2qlFkV1mu8zNtJ9hn4JGdyuW6xTv/view?usp=sharing")[#text("This is the plot")]#text(" I get when using ")#tao-math("\\frac{\\left|t\\right|}{\\frac{x}{4\\pi}+\\frac{t}{16}}", block: false)#text(" instead of ")#mi("\\frac{t}{x}")#text(". Is this in line with your expectations?")

#text("Will start to explore the zeroes of the theta function tomorrow.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509345")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("Hmm, that’s not what I was expecting at all… oh, wait, the picture is being swamped by the extremely large values of the vertical coordinate. Could you truncate the picture to, say, the right of ")#mi("\\sqrt{\\frac{x}{4\\pi} + \\frac{t}{16}} = 2")#text(", and rescale? Right now all the interesting behaviour is squashed into the x axis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509382")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("Ah, of course! Sorry for that.")

#link("https://drive.google.com/file/d/101wtC7VyM9aHTst2F-X1Xf62FQT0m6e9/view?usp=sharing")[#text("Zoomed in")]#text(" plot (vertical axis values ")#mi("\\le 3.6")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509402")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("Thanks for this! At first I was puzzled as to why the diagram was not as 1-periodic as I had expected, but I think it is because of the numerical cutoffs in t and x which are truncating some of the zero trajectories. (Though it puzzles me somewhat as to why some trajectories are truncated whereas others seem to blast straight through the cutoff.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509406")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("Here is an ")#link("https://drive.google.com/file/d/1uZcJZPwxglKUGhI77Fh9vyMC_cjzBa8q/view?usp=sharing")[#text("updated version")]#text(" with the theta zeros as overlay. Looks like a pretty good fit with the straight lines. For calculating the Theta-zeros I used ")#mi("x = 10...600")#text(" and ")#mi("t=-200...-1")#text(" (t-steps of 1).")

#text("Can’t explain the cut-off’s either yet, but note that exactly the same phenomenon occurs in the Theta-zeros (both lines at 5.5 and 6.5 are shorter). What could happen here is that the t-resolution by which the real zeros of latex H_t$ have been calculated (t-steps of 0.1) are inducing this phenomenon. Will take a deeper dive.")

#text("It also seems another asymptotic pattern has emerged in the normalised graph (marked with an arrow). Where could this come from (maybe it is also just caused by the cut-offs)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509410")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("Hmm, I was expecting the theta function to also capture some of the loops. Is there some way to make a contour plot of theta? It’s complex valued, but the phase is very predictable (it should be ")#mi("e^{\\pi i N}")#text(", if I have calculated correctly). The theta function should somehow “notice” the loops.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509407")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2018")])]

#text("Is there any quantitative expression for the smooth envelop appearing (with some inner and outer “spikes”) in the plot?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509448")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2018")])]

#text("Getting closer. One mistake I made, is I that used ")#mi("\\sum_{-\\infty}^{\\infty}")#text(" instead of ")#mi("\\sum_n")#text(" (as in the formula on the wiki-page) to evaluate the Theta-function. I now do get ")#link("https://drive.google.com/file/d/15Z45HHQWhBA-MT2g335cVpEzWrnqjBeu/view?usp=sharing")[#text("this implicit plot ")]#text(" (not normalised) and although the loops do start to get ‘noticed’ they don’t seem to be in the correct spot yet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509461")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2018")])]

#text("Hmm, this isn’t as good a fit as I was hoping for, even if one anticipates the presence of sign errors etc. (for instance, it seems that the theta function is not exhibiting enough oscillation near the t=0 axis to account for the interesting behaviour of the zeroes there). But certainly it feels like the approximation is somehow partially correct since it seems to be capturing some, but not all, of the relevant features. I’ll have to think about this some more.")

#text("One small thing to try is to use test of the other approximations to ")#mi("H_t")#text(" that are ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem#Large_negative_values_of_.5Bmath.5Dt.5B.2Fmath.5D")[#text("on the wiki")]#text(" (but note that these approximations are only up to various normalisation factors, so they should capture the zeroes of ")#mi("H_t")#text(" but not the magnitude). An easy one to start with is the alternate theta function approximation ")#mi("\\theta_{01}( \\frac{16 \\pi N}{8\\pi - iu}, \\frac{16 \\pi}{8\\pi - iu})")#text(". A couple of such plots may help detect any remaining errors either in the wiki derivation or in the numerical implementation.")

#text("[ADDED LATER: given the modularity properties of the theta function, I was expecting to see the theta zero set exhibit patterns similar to that of the fundamental domain of the modular group (see e.g. the picture in ")#link("https://en.wikipedia.org/wiki/Fundamental_domain#Fundamental_domain_for_the_modular_group")[#text("https://en.wikipedia.org/wiki/Fundamental_domain#Fundamental_domain_for_the_modular_group")]#text(" ), which does resemble somewhat the plots we’re seeing for the zeroes. But something seems to have gone wrong somewhere; not sure what yet.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509463")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2018")])]

#text("Rudolph, is your theta function evaluation code available? Theta functions are already implemented (acb_modular_theta).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509466")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2018")])]

#text("Started to work through each asymptotic for ")#mi("H_t")#text(" on the Wiki and in the section “To cancel off an exponential decay…”, there seems to be something missing in the equation just before “where”.")

#text("Shouldn’t ")#tao-math("e^{-v^2+\\pi\\sqrt{\\left|t\\right|}\\,v/4}", block: false)#text(" be ")#tao-math("e^{-v^2+\\pi\\sqrt{\\left|t\\right|}\\,v/4 -\\pi^2\\left|t\\right|/64}", block: false)#text(" ?")

#text("@Anonymous, yes I am aware of the ARB function, however used pari/gp for the current evaluations. Will share the code once I have worked through all the Wiki equations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509467")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2018")])]

#text("Ah, ignore my comment: missed the “…we discard any multiplicative factor which is non-zero…” at the beginning!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509472")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2018")])]

#text("Will continue tomorrow, however did find that I am ‘losing the plot’ between the formula under “is defined in (6) of the writeup” (still ok) and the formula just above “The two factors of” (no longer ok). The strange thing is that when I add the ignored multiplicative factor ")#mi("M_0((1+i\\tilde x)/2)")#text(" back into the integral, the zeros do get closer to the correct ones again (but that shouldn’t happen). Could there be something off in the Taylor expansion step or the achieved accuracy?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509483")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2018")])]

#text("I’ve now numbered the equations in the wiki for ease of reference. If I understand what you are saying, then the zeroes of the RHS of (3.7) on the wiki still agree fairly well with the zeroes of ")#mi("H_t")#text(", and if one makes the approximation (3.8) then we still have good agreement, but if one makes the approximation (3.9) instead then one no longer has agreement? That suggests some issue with numerical precision (after all, ")#mi("M_0")#text(" is very small). (Perhaps you are also substituting (3.10) and (3.11) as well, but again this would still sound like a numerical precision issue.)")

#text("At any rate, I feel like this sort of numerical walkthrough of the heuristic argument in the wiki should soon pin down exactly where the divergence between theory and numerics is coming from (for instance, we should be able to see which of the approximations (3.8), (3.9), (3.10), (3.11) is somehow faulty). (In the worst case scenario, we might have to explicitly put back in all the non-zero factors that I was dropping to keep the calculations from becoming too messy, as it may be easier to detect the divergence if we have an actual asymptotic rather than just an asymptotic up to non-zero factors).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509499")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2018")])]

#text("Is it possible that the numerical problem appears whenever the nonzero factor of the “main term” of a possible (still unknown) asymptotic expansion of ")#mi("H_t(x)")#text(" is making the main term “too small” to neglect the influence of the remainder term?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509521")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2018")])]

#text("Thanks for the numbering! Worked through each step and re-injected the multiplicative factors. All went much better numerically, however failed to reconcile the step between 3.16 and 3.17. Could it be that the last ")#mi("\\log{\\frac{n}{N}}")#text(" in 3.17 should be ")#mi("\\log{n}")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509538")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2018")])]

#text("Hmm, (3.16) and (3.17) should only differ by the constant nonzero multiplicative factor of ")#mi("N^{\\frac{1+i\\tilde x}{2}}")#text(", so I’m at a loss to see what the problem is, perhaps one just has to insert this numerical factor back in again. (It is puzzling though that these factors make so much difference. It must be some numerical computation quirk that I was unaware of.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509547")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2018")])]

#text("I’ve tried to reproduce Rudolph’s real zeros plot in ")#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509448")[#text("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509448")]#text(" but I got a different looking plot. For each (x, t) in a grid I plotted a blue pixel if theta is negative and a red pixel if theta is positive. This showed four blue and three red diagonal stripes of varying widths, with the six boundary lines between the stripes appearing to correspond to six long straight green lines of Ht zeros in Rudolph’s plot (one of these lines is hard to see in his plot because it’s partly obscured by the legend in the lower left).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509550")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2018")])]

#text("Still puzzled by the unstable results and probably have made a mistake somewhere but eager to get this sorted. Appreciate any help and have therefore just created a new issue ")#link("https://github.com/km-git-acc/dbn_upper_bound/issues/126#issue-394518354")[#text("here")]#text(". It contains the pari/gp code that I have used so far and grateful for any help/hints/tips on where the issue could be!")

#text("@anonymous, maybe you could also replicate some equations of the wiki-page in ARB, so we could compare output.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509551")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2018")])]

#text("print(“eq.328 “,Ht324(1000, -10))")

#text("this looks wrong, visually")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509553")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2018")])]

#text("Rudolph, my code is failing the sanity check by not getting a real RHS, so I probably have something wrong in the way I’m calling the theta function or there is a typo on the wiki.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509580")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2018")])]

#text("@anonymous, I am also getting an imaginary part in pari/gp when evaluating the RHS from eq. 3.07 onwards. Therefore don’t think this is induced by incorrect calling of the ARB-theta.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath 15, eleventh thread: Writing up the results, and exploring negative t | What's new")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-509621")[#strong[#text("Polymath 15, eleventh thread: Writing up the results, and exploring negative t | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2018")])]

#text("[…] thread of the Polymath15 project to upper bound the de Bruijn-Newman constant , continuing this post. Discussion of the project of a non-research nature can continue for now in the existing proposal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43f52aa77295050335c7966ccc336777ba01cbeeb09d4dc6b2277995d0c1116e-41302a5895202f13f12503bbc7876c07f78ecc150ed85ae5e5813f55ba554208.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabrice Imparato")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-685241")[#strong[#text("Fabrice Imparato")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2024")])]

#text("Dear Prof Tao, great paper combining heroic analyses and numerical verifications!")

#text("Unfortunately I am stuck with the numerical verification of claim (93) corresponding to the lower edge of ∂R, in which N0 ≤ N ≤ N1 and y = 0.2, despite using the Euler product mollifier with primes 2,3,5 and the improved triangle inequality.")

#text("dist(E(x+iy)f(x+iy),(−∞,0]) > 2.05 × 10−3 in the range [69098, 80000]")

#text("It appears that the βn coefficients are strictly positive except for n=2,3,5 where their value is zero and the αn coefficients also appear positive. Hence the improved triangle inequality only provides a modest improvement of about 0.8 factor compared to the triangle inequality in equation (98).")

#text("As mentioned in the paper, “As it turns out, this bound is not quite strong enough to be satisfactory for the numerical range")#linebreak()#text("of parameters we need”.")

#text("Please could you indicate where the sum exhibits significant cancellation other than the coefficients β2, β3 and β5. Or perhaps I may have misinterpreted the definition of the βn, αn coefficients in the paper.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-685255")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2024")])]

#text("It’s been a while, but I do recall that the gain of the improved triangle inequality was rather modest, but still good enough to conclude (in particular, to get the lower bound ")#mi("F_{69098, 80000} \\geq 0.0263\\dots")#text(" at the end of the section. Is there a specific step in the calculation where you found any sort of error or other issue?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-685274")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2024")])]

#text("Thanks for your quick response! The sum Y in Lemma 8.5 does appear too large with σ = 1.714328 and N_=69098 and N+=80000.")

#text("For the calculation, we used Python code on orderai.azurewebsites.net with 15 to 17 digits float and the sum is calculated over each congruence class separately. As an example βn = β(t,n)-β(t,2)*β(t,n/2) for n={2,4,8,14,16,22,26,28} mod 30 and αn are calculated in similar way for this congruence class.")

#text("The partial sums for n={2,4,…,28}, n={3,9,21,27} and n={5,25} mod 30 add up to >1.5 which is too large for the lower bound required.")

#text("As Platt & Trudgian showed in their 2020 paper that The Riemann hypothesis is true up to height 3000175332800, we may want to revisit the numerical verification to this height and the Euler 2 mollifier seems to give better results than the improved triangle inequality of Lemma 8.5 in this range.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-685279")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2024")])]

#text("I’ve contacted some of the other collaborators on this project to help look into this issue and hope to get back to you soon. It may be related with an issue we found in a previous version of the argument which should now be fixed, see ")#link("https://github.com/km-git-acc/dbn_upper_bound/issues/131#issuecomment-481039999")[#text("https://github.com/km-git-acc/dbn_upper_bound/issues/131#issuecomment-481039999")]#text(" , but we are not sure yet.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43f52aa77295050335c7966ccc336777ba01cbeeb09d4dc6b2277995d0c1116e-41302a5895202f13f12503bbc7876c07f78ecc150ed85ae5e5813f55ba554208.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabrice Imparato")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-685281")[#strong[#text("Fabrice Imparato")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2024")])]

#text("It might not be necessary to revisit Lemma 8.5 as the result Λ≤0.22 has now been superseded.")

#text("As mentioned in the paper, we can get Λ≤0.2 using Platt latest height and the parameters in the table Conditional Λ results, assuming a winding number of zero at the barrier location, which is the step requiring the most CPU.")

#text("We checked the calculations using parameters N0=630783 N1=5000000, t0=0.186, y0=0.16733 as per the paper. In the unbounded region, N1>5000000, we checked |ft(x + iy| > 1.25 × 10−3 using Lemma 8.2.")

#text("In the bounded region, N0≤N≤N1, we calculated a lower bound for |ft(x + iy| in each interval [630783, 800000], [800000, 1500000] etc. until we reached N1=5000000 using Lemma 10.1 based on Euler 2 mollifier and recalculating the σ in each interval.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-685285")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2024")])]

#text("Hi Fabrice. Whilst true that the result has been superseded by Platt’s 2020 verification of the RH at a greater height, I believe there still is value in exploring the different outcomes we get about Lemma 8.5.")

#text("You can find the pari-gp software we have used to evaluate ")#mi("F_{N_{-},N_{+}}")#text(" <a href=")#link("https://drive.google.com/file/d/1rxe_kFnLNNJXXiy2zdJ97iu5qnOZwhTR/view?usp=share_link")[#text("https://drive.google.com/file/d/1rxe_kFnLNNJXXiy2zdJ97iu5qnOZwhTR/view?usp=share_link")]#text(">here.</a> It is easy to read and can be run in a Sagemath cell.")

#text("The values I got for the individual variables are:")

#mi("N_{-}= 69098, N_{+}= 80000, t=y=0.2")#linebreak()#text("Mollifier primes ")#mi("2,3,5")#text(" hence ")#mi("D=30")#linebreak()#mi("\\sigma = 1.713328107")#linebreak()#mi("1.005,N_{-}^{-0.2} \\alpha_1 = 0.1082113877")#linebreak()#mi("1.005,N_{-}^{-0.2} \\alpha_2 = 0.01648208066")#linebreak()#mi("1.005,N_{-}^{-0.2} \\alpha_3 = 0.02824498649")#linebreak()#mi("1.005,N_{-}^{-0.2} \\alpha_4 = 0.02676681091")#linebreak()#mi("1.005,N_{-}^{-0.2} \\alpha_5 = 0.04677296806")#linebreak()#mi("1.005,N_{-}^{-0.2} \\alpha_6 = 0.01763287104")#linebreak()#mi("\\beta_2 = 0")#linebreak()#mi("\\beta_3 = 0")#linebreak()#mi("\\beta_4 = 0.05164061506")#linebreak()#mi("\\beta_5 = 0")#linebreak()#mi("\\beta_6 = 0.08608987410")#linebreak()#mi("F_{N_{-},N_{+}} = 0.02634178936")

#text("when Note that we have (historically) used an additional factor ")#mi("1.005")#text(", however this doesn’t change the outcome much. Grateful if you could compare these quantities with your computations.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43f52aa77295050335c7966ccc336777ba01cbeeb09d4dc6b2277995d0c1116e-41302a5895202f13f12503bbc7876c07f78ecc150ed85ae5e5813f55ba554208.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabrice Imparato")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-685288")[#strong[#text("Fabrice Imparato")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2024")])]

#text("Hi Rudolph, thanks for your help and for sharing the code! We got what went wrong with our calculation. We were counting the Dirichlet sum with βn = β(t,n)-β(t,2)*β(t,n/2) over the entire range up to 2400000 while there should be a threshold at 160000 in this particular case as defined by Threshdelta(n,divisor*N) in your code. Hence βn = 0 once you exceed the threshold.")

#text("Another observation that the Dirichlet coefficients βn and αn are all positive and equal zero for β2, β3 and β5 and once you exceed the threshold. Hence abs(b[n]+a[n])=abs(b[n])+abs(a[n]) and the difference between the improved triangle inequality of Lemma 8.5 and the triangle equality for n not in {2,3,5} is (1-a[1])/(1+a[1]) which is about a factor 0.8. We also used σ = 1.714328 which is more favourable for the Dirichlet sum.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-685289")[#strong[#text("Rudolph")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2024")])]

#text("Great and thanks for the efforts you put into this detailed verification. In this context you might also be interested in the third book in the sequel “Equivalents of the Riemann Hypothesis” by Kevin Broughan that was published earlier this year. In chapter 6 he shares a rewrite and verification of the Polymath15 work. By using the programming language Julia he obtains similar results as ours and includes some interesting new stream plots.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/06/polymath15-tenth-thread-numerics-update/#comment-685292")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2024")])]

#text("Glad to hear that the numerical discrepancy has now been resolved!")

#text("The improved triangle inequality was an ")#emph[#text("ad hoc")]#text(" fix for the immediate problem we had, which was that the naive triangle inequality bound was barely insufficient to guarantee a suitable barrier. It may well be that it will become unnecessary as the capability to perform numerics improves (and there may well be more efficient ways to guarantee a barrier to zeroes than the one we eventually landed on).")
]
]
