// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/
// Converted to Typst by tao2typ: "2026-10-14T10:25:08.300061+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A differentiation identity", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A differentiation identity")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 May 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/")[#text("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Here’s a cute identity I discovered by accident recently. Observe that")

#tao-aligned(keep: true)[


#tao-math("\\frac{d}{dx} (1+x^2)^{0/2}  & = 0", block: true)



#tao-math("\\frac{d^2}{dx^2} (1+x^2)^{1/2}  & = \\frac{1}{(1+x^2)^{3/2}}", block: true)



#tao-math("\\frac{d^3}{dx^3} (1+x^2)^{2/2}  & = 0", block: true)



#tao-math("\\frac{d^4}{dx^4} (1+x^2)^{3/2}  & = \\frac{9}{(1+x^2)^{5/2}}", block: true)



#tao-math("\\frac{d^5}{dx^5} (1+x^2)^{4/2}  & = 0", block: true)



#tao-math("\\frac{d^6}{dx^6} (1+x^2)^{5/2}  & = \\frac{225}{(1+x^2)^{7/2}}", block: true)
]

#text("and so one can conjecture that one has")

#align(center)[#tao-fit-display[#mitex("\\frac{d^{k+1}}{dx^{k+1}} (1+x^2)^{k/2} = 0")]]

#text("when ")#mi("k")#text(" is even, and")

#align(center)[#tao-fit-display[#mitex("\\frac{d^{k+1}}{dx^{k+1}} (1+x^2)^{k/2} = \\frac{(1 \\times 3 \\times \\dots \\times k)^2}{(1+x^2)^{(k+2)/2}}")]]

#text("when ")#mi("k")#text(" is odd. This is obvious in the even case since ")#mi("(1+x^2)^{k/2}")#text(" is a polynomial of degree ")#mi("k")#text(", but I struggled for a while with the odd case before finding a slick three-line proof. (I was first trying to prove the weaker statement that ")#mi("\\frac{d^{k+1}}{dx^{k+1}} (1+x^2)^{k/2}")#text(" was non-negative, but for some strange reason I was only able to establish this by working out the derivative exactly, rather than by using more analytic methods, such as convexity arguments.) I thought other readers might like the challenge (and also I’d like to see some other proofs), so rather than post my own proof immediately, I’ll see if anyone would like to supply their own proofs or thoughts in the comments. Also I am curious to know if this identity is connected to any other existing piece of mathematics.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (48)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a968d848a038d729014bb5828a6a59056d0571e26c2a05ee90cb12c2f8e73cd6-19b07a54336dd0d17a7e49e8231fff18ced0a12a91b396708c8ea039bf59768c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paata Ivanishvili")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456173")[#strong[#text("Paata Ivanishvili")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#text("Here is an approach:")#linebreak()#text(" Let ")#mi("f(x)=(1+x^{2})^{k/2}")#text(", and let ")#mi("T")#text(" be the following operator: it takes derivative with respect to x, then divides the result by ")#mi("\\cosh(x)")#text(", then again takes derivative with respect to ")#mi("x")#text(" and then again divides result by ")#mi("\\cosh(x)")#text(". Note that ")#mi("Tf(\\sinh(x))=f^{\\prime\\prime}(\\sinh(x))")#text(". Let ")#mi("x_{k}=(\\cosh(x))^{k}")#text(", and ")#mi("x_{0}=1")#text(". All we need to show is that ")#mi("T^{(k+2)/2}x_{k}=\\frac{(1\\times 3 \\times ...\\times k)^{2}}{x_{-k-1}}")#text(". Note that ")#mi("Tx_{k} = k(k-1)x_{k-2}-k(k-2)x_{k-4}")#text(". Now I think it should not be difficult to iterate this process and get the desired result.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/55b09fd124a17dcca3e13366901c6f66f0658ff92835dd6f4a682deaa336a7bb-19b07a54336dd0d17a7e49e8231fff18ced0a12a91b396708c8ea039bf59768c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paata Ivanishvili")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456175")[#strong[#text("Paata Ivanishvili")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#text("I am sorry for the typos: “All we need to show ")#mi("T^{(k+1)/2}=(1\\times 3\\times ...\\times k)^{2}x_{-k-2}")#text("”.")

#text("And by saying “to iterate this process”, of course I meant simple induction (")#mi("T")#text(" is a linear operator).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b59c9126682c96c5c1275455e7bb12d10f65d71631e7a82c73fe718959499f2b-856f14e3561466d3b3636c110b19692d32efbe82a2741c60434e922e7fb7ac88.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ofir Goro")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456174")[#strong[#text("Ofir Goro")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#text("I think Lagrange Inversion formula sheds light on this problem.")#linebreak()#text(" Let ")#mi("f(y) = \\sqrt{1+y^2}")#text(". If we denote ")#mi("x = \\frac{y}{f(y)}")#text(" (and note that ")#mi("x")#text(" satisfies ")#mi("y = \\frac{x}{\\sqrt{1-x^2}}")#text(", Lagrange Inversion says:")

#mi("[x^m]g(y) = \\frac{1}{m} [y^{m-1}] g^{\\prime}(y) f^m")#text(" for any power series ")#mi("g")#text(".")

#text("Choosing ")#mi("g(y) = \\arctan(y)")#text(", we get:")

#mi("[x^m]\\arctan \\frac{x}{\\sqrt{1-x^2}} = \\frac{1}{m} [y^{m-1}] (1+y^2)^{\\frac{m}{2} - 1}")#text(". Now we recall ")#mi("\\arctan \\frac{x}{\\sqrt{1-x^2}}  = \\arcsin x")#text(" and get the constant coefficient in your formula (replace ")#mi("m")#text(" by ")#mi("k+2")#text(" to see this more clearly).")

#text("By plugging ")#mi("g")#text(" such that ")#mi("g^{\\prime}(y) = (1+y^2)^{-i}")#text(", we can get the rest of the coefficients, and see that they agree with the formula. Not very slick, I agree, as the formula for the ")#mi("g")#text("‘s become more complicated.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c7661bd273cffe043f86752f200aa39ff51c922f0539d9a24edb4711550c5a3-a0a50444b66e0b14319b1babbce75f7f54d89765ac5ff4370b9c5ee34950f4b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amie")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456176")[#strong[#text("Amie")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#text("Here is a rather brute force proof.")

#text("Let ")#mi("h = (1+ x^2)")#text(".")#linebreak()#text(" Let ")#mi("f_k = h^{k/2} = h f_{k-2}")#text(", and let")#linebreak()#text(" let ")#mi("g_k = D^{(k+1)}(f_k)")

#text("Then")

#mi("D^2(gh) = D(g Dh + Dg h) = (D^2 g) h +  2 Dg Dh + 2 g)")

#mi("D^3(gh) =  (D^3 g) h + 3 D^2 g Dh + 6Dg")

#text("Inductively:")

#mi("D^{k}(gh) = D^{k}(g) h +  k D^{k-1} g Dh + (k^2 - k) D^{k-2} g")

#text("Thus:")

#mi("g_{k-2} = D^{k}f_{k-1} = D^{k} (h f_{k-3}) =  (D^k f_{k-3}) h + k D^{k-1}(f_{k-3}) Dh + (k^2 - k) g_{k-3}")

#text("We are left to verify the formula")

#mi("g_{k-1} =  (x^2 + 1 ) g_{k-3}^{\\prime\\prime} + 2 k x g_{k-3}^{\\prime}  + (k^2-k) g_{k-3}")

#text("(or perhaps there’s something slick with generating functions. But back to work).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17091d4a03d31ec4dcf328fd4d4d32db71be5b910e8d970cb06458f485a78ee0-f9203420c8451af72d62b1b2b4d5e95ce44a69b089d67063cdb25ebaac827640.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Amiot")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456177")[#strong[#text("Emmanuel Amiot")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#text("Identifying power expansions seems to work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456178")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#text("It seems that this identity (for complex argument ")#mi("i x")#text(") follows from Rodrigues formula for Chebyshev polynomials ")#mi("T_n")#text(". see e.g. table 18.5.1 in dlmf.nist.gov")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456179")[#strong[#text("1 – Fields Medalist Terence Tao stumbles upon a “differentiation identity | Offer Your")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")]

#text("[…] : ")#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/")[#text("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b59c9126682c96c5c1275455e7bb12d10f65d71631e7a82c73fe718959499f2b-856f14e3561466d3b3636c110b19692d32efbe82a2741c60434e922e7fb7ac88.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ofir Gorodetsky")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456180")[#strong[#text("Ofir Gorodetsky")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#text("It is worth noting that the straightforward brute force solution (comparing coefficients) actually works, and is relatively simple.")

#text("Namely, the coefficient of ")#mi("x^i")#text(" (")#mi("i")#text(" even) in ")#mi("(1+x^2)^{k/2}")#text(" (")#mi("k")#text(" is odd) is ")#mi("\\binom{k/2}{i/2}")#text(". After differentiating ")#mi("(k+1)")#text(" times, we get that the coefficient of ")#mi("x^{i-(k+1)}")#text(" is ")#mi("\\binom{k/2}{i/2} i (i-1) \\cdots (i-k)")#text(".")

#text("On the other hand, the coefficient of ")#mi("x^{i-(k+1)}")#text(" in the RHS is ")#mi("(1 \\cdot 3 \\cdots k)^2 \\binom{ -\\frac{k+2}{2}}{\\frac{i-(k+1)}{2}}")#text(".")

#text("For ")#mi("i=k+1")#text(" the equality amounts to ")#mi("\\binom{\\frac{k}{2}}{\\frac{k+1}{2}} (k+1)! = (1 \\cdot 3 \\cdots k)^2")#text(", which is verified by induction on odd ")#mi("k")#text("‘s, where the induction step follows from")#linebreak()#text(" ")#mi("\\displaystyle \\frac{(1 \\cdot 3 \\cdots k+2)^2}{(1 \\cdot 3 \\cdots k)^2} = (k+2)^2 = \\frac{\\frac{k+2}{2}}{\\frac{k+3}{2}}(k+2)(k+3)  = \\frac{ \\binom{(k+2)/2}{(k+3)/2} (k+3)!}{ \\binom{k/2}{(k+1)/2} (k+1)! }")#linebreak()#text(" (the identity ")#mi("\\binom{n}{j} /\\binom{n-1}{j-1} = \\frac{n}{j}")#text(" is useful here)")

#text("To proceed, perform induction on even values of ")#mi("i \\ge k +1")#text(". The base case was done now, and the induction step follows from the following identity:")#linebreak()#text(" ")#mi("\\displaystyle \\frac{\\binom{k/2}{(i+2)/2} (i+2)(i+1) \\cdots (i-k+2)}{\\binom{k/2}{i/2} i(i-1) \\cdots (i-k)} = \\frac{\\frac{k}{2} - \\frac{i}{2}}{\\frac{i}{2} + 1} \\frac{(i+2)(i+1)}{(i-k)(i-k+1)}")#linebreak()#text(" ")#mi("\\displaystyle  = \\frac{-(i+1)}{i-k+1} = \\frac{-\\frac{k+2}{2} - \\frac{i-(k+1)}{2}}{\\frac{i-(k+1)}{2}+1}")#linebreak()#text(" ")#mi("\\displaystyle  = \\frac{ \\binom{ -\\frac{k+2}{2}}{\\frac{i+2-(k+1)}{2}} }{ \\binom{ -\\frac{k+2}{2}}{\\frac{i-(k+1)}{2}} }")#linebreak()#text(" (the identity ")#mi("\\binom{n}{j+1} / \\binom{n}{j} = \\frac{n-j}{j+1}")#text(" is useful here)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b59c9126682c96c5c1275455e7bb12d10f65d71631e7a82c73fe718959499f2b-856f14e3561466d3b3636c110b19692d32efbe82a2741c60434e922e7fb7ac88.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ofir Gorodetsky")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456185")[#strong[#text("Ofir Gorodetsky")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#text("Here’s a proof using Leibnitz’ law. Write ")#mi("(x^2+1)^{k/2}")#text(" as ")#mi("(x+i)^{k/2} (x-i)^{k/2}")#text(". We differentiate this ")#mi("k+1")#text(" times and get:")

#mi("\\displaystyle \\sum_{n+m = k+1} ((x+i)^{k/2})^{(n)} ((x-i)^{k/2})^{(m)} \\binom{k+1}{n} = \\sum_{n+m = k+1} (k/2)_{n} (x+i)^{k/2 -n} (k/2)_{m} (x-i)^{k/2 -m} \\binom{k+1}{n}")

#text("where ")#mi("(x)_n")#text(" is the falling factorial.")

#text("We need to prove this sum equals ")#mi("(x^2+1)^{-k/2 - 1} (1 \\cdot 3 \\cdots k)^2")#text(". Multiplying both sides by ")#mi("(x^2+1)^{k/2+1}= (x+i)^{k/2+1} (x-i)^{k/2+1}")#text(", the desired equality becomes:")

#mi("\\sum_{n+m = k+1} (k/2)_n (k/2)_m \\binom{k+1}{n} (x+i)^m ( x-i)^n = (1 \\cdot 3 \\cdots k)^2")

#text("At this point one notices the interesting-though-tautological identity ")#mi("(k/2)_n (k/2)_m = (k/2)_{k+1} (-1)^m")#text(". Plugging it, the equality reduces to")

#mi("(k/2)_{k+1} \\sum_{n+m = k+1}  \\binom{k+1}{n} (-x-i)^m ( x-i)^n = (1 \\cdot 3 \\cdots k)^2")

#text("The sum is just ")#mi("((x-i) + (-x-i))^{k+1} = (-2i)^{k+1}=(-4)^{(k+1)/2}")#text(" (binomial theorem), hence everything boils down to the following:")

#mi("(k/2)_{k+1} (-4)^{(k+1)/2} = (1 \\cdot 3 \\cdots k)^2")

#text("This is again kind tautological, since the LHS is ")#mi("\\frac{k}{2} (\\frac{k}{2} - 1) \\cdots (-\\frac{k}{2})  (-4)^{(k+1)/2} = (\\frac{k}{2} \\cdot \\frac{k-2}{2} \\cdots \\frac{1}{2})^2  4^{(k+1)/2} = (1 \\cdot 3 \\cdots k)^2")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b59c9126682c96c5c1275455e7bb12d10f65d71631e7a82c73fe718959499f2b-856f14e3561466d3b3636c110b19692d32efbe82a2741c60434e922e7fb7ac88.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ofir Gorodetsky")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456186")[#strong[#text("Ofir Gorodetsky")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#text("(last post for tonight) I just realized we could have used the mentioned identity ")#mi("(k/2)_n (k/2)_m = (k/2)_{k+1} (-1)^m")#text(" right after we used Leibniz’ law, and in this way find the answer ")#mi("(1 \\cdot 3 \\cdots k)^2 (1+x^2)^{-k/2 - 1}")#text(" without even knowing it beforehand.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456193")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#text("This proof seems to be “from the book!”.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f4526707a3565a27330782583eed8714d9573cff38fcd08565a4a86932760b0-b82a1ab8788b4d02e93afd4517c8001b119d122cfd634a06930921d8ddc16f9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ivan Z.")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456189")[#strong[#text("Ivan Z.")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#text("I bet there is some nice parsimonious modular forms thingy behind this!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a68e4f9f5b35d6a42ebc2624bacf9d4900c822977e0b8d4fbb23ab3091732e84-0c30fba8f781fb4e46f6e5c83ac492c0a7f171c49ef6d764e3248a336b96dec4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paolo D'Isanto")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456191")[#strong[#text("Paolo D'Isanto")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#mi("\\frac{(n+1)!}{2\\pi i}\\int\\frac{(1+z^2)^{\\frac{n}{2}}}{z^{n+2}}dz=\\frac{d^{n+1}}{dz^{n+1}}(1+z^2)^{\\frac{n}{2}}|_{z=0}")

#text("We develope the binomial and so we have")

#mi("\\frac{(n+1)!}{2\\pi i}\\sum \\binom{\\frac{n}{2}}{\\nu}\\oint z^{2\\nu-n-2}dz")

#text("Now, because we are interested to only values of exponent of ")#mi("z")#text(" whose integral is not zero we impose that")

#mi("2\\nu-n-2=-1")

#text("so being ")#mi("\\nu")#text(" an integer ")#mi("n")#text(" is necessarily odd. In the other cases the Cauchy integral is zero. From this relation we have")

#mi("\\nu=\\frac{n+1}{2}")

#text("and so posing ")#mi("n=2N+1")#text(" we have:")

#mi("\\frac{d^{2N+2}}{dz^{2N+2}}(1+z^2)^{N+1}|_{z=0}=(2N+2)!\\binom{\\frac{2N+1}{2}}{N+1}")

#text("Remembering that")

#mi("\\Bigl(\\frac{2N+1}{2}\\Bigr)!=\\frac{(2N+1)!!}{2^{N+1}}\\sqrt{\\pi}")

#text("and")

#mi("(2N+2)!=(2N+1)!!(2N+2)!!")

#mi("(2N+2)!!=2^{N+1}(N+1)!")

#mi("(-1/2)!=\\sqrt{\\pi}")

#text("we obtain finally")

#mi("\\frac{d^{2N+2}}{dz^{2N+2}}(1+z^2)^{N+1}|_{z=0}=[(2N+1)!!]^2")

#text("Best Regards")

#text("Paolo D’Isanto")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456192")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#text("The contour of integration should be clearly defined (to avoid the branch line connecting the two branch points ")#mi("+i, -i")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e26ce1c5111f0039f24500ca7936b7065ef90765bd4b6af2c711d2cae4a6fef-63d36d230210859f10f66039ae4b784400c91f4da6dc5746ebebbdb0ac3c8f62.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zoltan Toroczkai")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456194")[#strong[#text("Zoltan Toroczkai")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#text("Let ")#mi("x=\\sinh z")#text(", ")#mi("y=\\cosh z")#text(", ")#mi("\\hat{L} \\cdot = \\frac{d}{dx} \\cdot = \\frac{1}{y}\\frac{1}{dz} \\cdot")#text(" and ")#mi("A_k = y^{k+2}\\hat{L}^{k+1}y^k")#text(", for ")#mi("k")#text(" odd. Using ")#mi("y^{\\prime 2}=y^2-1")#text(" and ")#mi("y^{\\prime\\prime} = y")#text(" (here prime denotes differentiation w.r.2 ")#mi("z")#text(") we find ")#mi("\\hat{L}^2 y^k=k(k-1)y^{k-2}-k(k-2)y^{k-4}\\;\\;(*)")#text(". It is easy to show the identity for ")#mi("p")#text(" odd: ")#mi("(y^{-p}y^{\\prime})^{\\prime} = y^{-(p+1)}\\left( p-(p-1)y^2\\right)")#text(". Using this identity then ")#mi("\\hat{L}^2 y^{-m} = y^{-(m+4)} \\left( m(m+1)y^2 -m(m+2) \\right)\\;\\;(**)")#text(" follows for ")#mi("m")#text(" odd. Assuming that ")#mi("A_m = y^{m+2} \\hat{L}^{m+1}y^{m} = (m!!)^2")#text(" holds for all ")#mi("m \\leq k-2")#text(", ")#mi("m")#text(" odd, we can write: ")#mi("A_k = y^{k+2} \\hat{L}^{k-1}\\left(\\hat{L}^2y^k\\right) = k(k-1)A_{k-2}y^2 - k(k-2)y^{k+2}\\hat{L}^{k-1}y^{k-4}")#text(", where we used (*). The second term is computed from (**) and we find: ")#mi("A_k =k(k-1)A_{k-2}y^2 -k(k-2)A_{k-4}\\left((k-2)(k-1)y^2 -k(k-2)\\right).")#text(" The ")#mi("y^2")#text(" terms cancel and we find that the identity is valid for ")#mi("m=k")#text(" (odd) as well. There is some sort of duality that appears here, which could be exploited for a short proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e26ce1c5111f0039f24500ca7936b7065ef90765bd4b6af2c711d2cae4a6fef-63d36d230210859f10f66039ae4b784400c91f4da6dc5746ebebbdb0ac3c8f62.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zoltan Toroczkai")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456195")[#strong[#text("Zoltan Toroczkai")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#text("There was a bit of a jump in my description above, this is more explicit: ")#mi("\\hat{L}^{k-1} y^{k-4} = \\hat{L}^{2}\\left(\\hat{L}^{k-3}y^{k-4}\\right) = A_{k-4} \\hat{L}^{2} y^{-(k-2)}")#text(" and then the rest easily follows.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a830450fdc42640734c399aefa8d8f69203b5cf003a6fb3d85c05a81a6dcced-6aa92d6fbc6161814fa75065d6b8ebec555852a948f8c3d0155ac32fac6aeb95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456196")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#text("In the neighborhood of infinity, ")#mi("(1+x^2)^{k-(1/2)}")#text(" can be written as a series of decreasing powers of ")#mi("x")#text(", starting from ")#mi("x^{2k-1}")#text(". If we differentiate ")#mi("2k")#text(" times, the nonnegative powers disappear, and the negative powers give powers of exponent at most ")#mi("-2k-1")#text(". Hence, the ")#mi("k")#text("-th derivative is ")#mi("O(x^{-2k-1})")#text(" at infinity. On the other hand, an immediate induction implies that it is a polynomial times ")#mi("(1+x^2)^{-k-(1/2)}")#text(": the domination implies that the polynomial is constant. This constant can be computed by taking ")#mi("(2k)!")#text(" times the term in ")#mi("x^{2k}")#text(" in the expansion of ")#mi("(1+x^2)^{k-(1/2)}")#text(" at zero.")

#emph[#text("[This is essentially the proof I eventually came up with also :-) – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d0787f36ff8adaaae2bf792d89bbd3946b1e7047e133f9a57e68c5c66436b1b-3457e7638e41a7fc17ccffbbb49839d30462270a5143f6b714c8535ead43712f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456204")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2015")])]

#text("Let ")#mi("h_k(x):=(1+x^2)^{k/2}")#text(", ")#mi("g(x):=x")#text(",")#linebreak()#text(" ")#mi("p_k:=(1\\times3\\times\\dots\\times k)^2")#text(". Then for odd ")#mi("k\\ge3")

#mi("D^{k+1}h_k=k D^k(gh_{k-2})=kg D^k h_{k-2}+k^2 D^{k-1}h_{k-2}")

#mi("=kg D(p_{k-2}/h_k)+k^2 p_{k-2}/h_k=p_k/h_{k+2},")

#text("as desired; for the third equality in the above display we use the induction, and for the second we use the Leibniz rule. Here ")#mi("D")#text(" is of course the differentiation operator.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a68e4f9f5b35d6a42ebc2624bacf9d4900c822977e0b8d4fbb23ab3091732e84-0c30fba8f781fb4e46f6e5c83ac492c0a7f171c49ef6d764e3248a336b96dec4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paolo D'Isanto")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456216")[#strong[#text("Paolo D'Isanto")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2015")])]

#text("Thanks Anonymous, sorry for all this posts, i was very tired because of i had the idea of demonstration this night! So, the most general contour on which the integral is calculated is every closed curve containing ")#mi("z=0")#text(" in the ")#mi("\\mathbb C")#text("-strip ")#mi("-1<\\Im z<1")#text(":")

#mi("\\gamma=\\left\\{z=\\rho(\\theta) e^{i\\theta}\\in\\mathbb C:-1<\\rho(\\theta)\\sin\\theta<1,\\rho(\\theta)\\cos\\theta\\in\\mathbb R,\\theta\\in[0,2\\pi]\\right\\}")

#text("So, the Tao-conjecture is verified for every")

#mi("x=\\rho(\\theta)cos\\theta\\in\\mathbb R")#text(".")

#text("Thanks a lot.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456218")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2015")])]

#text("Thanks for all the contributed proofs and proof strategies!")

#text("The proof of the identity that I originally had is essentially that found in ")#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456196")[#text("this previous anonymous comment")]#text(" (the only difference being that I computed the constant through Taylor expansion around infinity, rather than around zero), but I just worked out a Fourier-analytic proof which has the advantage of extending to non-integer values of ")#mi("k")#text(", and which is somewhat reminiscent of the proof of the functional equation for the zeta function via modularity of the theta function (confirming the ")#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456189")[#text("suspicion of Ivan Z. above")]#text("). For any ")#mi("s > 0")#text(", we scale the Gamma function")

#mi("\\displaystyle \\Gamma(s) = \\int_0^\\infty e^{-t} t^s \\frac{dt}{t}")

#text("to express ")#mi("(1+x^2)^{-s}")#text(" as the average of Gaussians:")

#mi("\\displaystyle (1+x^2)^{-s} = \\frac{\\pi^s}{\\Gamma(s)} \\int_0^\\infty e^{-\\pi t} e^{-\\pi t x^2} t^s \\frac{dt}{t}.")

#text("This formula is valid for any ")#mi("x \\in {\\mathbf R}")#text(". Taking (distributional) Fourier transforms, we conclude that")

#mi("\\displaystyle \\int_{\\mathbf R} e^{-2\\pi i x \\xi} (1+x^2)^{-s}\\ dx = \\frac{\\pi^s}{\\Gamma(s)} \\int_0^\\infty e^{-\\pi (t + \\xi^2 / t)} \\frac{t^s}{t^{1/2}} \\frac{dt}{t}. \\quad (*)")

#text("Making the change of variables ")#mi("t \\mapsto \\xi^2/t")#text(" we conclude")

#tao-math("\\displaystyle \\int_{\\mathbf R} e^{-2\\pi i x \\xi} (1+x^2)^{-s}\\ dx = \\frac{\\pi^s}{\\Gamma(s)}  \\left|\\xi\\right|^{2s-1} \\int_0^\\infty e^{-\\pi (t + \\xi^2 / t)} \\frac{t^{1-s}}{t^{1/2}} \\frac{dt}{t}.", block: false)

#text("If we compare this with (*) with ")#mi("s")#text(" replaced by ")#mi("1-s")#text(" (assuming temporarily that ")#mi("0 < s < 1")#text("), we conclude that")

#tao-math("\\displaystyle \\left|2 \\pi \\xi\\right|^{2s-1} \\int_{\\mathbf R} e^{-2\\pi i x \\xi} (1+x^2)^{s-1}\\ dx = \\frac{2^{2s-1} \\Gamma(s)}{\\Gamma(1-s)}  \\int_{\\mathbf R} e^{-2\\pi i x \\xi} (1+x^2)^{-s}\\ dx", block: false)

#text("which on inverting the Fourier transform leads to the distributional identity")

#tao-math("\\displaystyle \\left|\\frac{d}{dx}\\right|^{2s-1} (1+x^2)^{s-1} = \\frac{2^{2s-1} \\Gamma(s)}{\\Gamma(1-s)} (1+x^2)^{-s}.", block: false)

#text("This formula was only derived for ")#mi("0 < s < 1")#text(", but using analytic (or meromorphic) continuation in the space of tempered distributions it is valid for all ")#mi("s")#text(". Specialising to the case ")#mi("s = (k+2)/2")#text(" for odd ")#mi("k")#text(", we obtain")

#tao-math("\\displaystyle \\left|\\frac{d}{dx}\\right|^{k+1} (1+x^2)^{k/2} = \\frac{2^{k+1} \\Gamma(k/2 + 1)}{\\Gamma(-k/2)} (1+x^2)^{-(k+2)/2}.", block: false)

#text("As ")#mi("k")#text(" is an odd integer, ")#tao-math("\\left|\\frac{d}{dx}\\right|^{k+1} = (-1)^{(k+1)/2} \\frac{d^{k+1}}{dx^{k+1}}", block: false)#text(", while from the basic formula ")#mi("\\Gamma(s+1) = s\\Gamma(s)")#text(" one sees that")

#mi("\\displaystyle \\frac{2^{k+1} \\Gamma(k/2 + 1)}{\\Gamma(-k/2)} = (-1)^{(k+1)/2} (1 \\times 3 \\times \\dots \\times k)^2")

#text("and the claim follows.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456236")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2015")])]

#text("The above distributional identity implies also the case for even ")#mi("k")#text(" (in fact, the RHS vanishes whenever ")#mi("s = (k+2)/2")#text(" is a pole of ")#mi("\\Gamma (1-s)")#text(" – i.e. ")#mi("(k+2)/2")#text(" is a positive integer.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456270")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2015")])]

#text("It is not clear if ")#mi("f(x) = 1+ x^2")#text(" is really special. Therefore it seems natural to consider all the solutions for the general class of nonlinear(!) fractional derivatives eigenproblems")

#tao-math("\\left|\\frac {d}{d x}\\right|^{\\alpha}f(x) = \\lambda f(x)^{\\beta}", block: false)

#text("where ")#mi("\\alpha, \\beta")#text(" are real parameters, and ")#mi("\\lambda=\\lambda (\\alpha, \\beta)")#text(" is the corresponding “eigenvalue”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456291")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2015")])]

#text("Paul Nelson (private communication) has informed me that the fact that ")#tao-math("\\left|\\frac{d}{dx}\\right|^{2s-1} (1+x^2)^{s-1}", block: false)#text(" is a scalar multiple of ")#mi("(1+x^2)^{-s}")#text(" can be interpreted as a consequence of the isomorphism ")#mi("\\pi_s \\equiv \\pi_{1-s}")#text(" of the principal series representation ")#mi("\\pi_s")#text(" of ")#mi("G = PGL_2({\\bf R})")#text(" with ")#mi("\\pi_{1-s}")#text(", where one can express ")#mi("\\pi_s")#text(" as the space of (suitably nice) functions ")#mi("f: {\\bf R}^2 \\backslash \\{(0,0)\\} \\to {\\bf C}")#text(" obeying the homogeneity ")#tao-math("f(\\lambda x, \\lambda y) = \\left|\\lambda\\right|^{-s} f(x,y)", block: false)#text(" for ")#mi("\\lambda \\in {\\bf R} \\backslash 0, (x,y) \\in {\\bf R}^2 \\backslash \\{(0,0)\\}")#text(", with the usual action of ")#mi("G")#text(". One can view this principal series representation as the induced representation of the character ")#tao-math("\\begin{pmatrix} t & a \\\\ 0 & t^{-1} \\end{pmatrix} \\mapsto \\left|t\\right|^{-s}", block: false)#text(" on the Borel subgroup B of upper triangular matrices (I may have some signs incorrect here).")

#text("The homogeneous version ")#mi("(y^2+x^2)^{-s}")#text(" of ")#mi("(1+x^2)^{-s}")#text(" can be viewed as generating the spherical functions in this principal series representation, that is to say the functions invariant under the action of the maximal compact subgroup ")#mi("SO(2)")#text(". Because the two representations ")#mi("\\pi_s, \\pi_{1-s}")#text(" are isomorphic, their Whittaker models (that is to say, G-maps to the representation induced from a character of the nilpotent group ")#mi("\\begin{pmatrix} 1 & {\\bf R} \\\\ 0 & 1 \\end{pmatrix}")#text(") must agree up to scalar multiples, and in particular the two spherical functions mentioned above must become scalar multiples of each other after applying their respective Whittaker maps. On computing this map explicitly, this ends up showing that the functions ")#tao-math("\\left|\\xi\\right|^{1-s} \\int_{\\bf R} (1+x^2)^{-s} e^{2\\pi i x \\xi}\\ d\\xi", block: false)#text(" and ")#tao-math("\\left|\\xi\\right|^{s} \\int_{\\bf R} (1+x^2)^{s-1} e^{2\\pi i x \\xi}\\ d\\xi", block: false)#text(" are scalar multiples of each other, giving the claim after inverting the Fourier transform.")

#text("So it seems the “high level” explanation of the identity stems from the isomorphism between the principal series representations ")#mi("\\pi_s")#text(" and ")#mi("\\pi_{1-s}")#text(", but I don’t know of a simple way to establish this isomorphism (it seems to be a medium-length computation involving Frobenius reciprocity and Haar measure integrations). In any event, this seems to indicate that the similarity with the Riemann zeta functional equation is not entirely coincidental.")

#emph[#text("[Disclaimer: my grasp of the representation theory of Lie groups is a little shaky, and any inaccuracies in the above are due to myself and not to Nelson. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/584cd02f839ef6f42551e80d351f9a4a15cb388eea2c96194a9925dcd6248b8b-d4a31d6f5ab8c8b59637f67c32594b522a6199cfd232e67ffe727dace4462076.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456315")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2015")])]

#text("In more classical (and more elementary) terms, this is equivalent to ")#mi("K_{s-1/2}(2\\pi\\xi)=K_{1/2-s}(2\\pi\\xi)")#text(", i.e. to ")#mi("K_{\\nu}=K_{-\\nu}")#text(". See, for example, 8.432.5 in Gradshteyn-Ryzhik: Tables of integrals, series, and products (7th ed., 2007).")

#emph[#text("[Here ")#mi("K_\\nu")#text(" denotes the modified Bessel function of the second kind – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/584cd02f839ef6f42551e80d351f9a4a15cb388eea2c96194a9925dcd6248b8b-d4a31d6f5ab8c8b59637f67c32594b522a6199cfd232e67ffe727dace4462076.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456328")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2015")])]

#text("Just to clarify my point a bit, the fifth display in your Fourier-analytic proof precisely states ")#tao-math("K_{s-1/2}(2\\pi\\left|\\xi\\right|)=K_{1/2-s}(2\\pi\\left|\\xi\\right|)", block: false)#text(" in the light of 8.432.5 in Gradshteyn-Ryzhik. This symmetry has been known classically for the ")#mi("K")#text("-Bessel function, while later it has been realized to be a reflection of (or an equivalent form of) ")#mi("\\pi_s\\equiv\\pi_{1-s}")#text(". So in a sense you re-discovered all these symmetries.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456224")[#strong[#text("Solution to an elementary problem posed by T. Tao | Dirty Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2015")]

#text("[…] his most recent post, Prof. Tao shared the following elementary […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456226")[#strong[#text("And a Fields Medalist makes me feel better | College Math Teaching")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2015")]

#text("[…] latest post is about a clever observation about…calculus: in particular is is about […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6c30ac9baf2735480811247397ab2ec364b0a265782946430bc58c0c6d1a1eb-8ea7f4b7ffacf4a7c703ea19ea2051decf344686e6f35e13d81ea871aeb1627c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456253")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2015")])]

#text("Brute force induction also works: replacing ")#mi("k")#text(" by ")#mi("2l+1")#text(" one has to prove that")

#mi("\\displaystyle \\frac{d^{2l+2}}{dx^{2l+2}}(1+x^2)^{(2l+3)/2}=\\frac{(2l+1)!!^2}{(1+x^2)^{(2l+3)/2}}.")

#text("Now, by differentiating twice the left-hand side becomes")

#mi("\\displaystyle (2l+1) \\frac{d^{2l}}{dx^{2l}}(1+x^2)^{(2l-1)/2}+(2l+1)(2l-1)\\frac{d^{2l}}{dx^{2l}}x^2(1+x^2)^{(2l-3)/2}")

#mi("\\displaystyle =(2l+1)(2l)\\frac{d^{2l}}{dx^{2l}}(1+x^2)^{(2l-1)/2}-(2l+1)(2l-1)\\frac{d^{2l}}{dx^{2l}}(1+x^2)^{(2l-3)/2}.")

#text("Using the induction hypothesis twice gives")

#mi("\\displaystyle (2l+1)(2l)\\frac{(2l-1)!!^2}{(1+x^2)^{(2l+1)/2}}-(2l+1)(2l-1)\\frac{d^2}{dx^2}\\frac{(2l-3)!!^2}{(1+x^2)^{(2l-1)/2}}.")

#text("From this the proof is completed by straightforward computation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9047ad652fc5fc2c1d829d015c3e18dc310c5b106c99a379d144e8caf469a92-40df1a35526f9ed21cf26ca59b8ec6c37fd577376266170ea0340731e25af456.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christopher D. Long (@octonion)")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456282")[#strong[#text("Christopher D. Long (@octonion)")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2015")])]

#text("This is equivalent to my solution. The algebra is nicely simplified by the substitution ")#mi("x = \\tan(\\theta)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e26ce1c5111f0039f24500ca7936b7065ef90765bd4b6af2c711d2cae4a6fef-63d36d230210859f10f66039ae4b784400c91f4da6dc5746ebebbdb0ac3c8f62.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zoltan Toroczkai")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456284")[#strong[#text("Zoltan Toroczkai")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2015")])]

#text("Similar to what I provided above; I also wrote out the induction steps in detail.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d0787f36ff8adaaae2bf792d89bbd3946b1e7047e133f9a57e68c5c66436b1b-3457e7638e41a7fc17ccffbbb49839d30462270a5143f6b714c8535ead43712f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456304")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2015")])]

#text("Above one can find my direct induction proof, which is bit simpler and uses a more compact notation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456264")[#strong[#text("Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2015")]

#strong[#text("How can one prove Terence Tao’s cute differentiation identity?")]

#text("X= sinh y (1 + x^2)^1/2 = cosh y = dx/dy I’ve now spotted that this solution has already been posted on the original web site. ")#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/")[#text("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/")]#text(" So I leave you to read it there")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9047ad652fc5fc2c1d829d015c3e18dc310c5b106c99a379d144e8caf469a92-40df1a35526f9ed21cf26ca59b8ec6c37fd577376266170ea0340731e25af456.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christopher D. Long (@octonion)")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456280")[#strong[#text("Christopher D. Long (@octonion)")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2015")])]

#text("The standard substitution ")#mi("x=\\tan(\\theta)")#text(" reduces this to differentiating ")#mi("\\sec(\\theta)^n")#text(" ")#mi("n+1")#text(" times. After two differentiations we get ")#mi("n(n-1)\\sec(\\theta)^{n-2}-n(n-2)\\sec(\\theta)^{n-4}")#text(". By induction, we end up with ")#mi("C_n n(n-1)\\cos(\\theta)^n - C_{n-2}n(n-2)(\\cos(\\theta)^{n-2})^{\\prime\\prime}")#text(", which simplifies to ")#mi("n^2(n-2)^2C_{n-4}\\cos(\\theta)^{n+2}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76332eb6d2a297d571c4683ff0fcbe5d533e393424c187997beae9f0582fe36a-5583331e9fbe4356c62889ae2161f3bc017e3d16a3c509b67abec273ee6ac70e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mr Math")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456298")[#strong[#text("Mr Math")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2015")])]

#text("Mathematics is so beautiful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33675bdffeebfc8f839b850628b1fd090fe0a8237d0c07127ffeb822a9db463b-3eec23fb055d9e95342e531e9aadaca3db588e655bbfd8644d07fa941030383d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shalosh B. Ekhad and Doron Zeilberger")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456305")[#strong[#text("Shalosh B. Ekhad and Doron Zeilberger")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2015")])]

#text("If you go to Maple, and download the Maple package")

#link("http://www.math.rutgers.edu/~zeilberg/tokhniot/EKHAD")[#text("http://www.math.rutgers.edu/~zeilberg/tokhniot/EKHAD")]

#text("and you type:")

#text("lprint(AZd((2*k)!*(1+z^2)^(k-1/2)/(z-x)^(2*k+1) ,z,k,K)[1]);")

#text("you would get, after one nano-second")

#text("-(2*k+1)^2+(1+x^2)*K")

#text("which means that the left side (with k replaced by 2*k-1), let’s call it A(k),")#linebreak()#text(" satisfies the first-order recurrence")

#text("-(2*k+1)^2*A(k)+(1+x^2)*A(k+1)=0,")#linebreak()#text(" that together with the trivial value for A(0) implies the original statement.")#linebreak()#text(" For a verbose version, type:")#linebreak()#text(" AZpapd((2*k)!*(1+z^2)^(k-1/2)/(z-x)^(2*k+1) ,z,k,K);")

#text("Note that the proof is fully rigorous. Procedure AZd is an implementaion")#linebreak()#text(" of the Almkvist-Zeilberger algorithm, part of WZ theory.")

#text("k does not have to be an integer, and the recurrence is valid for all k,")#linebreak()#text(" hence one can get Gamma functions.")

#text("Of course, AZd can give recurrences for ANY expression of the form")

#text("D_x^(k) ( P(x)^k*Q(x)),")

#text("for a very wide class of P(x) and Q(x), but, alas, the recurrence is")#linebreak()#text(" usually not first-order. All the Rodriguez formulas for the classical")#linebreak()#text(" orthogonal polynomials yield the respective three-term recurrences.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456314")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2015")])]

#text("Some miscellaneous remarks on the identity.")

#text("I posted a related question on MathOverflow at ")#link("http://mathoverflow.net/questions/208341/is-this-differential-identity-known")[#text("http://mathoverflow.net/questions/208341/is-this-differential-identity-known")]#text(" where it was pointed out by Carlo Beenakker that the identity follows from the Rodrigues formula for the Gegenbauer polynomials ")#mi("C^{(\\alpha)}_n(x)")#text(", together with the fact that ")#mi("C^{(-n/2)}_n = 1")#text(" when n is even.")

#text("A reformulation of the identity (in the more general Gamma function form) is as a two-dimensional identity")

#tao-math("\\displaystyle \\left|\\frac{\\partial}{\\partial x_1}\\right|^{2s-1} \\left|x\\right|^{2s-2} = \\frac{2^{2s-1} \\Gamma(s)}{\\Gamma(1-s)} x_2^{2s-1} \\left|x\\right|^{-2s}", block: false)

#text("where ")#mi("x = (x_1,x_2) \\in {\\mathbf R}")#text(". Amusingly, this identity is essentially its own Fourier transform!")

#text("Another amusing consequence of the identity is that the function ")#mi("(1+x^2)^{k/2}")#text(" is “very convex” on the positive real axis in the sense that the first k+1 derivatives are all non-negative there. (This follows from repeated integration of the differentiation identity together with a Taylor expansion at the origin.) I don’t know of any other way to prove this “convexity” without going through the differential identity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456319")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2015")])]

#text("Is it possible to reformulate the two-dimensional identity on the sphere ")#mi("S^2")#text("? (perhaps by spherical harmonics?)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456503")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2015")])]

#text("Probably a shot in the dark. Notice that the equation for k = n has, on the right side, a function of the left side of the equation for k = n+2. Inductively, test that k = 1 works. Suppose k = n works, then reciprocate and multiply by the double factorial squared. Then take the “k+2″nd derivative of the resulting equation. Looking to simplify it to the equation where k = n + 2.")

#text("I tried it for a half an hour and didn’t get anywhere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4e5b01b0b7059dae1bd459fad4308185c02c0a62ae1b6208aa380e21578a7e6-fb63ef724dcdc531a24e4646f2d9f657a00ee485b6bcd21899fd2b3a6ff79306.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of antonio")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456504")[#strong[#text("antonio")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2015")])]

#text("You have forgotten the chain rule")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456712")[#strong[#text("Cathy O’Neil on Trig |")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2015")]

#text("[…] A “cute” differentiation identity […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed0d4197a92daf72c3ea741389ca7a4a32c5f6d0355b059c74de293e3c8e270b-b1a881bddbb01b7b4ca1cd344416c1d5b14a71725d23f1020c0dd1ec2e1fbc22.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ubik")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456720")[#strong[#text("Ubik")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2015")])]

#text("Here is another answer that is not really connected to any other existing piece of beautiful mathematics…")

#text("The function ")#mi("f_\\alpha(x):=(1+x^2)^{\\alpha/2}")#text(" is a solution of the first order ODE :")

#mi("(1+x^2)f^{\\prime}_\\alpha(x)-\\alpha x f_\\alpha(x)=0")

#text("If we differentiate ")#mi("k")#text("-times this equation (using the Leibniz’s Rule) we get")

#mi("(\\heartsuit)\\,\\,\\,\\, (1+x^2)\\frac{d^{k+1}}{dx^{k+1}}f_\\alpha(x)+x(2k-\\alpha)\\frac{d^{k}}{dx^{k}}f_\\alpha(x)+k(k-1-\\alpha)\\frac{d^{k-1}}{dx^{k-1}}f_\\alpha(x)=0.")

#text("If ")#mi("\\alpha=2N+1")#text(" and ")#mi("k=2N+2")#text(", we obtain that ")#mi("u(x)=\\frac{d^{2N+2}}{dx^{2N+2}}(1+x^2)^{N+\\frac12}")#text(" satisfies the ODE :")

#mi("(1+x^2) u^{\\prime}(x)+x(2N+3) u(x)=0.")#linebreak()#text(" Hence")

#mi("u(x)=\\frac{u(0)}{ (1+x^2)^{N+\\frac32}}.")

#text("It remains to compute ")#mi("u(0)")#text(" but the equation ")#mi("(\\heartsuit)")#text(" gives a recurrence formula for the derivative at ")#mi("x=0")#text(" of ")#mi("f_\\alpha")#text(" :")#linebreak()#text(" ")#mi("\\frac{d^{2\\ell+2}}{dx^{2\\ell+2}}f_\\alpha(0)+(2\\ell+1)(2\\ell-\\alpha)\\frac{d^{\\ell-1}}{dx^{\\ell-1}}f_\\alpha(0)=0.")#linebreak()#text(" So that")#linebreak()#text(" ")#mi("\\frac{d^{2N+2}}{dx^{2N+2}}f_\\alpha(0)=\\prod_{\\ell=0}^{N} (2\\ell+1)(\\alpha-2\\ell).")#linebreak()#text(" For ")#mi("\\alpha=2N+1")#text(" we get")#linebreak()#text(" ")#mi("u(0)=\\left(1\\times 3\\dots\\times (2N+1)\\right)^2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/016ab0b8029e77912a49a06d28a7af720c084fa5e6af8e9322353f57725e7eab-231654c8620d70ed61f2f3b894fc0e5cd68489d9f82610671d584a06cd3ceb96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-456864")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2015")])]

#text("This is a good topic for classes. In the post, you said “Here’s a cute identity I discovered by accident recently”. Could you please mention a little about the context that motivated matter ? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-457326")[#strong[#text("A differentiation identity — Thanks to Prof Terence Tao « Mathematics Hothouse")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2015")]

#text("[…] ")#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity")[#text("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-458353")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2015")])]

#text("A trivial generalization of the given identity is obtained by scaling the variable ")#mi("x")#text(" to ")#mi("\\sqrt{\\frac{a}{b}} x")#text(" where ")#mi("a")#text(" and ")#mi("b")#text(" are independent of ")#mi("x")

#text("The result so obtained is")

#mi("\\displaystyle \\frac{d^{2k}}{dx^{2k}} \\left(ax^{2}+b\\right)^{\\frac{\\left(2k-1\\right)}{2}}=\\frac{\\left(\\left(2k-1\\right)!!\\right)^{2}a^{k}b^{k}}{\\left(ax^{2}+b\\right)^{\\frac{\\left(2k+1\\right)}{2}}}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9725e3506cef426a645040ae12314a0645285460330c0cd77b1b65741894df0f-4bc1961cf36b11d33734a9a91020414558f0d380d4ac3ae9106545a84813d023.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jun")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-462436")[#strong[#text("Jun")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2015")])]

#text("This paper of Milnor: ")#link("http://people.ucsc.edu/~lewis/Math208/hairyball.pdf")[#text("http://people.ucsc.edu/~lewis/Math208/hairyball.pdf")]#text(" remind me of this post, though I don’t know if there are any connections behind.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a68e4f9f5b35d6a42ebc2624bacf9d4900c822977e0b8d4fbb23ab3091732e84-0c30fba8f781fb4e46f6e5c83ac492c0a7f171c49ef6d764e3248a336b96dec4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paolo D'Isanto")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-497817")[#strong[#text("Paolo D'Isanto")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2018")])]

#text("Dear Professor Tao,")

#text("is this Differentiation Identity related with the ")#mi("k")#text("-th moment of the Wigner’s Semicircle Law")

#mi("\\mathop{\\int}\\limits_{-1}^{+1}{\\frac{2}{k}t^k\\sqrt{1-t^2}dt}")

#text("setting ")#mi("t=ix")#text("? (Or, more generally, can we see this problem as equivalent to the problem to find a distribution ")#mi("f_X=f_X(x)")#text(" whose ")#mi("k")#text("-th moment, seen as the ")#mi("k")#text("-th derivative, in ")#mi("t=0")#text(", of its moment generating function")

#mi("M_X(t)\\equiv\\mathbb E e^{tX}=\\mathop{\\int}\\limits_{-\\infty}^{+\\infty}{e^{tx}f_X(x)dx}")#text(",")

#text("are vanishing when ")#mi("k")#text(" is even?).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb07e354c605793eccd4a1e6f35d9277d5bcf9a27556b330e57f37e715c5b27e-64a5642f9b952f9202b9d15c562e0ab464a7a3230df680d4ba706999c6123961.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A Differentiation Identity That I Came Up With – Trey's blog")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-535179")[#strong[#text("A Differentiation Identity That I Came Up With – Trey's blog")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2020")])]

#text("[…] Yesterday night, Terrence Tao posted a differentiation identity that he had discovered recently, and claimed a three-line proof. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/05/30/a-differentiation-identity/#comment-645144")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2022")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2022/06/16/a-differentiation-identity/")[#text("Aditya Guha Roy's weblog")]#text(".")
]
