// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:36:09.112171+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254B, Notes 2: Roth’s theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254B, Notes 2: Roth’s theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 April 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/")[#text("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("We now give a basic application of Fourier analysis to the problem of counting additive patterns in sets, namely the following famous theorem of Roth:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Roth’s theorem)")]#text(" ")#metadata(none) <tao-a5822a8c8b00deb97c29>#text(" Let ")#mi("{A}")#text(" be a subset of the integers ")#mi("{{\\bf Z}}")#text(" whose upper density")

#align(center)[#tao-fit-display[#tao-math("\\overline{\\delta}(A) := \\limsup_{N \\rightarrow \\infty} \\frac{\\left|A \\cap [-N,N]\\right|}{2N+1}", block: true)]]

#text("is positive. Then ")#mi("{A}")#text(" contains infinitely many arithmetic progressions ")#mi("{a, a+r, a+2r}")#text(" of length three, with ")#mi("{a \\in {\\bf Z}}")#text(" and ")#mi("{r>0}")#text(".")
]

#text("This is the first non-trivial case of ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("Szemerédi’s theorem")]#text(", which is the same assertion but with length three arithmetic progressions replaced by progressions of length ")#mi("{k}")#text(" for any ")#mi("{k}")#text(".")#linebreak()#text(" As it turns out, one can prove Roth’s theorem by an application of linear Fourier analysis – by comparing the set ")#mi("{A}")#text(" (or more precisely, the indicator function ")#mi("{1_A}")#text(" of that set, or of pieces of that set) against linear characters ")#mi("{n \\mapsto e(\\alpha n)}")#text(" for various frequencies ")#mi("{\\alpha \\in {\\bf R}/{\\bf Z}}")#text(". There are two extreme cases to consider (which are model examples of a more general dichotomy between structure and randomness). One is when ")#mi("{A}")#text(" is aligned up almost completely with one of these linear characters, for instance by being a ")#emph[#text("Bohr set")]#text(" of the form")

#align(center)[#tao-fit-display[#tao-math("\\{ n \\in {\\bf Z}: \\left\\| \\alpha n - \\theta \\right\\|_{{\\bf R}/{\\bf Z}} < \\varepsilon \\}", block: true)]]

#text("or more generally of the form")

#align(center)[#tao-fit-display[#mitex("\\{ n \\in {\\bf Z}: \\alpha n \\in U \\}")]]

#text("for some multi-dimensional frequency ")#mi("{\\alpha \\in {\\bf T}^d}")#text(" and some open set ")#mi("{U}")#text(". In this case, arithmetic progressions can be located using the equidistribution theory of the previous set of notes. At the other extreme, one has ")#emph[#text("Fourier-uniform")]#text(" or ")#emph[#text("Fourier-pseudorandom sets")]#text(", whose correlation with any linear character is negligible. In this case, arithmetic progressions can be produced in abundance via a Fourier-analytic calculation.")#linebreak()#text(" To handle the general case, one must somehow synthesise together the argument that deals with the structured case with the argument that deals with the random case. There are several known ways to do this, but they can be basically classified into two general methods, namely the ")#emph[#text("density increment argument")]#text(" (or ")#mi("{L^\\infty}")#text(" increment argument) and the ")#emph[#text("energy increment argument")]#text(" (or ")#mi("{L^2}")#text(" increment argument).")#linebreak()#text(" The idea behind the density increment argument is to introduce a dichotomy: either the object ")#mi("{A}")#text(" being studied is pseudorandom (in which case one is done), or else one can use the theory of the structured objects to locate a sub-object of significantly higher “density” than the original object. As the density cannot exceed one, one should thus be done after a finite number of iterations of this dichotomy. This argument was introduced by Roth in ")#link("http://www.ams.org/mathscinet-getitem?mr=46374")[#text("his original proof")]#text(" of the above theorem.")#linebreak()#text(" The idea behind the energy increment argument is instead to decompose the original object ")#mi("{A}")#text(" into two pieces (and, sometimes, a small additional error term): a ")#emph[#text("structured component")]#text(" that captures all the structured objects that have significant correlation with ")#mi("{A}")#text(", and a ")#emph[#text("pseudorandom component")]#text(" which has no significant correlation with any structured object. This decomposition usually proceeds by trying to maximise the “energy” (or ")#mi("{L^2}")#text(" norm) of the structured component, or dually by trying to minimise the energy of the residual between the original object and the structured object. This argument appears for instance in the proof of the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(" (which, not coincidentally, can also be used to prove Roth’s theorem), and is also implicit in the ergodic theory approach to such problems (through the machinery of conditional expectation relative to a factor, which is a type of orthogonal projection, the existence of which is usually established via an energy increment argument). However, one can also deploy the energy increment argument in the Fourier analytic setting, to give an alternate Fourier-analytic proof of Roth’s theorem that differs in some ways from the density increment proof.")#linebreak()#text(" In these notes we give both two Fourier-analytic proofs of Roth’s theorem, one proceeding via the density increment argument, and the other by the energy increment argument. As it turns out, both of these arguments extend to establish Szemerédi’s theorem, and more generally in counting other types of patterns, but this is non-trivial (requiring some sort of ")#emph[#text("inverse conjecture")]#text(" for the Gowers uniformity norms in both cases); we will discuss this further in later notes.")#linebreak()#text(" ")#metadata(none) <tao-4ac46172f41ae2efb425>

#heading(level: 1)[#strong[#text(" — 1. The density increment argument — ")]]

#text("We begin with the density increment argument. We first rephrase Roth’s theorem in a finitary form:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Roth’s theorem, again)")]#text(" ")#metadata(none) <tao-f662393c6c381fba5956>#text(" For every ")#mi("{\\delta > 0}")#text(", there exists an ")#mi("{N_0 = N_0(\\delta) > 0}")#text(", such that for every ")#mi("{N \\geq N_0}")#text(", and every ")#mi("{A \\subset [N]}")#text(" with ")#tao-math("{\\left|A\\right| \\geq \\delta N}", block: false)#text(", ")#mi("{A}")#text(" contains an arithmetic progression of length three.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Show that Theorem ")#link(<tao-a5822a8c8b00deb97c29>)[#text("1")]#text(" and Theorem ")#link(<tao-f662393c6c381fba5956>)[#text("2")]#text(" are equivalent.")
]

#text("We prove Theorem ")#link(<tao-f662393c6c381fba5956>)[#text("2")]#text(" by a downward induction on the density parameter ")#mi("{\\delta}")#text(". Let ")#mi("{P(\\delta)}")#text(" denote the proposition that Theorem ")#link(<tao-f662393c6c381fba5956>)[#text("2")]#text(" holds for that value of ")#mi("{\\delta}")#text(" (i.e. for sufficiently large ")#mi("{N}")#text(" and all ")#mi("{A \\subset [N]}")#text(" with ")#tao-math("{\\left|A\\right| \\geq \\delta N}", block: false)#text(", ")#mi("{A}")#text(" contains an arithmetic progression of length three). Our objective is to show that ")#mi("{P(\\delta)}")#text(" holds for all ")#mi("{\\delta > 0}")#text(".")#linebreak()#text(" Clearly, ")#mi("{P(\\delta)}")#text(" is (vacuously) true for ")#mi("{\\delta > 1}")#text(" (and trivially true for ")#mi("{\\delta \\geq 1}")#text("). It is also monotone in the sense that if ")#mi("{P(\\delta)}")#text(" holds for some ")#mi("{\\delta}")#text(", then ")#mi("{P(\\delta^{\\prime})}")#text(" holds for all ")#mi("{\\delta^{\\prime}>\\delta}")#text(". To downwardly induct on ")#mi("{\\delta}")#text(", we will prove the following dichotomy:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (Lack of progressions implies density increment)")]#text(" ")#metadata(none) <tao-8fbfe0254901865407c8>#text(" Let ")#mi("{\\delta > 0}")#text(", let ")#mi("{N}")#text(" be sufficiently large depending on ")#mi("{\\delta}")#text(", and let ")#mi("{A \\subset [N]}")#text(" be such that ")#tao-math("{\\left|A\\right| \\geq \\delta N}", block: false)#text(". Then one of the following holds:")

#list(
[#mi("{A}")#text(" contains an arithmetic progression of length three; or")],
[#text("there exists a subprogression ")#mi("{P}")#text(" of ")#mi("{[N]}")#text(" of length at least ")#mi("{N^{\\prime}}")#text(" such that ")#tao-math("{\\left|A \\cap P\\right| \\geq (\\delta + c(\\delta)) \\left|P\\right|}", block: false)#text(", where ")#mi("{N^{\\prime} = N^{\\prime}(N)}")#text(" goes to infinity as ")#mi("{N \\rightarrow \\infty}")#text(", and ")#mi("{c(\\delta) > 0}")#text(" is bounded away from zero whenever ")#mi("{\\delta}")#text(" is bounded away from zero.")]
)
]

#text("Let us see why Proposition ")#link(<tao-8fbfe0254901865407c8>)[#text("4")]#text(" implies Theorem ")#link(<tao-f662393c6c381fba5956>)[#text("2")]#text(". It is slightly more convenient to use a “well-ordering principle” argument rather than an induction argument, though of course the two approaches are equivalent. Let ")#mi("{\\delta_*}")#text(" be the infimum of all ")#mi("{\\delta}")#text(" for which ")#mi("{P(\\delta)}")#text(" holds, thus ")#mi("{0 \\leq \\delta_* \\leq 1}")#text(". If ")#mi("{\\delta_*=0}")#text(" then we are done, so suppose that ")#mi("{\\delta_*}")#text(" is non-zero. Then for any ")#mi("{\\varepsilon > 0}")#text(", ")#mi("{P(\\delta_*-\\varepsilon)}")#text(" is false, thus there exist arbitrarily large ")#mi("{N}")#text(" and ")#mi("{A \\subset [N]}")#text(" with ")#tao-math("{\\left|A\\right| \\geq (\\delta_*-\\varepsilon)N}", block: false)#text(" with no progressions of length three. By Proposition ")#link(<tao-8fbfe0254901865407c8>)[#text("4")]#text(", we can thus find a subprogression ")#mi("{P}")#text(" of ")#mi("{N}")#text(" of length at least ")#mi("{N^{\\prime}}")#text(" with ")#tao-math("{\\left|A \\cap P\\right| \\geq (\\delta_*-\\varepsilon + c(\\delta_*-\\varepsilon))\\left|P\\right|}", block: false)#text("; if ")#mi("{\\varepsilon}")#text(" is small enough, this implies that ")#tao-math("{\\left|A \\cap P\\right| \\geq (\\delta_*+\\varepsilon) \\left|P\\right|}", block: false)#text(". We then use an affine transformation to map ")#mi("{P}")#text(" to ")#mi("{[N^{\\prime}]}")#text(" (noting crucially that the property of having no arithmetic progressions of a given length is preserved by affine transformations). As ")#mi("{N}")#text(" can be arbitrarily large, ")#mi("{N^{\\prime}}")#text(" can be arbitrarily large also. Since ")#mi("{P(\\delta_*+\\varepsilon)}")#text(" is true, we see that ")#mi("{A \\cap P}")#text(" contains an arithmetic progression of length three, hence ")#mi("{A}")#text(" does also; which gives the desired contradiction.")#linebreak()#text(" It remains to prove Proposition ")#link(<tao-8fbfe0254901865407c8>)[#text("4")]#text(". There are two main steps. The first relies heavily on the fact that the progressions only have length three, and is proven via Fourier analysis:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Lack of progressions implies correlation with a linear phase)")]#text(" ")#metadata(none) <tao-61c08f912501b69e634b>#text(" Let ")#mi("{\\delta > 0}")#text(", let ")#mi("{N}")#text(" be sufficiently large depending on ")#mi("{\\delta}")#text(", let ")#mi("{A \\subset [N]}")#text(" be such that ")#tao-math("{\\left|A\\right| = \\delta^{\\prime} N}", block: false)#text(" for some ")#mi("{\\delta^{\\prime} \\geq \\delta}")#text(", with ")#mi("{A}")#text(" containing no arithmetic progressions of length three. Then there exists ")#mi("{\\alpha \\in {\\bf R}/{\\bf Z}}")#text(" such that ")#tao-math("{\\left|\\mathop{\\bf E}_{n \\in [N]} (1_A(n) - \\delta^{\\prime}) e(-\\alpha n)\\right| \\gg \\delta^2}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" In order to use Fourier analysis, it will be convenient to embed ")#mi("{[N]}")#text(" inside a cyclic group ")#mi("{{\\bf Z}/N^{\\prime}{\\bf Z}}")#text(", where ")#mi("{N^{\\prime}}")#text(" is equal to (say) ")#mi("{2N+1}")#text("; the exact choice here is only of minor importance, though it will be convenient to take ")#mi("{N^{\\prime}}")#text(" to be odd. We introduce the trilinear form")

#align(center)[#tao-fit-display[#mitex("\\Lambda(f,g,h) := \\mathop{\\bf E}_{n,r \\in {\\bf Z}/N^{\\prime}{\\bf Z}} f(n) g(n+r) h(n+2r)")]]

#text("for any functions ")#mi("{f,g,h: {\\bf Z}/N^{\\prime}{\\bf Z} \\rightarrow {\\bf C}}")#text("; we then observe that the quantity")

#align(center)[#tao-fit-display[#mitex("\\Lambda(1_A,1_A,1_A) = \\mathop{\\bf E}_{n,r \\in {\\bf Z}/N^{\\prime}{\\bf Z}} 1_A(n) 1_A(n+r) 1_A(n+2r)")]]

#text("(extending ")#mi("{1_A}")#text(" by zero outside of ")#mi("{[N]}")#text(") is equal to the number of arithmetic progressions ")#mi("{n,n+r,n+2r}")#text(" in ")#mi("{A}")#text(" (counting the degenerate progressions in which ")#mi("{r=0}")#text(", and also allowing for ")#mi("{r}")#text(" to be negative), divided by the normalising factor of ")#mi("{(N^{\\prime})^2}")#text(". On the other hand, by hypothesis, ")#mi("{A}")#text(" contains no non-degenerate arithmetic progressions of length three, and clearly has ")#tao-math("{\\left|A\\right| \\leq N}", block: false)#text(" degenerate progressions; thus we have ")#metadata(none) <tao-55afeaca27d014d306d6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\Lambda(1_A,1_A,1_A) \\ll 1/N.")]]

#text("On the other hand, from the Fourier inversion formula on the cyclic group ")#mi("{{\\bf Z}/N^{\\prime}{\\bf Z}}")#text(" we may write")

#align(center)[#tao-fit-display[#mitex("f(n) = \\sum_{\\alpha \\in \\frac{1}{N^{\\prime}}{\\bf Z} / {\\bf Z}} \\hat f(\\alpha) e(\\alpha n)")]]

#text("for any function ")#mi("{f: {\\bf Z}/N^{\\prime}{\\bf Z} \\rightarrow {\\bf C}}")#text(", where ")#mi("{\\hat f(\\alpha)}")#text(" are the Fourier coefficients")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\alpha) := \\mathop{\\bf E}_{n \\in {\\bf Z}/N^{\\prime}{\\bf Z}} f(n) e(-\\alpha n).")]]

#text("We may thus write ")#mi("{\\Lambda(f,g,h)}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\alpha_1,\\alpha_2,\\alpha_3 \\in \\frac{1}{N^{\\prime}}{\\bf Z}/{\\bf Z}} \\hat f(\\alpha_1) \\hat g(\\alpha_2) \\hat h(\\alpha_3)")]]

#metadata(none) <tao-390b4dd407b6d3d6271a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\mathop{\\bf E}_{n,r \\in {\\bf Z}/N^{\\prime}{\\bf Z}} e( \\alpha_1 n + \\alpha_2 (n+r) + \\alpha_3 (n+2r) ).")]]

#text("Now observe that we have the identity")

#align(center)[#tao-fit-display[#mitex("\\alpha n - 2 \\alpha(n+r) + \\alpha(n+2r)=0,")]]

#text("so the phase ")#mi("{\\alpha_1 n + \\alpha_2 (n+r) + \\alpha_3 (n+2r)}")#text(" is trivial whenever ")#mi("{(\\alpha_1,\\alpha_2,\\alpha_3)}")#text(" is of the form ")#mi("{(\\alpha,-2\\alpha,\\alpha)}")#text(", and so the expectation in ")#link(<tao-390b4dd407b6d3d6271a>)[#text("(2)")]#text(" is equal to ")#mi("{1}")#text(". Conversely, if ")#mi("{(\\alpha_1,\\alpha_2,\\alpha_3)}")#text(" is not of this form, then the phase is non-trivial, and from Fourier analysis we conclude that the expectation in ")#link(<tao-390b4dd407b6d3d6271a>)[#text("(2)")]#text(" vanishes. We conclude that the left-hand side of ")#link(<tao-390b4dd407b6d3d6271a>)[#text("(2)")]#text(" can be expressed as")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\alpha \\in \\frac{1}{N^{\\prime}}{\\bf Z} / {\\bf Z}} \\hat f(\\alpha) \\hat g(-2\\alpha) \\hat h(\\alpha).")]]

#text("Now using Plancherel’s theorem we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\alpha \\in \\frac{1}{N^{\\prime}}{\\bf Z} / {\\bf Z}} \\left|\\hat f(\\alpha)\\right|^2 = \\left\\| f\\right\\|_{L^2({\\bf Z}/N^{\\prime}{\\bf Z})}^2", block: true)]]

#text("(using normalised counting measure). Using this and Hölder’s inequality (and the fact that ")#mi("{N^{\\prime}}")#text(" is odd), we obtain the bounds ")#metadata(none) <tao-ba6775c0dca0c168769c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|\\Lambda(f,g,h)\\right| \\leq \\left\\|f\\right\\|_{L^2({\\bf Z}/N^{\\prime}{\\bf Z})} \\left\\|g\\right\\|_{L^2({\\bf Z}/N^{\\prime}{\\bf Z})} \\sup_{\\xi \\in {\\bf Z}/N^{\\prime}{\\bf Z}} \\left|\\hat h(\\xi)\\right|", block: true)]]

#text("and similarly for permutations of ")#mi("{f,g,h}")#text(" on the right-hand side.")#linebreak()#text(" We could apply this directly to ")#mi("{\\Lambda(1_A,1_A,1_A)}")#text(", but this is not useful, since we seek a ")#emph[#text("lower")]#text(" bound on this quantity rather than an upper bound. To get such a lower bound, we split ")#mi("{1_A = \\delta^{\\prime} 1_{[N]} + f}")#text(", where ")#mi("{f := 1_A - \\delta^{\\prime} 1_{[N]}}")#text(" is the mean zero portion of ")#mi("{1_A}")#text(", and use trilinearity to split ")#mi("{\\Lambda(1_A,1_A,1_A)}")#text(" into a main term ")#mi("{\\Lambda(\\delta^{\\prime} 1_{[N]}, \\delta^{\\prime} 1_{[N]}, \\delta^{\\prime} 1_{[N]})}")#text(", plus seven other error terms involving ")#mi("{1_A = \\delta^{\\prime} 1_{[N]}}")#text(" and ")#mi("{f}")#text(", with each error term involving at least one copy of ")#mi("{f}")#text(". The main term can be computed explicitly as")

#align(center)[#tao-fit-display[#mitex("\\Lambda(\\delta^{\\prime} 1_{[N]}, \\delta^{\\prime} 1_{[N]}, \\delta^{\\prime} 1_{[N]}) \\gg \\delta^3.")]]

#text("Comparing this with ")#link(<tao-55afeaca27d014d306d6>)[#text("(1)")]#text(", we conclude that one of the error terms must have magnitude ")#mi("{\\gg \\delta^3}")#text(" also. For sake of concreteness, let us say that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Lambda(f, \\delta^{\\prime} 1_{[N]}, f)\\right| \\gg \\delta^3;", block: true)]]

#text("the other cases are similar.")#linebreak()#text(" From the triangle inequality we see that ")#mi("{f, \\delta^{\\prime} 1_{[N]}}")#text(" have an ")#mi("{L^2({\\bf Z}/N^{\\prime}{\\bf Z})}")#text(" norm of ")#mi("{O( \\delta^{1/2} )}")#text(", and so from ")#link(<tao-ba6775c0dca0c168769c>)[#text("(3)")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Lambda(f, \\delta^{\\prime} 1_{[N]}, f)\\right| \\ll \\delta \\sup_{\\xi \\in {\\bf Z}/N^{\\prime}{\\bf Z}} \\left|\\hat f(\\xi)\\right|,", block: true)]]

#text("and so we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\hat f(\\xi)\\right| \\gg \\delta^2", block: true)]]

#text("for some ")#mi("{\\xi \\in {\\bf Z}/N^{\\prime}{\\bf Z}}")#text(". (Similarly for other error terms, though sometimes onewill need a permutation of ")#link(<tao-ba6775c0dca0c168769c>)[#text("(3)")]#text(" instead of ")#link(<tao-ba6775c0dca0c168769c>)[#text("(3)")]#text(" itself.) The claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" The above argument relied heavily on the fact that there was only a one-parameter family of linear relations between ")#mi("{n, n+r, n+2r}")#text(". The same argument does not work directly for finding arithmetic progressions of length longer than three; we return to this point in later notes.")
]

#text("The second step converts correlation with a linear character into a density increment on a subprogression:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (Fragmenting a linear character into progressions)")]#text(" ")#metadata(none) <tao-7587669ca42e19e8a9aa>#text(" Let ")#mi("{N \\geq 1}")#text(", let ")#mi("{\\varepsilon > 0}")#text(", and let ")#mi("{\\phi(n) := e(\\alpha n)}")#text(" be a linear phase. Then there exists ")#mi("{N^{\\prime} = N^{\\prime}(N,\\varepsilon)}")#text(" which goes to infinity as ")#mi("{N \\rightarrow \\infty}")#text(" for fixed ")#mi("{\\varepsilon}")#text(", and a partition")

#align(center)[#tao-fit-display[#mitex("[N] = \\bigcup_{j=1}^J P_j \\cup E")]]

#text("of ")#mi("{[N]}")#text(" into arithmetic progressions ")#mi("{P_j}")#text(" of length at least ")#mi("{N^{\\prime}}")#text(", together with an error term ")#mi("{E}")#text(" of cardinality at most ")#mi("{O(\\varepsilon N)}")#text(", such that ")#mi("{\\phi}")#text(" fluctuates by at most ")#mi("{O(\\varepsilon)}")#text(" on each progression ")#mi("{P_j}")#text(" (i.e. ")#tao-math("{\\left|\\phi(x)-\\phi(y)\\right| \\ll \\varepsilon}", block: false)#text(" whenever ")#mi("{x,y \\in P_j}")#text(").")
]

#emph[#text("Proof:")]#text(" We may assume that ")#mi("{N}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon}")#text(", as the claim is trivial otherwise (just set ")#mi("{N^{\\prime}=1}")#text(").")#linebreak()#text(" Fix ")#mi("{\\varepsilon}")#text(", and let ")#mi("{N^{\\prime}}")#text(" be a slowly growing function of ")#mi("{N}")#text(" to be chosen later. By using recurrence for the linear phase ")#mi("{n \\mapsto \\alpha n}")#text(", we can find a shift ")#mi("{h \\geq 1}")#text(" of size ")#mi("{h = O_{N^{\\prime},\\varepsilon}(1)}")#text(" such that ")#tao-math("{\\left\\| \\alpha h \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\varepsilon/N^{\\prime}}", block: false)#text(". We then partition ")#mi("{[N]}")#text(" into ")#mi("{h}")#text(" arithmetic progressions of spacing ")#mi("{h}")#text(", and then partition each of those progressions in turn into subprogressions ")#mi("{P_j}")#text(" of spacing ")#mi("{h}")#text(" and length ")#mi("{N^{\\prime}}")#text(", plus an error of cardinality at most ")#mi("{N^{\\prime}}")#text(", leading to an error set ")#mi("{E}")#text(" of cardinality at most ")#mi("{h N^{\\prime} = O_{N^{\\prime},\\varepsilon}(1)}")#text(". On each of the ")#mi("{P_j}")#text(", ")#mi("{\\alpha n}")#text(" fluctuates by at most ")#mi("{\\varepsilon}")#text(". The claim then follows by choosing ")#mi("{N^{\\prime}}")#text(" to be a sufficiently slowly growing function of ")#mi("{N}")#text(". ")#mi("\\Box")#linebreak()#text(" Now we can prove Proposition ")#link(<tao-8fbfe0254901865407c8>)[#text("4")]#text(" (and thus Roth’s theorem). Let ")#mi("{N, \\delta, \\delta^{\\prime}, A}")#text(" be as in Proposition ")#link(<tao-8fbfe0254901865407c8>)[#text("4")]#text(". By Proposition ")#link(<tao-61c08f912501b69e634b>)[#text("5")]#text(" (if ")#mi("{N}")#text(" is large enough), we can find ")#mi("{\\alpha}")#text(" for which")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n \\in [N]} (1_A(n) - \\delta^{\\prime}) e(-\\alpha n)\\right| \\gg \\delta^2.", block: true)]]

#text("We now let ")#mi("{\\varepsilon > 0}")#text(" be a small quantity depending on ")#mi("{\\delta}")#text(" to be chosen later (actually it turns out that we can take ")#mi("{\\varepsilon}")#text(" to be a small multiple of ")#mi("{\\delta^2}")#text(") and apply Proposition ")#link(<tao-7587669ca42e19e8a9aa>)[#text("7")]#text(" to decompose ")#mi("{[N]}")#text(" into progressions ")#mi("{P_1,\\ldots,P_J}")#text(" and an error term ")#mi("{E}")#text(" with the stated properties. Then we have")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} (1_A(n) - \\delta^{\\prime}) e(-\\alpha n) = \\frac{1}{N} ( \\sum_{j=1}^J \\sum_{n \\in P_j} (1_A(n) - \\delta^{\\prime}) e(-\\alpha n) ) + O(\\varepsilon).")]]

#text("Since ")#mi("{e(-\\alpha n)}")#text(" fluctuates by at most ")#mi("{\\varepsilon}")#text(" on ")#mi("{P_j}")#text(", we can apply the triangle inequality and conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n \\in [N]} (1_A(n) - \\delta^{\\prime}) e(-\\alpha n)\\right| \\leq \\frac{1}{N} \\left|\\sum_{j=1}^J \\sum_{n \\in P_j} (1_A(n) - \\delta^{\\prime})\\right| + O(\\varepsilon).", block: true)]]

#text("If ")#mi("{\\varepsilon}")#text(" is sufficiently small depending on ")#mi("{\\delta}")#text(", we conclude that ")#metadata(none) <tao-09f5ffef28309853265c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\sum_{j=1}^J \\left|\\sum_{n \\in P_j} (1_A(n) - \\delta^{\\prime})\\right| \\gg \\delta^2 N.", block: true)]]

#text("On the other hand, as ")#mi("{\\delta^{\\prime}}")#text(" is the mean of ")#mi("{1_A}")#text(" on ")#mi("{[N]}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in [N]} (1_A(n) - \\delta^{\\prime}) = 0")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^J \\sum_{n \\in P_j} (1_A(n) - \\delta^{\\prime}) = O(\\varepsilon).")]]

#text("Adding this to ")#link(<tao-09f5ffef28309853265c>)[#text("(4)")]#text(" and noting that ")#tao-math("{\\left|x\\right|+x = 2\\max(x,0)}", block: false)#text(" for real ")#mi("{x}")#text(", we conclude (for ")#mi("{\\varepsilon}")#text(" small enough) that")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^J \\max( \\sum_{n \\in P_j} (1_A(n) - \\delta^{\\prime}), 0) \\gg \\delta^2 N")]]

#text("and hence by the pigeonhole principle we can find ")#mi("{j}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\max( \\sum_{n \\in P_j} (1_A(n) - \\delta^{\\prime}), 0) \\gg \\delta^2 \\left|P_j\\right|", block: true)]]

#text("or in other words")

#align(center)[#tao-fit-display[#tao-math("\\left|A \\cap P_j\\right| / \\left|P_j\\right| \\geq \\delta^{\\prime} + c \\delta^2", block: true)]]

#text("for some absolute constant ")#mi("{c>0}")#text(", and Proposition ")#link(<tao-8fbfe0254901865407c8>)[#text("4")]#text(" follows.")#linebreak()#text(" It is possible to rewrite the above argument in the ultralimit setting, though it only makes the argument slightly shorter as a consequence. We sketch this alternate formulation below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Let ")#mi("{\\delta_*}")#text(" be as above.")

#list(
[#text("Show that if ")#mi("{N}")#text(" is an unbounded limit natural number, and ")#mi("{A \\subset [N]}")#text(" is a limit subset whose density ")#tao-math("{st(\\left|A\\right|/N)}", block: false)#text(" is strictly greater than ")#mi("{\\delta_*}")#text(", then ")#mi("{A}")#text(" contains a (limit) arithmetic progression ")#mi("{n,n+r,n+2r}")#text(" of length three (with ")#mi("{r \\neq 0}")#text(").")],
[#text("Show that there exists an unbounded limit natural number ")#mi("{N}")#text(" and a limit subset ")#mi("{A \\subset [N]}")#text(" of density ")#tao-math("{st(\\left|A\\right|/N)=\\delta_*}", block: false)#text(", which does not contain any arithmetic progressions of length three.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Show that if ")#mi("{N}")#text(" is an unbounded limit natural number, and ")#mi("{A \\subset [N]}")#text(" is a limit subset of positive density ")#tao-math("{st(\\left|A\\right|/N) = \\delta^{\\prime} >0}", block: false)#text(" with no arithmetic progressions of length three, then there exists a limit real ")#mi("{\\alpha}")#text(" such that ")#tao-math("{\\left|\\mathop{\\bf E}_{n \\in [N]} (1_A(n) - \\delta^{\\prime}) e(-\\alpha n)\\right| \\gg 1}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" If ")#mi("{N}")#text(" is an unbounded limit natural number, and ")#mi("{\\alpha}")#text(" is a limit real, show that one can partition ")#mi("{[N] = \\bigcup_{j=1}^J P_j \\cup E}")#text(", where ")#mi("{J}")#text(" is a limit natural number, the ")#mi("{P_j}")#text(" are limit arithmetic subprogressions of ")#mi("{[N]}")#text(" of unbounded length (with the map ")#mi("{j \\mapsto P_j}")#text(" being a limit function), such that ")#mi("{n \\mapsto e(\\alpha n)}")#text(" fluctuates by ")#mi("{o(1)}")#text(" on each ")#mi("{P_j}")#text(" (uniformly in ")#mi("{j}")#text("), and ")#tao-math("{\\left|E\\right| = o(N)}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Use the previous three exercises to reprove Roth’s theorem.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Roth’s theorem in bounded characteristic)")]#text(" ")#metadata(none) <tao-72460bf2d2db96b814b0>#text(" Let ")#mi("{F}")#text(" be a finite field, let ")#mi("{\\delta > 0}")#text(", and let ")#mi("{V}")#text(" be a finite vector space. Show that if the dimension of ")#mi("{V}")#text(" is sufficiently large depending on ")#mi("{F,\\delta}")#text(", and if ")#mi("{A \\subset V}")#text(" is such that ")#tao-math("{\\left|A\\right| \\geq \\delta \\left|V\\right|}", block: false)#text(", then there exists ")#mi("{a,r \\in V}")#text(" with ")#mi("{r \\neq 0}")#text(" such that ")#mi("{a,a+r,a+2r \\in A}")#text(". (")#emph[#text("Hint:")]#text(" Mimic the above arguments (either finitarily, or with ultralimits), using hyperplanes as a substitute for subprogressions.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Roth’s theorem in finite abelian groups)")]#text(" ")#metadata(none) <tao-b8d142be3fdead11b8d9>#text(" Let ")#mi("{G}")#text(" be a finite abelian group, and let ")#mi("{\\delta > 0}")#text(". Show that if ")#tao-math("{\\left|G\\right|}", block: false)#text(" is sufficiently large depending on ")#mi("{\\delta}")#text(", and ")#mi("{A \\subset G}")#text(" is such that ")#tao-math("{\\left|A\\right| \\geq \\delta \\left|G\\right|}", block: false)#text(", then there exists ")#mi("{a, r \\in V}")#text(" with ")#mi("{r \\neq 0}")#text(" such that ")#mi("{a, a+r, a+2r \\in A}")#text(". (")#emph[#text("Hint:")]#text(" if there is an element of ")#mi("{G}")#text(" of large order, one can use Theorem ")#link(<tao-f662393c6c381fba5956>)[#text("2")]#text(" and the pigeonhole principle. If all elements have bounded order, one can instead use Exercise ")#link(<tao-72460bf2d2db96b814b0>)[#text("12")]#text(".) This result (as well as the special case in the preceding exercise) was first established ")#link("http://www.ams.org/mathscinet-getitem?mr=1335785")[#text("by Meshulam")]#text(".")
]

#heading(level: 1)[#strong[#text(" — 2. The energy increment argument — ")]]

#text("Now we turn to the energy increment approach. This approach requires a bit more machinery to set up, but ends up being quite flexible and powerful (for instance, it is the starting point for my theorem with Ben Green establishing arbitrarily long progressions in the primes, which we do not know how to establish via density increment arguments).")#linebreak()#text(" Instead of passing from ")#mi("{[N]}")#text(" to a subprogression, we now instead ")#emph[#text("coarsen")]#text(" ")#mi("{[N]}")#text(" to some partition (or ")#emph[#text("factor")]#text(") of ")#mi("{[N]}")#text(", as follows. Define a ")#emph[#text("factor")]#text(" of ")#mi("{[N]}")#text(" to be a ")#mi("{\\sigma}")#text("-algebra of subsets ")#mi("{{\\mathcal B}}")#text(" of ")#mi("{[N]}")#text(", or equivalently a partition of ")#mi("{[N]}")#text(" into disjoint ")#emph[#text("atoms")]#text(" or ")#emph[#text("cells")]#text(" (with the elements of ")#mi("{{\\mathcal B}}")#text(" then being the arbitary unions of atoms). Given a function ")#mi("{f: [N] \\rightarrow {\\bf C}}")#text(" and a factor ")#mi("{{\\mathcal B}}")#text(", we define the ")#emph[#text("conditional expectation")]#text(" ")#mi("{\\mathop{\\bf E}(f|{\\mathcal B}): [N] \\rightarrow {\\bf C}}")#text(" to be the function whose value at a given point ")#mi("{x \\in [N]}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}(f|{\\mathcal B})(x) := \\frac{1}{\\left|{\\mathcal B}(x)\\right|} \\sum_{y \\in {\\mathcal B}(x)} f(y),", block: true)]]

#text("where ")#mi("{{\\mathcal B}(x)}")#text(" is the unique atom of ")#mi("{{\\mathcal B}}")#text(" that contains ")#mi("{x}")#text(". One can view the map ")#mi("{f \\mapsto \\mathop{\\bf E}(f|{\\mathcal B})}")#text(" as the orthogonal projection from ")#mi("{L^2([N])}")#text(" to ")#mi("{L^2({\\mathcal B})}")#text(", where ")#mi("{L^2([N])}")#text(" is the space of functions ")#mi("{f: [N] \\rightarrow {\\bf C}}")#text(" with the inner product")

#align(center)[#tao-fit-display[#mitex("\\langle f, g \\rangle_{L^2([N])} := \\mathop{\\bf E}_{n \\in [N]} f(n) \\overline{g(n)}")]]

#text("and ")#mi("{L^2({\\mathcal B})}")#text(" is the subspace of functions in ")#mi("{L^2([N])}")#text(" which are measurable with respect to ")#mi("{{\\mathcal B}}")#text(", or equivalently are constant on each atom of ")#mi("{{\\mathcal B}}")#text(".")#linebreak()#text(" We say that one factor ")#mi("{{\\mathcal B}^{\\prime}}")#text(" ")#emph[#text("refines")]#text(" another ")#mi("{{\\mathcal B}}")#text(" if ")#mi("{{\\mathcal B} \\subset {\\mathcal B}^{\\prime}}")#text(", or equivalently if every atom of ")#mi("{{\\mathcal B}}")#text(" is a union of atoms of ")#mi("{{\\mathcal B}^{\\prime}}")#text(", or if every atom of ")#mi("{{\\mathcal B^{\\prime}}}")#text(" is contained in an atom of ")#mi("{{\\mathcal B}^{\\prime}}")#text(", or equivalently again if ")#mi("{L^2({\\mathcal B}) \\subset L^2({\\mathcal B}^{\\prime})}")#text(". Given two factors ")#mi("{{\\mathcal B}}")#text(", ")#mi("{{\\mathcal B}^{\\prime}}")#text(", one can define their ")#emph[#text("join")]#text(" ")#mi("{{\\mathcal B} \\vee {\\mathcal B}^{\\prime}}")#text(" to be their least common refinement, thus the atoms in ")#mi("{{\\mathcal B} \\vee {\\mathcal B}^{\\prime}}")#text(" are the non-empty intersections of atoms in ")#mi("{{\\mathcal B}}")#text(" with atoms in ")#mi("{{\\mathcal B}^{\\prime}}")#text(".")#linebreak()#text(" The idea is to split a given function ")#mi("{f}")#text(" in ")#mi("{L^2([N])}")#text(" (and specifically, an indicator function ")#mi("{1_A}")#text(") into a projection ")#mi("{\\mathop{\\bf E}(f|{\\mathcal B})}")#text(" onto a “structured factor” ")#mi("{{\\mathcal B}}")#text(" to obtain a “structured component” ")#mi("{\\mathop{\\bf E}(f|{\\mathcal B})}")#text(", together with a “pseudorandom component” ")#mi("{f - \\mathop{\\bf E}(f|{\\mathcal B})}")#text(" that is essentially orthogonal to all structured functions. This decomposition is related to the classical decomposition of a vector in a Hilbert space into its orthogonal projection onto a closed subspace ")#mi("{V}")#text(", plus the complementary projection to the orthogonal complement ")#mi("{V^\\perp}")#text("; we will see the relationship between the two decompositions later when we pass to the ultralimit.")#linebreak()#text(" We need to make the notion of “structured” more precise. We begin with some definitions. We say that a function ")#mi("{f: [N] \\rightarrow {\\bf C}}")#text(" has ")#emph[#text("Fourier complexity")]#text(" at most ")#mi("{M}")#text(" if it can be expressed as")

#align(center)[#tao-fit-display[#mitex("f(n) = \\sum_{m=1}^{M^{\\prime}} c_m e(\\alpha_m n)")]]

#text("for some ")#mi("{M^{\\prime} \\leq M}")#text(" and some complex numbers ")#mi("{c_1,\\ldots,c_{M^{\\prime}}}")#text(" of magnitude at most ")#mi("{1}")#text(", and some real numbers ")#mi("{\\alpha_1,\\ldots,\\alpha_{M^{\\prime}}}")#text(". Note that from the Fourier inversion formula that every function will have some finite Fourier complexity, but typically one expects the complexity to grow with ")#mi("{N}")#text("; only a few special functions will have complexity bounded uniformly in ")#mi("{N}")#text(". Also note that if ")#mi("{f, g}")#text(" have Fourier complexity ")#mi("{M}")#text(" then ")#mi("{f+g, f-g, \\overline{f}}")#text(", or ")#mi("{fg}")#text(" all have Fourier complexity at most ")#mi("{O_M(1)}")#text("; informally, the space of bounded complexity functions forms an algebra. (We will be able to formalise this statement after we take ultralimits.)")#linebreak()#text(" Ideally, we would like to take “functions of bounded Fourier complexity” as our class of structured functions. For technical reasons (related to our desire to use indicator functions as structured functions), we need to take an ")#mi("{L^1}")#text(" closure and work with the wider class of ")#emph[#text("Fourier measurable")]#text(" functions as our structured class.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 14 (Measurability)")]#text(" ")#metadata(none) <tao-71fd5289db5ff8d90a0f>#text(" Let ")#mi("{{\\mathcal F}: {\\bf R}^+ \\rightarrow {\\bf R}^+}")#text(" be a function. We say that a function ")#mi("{f: [N] \\rightarrow {\\bf C}}")#text(" is ")#emph[#text("Fourier measurable")]#text(" with growth function ")#mi("{{\\mathcal F}}")#text(" if, for every ")#mi("{K > 1}")#text(", one can find a function ")#mi("{f_K: [N] \\rightarrow {\\bf C}}")#text(" of Fourier complexity at most ")#mi("{{\\mathcal F}(K)}")#text(" such that ")#tao-math("{\\mathop{\\bf E}_{n \\in [N]} \\left|f(n) - f_K(n)\\right| \\leq 1/K}", block: false)#text(".")#linebreak()#text(" A subset ")#mi("{A}")#text(" of ")#mi("{[N]}")#text(" is ")#emph[#text("Fourier measurable")]#text(" with growth function ")#mi("{{\\mathcal F}}")#text(" if ")#mi("{1_A}")#text(" is Fourier measurable with this growth function.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" Show that every interval ")#mi("{[a,b]}")#text(" in ")#mi("{[N]}")#text(" is Fourier measurable with some growth function ")#mi("{{\\mathcal F}}")#text(" independent of ")#mi("{N}")#text(". (Hint: apply ")#link("http://en.wikipedia.org/wiki/Fej%C3%A9r_kernel")[#text("Fejér summation")]#text(" to ")#mi("{1_{[a,b]}}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Let ")#mi("{f}")#text(" be a Fourier-measurable function with some growth function ")#mi("{{\\mathcal F}}")#text(", which is bounded in magnitude by ")#mi("{A}")#text(". Show that for every ")#mi("{K > 1}")#text(", one can find a function ")#mi("{\\tilde f_K: [N] \\rightarrow {\\bf C}}")#text(" which also is bounded in magnitude by ")#mi("{A}")#text(", and of Fourier complexity ")#mi("{O_{A,{\\mathcal F}(K)}(1)}")#text(", such that ")#tao-math("{\\mathop{\\bf E}_{n \\in [N]} \\left|f(n) - \\tilde f_K(n)\\right| \\ll 1/K}", block: false)#text(". (")#emph[#text("Hint:")]#text(" start with the approximating function ")#mi("{f_K}")#text(" from Definition ")#link(<tao-71fd5289db5ff8d90a0f>)[#text("14")]#text(", which is already bounded in magnitude by ")#mi("{{\\mathcal F}(K)}")#text(", and then set ")#mi("{\\tilde f_K := P( f_K, \\overline{f_K})}")#text(" where ")#mi("{P(z,\\overline{z})}")#text(" is a polynomial bounded in magnitude by ")#mi("{A}")#text(" on the ball of radius ")#mi("{{\\mathcal F}(K)}")#text(" which is close to the identity function on the ball of radius ")#mi("{A}")#text(" (such a function can be constructed via the ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93Weierstrass_theorem")[#text("Stone-Weierstrass theorem")]#text(").)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" ")#metadata(none) <tao-5e89e9d8544af15b204b>#text(" Show that if ")#mi("{f, g: [N] \\rightarrow {\\bf C}}")#text(" are bounded in magnitude by ")#mi("{A}")#text(", and are Fourier measurable with growth functions ")#mi("{{\\mathcal F}}")#text(", then ")#mi("{f+g}")#text(", ")#mi("{\\overline{f}}")#text(", and ")#mi("{fg}")#text(" are Fourier measurable with some growth function ")#mi("{{\\mathcal F}^{\\prime}}")#text(" depending only on ")#mi("{A}")#text(" and ")#mi("{{\\mathcal F}}")#text(".")#linebreak()#text(" Conclude that if ")#mi("{E, F \\subset [N]}")#text(" are Fourier-measurable with growth function ")#mi("{{\\mathcal F}}")#text(", then ")#mi("{[N] \\backslash E}")#text(", ")#mi("{E \\cup F}")#text(", and ")#mi("{E \\cap F}")#text(" are Fourier-measurable with some growth function ")#mi("{{\\mathcal F}^{\\prime}}")#text(" depending only on ")#mi("{{\\mathcal F}}")#text(".")
]

#text("We thus see that Fourier-measurable sets morally form a Boolean algebra. (Again, we can formalise this assertion once we pass to the ultralimit.)")#linebreak()#text(" Now we make a key observation (cf. this paper by ")#link("http://arxiv.org/abs/0806.0381v1")[#text("Reingold, Trevisan, Tulsiani, and Vadhan")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 18 (Correlation with a Fourier character implies correlation with a Fourier-measurable set)")]#text(" ")#metadata(none) <tao-224e231fed5dd104f5d5>#text(" Let ")#mi("{f: [N] \\rightarrow {\\bf C}}")#text(" be bounded in magnitude by ")#mi("{1}")#text(", and suppose that ")#tao-math("{\\left|\\mathop{\\bf E}_{n \\in [N]} f(n) e(-\\alpha n)\\right| \\geq \\delta}", block: false)#text(" for some ")#mi("{\\delta > 0}")#text(". Then there exists a Fourier-measurable set ")#mi("{E \\subset [N]}")#text(" with some growth function ")#mi("{{\\mathcal F}}")#text(" depending on ")#mi("{\\delta}")#text(", such that ")#tao-math("{\\left|\\mathop{\\bf E}_{n \\in [N]} f(n) 1_E(n)\\right| \\gg \\delta}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" By splitting ")#mi("{f}")#text(" into real and imaginary parts, we may assume without loss of generality that ")#mi("{f}")#text(" is real. Rotating ")#mi("{e(-\\alpha n)}")#text(", we may find a real number ")#mi("{\\theta}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} f(n) \\text{Re} e(-\\alpha n + \\theta) \\geq \\delta.")]]

#text("We then express")

#align(center)[#tao-fit-display[#mitex("\\text{Re} e(-\\alpha n + \\theta) = 1-\\int_{-1}^1 1_{E_t}(n)\\ dt")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("E_t := \\{ n \\in [N]: \\text{Re} e(-\\alpha n + \\theta) \\leq t \\}.")]]

#text("By Minkowski’s inequality, we thus have either")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n \\in [N]} f(n)\\right| \\geq \\delta/2", block: true)]]

#text("or")

#align(center)[#tao-fit-display[#mitex("\\int_{-1}^1 |\\mathop{\\bf E}_{n \\in [N]} f(n) 1_{E_t}(n)|\\ dt \\geq \\delta/2.")]]

#text("In the former case we are done (setting ")#mi("{E=[N]}")#text("), so suppose that the latter holds. If all the ")#mi("{E_t}")#text(" were uniformly Fourier-measurable, we would now be done in this case also by the pigeonhole principle. This is not quite true; however, it turns out that ")#emph[#text("most")]#text(" ")#mi("{E_t}")#text(" are uniformly measurable, and this will be enough. More precisely, let ")#mi("{\\varepsilon > 0}")#text(" be a small parameter to be chosen later, and say that ")#mi("{t}")#text(" is ")#emph[#text("good")]#text(" if one has")

#align(center)[#tao-fit-display[#tao-math("\\left|E_{t+r} \\backslash E_{t-r}\\right| \\leq 2\\varepsilon^{-1} r N", block: true)]]

#text("for all ")#mi("{r>0}")#text(". Let ")#mi("{\\Omega \\subset [-1,1]}")#text(" be the set of all bad ")#mi("{t}")#text(". Observe that for each bad ")#mi("{t}")#text(", we have ")#mi("{M\\mu(t) \\geq \\varepsilon^{-1}}")#text(", where ")#mi("{\\mu}")#text(" is the probability measure")

#align(center)[#tao-fit-display[#tao-math("\\mu(S) := \\frac{1}{N} \\left|\\{ n \\in [N]: \\text{Re} e(-\\alpha n + \\theta) \\in S \\}\\right|", block: true)]]

#text("and ")#mi("{M}")#text(" is the Hardy-Littlewood maximal function")

#align(center)[#tao-fit-display[#mitex("M\\mu(t) := \\sup_{r>0} \\frac{1}{2r} \\mu( [t-r,t+r] ).")]]

#text("Applying the ")#link("http://en.wikipedia.org/wiki/Hardy%E2%80%93Littlewood_maximal_inequality")[#text("Hardy-Littlewood maximal inequality")]#text(", we conclude that ")#tao-math("{\\left|\\Omega\\right| \\ll \\varepsilon}", block: false)#text(". In particular, if ")#mi("{\\varepsilon}")#text(" is small enough compared with ")#mi("{\\delta}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\int_{[-1,1] \\backslash \\Omega} |\\mathop{\\bf E}_{n \\in [N]} f(n) 1_{E_t}(n)|\\ dt \\gg \\delta")]]

#text("and so by the pigeonhole principle, there exists a good ")#mi("{t}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{n \\in [N]} f(n) 1_{E_t}(n)\\right| \\gg \\delta.", block: true)]]

#text("It remains to verify that ")#mi("{E_t}")#text(" is good. For any ")#mi("{K > 0}")#text(", we have (as ")#mi("{t}")#text(" is good) that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} 1_{E_{t+1/K}} - 1_{E_{t-1/K}} \\ll_\\delta 1/K.")]]

#text("Applying Urysohn’s lemma, we can thus find a smooth function ")#mi("{\\eta: {\\bf R} \\rightarrow {\\bf R}^+}")#text(" with ")#mi("{\\eta(t^{\\prime}) = 1}")#text(" for ")#mi("{t^{\\prime} < t-1/K}")#text(" and ")#mi("{\\eta(t^{\\prime})=0}")#text(" for ")#mi("{t^{\\prime} > t+1/K}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{n \\in [N]} \\left|1_{E_t}(n) - \\eta( \\text{Re} e(-\\alpha n + \\theta) )\\right| \\ll_\\delta 1/K.", block: true)]]

#text("Using the Weierstrass approximation theorem, one can then approximate ")#mi("{\\eta}")#text(" uniformly by ")#mi("{O(1/K)}")#text(" on ")#mi("{[-1,1]}")#text(" by a polynomial of degree ")#mi("{O_K(1)}")#text(" and coefficients ")#mi("{O_K(1)}")#text(". This allows one to approximate ")#mi("{1_{E_t}}")#text(" in ")#mi("{L^1}")#text(" norm to an accuracy of ")#mi("{O_\\delta(1/K)}")#text(" by a function of Fourier complexity ")#mi("{O_K(1)}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 19 (Correlation implies energy increment)")]#text(" ")#metadata(none) <tao-40adbe5704411c28ca6e>#text(" Let ")#mi("{f: [N] \\rightarrow [0,1]}")#text(", and let ")#mi("{{\\mathcal B}}")#text(" be a factor generated by at most ")#mi("{M}")#text(" atoms, each of which is Fourier-measurable with growth function ")#mi("{{\\mathcal F}}")#text(". Suppose that we have the correlation")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle f - \\mathop{\\bf E}(f|{\\mathcal B}), e(\\alpha \\cdot) \\rangle_{L^2([N])}\\right| \\geq \\delta", block: true)]]

#text("for some ")#mi("{\\delta > 0}")#text(" and ")#mi("{\\alpha \\in {\\bf R}}")#text(". Then there exists a refinement ")#mi("{{\\mathcal B}^{\\prime}}")#text(" generated by at most ")#mi("{2M}")#text(" atoms, each of which is Fourier-measurable with a growth function ")#mi("{{\\mathcal F}^{\\prime}}")#text(" depending only on ")#mi("{\\delta, {\\mathcal F}}")#text(", such that ")#metadata(none) <tao-11a4a60b518bf24989d4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| \\mathop{\\bf E}(f|{\\mathcal B}^{\\prime})\\right\\|_{L^2([N])}^2 - \\left\\| \\mathop{\\bf E}(f|{\\mathcal B})\\right\\|_{L^2([N])}^2 \\gg \\delta^2.", block: true)]]
]

#emph[#text("Proof:")]#text(" By Lemma ")#link(<tao-224e231fed5dd104f5d5>)[#text("18")]#text(", we can find a Fourier-measurable set ")#mi("{E}")#text(" with some growth function ")#mi("{{\\mathcal F}^{\\prime\\prime}}")#text(" depending on ")#mi("{\\delta}")#text(", such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle f - \\mathop{\\bf E}(f|{\\mathcal B}), 1_E \\rangle_{L^2([N])}\\right| \\gg \\delta.", block: true)]]

#text("We let ")#mi("{{\\mathcal B}^{\\prime}}")#text(" be the factor generated by ")#mi("{{\\mathcal B}}")#text(" and ")#mi("{E}")#text(". As ")#mi("{1_E}")#text(" is measurable with respect to ")#mi("{{\\mathcal B}^{\\prime}}")#text(", we may project onto ")#mi("{L^2({\\mathcal B}^{\\prime})}")#text(" and conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle \\mathop{\\bf E}(f|{\\mathcal B}^{\\prime}) - \\mathop{\\bf E}(f|{\\mathcal B}), 1_E \\rangle_{L^2([N])}\\right| \\gg \\delta.", block: true)]]

#text("By Cauchy-Schwarz, we thus have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathop{\\bf E}(f|{\\mathcal B}^{\\prime}) - \\mathop{\\bf E}(f|{\\mathcal B}) \\right\\|_{L^2([N])} \\gg \\delta.", block: true)]]

#text("Squaring and using Pythagoras’ theorem, we obtain ")#link(<tao-11a4a60b518bf24989d4>)[#text("(5)")]#text(". The remaining claims in the corollary follow from Exercise ")#link(<tao-5e89e9d8544af15b204b>)[#text("17")]#text(". ")#mi("\\Box")#linebreak()#text(" We can then iterate this corollary via an ")#emph[#text("energy increment argument")]#text(" to obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 20 (Weak arithmetic regularity lemma)")]#text(" ")#metadata(none) <tao-34dcda3f0cf99ccb47e9>#text(" Let ")#mi("{f: [N] \\rightarrow [0,1]}")#text(", and let ")#mi("{{\\mathcal B}}")#text(" be a factor generated by at most ")#mi("{M}")#text(" atoms, each of which is Fourier-measurable with growth function ")#mi("{{\\mathcal F}}")#text(". Let ")#mi("{\\delta > 0}")#text(". Then there exists an extension ")#mi("{{\\mathcal B}^{\\prime}}")#text(" of ")#mi("{{\\mathcal B}}")#text(" generated by ")#mi("{O_{M,\\delta}(1)}")#text(" atoms, each of which is Fourier-measurable with growth function ")#mi("{{\\mathcal F}^{\\prime}}")#text(" depending on ")#mi("{{\\mathcal F}, \\delta}")#text(", such that ")#metadata(none) <tao-0bb5e9329f190a4fa67f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|\\langle f - \\mathop{\\bf E}(f|{\\mathcal B}^{\\prime}), e(\\alpha \\cdot) \\rangle_{L^2([N])}\\right| < \\delta", block: true)]]

#text("for all ")#mi("{\\alpha \\in {\\bf R}}")#text(".")
]

#emph[#text("Proof:")]#text(" We initially set ")#mi("{{\\mathcal B}^{\\prime}}")#text(" equal to ")#mi("{{\\mathcal B}}")#text(". If ")#link(<tao-0bb5e9329f190a4fa67f>)[#text("(6)")]#text(" already holds, then we are done; otherwise, we invoke Corollary ")#link(<tao-40adbe5704411c28ca6e>)[#text("19")]#text(" to increase the “energy” ")#tao-math("{\\left\\| \\mathop{\\bf E}(f|{\\mathcal B}^{\\prime}) \\right\\|_{L^2}^2}", block: false)#text(" by ")#mi("{\\gg \\delta^2}")#text(", at the cost of possibly doubling the number of atoms in ")#mi("{{\\mathcal B}^{\\prime}}")#text(", and also altering the growth function somewhat. We iterate this procedure; as the energy ")#tao-math("{\\left\\| \\mathop{\\bf E}(f|{\\mathcal B}^{\\prime}) \\right\\|_{L^2}^2}", block: false)#text(" is bounded between zero and one, and increases by ")#mi("{\\gg \\delta^2}")#text(" at each step, the procedure must terminate in ")#mi("{O(1/\\delta^2)}")#text(" steps, at which point the claim follows. ")#mi("\\Box")#linebreak()#text(" It turns out that the power of this lemma is amplified if we iterate one more time, to obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 21 (Strong arithmetic regularity lemma)")]#text(" ")#metadata(none) <tao-a2f6973d4f45332b2397>#text(" Let ")#mi("{f: [N] \\rightarrow [0,1]}")#text(", let ")#mi("{\\varepsilon > 0}")#text(", and let ")#mi("{F: {\\bf R}^+ \\rightarrow {\\bf R}^+}")#text(" be an arbitrary function. Then we can decompose ")#mi("{f = f_{str} + f_{sml} + f_{psd}}")#text(" and find ")#mi("{1 \\leq M = O_{\\varepsilon,F}(1)}")#text(" such that")

#list(
[#text("(Nonnegativity) ")#mi("{f_{str}, f_{str}+f_{sml}}")#text(" take values in ")#mi("{[0,1]}")#text(", and ")#mi("{f_{sml}, f_{psd}}")#text(" have mean zero;")],
[#text("(Structure) ")#mi("{f_{str}}")#text(" is Fourier-measurable with a growth function ")#mi("{{\\mathcal F}_M}")#text(" that depends only on ")#mi("{M}")#text(";")],
[#text("(Smallness) ")#mi("{f_{sml}}")#text(" has an ")#mi("{L^2}")#text(" norm of at most ")#mi("{\\varepsilon}")#text("; and")],
[#text("(Pseudorandomness) One has ")#tao-math("{\\left|\\mathop{\\bf E}_{n \\in [N]} f_{psd}(n) e(-\\alpha n)\\right| \\leq 1/F(M)}", block: false)#text(" for all ")#mi("{\\alpha \\in {\\bf R}}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" We recursively define a sequence ")#mi("{M_1 < M_2 < \\ldots}")#text(" by setting ")#mi("{M_1 := 1}")#text(" and ")#mi("{M_{k+1} := M_k + F(M_k) + 1}")#text(" (say). Applying Proposition ")#link(<tao-34dcda3f0cf99ccb47e9>)[#text("20")]#text(" (starting with the trivial factor ")#mi("{{\\mathcal B}_1}")#text("), one can then find a nested sequence of refinements ")#mi("{{\\mathcal B}_1 \\subset {\\mathcal B}_2 \\subset \\ldots}")#text(", such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle f - \\mathop{\\bf E}(f|{\\mathcal B}_{k}), e(\\alpha \\cdot) \\rangle_{L^2([N])}\\right| < 1/M_k", block: true)]]

#text("for all ")#mi("{k \\geq 1}")#text(" and ")#mi("{\\alpha \\in {\\bf R}}")#text(", and such that each ")#mi("{{\\mathcal B}_k}")#text(" consists of ")#mi("{O_k(1)}")#text(" atoms that are Fourier-measurable with some growth function depending on ")#mi("{M_k}")#text(" (note that this quantity dominates ")#mi("{k}")#text(" and ")#mi("{M_1,\\ldots,M_{k-1}}")#text(" by construction). By Pythagoras’ theorem, the energies ")#tao-math("{\\left\\| \\mathop{\\bf E}(f|{\\mathcal B}_k)\\right\\|_{L^2([N])}^2}", block: false)#text(" are monotone increasing between ")#mi("{0}")#text(" and ")#mi("{1}")#text(", so by the pigeonhole principle there exists ")#mi("{k = O(1/\\varepsilon^2)}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathop{\\bf E}(f|{\\mathcal B}_{k+1})\\right\\|_{L^2([N])}^2 - \\left\\| \\mathop{\\bf E}(f|{\\mathcal B}_{k})\\right\\|_{L^2([N])}^2 \\leq \\varepsilon^2", block: true)]]

#text("and hence by Pythagoras")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathop{\\bf E}(f|{\\mathcal B}_{k+1}) - \\mathop{\\bf E}(f|{\\mathcal B}_{k})\\right\\|_{L^2([N])}^2 \\leq \\varepsilon^2.", block: true)]]

#text("Setting ")#mi("{f_{str} := \\mathop{\\bf E}(f|{\\mathcal B}_{k})}")#text(", ")#mi("{f_{sml} := \\mathop{\\bf E}(f|{\\mathcal B}_{k+1}) - \\mathop{\\bf E}(f|{\\mathcal B}_{k})}")#text(", ")#mi("{f_{psd} := f - \\mathop{\\bf E}(f|{\\mathcal B}_{k+1})}")#text(", we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 22")]#text(" This result is essentially due ")#link("http://www.ams.org/mathscinet-getitem?mr=2153903")[#text("to Green")]#text(" (though not quite in this language). Earlier related decompositions are due ")#link("http://www.ams.org/mathscinet-getitem?mr=853455")[#text("to Bourgain")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2488453")[#text("to Green-Konyagin")]#text(". The ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma in graph theory")]#text(" can be viewed as the graph-theoretic analogue of this Fourier-analytic result; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2212136")[#text("this paper of mine")]#text(" (or ")#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/")[#text("my FOCS paper")]#text(") for further discussion. The double iteration required to prove Theorem ")#link(<tao-a2f6973d4f45332b2397>)[#text("21")]#text(" means that the bounds here are quite poor (of tower-exponential type, in fact, when ")#mi("{F}")#text(" is exponential, which is typical in applications), much as in the graph theory case; thus the use of this lemma, while technically quantitative in nature, gives bounds that are usually quite inferior to what is known or suspected to be true.")#linebreak()#text(" As with the Ratner-type theorems from the previous notes, it is crucial that the uniformity ")#mi("{1/F(M)}")#text(" for the pseudorandom component ")#mi("{f_{psd}}")#text(" is of an arbitrarily higher quality than the measurability of the structured component ")#mi("{f_{str}}")#text(".")
]

#text("Much as the Ratner-type theorems from the previous notes could be used to prove multiple recurrence theorems, the arithmetic regularity lemma can be used (among other things) to give a proof of Roth’s theorem. We do so as follows. Let ")#mi("{N}")#text(" be a large integer, and let ")#mi("{A}")#text(" be a subset of ")#mi("{[N]}")#text(" with ")#tao-math("{\\left|A\\right| \\geq \\delta N}", block: false)#text(" for some ")#mi("{\\delta > 0}")#text(". We consider the expression ")#mi("{\\Lambda(1_A,1_A,1_A)}")#text(", where ")#mi("{\\Lambda}")#text(" is the trilinear form")

#align(center)[#tao-fit-display[#mitex("\\Lambda(f,g,h) := \\frac{1}{N^2} \\sum_{n \\in [N]} \\sum_{r \\in [-N,N]} f(n) g(n+r) h(n+2r).")]]

#text("We will show that ")#metadata(none) <tao-e00443c76cfe2be97aa8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\Lambda(1_A, 1_A, 1_A) \\gg_\\delta 1,")]]

#text("which implies that the number of all three-term arithmetic progressions in ")#mi("{A}")#text(" (including the degenerate ones with ")#mi("{r=0}")#text(") is ")#mi("{\\gg_\\delta N^2}")#text(". For ")#mi("{N}")#text(" sufficiently large depending on ")#mi("{\\delta}")#text(", this number is larger than the number ")#mi("{N}")#text(" of degenerate progressions, giving the theorem.")#linebreak()#text(" It remains to establish ")#link(<tao-e00443c76cfe2be97aa8>)[#text("(7)")]#text(". We apply Theorem ")#link(<tao-a2f6973d4f45332b2397>)[#text("21")]#text(" with parameters ")#mi("{\\varepsilon > 0}")#text(", ")#mi("{F}")#text(" to be chosen later (they will depend on ")#mi("{\\delta}")#text(") to obtain a quantity ")#mi("{M}")#text(" and a decomposition")

#align(center)[#tao-fit-display[#mitex("1_A = f_{str} + f_{sml} + f_{psd}")]]

#text("with the stated properties. This splits the left-hand side of ")#link(<tao-e00443c76cfe2be97aa8>)[#text("(7)")]#text(" into ")#mi("{27}")#text(" terms. But we can eliminate several of these terms:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Show that all of the terms in ")#link(<tao-e00443c76cfe2be97aa8>)[#text("(7)")]#text(" which involve at least one copy of ")#mi("{f_{psd}}")#text(" are of size ")#mi("{O(1/F(M))}")#text(". (")#emph[#text("Hint:")]#text(" Modify the proof of Proposition ")#link(<tao-61c08f912501b69e634b>)[#text("5")]#text(".)")
]

#text("From this exercise we see that ")#metadata(none) <tao-0932bfd7f77b3bef2b1a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\Lambda(1_A, 1_A, 1_A) = \\Lambda(f_{str}+f_{sml}, f_{str}+f_{sml}, f_{str}+f_{sml}) + O(1/F(M)).")]]

#text("Now we need to deal with ")#mi("{f_{str}+f_{sml}}")#text(". A key point is the ")#link("http://en.wikipedia.org/wiki/Almost_periodic_function")[#text("almost periodicity")]#text(" of ")#mi("{f_{str}+f_{sml}}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 24 (Almost periodicity)")]#text(" For ")#mi("{\\gg_{\\delta,M} N}")#text(" values of ")#mi("{r \\in [-\\varepsilon N,\\varepsilon N]}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{n \\in [N]} \\left|(f_{str}+f_{sml})(n+r) - (f_{str}+f_{sml})(n)\\right| \\ll \\varepsilon", block: true)]]

#text("(where we extend ")#mi("{f_{str}, f_{sml}}")#text(" by zero outside of ")#mi("{[N]}")#text(").")
]

#emph[#text("Proof:")]#text(" As ")#mi("{f_{str}}")#text(" is Fourier-measurable, we can approximate it to an error of ")#mi("{O(\\varepsilon)}")#text(" in ")#mi("{L^1[N]}")#text(" norm by a function ")#metadata(none) <tao-f20bb3a67149a42c9fe7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("g = \\sum_{j=1}^J c_j e(\\alpha_j n)")]]

#text("of Fourier complexity ")#mi("{J \\leq O_{M,\\varepsilon}(1)}")#text(". From the smallness of ")#mi("{f_{sml}}")#text(", we then have")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{n \\in [N]} \\left|(f_{str}+f_{sml})(n+r) - (f_{str}+f_{sml})(n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\leq \\mathop{\\bf E}_{n \\in [N]} \\left|g(n+r) - g(n)\\right| + O(\\varepsilon)", block: true)]]

#text("(where we extend ")#mi("{g}")#text(" using ")#link(<tao-f20bb3a67149a42c9fe7>)[#text("(9)")]#text(" rather than by zero, with the error being ")#mi("{O(\\varepsilon)}")#text(" when ")#tao-math("{\\left|r\\right| \\leq \\varepsilon N}", block: false)#text("). We can use ")#link(<tao-f20bb3a67149a42c9fe7>)[#text("(9)")]#text(" and the triangle inequality to bound")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{n \\in [N]} \\left|g(n+r) - g(n)\\right| \\leq \\sum_{j=1}^J |e(\\alpha_j r) - 1|.", block: true)]]

#text("Using multiple recurrence, we can find ")#mi("{\\gg_{J,\\varepsilon} N}")#text(" values of ")#mi("{r \\in [-\\varepsilon N, \\varepsilon N]}")#text(" such that ")#tao-math("{\\left\\| \\alpha_j r \\right\\|_{{\\bf R}/{\\bf Z}} \\leq \\varepsilon/J}", block: false)#text(" for all ")#mi("{1 \\leq j \\leq J}")#text(". The claim follows. ")#mi("\\Box")#linebreak()#text(" Now we can finish the proof of Roth’s theorem. As ")#mi("{f_{str}+f_{sml}}")#text(" has the same mean as ")#mi("{f}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} (f_{str}+f_{sml})(n) \\geq \\delta")]]

#text("and hence by Hölder’s inequality (and the non-negativity of ")#mi("{f_{str}+f_{sml}}")#text(")")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} (f_{str}+f_{sml})(n)^3 \\geq \\delta^3.")]]

#text("Now if ")#mi("{r}")#text(" is one of the periods in the above lemma, we have")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{n \\in [N]} \\left|(f_{str}+f_{sml})(n+r) - (f_{str}+f_{sml})(n)\\right| \\ll \\varepsilon", block: true)]]

#text("and thus by shifting")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{n \\in [N]} \\left|(f_{str}+f_{sml})(n+2r) - (f_{str}+f_{sml})(n+r)\\right| \\ll \\varepsilon", block: true)]]

#text("and so by the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{n \\in [N]} \\left|(f_{str}+f_{sml})(n+2r) - (f_{str}+f_{sml})(n)\\right| \\ll \\varepsilon.", block: true)]]

#text("Putting all this together using the triangle and Hölder inequalities, we obtain")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} (f_{str}+f_{sml})(n) (f_{str}+f_{sml})(n+r) (f_{str}+f_{sml})(n+2r)")]]

#align(center)[#tao-fit-display[#mitex("\\geq \\delta^3 - O(\\varepsilon).")]]

#text("Thus, if ")#mi("{\\varepsilon}")#text(" is sufficiently small depending on ")#mi("{\\delta}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{n \\in [N]} (f_{str}+f_{sml})(n) (f_{str}+f_{sml})(n+r) (f_{str}+f_{sml})(n+2r) \\gg \\delta^3")]]

#text("for ")#mi("{\\gg_{J,\\varepsilon} N}")#text(" values of ")#mi("{r}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\Lambda(f_{str}+f_{sml},f_{str}+f_{sml},f_{str}+f_{sml}) \\gg_{\\delta,M} 1;")]]

#text("if we then set ")#mi("{F}")#text(" to be a sufficiently rapidly growing function (depending on ")#mi("{\\delta}")#text("), we obtain the claim from ")#link(<tao-0932bfd7f77b3bef2b1a>)[#text("(8)")]#text(". This concludes the proof of Roth’s theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" Use the energy increment method to establish a different proof of Exercise ")#link(<tao-b8d142be3fdead11b8d9>)[#text("13")]#text(". (")#emph[#text("Hint:")]#text(" For the multiple recurrence step, use a pigeonhole principle argument rather than an appeal to equidistribution theory.)")
]

#text("We now briefly indicate how to translate the above arguments into the ultralimit setting. We first need to construct an important measure on limit sets, namely ")#emph[#text("Loeb measure")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26 (Construction of Loeb measure)")]#text(" Let ")#mi("{N}")#text(" be an unbounded natural number. Define the ")#emph[#text("Loeb measure")]#text(" ")#mi("{\\mu(A)}")#text(" of a limit subset ")#mi("{A}")#text(" of ")#mi("{[N]}")#text(" to be the quantity ")#tao-math("{st(\\left|A\\right|/N)}", block: false)#text(", thus for instance a set of cardinality ")#mi("{o(N)}")#text(" will have Loeb measure zero.")

#list(
[#text("Show that if a limit subset ")#mi("{A}")#text(" of ")#mi("{[N]}")#text(" is partitioned into countably many disjoint limit subsets ")#mi("{A_n}")#text(", that all but finitely many of the ")#mi("{A_n}")#text(" are empty, and so ")#mi("{\\mu(A) = \\mu(A_1)+\\ldots+\\mu(A_n)}")#text(".")],
[#text("Define the ")#emph[#text("outer measure")]#text(" ")#mi("{\\mu_*(A)}")#text(" of a subset ")#mi("{A}")#text(" of ")#mi("{[N]}")#text(" (not necessarily a limit subset) to be the infimum of ")#mi("{\\sum_n \\mu(A_n)}")#text(", where ")#mi("{A_1, A_2, \\ldots}")#text(" is a countable family of limit subsets of ")#mi("{[N]}")#text(" that cover ")#mi("{A}")#text(", and call a subset of ")#mi("{[N]}")#text(" ")#emph[#text("null")]#text(" if it has zero outer measure. Call a subset ")#emph[#text("Loeb measurable")]#text(" if it differs from a limit set by a null set. Show that there is a unique extension of Loeb measure ")#mi("{\\mu}")#text(" from limit sets to Loeb measurable sets that is a countably additive probability measure on ")#mi("{[N]}")#text(". (")#emph[#text("Hint:")]#text(" use the ")#link("http://en.wikipedia.org/wiki/Carath%C3%A9odory%27s_extension_theorem")[#text("Carathéodory extension theorem")]#text(", see e.g. my ")#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/")[#text("254B notes 0")]#text(" or ")#link("https://terrytao.wordpress.com/2009/01/03/254a-notes-0a-an-alternate-approach-to-the-caratheodory-extension-theorem/")[#text("notes 0a")]#text(".)")],
[#text("If ")#mi("{f: [N] \\rightarrow {\\bf C}}")#text(" is a limit function bounded in magnitude by some standard real ")#mi("{M}")#text(", show that ")#mi("{st(f)}")#text(" is a Loeb measurable function in ")#mi("{L^\\infty(\\mu)}")#text(", with norm at most ")#mi("{M}")#text(".")],
[#text("Show that there exists a unique trilinear form ")#mi("{\\Lambda: L^\\infty(\\mu) \\times L^\\infty(\\mu) \\times L^\\infty(\\mu) \\rightarrow {\\bf C}}")#text(", jointly continuous in the ")#mi("{L^3(\\mu)}")#text(" topology for all three inputs, such that")

#align(center)[#tao-fit-display[#mitex("\\Lambda(st(f),st(g),st(h))")]]

#align(center)[#tao-fit-display[#mitex("= st( \\frac{1}{N^2} \\sum_{n \\in [N]} \\sum_{r \\in [-N,N]} f(n) g(n+r) h(n+2r) )")]]

#text("for all bounded limit functions ")#mi("{f,g,h}")#text(".")],
[#text("Show that Roth’s theorem is equivalent to the assertion that ")#mi("{\\Lambda(f,f,f) > 0}")#text(" whenever ")#mi("{f \\in L^\\infty(\\mu)}")#text(" is a bounded non-negative function with ")#mi("{\\int_{[N]} f\\ d\\mu > 0}")#text(".")]
)
]

#text("Next, we develop the ultralimit analogue of Fourier measurability, which we will rename ")#emph[#text("Kronecker measurability")]#text(" due to the close analogy with the ")#emph[#text("Kronecker factor")]#text(" in ergodic theory.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27 (Construction of the Kronecker factor)")]#text(" Let ")#mi("{N}")#text(" be an unbounded natural number. We define a ")#emph[#text("Fourier character")]#text(" to be a function in ")#mi("{L^\\infty([N])}")#text(" of the form ")#mi("{n \\mapsto st(e(\\alpha n))}")#text(" for some limit real number ")#mi("{\\alpha}")#text(". We define a ")#emph[#text("trigonometric polynomial")]#text(" to be any finite linear combination (over the standard complex numbers) of Fourier characters. Let ")#mi("{{\\mathcal Z}^1}")#text(" be the ")#mi("{\\sigma}")#text("-algebra of Loeb measurable sets generated by the Fourier characters; we refer to ")#mi("{{\\mathcal Z}^1}")#text(" as the ")#emph[#text("Kronecker factor")]#text(", and functions or sets measurable in this factor as ")#emph[#text("Kronecker measurable")]#text(" functions and sets. Thus for instance all trigonometric polynomials are Kronecker measurable. We let ")#mi("{\\mathop{\\bf E}(f|{\\mathcal Z}^1)}")#text(" denote the orthogonal projection from ")#mi("{f}")#text(" to ")#mi("{L^2({\\mathcal Z^1})}")#text(", i.e. the conditional expectation to the Kronecker factor.")

#list(
[#text("Show that if ")#mi("{f \\in L^\\infty({\\mathcal Z}^1)}")#text(" is bounded in magnitude by ")#mi("{M}")#text(" and ")#mi("{\\varepsilon > 0}")#text(" is a standard real, then there exists a trigonometric polynomial ")#mi("{P \\in L^\\infty({\\mathcal Z}^1)}")#text(" which is also bounded in magnitude by ")#mi("{M}")#text(" and is within ")#mi("{\\varepsilon}")#text(" of ")#mi("{f}")#text(" in ")#mi("{L^1}")#text(" norm.")],
[#text("Show that if ")#mi("{f \\in L^\\infty({\\mathcal Z}^1)}")#text(" and ")#mi("{\\varepsilon > 0}")#text(", then there exists a limit subset ")#mi("{R}")#text(" of ")#mi("{[-\\varepsilon N, \\varepsilon N]}")#text(" of cardinality ")#mi("{\\gg N}")#text(" such that ")#tao-math("{\\left\\| f(\\cdot) - f(\\cdot+r) \\right\\|_{L^1([N])} \\leq \\varepsilon}", block: false)#text(" for all ")#mi("{r \\in R}")#text(" (extending ")#mi("{f}")#text(" by zero).")],
[#text("Show that if ")#mi("{f \\in L^\\infty({\\mathcal Z}^1)}")#text(" is non-negative with ")#mi("{\\int_{[N]} f\\ d\\mu > 0}")#text(", then ")#mi("{\\Lambda(f,f,f) > 0}")#text(".")],
[#text("Show that if ")#mi("{f_1,f_2,f_3 \\in L^\\infty([N])}")#text(" and ")#mi("{\\mathop{\\bf E}(f_i|{\\mathcal Z}^1)=0}")#text(" for at least one ")#mi("{i=1,2,3}")#text(", then ")#mi("{\\Lambda(f_1,f_2,f_3)=0}")#text(".")],
[#text("Conclude the proof of Roth’s theorem using ultralimits.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 28")]#text(" Note how the (finitary) arithmetic regularity lemma has been replaced by the more familiar (infinitary) theory of conditional expectation to a factor, and the finitary notion of measurability has been replaced by a notion from the traditional (countably additive) infinitary theory of measurability. This is one of the key advantages of the ultralimit approach, namely that it allows one to exploit already established theories of infinitary mathematics (e.g. measure theory, ergodic theory, Hilbert space geometry, etc.) to prove a finitary result.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" Use the ultralimit energy increment method to establish yet another proof of Exercise ")#link(<tao-b8d142be3fdead11b8d9>)[#text("13")]#text(".")
]

#heading(level: 1)[#strong[#text(" — 3. More quantitative bounds (optional) — ")]]

#text("The above proofs of Roth’s theorem (as formulated in, say, Theorem ")#link(<tao-f662393c6c381fba5956>)[#text("2")]#text(") were qualitative in the sense that they did not explicitly give a bound for ")#mi("{N_0}")#text(" in terms of ")#mi("{\\delta}")#text(". Nevertheless, by analysing the finitary arguments more carefully, a bound can be extracted:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]#text(" Show that in Proposition ")#link(<tao-7587669ca42e19e8a9aa>)[#text("7")]#text(", one can take ")#mi("{N^{\\prime} \\gg \\varepsilon^{O(1)} N^{1/2}}")#text(". Using this and the density increment argument, show that one can take ")#mi("{N_0 \\ll \\exp(\\exp(O(1/\\delta)))}")#text(" in Theorem ")#link(<tao-f662393c6c381fba5956>)[#text("2")]#text(". (To put it another way, subsets of ")#mi("{[N]}")#text(" of density much larger than ")#mi("{1/\\log \\log N}")#text(" will contain progressions of length three.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" Show that in the energy increment proof of Roth’s theorem, one can take the growth functions ")#mi("{{\\mathcal F}}")#text(" involved to be polynomial in ")#mi("{K}")#text(" (but with the exponent growing exponentially with each refinement of the factor), and ")#mi("{F}")#text(" can be taken to be an iterated exponential; thus ultimately allows one to take ")#mi("{N_0}")#text(" to be a ")#link("http://en.wikipedia.org/wiki/Tetration")[#text("tower exponential")]#text(" of height ")#mi("{O(\\delta^{-O(1)})}")#text(". (To put it another way, subsets of ")#mi("{[N]}")#text(" of density much larger than ")#mi("{1/\\log_*^c N}")#text(" for some ")#mi("{c>0}")#text(" will contain progressions of length three.) Thus we see that the energy increment argument, in the form presented here, provides much worse bounds than the density increment argument; but see below.")
]

#text("For the ultralimit arguments, it is significantly harder to extract a quantitative bound from the argument (basically one has to painstakingly “finitise” the argument first, essentially reaching the finitary counterparts of these arguments presented above). Thus we see that there is a tradeoff when using ultralimit analysis; the arguments become slightly cleaner (and one can deploy infinitary methods), but one tends to lose sight of what quantitative bounds the method establishes. (This is particularly the case if one begins to rely heavily on the axiom of choice (or on large cardinal axioms) once one takes ultralimits, although these axioms are not used in the examples above.)")#linebreak()#text(" It is possible to run the density increment argument more efficiently by combining it with some aspects of the energy increment argument. As described above, the density increment argument proceeds by locating a ")#emph[#text("single")]#text(" large Fourier coefficient ")#mi("{\\hat 1_A(\\alpha)}")#text(" of ")#mi("{A}")#text(", and uses this to obtain a density increment on a relatively short subprogression of ")#mi("{[N]}")#text(" (of length comparable to ")#mi("{\\sqrt{N}}")#text(", ignoring factors of ")#mi("{\\delta}")#text("). One then has to iterate this about ")#mi("{1/\\delta}")#text(" times before one obtains a truly significant density increment (e.g. from ")#mi("{\\delta}")#text(" to ")#mi("{2\\delta}")#text("). It is this repeated passage from ")#mi("{N}")#text(" to ")#mi("{\\sqrt{N}}")#text(" which is ultimately responsible for the double exponential bound for ")#mi("{N_0}")#text(" at the end of the day.")#linebreak()#text(" In an unpublished work, Endre Szemerédi observed that one can run this argument more efficiently by collecting ")#emph[#text("several")]#text(" large Fourier coefficients of ")#mi("{1_A}")#text(" simultaneously (somewhat in the spirit of the energy increment argument), and only then passing to a subprogression on which all of the relevant Fourier characters are simultaneously close to constant. The subprogression obtained is smaller as a consequence, but the density increment is much more substantial. Using this strategy, Endre was able to improve the original Roth bound of ")#mi("{N_0 \\ll \\exp(\\exp(O(1/\\delta)))}")#text(" to the somewhat better ")#mi("{N_0 \\ll \\exp(\\exp(O(\\log^2(1/\\delta))))}")#text(" (or equivalently, he was able to establish length three progressions in any subset of ")#mi("{[N]}")#text(" of density much larger than ")#mi("{\\exp(-c\\sqrt{\\log \\log N})}")#text(" for some ")#mi("{c>0}")#text("). By carefully optimising the choice of threshold for selecting the “large Fourier coefficients”, Szemerédi (unpublished) and ")#link("http://www.ams.org/mathscinet-getitem?mr=889362")[#text("Heath-Brown")]#text(" independently improved this method further to obtain ")#mi("{N_0 \\ll \\exp(\\delta^{-O(1)})}")#text(", or equivalently obtaining length three progressions in sets of density much larger than ")#mi("{\\log^{-c} N}")#text(". (This result was extended to arbitrary finite abelian groups ")#link("http://www.ams.org/mathscinet-getitem?mr=1335785")[#text("by Meshulam")]#text(".)")#linebreak()#text(" The next advance was ")#link("http://www.ams.org/mathscinet-getitem?mr=1726234")[#text("by Bourgain")]#text(", who realised that rather than pass to short subprogressions, it was more efficient to work on the significantly larger (but messier) Bohr sets ")#mi("{\\{ n: \\alpha n \\text{ mod } 1 \\in I \\}}")#text(", after ensuring that such Bohr sets were ")#emph[#text("regular")]#text(" (this condition is closely related to the Fourier measurability condition used in the energy increment argument). With this modification to the original Roth argument, the bound was lowered to ")#mi("{N_0 \\ll \\delta^{-O(1/\\delta^2)}}")#text(", or equivalently obtaining length three progressions in sets of density much larger than ")#mi("{\\sqrt{\\log\\log N/\\log N}}")#text(". Even more recently, this argument was combined with the Szemerédi-Heath-Brown argument by Bourgain (not yet published) to obtain the further improvement of ")#mi("{N_0 \\ll \\exp( O( \\delta^{-3/2} \\log^3( 1/\\delta) ) )}")#text(", or equivalently obtaining length three progressions in sets of density much larger than ")#mi("{(\\log \\log N)^2 / \\log^{2/3} N}")#text(". This is getting close to the ")#mi("{k=3}")#text(" case of an old conjecture of Erdös that asserts that any subset of the natural numbers whose sums of reciprocals diverge should have infinitely many arithmetic progressions of length ")#mi("{k}")#text(" for any ")#mi("{k}")#text(". To establish the ")#mi("{k=3}")#text(" case from quantitative versions of Roth’s theorem, one would basically need a bound of the form ")#mi("{N_0 \\ll \\exp( \\delta^{-1+c} )}")#text(" for some ")#mi("{c>0}")#text(" (or the ability to obtain progressions in sets of density ")#mi("{1/\\log^{1+c} N}")#text(").")#linebreak()#text(" On the other hand, there is an ")#link("http://www.ams.org/mathscinet-getitem?mr=18694")[#text("old counterexample of Behrend")]#text(" (based ultimately on the observation that a sphere in a high-dimensional lattice ")#mi("{{\\bf Z}^d}")#text(" does not contain any arithmetic progressions of length three) which shows that ")#mi("{N_0}")#text(" must be at least ")#mi("{\\gg \\exp( \\log^2(1/\\delta) )}")#text(" (in particular, it must be super-polynomial in ")#mi("{\\delta}")#text("); equivalently, it is known that there are subsets of ")#mi("{[N]}")#text(" of density about ")#mi("{\\exp(-c\\sqrt{\\log N})}")#text(" with no arithmetic progressions of length three. For the sharpest results in this direction, see this ")#link("http://arxiv.org/abs/0801.4310")[#text("paper of Elkin")]#text(" (and a later ")#link("http://arxiv.org/abs/0810.0732")[#text("exposition of Green and Wolf")]#text(").")#linebreak()#text(" The question of refining the bounds is an important one, as it tends to improve the technological understanding of current methods, as well as shed light on their relative strengths and weaknesses. However, this comes at the cost of making the arguments somewhat more technical, and so we shall not focus on the sharpest quantitative results in these notes.")

#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joel Moreira")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-44212")[#strong[#text("Joel Moreira")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2010")])]

#text("Dear Prof. Tao")

#text("In theorem 1, shouldn’t be limsup?")

#text("Also, after (1) (in the proof of proposition 4) I think it’s the cyclic group Z/N’Z.")

#text("And in the second equation in the proof of lemma 7, I believe that there is a sign missing (not that it matters).")

#emph[#text("[Corrected, thanks – T.]")]

#text("Great Notes!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-44221")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2010")])]

#text("The full entry shows up on the main page for your blog. Did you mean to have it all show, rather than just the beginning? Maybe it’s something weird on my side.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 3: Linear patterns « What’s new")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-44472")[#strong[#text("254B, Notes 3: Linear patterns « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2010")])]

#text("[…] von Neumann theorem, Gowers uniformity norms, linear patterns | by Terence Tao In the previous lecture notes, we used (linear) Fourier analysis to control the number of three-term arithmetic progressions in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 5: The inverse conjecture for the Gowers norm I. The finite field case « What’s new")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-45034")[#strong[#text("254B, Notes 5: The inverse conjecture for the Gowers norm I. The finite field case « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2010")])]

#text("[…] proceed we need the following analogue of Proposition 5 of Notes 2: Exercise 6 (Fragmenting a polynomial into subspaces) Let be a classical polynomial of degree . […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 6: The inverse conjecture for the Gowers norm II. The integer case « What’s new")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-45209")[#strong[#text("254B, Notes 6: The inverse conjecture for the Gowers norm II. The integer case « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2010")])]

#text("[…] with growth function depending only on , where Fourier measurability was defined in Notes 2. Exercise 18 Show that the class of nilsequences of degree does not change if we drop the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Lecture Notes 7: The transference principle, and linear equations in primes « What’s new")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-45345")[#strong[#text("254B, Lecture Notes 7: The transference principle, and linear equations in primes « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2010")])]

#text("[…] should be compared with Roth’s theorem in the integers (Notes 2), which is the same statement but with the primes replaced by the integers (or natural numbers ). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90aa6386641bc9897c01d26e95c2d39f4b5fc3c4aefdf913beb0adc36ae6c66b-57f60c4d70ae636346f3500edb78c8f57812b386a0cab14c0ceb24809d82333c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ylin2")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-73890")[#strong[#text("ylin2")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2011")])]

#text("Dear Professor Tao: In exercise 8, you said to consider a Fejer summation method. But Fejer kernel seems to be defined on the continuous torus, so how to adapt that method to the discrete setting as in this problem?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-73996")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2011")])]

#text("A function on the integers can be viewed as the restriction of a function on the reals.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-120916")[#strong[#text("Applications of Szemerédi’s regularity lemma: triangle removal lemma, Roth’s theorem, corner’s theorem and graph removal lemma « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2012")]

#text("[…] regularity lemma, and now we give a few of its various applications: the triangle removal lemma, Roth’s theorem on the existence of arithmetic progressions of length in subsets of the integers with positive […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-498386")[#strong[#text("Finitary versions of theorems – Write down what you’ve done")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2018")]

#text("[…] of Roth’s theorem on arithmetic progressions which I wanted to understand. I found it in Terence Tao’s lecture notes on higher order Fourier analysis. While working my way through this proof I tried to solve the exercises. However, already the first […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/724a5f80344d8c833d5f96098156b6474d7241d0645221f832a2cf430c495e55-d0c51b33bad4c6bd68b860e2c692845dc25308fcf7971962b7e0162cc488bbfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hc")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-536639")[#strong[#text("hc")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2020")])]

#text("I have a confusion: what does arithmetic regularity lemma buy us in the energy increment proof?")

#text("It seems like after Proposition 9, we already found the right sigma algebra ")#mi("\\mathcal{B}^{\\prime}")#text(" of Fourier measurable sets with complexity ")#mi("O_{\\delta}(1)")#text(" (say we start with ")#mi("\\mathcal{B}")#text(" being the trivial ")#mi("\\sigma")#text("-algebra). We can then write")

#mi("\\displaystyle 1_A = \\mathbb{E}(f| \\mathcal{B}^{\\prime}) + (f - \\mathbb{E}(f | \\mathcal{B}^{\\prime}))")

#text("Almost periodicity should hold for ")#mi("\\mathbb{E}(f| \\mathcal{B}^{\\prime})")#text(" as in your proof. By proposition 9, the residual ")#mi("f - \\mathbb{E}(f | \\mathcal{B}^{\\prime})")#text(" would have small ")#mi("U^2")#text("-norm, say ")#mi("\\delta^{1/2}")#text(". It seems like one can already conclude Roth’s theorem here.")

#text("Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-536650")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2020")])]

#text("Almost periodicity will give a good contribution from ")#mi("{\\mathbb E}(f|{\\mathcal B}^{\\prime})")#text(", but only on a relatively small number of shifts ")#mi("r")#text(" (a lower bound of ")#mi("\\gg_\\delta N")#text(". The ")#mi("U^2")#text(" control of ")#mi("f- {\\mathbb E}(f|{\\mathcal B}^{\\prime})")#text(" is not strong enough to control its contribution on such a sparse set of shifts, so one cannot conclude any nontrivial lower bound on the number of 3-term APs this way.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/724a5f80344d8c833d5f96098156b6474d7241d0645221f832a2cf430c495e55-d0c51b33bad4c6bd68b860e2c692845dc25308fcf7971962b7e0162cc488bbfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hc")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-536901")[#strong[#text("hc")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2020")])]

#text("Thanks for your quick reply, this is very helpful!")

#text("I missed that ")#mi("\\mathbb{E}(f | \\mathcal{B}^{\\prime})")#text(" has another dependency on ")#mi("\\delta")#text(" (coming from ")#mi("\\mathcal{B}^{\\prime}")#text(" having ")#mi("O_{\\delta}(1)")#text(" atoms), hence I thought I can still have enough shifts ")#mi("r")#text(" independent of ")#mi("\\delta")#text(" :(")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a8653ab8dfac3a25c6f9340943b33970aa07b2ad6caf3ef2abe1d67163efdec5-1415eb6c7007c23d93e793782eb1ea04e9adfd85195233713cf70b9cbe27af22.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S M")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-560066")[#strong[#text("S M")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("Dear Professor Tao, if you do not terribly mind a couple of stupid questions, could you please comment on how to actually prove that ")#mi("1_[a,b]")#text(" is Fourier-measurable? I do not quite understand what Fejer summation means but do you mean that one should define take our ")#mi("f_K")#text(" to be ")#mi("C_K 1_{[a,b]}=1_[a,b]*F_K")#text(" where ")#mi("F_K")#text(" denotes the Fejer kernel?")

#text("Secondly, I simply cannot wrap my head around what the definition of ")#mi("\\int_1^1 1_{E_t}")#text(" is. Usually, if I had to calculate such an integral I would try to approximate such a function by simple functions and then using the monotone convergence theorem or something similar. However, I do not quite know how to work with this integral of ")#mi("1_{E_t}")#text(". Thank you for patiently reading my questions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a8653ab8dfac3a25c6f9340943b33970aa07b2ad6caf3ef2abe1d67163efdec5-1415eb6c7007c23d93e793782eb1ea04e9adfd85195233713cf70b9cbe27af22.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S M")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-560067")[#strong[#text("S M")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("Sorry, I meant ")#mi("\\int_{-1}^1 1_{E_t(n)}\\mathrm{d}t")#text(" and ")#mi("1_{[a,b]}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a8653ab8dfac3a25c6f9340943b33970aa07b2ad6caf3ef2abe1d67163efdec5-1415eb6c7007c23d93e793782eb1ea04e9adfd85195233713cf70b9cbe27af22.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S M")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-560443")[#strong[#text("S M")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2020")])]

#text("I think I (with some help from my teacher!) just figured out what the definition of ")#mi("E_t")#text(" should naturally be")#linebreak()#text(" ")#mi("\\int_{-1}^{1}1_{E_t}(n)\\mathrm{d}t=\\int_{[-1,1]\\cap [g(n),\\infty)} 1  \\mathrm{d}t=\\int_{[g(n),1]} 1  \\mathrm{d}t")#text(" where we define ")#mi("g(n)=\\Re e(-\\alpha n+\\theta)")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c620300871938edc7f2479f0b0ba17f6903f20059bdfee397e078d5f2e3fd338-45a5bbb177a9bc377bcb72337273c93904f6fd03f53e7444ff36d00194d60ff8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek Khetan")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-562934")[#strong[#text("Abhishek Khetan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2020")])]

#text("Dear Professor Tao,")

#text("In the section on the density increment argument, when you wrote “…conclude that the left-hand side of (1) can be expressed as…” I think you meant to refer to Equation (2) rather than Equation (1).")

#text("Thank you.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-636907")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2021")])]

#text("Dear Prof. Tao,")

#text("In the corollary 19(here) or ( or cor. 1.2.9 from textbook)")

#text("What is meant by the term “generated”. You have used this term several times and I am unable to infer its meaning. The argument says:")

#text("1. there exists a refinement generated by ")#mi("\\mathcal{B}")#text(" generated by at most ")#mi("2M")#text(" atoms.")

#text("2.We let ")#mi("\\mathcal{B}^{\\prime}")#text(" be the factor generated by ")#mi("\\mathcal{B}")#text(" and ")#mi("E")#text(".")

#text("3. How does it follow from ")#tao-math("\\left|\\langle f-\\mathbb{E}(f|\\mathcal{B}),1_E\\rangle_{L^2(N)}\\right|>>\\delta", block: false)#text(" and the fact that ")#mi("1_E")#text(" is measurable with respect to to $\\mathcal{B’}$ that")#linebreak()#text(" ")#tao-math("\\left|\\langle \\mathbb{E}(f|\\mathcal{B^{\\prime}})-\\mathbb{E}(f|\\mathcal{B}),1_E\\rangle_{L^2(N)}\\right|>>\\delta", block: false)

#emph[#text("[See ")#link("https://en.wikipedia.org/wiki/%CE%A3-algebra#%CF%83-algebra_generated_by_an_arbitrary_family")[#text("https://en.wikipedia.org/wiki/%CE%A3-algebra#%CF%83-algebra_generated_by_an_arbitrary_family")]#text(" -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-636908")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2021")])]

#text("Can you please elaborate or give details on how to proceed with question 3? I am unable to follow directly. Thank you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-685780")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2024")])]

#text("Dear Prof Tao,")

#text("It’s always bothered me: If ")#mi("A")#text(" and ")#mi("P")#text(" have some significant overlap, then doesn’t this mean that $A$ contains AP’s?")

#text("Maybe this is just very ironic, or does it imply some overall limit about the proofs that appeal to random sets having plenty of AP’s?")

#text("Thank you, David.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/08/254b-notes-2-roths-theorem/#comment-685788")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2024")])]

#text("A random subset of an arithmetic progression ")#mi("P")#text(" (e.g., a set formed by selecting 50% of the elements of ")#mi("P")#text(" at random) will have large overlap in ")#mi("P")#text(", but only contain relatively small arithmetic progressions on the average (if the original progression is of length ")#mi("N")#text(", the largest progression in the random subset is typically of size ")#mi("\\log N")#text(" or so), as most of the longer progressions will be decimated by the random subselection process.")
]
]
