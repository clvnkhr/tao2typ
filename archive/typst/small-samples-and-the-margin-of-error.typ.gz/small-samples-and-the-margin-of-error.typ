// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/
// Converted to Typst by tao2typ: "2026-10-14T15:16:53.071163+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Small samples, and the margin of error", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Small samples, and the margin of error")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 October 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/")[#text("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The U.S. presidential election is now only a few weeks away. The politics of this election are of course interesting and important, but I do ")#emph[#text("not")]#text(" want to discuss these topics here (there is not exactly a shortage of other venues for such a discussion), and would request that readers refrain from doing so in the comments to this post. However, I thought it would be apropos to talk about some of the basic mathematics underlying electoral polling, and specifically to explain the fact, which can be highly unintuitive to those not well versed in statistics, that polls can be accurate even when sampling only a tiny fraction of the entire population.")

#text("Take for instance a nationwide poll of U.S. voters on which presidential candidate they intend to vote for. A typical poll will ask a number ")#mi("n")#text(" of randomly selected voters for their opinion; a typical value here is ")#mi("n = 1000")#text(". In contrast, the total voting-eligible population of the U.S. – let’s call this set ")#mi("X")#text(" – is about 200 million. (The actual turnout in the election is likely to be closer to 100 million, but let’s ignore this fact for the sake of discussion.) Thus, such a poll would sample about 0.0005% of the total population ")#mi("X")#text(" – an incredibly tiny fraction. Nevertheless, the ")#link("http://en.wikipedia.org/wiki/Margin_of_error")[#text("margin of error")]#text(" (at the 95% ")#link("http://en.wikipedia.org/wiki/Confidence_interval")[#text("confidence level")]#text(") for such a poll, if conducted under idealised conditions (see below), is about 3%. In other words, if we let ")#mi("p")#text(" denote the proportion of the entire population ")#mi("X")#text(" that will vote for a given candidate ")#mi("A")#text(", and let ")#mi("\\overline{p}")#text(" denote the proportion of the polled voters that will vote for ")#mi("A")#text(", then the event ")#mi("\\overline{p}-0.03 \\leq p \\leq \\overline{p}+0.03")#text(" will occur with probability at least 0.95. Thus, for instance (and oversimplifying a little – see below), if the poll reports that 55% of respondents would vote for A, then the true percentage of the electorate that would vote for A has at least a 95% chance of lying between 52% and 58%. Larger polls will of course give a smaller margin of error; for instance the margin of error for an (idealised) poll of 2,000 voters is about 2%.")

#text("I’ll give a rigorous proof of a weaker version of the above statement (giving a margin of error of about 7%, rather than 3%) in an appendix at the end of this post. But the main point of my post here is a little different, namely to address the common misconception that the accuracy of a poll is a function of the ")#emph[#text("relative")]#text(" sample size rather than the ")#emph[#text("absolute")]#text(" sample size, which would suggest that a poll involving only 0.0005% of the population could not possibly have a margin of error as low as 3%. I also want to point out some limitations of the mathematical analysis; depending on the methodology and the context, some polls involving 1000 respondents may have a much higher margin of error than the idealised rate of 3%.")

#metadata(none) <tao-8c6f1a79183578be255f>

#heading(level: 1)[#text("— Assumptions and conclusion —")]

#text("Not all polls are created equal; there are a certain number of hypotheses on the methodology and effectiveness of the poll that we have to assume in order to make our mathematical conclusions valid. We will make the following idealised assumptions:")

#enum(start: 1, 
[#strong[#text("Simple question. ")]#text("Voters polled can only offer one of two responses, which I will call A and not-A; thus we ignore the effect of third-party candidates, undecided voters, or refusals to respond. In particular, we do not try to combine this data with other questions about the polled voters, such as demographic data. We also assume that the question is unambiguous and cannot be misinterpreted by respondents (see Hypothesis 3 below).")],
[#strong[#text("Perfect response rate.")]#text(" All voters polled offer a response; there are no refusals to respond to the poll, or failures to make contact with the voter being polled. (This is a special case of 1., but deserves to be emphasised.) In particular, this excludes polls that are ")#link("http://en.wikipedia.org/wiki/Self-selection")[#text("self-selected")]#text(", such as internet polls (since in most cases, a large fraction of viewers of a web page with a poll will refuse to respond to that poll).")],
[#strong[#text("Honest responses")]#text(". The response given by a voter to the poll is an accurate representation whether that voter intends to vote for ")#mi("A")#text(" or not; thus we ignore response-distorting effects such as the ")#link("http://en.wikipedia.org/wiki/Bradley_effect")[#text("Bradley effect")]#text(" or ")#link("http://en.wikipedia.org/wiki/Push_poll")[#text("push-polling")]#text(", as well as ")#link("http://en.wikipedia.org/wiki/Tactical_voting")[#text("tactical voting")]#text(", frivolous responses, misunderstanding of the question, or attempts to “game” a poll by the respondents.")],
[#strong[#text("Fixed poll size.")]#text(" The number ")#mi("n")#text(" of polled voters is fixed in advance; in particular, one cannot keep polling until one has achieved some desired outcome, and then stop.")],
[#link("http://en.wikipedia.org/wiki/Simple_random_sample")[#strong[#text("Simple random sampling")]]#text(" (without replacement). Each one of the ")#mi("n")#text(" voters polled is selected ")#link("http://en.wikipedia.org/wiki/Uniform_distribution_(discrete)")[#text("uniformly at random")]#text(" among the entire population ")#mi("X")#text(", thus each voter is equally likely to be selected by the poll, and no non-voter can be selected by the poll. (In particular, we make the important assumption that there is no ")#link("http://en.wikipedia.org/wiki/Selection_bias")[#text("selection bias")]#text(".) Furthermore, each polled voter is chosen ")#link("http://en.wikipedia.org/wiki/Statistical_independence")[#text("independently")]#text(" of all the others, except for the one condition that we do not poll any given voter more than once. (Thus, once a voter is polled, that voter is “crossed off the list” of the pool ")#mi("X")#text(" of voters that one randomly selects from to determine the next voter polled.) In particular, we assume that the poll is not ")#link("http://en.wikipedia.org/wiki/Cluster_sampling")[#text("clustered")]#text(".")],
[#strong[#text("Honest reporting.")]#text(" The results of the poll are always reported, with no inaccuracies; one cannot cancel, modify, or ignore a poll once it has begun. In particular, one cannot conduct multiple polls and only report the “best” results (thus running the risk of ")#link("http://en.wikipedia.org/wiki/Confirmation_bias")[#text("confirmation bias")]#text(").")]
)

#text("Polls which deviate significantly from these hypotheses (e.g. due to complex questions, self-selection or other selection bias, confirmation bias, inaccurate responses, a high refusal rate, variable poll size, or clustering) will generally be less accurate than an idealised poll with the same sample size. Of course, there is a substantial literature in statistics (and polling methodology) devoted to measuring, mitigating, avoiding, or compensating for these less ideal situations, but we will not discuss those (important) issues here. We will remark though that in practice it is difficult to make the poll selection truly uniform. For instance, if one is conducting a telephone poll, then the sample will of course be heavily biased towards those voters who actually own phones; a little more subtly, it will also be biased toward those voters who are near their phones at the time the poll was conducted, and have the time and inclination to answer phone calls. As long as these factors are not strongly ")#link("http://en.wikipedia.org/wiki/Correlation")[#text("correlated")]#text(" with the poll question (i.e. whether the voter will vote for A), this is not a major concern, but in some cases, the poll methodology will need to be adjusted (e.g. by reweighting the sample) to compensate for the non-uniformity.")

#text("As stated in the introduction, we let ")#mi("p")#text(" be the proportion of the entire population ")#mi("X")#text(" that will vote for ")#mi("A")#text(", and ")#mi("\\overline{p}")#text(" be the proportion of the polled voters that will vote for ")#mi("A")#text(" (which, by Hypotheses 2 and 3, is exactly equal to the proportion of polled voters that say that they will vote for ")#mi("A")#text("). Under the above idealised conditions, if the number ")#mi("n")#text(" of polled voters is 1,000, and the size of the population ")#mi("X")#text(" is 200 million, then the margin of error is about 3%, thus ")#mi("{\\Bbb P}( \\overline{p}-0.03 \\leq p \\leq \\overline{p} + 0.03 ) \\geq 0.95")#text(". (See this ")#link("http://www.americanresearchgroup.com/moe.html")[#text("margin of error calculator")]#text(" for what happens with different choices of parameters.)")

#text("There is an important subtlety here: it is only the ")#emph[#text("unconditional")]#text(" probability of the event ")#mi("\\overline{p}-0.03 \\leq p \\leq \\overline{p} + 0.03")#text(" that is guaranteed to be greater than 0.95. If one has additional ")#link("http://en.wikipedia.org/wiki/Prior_probability")[#text("prior")]#text(" information about ")#mi("p")#text(" and ")#mi("\\overline{p}")#text(", then the ")#link("http://en.wikipedia.org/wiki/Conditional_probability")[#emph[#text("conditional")]#text(" probability")]#text(" of this event, relative to this information, may be very different. For instance, if one had, prior to the poll, a very good reason to believe that ")#mi("p")#text(" is almost certainly between 0.4 and 0.6, and then the poll reports ")#mi("\\overline{p}")#text(" to be 0.1, then the conditional probability that ")#mi("\\overline{p}-0.03 \\leq p \\leq \\overline{p}+0.03")#text(" occurs should be lower than the unconditional probability. [Note though that having priori information just about ")#mi("p")#text(", and not ")#mi("\\overline{p}")#text(", will not cause the probability to drop below 95%, as this bound on the confidence level is uniform in ")#mi("p")#text(".] The question of how to account for prior information is a very delicate one in ")#link("http://en.wikipedia.org/wiki/Bayesian_probability")[#text("Bayesian probability")]#text(", and will not be discussed here.")

#text("One special case of the above point is worth emphasising: the statement that ")#mi("\\overline{p}-0.03 \\leq p \\leq \\overline{p} + 0.03")#text(" is true with at least 95% probability is only valid ")#emph[#text("before")]#text(" one actually conducts the poll and finds out the value of ")#mi("\\overline{p}")#text(". Once ")#mi("\\overline{p}")#text(" is computed, the statement ")#mi("\\overline{p}-0.03 \\leq p \\leq \\overline{p} + 0.03")#text(" is either true or false, i.e. occurs with probability 1 or 0 (unless one takes a Bayesian approach, as mentioned above). [This phenomenon of course occurs all the time in probability. For instance, if x denotes the outcome of rolling a fair six-sided die, then before one performs this roll, the probability that x equals 1 will be 1/6, but after one has seen what the value of this die is, the probability that x equals 1 will be either 1 or 0.]")

#heading(level: 1)[#text("— Nobody asked for my opinion! —")]

#text("One intuitive argument against a poll of small relative size being accurate goes something like this: a poll of just 1,000 people among a population of 200,000,000 is almost certainly not going to poll myself, or any of my friends or acquaintances. If the opinions of myself, and everyone that I know, is not being considered at all in this poll, how could this poll possibly be accurate?")

#text("It is true that if you know, say, 5,000 voting-eligible people, then chances are that none of them (or maybe one of them, at best) will be contacted by the above poll. However, even though the opinions of all these people are not being directly polled, there will be many other people with ")#emph[#text("equivalent")]#text(" opinions that ")#emph[#text("will")]#text(" be contacted by the poll. Through those people, the views of yourself and your friends are being represented. [This may seem like a very weak form of representation, but recall that you and your 5,000 friends and acquaintances still only represent 0.0025% of the total electorate.]")

#text("Now one may argue that no two voters are identical, and that each voter arrives at a decision of who to vote for their own unique reasons. True enough – but recall that this poll is asking only a ")#emph[#text("simple")]#text(" question: whether one is going to vote for A or not. Once one narrowly focuses on this question alone, any two voters who both decide to vote for A, or to not vote for A, are considered equivalent, even if they arrive at this decision for totally different reasons. So, for the purposes of this poll, there are only two types of voters in the world – A-voters, and not-A-voters – with all voters in one of these two types considered equivalent. In particular, any given voter is going to have millions of other equivalent voters distributed throughout the population ")#mi("X")#text(", and a representative fraction of those equivalent voters is likely to be picked up by the poll.")

#text("As mentioned before, polls which offer complex questions (for instance, trying to discern the motivation behind one’s voting choices) will inherently be less accurate; there are now fewer equivalent voters for each individual, and it is harder for a poll to pick up each equivalence class in a representative manner. (In particular, the more questions that are asked, the more likely it becomes that the responses to at least one of these questions will be inaccurate by an amount exceeding its margin of error. This provides a limit as to how much information one can confidently extract from ")#link("http://en.wikipedia.org/wiki/Data_mining")[#text("data mining")]#text(" any given data set.)")

#heading(level: 1)[#text("— Is there enough information? —")]

#text("Another common objection to the accuracy of polls argues that there is not enough information (or “degrees of freedom”) present in the poll sample to accurately describe the much larger amount of data present in the full population; 1,000 bits of data cannot possibly contain 200,000,000 bits of information. However, we are not asking to find out so much information; the purpose of the poll is to estimate just a ")#emph[#text("single")]#text(" piece of information, namely the number ")#mi("p")#text(". If one is willing to accept an error of up to 3%, then one can represent this piece of information in about five bits rather than 200,000,000. So, in principle at least, there is more than enough information present in the poll to recover this information; one does not need to sample the entire population to get a good reading. (The same general philosophy underlies ")#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/")[#text("compressed sensing")]#text(", but that’s another story.)")

#text("As before, the accuracy degrades as one asks more and more complicated questions. For instance, if one were to poll 1,000 voters for their opinions on two unrelated questions A and B, each of the answers to A and B would be accurate to within 3% with probability 95%, but the probability that the answers to A and B were simultaneously accurate to within 3% would be lower (around 90% or so), and so any data analysis that relies on the responses to both A and B may not have as high a confidence level as data analysis that relies on A and B separately. This is consistent with the information-theoretic perspective: we are demanding more and more bits of information on our population, and it is harder for our fixed data set to supply so much information accurately and confidently.")

#heading(level: 1)[#text("— Swings —")]

#text("One intuitive way to gauge the margin of error of a poll is to see how likely such a poll is to accurately detect a swing in the electorate. Suppose for instance that over the course of a given time period (e.g. a week), 7% of the voters switch their vote from not-A to A, while another 2% of the voters switch their vote from A to not-A, leading to a net increase of 5% in the proportion ")#mi("p")#text(" of voters voting for A. How would this swing in the vote affect the proportion ")#mi("\\overline{p}")#text(" of the voters being polled, if one imagines the same voters being polled at both the start of the week and at the end of the week?")

#text("If the poll was conducted by simple random sampling, then each of the 1,000 voters polled would have a 7% probability of switching from not-A to A, and and a 2% probability of switching from A to not-A. Thus, one would expect about 70 of the 1,000 voters polled to switch to A, and about 20 to switch to not-A, leading to a net swing of 50 voters, that would increase ")#mi("\\overline{p}")#text(" by 5%, thus matching the increase in p. Now, in practice, there will be some variability here; due to the luck of the draw, the poll may pick up more or less than 70 of the voters switching to A, and more or less than 20 of the voters switching to not-A. But having 1,000 voters to sample is just about large enough for the ")#link("http://en.wikipedia.org/wiki/Law_of_large_numbers")[#text("law of large numbers")]#text(" to kick in and ensure that the number of voters switching to A picked up by the poll will be significantly larger than the number of voters switching to not-A. Thus, this poll will have a good chance of detecting a swing of size 5% or more, which is consistent with the assertion of a margin of error of about 3%. [In appealing to the law of large numbers, we are implicitly exploiting the uniformity and independence assumptions in Hypothesis 5.]")

#text("It is worth noting that this swing of 5% in an electorate of 200,000,000 voters represents quite a large shift in absolute terms: fourteen million voters switching to A and four million switching away from A. Quite a few of these shifting voters will be picked up by the poll (in contrast to one’s sphere of friends and acquaintances, which is likely to be missed completely).")

#heading(level: 1)[#text("— Irregularity —")]

#text("Another intuitive objection to polling accuracy is that the voting population is far from homogeneous. For instance, it is clear that voting preferences for the U.S. presidential election vary widely among the 50 states – shouldn’t one need to multiply the poll size by 50 just to accomodate this fact? Similarly for distinctions in voting patterns based on gender, race, party affiliation, etc.")

#text("Again, these irregularities in voter distribution do not affect the final accuracy of the poll, for two reasons. Firstly, we are asking only the simple question of whether a voter votes for A or not-A, and are not breaking down the answers to this question by state, gender, race, or any other factor; as stated before, two voters are considered equivalent as long as they have the same preference for A, even if they are in different states, have different genders, etc. Secondly, while it is conceivable that the poll will cluster its sample in one particular state (or one particular gender, etc.), thus potentially skewing the poll, the fact that the voters are selected uniformly ")#emph[#text("and")]#text(" independently of each other prevents this from happening very often. (And in any event, clustering in a demographic or geographic category is not what is of direct importance to the accuracy of the poll; the only thing that really matters in the end is whether there is clustering in the category of A-voters or not-A-voters.) The independence hypothesis is rather important. If for instance one were to poll by picking one particular location in the U.S. at random, and polling 1,000 people from that location, then the responses would be highly correlated (as one could have picked a location which happens to highly favour A, or highly favour not-A) and would have a much larger margin of error than if one polled 1,000 people at random across the U.S..")

#text("[Incidentally, in the specific case of the U.S. presidential election, statewide polls are in fact more relevant to the outcome of the election than nationwide polls, due to the mechanics of the ")#link("http://en.wikipedia.org/wiki/Electoral_College_(United_States)")[#text("U.S. Electoral College")]#text(", but this does not detract from the above points.]")

#heading(level: 1)[#text("— Analogies —")]

#text("Some analogies may help explain why the relative size of a sample is largely irrelevant to the accuracy of a poll.")

#text("Suppose one is in front of a large body of water (e.g. a sea or ocean), and wants to determine whether it is a freshwater or saltwater body. This can be done very easily: dip one’s finger into the body of water and taste a single drop. This gives an extremely accurate result, even though the relative proportion of the sample size to the population size is, literally, a drop in the ocean; the quintillions of water molecules and salt molecules present in that drop are more than sufficient to give a good reading of the salinity of the water body.")

#text("[To be fair, in order for this reading to be accurate, one needs to assume that the salinity is uniformly distributed across the body of water; if for instance the body happened to be nearly fresh on one side and much saltier on the other, then dipping one’s finger in just one of these two sides would lead to an inaccurate measurement of average salinity. But if one were to stir the body of water vigorously, this irregularity of distribution disappears. The procedure of taking a random sample, with each sample point being independent of all the others, is analogous to this stirring procedure.]")

#text("Another analogy comes from digital imaging. As we all know, a digital camera takes a picture of a real-world object (e.g. a human face) and converts it into an array of pixels; an image with a larger number of pixels will generally lead to a more accurate image than one with fewer. But even with just a handful of pixels, say 1,000 pixels, one is already able to make crude distinctions between different images, for instance to distinguish a light-skinned face from a dark-skinned face (despite the fact that skin colour is determined by millions of cells and quintillions of pigment molecules). See for instance this well-known (and ")#emph[#text("very")]#text(" low resolution) image of a US president, by ")#link("http://en.wikipedia.org/wiki/Leon_Harmon")[#text("Leon Harmon")]#text(":")

#align(center)[#link("https://terrytao.wordpress.com/wp-content/uploads/2008/10/lincoln.jpg")[#image("../assets/520e7366e6f49ef236e2641ed3b643a7f4c592efaacc78292ac0ebdb19994646-61d9fc84cba0cc5a3fcb3b2e0cdca6feae7c35c5a1646a739cd5cfd376ef155d.jpg", width: 90%)]]

#heading(level: 1)[#text("— Appendix: Mathematical justification —")]

#text("One can compute the margin of error for this simple sampling problem very precisely using the ")#link("http://en.wikipedia.org/wiki/Binomial_distribution")[#text("binomial distribution")]#text("; however I would like to present here a cruder but more robust estimate, based on the ")#link("http://en.wikipedia.org/wiki/Second_moment_method")[#text("second moment method")]#text(", that works in much greater generality than the setting discussed here. (It is closely related to the arguments in my ")#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/")[#text("previous post on the law of large numbers")]#text(".) The main mathematical result we need is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem.")]#text(" Let X be a finite set, let A be a subset of X, and let ")#tao-math("p := \\left|A\\right|/\\left|X\\right|", block: false)#text(" be the proportion of elements of X that lie in A. Let ")#mi("x_1, \\ldots, x_n")#text(" be sampled ")#link("http://en.wikipedia.org/wiki/Independent_and_identically-distributed_random_variables")[#text("independently and uniformly")]#text(" at random from X (in particular, we allow repetitions). Let ")#tao-math("\\overline{p} := \\left|\\{1 \\leq i \\leq n: x_i \\in A \\}\\right|/n", block: false)#text(" be the proportion of the ")#mi("x_1,\\ldots,x_n")#text(" (counting repetition) that lie in A. Then for any ")#mi("r > 0")#text(", one has")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("{\\Bbb P}( \\left|\\overline{p}-p\\right| \\leq r ) \\geq 1 - \\frac{1}{4 n r^2}.", block: true)]]
]

#strong[#text("Proof.")]#text(" We use the second moment method. For each ")#mi("1 \\leq i \\leq n")#text(", let ")#mi("I_i")#text(" be the ")#link("http://en.wikipedia.org/wiki/Indicator_function")[#text("indicator")]#text(" of the event ")#mi("x_i \\in A")#text(", thus ")#mi("I_i := 1")#text(" when ")#mi("x_i \\in A")#text(" and ")#mi("I_i = 0")#text(" otherwise. Observe that each ")#mi("I_i")#text(" has a probability of p of equaling 1, thus")

#align(center)[#tao-fit-display[#mitex("p = {\\Bbb E} I_i.")]]

#text("On the other hand, we have")

#align(center)[#mi("\\overline{p} = \\frac{1}{n} \\sum_{i=1}^n I_i")#text(".")]

#text("Thus")

#align(center)[#mi("\\overline{p}-p = \\frac{1}{n} \\sum_{i=1}^n I_i - {\\Bbb E}(I_i)")#text(";")]

#text("squaring this and taking expectations, we obtain")

#align(center)[#tao-fit-display[#tao-math("{\\Bbb E} \\left|\\overline{p}-p\\right|^2 = \\frac{1}{n^2} \\sum_{i=1}^n {\\bf Var}(I_i) + \\frac{2}{n} \\sum_{1 \\leq i < j \\leq n} {\\bf Cov}(I_i,I_j)", block: true)]]

#text("where ")#mi("{\\bf Var}(I_i) := {\\Bbb E} (I_i-{\\Bbb E} I_i)^2")#text(" is ")#link("http://en.wikipedia.org/wiki/Variance")[#text("variance")]#text(" of ")#mi("I_i")#text(", and ")#mi("{\\bf Cov}(I_i,I_j) := {\\Bbb E}( (I_i-p) (I_j-p))")#text(" is the ")#link("http://en.wikipedia.org/wiki/Covariance")[#text("covariance")]#text(" of ")#mi("I_i, I_j")#text(".")

#text("By assumption, the random variable ")#mi("I_i, I_j")#text(" for ")#mi("i \\neq j")#text(" are ")#link("http://en.wikipedia.org/wiki/Statistical_independence")[#text("independent")]#text(", and so the covariances ")#mi("{\\bf Cov}(I_i, I_j)")#text(" vanish. On the other hand, a direct computation shows that")

#align(center)[#tao-fit-display[#mitex("{\\bf Var}(I_i) = p - p^2 = \\frac{1}{4} - (p-\\frac{1}{2})^2 \\leq \\frac{1}{4}")]]

#text("for each i. Putting all this together we conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\Bbb E} \\left|\\overline{p}-p\\right|^2 \\leq \\frac{1}{4n}", block: true)]]

#text("and the claim (1) follows from ")#link("http://en.wikipedia.org/wiki/Markov%27s_inequality")[#text("Markov’s inequality")]#text(". ")#mi("\\Box")

#text("Applying this theorem with n=1000 and ")#mi("r=1/\\sqrt{200} \\approx 0.07")#text(", we conclude that p and ")#mi("\\overline{p}")#text(" lie within about 7% of each other with probability at least 95%, regardless of how large the population X is. In the context of an election poll, this means that if one samples 1000 voters independently at random (with replacement) whether they would vote for A, the margin of error for the answer would be at most 7% at the 95% confidence level.")

#strong[#text("Remark 1.")]#text(" Observe that the proof of the above theorem did not really need the ")#mi("x_i")#text(" to be fully independent of each other; the key thing was that each ")#mi("x_i")#text(" was close to uniformly distributed, and that the covariances between the indicators ")#mi("I_i, I_j")#text(" were small. (Thus one only needs ")#link("http://en.wikipedia.org/wiki/Pairwise_independence")[#text("pairwise independence")]#text(" rather than joint independence for the theorem to hold.) Because of this, one can also obtain variants of the above theorem when one selects ")#mi("x_1,\\ldots,x_n")#text(" for random sampling without replacement (known as ")#link("http://en.wikipedia.org/wiki/Simple_random_sample")[#text("simple random sampling")]#text("); now there is a slight correlation between ")#mi("I_i, I_j")#text(", but it turns out to be negligible when X is large, for instance when n=1000 and ")#tao-math("\\left|X\\right| \\sim 10^8", block: false)#text(". (For this range of parameters, there is a non-trivial probability of a ")#link("http://en.wikipedia.org/wiki/Birthday_paradox")[#text("birthday paradox")]#text(" occurring, so the two sampling methods are genuinely different from each other; but they turn out to have almost the same margin of error anyway.) ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" If one assumes joint independence instead of pairwise independence, one can obtain slightly sharper inequalities than (1) (e.g. by using the ")#link("http://en.wikipedia.org/wiki/Chernoff_inequality")[#text("Chernoff inequality")]#text("), but at the 95% confidence level, this gives a relatively modest improvement only in the margin of error (in our specific example, the optimal margin of error is about 3% rather than 7%). ")#mi("\\diamond")

#strong[#text("Remark 3.")]#text(" An inspection of the argument shows that if p is known to be very small or very large, then the margin of error is better than what (1) predicts. (In the most extreme case, if p=0 or p=1, then it is easy to see that the margin of error is zero.) But in the case of election polls, p is generally expected to be close to 1/2, and so one does not expect to be able to improve the margin of error much from this effect. And in any case, we don’t know the value of p exactly in practice (otherwise why would we be doing the poll in the first place?). ")#mi("\\diamond")

#strong[#text("Remark 4.")]#text(" In real world situations, it can be difficult or impractical to get the ")#mi("x_i")#text(" to be close to uniformly distributed (because of ")#link("http://en.wikipedia.org/wiki/Sampling_bias")[#text("sampling bias")]#text("), and to keep the correlations low (because of effects such as ")#link("http://en.wikipedia.org/wiki/Cluster_sampling")[#text("clustering")]#text("). Because of this, one often needs to perform a more complicated sampling procedure than simple random sampling, which requires more sophisticated statistical analysis than given by the above theorem. This is beyond the scope of this post, though. ")#mi("\\diamond")

#text("[")#emph[#text("Updated")]#text(", October 13: added emphasis that the confidence level only applies before one performs the poll, not afterwards.]")

#text("[")#emph[#text("Updated")]#text(", October 17: Minor corrections; thanks to Tom Verhoeff for pointing them out.]")

#heading(level: 1)[#text("Comments (40)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of weiyu")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-32892")[#strong[#text("weiyu")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2008")])]

#text("thanks. interesting article.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed47655a0b6e41c7e83d4d211e5345668792424b727e0d997098b7094e7f3f85-ca11d7e3eebf3d4414fe4492885285ff33f95818aeb223994bee6120b39466ff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hmm")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-32902")[#strong[#text("hmm")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2008")])]

#text("very difficult article, did not understand any of it. :) but it’s ok, i am used to your posts being super difficult :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d66e59dfaf4c1f23d86627efca833f89af52e6dd450fdfad4c7be628b56ef6a1-fc158ecc1a4b2828b0f0cdb036c53612151235fdb8f5f36262298284e94658e8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of eyeadventures")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-32911")[#strong[#text("eyeadventures")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2008")])]

#text("I could understand a part of this. Looking very informative.")

#text("eyeadventures.wordpress.com")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36b360c6eb6e8d0b9c41dff389f56325eaa85940b38dece7e905757ab330b247-d1738e234b06d3bdc93788630c04b8451a598291cdd28e84af4c85dff38d6f1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ed Jones")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-32912")[#strong[#text("Ed Jones")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2008")])]

#text("This is a really useful post. We conduct random sample research in an event marketing measurement context. These are things I worry about and try to point out when I see a client take results and run with them that may have significant weaknesses. For example, very high level executives are not nearly as likely to respond to a poll because they are very busy or they have an assistant screen their correspondence, so they are under-represented in the result.")

#text("Also, people tend to believe everything they hear on TV and the myriad of polls we see reported daily have many of these issues. I believe that is why networks famously called states incorrectly on election day. I would guess we are usually looking at close to 10% possible (not probable) error on most of the better political polls reported on TV.")

#text("Thanks for a very thoughtful article. If you could dumb it down a bit, it should be required reporting on every network.")

#text("Ed Jones")#linebreak()#text(" Constellation Communication Corp. ")#link("http://constellationcc.com")[#text("http://constellationcc.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18b8dc6dae58da908f8f66d2a586cb2201f4488f96f304eaf1992c6fd9077c16-c11f51f1c9c09138053269ffe54c1be2079dce5cd52a14286e5b53bd07f3e35e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bradlongo")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-32919")[#strong[#text("bradlongo")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2008")])]

#text("nice post. I found this really interesting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62942d750091f8c80f6661ac7ba4a1565d6877a1c4224387312917011e7abfcd-a7be0f019f6b83420fd09a7277d4cfcd13c4d527d321828313f346021fcbc257.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mohammadyasir")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-32920")[#strong[#text("mohammadyasir")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2008")])]

#text("interesting")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-32922")[#strong[#text("Encuestas electorales y margen de error « Series Divergentes")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2008")]

#text("[…] under Matemáticas, Series divergentes Terence Tao publicó en su blog el artículo Small samples, and the margin of error, en el cual discute las matemáticas de las encuestas electorales, al menos las ideas básicas en […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-32930")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2008")]

#text("[…] Small samples, and the margin of error The U.S. presidential election is now only a few weeks away. The politics of this election are of course interesting […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-32932")[#strong[#text("Let’s Read The Internet! Week 1 « Arcsecond")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2008")]

#text("[…] <h4>Small samples, and the margin of error</h4> […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-32939")[#strong[#text("Mathematics of Elections: Polling « OU Math Club")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2008")]

#text("[…] his blog, Terence Tao discusses the mathematics of how one verify the confidence level and margin of error even when you only poll […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5cc1e72603efc0b3666d5c66e777d73284ee98fde6c3d1597958b8e323fb0591-f070305225a29897b5259ddeb0cec737cd5090a58cd5679408e3bdfb9655c57d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jonm")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-32940")[#strong[#text("jonm")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2008")])]

#text("There seems to be a typo in the equation after “Putting all this together we conclude that”. The n^2 should just be an n. ")#emph[#text("[Fixed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c52890d2455c85550314e6bfbc242643d736a8badc718c0b0a166c34604dd74-a9fe5f81dae205058d767585ed2a58993fc1f2a17e3183034e2795d97a2eef3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Asher Silvera")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-32941")[#strong[#text("David Asher Silvera")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2008")])]

#text("…”there is not exactly a shortage of other venues for such a discussion”…[ about the U.S. presidential election]")#linebreak()#text(" This must be the understatement of the year!")#linebreak()#text(" Congratulations on your very wise decision not to discuss this topic.")#linebreak()#text(" As usual I am overwhelmed by the diversity of subjects about which")#linebreak()#text(" you are able to write so intelligently.")#linebreak()#text(" Dear Terry , just to prove you are human, could you tell us about something you do NOT know?")#linebreak()#text(" Best, Asher")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Sogge")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-32948")[#strong[#text("Chris Sogge")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2008")])]

#text("A big factor in the accuracy of Presidential polls is the common practice of weighting for party ID. Most seem to do it now. Some, such as Rasmussen are up front about it, and he’s been pretty accurate in past races. Currently he weighs Democrats 6% more heavily than Republicans, and he has Obama up by 6. In other cases, you have to dig into the internals to see what’s behind the polls. For instance, Newsweek just came up with a national poll saying that Obama was up by 11 points. Digging into their internals, of the people polled, 27 percent were Republican, 40 percent Democrat, and 30 percent Independent. That’s a 13 point spread of Democrats versus Republicans. Over the last 5 presidential elections, the biggest spread between Democrats and Republicans was 4 points. In 2004, the spread was even, 37-37. Over the last 5 presidential elections, the spread never changed by more than 4 points.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-33014")[#strong[#text("Wiskundemeisjes » De wiskunde achter polls")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2008")]

#text("[…] Tao schreef op zijn blog een mooi artikel over de wiskunde achter polls: Small samples, and the margin of error. Hoe kan een steekproef van slechts duizend Amerikanen nou voorspellen wat er gebeurt als miljoenen […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04aad16f81c2b743761ecb7fa3b91ab282d4c444910d3ebfef47d83f18625271-b081378830f1f7299d4191010eb744bb728dfd635d8e573393e8ad71f926cfd4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kieran")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-33064")[#strong[#text("Kieran")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2008")])]

#text("….if the poll reports that 55% of respondents would vote for A, then the true percentage of the electorate that would vote for A has at least a 95% chance of lying between 52% and 58%.")

#text("This isn’t true. The 95% probability refers to the sampling error, not to the interval itself. The true population percentage is either in the interval or it is not. If we conducted the same survey many times, drawing a new sample each time, and we calculated the 95% confidence interval around the estimated proportion in each of these, then we would have many confidence intervals. 95% of these would contain the true population percentage, 5% would not.")

#text("When conducting only one survey, there is a 95% probability that you will draw a sample which will produce a confidence interval that contains the population parameter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-33065")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2008")])]

#text("Dear Kieran,")

#text("Yes, you are right; I say in the post that this is an oversimplification, and discuss it in detail a little later in the post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd35b18525f4110cd3268a36343a624cc0757f2c82a42db0ac195907268b9fd2-884a451732ea9aee114ce205cf58e1c6e545414767e3ca2fffb0f91e5fbc2b4e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DTyson")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-33067")[#strong[#text("DTyson")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2008")])]

#text("Kieran,")#linebreak()#text(" Well noted. I stress this very concept to my Statistics students. 95% confidence is NOT 95% probability. This notion is unsettlingly subtle, but really important to understand.")

#text("I think most of the difficulty lies in the idea that long term relative frequencies are empirical probabilities, and so relative frequencies are connected with probabilities in my students’ minds.")

#text("If I remember correctly from “The Lady Tasting Tea” (by David Salsburg), the first appearance of the confidence interval (as we know it today) was met with some skepticism precisely because the interval estimate either captures the parameter or doesn’t. So have we really gotten an interval estimate of the parameter? Well, with 95% confidence we have…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-33073")[#strong[#text("Ruminations » Blog Archive » A Contrarian View: Why Should I Vote?")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2008")]

#text("[…] to look at state voting populations and assume that polling simply reads general trends. But the math behind using small sample set polling, done properly, is overwhelming. Confidence ratings on sampling are […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86ab09aa091e235463696b6846f77b1c9825d19c9d171b012067b2c586e9a511-4c9da47dbeaab2678989a059548313ab299353aca78b27802d5bb61c572bead0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Neven")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-33074")[#strong[#text("Neven")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2008")])]

#text("Terry,")

#text("Thank you for an illuminating article, especially about the difference in probabilities of a statement about p before and after the poll. I am thinking about weather forecasts which commonly state that the probability of rain tomorrow is say 80%. If I always disregard such forecast and go picnicking, in my lifetime I’ll end up wet 80% of time. However, if I decide to picnick tomorrow I am going to be either wet or dry and nothing more can be said today about the situation. Am I right?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mavis")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-33213")[#strong[#text("mavis")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2008")])]

#text("Any introductory statistics book / class explains this, and in a much easier-to-understand way. Everyone should be required to take a little statistics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The inverse conjecture for the Gowers norm over finite fields via the correspondence principle « What’s new")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-33367")[#strong[#text("The inverse conjecture for the Gowers norm over finite fields via the correspondence principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2008")])]

#text("[…] moderately large sample sizes can be accurate even when the overall population is enormous (see my previous post for more discussion on this). To cut a long story short, this shuffling (or “statistical […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-33532")[#strong[#text("How Polling Works « Curious Ramblings")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2008")]

#text("[…] Polling Works Terrence Tao has a great blog entry about the mathematics of polling. One thing he points out, which to me at first was unintuitive, is that polling accuracy is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-33574")[#strong[#text("Margin of Error « I’m just a simple DBA on a complex production system")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2008")]

#text("[…] you are really interested in the subject and not afraid of some mathematical notation, Terence Tao has a much deeper analysis of the subject. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/597f971cb349154326b3f1a080323b3c527c236b21b5f17f0c3c5e7f1ec64862-20f9211aa491f07bf9cf80f85c433374050ca0d111476a24760076463ae621f4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of balkrishnapatankar")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-34240")[#strong[#text("balkrishnapatankar")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2008")])]

#text("Thanks … Very interesting article …. Please keep writing more of such non technical but a bit mathematical posts in future")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benford’s law, Zipf’s law, and the Pareto distribution « What’s new")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-39865")[#strong[#text("Benford’s law, Zipf’s law, and the Pareto distribution « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2009")])]

#text("[…] the CIA world factbook); I have put the raw data here. This is a relatively small sample (cf. my previous post), but is already enough to discern these laws in action. For instance, here is how the data set […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dfdcb4dbc58a05d24957d7e653dbda2ee940cb2dd2cd000426ede23156f84eae-473c9688c127f8feb14da0acf8baf2d607f98c8f02e3481fa6b8109e1c6fff9c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-41820")[#strong[#text("Mike")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2009")])]

#text("Nice to look back at somthing written before the elections. Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a62f4e1adacfc00f55f9b044ceaea9de76e7fa4260580b562fb748d308ff5e3-d8d21516c435e2400db9d2dd5c1da99a556e6019972361fd15d4b103232ba813.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of April S.")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-46463")[#strong[#text("April S.")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2010")])]

#text("This is a really interesting! I love statistics and hate it when I see polls that are obviously skewed in their results. I think a big part of it is biased sampling. Poll the people who will give the answer you want and most people don’t know the difference!")

#link("http://blog.thinkwell.com/2010/08/7th-grade-math-populations-and-samples.html")[#text("http://blog.thinkwell.com/2010/08/7th-grade-math-populations-and-samples.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A second draft of a non-technical article on universality « What’s new")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-46993")[#strong[#text("A second draft of a non-technical article on universality « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2010")])]

#text("[…] Tao, “Small samples and the margin of error“, blog post, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-62072")[#strong[#text("Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2011")]

#strong[#text("How do I determine that there are less than 10% brown M&Ms in a particular group?…")]

#text("The fact that the big box is 20% brown doesn’t have any bearing — you could break the box up into groups in such a way that one of the groups was entirely brown, or such that one group was entirely red, or both. In fact, since you’re only looking at…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28553e244ffb02af63ba5effe013f8e535ce7225416350a63f63e5734e88c266-323bca10ada03b4f55b2a2348a80cb7074735df8d36bf0d85d7d8a95ee5c7829.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xoeve")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-84579")[#strong[#text("xoeve")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2011")])]

#text("This isn’t true. The 95% probability refers to the sampling error, not to the interval itself. The true population percentage is either in the interval or it is not. If we conducted the same survey many times, drawing a new sample each time, and we calculated the 95% confidence interval around the estimated proportion in each of these, then we would have many confidence intervals. 95% of these would contain the true population percentage, 5% would not.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-84733")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2011")])]

#text("Yes, the 95% probability only applies as an unconditional probability before the poll is taken, and not as a conditional probability after the poll is taken; this is discussed at the end of the “Assumptions and conclusions” section.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-416802")[#strong[#text("A mágica das pesquisas eleitorais | Economia de Pen Drive")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2014")]

#text("[…] Quer entender melhor a matemática por trás dessa história ? ")#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/")[#text("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-445083")[#strong[#text("La encuesta electoral y las intenciones políticas. Por Carlos Martínez G. | Politica Politico")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2014")]

#text("[…] [4] Terence Tao. ")#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/")[#text("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97ee7a51ca63d7c520a354ff2ada76fc57b56bab5e97c96fdc5255fe20902e96-898122d56de6f108fa6f2f0b82aa1b4708c9382a810bdb4a651d1e38ca5582b5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pollstistics | Cogito Ergo")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-462658")[#strong[#text("Pollstistics | Cogito Ergo")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2015")])]

#text("[…] more realistic number for mathematical reasons relating to the sampling itself and randomness (see Small samples, and the margin of error). Further, even this is somewhat idealized in scenario and questions can come up as to nature of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10245b25022cd7f2afca97830cffe729045ab77d43be597d2e7d42a31e1ebe20-c5877a72773e4a4e2663f2b5c3d50ba5813630ff258dad6e3839686304c528cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joung Hwang")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-466367")[#strong[#text("Joung Hwang")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2016")])]

#text("Thank you for this exposition. I have a follow-up question. Usually, any given poll asks different questions to respondents. An example would be polling about multiple different potential presidential match-ups (e.g., Trump vs. Clinton, Trump vs. Sanders, Rubio vs. Clinton, etc.) Since the same sample is being used to estimate these different match-ups, the estimates do not appear to be statistially independent to each other. How should one think about figuring out valid margins of error when a single poll is used to produce estimates for multiple questions?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-689445")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2025")])]

#text("Prof Tao,")

#text("“How does would…” should be “How does/would…”.")

#text("I am confused about one thing: you wroted that “…information (or “degrees of freedom”)…”, but how would Degrees of Freedom, which is the number of independent parameters in a system, relate to information? I don’t know why these two terms would be associated to each other.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-689446")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2025")])]

#text("Thanks for the correction!")

#text("Roughly speaking, information (or entropy) is the logarithm of the number of “")#link("https://en.wikipedia.org/wiki/Microstate_(statistical_mechanics)")[#text("microstates")]#text("” in a system, which typically grows exponentially with the number of degrees of freedom. So information tends to be proportional to the number of degrees of freedom. For instance, an image with N pixels takes around N bytes to store (without compression), because there are N degrees of freedom, and so the total number of possible states for the image is exponential in N. (Though if the image is of a “real world” nature then it often concentrates in a much smaller set of states than a completely random assortment of pixels does; so the entropy is lower, as is the effective number of degrees of freedom.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-689454")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2025")])]

#text("Dear Dr Tao,")

#text("It seems all the words “molecues” should be “molecules”. ")#emph[#text("[Corrected, thanks – T.]")]

#text("After reading this blog, I have doubts about these terms: what exactly do “margin of error” and “confidence intervals” convey in practice? How should we treat these concepts in the right way?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-689457")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2025")])]

#text("One can adopt the following “frequentist” interpretation. Suppose that a reputable polling company performs 1000 polls, each of which has a 3% margin of error at the 95% confidence level. Then, one expects 95% of them, or all but 50 of them, to report within this margin of error of 3% of the true percentage. However, one does not know which 50 of the 1000 polls performed will be off by more than 3%. (Also, the number of such “off” polls may not be *exactly* 50, but would fluctuate randomly above and below this number.)")

#text("If the polling company only reports some of these 1000 polls but fails to report others, then this may distort the percentage; it is possible for instance for a pollster to improve its apparent accuracy (or accidentally reduce their accuracy) by secretly discarding any poll whose answers look too far off from what they subjectively believe to be the truth. So if one suspects polls to only be selectively reported (e.g., one is gathering news from a partisan source that only reports favorable polls and ignores unfavorable ones), the accuracy that the margin of error would otherwise ordinarily suggest can be significantly altered. In particular, if one is only possession of a single solitary poll and no other information, then the way in which this poll came to your attention (and all other polls did not) actually becomes much more important than the nominal margin of error or nominal confidence level, as the poll could be cherry-picked amongst many such polls to support a predetermined narrative, thus creating a strong selection bias. Conversely, if one is confident that one is receiving the complete set of polls, including both favorable and unfavorable ones, then the margin of error and confidence level become more useful quantities to help give as accurate a portrait of the available information as possible.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/10/small-samples-and-the-margin-of-error/#comment-689460")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2025")])]

#text("Thanks for the reply!")

#text("There’s one thing that I am not clear about: in the first sentence you assumed that this is in the framework of “frequentist”, but when should we adopt the “bayesian” view in practice? And how to account for prior information in the Bayesian probability framework?")
]
]
]
