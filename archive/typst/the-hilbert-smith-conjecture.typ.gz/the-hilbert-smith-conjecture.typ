// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/08/13/the-hilbert-smith-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T16:36:36.256769+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Hilbert-Smith conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Hilbert-Smith conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 August 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/08/13/the-hilbert-smith-conjecture/")[#text("https://terrytao.wordpress.com/2011/08/13/the-hilbert-smith-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The classical formulation of ")#link("http://en.wikipedia.org/wiki/Hilbert's_fifth_problem")[#text("Hilbert’s fifth problem")]#text(" asks whether topological groups that have the ")#emph[#text("topological")]#text(" structure of a manifold, are necessarily Lie groups. This is indeed, the case, thanks to following theorem of ")#link("http://www.ams.org/mathscinet-getitem?mr=49203")[#text("Gleason")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=49204")[#text("Montgomery-Zippin")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Hilbert’s fifth problem)")]#text(" ")#metadata(none) <tao-4dfc9ae36d2f22700d6b>#text(" Let ")#mi("{G}")#text(" be a ")#link("http://en.wikipedia.org/wiki/Topological_group")[#text("topological group")]#text(" which is ")#link("http://en.wikipedia.org/wiki/Locally_Euclidean")[#text("locally Euclidean")]#text(". Then ")#mi("{G}")#text(" is isomorphic to a Lie group.")
]

#text("We have discussed the proof of this result, and of related results, in ")#link("https://terrytao.wordpress.com/tag/hilberts-fifth-problem/")[#text("previous posts")]#text(". There is however a generalisation of Hilbert’s fifth problem which remains open, namely the ")#link("http://en.wikipedia.org/wiki/Hilbert%E2%80%93Smith_conjecture")[#text("Hilbert-Smith conjecture")]#text(", in which it is a space acted on by the group which has the manifold structure, rather than the group itself:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2 (Hilbert-Smith conjecture)")]#text(" ")#metadata(none) <tao-780f86745746934c7b4b>#text(" Let ")#mi("{G}")#text(" be a locally compact topological group which acts continuously and faithfully (or effectively) on a connected finite-dimensional manifold ")#mi("{X}")#text(". Then ")#mi("{G}")#text(" is isomorphic to a Lie group.")
]

#text("Note that Conjecture ")#link(<tao-780f86745746934c7b4b>)[#text("2")]#text(" easily implies Theorem ")#link(<tao-4dfc9ae36d2f22700d6b>)[#text("1")]#text(" as one can pass to the connected component ")#mi("{G^\\circ}")#text(" of a locally Euclidean group (which is clearly locally compact), and then look at the action of ")#mi("{G^\\circ}")#text(" on itself by left-multiplication.")

#text("The hypothesis that the action is faithful (i.e. each non-identity group element ")#mi("{g \\in G \\backslash \\{\\text{id}\\}}")#text(" acts non-trivially on ")#mi("{X}")#text(") cannot be completely eliminated, as any group ")#mi("{G}")#text(" will have a trivial action on any space ")#mi("{X}")#text(". The requirement that ")#mi("{G}")#text(" be locally compact is similarly necessary: consider for instance the diffeomorphism group ")#mi("{\\text{Diff}(S^1)}")#text(" of, say, the unit circle ")#mi("{S^1}")#text(", which acts on ")#mi("{S^1}")#text(" but is infinite dimensional and is not locally compact (with, say, the uniform topology). Finally, the connectedness of ")#mi("{X}")#text(" is also important: the infinite torus ")#mi("{G = ({\\bf R}/{\\bf Z})^{\\bf N}}")#text(" (with the product topology) acts faithfully on the disconnected manifold ")#mi("{X := {\\bf R}/{\\bf Z} \\times {\\bf N}}")#text(" by the action")

#align(center)[#tao-fit-display[#mitex("(g_n)_{n \\in {\\bf N}} (\\theta, m) := (\\theta + g_m, m).")]]

#text("The conjecture in full generality remains open. However, there are a number of partial results. For instance, it was observed ")#link("http://www.ams.org/mathscinet-getitem?mr=73104")[#text("by Montgomery and Zippin")]#text(" that the conjecture is true for ")#emph[#text("transitive")]#text(" actions, by a modification of the argument used to establish Theorem ")#link(<tao-4dfc9ae36d2f22700d6b>)[#text("1")]#text(". This special case of the Hilbert-Smith conjecture (or more precisely, a generalisation thereof in which “finite-dimensional manifold” was replaced by “locally connected locally compact finite-dimensional”) was used in Gromov’s proof of ")#link("http://en.wikipedia.org/wiki/Gromov's_theorem_on_groups_of_polynomial_growth")[#text("his famous theorem on groups of polynomial growth")]#text(". I record the argument of Montgomery and Zippin below the fold.")

#text("Another partial result is the reduction of the Hilbert-Smith conjecture to the ")#mi("{p}")#text("-adic case. Indeed, it is known that Conjecture ")#link(<tao-780f86745746934c7b4b>)[#text("2")]#text(" is equivalent to")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 3 (Hilbert-Smith conjecture for ")#mi("{p}")#text("-adic actions)")]#text(" ")#metadata(none) <tao-f41707cee121038e26ae>#text(" It is not possible for a ")#mi("{p}")#text("-adic group ")#mi("{{\\bf Z}_p}")#text(" to act continuously and effectively on a connected finite-dimensional manifold ")#mi("{X}")#text(".")
]

#text("The reduction to the ")#mi("{p}")#text("-adic case follows from the structural theory of locally compact groups (specifically, the Gleason-Yamabe theorem discussed in ")#link("https://terrytao.wordpress.com/2011/05/30/van-dantzigs-theorem/")[#text("previous")]#text(" ")#link("https://terrytao.wordpress.com/2011/06/17/hilberts-fifth-problem-and-gleason-metrics/")[#text("posts")]#text(") and some results of Newman that sharply restrict the ability of periodic actions on a manifold ")#mi("{X}")#text(" to be close to the identity. I record this argument (which appears for instance in ")#link("http://www.ams.org/mathscinet-getitem?mr=1641899")[#text("this paper of Lee")]#text(") below the fold also.")

#metadata(none) <tao-dc2a9483dbb60ece1de6>

#heading(level: 1)[#strong[#text(" — 1. Transitive actions — ")]]

#text("We now show the transitive case of the Hilbert-Smith conjecture, following ")#link("http://www.ams.org/mathscinet-getitem?mr=73104")[#text("Montgomery and Zippin")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" Let ")#mi("{G}")#text(" be a locally compact ")#mi("{\\sigma}")#text("-compact group that acts transitively, faithfully, and continuously on a connected manifold ")#mi("{X}")#text(". Then ")#mi("{G}")#text(" is isomorphic to a Lie group.")
]

#text("The ")#mi("{\\sigma}")#text("-compact hypothesis is a technical one, and can likely be dropped, but we retain it for this discussion (as in most applications we can reduce to this case).")

#text("The advantage of transitivity is that one can now view ")#mi("{X}")#text(" as a homogeneous space ")#mi("{X=G/H}")#text(" of ")#mi("{G}")#text(", where ")#mi("{H = \\text{Stab}(x_0)}")#text(" is the stabiliser of a point ")#mi("{x_0}")#text(" (and is thus a closed subgroup of ")#mi("{G}")#text("). Note that ")#emph[#text("a priori")]#text(", we only know that ")#mi("{X}")#text(" and ")#mi("{G/H}")#text(" are identifiable as ")#emph[#text("sets")]#text(", with the identification map ")#mi("{\\iota: G/H \\rightarrow X}")#text(" defined by setting ")#mi("{\\iota( g H ) := g x_0}")#text(" being continuous; but thanks to the ")#mi("{\\sigma}")#text("-compact hypothesis, we can upgrade ")#mi("{\\iota}")#text(" to a homeomorphism. Indeed, as ")#mi("{G}")#text(" is ")#mi("{\\sigma}")#text("-compact, ")#mi("{G/H}")#text(" is also; and so given any compact neighbourhood of the identity ")#mi("{K}")#text(" in ")#mi("{G}")#text(", ")#mi("{G/H}")#text(" can be covered by countably many translates of ")#mi("{KH/H}")#text(". By the ")#link("http://en.wikipedia.org/wiki/Baire_category_theorem")[#text("Baire category theorem")]#text(", one of these translates ")#mi("{gK}")#text(" has an image ")#mi("{\\iota(gKH/H) = gKx_0}")#text(" in ")#mi("{X}")#text(" with non-empty interior, which implies that ")#mi("{K^{-1} K x_0}")#text(" has ")#mi("{x_0}")#text(" as an interior point. From this it is not hard to see that the map ")#mi("{\\iota}")#text(" is open; as it is also a continuous bijection, it is therefore a homeomorphism.")

#text("By the Gleason-Yamabe theorem, ")#mi("{G}")#text(" has an open subgroup ")#mi("{G^{\\prime}}")#text(" that is the inverse limit of Lie groups. (Note that ")#mi("{G}")#text(" is Hausdorff because it acts faithfully on the Hausdorff space ")#mi("{X}")#text(".) ")#mi("{G^{\\prime}}")#text(" acts transitively on ")#mi("{G^{\\prime}H/H}")#text(", which is an open subset of ")#mi("{G/H}")#text(" and thus also a manifold. Thus, we may assume without loss of generality that ")#mi("{G}")#text(" is itself the inverse limit of Lie groups ")#mi("{G_n = G/K_n}")#text(", where ")#mi("{K_1 \\supset K_2 \\supset \\ldots}")#text(" is a sequence of normal compact groups shrinking to the identity.")

#text("As ")#mi("{G}")#text(" is ")#mi("{\\sigma}")#text("-compact, the manifold ")#mi("{X}")#text(" is also. As ")#mi("{G}")#text(" acts faithfully on ")#mi("{X}")#text(", this makes ")#mi("{G}")#text(" first countable; and so ")#mi("{G}")#text(" is the inverse limit of a ")#emph[#text("sequence")]#text(" of Lie groups ")#mi("{G_n}")#text(", with each ")#mi("{G_{n+1}}")#text(" projecting surjectively onto ")#mi("{G_n}")#text(".")

#text("Let ")#mi("{H_n}")#text(" be the projection of ")#mi("{H}")#text(" onto ")#mi("{G_n}")#text("; this is a closed subgroup of the Lie group ")#mi("{G_n}")#text(", and each ")#mi("{H_{n+1}}")#text(" projects surjectively onto ")#mi("{H_n}")#text(". Then ")#mi("{G_n/H_n}")#text(" are manifolds, and ")#mi("{G/H}")#text(" is the inverse limit of the ")#mi("{G_n/H_n = G / HK_n}")#text(". By invariance of domain, the dimensions of the ")#mi("{G_n/H_n}")#text(" must be non-decreasing, and bounded above by the dimension of ")#mi("{G/H}")#text(". Thus, for ")#mi("{n}")#text(" large enough, the dimensions of ")#mi("{G_n/H_n}")#text(" must be constant; by renumbering, we may assume that ")#emph[#text("all")]#text(" the ")#mi("{G_n/H_n}")#text(" have the same dimension. As each ")#mi("{G_{n+1}/H_{n+1}}")#text(" is a cover of ")#mi("{G_n/H_n}")#text(" with structure group ")#mi("{K_n/K_{n+1}}")#text(", we conclude that the ")#mi("{K_n/K_{n+1}}")#text(" are zero-dimensional and compact, and thus finite. On the other hand, ")#mi("{G/H}")#text(" is locally connected, which implies that the ")#mi("{K_n/K_{n+1}}")#text(" are eventually trivial. Indeed, if we pick a simply connected neighbbourhood ")#mi("{U_1}")#text(" of the identity in ")#mi("{G_1/H_1}")#text(", then by local connectedness of ")#mi("{G/H}")#text(", there exists a connected neighbourhood ")#mi("{U}")#text(" of the identity in ")#mi("{G/H}")#text(" whose projection to ")#mi("{G_1/H_1}")#text(" is contained in ")#mi("{U_1}")#text(". Being open, ")#mi("{U}")#text(" must contain one of the ")#mi("{K_n}")#text(". If ")#mi("{K_n/K_m}")#text(" is non-trivial for any ")#mi("{m>n}")#text(", then the projection of ")#mi("{U}")#text(" to ")#mi("{G_m/H_m}")#text(" will then be disconnected (as this projection will be contained in a neighbourhood with the topological structure of ")#mi("{U \\times K_1/K_m}")#text(", and its intersection with the latter fibre is at least as large as ")#mi("{K_n/K_m}")#text(". We conclude that ")#mi("{K_n}")#text(" is trivial for ")#mi("{n}")#text(" large enough, and so ")#mi("{G = G_n}")#text(" is a Lie group as required.")

#heading(level: 1)[#strong[#text(" — 2. Periodic actions of prime order — ")]]

#text("We now study periodic actions ")#mi("{T: X \\rightarrow X}")#text(" on a manifold ")#mi("{X}")#text(" of some prime order ")#mi("{p}")#text(", thus ")#mi("{T^p = \\text{id}}")#text(".")

#text("The basic observation to exploit here is that of ")#emph[#text("rigidity")]#text(": a periodic action (or more precisely, the orbits of this action) cannot be too close to the identity, without actually ")#emph[#text("being")]#text(" the identity. More precisely, we have the following theorem of Newman:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Newman’s first theorem)")]#text(" ")#metadata(none) <tao-11507a0e2f5e69d5dfa4>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf R}^n}")#text(" containing the closed unit ball ")#mi("{B}")#text(", and let ")#mi("{T: U \\rightarrow U}")#text(" be a homeomorphism of some prime period ")#mi("{p \\geq 1}")#text(". Suppose that for every ")#mi("{x \\in U}")#text(", the orbit ")#mi("{\\{ T^n x: n = 0,1,\\ldots,p-1\\}}")#text(" has diameter strictly less than ")#mi("{1}")#text(". Then ")#mi("{T(0)=0}")#text(".")
]

#text("Note that some result like this must be needed in order to establish the Hilbert-Smith conjecture. Suppose for instance that one could find a non-trivial transformation ")#mi("{T}")#text(" of some period ")#mi("{p}")#text(" on the unit ball ")#mi("{B}")#text(" that preserved the boundary of that ball. Then by placing infinitely many disjoint copies of that ball into ")#mi("{{\\bf R}^n}")#text(", and considering maps that are equal to some power of ")#mi("{T}")#text(" on each such ball, and on the identity outside all the balls, we can obtain a faithful action of ")#mi("{({\\bf Z}/p{\\bf Z})^{\\bf N}}")#text(" on ")#mi("{{\\bf R}^n}")#text(", contradicting the Hilbert-Smith conjecture.")

#text("To prove the theorem we will need some basic ")#link("http://en.wikipedia.org/wiki/Topological_degree_theory")[#text("degree theory")]#text(". Given a continuously differentiable map ")#mi("{\\Phi: B \\rightarrow {\\bf R}^n}")#text(", we know from ")#link("http://en.wikipedia.org/wiki/Sard%27s_theorem")[#text("Sard’s theorem")]#text(" that almost every point ")#mi("{x}")#text(" in ")#mi("{{\\bf R}^n}")#text(" is a regular point, in that the preimage ")#mi("{\\Phi^{-1}(\\{x\\})}")#text(" is finite and avoids the boundary ")#mi("{\\partial B}")#text(" of ")#mi("{B}")#text(", with ")#mi("{\\nabla \\Phi(x)}")#text(" being non-degenerate at each ")#mi("{x}")#text(". We can define the ")#emph[#text("degree")]#text(" of ")#mi("{\\Phi}")#text(" at the regular point ")#mi("{x}")#text(" to be the number of preimages with ")#mi("{\\nabla \\Phi}")#text(" orientation-preserving, minus the number of preimages with ")#mi("{\\nabla \\Phi}")#text(" orientation-reversing. One can show that this degree extends to a constant integer-valued function on each connected component ")#mi("{U}")#text(" of ")#mi("{{\\bf R}^n \\backslash \\Phi(\\partial B)}")#text("; indeed, one can define the degree ")#mi("{\\text{deg}(U)}")#text(" on such a component analytically by the formula")

#align(center)[#tao-fit-display[#mitex("\\text{deg}(U) = \\int_B \\Phi^* \\omega")]]

#text("for any volume form ")#mi("{\\omega}")#text(" on ")#mi("{U}")#text(" of total mass ")#mi("{1}")#text(" (one can show that this definition is independent of the choice of ")#mi("{\\omega}")#text("). This definition is stable under uniform convergence of ")#mi("{\\Phi}")#text(", and thus can be used to also define the degree for maps ")#mi("{\\Phi}")#text(" that are merely continuous rather than continuously differentiable.")

#emph[#text("Proof:")]#text(" Suppose for contradiction that ")#mi("{T(0) \\neq 0}")#text(". We use an averaging argument, combined with ")#link("http://en.wikipedia.org/wiki/Topological_degree_theory")[#text("degree theory")]#text(". Let ")#mi("{\\Phi: U \\rightarrow {\\bf R}^n}")#text(" be the map")

#align(center)[#tao-fit-display[#mitex("\\Phi(x) := \\frac{1}{p} \\sum_{n=0}^{p-1} T^n x.")]]

#text("Then from construction, ")#mi("{\\Phi}")#text(" is continuous and ")#mi("{T}")#text("-invariant (thus ")#mi("{\\Phi(x)=\\Phi(Tx)}")#text(" for all ")#mi("{x \\in U}")#text(") and we have ")#tao-math("{\\left|\\Phi(x)-x\\right| < 1}", block: false)#text(" for all ")#mi("{x \\in U}")#text(". In particular, ")#mi("{\\Phi}")#text(" is non-zero on the boundary ")#mi("{\\partial B}")#text(" of ")#mi("{B}")#text(", and ")#mi("{\\Phi(\\partial B)}")#text(" is contractible to ")#mi("{\\partial B}")#text(" in ")#mi("{{\\bf R}^n \\backslash 0}")#text(" (by taking convex combinations of ")#mi("{\\Phi}")#text(" and the identity). As such, the degree of ")#mi("{\\Phi}")#text(" on ")#mi("{B}")#text(" near the origin is equal to ")#mi("{1}")#text(".")

#text("A similar argument shows that the homeomorphism ")#mi("{T}")#text(" has degree ")#mi("{1}")#text(" on ")#mi("{B}")#text(" near the origin, and in particular is orientation-preserving rather than orientation reversing.")

#text("On the other hand, it can be shown that the degree of ")#mi("{\\Phi}")#text(" must be divisible by ")#mi("{q}")#text(", leading to a contradiction. This is easiest to see in the case when ")#mi("{\\Phi}")#text(" is continuously differentiable, for then by Sard’s theorem we may find a regular point ")#mi("{x}")#text(" arbitrarily close to ")#mi("{0}")#text(". On the other hand, since ")#mi("{T(0)}")#text(" is a positive distance away from ")#mi("{0}")#text(", we see that for ")#mi("{x}")#text(" sufficiently close to ")#mi("{0}")#text(", ")#mi("{x}")#text(" is not a fixed point of ")#mi("{T}")#text(", and thus (as ")#mi("{T}")#text(" has prime order) all elements in the preimage ")#mi("{\\Phi^{-1}(\\{x\\})}")#text(" are not fixed points of ")#mi("{T}")#text(" either. Thus ")#mi("{\\Phi^{-1}(\\{x\\})}")#text(" can be partitioned into a finite number of disjoint orbits of ")#mi("{T}")#text(" of cardinality ")#mi("{p}")#text(". As ")#mi("{T}")#text(" is orientation preserving and ")#mi("{x}")#text(" is a regular point of ")#mi("{\\Phi}")#text(", each of these orbits contributes ")#mi("{+p}")#text(" or ")#mi("{-p}")#text(" to the degree, giving the claim.")

#text("The case when ")#mi("{\\Phi}")#text(" is not continuously differentiable is trickier, as the degree is not as easily computed in this case. One way to proceed is to perturb ")#mi("{T}")#text(" (or more precisely, the graph ")#mi("{\\{ (x, Tx, \\ldots, T^{p-1} x): x \\in U \\}}")#text(" in ")#mi("{U^p}")#text(") to be piecewise linear near the preimage of ")#mi("{0}")#text(" (while preserving the periodicity properties of the graph), so that degree can be computed by hand; this is the approach taken in Newman’s original paper. Another is to use the machinery of ")#link("http://en.wikipedia.org/wiki/Singular_homology")[#text("singular homology")]#text(", which is more general and flexible than degree theory; this is the approach taken ")#link("http://www.ams.org/leavingmsn?url=http://dx.doi.org/10.2307/1968910")[#text("by Smith")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=238353")[#text("by Dress")]#text(". ")#mi("\\Box")

#text("Note that the above argument shows not only that ")#mi("{T}")#text(" fixes the origin ")#mi("{0}")#text(", but must also fix an open neighbourhood of the origin, by translating ")#mi("{B}")#text(" slightly. One can then extend this open neighbourhood to the entire space by the following variant of Theorem ")#link(<tao-11507a0e2f5e69d5dfa4>)[#text("5")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Newman’s second theorem)")]#text(" ")#metadata(none) <tao-19fba0e995b9794fc2c2>#text(" Let ")#mi("{X}")#text(" be a connected manifold, and let ")#mi("{T: X \\rightarrow X}")#text(" be a homeomorphism of some prime order ")#mi("{p}")#text(" that fixes a non-empty open set ")#mi("{U}")#text(". Then ")#mi("{T}")#text(" is the identity.")
]

#emph[#text("Proof:")]#text(" We need to show that ")#mi("{T}")#text(" fixes all points in ")#mi("{X}")#text(", and not just ")#mi("{U}")#text(". Suppose for sake of contradiction that ")#mi("{T}")#text(" just fixes some of the points in ")#mi("{X}")#text(" and not others. By a continuity argument, and applying a homeomorphic change of variables if necessary, we can find a coordinate chart containing the ball ")#mi("{B}")#text(", where ")#mi("{T}")#text(" fixes all ")#mi("{x = (x_1,\\ldots,x_n) \\in B}")#text(" with ")#mi("{x_1 \\leq 0}")#text(", but does not fix all ")#mi("{x \\in B}")#text(" with ")#mi("{x_1 > 0}")#text(". By shrinking ")#mi("{B}")#text(" we may assume that the entire orbit ")#mi("{B, TB, \\ldots, T^{p-1} B}")#text(" stays inside the coordinate chart (and can thus be viewed as a subset of ")#mi("{{\\bf R}^n}")#text("). Then the map ")#mi("{\\Phi}")#text(" can be defined as before. This map is the identity on the left hemisphere ")#mi("{\\{ x \\in B: x_1 \\leq 0 \\}}")#text(". On the right hemisphere ")#mi("{\\{ x \\in B: x_1 > 0\\}}")#text(", one observes for ")#mi("{x}")#text(" small enough that ")#mi("{x, Tx, \\ldots, T^{p-1} x}")#text(" must all stay on the right-hemisphere (as they must lie in ")#mi("{B}")#text(" and cannot enter the left-hemisphere, where ")#mi("{T}")#text(" is the identity) and so ")#mi("{\\Phi}")#text(" stays on the right. This implies that ")#mi("{\\Phi}")#text(" has degree ")#mi("{1}")#text(" near ")#mi("{0}")#text(" on a small ball around the origin, but as before one can argue that the degree must in fact be divisible by ")#mi("{p}")#text(", leading again to a contradiction. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 3. Reduction to the ")#mi("{p}")#text("-adic case — ")]]

#text("We are now ready to prove Conjecture ")#link(<tao-780f86745746934c7b4b>)[#text("2")]#text(" assuming Conjecture ")#link(<tao-f41707cee121038e26ae>)[#text("3")]#text(". Let ")#mi("{G}")#text(" be a locally compact group acting continuously and faithfully on a connected manifold ")#mi("{X}")#text("; we wish to show that ")#mi("{G}")#text(" is Lie.")

#text("We first make some basic reductions. From the Gleason-Yamabe theorem (as discussed in this post) every locally compact group ")#mi("{G}")#text(" contains an open subgroup which is an extension of a Lie group by a compact subgroup of ")#mi("{G}")#text(". Since a group with a Lie group as an open subgroup is again Lie (because all outer automorphisms of Lie groups are smooth), and an extension of a Lie group by a Lie group is again Lie (this latter result, first ")#link("http://www.ams.org/mathscinet-getitem?mr=39730")[#text("proved by Gleason")]#text(", follows for instance from the fact that a locally compact group is Lie if and only if it is NSS), it thus suffices to prove the claim when ")#mi("{G}")#text(" is compact. In particular, all orbits of ")#mi("{G}")#text(" on ")#mi("{X}")#text(" are also compact.")

#text("Let ")#mi("{B}")#text(" be a small ball in chart of ")#mi("{X}")#text(" around some origin ")#mi("{x_0}")#text(". By continuity, there is some neighbourhood ")#mi("{U}")#text(" of the identity in ")#mi("{G}")#text(" such that ")#mi("{gB \\ni x_0}")#text(" for all ")#mi("{g \\in U}")#text(". By the Peter-Weyl theorem, there is a compact normal subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" in ")#mi("{U}")#text(" with ")#mi("{G/G^{\\prime}}")#text(" linear (and hence Lie). The set ")#mi("{G^{\\prime} B}")#text(" is then a ")#mi("{G^{\\prime}}")#text("-invariant manifold, which is precompact and connected (because all the shifts ")#mi("{gB}")#text(" are connected and share a common point). If we let ")#mi("{G^{\\prime\\prime}}")#text(" be the subgroup of ")#mi("{G^{\\prime}}")#text(" that fixes ")#mi("{G^{\\prime}B}")#text(", then ")#mi("{G^{\\prime\\prime}}")#text(" is a compact normal subgroup of ")#mi("{G^{\\prime}}")#text(", and ")#mi("{G^{\\prime}/G^{\\prime\\prime}}")#text(" acts faithfully on ")#mi("{G^{\\prime}B}")#text(". By Newman’s first theorem (Theorem ")#link(<tao-11507a0e2f5e69d5dfa4>)[#text("5")]#text("), we see that if ")#mi("{U}")#text(" is small enough, then ")#mi("{G^{\\prime}/G^{\\prime\\prime}}")#text(" cannot contain any elements of prime order, and hence cannot contain any non-trivial periodic elements whatsoever; by Conjecture ")#link(<tao-f41707cee121038e26ae>)[#text("3")]#text(", it also cannot contain a continuously embedded copy of ")#mi("{{\\bf Z}_p}")#text(" for any ")#mi("{p}")#text(". We claim that this forces ")#mi("{G^{\\prime}/G^{\\prime\\prime}}")#text(" to be trivial.")

#text("As ")#mi("{G^{\\prime}B}")#text(" is precompact, the space of ")#mi("{C(\\overline{G^{\\prime}B} \\rightarrow \\overline{G^{\\prime}B})}")#text(" of continuous maps from ")#mi("{G^{\\prime}/G^{\\prime\\prime}}")#text(" to itself (with the compact-open topology) is first countable, which makes ")#mi("{G^{\\prime}/G^{\\prime\\prime}}")#text(" first-countable as well (since ")#mi("{G^{\\prime}/G^{\\prime\\prime}}")#text(" is homeomorphic to a subspace of ")#mi("{C(\\overline{G^{\\prime}B} \\rightarrow \\overline{G^{\\prime}B})}")#text("). The claim now follows from")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7")]#text(" ")#metadata(none) <tao-5f2b1d6f5492140fa7b4>#text(" Let ")#mi("{G}")#text(" be a compact first-countable group which does not contain any non-trivial periodic elements or a continuously embedded copy of ")#mi("{{\\bf Z}_p}")#text(" for any ")#mi("{p}")#text(". Then ")#mi("{G}")#text(" is trivial.")
]

#emph[#text("Proof:")]#text(" Every element ")#mi("{g}")#text(" of ")#mi("{G}")#text(" is contained in a compact ")#emph[#text("abelian")]#text(" subgroup of ")#mi("{G}")#text(", namely the closed group ")#mi("{\\overline{\\langle g \\rangle}}")#text(" generated by ")#mi("{g}")#text(". Thus we may assume without loss of generality that ")#mi("{G}")#text(" is abelian.")

#text("As ")#mi("{G}")#text(" is both compact and first countable, it can be written (using the Peter-Weyl theorem) as the inverse limit ")#mi("{\\lim_{\\leftarrow} G_n}")#text(" of a countable sequence of compact abelian Lie groups ")#mi("{G_n}")#text(", with surjective continuous projection homomorphisms ")#mi("{\\pi_{n+1 \\rightarrow n}: G_{n+1} \\rightarrow G_n}")#text(" between these Lie groups. (Note that without first countability, one might only be an inverse limit of a ")#emph[#text("net")]#text(" of Lie groups rather than a sequence, as one can see for instance with the example ")#mi("{({\\bf R}/{\\bf Z})^{\\bf R}}")#text(".)")

#text("Suppose for contradiction that at least one of the ")#mi("{G_n}")#text(", say ")#mi("{G_1}")#text(", is non-trivial. It is a standard fact that every compact abelian Lie group is isomorphic to the direct product of a torus and a finite group. (Indeed, in the connected case one can inspect the kernel of the exponential map, and then one can extend to the general case by viewing a compact Lie group as an extension of a finite group by a connected compact Lie group.) in particular, the periodic points (i.e. points of finite order) are dense, and so there exists an element ")#mi("{g_1}")#text(" of ")#mi("{G_1}")#text(" of finite non-trivial order. By raising ")#mi("{g_1}")#text(" to a suitable power, we may assume that ")#mi("{g_1}")#text(" has some prime order ")#mi("{p}")#text(".")

#text("We now claim inductively that for each ")#mi("{n=1,2,\\ldots}")#text(", ")#mi("{g_1}")#text(" can be lifted to an element ")#mi("{g_n \\in G_n}")#text(" of some order ")#mi("{p^{k_n}}")#text(", where ")#mi("{1 = k_1 \\leq k_2 \\leq \\ldots}")#text(" are a non-decreasing set of integers. Indeed, suppose inductively that we have already lifted ")#mi("{g_1}")#text(" up to ")#mi("{g_n \\in G_n}")#text(" with order ")#mi("{p^{k_n}}")#text(". The preimage of ")#mi("{g_n}")#text(" in ")#mi("{G_{n+1}}")#text(" is then an open subset of the preimage of ")#mi("{\\langle g_n \\rangle}")#text(", which is a compact abelian Lie group, and thus contains an element ")#mi("{g^{\\prime}_{n+1}}")#text(" of some finite order. As ")#mi("{g_n}")#text(" has order ")#mi("{p^{k_n}}")#text(", ")#mi("{g^{\\prime}_{n+1}}")#text(" must have an order divisible by ")#mi("{p^{k_n}}")#text(", and thus of the form ")#mi("{p^{k_{n+1}} q}")#text(" for some ")#mi("{q}")#text(" coprime to ")#mi("{p}")#text(" and some ")#mi("{k_{n+1} \\geq k_n}")#text(". By raising ")#mi("{g^{\\prime}_{n+1}}")#text(" to a multiple of ")#mi("{q}")#text(" that equals ")#mi("{1}")#text(" mod ")#mi("{p^{k_n}}")#text(", we may eliminate ")#mi("{q}")#text(" and obtain a preimage ")#mi("{g_{n+1}}")#text(" of order ")#mi("{p^{k_{n+1}}}")#text(", and the claim follows.")

#text("There are now two cases, depending on whether ")#mi("{k_n}")#text(" goes to infinity or not. If the ")#mi("{k_n}")#text(" stay bounded, then they converge to a limit ")#mi("{k}")#text(", and the inverse limit of the ")#mi("{g_n}")#text(" is then an element ")#mi("{g}")#text(" of ")#mi("{G}")#text(" of finite order ")#mi("{p^k}")#text(", a contradiction. But if the ")#mi("{k_n}")#text(" are unbounded, then ")#mi("{G}")#text(" contains a continuously embedded copy of the inverse limit of the ")#mi("{{\\bf Z}/p^{k_n}{\\bf Z}}")#text(", which is ")#mi("{{\\bf Z}_p}")#text(", and again we have a contradiction. ")#mi("\\Box")

#text("Since ")#mi("{G^{\\prime}/G^{\\prime\\prime}}")#text(" and ")#mi("{G/G^{\\prime}}")#text(" are both Lie groups, ")#mi("{G/G^{\\prime\\prime}}")#text(" is Lie too. Thus it suffices to show that ")#mi("{G^{\\prime\\prime}}")#text(" is Lie. Without loss of generality, we may therefore replace ")#mi("{G}")#text(" by ")#mi("{G^{\\prime\\prime}}")#text(" and assume that ")#mi("{B}")#text(" is fixed by ")#mi("{G}")#text(".")

#text("Now let ")#mi("{\\Sigma}")#text(" be the closure of the interior of the set of fixed points of ")#mi("{G}")#text(". Then ")#mi("{\\Sigma}")#text(" is non-empty, and is also clearly closed. We claim that ")#mi("{\\Sigma}")#text(" is open; by connectedness of ")#mi("{X}")#text(", this implies that ")#mi("{\\Sigma=X}")#text(", which by faithfulness of ")#mi("{G}")#text(" implies that ")#mi("{G}")#text(" is trivial, giving the claim. Indeed, let ")#mi("{x \\in \\Sigma}")#text(", and let ")#mi("{B}")#text(" be a small ball around ")#mi("{x}")#text(". As before, ")#mi("{GB}")#text(" is then a connected ")#mi("{G}")#text("-invariant ")#mi("{\\sigma}")#text("-compact manifold, and so if ")#mi("{G^{\\prime}}")#text(" is the subgroup of ")#mi("{G}")#text(" that fixes ")#mi("{GB}")#text(", then ")#mi("{G/G^{\\prime}}")#text(" is a compact Lie group that acts faithfully on ")#mi("{GB}")#text(" fixing a nontrivial open subset of ")#mi("{GB}")#text(". By Newman’s theorem (Theorem ")#link(<tao-19fba0e995b9794fc2c2>)[#text("6")]#text("), ")#mi("{G/G^{\\prime}}")#text(" cannot contain any periodic elements; by Conjecture ")#link(<tao-f41707cee121038e26ae>)[#text("3")]#text(", it also cannot contain any copy of ")#mi("{{\\bf Z}_p}")#text(". By Lemma ")#link(<tao-5f2b1d6f5492140fa7b4>)[#text("7")]#text(", ")#mi("{G/G^{\\prime}}")#text(" is trivial, and so ")#mi("{G}")#text(" fixes all of ")#mi("{B}")#text(". Thus gives the desired openness of ")#mi("{\\Sigma}")#text(" as required.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Whereas actions of the finite group ")#mi("{{\\bf Z}/p{\\bf Z}}")#text(" on manifolds can be analysed by degree theory, it appears that actions of ")#mi("{p}")#text("-adic groups ")#mi("{{\\bf Z}_p}")#text(" require more sophisticated homological tools; the ")#mi("{p}")#text("-adic analogues of the averaged map ")#mi("{\\Phi}")#text(" now typically have infinite preimages and it is no longer obvious how to compute the degree of such maps. Nevertheless, some progress has been made along these lines under some additional regularity hypotheses on the action, such as Lipschitz continuity; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=1464908")[#text("this paper of Repovs and Scepin")]#text(". Note that if ")#mi("{T: X \\rightarrow X}")#text(" is the action of the generator of ")#mi("{{\\bf Z}_p}")#text(", then the powers ")#mi("{T^{p^n}: X \\rightarrow X}")#text(" will converge to the identity locally uniformly as ")#mi("{n \\rightarrow \\infty}")#text(". This is already enough to rule out generating maps ")#mi("{T}")#text(" that are smooth but non-trivial by use of Taylor expansion; see the ")#link("http://www.ams.org/mathscinet-getitem?mr=73104")[#text("text of Montgomery and Zippin")]#text(". (In fact, this type of argument even works for ")#mi("{C^1}")#text(" actions.)")
]

#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 0 – Hilbert’s fifth problem and related topics « What’s new")]], [#link("https://terrytao.wordpress.com/2011/08/13/the-hilbert-smith-conjecture/#comment-70860")[#strong[#text("254A, Notes 0 – Hilbert’s fifth problem and related topics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2011")])]

#text("[…] fifth problem for group actions, known as the Hilbert-Smith conjecture, which was discussed at this blog post.) To answer this question, we need to relax the notion of a Lie group to that of a topological […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e84b6f8e0e937f4fb4aa554bcbc4ab0cfed90db5f356bcfca1a5dc032206eb-df0274d4fa00182253b22e6fdbcf17c1937d8d5713184d5d85ead37c4e2a9a72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of handaoyuan")]], [#link("https://terrytao.wordpress.com/2011/08/13/the-hilbert-smith-conjecture/#comment-71339")[#strong[#text("handaoyuan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2011")])]

#text("Hello, Professor Tao, Louis F. McAuley has published his preprint in arxiv about the proof of Hilbert-Smith conjecture.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a42cba640f2f48d3f054903d909fb2ce11e1a826b0a5390f8e42d4684bea591b-5dce9a925b3fb33ba098ac4f22ed772ccac177173e57b03a627300d00316757a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of More on Hilbert’s tenth problem | cartesian product")]], [#link("https://terrytao.wordpress.com/2011/08/13/the-hilbert-smith-conjecture/#comment-82312")[#strong[#text("More on Hilbert’s tenth problem | cartesian product")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")])]

#text("[…] The Hilbert-Smith conjecture (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 5: The structure of locally compact groups, and Hilbert’s fifth problem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/08/13/the-hilbert-smith-conjecture/#comment-90827")[#strong[#text("254A, Notes 5: The structure of locally compact groups, and Hilbert’s fifth problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2011")])]

#text("[…] difficulty is to figure out a way to eliminate the possibility that is a -adic group . See this previous blog post for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21693cd7f2b10021ea643d3931e0b6778904e97d2acb8b7b673761965350539b-6ef14631a8b9368510a5dc2caaf5e92066c08889d66d7b945f9025d88d4321dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On Tao’s talk and the 3-dimensional Hilbert-Smith conjecture « Area 777")]], [#link("https://terrytao.wordpress.com/2011/08/13/the-hilbert-smith-conjecture/#comment-141872")[#strong[#text("On Tao’s talk and the 3-dimensional Hilbert-Smith conjecture « Area 777")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2012")])]

#text("[…] mentioned in Tao’s post, in fact is the only possible bad case! i.e. it is sufficient to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/13/the-hilbert-smith-conjecture/#comment-226791")[#strong[#text("IPAM’s program “Interactions between Analysis and Geometry” and John Pardon’s talk on Hilbert-Smith conjecture for 3-manifolds | Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2013")]

#text("[…] recommend consulting Terence Tao’s notes on Hilbert’s 5th problem (as well as his post here on Hilbert-Smith […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/13/the-hilbert-smith-conjecture/#comment-466678")[#strong[#text("Hilbert’s Problems: Part 1 | mathsbyagirl")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2016")]

#text("[…] seen to be resolved by Andrew Gleason in 1954, however if it is seen to be equivalent to the Hilbert-Smith Conjecture, then it remains […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af9caae6febe5d6f9af61610108ef30c06711f173398a24f01ad2dac282d32eb-48d2574699d73596f7ffd2e774c6fad0286c722d22968087d4c12ee6c199cab1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/13/the-hilbert-smith-conjecture/#comment-474517")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2016")])]

#text("Dear Prof. Tao,")

#text("In your statement of Hilbert’s 5th, needn’t we assume G is second-countable? For example, the real line with the discrete topology is locally Euclidean and is not isomorphic to a Lie group.")

#text("Thanks.")

#emph[#text("[I am not requiring manifolds (or Lie groups) here to be second countable, though one can certainly impose this condition if desired (it doesn’t change the difficulty of Hilbert’s fifth much) -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/562f778a672442c36297f0c0c5e35b7944dd7437388dfb60710ae12dee5e6add-263540662e9778abf68885a1f03e6dfebbe13cf20c048d7e863f8113eb90a95f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammed Mannan")]], [#link("https://terrytao.wordpress.com/2011/08/13/the-hilbert-smith-conjecture/#comment-685184")[#strong[#text("Mohammed Mannan")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2024")])]

#text("After reading your book “Hilbert’s fifth problem and related topics,” what other background readings do you recommend to understand John Pardon’s proof of the Hilbert–Smith conjecture for three manifolds?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/13/the-hilbert-smith-conjecture/#comment-685194")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2024")])]

#text("I’m afraid you’ll have to consult a low-dimensional topologist for a proper answer to that question. My knowledge of the subject roughly encompasses what ")#link("https://pi.math.cornell.edu/~hatcher/AT/AT.pdf")[#text("Hatcher’s book on algebraic topology")]#text(" covers; I highly recommend that book, but I’m pretty sure Pardon uses more results from low-dimensional topology than is covered there.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/562f778a672442c36297f0c0c5e35b7944dd7437388dfb60710ae12dee5e6add-263540662e9778abf68885a1f03e6dfebbe13cf20c048d7e863f8113eb90a95f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammed Mannan")]], [#link("https://terrytao.wordpress.com/2011/08/13/the-hilbert-smith-conjecture/#comment-685691")[#strong[#text("Mohammed Mannan")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2024")])]

#text("In the proof of Lemma 7 that g_1 can be successively lifted, I’m unsure that “the preimage of g_n in G_(n+1) is then a dense subset of the preimage of <g_n>” is true, for example, the identity is in the preimage of <g_n>, whereas the preimage of g_n does not contain the identity so it has a neighborhood disjoint from a neighborhood of the identity.")

#text("I was able to proceed by observing that a lift of g_n, raised to k_n, is in the kernel of the projection map, and then multiplying by a suitable element in the kernel of the projection map using the fact that it is a torus x a finite abelian group.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/13/the-hilbert-smith-conjecture/#comment-685695")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2024")])]

#text("Oops, “dense” should be “open” in that sentence. I have edited accordingly.")
]
]
