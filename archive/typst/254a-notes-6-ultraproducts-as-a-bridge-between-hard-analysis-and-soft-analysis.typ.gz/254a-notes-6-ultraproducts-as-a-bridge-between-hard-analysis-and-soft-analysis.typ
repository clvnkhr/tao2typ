// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/
// Converted to Typst by tao2typ: "2026-10-14T16:36:40.677865+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 6: Ultraproducts as a bridge between hard analysis and soft analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 6: Ultraproducts as a bridge between hard analysis and soft analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 October 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Roughly speaking, mathematical analysis can be divided into two major styles, namely ")#emph[#text("hard analysis")]#text(" and ")#emph[#text("soft analysis")]#text(". The precise distinction between the two types of analysis is imprecise (and in some cases one may use a blend the two styles), but some key differences can be listed as follows.")

#list(
[#text("Hard analysis tends to be concerned with ")#emph[#text("quantitative")]#text(" or ")#emph[#text("effective")]#text(" properties such as estimates, upper and lower bounds, convergence rates, and growth rates or decay rates. In contrast, soft analysis tends to be concerned with ")#emph[#text("qualitative")]#text(" or ")#emph[#text("ineffective")]#text(" properties such as existence and uniqueness, finiteness, measurability, continuity, differentiability, connectedness, or compactness.")],
[#text("Hard analysis tends to be focused on ")#emph[#text("finitary")]#text(", ")#emph[#text("finite-dimensional")]#text(" or ")#emph[#text("discrete")]#text(" objects, such as finite sets, finitely generated groups, finite Boolean combination of boxes or balls, or “finite-complexity” functions, such as polynomials or functions on a finite set. In contrast, soft analysis tends to be focused on ")#emph[#text("infinitary")]#text(", ")#emph[#text("infinite-dimensional")]#text(", or ")#emph[#text("continuous")]#text(" objects, such as arbitrary measurable sets or measurable functions, or abstract locally compact groups.")],
[#text("Hard analysis tends to involve explicit use of many parameters such as ")#mi("{\\epsilon}")#text(", ")#mi("{\\delta}")#text(", ")#mi("{N}")#text(", etc. In contrast, soft analysis tends to rely instead on properties such as continuity, differentiability, compactness, etc., which ")#emph[#text("implicitly")]#text(" are defined using a similar set of parameters, but whose parameters often do not make an ")#emph[#text("explicit")]#text(" appearance in arguments.")],
[#text("In hard analysis, it is often the case that a key lemma in the literature is not quite optimised for the application at hand, and one has to reprove a slight variant of that lemma (using a variant of the proof of the original lemma) in order for it to be suitable for applications. In contrast, in soft analysis, key results can often be used as “black boxes”, without need of further modification or inspection of the proof.")],
[#text("The properties in soft analysis tend to enjoy precise closure properties; for instance, the composition or linear combination of continuous functions is again continuous, and similarly for measurability, differentiability, etc. In contrast, the closure properties in hard analysis tend to be fuzzier, in that the parameters in the conclusion are often different from the parameters in the hypotheses. For instance, the composition of two Lipschitz functions with Lipschitz constant ")#mi("{K}")#text(" is still Lipschitz, but now with Lipschitz constant ")#mi("{K^2}")#text(" instead of ")#mi("{K}")#text(". These changes in parameters mean that hard analysis arguments often require more “bookkeeping” than their soft analysis counterparts, and are less able to utilise algebraic constructions (e.g. quotient space constructions) that rely heavily on precise closure properties.")]
)

#text("In the lectures so far, focusing on the theory surrounding Hilbert’s fifth problem, the results and techniques have fallen well inside the category of soft analysis. However, we will now turn to the theory of approximate groups, which is a topic which is traditionally studied using the methods of hard analysis. (Later we will also study groups of polynomial growth, which lies on an intermediate position in the spectrum between hard and soft analysis, and which can be profitably analysed using both styles of analysis.)")

#text("Despite the superficial differences between hard and soft analysis, though, there are a number of important ")#emph[#text("correspondences")]#text(" between results in hard analysis and results in soft analysis. For instance, if one has some sort of uniform quantitative bound on some expression relating to finitary objects, one can often use limiting arguments to then conclude a qualitative bound on analogous expressions on infinitary objects, by viewing the latter objects as some sort of “limit” of the former objects. Conversely, if one has a qualitative bound on infinitary objects, one can often use ")#emph[#text("compactness and contradiction arguments")]#text(" to recover uniform quantitative bounds on finitary objects as a corollary.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Another type of correspondence between hard analysis and soft analysis, which is “syntactical” rather than “semantical” in nature, arises by taking the ")#emph[#text("proofs")]#text(" of a soft analysis result, and translating such a qualitative proof somehow (e.g. by carefully manipulating quantifiers) into a quantitative proof of an analogous hard analysis result. This type of technique is sometimes referred to as ")#emph[#text("proof mining")]#text(" in the proof theory literature, and is discussed in ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("this previous blog post")]#text(" (and its comments). We will however not employ systematic proof mining techniques here, although in later posts we will informally borrow arguments from infinitary settings (such as the methods used to construct Gleason metrics) and adapt them to finitary ones.")
]

#text("Let us illustrate the correspondence between hard and soft analysis results with a simple example.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" ")#metadata(none) <tao-84bae4db933bb6e48e3d>#text(" Let ")#mi("{X}")#text(" be a ")#link("http://en.wikipedia.org/wiki/Sequentially_compact_space")[#text("sequentially compact")]#text(" topological space, let ")#mi("{S}")#text(" be a dense subset of ")#mi("{X}")#text(", and let ")#mi("{f: X \\rightarrow [0,+\\infty]}")#text(" be a continuous function (giving the extended half-line ")#mi("{[0,+\\infty]}")#text(" the usual order topology). Then the following statements are equivalent:")

#list(
[#text("(i) (Qualitative bound on infinitary objects) For all ")#mi("{x \\in X}")#text(", one has ")#mi("{f(x) < +\\infty}")#text(".")],
[#text("(ii) (Quantitative bound on finitary objects) There exists ")#mi("{M < +\\infty}")#text(" such that ")#mi("{f(x) \\leq M}")#text(" for all ")#mi("{x \\in S}")#text(".")]
)
]

#text("In applications, ")#mi("{S}")#text(" is typically a (non-compact) set of “finitary” (or “finite complexity”) objects of a certain class, and ")#mi("{X}")#text(" is some sort of “completion” or “compactification” of ")#mi("{S}")#text(" which admits additional “infinitary” objects that may be viewed as limits of finitary objects.")

#emph[#text("Proof:")]#text(" To see that (ii) implies (i), observe from density that every point ")#mi("{x}")#text(" in ")#mi("{X}")#text(" is adherent to ")#mi("{S}")#text(", and so given any neighbourhood ")#mi("{U}")#text(" of ")#mi("{x}")#text(", there exists ")#mi("{y \\in S \\cap U}")#text(". Since ")#mi("{f(y) \\leq M}")#text(", we conclude from the continuity of ")#mi("{f}")#text(" that ")#mi("{f(x) \\leq M}")#text(" also, and the claim follows.")

#text("Conversely, to show that (i) implies (ii), we use the “compactness and contradiction” argument. Suppose for sake of contradiction that (ii) failed. Then for any natural number ")#mi("{n}")#text(", there exists ")#mi("{x_n \\in S}")#text(" such that ")#mi("{f(x_n) \\geq n}")#text(". (Here we have used the axiom of choice, which we will assume throughout this course.) Using sequential compactness, and passing to a subsequence if necessary, we may assume that the ")#mi("{x_n}")#text(" converge to a limit ")#mi("{x \\in X}")#text(". By continuity of ")#mi("{f}")#text(", this implies that ")#mi("{f(x) = +\\infty}")#text(", contradicting (i). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" Note that the above deduction of (ii) from (i) is ")#emph[#text("ineffective")]#text(" in that it gives no explicit bound on the uniform bound ")#mi("{M}")#text(" in (ii). Without any further information on ")#emph[#text("how")]#text(" the qualitative bound (i) is proven, this is the best one can do in general (and this is one of the most significant weaknesses of infinitary methods when used to solve finitary problems); but if one has access to the proof of (i), one can often ")#emph[#text("finitise")]#text(" or ")#emph[#text("proof mine")]#text(" that argument to extract an effective bound for ")#mi("{M}")#text(", although often the bound one obtains in the process is quite poor (particularly if the proof of (i) relied extensively on infinitary tools, such as limits). See ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("this blog post")]#text(" for some related discussion.")
]

#text("The above simple example illustrates that in order to get from an “infinitary” statement such as (i) to a “finitary” statement such as (ii), a key step is to be able to take a sequence ")#mi("{(x_n)_{n \\in {\\bf N}}}")#text(" (or in some cases, a more general ")#link("http://en.wikipedia.org/wiki/Net_(mathematics)")[#text("net")]#text(" ")#mi("{(x_\\alpha)_{\\alpha \\in A}}")#text(") of finitary objects and extract a suitable infinitary limit object ")#mi("{x}")#text(". In the literature, there are three main ways in which one can extract such a limit:")

#list(
[#text("(Topological limit) If the ")#mi("{x_n}")#text(" are all elements of some topological space ")#mi("{S}")#text(" (e.g. an incomplete function space) which has a suitable “compactification” or “completion” ")#mi("{X}")#text(" (e.g. a Banach space), then (after passing to a subsequence if necessary) one can often ensure the ")#mi("{x_n}")#text(" converge in a topological sense (or in a metrical sense) to a limit ")#mi("{x}")#text(". The use of this type of limit to pass between quantitative/finitary and qualitative/infinitary results is particularly common in the more analytical areas of mathematics (such as ergodic theory, asymptotic combinatorics, or PDE), due to the abundance of useful compactness results in analysis such as the (sequential) ")#link("http://en.wikipedia.org/wiki/Banach%E2%80%93Alaoglu_theorem")[#text("Banach-Alaoglu theorem")]#text(", ")#link("http://en.wikipedia.org/wiki/Prokhorov%27s_theorem")[#text("Prokhorov’s theorem")]#text(", the ")#link("http://en.wikipedia.org/wiki/Helly_selection_theorem")[#text("Helly selection theorem")]#text(", the ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0%E2%80%93Ascoli_theorem")[#text("Arzelá-Ascoli theorem")]#text(", or even the humble ")#link("http://en.wikipedia.org/wiki/Bolzano%E2%80%93Weierstrass_theorem")[#text("Bolzano-Weierstrass theorem")]#text(". However, one often has to take care with the nature of convergence, as many compactness theorems only guarantee convergence in a weak sense rather than in a strong one.")],
[#text("(Categorical limit) If the ")#mi("{x_n}")#text(" are all objects in some category (e.g. metric spaces, groups, fields, etc.) with a number of morphisms between the ")#mi("{x_n}")#text(" (e.g. morphisms from ")#mi("{x_{n+1}}")#text(" to ")#mi("{x_n}")#text(", or vice versa), then one can often form a ")#link("http://en.wikipedia.org/wiki/Direct_limit")[#text("direct limit")]#text(" ")#mi("{\\lim_{\\rightarrow} x_n}")#text(" or ")#link("http://en.wikipedia.org/wiki/Inverse_limit")[#text("inverse limit")]#text(" ")#mi("{\\lim_{\\leftarrow} x_n}")#text(" of these objects to form a limiting object ")#mi("{x}")#text(". The use of these types of limits to connect quantitative and qualitative results is common in subjects such as algebraic geometry that are particularly amenable to categorical ways of thinking. (We have seen inverse limits appear in the discussion of Hilbert’s fifth problem, although in that context they were not really used to connect quantitative and qualitative results together.)")],
[#text("(Logical limit) If the ")#mi("{x_n}")#text(" are all distinct spaces (or elements or subsets of distinct spaces), with few morphisms connecting them together, then topological and categorical limits are often unavailable or unhelpful. In such cases, however, one can still tie together such objects using an ")#link("http://en.wikipedia.org/wiki/Ultraproduct")[#text("ultraproduct")]#text(" construction (or similar device) to create a limiting object ")#mi("{\\lim_{n \\rightarrow \\alpha} x_n}")#text(" or limiting space ")#mi("{\\prod_{n \\rightarrow \\alpha} x_n}")#text(" that is a ")#emph[#text("logical limit")]#text(" of the ")#mi("{x_n}")#text(", in the sense that various properties of the ")#mi("{x_n}")#text(" (particularly those that can be phrased using the language of first-order logic) are preserved in the limit. As such, logical limits are often very well suited for the task of connecting finitary and infinitary mathematics together. Ultralimit type constructions are of course used extensively in logic (particularly in model theory), but are also popular in metric geometry. They can also be used in many of the previously mentioned areas of mathematics, such as algebraic geometry (as discussed in ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("this previous post")]#text(").")]
)

#text("The three types of limits are analogous in many ways, with a number of connections between them. For instance, in the study of groups of polynomial growth, both topological limits (using the metric notion of ")#link("http://en.wikipedia.org/wiki/Gromov%E2%80%93Hausdorff_convergence")[#text("Gromov-Hausdorff convergence")]#text(") and logical limits (using the ")#link("http://en.wikipedia.org/wiki/Ultralimit")[#text("ultralimit")]#text(" construction) are commonly used, and to some extent the two constructions are at least partially interchangeable in this setting. (See also ")#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/")[#text("these previous")]#text(" ")#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/")[#text("posts")]#text(" for the use of ultralimits as a substitute for topological limits.) In the theory of approximate groups, though, it was observed ")#link("http://arxiv.org/abs/0909.2190")[#text("by Hrushovski")]#text(" that logical limits (and in particular, ")#emph[#text("ultraproducts")]#text(") are the most useful type of limit to connect finitary approximate groups to their infinitary counterparts. One reason for this is that one is often interested in obtaining results on approximate groups ")#mi("{A}")#text(" that are uniform in the choice of ambient group ")#mi("{G}")#text(". As such, one often seeks to take a limit of approximate groups ")#mi("{A_n}")#text(" that lie in completely unrelated ambient groups ")#mi("{G_n}")#text(", with no obvious morphisms or metrics tying the ")#mi("{G_n}")#text(" to each other. As such, the topological and categorical limits are not easily usable, whereas the logical limits can still be employed without much difficulty.")

#text("Logical limits are closely tied with ")#link("http://en.wikipedia.org/wiki/Non-standard_analysis")[#text("non-standard analysis")]#text(". Indeed, by applying an ultraproduct construction to standard number systems such as the natural numbers ")#mi("{{\\bf N}}")#text(" or the reals ")#mi("{{\\bf R}}")#text(", one can obtain nonstandard number systems such as the nonstandard natural numbers ")#mi("{{}^* {\\bf N}}")#text(" or the nonstandard real numbers (or ")#link("http://en.wikipedia.org/wiki/Hyperreal_number")[#text("hyperreals")]#text(") ")#mi("{{}^* {\\bf R}}")#text(". These nonstandard number systems behave very similarly to their standard counterparts, but also enjoy the advantage of containing the standard number systems as proper subsystems (e.g. ")#mi("{{\\bf R}}")#text(" is a subring of ")#mi("{{}^* {\\bf R}}")#text("), which allows for some convenient algebraic manipulations (such as the quotient space construction to create spaces such as ")#mi("{{}^* {\\bf R} / {\\bf R}}")#text(") which are not easily accessible in the purely standard universe. Nonstandard spaces also enjoy a useful completeness property, known as ")#link("http://en.wikipedia.org/wiki/Saturated_model")[#text("countable saturation")]#text(", which is analogous to metric completeness (as discussed in ")#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/")[#text("this previous blog post")]#text(") and which will be particularly useful for us in tying together the theory of approximate groups with the theory of Hilbert’s fifth problem. See this previous post for more discussion on ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("ultrafilters and nonstandard analysis")]#text(".")

#text("In these notes, we lay out the basic theory of ultraproducts and ultralimits (in particular, proving ")#link("http://en.wikipedia.org/wiki/Ultraproduct#.C5.81o.C5.9B.27s_theorem")[#text("Los’s theorem")]#text(", which roughly speaking asserts that ultralimits are limits in a logical sense, as well as the countable saturation property alluded to earlier). We also lay out some of the basic foundations of nonstandard analysis, although we will not rely too heavily on nonstandard tools in this course. Finally, we apply this general theory to approximate groups, to connect finite approximate groups to an infinitary type of approximate group which we will call an ")#emph[#text("ultra approximate group")]#text(". We will then study these ultra approximate groups (and models of such groups) in more detail in the next set of notes.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" Throughout these notes (and in the rest of the course), we will assume the ")#link("http://en.wikipedia.org/wiki/Axiom_of_choice")[#text("axiom of choice")]#text(", in order to easily use ultrafilter-based tools. If one really wanted to expend the effort, though, one could eliminate the axiom of choice from the proofs of the final “finitary” results that one is ultimately interested in proving, at the cost of making the proofs significantly lengthier. Indeed, there is a general ")#link("http://www.ncbi.nlm.nih.gov/pmc/articles/PMC1077160/")[#text("result of Gödel")]#text(" that any result which can be stated in the language of Peano arithmetic (which, roughly speaking, means that the result is “finitary” in nature), and can be proven in set theory using the axiom of choice (or more precisely, in the ")#link("http://en.wikipedia.org/wiki/Zermelo%E2%80%93Fraenkel_set_theory")[#text("ZFC axiom system")]#text("), can also be proven in set theory without the axiom of choice (i.e. in the ZF system). As this course is not focused on foundations, we shall simply assume the axiom of choice henceforth to avoid further distraction by such issues.")
]

#metadata(none) <tao-769dea68b8731c7aff8d>

#heading(level: 1)[#strong[#text(" — 1. Ultrafilters — ")]]

#text("The concept of an ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilter")]#text(" will be fundamental. We will only need to consider ultrafilters on the natural numbers ")#mi("{{\\bf N}}")#text(", although one can certainly consider ultrafilters on more general sets.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (Ultrafilter)")]#text(" An ")#emph[#text("filter")]#text(" ")#mi("{\\alpha}")#text(" on the natural numbers is a collection of sets of natural numbers obeying the following axioms:")

#list(
[#text("(Monotonicity) If ")#mi("{E \\subset F \\subset {\\bf N}}")#text(", and ")#mi("{E \\in \\alpha}")#text(", then ")#mi("{F \\in \\alpha}")#text(".")],
[#text("(Intersection) If ")#mi("{E, F \\in \\alpha}")#text(", then ")#mi("{E \\cap F \\in \\alpha}")#text(".")],
[#text("(Properness) ")#mi("{\\emptyset \\not \\in \\alpha}")#text(".")]
)

#text("An ")#emph[#text("ultrafilter")]#text(" ")#mi("{\\alpha}")#text(" on the natural numbers is a filter which obeys an additional axiom:")

#list(
[#text("(Maximality) If ")#mi("{E \\subset {\\bf N}}")#text(", then exactly one of ")#mi("{E}")#text(" and ")#mi("{{\\bf N} \\backslash E}")#text(" lies in ")#mi("{\\alpha}")#text(".")]
)

#text("A ")#emph[#text("nonprincipal ultrafilter")]#text(" is an ultrafilter ")#mi("{\\alpha}")#text(" that obeys one final axiom:")

#list(
[#text("(Nonprincipality) No finite set belongs to ")#mi("{\\alpha}")#text(". (Equivalently: any ")#link("http://en.wikipedia.org/wiki/Cofinite")[#text("cofinite")]#text(" set will belong to ")#mi("{\\alpha}")#text(".)")]
)

#text("Given a nonprincipal ultrafilter ")#mi("{\\alpha}")#text(", we say that a set ")#mi("{E \\subset {\\bf N}}")#text(" is ")#emph[#mi("{\\alpha}")#text("-large")]#text(" if it is contained in ")#mi("{\\alpha}")#text(", and ")#emph[#mi("{\\alpha}")#text("-small")]#text(" otherwise. A property ")#mi("{P(n)}")#text(" of the natural numbers ")#mi("{n \\in {\\bf N}}")#text(" is said ")#emph[#text("to hold for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")]#text(" if it holds in an ")#mi("{\\alpha}")#text("-large set.")
]

#text("The most basic fact about nonprincipal ultrafilters is that they exist – a result due to Tarski, and known as the ")#link("http://en.wikipedia.org/wiki/Boolean_prime_ideal_theorem#The_ultrafilter_lemma")[#text("ultrafilter lemma")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Ultrafilter lemma)")]#text(" Show that there exists at least one nonprincipal ultrafilter. (")#emph[#text("Hint:")]#text(" first construct a nonprincipal filter, and then use ")#link("http://en.wikipedia.org/wiki/Zorn%27s_lemma")[#text("Zorn’s lemma")]#text(" to place it inside a maximal nonprincipal filter.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Call an ultrafilter ")#emph[#text("principal")]#text(" if it is not nonprincipal. Show that for any natural number ")#mi("{n_0}")#text(", the set ")#mi("{\\{ E \\subset {\\bf N}: n_0 \\in E \\}}")#text(" is a principal ultrafilter, and conversely every principal ultrafilter is of this form. Thus, the space of principal ultrafilters can be identified with ")#mi("{{\\bf N}}")#text(".")
]

#text("The space of all ultrafilters is denoted ")#mi("{\\beta {\\bf N}}")#text(", and so by the preceding exercise one can view ")#mi("{{\\bf N}}")#text(" as a subset of ")#mi("{\\beta {\\bf N}}")#text(", with ")#mi("{\\beta {\\bf N} \\backslash {\\bf N}}")#text(" denoting the nonprincipal ultrafilters.")

#text("Ultrafilters can be interpreted in a number of different ways, as indicated by the exercises below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Ultrafilters as finitely additive probability measures)")]#text(" If ")#mi("{\\alpha}")#text(" is an ultrafilter, show that the map ")#mi("{\\mu: 2^{\\bf N} \\rightarrow \\{0,1\\}}")#text(" that maps ")#mi("{\\alpha}")#text("-large subsets of ")#mi("{{\\bf N}}")#text(" to ")#mi("{1}")#text(" and ")#mi("{\\alpha}")#text("-small subsets of ")#mi("{{\\bf N}}")#text(" to ")#mi("{0}")#text(", is a finitely additive probability measure (thus ")#mi("{\\mu(E)+\\mu(F)=\\mu(E \\cup F)}")#text(" whenever ")#mi("{E, F \\subset {\\bf N}}")#text(" are disjoint). Conversely, show that every finitely additive probability measure ")#mi("{\\mu: 2^{\\bf N} \\rightarrow \\{0,1\\}}")#text(" that takes values in ")#mi("{\\{0,1\\}}")#text(" arises in this manner.")
]

#text("In view of the above exercise, one may view “")#mi("{\\alpha}")#text("-large” as analogous to “full measure”, and “holding for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text("” as analogous to “holding for almost all ")#mi("{n}")#text("“, except that the measure is only finitely additive instead of countably additive, and so concepts such as ")#mi("{\\alpha}")#text("-largeness are only stable under finitely many intersections, rather than countably many intersections.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4 (Ultrafilters as Stone-Cech compactification of ")#mi("{{\\bf N}}")#text(")")]#text(" We view ")#mi("{\\beta {\\bf N}}")#text(" as a subset of the power set ")#mi("{2^{2^{\\bf N}}}")#text(", and give it the induced topology from the product topology on ")#mi("{2^{2^{\\bf N}}}")#text(".")

#list(
[#text("(i) If ")#mi("{\\alpha}")#text(" is a nonprincipal ultrafilter, show that every neighbourhood of ")#mi("{\\alpha}")#text(" in ")#mi("{\\beta {\\bf N}}")#text(" intersects ")#mi("{{\\bf N}}")#text(" in an ")#mi("{\\alpha}")#text("-large set, and that every ")#mi("{\\alpha}")#text("-large set arises in this manner. (This explains the notation “")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text("“.)")],
[#text("(ii) Show that this makes ")#mi("{\\beta {\\bf N}}")#text(" a ")#emph[#text("compactification")]#text(" of ")#mi("{{\\bf N}}")#text(" in the sense that it is compact Hausdorff and contains ")#mi("{{\\bf N}}")#text(" as a dense subset.")],
[#text("(iii) Show that ")#mi("{\\beta {\\bf N}}")#text(" is a ")#emph[#text("universal compactification")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93%C4%8Cech_compactification")[#text("Stone-Cech compactification")]#text("), thus if ")#mi("{X}")#text(" is any other compactification of ")#mi("{{\\bf N}}")#text(", then there is a unique continuous map ")#mi("{f: \\beta {\\bf N} \\rightarrow X}")#text(" that is the identity on ")#mi("{{\\bf N}}")#text(".")],
[#text("(iv) If ")#mi("{Y}")#text(" is any compact Hausdorff space, show that every function ")#mi("{f: {\\bf N} \\rightarrow Y}")#text(" has a unique continuous extension ")#mi("{\\beta f: \\beta {\\bf N} \\rightarrow Y}")#text(" to the space ")#mi("{\\beta {\\bf N}}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" More discussion on the Stone-Cech compactification can be found in ")#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/")[#text("this previous blog post")]#text(". The compact space ")#mi("{\\beta {\\bf N}}")#text(" can also be endowed with an interesting semigroup structure, which is of importance in Ramsey theory and ergodic theory; see ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("this previous post")]#text(" for more details.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Ultrafilters as Banach limits)")]#text(" ")#metadata(none) <tao-340e570c1e78a3d0ad80>#text(" Recall that a functional ")#mi("{\\lambda: \\ell^\\infty({\\bf N}) \\rightarrow {\\bf C}}")#text(" from the ")#link("http://en.wikipedia.org/wiki/*-algebra")[#text("*-algebra")]#text(" ")#mi("{\\ell^\\infty({\\bf N})}")#text(" of bounded complex sequences ")#mi("{(a_n)_{n \\in {\\bf N}}}")#text(" to the complex numbers is a ")#emph[#text("*-homomorphism")]#text(" if it is complex-linear and obeys the conjugation law")

#align(center)[#tao-fit-display[#mitex("\\lambda(( \\overline{a_n} )_{n \\in {\\bf N}}) = \\overline{\\lambda(( a_n )_{n \\in {\\bf N}})}")]]

#text("and the homomorphism law")

#align(center)[#tao-fit-display[#mitex("\\lambda(( a_n b_n )_{n \\in {\\bf N}}) = \\lambda(( a_n )_{n \\in {\\bf N}}) \\lambda(( b_n )_{n \\in {\\bf N}})")]]

#text("for all bounded sequences ")#mi("{a_n, b_n}")#text(", while mapping the constant sequence ")#mi("{(1)_{n \\in {\\bf N}}}")#text(" to ")#mi("{1}")#text(".")

#list(
[#text("(i) Show that if ")#mi("{\\alpha}")#text(" is a ultrafilter, show that there exists a unique *-homomorphism ")#mi("{\\alpha\\!-\\!\\lim: \\ell^\\infty({\\bf N}) \\rightarrow {\\bf C}}")#text(" with the property that for every ")#mi("{E \\subset {\\bf N}}")#text(", one has ")#mi("{\\alpha\\!-\\!\\lim 1_E(n) = 1}")#text(" if and only if ")#mi("{E}")#text(" is ")#mi("{\\alpha}")#text("-large.")],
[#text("(ii) Conversely, show that all *-homomorphisms ")#mi("{\\lambda}")#text(" from ")#mi("{\\ell^\\infty({\\bf N})}")#text(" to ")#mi("{{\\bf C}}")#text(" arise in this fashion, and that a *-homomorphism arises from a nonprincipal ultrafilter if and only if it extends the limit functional (thus ")#mi("{\\lambda( (a_n)_{n \\in {\\bf N}} ) = \\lim_{n \\rightarrow \\infty} a_n}")#text(" whenever ")#mi("{a_n}")#text(" is convergent).")]
)
]

#text("From the above exercise we see that ")#mi("{\\beta {\\bf N}}")#text(" can be viewed as the ")#link("http://en.wikipedia.org/wiki/Gelfand_representation#The_spectrum_of_a_commutative_C.2A-algebra")[#text("Gelfand spectrum")]#text(" of ")#mi("{\\ell^\\infty({\\bf N})}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6 (Ultrafilters and Arrow’s theorem)")]#text(" Let ")#mi("{S}")#text(" be a finite set consisting of at least three elements (representing “candidates”). Let ")#mi("{O(S)}")#text(" denote the space of all total orderings ")#mi("{<}")#text(" on ")#mi("{S}")#text(". Define a ")#emph[#text("voting system")]#text(" to be a function ")#mi("{V: O(S)^{\\bf N} \\rightarrow O(S)}")#text(" from a sequence ")#mi("{(<_n)_{n \\in {\\bf N}}}")#text(" of orderings on ")#mi("{S}")#text(" (representing the preferences of an infinite number of “voters”) to an ordering ")#mi("{V((<_n)_{n \\in {\\bf N}})}")#text(" on ")#mi("{S}")#text(". If ")#mi("{\\alpha}")#text(" is a nonprincipal ultrafilter, show that there is a unique voting system ")#mi("{V_\\alpha: O(S)^{\\bf N} \\rightarrow O(S)}")#text(" with the property that for any distinct ")#mi("{A, B \\in S}")#text(", one has ")#mi("{A V((<_n)_{n \\in {\\bf N}}) B}")#text(" if and only if ")#mi("{A <_n B}")#text(" for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(". Show furthermore that this voting system obeys the following axioms for all distinct candidates ")#mi("{A,B}")#text(" and all orderings ")#mi("{<_n \\in O(S)}")#text(":")

#list(
[#text("(Consensus) If ")#mi("{A <_n B}")#text(" for all ")#mi("{n}")#text(", then ")#mi("{A V((<_n)_{n \\in {\\bf N}}) B}")#text(".")],
[#text("(Non-dictatorship) There is no ")#mi("{n_0}")#text(" with the property that ")#mi("{A V((<_n)_{n \\in {\\bf N}}) B}")#text(" holds if and only if ")#mi("{A <_{n_0} B}")#text(" holds for all choices of ")#mi("{A, B, <_n}")#text(".")],
[#text("(Independence of irrelevant alternatives) The truth value of ")#mi("{A V((<_n)_{n \\in {\\bf N}}) B}")#text(" depends only on the truth values of ")#mi("{A <_n B}")#text(" for all ")#mi("{n}")#text(". Thus, if ")#mi("{(<^{\\prime}_n)_{n\\in {\\bf N}}}")#text(" is another sequence of orderings such that ")#mi("{A <_n B}")#text(" if and only if ")#mi("{A <^{\\prime}_n B}")#text(", then ")#mi("{A V((<_n)_{n \\in {\\bf N}}) B}")#text(" holds if and only if ")#mi("{A V((<^{\\prime}_n)_{n \\in {\\bf N}}) B}")#text(" holds.")]
)

#text("Conversely, show that any voting system obeying the above axioms arises from an nonprincipal ultrafilter in this fashion. Thus we see that ")#link("http://en.wikipedia.org/wiki/Arrow's_impossibility_theorem")[#text("Arrow’s theorem")]#text(" does not hold for infinite sets due to the existence of nonprincipal ultrafilters in this setting; or to put it another way, Arrow’s theorem is equivalent to the assertion that finite sets have no nonprincipal ultrafilters. (This connection between ultrafilters and Arrow’s theorem was first observed by Kirman and Sondermann. See ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("this previous blog post")]#text(" for more discussion of the voting interpretation of an ultrafilter.)")
]

#text("As the above examples indicate, there are many different ways to view ultrafilters. My personal preference (at least from the perspective of forming ultraproducts and doing nonstandard analysis) is to view a nonprincipal ultrafilter as a consistent way to take limits of sequences that do not necessarily converge in the classical sense, as per Exercise ")#link(<tao-340e570c1e78a3d0ad80>)[#text("5")]#text("; but other readers may prefer to use one of the other interpretations of an ultrafilter instead.")

#heading(level: 1)[#strong[#text(" — 2. Ultrapowers and ultralimits — ")]]

#text("We now turn to the formal definition of an ultrapower and ultralimit. In order to define these two terms, we must first fix two objects:")

#list(
[#text("A ")#emph[#text("non-principal ultrafilter")]#text(" ")#mi("{\\alpha \\in \\beta {\\bf N} \\backslash {\\bf N}}")#text("; and")],
[#text("A ")#emph[#text("standard universe")]#text(" ")#mi("{{\\mathfrak U}}")#text(", which is some some set of objects, the elements of which we refer to as ")#emph[#text("standard objects")]#text(". We refer to subsets of the standard universe (i.e. sets of standard objects) as ")#emph[#text("standard spaces")]#text(" (or ")#emph[#text("standard sets")]#text(").")]
)

#text("Informally, the standard universe is going to contain all the objects that we are initially interested in studying. For instance, if we are doing arithmetic, the standard universe might be the natural numbers ")#mi("{{\\bf N}}")#text(". If we are doing analysis, the standard universe might include the real numbers ")#mi("{{\\bf R}}")#text(", as well as the set of subsets of ")#mi("{{\\bf R}}")#text(", the set of functions from ")#mi("{{\\bf R}}")#text(" to ")#mi("{{\\bf R}}")#text(", and so forth. If we are studying approximate groups in an ambient group ")#mi("{G}")#text(", the standard universe might include the elements of ")#mi("{G}")#text(", subsets of ")#mi("{G}")#text(", and similar such objects. We will place some more constraints on the standard universe later, but for now, the only requirement we have is that this universe forms a set. (In particular, the standard universe cannot be so huge to be a ")#link("http://en.wikipedia.org/wiki/Class_(set_theory)")[#text("proper class")]#text(", such as the class of all sets, or the class of all groups, etc., although in most applications outside of set theory, this is hardly a restriction.)")

#text("In practice, the standard universe will contain many familiar mathematical spaces, such as the natural numbers, the real numbers, and so forth. To emphasise this, we will sometimes refer to the natural numbers ")#mi("{{\\bf N}}")#text(" as the ")#emph[#text("standard")]#text(" natural numbers, the real numbers ")#mi("{{\\bf R}}")#text(" as the ")#emph[#text("standard")]#text(" real numbers ")#mi("{{\\bf R}}")#text(", and so forth. This is in order to distinguish such spaces from the ")#emph[#text("nonstandard")]#text(" natural numbers ")#mi("{{}^* {\\bf N}}")#text(", the ")#emph[#text("nonstandard")]#text(" real numbers ")#mi("{{}^* {\\bf R}}")#text(", etc., which we now define.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" For the applications in this course, the precise choice of nonprincipal ultrafilter ")#mi("{\\alpha}")#text(" will be completely irrelevant; one such ultrafilter will be just as good for our purposes as another. Basically, we only use the ultrafilter ")#mi("{\\alpha}")#text(" in order to fix a consistent way to make choices amongst any sequence of options indexed by the natural numbers; but the precise way in which these choices are made will not be important, so long as it is consistent (in the sense that the ultrafilter axioms are obeyed). There are other applications of ultrafilters, however, in which some nonprincipal ultrafilters are decidedly superior to others; see ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("this previous post")]#text(" for an example of this in dynamical systems.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3 (Ultralimits and ultraproducts)")]#text(" Two sequences ")#mi("{(x_n)_{n \\in {\\bf N}}}")#text(", ")#mi("{(y_n)_{n \\in {\\bf N}}}")#text(" of standard objects ")#mi("{x_n, y_n \\in {\\mathfrak U}}")#text(" are said to be ")#emph[#text("equivalent")]#text(" if one has ")#mi("{x_n = y_n}")#text(" for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(". This is easily seen to be an equivalence relation. We define the ")#emph[#text("ultralimit")]#text(" ")#mi("{\\lim_{n \\rightarrow \\alpha} x_n}")#text(" to be the equivalence class of a sequence ")#mi("{(x_n)_{n \\in {\\bf N}}}")#text("; thus ")#mi("{\\lim_{n \\rightarrow \\alpha} x_n = \\lim_{n \\rightarrow \\alpha} y_n}")#text(" if and only if ")#mi("{x_n=y_n}")#text(" for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(". Such ultralimits will be called ")#emph[#text("nonstandard objects")]#text(".")

#text("Given a sequence ")#mi("{(X_n)_{n \\in {\\bf N}}}")#text(" of standard spaces ")#mi("{X_n \\subset {\\mathfrak U}}")#text(", we define the ")#link("http://en.wikipedia.org/wiki/Ultraproduct")[#text("ultraproduct")]#text(" ")#mi("{\\prod_{n \\rightarrow \\alpha} X_n}")#text(" to be the space of all ultralimits ")#mi("{\\lim_{n \\rightarrow \\alpha} x_n}")#text(", where ")#mi("{x_n \\in X_n}")#text(" for each ")#mi("{n}")#text(". Such spaces will be called ")#emph[#text("nonstandard spaces")]#text(" (also known as ")#emph[#text("nonstandard sets")]#text(" or ")#emph[#text("internal sets")]#text(").")

#text("If ")#mi("{X}")#text(" is a standard space, we define the ")#emph[#text("ultrapower")]#text(" ")#mi("{{}^* X}")#text(" of ")#mi("{X}")#text(" to be the ultraproduct ")#mi("{{}^* X := \\prod_{n \\rightarrow \\alpha} X}")#text(" of the constant sequence ")#mi("{X}")#text(". We embed ")#mi("{X}")#text(" inside ")#mi("{{}^* X}")#text(" by identifying each element ")#mi("{x}")#text(" of ")#mi("{X}")#text(" with the ultralimit ")#mi("{\\lim_{n \\rightarrow \\alpha} x}")#text(". If ")#mi("{X}")#text(" is the standard elements of some type, we refer to elements of ")#mi("{{}^* X}")#text(" (i.e. ultralimits of sequences in ")#mi("{X}")#text(") as nonstandard elements of the same type. Thus, for instance, elements of ")#mi("{{}^* {\\bf N}}")#text(" are nonstandard natural numbers, elements of ")#mi("{{}^* {\\bf R}}")#text(" are nonstandard real numbers (also known as ")#link("http://en.wikipedia.org/wiki/Hyperreal_number")[#text("hyperreals")]#text("), and so forth. The ultrapower ")#mi("{{}^* {\\mathfrak U}}")#text(" of the standard universe will be called the ")#emph[#text("nonstandard universe")]#text(".")
]

#text("Note that one can define an ultralimit ")#mi("{\\lim_{n \\rightarrow \\alpha} x_n}")#text(" for sequences ")#mi("{x_n}")#text(" of standard objects that are only defined for an ")#mi("{\\alpha}")#text("-large set of ")#mi("{n}")#text(", and similarly one can define ultraproducts ")#mi("{\\prod_{n \\rightarrow \\alpha} X_n}")#text(" on spaces ")#mi("{X_n}")#text(" that are only defined for an ")#mi("{\\alpha}")#text("-large set of ")#mi("{n}")#text(". From the nonprincipal nature of ")#mi("{\\alpha}")#text(" we observe that we can modify ")#mi("{x_n}")#text(" or ")#mi("{X_n}")#text(" for finitely many ")#mi("{n}")#text(" without affecting the ultralimit ")#mi("{\\lim_{n \\rightarrow \\alpha} x_n}")#text(" or ultraproduct ")#mi("{\\prod_{n \\rightarrow \\alpha} X_n}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" The relation between a standard space ")#mi("{X}")#text(" and its ultrapower ")#mi("{{}^* X}")#text(" is analogous in some ways to the relationship between the rationals ")#mi("{{\\bf Q}}")#text(" and its ")#link("http://en.wikipedia.org/wiki/Complete_metric_space")[#text("metric completion")]#text(", namely the real line ")#mi("{{\\bf R}}")#text(". Indeed, using the usual metric completion construction, one can interpret a real number as an equivalence class of Cauchy sequences of rationals (or as a formal limit ")#mi("{\\lim_{n \\rightarrow \\infty} q_n}")#text(" of one of the Cauchy sequences in this class), and then one identifies each rational ")#mi("{q}")#text(" with its formal limit ")#mi("{\\lim_{n \\rightarrow \\infty} q}")#text(" in order to keep the rationals embedded inside the reals. Note however that whilst in the metric completion, one is only allowed to take (formal) limits of Cauchy sequences, in the ultrapower construction one may take limits of ")#emph[#text("arbitrary")]#text(" sequences. This makes the ultrapower construction more “powerful” than the metric completion construction in that no ")#emph[#text("a priori")]#text(" convergence (or even boundedness) hypotheses are needed in order to take limits. See ")#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/")[#text("this previous blog post")]#text(" for more discussion of ultrapowers as a completion.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" With our conventions, we have the slightly unfortunate consequence that every standard object is also a nonstandard object; for instance, every standard natural number is also a nonstandard natural number, every standard real is also a nonstandard real, and so forth. We will occasionally use the terminology ")#emph[#text("strictly nonstandard")]#text(" to denote a nonstandard object that is not standard. For instance, an element of ")#mi("{{}^* {\\bf N} \\backslash {\\bf N}}")#text(" would be a strictly nonstandard natural number.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-47a1c9327e4f9ed78e19>#text(" If ")#mi("{X}")#text(" is a standard space, show that ")#mi("{X = {}^* X}")#text(" if and only if ")#mi("{X}")#text(" is finite. In particular, if ")#mi("{x_n \\in X}")#text(" is a sequence with finite (standard) range ")#mi("{X}")#text(", then ")#mi("{\\lim_{n \\rightarrow \\alpha} x_n}")#text(" also lives in the same range ")#mi("{X}")#text(".")
]

#text("The above exercise shows that for finite spaces, there is no distinction between a standard space ")#mi("{X}")#text(" and its nonstandard counterpart ")#mi("{{}^* X}")#text(". However, for infinite spaces, the nonstandard version of the space is usually much larger:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Show that ")#mi("{{}^* {\\bf N}}")#text(" is uncountable. (")#emph[#text("Hint:")]#text(" adapt the ")#link("http://en.wikipedia.org/wiki/Cantor's_diagonal_argument")[#text("Cantor diagonal argument")]#text(".) The precise cardinality of an ultrapower is actually quite difficult to determine in general, as it can depend on the choice of ultrafilter and even on the choice of additional set theory axioms such as the ")#link("http://en.wikipedia.org/wiki/Continuum_hypothesis")[#text("continuum hypothesis")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9 (Ultrapowers preserve Boolean operations)")]#text(" ")#metadata(none) <tao-3d099d0f13df9d0bb442>#text(" Let ")#mi("{X, Y}")#text(" be standard spaces. Show that ")#mi("{(X \\cup Y)^* = X^* \\cup Y^*}")#text(", ")#mi("{(X \\cap Y)^* = X^* \\cap Y^*}")#text(", and ")#mi("{(X \\backslash Y)^* = X^* \\backslash Y^*}")#text(". Also show that ")#mi("{X \\subset Y}")#text(" if and only if ")#mi("{X^* \\subset Y^*}")#text(".")
]

#text("Strictly speaking, ultrapowers do not preserve Cartesian products: from the definitions, ")#mi("{(X \\times Y)^*}")#text(" and ")#mi("{X^* \\times Y^*}")#text(" are slightly different spaces. However, there is an obvious bijection between the two sets, and we shall abuse notation and implicitly make the identification ")#mi("{(X \\times Y)^* = X^* \\times Y^*}")#text(" throughout the rest of this post. More generally, given sequences ")#mi("{X_n, Y_n}")#text(" of standard spaces, we make the identification ")#mi("{\\prod_{n \\rightarrow \\alpha} (X_n \\times Y_n) = (\\prod_{n \\rightarrow \\alpha} X_n) \\times (\\prod_{n \\rightarrow \\alpha} Y_n)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" Just as standard spaces ")#mi("{X}")#text(" are subsets of the standard universe ")#mi("{{\\mathfrak U}}")#text(", nonstandard spaces ")#mi("{\\prod_{n \\rightarrow \\alpha} X_n}")#text(" are subsets of the nonstandard universe ")#mi("{{}^* {\\mathfrak U}}")#text(". However, the converse is not true in general; not every subset of the nonstandard universe is necessarily a nonstandard space. For instance, we will show later that ")#mi("{{\\bf N}}")#text(" is not a nonstandard subset of ")#mi("{{}^* {\\bf N}}")#text(" (and as such, is sometimes referred to as an ")#emph[#text("external subset")]#text(" of ")#mi("{{}^* {\\bf N}}")#text("). Very roughly speaking, internal spaces in the nonstandard universe play a role similar to that of elementary sets (i.e. finite boolean combinations of intervals) in the real line; they are closed under various operations, but fall well short of exhausting all possible subsets of the ambient space. (Actually, an even better analogy would be the ")#link("http://en.wikipedia.org/wiki/Clopen_set")[#text("clopen")]#text(" subsets of a ")#link("http://en.wikipedia.org/wiki/Cantor_space")[#text("Cantor space")]#text(".)")
]

#text("Now we record an important property of nonstandard spaces, analogous to the ")#link("http://en.wikipedia.org/wiki/Finite_intersection_property")[#text("finite intersection property")]#text(" formulation of (countable) compactness.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Countable saturation)")]#text(" Let ")#mi("{F_1, F_2, \\ldots}")#text(" be a sequence of nonstandard spaces such that any finite collection of these spaces has non-empty intersection (thus ")#mi("{\\bigcap_{m=1}^M F_m \\neq \\emptyset}")#text(" for all ")#mi("{M \\geq 1}")#text("). Then the entire sequence has non-empty intersection (thus ")#mi("{\\bigcap_{m=1}^\\infty F_m \\neq \\emptyset}")#text(").")
]

#emph[#text("Proof:")]#text(" Write ")#mi("{F_m = \\prod_{n \\rightarrow \\alpha} F_{n,m}}")#text(", then for each ")#mi("{m}")#text(", ")#mi("{\\bigcap_{m=1}^M F_m}")#text(" is the ultraproduct of ")#mi("{\\bigcap_{m=1}^M F_{m,n}}")#text(" (cf. Exercise ")#link(<tao-3d099d0f13df9d0bb442>)[#text("9")]#text("). In particular, ")#mi("{\\bigcap_{m=1}^M F_{m,n}}")#text(" is non-empty for all ")#mi("{n}")#text(" in an ")#mi("{\\alpha}")#text("-large subset ")#mi("{E_M}")#text(" of the natural numbers. By shrinking the ")#mi("{E_M}")#text(" as necessary we may assume that they are monotone, thus ")#mi("{E_1 \\supset E_2 \\supset \\ldots}")#text(", and such that ")#mi("{E_M}")#text(" does not contain any natural number less than ")#mi("{M}")#text("; in particular, ")#mi("{\\bigcap_{M=1}^\\infty E_M = \\emptyset}")#text(". For any ")#mi("{n \\in E_1}")#text(", let ")#mi("{M_n}")#text(" denote the largest natural number ")#mi("{M}")#text(" such that ")#mi("{n \\in E_M}")#text(", and then let ")#mi("{x_n}")#text(" denote an element of ")#mi("{\\bigcap_{m=1}^{M_n} F_{m,n}}")#text(". Then by construction, for each ")#mi("{m \\geq 1}")#text(", we have ")#mi("{x_n \\in F_{m,n}}")#text(" for all ")#mi("{n \\in E_m}")#text(", and thus the nonstandard object ")#mi("{x := \\lim_{n \\rightarrow \\alpha} x_n}")#text(" lies in ")#mi("{F_m}")#text(" for all ")#mi("{m}")#text(", and thus ")#mi("{\\bigcap_{m=1}^\\infty F_m}")#text(" is non-empty as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Countable compactness)")]#text(" ")#metadata(none) <tao-cdf5b9d70c6aa5a74e2d>#text(" Show that any countable cover of a nonstandard space by other nonstandard spaces has a finite subcover.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11 (Bolzano-Weierstrass type theorem)")]#text(" ")#metadata(none) <tao-ab02eedd0712a148636d>#text(" Let ")#mi("{X_1,\\ldots,X_k}")#text(" be a finite collection of nonstandard spaces, and let ")#mi("{P_i: X_1 \\times \\ldots \\times X_k \\rightarrow \\{ \\text{true},\\text{false}\\}}")#text(" be an at most countable collection of nonstandard ")#mi("{k}")#text("-ary predicates on these spaces. Let ")#mi("{x_{1,m}, \\ldots, x_{k,m}}")#text(" for ")#mi("{m \\in {\\bf N}}")#text(" be sequences of nonstandard objects in ")#mi("{X_1,\\ldots,X_k}")#text(" respectively (indexed by the standard natural numbers ")#mi("{{\\bf N}}")#text("). Show that there are subsequences ")#mi("{x_{1,m_j},\\ldots,x_{k,m_j}}")#text(" which ")#emph[#text("converge elementarily")]#text(" to some elements ")#mi("{x_1,\\ldots,x_k}")#text(" of ")#mi("{X_1,\\ldots,X_k}")#text(" in the sense that for each predicate ")#mi("{P_i}")#text(", one has ")#mi("{P_i(x_{1,{m_j}},\\ldots,x_{k,{m_j}}) = P_i(x_1,\\ldots,x_k)}")#text(" for all sufficiently large ")#mi("{j}")#text(". (See ")#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/")[#text("this previous post")]#text(" for more discussion on these sorts of completeness properties on nonstandard spaces.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" By replacing the ultraproduct construction with more sophisticated set-theoretic constructions, one can strengthen the countable saturation property by replacing “countable” by “at most cardinality ")#mi("{\\kappa}")#text("” for any given cardinal ")#mi("{\\kappa}")#text("; however, as one increases ")#mi("{\\kappa}")#text(", the size of the ultraproduct-type object must also necessarily increase (although one can make the size of the model only slightly larger than ")#mi("{\\kappa}")#text(", if one is willing to use ")#link("http://en.wikipedia.org/wiki/Inaccessible_cardinal")[#text("inaccessible cardinals")]#text("). Such (huge) saturated models are of importance in model theory, but for our applications we will only need to work with the countably saturated models provided by the ultraproduct construction.")
]

#text("We have taken ultralimits and ultraproducts of standard objects and standard spaces; now we perform a similar construction to standard functions and relations.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 5 (Ultralimits of functions and relations)")]#text(" A ")#emph[#text("standard function")]#text(" is a function ")#mi("{f: X \\rightarrow Y}")#text(" between two standard spaces ")#mi("{X, Y}")#text(". Given a sequence ")#mi("{f_n: X_n \\rightarrow Y_n}")#text(" of standard functions, we define the ")#emph[#text("ultralimit")]#text(" ")#mi("{\\lim_{n \\rightarrow \\alpha} f_n: \\prod_{n \\rightarrow \\alpha} X_n \\rightarrow \\prod_{n \\rightarrow \\alpha} Y_n}")#text(" to be the function defined by the formula")

#align(center)[#tao-fit-display[#mitex("(\\lim_{n \\rightarrow \\alpha} f_n) (\\lim_{n \\rightarrow \\alpha} x_n) := \\lim_{n \\rightarrow\\alpha} f_n(x_n)")]]

#text("whenever ")#mi("{x_n \\in X_n}")#text(". One can easily verify that this does indeed define a function, which we refer to as a ")#emph[#text("nonstandard function")]#text(" (also called an ")#emph[#text("internal function")]#text(" in the literature). The ultralimit ")#mi("{{}^* f := \\lim_{n \\rightarrow \\alpha} f}")#text(" of a single standard function is thus a nonstandard function from ")#mi("{{}^* X}")#text(" to ")#mi("{{}^* Y}")#text(" that extends ")#mi("{f}")#text("; by abuse of notation we shall also refer to ")#mi("{{}^* f}")#text(" as ")#mi("{f}")#text(" (analogously to how we identify ")#mi("{\\lim_{n \\rightarrow \\alpha} x}")#text(" with ")#mi("{x}")#text(" rather than giving it a different name such as ")#mi("{{}^* x}")#text(").")

#text("Similarly, for a (standard) natural number ")#mi("{k \\in {\\bf N}}")#text(", define a ")#emph[#text("standard ")#mi("{k}")#text("-ary relation")]#text(" (or ")#emph[#text("standard ")#mi("{k}")#text("-ary predicate")]#text(") to be a standard function ")#mi("{R: X_1 \\times \\ldots \\times X_k \\rightarrow \\{ \\text{true}, \\text{false}\\}}")#text(" from the product of ")#mi("{k}")#text(" standard spaces to the Boolean space ")#mi("{\\{ \\text{true}, \\text{false}\\}}")#text(" (which we will treat as part of the standard universe ")#mi("{{\\mathfrak U}}")#text("). By the preceding construction (and Exercise ")#link(<tao-47a1c9327e4f9ed78e19>)[#text("7")]#text("), the ultralimit ")#mi("{\\lim_{n \\rightarrow \\alpha} R_n}")#text(" of a sequence of standard ")#mi("{k}")#text("-ary relations ")#mi("{R_n: X_{1,n} \\times \\ldots \\times X_{k,n} \\rightarrow \\{ \\text{true}, \\text{false}\\}}")#text(" (with ")#mi("{k}")#text(" independent of ")#mi("{n}")#text(") is another ")#mi("{k}")#text("-ary relation")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\alpha} R_n: \\lim_{n \\rightarrow \\alpha} X_{1,n} \\times \\lim_{n \\rightarrow \\alpha} X_{k,n} \\rightarrow \\{ \\text{true}, \\text{false}\\},")]]

#text("which we will call a ")#emph[#text("nonstandard ")#mi("{k}")#text("-ary relation")]#text(" (also known as an ")#emph[#text("internal ")#mi("{k}")#text("-ary relation")]#text("). Thus ")#mi("{\\lim_{n \\rightarrow \\alpha} R_n( \\lim_{n \\rightarrow \\alpha} x_{1,n},\\ldots,\\lim_{n \\rightarrow \\alpha} x_{k,n})}")#text(" is true if and only if ")#mi("{R_n(x_{1,n},\\ldots,x_{k,n})}")#text(" is true for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(". Again, we identify each relation ")#mi("{R}")#text(" with its nonstandard extension ")#mi("{{}^* R := \\lim_{n\\rightarrow \\alpha} R}")#text(".")

#text("In a very similar spirit, given a sequence ")#mi("{O_n: X_{1,n} \\times \\ldots \\times X_{k,n} \\rightarrow Y_n}")#text(" of standard ")#mi("{k}")#text("-ary operators, one can define the ultralimit")

#align(center)[#tao-fit-display[#mitex("\\lim_{n \\rightarrow \\alpha} O_n: \\lim_{n \\rightarrow \\alpha} X_{1,n} \\times \\lim_{n \\rightarrow \\alpha} X_{k,n} \\rightarrow \\lim_{n \\rightarrow \\alpha} Y_n")]]

#text("which we will call a ")#emph[#text("nonstandard ")#mi("{k}")#text("-ary operator")]#text(" (also known as an ")#emph[#text("internal ")#mi("{k}")#text("-ary operator")]#text("). Again, we identify each standard operator ")#mi("{O}")#text(" with its nonstandard extension ")#mi("{{}^* O := \\lim_{n \\rightarrow \\alpha} O}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" Let ")#mi("{a = \\lim_{n \\rightarrow \\alpha} a_n}")#text(" and ")#mi("{b = \\lim_{n \\rightarrow \\alpha} b_n}")#text(" be two nonstandard natural numbers (thus ")#mi("{a_n, b_n}")#text(" are sequences of standard natural numbers). Then, by definition,")

#list(
[#mi("{a+b}")#text(" is the nonstandard natural number ")#mi("{a+b := \\lim_{n \\rightarrow \\alpha} a_n + b_n}")#text(".")],
[#mi("{ab}")#text(" is the nonstandard natural number ")#mi("{ab := \\lim_{n \\rightarrow \\alpha} a_n b_n}")#text(".")],
[#text("One has ")#mi("{a < b}")#text(" if ")#mi("{a_n < b_n}")#text(" for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(".")],
[#mi("{a}")#text(" is even if ")#mi("{a_n}")#text(" is even for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(".")],
[#mi("{a}")#text(" is prime if ")#mi("{a_n}")#text(" is prime for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(".")]
)
]

#text("A basic fact about the ultraproduct construction is that any elementary (or more precisely, ")#link("http://en.wikipedia.org/wiki/First-order_logic")[#text("first-order")]#text(") statement that is true for a standard space (or a sequence of such standard spaces) is also true for the associated nonstandard space (either an ultrapower or an ultraproduct). We will formalise this assertion shortly, but let us first illustrate it with some examples.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]

#list(
[#text("(i) Show that addition on the nonstandard natural numbers is both commutative and associative.")],
[#text("(ii) Show that a nonstandard natural number ")#mi("{a}")#text(" is even if and only if it is of the form ")#mi("{a = 2b}")#text(" for some nonstandard natural number ")#mi("{b}")#text(".")],
[#text("(iii) Show that a nonstandard natural number ")#mi("{a}")#text(" is prime if and only if it is greater than ")#mi("{1}")#text(", but cannot be factored as ")#mi("{a=bc}")#text(" for some nonstandard natural numbers ")#mi("{b,c > 1}")#text(".")],
[#text("(iv) Show that the standard ")#link("http://en.wikipedia.org/wiki/Goldbach_conjecture")[#text("Goldbach conjecture")]#text(" (every even standard natural number larger than ")#mi("{2}")#text(" is the sum of two standard primes) is logically equivalent to the nonstandard Goldbach conjecture (every even nonstandard natural number larger than ")#mi("{2}")#text(" is the sum of two nonstandard primes).")],
[#text("(v) Show that the standard ")#link("http://en.wikipedia.org/wiki/Twin_prime_conjecture")[#text("twin prime conjecture")]#text(" (for any standard natural number ")#mi("{a}")#text(", there exists a standard prime ")#mi("{p>a}")#text(" such that ")#mi("{p+2}")#text(" is also prime) is logically equivalent to the nonstandard twin prime conjecture (for any nonstandard natural number ")#mi("{a}")#text(", there exists a nonstandard prime ")#mi("{p>a}")#text(" such that ")#mi("{p+2}")#text(" is also a nonstandard prime).")]
)
]

#text("Now we generalise the above examples.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Let ")#mi("{k \\geq 0}")#text(", and let ")#mi("{P_n, Q_n: X_{1,n} \\times \\ldots \\times X_{k,n} \\rightarrow \\{ \\text{true}, \\text{false}\\}}")#text(" be two sequences of ")#mi("{k}")#text("-ary predicates. For each ")#mi("{1 \\leq i \\leq k}")#text(", let ")#mi("{X_i := \\prod_{n\\rightarrow \\alpha} X_{i,n}}")#text(", and write ")#mi("{P := \\lim_{n \\rightarrow \\alpha} P_n}")#text(" and ")#mi("{Q := \\lim_{n \\rightarrow \\alpha} Q_n}")#text(".")

#list(
[#text("(i) (Continuity of Boolean operations) Show that ")#mi("{\\lim_{n \\rightarrow\\alpha} (P_n \\wedge Q_n) = P \\wedge Q}")#text(", ")#mi("{\\lim_{n \\rightarrow\\alpha} (P_n \\vee Q_n) = P \\vee Q}")#text(", and ")#mi("{\\lim_{n \\rightarrow \\alpha} (\\neg P_n) = \\neg P}")#text(".")],
[#text("(ii) (Continuity of existential quantifier) If ")#mi("{1 \\leq i \\leq k}")#text(", ")#mi("{\\exists_i P_n}")#text(" denotes the ")#mi("{k-1}")#text("-ary predicate ")#mi("{\\exists x_i \\in X_{i,n}: P_n(x_{1,n},\\ldots,x_{k,n})}")#text(" in the remaining ")#mi("{k-1}")#text(" variables ")#mi("{x_{j,n} \\in X_{j,n}}")#text(" for ")#mi("{j \\neq i}")#text(", and ")#mi("{\\exists_i P}")#text(" denotes the ")#mi("{k-1}")#text("-ary predicate ")#mi("{\\exists x_i \\in X_i: P(x_1,\\ldots,x_k)}")#text(" in the remaining ")#mi("{k-1}")#text(" variables ")#mi("{x_j \\in X_j}")#text(" for ")#mi("{j \\neq i}")#text(", show that ")#mi("{\\lim_{n \\rightarrow \\alpha} \\exists_i P_n = \\exists_i P}")#text(".")],
[#text("(iii) (Continuity of universal quantifier) If ")#mi("{1 \\leq i \\leq k}")#text(", ")#mi("{\\forall_i P_n}")#text(" denotes the ")#mi("{k-1}")#text("-ary predicate ")#mi("{\\forall x_i \\in X_{i,n}: P_n(x_{1,n},\\ldots,x_{k,n})}")#text(" in the remaining ")#mi("{k-1}")#text(" variables ")#mi("{x_{j,n} \\in X_{j,n}}")#text(" for ")#mi("{j \\neq i}")#text(", and ")#mi("{\\exists_i P}")#text(" denotes the ")#mi("{k-1}")#text("-ary predicate ")#mi("{\\forall x_i \\in X_i: P(x_1,\\ldots,x_k)}")#text(" in the remaining ")#mi("{k-1}")#text(" variables ")#mi("{x_j \\in X_j}")#text(" for ")#mi("{j \\neq i}")#text(", show that ")#mi("{\\lim_{n \\rightarrow \\alpha} \\forall_i P_n = \\forall_i P}")#text(".")]
)
]

#text("By iterating the above exercise, we can obtain ")#emph[#text("Los’s theorem")]#text(", which we first state informally as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Los’s theorem, informal version)")]#text(" ")#metadata(none) <tao-06271baf49532c879aa3>#text(" Let ")#mi("{k, m}")#text(" be natural numbers. For each natural number ")#mi("{n}")#text(", suppose one has a collection ")#mi("{a_{1,n},\\ldots,a_{m,n}}")#text(" of standard objects, spaces, operators, and relations (of various arities), and let ")#mi("{a_1,\\ldots,a_m}")#text(" be the corresponding nonstandard objects, spaces, operators, and relations formed via the ultralimit or ultraproduct construction. Let ")#mi("{P}")#text(" be a formal ")#mi("{k}")#text("-ary predicate expressible in first-order logic using ")#mi("{m}")#text(" objects, spaces, operators, and relations. Then ")#mi("{P}")#text(", when quantified over ")#mi("{a_1,\\ldots,a_m}")#text(", is the ultralimit of ")#mi("{P}")#text(" quantified over ")#mi("{a_{1,n},\\ldots,a_{m,n}}")#text(". (In particular, ")#mi("{P}")#text(" quantified over ")#mi("{a_1,\\ldots,a_m}")#text(" is a nonstandard predicate.)")

#text("Specialising to the case ")#mi("{k=0}")#text(", (so ")#mi("{P}")#text(" is a first-order sentence involving ")#mi("{m}")#text(" objects, spaces, operators, and relations), we see that ")#mi("{P}")#text(" is true when quantified over ")#mi("{a_1,\\ldots,a_m}")#text(" if and only if ")#mi("{P}")#text(" is true when quantified over ")#mi("{a_{1,n},\\ldots,a_{m,n}}")#text(" for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 7 (Special case of Los’s theorem, informal version)")]#text(" ")#metadata(none) <tao-cb6e53541e37a1d6076e>#text(" Any first-order sentence that holds for a finite collection of standard objects, spaces, operators, and relations, also holds for their corresponding nonstandard counterparts (using the ultralimit or ultrapower construction).")
]

#text("Before we state the theorem more formally, let is illustrate it with some more examples.")

#list(
[#mi("{{\\bf R}}")#text(" is an ordered field when given the usual constants ")#mi("{0, 1}")#text(", field operations ")#mi("{+, -, \\cdot, ()^{-1}}")#text(", and order relation ")#mi("{<}")#text(". (Technically, ")#mi("{()^{-1}}")#text(" is not an operation on ")#mi("{{\\bf R}}")#text(" because it is undefined at ")#mi("{0}")#text(", but this can easily be fixed by artificial means, e.g. by arbitrarily defining ")#mi("{()^{-1}}")#text(" at ")#mi("{0}")#text(".). The assertion that ")#mi("{{\\bf R}}")#text(" is an ordered field can be expressed as a (rather lengthy) sentence in first-order logic using the indicated spaces, objects, operations, and relations. As a consequence, the ultrapower ")#mi("{{}^* {\\bf R}}")#text(" (with the same constants ")#mi("{0, 1}")#text(" and the nonstandard extensions of the field operations and order relation) is also an ordered field.")],
[#text("Let ")#mi("{G_n= (G_n,\\cdot_n)}")#text(" be a sequence of groups; then the ultraproduct ")#mi("{G := \\prod_{n \\rightarrow \\alpha} G_n}")#text(" (with the ultralimit group operation ")#mi("{\\cdot := \\lim_{n \\rightarrow \\alpha} \\cdot_n}")#text(", and similarly for the group identity and inverse operations) is also a group, because the group axioms can be phrased in first-order logic using the indicated structures. If, for each ")#mi("{n}")#text(", ")#mi("{g_n}")#text(" is an element of ")#mi("{G_n}")#text(", then the ultralimit ")#mi("{\\lim_{n \\rightarrow \\alpha} g_n}")#text(" is a central element of ")#mi("{G}")#text(" if and only if ")#mi("{g_n}")#text(" is a central element of ")#mi("{G_n}")#text(" for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(". Similarly, if for each ")#mi("{n}")#text(", ")#mi("{H_n}")#text(" is a subset of ")#mi("{G_n}")#text(", then the ultraproduct ")#mi("{\\prod_{n \\rightarrow \\alpha} H_n}")#text(" is a normal subgroup of ")#mi("{G}")#text(" if and only if ")#mi("{H_n}")#text(" is a normal subgroup of ")#mi("{G_n}")#text(" for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(".")],
[#text("The standard natural numbers ")#mi("{{\\bf N}}")#text(" obey the axiom of induction: if ")#mi("{P(n)}")#text(" is a predicate definable in the language of Peano arithmetic, and ")#mi("{P(0)}")#text(" is true, and ")#mi("{P(n)}")#text(" implies ")#mi("{P(n+1)}")#text(" for all ")#mi("{n \\in {\\bf N}}")#text(", then ")#mi("{P(n)}")#text(" is true for all ")#mi("{n \\in {\\bf N}}")#text(". As a consequence, the same axiom of induction also holds for the nonstandard natural numbers ")#mi("{{}^*{\\bf N}}")#text(". Note however it is important for the nonstandard axiom of induction that the predicate be definable in the language of Peano arithmetic. For instance, the following argument is fallacious: “")#mi("{0 \\in {\\bf N}}")#text(", and for any nonstandard natural number ")#mi("{n}")#text(", ")#mi("{n \\in {\\bf N}}")#text(" implies ")#mi("{n+1 \\in {\\bf N}}")#text(". Hence, by induction, ")#mi("{n \\in {\\bf N}}")#text(" for all nonstandard natural numbers ")#mi("{n}")#text("“. The reason is that the predicate “")#mi("{n \\in {\\bf N}}")#text("” is not formalisable in the language of Peano arithmetic.")],
[#text("Exercise ")#link(<tao-3d099d0f13df9d0bb442>)[#text("9")]#text(" can be interpreted as a special case of Corollary ")#link(<tao-cb6e53541e37a1d6076e>)[#text("7")]#text(".")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]

#list(
[#text("(i) Show that ")#mi("{{\\bf N}}")#text(" (viewed as a subset of ")#mi("{{}^* {\\bf N}}")#text(") is not a nonstandard space. (")#emph[#text("Hint:")]#text(" if it were, the fallacious induction mentioned earlier could now be made valid.)")],
[#text("(ii) Establish the ")#link("http://en.wikipedia.org/wiki/Overspill")[#text("overspill")]#text(" principle: if a nonstandard predicate ")#mi("{P(n)}")#text(" on the nonstandard natural numbers is true for all standard natural numbers, then it is true for at least one strictly nonstandard natural number as well.")],
[#text("(iii) Show that if a nonstandard subset of ")#mi("{{}^* {\\bf N}}")#text(" consists only of standard natural numbers, then it is finite.")],
[#text("(iv) Show that the nonstandard natural numbers ")#mi("{{}^* {\\bf N}}")#text(" are not well-ordered. Why does this not contradict Los’s theorem?")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" For each ")#mi("{n}")#text(", let ")#mi("{G_n}")#text(" be a group, and let ")#mi("{S_n}")#text(" be a subset of ")#mi("{G_n}")#text(". Write ")#mi("{G := \\prod_{n \\rightarrow \\alpha} G_n}")#text(" and ")#mi("{S := \\prod_{n \\rightarrow\\alpha} S_n}")#text(".")

#list(
[#text("(i) Give an example in which each ")#mi("{S_n}")#text(" generates ")#mi("{G_n}")#text(" as a group, but ")#mi("{S}")#text(" does not generate ")#mi("{G}")#text(" as a group.")],
[#text("(ii) Show that ")#mi("{S}")#text(" generates ")#mi("{G}")#text(" as a group if and only if there exists a (standard) natural number ")#mi("{M}")#text(" such that ")#mi("{(S_n \\cup \\{1\\} \\cup S^{-1}_n)^M = G_n}")#text(" for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(". (")#emph[#text("Hint:")]#text(" apply countable saturation (Exercise ")#link(<tao-cdf5b9d70c6aa5a74e2d>)[#text("10")]#text(") to the sets ")#mi("{(S \\cup \\{1\\} \\cup S^{-1})^M}")#text(".)")]
)
]

#text("Now we make Los’s theorem more precise, by defining a ")#link("http://en.wikipedia.org/wiki/Formal_language")[#text("formal language")]#text(" for first-order logic. (This section is optional and may be safely omitted by the reader.)")

#text("Suppose we are given a collection ")#mi("{{\\mathcal L}}")#text(" of formal objects, spaces, operators, and relations, with each object (formally) belonging to one of the spaces, and with each of the operators and relations formally defined on some collection of these spaces (and in the case of operators, taking values in one of the spaces) as well. We will refer to elements of ")#mi("{{\\mathcal L}}")#text(" as ")#emph[#text("primitive terms")]#text(". Initially, we do not actually identify these formal terms with concrete counterparts, whether they be standard or nonstandard. A ")#link("http://en.wikipedia.org/wiki/Well-formed_formula")[#text("well-formed formula")]#text(" involving ")#mi("{{\\mathcal L}}")#text(" and one or more formal free variables ")#mi("{x_1,\\ldots,x_n}")#text(", each of which belonging to one of the formal spaces, is formed by a finite number of applications of the following rules:")

#list(
[#text("Each free variable ")#mi("{x_1,\\ldots,x_n}")#text(" is a well-formed formula (belonging to the associated formal space).")],
[#text("Each object in ")#mi("{{\\mathcal C}}")#text(" is a well-formed formula (belonging to the associated formal space).")],
[#text("If ")#mi("{a_1,\\ldots,a_k}")#text(" are well-formed formulae, and ")#mi("{O}")#text(" is a ")#mi("{k}")#text("-ary operator, then ")#mi("{O(a_1,\\ldots,a_k)}")#text(" will be a well-formed formula if the ")#mi("{a_1,\\ldots,a_k}")#text(" belong to the formal spaces indicated by the domain of ")#mi("{O}")#text(". Of course, ")#mi("{O(a_1,\\ldots,a_k)}")#text(" then belongs to the formal space indicated by the range of ")#mi("{O}")#text(".")]
)

#text("A ")#emph[#text("formal predicate")]#text(" ")#mi("{P = P(x_1,\\ldots,x_k)}")#text(" involving ")#mi("{{\\mathcal L}}")#text(" and one or more free variables ")#mi("{x_1,\\ldots,x_k}")#text(" is then formed by a finite number of applications of the following rules:")

#list(
[#text("If ")#mi("{X}")#text(", ")#mi("{Y}")#text(" are well-formed formulae belonging to the same formal space, then ")#mi("{X=Y}")#text(" is a predicate.")],
[#text("If ")#mi("{X_1,\\ldots,X_k}")#text(" are well-formed formulae, and ")#mi("{R}")#text(" is a ")#mi("{k}")#text("-ary relation in ")#mi("{{\\mathcal L}}")#text(", then ")#mi("{R(X_1,\\ldots,X_k)}")#text(" is a predicate if the ")#mi("{X_1,\\ldots,X_k}")#text(" belong to the formal spaces indicated by the domain of ")#mi("{R}")#text(".")],
[#text("If ")#mi("{P}")#text(" and ")#mi("{Q}")#text(" are predicates, then so are ")#mi("{(P \\vee Q)}")#text(", ")#mi("{(P \\wedge Q)}")#text(", ")#mi("{(\\neg P)}")#text(", ")#mi("{(P \\implies Q)}")#text(", and ")#mi("{(P \\iff Q)}")#text(".")],
[#text("If ")#mi("{P(x_1,\\ldots,x_k,x)}")#text(" is a predicate in ")#mi("{x_1,\\ldots,x_k}")#text(" and an additional free variable ")#mi("{x}")#text(" in some formal space ")#mi("{X}")#text(", then ")#mi("{(\\exists x \\in X: P(x_1,\\ldots,x_k,x))}")#text(" and ")#mi("{(\\forall x \\in X: P(x_1,\\ldots,x_k,x))}")#text(" are predicates in ")#mi("{x_1,\\ldots,x_k}")#text(". (Similarly for any permutation in the ordering of ")#mi("{x_1,\\ldots,x_k,x}")#text(".)")]
)

#text("Given a formal predicate involving ")#mi("{{\\mathcal L}}")#text(" and one or more free variables ")#mi("{x_1,\\ldots,x_n}")#text(", we may ")#emph[#text("quantify")]#text(" (or ")#emph[#text("interpret")]#text(") the predicate by associating each formal object in ")#mi("{{\\mathcal L}}")#text(" to an actual object, which may be a standard object, a nonstandard object, or something else entirely, and similarly associating an actual space, relation, or operator to each formal space, relation, or operator, making sure that all the relevant domains and ranges are respected. When one does so, the formal predicate ")#mi("{P}")#text(" becomes a concrete predicate ")#mi("{P: X_1 \\times \\ldots \\times X_k \\rightarrow \\{ \\text{true}, \\text{false}\\}}")#text(" on the appropriate quantified spaces by interpreting all the symbols in ")#mi("{P}")#text(" in the obvious fashion. For instance, if the primitive terms consist of a formal space ")#mi("{X}")#text(" and a formal binary operation ")#mi("{\\cdot: X \\times X \\rightarrow X}")#text(", then ")#mi("{P(x) := ``\\forall y \\in X: xy = yx^{\\prime\\prime}}")#text(" is a formal unary predicate, and if one quantifies this predicate over a concrete group ")#mi("{G=(G,\\cdot)}")#text(" (which may be standard, nonstandard, or neither), then one obtains a concrete unary predicate ")#mi("{P: G \\rightarrow \\{\\text{true}, \\text{false}\\}}")#text(", with ")#mi("{P(g)}")#text(" true precisely when ")#mi("{g}")#text(" is a central element of ")#mi("{G}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" With the above definitions, prove Theorem ")#link(<tao-06271baf49532c879aa3>)[#text("6")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Compactness theorem)")]#text(" Let ")#mi("{{\\mathcal L}}")#text(" be an at most countable collection of formal objects, spaces, operators and relations. Let ")#mi("{S_1, S_2, S_3, \\ldots}")#text(" be a sequence of sentences involving the symbols in ")#mi("{{\\mathcal L}}")#text(". Suppose that any finite collection ")#mi("{S_1,\\ldots,S_n}")#text(" of these sentences is satisfiable in the standard universe, thus there exists an assignment of standard objects, spaces, operators, or relations to each element of ")#mi("{{\\mathcal L}}")#text(" for which ")#mi("{S_1,\\ldots,S_n}")#text(" are all true when quantified over these assignments. Show that the entire collection ")#mi("{S_1,S_2,\\ldots}")#text(" are then satisfiable in the nonstandard universe, thus there exists an assignment of nonstandard objects. (This is the countable case of the ")#link("http://en.wikipedia.org/wiki/Compactness_theorem")[#text("compactness theorem")]#text(" in logic. One can also use ultraproducts over larger sets than ")#mi("{{\\bf N}}")#text(" to prove the general case of the compactness theorem, but we will not do so here.)")
]

#heading(level: 1)[#strong[#text(" — 3. Nonstandard finite sets and nonstandard finite sums — ")]]

#text("It will be convenient to extend the standard machinery of finite sets and finite sums to the nonstandard setting. Define a ")#emph[#text("nonstandard finite set")]#text(" to be an ultraproduct ")#mi("{A = \\prod_{n \\rightarrow \\alpha} A_n}")#text(" of finite sets, and a ")#emph[#text("nonstandard finite sequence of reals")]#text(" ")#mi("{(x_m)_{m \\in A}}")#text(" to be a nonstandard function ")#mi("{m \\mapsto x_m}")#text(" from a nonstandard finite set ")#mi("{A}")#text(" to the nonstandard reals, or equivalently an ultralimit of standard finite sequences ")#mi("{(x_{m,n})_{m \\in A_n}}")#text(" of reals. We can define the (nonstandard) cardinality ")#tao-math("{\\left|A\\right|}", block: false)#text(" of a nonstandard finite set in the usual manner:")

#align(center)[#tao-fit-display[#tao-math("\\left|\\prod_{n \\rightarrow \\alpha} A_n\\right| := \\lim_{n \\rightarrow \\alpha} \\left|A_n\\right|.", block: true)]]

#text("Thus, for instance, if ")#mi("{N}")#text(" is a nonstandard natural number, then the nonstandard finite set ")#mi("{\\{ n \\in {}^* {\\bf N}: 1 \\leq n \\leq N\\}}")#text(" has nonstandard cardinality ")#mi("{N}")#text(".")

#text("Similarly, if ")#mi("{(x_m)_{m \\in A} = \\lim_{n \\rightarrow \\alpha} (x_{m,n})_{m \\in A_n}}")#text(" is a nonstandard finite sequence of reals, we define the nonstandard sum ")#mi("{\\sum_{m \\in A} x_m}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\in A} x_m := \\lim_{n \\rightarrow \\alpha} \\sum_{m \\in A_n} x_{m,n}.")]]

#text("Thus for instance ")#tao-math("{\\sum_{m \\in A} 1 = \\left|A\\right|}", block: false)#text(". By using Los’s theorem, all the basic laws of algebra for manipulating standard finite sums carry over to nonstandard finite sums. For instance, we may interchange summations")

#align(center)[#tao-fit-display[#mitex("\\sum_{m_1 \\in A_1} \\sum_{m_2 \\in A_2} x_{m_1,m_2} = \\sum_{m_2 \\in A_2} \\sum_{m_1 \\in A_1} x_{m_1,m_2} = \\sum_{(m_1,m_2) \\in A_1 \\times A_2} x_{m_1,m_2}")]]

#text("for any nonstandard finite sequence ")#mi("{(x_{m_1,m_2})_{(m_1,m_2) \\in A_1 \\times A_2}}")#text(" of reals indexed by a product set, simply because the same assertion is obviously true for standard finite sequences.")

#heading(level: 1)[#strong[#text(" — 4. Asymptotic notation — ")]]

#text("The ultrapower and ultralimit constructions are extremely general, being basically applicable to any collection of standard objects, spaces, objects, and relations. However, when one applies these constructions to standard ")#emph[#text("number systems")]#text(", such as the natural numbers ")#mi("{{\\bf N}}")#text(", the integers ")#mi("{{\\bf Z}}")#text(", the real numbers ")#mi("{{\\bf R}}")#text(", or the complex numbers ")#mi("{{\\bf C}}")#text(" to obtain nonstandard number systems such as ")#mi("{{}^* {\\bf N}}")#text(", ")#mi("{{}^* {\\bf Z}}")#text(", ")#mi("{{}^* {\\bf R}}")#text(", ")#mi("{{}^* {\\bf C}}")#text(", then one can gain an additional tool of use in analysis, namely a clean ")#emph[#text("asymptotic notation")]#text(" which is closely related to standard asymptotic notation, but has a slightly different arrangement of quantifiers that make the nonstandard asymptotic notation better suited to algebraic constructions (such as the quotient space construction) than standard asymptotic notation.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 8 (Asymptotic notation)")]#text(" Let ")#mi("{R}")#text(" be one of the standard number systems (")#mi("{{\\bf N}}")#text(", ")#mi("{{\\bf Z}}")#text(", ")#mi("{{\\bf Q}}")#text(", ")#mi("{{\\bf R}}")#text(", ")#mi("{{\\bf C}}")#text("). A nonstandard number ")#mi("{x}")#text(" in ")#mi("{{}^* R}")#text(" is said to be ")#emph[#text("bounded")]#text(" if one has ")#tao-math("{\\left|x\\right| \\leq C}", block: false)#text(" for some standard real number ")#mi("{C}")#text(" (or equivalently, ")#tao-math("{\\left|x\\right| \\leq n}", block: false)#text(" some standard natural number ")#mi("{n}")#text("), and ")#emph[#text("unbounded")]#text(" otherwise. If ")#mi("{y}")#text(" is a non-negative nonstandard real, we write ")#mi("{x = O(y)}")#text(" if ")#tao-math("{\\left|x\\right| \\leq Cy}", block: false)#text(" for some standard real number ")#mi("{C}")#text(", thus a nonstandard number is bounded if and only if it is ")#mi("{O(1)}")#text(". We say that ")#mi("{x}")#text(" is ")#emph[#text("infinitesimal")]#text(" if ")#tao-math("{\\left|x\\right| \\leq \\epsilon}", block: false)#text(" for every standard real number ")#mi("{\\epsilon>0}")#text(" (or equivalently, if ")#tao-math("{\\left|x\\right| \\leq \\frac{1}{n}}", block: false)#text(" for all standard positive natural numbers ")#mi("{n}")#text("), and write ")#mi("{x=o(y)}")#text(" if ")#tao-math("{\\left|x\\right| \\leq \\epsilon y}", block: false)#text(" for all standard real numbers ")#mi("{\\epsilon>0}")#text(", thus ")#mi("{x}")#text(" is infinitesimal if and only if it is ")#mi("{o(1)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" All standard numbers are bounded, and all non-zero standard numbers are non-infinitesimal. The nonstandard natural number ")#mi("{N := \\lim_{n \\rightarrow \\alpha} n}")#text(" is unbounded, and the nonstandard real number ")#mi("{\\frac{1}{N} = \\lim_{n\\rightarrow \\alpha} \\frac{1}{n}}")#text(" is non-zero but infinitesimal.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" One can also develop analogous nonstandard asymptotic notation on other spaces, such as normed vector spaces or locally compact groups; see for instance ")#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/")[#text("this previous blog post")]#text(" for an example of the former, and ")#link("http://www.ams.org/mathscinet-getitem?mr=967314")[#text("this paper of Hirschfeld")]#text(" on a nonstandard proof of Hilbert’s fifth problem for an example of the latter. We will however not need to deploy nonstandard asymptotic notation in such generality here.")
]

#text("Note that we can apply asymptotic notation to individual nonstandard numbers, in contrast to standard asymptotic notation in which one needs to have the numbers involved to depend on some additional parameter if one wishes to prevent the notation from degenerating into triviality. In particular, we can form well-defined sets such as the ")#emph[#text("bounded nonstandard reals")]

#align(center)[#tao-fit-display[#mitex("O({\\bf R}) := \\{ x \\in {}^* {\\bf R}: x = O(1) \\}")]]

#text("and the ")#emph[#text("infinitesimal nonstandard reals")]

#align(center)[#tao-fit-display[#mitex("o({\\bf R}) := \\{ x \\in {}^* {\\bf R}: x = o(1) \\}.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Standard part)")]#text(" Show that ")#mi("{o({\\bf R})}")#text(" is an ideal of the commutative ring ")#mi("{O({\\bf R})}")#text(", and one has the decomposition ")#mi("{O({\\bf R}) = {\\bf R} \\oplus o({\\bf R})}")#text(", thus every bounded real ")#mi("{x = O({\\bf R})}")#text(" has a unique decomposition ")#mi("{x = \\text{st}(x) + (x-\\text{st}(x))}")#text(" into a ")#emph[#text("standard part")]#text(" ")#mi("{\\text{st}(x) \\in {\\bf R}}")#text(" and an ")#emph[#text("infinitesimal part")]#text(" ")#mi("{x - \\text{st}(x) \\in o({\\bf R})}")#text(". Show that the map ")#mi("{x \\mapsto \\text{st}(x)}")#text(" is a ring homomorphism from ")#mi("{O({\\bf R})}")#text(" to ")#mi("{{\\bf R}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Let ")#mi("{N}")#text(" be an unbounded nonstandard natural number. Write ")#mi("{O_{\\bf Z}(N) := \\{ n \\in {}^* {\\bf Z}: n = O(N)\\}}")#text(" and ")#mi("{o_{\\bf Z}(N) := \\{ n \\in {}^* {\\bf Z}: n = o(N)\\}}")#text(". Show that ")#mi("{o_{\\bf Z}(N)}")#text(" is a subgroup of the additive group ")#mi("{O_{\\bf Z}(N)}")#text(", and that the quotient group ")#mi("{O_{\\bf Z}(N)/o_{\\bf Z}(N)}")#text(" is isomorphic (as an additive group) to the standard real numbers ")#mi("{{\\bf R}}")#text(". (One could in fact use this construction as a ")#emph[#text("definition")]#text(" of the real number system, although this would be a rather idiosyncratic choice of construction.)")
]

#text("The following exercise should be compared with Proposition ")#link(<tao-84bae4db933bb6e48e3d>)[#text("1")]#text(". Note the absence of a continuity hypothesis on the function ")#mi("{f}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Let ")#mi("{f: X \\rightarrow {\\bf R}}")#text(" be a standard function, which we extend to a nonstandard function ")#mi("{f: {}^* X \\rightarrow {}^* {\\bf R}}")#text(" in the usual manner. Show that the following statements are equivalent:")

#list(
[#text("(i) (Qualitative bound on nonstandard objects) For all ")#mi("{x \\in {}^* X}")#text(", one has ")#mi("{f(x) = O(1)}")#text(".")],
[#text("(ii) (Quantitative bound on standard objects) There exists a standard real ")#mi("{M < +\\infty}")#text(" such that ")#tao-math("{\\left|f(x)\\right| \\leq M}", block: false)#text(" for all ")#mi("{x \\in X}")#text(".")]
)

#text("(")#emph[#text("Hint:")]#text(" use some version of the countable saturation property.)")
]

#text("One of the first motivations of nonstandard analysis was to obtain a rigorous theory of infinitesimals that could be used as an alternate (though logically equivalent) foundation for real analysis. We will not need to use this foundation here, but the following exercises are intended to give some indication of one might start setting up such foundations.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Let ")#mi("{E}")#text(" be a standard subset of the reals ")#mi("{{\\bf R}}")#text(".")

#list(
[#text("Show that ")#mi("{E}")#text(" is open if and only if ")#mi("{E + o({\\bf R}) \\subset {}^* E}")#text(", or equivalently if ")#mi("{\\text{st}^{-1}(E) \\subset {}^* E}")#text(". (Here, ")#mi("{A+B := \\{a+b: a \\in A, b \\in B \\}}")#text(" denotes the sumset of ")#mi("{A}")#text(" and ")#mi("{B}")#text(".)")],
[#text("Show that ")#mi("{E}")#text(" is closed if and only if ")#mi("{{}^* E \\cap O({\\bf R}) \\subset E + o({\\bf R})}")#text(", or equivalently if ")#mi("{\\text{st}({}^* E \\cap O({\\bf R})) \\subset E}")#text(".")],
[#text("Show that ")#mi("{E}")#text(" is bounded if and only if ")#mi("{{}^* E \\subset O({\\bf R})}")#text(".")],
[#text("Show that ")#mi("{E}")#text(" is compact if and only if ")#mi("{{}^* E \\subset E + o({\\bf R})}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Let ")#mi("{(x_n)_{n \\in {\\bf N}}}")#text(" be a standard sequence of reals, and let ")#mi("{(x_n)_{n \\in {}^* {\\bf N}}}")#text(" be its nonstandard extension. Let ")#mi("{L}")#text(" be a real number.")

#list(
[#text("Show that ")#mi("{x_n}")#text(" converges to ")#mi("{L}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" if and only if ")#mi("{x_N = L+o(1)}")#text(" for all unbounded natural numbers ")#mi("{N}")#text(".")],
[#text("Show that ")#mi("{\\sum_{n=1}^\\infty x_n}")#text(" is conditionally convergent to ")#mi("{L}")#text(" if and only if ")#mi("{\\sum_{n=1}^N x_N = L + o(1)}")#text(" for all unbounded natural numbers ")#mi("{N}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a standard function, and let ")#mi("{f: {}^* {\\bf R} \\rightarrow {}^* {\\bf R}}")#text(" be its nonstandard extension. Show that the following are equivalent:")

#list(
[#mi("{f}")#text(" is a continuous function.")],
[#text("One has ")#mi("{f(y) = f(x)+o(1)}")#text(" whenever ")#mi("{x \\in {\\bf R}}")#text(", ")#mi("{y \\in {}^* {\\bf R}}")#text(", and ")#mi("{y = x+o(1)}")#text(".")],
[#text("One has ")#mi("{f(\\text{st}(x)) = \\text{st}(f(x))}")#text(" for all ")#mi("{x \\in O({\\bf R})}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a standard function, and let ")#mi("{f: {}^* {\\bf R} \\rightarrow {}^* {\\bf R}}")#text(" be its nonstandard extension. Show that the following are equivalent:")

#list(
[#mi("{f}")#text(" is a uniformly continuous function.")],
[#text("One has ")#mi("{f(y) = f(x) + o(1)}")#text(" whenever ")#mi("{x, y \\in {}^* {\\bf R}}")#text(" and ")#mi("{y=x+o(1)}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a standard function, and let ")#mi("{f: {}^* {\\bf R} \\rightarrow {}^* {\\bf R}}")#text(" be its nonstandard extension. Show that the following are equivalent:")

#list(
[#mi("{f}")#text(" is a differentiable function.")],
[#text("There exists a standard function ")#mi("{f^{\\prime}: {\\bf R} \\rightarrow {\\bf R}}")#text(" such that ")#tao-math("{f(x+h) = f(x) + f^{\\prime}(x) h + o(\\left|h\\right|)}", block: false)#text(" for all ")#mi("{x \\in {\\bf R}}")#text(" and ")#mi("{h = o(1)}")#text(", or equivalently if ")#mi("{f^{\\prime}(x) = \\text{st} \\frac{f(x+h)-f(x)}{h}}")#text(" for all ")#mi("{x \\in {\\bf R}}")#text(" and non-zero ")#mi("{h = o(1)}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a standard continuous function, and let ")#mi("{f: {}^* {\\bf R} \\rightarrow {}^* {\\bf R}}")#text(" be its nonstandard extension. Show that for any standard reals ")#mi("{a<b}")#text(" and any unbounded natural number ")#mi("{N}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\int_a^b f(x)\\ dx = \\text{st} \\frac{1}{N} \\sum_{n=1}^N f(a + \\frac{b-a}{N} n)")]]

#text("(note that ")#mi("{\\sum_{n=1}^N f(a + \\frac{b-a}{N} n)}")#text(" is a nonstandard finite sum). More generally, show that")

#align(center)[#tao-fit-display[#mitex("\\int_a^b f(x)\\ dx = \\text{st} \\frac{1}{N} \\sum_{n=1}^N f(x_n^*) (x_n - x_{n-1})")]]

#text("whenever ")#mi("{(x_n)_{0 \\leq n \\leq N}}")#text(" and ")#mi("{(x_n^*)_{1 \\leq n \\leq N}}")#text(" are nonstandard finite sequences with ")#mi("{a \\leq x_{n-1} \\leq x_n^* \\leq x_n \\leq b}")#text(" and ")#mi("{x_n = x_{n-1} + o(1)}")#text(" for all ")#mi("{1 \\leq n \\leq N}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 5. Ultra approximate groups — ")]]

#text("In this section we specialise the above ultraproduct machinery to the concept of a finite approximate group, to link such objects with a type of infinite approximate group which we call an ")#emph[#text("ultra approximate group")]#text(". These objects will be studied much more intensively in the next two lectures, but for now we focus on the correspondence between ultra approximate groups and their finitary counterparts.")

#text("We first recall the notion of an approximate group. For simplicity, we work for now in the global group setting, although later on we will also need to generalise to local groups.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 9 (Approximate group)")]#text(" Let ")#mi("{K \\geq 1}")#text(" be a standard real number. A (global) ")#emph[#text("approximate group")]#text(" is a subset ")#mi("{A}")#text(" of a global group ")#mi("{G = (G,\\cdot)}")#text(" which is symmetric, contains the identity, and is such that ")#mi("{A \\cdot A}")#text(" can be covered by at most ")#mi("{K}")#text(" left-translates of ")#mi("{A}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 10 (Ultra approximate group)")]#text(" An ")#emph[#text("ultra approximate group")]#text(" is an ultraproduct ")#mi("{A = \\prod_{n \\rightarrow \\alpha} A_n}")#text(", where each ")#mi("{A_n \\subset G_n}")#text(" is a standard finite ")#mi("{K}")#text("-approximate group for some ")#mi("{K}")#text(" independent of ")#mi("{n}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" If ")#mi("{N = \\prod_{n \\rightarrow \\alpha} N_n}")#text(" is a nonstandard natural number, then the nonstandard arithmetic progression ")#mi("{\\{ m \\in {}^* {\\bf N}: -N \\leq m \\leq N \\}}")#text(" is an ultra approximate group, because it is an ultraproduct of standard finite ")#mi("{2}")#text("-approximate groups ")#mi("{\\{ m \\in {\\bf N}: -N_n \\leq m \\leq N_n\\}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4")]#text(" If ")#mi("{N = \\prod_{n \\rightarrow \\alpha} N_n}")#text(" is a nonstandard natural number, then the nonstandard cyclic group ")#mi("{{\\bf Z}/N{\\bf Z} = \\prod_{n \\rightarrow \\alpha} {\\bf Z}/N_n{\\bf Z}}")#text(" is an ultra approximate group, because it is an ultraproduct of standard cyclic groups. More generally, any nonstandard finite group (i.e. an ultraproduct of standard finite groups) is an ultra approximate group.")
]

#text("For any fixed ")#mi("{K}")#text(", the statement of a set ")#mi("{A}")#text(" in a group ")#mi("{G}")#text(" being a ")#mi("{K}")#text("-approximate group can be phrased in first-order logic quantified over ")#mi("{G}")#text(" using the group operations and the predicate ")#mi("{x \\in A}")#text(" of membership in ")#mi("{A}")#text(". From this and Los’s theorem, we see that any ultraproduct of ")#mi("{K}")#text("-approximate groups is again a ")#mi("{K}")#text("-approximate group. In particular, an ultra approximate group is a ")#mi("{K}")#text("-approximate group for some (standard) finite ")#mi("{K}")#text(".")

#text("We will be able to make a correspondence between various assertions about ")#mi("{K}")#text("-approximate groups and about ultra approximate groups, so that problems about the former can be translated to problems about the latter. By itself, this correspondence is not particularly deep or substantial; but the point will be that by moving from the finitary category of finite ")#mi("{K}")#text("-approximate groups to the infinitary category of ultra approximate groups, we will be able to deploy tools from infinitary mathematics, and in particular the topological group theory results (such as the Gleason-Yamabe theorem) from previous notes, to bear on the problem. We will execute this strategy in the next few notes, but for now, let us just see how the correspondence works. We begin with a simple example, in the bounded ")#link("http://en.wikipedia.org/wiki/Torsion_group")[#text("torsion")]#text(" case. For a standard natural number ")#mi("{r}")#text(", we say that a group ")#mi("{G}")#text(" is ")#emph[#mi("{r}")#text("-torsion")]#text(" if every element has order at most ")#mi("{r}")#text(", thus for each ")#mi("{g \\in G}")#text(" one has ")#mi("{g^n = 1}")#text(" for some ")#mi("{1 \\leq n \\leq r}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 11 (Correspondence in the torsion case)")]#text(" Let ")#mi("{r \\geq 1}")#text(". The following two statements are equivalent:")

#list(
[#text("(i) (Finitary statement) For all ")#mi("{K \\geq 1}")#text(", there exists ")#mi("{C_{K,r} \\geq 1}")#text(" such that, given a finite ")#mi("{K}")#text("-approximate group ")#mi("{A}")#text(" in an ")#mi("{r}")#text("-torsion group ")#mi("{G}")#text(", one can find a finite (genuine) subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" such that ")#mi("{A^4}")#text(" contains ")#mi("{H}")#text(", and ")#mi("{A}")#text(" can be covered by at most ")#mi("{C_{K,r}}")#text(" left-translates of ")#mi("{H}")#text(".")],
[#text("(ii) (Infinitary statement) For any ultra approximate group ")#mi("{A}")#text(" in a ")#mi("{r}")#text("-torsion nonstandard group ")#mi("{G}")#text(", one can find a nonstandard finite subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" such that ")#mi("{A^4}")#text(" contains ")#mi("{H}")#text(", and ")#mi("{A}")#text(" can be covered by finitely many left-translates of ")#mi("{H}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" Let us first assume (i) and establish (ii). Let ")#mi("{A = \\prod_{n \\rightarrow \\alpha} A_n}")#text(" be an ultra approximate group in an ")#mi("{r}")#text("-torsion nonstandard group ")#mi("{G = \\prod_{n \\rightarrow \\alpha} G_n}")#text(". Since ")#mi("{G}")#text(" is ")#mi("{r}")#text("-torsion, and the property of being ")#mi("{r}")#text("-torsion is a first-order statement in the language of groups, we see from Los’s theorem that ")#mi("{G_n}")#text(" is a ")#mi("{r}")#text("-torsion group for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(". Since the ")#mi("{A_n}")#text(" are all finite ")#mi("{K}")#text("-approximate groups for some ")#mi("{K}")#text(" independent of ")#mi("{n}")#text(", we conclude from (i) that for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(", we can find a finite subgroup ")#mi("{H_n}")#text(" of ")#mi("{G_n}")#text(" such that ")#mi("{A_n^4}")#text(" contains ")#mi("{H_n}")#text(", and ")#mi("{A_n}")#text(" can be covered by at most ")#mi("{C_{K,r}}")#text(" left-translates of ")#mi("{H_n}")#text(". Taking ")#mi("{H := \\prod_{n \\rightarrow \\alpha} H_n}")#text(" and applying Los’s theorem again, we cnoclude that ")#mi("{H}")#text(" is a nonstandard finite subgroup of ")#mi("{G}")#text(", that ")#mi("{A^4}")#text(" contains ")#mi("{H}")#text(", and ")#mi("{A}")#text(" can be covered by at most ")#mi("{C_{K,r}}")#text(" left-translates of ")#mi("{H}")#text(", giving (ii) as desired.")

#text("Now we assume (ii) and establish (i). Suppose for contradiction that (i) failed. Carefully negating the quantifiers, we conclude that there exists ")#mi("{K \\geq }")#text(" such that for each natural number ")#mi("{n}")#text(", one can find a finite ")#mi("{K}")#text("-approximate group ")#mi("{A_n}")#text(" in an ")#mi("{r}")#text("-torsion group ")#mi("{G_n}")#text(" for which there does ")#emph[#text("not")]#text(" exist any finite subgroup ")#mi("{H_n}")#text(" of ")#mi("{G_n}")#text(" such that ")#mi("{A_n^4}")#text(" contains ")#mi("{H_n}")#text(" ")#emph[#text("and")]#text(" ")#mi("{A_n}")#text(" can be covered by at most ")#mi("{n}")#text(" left-translates of ")#mi("{H_n}")#text(". We then form the ultraproducts ")#mi("{A := \\prod_{n \\rightarrow \\alpha} A_n}")#text(" and ")#mi("{G := \\prod_{n \\rightarrow \\alpha} G_n}")#text(". By Los’s theorem, ")#mi("{G}")#text(" is an ")#mi("{r}")#text("-torsion nonstandard group, and ")#mi("{A}")#text(" is an ultra approximate group in ")#mi("{G}")#text(". Thus, by (ii), there is a nonstandard finite subgroup ")#mi("{H = \\prod_{n \\rightarrow \\alpha} H_n}")#text(" of ")#mi("{G}")#text(" such that ")#mi("{A^4}")#text(" contains ")#mi("{H}")#text(" and ")#mi("{A}")#text(" is covered by ")#mi("{M}")#text(" left-translates of ")#mi("{H}")#text(" for some (standard) natural number ")#mi("{M}")#text(". By Los’s theorem, we conclude that for all ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(", ")#mi("{H_n}")#text(" is a finite subgroup of ")#mi("{G_n}")#text(", ")#mi("{A_n^4}")#text(" contains ")#mi("{H_n}")#text(", and ")#mi("{A_n}")#text(" is covered by ")#mi("{M}")#text(" left-translates of ")#mi("{H_n}")#text(". In particular, as ")#mi("{\\alpha}")#text(" is nonprincipal, this assertion holds for at least one ")#mi("{n > M}")#text(". But this contradicts the construction of ")#mi("{A_n}")#text(". ")#mi("\\Box")

#text("Note how the infinitary statement in the above proposition is a qualitative version of the more quantitative finitary statement. In particular, parameters such as ")#mi("{K}")#text(" and ")#mi("{C_{K,r}}")#text(" have been efficiently concealed in the infinitary formulation, whereas they must be made explicit in the finitary formulation. As such, the infinitary approach leads to a reduction in the amount of “epsilon management” that one often has to perform in finitary settings.")

#text("In the next section we will use the Gleason-Yamabe theorem to establish (ii) and hence conclude (i) as a corollary (this argument is essentially ")#link("http://arxiv.org/abs/0909.2190")[#text("due to Hrushovski")]#text("). Interestingly, no purely finitary proof of (i) in full generality is currently known (other than by finitising the infinitary proof, which is in principle possible, but would create an extremely long and messy proof as a consequence). We move from the bounded torsion setting to another special case, namely the abelian setting. Here, the finite subgroups need to be replaced by the more general concept of a ")#emph[#text("coset progression")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 12")]#text(" A (standard symmetric) ")#emph[#text("generalised arithmetic progression")]#text(" ")#mi("{P}")#text(" of rank ")#mi("{r}")#text(" in a (standard) additive group ")#mi("{G = (G,+)}")#text(" is a set of the form")

#align(center)[#tao-fit-display[#tao-math("P = P(v_1,\\ldots,v_r;N_1,\\ldots,N_r) := \\{ a_1 v_1 + \\ldots + a_r v_r: \\left|a_1\\right| \\leq N_1, \\ldots, \\left|a_r\\right| \\leq N_r \\}", block: true)]]

#text("where ")#mi("{v_1,\\ldots,v_r \\in G}")#text(", ")#mi("{N_1,\\ldots,N_r > 0}")#text(", and the ")#mi("{a_1,\\ldots,a_r}")#text(" are constrained to be integers. An ")#emph[#text("ultra generalised arithmetic progression")]#text(" is an ultraproduct ")#mi("{P := \\prod_{n \\rightarrow \\alpha} P_n}")#text(" of standard generalised arithmetic progressions ")#mi("{P_n}")#text(" of fixed rank ")#mi("{r}")#text(".")

#text("A (standard) ")#emph[#text("coset progression")]#text(" ")#mi("{Q}")#text(" of rank ")#mi("{r}")#text(" in a (standard) additive group ")#mi("{G = (G,+)}")#text(" is a set of the form ")#mi("{Q=H+P}")#text(", where ")#mi("{H}")#text(" is a finite subgroup of ")#mi("{G}")#text(" and ")#mi("{P}")#text(" is a generalised arithmetic progression of rank ")#mi("{r}")#text(". An ")#emph[#text("ultra coset progression")]#text(" is an ultraproduct ")#mi("{Q := \\prod_{n \\rightarrow \\alpha} Q_n}")#text(" of standard coset progressions ")#mi("{Q_n}")#text(" of fixed rank ")#mi("{r}")#text("; equivalently, it is a set of the form ")#mi("{H+P}")#text(", where ")#mi("{H}")#text(" is a nonstandard finite group in a nonstandard group ")#mi("{G}")#text(", and ")#mi("{P}")#text(" is an ultra generalised arithmetic progression in ")#mi("{G}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" Show that the following two statements are equivalent:")

#list(
[#text("(i) (Finitary abelian Freiman theorem) For all ")#mi("{K \\geq 1}")#text(", there exists ")#mi("{C_{K}, r_K \\geq 1}")#text(" such that, given a finite ")#mi("{K}")#text("-approximate group ")#mi("{A}")#text(" in an abelian group ")#mi("{G = (G,+)}")#text(", one can find a coset progression ")#mi("{Q}")#text(" in ")#mi("{G}")#text(" of rank at most ")#mi("{r_K}")#text(" such that ")#mi("{A^4}")#text(" contains ")#mi("{Q}")#text(", and ")#mi("{A}")#text(" can be covered by at most ")#mi("{C_{K}}")#text(" left-translates of ")#mi("{Q}")#text(".")],
[#text("(ii) (Infinitary abelian Freiman theorem) For any ultra approximate group ")#mi("{A}")#text(" in a abelian nonstandard group ")#mi("{G = (G,+)}")#text(", one can find an ultra coset progression ")#mi("{Q}")#text(" of ")#mi("{G}")#text(" such that ")#mi("{A^4}")#text(" contains ")#mi("{Q}")#text(", and ")#mi("{A}")#text(" can be covered by finitely many left-translates of ")#mi("{Q}")#text(".")]
)
]

#text("The statement (i) was established ")#link("http://www.ams.org/mathscinet-getitem?mr=2302736")[#text("by Green and Ruzsa")]#text(" by finitary means (such as the finite Fourier transform). In later notes we will give an alternate proof of (i) that proceeds via (ii) and the structure theory of locally compact abelian groups.")

#text("Finally, we can give the correspondence in the full nonabelian setting.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 13")]#text(" Given a (standard) finite number of generators ")#mi("{v_1,\\ldots,v_r}")#text(" in a (standard) group ")#mi("{G = (G,\\cdot)}")#text(", and (standard) real numbers ")#mi("{N_1,\\ldots,N_r>0}")#text(", define the ")#emph[#text("noncommutative progression")]#text(" ")#mi("{P( v_1,\\ldots,v_r; N_1,\\ldots,N_r)}")#text(" to be the set of all words in ")#mi("{v_1^{\\pm 1},\\ldots,v_r^{\\pm 1}}")#text(" involving at most ")#mi("{N_i}")#text(" copies of ")#mi("{v_i^{\\pm 1}}")#text(" for each ")#mi("{1 \\leq i \\leq r}")#text(". We refer to ")#mi("{r}")#text(" as the ")#emph[#text("rank")]#text(" of the noncommutative progression. A ")#emph[#text("nilprogression")]#text(" of rank ")#mi("{r}")#text(" and step at most ")#mi("{s}")#text(" is a noncommutative progression that lies in a ")#link("http://en.wikipedia.org/wiki/Nilpotent_group")[#text("nilpotent group")]#text(" of step at most ")#mi("{s}")#text(". A \\epmh{coset nilprogression} in ")#mi("{G}")#text(" of rank ")#mi("{r}")#text(" and step at most ")#mi("{s}")#text(" is a set of the form ")#mi("{\\pi^{-1}(P)}")#text(", where ")#mi("{H}")#text(" is a finite group in ")#mi("{G}")#text(", ")#mi("{N(H)}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Normalizer")[#text("normaliser")]#text(" of ")#mi("{H}")#text(", ")#mi("{\\pi: N(H) \\rightarrow N(H)/H}")#text(" is the quotient map, and ")#mi("{P}")#text(" is a nilprogression of rank ")#mi("{r}")#text(" in ")#mi("{N(H)/H}")#text(".")

#text("An ")#emph[#text("ultra coset nilprogression")]#text(" is an ultraproduct ")#mi("{Q = \\prod_{n \\rightarrow \\alpha} Q_n}")#text(" of coset nilprogressions of rank ")#mi("{r}")#text(" and step at most ")#mi("{s}")#text(", for some standard natural numbers ")#mi("{r, s}")#text(" independent of ")#mi("{n}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Show that the following two statements are equivalent:")

#list(
[#text("(i) (Finitary nonabelian Freiman theorem) For all ")#mi("{K \\geq 1}")#text(", there exists ")#mi("{C_{K}, s_K, r_K \\geq 1}")#text(" such that, given a finite ")#mi("{K}")#text("-approximate group ")#mi("{A}")#text(" in a group ")#mi("{G = (G,\\cdot)}")#text(", one can find a coset nilprogression ")#mi("{Q}")#text(" in ")#mi("{G}")#text(" of rank at most ")#mi("{r_K}")#text(" and step at most ")#mi("{s_K}")#text(" such that ")#mi("{A^4}")#text(" contains ")#mi("{Q}")#text(", and ")#mi("{A}")#text(" can be covered by at most ")#mi("{C_{K}}")#text(" left-translates of ")#mi("{Q}")#text(".")],
[#text("(ii) (Infinitary nonabelian Freiman theorem) For any ultra approximate group ")#mi("{A}")#text(" in a nonstandard group ")#mi("{G = (G,\\cdot)}")#text(", one can find an ultra coset nilprogression ")#mi("{Q}")#text(" in ")#mi("{G}")#text(" such that ")#mi("{A^4}")#text(" contains ")#mi("{Q}")#text(", and ")#mi("{A}")#text(" can be covered by finitely many left-translates of ")#mi("{Q}")#text(".")]
)
]

#text("In later notes we will establish (ii), and hence (i), thus giving a (qualitatively) satisfactory description of finite approximate groups in arbitrary groups.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" Let ")#mi("{n}")#text(" be a standard natural number. Show that every nonstandard finite subgroup of ")#mi("{{}^* GL_n({\\bf C})}")#text(" is virtually abelian.")
]

#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-93344")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2011")])]

#text("Hi Terry,")

#text("I’m a bit confused by the link provided to Goedel’s paper in Remark 3. What you say is that adding the axiom of choice to ZF is _conservative_ for statements in the language of PA, but you are linking to the paper about the _relative consistency_ of adding AC to ZF. I know this course is ‘not focused on foundations’, but could you clarify?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-93345")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2011")])]

#text("The way Godel proves the relative consistency of AC in that paper is by starting with an arbitrary model of ZF and showing that inside it one can obtain a model of ZFC (namely, the ")#link("http://en.wikipedia.org/wiki/Constructible_universe")[#text("constructible universe")]#text(" L). This universe has the same model ")#mi("\\omega")#text(" of the natural numbers as the original model of ZF (basically because all natural numbers in the original model are constructible in that model), and in particular assigns the same truth value to any sentence in the language of PA as the original model (i.e. arithmetic is ")#link("http://en.wikipedia.org/wiki/Absoluteness_(mathematical_logic)")[#text("absolute")]#text(" between the original model and the constructible universe). Thus, if one can prove a sentence in the language of PA in ZFC, then that sentence is also true in all models of ZF, and hence is provable in ZF by completeness.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-93402")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2011")])]

#text("Ah, thanks. Just that the paper you linked to is a one-page research announcement and has no proofs. Makes sense now.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Proof mining and approximate groups, announcement | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-96148")[#strong[#text("Proof mining and approximate groups, announcement | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2011")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysi")[#text("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysi")]#text("… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The structure of approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-96266")[#strong[#text("The structure of approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2011")])]

#text("[…] faithful representation” is a good first approximation.) As discussed in the previous lecture notes, we use an ultralimit for this purpose; the paper of Hrushovski where this strategy was first […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 7: Models of ultra approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-97538")[#strong[#text("254A, Notes 7: Models of ultra approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2011")])]

#text("[…] the previous set of notes, we introduced the notion of an ultra approximate group – an ultraproduct of finite […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The microstructure of approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-101202")[#strong[#text("254A, Notes 8: The microstructure of approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2011")])]

#text("[…] fact, a stronger statement is true, involving the nilprogressions defined in Notes 6: Proposition […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b976ffc6598bc40e43d82d776f83d6e8abd3a5ff2c98e11134280a5d8ad366fe-602c3d9f80b279b50a9fbb45a3fc70504532b66405f6ad18f67c7b517c26451f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Machfudz")]], [#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-103873")[#strong[#text("Machfudz")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2011")])]

#text("ough…")#linebreak()#text(" I still confused..")#linebreak()#text(" XD")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Hayes")]], [#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-104066")[#strong[#text("Ben Hayes")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2011")])]

#text("In Exercise 19, should $N$ be strictly non-standard? I think in the case $N=1,$ then the quotient group is just $Z.$")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-104153")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2011")])]

#text("In definition 5, in the definition of a standard k-ary relation, the R_k should be replaced with X_k.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 5: Product theorems, pivot arguments, and the Larsen-Pink non-concentration inequality « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-126691")[#strong[#text("254B, Notes 5: Product theorems, pivot arguments, and the Larsen-Pink non-concentration inequality « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("[…] use the tool of ultraproducts (which we will phrase in the language of nonstandard analysis). See this previous blog post for a discussion of ultraproducts and how they can be used to turn quantitative (or […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A cheap version of nonstandard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-136449")[#strong[#text("A cheap version of nonstandard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2012")])]

#text("[…] an ultrapower of with respect to some non-principal ultrafilter over the natural numbers; see e.g. this blog post for details. Once one is comfortable with ultrafilters and ultrapowers, this becomes quite a simple […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Definable subsets over (nonstandard) finite fields, and almost quantifier elimination « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-169850")[#strong[#text("Definable subsets over (nonstandard) finite fields, and almost quantifier elimination « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2012")])]

#text("[…] this ultraproduct. (We will be using the notation of ultraproducts and nonstandard analysis from this previous blog post.) This approach is equivalent to the more finitary approach mentioned in the previous paragraph, at […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-186993")[#strong[#text("Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2012")])]

#text("[…] will assume some familiarity with nonstandard analysis, as covered for instance in these previous blog […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Expanding polynomials over finite fields of large characteristic, and a regularity lemma for definable sets « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-192677")[#strong[#text("Expanding polynomials over finite fields of large characteristic, and a regularity lemma for definable sets « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2012")])]

#text("[…] into equivalent qualitative, infinitary problems in zero characteristic (in the spirit of this blog post). This allows one to use several tools from those fields as “black boxes”; not just the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Multiple recurrence in quasirandom groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-197379")[#strong[#text("Multiple recurrence in quasirandom groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2012")])]

#text("[…] this mixing theorem. Instead, we had to first use the machinery of ultraproducts (as discussed in this previous post) to convert the finitary statement about a quasirandom group to an infinitary statement about a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rectification and the Lefschetz principle | What's new")]], [#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-219475")[#strong[#text("Rectification and the Lefschetz principle | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2013")])]

#text("[…] can be used as a bridge to connect quantitative and qualitative results (as discussed in these previous blog posts), we will deduce Theorem 3 from the following (well-known) qualitative […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]], [#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-255857")[#strong[#text("Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2013")])]

#text("[…] analysis“. Some of the material here is drawn from previous blog posts, notably “Ultraproducts as a bridge between hard analysis and soft analysis” and “Ultralimit analysis and quantitative algebraic geometry“‘. The text […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-549403")[#strong[#text("Métodos infinitos para resolver problemas de carácter finito – 24 Noticias")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2020")]

#text("[…] de resultados algebraicos, combinatorios y particularmente en teoría de modelos, gracias al célebre teorema del polaco Jerzy Łoś (su apellido se pronuncia como la palabra inglesa wash). El mismo Hindman […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/#comment-549510")[#strong[#text("Métodos infinitos para resolver problemas de carácter finito » Mascarillas para protección del coronavirus")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2020")]

#text("[…] de resultados algebraicos, combinatorios y particularmente en teoría de modelos, gracias al célebre teorema del polaco Jerzy Łoś (su apellido se pronuncia como la palabra inglesa wash). El mismo Hindman […]")
]
