// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T07:01:07.585089+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Mobius function is strongly orthogonal to nilsequences", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Mobius function is strongly orthogonal to nilsequences")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 July 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/")[#text("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(" and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" our paper, “")#link("http://arxiv.org/abs/0807.1736")[#text("The Möbius function is asymptotically orthogonal to nilsequences")]#text("“, which is a sequel to our earlier paper “")#link("http://arxiv.org/abs/0709.3562")[#text("The quantitative behaviour of polynomial orbits on nilmanifolds")]#text("“, which I talked about in this ")#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/")[#text("post")]#text(". In this paper, we apply our previous results on quantitative equidistribution polynomial orbits in nilmanifolds to settle the Möbius and nilsequences conjecture from our ")#link("http://arxiv.org/abs/math.NT/0606088")[#text("earlier paper")]#text(", as part of our program to detect and count solutions to linear equations in primes. (The other major plank of that program, namely the inverse conjecture for the Gowers norm, remains partially unresolved at present.) Roughly speaking, this conjecture asserts the asymptotic orthogonality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|\\frac{1}{N} \\sum_{n=1}^N \\mu(n) f(n)\\right| \\ll_A \\log^{-A} N", block: true)]]

#text("between the ")#link("http://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(" ")#mi("\\mu(n)")#text(" and any Lipschitz nilsequence f(n), by which we mean a sequence of the form ")#mi("f(n) = F(g^n x)")#text(" for some orbit ")#mi("g^n x")#text(" in a ")#link("http://en.wikipedia.org/wiki/Nilmanifold")[#text("nilmanifold")]#text(" ")#mi("G/\\Gamma")#text(", and some Lipschitz function ")#mi("F: G/\\Gamma \\to {\\Bbb C}")#text(" on that nilmanifold. (The implied constant can depend on the nilmanifold and on the Lipschitz constant of F, but it is important that it be independent of the generator g of the orbit or the base point x.) The case when f is constant is essentially the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text("; the case when f is periodic is essentially the prime number theorem in arithmetic progressions. The case when f is almost periodic (e.g. ")#mi("f(n) = e^{2\\pi i \\alpha n}")#text(" for some irrational ")#mi("\\alpha")#text(") was established by Davenport, using the method of Vinogradov. The case when f was a 2-step nilsequence (such as the quadratic phase ")#mi("f(n) = e^{2\\pi i \\alpha n^2}")#text("; bracket quadratic phases such as ")#mi("f(n) = e^{2\\pi \\lfloor \\alpha n \\rfloor \\beta n}")#text(" can also be covered by an approximation argument, though the logarithmic decay in (1) is weakened as a consequence) was done ")#link("http://arxiv.org/abs/math.NT/0606087")[#text("by Ben and myself")]#text(" a few years ago, by a rather ")#emph[#text("ad hoc")]#text(" adaptation of Vinogradov’s method. By using the equidistribution theory of nilmanifolds, we were able to apply Vinogradov’s method more systematically, and in fact the proof is relatively short (20 pages), although it relies on the 64-page predecessor paper on equidistribution. I’ll talk a little bit more about the proof after the fold.")

#text("There is an amusing way to interpret the conjecture (using the close relationship between nilsequences and bracket polynomials) as an assertion of the pseudorandomness of the Liouville function from a computational complexity perspective. Suppose you possess a calculator with the wonderful property of being infinite precision: it can accept arbitrarily large real numbers as input, manipulate them precisely, and also store them in memory. However, this calculator has two limitations. Firstly, the only operations available are addition, subtraction, multiplication, integer part ")#mi("x \\mapsto [x]")#text(", fractional part ")#mi("x \\mapsto \\{x\\}")#text(", memory store (into one of O(1) registers), and memory recall (from one of these O(1) registers). In particular, there is no ability to perform division. Secondly, the calculator only has a finite display screen, and when it shows a real number, it only shows O(1) digits before and after the decimal point. (Thus, for instance, the real number 1234.56789 might be displayed only as ")#mi("\\ldots 34.56\\ldots")#text(".)")

#text("Now suppose you play the following game with an opponent.")

#enum(start: 1, 
[#text("The opponent specifies a large integer d.")],
[#text("You get to enter in O(1) real constants of your choice into your calculator. These can be absolute constants such as ")#mi("\\sqrt{2}")#text(" and ")#mi("\\pi")#text(", or they can depend on d (e.g. you can enter in ")#mi("10^{-d}")#text(").")],
[#text("The opponent randomly selects an d-digit integer n, and enters n into one of the registers of your calculator.")],
[#text("You are allowed to perform O(1) operations on your calculator and record what is displayed on the calculator’s viewscreen.")],
[#text("After this, you have to guess whether the opponent’s number n had an odd or even number of prime factors (i.e. you guess ")#mi("\\lambda(n)")#text(".)")],
[#text("If you guess correctly, you win $1; otherwise, you lose $1.")]
)

#text("For instance, using your calculator you can work out the first few digits of ")#mi("\\{ \\sqrt{2}n \\lfloor \\sqrt{3} n \\rfloor \\}")#text(", provided of course that you entered the constants ")#mi("\\sqrt{2}")#text(" and ")#mi("\\sqrt{3}")#text(" in advance. You can also work out the leading digits of n by storing ")#mi("10^{-d}")#text(" in advance, and computing the first few digits of ")#mi("10^{-d} n")#text(".")

#text("Our theorem is ")#emph[#text("equivalent")]#text(" to the assertion that as d goes to infinity (keeping the O(1) constants fixed), your probability of winning this game converges to 1/2; in other words, your calculator becomes asymptotically useless to you for the purposes of guessing whether n has an odd or even number of prime factors, and you may as well just guess randomly.")

#text("[I should mention a recent result in a similar spirit by Mauduit and Rivat; in this language, their result asserts that knowing the last few digits of the digit-sum of n does not increase your odds of guessing ")#mi("\\lambda(n)")#text(" correctly.]")

#metadata(none) <tao-6919777f282f9a70a52a>

#text("Now let me sketch the method of proof, which basically follows the Vinogradov (and Hardy-Littlewood) approach. First, we use a factorisation theorem in our equidistribution paper to prepare the nilsequence f(n) into what is basically one of two forms: either a periodic sequence (or something very close to a periodic sequence) or a totally equidistributed sequence. (Actually, it is possible to also be a hybrid of the two, in which the sequence foliates along dense arithmetic progressions into subsequences, each of which is totally equidistributed in its own nilmanifold, but let us ignore this technicality for simplicity.)")

#text("In the “major arc” case when the sequence f(n) is basically periodic, we can appeal to the prime number theorem in arithmetic progressions (or more precisely, the Siegel-Walfisz theorem, in order to get the right decay rate).")

#text("In the “minor arc” case when f(n) is equidistributed, we use the method of Type I and Type II sums. The basic idea here is to play off the multiplicative structure of the Möbius function ")#mi("\\mu(n)")#text(" against the additive structure (in this case, equidistribution) of the nilsequence ")#mi("f(n)")#text(". More precisely, we express ")#mi("\\mu(n)")#text(" as a divisor sum, for instance using the identity")

#align(center)[#tao-fit-display[#mitex("\\mu(n) = \\sum_{b,c: bc|n} \\mu(b) \\mu(c)")]]

#text("to rewrite sums such as ")#mi("\\sum_n \\mu(n) f(n)")#text(" in the form")

#align(center)[#tao-fit-display[#mitex("\\sum_b \\sum_c \\sum_d \\mu(b) \\mu(c) f(bcd)")]]

#text("(here we suppress the ranges of the variables n,b,c,d for sake of discussion). The philosophy here is that the arithmetic terms such as ")#mi("\\mu(b)")#text(" and ")#mi("\\mu(c)")#text(" are complicated and should be eliminated whenever possible (for instance, using the Cauchy-Schwarz inequality), whereas the dynamic term ")#mi("f(bcd)")#text(" is much easier to understand thanks to its equidistribution. Indeed, after performing various truncation tricks and Cauchy-Schwarz tricks, one can eliminate the number-theoretic terms from the above expressions, and upper bound their magnitude by a combination of Type I sums of the form")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\left|\\sum_m f(nm)\\right|", block: true)]]

#text("and Type II sums of the form")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\sum_{n^{\\prime}} \\left|\\sum_m f(nm) f(n^{\\prime}m)\\right|", block: true)]]

#text("where we again suppress the (important) technical details about what ranges the variables n, n’, m will be varying over. These sums can then be handled by the equidistribution assumption on f, the key lemma being (roughly speaking) that if a nilsequence ")#mi("n \\mapsto f(n)")#text(" is equidistributed then the dilates ")#mi("n \\mapsto f(mn)")#text(" will also be equidistributed for most m. (This is a quantitative and generalised variant of the obvious fact that if a number is irrational, then most integer multiples of that number will also be irrational.)")

#text("[")#emph[#text("Update")]#text(", July 20: Title of paper changed.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/065138e1b1902805d7f744a8b774918e0ccbb72d8c610f9cb5f0d04cde9795e3-c304526fcf69ae299ab157ae31b1f0cc68fc0ab5c24aaa809399deb8b52fce69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mats Granvik")]], [#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/#comment-31786")[#strong[#text("Mats Granvik")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2008")])]

#text("Dear Professor Terence Tao,")

#text("I have found that the n:th term of the möbius function can be calculated as a determinant of a modified nxn Redheffer Matrix where Redheffer Matrix(n,n) = 0. That is, the lower right corner is put to 0 in each nxn Redheffer Matrix.")

#text("References:")#linebreak()#text(" The On-Line Encyclopedia of Integer Sequences:")#linebreak()#text(" ")#link("http://www.research.att.com/~njas/sequences/A143104")[#text("http://www.research.att.com/~njas/sequences/A143104")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marker lectures II, “Linear equations in primes” « What’s new")]], [#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/#comment-33718")[#strong[#text("Marker lectures II, “Linear equations in primes” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2008")])]

#text("[…] enough for our purposes, and we had to develop a quantitative analogue of this theory; see these blog posts for more discussion. Anyway, it all works, and gives asymptotics for progressions of length […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/065138e1b1902805d7f744a8b774918e0ccbb72d8c610f9cb5f0d04cde9795e3-c304526fcf69ae299ab157ae31b1f0cc68fc0ab5c24aaa809399deb8b52fce69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mats Granvik")]], [#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/#comment-35193")[#strong[#text("Mats Granvik")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2009")])]

#text("It appears that if you move the element in the lower right corner of a triangular matrix to a position somewhere in the same column, then the determinant is the value at a corresponding position in the transposed matrix inverse of the number triangle.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/065138e1b1902805d7f744a8b774918e0ccbb72d8c610f9cb5f0d04cde9795e3-c304526fcf69ae299ab157ae31b1f0cc68fc0ab5c24aaa809399deb8b52fce69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mats Granvik")]], [#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/#comment-35196")[#strong[#text("Mats Granvik")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2009")])]

#text("Does not hold for all triangular matrices. The diagonal must probably consist of ones.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/065138e1b1902805d7f744a8b774918e0ccbb72d8c610f9cb5f0d04cde9795e3-c304526fcf69ae299ab157ae31b1f0cc68fc0ab5c24aaa809399deb8b52fce69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mats Granvik")]], [#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/#comment-50629")[#strong[#text("Mats Granvik")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2011")])]

#text("Dear readers of Terence Taos blog,")

#text("I made an attempt to write an expression in terms of Lambert series for the power series of the Mobius function. This is what I arrived at:")

#mi("\\sum \\limits_{n=1}^{\\infty} \\mu(n)x^n = x^1 - \\frac{x^{2}}{1-x^{1}} + \\sum \\limits_{a=2}^{\\infty} \\frac{x^{2a}}{1-x^{1a}} - \\sum \\limits_{b=2}^{\\infty} \\sum \\limits_{a=2}^{\\infty} \\frac{x^{2ab}}{1-x^{ab}} + \\sum \\limits_{c=2}^{\\infty} \\sum \\limits_{b=2}^{\\infty} \\sum \\limits_{a=2}^{\\infty} \\frac{x^{2abc}}{1-x^{abc}} - ...")

#text("I am unsure about the 5:th term.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://mobiusfunction.wordpress.com/2011/03/08/the-ordinary-generating-function-for-the-mobius-function/")[#text("The ordinary generating function for the Mobius function")]
]

#link("http://mobiusfunction.wordpress.com/2011/03/08/the-ordinary-generating-function-for-the-mobius-function/")[#text("Mobius function generating function")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/#comment-50673")[#strong[#text("The ordinary generating function for the Mobius function | The Mobius function Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2011")]

#text("[…] I also posted it here: Terence Taos blog […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Bourgain-Sarnak-Ziegler orthogonality criterion « What’s new")]], [#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/#comment-108779")[#strong[#text("The Bourgain-Sarnak-Ziegler orthogonality criterion « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2011")])]

#text("[…] also apply this criterion to nilsequences (obtaining a quick proof of a qualitative version of a result of Ben Green and myself) and to horocycle flows (for which no Möbius orthogonality result was previously […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 7: Sieving and expanders « What’s new")]], [#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/#comment-131023")[#strong[#text("254B, Notes 7: Sieving and expanders « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2012")])]

#text("[…] theorem handles infinite arithmetic progressions , and a somewhat complicated result of Green, Tao, and Ziegler handles “non-degenerate” affine lattices in of rank two or more (such as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Chowla conjecture and the Sarnak conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/#comment-182162")[#strong[#text("The Chowla conjecture and the Sarnak conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2012")])]

#text("[…] For nilsequences, this is a result of Ben Green and myself. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Concatenation theorems for anti-Gowers-uniform functions and Host-Kra characteristic factors; polynomial patterns in primes | What's new")]], [#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/#comment-467303")[#strong[#text("Concatenation theorems for anti-Gowers-uniform functions and Host-Kra characteristic factors; polynomial patterns in primes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2016")])]

#text("[…] such functions (thanks to results such as the proof of the inverse conjecture for the Gowers norms, the orthogonality of the Möbius function with nilsequences, and asymptotics for linear equations in primes), but much less control is currently available for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Odd order cases of of the logarithmically averaged Chowla conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/#comment-487026")[#strong[#text("Odd order cases of of the logarithmically averaged Chowla conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2017")])]

#text("[…] requires the Gowers uniformity of the (W-tricked) von Mangoldt function, established in several papers of Ben Green, Tamar Ziegler, and myself). The proof follows the lines sketched in the previous blog […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f449649ee72aacb2a1bebb13b00532f0d6edf19f93054a8f037494fefc9365f-e6eabfd6cf52e8405b36520df83897941bd673491e3a3b4800c445f3f22b1b7b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lionel")]], [#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/#comment-536263")[#strong[#text("Lionel")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2020")])]

#text("“the obvious fact that if a number is irrational, then most integer multiples of that number will also be irrational.” I guess there is something missing in this statement: all integer multiples of an irrational number are irrational.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/#comment-536363")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2020")])]

#text("That stronger statement is of course true, but it is the weaker statement that is being generalised here. From a quantitative viewpoint, in which one replaces “irrational” by “not well approximated by a rational of bounded denominator”, the “most multiples” statement is what extends, rather than the “all multiples” statement. For instance, if ")#mi("\\alpha")#text(" is the Liouville number ")#mi("\\sum_{n=1}^\\infty \\frac{1}{10^{n!}}")#text(", then ")#mi("\\alpha")#text(" is not too well approximated by rationals of bounded denominator, and the same is true for most of its multiples, but there are a few multiples such as ")#mi("10^{n!} \\alpha")#text(" that are unusually close to integers, and thus behave quantitatively like rationals even though they are technically irrational.")
]
]
