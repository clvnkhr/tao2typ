// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/08/10/alexandre-borovik-mathematics-under-arrest/
// Converted to Typst by tao2typ: "2026-10-14T15:16:27.225204+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "(Alexandre Borovik) Mathematics under arrest", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("(Alexandre Borovik) Mathematics under arrest")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 August 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/08/10/alexandre-borovik-mathematics-under-arrest/")[#text("https://terrytao.wordpress.com/2007/08/10/alexandre-borovik-mathematics-under-arrest/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("[")#emph[#text("This post is authored by ")#link("http://www.maths.manchester.ac.uk/~avb/")[#text("Alexandre Borovik")]]#text(". ")#emph[#text("An extended version of this post, with further links and background information, ")#link("http://www.maths.manchester.ac.uk/~avb/micromathematics/2007/08/blackboard-is-still-under-arrest.html")[#text("can be found on Alexandre’s blog")]]#text(".]")

#text("I had never in my life seen an ")#link("http://www.maths.manchester.ac.uk/%7Eavb/micromathematics/2007/08/blackboard-under-arrest.html")[#text("arrested blackboard encircled by a police tape")]#text(", still with some group theory problems on it.")

#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/www.maths.manchester.ac.uk/~avb/micromathematics/uploaded_images/ArrestedBlackboard-769044.jpg")[Original image]]]

#text("But this had actually happened when the ")#link("http://www.matematikdunyasi.org/yazokulu/yazokulu_duyuru.html")[#text("Turkish authorities closed")#linebreak()#text(" down the Mathematical Summer School")]#text(" run by ")#link("http://www.alinesin.org/")[#text("Ali Nesin ")]#text("for Turkish undergraduate students; Ali Nesin may face prosecution for an Orwellian offence of “")#strong[#text("education without permission")]#text("“. Please sign the ")#link("http://savesummerschool.blogspot.com/")[#text("online petition")]#text(" in his support.")#linebreak()#text(" ")#metadata(none) <tao-4ef2220076812f58e4f0>

#text("The bizarre nature of the incident inevitably requires some explanation.")#linebreak()#text(" The School is a continuation of Mathematical Summer Camps run by Ali")#linebreak()#text(" Nesin for many years. It provides high quality intensive courses in")#linebreak()#text(" topics more advanced than the usual undergraduate fare. I visited the")#linebreak()#text(" School and can attest to its highest quality – see my posts “")#link("http://www.maths.manchester.ac.uk/%7Eavb/micromathematics/2007/07/gold-sand-in-stream.html")[#text("Gold Sand in")#linebreak()#text(" a Stream")]#text("” and “")#link("http://www.maths.manchester.ac.uk/%7Eavb/micromathematics/2007/07/photos-from-mathematical-village_26.html")[#text("Photos from Mathematical Village")]#text("“.")

#text("However, local authorities were unhappy with Ali’s activities and")#linebreak()#text(" accused him of a number of alleged violations. But it appears that none")#linebreak()#text(" of the regulations allegedly breached provides a formal cause for")#linebreak()#text(" closing the school. This perhaps explains why the authorities decided to")#linebreak()#text(" invoke the charge of “education without permission”. It should be noted")#linebreak()#text(" at this point that")

#enum(start: 1, 
[#text("all students in the School are over 18;")],
[#text("the School does not award any degrees, diplomas, etc., and that its sole purpose is pure enjoyment of mathematics;")],
[#text("the School had financial support from ")#link("http://en.wikipedia.org/wiki/Scientific_and_Technological_Research_Council_of_Turkey")[#text("TUBITAK")]#text(" (the Turkish equivalent of the ")#link("http://en.wikipedia.org/wiki/National_Science_Foundation")[#text("NSF")]#text(" or ")#link("http://en.wikipedia.org/wiki/EPSRC")[#text("EPSRC")]#text(") and from some leading Turkish Universities;")],
[#text("Professor Ali Nesin is Chairman of the ")#link("http://www.math.bilgi.edu.tr/")[#text("Department of Mathematics ")]#text("in ")#link("http://international.bilgi.edu.tr/")[#text("Istanbul Bilgi University")]#text(", one of the best Universities in Turkey.")]
)

#text("Gendarmes put the tape around the blackboard on 31 July 2007. On 3")#linebreak()#text(" August 2007, a group of mathematicians ")#link("http://savesummerschool.blogspot.com/")[#text("sent a letter")]#text(" to the Prime Minister of Turkey asking him to stop the shameful prosecution; at the present moment, the Prime Minister’s office and the Governor of Ismir are involved in the dispute. However, this week Ali Nesin was summoned to the prosecutor’s office, where a state prosecutor accused him of ” founding an institution of education without permission” and of “educating without permission”. The situation is very fluid, and continuing support from the international mathematical community is of crucial importance.")

#text("Please support the noble cause of mathematics and ")#link("http://savesummerschool.blogspot.com/")[#text("sign the petition")]#text(".")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf445dd3ded972a5d1b62126dac2900bf47db6c85c39b95626f92b945e4f092-821d2a67ec2aa6fd2150e7112d80a9cf9bad4da7b90b8dab1f324d9a6a89f5c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2007/08/10/alexandre-borovik-mathematics-under-arrest/#comment-6270")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2007")])]

#text("I still urge people with better academic reputations than mine to sign the petition.")

#text("This differs, I believe, from tales of the Cold War, when men in Black would wheel blackboards out of lecture halls when the equations thereon were deemed too classified for the audience, or even for the author, to read.")

#text("There was a patent application I worked on with the late James B. Stephenson, on cryogenic stealthy satellite technology, which was whisked away as beyond our ability to read.")

#text("But education? “WE resent this question on the final exam you wrote. To the Gulag with you!”")

#text("“Hello, my name is Alexander Solzhenitsyn. Welcome to my research establishment, soon to be memorialized in the books whose working titles are The First Circle and Cancer Ward…")

#text("I find myself agreeing with my late colleague Prof. Timothy Leary, who asserted that the zeroth amendment to the Constitution should be Freedom of State of Consciousness, without which Freedom of Speech was moot.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/10/alexandre-borovik-mathematics-under-arrest/#comment-6291")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2007")]

#text("[…] (Alexandre Borovik) Mathematics under arrest [This post is authored by Alexandre Borovik. An extended version of this post, with further links and background […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/10/alexandre-borovik-mathematics-under-arrest/#comment-6422")[#strong[#text("stimulant » Blog Archive » things to look at (August 11th)")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2007")]

#text("[…] (Alexandre Borovik) Mathematics under arrest « What?s new – Oh god. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/10/alexandre-borovik-mathematics-under-arrest/#comment-25373")[#strong[#text("educating without permission « An Ergodic Walk")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2008")]

#text("[…] 2007 educating without permission Posted by asarwate under Math, News, Politics Via What’s New, I saw a story of how the Turkish government is trying to shut down a summer school for mathematics […]")
]
