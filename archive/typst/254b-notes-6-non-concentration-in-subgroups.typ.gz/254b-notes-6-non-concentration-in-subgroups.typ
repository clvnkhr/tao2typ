// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/02/13/254b-notes-6-non-concentration-in-subgroups/
// Converted to Typst by tao2typ: "2026-10-14T16:36:48.620528+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254B, Notes 6: Non-concentration in subgroups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254B, Notes 6: Non-concentration in subgroups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 February 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/02/13/254b-notes-6-non-concentration-in-subgroups/")[#text("https://terrytao.wordpress.com/2012/02/13/254b-notes-6-non-concentration-in-subgroups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the ")#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/")[#text("last")]#text(" ")#link("https://terrytao.wordpress.com/2012/01/13/254b-notes-4-the-bourgain-gamburd-expansion-machine/")[#text("three")]#text(" ")#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/")[#text("notes")]#text(", we discussed the Bourgain-Gamburd expansion machine and two of its three ingredients, namely quasirandomness and product theorems, leaving only the non-concentration ingredient to discuss. We can summarise the results of the last three notes, in the case of fields of prime order, as the following theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Non-concentration implies expansion in ")#mi("{SL_d}")#text(")")]#text(" ")#metadata(none) <tao-a9a5938e11812b3d57cb>#text(" Let ")#mi("{p}")#text(" be a prime, let ")#mi("{d \\geq 1}")#text(", and let ")#mi("{S}")#text(" be a symmetric set of elements in ")#mi("{G := SL_d(F_p)}")#text(" of cardinality ")#tao-math("{\\left|S\\right|=k}", block: false)#text(" not containing the identity. Write ")#tao-math("{\\mu := \\frac{1}{\\left|S\\right|} \\sum_{s\\in S}\\delta_s}", block: false)#text(", and suppose that one has the non-concentration property ")#metadata(none) <tao-4c47047f6297bbb78688>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\sup_{H < G}\\mu^{(n)}(H) < \\left|G\\right|^{-\\kappa}", block: true)]]

#text("for some ")#mi("{\\kappa>0}")#text(" and some even integer ")#tao-math("{n \\leq \\Lambda \\log \\left|G\\right|}", block: false)#text(". Then ")#mi("{Cay(G,S)}")#text(" is a two-sided ")#mi("{\\epsilon}")#text("-expander for some ")#mi("{\\epsilon>0}")#text(" depending only on ")#mi("{k, d, \\kappa,\\Lambda}")#text(".")
]

#emph[#text("Proof:")]#text(" From ")#link(<tao-4c47047f6297bbb78688>)[#text("(1)")]#text(" we see that ")#mi("{\\mu^{(n)}}")#text(" is not supported in any proper subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(", which implies that ")#mi("{S}")#text(" generates ")#mi("{G}")#text(". The claim now follows from the Bourgain-Gamburd expansion machine (Theorem 2 of ")#link("https://terrytao.wordpress.com/2012/01/13/254b-notes-4-the-bourgain-gamburd-expansion-machine/")[#text("Notes 4")]#text("), the product theorem (Theorem 1 of ")#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/")[#text("Notes 5")]#text("), and quasirandomness (Exercise 8 of ")#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/")[#text("Notes 3")]#text("). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The same argument also works if we replace ")#mi("{F_p}")#text(" by the field ")#mi("{F_{p^j}}")#text(" of order ")#mi("{p^j}")#text(" for some bounded ")#mi("{j}")#text(". However, there is a difficulty in the regime when ")#mi("{j}")#text(" is unbounded, because the quasirandomness property becomes too weak for the Bourgain-Gamburd expansion machine to be directly applicable. On theother hand, the above type of theorem was generalised to the setting of cyclic groups ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(" with ")#mi("{q}")#text(" square-free ")#link("http://arxiv.org/abs/1001.3664")[#text("by Varju")]#text(", to arbitrary ")#mi("{q}")#text(" ")#link("http://arxiv.org/abs/1006.3365")[#text("by Bourgain and Varju")]#text(", and to more general algebraic groups than ")#mi("{SL_d}")#text(" and square-free ")#mi("{q}")#text(" ")#link("http://arxiv.org/abs/1108.4900")[#text("by Salehi Golsefidy and Varju")]#text(". It may be that some modification of the proof techniques in these papers may also be able to handle the field case ")#mi("{F_{p^j}}")#text(" with unbounded ")#mi("{j}")#text(".")
]

#text("It thus remains to construct tools that can establish the non-concentration property ")#link(<tao-4c47047f6297bbb78688>)[#text("(1)")]#text(". The situation is particularly simple in ")#mi("{SL_2(F_p)}")#text(", as we have a good understanding of the subgroups of that group. Indeed, from Theorem 14 from ")#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/")[#text("Notes 5")]#text(", we obtain the following corollary to Theorem ")#link(<tao-a9a5938e11812b3d57cb>)[#text("1")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2 (Non-concentration implies expansion in ")#mi("{SL_2}")#text(")")]#text(" ")#metadata(none) <tao-d2332112c1e921f8add1>#text(" Let ")#mi("{p}")#text(" be a prime, and let ")#mi("{S}")#text(" be a symmetric set of elements in ")#mi("{G := SL_2(F_p)}")#text(" of cardinality ")#tao-math("{\\left|S\\right|=k}", block: false)#text(" not containing the identity. Write ")#tao-math("{\\mu := \\frac{1}{\\left|S\\right|} \\sum_{s\\in S}\\delta_s}", block: false)#text(", and suppose that one has the non-concentration property ")#metadata(none) <tao-1d66df321d1eebc0cd8e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\sup_{B}\\mu^{(n)}(B) < \\left|G\\right|^{-\\kappa}", block: true)]]

#text("for some ")#mi("{\\kappa>0}")#text(" and some even integer ")#tao-math("{n \\leq \\Lambda \\log \\left|G\\right|}", block: false)#text(", where ")#mi("{B}")#text(" ranges over all Borel subgroups of ")#mi("{SL_2(\\overline{F})}")#text(". Then, if ")#tao-math("{\\left|G\\right|}", block: false)#text(" is sufficiently large depending on ")#mi("{k,\\kappa,\\Lambda}")#text(", ")#mi("{Cay(G,S)}")#text(" is a two-sided ")#mi("{\\epsilon}")#text("-expander for some ")#mi("{\\epsilon>0}")#text(" depending only on ")#mi("{k, \\kappa,\\Lambda}")#text(".")
]

#text("It turns out ")#link(<tao-1d66df321d1eebc0cd8e>)[#text("(2)")]#text(" can be verified in many cases by exploiting the solvable nature of the Borel subgroups ")#mi("{B}")#text(". We give two examples of this in these notes. The first result, ")#link("http://www.ams.org/mathscinet-getitem?mr=2415383")[#text("due to Bourgain and Gamburd")]#text(" (with earlier partial results ")#link("http://www.ams.org/mathscinet-getitem?mr=1900698")[#text("by Gamburd")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1645694")[#text("by Shalom")]#text(") generalises Selberg’s expander construction to the case when ")#mi("{S}")#text(" generates a thin subgroup of ")#mi("{SL_2({\\bf Z})}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Expansion in thin subgroups)")]#text(" ")#metadata(none) <tao-afebcf727f4e03cbc2b1>#text(" Let ")#mi("{S}")#text(" be a symmetric subset of ")#mi("{SL_2({\\bf Z})}")#text(" not containing the identity, and suppose that the group ")#mi("{\\langle S \\rangle}")#text(" generated by ")#mi("{S}")#text(" is not ")#link("http://en.wikipedia.org/wiki/Solvable_group#Virtually_solvable_groups")[#text("virtually solvable")]#text(". Then as ")#mi("{p}")#text(" ranges over all sufficiently large primes, the Cayley graphs ")#mi("{Cay(SL_2(F_p), \\pi_p(S))}")#text(" form a two-sided expander family, where ")#mi("{\\pi_p: SL_2({\\bf Z}) \\rightarrow SL_2(F_p)}")#text(" is the usual projection.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One corollary of Theorem ")#link(<tao-afebcf727f4e03cbc2b1>)[#text("3")]#text(" (or of the non-concentration estimate ")#link(<tao-8c9afacfdf527a1e867f>)[#text("(3)")]#text(" below) is that ")#mi("{\\pi_p(S)}")#text(" generates ")#mi("{SL_2(F_p)}")#text(" for all sufficiently large ")#mi("{p}")#text(", if ")#mi("{\\langle S \\rangle}")#text(" is not virtually solvable. This is a special case of a much more general result, known as the ")#link("http://en.wikipedia.org/wiki/Approximation_in_algebraic_groups")[#text("strong approximation theorem")]#text(", although this is certainly not the most direct way to prove such a theorem. Conversely, the strong approximation property is used in generalisations of this result to higher rank groups than ")#mi("{SL_2}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" In the converse direction, if ")#mi("{\\langle S\\rangle}")#text(" is virtually solvable, show that for sufficiently large ")#mi("{p}")#text(", ")#mi("{\\pi_p(S)}")#text(" fails to generate ")#mi("{SL_2(F_p)}")#text(". (")#emph[#text("Hint:")]#text(" use Theorem 14 from ")#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/")[#text("Notes 5")]#text(" to prevent ")#mi("{SL_2(F_p)}")#text(" from having bounded index solvable subgroups.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2 (Lubotzsky’s 1-2-3 problem)")]#text(" Let ")#mi("{S := \\{ \\begin{pmatrix}1 & \\pm 3 \\\\ 0 & 1 \\end{pmatrix}, \\begin{pmatrix}1 & 0 \\\\ \\pm 3 & 1 \\end{pmatrix}}")#text(".")

#list(
[#text("(i) Show that ")#mi("{S}")#text(" generates a free subgroup of ")#mi("{SL_2({\\bf Z})}")#text(". (")#emph[#text("Hint:")]#text(" use a ping-pong argument, as in Exercise 23 of ")#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/")[#text("Notes 2")]#text(".)")],
[#text("(ii) Show that if ")#mi("{v, w}")#text(" are two distinct elements of the sector ")#mi("{\\{ (x,y) \\in {\\bf R}^2_+: x/2 < y < 2x \\}}")#text(", then there os no element ")#mi("{g \\in \\langle S \\rangle}")#text(" for which ")#mi("{gv = w}")#text(". (")#emph[#text("Hint:")]#text(" this is another ping-pong argument.) Conclude that ")#mi("{\\langle S \\rangle}")#text(" has infinite index in ")#mi("{SL_2({\\bf Z})}")#text(". (Contrast this with the situation in which the ")#mi("{3}")#text(" coefficients in ")#mi("{S}")#text(" are replaced by ")#mi("{1}")#text(" or ")#mi("{2}")#text(", in which case ")#mi("{\\langle S \\rangle}")#text(" is either all of ")#mi("{SL_2({\\bf Z})}")#text(", or a finite index subgroup, as demonstrated in Exercise 23 of ")#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/")[#text("Notes 2")]#text(").")],
[#text("(iii) Show that ")#mi("{Cay(SL_2(F_p), \\pi_p(S))}")#text(" for sufficiently large primes ")#mi("{p}")#text(" form a two-sided expander family.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" Theorem ")#link(<tao-afebcf727f4e03cbc2b1>)[#text("3")]#text(" has been generalised to arbitrary linear groups, and with ")#mi("{F_p}")#text(" replaced by ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(" for square-free ")#mi("{q}")#text("; see ")#link("http://arxiv.org/abs/1108.4900")[#text("this paper of Salehi Golsefidy and Varju")]#text(". In this more general setting, the condition of virtual solvability must be replaced by the condition that the connected component of the Zariski closure of ")#mi("{\\langle S \\rangle}")#text(" is ")#link("http://en.wikipedia.org/wiki/Perfect_group")[#text("perfect")]#text(". An effective version of Theorem ")#link(<tao-afebcf727f4e03cbc2b1>)[#text("3")]#text(" (with completely explicit constants) was recently obtained ")#link("http://arxiv.org/abs/1201.1139")[#text("by Kowalski")]#text(".")
]

#text("The second example concerns Cayley graphs constructed using random elements of ")#mi("{SL_2(F_p)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Random generators expand)")]#text(" ")#metadata(none) <tao-24c5de81702a61becdbb>#text(" Let ")#mi("{p}")#text(" be a prime, and let ")#mi("{x,y}")#text(" be two elements of ")#mi("{SL_2(F_p)}")#text(" chosen uniformly at random. Then with probability ")#mi("{1-o_{p \\rightarrow \\infty}(1)}")#text(", ")#mi("{Cay(SL_2(F_p), \\{x,x^{-1},y,y^{-1}\\})}")#text(" is a two-sided ")#mi("{\\epsilon}")#text("-expander for some absolute constant ")#mi("{\\epsilon}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" As with Theorem ")#link(<tao-afebcf727f4e03cbc2b1>)[#text("3")]#text(", Theorem ")#link(<tao-24c5de81702a61becdbb>)[#text("4")]#text(" has also been extended to a number of other groups, such as the Suzuki groups (in ")#link("http://arxiv.org/abs/1005.0782")[#text("this paper of Breuillard, Green, and Tao")]#text("), and more generally to finite simple groups of Lie type of bounded rank (in forthcoming work of Breuillard, Green, Guralnick, and Tao). There are a number of other constructions of expanding Cayley graphs in such groups (and in other interesting groups, such as the alternating groups) beyond those discussed in these notes; see ")#link("http://arxiv.org/abs/1105.2389")[#text("this recent survey of Lubotzky")]#text(" for further discussion. It has been conjectured ")#link("http://www.ams.org/mathscinet-getitem?mr=1235570")[#text("by Lubotzky and Weiss")]#text(" that ")#emph[#text("any")]#text(" pair ")#mi("{x,y}")#text(" of (say) ")#mi("{SL_2(F_p)}")#text(" that generates the group, is a two-sided ")#mi("{\\epsilon}")#text("-expander for an absolute constant ")#mi("{\\epsilon}")#text(": in the case of ")#mi("{SL_2(F_p)}")#text(", this has been established for a density one set of primes ")#link("http://www.ams.org/mathscinet-getitem?mr=2746951")[#text("by Breuillard and Gamburd")]#text(".")
]

#heading(level: 1)[#strong[#text(" — 1. Expansion in thin subgroups — ")]]

#text("We now prove Theorem ")#link(<tao-afebcf727f4e03cbc2b1>)[#text("3")]#text(". The first observation is that the expansion property is monotone in the group ")#mi("{\\langle S \\rangle}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Let ")#mi("{S, S^{\\prime}}")#text(" be symmetric subsets of ")#mi("{SL_2({\\bf Z})}")#text(" not containing the identity, such that ")#mi("{\\langle S \\rangle \\subset \\langle S^{\\prime} \\rangle}")#text(". Suppose that ")#mi("{Cay(SL_2(F_p), \\pi_p(S))}")#text(" is a two-sided expander family for sufficiently large primes ")#mi("{p}")#text(". Show that ")#mi("{Cay(SL_2(F_p), \\pi_p(S^{\\prime}))}")#text(" is also a two-sided expander family.")
]

#text("As a consequence, Theorem ")#link(<tao-afebcf727f4e03cbc2b1>)[#text("3")]#text(" follows from the following two statments:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Tits alternative)")]#text(" ")#metadata(none) <tao-13a465fc6616da8d2afa>#text(" Let ")#mi("{\\Gamma \\subset SL_2({\\bf Z})}")#text(" be a group. Then exactly one of the following statements holds:")

#list(
[#text("(i) ")#mi("{\\Gamma}")#text(" is virtually solvable.")],
[#text("(ii) ")#mi("{\\Gamma}")#text(" contains a copy of the free group ")#mi("{F_2}")#text(" of two generators as a subgroup.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Expansion in free groups)")]#text(" ")#metadata(none) <tao-d78de925a87867319201>#text(" Let ")#mi("{x,y \\in SL_2({\\bf Z})}")#text(" be generators of a free subgroup of ")#mi("{SL_2({\\bf Z})}")#text(". Then as ")#mi("{p}")#text(" ranges over all sufficiently large primes, the Cayley graphs ")#mi("{Cay(SL_2(F_p), \\pi_p(\\{x,y,x^{-1},y^{-1}\\}))}")#text(" form a two-sided expander family.")
]

#text("Theorem ")#link(<tao-13a465fc6616da8d2afa>)[#text("5")]#text(" is a special case of the famous ")#link("http://en.wikipedia.org/wiki/Tits_alternative")[#text("Tits alternative")]#text(", which among other things allows one to replace ")#mi("{SL_2({\\bf Z})}")#text(" by ")#mi("{GL_d(k)}")#text(" for any ")#mi("{d \\geq 1}")#text(" and any field ")#mi("{k}")#text(" of characteristic zero (and fields of positive characteristic are also allowed, if one adds the requirement that ")#mi("{\\Gamma}")#text(" be finitely generated). We will not prove the full Tits alternative here, but instead just give an ")#emph[#text("ad hoc")]#text(" proof of the special case in Theorem ")#link(<tao-13a465fc6616da8d2afa>)[#text("5")]#text(" in the following exercise.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Given any matrix ")#mi("{g \\in SL_2({\\bf Z})}")#text(", the singular values are ")#tao-math("{\\left\\|g\\right\\|_{op}}", block: false)#text(" and ")#tao-math("{\\left\\|g\\right\\|_{op}^{-1}}", block: false)#text(", and we can apply the singular value decomposition to decompose")

#align(center)[#tao-fit-display[#tao-math("g = u_1(g) \\left\\|g\\right\\|_{op} v_1^*(g) + u_2(g) \\left\\|g\\right\\|_{op}^{-1} v_2(g)^*", block: true)]]

#text("where ")#mi("{u_1(g),u_2(g)\\in {\\bf C}^2}")#text(" and ")#mi("{v_1(g), v_2(g) \\in {\\bf C}^2}")#text(" are orthonormal bases. (When ")#tao-math("{\\left\\|g\\right\\|_{op}>1}", block: false)#text(", these bases are uniquely determined up to phase rotation.) We let ")#mi("{\\tilde u_1(g) \\in {\\bf CP}^1}")#text(" be the projection of ")#mi("{u_1(g)}")#text(" to the projective complex plane, and similarly define ")#mi("{\\tilde v_2(g)}")#text(".")

#text("Let ")#mi("{\\Gamma}")#text(" be a subgroup of ")#mi("{SL_2({\\bf Z})}")#text(". Call a pair ")#mi("{(u,v) \\in {\\bf CP}^1 \\times {\\bf CP}^1}")#text(" a ")#emph[#text("limit point")]#text(" of ")#mi("{\\Gamma}")#text(" if there exists a sequence ")#mi("{g_n \\in \\Gamma}")#text(" with ")#tao-math("{\\left\\|g_n\\right\\|_{op} \\rightarrow \\infty}", block: false)#text(" and ")#mi("{(\\tilde u_1(g_n), \\tilde v_2(g_n)) \\rightarrow (u,v)}")#text(".")

#list(
[#text("(i) Show that if ")#mi("{\\Gamma}")#text(" is infinite, then there is at least one limit point.")],
[#text("(ii) Show that if ")#mi("{(u,v)}")#text(" is a limit point, then so is ")#mi("{(v,u)}")#text(".")],
[#text("(iii) Show that if there are two limit points ")#mi("{(u,v), (u^{\\prime},v^{\\prime})}")#text(" with ")#mi("{\\{u,v\\} \\cap \\{u^{\\prime},v^{\\prime}\\} = \\emptyset}")#text(", then there exist ")#mi("{g,h \\in \\Gamma}")#text(" that generate a free group. (")#emph[#text("Hint:")]#text(" Choose ")#mi("{(\\tilde u_1(g), \\tilde v_2(g))}")#text(" close to ")#mi("{(u,v)}")#text(" and ")#mi("{(\\tilde u_1(h),\\tilde v_2(h))}")#text(" close to ")#mi("{(u^{\\prime},v^{\\prime})}")#text(", and consider the action of ")#mi("{g}")#text(" and ")#mi("{h}")#text(" on ")#mi("{{\\bf CP}^1}")#text(", and specifically on small neighbourhoods of ")#mi("{u,v,u^{\\prime},v^{\\prime}}")#text(", and set up a ping-pong type situation.)")],
[#text("(iv) Show that if ")#mi("{g \\in SL_2({\\bf Z})}")#text(" is hyperbolic (i.e. it has an eigenvalue greater than 1), with eigenvectors ")#mi("{u,v}")#text(", then the projectivisations ")#mi("{(\\tilde u,\\tilde v)}")#text(" of ")#mi("{u,v}")#text(" form a limit point. Similarly, if ")#mi("{g}")#text(" is regular parabolic (i.e. it has an eigenvalue at 1, but is not the identity) with eigenvector ")#mi("{u}")#text(", show that ")#mi("{(\\tilde u,\\tilde bu)}")#text(" is a limit point.")],
[#text("(v) Show that if ")#mi("{\\Gamma}")#text(" has no free subgroup of two generators, then all hyperbolic and regular parabolic elements of ")#mi("{\\Gamma}")#text(" have a common eigenvector. Conclude that all such elements lie in a solvable subgroup of ")#mi("{\\Gamma}")#text(".")],
[#text("(vi) Show that if an element ")#mi("{g \\in SL_2({\\bf Z})}")#text(" is neither hyperbolic nor regular parabolic, and is not a multiple of the identity, then ")#mi("{g}")#text(" is conjugate to a rotation by ")#mi("{\\pi/2}")#text(" (in particular, ")#mi("{g^2=-1}")#text(").")],
[#text("(vii) Establish Theorem ")#link(<tao-13a465fc6616da8d2afa>)[#text("5")]#text(". (")#emph[#text("Hint:")]#text(" show that two square roots of ")#mi("{-1}")#text(" in ")#mi("{SL_2({\\bf Z})}")#text(" cannot multiply to another square root of ")#mi("{-1}")#text(".)")]
)
]

#text("Now we prove Theorem ")#link(<tao-d78de925a87867319201>)[#text("6")]#text(". Let ")#mi("{\\Gamma}")#text(" be a free subgroup of ")#mi("{SL_2({\\bf Z})}")#text(" generated by two generators ")#mi("{x,y}")#text(". Let ")#mi("{\\mu := \\frac{1}{4} (\\delta_x +\\delta_{x^{-1}} + \\delta_y + \\delta_{y^{-1}})}")#text(" be the probability measure generating a random walk on ")#mi("{SL_2({\\bf Z})}")#text(", thus ")#mi("{(\\pi_p)_* \\mu}")#text(" is the corresponding generator on ")#mi("{SL_2(F_p)}")#text(". By Corollary ")#link(<tao-d2332112c1e921f8add1>)[#text("2")]#text(", it thus suffices to show that ")#metadata(none) <tao-8c9afacfdf527a1e867f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sup_{B}((\\pi_p)_* \\mu)^{(n)}(B) < p^{-\\kappa}")]]

#text("for all sufficiently large ")#mi("{p}")#text(", some absolute constant ")#mi("{\\kappa>0}")#text(", and some even ")#mi("{n = O(\\log p)}")#text(" (depending on ")#mi("{p}")#text(", of course), where ")#mi("{B}")#text(" ranges over Borel subgroups.")

#text("As ")#mi("{\\pi_p}")#text(" is a homomorphism, one has ")#mi("{((\\pi_p)_* \\mu)^{(n)}(B) = (\\pi_p)_* (\\mu^{(n)})(B) = \\mu^{(n)}(\\pi_p^{-1}(B))}")#text(" and so it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sup_{B} \\mu^{(n)}(\\pi_p^{-1}(B)) < p^{-\\kappa}.")]]

#text("To deal with the supremum here, we will use an argument ")#link("http://www.ams.org/mathscinet-getitem?mr=2415383")[#text("of Bourgain and Gamburd")]#text(", taking advantage of the fact that all Borel groups of ")#mi("{SL_2}")#text(" obey a common group law, the point being that free groups such as ")#mi("{\\Gamma}")#text(" obey such laws only very rarely. More precisely, we use the fact that the Borel groups are solvable of derived length two; in particular we have ")#metadata(none) <tao-d391f11b3b9f8ced025d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("[[a,b],[c,d]] = 1")]]

#text("for all ")#mi("{a,b,c,d \\in B}")#text(". Now, ")#mi("{\\mu^{(n)}}")#text(" is supported on matrices in ")#mi("{SL_2({\\bf Z})}")#text(" whose coefficients have size ")#mi("{O(\\exp(O(n)))}")#text(" (where we allow the implied constants to depend on the choice of generators ")#mi("{x,y}")#text("), and so ")#mi("{(\\pi_p)_*( \\mu^{(n)} )}")#text(" is supported on matrices in ")#mi("{SL_2(F_p)}")#text(" whose coefficients also have size ")#mi("{O(\\exp(O(n)))}")#text(". If ")#mi("{n}")#text(" is less than a sufficiently small multiple of ")#mi("{\\log p}")#text(", these coefficients are then less than ")#mi("{p^{1/10}}")#text(" (say). As such, if ")#mi("{\\tilde a,\\tilde b,\\tilde c,\\tilde d \\in SL_2({\\bf Z})}")#text(" lie in the support of ")#mi("{\\mu^{(n)}}")#text(" and their projections ")#mi("{a = \\pi_p(\\tilde a), \\ldots, d = \\pi_p(\\tilde d)}")#text(" obey the word law ")#link(<tao-d391f11b3b9f8ced025d>)[#text("(4)")]#text(" in ")#mi("{SL_2(F_p)}")#text(", then the original matrices ")#mi("{\\tilde a, \\tilde b, \\tilde c, \\tilde d}")#text(" obey the word law ")#link(<tao-d391f11b3b9f8ced025d>)[#text("(4)")]#text(" in ")#mi("{SL_2({\\bf Z})}")#text(". (This lifting of identities from the characteristic ")#mi("{p}")#text(" setting of ")#mi("{SL_2(F_p)}")#text(" to the characteristic ")#mi("{0}")#text(" setting of ")#mi("{SL_2({\\bf Z})}")#text(" is a simple example of the “Lefschetz principle”.)")

#text("To summarise, if we let ")#mi("{E_{n,p,B}}")#text(" be the set of all elements of ")#mi("{\\pi_p^{-1}(B)}")#text(" that lie in the support of ")#mi("{\\mu^{(n)}}")#text(", then ")#link(<tao-d391f11b3b9f8ced025d>)[#text("(4)")]#text(" holds for all ")#mi("{a,b,c,d \\in E_{n,p,B}}")#text(". This severely limits the size of ")#mi("{E_{n,p,B}}")#text(" to only be of polynomial size, rather than exponential size:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7")]#text(" ")#metadata(none) <tao-05ec7ecbd2c50a1f0c60>#text(" Let ")#mi("{E}")#text(" be a subset of the support of ")#mi("{\\mu^{(n)}}")#text(" (thus, ")#mi("{E}")#text(" consists of words in ")#mi("{x,y,x^{-1},y^{-1}}")#text(" of length ")#mi("{n}")#text(") such that the law ")#link(<tao-d391f11b3b9f8ced025d>)[#text("(4)")]#text(" holds for all ")#mi("{a,b,c,d \\in E}")#text(". Then ")#tao-math("{\\left|E\\right| \\ll n^2}", block: false)#text(".")
]

#text("The proof of this proposition is laid out in the exercise below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Let ")#mi("{\\Gamma}")#text(" be a free group generated by two generators ")#mi("{x,y}")#text(". Let ")#mi("{B}")#text(" be the set of all words of length at most ")#mi("{n}")#text(" in ")#mi("{x,y,x^{-1},y^{-1}}")#text(".")

#list(
[#text("(i) Show that if ")#mi("{a,b \\in \\Gamma}")#text(" commute, then ")#mi("{a, b}")#text(" lie in the same cyclic group, thus ")#mi("{a = c^i, b = c^j}")#text(" for some ")#mi("{c \\in \\Gamma}")#text(" and ")#mi("{i,j \\in {\\bf Z}}")#text(".")],
[#text("(ii) Show that if ")#mi("{a \\in \\Gamma}")#text(", there are at most ")#mi("{O(n)}")#text(" elements of ")#mi("{B}")#text(" that commute with ")#mi("{a}")#text(".")],
[#text("(iii) Show that if ")#mi("{a,c \\in \\Gamma}")#text(", there are at most ")#mi("{O(n)}")#text(" elements ")#mi("{b}")#text(" of ")#mi("{B}")#text(" with ")#mi("{[a,b] = c}")#text(".")],
[#text("(iv) Prove Proposition ")#link(<tao-05ec7ecbd2c50a1f0c60>)[#text("7")]#text(".")]
)
]

#text("Now we can conclude the proof of Theorem ")#link(<tao-afebcf727f4e03cbc2b1>)[#text("3")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" ")#metadata(none) <tao-82f1af9e9d862b7ddd97>#text(" Let ")#mi("{\\Gamma}")#text(" be a free group generated by two generators ")#mi("{x,y}")#text(".")

#list(
[#text("(i) Show that ")#tao-math("{\\left\\| \\mu^{(n)} \\right\\|_{\\ell^\\infty(\\Gamma)} \\ll c^n}", block: false)#text(" for some absolute constant ")#mi("{0 < c<1}")#text(". (For much more precise information on ")#mi("{\\mu^{(n)}}")#text(", see ")#link("http://www.ams.org/mathscinet-getitem?mr=109367")[#text("this paper of Kesten")]#text(".)")],
[#text("(ii) Conclude the proof of Theorem ")#link(<tao-afebcf727f4e03cbc2b1>)[#text("3")]#text(".")]
)
]

#heading(level: 1)[#strong[#text(" — 2. Random generators expand — ")]]

#text("We now prove Theorem ")#link(<tao-24c5de81702a61becdbb>)[#text("4")]#text(". Let ")#mi("{{\\bf F}_2}")#text(" be the free group on two formal generators ")#mi("{a,b}")#text(", and let ")#mi("{\\mu := \\frac{1}{4}(\\delta_a + \\delta_b + \\delta_{a^{-1}}+ \\delta_{b^{-1}}}")#text(" be the generator of the random walk. For any word ")#mi("{w \\in {\\bf F}_2}")#text(" and any ")#mi("{x,y}")#text(" in a group ")#mi("{G}")#text(", let ")#mi("{w(x,y) \\in G}")#text(" be the element of ")#mi("{G}")#text(" formed by substituting ")#mi("{x,y}")#text(" for ")#mi("{a,b}")#text(" respectively in the word ")#mi("{w}")#text("; thus ")#mi("{w}")#text(" can be viewed as a map ")#mi("{w: G \\times G \\rightarrow G}")#text(" for any group ")#mi("{G}")#text(". Observe that if ")#mi("{w}")#text(" is drawn randomly using the distribution ")#mi("{\\mu^{(n)}}")#text(", and ")#mi("{x,y \\in SL_2(F_p)}")#text(", then ")#mi("{w(x,y)}")#text(" is distributed according to the law ")#mi("{\\tilde \\mu^{(n)}}")#text(", where ")#mi("{\\tilde \\mu := \\frac{1}{4}(\\delta_x + \\delta_y + \\delta_{x^{-1}}+ \\delta_{y^{-1}})}")#text(". Applying Corollary ")#link(<tao-d2332112c1e921f8add1>)[#text("2")]#text(", it suffices to show that whenever ")#mi("{p}")#text(" is a large prime and ")#mi("{x,y}")#text(" are chosen uniformly and independently at random from ")#mi("{SL_2(F_p)}")#text(", that with probability ")#mi("{1-o_{p \\rightarrow \\infty}(1)}")#text(", one has ")#metadata(none) <tao-7c2ecd07f155648431e0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sup_B {\\bf P}_w ( w(x,y) \\in B ) \\leq p^{-\\kappa}")]]

#text("for some absolute constant ")#mi("{\\kappa}")#text(", where ")#mi("{B}")#text(" ranges over all Borel subgroups of ")#mi("{SL_2(\\overline{F_p})}")#text(" and ")#mi("{w}")#text(" is drawn from the law ")#mi("{\\mu^{(n)}}")#text(" for some even natural number ")#mi("{n = O(\\log p)}")#text(".")

#text("Let ")#mi("{B_n}")#text(" denote the words in ")#mi("{{\\bf F}_2}")#text(" of length at most ")#mi("{n}")#text(". We may use the law ")#link(<tao-d391f11b3b9f8ced025d>)[#text("(4)")]#text(" to obtain good bound on the supremum in ")#link(<tao-7c2ecd07f155648431e0>)[#text("(5)")]#text(" assuming a certain non-degeneracy property of the word evaluations ")#mi("{w(x,y)}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Let ")#mi("{n}")#text(" be a natural number, and suppose that ")#mi("{x,y \\in SL_2(F_p)}")#text(" is such that ")#mi("{w(x,y) \\neq 1}")#text(" for ")#mi("{w \\in B_{100n} \\backslash \\{1\\}}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("\\sup_B {\\bf P}_w ( w(x,y) \\in B ) \\ll \\exp(-cn)")]]

#text("for some absolute constant ")#mi("{c>0}")#text(", where ")#mi("{w}")#text(" is drawn from the law ")#mi("{\\mu^{(n)}}")#text(". (")#emph[#text("Hint:")]#text(" use ")#link(<tao-d391f11b3b9f8ced025d>)[#text("(4)")]#text(" and the hypothesis to lift the problem up to ")#mi("{{\\bf F}_2}")#text(", at which point one can use Proposition ")#link(<tao-05ec7ecbd2c50a1f0c60>)[#text("7")]#text(" and Exercise ")#link(<tao-82f1af9e9d862b7ddd97>)[#text("6")]#text(".)")
]

#text("In view of this exercise, it suffices to show that with probability ")#mi("{1-o_{p \\rightarrow\\infty}(1)}")#text(", one has ")#mi("{w(x,y) \\neq 1}")#text(" for all ")#mi("{w \\in B_{100n} \\backslash \\{1\\}}")#text(" for some ")#mi("{n}")#text(" comparable to a small multiple of ")#mi("{\\log p}")#text(". As ")#mi("{B_{100n}}")#text(" has ")#mi("{\\exp(O(n))}")#text(" elements, it thus suffices by the union bound to show that ")#metadata(none) <tao-4ade97dda67d9671232b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("{\\bf P}_{x,y}(w(x,y)=1) \\leq p^{-\\gamma}")]]

#text("for some absolute constant ")#mi("{\\gamma > 0}")#text(", and any ")#mi("{w \\in {\\bf F}_2 \\backslash \\{1\\}}")#text(" of length less than ")#mi("{c\\log p}")#text(" for some sufficiently small absolute constant ")#mi("{c>0}")#text(".")

#text("Let us now fix a non-identity word ")#mi("{w}")#text(" of length ")#tao-math("{\\left|w\\right|}", block: false)#text(" less than ")#mi("{c\\log p}")#text(", and consider ")#mi("{w}")#text(" as a function from ")#mi("{SL_2(k) \\times SL_2(k)}")#text(" to ")#mi("{SL_2(k)}")#text(" for an arbitrary field ")#mi("{k}")#text(". We can identify ")#mi("{SL_2(k)}")#text(" with the set ")#mi("{\\{ (a,b,c,d)\\in k^4: ad-bc=1\\}}")#text(". A routine induction then shows that the expression ")#mi("{w((a,b,c,d),(a^{\\prime},b^{\\prime},c^{\\prime},d^{\\prime}))}")#text(" is then a polynomial in the eight variables ")#mi("{a,b,c,d,a^{\\prime},b^{\\prime},c^{\\prime},d^{\\prime}}")#text(" of degree ")#tao-math("{O(\\left|w\\right|)}", block: false)#text(" and coefficients which are integers of size ")#tao-math("{O( \\exp( O(\\left|w\\right|) ) )}", block: false)#text(". Let us then make the additional restriction to the case ")#mi("{a,a^{\\prime} \\neq 0}")#text(", in which case we can write ")#mi("{d = \\frac{bc+1}{a}}")#text(" and ")#mi("{d^{\\prime} =\\frac{b^{\\prime}c^{\\prime}+1}{a^{\\prime}}}")#text(". Then ")#mi("{w((a,b,c,d),(a^{\\prime},b^{\\prime},c^{\\prime},d^{\\prime}))}")#text(" is now a rational function of ")#mi("{a,b,c,a^{\\prime},b^{\\prime},c^{\\prime}}")#text(" whose numerator is a polynomial of degree ")#tao-math("{O(\\left|w\\right|)}", block: false)#text(" and coefficients of size ")#tao-math("{O( \\exp( O(\\left|w\\right|) ) )}", block: false)#text(", and the denominator is a monomial of ")#mi("{a,a^{\\prime}}")#text(" of degree ")#tao-math("{O(\\left|w\\right|)}", block: false)#text(".")

#text("We then specialise this rational function to the field ")#mi("{k=F_p}")#text(". It is conceivable that when one does so, the rational function collapses to the constant polynomial ")#mi("{(1,0,0,1)}")#text(", thus ")#mi("{w((a,b,c,d),(a^{\\prime},b^{\\prime},c^{\\prime},d^{\\prime}))=1}")#text(" for all ")#mi("{(a,b,c,d),(a^{\\prime},b^{\\prime},c^{\\prime},d^{\\prime}) \\in SL_2(F_p)}")#text(" with ")#mi("{a,a^{\\prime} \\neq 0}")#text(". (For instance, this would be the case if ")#tao-math("{w(x,y) = x^{\\left|SL_2(F_p)\\right|}}", block: false)#text(", by ")#link("http://en.wikipedia.org/wiki/Lagrange%27s_theorem_(group_theory)")[#text("Lagrange’s")]#text(" theorem, if it were not for the fact that ")#tao-math("{\\left|w\\right|}", block: false)#text(" is far too large here.) But suppose that this rational function does not collapse to the constant rational function. Applying the Schwarz-Zippel lemma (Exercise 23 from ")#link("https://terrytao.wordpress.com/2012/02/05/254b-notes-5-product-theorems-pivot-arguments-and-the-larsen-pink-non-concentration-inequality/")[#text("Notes 5")]#text("), we then see that the set of pairs ")#mi("{(a,b,c,d),(a^{\\prime},b^{\\prime},c^{\\prime},d^{\\prime}) \\in SL_2(F_p)}")#text(" with ")#mi("{a,a^{\\prime} \\neq 0}")#text(" and ")#mi("{w((a,b,c,d),(a^{\\prime},b^{\\prime},c^{\\prime},d^{\\prime}))=1}")#text(" is at most ")#tao-math("{O( \\left|w\\right| p^5 )}", block: false)#text("; adding in the ")#mi("{a=0}")#text(" and ")#mi("{a^{\\prime}=0}")#text(" cases, one still obtains a bound of ")#tao-math("{O(\\left|w\\right|p^5)}", block: false)#text(", which is acceptable since ")#tao-math("{\\left|SL_2(F_p)\\right|^2 \\sim p^6}", block: false)#text(" and ")#tao-math("{\\left|w\\right| = O( \\log p )}", block: false)#text(". Thus, the only remaining case to consider is when the rational function ")#mi("{w((a,b,c,d),(a^{\\prime},b^{\\prime},c^{\\prime},d^{\\prime}))}")#text(" is identically ")#mi("{1}")#text(" on ")#mi("{SL_2(F_p)}")#text(" with ")#mi("{a,a^{\\prime} \\neq 0}")#text(".")

#text("Now we perform another “Lefschetz principle” maneuvre to change the underlying field. Recall that the denominator of rational function ")#mi("{w((a,b,c,d),(a^{\\prime},b^{\\prime},c^{\\prime},d^{\\prime}))}")#text(" is monomial in ")#mi("{a,a^{\\prime}}")#text(", and the numerator has coefficients of size ")#tao-math("{O(\\exp(O(\\left|w\\right|)))}", block: false)#text(". If ")#tao-math("{\\left|w\\right|}", block: false)#text(" is less than ")#mi("{c\\log p}")#text(" for a sufficiently small ")#mi("{p}")#text(", we conclude in particular (for ")#mi("{p}")#text(" large enough) that the coefficients all have magnitude less than ")#mi("{p}")#text(". As such, the only way that this function can be identically ")#mi("{1}")#text(" on ")#mi("{SL_2(F_p)}")#text(" is if it is identically ")#mi("{1}")#text(" on ")#mi("{SL_2(k)}")#text(" for all ")#mi("{k}")#text(" with ")#mi("{a,a^{\\prime} \\neq 0}")#text(", and hence for ")#mi("{a=0}")#text(" or ")#mi("{a^{\\prime}=0}")#text(" also by taking Zariski closures.")

#text("On the other hand, we know that for some choices of ")#mi("{k}")#text(", e.g. ")#mi("{k={\\bf R}}")#text(", ")#mi("{SL_2(k)}")#text(" contains a copy ")#mi("{\\Gamma}")#text(" of the free group on two generators (see e.g. Exercise 23 of ")#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/")[#text("Notes 2")]#text("). As such, it is not possible for any non-identity word ")#mi("{w}")#text(" to be identically trivial on ")#mi("{SL_2(k) \\times SL_2(k)}")#text(". Thus this case cannot actually occur, completing the proof of ")#link(<tao-4ade97dda67d9671232b>)[#text("(6)")]#text(" and hence of Theorem ")#link(<tao-24c5de81702a61becdbb>)[#text("4")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" We see from the above argument that the existence of subgroups ")#mi("{\\Gamma}")#text(" of an algebraic group with good “independence” properties – such as that of generating a free group – can be useful in studying the expansion properties of that algebraic group, even if the field of interest in the latter is distinct from that of the former. For more complicated algebraic groups than ")#mi("{SL_2}")#text(", in which laws such as ")#link(<tao-d391f11b3b9f8ced025d>)[#text("(4)")]#text(" are not always available, it turns out to be useful to place further properties on the subgroup ")#mi("{\\Gamma}")#text(", for instance by requiring that all non-abelian subgroups of that group be Zariski dense (a property which has been called ")#emph[#text("strong density")]#text("), as this turns out to be useful for preventing random walks from concentrating in proper algebraic subgroups. See ")#link("http://arxiv.org/abs/1010.4259")[#text("this paper of Breuillard, Guralnick, Green and Tao")]#text(" for constructions of strongly dense free subgroups of algebraic groups and further discussion.")
]

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2012/02/13/254b-notes-6-non-concentration-in-subgroups/#comment-128576")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2012")])]

#text("Regarding remark 1: I think using the lazy random walk you can only prove one-sided expansion (you only see the spectral gap at the top), while using even powers of the standard walk will bound the two-sided gap.")

#emph[#text("[Oops, that was silly of me. The remark has now been deleted, with appropriate changes to all sidedness references. -T]")]

#text("Regarding Remark 2: While this follows from expansion (since the proper subgroups are virtually solvable and hence don’t expand for any bounded set of generators), in proving strong approximation by this route you might as well stop earlier — it already follows from the large girth (which is basically an ingredient in the proof of expansion). Let ")#mi("S=\\{x,y\\} \\in {SL}_2({\\bf Z})")#text(" generate a free group (obtained from the Tits alternative) and choose ")#mi("a,b,c,d")#text(" in that group so that ")#mi("[[a,b],[c,d]] \\neq 1")#text(". Observes with Bourgain-Gamburd that every proper subgroup of ")#mi("{SL}_2({\\bf Z})")#text(" satisfies the law ")#mi("[[a,b],[c,d]] = 1")#text(". It follows that modulo a prime ")#mi("p")#text(" which does not divide the entries of the chosen double commutator the images of ")#mi("x,y")#text(" do not generate a proper subgroup, and hence are a set of generators.")

#text("On the other hand, I don’t see how to generalize this to other groups, which have ")#mi("SL_2")#text(" as a subgroup (even if you assume expansion, since we have just shown that these groups expand). As far as I know the proofs of expansion in higher rank all use the strong approximation theorem rather than imply it, but I’d be happy to learn otherwise.")

#emph[#text("[Fair enough, I’ll modify the remark accordingly. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e6f9636aff4e8efe4f609718e99d3efcc5d132dc590b2294f863aa6072fc4c2-ef6a1eba3a4d425a0ccc25fb352a292dd688da2e3dce9fb615482db41998fc1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of iamdibakardatta")]], [#link("https://terrytao.wordpress.com/2012/02/13/254b-notes-6-non-concentration-in-subgroups/#comment-129455")[#strong[#text("iamdibakardatta")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2012")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I am a PhD student in Solid Mechanics at Brown University, USA. According your point of view, what is the ‘ physical significance of entropy ‘ ?")#linebreak()#text(" Thank you in advance for the reply.")#linebreak()#text(" Regards,")#linebreak()#text(" Dibakar")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ff16e931e85f1c3cd85ccc7a7c84890c3808f939c23a90b6d6a207accf032755-bea49347367a21cd6f917516ced7fd450f72ce33509dc4514053f0e3ceb654a1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kit")]], [#link("https://terrytao.wordpress.com/2012/02/13/254b-notes-6-non-concentration-in-subgroups/#comment-129809")[#strong[#text("kit")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2012")])]

#text("typo in exercise 2: then there os no element")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 7: Sieving and expanders « What’s new")]], [#link("https://terrytao.wordpress.com/2012/02/13/254b-notes-6-non-concentration-in-subgroups/#comment-131026")[#strong[#text("254B, Notes 7: Sieving and expanders « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2012")])]

#text("[…] turns out that to prove Theorem 1, the Cayley expansion results in from the previous set of notes are not quite enough; one needs a more general Cayley expansion result in where is square-free […]")
]
