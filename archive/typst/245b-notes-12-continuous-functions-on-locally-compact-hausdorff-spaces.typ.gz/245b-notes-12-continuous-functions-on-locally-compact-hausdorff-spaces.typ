// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/
// Converted to Typst by tao2typ: "2026-10-14T07:13:41.650377+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245B, Notes 12: Continuous functions on locally compact Hausdorff spaces", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245B, Notes 12: Continuous functions on locally compact Hausdorff spaces")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 March 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A key theme in real analysis is that of studying general functions ")#mi("{f: X \\rightarrow {\\bf R}}")#text(" or ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" by first approximating them by “simpler” or “nicer” functions. But the precise class of “simple” or “nice” functions may vary from context to context. In measure theory, for instance, it is common to approximate measurable functions by indicator functions or simple functions. But in other parts of analysis, it is often more convenient to approximate rough functions by continuous or smooth functions (perhaps with compact support, or some other decay condition), or by functions in some algebraic class, such as the class of polynomials or ")#link("http://en.wikipedia.org/wiki/Trigonometric_polynomial")[#text("trigonometric polynomials")]#text(".")

#text("In order to approximate rough functions by more continuous ones, one of course needs tools that can generate continuous functions with some specified behaviour. The two basic tools for this are ")#link("http://en.wikipedia.org/wiki/Urysohn%27s_lemma")[#text("Urysohn’s lemma")]#text(", which approximates indicator functions by continuous functions, and the ")#link("http://en.wikipedia.org/wiki/Tietze_extension_theorem")[#text("Tietze extension theorem")]#text(", which extends continuous functions on a subdomain to continuous functions on a larger domain. An important consequence of these theorems is the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem")]#text(" for linear functionals on the space of compactly supported continuous functions, which describes such functionals in terms of ")#link("http://en.wikipedia.org/wiki/Radon_measure")[#text("Radon measures")]#text(".")

#text("Sometimes, approximation by continuous functions is not enough; one must approximate continuous functions in turn by an even smoother class of functions. A useful tool in this regard is the ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93Weierstrass_theorem")[#text("Stone-Weierstrass theorem")]#text(", that generalises the classical ")#link("http://en.wikipedia.org/wiki/Weierstrass_approximation_theorem#Weierstrass_approximation_theorem")[#text("Weierstrass approximation theorem")]#text(" to more general algebras of functions.")

#text("As an application of this theory (and of many of the results accumulated in previous lecture notes), we will present (in an optional section) the commutative ")#link("http://en.wikipedia.org/wiki/Gelfand%E2%80%93Naimark_theorem")[#text("Gelfand-Neimark theorem")]#text(" classifying all commutative unital ")#link("http://en.wikipedia.org/wiki/C*-algebra")[#mi("{C^*}")#text("-algebras")]#text(".")

#metadata(none) <tao-78da40e270ebe399f0f2>

#heading(level: 1)[#strong[#text(" — 1. Urysohn’s lemma — ")]]

#text("Let ")#mi("{X}")#text(" be a topological space. An indicator function ")#mi("{1_E}")#text(" in this space will not typically be a continuous function (indeed, if ")#mi("{X}")#text(" is connected, this only happens when ")#mi("{E}")#text(" is the empty set or the whole set). Nevertheless, for certain topological spaces, it is possible to approximate an indicator function by a continuous function, as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Urysohn’s lemma)")]#text(" Let ")#mi("{X}")#text(" be a topological space. Then the following are equivalent:")

#list(
[#text("(i) Every pair of disjoint closed sets ")#mi("{K, L}")#text(" in ")#mi("{X}")#text(" can be separated by disjoint open neighbourhoods ")#mi("{U \\supset K}")#text(", ")#mi("{V \\supset L}")#text(".")],
[#text("(ii) For every closed set ")#mi("{K}")#text(" in ")#mi("{X}")#text(" and every open neighbourhood ")#mi("{U}")#text(" of ")#mi("{K}")#text(", there exists an open set ")#mi("{V}")#text(" and a closed set ")#mi("{L}")#text(" such that ")#mi("{K \\subset V \\subset L \\subset U}")#text(".")],
[#text("(iii) For every pair of disjoint closed sets ")#mi("{K, L}")#text(" in ")#mi("{X}")#text(", there exists a continuous function ")#mi("{f: X \\rightarrow [0,1]}")#text(" which equals ")#mi("{1}")#text(" on ")#mi("{K}")#text(" and ")#mi("{0}")#text(" on ")#mi("{L}")#text(".")],
[#text("(iv) For every closed set ")#mi("{K}")#text(" in ")#mi("{X}")#text(" and every open neighbourhood ")#mi("{U}")#text(" of ")#mi("{K}")#text(", there exists a continuous function ")#mi("{f: X \\rightarrow [0,1]}")#text(" such that ")#mi("{1_K(x) \\leq f(x) \\leq 1_U(x)}")#text(" for all ")#mi("{x \\in X}")#text(".")]
)
]

#text("A topological space which obeys any (and hence all) of (i-iv) is known as a ")#link("http://en.wikipedia.org/wiki/Normal_space")[#text("normal space")]#text("; definition (i) is traditionally taken to be the standard definition of normality. We will give some examples of normal spaces shortly.")

#emph[#text("Proof:")]#text(" The equivalence of (iii) and (iv) is clear, as the complement of a closed set is an open set and vice versa. The equivalence of (i) and (ii) follows similarly.")

#text("To deduce (i) from (iii), let ")#mi("{K, L}")#text(" be disjoint closed sets, let ")#mi("{f}")#text(" be as in (iii), and let ")#mi("{U, V}")#text(" be the open sets ")#mi("{U := \\{ x \\in X: f(x) > 2/3 \\}}")#text(" and ")#mi("{V := \\{x \\in X: f(x) < 1/3 \\}}")#text(".")

#text("The only remaining task is to deduce (iv) from (ii). Suppose we have a closed set ")#mi("{K = K_1}")#text(" and an open set ")#mi("{U = U_0}")#text(" with ")#mi("{K_1 \\subset U_0}")#text(". Applying (ii), we can find an open set ")#mi("{U_{1/2}}")#text(" and a closed set ")#mi("{K_{1/2}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("K_1 \\subset U_{1/2} \\subset K_{1/2} \\subset U_0.")]]

#text("Applying (ii) two more times, we can find more open sets ")#mi("{U_{1/4}, U_{3/4}}")#text(" and closed sets ")#mi("{K_{1/4}, K_{3/4}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("K_1 \\subset U_{3/4} \\subset K_{3/4} \\subset U_{1/2} \\subset K_{1/2} \\subset U_{1/4} \\subset K_{1/4} \\subset U_0.")]]

#text("Iterating this process, we can construct open sets ")#mi("{U_q}")#text(" and closed sets ")#mi("{K_q}")#text(" for every dyadic rational ")#mi("{q = a/2^n}")#text(" in ")#mi("{(0,1)}")#text(" such that ")#mi("{U_q \\subset K_q}")#text(" for all ")#mi("{0 < q < 1}")#text(", and ")#mi("{K_{q^{\\prime}} \\subset U_{q}}")#text(" for any ")#mi("{0 \\leq q < q^{\\prime} \\leq 1}")#text(".")

#text("If we now define ")#mi("{f(x) := \\sup \\{ q: x \\in U_q \\} = \\inf \\{ q: x \\not \\in K_q \\}}")#text(", where ")#mi("{q}")#text(" ranges over dyadic rationals between ")#mi("{0}")#text(" and ")#mi("{1}")#text(", and with the convention that the empty set has sup ")#mi("{0}")#text(" and inf ")#mi("{1}")#text(", one easily verifies that the sets ")#mi("{\\{ f(x) > \\alpha \\} = \\bigcup_{q>\\alpha} U_q}")#text(" and ")#mi("{\\{f(x) < \\alpha\\} = \\bigcup_{q<\\alpha} X \\backslash K_q}")#text(" are open for every real number ")#mi("{\\alpha}")#text(", and so ")#mi("{f}")#text(" is continuous as required. ")#mi("\\Box")

#text("The definition of normality is very similar to the ")#link("http://en.wikipedia.org/wiki/Hausdorff_space")[#text("Hausdorff property")]#text(", which separates pairs of points instead of closed sets. Indeed, if every point in ")#mi("{X}")#text(" is closed (a property known as the ")#link("http://en.wikipedia.org/wiki/T1_space")[#mi("{T_1}")#text(" property")]#text("), then normality clearly implies the Hausdorff property. The converse is not always true, but (as the term suggests) in practice most topological spaces one works with in real analysis are normal. For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Show that every metric space is normal.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Let ")#mi("{X}")#text(" be a Hausdorff space.")

#list(
[#text("Show that a compact subset of ")#mi("{X}")#text(" and a point disjoint from that set can always be separated by open neighbourhoods.")],
[#text("Show that a pair of disjoint compact subsets of ")#mi("{X}")#text(" can always be separated by open neighbourhoods.")],
[#text("Show that every compact Hausdorff space is normal.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Let ")#mi("{{\\bf R}}")#text(" be the real line with the usual topology ")#mi("{{\\mathcal F}}")#text(", and let ")#mi("{{\\mathcal F}^{\\prime}}")#text(" be the topology on ")#mi("{{\\bf R}}")#text(" generated by ")#mi("{{\\mathcal F}}")#text(" and the set ")#mi("{\\{{\\bf Q}\\}}")#text(" consisting only of the rationals ")#mi("{{\\bf Q}}")#text("; in other words, ")#mi("{{\\mathcal F}^{\\prime}}")#text(" is the coarsest refinement of the usual topology that makes the set of rationals ")#mi("{{\\bf Q}}")#text(" an open set. Show that ")#mi("{({\\bf R}, {\\mathcal F}^{\\prime})}")#text(" is Hausdorff, with every point closed, but is not normal.")
]

#text("The above example was a simple but somewhat artificial example of a non-normal space. One can create more “natural” examples of non-normal Hausdorff spaces (with every point closed), but establishing non-normality becomes more difficult. The following example is due ")#link("http://www.ams.org/mathscinet-getitem?mr=26802")[#text("to Stone")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" ")#metadata(none) <tao-fb4a65c1c47c22585531>#text(" Let ")#mi("{{\\bf N}^{\\bf R}}")#text(" be the space of natural number-valued tuples ")#mi("{(n_x)_{x \\in {\\bf R}}}")#text(", endowed with the product topology (i.e. the topology of pointwise convergence).")

#list(
[#text("Show that ")#mi("{{\\bf N}^{\\bf R}}")#text(" is Hausdorff, and every point is closed.")],
[#text("For ")#mi("{j=1,2}")#text(", let ")#mi("{K_j}")#text(" be the set of all tuples ")#mi("{(n_x)_{x \\in {\\bf R}}}")#text(" such that ")#mi("{n_x=j}")#text(" for all ")#mi("{x}")#text(" outside of a countable set, and such that ")#mi("{x \\mapsto n_x}")#text(" is injective on this finite set (i.e. there do not exist distinct ")#mi("{x, x^{\\prime}}")#text(" such that ")#mi("{n_x = n_{x^{\\prime}} \\neq j}")#text("). Show that ")#mi("{K_1, K_2}")#text(" are disjoint and closed.")],
[#text("Show that given any open neighbourhood ")#mi("{U}")#text(" of ")#mi("{K_1}")#text(", there exists disjoint finite subsets ")#mi("{A_1, A_2, \\ldots}")#text(" of ")#mi("{{\\bf R}}")#text(" and an injective function ")#mi("{f: \\bigcup_{i=1}^\\infty A_i \\rightarrow {\\bf N}}")#text(" such that for any ")#mi("{j \\geq 0}")#text(", any ")#mi("{(m_x)_{x \\in {\\bf R}}}")#text(" such that ")#mi("{m_x = f(x)}")#text(" for all ")#mi("{x \\in A_1 \\cup \\ldots \\cup A_j}")#text(" and is identically ")#mi("{1}")#text(" on ")#mi("{A_{j+1}}")#text(", lies in ")#mi("{U}")#text(".")],
[#text("Show that any open neighbourhood of ")#mi("{K_1}")#text(" and any open neighbourhood of ")#mi("{K_2}")#text(" necessarily intersect, and so ")#mi("{{\\bf N}^{\\bf R}}")#text(" is not normal.")],
[#text("Conclude that ")#mi("{{\\bf R}^{\\bf R}}")#text(" with the product topology is not normal.")]
)
]

#text("The property of being normal is a topological one, thus if one topological space is normal, then any other topological space homeomorphic to it is also normal. However, (unlike, say, the Hausdorff property), the property of being normal is not preserved under passage to subspaces:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Given an example of a subspace of a normal space which is not normal. (")#emph[#text("Hint")]#text(": use Exercise ")#link(<tao-fb4a65c1c47c22585531>)[#text("5")]#text(", possibly after replacing ")#mi("{{\\bf R}}")#text(" with a homeomorphic equivalent.)")
]

#text("Let ")#mi("{C_c(X \\rightarrow {\\bf R})}")#text(" be the space of real continuous compactly supported functions on ")#mi("{X}")#text(". Urysohn’s lemma generates a large number of useful elements of ")#mi("{C_c(X \\rightarrow {\\bf R})}")#text(", in the case when ")#mi("{X}")#text(" is ")#link("http://en.wikipedia.org/wiki/Locally_compact_space")[#text("locally compact")]#text(" Hausdorff:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-70e5d7b6a29b392f8507>#text(" Let ")#mi("{X}")#text(" be a locally compact Hausdorff space, let ")#mi("{K}")#text(" be a compact set, and let ")#mi("{U}")#text(" be an open neighbourhood of ")#mi("{K}")#text(". Show that there exists ")#mi("{f \\in C_c(X \\rightarrow {\\bf R})}")#text(" such that ")#mi("{1_K(x) \\leq f(x) \\leq 1_U(x)}")#text(" for all ")#mi("{x \\in X}")#text(". (")#emph[#text("Hint:")]#text(" First use the local compactness of ")#mi("{X}")#text(" to find a neighbourhood of ")#mi("{K}")#text(" with compact closure; then restrict ")#mi("{U}")#text(" to this neighbourhood. The closure of ")#mi("{U}")#text(" is now a compact set; restrict everything to this set, at which point the space becomes normal.)")
]

#text("One consequence of this exercise is that ")#mi("{C_c(X \\rightarrow {\\bf R})}")#text(" tends to be dense in many other function spaces. We give an important example here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 8 (Radon measure)")]#text(" ")#metadata(none) <tao-827951b0c9cb29e7571f>#text(" Let ")#mi("{X}")#text(" be a locally compact Hausdorff space that is also ")#link("http://en.wikipedia.org/wiki/%CE%A3-compact_space")[#mi("{\\sigma}")#text("-compact")]#text(", and let ")#mi("{{\\mathcal B}}")#text(" be the ")#link("http://en.wikipedia.org/wiki/Borel_set")[#text("Borel")]#text(" ")#mi("{\\sigma}")#text("-algebra. An (unsigned) ")#link("http://en.wikipedia.org/wiki/Radon_measure")[#text("Radon measure")]#text(" is a unsigned measure ")#mi("{\\mu: {\\mathcal B} \\rightarrow {\\bf R}^+}")#text(" with the following properties:")

#list(
[#text("(Local finiteness) For any compact subset ")#mi("{K}")#text(" of ")#mi("{X}")#text(", ")#mi("{\\mu(K)}")#text(" is finite.")],
[#text("(")#link("http://en.wikipedia.org/wiki/Outer_regular_measure")[#text("Outer regularity")]#text(") For any Borel set ")#mi("{E}")#text(" of ")#mi("{X}")#text(", ")#mi("{\\mu(E) = \\inf\\{ \\mu(U): U \\supset E; U \\text{ op{}en} \\}}")#text(".")],
[#text("(")#link("http://en.wikipedia.org/wiki/Inner_regular_measure")[#text("Inner regularity")]#text(") For any Borel set ")#mi("{E}")#text(" of ")#mi("{X}")#text(", ")#mi("{\\mu(E) = \\sup\\{ \\mu(K): K \\subset E; K \\text{ compact} \\}}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 9")]#text(" ")#link("http://en.wikipedia.org/wiki/Lebesgue_measure")[#text("Lebesgue measure")]#text(" ")#mi("{m}")#text(" on ")#mi("{{\\bf R}^n}")#text(" is a Radon measure, as is any absolutely continuous unsigned measure ")#mi("{m_f}")#text(", where ")#mi("{f \\in L^1({\\bf R}^n, dm)}")#text(". More generally, if ")#mi("{\\mu}")#text(" is Radon and ")#mi("{\\nu}")#text(" is a finite unsigned measure which is ")#link("http://en.wikipedia.org/wiki/Absolutely_continuous_measure")[#text("absolutely continuous")]#text(" with respect to ")#mi("{\\mu}")#text(", then ")#mi("{\\nu}")#text(" is Radon. On the other hand, ")#link("http://en.wikipedia.org/wiki/Counting_measure")[#text("counting measure")]#text(" on ")#mi("{{\\bf R}^n}")#text(" is not Radon (it is not locally finite). It is possible to define Radon measures on Hausdorff spaces that are not ")#mi("{\\sigma}")#text("-compact or locally compact, but the theory is more subtle and will not be considered here. We will study Radon measures more thoroughly in the next section.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10")]#text(" ")#metadata(none) <tao-869e889501378164b0ea>#text(" Let ")#mi("{X}")#text(" be a locally compact Hausdorff space that is also ")#mi("{\\sigma}")#text("-compact, and let ")#mi("{\\mu}")#text(" be a Radon measure on ")#mi("{X}")#text(". Then for any ")#mi("{0 < p < \\infty}")#text(", ")#mi("{C_c(X \\rightarrow {\\bf R})}")#text(" is a dense subset in (real-valued) ")#mi("{L^p(X,\\mu)}")#text(". In other words, every element of ")#mi("{L^p(X,\\mu)}")#text(" can be expressed as a limit (in ")#mi("{L^p(X,\\mu)}")#text(") of continuous functions of compact support.")
]

#emph[#text("Proof:")]#text(" Since continuous functions of compact support are bounded, and compact sets have finite measure, we see that ")#mi("{C_c(X)}")#text(" is a subspace of ")#mi("{L^p(X,\\mu)}")#text(". We need to show that the closure ")#mi("{\\overline{C_c(X)}}")#text(" of this space contains all of ")#mi("{L^p(X,\\mu)}")#text(".")

#text("Let ")#mi("{E}")#text(" be a Borel set of finite measure. Applying inner and outer regularity, we can find a sequence of compact sets ")#mi("{K_n \\subset E}")#text(" and open sets ")#mi("{U_n \\supset E}")#text(" such that ")#mi("{\\mu(E \\backslash K_n), \\mu(U_n \\backslash E) \\rightarrow 0}")#text(". Applying Exercise ")#link(<tao-70e5d7b6a29b392f8507>)[#text("7")]#text(", we can then find ")#mi("{f_n \\in C_c(X \\rightarrow {\\bf R})}")#text(" such that ")#mi("{1_{K_n}(x) \\leq f_n(x) \\leq 1_{U_n}(x)}")#text(". In particular, this implies (by the ")#link("http://en.wikipedia.org/wiki/Squeeze_theorem")[#text("squeeze theorem")]#text(") that ")#mi("{f_n}")#text(" converges in ")#mi("{L^p(X,\\mu)}")#text(" to ")#mi("{1_E}")#text(" (here we use the finiteness of ")#mi("{p}")#text("); thus ")#mi("{1_E}")#text(" lies in ")#mi("{\\overline{C_c(X \\rightarrow {\\bf R})}}")#text(" for any measurable set ")#mi("{E}")#text(". By linearity, all simple functions lie in ")#mi("{\\overline{C_c(X \\rightarrow {\\bf R})}}")#text("; taking closures, we see that any ")#mi("{L^p}")#text(" function lies in ")#mi("{\\overline{C_c(X \\rightarrow {\\bf R})}}")#text(", as desired. ")#mi("\\Box")

#text("Of course, the real-valued version of the above proposition immediately implies a complex-valued analogue. On the other hand, the claim fails when ")#mi("{p=\\infty}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{X}")#text(" be a locally compact Hausdorff space that is ")#mi("{\\sigma}")#text("-compact, and let ")#mi("{\\mu}")#text(" be a Radon measure. Assume that ")#mi("{\\mu}")#text(" has full support, which means that every non-empty open set has positive measure. Show that the closure of ")#mi("{C_c(X \\rightarrow {\\bf R})}")#text(" in ")#mi("{L^\\infty(X,\\mu)}")#text(" is ")#mi("{C_0(X \\rightarrow {\\bf R})}")#text(", the space of continuous real-valued functions which vanish at infinity (i.e. for every ")#mi("{\\varepsilon > 0}")#text(" there exists a compact set ")#mi("{K}")#text(" such that ")#tao-math("{\\left|f(x)\\right| \\leq \\varepsilon}", block: false)#text(" for all ")#mi("{x \\not \\in K}")#text("). Thus, in general, ")#mi("{C_c(X \\rightarrow {\\bf R})}")#text(" is not dense in ")#mi("{L^\\infty(X,\\mu)}")#text(".")

#text("(For an extra challenge: do this exercise without the hypothesis that ")#mi("{\\mu}")#text(" has full support.)")
]

#text("Thus we see that the ")#mi("{L^\\infty}")#text(" norm is strong enough to preserve continuity in the limit, whereas the ")#mi("{L^p}")#text(" norms are (locally) weaker and permit discontinuous functions to be approximated by continuous ones.")

#text("Another important consequence of Urysohn’s lemma is the ")#link("http://en.wikipedia.org/wiki/Tietze_extension_theorem")[#text("Tietze extension theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 12 (Tietze extension theorem)")]#text(" ")#metadata(none) <tao-c366aac99a54fca9dca6>#text(" Let ")#mi("{X}")#text(" be a normal topological space, let ")#mi("{[a,b] \\subset {\\bf R}}")#text(" be a bounded interval, let ")#mi("{K}")#text(" be a closed subset of ")#mi("{X}")#text(", and let ")#mi("{f: K \\rightarrow [a,b]}")#text(" be a continuous function. Then there exists a continuous function ")#mi("{\\tilde f: X \\rightarrow [a,b]}")#text(" which extends ")#mi("{f}")#text(", i.e. ")#mi("{\\tilde f(x) = f(x)}")#text(" for all ")#mi("{x \\in K}")#text(".")
]

#emph[#text("Proof:")]#text(" It suffices to find an continuous extension ")#mi("{\\tilde f: X \\rightarrow {\\bf R}}")#text(" taking values in the real line rather than in ")#mi("{[a,b]}")#text(", since one can then replace ")#mi("{\\tilde f}")#text(" by ")#mi("{\\min(\\max(\\tilde f, a),b)}")#text(" (note that min and max are continuous operations).")

#text("Let ")#mi("{T: BC(X \\rightarrow {\\bf R}) \\rightarrow BC(K \\rightarrow {\\bf R})}")#text(" be the restriction map ")#mi("{Tf := f\\downharpoonright_K}")#text(". This is clearly a continuous linear map; our task is to show that it is surjective, i.e. to find a solution to the equation ")#mi("{Tg=f}")#text(" for each ")#mi("{f \\in BC(X \\rightarrow {\\bf R})}")#text(". We do this by the standard analysis trick of getting an approximate solution to ")#mi("{Tg=f}")#text(" first, and then using iteration to boost the approximate solution to an exact solution.")

#text("Let ")#mi("{f: K \\rightarrow {\\bf R}}")#text(" have sup norm ")#mi("{1}")#text(", thus ")#mi("{f}")#text(" takes values in ")#mi("{[-1,1]}")#text(". To solve the problem ")#mi("{Tg=f}")#text(", we approximate ")#mi("{f}")#text(" by ")#mi("{\\frac{1}{3} 1_{f\\geq 1/3} - \\frac{1}{3} 1_{f \\leq -1/3}}")#text(". By Urysohn’s lemma, we can find a continuous function ")#mi("{g: X \\rightarrow [-1/3,1/3]}")#text(" such that ")#mi("{g=1/3}")#text(" on the closed set ")#mi("{\\{ x \\in K: f \\geq 1/3\\}}")#text(" and ")#mi("{g=-1/3}")#text(" on the closed set ")#mi("{\\{ x \\in K: f \\leq -1/3\\}}")#text(". Now, ")#mi("{Tg}")#text(" is not quite equal to ")#mi("{f}")#text("; but observe from construction that ")#mi("{f-Tg}")#text(" has sup norm ")#mi("{2/3}")#text(".")

#text("Scaling this fact, we conclude that, given any ")#mi("{f \\in BC(K \\rightarrow {\\bf R})}")#text(", we can find a decomposition ")#mi("{f = Tg + f^{\\prime}}")#text(", where ")#tao-math("{\\left\\|g\\right\\|_{BC(X \\rightarrow {\\bf R})} \\leq \\frac{1}{3} \\left\\| f \\right\\|_{BC(K \\rightarrow {\\bf R})}}", block: false)#text(" and ")#tao-math("{\\left\\|f^{\\prime}\\right\\|_{BC(K \\rightarrow {\\bf R})} \\leq \\frac{2}{3} \\left\\|f\\right\\|_{BC(K \\rightarrow {\\bf R})}}", block: false)#text(".")

#text("Starting with any ")#mi("{f=f_0 \\in BC(K \\rightarrow {\\bf R})}")#text(", we can now iterate this construction to express ")#mi("{f_n = Tg_n + f_{n+1}}")#text(" for all ")#mi("{n =0,1,2,\\ldots}")#text(", where ")#tao-math("{\\left\\|f_n\\right\\|_{BC(K \\rightarrow R)} \\leq (\\frac{2}{3})^n \\left\\|f\\right\\|_{BC(K \\rightarrow {\\bf R})}}", block: false)#text(" and ")#tao-math("{\\left\\|g_n\\right\\|_{BC(X \\rightarrow {\\bf R})} \\leq \\frac{1}{3} (\\frac{2}{3})^n \\left\\|f\\right\\|_{BC(K \\rightarrow {\\bf R})}}", block: false)#text(". As ")#mi("{BC(X \\rightarrow {\\bf R})}")#text(" is a Banach space, we see that ")#mi("{\\sum_{n=0}^\\infty g_n}")#text(" converges absolutely to some limit ")#mi("{g \\in BC(X \\rightarrow {\\bf R})}")#text(", and that ")#mi("{Tg=f}")#text(", as desired. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 13")]#text(" Observe that Urysohn’s lemma can be viewed the special case of the Tietze extension theorem when ")#mi("{K}")#text(" is the union of two disjoint closed sets, and ")#mi("{f}")#text(" is equal to ")#mi("{1}")#text(" on one of these sets and equal to ")#mi("{0}")#text(" on the other.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 14")]#text(" One can extend the Tietze extension theorem to finite-dimensional vector spaces: if ")#mi("{K}")#text(" is a closed subset of a normal vector space ")#mi("{X}")#text(" and ")#mi("{f: K \\rightarrow {\\bf R}^n}")#text(" is bounded and continuous, then one has a bounded continuous extension ")#mi("{\\overline{f}: K \\rightarrow {\\bf R}^n}")#text(". Indeed, one simply applies the Tietze extension theorem to each component of ")#mi("{f}")#text(" separately. However, if the range space is replaced by a space with a non-trivial topology, then there can be topological obstructions to continuous extension. For instance, a map ")#mi("{f: \\{0,1\\} \\rightarrow Y}")#text(" from a two-point set into a topological space ")#mi("{Y}")#text(" is always continuous, but can be extended to a continuous map ")#mi("{\\tilde f: {\\bf R} \\rightarrow Y}")#text(" if and only if ")#mi("{f(0)}")#text(" and ")#mi("{f(1)}")#text(" lie in the same ")#link("http://en.wikipedia.org/wiki/Path-connected#Path_connectedness")[#text("path-connected")]#text(" component of ")#mi("{Y}")#text(". Similarly, if ")#mi("{f: S^1 \\rightarrow Y}")#text(" is a map from the unit circle into a topological space ")#mi("{Y}")#text(", then a continuous extension from ")#mi("{S^1}")#text(" to ")#mi("{{\\bf R}^2}")#text(" exists if and only if the closed curve ")#mi("{f: S^1 \\rightarrow Y}")#text(" is ")#link("http://en.wikipedia.org/wiki/Contractible_space")[#text("contractible")]#text(" to a point in ")#mi("{Y}")#text(". These sorts of questions require the machinery of algebraic topology to answer them properly, and are beyond the scope of this course.")
]

#text("There are analogues for the Tietze extension theorem in some other categories of functions. For instance, in the Lipschitz category, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" Let ")#mi("{X}")#text(" be a metric space, let ")#mi("{K}")#text(" be a subset of ")#mi("{X}")#text(", and let ")#mi("{f: K \\rightarrow {\\bf R}}")#text(" be a ")#link("http://en.wikipedia.org/wiki/Lipschitz_continuity")[#text("Lipschitz continuous")]#text(" map with some Lipschitz constant ")#mi("{A}")#text(" (thus ")#tao-math("{\\left|f(x)-f(y)\\right| \\leq A d(x,y)}", block: false)#text(" for all ")#mi("{x,y \\in K}")#text("). Show that there exists an extension ")#mi("{\\tilde f: X \\rightarrow {\\bf R}}")#text(" of ")#mi("{f}")#text(" which is Lipschitz continuous with the same Lipschitz constant ")#mi("{A}")#text(". (")#emph[#text("Hint:")]#text(" A “greedy” algorithm will work here: pick ")#mi("{\\tilde f}")#text(" to be as large as one can get away with (or as small as one can get away with.))")
]

#text("One can also remove the requirement that the function ")#mi("{f}")#text(" be bounded in the Tietze extension theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Let ")#mi("{X}")#text(" be a normal topological space, let ")#mi("{K}")#text(" be a closed subset of ")#mi("{X}")#text(", and let ")#mi("{f: K \\rightarrow {\\bf R}}")#text(" be a continuous map (not necessarily bounded). Then there exists an extension ")#mi("{\\tilde f: X \\rightarrow {\\bf R}}")#text(" of ")#mi("{f}")#text(" which is still continuous. (")#emph[#text("Hint")]#text(": first “compress” ")#mi("{f}")#text(" to be bounded by working with, say, ")#mi("{\\arctan(f)}")#text(" (other choices are possible), and apply the usual Tietze extension theorem. There will be some sets in which one cannot invert the compression function, but one can deal with this by a further appeal to Urysohn’s lemma to damp the extension out on such sets.)")
]

#text("There is also a ")#link("http://en.wikipedia.org/wiki/Locally_compact_space")[#text("locally compact")]#text(" Hausdorff version of the Tietze extension theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" ")#metadata(none) <tao-c7b68ac37f364473e922>#text(" Let ")#mi("{X}")#text(" be locally compact Hausdorff, let ")#mi("{K}")#text(" be compact, and let ")#mi("{f \\in C(K \\rightarrow {\\bf R})}")#text(". Then there exists ")#mi("{\\tilde f \\in C_c(X \\rightarrow {\\bf R})}")#text(" which extends ")#mi("{f}")#text(".")
]

#text("Proposition ")#link(<tao-869e889501378164b0ea>)[#text("10")]#text(" shows that measurable functions in ")#mi("{L^p}")#text(" can be approximated by continuous functions of compact support (cf. ")#link("http://en.wikipedia.org/wiki/Littlewood%27s_three_principles_of_real_analysis")[#text("Littlewood’s second principle")]#text("). Another approximation result in a similar spirit is ")#link("http://en.wikipedia.org/wiki/Lusin%27s_theorem")[#text("Lusin’s theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 18 (Lusin’s theorem)")]#text(" Let ")#mi("{X}")#text(" be a locally compact Hausdorff space that is ")#mi("{\\sigma}")#text("-compact, and let ")#mi("{\\mu}")#text(" be a Radon measure. Let ")#mi("{f: X \\rightarrow {\\bf R}}")#text(" be a measurable function supported on a set of finite measure, and let ")#mi("{\\varepsilon > 0}")#text(". Then there exists ")#mi("{g \\in C_c(X \\rightarrow {\\bf R})}")#text(" which agrees with ")#mi("{f}")#text(" outside of a set of measure at most ")#mi("{\\varepsilon}")#text(".")
]

#emph[#text("Proof:")]#text(" Observe that as ")#mi("{f}")#text(" is finite everywhere, it is bounded outside of a set of arbitrarily small measure. Thus we may assume without loss of generality that ")#mi("{f}")#text(" is bounded. Similarly, as ")#mi("{X}")#text(" is ")#mi("{\\sigma}")#text("-compact (or by inner regularity), the support of ")#mi("{f}")#text(" differs from a compact set by a set of arbitrarily small measure; so we may assume that ")#mi("{f}")#text(" is also supported on a compact set ")#mi("{K}")#text(". By Exercise ")#link(<tao-c7b68ac37f364473e922>)[#text("17")]#text(", it then suffices to show that ")#mi("{f}")#text(" is continuous on the complement of an open set of arbitrarily small measure; by outer regularity, we may delete the adjective “open” from the preceding sentence.")

#text("As ")#mi("{f}")#text(" is bounded and compactly supported, ")#mi("{f}")#text(" lies in ")#mi("{L^p(X,\\mu)}")#text(" for every ")#mi("{0 < p < \\infty}")#text(", and using Proposition ")#link(<tao-869e889501378164b0ea>)[#text("10")]#text(" and Chebyshev’s inequality, it is not hard to find, for each ")#mi("{n = 1,2,\\ldots}")#text(", a function ")#mi("{f_n \\in C_c(X\\rightarrow {\\bf R})}")#text(" which differs from ")#mi("{f}")#text(" by at most ")#mi("{1/2^n}")#text(" outside of a set of measure at most ")#mi("{\\varepsilon/2^{n+2}}")#text(" (say). In particular, ")#mi("{f_n}")#text(" converges uniformly to ")#mi("{f}")#text(" outside of a set of measure at most ")#mi("{\\varepsilon/4}")#text(", and ")#mi("{f}")#text(" is therefore continuous outside this set. The claim follows. ")#mi("\\Box")

#text("Another very useful application of Urysohn’s lemma is to create ")#link("http://en.wikipedia.org/wiki/Partition_of_unity")[#text("partitions of unity")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 19 (Partitions of unity)")]#text(" ")#metadata(none) <tao-95821c6a2c21666416a4>#text(" Let ")#mi("{X}")#text(" be a normal topological space, and let ")#mi("{(K_\\alpha)_{\\alpha \\in A}}")#text(" be a collection of closed sets that cover ")#mi("{X}")#text(". For each ")#mi("{\\alpha \\in A}")#text(", let ")#mi("{U_\\alpha}")#text(" be an open neighbourhood of ")#mi("{K_\\alpha}")#text(", which are finitely overlapping in the sense that each ")#mi("{x \\in X}")#text(" has a neighbourhood that intersects at most finitely many of the ")#mi("{U_\\alpha}")#text(". Then there exists a continuous function ")#mi("{f_\\alpha: X \\rightarrow [0,1]}")#text(" supported on ")#mi("{U_\\alpha}")#text(" for each ")#mi("{\\alpha \\in A}")#text(" such that ")#mi("{\\sum_{\\alpha \\in A} f_\\alpha(x) = 1}")#text(" for all ")#mi("{x \\in X}")#text(".")

#text("If ")#mi("{X}")#text(" is locally compact Hausdorff instead of normal, and the ")#mi("{K_\\alpha}")#text(" are compact, then one can take the ")#mi("{f_\\alpha}")#text(" to be compactly supported.")
]

#emph[#text("Proof:")]#text(" Suppose first that ")#mi("{X}")#text(" is normal. By Urysohn’s lemma, one can find a continuous function ")#mi("{g_\\alpha: X \\rightarrow [0,1]}")#text(" for each ")#mi("{\\alpha \\in A}")#text(" which is supported on ")#mi("{U_\\alpha}")#text(" and equals ")#mi("{1}")#text(" on the closed set ")#mi("{K_\\alpha}")#text(". Observe that the function ")#mi("{g := \\sum_{\\alpha \\in A} g_\\alpha}")#text(" is well-defined, continuous and bounded below by ")#mi("{1}")#text(". The claim then follows by setting ")#mi("{f_\\alpha := g_\\alpha/g}")#text(".")

#text("The final claim follows by using Exercise ")#link(<tao-70e5d7b6a29b392f8507>)[#text("7")]#text(" instead of Urysohn’s lemma. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" ")#metadata(none) <tao-89dc3aa169ac8f8f4a66>#text(" Let ")#mi("{X}")#text(" be a topological space. A function ")#mi("{f: X \\rightarrow {\\bf R}}")#text(" is said to be ")#emph[#text("upper semi-continuous")]#text(" if ")#mi("{f^{-1}( (-\\infty,a) )}")#text(" is open for all real ")#mi("{a}")#text(", and ")#emph[#text("lower semi-continuous")]#text(" if ")#mi("{f^{-1}( (a,+\\infty) )}")#text(" is open for all real ")#mi("{a}")#text(".")

#enum(start: 1, 
[#text("Show that an indicator function ")#mi("{1_E}")#text(" is upper semi-continuous if and only if ")#mi("{E}")#text(" is closed, and lower semi-continuous if and only if ")#mi("{E}")#text(" is open.")],
[#text("If ")#mi("{X}")#text(" is normal and ")#mi("{T_1}")#text(" (which means that all points are closed), show that a function ")#mi("{f}")#text(" is upper semi-continuous if and only if ")#mi("{f(x) = \\inf\\{ g(x): g \\in C(X \\rightarrow (-\\infty,+\\infty]), g \\geq f \\}}")#text(" for all ")#mi("{x \\in X}")#text(", and lower semi-continuous if and only if ")#mi("{f(x) = \\sup\\{ g(x): g \\in C(X \\rightarrow [-\\infty,+\\infty)), g \\leq f \\}}")#text(" for all ")#mi("{x \\in X}")#text(", where we write ")#mi("{f \\leq g}")#text(" if ")#mi("{f(x) \\leq g(x)}")#text(" for all ")#mi("{x \\in X}")#text(".")]
)
]

#heading(level: 1)[#strong[#text(" — 2. The Riesz representation theorem — ")]]

#text("Let ")#mi("{X}")#text(" be a locally compact Hausdorff space which is also ")#mi("{\\sigma}")#text("-compact. In Definition ")#link(<tao-827951b0c9cb29e7571f>)[#text("8")]#text(" we defined the notion of a Radon measure. Such measures are quite common in real analysis. For instance, we have the following result.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 21")]#text(" ")#metadata(none) <tao-f916a6b54fccf4fbdce5>#text(" Let ")#mi("{\\mu}")#text(" be a non-negative finite Borel measure on a compact metric space ")#mi("{X}")#text(". Then ")#mi("{\\mu}")#text(" is a Radon measure.")
]

#emph[#text("Proof:")]#text(" As ")#mi("{\\mu}")#text(" is finite, it is locally finite, so it suffices to show inner and outer regularity. Let ")#mi("{{\\mathcal A}}")#text(" be the collection of all Borel subsets ")#mi("{E}")#text(" of ")#mi("{X}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\sup \\{ \\mu(K): K \\subset E, \\text{ closed} \\} = \\inf \\{ \\mu(U): U \\supset E, \\text{ op{}en} \\} = \\mu(E),")]]

#text("It will then suffice to show that every Borel set lies in ")#mi("{{\\mathcal A}}")#text(" (note that as ")#mi("{X}")#text(" is compact, a subset ")#mi("{K}")#text(" of ")#mi("{X}")#text(" is closed if and only if it is compact).")

#text("Clearly ")#mi("{{\\mathcal A}}")#text(" contains the empty set and the whole set ")#mi("{X}")#text(", and is closed under complements. It is also closed under finite unions and intersections. Indeed, given two sets ")#mi("{E, F \\in {\\mathcal A}}")#text(", we can find a sequences ")#mi("{K_n \\subset E \\subset U_n}")#text(", ")#mi("{L_n \\subset F \\subset V_n}")#text(" of closed sets ")#mi("{K_n, L_n}")#text(" and open sets ")#mi("{U_n, V_n}")#text(" such that ")#mi("{\\mu(K_n), \\mu(U_n) \\rightarrow \\mu(E)}")#text(" and ")#mi("{\\mu(L_n), \\mu(V_n) \\rightarrow \\mu(F)}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("\\mu(K_n \\cap L_n) + \\mu(K_n \\cup L_n) = \\mu(K_n) + \\mu(L_n) \\rightarrow \\mu(E) + \\mu(F) = \\mu(E \\cap F) + \\mu(E \\cup F)")]]

#text("we have (by monotonicity of ")#mi("{\\mu}")#text(") that")

#align(center)[#tao-fit-display[#mitex("\\mu(K_n \\cap L_n) \\rightarrow \\mu(E \\cap F); \\quad \\mu(K_n \\cup L_n) \\rightarrow \\mu(E \\cup F)")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("\\mu(U_n \\cap V_n) \\rightarrow \\mu(E \\cap F); \\quad \\mu(U_n \\cup V_n) \\rightarrow \\mu(E \\cup F)")]]

#text("and so ")#mi("{E \\cap F, E \\cup F \\in {\\mathcal A}}")#text(".")

#text("One can also show that ")#mi("{{\\mathcal A}}")#text(" is closed under countable disjoint unions and is thus a ")#mi("{\\sigma}")#text("-algebra. Indeed, given disjoint sets ")#mi("{E_n \\in{\\mathcal A}}")#text(" and ")#mi("{\\varepsilon > 0}")#text(", pick a closed ")#mi("{K_n \\subset E_n}")#text(" and open ")#mi("{U_n \\supset E_n}")#text(" such that ")#mi("{\\mu(E_n \\backslash K_n), \\mu(U_n \\backslash E_n) \\leq \\varepsilon/2^n}")#text("; then")

#align(center)[#tao-fit-display[#mitex("\\mu(\\bigcup_{n=1}^\\infty E_n) \\leq \\mu(\\bigcup_{n=1}^\\infty U_n) \\leq \\sum_{n=1}^\\infty\\mu(E_n) + \\varepsilon")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mu(\\bigcup_{n=1}^\\infty E_n) \\geq \\mu(\\bigcup_{n=1}^N K_n) \\geq \\sum_{n=1}^N \\mu(E_n) - \\varepsilon")]]

#text("for any ")#mi("{N}")#text(", and the claim follows from the squeeze test.")

#text("To finish the claim it suffices to show that every open set ")#mi("{V}")#text(" lies in ")#mi("{{\\mathcal A}}")#text(". For this it will suffice to show that ")#mi("{V}")#text(" is a countable union of closed sets. But as ")#mi("{X}")#text(" is a compact metric space, it is separable (Lemma 4 from ")#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/")[#text("Notes 10")]#text("), and so ")#mi("{V}")#text(" has a countable dense subset ")#mi("{x_1,x_2,\\ldots}")#text(". One then easily verifies that every point in the open set ")#mi("{V}")#text(" is contained in a closed ball of rational radius centred at one of the ")#mi("{x_i}")#text(" that is in turn contained in ")#mi("{V}")#text("; thus ")#mi("{V}")#text(" is the countable union of closed sets as desired. ")#mi("\\Box")

#text("This result can be extended to more general spaces than compact metric spaces, for instance to Polish spaces (provided that the measure remains finite). For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Let ")#mi("{X}")#text(" be a locally compact metric space which is ")#mi("{\\sigma}")#text("-compact, and let ")#mi("{\\mu}")#text(" be an unsigned Borel measure which is finite on every compact set. Show that ")#mi("{\\mu}")#text(" is a Radon measure.")
]

#text("When the assumptions of ")#mi("{X}")#text(" are weakened, then it is possible to find locally finite Borel measures that are not Radon measures, but they are somewhat pathological in nature.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Let ")#mi("{X}")#text(" be a locally compact Hausdorff space which is ")#mi("{\\sigma}")#text("-compact, and let ")#mi("{\\mu}")#text(" be a Radon measure. Define a ")#mi("{F_\\sigma}")#text(" set to be a countable union of closed sets, and a ")#mi("{G_\\delta}")#text(" set to be a countable intersection of open sets. Show that every Borel set can be expressed as the union of an ")#mi("{F_\\sigma}")#text(" set and a null set, and as a ")#mi("{G_\\delta}")#text(" set with a null subset removed.")
]

#text("If ")#mi("{\\mu}")#text(" is a Radon measure on ")#mi("{X}")#text(", then we can define the integral ")#mi("{I_\\mu(f) := \\int_X f\\ d\\mu}")#text(" for every ")#mi("{f \\in C_c(X \\rightarrow {\\bf R})}")#text(", since ")#mi("{\\mu}")#text(" assigns every compact set a finite measure. Furthermore, ")#mi("{I_\\mu}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Linear_functional")[#text("linear functional")]#text(" on ")#mi("{C_c(X \\rightarrow {\\bf R})}")#text(" which is ")#emph[#text("positive")]#text(" in the sense that ")#mi("{I_\\mu(f) \\geq 0}")#text(" whenever ")#mi("{f}")#text(" is non-negative. If we place the uniform norm on ")#mi("{C_c(X \\rightarrow {\\bf R})}")#text(", then ")#mi("{I_\\mu}")#text(" is continuous if and only if ")#mi("{\\mu}")#text(" is finite; but we will not use continuity for now, relying instead on positivity.")

#text("The fundamentally important ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem")]#text(" for such spaces asserts that this is the ")#emph[#text("only")]#text(" way to generate such linear functionals:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 24 (Riesz representation theorem for ")#mi("{C_c(X \\rightarrow {\\bf R})}")#text(", unsigned version)")]#text(" ")#metadata(none) <tao-36bde837209c48be9aa3>#text(" Let ")#mi("{X}")#text(" be a locally compact Hausdorff space which is also ")#mi("{\\sigma}")#text("-compact. Let ")#mi("{I: C_c(X \\rightarrow {\\bf R}) \\rightarrow {\\bf R}}")#text(" be a positive linear functional. Then there exists a unique Radon measure ")#mi("{\\mu}")#text(" on ")#mi("{X}")#text(" such that ")#mi("{I = I_\\mu}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 25")]#text(" The ")#mi("{\\sigma}")#text("-compactness hypothesis can be dropped (after relaxing the inner regularity condition to only apply to open sets, rather than to all sets); but I will restrict attention here to the ")#mi("{\\sigma}")#text("-compact case (which already covers a large fraction of the applications of this theorem) as the argument simplifies slightly.")
]

#emph[#text("Proof:")]#text(" We first prove the uniqueness, which is quite easy due to all the properties that Radon measures enjoy. Suppose we had two Radon measures ")#mi("{\\mu, \\mu^{\\prime}}")#text(" such that ")#mi("{I = I_\\mu = I_{\\mu^{\\prime}}}")#text("; in particular, we have ")#metadata(none) <tao-773fa2b7f15b36e930a4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\int_X f\\ d\\mu = \\int_X f\\ d\\mu^{\\prime}")]]

#text(" ")#text(" for all ")#mi("{f \\in C_c(X \\rightarrow {\\bf R})}")#text(". Now let ")#mi("{K}")#text(" be a compact set, and let ")#mi("{U}")#text(" be an open neighbourhood of ")#mi("{K}")#text(". By Exercise ")#link(<tao-70e5d7b6a29b392f8507>)[#text("7")]#text(", we can find ")#mi("{f \\in C_c(X \\rightarrow {\\bf R})}")#text(" with ")#mi("{1_K \\leq f \\leq 1_U}")#text("; applying this to ")#link(<tao-773fa2b7f15b36e930a4>)[#text("(1)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\mu(U) \\geq \\mu^{\\prime}(K).")]]

#text("Taking suprema in ")#mi("{K}")#text(" and using inner regularity, we conclude that ")#mi("{\\mu(U) \\geq \\mu^{\\prime}(U)}")#text("; exchanging ")#mi("{\\mu}")#text(" and ")#mi("{\\mu^{\\prime}}")#text(" we conclude that ")#mi("{\\mu}")#text(" and ")#mi("{\\mu^{\\prime}}")#text(" agree on open sets; by outer regularity we then conclude that ")#mi("{\\mu}")#text(" and ")#mi("{\\mu^{\\prime}}")#text(" agree on all Borel sets.")

#text("Now we prove existence, which is significantly trickier. We will initially make the simplifying assumption that ")#mi("{X}")#text(" is compact (so in particular ")#mi("{C_c(X \\rightarrow {\\bf R}) = C(X \\rightarrow {\\bf R}) = BC(X \\rightarrow {\\bf R})}")#text("), and remove this assumption at the end of the proof.")

#text("Observe that ")#mi("{I}")#text(" is monotone on ")#mi("{C(X \\rightarrow {\\bf R})}")#text(", thus ")#mi("{I(f) \\leq I(g)}")#text(" whenever ")#mi("{f \\leq g}")#text(".")

#text("We would like to define the measure ")#mi("{\\mu}")#text(" on Borel sets ")#mi("{E}")#text(" by defining ")#mi("{\\mu(E) := I(1_E)}")#text(". This does not work directly, because ")#mi("{1_E}")#text(" is not continuous. To get around this problem we shall begin by extending the functional ")#mi("{I}")#text(" to the class ")#mi("{BC_{lsc}(X \\rightarrow {\\bf R}^+)}")#text(" of bounded lower ")#link("http://en.wikipedia.org/wiki/Semi-continuity")[#text("semi-continuous")]#text(" non-negative functions. We define ")#mi("{I(f)}")#text(" for such functions by the formula")

#align(center)[#tao-fit-display[#mitex("I(f) := \\sup \\{ I(g): g \\in C_c(X \\rightarrow {\\bf R}); 0 \\leq g \\leq f \\}")]]

#text("(cf. Exercise ")#link(<tao-89dc3aa169ac8f8f4a66>)[#text("20")]#text("). This definition agrees with the existing definition of ")#mi("{I(f)}")#text(" in the case when ")#mi("{f}")#text(" is continuous. Since ")#mi("{I(1)}")#text(" is finite and ")#mi("{I}")#text(" is monotone, one sees that ")#mi("{I(f)}")#text(" is finite (and non-negative) for all ")#mi("{f \\in BC_{lsc}(X \\rightarrow {\\bf R}^+)}")#text(". One also easily sees that ")#mi("{I}")#text(" is monotone on ")#mi("{BC_{lsc}(X \\rightarrow {\\bf R}^+)}")#text(": ")#mi("{I(f) \\leq I(g)}")#text(" whenever ")#mi("{f,g \\in BC_{lsc}(X \\rightarrow {\\bf R}^+)}")#text(" and ")#mi("{f \\leq g}")#text(", and homogeneous in the sense that ")#mi("{I(cf) = cI(f)}")#text(" for all ")#mi("{f \\in BC_{lsc}(X \\rightarrow {\\bf R}^+)}")#text(" and ")#mi("{c > 0}")#text(". It is also easy to verify the super-additivity property ")#mi("{I(f+f^{\\prime}) \\geq I(f) + I(f^{\\prime})}")#text(" for ")#mi("{f, f^{\\prime} \\in BC_{lsc}(X \\rightarrow {\\bf R}^+)}")#text("; this simply reflects the linearity of ")#mi("{I}")#text(" on ")#mi("{C_c(X \\rightarrow {\\bf R})}")#text(", together with the fact that if ")#mi("{0 \\leq g \\leq f}")#text(" and ")#mi("{0 \\leq g^{\\prime} \\leq f^{\\prime}}")#text(", then ")#mi("{0 \\leq g+g^{\\prime} \\leq f+f^{\\prime}}")#text(".")

#text("We now complement the super-additivity property with a countably sub-additive one: if ")#mi("{f_n \\in BC_{lsc}(X \\rightarrow {\\bf R}^+)}")#text(" is a sequence, and ")#mi("{f \\in BC_{lsc}(X \\rightarrow {\\bf R}^+)}")#text(" is such that ")#mi("{f(x) \\leq \\sum_{n=1}^\\infty f_n(x)}")#text(" for all ")#mi("{x \\in X}")#text(", then ")#mi("{I(f) \\leq \\sum_{n=1}^\\infty I(f_n)}")#text(".")

#text("Pick a small ")#mi("{0 < \\varepsilon < 1}")#text(". It will suffice to show that ")#mi("{I(g) \\leq \\sum_{n=1}^\\infty I(f_n) + O( \\varepsilon )}")#text(" whenever ")#mi("{g \\in C_c(X \\rightarrow {\\bf R})}")#text(" is such that ")#mi("{0 \\leq g \\leq f}")#text(", and ")#mi("{O(\\varepsilon}")#text(" denotes a quantity bounded in magnitude by ")#mi("{C \\varepsilon}")#text(", where ")#mi("{C}")#text(" is a quantity that is independent of ")#mi("{\\varepsilon}")#text(" (but can depend on ")#mi("{I}")#text(" and ")#mi("{g}")#text(").")

#text("Fix ")#mi("{g}")#text(". For every ")#mi("{x \\in X}")#text(", we can find a neighbourhood ")#mi("{U_x}")#text(" of ")#mi("{x}")#text(" such that ")#tao-math("{\\left|g(y)-g(x)\\right| \\leq \\varepsilon}", block: false)#text(" for all ")#mi("{y \\in U_x}")#text("; we can also find ")#mi("{N_x > 0}")#text(" such that ")#mi("{\\sum_{n=1}^{N_x} f_n(x) \\geq f(x) - \\varepsilon \\geq g(x) - \\varepsilon}")#text(". By shrinking ")#mi("{U_x}")#text(" if necessary, we see from the lower semicontinuity of the ")#mi("{f_n}")#text(" and ")#mi("{f}")#text(" that we can also ensure that ")#mi("{f_n(y) \\geq f_n(x) - \\varepsilon/2^n}")#text(" for all ")#mi("{1 \\leq n \\leq N_x}")#text(" and ")#mi("{y \\in U_x}")#text(".")

#text("By normality, we can find open neighbourhoods ")#mi("{V_x}")#text(" of ")#mi("{x}")#text(" whose closure lies in ")#mi("{U_x}")#text(". The ")#mi("{V_x}")#text(" form an open cover of ")#mi("{X}")#text(". Since we are assuming ")#mi("{X}")#text(" to be compact, we can thus find a finite subcover ")#mi("{V_{x_1},\\ldots,V_{x_k}}")#text(" of ")#mi("{X}")#text(". Applying Lemma ")#link(<tao-95821c6a2c21666416a4>)[#text("19")]#text(", we can thus find a partition of unity ")#mi("{1 = \\sum_{j=1}^k \\psi_j}")#text(", where each ")#mi("{\\psi_j}")#text(" is supported on ")#mi("{U_{x_j}}")#text(".")

#text("Let ")#mi("{x \\in X}")#text(". Then we can write ")#mi("{g(x) = \\sum_{j: x \\in U_{x_j}} g(x) \\psi_j(x)}")#text(". If ")#mi("{j}")#text(" is in this sum, then ")#tao-math("{\\left|g(x_j)-g(x)\\right| \\leq \\varepsilon}", block: false)#text(". We can then write")

#tao-aligned(keep: true)[


#tao-math("g(x)  & \\leq \\sum_{j: x \\in U_{x_j}} g(x_j) \\psi_j(x) + O(\\varepsilon)", block: true)



#tao-math(" & \\leq \\sum_{j: x \\in U_{x_j}} g(x_j) \\psi_j(x) \\sum_{n=1}^{N_{x_j}} f_n(x_j) \\psi_j(x) + O( \\varepsilon )", block: true)



#tao-math(" & \\leq \\sum_{n=1}^\\infty \\sum_{j: N_{x_j} \\geq n} f_n(x_j) \\psi_j) + O(\\varepsilon).", block: true)
]

#text("Observe that only finitely many summands are non-zero. Applying ")#mi("{I}")#text(" and using monotonicity and finite additivity on ")#mi("{C_c(X)}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("I(g) \\leq \\sum_{n=1}^\\infty I (\\sum_{j: N_{x_j} \\geq n} f_n(x_j) \\psi_j ) + O( \\varepsilon )")]]

#text("(here we use that ")#mi("{1 \\in C_c(X)}")#text(" and so ")#mi("{I(1)}")#text(" is finite). On the other hand, from the triangle inequality we have the pointwise bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{j: N_{x_j} \\geq n} f_n(x_j) \\psi_j(x) \\leq \\sum_{j: N_{x_j} \\geq n} f_n(x) \\psi_j(x) + O(\\varepsilon/2^n) = f_n(x) + O(\\varepsilon/2^n)")]]

#text("for any ")#mi("{x \\in X}")#text(" and any ")#mi("{n}")#text(", hence")

#align(center)[#tao-fit-display[#mitex("I(g) \\leq \\sum_{n=1}^\\infty I(f_n) + O( \\varepsilon )")]]

#text("as desired.")

#text("Combining sub-additivity and super-additivity we see that ")#mi("{I}")#text(" is additive: ")#mi("{I(f+g)=I(f)+I(g)}")#text(" for ")#mi("{f, g \\in BC_{lsc}(X \\rightarrow {\\bf R}^+)}")#text(".")

#text("Now that we are able to integrate lower semi-continuous functions, we can start defining the Radon measure ")#mi("{\\mu}")#text(". When ")#mi("{U}")#text(" is open, we define ")#mi("{\\mu(U)}")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\mu(U) := I( 1_U ),")]]

#text("which is well-defined and non-negative since ")#mi("{1_U}")#text(" is bounded, non-negative and lower semi-continuous. When ")#mi("{K}")#text(" is closed we define ")#mi("{\\mu(K)}")#text(" by complementation:")

#align(center)[#tao-fit-display[#mitex("\\mu(K) := \\mu(X) - \\mu( X \\backslash K );")]]

#text("this is compatible with the definition of ")#mi("{\\mu}")#text(" on open sets by additivity of ")#mi("{I}")#text(", and is also non-negative. The monotonicity of ")#mi("{I}")#text(" implies monotonicity of ")#mi("{\\mu}")#text(": in particular, if a closed set ")#mi("{K}")#text(" lies in an open set ")#mi("{U}")#text(", then ")#mi("{\\mu(K) \\leq \\mu(U)}")#text(".")

#text("Given any set ")#mi("{E \\subset X}")#text(", define the ")#emph[#text("outer measure")]

#align(center)[#tao-fit-display[#mitex("\\mu^+(E) := \\inf \\{ \\mu(U): E \\subset U, \\text{ op{}en} \\}")]]

#text("and the ")#emph[#text("inner measure")]

#align(center)[#tao-fit-display[#mitex("\\mu^-(E) := \\sup \\{ \\mu(K): E \\supset K, \\text{ closed} \\};")]]

#text("thus ")#mi("{0 \\leq \\mu^-(E) \\leq \\mu^+(E) \\leq \\mu(X)}")#text(". We call a set ")#mi("{E}")#text(" ")#emph[#text("measurable")]#text(" if ")#mi("{\\mu^-(E) = \\mu^+(E)}")#text(". By arguing as in the proof of Theorem ")#link(<tao-f916a6b54fccf4fbdce5>)[#text("21")]#text(", we see that the class of measurable sets is a ")#link("http://en.wikipedia.org/wiki/Boolean_algebra_(structure)")[#text("Boolean algebra")]#text(". Next, we claim that every open set ")#mi("{U}")#text(" is measurable. Indeed, unwrapping all the definitions we see that")

#align(center)[#tao-fit-display[#mitex("\\mu(U) = \\sup \\{ I(f): f \\in C_c(X \\rightarrow {\\bf R}); 0 \\leq f \\leq 1_U \\}.")]]

#text("Each ")#mi("{f}")#text(" in this supremum can be perturbed by an epsilon to a function ")#mi("{\\max(f-\\varepsilon,0)}")#text(" supported in some closed subset ")#mi("{K}")#text(" of ")#mi("{U}")#text(", and from this one easily verifies that ")#mi("{\\mu^+(U) = \\mu(U) = \\mu^-(U)}")#text(". Similarly, every closed set ")#mi("{K}")#text(" is measurable. We can now extend ")#mi("{\\mu}")#text(" to measurable sets by declaring ")#mi("{\\mu(E) := \\mu^+(E) = \\mu^-(E)}")#text(" when ")#mi("{E}")#text(" is measurable; this is compatible with the previous definitions of ")#mi("{\\mu}")#text(".")

#text("Next, let ")#mi("{E_1, E_2, \\ldots}")#text(" be a countable sequence of disjoint measurable sets. Then for any ")#mi("{\\varepsilon > 0}")#text(", we can find open neighbourhoods ")#mi("{U_n}")#text(" of ")#mi("{E_n}")#text(" and closed sets ")#mi("{K_n}")#text(" in ")#mi("{E_n}")#text(" such that ")#mi("{\\mu(E_n) \\leq \\mu(U_n) \\leq \\mu(E_n) + \\varepsilon/2^n}")#text(" and ")#mi("{\\mu(E_n)-\\varepsilon/2^n \\leq \\mu(K_n) \\leq \\mu(E_n)}")#text(". Using the sub-additivity of ")#mi("{I}")#text(" on ")#mi("{BC_{lsc}(X \\rightarrow {\\bf R}^+)}")#text(", we have ")#mi("{\\mu(\\bigcup_{n=1}^\\infty U_n) \\leq \\sum_{n=1}^\\infty \\mu(U_n) \\leq \\sum_{n=1}^\\infty \\mu(E_n) + \\varepsilon}")#text(". Similarly, from the additivity of ")#mi("{I}")#text(" we have ")#mi("{\\mu(\\bigcup_{n=1}^N K_n) = \\sum_{n=1}^N \\mu(K_n) \\geq \\sum_{n=1}^N \\mu(E_n) - \\varepsilon}")#text(". Letting ")#mi("{\\varepsilon \\rightarrow 0}")#text(", we conclude that ")#mi("{\\bigcup_{n=1}^\\infty E_n}")#text(" is measurable with ")#mi("{\\mu( \\bigcup_{n=1}^\\infty E_n ) = \\sum_{n=1}^\\infty \\mu(E_n)}")#text(". Thus the Boolean algebra of measurable sets is in fact a ")#mi("{\\sigma}")#text("-algebra, and ")#mi("{\\mu}")#text(" is a countably additive measure on it. From construction we also see that it is finite, outer regular, and inner regular, and therefore is a Radon measure. The only remaining thing to check is that ")#mi("{I(f) = I_\\mu(f)}")#text(" for all ")#mi("{f \\in C(X \\rightarrow {\\bf R})}")#text(". If ")#mi("{f}")#text(" is a finite non-negative linear combination of indicator functions of open sets, the claim is clear from the construction of ")#mi("{\\mu}")#text(" and the additivity of ")#mi("{I}")#text(" on ")#mi("{BC_{lsc}(X \\rightarrow {\\bf R}^+)}")#text("; taking uniform limits, we obtain the claim for non-negative continuous functions, and then by linearity we obtain it for all functions.")

#text("This concludes the proof in the case when ")#mi("{X}")#text(" is compact. Now suppose that ")#mi("{X}")#text(" is ")#mi("{\\sigma}")#text("-compact. Then we can find a partition of unity ")#mi("{1 = \\sum_{n=0}^\\infty \\psi_n}")#text(" into continuous compactly supported functions ")#mi("{\\psi_n \\in C_c(X \\rightarrow {\\bf R}^+)}")#text(", with each ")#mi("{x \\in X}")#text(" being contained in the support of finitely many ")#mi("{\\psi_n}")#text(". (Indeed, from ")#mi("{\\sigma}")#text("-compactness and the locally compact Hausdorff property one can find a nested sequence ")#mi("{K_1 \\subset K_2 \\subset \\ldots}")#text(" of compact sets, with each ")#mi("{K_n}")#text(" in the interior of ")#mi("{K_{n+1}}")#text(", such that ")#mi("{\\bigcup_n K_n = X}")#text(". Using Exercise ")#link(<tao-70e5d7b6a29b392f8507>)[#text("7")]#text(", one can find functions ")#mi("{\\eta_n \\in C_c(X \\rightarrow {\\bf R}^+)}")#text(" that equal ")#mi("{1}")#text(" on ")#mi("{K_n}")#text(" and are supported on ")#mi("{K_{n+1}}")#text("; now take ")#mi("{\\psi_n := \\eta_{n+1} - \\eta_n}")#text(" and ")#mi("{\\psi_0 := \\eta_0}")#text(".) Observe that ")#mi("{I(f) = \\sum_n I(\\psi_n f)}")#text(" for all ")#mi("{f \\in C_c(X \\rightarrow {\\bf R})}")#text(". From the compact case we see that there exists a finite Radon measure ")#mi("{\\mu_n}")#text(" such that ")#mi("{I(\\psi_n f) = I_{\\mu_n}(f)}")#text(" for all ")#mi("{f \\in C_c(X \\rightarrow {\\bf R})}")#text("; setting ")#mi("{\\mu := \\sum_n \\mu_n}")#text(" one can verify (using the ")#link("http://en.wikipedia.org/wiki/Monotone_convergence_theorem")[#text("monotone convergence theorem")]#text(") that ")#mi("{\\mu}")#text(" obeys the required properties. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 26")]#text(" One can also construct the Radon measure ")#mi("{\\mu}")#text(" using the ")#link("http://en.wikipedia.org/wiki/Carath%C3%A9odory%27s_extension_theorem")[#text("Carátheodory extension theorem")]#text("; this proof of the Riesz representation theorem can be found in many real analysis texts. A third method is to first create the space ")#mi("{L^1}")#text(" by taking the completion of ")#mi("{C_c(X \\rightarrow {\\bf R})}")#text(" with respect to the ")#mi("{L^1}")#text(" norm ")#tao-math("{\\left\\| f \\right\\|_{L^1} := I(\\left|f\\right|)}", block: false)#text(", and then define ")#tao-math("{\\mu(E) := \\left\\| 1_E \\right\\|_{L^1}}", block: false)#text(". It seems to me that all three proofs are about equally lengthy, and ultimately rely on the same ingredients; they all seem to have their strengths and weaknesses, and involve at least one tricky computation somewhere (in the above argument, the most tricky thing is the countable subadditivity of ")#mi("{I}")#text(" on lower semicontinuous functions). I have yet to find a proof of this theorem which is both clean and conceptual, and would be happy to learn of other proofs of this theorem.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 27")]#text(" One can use the Riesz representation theorem to provide an alternate construction of ")#link("http://en.wikipedia.org/wiki/Lebesgue_measure")[#text("Lebesgue measure")]#text(", say on ")#mi("{{\\bf R}}")#text(". Indeed, the ")#link("http://en.wikipedia.org/wiki/Riemann_integral")[#text("Riemann integral")]#text(" already provides a positive linear functional on ")#mi("{C_c({\\bf R} \\rightarrow {\\bf R})}")#text(", which by the Riesz representation theorem must come from a Radon measure, which can be easily verified to assign the value ")#mi("{b-a}")#text(" to every interval ")#mi("{[a,b]}")#text(" and thus must agree with Lebesgue measure. The same approach lets one define volume measures on manifolds with a volume form.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Let ")#mi("{X}")#text(" be a locally compact Hausdorff space which is ")#mi("{\\sigma}")#text("-compact, and let ")#mi("{\\mu}")#text(" be a Radon measure. For any non-negative Borel measurable function ")#mi("{f}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\int_X f\\ d\\mu = \\inf \\{ \\int_X g\\ d\\mu: g \\geq f; g \\text{ lower semi-continuous} \\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\int_X f\\ d\\mu = \\sup \\{ \\int_X g\\ d\\mu: 0 \\leq g \\leq f; g \\text{ upper semi-continuous} \\}")]]

#text("(where we allow ")#mi("{g}")#text(" to attain infinite values). Similarly, for any non-negative lower semi-continuous function ")#mi("{g}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\int_X g\\ d\\mu = \\sup \\{ \\int_X h\\ d\\mu: 0 \\leq h \\leq g; h \\in C_c(X \\rightarrow {\\bf R}) \\}.")]]
]

#text("Now we consider signed functionals on ")#mi("{C_c(X \\rightarrow {\\bf R})}")#text(", which we now turn into a normed vector space using the uniform norm. The key lemma here is the following variant of the ")#link("http://en.wikipedia.org/wiki/Hahn_decomposition_theorem")[#text("Jordan decomposition theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 29 (Jordan decomposition for functions)")]#text(" ")#metadata(none) <tao-ae10657a0ad512c52616>#text(" Let ")#mi("{I \\in C_c(X \\rightarrow {\\bf R})^*}")#text(" be a (real) continuous linear functional. Then there exist positive linear functions ")#mi("{I^+, I^- \\in C_c(X \\rightarrow {\\bf R})^*}")#text(" such that ")#mi("{I = I^+ - I^-}")#text(".")
]

#emph[#text("Proof:")]#text(" For ")#mi("{f \\in C_c(X \\rightarrow {\\bf R}^+)}")#text(", we define")

#align(center)[#tao-fit-display[#mitex("I^+(f) := \\sup \\{ I(g): g \\in C_c(X \\rightarrow {\\bf R}): 0 \\leq g \\leq f \\}.")]]

#text("Clearly ")#mi("{0 \\leq I(f) \\leq I^+(f)}")#text(" for ")#mi("{f \\in C_c(X \\rightarrow {\\bf R}^+)}")#text("; one also easily verifies the homogeneity property ")#mi("{I^+(cf) = c I^+(f)}")#text(" and super-additivity property ")#mi("{I^+(f_1+f_2) \\geq I^+(f_1)+I^+(f_2)}")#text(" for ")#mi("{c>0}")#text(" and ")#mi("{f, f_1, f_2 \\in C_c(X \\rightarrow {\\bf R}^+)}")#text(". On the other hand, if ")#mi("{g, f_1, f_2 \\in C_c(X \\rightarrow {\\bf R}^+)}")#text(" are such that ")#mi("{g \\leq f_1+f_2}")#text(", then we can decompose ")#mi("{g = g_1+g_2}")#text(" for some ")#mi("{g_1, g_2 \\in C_c(X \\rightarrow {\\bf R}^+)}")#text(" with ")#mi("{g_1 \\leq f_1}")#text(" and ")#mi("{g_2 \\leq f_2}")#text("; for instance we can take ")#mi("{g_1 := \\min(g,f_1)}")#text(" and ")#mi("{g_2 := g-g_1}")#text(". From this we can complement super-additivity with sub-additivity and conclude that ")#mi("{I^+(f_1+f_2) = I^+(f_1)+I^+(f_2)}")#text(".")

#text("Every function in ")#mi("{C_c(X \\rightarrow {\\bf R})}")#text(" can be expressed as the difference of two functions in ")#mi("{C_c(X \\rightarrow {\\bf R}^+)}")#text(". From the additivity and homogeneity of ")#mi("{I^+}")#text(" on ")#mi("{C_c(X \\rightarrow {\\bf R}^+)}")#text(" we may thus extend ")#mi("{I^+}")#text(" uniquely to be a linear functional on ")#mi("{C_c(X \\rightarrow {\\bf R})}")#text(". Since ")#mi("{I}")#text(" is bounded on ")#mi("{C_c(X \\rightarrow {\\bf R})}")#text(", we see that ")#mi("{I^+}")#text(" is also. If we then define ")#mi("{I^- := I^+ - I}")#text(", one quickly verifies all the required properties. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]#text(" Show that among all possible choices for the functionals ")#mi("{I^+, I^-}")#text(" appearing in the above lemma, there is a unique choice which is ")#emph[#text("minimal")]#text(" in the sense that for any other functionals ")#mi("{\\tilde I^+, \\tilde I^-}")#text(" obeying the conclusions of the lemma, one has ")#mi("{\\tilde I^+(f) \\geq I^+(f)}")#text(" and ")#mi("{\\tilde I^-(f) \\geq I^-(f)}")#text(" for all nonnegative ")#mi("{f \\in C_c(X \\rightarrow {\\bf R})}")#text(".")
]

#text("Define a ")#emph[#text("signed Radon measure")]#text(" on a ")#mi("{\\sigma}")#text("-compact, locally compact Hausdorff space ")#mi("{X}")#text(" to be a ")#link("http://en.wikipedia.org/wiki/Signed_measure")[#text("signed")]#text(" Borel measure ")#mi("{\\mu}")#text(" whose positive and negative variations are both Radon. It is easy to see that a signed Radon measure ")#mi("{\\mu}")#text(" generates a linear functional ")#mi("{I_\\mu}")#text(" on ")#mi("{C_c(X \\rightarrow {\\bf R})}")#text(" as before, and ")#mi("{I_\\mu}")#text(" is continuous if ")#mi("{\\mu}")#text(" is finite. We have a converse:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31 (Riesz representation theorem, signed version)")]#text(" Let ")#mi("{X}")#text(" be a locally compact Hausdorff space which is also ")#mi("{\\sigma}")#text("-compact, and let ")#mi("{I \\in C_c(X \\rightarrow {\\bf R})^*}")#text(" be a continuous linear functional. Then there exists a unique signed finite Radon measure ")#mi("{\\mu}")#text(" such that ")#mi("{I = I_\\mu}")#text(". (")#emph[#text("Hint")]#text(": combine Theorem ")#link(<tao-36bde837209c48be9aa3>)[#text("24")]#text(" with Lemma ")#link(<tao-ae10657a0ad512c52616>)[#text("29")]#text(".)")
]

#text("The space of signed finite Radon measures on ")#mi("{X}")#text(" is denoted ")#mi("{M(X \\rightarrow {\\bf R})}")#text(", or ")#mi("{M(X)}")#text(" for short.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" Show that the space ")#mi("{M(X)}")#text(", with the total variation norm ")#tao-math("{\\left\\| \\mu \\right\\|_{M(X)} := \\left|\\mu\\right|(X)}", block: false)#text(", is a real Banach space, which is isomorphic to the dual of both ")#mi("{C_c(X \\rightarrow {\\bf R})}")#text(" and its completion ")#mi("{C_0(X \\rightarrow {\\bf R})}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("C_c(X \\rightarrow {\\bf R})^* \\equiv C_0(X \\rightarrow {\\bf R})^* \\equiv M(X).")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 33")]#text(" Note that the previous exercise generalises the identifications ")#mi("{c_c({\\bf N})^* \\equiv c_0({\\bf N})^* \\equiv \\ell^1({\\bf N})}")#text(" from previous notes. For compact Hausdorff spaces ")#mi("{X}")#text(", we have ")#mi("{C(X \\rightarrow {\\bf R}) = C_0(X \\rightarrow {\\bf R})}")#text(", and thus ")#mi("{C(X \\rightarrow {\\bf R})^* \\equiv M(X)}")#text(". For locally compact Hausdorff spaces that are ")#mi("{\\sigma}")#text("-compact but not compact, we instead have ")#mi("{C(X \\rightarrow {\\bf R})^* \\equiv M(\\beta X)}")#text(", where ")#mi("{\\beta X}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93%C4%8Cech_compactification")[#text("Stone-Cech compactification")]#text(" of ")#mi("{X}")#text(", which we will discuss in later notes.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 34")]#text(" One can of course also define complex Radon measures to be those ")#link("http://en.wikipedia.org/wiki/Complex_measure")[#text("complex")]#text(" finite Borel measures whose real and imaginary parts are signed Radon measures, and define ")#mi("{M(X \\rightarrow {\\bf C})}")#text(" to be the space of all such measures; then one has analogues of the above identifications. We omit the details.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35")]#text(" Let ")#mi("{X, Y}")#text(" be two locally compact Hausdorff spaces that are also ")#mi("{\\sigma}")#text("-compact, and let ")#mi("{f: X \\rightarrow Y}")#text(" be a continuous map. If ")#mi("{\\mu}")#text(" is an unsigned finite Radon measure on ")#mi("{X}")#text(", show that the ")#link("http://en.wikipedia.org/wiki/Pushforward_measure")[#text("pushforward measure")]#text(" ")#mi("{f_\\# \\mu}")#text(" on ")#mi("{Y}")#text(", defined by ")#mi("{f_\\# \\mu(E) := \\mu(f^{-1}(E))}")#text(", is a Radon measure on ")#mi("{Y}")#text(". What happens for infinite measures? Establish the same fact for signed finite Radon measures.")
]

#text("Let ")#mi("{X}")#text(" be locally compact Hausdorff and ")#mi("{\\sigma}")#text("-compact. As ")#mi("{M(X)}")#text(" is equivalent to the ")#link("http://en.wikipedia.org/wiki/Dual_space")[#text("dual")]#text(" of the Banach space ")#mi("{C_0(X \\rightarrow {\\bf R})}")#text(", it acquires a ")#link("http://en.wikipedia.org/wiki/Weak_topology")[#text("weak* topology")]#text(" (see ")#link("https://terrytao.wordpress.com/2009/02/21/245b-notes-11-the-strong-and-weak-topologies/")[#text("Notes 11")]#text("), known as the ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague topology")]#text(". A sequence of Radon measures ")#mi("{\\mu_n \\in M(X)}")#text(" then converges vaguely to a limit ")#mi("{\\mu \\in M(X)}")#text(" if and only if ")#mi("{\\int_X f\\ d\\mu_n \\rightarrow \\int_X f\\ d\\mu}")#text(" for all ")#mi("{f \\in C_0(X \\rightarrow {\\bf R})}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36")]#text(" Let ")#mi("{m}")#text(" be Lebesgue measure on the real line (with the usual topology).")

#list(
[#text("Show that the measures ")#mi("{n m\\downharpoonright_{[0,1/n]}}")#text(" converge vaguely as ")#mi("{n\\rightarrow \\infty}")#text(" to the ")#link("http://en.wikipedia.org/wiki/Dirac_measure")[#text("Dirac mass")]#text(" ")#mi("{\\delta_0}")#text(" at the origin ")#mi("{0}")#text(".")],
[#text("Show that the measures ")#mi("{\\frac{1}{n} \\sum_{i=1}^n \\delta_{i/n}}")#text(" converge vaguely as ")#mi("{n \\rightarrow \\infty}")#text(" to the measure ")#mi("{m\\downharpoonright_{[0,1]}}")#text(". (")#emph[#text("Hint:")]#text(" Continuous, compactly supported functions are ")#link("http://en.wikipedia.org/wiki/Riemann_integrable")[#text("Riemann integrable")]#text(".)")],
[#text("Show that the measures ")#mi("{\\delta_n}")#text(" converge vaguely as ")#mi("{n \\rightarrow \\infty}")#text(" to the zero measure ")#mi("{0}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" Let ")#mi("{X}")#text(" be locally compact Hausdorff and ")#mi("{\\sigma}")#text("-compact. Show that for every unsigned Radon measure ")#mi("{\\mu}")#text(", the map ")#mi("{\\iota: L^1(\\mu) \\rightarrow M(X)}")#text(" defined by sending ")#mi("{f \\in L^1(\\mu)}")#text(" to the measure ")#mi("{\\mu_f}")#text(" is an ")#link("http://en.wikipedia.org/wiki/Isometry")[#text("isometry")]#text(", thus ")#mi("{L^1(\\mu)}")#text(" can be identified with a subspace of ")#mi("{M(X)}")#text(". Show that this subspace is closed in the norm topology, but give an example to show that it need not be closed in the vague topology. Show that ")#mi("{M(X) = \\bigcup_\\mu L^1(\\mu)}")#text(", where ")#mi("{\\mu}")#text(" ranges over all unsigned Radon measures on ")#mi("{X}")#text("; thus one can think of ")#mi("{M(X)}")#text(" as many ")#mi("{L^1}")#text("‘s “glued together”.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38")]#text(" Let ")#mi("{X}")#text(" be a locally compact Hausdorff space which is ")#mi("{\\sigma}")#text("-compact. Let ")#mi("{f_n \\in C_0(X \\rightarrow {\\bf R})}")#text(" be a sequence of functions, and let ")#mi("{f \\in C_0(X \\rightarrow {\\bf R})}")#text(" be another function. Show that ")#mi("{f_n}")#text(" converges weakly to ")#mi("{f}")#text(" in ")#mi("{C_0(X \\rightarrow {\\bf R})}")#text(" if and only if the ")#mi("{f_n}")#text(" are uniformly bounded and converge pointwise to ")#mi("{f}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39")]#text(" Let ")#mi("{X}")#text(" be a locally compact metric space which is ")#mi("{\\sigma}")#text("-compact.")

#list(
[#text("Show that the space of finitely supported measures in ")#mi("{M(X)}")#text(" is a dense subset of ")#mi("{M(X)}")#text(" in the vague topology.")],
[#text("Show that a Radon probability measure in ")#mi("{M(X)}")#text(" can be expressed as the vague limit of a sequence of discrete (i.e. finitely supported) probability measures.")]
)
]

#heading(level: 1)[#strong[#text(" — 3. The Stone-Weierstrass theorem — ")]]

#text("We have already seen how rough functions (e.g. ")#mi("{L^p}")#text(" functions) can be approximated by continuous functions. Now we study in turn how continuous functions can be approximated by even more special functions, such as polynomials. The natural topology to work with here is the uniform topology (since uniform limits of continuous functions are continuous).")

#text("For non-compact spaces, such as ")#mi("{{\\bf R}}")#text(", it is usually not possible to approximate continuous functions uniformly by a smaller class of functions. For instance, the function ")#mi("{\\sin(x)}")#text(" cannot be approximated uniformly by polynomials on ")#mi("{{\\bf R}}")#text(", since ")#mi("{\\sin(x)}")#text(" is bounded, the only bounded polynomials are the constants, and constants cannot converge to anything other than another constant. On the other hand, on a compact domain such as ")#mi("{[-1,1]}")#text(", one can easily approximate ")#mi("{\\sin(x)}")#text(" uniformly by polynomials, for instance by using ")#link("http://en.wikipedia.org/wiki/Taylor_series")[#text("Taylor series")]#text(". So we will focus instead on compact Hausdorff spaces ")#mi("{X}")#text(" such as ")#mi("{[-1,1]}")#text(", in which continuous functions are automatically bounded.")

#text("The space ")#mi("{{\\mathcal P}([-1,1])}")#text(" of (real-valued) polynomials is a subspace of the Banach space ")#mi("{C([-1,1])}")#text(". But it is also closed under pointwise multiplication ")#mi("{f, g\\mapsto fg}")#text(", making ")#mi("{{\\mathcal P}([-1,1])}")#text(" an ")#link("http://en.wikipedia.org/wiki/Algebra_over_a_field")[#text("algebra")]#text(", and not merely a vector space. We can then rephrase the classical ")#link("http://en.wikipedia.org/wiki/Weierstrass_approximation_theorem")[#text("Weierstrass approximation theorem")]#text(" as the assertion that ")#mi("{{\\mathcal P}([-1,1])}")#text(" is dense in ")#mi("{C([-1,1])}")#text(".")

#text("One can then ask the more general question of when a sub-algebra ")#mi("{{\\mathcal A}}")#text(" of ")#mi("{C(X)}")#text(" – i.e. a subspace closed under pointwise multiplication – is dense. Not every sub-algebra is dense: the algebra of constants, for instance, will not be dense in ")#mi("{C(X)}")#text(" when ")#mi("{X}")#text(" has at least two points. Another example in a similar spirit: given two distinct points ")#mi("{x_1, x_2}")#text(" in ")#mi("{X}")#text(", the space ")#mi("{\\{ f \\in C(X): f(x_1) = f(x_2) \\}}")#text(" is a sub-algebra of ")#mi("{C(X)}")#text(", but it is not dense, because it is already closed, and cannot ")#emph[#text("separate")]#text(" ")#mi("{x_1}")#text(" and ")#mi("{x_2}")#text(" in the sense that it cannot produce a function that assigns different values to ")#mi("{x_1}")#text(" and ")#mi("{x_2}")#text(".")

#text("The remarkable ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93Weierstrass_theorem")[#text("Stone-Weierstrass theorem")]#text(" shows that this inability to separate points is the ")#emph[#text("only")]#text(" obstruction to density, at least for algebras with the identity.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 40 (Stone-Weierstrass theorem, real version)")]#text(" Let ")#mi("{X}")#text(" be a compact Hausdorff space, and let ")#mi("{{\\mathcal A}}")#text(" be a sub-algebra of ")#mi("{C(X \\rightarrow {\\bf R})}")#text(" which contains the constant function ")#mi("{1}")#text(" and separates points (i.e. for every distinct ")#mi("{x_1, x_2 \\in X}")#text(", there exists at least one ")#mi("{f}")#text(" in ")#mi("{{\\mathcal A}}")#text(" such that ")#mi("{f(x_1) \\neq f(x_2)}")#text(". Then ")#mi("{{\\mathcal A}}")#text(" is dense in ")#mi("{C(X \\rightarrow {\\bf R})}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 41")]#text(" Observe that this theorem contains the Weierstrass approximation theorem as a special case, since the algebra of polynomials clearly separates points. Indeed, we will use (a very special case) of the Weierstrass approximation theorem in the proof.")
]

#emph[#text("Proof:")]#text(" It suffices to verify the claim for algebras ")#mi("{{\\mathcal A}}")#text(" which are closed in the ")#mi("{C(X \\rightarrow {\\bf R})}")#text(" topology, since the claim follows in the general case by replacing ")#mi("{{\\mathcal A}}")#text(" with its closure (note that the closure of an algebra is still an algebra).")

#text("Observe from the ")#link("http://en.wikipedia.org/wiki/Weierstrass_approximation_theorem")[#text("Weierstrass approximation theorem")]#text(" that on any bounded interval ")#mi("{[-K,K]}")#text(", the function ")#tao-math("{\\left|x\\right|}", block: false)#text(" can be expressed as the uniform limit of polynomials ")#mi("{P_n(x)}")#text("; one can even write down explicit formulae for such a ")#mi("{P_n}")#text(", though we will not need such formulae here. Since continuous functions on the compact space ")#mi("{X}")#text(" are bounded, this implies that for any ")#mi("{f \\in {\\mathcal A}}")#text(", the function ")#tao-math("{\\left|f\\right|}", block: false)#text(" is the uniform limit of polynomial combinations ")#mi("{P_n(f)}")#text(" of ")#mi("{f}")#text(". As ")#mi("{{\\mathcal A}}")#text(" is an algebra, the ")#mi("{P_n(f)}")#text(" lie in ")#mi("{{\\mathcal A}}")#text("; as ")#mi("{{\\mathcal A}}")#text(" is closed; we see that ")#tao-math("{\\left|f\\right|}", block: false)#text(" lies in ")#mi("{{\\mathcal A}}")#text(".")

#text("Using the identities ")#tao-math("{\\max(f,g) = \\frac{f+g}{2} + \\left|\\frac{f-g}{2}\\right|}", block: false)#text(", ")#tao-math("{\\min(f,g) = \\frac{f+g}{2} - \\left|\\frac{f-g}{2}\\right|}", block: false)#text(", we conclude that ")#mi("{{\\mathcal A}}")#text(" is a ")#emph[#text("lattice")]#text(" in the sense that one has ")#mi("{\\max(f,g), \\min(f,g) \\in {\\mathcal A}}")#text(" whenever ")#mi("{f, g \\in {\\mathcal A}}")#text(".")

#text("Now let ")#mi("{f \\in C(X \\rightarrow {\\bf R})}")#text(" and ")#mi("{\\varepsilon > 0}")#text(". We would like to find ")#mi("{g \\in {\\mathcal A}}")#text(" such that ")#tao-math("{\\left|f(x)-g(x)\\right| \\leq \\varepsilon}", block: false)#text(" for all ")#mi("{x \\in X}")#text(".")

#text("Given any two points ")#mi("{x, y \\in X}")#text(", we can at least find a function ")#mi("{g_{xy} \\in {\\mathcal A}}")#text(" such that ")#mi("{g_{xy}(x)=f(x)}")#text(" and ")#mi("{g_{xy}(y)=f(y)}")#text("; this follows since the vector space ")#mi("{{\\mathcal A}}")#text(" separates points and also contains the identity function (the case ")#mi("{x=y}")#text(" needs to be treated separately). We now use these functions ")#mi("{g_{xy}}")#text(" to build the approximant ")#mi("{g}")#text(". First, observe from continuity that for every ")#mi("{x, y \\in X}")#text(" there exists an open neighbourhood ")#mi("{V_{xy}}")#text(" of ")#mi("{y}")#text(" such that ")#mi("{g_{xy}(y^{\\prime}) \\geq f(y^{\\prime})-\\varepsilon}")#text(" for all ")#mi("{y^{\\prime} \\in V_{xy}}")#text(". By compactness, for any fixed ")#mi("{x}")#text(" we can cover ")#mi("{X}")#text(" by a finite number of these ")#mi("{V_{xy}}")#text(". Taking the max of all the ")#mi("{g_{xy}}")#text(" associated to this finite subcover, we create another function ")#mi("{g_x \\in {\\mathcal A}}")#text(" such that ")#mi("{g_x(x) = f(x)}")#text(" and ")#mi("{g_x(y) \\geq f(y) - \\varepsilon}")#text(" for all ")#mi("{y \\in X}")#text(". By continuity, we can find an open neighbourhood ")#mi("{U_x}")#text(" of ")#mi("{x}")#text(" such that ")#mi("{g_x(x^{\\prime}) \\leq f(x^{\\prime})+\\varepsilon}")#text(" for all ")#mi("{x^{\\prime} \\in U_x}")#text(". Again applying compactness, we can cover ")#mi("{X}")#text(" by a finite number of the ")#mi("{U_x}")#text("; taking the min of all the ")#mi("{g_x}")#text(" associated to this finite subcover we obtain ")#mi("{g \\in {\\mathcal A}}")#text(" with ")#mi("{f(x)-\\varepsilon \\leq g(x) \\leq f(x)+\\varepsilon}")#text(" for all ")#mi("{x \\in X}")#text(", and the claim follows. ")#mi("\\Box")

#text("There is an analogue of the Stone-Weierstrass theorem for algebras that do not contain the identity:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42")]#text(" ")#metadata(none) <tao-4230a1e7bf8cb32f2d83>#text(" Let ")#mi("{X}")#text(" be a compact Hausdorff space, and let ")#mi("{{\\mathcal A}}")#text(" be a closed sub-algebra of ")#mi("{C(X \\rightarrow {\\bf R})}")#text(" which separates points but does not contain the identity. Show that there exists a unique ")#mi("{x_0 \\in X}")#text(" such that ")#mi("{{\\mathcal A} = \\{ f \\in C(X \\rightarrow {\\bf R}): f(x_0)=0 \\}}")#text(".")
]

#text("The Stone-Weierstrass theorem is not true as stated in the complex case. For instance, the space ")#mi("{C( \\mathbb{D} \\rightarrow {\\bf C} )}")#text(" of complex-valued functions on the closed unit disk ")#tao-math("{\\mathbb{D} := \\{ z \\in {\\bf C}: \\left|z\\right| \\leq 1 \\}}", block: false)#text(" has a closed proper sub-algebra that separates points, namely the algebra ")#mi("{{\\mathcal H}({\\mathbb D})}")#text(" of functions in ")#mi("{C( \\mathbb{D} \\rightarrow {\\bf C} )}")#text(" that are ")#link("http://en.wikipedia.org/wiki/Holomorphic")[#text("holomorphic")]#text(" on the interior of this disk. Indeed, by ")#link("http://en.wikipedia.org/wiki/Cauchy%27s_integral_theorem")[#text("Cauchy’s theorem")]#text(" and its converse (")#link("http://en.wikipedia.org/wiki/Morera%27s_theorem")[#text("Morera’s theorem")]#text("), a function ")#mi("{f \\in C(\\mathbb{D} \\rightarrow {\\bf C})}")#text(" lies in ")#mi("{{\\mathcal H}({\\mathbb D})}")#text(" if and only if ")#mi("{\\int_\\gamma f = 0}")#text(" for every closed contour ")#mi("{\\gamma}")#text(" in ")#mi("{{\\mathbb D}}")#text(", and one easily verifies that this implies that ")#mi("{{\\mathcal H}({\\mathbb D})}")#text(" is closed; meanwhile, the holomorphic function ")#mi("{z \\mapsto z}")#text(" separates all points. However, the Stone-Weierstrass theorem can be recovered in the complex case by adding one further axiom, namely that the algebra be closed under conjugation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 43 (Stone-Weierstrass theorem, complex version)")]#text(" Let ")#mi("{X}")#text(" be a compact Hausdorff space, and let ")#mi("{{\\mathcal A}}")#text(" be a complex sub-algebra of ")#mi("{C(X \\rightarrow {\\bf C})}")#text(" which contains the constant function ")#mi("{1}")#text(", separates points, and is closed under the conjugation operation ")#mi("{f \\mapsto \\overline{f}}")#text(". Then ")#mi("{{\\mathcal A}}")#text(" is dense in ")#mi("{C(X \\rightarrow {\\bf C})}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 44")]#text(" Let ")#mi("{{\\mathcal T} \\subset C({\\bf R}/{\\bf Z} \\rightarrow {\\bf C})}")#text(" be the space of trigonometric polynomials ")#mi("{x \\mapsto \\sum_{n=-N}^N c_n e^{2\\pi i n x}}")#text(" on the unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(", where ")#mi("{N \\geq 0}")#text(" and the ")#mi("{c_n}")#text(" are complex numbers. Show that ")#mi("{{\\mathcal T}}")#text(" is dense in ")#mi("{C({\\bf R}/{\\bf Z} \\rightarrow {\\bf C})}")#text(" (with the uniform topology), and that ")#mi("{{\\mathcal T}}")#text(" is dense in ")#mi("{L^p({\\bf R}/{\\bf Z} \\rightarrow {\\bf C})}")#text(" (with the ")#mi("{L^p}")#text(" topology) for all ")#mi("{0 < p < \\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 45")]#text(" Let ")#mi("{X}")#text(" be a locally compact Hausdorff space that is ")#mi("{\\sigma}")#text("-compact, and let ")#mi("{{\\mathcal A}}")#text(" be a sub-algebra of ")#mi("{C(X \\rightarrow {\\bf R})}")#text(" which separates points and contains the identity function. Show that for every function ")#mi("{f \\in C(X \\rightarrow {\\bf R})}")#text(" there exists a sequence ")#mi("{f_n \\in {\\mathcal A}}")#text(" which converges to ")#mi("{f}")#text(" uniformly on compact subsets of ")#mi("{X}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 46")]#text(" Let ")#mi("{X, Y}")#text(" be compact Hausdorff spaces. Show that every function ")#mi("{f \\in C( X \\times Y \\rightarrow {\\bf R})}")#text(" can be expressed as the uniform limit of functions of the form ")#mi("{(x,y) \\mapsto \\sum_{j=1}^k f_j(x) g_j(y)}")#text(", where ")#mi("{f_j \\in C(X \\rightarrow {\\bf R})}")#text(" and ")#mi("{g_j \\in C(Y \\rightarrow {\\bf R})}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 47")]#text(" Let ")#mi("{(X_\\alpha)_{\\alpha \\in A}}")#text(" be a family of compact Hausdorff spaces, and let ")#mi("{X := \\prod_{\\alpha \\in A} X_\\alpha}")#text(" be the product space (with the product topology). Let ")#mi("{f \\in C(X \\rightarrow {\\bf R})}")#text(". Show that ")#mi("{f}")#text(" can be expressed as the uniform limit of continuous functions ")#mi("{f_n}")#text(", each of which only depend on finitely many of the coordinates in ")#mi("{A}")#text(", thus there exists a finite subset ")#mi("{A_n}")#text(" of ")#mi("{A}")#text(" and a continuous function ")#mi("{g_n \\in C(\\prod_{\\alpha \\in A_n} X_\\alpha \\rightarrow {\\bf R})}")#text(" such that ")#mi("{f_n( (x_\\alpha)_{\\alpha \\in A} ) = g_n( (x_\\alpha)_{\\alpha \\in A_n} )}")#text(" for all ")#mi("{(x_\\alpha)_{\\alpha \\in A} \\in X}")#text(".")
]

#text("One useful application of the Stone-Weierstrass theorem is to demonstrate separability of spaces such as ")#mi("{C(X)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 48")]#text(" Let ")#mi("{X}")#text(" be a compact metric space. Then ")#mi("{C(X \\rightarrow {\\bf C})}")#text(" and ")#mi("{C(X \\rightarrow {\\bf R})}")#text(" are separable.")
]

#emph[#text("Proof:")]#text(" It suffices to show that ")#mi("{C(X \\rightarrow {\\bf R})}")#text(" is separable. By Lemma 4 of ")#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/")[#text("Notes 10")]#text(", ")#mi("{X}")#text(" has a countable dense subset ")#mi("{x_1,x_2,\\ldots}")#text(". By Urysohn’s lemma, for each ")#mi("{n, m \\geq 1}")#text(" we can find a function ")#mi("{\\psi_{n,m} \\in C(X \\rightarrow {\\bf R})}")#text(" which equals ")#mi("{1}")#text(" on ")#mi("{B(x_n,1/m)}")#text(" and is supported on ")#mi("{B(x_n,2/m)}")#text(". The ")#mi("{\\psi_{n,m}}")#text(" can then easily be verified to separate points, and so by the Stone-Weierstrass theorem, the algebra of polynomial combinations of the ")#mi("{\\psi_{n,m}}")#text(" in ")#mi("{C(X \\rightarrow {\\bf R})}")#text(" are dense; this implies that the algebra of ")#emph[#text("rational")]#text(" polynomial combinations of the ")#mi("{\\psi_{n,m}}")#text(" are dense, and the claim follows. ")#mi("\\Box")

#text("Combining this with the Riesz representation theorem and the sequential ")#link("http://en.wikipedia.org/wiki/Banach%E2%80%93Alaoglu_theorem")[#text("Banach-Alaoglu theorem")]#text(", we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 49")]#text(" If ")#mi("{X}")#text(" is a compact metric space, then the closed unit ball of ")#mi("{M(X)}")#text(" is sequentially compact in the vague topology.")
]

#text("Combining this with Theorem ")#link(<tao-f916a6b54fccf4fbdce5>)[#text("21")]#text(", we conclude a special case of ")#link("http://en.wikipedia.org/wiki/Prokhorov%27s_theorem")[#text("Prokhorov’s theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 50 (Prokhorov’s theorem, compact case)")]#text(" Let ")#mi("{X}")#text(" be a compact metric space, and let ")#mi("{\\mu_n}")#text(" be a sequence of Borel (hence Radon) probability measures on ")#mi("{X}")#text(". Then there exists a subsequence of ")#mi("{\\mu_n}")#text(" which converge vaguely to another Borel probability measure ")#mi("{\\mu}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 51 (Prokhorov’s theorem, non-compact case)")]#text(" Let ")#mi("{X}")#text(" be a locally compact metric space which is ")#mi("{\\sigma}")#text("-compact, and let ")#mi("{\\mu_n}")#text(" be a sequence of Borel probability measures. We assume that the sequence ")#mi("{\\mu_n}")#text(" is ")#link("http://en.wikipedia.org/wiki/Tightness_of_measures")[#text("tight")]#text(", which means that for every ")#mi("{\\varepsilon > 0}")#text(" there exists a compact set ")#mi("{K}")#text(" such that ")#mi("{\\mu_n(X \\backslash K) \\leq \\varepsilon}")#text(" for all ")#mi("{n}")#text(". Show that there is a subsequence of ")#mi("{\\mu_n}")#text(" which converges vaguely to another Borel probability measure ")#mi("{\\mu}")#text(". If tightness is not assumed, show that there is a subsequence which converges vaguely to a non-negative Borel measure ")#mi("{\\mu}")#text(", but give an example to show that this measure need not be a probability measure.")
]

#text("This theorem can be used to establish ")#link("http://en.wikipedia.org/wiki/Helly%27s_selection_theorem")[#text("Helly’s selection theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 52 (Helly’s selection theorem)")]#text(" Let ")#mi("{f_n: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a sequence of functions whose ")#link("http://en.wikipedia.org/wiki/Bounded_variation")[#text("total variation")]#text(" is uniformly bounded in ")#mi("{n}")#text(", and which is bounded at one point ")#mi("{x_0 \\in {\\bf R}}")#text(" (i.e. ")#mi("{\\{ f_n(x_0): n=1,2,\\ldots\\}}")#text(" is bounded). Show that there exists a subsequence of ")#mi("{f_n}")#text(" which converges pointwise almost everywhere on compact subsets of ")#mi("{{\\bf R}}")#text(". (")#emph[#text("Hint:")]#text(" one can deduce this from Prokhorov’s theorem using the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_calculus")[#text("fundamental theorem of calculus")]#text(" for functions of bounded variation.)")
]

#heading(level: 1)[#strong[#text(" — 4. The commutative Gelfand-Naimark theorem (optional) — ")]]

#text("One particularly beautiful application of the machinery developed in the last few notes is the commutative ")#link("http://en.wikipedia.org/wiki/Gelfand%E2%80%93Naimark_theorem")[#text("Gelfand-Naimark theorem")]#text(", that classifies commutative ")#link("http://en.wikipedia.org/wiki/C*-algebra")[#mi("{C^*}")#text("-algebras")]#text(", and is of importance in spectral theory, operator algebras, and quantum mechanics.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 53")]#text(" A ")#emph[#text("complex Banach algebra")]#text(" is a complex Banach space ")#mi("{A}")#text(" which is also a complex algebra, such that ")#tao-math("{\\left\\|xy\\right\\| \\leq \\left\\|x\\right\\| \\left\\|y\\right\\|}", block: false)#text(" for all ")#mi("{x,y \\in A}")#text(". An algebra is ")#emph[#text("unital")]#text(" if it contains a multiplicative identity ")#mi("{1}")#text(", and ")#emph[#text("commutative")]#text(" if ")#mi("{xy=yx}")#text(" for all ")#mi("{x,y \\in A}")#text(". A ")#link("http://en.wikipedia.org/wiki/C*-algebra")[#mi("{C^*}")#text("-algebra")]#text(" is a complex Banach algebra with an anti-homomorphism map ")#mi("{x \\mapsto x^*}")#text(" from ")#mi("{A}")#text(" to ")#mi("{A}")#text(" (thus ")#mi("{(xy)^* = y^* x^*}")#text(", ")#mi("{(x+y)^*=x^*+y^*}")#text(", and ")#mi("{(cx)^* = \\overline{c} x}")#text(" for ")#mi("{x,y \\in A}")#text(" and ")#mi("{c \\in {\\bf C}}")#text(") which is an isometry (thus ")#tao-math("{\\left\\|x^*\\right\\|=\\left\\|x\\right\\|}", block: false)#text(" for all ")#mi("{x \\in A}")#text("), an involution (thus ")#mi("{(x^*)^*=x}")#text(" for all ")#mi("{x \\in A}")#text("), and obeys the ")#emph[#mi("{C^*}")#text(" identity")]#text(" ")#tao-math("{\\left\\|x^* x \\right\\| = \\left\\|x\\right\\|^2}", block: false)#text(" for all ")#mi("{x \\in A}")#text(".")

#text("A ")#emph[#text("homomorphism")]#text(" ")#mi("{\\phi: A \\rightarrow B}")#text(" between two ")#mi("{C^*}")#text("-algebras is a continuous algebra homomorphism such that ")#mi("{\\phi(x^*) =\\phi(x)^*}")#text(" for all ")#mi("{x \\in X}")#text(". An ")#emph[#text("isomorphism")]#text(" is an homomorphism whose inverse exists and is also a homomorphism; two ")#mi("{C^*}")#text("-algebras are ")#emph[#text("isomorphic")]#text(" if there exists an isomorphism between them.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 54")]#text(" If ")#mi("{H}")#text(" is a Hilbert space, and ")#mi("{B(H \\rightarrow H)}")#text(" is the algebra of bounded linear operators on this space, with the adjoint map ")#mi("{T \\mapsto T^*}")#text(" and the operator norm, show that ")#mi("{B(H \\rightarrow H)}")#text(" is a unital ")#mi("{C^*}")#text("-algebra (not necessarily commutative). Indeed, one can think of ")#mi("{C^*}")#text("-algebras as an abstraction of a space of bounded linear operators on a Hilbert space (this is basically the content of the non-commutative ")#link("http://en.wikipedia.org/wiki/Gelfand%E2%80%93Naimark_theorem")[#text("Gelfand-Naimark theorem")]#text(", which we will not discuss here).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 55")]#text(" ")#metadata(none) <tao-ee58dc2ac168ba351fec>#text(" If ")#mi("{X}")#text(" is a compact Hausdorff space, show that ")#mi("{C(X \\rightarrow {\\bf C})}")#text(" is a unital commutative ")#mi("{C^*}")#text("-algebra, with involution ")#mi("{f^* := \\overline{f}}")#text(".")
]

#text("The remarkable (unital commutative) Gelfand-Naimark theorem asserts the converse statement to Exercise ")#link(<tao-ee58dc2ac168ba351fec>)[#text("55")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 56 (Unital commutative Gelfand-Naimark theorem)")]#text(" ")#metadata(none) <tao-618f8819eeae62b32f89>#text(" Every unital commutative ")#mi("{C^*}")#text("-algebra ")#mi("{A}")#text(" is isomorphic to ")#mi("{C(X \\rightarrow {\\bf C})}")#text(" for some compact Hausdorff space ")#mi("{X}")#text(".")
]

#text("There are analogues of this theorem for non-unital or non-commutative ")#mi("{C^*}")#text("-algebras, but for simplicity we shall restrict attention to the unital commutative case. We first need some spectral theory.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 57")]#text(" Let ")#mi("{A}")#text(" be a unital Banach algebra. Show that if ")#mi("{x \\in A}")#text(" is such that ")#tao-math("{\\left\\|x-1\\right\\|<1}", block: false)#text(", then ")#mi("{x}")#text(" is invertible. (")#emph[#text("Hint:")]#text(" use ")#link("http://en.wikipedia.org/wiki/Neumann_series")[#text("Neumann series")]#text(".) Conclude that the space ")#mi("{A^\\times \\subset A}")#text(" of invertible elements of ")#mi("{A}")#text(" is open.")
]

#text("Define the spectrum ")#mi("{\\sigma(x)}")#text(" of an element ")#mi("{x \\in A}")#text(" to be the set of all ")#mi("{z \\in {\\bf C}}")#text(" such that ")#mi("{x - z 1}")#text(" is not invertible.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 58")]#text(" ")#metadata(none) <tao-8ce3e71ef8635d2bf279>#text(" If ")#mi("{A}")#text(" is a unital Banach algebra and ")#mi("{x \\in A}")#text(", show that ")#mi("{\\sigma(x)}")#text(" is a compact subset of ")#mi("{{\\bf C}}")#text(" that is contained inside the disk ")#tao-math("{\\{ z \\in {\\bf C}: \\left|z\\right| \\leq \\left\\|x\\right\\| \\}}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 59 (Beurling-Gelfand spectral radius formula)")]#text(" If ")#mi("{A}")#text(" is a unital Banach algebra and ")#mi("{x \\in A}")#text(", show that ")#mi("{\\sigma(x)}")#text(" is non-empty with ")#tao-math("{\\sup \\{ \\left|z\\right|: z \\in \\sigma(x) \\} = \\lim_{n \\rightarrow \\infty} \\left\\|x^n\\right\\|^{1/n}}", block: false)#text(". (")#emph[#text("Hint:")]#text(" To get the upper bound, observe that if ")#mi("{x^n-z^n1}")#text(" is invertible for some ")#mi("{n \\geq 1}")#text(", then so is ")#mi("{x-zI}")#text(", then use Exercise ")#link(<tao-8ce3e71ef8635d2bf279>)[#text("58")]#text(". To get the lower bound, first observe that for any ")#mi("{\\lambda \\in A^*}")#text(", the function ")#mi("{f_\\lambda: z \\mapsto \\lambda( (x-zI)^{-1} )}")#text(" is holomorphic on the complement of ")#mi("{\\sigma(x)}")#text(", which is already enough (with ")#link("http://en.wikipedia.org/wiki/Liouville%27s_theorem_(complex_analysis)")[#text("Liouville’s theorem")]#text(") to show that ")#mi("{\\sigma}")#text(" is non-empty. Let ")#tao-math("{r > \\sup \\{ \\left|z\\right|: z \\in \\sigma(x) \\}}", block: false)#text(" be arbitrary, then use Laurent series to show that ")#tao-math("{\\left|\\lambda( x^n )\\right| \\leq C_{\\lambda,r} r^n}", block: false)#text(" for all ")#mi("{n}")#text(" and some ")#mi("{C_{\\lambda,r}}")#text(" independent of ")#mi("{n}")#text(". Then divide by ")#mi("{r^n}")#text(" and use the ")#link("http://en.wikipedia.org/wiki/Uniform_boundedness_principle")[#text("uniform boundedness principle")]#text(" to conclude.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 60 (")#mi("{C^*}")#text("-algebra spectral radius formula)")]#text(" ")#metadata(none) <tao-2500b17660d82effbaf6>#text(" Let ")#mi("{A}")#text(" be a unital ")#mi("{C^*}")#text("-algebra. Show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|x \\right\\| = \\left\\| (x^* x)^{2^n} \\right\\|^{1/2^{n+1}} = \\left\\| (x x^*)^{2^n} \\right\\|^{1/2^{n+1}}", block: true)]]

#text("for all ")#mi("{n \\geq 1}")#text(" and ")#mi("{x \\in A}")#text(". Conclude that any homomorphism between ")#mi("{C^*}")#text("-algebras has operator norm at most ")#mi("{1}")#text(". Also conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sup \\{ \\left|z\\right|: z \\in \\sigma(x) \\} = \\left\\|x\\right\\|", block: true)]]

#text("when ")#mi("{x}")#text(" is self-adjoint.")
]

#text("The next important concept is that of a ")#link("http://en.wikipedia.org/wiki/Character_(mathematics)")[#text("character")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 61")]#text(" Let ")#mi("{A}")#text(" be a unital commutative ")#mi("{C^*}")#text("-algebra. A ")#emph[#text("character")]#text(" of ")#mi("{A}")#text(" is an element ")#mi("{\\lambda \\in A^*}")#text(" in the dual Banach space such that ")#mi("{\\lambda(xy) = \\lambda(x)\\lambda(y)}")#text(", ")#mi("{\\lambda(1)=1}")#text(", and ")#mi("{\\lambda(x^*) = \\overline{\\lambda(x)}}")#text(" for all ")#mi("{x,y \\in A}")#text("; equivalently, a character is a homomorphism from ")#mi("{A}")#text(" to ")#mi("{{\\bf C}}")#text(" (viewed as a (unital) ")#mi("{C^*}")#text(" algebra). We let ")#mi("{\\hat A \\subset A^*}")#text(" be the space of all characters; this space is known as the ")#emph[#text("spectrum")]#text(" of ")#mi("{A}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 62")]#text(" If ")#mi("{A}")#text(" is a unital commutative ")#mi("{C^*}")#text("-algebra, show that ")#mi("{\\hat A}")#text(" is a compact Hausdorff subset of ")#mi("{A^*}")#text(" in the weak-* topology. (")#emph[#text("Hint:")]#text(" first use the spectral radius formula to show that all characters have operator norm ")#mi("{1}")#text(", then use the ")#link("http://en.wikipedia.org/wiki/Banach%E2%80%93Alaoglu_theorem")[#text("Banach-Alaoglu theorem")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 63")]#text(" Define an ")#link("http://en.wikipedia.org/wiki/Ideal_(ring_theory)")[#text("ideal")]#text(" of a unital commutative ")#mi("{C^*}")#text("-algebra ")#mi("{A}")#text(" to be a proper subspace ")#mi("{I}")#text(" of ")#mi("{A}")#text(" such that ")#mi("{xy, yx \\in I}")#text(" for all ")#mi("{x \\in I}")#text(" and ")#mi("{y \\in A}")#text(". Show that if ")#mi("{\\lambda \\in \\hat A}")#text(", then the ")#link("http://en.wikipedia.org/wiki/Kernel_(linear_operator)")[#text("kernel")]#text(" ")#mi("{\\lambda^{-1}(\\{0\\})}")#text(" is a maximal ideal in ")#mi("{A}")#text("; conversely, if ")#mi("{I}")#text(" is a maximal ideal in ")#mi("{A}")#text(", show that ")#mi("{I}")#text(" is closed, and there is exactly one ")#mi("{\\lambda \\in \\hat A}")#text(" such that ")#mi("{I = \\lambda^{-1}(\\{0\\})}")#text(". Thus the spectrum of ")#mi("{A}")#text(" can be canonically identified with the space of maximal ideals in ")#mi("{A}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 64")]#text(" Let ")#mi("{X}")#text(" be a compact Hausdorff space, and let ")#mi("{A}")#text(" be the ")#mi("{C^*}")#text("-algebra ")#mi("{A := C(X \\rightarrow {\\bf C})}")#text(". Show that for each ")#mi("{x \\in X}")#text(", the operation ")#mi("{\\lambda_x: f \\mapsto f(x)}")#text(" is a character of ")#mi("{A}")#text(". Show that the map ")#mi("{\\lambda: x \\mapsto \\lambda_x}")#text(" is a homeomorphism from ")#mi("{X}")#text(" to ")#mi("{\\hat A}")#text("; thus the spectrum of ")#mi("{C(X \\rightarrow {\\bf C})}")#text(" can be canonically identified with ")#mi("{X}")#text(". (")#emph[#text("Hint:")]#text(" use Exercise ")#link(<tao-4230a1e7bf8cb32f2d83>)[#text("42")]#text(" to show the surjectivity of ")#mi("{\\lambda}")#text(", Urysohn’s lemma to show injectivity, and Corollary 2 of ")#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/")[#text("Notes 10")]#text(" to show the homeomorphism property.)")
]

#text("Inspired by the above exercise, we define the ")#link("http://en.wikipedia.org/wiki/Gelfand_representation")[#text("Gelfand representation")]#text(" ")#mi("{\\hat{}: A \\mapsto C(\\hat A \\rightarrow {\\bf C})}")#text(", by the formula ")#mi("{\\hat x(\\lambda) := \\lambda(x)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 65")]#text(" ")#metadata(none) <tao-c5a4dd8733e10c84f8ac>#text(" Show that if ")#mi("{A}")#text(" is a unital commutative ")#mi("{C^*}")#text("-algebra, then the Gelfand representation is a homomorphism of ")#mi("{C^*}")#text("-algebras.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 66")]#text(" ")#metadata(none) <tao-97578395f48870186c10>#text(" Let ")#mi("{x}")#text(" be a non-invertible element of a unital commutative ")#mi("{C^*}")#text("-algebra ")#mi("{A}")#text(". Show that ")#mi("{\\hat x}")#text(" vanishes at some ")#mi("{\\lambda \\in \\hat A}")#text(". (")#emph[#text("Hint:")]#text(" the set ")#mi("{\\{ xy: y \\in A \\}}")#text(" is a proper ideal of ")#mi("{A}")#text(", and thus by ")#link("http://en.wikipedia.org/wiki/Zorn%27s_lemma")[#text("Zorn’s lemma")]#text(" is contained in a maximal ideal.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 67")]#text(" ")#metadata(none) <tao-b3144fef4e2fa695f890>#text(" Show that if ")#mi("{A}")#text(" is a unital commutative ")#mi("{C^*}")#text("-algebra, then the Gelfand representation is an isometry. (")#emph[#text("Hint:")]#text(" use Exercise ")#link(<tao-2500b17660d82effbaf6>)[#text("60")]#text(" and Exercise ")#link(<tao-97578395f48870186c10>)[#text("66")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 68")]#text(" Use the complex Stone-Weierstrass theorem and Exercises ")#link(<tao-c5a4dd8733e10c84f8ac>)[#text("65")]#text(", ")#link(<tao-b3144fef4e2fa695f890>)[#text("67")]#text(" to conclude the proof of Theorem ")#link(<tao-618f8819eeae62b32f89>)[#text("56")]#text(".")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (110)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d24cb1f8b61e562dc3e31312f667c4f5cb30dbb07513346970a841008d40f3f9-1558e32e64d46f4db5280433cac4fad9382473308f599bbe9f64c6d5540a9830.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-448162")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2015")])]

#text("In Lemma 9, you don’t really need to equip ")#mi("C_c")#text(" with a topology in order to show that every linear functional ")#mi("I : C_c \\to \\mathbb{R}")#text(" can be written as a difference of two positive functionals ")#mi("I^+")#text(" and ")#mi("I^-")#text(". If ")#mi("C_c")#text(" is equipped with the uniform norm then ")#mi("I")#text(" is continuous if and only if the corresponding Radon measure is a finite signed measure. However, we can also equip ")#mi("C_c")#text(" with a locally convex topology (see ")#link("http://en.wikipedia.org/wiki/Radon_measure#Measures")[#text("http://en.wikipedia.org/wiki/Radon_measure#Measures")]#text("). In this case, we have more continuous functionals, namely signed Radon measures that can be also infinite on one side or even “real” Radon measures, i.e. differences of positive Radon measures, that cannot be written in terms of a set function.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37f47cfb6fb19c5bb4b8296e04f78586af9cf04532d4a62569d53fbe4fed4748-7e255c6b999d815e584fae266dc3e13283967679af2bf6379d3b7a748b06e1b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bob")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-454295")[#strong[#text("Bob")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2015")])]

#text("Dear Prof. Tao,")#linebreak()#text(" can you give me a reference about the proof of Riesz representation theorem via creating L^1 as the completion of C_c(X)?")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ea5260427311bd048e34e87c9219ecb23210d05bc813f3522197c5afef1e580-0cf91c1bf528b66c78a69ced98cd772615b5964a0b32d4da40d3c4d9d647f729.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of eshetu")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-454320")[#strong[#text("eshetu")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2015")])]

#text("Could anyone help me the proof of theorem 15? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 2: Product measures and independence | What's new")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-460458")[#strong[#text("275A, Notes 2: Product measures and independence | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2015")])]

#text("[…] for any compact separable metric spaces. Radon measures are often used in real analysis (see e.g. these lecture notes) but we will not develop their theory further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 4: The central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-461363")[#strong[#text("275A, Notes 4: The central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2015")])]

#text("[…] distribution (this is a consequence of the Riesz representation theorem, discussed for instance in this blog post). As a consequence of the insensitivity of convergence in distribution to equivalence in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-461859")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2015")])]

#text("The formulation of partitions of unity looks quite different from the ones from the Wikipedia link you gave.")

#text("What is essential with using the “closed” cover in Lemma 6? Can one formulate it by using only “open” cover?")

#text("I’ve seen the ")#emph[#text("smooth partitions of unity")]#text(" in PDE (for example in Evans’s book) which says that if ")#mi("\\{V_i\\}")#text(" is an open cover of an open subset ")#mi("U")#text(" of ")#mi("{\\bf R}^d")#text(", then there exists ")#mi("\\zeta_i:U\\to[0,1]")#text(" such that ")#mi("\\zeta_i\\in C_c^\\infty(V_i)")#text(" and the sum of ")#mi("\\zeta_i")#text(" equals to ")#mi("1")#text(" pointwise on $U$. Can this be deduced from Lemma 6 (and suitable mollification)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-461860")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2015")])]

#text("If the space is locally compact Hausdorff, then any open cover will have a partition of unity with compactly supported functions, and the additional conditions in Lemma 6 are not needed. (Actually, this would make a good additional exercise here, which I may add to a future edition of the text.) But in the normal case, I believe some condition like this is necessary.")

#text("One can obtain a smooth partition of unity from a continuous one by convolving all the functions by an smooth approximation to the identity (with the exact choice of mollifier dependent on the location, as the open sets may become increasingly small in diameter at infinity), and then dividing out by the sum as before in order to recover the property of summing to one.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-462863")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2015")])]

#text("In the proof of the Urysohn lemma, can")

#mi("f(x) := \\sup \\{ q: x \\in U_q \\} = \\inf \\{ q: x \\not \\in K_q \\}")

#text("be replaced with")

#mi("f(x) := \\sup \\{ q: x \\in K_q \\}")

#text("or")

#mi("f(x)= \\inf \\{ q: x \\not \\in U_q \\}")#text("?")

#emph[#text("[Yes, although these descriptions of ")#mi("f")#text(" are not as useful as the first two for establishing continuity. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-466431")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2016")])]

#text("Do you have a reference for part 4 (The commutative Gelfand-Naimark theorem (optional) ) in this note which is also similar to the way you represent it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-466453")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2016")])]

#text("I adapted this material from various texts on non-commutative Gelfand theory (of which there are several), specialising to the commutative case. I don’t know of a text that focuses primarily on the commutative case though.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-466433")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2016")])]

#text("Does the “spectrum” in Definition 16 have anything to do with the one in ")#link("https://en.wikipedia.org/wiki/Spectrum_(functional_analysis)#Definition")[#text("https://en.wikipedia.org/wiki/Spectrum_(functional_analysis)#Definition")]#linebreak()#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-466451")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2016")])]

#text("This is the Gelfand spectrum: ")#link("https://en.wikipedia.org/wiki/Gelfand_representation#The_spectrum_of_a_commutative_C.2A-algebra")[#text("https://en.wikipedia.org/wiki/Gelfand_representation#The_spectrum_of_a_commutative_C.2A-algebra")]#text(" of a function space, rather than the spectrum of a linear operator. In some cases there is a relationship; for instance the Gelfand spectrum of the convolution algebra ")#mi("L^1({\\bf R}^n)")#text(" is naturally associated to the joint spectrum of the infinitesimal translation operators ")#mi("\\frac{\\partial}{\\partial x_1}, \\dots, \\frac{\\partial}{\\partial x_n}")#text(". In particular, both concepts can be viewed as capturing a notion of the available “frequencies” in a function space or linear operator. However in general there is not much of a direct relationship between the two.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-466504")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2016")])]

#text("In ")#link("http://math.oregonstate.edu/~holladwi/banach_algebras.pdf")[#text("http://math.oregonstate.edu/~holladwi/banach_algebras.pdf")]#text(" , the Gelfand-Naimark Theorem (Theorem 50) is called as the “abstract spectral theorem”, in which the spectrum is the set of characters. Then Gelfand-Naimark is used in the proof of Theorem 51 (spectral theorem), in which the spectrum of a linear operator appears.")

#text("Is this also related to what you said in the comment?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-466438")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2016")])]

#text("Do Definition 16 and Exercise 39 remain the same if one replaces ")#mi("C^*")#text("-algebra with Banach-algebra and drops the condition ")#mi("\\lambda(x^*)=\\overline{\\lambda(x)}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-466452")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2016")])]

#text("I believe one can prove something of this form with the aid of the Riesz representation theorem, but I haven’t checked the details.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc2dd4ebeefc8f65e28a9c9451011d784b1081d92dd66b32a550061eaa39c9a7-355f8ffe79f68f85468dad0c9a96b005398fdabe28bcea7a6de74736a6df92bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-470122")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2016")])]

#text("Exercise 11 does not need to hold for non-Hausdorff ")#mi("X")#text(". A counterexample being the two point space with one point being open but not closed. All continuous functions are constant, but there are nonconstant semicontinuos ones.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-470150")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2016")])]

#text("Sorry, could you elaborate on why this is a counterexample to either part of Exercise 11? Note that part 2 of this exercise has the additional assumption that ")#mi("X")#text(" is normal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc2dd4ebeefc8f65e28a9c9451011d784b1081d92dd66b32a550061eaa39c9a7-355f8ffe79f68f85468dad0c9a96b005398fdabe28bcea7a6de74736a6df92bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-470153")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2016")])]

#text("It’s a little nitpicky, but by the definition given in these notes, this space is normal (while not fulfilling part 2). It is just required that you can separate disjoint closed sets by disjoint open neighborhoods, which is automatically the case here, since one of the closed sets must be empty.")

#emph[#text("[Ah, I see now. Correction added, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5a8cdb11fef7e643673647c6d7608d249ab5eafcb688c107a2240fa42bb4e96c-31f6445afd1c3986e98c9ef59332679f6c081fb95bf9fb5988ae2ebfb97f3045.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zhche")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-474283")[#strong[#text("zhche")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2016")])]

#text("Dear Prof Tao,")

#text("As for exercise 15, the uniqueness of the minimal decomposition is quite easy to prove. But for the existence part, I think for any two different decompositions ")#mi("I=I^+_1-I^-_1")#text(" and ")#mi("I=l^+_2-I^-_2")#text(", they only need to satisfy that difference ")#mi("I^+_1-I^+_2=I^-_1-I^-_2")#text(" is a linear functional, not necessarily the value ")#mi("I^+_1(f)-I^+_2(f)")#text(" be positive for each ")#mi("f")#text(" in ")#mi("C_c(X)")#text(". Then the sense of ordering does not necessarily for any two decompositions, i.e., there may be no minimal decompositions. Am I understanding right ?")

#text("Regards")#linebreak()#text(" Che Zhihua")

#emph[#text("[It is possible for a partial order to have a minimal element even if it fails to be a total order. For instance, the set of all subsets of a given set ")#mi("X")#text(" (partially ordered by set inclusion) has a minimal element ")#mi("\\emptyset")#text(" even though most pairs ")#mi("A,B")#text(" of subsets of ")#mi("X")#text(" are incomparable. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5a8cdb11fef7e643673647c6d7608d249ab5eafcb688c107a2240fa42bb4e96c-31f6445afd1c3986e98c9ef59332679f6c081fb95bf9fb5988ae2ebfb97f3045.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zhche")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-474310")[#strong[#text("zhche")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2016")])]

#text("Yes, I found it partial order. So this exercise means to want us to prove that this poset HAS a least element, e.g., prove it is bounded lattice ? Then this exercise is not that trivial.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c06b5c608061b3433364d7a08c276448981d7dbe3ec5a42a3c2cf5097f6a6116-b2064c0da56b72183b36a8e311c8403011196cba9557b86b4ddceb8d838b15a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-474836")[#strong[#text("Ian")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2016")])]

#text("Professor Tao:")

#text("Concerning the proof of Lusin’s Theorem, could you please explain the use of Exercise 10? It seems to me that this exercise produces a function that agrees with ")#mi("f")#text(" only in (most of) its compact support, but doesn’t really guarantee anything on the whole space.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-474850")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2016")])]

#text("One can multiply the function produced by Exercise 10 with a cutoff function coming from Urysohn’s lemma to make the support of that function only slightly larger than the support of ")#mi("f")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: The central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-478162")[#strong[#text("254A, Notes 2: The central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("[…] distribution (this is a consequence of the Riesz representation theorem, discussed for instance in this blog post). As a consequence of the insensitivity of convergence in distribution to equivalence in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A: Problem solving strategies | What's new")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-511371")[#strong[#text("245A: Problem solving strategies | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2019")])]

#text("[…] is true for a class of functions that is large enough to separate points in the space, so that the Stone-Weierstrass theorem may be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-513732")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2019")])]

#text("Dear Prof. Tao (or anyone reading this),")

#text("the proof of Riesz’ theorem that you gave relied on the ")#mi("\\sigma")#text("-compactness hypothesis, because only this hypothesis allowed the transition from the compact to the general case. Is it true that one might drop this hypothesis by resorting to more general means of summation (such as integration against a counting measure)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-539276")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2020")])]

#text("I have seen a (quite short) proof of Theorem 10 (the complex version) using Zorn’s lemma. But I can only remember the beginning.")

#text("Let ")#mi("h\\in C(X)")#text(" and one wants to show that ")#tao-math("d=\\textrm{dist}(h,A)=\\inf_{f\\in A}\\left\\|h-f\\right\\|=0", block: false)#text(". The proof draws a contradiction by assuming that ")#mi("d>0")#text(".")

#text("It then defines for any closed ")#mi("K\\subset X")#text(" that")

#tao-math("d_K:=\\inf_{f\\in A}\\sup_{x\\in K}\\left|f(x)-h(x)\\right|", block: false)#text(".")

#text("Define ")#mi("\\mathcal{F}=\\{K\\subset X: K \\textrm{ closed } d_K=d\\}")#text(".")

#text("Zorn’s lemma implies (I don’t know how) that there exists ")#mi("K_0\\in\\mathcal{F}")#text(" minimal with respect to ")#mi("\\subset")#text(" and ")#mi("K_0")#text(" is not a singleton.")

#text("Do anyone know how to finish the proof and where is it possibly from?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-642445")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2022")])]

#text("Dear Prof.Tao: Is Exercise 7 incorrect? Consider the dirac measure at some point as the Radon measure on real line. Then it seems the convergence in $L^\\infty$ only controls the convergence at this point.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-642466")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2022")])]

#text("Actually, the statement is still true in this case! (But one needs the Tietze extension theorem, which is not covered at this stage of the notes, and so this exercise needs to be moved. See the erratum to the book version of this exercise (Exercise 1.10.7) at ")#link("https://terrytao.wordpress.com/books/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/")[#text("https://terrytao.wordpress.com/books/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-642478")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2022")])]

#text("Dear Prof.Tao. How to construct a closed subset as support of measure such that every open set(non-empty) has positive measure. If we just take the union of all open set in $X$ having null measure and the complement of this union is closed but may not be co-null(since this may be an uncountable union), if we just assume second countability, this is OK(but in general locally compact and sigma-compact Hausdorff space may be not normal). But I still don’t understand how to use Tietz extension(since $X$ may be not normal,and if we take one-point Alexandroff compactification, then the closed set may be not closed any more). Also how Tietz extension controls the growth at infinity? Would you elaborate more? It seems this problem has been posted also here :")#link("https://math.stackexchange.com/questions/1576634/the-closure-of-c-c-in-l-infty-is-c-0")[#text("https://math.stackexchange.com/questions/1576634/the-closure-of-c-c-in-l-infty-is-c-0")]#text(" But the discussion seems not conclusive.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-643098")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2022")])]

#text("Is Exercise15 correct？Whether ")#mi("f")#text(" should be positive instead?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-643137")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2022")])]

#text("It is correct. ")#mi("f")#text(" need not be positive.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-674000")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2023")])]

#text("Perhaps the Wikipedia page linked to Riesz representation theorem should be ")#link("https://en.wikipedia.org/wiki/Riesz–Markov–Kakutani_representation_theorem")[#text("https://en.wikipedia.org/wiki/Riesz–Markov–Kakutani_representation_theorem")]#text(" rather than the one related to Hilbert space?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-692307")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2026")])]

#text("Dr Tao,")

#text("There is a small typo in Definition61, “…is be…”")

#text("In analysis we have encounter distinct types of representation theorems. Take Riesz representation theorem for example, I wonder what Riesz representation theorem “represents”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-692467")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2026")])]

#text("Thanks for the correction.")

#text("I have ")#link("https://claude.ai/share/ca10ee28-fc91-4501-9af2-5bcdac0c4a23")[#text("outsourced your question to an AI")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-692478")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2026")])]

#text("Thanks for your reply.")

#text("I understand what ")#emph[#text("representation")]#text(" means now. However, I have carefully studied the proof of this theorem, yet I still cannot grasp the core idea behinidthe proof. I would like to ask: What is the strategy of this proof?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-692482")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2026")])]

#text("I am ")#link("https://claude.ai/share/ca10ee28-fc91-4501-9af2-5bcdac0c4a23")[#text("outsourcing this question to (the same) AI")]#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-692580")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2026")])]

#text("Prof Tao:")

#text("The property of being ")#emph[#text("normal")]#text(" is not preserved under passage to subspaces. Why is it that among topological properties, say the Hausdorff property can be inherited by subspaces, while normality cannot? What is the deeper reason behind this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-692588")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2026")])]

#text("I am ")#link("https://claude.ai/share/b5e53ead-8883-42d5-8660-f769b2112a03")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-692683")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2026")])]

#text("In Theorem 12 you mentioned that ”…We do this by the ")#emph[#text("standard analysis trick")]#text("…”")

#text("The iterative argument in this proof is remarkably ingenious, and it reminds me of the bootstrap method in probability theory or statistics. I wonder if there is any commonality between the ideas behind the two?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-692688")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2026")])]

#text("I am ")#link("https://claude.ai/share/e932295f-a885-48f3-9f99-c1cf184b7541")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-692752")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2026")])]

#text("Dr Tao, In Definition 8, why would the set K in the inner regularity chosen to be compact rather than closed? Since the set U is open in the outer regularity, so maybe using the dual concepts of open sets and closed sets can be more natural(?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-692769")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2026")])]

#text("As it turns out, measure theory isn’t perfectly symmetric with regards to “approximation from below” and “approximation from above” (except in settings where the entire space is finite measure, in which case one can pass back and forth using complements). When approximating from below, it is more convenient to use sets that are “small” in various senses – and compactness is a natural notion for this, as the very name suggests. Whereas when approximating from above, it is convenient to use sets that are “roomy” in some sense – and open sets are the natural candidate here. The two notions also play well against each other, thanks to the open cover definition of compactness.")

#text("But actually, when one works in inseparable spaces, the “correct” notion of inner regularity does not seem to involve either closed sets or compact sets, but rather compact ")#mi("G_\\delta")#text(" sets (at least in the Hausdorff finite measure setting, and using the Baire sigma algebra over the Borel sigma algebra). See Section 4 of ")#link("https://arxiv.org/abs/2010.00681")[#text("this paper of Jamneshan and myself")]#text(" for more discussion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-693063")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2026")])]

#text("In Theorem 24, the proof relies on converting sets into functions. Is the reason for doing this that sets are difficult to handle, or is it because this allows the use of certain other analytical techniques to deal with functions instead of sets, or is there another reason?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-693079")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2026")])]

#text("See ")#link("https://www.tricki.org/article/Turn_sets_into_functions")[#text("https://www.tricki.org/article/Turn_sets_into_functions")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-693100")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2026")])]

#text("Thank you for the link. I’d like to ask one more technical point: in differential geometry, we would use partitions of unity as a tool for local-to-global arguments. In the proof of Theorem 24, the partition of unity is also used – perhaps these two partitions of unity do not have connections, but when can one expect a partition-of-unity argument to work and why in real anlysis (at least in the case of Theorem 24)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-693104")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2026")])]

#text("Roughly speaking, regularity classes of functions can be classified as either “rigid”, in which analytic continuation type properties are available, or “localizable”, in which partitions of unity are available. Rigid classes include analytic functions, algebraic functions, and polynomials; and localizable classes include smooth functions (or anything rougher than this, e.g., continuous functions). Gevrey classes lie just below the analytic regularity class and are (barely) localizable. As long as one is working at localizable levels of regularity, one expects partition of unity arguments to be useful.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-693218")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2026")])]

#text("Dr Tao:")

#text("I think the proof of Exercise 5 is much more difficult than the proof of Exercise 4-Could you elaborate on why you think the example given by Stone is more natural to you?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-693716")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2026")])]

#text("I’m puzzled by one point in the proof of Theorem 40: why can we derive g_{xy}(y’) ≥ f(y’) – ε for all y’ ∈ an open neighborhood V_{xy} from continuity? Also, is this an application of the technique of “")#emph[#text("create an epsilon of room")]#text("“?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-694187")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2026")])]

#text("Took me 10 minutes to parse the first bullet point of ")#strong[#text("Exercise 5")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-694226")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2026")])]

#text("Dear Dr Tao，")

#text("Why is it that in the definitions of the separation axioms, such as normality, we need “separated by a ")#emph[#text("continuous")]#text(" function” rather than “separated by a function”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-2/#comment-694252")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2026")])]

#text("If one works in the set-theoretic category of arbitrary functions (as opposed to the topological category of continuous functions, or the smooth category of smooth functions, etc.) then any two disjoint sets become separated, due to the existence of ")#link("https://en.wikipedia.org/wiki/Indicator_function")[#text("indicator functions")]#text(".")

#text("In this vein, separation axioms can be viewed as an assertion that, for the given topological space, the topological category “behaves like” the set-theoretic category in various technical senses. (There may well be a category-theoretic perspective that makes this “behave like” assertion far more precise, but I will leave that refinement to experts in category theory.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-36271")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2009")])]

#text("In example one, I guess it should be ”……… absolutely cts with respect to ")#mi("\\mu")#text("” ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-36272")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2009")])]

#text("I gather from exercise 35 that characters are required to be homeomorphisms onto ")#mi("\\mathbb{C}")#text(", and not just to ")#mi("\\mathbb{C}")#text(". Is that correct?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-36273")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2009")])]

#text("Yes; I forgot to mention that characters must preserve the unit, which is equivalent to them being onto (or to them being non-zero). [I assume you meant “homomorphism” rather than “homeomorphism”.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f997fa2ad8839adf0ab215638d34a42be5eb2c2fc7a89d0a4d465fdb314cb49-9a8e97053fad47fd5d9e2f4a445c750d5c2359a3f03c0332cfa773d94338ac41.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max Baroi")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-36275")[#strong[#text("Max Baroi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2009")])]

#text("Yes, I did mean homomorphism. Sorry about that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/087efbd64dbb2bf3003cb0fe9d7cf1229bad84470d1637450d2d5f36eaa73bc9-3cee5444008f795ba5d1dd46a139a06cdd7870234ded3639372d93dcdead54da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mmailliw/william")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-36289")[#strong[#text("mmailliw/william")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2009")])]

#text("I’m pretty sure R^N is metrizable (with the countable product metric), being a countable product of metric spaces; therefore, isn’t it normal (making Exercise 3 false as written)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-36292")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2009")])]

#text("Hmm, right, the argument I had in mind was rubbish. I looked up the proof that ")#mi("N^R")#text(" is non-normal (which was what I was really after); it was surprisingly non-trivial. Still, I’ve outlined how it goes in the updated version of the exercises.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/626e53d46c710500df401cd08527c0d77bc41c025132055eb6b1eff8f8e41115-d87af44ed68cc76739d63ca4c13478d58612e8f3dab93013de42dffa7899abb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-36293")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2009")])]

#text("Here is a simpler if less elementary example of a non-normal but otherwise nice (eg, locally compact Hausdorff) space. Let ")#mi("X=(\\omega+1)\\times(\\omega_1+1)")#text(", where $\\omega+1$ and $\\omega_1+1$ are ordinals with the order topology, and ")#mi("Y=X-\\{(\\omega,\\omega_1)\\}")#text(". Then Y is locally compact Hausdorff since X is compact Hausdorff. However, the disjoint closed sets ")#mi("C=\\omega\\times\\{\\omega_1\\}")#text(" and ")#mi("D=\\{\\omega\\}\\times\\omega_1")#text(" (ie, the “top” and “right” edges of the product) cannot be separated by open sets. Indeed, a neighborhood of C must contain a rectangle ")#mi("\\omega\\times[\\alpha,\\omega_1]")#text(" since for each first coordinate n it contains some ")#mi("[\\alpha_n,\\omega_1]")#text(" and there are only countably many n.")

#text("(If you prefer, you can do the same thing replacing ")#mi("\\omega+1")#text(" by [0,1] and ")#mi("\\omega_1+1")#text(" by the closed long line.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aaed0abc7e358133c38f6cdbe201713e4f795ade6b5a9b50d90dc79fc437b7e6-169ed54092edba23e1076ef1642a3d9e616d91a4ba40bded81b3c34d5d4c29e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anush Tserunyan")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-36334")[#strong[#text("Anush Tserunyan")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("I have some questions about Exercise 4 (R^R is non-normal). I would really appreciate if you answer to them.")

#text("1. In the definition of K_j when you say n_x = j for all x outside of a FINITE set, shouldn’t it be n_x = j for all x outside of a COUNTABLE set instead? Otherwise, I think K_j is not closed (take an infinite countable subset A of R and define f in N^R to be an injection into N on A and j outside A, then f doesn’t belong to K_j but belongs to its closure).")

#text("2. Isn’t the third statement (the one about a sequence of disjoint finite sets A_1, A_2,…) true for all open U containing the constant 1 function?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-36335")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("Dear Anush,")

#text("Yes, the n_x should be equal to j outside of a countable set rather than a finite one. In the third statement, I forgot to add that the n_x there need to be injective on the union of the A_i’s; I’ve changed the text to reflect this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pierre")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-36454")[#strong[#text("Pierre")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2009")])]

#text("For those who read french, you should read the very good book of laurent Schwartz “Analyse 3” Theorie de la mesure, which is a good survey of the measure theory, in every meaning (Lebesgue, Radon-Nikodym, Borel, Lusin…)")#linebreak()#text(" If I remember well, he uses Caratheodory’s theorem to show the Riesz representation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 13: Compactification and metrisation (optional) « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-36957")[#strong[#text("245B, Notes 13: Compactification and metrisation (optional) « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2009")])]

#text("[…] Show that is a unital commutative -algebra (see Section 4 of Notes 12). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254C, Notes 2: The Fourier transform « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-37981")[#strong[#text("254C, Notes 2: The Fourier transform « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("[…] probability measure such that for all . (Hint: Use Prokhorov’s theorem, see Corollary 13 of 245B Notes 12. Try the case […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-38722")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2009")])]

#text("Dear Prof. Tao,")

#text("I think in proof of Prop 3, ")#mi("\\mu(E \\setminus U_n)")#text(" should be replaced by ")#mi("\\mu(U_n \\setminus E)")#text(". I still have problem on the exercise 6: We restrict our argument on a compact set (say ")#mi("A")#text("), according to the Urysohn’s theorem we can construct some function ")#mi("f \\in C_c(A)")#text(". Our aim is to construct a funcition in $C_c(X)$, it seems we can set ")#mi("f=0")#text(" for ")#mi("x \\notin A")#text(". I am a little doubted if this new ")#mi("f")#text(" is continuous (It most probably a trivial question).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-38724")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2009")])]

#text("Thanks for the correction! To make f continuous across all of X, one needs to ensure that f vanishes on the boundary of A, but Urysohn’s lemma can guarantee this for us.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-38972")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2009")])]

#text("Dear Prof. Tao,")

#text("I was wondering if you could give a little more details on the hint of Exercise 8.")

#text("I also have some problem on exercise 9: First extend the ")#mi("arctan(f)")#text(" to be a new function ")#mi("g")#text(" on ")#mi("X")#text(" by Tietze extension theorem, there may be ")#mi("g(x) \\notin (-\\pi/2,\\pi/2)")#text(" for some ")#mi("x \\in X")#text(". Define ")#mi("A=\\{x;g(x) \\in (-\\infty,-\\pi/2] \\cup [\\pi/2,+\\infty)\\}")#text(", which is a closed set. By Urysohn’s lemma, we can construct a continuous funtion ")#mi("U")#text(" such that ")#mi("U(x)=0")#text(" for ")#mi("x \\in A")#text(" and ")#mi("U(x)=1")#text(" for ")#mi("x \\in B")#text(", where ")#mi("B")#text(" is any closed subset of ")#mi("A^c")#text(". Let ")#mi("\\tilde{g}(x)=U(x)g(x)")#text(", and let ")#mi("\\tilde{f}(x)=tan \\tilde{g}(x)")#text(", but we have the possibility ")#mi("\\tilde{f}(x) \\neq f(x)")#text(" for some ")#mi("x \\in K")#text(" by the construction of ")#mi("\\tilde{g}")#text(". Most probably my understanding your hint is not right.")

#text("Thanks a lot in advance!")

#text("Best regards.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-38978")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2009")])]

#text("For Exercise 8, you might want to play with some simple examples, e.g. when X consists of K together with a single additional point x, in which case the only task is to figure out what value to assign to ")#mi("\\tilde f(x)")#text(". Try to make ")#mi("\\tilde f(x)")#text(" as large as possible while retaining the Lipschitz property. Once you have the formula for ")#mi("\\tilde f(x)")#text(" in this one-point-extension case, you should be able to handle the general case.")

#text("For Exercise 9, set B equal to K.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-38994")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2009")])]

#text("Dear Prof. Tao,")

#text("As for Exercise 9, I am doubted if there are some point ")#mi("y \\in \\partial K")#text(" and some sequence ")#mi("\\{x_n\\} \\subset K")#text(" with ")#mi("x_n \\rightarrow y")#text(" such that ")#mi("lim_{x_n \\rightarrow y} arctan f(x_n)=\\pi/2")#text(" (or ")#mi("-\\pi/2")#text("). In this case, there seems some problem for taking ")#mi("B")#text(" as ")#mi("K")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-38995")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2009")])]

#text("Dear PDEbeginner,")

#text("By hypothesis, K is closed, and f is continuous and finite on K, so the scenario you describe cannot occur.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ba7e44815478ec3833db8b7ae5fdbd8a838b1df3bb091dab3013d038182b79a-8da1e0d395d80fa1dbb0a4454473515ce86491e017d50c40680bb1758c91a583.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Haokun Xu")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-39594")[#strong[#text("Haokun Xu")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2009")])]

#text("Hi Professor Tao,")

#text("In your proof of the Stone-Weierstrass theorem, I think you meant to define min(f,g) = (f+g)/2 – |(f-g)/2|, as opposed to (f+g)/2 + |(f-g)/2|.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ba7e44815478ec3833db8b7ae5fdbd8a838b1df3bb091dab3013d038182b79a-8da1e0d395d80fa1dbb0a4454473515ce86491e017d50c40680bb1758c91a583.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Haokun Xu")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-39595")[#strong[#text("Haokun Xu")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2009")])]

#text("Hi Professor Tao,")

#text("Also, in the last paragraph of your proof of the Stone-Weierstrass theorem, with the sentence beginning “First, observe from continuity that,” I think you meant g_xy (y’) > f(y’) + epsilon as opposed to g(y’) > f(y’) + epsilon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-39596")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2009")])]

#text("Dear Haokun: thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ba7e44815478ec3833db8b7ae5fdbd8a838b1df3bb091dab3013d038182b79a-8da1e0d395d80fa1dbb0a4454473515ce86491e017d50c40680bb1758c91a583.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Haokun Xu")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-39610")[#strong[#text("Haokun Xu")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2009")])]

#text("Hi Professor Tao,")

#text("Also, in the first paragraph of your proof of Urysohn’s lemma, I think you meant to say that (3)(4) and (1)(2) are clearly equivalent as oppose to (2)(3) and (1)(2).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-40825")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2009")])]

#text("Dear Prof. Tao,")

#text("Could you give some hint on the proof of exercise 23? In section 3 (paragraph 4), it seems that the sub-algebra ")#mi("\\mathcal {A}")#text(" is the subspace of ")#mi("C(X)")#text(" closed under pointwise multiplication and addition.")

#text("Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-40827")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2009")])]

#text("There was a slight error in that exercise: I forgot to add the assumption that ")#mi("{\\mathcal A}")#text(" had to be closed.")

#text("One can establish the claim in two parts. First, show that ")#mi("{\\mathcal A}")#text(" is contained in one of the ")#mi("\\{ f \\in C(X): f(x_0)=0\\}")#text(" by arguing by contradiction (if this was not the case, one could soon create a function in the algebra that never vanished, and then show that the algebra contained 1, a contradiction). Then, adjoin the constants to the algebra and use the previous Stone-Weierstrass theorem (Theorem 10).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-40830")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2009")])]

#text("Dear Prof. Tao,")

#text("I tried to prove the claim in a similar way before I asked you the question.")

#text("To construct a never vanishing funciton, I tried to use the argument in the proof of Theorem 10: prove that ")#mi("min(f,g), max(f,g) \\in \\mathcal A")#text(" if ")#mi("f, g \\in \\mathcal A")#text(", and then construct a never vanishing function. However, to prove ")#mi("min(f,g), max(f,g) \\in \\mathcal A")#text(" if $f, g \\in \\mathcal A$, we seem to need the constant in $\\mathcal A$.")

#text("Suppose that we have constructed a never vanishing function ")#mi("h")#text(", I tried to apply the Taylor’s expansion for ")#mi("\\frac 1 h")#text(", in Taylor’s expansion of ")#mi("\\frac 1h")#text(", the first term is a constant, i.e. if ")#mi("\\frac 1h \\in \\mathcal A")#text(", then the constant needs to be in ")#mi("\\mathcal A")#text(".")

#text("I will think of it more.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Israel Gelfand « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-41746")[#strong[#text("Israel Gelfand « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2009")])]

#text("[…] Gelfand’s beautiful theory of -algebras and related spaces made quite an impact on me as a graduate student in Princeton, to the point where I was seriously considering working in this area; but there was not much activity in operator algebras at the time there, and I ended up working in harmonic analysis under Eli Stein instead. (Though I am currently involved in another operator algebras project, of which I hope to be able to discuss in the near future. The commutative version of this theory is discussed in these lecture notes of mine.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seminar „Funktionalanalysis“ « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-43307")[#strong[#text("Seminar „Funktionalanalysis“ « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2010")])]

#text("[…] auf kompakten Hausdorffräumen (T. Tao, Continuous functions on locally compact Hausdorff spaces, Blognotes zur Vorlesung 245B; N. Carothers, l.c. Chap. 12 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The uncertainty principle « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-45692")[#strong[#text("The uncertainty principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2010")])]

#text("[…] Stone/Gelfand duality A (locally compact Hausdorff) topological space can be viewed in physical space (as a collection of points), or dually, via the algebra of continuous complex-valued functions on that space, or (in the case when is compact and totally disconnected) via the boolean algebra of clopen sets (or equivalently, the idempotents of ). The fundamental connection between the two is given by the Stone representation theorem or the (commutative) Gelfand-Naimark theorem. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c24d72168c963bb09dda75bf65f8f76ccf6be936fb9126c24720cf32afe35104-7c7e68ea866db7666fbbcd12f58ce2e451bba5c23ee58e55ddbaf903db01bbf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kestutis Cesnavicius")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-46646")[#strong[#text("Kestutis Cesnavicius")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2010")])]

#text("Thank you for a wonderful set of notes! A couple of (possibly) typos:")

#text("1. In Exercise 7 ")#mi("x \\in K")#text(" should be ")#mi("x\\not\\in K")#text(".")#linebreak()#text(" 2. In Lemma 6 I don’t see how the given conditions imply continuity of ")#mi("g")#text(". I guess each ")#mi("x")#text(" should have a neighbourhood intersecting only finitely many ")#mi("U_{\\alpha}")#text("‘s.")#linebreak()#text(" 3. In the last display in the proof of Theorem 7 the middle union should be to ")#mi("N")#text(" rather than to ")#mi("\\infty")#text(".")#linebreak()#text(" 4. Towards the end of the proof of Theorem 8 in two instances the indices ")#mi("lsc")#text(" are missing. Also, once ")#mi("\\sum K_n")#text(" should be ")#mi("\\bigcup K_n")#text(" in the same (penultimate) paragraph.")#linebreak()#text(" 5. In Remark 5 ")#mi("C_0")#text(" should be ")#mi("C_c")#text(".")#linebreak()#text(" 6. In the second sentence of the proof of Lemma 9 ")#mi("I^+(f)")#text(" and ")#mi("I(f)")#text(" should be swapped in the inequality.")#linebreak()#text(" 7. Exercise 18 does not hold as stated (e.g., ")#mi("f")#text(" maps the plane to the origin).")#linebreak()#text(" 8. In Exercise 25 one should impose additionally ")#mi("f(0) = f(1)")#text(" or replace the unit interval by the circle.")#linebreak()#text(" 9. The Corollary 12, I guess, should be “If ")#mi("X")#text(" is a compact metric space, then the closed unit ball in ")#mi("M(X)")#text(" is sequentially compact in the vague topology.”")#linebreak()#text(" 10. Exercise 30 does not hold as stated: e.g., a family of piecewise linear functions, the nth of which passes through (-2/n, 0), (-1/n, 1), (1/n, -1), (2/n, 0) and is linear inbetween (and zero at infinities).")#linebreak()#text(" 11. It seems that (xy)* = y*x* is missing in the Definition 14.")#linebreak()#text(" 12. In Exercise 35 ")#mi("\\lambda(x^n)")#text(" should be ")#tao-math("\\left|\\lambda(x^n)\\right|", block: false)#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 1: Lebesgue measure « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-46918")[#strong[#text("245A, Notes 1: Lebesgue measure « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2010")])]

#text("[…] of measure can be used to define the concept of a Radon measure, which will be encountered much later in this course series. Exercise 14 (Criteria for finite measure) Let . Show that the following are […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 2: The Lebesgue integral « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-47163")[#strong[#text("245A, Notes 2: The Lebesgue integral « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2010")])]

#text("[…] But then, by Exercise 14 of ")#link("http://en.wikipedia.org/wiki/Urysohn’s_lemma")[#text("http://en.wikipedia.org/wiki/Urysohn’s_lemma")]#text(", which we wil cover in 245B). It is then clear from construction that as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-47247")[#strong[#text("245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2010")])]

#text("[…] One question that will not be addressed much in this current set of notes is how one actually constructs interesting examples of measures. We will discuss this issue more in later notes (although one of the most powerful tools for such constructions, namely the Riesz representation theorem, will not be covered until 245B). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/14e8f37d3e8e3ebf22e1955d0a401065faf54d0ba20eaf8f86b37f79579bd77a-bca3a6f1cc3344feafc6517bf191b42330be9b5a139cebfecda071fb0137bea5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yaoliang")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-47511")[#strong[#text("yaoliang")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2010")])]

#text("I was trying to do Exercise 11. Do we need to assume the l.s.c. function f is bounded from below? Otherwise I can’t figure out how to avoid function g to take value -infty. As a side note, the condition on X can be relaxed to completely regular (which turns out to be necessary as well).")

#text("Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-47512")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2010")])]

#text("Ah, yes, one does need to allow g to take the value -infty in this case. I’ve adjusted the question accordingly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 5: Differentiation theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-47649")[#strong[#text("245A, Notes 5: Differentiation theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2010")])]

#text("[…] finite Borel measures have this property, but we will not prove this here; see Exercise 12 of these notes.) Establish the Hardy-Littlewood maximal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 6: Outer measures, pre-measures, and product measures « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-47921")[#strong[#text("245A, Notes 6: Outer measures, pre-measures, and product measures « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2010")])]

#text("[…] We remark that these notes omit a very important way to construct measures, namely the Riesz representation theorem, but we will defer discussion of this theorem to 245B. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb60d0f893124fdbd4172c3dcf709a6c730e36cb9b0602fad4a0a85586a1d16-352be768f3a1f0853fd3d4a46d65b025ef1dc9f8a2979f28fb6def09a469a98c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 2: The Lebesgue integral « mathTHÍCHinTOÁNmyHỌCbrain")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-48944")[#strong[#text("245A, Notes 2: The Lebesgue integral « mathTHÍCHinTOÁNmyHỌCbrain")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2010")])]

#text("[…] can set for some sufficiently large ; one may also invoke Urysohn’s lemma, which we wil cover in 245B). It is then clear from construction that as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4f6ff1da4727f702e015d04fb4d3027d2159b851298a36042060d2b4965c5fe-246e536fc6d4ae119d0d6494b46c6eecd3c9203b340215b770daf37277fed1cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Lu")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-51206")[#strong[#text("Peter Lu")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2011")])]

#text("Hi prof Tao,")

#text("I’m not sure if you’ve been informed yet, but I believe there is a misnumbering in your homework for 245C. The last problem given was “Exercise 1.10.25 (Density of Fourier series). Note an important typo in this question: [R,Z] should be R/Z (i.e. the unit circle).” which is clearly Exercise 25 in the notes of this blog post. It seems to be a different problem in your book, or at least the pdf copy that you have available for download.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4f6ff1da4727f702e015d04fb4d3027d2159b851298a36042060d2b4965c5fe-246e536fc6d4ae119d0d6494b46c6eecd3c9203b340215b770daf37277fed1cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Lu")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-51207")[#strong[#text("Peter Lu")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2011")])]

#text("Oh my mistake, I went back and checked again and it is more or less the same problem except you have . C[0,1] instead of R/Z in the book.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Central extensions of Lie groups, and cocycle averaging « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-53574")[#strong[#text("Central extensions of Lie groups, and cocycle averaging « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2011")])]

#text("[…] Thus, we may then apply the (LCH version of the) Tietze extension theorem (discussed on this blog here), and extend the map to a continuous (and compactly supported) function defined on all of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-57488")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2011")])]

#text("Hello,")

#text("In the proof of the existence of the partitions of unity, by “[…] is well-defined, continuous and bounded below by 1” did you mean that is just bounded? a point may belong to multiple compact sets (but to only a finite amount of them).")

#emph[#text("[No, it is important that ")#mi("\\sum_{\\alpha \\in A} g_\\alpha")#text(" is both continuous and bounded below in order to have a continuous inverse. It is not necessarily bounded above, but it is finite at every point. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-59892")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2011")])]

#text("Hello, I have an alternative proof of the subaditivity of the linear functional from the RRT, I think it is ok, here it is:")

#strong[#text("Lemma:")]#text(" If ")#mi("f, f_n \\in BC_{lsc}^+(X)")#text(" are such that ")#mi("f \\leq \\sum_n f_n")#text(", then ")#mi("\\widetilde{I}(f) \\leq \\sum_n \\widetilde{I}(f_n)")#text(".")

#strong[#text("Proof:")]#text(" If ")#mi("\\sum_n \\widetilde{I}(f_n) = +\\infty")#text(" then equality is trivialy true, so we can assume ")#mi("f = \\sum_n f_n")#text(" and the series converges.")

#text("Because of the way ")#mi("\\widetilde{I}(f)")#text(" is defined, it es enough to proof that if ")#mi("g \\in C_c(X)")#text(" is such that ")#mi("0 \\leq g \\leq f")#text(" then there exist ")#mi("g_n \\in C_c(X)")#text(" such that ")#mi("0 \\leq g_n \\leq f_n")#text(" and ")#mi("g = \\sum_n g_n")#text(".")

#text("Consider the family")

#mi("\\mathfrak{M} = \\{ (g_n)_n: g_k \\in C_c(X), \\; 0 \\leq g_k \\leq f_k, \\; \\sum_k g_k \\leq g \\}")

#text("which is not empty because the sequence of null functions is inside")#linebreak()#text(" ")#mi("\\mathfrak{M}")#text(". ")#mi("\\mathfrak{M}")#text(" is partially ordered by ")#mi("(g_n) \\leq (g^{\\prime}_n)")#text(" if ")#mi("g_k \\leq g^{\\prime}_k")#text(" for all ")#mi("k")#text(". Let ")#mi("(g^k_n)")#linebreak()#text(" a totally ordered subset of ")#mi("\\mathfrak{M}")#text(".Then")#linebreak()#text(" ")#mi("(g_n^k)_k")#text(" is a nondecreasing sequence of continuos functions on a compact set, so by Dini’s theorem in converged uniformly to a continuous function ")#mi("g_n")#text(", and clearly ")#mi("(g_n)_n \\in \\mathfrak{M}")#text(". I claim that ")#mi("\\sum_n g_n = g")#text(", indeed, if")#linebreak()#text(" ")#mi("\\sum_n g_n(x) \\leq g(x) - \\epsilon \\leq f(x)-\\epsilon = \\sum_n f_n(x) - \\epsilon")#text(" for some ")#mi("x \\in X")#text(" and for all sufficiently small \\epsilon greater than 0, then as every term involved is nonnegative and ")#mi("g_k \\leq f_k")#text("for all ")#mi("k")#text(", there exists some ")#mi("k")#text(" such that")#linebreak()#text(" ")#mi("g_k(x) < f_k(x) - \\epsilon")#text(". By the lower semicontinuity of ")#mi("f_k")#text(" there is an open neighbourhood ")#mi("U")#text(" of ")#mi("x")#text(" such that ")#mi("f_k(x) \\leq f_k(y) + \\frac{\\epsilon}{2}")#text(" for every ")#mi("y \\in U")#text(", and by the continuity of ")#mi("g_k")#text(",")#linebreak()#text(" changing ")#mi("U")#text(" if necessary, we have that for any ")#mi("y \\in U")#text(",")#linebreak()#text(" ")#mi("g_k(y) \\leq f_k(x) - \\epsilon \\leq f_k(y) - \\frac{\\epsilon}{2}")#text(".")#linebreak()#text(" As ")#mi("X")#text(" locally compact, there is a compact neighbourhood ")#mi("K")#text(" of")#linebreak()#text(" ")#mi("x")#text(" in ")#mi("U")#text(", and by normality of ")#mi("X")#text(" and Urysohn's lemma there is a function ")#mi("h: X \\to [0, 1]")#text(" such that")#linebreak()#text(" ")#mi("h|K \\equiv 1")#text(" and ")#mi("h")#text(" is zero in the complement of ")#mi("U")#text(".Taking ")#mi("g^{\\prime}_k = g_k + \\frac{\\epsilon}{4} h")#text(" one gets an element in ")#mi("\\mathfrak{M}")#linebreak()#text(" strictly greater than ")#mi("g")#text(", which proves that ")#mi("\\sum_n g_n = g")#linebreak()#text(" as we wished. []")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1acb940f8f8405b3b081933ef9789a8ee01e93bd3f6b5e752116a45d51725d9-6624b7280d4142ab04f7c3b91775c545aa34df0fee62eecb5c7e6d4971de372c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-457380")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2015")])]

#text("I don’t think your application of Dini’s theorem is correct, continuity of the limit is an assumption of Dini’s theorem and not part of the conclusion (uniform convergence is the only part of the conclusion of Dini’s theorem).")

#text("E.g: Take the function $1-x^n$ on the closed unit interval, it is an increasing sequence of functions but the limit is not continuous.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b88d70dc194adf72f057699180f305b5075fdcc17a3847207ae2f1d091549372-21fb19c3ee7a87393199500520e1bbca17fa45453e93fa79b406b21ad7f74989.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Georges Elencwajg")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-75616")[#strong[#text("Georges Elencwajg")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2011")])]

#text("Algebraically minded readers might like to notice that, given an arbitrary affine scheme X=Spec(A) and two disjoint closed subschemes Y=V(I), Z =V(J), there exists a global regular function f in A whose restrictions to Y and Z are respectively 0 and 1. This follows from the Chinese remainder theorem since disjointness of Y and Z translates into I+J=A .")#linebreak()#text(" Of course if X is irreducible, it is impossible to find disjoint neighbourhoods of Y and Z , since there are no disjoint nonempty open sets in X at all.")#linebreak()#text(" More generally the analogon of Tietze’s theorem is true: any regular function on Y extends to a regular function on X. (Affine) scheme theory is built in such a way that this is actually a tautology , boiling down to the fact that the quotient morphism from A to A/I is surjective!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-127835")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2012")])]

#text("In the proof of Theorem 7, you remark “(note that as {X} is compact, a subset {K} of {X} is closed if and only if it is compact).”")

#text("You probably want to mention here that you are also using the fact that X is Hausdorff to get the implication “K compact ==> K closed”. In general, a compact subset K of a compact space X will not be closed.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-127851")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2012")])]

#text("In Exercise 17, you write")

#text("“{C_c(X \\rightarrow {\\bf R})} and its completion {C_0(X \\rightarrow {\\bf R})}”")

#text("What norm on C_c(X –> R) are we taking its completion with respect to?")

#emph[#text("[")#mi("C_c")#text(" is understood to be given the uniform topology by default. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-128344")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2012")])]

#text("I think that Proposition 3 could be simplified a bit. I’ll reproduce it, as written above, here for convenience:")

#text("“Proposition 3: Let ")#mi("{X}")#text(" be a locally compact Hausdorff space which is also ")#mi("{\\sigma}")#text("-compact, and let ")#mi("{\\mu}")#text(" be a Radon measure on ")#mi("{X}")#text(". Then for any ")#mi("{0 < p < \\infty}")#text(", ")#mi("{C_c(X \\rightarrow {\\bf R})}")#text(" is a dense subset in (real-valued) ")#mi("{L^p(X,\\mu)}")#text(". In other words, every element of ")#mi("{L^p(X,\\mu)}")#text(" can be expressed as a limit (in ")#mi("{L^p(X,\\mu)}")#text(") of continuous functions of compact support.")

#text("Proof: Since continuous functions of compact support are bounded, and compact sets have finite measure, we see that ")#mi("{C_c(X)}")#text(" is a subspace of ")#mi("{L^p(X,\\mu)}")#text(". We need to show that the closure ")#mi("{\\overline{C_c(X)}}")#text(" of this space contains all of ")#mi("{L^p(X,\\mu)}")#text(".")

#text("Let ")#mi("{K}")#text(" be a compact set, and let ")#mi("{E \\subset K}")#text(" be a Borel set, then ")#mi("{E}")#text(" has finite measure. Applying inner and outer regularity, we can find a sequence of compact sets ")#mi("{K_n \\subset E}")#text(" and open sets ")#mi("{U_n \\supset E}")#text(" such that ")#mi("\\mu(E \\backslash K_n), \\mu(U_n \\backslash E) \\rightarrow 0")#text(". Applying Exercise 6, we can then find ")#mi("{f_n \\in C_c(X \\rightarrow {\\bf R})}")#text(" such that ")#mi("{1_{K_n}(x) \\leq f_n(x) \\leq 1_{U_n}(x)}")#text(". In particular, this implies (by the squeeze theorem) that ")#mi("{f_n}")#text(" converges in ")#mi("{L^p(X,\\mu)}")#text(" to ")#mi("{1_E}")#text(" (here we use the finiteness of ")#mi("{p}")#text("); thus ")#mi("{1_E}")#text(" lies in ")#mi("{\\overline{C_c(X \\rightarrow {\\bf R})}}")#text(" for any measurable subset ")#mi("{E}")#text(" of ")#mi("{K}")#text(". By linearity, all simple functions supported on ")#mi("{K}")#text(" also lie in ")#mi("{\\overline{C_c(X \\rightarrow {\\bf R})}}")#text("; taking closures, we see that any ")#mi("{L^p}")#text(" function supported in ")#mi("{K}")#text(" also lies in ")#mi("{\\overline{C_c(X \\rightarrow {\\bf R})}}")#text(". As ")#mi("{X}")#text(" is ")#mi("{\\sigma}")#text("-finite, one can express any non-negative ")#mi("{L^p}")#text(" function as a monotone limit of compactly supported functions, and thus every non-negative ")#mi("{L^p}")#text(" function lies in ")#mi("{\\overline{C_c(X \\rightarrow {\\bf R})}}")#text(", and thus all ")#mi("{L^p}")#text(" functions lie in this space, and the claim follows. ")#mi("\\Box")#text("\"")

#text("It seems that the compact set ")#mi("K")#text(" here is extraneous; one only needs the fact that ")#mi("E")#text(" has finite measure to apply the argument about approximation via inner/outer regularity and bump functions. I don't see how ")#mi("K")#text(" plays any role.")

#text("If this is correct, then we should have that ")#mi("1_{E}")#text(" lies in the closure ")#mi("{\\overline{C_c(X)}}")#text(" for all sets ")#mi("E")#text(" of finite measure. Consequently, the space of simple functions with finite measure support lies in ")#mi("{\\overline{C_c(X)}}")#text(". But you have already proven in Proposition 2 of")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("245B, notes 3: L^p spaces")]
]

#text("that the closure of the space of simple functions with finite measure support in ")#mi("{L^p}")#text(" is, in fact, all of ")#mi("{L^p}")#text(" (provided that ")#mi("p < \\infty")#text("). The proof you give there works for an arbitrary measure space.")

#text("In particular, we can avoid the ")#mi("\\sigma")#text("-compact hypothesis entirely.")

#emph[#text("[Fair enough; I’ve adjusted the text accordingly. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-148769")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2012")])]

#text("Regarding Exercise 37, Banach-Alaoglu is unnecessary. The weak-* topology on the space of characters is just the Zariski topology on the maximal spectrum, and this is compact for any commutative ring whatsoever by a straightforward and purely algebraic argument.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-148778")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2012")])]

#text("Well, OK, although showing that the weak-* topology and Zariski topology are equivalent on ")#mi("\\hat A")#text(" is not entirely trivial (I think one needs to at least develop a continuous functional calculus for this).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-148862")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2012")])]

#text("Ah. My apologies. I was under the mistaken impression that the two were equivalent by definition (but the weak-* topology is the coarsest topology making evaluation on elements of ")#mi("A")#text(" continuous when ")#mi("\\mathbb{C}")#text(" is given the usual topology and the Zariski topology is the coarsest topology making evaluation on elements of ")#mi("A")#text(" continuous when ")#mi("\\mathbb{C}")#text(" is given the ")#emph[#text("Zariski")]#text(" topology…).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f644849dc5134648454c8cd775feb8f6516381648d6f246b27e29d7da4889df1-d45cd95d4dbeadd00a7377d0c40f4c8b7463de0e666a476c3347cebfebae688c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sven")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-153075")[#strong[#text("Sven")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2012")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Helly’s selection theorem seems to always be stated for functions on an interval. Does that mean that it cannot be generalized to functions on $\\mathbb{R}^N$?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-153078")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2012")])]

#text("In higher dimensions, the total variation norm does not control the uniform norm (the Sobolev embedding numerology becomes increasingly unfavorable as the dimension increases), and so a naive extension of Helly’s theorem to higher dimensions fails. But there are certainly other compactness theorems in higher dimensions which can be viewed as substitutes (e.g. Rellich compactness theorem).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-160894")[#strong[#text("Noncommutative probability « Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2012")]

#text("[…] In fact a much stronger statement is true due to the following corollary of the Riesz-Markov theorem, which we will not prove; see Terence Tao’s notes. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/296ad3b1197869ddeb39ca34737d6c1deb6d542cf8e35a2903e4eb44304a955f-28b02b854ce6aadab77d5e78775118d644cf6181d1d11d99f5a31154af5b44fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Katy")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-186896")[#strong[#text("Katy")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2012")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Thank you for the wonderful notes! In exercise 36, I think that $||x|| = \\{ \\sup |z| : z \\in \\sigma(x) \\}$ holds for self-adjoint elements of the C*-algebra. For example, consider the operator $x$ on $\\mathbb{C}^2$ that sends $(e_1,e_2) \\to (e_2, 0)$. In this case, $\\sigma(x) = 0$, but $||x|| = 1$.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2061023cb1c94b07515daade3dba62ac058b750a4c4b4aa7632933dc0a828c24-c5a05b0ef9d46733bcac972b93d4295fb8764dd757d7627c7974df2295325cbc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lug")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-213731")[#strong[#text("Lug")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2013")])]

#text("Dear Dr. Tao,")#linebreak()#text(" This might just be my problem, but In exercise 3, I found the word ‘refinement’ confusing, which would make people (at least me) think F’ is coarser than F, but actually F’ is finer. I actually struggled a while there for a while by the contradicting meanings of the two definitions of F’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-225747")[#strong[#text("Solution Set I | Interesting Mathematics exercises")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2013")]

#text("[…] : Initial hunch is to hammer this problem to with the Weierstrass Approximation Theorem (see Terrence Tao’s blog for a more general version of the same). However, one needs to be careful in getting uniformity in approximation. Any simplification of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c85df9bcaef8a04be2221e2985dc4e51ad4ff59497dba9b86e40fa33e8e6f94e-6e6ffb2875ccd37034f1c2aeb7401c211a14c354c17b76bc35bea7d0274de221.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-239021")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2013")])]

#text("sir for a function belongs to the test space (that is space of all continuous function with compacct support) i want to decompose one function say “\\phi” into difference of two non-negative continuous function with compact support.what is this positive and negative part of function \\phi) ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da8861a986d9cbe531c94801267cf63f537fe5487443b7dd90d12dfaff68be23-b765d331332ddd780e085a7d90c56ff09927bf526baa74bd5fc468f7f78a8e60.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of UPS")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-243203")[#strong[#text("UPS")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2013")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Does there exists an extension of the Prokhorov’s theorem to the space of finitely additive signed measures (with an underlying space say R^n)?")

#text("Motivation: Bounded Lipschitz (dual) metric metrizes the narrow topology on the space of finitely additive signed measures. So can we have a similar characterization (like Prokhorov’s theorem) of compact sets in this space.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6598694526cf1985410ebd735b6dfa658d8db6fe2c9b8394acc91684d11add4f-2a8c5d384c4fc4dc48c68ad1919569e2971893800148cab32c07e26dc4bbd626.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Hevener")]], [#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/comment-page-1/#comment-418338")[#strong[#text("Richard Hevener")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2014")])]

#text("In your proof of Thm. 5 (Lusin), line 5, you should change ‘By Theorem 4’ to ‘By Exercise 10’. Also, why not drop the ")#mi("\\sigma")#text("-compact hypothesis?")

#emph[#text("[Corrected, thanks. For some minor technical reasons I have restricted Radon measures here to the sigma-compact case; see Example 1 and Remark 3. -T.]")]
]
