// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/03/12/pcm-article-ricci-flow/
// Converted to Typst by tao2typ: "2026-10-14T16:35:14.847252+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "PCM article: Ricci flow", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("PCM article: Ricci flow")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 March 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/03/12/pcm-article-ricci-flow/")[#text("https://terrytao.wordpress.com/2008/03/12/pcm-article-ricci-flow/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’m closing my ")#link("https://terrytao.wordpress.com/category/paper/companion/")[#text("series of articles")]#text(" for the ")#link("http://gowers.wordpress.com/2007/09/06/hello-world/")[#text("Princeton Companion to Mathematics ")]#text("with my article on “")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/03/ricci1.pdf")[#text("Ricci flow")]#text("“. Of course, this flow on Riemannian manifolds is now very well known to mathematicians, due to its fundamental role in Perelman’s ")#link("http://en.wikipedia.org/wiki/Hamilton%E2%80%93Perelman_solution_of_the_Poincar%C3%A9_conjecture")[#text("celebrated proof")]#text(" of the ")#link("http://en.wikipedia.org/wiki/Poincare_conjecture")[#text("Poincaré conjecture")]#text(". In this short article, I do not focus on that proof, but instead on the more basic questions as to what a ")#link("http://en.wikipedia.org/wiki/Riemannian_manifold")[#text("Riemannian manifold")]#text(" is, what the ")#link("http://en.wikipedia.org/wiki/Ricci_curvature")[#text("Ricci curvature tensor")]#text(" is on such a manifold, and how ")#link("http://en.wikipedia.org/wiki/Ricci_flow")[#text("Ricci flow")]#text(" qualitatively changes the geometry (and with surgery, the topology) of such manifolds over time.")

#text("I’ve saved this article for last, in part because it ties in well with my upcoming course on Perelman’s proof which will start in a few weeks (details to follow soon).")

#text("The last external article for the PCM that I would like to point out here is ")#link("http://www.math.ucdavis.edu/~osserman/")[#text("Brian Osserman")]#text("‘s ")#link("http://www.math.ucdavis.edu/~osserman/math/pcm.pdf")[#text("article on the Weil conjectures")]#text(", which include the “Riemann hypothesis over finite fields” that was famously solved by Deligne. These (now solved) conjectures, which among other things gives some quite precise control on the number of points in an algebraic variety over a finite field, were (and continue to be) a major motivating force behind much of modern arithmetic and algebraic geometry.")

#text("[")#emph[#text("Update")]#text(", Mar 13: Actual link to Weil conjecture article added.]")

#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3840e46e204c3a6a1d5b450c937bc33c9a887399e75466c36ad16c6b0d2dd69e-49cf95b612b59fbe87bb430eac6d45643219b3a8bbff6a8c40ebca596fd3b516.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy")]], [#link("https://terrytao.wordpress.com/2008/03/12/pcm-article-ricci-flow/#comment-27197")[#strong[#text("Andy")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2008")])]

#text("typo: bottom of p.2, ’emenating’ –> ’emanating’.")

#text("An informative article, thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/03/12/pcm-article-ricci-flow/#comment-27199")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2008")])]

#text("Nice article! In the second paragraph on page 2, can r really go to infinity for Earth?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2008/03/12/pcm-article-ricci-flow/#comment-27207")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2008")])]

#text("Dear Prof. Tao,")

#text("Are you planning to post (at least some version of) the forthcoming lectures of yours on Perelman’s work in your blog, as you did for your fine lectures on dynamical systems (254A)? That would be great!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24855c000459d469521dac1d33b7604ae613422dbb1568aecc5012386c434551-a2aef3bbf99bc1616122b299b154330ada3b9839c53565e3a9927d35881dc70a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve")]], [#link("https://terrytao.wordpress.com/2008/03/12/pcm-article-ricci-flow/#comment-27211")[#strong[#text("Steve")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2008")])]

#text("The link to the Weil conjectures article is broken.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/12/pcm-article-ricci-flow/#comment-27217")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2008")])]

#text("Thanks for the corrections!")

#text("Dear t8m8r: one can set r to be any real number when defining the balls B(x,r). Of course, as the Earth has finite diameter, these balls eventually cover the entire Earth and stop growing any larger once r is sufficiently large (in particular, the ball no longer has a boundary). [In the other direction, of course, a ball B(x,r) becomes empty if we make the radius negative.]")

#text("Dear Pedro: I am planning to post notes on my 285G class, though it will not be quite as self-contained as my 245A class as it is building in part on an existing course in Ricci flow here at UCLA. More details to follow soon…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/03/12/pcm-article-ricci-flow/#comment-27221")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2008")])]

#text("Thanks! I think I was thinking that a ball should have boundary instead of recalling the definition.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a44d3cbb676cf230d7823cbbebe236d619a061e5dd8fa017d016734c54798013-fe3c7f6f137a58393891aead297c53fe3272618b3658a01c4b01929f56046260.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony Lai")]], [#link("https://terrytao.wordpress.com/2008/03/12/pcm-article-ricci-flow/#comment-27232")[#strong[#text("Tony Lai")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2008")])]

#text("Hello, Professor Tao. My name is Tony Lai. Like you, I’m a former prodigy; when I was 18, I received my PhD in computer science from U. Waterloo, as mentioned in ")#link("http://www.cs.uwaterloo.ca/about/history")[#text("http://www.cs.uwaterloo.ca/about/history")]#text(". I live in Toronto, and I heard that you’re visiting the Fields Institute in April. Would you have a few minutes to spare for a chat? Thanks very much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 0: Riemannian manifolds and curvature « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/12/pcm-article-ricci-flow/#comment-27668")[#strong[#text("285G, Lecture 0: Riemannian manifolds and curvature « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2008")])]

#text("[…] rank (2,0) tensor – just like the metric g! This observation will of course be vital for defining Ricci flow later. (This observation, as well as a similar observation for the stress-energy tensor, was also […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 1: Flows on Riemannian manifolds « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/12/pcm-article-ricci-flow/#comment-27726")[#strong[#text("285G, Lecture 1: Flows on Riemannian manifolds « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2008")])]

#text("[…] manifolds (e.g. curvature, length, volume) change by such flows. We then specialise to the case of Ricci flow (together with some close relatives of this flow, such as renormalised Ricci flow, or Ricci flow […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aprameyan")]], [#link("https://terrytao.wordpress.com/2008/03/12/pcm-article-ricci-flow/#comment-28778")[#strong[#text("Aprameyan")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2008")])]

#text("In your statement of the Poincare conjecture, should it not be compact and simply connected ? Doesn’t seem to make sense, to me, as it is stated.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ecae8949d2a582e9af01568c77d446037d267c5a34c0888852d4d85f3be7415f-27e0afd8f9c27dfe535af27e295a01d3dd66853ead7569fa505021abb4e09a9c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Article Rewriter")]], [#link("https://terrytao.wordpress.com/2008/03/12/pcm-article-ricci-flow/#comment-31252")[#strong[#text("Article Rewriter")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2008")])]

#text("In response to Aprameyan, indeed it should be compact and simply connected.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2158d5744d7f14c39f496c6df05751372a04da1eb8814ab2949a3e24171a37c-3d75a7dd66646c827fb34a7b9890d7d87716bbffbe363d8811913351e5396883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas")]], [#link("https://terrytao.wordpress.com/2008/03/12/pcm-article-ricci-flow/#comment-42395")[#strong[#text("Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2009")])]

#text("What is the relation of Ricci flow with renormalization?")

#text("I ask because the existence of ")#link("https://terrytao.wordpress.com/2008/02/19/why-are-solitons-stable/")[#emph[#text("arithmetic versions of solitons")]]#text(" made me ask ")#link("http://mathoverflow.net/questions/4121/spec-z-analogue-of-thurston-program")[#emph[#text("recently in mathoverflow")]]#text(" about Ricci flow and Ilya Nikokoshev mentiones that Ricci flow “is” renormalization in QFT. As the later should have some arithmetic analogies, my question")
]
