// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/
// Converted to Typst by tao2typ: "2026-10-14T15:16:46.891834+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 13: Li-Yau-Hamilton Harnack inequalities and κ-solutions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 13: Li-Yau-Hamilton Harnack inequalities and κ-solutions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 May 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/")[#text("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

#text("We now turn to the theory of ")#emph[#text("parabolic Harnack inequalities")]#text(", which control the variation over space and time of solutions to the scalar heat equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("u_t = \\Delta u")]]

#text("which are bounded and non-negative, and (more pertinently to our applications) of the curvature of Ricci flows")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("g_t = -2\\text{Ric}")]]

#text("whose Riemann curvature ")#mi("\\text{Riem}")#text(" or Ricci curvature ")#mi("\\text{Ric}")#text(" is bounded and non-negative. For instance, the classical ")#link("http://www.ams.org/mathscinet-getitem?mr=159139")[#text("parabolic Harnack inequality of Moser")]#text(" asserts, among other things, that one has a bound of the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("u(t_1,x_1) \\leq C(t_1,x_1,t_0,x_0,T_-,T_+,M) u(t_0,x_0)")]]

#text("whenever ")#mi("u: [T_-,T_+] \\times M \\to {\\Bbb R}^+")#text(" is a bounded non-negative solution to (1) on a complete static Riemannian manifold M of bounded curvature, ")#mi("(t_1,x_1), (t_0,x_0) \\in [T_-,T_+] \\times M")#text(" are spacetime points with ")#mi("t_1 < t_0")#text(", and ")#mi("C(t_1,x_1,t_0,x_0,T_-,T_+,M)")#text(" is a constant which is uniformly bounded for fixed ")#mi("t_1,t_0,T_-,T_+,M")#text(" when ")#mi("x_1,x_0")#text(" range over a compact set. (The even more classical ")#link("http://en.wikipedia.org/wiki/Harnack's_inequality")[#text("elliptic Harnack inequality")]#text(" gives (1) in the steady state case, i.e. for bounded non-negative harmonic functions.) In terms of ")#link("http://en.wikipedia.org/wiki/Heat_kernel")[#text("heat kernels")]#text(", one can view (1) as an assertion that the heat kernel associated to ")#mi("(t_0,x_0)")#text(" dominates (up to multiplicative constants) the heat kernel at ")#mi("(t_1,x_1)")#text(".")

#text("The classical proofs of the parabolic Harnack inequality do not give particularly sharp bounds on the constant ")#mi("C(t_1,x_1,t_0,x_0,T_-,T_+,M)")#text(". Such sharp bounds were obtained ")#link("http://www.ams.org/mathscinet-getitem?mr=834612")[#text("by Li and Yau")]#text(", especially in the case of the scalar heat equation (1) in the case of static manifolds of non-negative Ricci curvature, using Bochner-type identities and the scalar maximum principle. In fact, a stronger differential version of (3) was obtained which implied (3) by an integration along spacetime curves (closely analogous to the ")#mi("{\\mathcal L}")#text("-geodesics considered in earlier lectures). These bounds were particularly strong in the case of ancient solutions (in which one can send ")#mi("T_- \\to -\\infty")#text("). Subsequently, ")#link("http://www.ams.org/mathscinet-getitem?mr=1198607")[#text("Hamilton applied")]#text(" his tensor-valued maximum principle together with some remarkably delicate tensor algebra manipulations to obtain Harnack inequalities of Li-Yau type for solutions to the Ricci flow (2) with bounded non-negative Riemannian curvature. In particular, this inequality applies to the ")#mi("\\kappa")#text("-solutions introduced in the ")#link("https://terrytao.wordpress.com/2008/05/16/285g-lecture-12-high-curvature-regions-of-ricci-flow-and-%ce%ba-solutions/")[#text("previous lecture")]#text(".")

#text("In this current lecture, we shall discuss all of these inequalities (although we will not give the full details for the proof of Hamilton’s Harnack inequality, as the computations are quite involved), and derive several important consequences of that inequality for ")#mi("\\kappa")#text("-solutions. The material here is based on several sources, including ")#link("http://www.ams.org/mathscinet-getitem?mr=1625845")[#text("Evans’ PDE book")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2251315")[#text("Müller’s book")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian’s book")]#text(", the ")#link("http://www.ams.org/mathscinet-getitem?mr=2233789")[#text("paper of Cao-Zhu")]#text(", and of course the primary source papers mentioned in this article.")

#metadata(none) <tao-33347f7dbb441d5becd0>

#heading(level: 1)[#text("— Scalar parabolic Harnack inequalities —")]

#text("Before we turn to the inequalities for Ricci flows (which are our main interest), we first consider the simpler case of scalar non-negative bounded solutions ")#mi("u: [T_-,T_+] \\times M \\to {\\Bbb R}^+")#text(" to the heat equation (1) on a static complete smooth Riemannian manifold ")#mi("(M,g)")#text(". This case will not actually be used in our applications but serve as an important motivating example of the method. Our basic tools will be the scalar maximum principle and the following identity.")

#strong[#text("Exercise 1.")]#text(" Let ")#mi("f: M \\to {\\Bbb R}")#text(" be a smooth function. Establish the ")#link("http://en.wikipedia.org/wiki/Bochner%27s_formula")[#text("Bochner formula")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\Delta \\left|\\nabla f\\right|_g^2 = 2 \\nabla_{\\nabla f} \\Delta f + 2 \\left|\\text{Hess}(f)\\right|_g^2 + 2 \\text{Ric}(\\nabla f, \\nabla f).", block: true)]]

#text("(Hint: use abstract index notation, and use the torsion-free nature of the connection, combined with the definitions of Riemann and Ricci curvature.) ")#mi("\\diamond")

#text("This leads to the following consequence:")

#strong[#text("Exercise 2.")]#text(" Let ")#mi("u: [T_-,T_+] \\times M \\to {\\Bbb R}^+")#text(" be a strictly positive solution to (1), and let ")#mi("f := \\log u")#text(". Establish the nonlinear heat equation identities")

#tao-aligned(keep: true)[


#tao-math("f_t  & = \\Delta f + \\nabla_{\\nabla f} f = \\Delta f + \\left|\\nabla f\\right|_g^2", block: true, numbering: n => [#text("(5)")])



#tao-math("\\partial_t (\\Delta f)  & = \\Delta(\\Delta f) + \\nabla_{\\nabla f} \\Delta f + 2 \\left|\\text{Hess} f\\right|_g^2 + 2 \\text{Ric}(\\nabla f, \\nabla f)", block: true, numbering: n => [#text("(6)")])
]

#align(center)[#tao-math("\\partial_t (\\left|\\nabla f\\right|^2) = \\Delta(\\left|\\nabla f\\right|^2) + \\nabla_{\\nabla f}(\\left|\\nabla f\\right|^2) - 2 \\left|\\text{Hess} f\\right|_g^2 + 2 \\text{Ric}(\\nabla f, \\nabla f)", block: false)#text(". ")#mi("\\diamond")#text(" (7)")]

#text("Now we can state the Li-Yau Harnack inequality.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" (Li-Yau Harnack inequality) Let M be a smooth compact d-dimensional Riemannian manifold with non-negative Ricci curvature, and let ")#mi("u: [T_-,T_+] \\times M \\to {\\Bbb R}^+")#text(" be a strictly positive smooth solution to (1). Then for every ")#mi("(t,x) \\in (T_-,T_+] \\times M")#text(", we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\frac{\\partial_t u}{u} - \\frac{\\left|\\nabla u\\right|^2}{u^2} + \\frac{d}{2(t-T_-)} \\geq 0.", block: true)]]
]

#strong[#text("Proof.")]#text(" By adding an epsilon to u if necessary (and then sending epsilon back to zero at the end of the argument) we may assume that ")#mi("u \\geq \\varepsilon")#text(" for some ")#mi("\\varepsilon > 0")#text(". (We shall use this trick frequently in the sequel and refer to it as the ")#emph[#text("epsilon-regularisation trick")]#text(".) Write ")#mi("f := \\log u")#text(" and ")#mi("F := \\Delta f")#text(". From Cauchy-Schwarz we have ")#tao-math("\\left|\\text{Hess} f\\right|_g^2 \\geq \\frac{1}{d} F^2", block: false)#text(", and so from (6) we see that F is a supersolution to a nonlinear heat equation:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("F_t \\geq \\Delta F + \\nabla_{\\nabla f} F + \\frac{2}{d} \\left|F\\right|^2.", block: true)]]

#text("On the other hand, ")#mi("-\\frac{d}{2(t-T_-)}")#text(" is a sub-solution to the same equation, and the hypothesis that u is smooth and bounded below by ")#mi("\\varepsilon")#text(" (together with the compactness of M) implies that F dominates ")#mi("-\\frac{d}{2(t-T_-)}")#text(" at times close to ")#mi("T_-")#text(". Applying the scalar maximum principle (Corollary 1 from ")#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("Lecture 3")]#text(") we conclude that ")#mi("F \\geq -\\frac{d}{2(t-T_-)}")#text(". The claim (8) now follows from (5) and the chain rule. ")#mi("\\Box")

#strong[#text("Remark 1.")]#text(" One can extend this inequality to the case when M is not compact, but is instead complete with bounded curvature, as long as one now adds the hypothesis that u is bounded (which was automatic in the compact case). The basic idea used to modify the proof is to multiply u by a suitable weight that grows at infinity to force the minimum value of F to lie in a compact set so that the maximum principle arguments can still be applied; we omit the standard details. ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" Observe that when ")#mi("M={\\Bbb R}^d")#text(" is Euclidean and u is the fundamental solution ")#tao-math("u(t,x) = \\frac{1}{(4\\pi (t-T_-))^{d/2}} e^{-\\left|x-x_0\\right|^2/4(t-T_-)}", block: false)#text(" for some ")#mi("x_0 \\in {\\Bbb R}^d")#text(", that (8) becomes an equality. ")#mi("\\diamond")

#text("For strictly positive ancient solutions ")#mi("u: (-\\infty,0] \\times M \\to {\\Bbb R}^+")#text(" to (1) on a compact manifold of non-negative Ricci curvature, one can send ")#mi("T_-")#text(" to negative infinity, we conclude from (8) that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\frac{\\partial_t u}{u} \\geq \\frac{\\left|\\nabla u\\right|^2}{u^2}.", block: true)]]

#text("In particular we see that ")#mi("\\partial_t u \\geq 0")#text("; thus non-negative ancient solutions to the linear heat equation on compact manifolds of non-negative Ricci curvature are non-decreasing in time. [Actually, it turns out that the only such solutions are in fact constant, but we will shortly generalise this assertion to less trivial situations.]")

#text("One can linearise the inequality (10) in u, obtaining the assertion that")

#align(center)[#tao-math("\\displaystyle \\partial_t u - \\nabla_X u + \\frac{1}{4} \\left|X\\right|_g^2 u \\geq 0", block: false)#text(" (10′)")]

#text("for any vector field X. Indeed (10) and (10′) are easily seen to be equivalent by the Cauchy-Schwarz inequality. One advantage of the formulation (10′) is that it also holds true when u is merely non-negative, as opposed to strictly positive u, by the epsilon-regularisation trick. In terms of ")#mi("f = \\log u")#text(", (10′) can also be expressed as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\partial_t f - \\nabla_X f + \\frac{1}{4} \\left|X\\right|_g^2 \\geq 0", block: true)]]

#text("although now one needs u to be strictly positive for (11) to make sense.")

#text("Now let ")#mi("(t_0,x_0), (t_1,x_1) \\in (-\\infty,0] \\times M")#text(" be points in spacetime with ")#mi("t_1 < t_0")#text(", let ")#mi("\\tau_1 := t_0 - t_1")#text(", and let ")#mi("\\gamma: [0,\\tau_1] \\to M")#text(" be a path from ")#mi("x_0")#text(" to ")#mi("x_1")#text(". From the fundamental theorem of calculus and the chain rule we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("f(t_1,x_1) - f(t_0,x_0) = \\int_0^{\\tau_1} -\\partial_t f + \\nabla_X f\\ d\\tau")]]

#text("where ")#mi("X := \\gamma^{\\prime}(\\tau)")#text(" and the integrand is evaluated at ")#mi("(t_0-\\tau,\\gamma(\\tau))")#text(". Applying (11) and then exponentiating we obtain the Harnack inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("u(t_1,x_1) \\leq \\exp( \\frac{1}{4} \\int_0^{\\tau_1} \\left|X\\right|^2\\ d\\tau ) u(t_0,x_0)", block: true)]]

#text("which can be extended from strictly positive solutions u to non-negative solutions u by the epsilon-regularisation trick. (Observe the similarity here with the ")#mi("{\\mathcal L}")#text("-geodesic theory from ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("Lecture 10")]#text(".) By choosing ")#mi("\\gamma")#text(" to be the constant-speed minimising geodesic from ")#mi("x_0")#text(" to ")#mi("x_1")#text(", we thus conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("u(t_1,x_1) \\leq \\exp( d(x_0,x_1)^2/4\\tau_1 ) u(t_0,x_0).")]]

#strong[#text("Remark 3.")]#text(" Specialising to the case when u is a static harmonic function and sending ")#mi("\\tau_1 \\to \\infty")#text(" (and using Remark 1), we recover a variant of ")#link("http://en.wikipedia.org/wiki/Liouville%27s_theorem_%28complex_analysis%29")[#text("Liouville’s theorem")]#text(": a bounded harmonic function on a Riemannian manifold of bounded non-negative curvature is constant. ")#mi("\\diamond")

#strong[#text("Exercise 3.")]#text(" If the non-negative solution u to (1) is not ancient, but is only restricted to a time interval ")#mi("{}[T_-,T_+]")#text(", show that one still has the variant")

#align(center)[#mi("\\displaystyle  u(t_1,x_1) \\leq (\\frac{t_2-T_-}{t_1-T_-})^{d/2} \\exp( d(x_0,x_1)^2/4\\tau_1 ) u(t_0,x_0)")#text(". ")#mi("\\diamond")#text(" (15)")]

#strong[#text("Exercise 4. ")]#text("If the non-negative solution u to (1) is restricted to a time interval ")#mi("{}[T_-,T_+]")#text(", and one no longer assumes that the Ricci curvature is non-negative (but it will still be bounded, since M is compact), establish the Harnack inequality (3) for some ")#mi("C(t_1,x_1,t_0,x_0,T_-,T_+,M)")#text(". (Hint: repeat the above arguments but with F replaced by ")#tao-math("F_\\kappa := \\Delta f + \\kappa \\left|\\nabla f\\right|^2", block: false)#text(" for some small ")#mi("\\kappa")#text(". Show (using (6), (7)) that if ")#mi("\\kappa")#text(" is small enough, then ")#mi("F_\\kappa")#text(" obeys an inequality similar to (9) but with an additional factor of ")#tao-math("-O_\\kappa(\\left|F_\\kappa\\right|)", block: false)#text(" on the right-hand side. ")#mi("\\diamond")

#strong[#text("Exercise 5.")]#text(" Establish the ")#emph[#text("strong maximum principle")]#text(": if M is compact and ")#mi("u: [T_-,T_+] \\times M \\to {\\Bbb R}^+")#text(" is a non-negative solution to (1) which is not identically zero, then it is strictly positive for times ")#mi("t \\in (T_-,T_+]")#text(" (or equivalently, if u vanishes at even one point in ")#mi("(T_-,T_+] \\times M")#text(", then it is identically zero). ")#mi("\\diamond")

#strong[#text("Exercise 6.")]#text(" Generalise the strong maximum principle to the case when u is a supersolution ")#mi("u_t \\geq \\Delta u")#text(" to the heat equation rather than a solution. Also generalise it to the case when the metric g is not static, but instead varies smoothly in time. (For an additional challenge, generalise further to the case when M is complete, the metric has uniformly bounded Riemann curvature, u is bounded, and one also has a drift term ")#mi("\\nabla_X u")#text(" on the right-hand side of the equation for some bounded X.) ")#mi("\\diamond")

#strong[#text("Exercise 7.")]#text(" Using the final generalisation of Exercise 6, as well as the evolution equation for scalar curvature (equation (31) of ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text("), show that the scalar curvature of a ")#mi("\\kappa")#text(" solution is strictly positive at every point in spacetime. (We will prove stronger versions of this fact later in this lecture.) ")#mi("\\diamond")

#text("Further variants and applications of these scalar Harnack inequalities can be found in the ")#link("http://www.ams.org/mathscinet-getitem?mr=834612")[#text("paper of Li and Yau")]#text(".")

#heading(level: 1)[#text("— Parabolic Harnack inequalities for the Ricci flow —")]

#text("Now we turn from the scalar equation (1) to the Ricci flow equation (2), which one could think of as a kind of tensor-valued quasilinear heat equation (by de Turck’s trick, see ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text("). To begin with let us first consider the simple two-dimensional case d=2. In this case the Bianchi identities make the Riemann, Ricci, and scalar curvatures are all essentially equivalent (see ")#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/")[#text("Lecture 0")]#text("); in particular one has the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\text{Ric} = \\frac{1}{2} R g")]]

#text("in the two-dimensional case. In particular, the heat equation for scalar curvature (equation (31) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text(") simplifies to")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\partial_t R = \\Delta R + R^2")]]

#text("in this case; compare this with (1).")

#text("Suppose that the scalar curvature R is strictly positive. Setting ")#mi("f := \\log R")#text(", one has an analogue of (5):")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\partial_t f = \\Delta f + \\nabla_f f + R.")]]

#strong[#text("Exercise 8.")]#text(" If we set ")#mi("F :=  \\partial_t f - \\nabla_f f = \\Delta f + R")#text(", show the following analogue of (9):")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\partial_t F \\geq \\Delta F + 2 \\nabla_{\\nabla f} F + F^2.")]]

#text("[Hint: you will need to first derive the identity ")#mi("\\partial_t \\Delta v = \\Delta \\partial_t v + R \\Delta v")#text(" for arbitrary smooth v.] Conclude that if M is compact and R is strictly positive on the time interval ")#mi("{}[T_-,T_+]")#text(", then ")#mi("F \\geq -1/(t-T_-)")#text(", and thus conclude ")#emph[#text("Hamilton’s Harnack inequality for surfaces")]#text(":")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\partial_t R - \\frac{\\left|\\nabla R\\right|_g^2}{R} + \\frac{R}{t-T_-} \\geq 0.", block: true)]]

#text("Extend this inequality to the case when R is merely non-negative rather than strictly positive by setting f equal to ")#mi("\\log(R+\\varepsilon)")#text(" rather than ")#mi("\\log R")#text(" and then setting ")#mi("\\varepsilon")#text(" to zero (this is how should performs the epsilon regularisation trick for Ricci flow, by modifying the logarithm function by an epsilon, rather than the solution). ")#mi("\\diamond")

#text("For ancient two-dimensional solutions with non-negative curvature, we thus conclude from the Harnack inequality (20) that R (and ")#mi("f = \\log R")#text(") obeys the same bounds (10), (10′), (11) that scalar solutions u did previously. In particular R is non-decreasing in time, and more generally")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\partial_t R - \\nabla_X R + \\frac{1}{4} \\left|X\\right|_g^2 R \\geq 0", block: true)]]

#text("for any X. We can also obtain an analogue of (13). Also, observe from the assumption of non-negative curvature and (2) that the metric is non-increasing with time, and so we can also deduce an analogue of (14):")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("R(t_1,x_1) \\leq \\exp( d_{g(t_1)}(x_0,x_1)^2/4\\tau_1 ) R(t_0,x_0).")]]

#text("With a non-trivial amount of effort, one can extend Hamilton’s Harnack inequality to higher dimensions. One cannot argue solely using the scalar curvature R, because the equation ")#tao-math("\\partial_t R = \\Delta R + 2 \\left|\\text{Ric}\\right|^2", block: false)#text(" for that curvature also involves the Ricci tensor, which thus also needs to be controlled. What is worse, one cannot argue solely using the Ricci tensor either, because the equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\partial_t \\text{Ric}_{\\alpha \\beta} = \\Delta \\text{Ric}_{\\alpha \\beta} + 2 \\text{Ric}^\\gamma_\\delta \\text{Riem}^\\delta_{\\alpha \\gamma \\beta} - 2 \\text{Ric}_{\\alpha \\gamma} \\text{Ric}^\\gamma_\\beta")]]

#text("for the evolution of that curvature involves the Riemann tensor. To proceed, one in fact has to deal with the equation for the full Riemann tensor,")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\partial_t \\text{Riem} = \\Delta \\text{Riem} + {\\mathcal O}(g^{-1} \\text{Riem}^2 )")]]

#text("where ")#mi("{\\mathcal O}(g^{-1} \\text{Riem}^2 )")#text(" is an explicit but rather complicated quadratic expression in the Riemann curvature. This expression simplifies when using a moving orthonormal frame, as was done in Lecture 3, to the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\partial_t {\\mathcal T} = \\Delta {\\mathcal T} + {\\mathcal T}^2 + {\\mathcal T}^\\#.")]]

#text("By using (25) and many tensor calculations, one can (eventually) establish a (rather complicated) analogue of the (21) for ")#mi("{\\mathcal T}")#text(", and hence for ")#mi("\\text{Riem}")#text(" and then (after taking some traces) to R. In particular, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (Hamilton’s Harnack inequality for ancient Ricci flows) Let ")#mi("t \\mapsto (M,g(t))")#text(" be a complete ancient Ricci flow with non-negative bounded Riemann curvature. (In particular, all ")#mi("\\kappa")#text("-solutions are of this form.) Then we have the pointwise inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\partial_t R - \\nabla_X R + \\frac{1}{2} \\text{Ric}(X,X) \\geq 0")]]

#text("for any vector field X.")
]

#text("Note that in the two-dimensional case, (26) collapses to (23) thanks to (16).")

#text("The proof of (26) is remarkably delicate (in particular, going through the tensor curvature equation (25)), but ultimately follows broadly similar lines to the previous arguments (i.e. Bochner-type identities, Cauchy-Schwarz type inequalities, and tensor maximum principles). For technical reasons it is also convenient to carry auxiliary tensor fields such as the vector field X appearing in (26) throughout the argument. We refer the reader to ")#link("http://www.ams.org/mathscinet-getitem?mr=1198607")[#text("Hamilton’s original paper")]#text(" for details. (There are alternate proofs, such as the one by ")#link("http://www.ams.org/mathscinet-getitem?mr=1362964")[#text("Chow and Chu")]#text(" using a metric closely related to the high-dimensional metrics considered in ")#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("Lecture 9")]#text(", but all of the proofs I know of require a significant amount of calculation.)")

#strong[#text("Exercise 9.")]#text(" Suppose that ")#mi("(M,g)")#text(" solves the gradient steady soliton equation ")#mi("\\text{Ric} + \\text{Hess}(f) = 0")#text(" for some smooth f. Using the Bianchi identity ")#mi("\\nabla_\\alpha R = 2 \\nabla^\\beta \\text{Ric}_{\\alpha\\beta}")#text(", establish the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\nabla_\\alpha R = 2\\text{Ric}_{\\alpha \\beta} \\nabla^\\beta f")]]

#text("(note this identity also holds for gradient shrinking or expanding solitons) and then by taking divergences and using the Bianchi identity again, establish that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#tao-math("\\Delta R + 2 \\left|\\text{Ric}\\right|^2 = \\nabla_\\alpha R \\nabla^\\alpha f.", block: true)]]

#text("Conclude that (26) is an identity in this case when one sets ")#mi("X^\\alpha := 2 \\nabla^\\alpha f")#text(". ")#mi("\\diamond")

#heading(level: 1)[#text("— Applications of the Harnack inequality —")]

#text("Now we develop some applications of the Harnack inequality for ")#mi("\\kappa")#text("-solutions. One easy application follows by setting X equal to 0, giving")#linebreak()#text(" the pointwise monotonicity of the scalar curvature in time:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("\\partial_t R \\geq 0.")]]

#text("Another application is to obtain a slightly weakened version of (22) (with the 4 in the denominator replaced by 2):")

#strong[#text("Exercise 10.")]#text(" Show that one has ")#tao-math("\\text{Ric}(X,X) \\leq \\frac{1}{2} R \\left|X\\right|^2", block: false)#text(" whenever one has non-negative Riemann curvature. Using this and (26), show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("R(t_1,x_1) \\leq \\exp( d_{g(t_1)}(x_0,x_1)^2/2\\tau_1 ) R(t_0,x_0).")]]

#text("for all ")#mi("\\kappa")#text("-solutions and all spacetime points ")#mi("(t_0,x_0), (t_1,x_1)")#text(" with ")#mi("t_1 < t_0")#text(". ")#mi("\\diamond")

#text("Now we use the Harnack inequality to obtain some further control on the reduced length function ")#mi("l_{(t_0,x_0)}(t_1,x_1)")#text(". Recall that this quantity takes the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#tao-math("l_{(t_0,x_0)}(t_1,x_1) = \\frac{1}{\\sqrt{2\\tau_1}} \\int_0^{\\tau_1} \\sqrt{\\tau} ( \\left|X\\right|_g^2 + R)\\ d\\tau", block: true)]]

#text("where ")#mi("X := \\gamma^{\\prime}")#text(" and ")#mi("\\gamma: [0,\\tau_1] \\to M")#text(" is a minimising ")#mi("{\\mathcal L}")#text("-geodesic, which in particular means that it obeys the ")#mi("{\\mathcal L}")#text("-geodesic equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("\\nabla_X X - \\frac{1}{2} \\nabla_X R +\\frac{1}{2\\tau} X + 2 \\text{Ric}(X,\\cdot)^* = 0")]]

#text("(see equation (27) from ")#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("Lecture 10")]#text("). Using (32) and the chain rule, we can compute the ")#link("http://en.wikipedia.org/wiki/Total_derivative")[#text("total derivative")]#text(" ")#tao-math("\\frac{d}{d\\tau} \\left|X\\right|^2", block: false)#text(" along the path ")#mi("\\gamma")#linebreak()#text(" as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#tao-math("\\frac{d}{d\\tau} \\left|X\\right|^2 = \\nabla_X R - \\frac{1}{\\tau} \\left|X\\right|^2 - 2 \\text{Ric}(X,X).", block: true)]]

#text("On the other hand, the Harnack inequality (26) (with X replaced by 2X) lets us bound the total derivative of R:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("\\frac{d}{d\\tau} R \\leq - \\nabla_X R + 2 \\text{Ric}(X,X).")]]

#text("We add (33) and (34) and rearrange to obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#tao-math("\\frac{d}{d\\tau} [\\tau^{3/2} (\\left|X\\right|^2+R)] \\leq \\frac{3}{2} \\sqrt{\\tau} (\\left|X\\right|^2+R) - \\tau^{1/2} \\left|X\\right|^2.", block: true)]]

#text("We (somewhat crudely) discard the non-negative ")#tao-math("\\tau^{1/2} \\left|X\\right|^2", block: false)#text(" term and integrate in ")#mi("\\tau")#text(" using (31) to obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#tao-math("\\tau_1^{3/2} (\\left|X(\\tau_1)\\right|^2+R) \\leq \\frac{3}{2} 2\\tau^{1/2} l(t_1,x_1)", block: true)]]

#text("where we abbreviate ")#mi("l_{(t_0,x_0)}")#text(" as l. Using the first variation formulae for reduced length (see equations (14), (15) from ")#link("https://terrytao.wordpress.com/2008/05/14/285g-lecture-11-%ce%ba-noncollapsing-via-perelman-reduced-volume/")[#text("Lecture 11")]#text("), as well as the nonnegativity of R (and hence of l), we obtain the useful inequalities")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#tao-math("0 \\leq \\left|\\nabla l\\right|^2 + R \\leq \\frac{3l}{\\tau}", block: true)]]

#text("and")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("-\\frac{2l}{\\tau} \\leq \\partial_\\tau l \\leq \\frac{l}{\\tau}.")]]

#text("Informally, this means that at any given point ")#mi("(t_1,x_1)")#text(" to the past of ")#mi("(t_0,x_0)")#text(", l is roughly constant at spatial scales ")#mi("\\sqrt{\\tau}")#text(" and at temporal scales ")#mi("\\tau")#text(". Furthermore, if l is bounded, then one has bounded normalised curvature at such scales.")

#heading(level: 1)[#text("— A splitting theorem —")]

#text("Our final application of these ideas (or more precisely, of the strong maximum principle) will be to establish a dichotomy (due ")#link("http://www.ams.org/mathscinet-getitem?mr=862046")[#text("to Hamilton")]#text(") for 3-dimensional ")#mi("\\kappa")#text("-solutions: either their Ricci curvature is strictly positive, or the solution splits locally as the product of a line with a two-dimensional solution.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1. ")]#text(" Let ")#mi("t \\mapsto (M,g(t))")#text(" be a three-dimensional ")#mi("\\kappa")#text("-solution. Suppose that the Ricci tensor has a zero eigenvalue at some point ")#mi("(t_0,x_0)")#text(". Then on the slab ")#mi("(-\\infty,t_0) \\times M")#text(", the Ricci flow locally splits as the product of a two-dimensional Ricci flow and a line.")
]

#strong[#text("Proof.")]#text(" The first stage is to show that the Ricci tensor has a zero eigenvalue on all of")#linebreak()#text(" ")#mi("(-\\infty,t_0) \\times M")#text(". Let ")#mi("0 \\leq \\nu \\leq \\mu \\leq \\lambda")#text(" denote the three eigenvalues of the Riemann tensor ")#mi("{\\mathcal T}")#text(" as viewed in an orthonormal frame (as in ")#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("Lecture 3")]#text("), thus a zero eigenvalue of the Ricci tensor is equivalent to ")#mi("\\nu+\\mu=0")#text(". Suppose for contradiction that at some time ")#mi("t_1 < t_0")#text(", this quantity is not identically zero, thus we can find some non-negative scalar function ")#mi("h(t_1,\\cdot): M \\to {\\Bbb R}^+")#text(", not")#linebreak()#text(" identically zero, such that ")#mi("\\nu+\\mu \\geq h")#text(" at time ")#mi("t_1")#text(". We then extend h by the heat equation, so by the strong maximum principle h is strictly positive for all times after ")#mi("t_1")#text(". From the convexity of the functional ")#mi("\\nu+\\mu")#text(" (which one can view as the minimal trace of ")#mi("{\\mathcal T}")#text(" over two-dimensional subspaces), we see that the set ")#mi("\\{ ({\\mathcal T},h): \\nu+\\mu \\geq h \\}")#text(" cuts out a fibrewise convex parallel subset of a suitable vector bundle over ")#mi("{}[t_1,t_0] \\times M")#text(" (in the sense of the tensor maximum principle, Proposition 1 from ")#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("Lecture 3")]#text("), which one can easily check to be preserved under the ODE associated to the simultaneous evolution of (25) and the scalar heat equation for h.")#linebreak()#text(" Applying the tensor maximum principle we conclude that ")#mi("\\nu+\\mu \\geq h")#text(" for all times in ")#mi("{}[t_1,t_0]")#text(", and in particular that ")#mi("\\nu+\\mu")#text(" is non-zero at ")#mi("(t_0,x_0)")#text(", a contradiction. Thus the Ricci curvature must have a zero eigenvalue on all of ")#mi("(-\\infty,t_0) \\times M")#text(", thus ")#mi("\\nu=\\mu=0")#text(" on this slab. On the other hand, from Exercise 7 we must have ")#mi("\\lambda > 0")#text(" throughout this slab.")

#text("The symmetric rank 2 tensor ")#mi("{\\mathcal T}")#text(" thus has rank 1 at every point, and thus locally can be expressed in the form ")#mi("{\\mathcal T} = a v \\otimes v")#text(" for some smooth non-zero scalar a and a unit vector field v. (If M was orientable, one could extend this vector field to be global). The equation (25) then becomes")

#tao-aligned(keep: true)[


#tao-math("a_t v \\otimes v + a v \\otimes v_t + a v_t \\otimes v  & = (\\Delta a + a^2) v \\otimes v", block: true)



#tao-math(" & + (\\nabla^\\alpha a) (v \\otimes \\nabla_\\alpha v + \\nabla_\\alpha v \\otimes v) + 2a \\nabla_\\alpha v \\otimes \\nabla^\\alpha v.", block: true, numbering: n => [#text("(39)")])
]

#text("Since v is a unit vector field, the vector fields ")#mi("\\nabla_X v")#text(" are orthogonal to v for every v. Thus we can restrict to the component of (39) that is completely orthogonal to v, and conclude (since a is nonzero) that ")#mi("\\nabla_\\alpha v \\otimes \\nabla^\\alpha v = 0")#text(". If we then inspect the component of (39) which is partially orthogonal to v, we also learn that ")#mi("v_t = 0")#text(". Expressing the left-hand side in an orthonormal basis as the sum of rank one positive semi-definite matrices, we easily conclude that ")#mi("\\nabla_\\alpha v = 0")#text(", i.e. v is parallel to the connection. This implies that the dual one-form ")#mi("v^* \\in \\Gamma(T^* M)")#text(" is closed and hence locally exact; thus v is locally the gradient of some potential function f. From this we easily see that the flow locally splits as the product of a two-dimensional flow (on a level set of f) and a line (the flow lines of v), and then it is easy to verify that the two-dimensional flow is a Ricci flow, as claimed. ")#mi("\\Box")

#strong[#text("Remark 4")]#text(". One cannot always extend this local splitting to a global one, due to topological obstructions; consider for instance the oriented round shrinking cylinder quotient (Example 3 of ")#link("https://terrytao.wordpress.com/2008/05/16/285g-lecture-12-high-curvature-regions-of-ricci-flow-and-%ce%ba-solutions/")[#text("Lecture 12")]#text("). One could also imagine the product of a round shrinking ")#mi("S^2")#text(" and a static circle ")#mi("S^1")#text(", in which the null eigenvector of the Ricci tensor splits off as a circle rather than a line; but this is not a ")#mi("\\kappa")#text("-solution because it becomes collapsed at large scales in the distant past.")#linebreak()#text(" ")#mi("\\diamond")

#strong[#text("Remark 5.")]#text(" The above splitting analysis can be carried out in any dimension; for instance, one can show that the rank of the Riemann tensor is a constant for any ancient solution with bounded non-negative Riemann curvature. For this and further splitting results in this case, see the paper of ")#link("http://www.ams.org/mathscinet-getitem?mr=862046")[#text("Hamilton")]#text(". ")#mi("\\diamond")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 14: Stationary points of Perelman entropy or reduced volume are gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/#comment-29974")[#strong[#text("285G, Lecture 14: Stationary points of Perelman entropy or reduced volume are gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2008")])]

#text("[…] Perelman entropy, reduced volume, Ricci flow We continue our study of -solutions. In the previous lecture we primarily exploited the non-negative curvature of such solutions; in this lecture and the next, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 15: Geometric limits of Ricci flows, and asymptotic gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/#comment-30082")[#strong[#text("285G, Lecture 15: Geometric limits of Ricci flows, and asymptotic gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2008")])]

#text("[…] we use the estimates on reduced length from the Harnack inequality analysis in Lecture 13 to locate some good regions of spacetime of a -solution in which to do the asymptotic analysis. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 16: Classification of asymptotic gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/#comment-30136")[#strong[#text("285G, Lecture 16: Classification of asymptotic gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2008")])]

#text("[…] is if the scalar curvature vanishes also. But then the strong maximum principle (Exercise 7 from Lecture 13) forces the gradient shrinking soliton to be flat at all sufficiently early times (and hence at all […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 17: The structure of κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/#comment-30206")[#strong[#text("285G, Lecture 17: The structure of κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2008")])]

#text("[…] curvature vanishes at any point, then by Hamilton’s splitting theorem (Proposition 1 from Lecture 13) the flow splits (locally, at least) as a line and a two-dimensional flow. Passing to a double […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ky")]], [#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/#comment-31965")[#strong[#text("ky")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2008")])]

#text("I am lost as to how you get the coefficient of 2 on (34) from (26). Please elaborate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/#comment-31977")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2008")])]

#text("Dear ky,")

#text("Apply (26) with X replaced by 2X.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b51fd794e6e451a906600feca2af9d1d1167c662ce8edc2db7da43b7283e91d6-cc427d67fc77ab05f1a29d89486ac010f4e6c02de9c04fa843a890a47f83da4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Azita")]], [#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/#comment-460320")[#strong[#text("Azita")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2015")])]

#text("That was so helpful. thank you a lot.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adrian")]], [#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/#comment-613489")[#strong[#text("Adrian")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2020")])]

#text("Hi, Prof. Tao. Could you elaborate on Remark 1? Like what weight should we multiply exactly? Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/05/19/285g-lecture-13-li-yau-hamilton-harnack-inequalities-and-%ce%ba-solutions/#comment-613549")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2020")])]

#text("One can find a version of this argument for instance in the original paper of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=834612")[#text("Li and Yau")]#text(" (in Theorem 1.2; note that in the setting here one can set ")#mi("q,\\theta,\\gamma,K")#text(" to zero, then send ")#mi("R")#text(" to infinity and ")#mi("\\alpha")#text(" to 1). They apply a weight in a slightly different fashion from the one suggested here but the strategy is broadly the same.")
]
]
