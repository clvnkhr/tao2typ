// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/04/28/notes-on-nilcharacters-and-their-symbols/
// Converted to Typst by tao2typ: "2026-10-14T15:19:52.399532+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Notes on nilcharacters and their symbols", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Notes on nilcharacters and their symbols")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 April 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/04/28/notes-on-nilcharacters-and-their-symbols/")[#text("https://terrytao.wordpress.com/2017/04/28/notes-on-nilcharacters-and-their-symbols/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A sequence ")#mi("{a: {\\bf Z} \\rightarrow {\\bf C}}")#text(" of complex numbers is said to be ")#link("https://en.wikipedia.org/wiki/Quasiperiodic_motion")[#text("quasiperiodic")]#text(" if it is of the form")

#align(center)[#tao-fit-display[#mitex("a(n) = F( \\alpha_1 n \\text{ mod } 1, \\dots, \\alpha_k n \\text{ mod } 1)")]]

#text("for some real numbers ")#mi("{\\alpha_1,\\dots,\\alpha_k}")#text(" and continuous function ")#mi("{F: ({\\bf R}/{\\bf Z})^k \\rightarrow {\\bf C}}")#text(". For instance, linear phases such as ")#mi("{n \\mapsto e(\\alpha n + \\beta)}")#text(" (where ")#mi("{e(\\theta) := e^{2\\pi i \\theta}}")#text(") are examples of quasiperiodic sequences; the top order coefficient ")#mi("{\\alpha}")#text(" (modulo ")#mi("{1}")#text(") can be viewed as a “frequency” of the integers, and an element of the ")#link("https://en.wikipedia.org/wiki/Pontryagin_duality")[#text("Pontryagin dual")]#text(" ")#mi("{\\hat {\\bf Z} \\equiv {\\bf R}/{\\bf Z}}")#text(" of the integers. Any periodic sequence is also quasiperiodic (taking ")#mi("{k=1}")#text(" and ")#mi("{\\alpha_1}")#text(" to be the reciprocal of the period). A sequence is said to be ")#link("https://en.wikipedia.org/wiki/Almost_periodic_function")[#text("almost periodic")]#text(" if it is the uniform limit of quasiperiodic sequences. For instance any Fourier series of the form")

#align(center)[#tao-fit-display[#mitex("a(n) = \\sum_{j=1}^\\infty c_j e(\\alpha_j n)")]]

#text("with ")#mi("{\\alpha_1,\\alpha_2,\\dots}")#text(" real numbers and ")#mi("{c_1,c_2,\\dots}")#text(" an absolutely summable sequence of complex coefficients, will be almost periodic.")

#text("These sequences arise in various “complexity one” problems in arithmetic combinatorics and ergodic theory. For instance, if ")#mi("{(X, \\mu, T)}")#text(" is a measure-preserving system – a probability space ")#mi("{(X,\\mu)}")#text(" equipped with a measure-preserving shift, and ")#mi("{f_1,f_2 \\in L^\\infty(X)}")#text(" are bounded measurable functions, then the correlation sequence")

#align(center)[#tao-fit-display[#mitex("a(n) := \\int_X f_1(x) f_2(T^n x)\\ d\\mu(x)")]]

#text("can be shown to be an almost periodic sequence, plus an error term ")#mi("{b_n}")#text(" which is “null” in the sense that it has vanishing uniform density:")

#align(center)[#tao-fit-display[#tao-math("\\sup_N \\frac{1}{M} \\sum_{n=N+1}^{N+M} \\left|b_n\\right| \\rightarrow 0 \\text{ as } M \\rightarrow \\infty.", block: true)]]

#text("This can be established in a number of ways, for instance by writing ")#mi("{a(n)}")#text(" as the Fourier coefficients of the spectral measure of the shift ")#mi("{T}")#text(" with respect to the functions ")#mi("{f_1,f_2}")#text(", and then decomposing that measure into pure point and continuous components.")

#text("In the last two decades or so, it has become clear that there are natural higher order versions of these concepts, in which linear polynomials such as ")#mi("{\\alpha n + \\beta}")#text(" are replaced with higher degree counterparts. The most obvious candidates for these counterparts would be the polynomials ")#mi("{\\alpha_d n^d + \\dots + \\alpha_0}")#text(", but this turns out to not be a complete set of higher degree objects needed for the theory. Instead, the higher order versions of quasiperiodic and almost periodic sequences are now known as ")#emph[#text("basic nilsequences")]#text(" and ")#emph[#text("nilsequences")]#text(" respectively, while the higher order version of a linear phase is a ")#emph[#text("nilcharacter")]#text("; each nilcharacter then has a ")#emph[#text("symbol")]#text(" that is a higher order generalisation of the concept of a frequency (and the collection of all symbols forms a group that can be viewed as a higher order version of the Pontryagin dual of ")#mi("{{\\bf Z}}")#text("). The theory of these objects is spread out in the literature across a number of papers; in particular, the theory of nilcharacters is mostly developed in Appendix E of ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("this 116-page paper of Ben Green, Tamar Ziegler, and myself")]#text(", and is furthermore written using nonstandard analysis and treating the more general setting of higher dimensional sequences. I therefore decided to rewrite some of that material in this blog post, in the simpler context of the qualitative asymptotic theory of one-dimensional nilsequences and nilcharacters rather than the quantitative single-scale theory that is needed for combinatorial applications (and which necessitated the use of nonstandard analysis in the previous paper).")

#text("For technical reasons (having to do with the non-trivial topological structure on nilmanifolds), it will be convenient to work with vector-valued sequences, that take values in a finite-dimensional complex vector space ")#mi("{{\\bf C}^m}")#text(" rather than in ")#mi("{{\\bf C}}")#text(". By doing so, the space of sequences is now, technically, no longer a ring, as the operations of addition and multiplication on vector-valued sequences become ill-defined. However, we can still take complex conjugates of a sequence, and add sequences taking values in the same vector space ")#mi("{{\\bf C}^m}")#text(", and for sequences taking values in different vector spaces ")#mi("{{\\bf C}^m}")#text(", ")#mi("{{\\bf C}^{m^{\\prime}}}")#text(", we may utilise the ")#link("https://en.wikipedia.org/wiki/Tensor_product")[#text("tensor product")]#text(" ")#mi("{\\otimes: {\\bf C}^m \\times {\\bf C}^{m^{\\prime}} \\rightarrow {\\bf C}^{mm^{\\prime}}}")#text(", which we will normalise by defining")

#align(center)[#tao-fit-display[#mitex("(z_1,\\dots,z_m) \\otimes (w_1,\\dots,w_{m^{\\prime}}) = (z_1 w_1, \\dots, z_1 w_{m^{\\prime}}, \\dots, z_m w_1, \\dots, z_m w_{m^{\\prime}} ).")]]

#text("This product is associative and bilinear, and also commutative up to permutation of the indices. It also interacts well with the Hermitian norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (z_1,\\dots,z_m) \\right\\| := \\sqrt{\\left|z_1\\right|^2 + \\dots + \\left|z_m\\right|^2}", block: true)]]

#text("since we have ")#tao-math("{\\left\\|z \\otimes w\\right\\| = \\left\\|z\\right\\| \\left\\|w\\right\\|}", block: false)#text(".")

#text("The traditional definition of a basic nilsequence (as defined for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=2138068")[#text("by Bergelson, Host, and Kra")]#text(") is as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Basic nilsequence, first definition)")]#text(" A ")#emph[#text("nilmanifold of step at most ")#mi("{d}")]#text(" is a quotient ")#mi("{G/\\Gamma}")#text(", where ")#mi("{G}")#text(" is a connected, simply connected nilpotent Lie group of step at most ")#mi("{d}")#text(" (thus, all ")#mi("{d+1}")#text("-fold commutators vanish) and ")#mi("{\\Gamma}")#text(" is a discrete cocompact lattice in ")#mi("{G}")#text(". A ")#emph[#text("basic nilsequence of degree at most ")#mi("{d}")]#text(" is a sequence of the form ")#mi("{n \\mapsto F(g^n g_0 \\Gamma)}")#text(", where ")#mi("{g_0 \\Gamma \\in G/\\Gamma}")#text(", ")#mi("{g \\in G}")#text(", and ")#mi("{F: G/\\Gamma \\rightarrow {\\bf C}^m}")#text(" is a continuous function.")
]

#text("For instance, it is not difficult using this definition to show that a sequence is a basic nilsequence of degree at most ")#mi("{1}")#text(" if and only if it is quasiperiodic. The requirement that ")#mi("{G}")#text(" be simply connected can be easily removed if desired by passing to a universal cover, but it is technically convenient to assume it (among other things, it allows for a well-defined logarithm map that obeys the Baker-Campbell-Hausdorff formula). When one wishes to perform a more quantitative analysis of nilsequences (particularly when working on a “single scale”. sich as on a single long interval ")#mi("{\\{ N+1, \\dots, N+M\\}}")#text("), it is common to impose additional regularity conditions on the function ")#mi("{F}")#text(", such as Lipschitz continuity or smoothness, but ordinary continuity will suffice for the qualitative discussion in this blog post.")

#text("Nowadays, and particularly when one needs to understand the “single-scale” equidistribution properties of nilsequences, it is more convenient (as is for instance done in ")#link("https://arxiv.org/abs/1404.0093")[#text("this ICM paper of Green")]#text(") to use an alternate definition of a nilsequence as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2")]#text(" Let ")#mi("{d \\geq 0}")#text(". A ")#emph[#text("filtered group of degree at most ")#mi("{d}")]#text(" is a group ")#mi("{G}")#text(" together with a sequence ")#mi("{G_\\bullet = (G_0,G_1,G_2,\\dots)}")#text(" of subgroups ")#mi("{G \\geq G_0 \\geq G_1 \\geq \\dots}")#text(" with ")#mi("{G_{d+1}=\\{\\text{id}\\}}")#text(" and ")#mi("{[G_i,G_j] \\subset G_{i+j}}")#text(" for ")#mi("{i,j \\geq 0}")#text(". A ")#emph[#text("polynomial sequence")]#text(" ")#mi("{g: {\\bf Z} \\rightarrow G}")#text(" into a filtered group is a function such that ")#mi("{\\partial_{h_i} \\dots \\partial_{h_1} g(n) \\in G_i}")#text(" for all ")#mi("{i \\geq 0}")#text(" and ")#mi("{n,h_1,\\dots,h_i \\in{\\bf Z}}")#text(", where ")#mi("{\\partial_h g(n) := g(n+h) g(n)^{-1}}")#text(" is the difference operator. A ")#emph[#text("filtered nilmanifold of degree at most ")#mi("{s}")]#text(" is a quotient ")#mi("{G/\\Gamma}")#text(", where ")#mi("{G}")#text(" is a filtered group of degree at most ")#mi("{s}")#text(" such that ")#mi("{G}")#text(" and all of the subgroups ")#mi("{G_i}")#text(" are connected, simply connected nilpotent filtered Lie group, and ")#mi("{\\Gamma}")#text(" is a discrete cocompact subgroup of ")#mi("{G}")#text(" such that ")#mi("{\\Gamma_i := \\Gamma \\cap G_i}")#text(" is a discrete cocompact subgroup of ")#mi("{G_i}")#text(". A ")#emph[#text("basic nilsequence of degree at most ")#mi("{d}")]#text(" is a sequence of the form ")#mi("{n \\mapsto F(g(n))}")#text(", where ")#mi("{g: {\\bf Z} \\rightarrow G}")#text(" is a polynomial sequence, ")#mi("{G/\\Gamma}")#text(" is a filtered nilmanifold of degree at most ")#mi("{d}")#text(", and ")#mi("{F: G \\rightarrow {\\bf C}^m}")#text(" is a continuous function which is ")#mi("{\\Gamma}")#text("-automorphic, in the sense that ")#mi("{F(g \\gamma) = F(g)}")#text(" for all ")#mi("{g \\in G}")#text(" and ")#mi("{\\gamma \\in \\Gamma}")#text(".")
]

#text("One can easily identify a ")#mi("{\\Gamma}")#text("-automorphic function on ")#mi("{G}")#text(" with a function on ")#mi("{G/\\Gamma}")#text(", but there are some (very minor) advantages to working on the group ")#mi("{G}")#text(" instead of the quotient ")#mi("{G/\\Gamma}")#text(", as it becomes slightly easier to modify the automorphy group ")#mi("{\\Gamma}")#text(" when needed. (But because the action of ")#mi("{\\Gamma}")#text(" on ")#mi("{G}")#text(" is free, one can pass from ")#mi("{\\Gamma}")#text("-automorphic functions on ")#mi("{G}")#text(" to functions on ")#mi("{G/\\Gamma}")#text(" with very little difficulty.) The main reason to work with polynomial sequences ")#mi("{n \\mapsto g(n)}")#text(" rather than geometric progressions ")#mi("{n \\mapsto g^n g_0 \\Gamma}")#text(" is that they form a group, a fact essentially established by ")#link("http://www.ams.org/mathscinet-getitem?mr=88496")[#text("by Lazard")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1608723")[#text("Leibman")]#text("; see Corollary B.4 of ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("this paper of Green, Ziegler, and myself")]#text(" for a proof in the filtered group setting.")

#text("It is easy to see that any sequence that is a basic nilsequence of degree at most ")#mi("{d}")#text(" in the sense of the first definition, is also a basic nilsequence of degree at most ")#mi("{d}")#text(" in the second definition, since a nilmanifold of degree at most ")#mi("{d}")#text(" can be filtered using the ")#link("https://en.wikipedia.org/wiki/Central_series")[#text("lower central series")]#text(", and any linear sequence ")#mi("{n \\mapsto g^n g_0}")#text(" will be a polynomial sequence with respect to that filtration. The converse implication is a little trickier, but still not too hard to show: see Appendix C of ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("this paper of Ben Green, Tamar Ziegler, and myself")]#text(". There are two key examples of basic nilsequences to keep in mind. The first are the polynomially quasiperiodic sequences")

#align(center)[#tao-fit-display[#mitex("a(n) = F( P_1(n), \\dots, P_k(n) ),")]]

#text("where ")#mi("{P_1,\\dots,P_k: {\\bf Z} \\rightarrow {\\bf R}}")#text(" are polynomials of degree at most ")#mi("{d}")#text(", and ")#mi("{F: {\\bf R}^k \\rightarrow {\\bf C}^m}")#text(" is a ")#mi("{{\\bf Z}^k}")#text("-automorphic (i.e., ")#mi("{{\\bf Z}^k}")#text("-periodic) continuous function. The map ")#mi("{P: {\\bf Z} \\rightarrow {\\bf R}^k}")#text(" defined by ")#mi("{P(n) := (P_1(n),\\dots,P_k(n))}")#text(" is a polynomial map of degree at most ")#mi("{d}")#text(", if one filters ")#mi("{{\\bf R}^k}")#text(" by defining ")#mi("{({\\bf R}^k)_i}")#text(" to equal ")#mi("{{\\bf R}^k}")#text(" when ")#mi("{i \\leq d}")#text(", and ")#mi("{\\{0\\}}")#text(" for ")#mi("{i > d}")#text(". The torus ")#mi("{{\\bf R}^k/{\\bf Z}^k}")#text(" then becomes a filtered nilmanifold of degree at most ")#mi("{d}")#text(", and ")#mi("{a(n)}")#text(" is thus a basic nilsequence of degree at most ")#mi("{d}")#text(" as per the second definition. It is also possible explicitly describe ")#mi("{a_n}")#text(" as a basic nilsequence of degree at most ")#mi("{d}")#text(" as per the first definition, for instance (in the ")#mi("{k=1}")#text(" case) by taking ")#mi("{G}")#text(" to be the space of upper triangular unipotent ")#mi("{d+1 \\times d+1}")#text(" real matrices, and ")#mi("{\\Gamma}")#text(" the subgroup with integer coefficients; we leave the details to the interested reader.")

#text("The other key example is a sequence of the form")

#align(center)[#tao-fit-display[#mitex("a(n) = F( \\alpha n, \\{ \\alpha n \\} \\beta n )")]]

#text("where ")#mi("{\\alpha,\\beta}")#text(" are real numbers, ")#mi("{\\{ \\alpha n \\} = \\alpha n - \\lfloor \\alpha n \\rfloor}")#text(" denotes the fractional part of ")#mi("{\\alpha n}")#text(", and and ")#mi("{F: {\\bf R}^2 \\rightarrow {\\bf C}^m}")#text(" is a ")#mi("{{\\bf Z}^2}")#text("-automorphic continuous function that vanishes in a neighbourhood of ")#mi("{{\\bf Z} \\times {\\bf R}}")#text(". To describe this as a nilsequence, we use the nilpotent connected, simply connected degree ")#mi("{2}")#text(", Heisenberg group")

#align(center)[#tao-fit-display[#mitex("G := \\begin{pmatrix} 1 & {\\bf R} & {\\bf R} \\\\ 0 & 1 & {\\bf R} \\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("with the lower central series filtration ")#mi("{G_0=G_1=G}")#text(", ")#mi("{G_2= [G,G] = \\begin{pmatrix} 1 &0 & {\\bf R} \\\\ 0 & 1 & 0 \\\\ 0 & 0 & 1 \\end{pmatrix}}")#text(", and ")#mi("{G_i = \\{ \\mathrm{id} \\}}")#text(" for ")#mi("{i > 2}")#text(", ")#mi("{\\Gamma}")#text(" to be the discrete compact subgroup")

#align(center)[#tao-fit-display[#mitex("\\Gamma := \\begin{pmatrix} 1 & {\\bf Z} & {\\bf Z} \\\\ 0 & 1 & {\\bf Z} \\\\ 0 & 0 & 1 \\end{pmatrix},")]]

#mi("{g: {\\bf Z} \\rightarrow G}")#text(" to be the polynomial sequence")

#align(center)[#tao-fit-display[#mitex("g(n) := \\begin{pmatrix} 1 & \\beta n & \\alpha \\beta n^2 \\\\ 0 & 1 & \\alpha n \\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("and ")#mi("{\\tilde F: G \\rightarrow {\\bf C}^m}")#text(" to be the ")#mi("{\\Gamma}")#text("-automorphic function")

#align(center)[#tao-fit-display[#mitex("\\tilde F( \\begin{pmatrix} 1 & x & y \\\\ 0 & 1 & z \\\\ 0 & 0 & 1 \\end{pmatrix} ) = F( \\{ z \\}, y - \\lfloor z \\rfloor x );")]]

#text("one easily verifies that this function is indeed ")#mi("{\\Gamma}")#text("-automorphic, and it is continuous thanks to the vanishing properties of ")#mi("{F}")#text(". Also we have ")#mi("{a(n) = \\tilde F(g(n))}")#text(", so ")#mi("{a}")#text(" is a basic nilsequence of degree at most ")#mi("{2}")#text(". One can concoct similar examples with ")#mi("{\\{ \\alpha n \\} \\beta n}")#text(" replaced by other “bracket polynomials” of ")#mi("{n}")#text("; for instance")

#align(center)[#tao-fit-display[#mitex("a(n) = F( \\alpha n, \\{ \\alpha n - \\frac{1}{2} \\} \\beta n )")]]

#text("will be a basic nilsequence if ")#mi("{F}")#text(" now vanishes in a neighbourhood of ")#mi("{(\\frac{1}{2}+{\\bf Z}) \\times {\\bf R}}")#text(" rather than ")#mi("{{\\bf Z} \\times {\\bf R}}")#text(". See ")#link("http://www.ams.org/mathscinet-getitem?mr=2318563")[#text("this paper of Bergelson and Leibman")]#text(" for more discussion of bracket polynomials (also known as generalised polynomials) and their relationship to nilsequences.")

#text("A ")#emph[#text("nilsequence of degree at most ")#mi("{d}")]#text(" is defined to be a sequence that is the uniform limit of basic nilsequences of degree at most ")#mi("{d}")#text(". Thus for instance a sequence is a nilsequence of degree at most ")#mi("{1}")#text(" if and only if it is almost periodic, while a sequence is a nilsequence of degree at most ")#mi("{0}")#text(" if and only if it is constant. Such objects arise in higher order recurrence: for instance, if ")#mi("{h_0,\\dots,h_d}")#text(" are integers, ")#mi("{(X,\\mu,T)}")#text(" is a measure-preserving system, and ")#mi("{f_0,\\dots,f_d \\in L^\\infty(X)}")#text(", then it was ")#link("http://www.ams.org/mathscinet-getitem?mr=3294297")[#text("shown by Leibman")]#text(" that the sequence")

#align(center)[#tao-fit-display[#mitex("n \\mapsto \\int_X f_0(T^{h_0 n} x) \\dots f_d(T^{h_d n} x)\\ d\\mu(x)")]]

#text("is equal to a nilsequence of degree at most ")#mi("{d}")#text(", plus a null sequence. (The special case when the measure-preserving system was ergodic and ")#mi("{h_i = i}")#text(" for ")#mi("{i=0,\\dots,d}")#text(" was previously established by ")#link("http://www.ams.org/mathscinet-getitem?mr=2138068")[#text("Bergelson, Host, and Kra")]#text(".) Nilsequences also arise in the inverse theory of the Gowers uniformity norms, as discussed for instance in ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("this previous post")]#text(".")

#text("It is easy to see that a sequence ")#mi("{a: {\\bf Z} \\rightarrow {\\bf C}^m}")#text(" is a basic nilsequence of degree at most ")#mi("{d}")#text(" if and only if each of its ")#mi("{m}")#text(" components are. The scalar basic nilsequences ")#mi("{a: {\\bf Z} \\rightarrow {\\bf C}}")#text(" of degree ")#mi("{d}")#text(" are easily seen to form a ")#mi("{*}")#text("-algebra (that is to say, they are a complex vector space closed under pointwise multiplication and complex conjugation), which implies similarly that vector-valued basic nilsequences ")#mi("{a: {\\bf Z} \\rightarrow {\\bf C}^m}")#text(" of degree at most ")#mi("{d}")#text(" form a complex vector space closed under complex conjugation for each ")#mi("{m}")#text(", and that the tensor product of any two basic nilsequences of degree at most ")#mi("{d}")#text(" is another basic nilsequence of degree at most ")#mi("{d}")#text(". Similarly with “basic nilsequence” replaced by “nilsequence” throughout.")

#text("Now we turn to the notion of a nilcharacter, as defined in ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("this paper of Ben Green, Tamar Ziegler, and myself")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3 (Nilcharacters)")]#text(" Let ")#mi("{d \\geq 1}")#text(". A ")#emph[#text("sub-nilcharacter of degree ")#mi("{d}")]#text(" is a basic nilsequence ")#mi("{\\chi: n \\mapsto F(g(n))}")#text(" of degree at most ")#mi("{d}")#text(", such that ")#mi("{F}")#text(" obeys the additional modulation property ")#metadata(none) <tao-74101a325e6263b37f11>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("F( g_d g ) = e( \\xi \\cdot g_d ) F(g)")]]

#text("for all ")#mi("{g \\in G}")#text(" and ")#mi("{g_d \\in G_d}")#text(", where ")#mi("{\\xi: G_d \\rightarrow {\\bf R}}")#text(" is a continuous homomorphism ")#mi("{g_d \\mapsto \\xi \\cdot g_d}")#text(". (Note from ")#link(<tao-74101a325e6263b37f11>)[#text("(1)")]#text(" and ")#mi("{\\Gamma}")#text("-automorphy that unless ")#mi("{F}")#text(" vanishes identically, ")#mi("{\\xi}")#text(" must map ")#mi("{\\Gamma_d}")#text(" to ")#mi("{{\\bf Z}}")#text(", thus without loss of generality one can view ")#mi("{\\xi}")#text(" as an element of the Pontryagial dual of the torus ")#mi("{G_d / \\Gamma_d}")#text(".) If in addition one has ")#tao-math("{\\left\\|F(g)\\right\\|=1}", block: false)#text(" for all ")#mi("{g \\in G}")#text(", we call ")#mi("{\\chi}")#text(" a ")#emph[#text("nilcharacter")]#text(" of degree ")#mi("{d \\geq 1}")#text(".")
]

#text("In the degree one case ")#mi("{d=1}")#text(", the only sub-nilcharacters are of the form ")#mi("{\\chi(n) = e(\\alpha n)}")#text(" for some vector ")#mi("{c \\in {\\bf C}^m}")#text(" and ")#mi("{\\alpha \\in {\\bf R}}")#text(", and this is a nilcharacter if ")#mi("{c}")#text(" is a unit vector. Similarly, in higher degree, any sequence of the form ")#mi("{\\chi(n) = c e(P(n))}")#text(", where ")#mi("{c \\in {\\bf C}^m}")#text(" is a vector and ")#mi("{P: {\\bf Z} \\rightarrow {\\bf R}}")#text(" is a polynomial of degree at most ")#mi("{d}")#text(", is a sub-nilcharacter of degree ")#mi("{d}")#text(", and a character if ")#mi("{c}")#text(" is a unit vector. A nilsequence of degree at most ")#mi("{d-1}")#text(" is automatically a sub-nilcharacter of degree ")#mi("{d}")#text(", and a nilcharacter if it is of magnitude ")#mi("{1}")#text(". A further example of a nilcharacter is provided by the two-dimensional sequence ")#mi("{\\chi: {\\bf Z} \\rightarrow {\\bf C}^2}")#text(" defined by ")#metadata(none) <tao-5312fb609f60384731fc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\chi(n) := ( F_0( \\alpha n ) e( \\{ \\alpha n \\} \\beta n ), F_{1/2}( \\alpha n ) e( \\{ \\alpha n - \\frac{1}{2} \\} \\beta n ) )")]]

#text("where ")#mi("{F_0, F_{1/2}: {\\bf R} \\rightarrow {\\bf C}}")#text(" are continuous, ")#mi("{{\\bf Z}}")#text("-automorphic functions that vanish on a neighbourhood of ")#mi("{{\\bf Z}}")#text(" and ")#mi("{\\frac{1}{2}+{\\bf Z}}")#text(" respectively, and which form a partition of unity in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\left|F_0(x)\\right|^2 + \\left|F_{1/2}(x)\\right|^2 = 1", block: true)]]

#text("for all ")#mi("{x \\in {\\bf R}}")#text(". Note that one needs both ")#mi("{F_0}")#text(" and ")#mi("{F_{1/2}}")#text(" to be not identically zero in order for all these conditions to be satisfied; it turns out (for topological reasons) that there is no scalar nilcharacter that is “equivalent” to this nilcharacter in a sense to be defined shortly. In some literature, one works exclusively with sub-nilcharacters rather than nilcharacters, however the former space contains zero-divisors, which is a little annoying technically. Nevertheless, both nilcharacters and sub-nilcharacters generate the same set of “symbols” as we shall see later.")

#text("We claim that every degree ")#mi("{d}")#text(" sub-nilcharacter ")#mi("{f: {\\bf Z} \\rightarrow {\\bf C}^m}")#text(" can be expressed in the form ")#mi("{f = c \\chi}")#text(", where ")#mi("{\\chi: {\\bf Z} \\rightarrow {\\bf C}^{m^{\\prime}}}")#text(" is a degree ")#mi("{d}")#text(" nilcharacter, and ")#mi("{c: {\\bf C}^{m^{\\prime}} \\rightarrow {\\bf C}^m}")#text(" is a linear transformation. Indeed, by scaling we may assume ")#mi("{f(n) = F(g(n))}")#text(" where ")#tao-math("{\\left|F\\right| < 1}", block: false)#text(" uniformly. Using partitions of unity, one can find further functions ")#mi("{F_1,\\dots,F_m}")#text(" also obeying ")#link(<tao-74101a325e6263b37f11>)[#text("(1)")]#text(" for the same character ")#mi("{\\xi}")#text(" such that ")#tao-math("{\\left|F_1\\right|^2 + \\dots + \\left|F_m\\right|^2}", block: false)#text(" is non-zero; by dividing out the ")#mi("{F_1,\\dots,F_m}")#text(" by the square root of this quantity, and then multiplying by ")#tao-math("{\\sqrt{1-\\left|F\\right|^2}}", block: false)#text(", we may assume that")

#align(center)[#tao-fit-display[#tao-math("\\left|F\\right|^2 + \\left|F_1\\right|^2 + \\dots + \\left|F_m\\right|^2 = 1,", block: true)]]

#text("and then")

#align(center)[#tao-fit-display[#mitex("\\chi(n) := (F(g(n)), F_1(g(n)), \\dots, F_m(g(n)))")]]

#text("becomes a degree ")#mi("{d}")#text(" nilcharacter that contains ")#mi("{f(n)}")#text(" amongst its components, giving the claim.")

#text("As we shall show below, nilsequences can be approximated uniformly by linear combinations of nilcharacters, in much the same way that quasiperiodic or almost periodic sequences can be approximated uniformly by linear combinations of linear phases. In particular, nilcharacters can be used as “obstructions to uniformity” in the sense of the inverse theory of the Gowers uniformity norms.")

#text("The space of degree ")#mi("{d}")#text(" nilcharacters forms a semigroup under tensor product, with the constant sequence ")#mi("{1}")#text(" as the identity. One can upgrade this semigroup to an abelian group by quotienting nilcharacters out by equivalence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4")]#text(" Let ")#mi("{d \\geq 1}")#text(". We say that two degree ")#mi("{d}")#text(" nilcharacters ")#mi("{\\chi: {\\bf Z} \\rightarrow {\\bf C}^m}")#text(", ")#mi("{\\chi^{\\prime}: {\\bf Z} \\rightarrow {\\bf C}^{m^{\\prime}}}")#text(" are ")#emph[#text("equivalent")]#text(" if ")#mi("{\\chi \\otimes \\overline{\\chi^{\\prime}}: {\\bf Z} \\rightarrow {\\bf C}^{mm^{\\prime}}}")#text(" is equal (as a sequence) to a basic nilsequence of degree at most ")#mi("{d-1}")#text(". (We will later show that this is indeed an equivalence relation.) The equivalence class ")#mi("{[\\chi]_{\\mathrm{Symb}^d({\\bf Z})}}")#text(" of such a nilcharacter will be called the ")#emph[#text("symbol")]#text(" of that nilcharacter (in analogy to the ")#link("https://en.wikipedia.org/wiki/Symbol_of_a_differential_operator")[#text("symbol of a differential or pseudodifferential operator")]#text("), and the collection of such symbols will be denoted ")#mi("{\\mathrm{Symb}^d({\\bf Z})}")#text(".")
]

#text("As we shall see below the fold, ")#mi("{\\mathrm{Symb}^d({\\bf Z})}")#text(" has the structure of an abelian group, and enjoys some nice “symbol calculus” properties; also, one can view symbols as precisely describing the obstruction to equidistribution for nilsequences. For ")#mi("{d=1}")#text(", the group is isomorphic to the Ponytragin dual ")#mi("{\\hat {\\bf Z} = {\\bf R}/{\\bf Z}}")#text(" of the integers, and ")#mi("{\\mathrm{Symb}^d({\\bf Z})}")#text(" for ")#mi("{d > 1}")#text(" should be viewed as higher order generalisations of this Pontryagin dual. In principle, this group can be explicitly described for all ")#mi("{d}")#text(", but the theory rapidly gets complicated as ")#mi("{d}")#text(" increases (much as the classification of nilpotent Lie groups or Lie algebras of step ")#mi("{d}")#text(" rapidly gets complicated even for medium-sized ")#mi("{d}")#text(" such as ")#mi("{d=3}")#text(" or ")#mi("{d=4}")#text("). We will give an explicit description of the ")#mi("{d=2}")#text(" case here. There is however one nice (and non-trivial) feature of ")#mi("{\\mathrm{Symb}^d({\\bf Z})}")#text(" for ")#mi("{d \\geq 2}")#text(" – it is not just an abelian group, but is in fact a vector space over the rationals ")#mi("{{\\bf Q}}")#text("!")

#metadata(none) <tao-12bc39c5fc53632e6f01>

#heading(level: 1)[#strong[#text(" — 1. Properties of nilcharacters — ")]]

#text("Much of the material here is an adaptation of material from Appendix E of ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("my paper with Green and Ziegler")]#text(". We focus primarily on nilcharacters, and discuss the theory of sub-nilcharacters in Remark ")#link(<tao-b6020b2fa4cee6ca6ce5>)[#text("9")]#text(".")

#text("We begin with the verification that equivalence of nilcharacters is indeed an equivalence relation. Symmetry is obvious (since the conjugate of a basic nilsequence is again a basic nilsequence). Now we turn to reflexivity. Let ")#mi("{\\chi(n) = F( g(n) )}")#text(" be a degree ")#mi("{d}")#text(" nilcharacter. Then ")#mi("{\\chi \\otimes \\overline{\\chi}}")#text(" can be written as")

#align(center)[#tao-fit-display[#mitex("\\chi \\otimes \\overline{\\chi}(n) = F \\otimes \\overline{F}( g(n) ).")]]

#text("From ")#link(<tao-74101a325e6263b37f11>)[#text("(1)")]#text(" we see that the function ")#mi("{F \\otimes \\overline{F}: G \\rightarrow {\\bf C}^{m^2}}")#text(" is ")#mi("{G_d}")#text("-invariant, and thus descends upon quotienting by the closed central subgroup ")#mi("{G_d}")#text(" of ")#mi("{G}")#text(" to a function on ")#mi("{G/G_d}")#text(" (which is ")#mi("{\\Gamma G_d/G_d}")#text(" invariant). As ")#mi("{G/G_d}")#text(" is a filtered group of degree at most ")#mi("{d-1}")#text(", and ")#mi("{G/\\Gamma G_d}")#text(" is similarly a filtered nilmanifold of degree at most ")#mi("{d-1}")#text(", this lets us describe ")#mi("{\\chi \\otimes \\overline{\\chi}}")#text(" as a nilsequence of degree ")#mi("{\\leq d-1}")#text(", giving the claim. (It is instructive to calculate ")#mi("{\\chi \\otimes \\overline{\\chi}}")#text(" explicitly for the example ")#link(<tao-5312fb609f60384731fc>)[#text("(2)")]#text(" to see the quasiperiodic structure.) Finally, we show transitivity. If ")#mi("{\\chi_1}")#text(" is equivalent to ")#mi("{\\chi_2}")#text(", and ")#mi("{\\chi_2}")#text(" is equivalent to ")#mi("{\\chi_3}")#text(", then ")#mi("{\\chi_1 \\otimes \\overline{\\chi_2}}")#text(" and ")#mi("{\\chi_2 \\otimes \\overline{\\chi_3}}")#text(" are both nilsequences of degree ")#mi("{\\leq d-1}")#text(", so their tensor product ")#mi("{\\chi_1 \\otimes \\overline{\\chi_2} \\otimes \\chi_2 \\otimes \\overline{\\chi_3}}")#text(" is also. On the other hand, ")#mi("{\\chi_2}")#text(" has magnitude ")#mi("{1}")#text(", so ")#mi("{\\overline{\\chi_2} \\otimes \\chi_2}")#text(" has trace one. Contracting, we conclude that ")#mi("{\\chi_1 \\otimes \\overline{\\chi_3}}")#text(" is a nilsequence of degree ")#mi("{\\leq d-1}")#text(", establishing transitivity.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" A variant of the above arguments shows that two degree ")#mi("{d}")#text(" nilcharacters ")#mi("{\\chi: {\\bf Z} \\rightarrow {\\bf C}^m}")#text(", ")#mi("{\\chi^{\\prime}: {\\bf Z} \\rightarrow {\\bf C}^{m^{\\prime}}}")#text(" are equivalent if and only if ")#mi("{\\chi}")#text(" can be expressed as ")#mi("{c (\\chi^{\\prime} \\otimes \\psi)}")#text(" for some nilsequence ")#mi("{\\psi: {\\bf Z} \\rightarrow {\\bf C}^{m^{\\prime\\prime}}}")#text(" of degree at most ")#mi("{d-1}")#text(", and some linear transformation ")#mi("{c: {\\bf C}^{m^{\\prime}m^{\\prime\\prime}} \\rightarrow {\\bf C}^m}")#text(".")
]

#text("Now we impose a group structure on ")#mi("{\\mathrm{Symb}^d({\\bf Z})}")#text(" by taking")

#align(center)[#tao-fit-display[#mitex("0 := [1]_{\\mathrm{Symb}^d({\\bf Z})}")]]

#text("to be the identity element,")

#align(center)[#tao-fit-display[#mitex("- [\\chi]_{\\mathrm{Symb}^d({\\bf Z})} := [\\overline{\\chi}]_{\\mathrm{Symb}^d({\\bf Z})}")]]

#text("to be the negation operation, and")

#align(center)[#tao-fit-display[#mitex("[\\chi]_{\\mathrm{Symb}^d({\\bf Z})} + [\\chi^{\\prime}]_{\\mathrm{Symb}^d({\\bf Z})} := [\\chi \\otimes \\chi^{\\prime}]_{\\mathrm{Symb}^d({\\bf Z})}")]]

#text("to be the group operation, for any degree ")#mi("{d}")#text(" nilcharacters ")#mi("{\\chi,\\chi^{\\prime}}")#text(".")

#text("It is clear that negation is well-defined: if ")#mi("{\\chi}")#text(" is equivalent to ")#mi("{\\chi^{\\prime}}")#text(", then ")#mi("{\\overline{\\chi}}")#text(" is equivalent to ")#mi("{\\overline{\\chi^{\\prime}}}")#text(". Similarly, the group operation is well-defined; for instance, if ")#mi("{\\chi^{\\prime}}")#text(" is equivalent to ")#mi("{\\chi^{\\prime\\prime}}")#text(", then ")#mi("{\\chi \\otimes \\chi^{\\prime}}")#text(" is equivalent to ")#mi("{\\chi \\otimes \\chi^{\\prime\\prime}}")#text(", since ")#mi("{(\\chi \\otimes \\chi^{\\prime}) \\otimes \\overline{(\\chi \\otimes \\chi^{\\prime\\prime})}}")#text(" is a rearrangement of the tensor product of ")#mi("{\\chi \\otimes \\overline{\\chi}}")#text(" and ")#mi("{\\chi^{\\prime} \\otimes \\overline{\\chi^{\\prime\\prime}}}")#text(", both of which are known to be nilsequences of degree at most ")#mi("{d-1}")#text(". It is also routine to check that the group operation is commutative and associative, that ")#mi("{0}")#text(" is indeed the group identity, and that the negation operation is the inverse of the addition operation.")

#text("Now we show that any nilsequence ")#mi("{f: {\\bf Z} \\rightarrow {\\bf C}^m}")#text(" of degree at most ")#mi("{d}")#text(" may be approximated uniformly by finite linear combinations")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^k c_j \\chi_j")]]

#text("of degree ")#mi("{d}")#text(" nilsequences ")#mi("{\\chi_j: {\\bf Z} \\rightarrow {\\bf C}^{m_j}}")#text(", where ")#mi("{c_j: {\\bf C}^{m_j} \\rightarrow {\\bf C}^m}")#text(" are linear transformations. Clearly it suffices to show this for a basic nilsequence ")#mi("{f(n) = F(g(n))}")#text(". By the Stone-Weierstrass theorem, the continuous function ")#mi("{F}")#text(" can be approximated uniformly by smooth functions, so we may assume without loss of generality that ")#mi("{F}")#text(" is smooth. Quotienting out by the discrete group ")#mi("{\\Gamma_d}")#text(", ")#mi("{F}")#text(" now descends to a function on ")#mi("{G/\\Gamma_d}")#text(", which has a central free action of the torus ")#mi("{G_d/\\Gamma_d}")#text(". Performing a (uniformly convergent) Fourier decomposition with respect to this group action (or, if one prefers, decomposing into isotypic components of this action), we may assume that ")#mi("{F}")#text(" obeys the equivariance property ")#link(<tao-74101a325e6263b37f11>)[#text("(1)")]#text(" for some character ")#mi("{\\xi}")#text(" from ")#mi("{G_d/\\Gamma_d}")#text(" to ")#mi("{{\\bf R}/{\\bf Z}}")#text(", which makes it a sub-nilcharacter, and the claim then follows.")

#text("In the case ")#mi("{d=1}")#text(", we have already noted that every nilcharacter takes the form ")#mi("{\\chi(n) = c e(\\alpha n)}")#text(" for some real number ")#mi("{\\alpha}")#text(" and unit vector ")#mi("{c}")#text(", and it is easy to see that two such nilcharacters ")#mi("{c e(\\alpha n)}")#text(", ")#mi("{c^{\\prime} e(\\alpha^{\\prime} n)}")#text(" are equivalent if and only if ")#mi("{\\alpha}")#text(" and ")#mi("{\\alpha^{\\prime}}")#text(" differ by an integer. As such, one readily verifies that ")#mi("{\\mathrm{Symb}^1({\\bf Z})}")#text(" is isomorphic to ")#mi("{{\\bf R}/{\\bf Z}}")#text(", with the symbol of ")#mi("{c e(\\alpha n)}")#text(" being identified with ")#mi("{\\alpha \\text{ mod } 1}")#text(". Similarly, if ")#mi("{d > 1}")#text(" and one restricts attention to nilcharacters of the form ")#mi("{\\chi(n) = c e(\\alpha_d n^d + \\dots + \\alpha_0)}")#text(", then the nilcharacters are equivalent if and only if the ")#mi("{\\alpha_d}")#text(" differ by a rational, and so ")#mi("{\\mathrm{Symb}^d({\\bf Z})}")#text(" contains a copy of ")#mi("{{\\bf R}/{\\bf Q}}")#text(", with the symbol of ")#mi("{c e(\\alpha_d n^d + \\dots + \\alpha_0)}")#text(" being identified with ")#mi("{\\alpha_d \\text{ mod } {\\bf Q}}")#text(". (Among other things, this suggests that there is no particularly good (e.g. Hausdorff) topology to place on ")#mi("{\\mathrm{Symb}^d({\\bf Z})}")#text(" for ")#mi("{d>1}")#text(", in contrast to the Pontryagin dual which has a natural topology (the ")#link("https://en.wikipedia.org/wiki/Compact-open_topology")[#text("compact-open topology")]#text(").")

#text("Nilcharacters behave well with translation and dilation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Affine symmetry)")]#text(" ")#metadata(none) <tao-d18b0d4411bb927a0d70>#text(" Let ")#mi("{d \\geq 1}")#text(", and let ")#mi("{\\chi: {\\bf Z} \\rightarrow {\\bf C}^m}")#text(" be a nilcharacter.")

#list(
[#text("For any integer ")#mi("{h}")#text(", the shift ")#mi("{n \\mapsto \\chi(n+h)}")#text(" is equivalent to ")#mi("{\\chi}")#text(": ")#mi("{[\\chi(\\cdot+h)]_{\\mathrm{Symb}^d({\\bf Z})} = [\\chi]_{\\mathrm{Symb}^d({\\bf Z})}}")#text(".")],
[#text("For any integer ")#mi("{q}")#text(", the dilation ")#mi("{n \\mapsto \\chi(qn)}")#text(" is equivalent to ")#mi("{\\chi^{\\otimes q^d}}")#text(" (the tensor product of ")#mi("{q^d}")#text(" copies of ")#mi("{\\chi}")#text(": ")#mi("{[\\chi(q\\cdot)]_{\\mathrm{Symb}^d({\\bf Z})} = q^d[\\chi]_{\\mathrm{Symb}^d({\\bf Z})}}")#text(".")]
)
]

#text("The reader may check that this lemma is consistent with the identification of the symbol of ")#mi("{c e(\\alpha_d n^d + \\dots + \\alpha_0)}")#text(" with ")#mi("{\\alpha_d \\text{ mod } {\\bf Q}}")#text(".")

#emph[#text("Proof:")]#text(" For the first claim, it suffices to represent ")#mi("{\\chi(\\cdot+h) \\otimes \\overline{\\chi}(\\cdot)}")#text(" as a nilsequence of degree at most ")#mi("{d-1}")#text(". If ")#mi("{\\chi(n) = F(g(n))}")#text(", then this sequence can be expanded as")

#align(center)[#tao-fit-display[#mitex("n \\mapsto F(g(n+h)) \\otimes \\overline{F}(g(n)).")]]

#text("The sequence ")#mi("{n \\mapsto (g(n+h), g(n))}")#text(" can be verified to be a polynomial sequence in ")#mi("{G^\\Box}")#text(", which is defined to be the filtered group ")#mi("{G^\\Box = G_0 \\times_{G_1} G_0}")#text(" with subgroups ")#mi("{G^\\Box_i := G_i \\times_{G_{i+1}} G_i}")#text(", where ")#mi("{G_i \\times_{G_{i+1}} G_i}")#text(" is the collection of pairs ")#mi("{(g_i, g^{\\prime}_i) \\in G_i \\times G_i}")#text(" such that ")#mi("{g_i \\in g^{\\prime}_i G_{i+1}}")#text(". From ")#link(<tao-74101a325e6263b37f11>)[#text("(1)")]#text(" we see that the function ")#mi("{(g,g^{\\prime}) \\mapsto F(g) \\otimes \\overline{F}(g^{\\prime})}")#text(" is invariant with respect to the central action of ")#mi("{G^\\Box_d}")#text(" (which is the diagonally embedded copy of ")#mi("{G_d}")#text(" in ")#mi("{G_d \\times G_d}")#text("). If we then define ")#mi("{\\overline{G^\\Box}}")#text(" to be the quotient of ")#mi("{G^\\Box}")#text(" by ")#mi("{G^\\Box_d}")#text(", this is now a filtered group of degree at most ")#mi("{d-1}")#text(", and the polynomial sequence ")#mi("{n \\mapsto (g(n+h),g(n))}")#text(" projects to a polynomial sequence ")#mi("{\\overline{g^\\Box}}")#text(" in ")#mi("{\\overline{G^\\Box}}")#text(", with a representation of the form")

#align(center)[#tao-fit-display[#mitex("F(g(n+h)) \\otimes \\overline{F}(g(n)) = \\overline{F^\\Box}( \\overline{g^\\Box}(n))")]]

#text("for some continuous function ")#mi("{\\overline{F^\\Box}: \\overline{G^\\Box} \\rightarrow {\\bf C}^{m^2}}")#text(" which is automorphic with respect to the projection of ")#mi("{G^\\Box}")#text(" to ")#mi("{\\overline{G^\\Box}}")#text(". This gives the first claim.")

#text("The second claim is proven similarly, with the role of ")#mi("{G_i \\times_{G_{i+1}} G_i}")#text(" being played by the collection of pairs ")#mi("{(g_i, g^{\\prime}_i) \\in G_i \\times G_i}")#text(" such that ")#mi("{g_i \\in (g^{\\prime}_i)^{q^i} G_{i+1}}")#text("; we leave the details to the interested reader (or see Lemma E.8(v) of ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("my paper with Green and Ziegler")]#text("). ")#mi("\\Box")

#text("Now we connect the symbol with equidistribution.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7")]#text(" ")#metadata(none) <tao-7d601f9d20703a97b8cb>#text(" Let ")#mi("{d \\geq 1}")#text(", and let ")#mi("{\\chi: {\\bf R} \\rightarrow {\\bf C}^m}")#text(" be a nilcharacter. Then ")#mi("{[\\chi]_{\\mathrm{Symb}^d({\\bf Z})}}")#text(" vanishes if and only if there exists a nilsequence ")#mi("{f}")#text(" of degree at most ")#mi("{d-1}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{N \\rightarrow \\infty} \\left|\\sum_{n=1}^N \\chi(n) \\otimes f(n)\\right| > 0.", block: true)]]
]

#text("Actually, the limits of sequences such as ")#mi("{\\lim_{N \\rightarrow \\infty} \\sum_{n=1}^N \\chi(n) \\otimes f(n)}")#text(" always exist, and are in fact equal to ")#mi("{\\lim_{N \\rightarrow \\infty} \\sum_{n=M_N+1}^{M_N+N} \\chi(n) \\otimes f(n)}")#text(" for an arbitrary sequence ")#mi("{M_N}")#text("; this follows from the equidistribution theorem ")#link("http://www.ams.org/mathscinet-getitem?mr=2122920")[#text("of Leibman")]#text(".")

#emph[#text("Proof:")]#text(" If ")#mi("{[\\chi]_{\\mathrm{Symb}^d({\\bf Z})}}")#text(" vanishes, then ")#mi("{\\chi}")#text(" is a nilsequence of degree ")#mi("{d-1}")#text(", and ")#mi("{\\chi \\otimes \\overline{\\chi}}")#text(" has trace ")#mi("{!1}")#text(". The forward implication then follows by taking ")#mi("{f = \\overline{\\chi}}")#text(".")

#text("Now we establish the converse implication. As ")#mi("{f}")#text(" is a sub-nilcharacter of vanishing symbol, we may write it as a linear transform of a nilcharacter ")#mi("{\\chi^{\\prime}}")#text(" of vanishing symbol. By replacing ")#mi("{\\chi}")#text(" with ")#mi("{\\chi \\otimes \\chi^{\\prime}}")#text(" (which does not affect the symbol), we may thus assume without loss of generality that ")#mi("{f}")#text(" is the identity, that is to say we may assume without loss of generality that")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{N \\rightarrow \\infty} \\left|\\sum_{n=1}^N \\chi(n)\\right| > 0.", block: true)]]

#text("When ")#mi("{d=1}")#text(" this immediately shows that ")#mi("{\\chi}")#text(" is constant from Fourier analysis, so assume ")#mi("{d>1}")#text(". Write ")#mi("{\\chi(n) = F(g(n))}")#text(". Now we appeal to the factorisation theorem for nilsequences (see Corollary 1.12 of ")#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/")[#text("this paper of myself and Ben Green")]#text(" to factorise")

#align(center)[#tao-fit-display[#mitex("g(n) = \\varepsilon g^{\\prime}(n) \\gamma(n)")]]

#text("where ")#mi("{\\varepsilon \\in G}")#text(" is a constant, ")#mi("{\\gamma}")#text(" is a polynomial sequence which is rational in the sense that there is a natural number ")#mi("{m}")#text(" such that ")#mi("{\\gamma(n)^m \\in\\Gamma}")#text(" for all ")#mi("{n \\in {\\bf Z}}")#text(" (which, among other things, implies that ")#mi("{\\gamma(n) \\Gamma^{\\prime}}")#text(" is periodic in ")#mi("{n}")#text(" for any subgroup ")#mi("{\\Gamma^{\\prime}}")#text(" ")#link("https://en.wikipedia.org/wiki/Commensurability_(mathematics)")[#text("commensurate")]#text(" to ")#mi("{\\Gamma}")#text("), and ")#mi("{g^{\\prime}}")#text(" is another periodic sequence which takes values in a filtered subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" such that ")#mi("{G^{\\prime} = G^{\\prime}_0}")#text(" and ")#mi("{G^{\\prime}_i}")#text(" is a connected, simply connected Lie group containing ")#mi("{\\Gamma \\cap G^{\\prime}_i}")#text(" as a cocompact subgroup for each ")#mi("{i}")#text(", such that ")#mi("{g^{\\prime}(n) \\Gamma^{\\prime}}")#text(" is totally equidistributed (that is, equidistributed along any arithmetic progression) in ")#mi("{G^{\\prime}/\\Gamma^{\\prime}}")#text(" for any ")#mi("{\\Gamma^{\\prime}}")#text(" commensurate to ")#mi("{\\Gamma \\cap G^{\\prime}}")#text(".")

#text("By the triangle inequality, we can find an arithmetic progression in which ")#mi("{\\gamma(n) = \\gamma}")#text(" is constant and ")#mi("{\\chi}")#text(" has non-zero mean. On this progression we have ")#mi("{\\chi(n) = \\tilde F(g^{\\prime}(n))}")#text(", where ")#mi("{\\tilde F: G^{\\prime} \\rightarrow {\\bf C}^m}")#text(" is the function ")#mi("{\\tilde F(g) := F(\\varepsilon g \\gamma)}")#text(". This function is automorphic with respect to the group ")#mi("{\\gamma^{-1} \\Gamma \\gamma \\cap G^{\\prime}}")#text(", which is commensurate with ")#mi("{\\Gamma \\cap G^{\\prime}}")#text(" as ")#mi("{\\gamma}")#text(" is rational; by equidistribution, we conclude that ")#mi("{\\tilde F}")#text(" has non-zero mean on ")#mi("{G^{\\prime}}")#text(". But ")#mi("{\\tilde F}")#text(" obeys the equivariance property ")#link(<tao-74101a325e6263b37f11>)[#text("(1)")]#text(" for ")#mi("{g_d}")#text(" in ")#mi("{G^{\\prime}_d}")#text(", and hence ")#mi("{\\xi}")#text(" must annihilate all of ")#mi("{G^{\\prime}_d}")#text(". Quotienting out by ")#mi("{G^{\\prime}_d}")#text(", we can thus represent ")#mi("{\\chi}")#text(" on this progression by a nilsequence of degree at most ")#mi("{d-1}")#text(". On other progressions of the same spacing, the constant ")#mi("{\\gamma}")#text(" changes, but ")#mi("{\\xi}")#text(" still annihilates ")#mi("{G^{\\prime}_d}")#text(", so ")#mi("{\\chi}")#text(" is also a nilsequence of degree at most ")#mi("{d-1}")#text(" on all other progressions. Since the indicator function of an arithmetic progression is also a nilsequence of degree at most ")#mi("{1}")#text(", and hence at most ")#mi("{d-1}")#text(", ")#mi("{\\chi}")#text(" itself is a nilsequence of degree at most ")#mi("{d-1}")#text(", as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" One can almost obtain this result by using the ")#link("http://www.ams.org/mathscinet-getitem?mr=2644354")[#text("arguments of Bogdanov and Viola")]#text(", but the assertion that ")#mi("{[\\chi]_{\\mathrm{Symb}^d({\\bf Z})}}")#text(" vanishes becomes replaced with the weaker assertion that ")#mi("{[\\chi]_{\\mathrm{Symb}^d({\\bf Z})}}")#text(" can be approximated to arbitrary accuracy (in some normalised ")#mi("{\\ell^1}")#text(" sense) by nilsequences of degree at most ")#mi("{d-1}")#text(". In the finite field setting one can use an “error correction” argument to recover an analogue of the above proposition by the Bogdanov-Viola argument; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2592422")[#text("this paper of Ben Green and myself")]#text(". But we do not know how to do this in the nilsequence setting without using the same sort of machinery used in the above proof of the proposition.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" ")#metadata(none) <tao-b6020b2fa4cee6ca6ce5>#text(" Now we can discuss the relationship of sub-nilcharacters with nilcharacters. We have already observed that any degree ")#mi("{d}")#text(" sub-nilcharacter ")#mi("{f}")#text(" is of the form ")#mi("{c \\psi}")#text(", where ")#mi("{\\psi}")#text(" is a degree ")#mi("{d}")#text(" nilcharacter and ")#mi("{c}")#text(" is a linear transformation; conversely, any sequence of the form ")#mi("{c \\psi}")#text(" will be a degree ")#mi("{d}")#text(" sub-nilcharacter. If a sub-nilcharacter ")#mi("{f}")#text(" that is not identically zero has two representations ")#mi("{f = c \\psi = c^{\\prime} \\psi^{\\prime}}")#text(", then ")#tao-math("{\\left|f\\right|^2 = \\tilde c( \\psi \\otimes \\overline{\\psi^{\\prime}})}", block: false)#text(" for some linear functional ")#mi("{\\tilde c}")#text(". The mean of ")#tao-math("{\\left|f\\right|^2}", block: false)#text(" is then non-zero by the equidistribution theory of nilmanifolds, hence by the above proposition, ")#mi("{[\\psi \\otimes \\overline{\\psi^{\\prime}}]_{\\mathrm{Symb}^d({\\bf Z})}}")#text(" vanishes, thus ")#mi("{\\psi}")#text(" and ")#mi("{\\psi^{\\prime}}")#text(" have the same symbol. Because of this, it becomes meaningful to talk about the symbol ")#mi("{[f]_{\\mathrm{Symb}^d({\\bf Z})}}")#text(" of a sub-nilcharacter as long as it is not identically zero. This symbol can then easily be verified to be a homomorphism in the sense that ")#mi("{[f \\otimes f^{\\prime}]_{\\mathrm{Symb}^d({\\bf Z})} = [f]_{\\mathrm{Symb}^d({\\bf Z})} + [f^{\\prime}]_{\\mathrm{Symb}^d({\\bf Z})}}")#text(" whenever ")#mi("{f,f^{\\prime}}")#text(" are degree ")#mi("{d}")#text(" sub-nilcharacters with ")#mi("{f \\otimes f^{\\prime}}")#text(" not identically zero. Thus one has a reasonably satisfactory theory of symbols for sub-nilcharacters as well as nilcharacters, although the presence of zero divisors does create some additional annoying technical issues, which is the main reason we focus instead on nilcharacters in this post.")

#text("For similar reasons, we can also assign a symbol in ")#mi("{\\mathrm{Symb}^d({\\bf Z})}")#text(" to any bracket polynomial of degree at most ")#mi("{d}")#text("; we omit the details.")
]

#text("Now we discuss the structure of ")#mi("{\\mathrm{Symb}^2({\\bf Z})}")#text(". Amongst the elements of this group, we have the symbols ")#mi("{[\\alpha]}")#text(" for ")#mi("{\\alpha \\in {\\bf R}}")#text(", defined as the symbol of the nilcharacter ")#mi("{n \\mapsto e(\\alpha n^2)}")#text(". These symbols obey the laws")

#align(center)[#tao-fit-display[#mitex("[\\alpha] + [\\beta] = [\\alpha+\\beta]")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("[a/q] = 0")]]

#text("for any rational ")#mi("{a/q}")#text(" (since ")#mi("{n \\mapsto e(an^2/q)}")#text(" is periodic and thus a nilsequence of degree at most ")#mi("{1}")#text("). In addition, we have the symbols ")#mi("{[\\alpha \\ast \\beta]}")#text(", defined for ")#mi("{\\alpha,\\beta \\in {\\bf R}}")#text(" to be the symbol of the nilcharacter ")#link(<tao-5312fb609f60384731fc>)[#text("(2)")]#text(". It is clear from definition that these symbols are linear in ")#mi("{\\beta}")#text(": ")#metadata(none) <tao-38760eabb666e8e61ee6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("[\\alpha \\ast \\beta] + [\\alpha \\ast \\beta^{\\prime}] = [\\alpha \\ast (\\beta+\\beta^{\\prime})].")]]

#text("Also, if one of ")#mi("{\\alpha}")#text(" or ")#mi("{\\beta}")#text(" is rational, then the nilcharacter collapses to a nilsequence of degree at most one, and thus")

#align(center)[#tao-fit-display[#mitex("[a/q * \\alpha] = [\\alpha * a/q] = 0")]]

#text("for any rational ")#mi("{a/q}")#text(" and real ")#mi("{\\alpha}")#text(". Furthermore, we also have the identity")

#align(center)[#tao-fit-display[#mitex("[\\alpha * \\beta] + [\\beta * \\alpha] = [\\alpha \\beta].")]]

#text("To see this, observe that ")#mi("{e( (\\alpha n - \\{ \\alpha n \\})(\\beta n - \\{\\beta n \\})) = 1}")#text(" since the argument of ")#mi("{e()}")#text(" is the product of two integers. We can rewrite this as")

#align(center)[#tao-fit-display[#mitex("e( \\{ \\alpha n \\} \\beta n ) e( \\{ \\beta n \\} \\alpha n ) = e( \\alpha \\beta n ).")]]

#text("The sub-nilcharacter ")#mi("{F( \\alpha n ) e( \\{ \\alpha n \\} \\beta n )}")#text(", where ")#mi("{F: {\\bf R} \\rightarrow {\\bf C}}")#text(" is ")#mi("{{\\bf Z}}")#text("-automorphic and vanishing on a neighbourhood of ")#mi("{{\\bf Z}}")#text(", has symbol ")#mi("{[\\alpha*\\beta]}")#text(", and similarly ")#mi("{F( \\beta n ) e( \\{ \\beta n \\} \\alpha n )}")#text(" has symbol ")#mi("{[\\beta*\\alpha]}")#text(". One can arrange matters so that the product is not identically zero, and by the above identity the symbol will be ")#mi("{[\\alpha \\beta]}")#text(", giving the claim. From this and ")#link(<tao-38760eabb666e8e61ee6>)[#text("(3)")]#text(" we see that ")#mi("{\\alpha \\ast \\beta}")#text(" is also linear in ")#mi("{\\alpha}")#text(":")

#align(center)[#tao-fit-display[#mitex("[\\alpha \\ast \\beta] + [\\alpha^{\\prime} \\ast \\beta] = [(\\alpha + \\alpha^{\\prime}) \\ast \\beta].")]]

#text("Finally, noting that ")#mi("{F(\\alpha n / 2) e( (\\alpha n - \\{ \\alpha n \\})^2 / 2)}")#text(" is a nilsequence of degree at most ")#mi("{1}")#text(" if ")#mi("{F}")#text(" vanishes on a neighbourhood of ")#mi("{{\\bf Z}/2}")#text(", one can show that")

#align(center)[#tao-fit-display[#mitex("[\\alpha * \\alpha] = [\\alpha^2 / 2].")]]

#text("These turn out to be a generating set of identities for ")#mi("{\\mathrm{Symb}^2({\\bf Z})}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10")]#text(" ")#mi("{\\mathrm{Symb}^2({\\bf Z})}")#text(" is generated by the symbols ")#mi("{[\\alpha]}")#text(" and ")#mi("{[\\alpha * \\beta]}")#text(" for ")#mi("{\\alpha,\\beta \\in {\\bf R}}")#text(", subject to the identities listed above.")
]

#emph[#text("Proof:")]#text(" The fact that any degree ")#mi("{2}")#text(" nilcharacter can be expressed as a finite integer linear combination of the symbols ")#mi("{[\\alpha]}")#text(" and ")#mi("{[\\alpha * \\beta]}")#text(" follows from the calculations in Section 12 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2391635")[#text("this paper of Green and myself")]#text(". Now we need to show that a finite integer linear combination of these symbols only vanishes when such vanishing can be deduced from the above relations. Given such a combination, we can use express all real numbers ")#mi("{\\alpha,\\beta}")#text(" involved as integer combinations of a linearly independent basis ")#mi("{1, \\xi_1,\\dots,\\xi_m}")#text(" over the rationals, and after many applications of the above identities we may then place the linear combination in the normal form ")#metadata(none) <tao-48d4a7bd3a31b5c7366c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{1 \\leq i < j \\leq m} a_{ij} [\\xi_i * \\xi_j] + [\\eta]")]]

#text("for some integers ")#mi("{a_{ij}}")#text(" and real ")#mi("{\\eta}")#text(". It will then suffice to show that such linear combinations can only vanish when all the ")#mi("{a_{ij}}")#text(" are zero and ")#mi("{\\eta}")#text(" is a rational.")

#text("The claim is clear when the ")#mi("{a_{ij}}")#text(" all vanish, so suppose for instance that ")#mi("{a_{12}}")#text(" does not vanish. If one takes ")#mi("{G}")#text(" to be the free nilpotent Lie group of degree ")#mi("{2}")#text(" generated by ")#mi("{m}")#text(" generators ")#mi("{e_1,\\dots,e_m}")#text(", and ")#mi("{\\Gamma}")#text(" to be the discrete subgroup generated by the same generators, then one can construct a sub-nilsequence ")#mi("{f}")#text(" with the symbol ")#link(<tao-48d4a7bd3a31b5c7366c>)[#text("(4)")]#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("f(n) := e(\\eta n^2) F( e_m^{\\xi_m n} \\dots e_1^{\\xi_1 n} )")]]

#text("where ")#mi("{F:G \\rightarrow {\\bf C}}")#text(" is a continuous ")#mi("{\\Gamma}")#text("-automorphic function such that ")#metadata(none) <tao-9d618f3636ac431ded95>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("F( [e_j, e_i]^t g ) = e(a_{ij} t) F(g)")]]

#text("for all ")#mi("{1 \\leq i < j \\leq n}")#text(", ")#mi("{g \\in G}")#text(", and ")#mi("{t \\in {\\bf R}}")#text(".")

#text("If the symbol ")#link(<tao-48d4a7bd3a31b5c7366c>)[#text("(4)")]#text(" vanishes, then this sub-nilsequence must correlate with a linear phase, thus")

#align(center)[#tao-fit-display[#mitex("n \\mapsto e(\\eta n^2 + \\gamma n) F( e_m^{\\xi_m n} \\dots e_1^{\\xi_1 n} )")]]

#text("must have non-zero mean. Suppose first that ")#mi("{\\eta}")#text(" is irrational. The sequence ")#mi("{n \\mapsto (\\eta n^2 + \\gamma_n, e_m^{\\xi_m n} \\dots e_1^{\\xi_1 n} )}")#text(" is a polynomial sequence into ")#mi("{{\\bf R} \\times G}")#text(", whose quotient onto the abelianisation ")#mi("{{\\bf R} \\times {\\bf R}^m}")#text(" is easily seen to be equidistributed modulo ")#mi("{{\\bf Z} \\times {\\bf Z}^m}")#text(". Applying the equidistribution results , this implies that the polynomial sequence into ")#mi("{{\\bf R} \\times G}")#text(" is equidistributed modulo ")#mi("{{\\bf Z} \\times \\Gamma}")#text(". This implies that the ")#mi("{{\\bf Z} \\times \\Gamma}")#text("-automorphic function")

#align(center)[#tao-fit-display[#mitex("(x, g) \\mapsto e(x) F(g)")]]

#text("on ")#mi("{{\\bf R} \\times G}")#text(" has mean zero, which is absurd thanks to the ")#mi("{e(x)}")#text(" component. Similarly if ")#mi("{\\gamma}")#text(" is irrational and independent (over ")#mi("{{\\bf Q}}")#text(") of the ")#mi("{1,\\xi_1,\\dots,\\xi_m}")#text(". The only remaining case is when ")#mi("{\\xi}")#text(" is rational and ")#mi("{\\gamma}")#text(" is a linear combination over ")#mi("{{\\bf Q}}")#text(" of the ")#mi("{1,\\xi_1,\\dots,\\xi_m}")#text(". By dividing the ")#mi("{\\xi_i}")#text(" by a suitable natural number (and multiplying the ")#mi("{a_{i,j}}")#text(" appropriately), we may assume that ")#mi("{\\gamma}")#text(" is the sum of a rational and an integer combination of the ")#mi("{\\xi_1,\\dots,\\xi_m}")#text(", and then by passing to a suitable arithmetic progression we can absorb the ")#mi("{e(\\eta n^2 + \\gamma n)}")#text(" term into the ")#mi("{F}")#text(" term. The above equidistribution analysis now implies that ")#mi("{F}")#text(" has non-zero mean on ")#mi("{G}")#text(", hich is absurd thanks to ")#link(<tao-9d618f3636ac431ded95>)[#text("(5)")]#text(" applied to the nonzero coefficient ")#mi("{a_{12}}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 11")]#text(" We can now define an anti-symmetric form ")#mi("{\\wedge}")#text(" from ")#mi("{{\\bf R}/{\\bf Q} \\rightarrow {\\bf R}/{\\bf Q}}")#text(" to ")#mi("{\\mathrm{Symb}^2({\\bf Z})}")#text(" by defining")

#align(center)[#tao-fit-display[#mitex("(\\alpha+{\\bf Q}) \\wedge (\\beta+{\\bf Q}) := [\\alpha * \\beta] - [\\alpha \\beta / 2]")]]

#text("for any real ")#mi("{\\alpha,\\beta}")#text("; one can check using the above identities that this is indeed a well-defined anti-symmetric form. The above proposition then gives an isomorphism")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Symb}^2({\\bf Z}) \\equiv \\bigwedge^2 {\\bf R}/{\\bf Q} \\oplus {\\bf R}/{\\bf Q}")]]

#text("where we view ")#mi("{{\\bf R}/{\\bf Q}}")#text(" as a vector space over ")#mi("{{\\bf Q}}")#text(". In particular ")#mi("{\\mathrm{Symb}^2({\\bf Z})}")#text(" is a vector space over ")#mi("{{\\bf Q}}")#text(".")
]

#text("In principle, one could extend the above calculations to higher degrees, and give similarly explicit descriptions of ")#mi("{\\mathrm{Symb}^d({\\bf Z})}")#text(" for higher ")#mi("{d}")#text(". The claculations appear to become rather complicated, however. Nevertheless, we can at least establish the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 12")]#text(" If ")#mi("{d \\geq 2}")#text(", then the abelian group ")#mi("{\\mathrm{Symb}^d({\\bf Z})}")#text(" can be given the structure of a vector space over ")#mi("{{\\bf Q}}")#text(".")
]

#emph[#text("Proof:")]#text(" In order to give a suitable action of ")#mi("{{\\bf Q}}")#text(" on ")#mi("{\\mathrm{Symb}^d({\\bf Z})}")#text(", one needs to show two things:")

#list(
[#text("(")#link("https://en.wikipedia.org/wiki/Divisible_group")[#text("divisible group")]#text(") For every degree ")#mi("{d}")#text(" nilcharacter ")#mi("{\\chi}")#text(" and natural number ")#mi("{q}")#text(", there exists a degree ")#mi("{d}")#text(" nilcharacter ")#mi("{\\chi^{\\prime}}")#text(" such that ")#mi("{(\\chi^{\\prime})^{\\otimes q}}")#text(" is equivalent to ")#mi("{\\chi}")#text(".")],
[#text("(")#link("https://en.wikipedia.org/wiki/Torsion_(algebra)")[#text("torsion-free")]#text(") If ")#mi("{\\chi}")#text(" is a degree ")#mi("{d}")#text(" nilcharacter and ")#mi("{q}")#text(" is a natural number such that ")#mi("{\\chi^{\\otimes q}}")#text(" has vanishing symbol, then ")#mi("{\\chi}")#text(" also has vanishing symbol.")]
)

#text("We begin with divisibility. It suffices by Lemma ")#link(<tao-d18b0d4411bb927a0d70>)[#text("6")]#text(" to write ")#mi("{\\chi(n)}")#text(" as ")#mi("{\\chi^{\\prime\\prime}(q n)}")#text(" for some degree ")#mi("{d}")#text(" nilcharacter ")#mi("{\\chi^{\\prime\\prime}}")#text(", since one can then take ")#mi("{\\chi^{\\prime}}")#text(" equal to ")#mi("{(\\chi^{\\prime\\prime})^{\\otimes q^{d-1}}}")#text(". This in turn is achievable if we can extend the polynomial sequence ")#mi("{n \\mapsto g(n)}")#text(" from ")#mi("{{\\bf Z}}")#text(" to ")#mi("{G}")#text(" associated to ")#mi("{\\chi}")#text(" to a continuous polynomial sequence ")#mi("{t \\mapsto g(t)}")#text(" from ")#mi("{{\\bf R}}")#text(" to ")#mi("{G}")#text(". But any polynomial sequence can be written in the form ")#mi("{g(n) = g_0 g_1^n \\dots g_d^{n^d}}")#text(" for some ")#mi("{g_i \\in G_i}")#text(", and one simply takes ")#mi("{g(t) = g_0 g_1^t \\dots g_d^{t^d}}")#text(" for ")#mi("{t \\in {\\bf R}}")#text(" (using the logarithm and exponential maps on the simply connected nilpotent groups ")#mi("{G_i}")#text(" to define the operation of raising to real powers). This establishes divisibility; we note that this also holds when ")#mi("{d=1}")#text(".")

#text("Now we establish that ")#mi("{\\mathrm{Symb}^d({\\bf Z})}")#text(" is torsion-free. If ")#mi("{\\chi^{\\otimes q}}")#text(" has vanishing symbol, then by Lemma ")#link(<tao-d18b0d4411bb927a0d70>)[#text("6")]#text(", ")#mi("{n \\mapsto \\chi(qn)}")#text(" is a nilsequence of degree at most ")#mi("{d-1}")#text(", and hence correlates with a nilcharacter ")#mi("{\\chi^{\\prime}}")#text(" of degree ")#mi("{d-1}")#text(". By the divisibility argument, we can write ")#mi("{\\chi^{\\prime}(n) = \\chi^{\\prime\\prime}(qn)}")#text(" for another nilcharacter ")#mi("{\\chi^{\\prime\\prime}}")#text(" of degree ")#mi("{d-1}")#text(". Thus ")#mi("{\\chi}")#text(" correlates with ")#mi("{\\chi^{\\prime\\prime}}")#text(" on an arithmetic progression of spacing ")#mi("{q}")#text(", and hence by Fourier expansion (and the hypothesis ")#mi("{d \\geq 1}")#text(") we see that ")#mi("{\\chi}")#text(" correlates with a nilcharacter of degree at most ")#mi("{d-1}")#text(" on the entire integers, giving the claim. ")#mi("\\Box")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/280eb763735af9573fe0d6e75160fdf49201f7fc4518e12e9dcfa711d060e39c-18f8b145e6dd0013890319f91ec2381fab0403832c045f9c7cb662b5103fceab.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Romain Viguier")]], [#link("https://terrytao.wordpress.com/2017/04/28/notes-on-nilcharacters-and-their-symbols/#comment-480144")[#strong[#text("Romain Viguier")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2017")])]

#text("Thanks for this article, you are a great teacher. One remark: the symetry implies by the definition seems to implies a bilinear model with the following symetry : one part well defined and target-adapted, the other part seems to be also target-adapted but sounds imaginary. I wonder if this implies strange interaction with nilcharacters. In fact, I think it is a way to smoothly transform topological maniflods.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/280eb763735af9573fe0d6e75160fdf49201f7fc4518e12e9dcfa711d060e39c-18f8b145e6dd0013890319f91ec2381fab0403832c045f9c7cb662b5103fceab.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Romain Viguier")]], [#link("https://terrytao.wordpress.com/2017/04/28/notes-on-nilcharacters-and-their-symbols/#comment-480145")[#strong[#text("Romain Viguier")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2017")])]

#text("My comment refers mainly to def 4.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f2f72f6b07913ad4746c420968ca8ec8cc8f1afb83b080e97af974bbbe053c2-6f5e495e194a711e1e6550b1a582eddca7192ae9250817c29f78ea0891feb348.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Smith")]], [#link("https://terrytao.wordpress.com/2017/04/28/notes-on-nilcharacters-and-their-symbols/#comment-480177")[#strong[#text("John Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2017")])]

#text("Good luck on your attempt on the Riemann Hypothesis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebfc592b1dfe7fbc6b3db328a99edb83965e209243aac288de1eab2dfbe8d3f1-16dafef2e9965161b0fbab76d6686363904d5e3a458785859ad5a274d999afb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian")]], [#link("https://terrytao.wordpress.com/2017/04/28/notes-on-nilcharacters-and-their-symbols/#comment-480184")[#strong[#text("Ian")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2017")])]

#text("I think you mean “By doing so the space of sequences is now” instead of “By doing the space of sequences is now.”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2017/04/28/notes-on-nilcharacters-and-their-symbols/#comment-480369")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2017")])]

#text("Dear Prof. Tao, in the fourth displaystyle eqn. from above, replace “n + M” by “N + M” above the summation sigma sign.")

#emph[#text("[Corrected, thanks -T.]")]
]
