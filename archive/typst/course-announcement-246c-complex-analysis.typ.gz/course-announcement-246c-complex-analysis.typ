// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/03/13/course-announcement-246c-complex-analysis/
// Converted to Typst by tao2typ: "2026-10-14T16:38:18.045534+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Course announcement: 246C, complex analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Course announcement: 246C, complex analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 March 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/03/13/course-announcement-246c-complex-analysis/")[#text("https://terrytao.wordpress.com/2018/03/13/course-announcement-246c-complex-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Next quarter (starting Monday, April 2) I will be teaching ")#link("https://ccle.ucla.edu/course/view/18S-MATH246C-1")[#text("Math 246C (complex analysis)")]#text(" here at UCLA. This is the third in a three-series graduate course on complex analysis; a few years ago I taught the ")#link("https://terrytao.wordpress.com/category/teaching/246a-complex-analysis/")[#text("first course in this series (246A)")]#text(", so this course can be thought of in some sense as a sequel to that one (and would certainly assume knowledge of the material in that course as a prerequisite), although it also assumes knowledge of material from the second course 246B (which covers such topics as Weierstrass factorization and the theory of harmonic functions).")

#text("246C is primarily a topics course, and tends to be a somewhat miscellaneous collection of complex analysis subjects that were not covered in the previous two installments of the series. The initial topics I have in mind to cover are")

#list(
[#link("https://en.wikipedia.org/wiki/Elliptic_function")[#text("Elliptic functions")]#text(";")],
[#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93Roch_theorem")[#text("The Riemann-Roch theorem")]#text(";")],
[#link("https://en.wikipedia.org/wiki/Circle_packing")[#text("Circle packings")]#text(";")],
[#link("https://en.wikipedia.org/wiki/De_Branges%27s_theorem")[#text("The Bieberbach conjecture")]#text(" (proven by de Branges); and")],
[#link("https://en.wikipedia.org/wiki/Schramm%E2%80%93Loewner_evolution")[#text("the Schramm-Loewner equation")]#text(" (SLE).")],
[#text("This list is however subject to change (it is the first time I will have taught on any of these topics, and I am not yet certain on the most logical way to arrange them; also I am not completely certain that I will be able to cover all the above topics in ten weeks). I welcome reference recommendations and other suggestions from readers who have taught on one or more of these topics.")]
)

#text("As usual, I will be posting lecture notes on this blog as the course progresses.")

#text("[Update: Mar 13: removed elliptic functions, as I have just learned that this was already covered in the prior 246B course.]")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/13/course-announcement-246c-complex-analysis/#comment-493860")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2018")])]

#text("Another possible topic is ")#mi("H^p")#text(" spaces.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2018/03/13/course-announcement-246c-complex-analysis/#comment-493910")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2018")])]

#text("I can’t wait for the notes, and will certainly gladly give any corrections I might find.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jaikrishnan Janardhanan")]], [#link("https://terrytao.wordpress.com/2018/03/13/course-announcement-246c-complex-analysis/#comment-493925")[#strong[#text("Jaikrishnan Janardhanan")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2018")])]

#text("One topic I am very fond of teaching is the Ahlfors–Schwarz lemma and using to give proofs of the big Picard theorem, the general Montel’s theorem, etc. The book “Complex Analysis: The geometric viewpoint” has a very nice presentation of all this. The book also introduces several invariant metrics which are indispensable in the study of holomorphic mappings in higher dimensions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2018/03/13/course-announcement-246c-complex-analysis/#comment-493978")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2018")])]

#text("There’s a discussion of Riemann Roch theorem in Chapter 21 of Fulton’s “Algebraic Topology” after the chapter on Riemann Surfaces and Algebraic Curves in Part X on Riemann Surfaces. It is also in Chapter 5 of Joe Polchinski’s book on String Theory.")

#text("One wishes to integrate objects over a “curve” ")#mi("X = \\{ (z,w): F(z,w) = 0 \\}")#text(". I very modestly assume that “cohomology” just means “integrals” and carry on.")

#text("I don’t know much about SLE except that it relates conformal mappings and random walk. It gets very complicated. Oded Schramm wrote about many exciting statistical models during his time at Microsoft :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3350ea12313b7116ad58455ab52de9c62b9e60ca8e79d147b166aca6e96376c-8c6d570bbcad244403921e6664f3a0c639372027274ef91d01ddb37a26d76ce5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rob")]], [#link("https://terrytao.wordpress.com/2018/03/13/course-announcement-246c-complex-analysis/#comment-494067")[#strong[#text("Rob")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2018")])]

#text("Are the notes from 246B available? Thanks :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Russell")]], [#link("https://terrytao.wordpress.com/2018/03/13/course-announcement-246c-complex-analysis/#comment-494081")[#strong[#text("Russell")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2018")])]

#text("John Garnett taught the 246B course, we did the last few chapters of Ahlfors Complex Analysis, Caratheodory’s theorem, the Uniformization theorem, and intro to univalent functions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3350ea12313b7116ad58455ab52de9c62b9e60ca8e79d147b166aca6e96376c-8c6d570bbcad244403921e6664f3a0c639372027274ef91d01ddb37a26d76ce5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rob")]], [#link("https://terrytao.wordpress.com/2018/03/13/course-announcement-246c-complex-analysis/#comment-494083")[#strong[#text("Rob")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2018")])]

#text("Thank you Russell :)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/13/course-announcement-246c-complex-analysis/#comment-494788")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2018")])]

#text("It would be interesting to see some elliptic modular forms in the course.")
]
