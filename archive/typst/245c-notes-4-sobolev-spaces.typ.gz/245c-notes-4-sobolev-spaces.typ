// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/
// Converted to Typst by tao2typ: "2026-10-14T16:35:44.610018+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245C, Notes 4: Sobolev spaces", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245C, Notes 4: Sobolev spaces")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 April 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/")[#text("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("As discussed in previous notes, a function space norm can be viewed as a means to rigorously quantify various statistics of a function ")#mi("{f: X \\rightarrow {\\bf C}}")#text(". For instance, the “height” and “width” can be quantified via the ")#mi("{L^p(X,\\mu)}")#text(" norms (and their relatives, such as the Lorentz norms ")#tao-math("{\\left\\|f\\right\\|_{L^{p,q}(X,\\mu)}}", block: false)#text("). Indeed, if ")#mi("{f}")#text(" is a step function ")#mi("{f = A 1_E}")#text(", then the ")#mi("{L^p}")#text(" norm of ")#mi("{f}")#text(" is a combination ")#tao-math("{\\left\\|f\\right\\|_{L^p(X,\\mu)} = \\left|A\\right| \\mu(E)^{1/p}}", block: false)#text(" of the height (or amplitude) ")#mi("{A}")#text(" and the width ")#mi("{\\mu(E)}")#text(".")

#text("However, there are more features of a function ")#mi("{f}")#text(" of interest than just its width and height. When the domain ")#mi("{X}")#text(" is a Euclidean space ")#mi("{{\\bf R}^d}")#text(" (or domains related to Euclidean spaces, such as open subsets of ")#mi("{{\\bf R}^d}")#text(", or manifolds), then another important feature of such functions (especially in PDE) is the ")#emph[#text("regularity")]#text(" of a function, as well as the related concept of the ")#emph[#text("frequency scale")]#text(" of a function. These terms are not rigorously defined; but roughly speaking, regularity measures how smooth a function is (or how many times one can differentiate the function before it ceases to be a function), while the frequency scale of a function measures how quickly the function oscillates (and would be inversely proportional to the wavelength). One can illustrate this informal concept with some examples:")

#list(
[#text("Let ")#mi("{\\phi \\in C^\\infty_c({\\bf R})}")#text(" be a test function that equals ")#mi("{1}")#text(" near the origin, and ")#mi("{N}")#text(" be a large number. Then the function ")#mi("{f(x) := \\phi(x) \\sin(Nx)}")#text(" oscillates at a wavelength of about ")#mi("{1/N}")#text(", and a frequency scale of about ")#mi("{N}")#text(". While ")#mi("{f}")#text(" is, strictly speaking, a smooth function, it becomes increasingly less smooth in the limit ")#mi("{N \\rightarrow \\infty}")#text("; for instance, the derivative ")#mi("{f^{\\prime}(x) = \\phi^{\\prime}(x) \\sin(Nx) + N \\phi(x) \\cos(Nx)}")#text(" grows at a roughly linear rate as ")#mi("{N \\rightarrow \\infty}")#text(", and the higher derivatives grow at even faster rates. So this function does not really have any regularity in the limit ")#mi("{N \\rightarrow \\infty}")#text(". Note however that the height and width of this function is bounded uniformly in ")#mi("{N}")#text("; so regularity and frequency scale are independent of height and width.")],
[#text("Continuing the previous example, now consider the function ")#mi("{g(x) := N^{-s} \\phi(x) \\sin(Nx)}")#text(", where ")#mi("{s \\geq 0}")#text(" is some parameter. This function also has a frequency scale of about ")#mi("{N}")#text(". But now it has a certain amount of regularity, even in the limit ")#mi("{N \\rightarrow \\infty}")#text("; indeed, one easily checks that the ")#mi("{k^{th}}")#text(" derivative of ")#mi("{g}")#text(" stays bounded in ")#mi("{N}")#text(" as long as ")#mi("{k \\leq s}")#text(". So one could view this function as having “")#mi("{s}")#text(" degrees of regularity” in the limit ")#mi("{N \\rightarrow \\infty}")#text(".")],
[#text("In a similar vein, the function ")#mi("{N^{-s} \\phi(Nx)}")#text(" also has a frequency scale of about ")#mi("{N}")#text(", and can be viewed as having ")#mi("{s}")#text(" degrees of regularity in the limit ")#mi("{N \\rightarrow \\infty}")#text(".")],
[#text("The function ")#tao-math("{\\phi(x) \\left|x\\right|^s 1_{x > 0}}", block: false)#text(" also has about ")#mi("{s}")#text(" degrees of regularity, in the sense that it can be differentiated up to ")#mi("{s}")#text(" times before becoming unbounded. By performing a dyadic decomposition of the ")#mi("{x}")#text(" variable, one can also decompose this function into components ")#tao-math("{\\psi(2^n x) \\left|x\\right|^s}", block: false)#text(" for ")#mi("{n \\geq 0}")#text(", where ")#mi("{\\psi(x) := (\\phi(x)-\\phi(2x)) 1_{x>0}}")#text(" is a bump function supported away from the origin; each such component has frequency scale about ")#mi("{2^n}")#text(" and ")#mi("{s}")#text(" degrees of regularity. Thus we see that the original function ")#tao-math("{\\phi(x) \\left|x\\right|^s 1_{x > 0}}", block: false)#text(" has a range of frequency scales, ranging from about ")#mi("{1}")#text(" all the way to ")#mi("{+\\infty}")#text(".")],
[#text("One can of course concoct higher-dimensional analogues of these examples. For instance, the localised plane wave ")#mi("{\\phi(x) \\sin(\\xi \\cdot x)}")#text(" in ")#mi("{{\\bf R}^d}")#text(", where ")#mi("{\\phi \\in C^\\infty_c({\\bf R}^d)}")#text(" is a test function, would have a frequency scale of about ")#tao-math("{\\left|\\xi\\right|}", block: false)#text(".")]
)

#text("There are a variety of function space norms that can be used to capture frequency scale (or regularity) in addition to height and width. The most common and well-known examples of such spaces are the ")#link("http://en.wikipedia.org/wiki/Sobolev_space")[#text("Sobolev space norms")]#text(" ")#tao-math("{\\left\\| f\\right\\|_{W^{s,p}({\\bf R}^d)}}", block: false)#text(", although there are a number of other norms with similar features (such as ")#link("http://en.wikipedia.org/wiki/H%C3%B6lder_condition")[#text("Hölder norms")]#text(", ")#link("http://en.wikipedia.org/wiki/Besov_space")[#text("Besov norms")]#text(", and Triebel-Lizorkin norms). Very roughly speaking, the ")#mi("{W^{s,p}}")#text(" norm is like the ")#mi("{L^p}")#text(" norm, but with “")#mi("{s}")#text(" additional degrees of regularity”. For instance, in one dimension, the function ")#mi("{A \\phi(x/R) \\sin(Nx)}")#text(", where ")#mi("{\\phi}")#text(" is a fixed test function and ")#mi("{R, N}")#text(" are large, will have a ")#mi("{W^{s,p}}")#text(" norm of about ")#tao-math("{\\left|A\\right| R^{1/p} N^s}", block: false)#text(", thus combining the “height” ")#tao-math("{\\left|A\\right|}", block: false)#text(", the “width” ")#mi("{R}")#text(", and the “frequency scale” ")#mi("{N}")#text(" of this function together. (Compare this with the ")#mi("{L^p}")#text(" norm of the same function, which is about ")#tao-math("{\\left|A\\right| R^{1/p}}", block: false)#text(".)")

#text("To a large extent, the theory of the Sobolev spaces ")#mi("{W^{s,p}({\\bf R}^d)}")#text(" resembles their Lebesgue counterparts ")#mi("{L^p({\\bf R}^d)}")#text(" (which are as the special case of Sobolev spaces when ")#mi("{s=0}")#text("), but with the additional benefit of being able to interact very nicely with (weak) derivatives: a first derivative ")#mi("{\\frac{\\partial f}{\\partial x_j}}")#text(" of a function in an ")#mi("{L^p}")#text(" space usually leaves all Lebesgue spaces, but a first derivative of a function in the Sobolev space ")#mi("{W^{s,p}}")#text(" will end up in another Sobolev space ")#mi("{W^{s-1,p}}")#text(". This compatibility with the differentiation operation begins to explain why Sobolev spaces are so useful in the theory of partial ")#emph[#text("differential")]#text(" equations. Furthermore, the regularity parameter ")#mi("{s}")#text(" in Sobolev spaces is not restricted to be a natural number; it can be any real number, and one can use ")#emph[#text("fractional")]#text(" derivative or integration operators to move from one regularity to another. Despite the fact that most partial differential equations involve differential operators of integer order, fractional spaces are still of importance; for instance it often turns out that the Sobolev spaces which are ")#emph[#text("critical")]#text(" (scale-invariant) for a certain PDE are of fractional order.")

#text("The ")#link("http://en.wikipedia.org/wiki/Uncertainty_principle")[#text("uncertainty principle")]#text(" in Fourier analysis places a constraint between the width and frequency scale of a function; roughly speaking (and in one dimension for simplicity), the product of the two quantities has to be bounded away from zero (or to put it another way, a wave is always at least as wide as its wavelength). This constraint can be quantified as the very useful ")#link("http://en.wikipedia.org/wiki/Sobolev_inequality")[#text("Sobolev embedding theorem")]#text(", which allows one to trade regularity for integrability: a function in a Sobolev space ")#mi("{W^{s,p}}")#text(" will automatically lie in a number of other Sobolev spaces ")#mi("{W^{\\tilde s,\\tilde p}}")#text(" with ")#mi("{\\tilde s < s}")#text(" and ")#mi("{\\tilde p > p}")#text("; in particular, one can often embed Sobolev spaces into Lebesgue spaces. The trade is not reversible: one cannot start with a function with a lot of integrability and no regularity, and expect to recover regularity in a space of lower integrability. (One can already see this with the most basic example of Sobolev embedding, coming from the fundamental theorem of calculus. If a (continuously differentiable) function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" has ")#mi("{f^{\\prime}}")#text(" in ")#mi("{L^1({\\bf R})}")#text(", then we of course have ")#mi("{f \\in L^\\infty({\\bf R})}")#text("; but the converse is far from true.)")

#link("http://en.wikipedia.org/wiki/Plancherel_theorem")[#text("Plancherel’s theorem")]#text(" reveals that Fourier-analytic tools are particularly powerful when applied to ")#mi("{L^2}")#text(" spaces. Because of this, the Fourier transform is very effective at dealing with the ")#mi("{L^2}")#text("-based Sobolev spaces ")#mi("{W^{s,2}({\\bf R}^d)}")#text(", often abbreviated ")#mi("{H^s({\\bf R}^d)}")#text(". Indeed, using the fact that the Fourier transform converts regularity to decay, we will see that the ")#mi("{H^s({\\bf R}^d)}")#text(" spaces are nothing more than Fourier transforms of weighted ")#mi("{L^2}")#text(" spaces, and in particular enjoy a Hilbert space structure. These Sobolev spaces, and in particular the ")#emph[#text("energy space")]#text(" ")#mi("{H^1({\\bf R}^d)}")#text(", are of particular importance in any PDE that involves some sort of energy functional (this includes large classes of elliptic, parabolic, dispersive, and wave equations, and especially those equations connected to physics and/or geometry).")

#text("We will not fully develop the theory of Sobolev spaces here, as this would require the theory of ")#link("http://en.wikipedia.org/wiki/Singular_integral")[#text("singular integrals")]#text(", which is beyond the scope of this course. There are of course many references for further reading; one is Stein’s “")#link("http://www.ams.org/mathscinet-getitem?mr=290095")[#text("Singular integrals and differentiability properties of functions")]#text("“.")

#metadata(none) <tao-8e4385e3cc29d75f6d67>

#heading(level: 1)[#strong[#text(" — 1. Hölder spaces — ")]]

#text("Throughout these notes, ")#mi("{d \\geq 1}")#text(" is a fixed dimension.")

#text("Before we study Sobolev spaces, let us first look at the more elementary theory of ")#link("http://en.wikipedia.org/wiki/H%C3%B6lder_condition")[#text("Hölder spaces")]#text(" ")#mi("{C^{k,\\alpha}({\\bf R}^d)}")#text(", which resemble Sobolev spaces but with the aspect of width removed (thus Hölder norms only measure a combination of height and frequency scale). One can define these spaces on many domains (for instance, the ")#mi("{C^{0,\\alpha}}")#text(" norm can be defined on any metric space) but we shall largely restrict attention to Euclidean spaces ")#mi("{{\\bf R}^d}")#text(" for sake of concreteness.")

#text("We first recall the ")#mi("{C^k({\\bf R}^d)}")#text(" spaces, which we have already been implicitly using in previous lectures. The space ")#mi("{C^0({\\bf R}^d) = BC({\\bf R}^d)}")#text(" is the space of bounded continuous functions ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" on ")#mi("{{\\bf R}^d}")#text(", with norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{C^0({\\bf R}^d)} := \\sup_{x \\in {\\bf R}^d} \\left|f(x)\\right| = \\left\\|f\\right\\|_{L^\\infty({\\bf R}^d)}.", block: true)]]

#text("This norm gives ")#mi("{C^0}")#text(" the structure of a Banach space. More generally, one can then define the spaces ")#mi("{C^k({\\bf R}^d)}")#text(" for any non-negative integer ")#mi("{k}")#text(" as the space of all functions which are ")#mi("{k}")#text(" times continuously differentiable, with all derivatives of order ")#mi("{k}")#text(" bounded, and whose norm is given by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{C^k({\\bf R}^d)} := \\sum_{j=0}^k \\sup_{x \\in {\\bf R}^d} \\left|\\nabla^j f(x)\\right| = \\sum_{j=0}^k \\left\\|\\nabla^j f\\right\\|_{L^\\infty({\\bf R}^d)},", block: true)]]

#text("where we view ")#mi("{\\nabla^j f}")#text(" as a rank ")#mi("{j}")#text(", dimension ")#mi("{d}")#text(" tensor with complex coefficients (or equivalently, as a vector of dimension ")#mi("{d^j}")#text(" with complex coefficients), thus")

#align(center)[#tao-fit-display[#tao-math("\\left|\\nabla^j f(x)\\right| = (\\sum_{i_1,\\ldots,i_j = 1,\\ldots d} \\left|\\frac{\\partial^j}{\\partial {x_{i_1}} \\ldots \\partial {x_{i_j}}} f(x)\\right|^2)^{1/2}.", block: true)]]

#text("(One does not have to use the ")#mi("{\\ell^2}")#text(" norm here, actually; since all norms on a finite-dimensional space are equivalent, any other means of taking norms here will lead to an equivalent definition of the ")#mi("{C^k}")#text(" norm. More generally, all the norms discussed here tend to have several definitions which are equivalent up to constants, and in most cases the exact choice of norm one uses is just a matter of personal taste.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" In some texts, ")#mi("{C^k({\\bf R}^d)}")#text(" is used to denote the functions which are ")#mi("{k}")#text(" times continuously differentiable, but whose derivatives up to ")#mi("{k^{th}}")#text(" order are allowed to be unbounded, so for instance ")#mi("{e^x}")#text(" would lie in ")#mi("{C^k({\\bf R})}")#text(" for every ")#mi("{k}")#text(" under this definition. Here, we will refer to such functions (with unbounded derivatives) as lying in ")#mi("{C^k_{loc}({\\bf R}^d)}")#text(" (i.e. they are locally in ")#mi("{C^k}")#text("), rather than ")#mi("{C^k({\\bf R}^d)}")#text(". Similarly, we make a distinction between ")#mi("{C^\\infty_{loc}({\\bf R}^d) = \\bigcap_{k=1}^\\infty C^k_{loc}({\\bf R}^d)}")#text(" (smooth functions, with no bounds on derivatives) and ")#mi("{C^\\infty({\\bf R}^d) = \\bigcap_{k=1}^\\infty C^k({\\bf R}^d)}")#text(" (smooth functions, all of whose derivatives are bounded). Thus, for instance, ")#mi("{e^x}")#text(" lies in ")#mi("{C^\\infty_{loc}({\\bf R})}")#text(" but not ")#mi("{C^\\infty({\\bf R})}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Show that ")#mi("{C^k({\\bf R}^d)}")#text(" is a Banach space.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Show that for every ")#mi("{d \\geq 1}")#text(" and ")#mi("{k \\geq 0}")#text(", the ")#mi("{C^k({\\bf R}^d)}")#text(" norm is equivalent to the modified norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{\\tilde C^k({\\bf R}^d)} := \\left\\|f\\right\\|_{L^\\infty({\\bf R}^d)} + \\left\\|\\nabla^k f\\right\\|_{L^\\infty({\\bf R}^d)}", block: true)]]

#text("in the sense that there exists a constant ")#mi("{C}")#text(" (depending on ")#mi("{k}")#text(" and ")#mi("{d}")#text(") such that")

#align(center)[#tao-fit-display[#tao-math("C^{-1} \\left\\|f\\right\\|_{C^k({\\bf R}^d)} \\leq \\left\\| f \\right\\|_{\\tilde C^k({\\bf R}^d)} \\leq \\left\\|f\\right\\|_{C^k({\\bf R}^d)}", block: true)]]

#text("for all ")#mi("{f \\in C^k({\\bf R}^d)}")#text(". (")#emph[#text("Hint:")]#text(" use Taylor series with remainder.) Thus when defining the ")#mi("{C^k}")#text(" norms, one does not really need to bound all the intermediate derivatives ")#mi("{\\nabla^j f}")#text(" for ")#mi("{0 < j < k}")#text("; the two extreme terms ")#mi("{j=0, j=k}")#text(" suffice. (This is part of a more general interpolation phenomenon; the extreme terms in a sum often already suffice to control the intermediate terms.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" ")#metadata(none) <tao-11f00ae3d8c981675ec1>#text(" Let ")#mi("{\\phi \\in C^\\infty_c({\\bf R}^d)}")#text(" be a bump function, and ")#mi("{k \\geq 0}")#text(". Show that if ")#mi("{\\xi \\in {\\bf R}^d}")#text(" with ")#tao-math("{\\left|\\xi\\right| \\geq 1}", block: false)#text(", ")#tao-math("{R \\geq 1/\\left|\\xi\\right|}", block: false)#text(", and ")#mi("{A > 0}")#text(", then the function ")#mi("{A \\phi(x/R) \\sin(\\xi \\cdot x)}")#text(" has a ")#mi("{C^k}")#text(" norm of at most ")#tao-math("{C A \\left|\\xi\\right|^k}", block: false)#text(", where ")#mi("{C}")#text(" is a constant depending only on ")#mi("{\\phi}")#text(", ")#mi("{d}")#text(" and ")#mi("{k}")#text(". Thus we see how the ")#mi("{C^k}")#text(" norm relates to the height ")#mi("{A}")#text(", width ")#mi("{R^d}")#text(", and frequency scale ")#tao-math("{\\left|\\xi\\right|}", block: false)#text(" of the function, and in particular how the width ")#mi("{R}")#text(" is largely irrelevant. What happens when the condition ")#tao-math("{R \\geq 1/\\left|\\xi\\right|}", block: false)#text(" is dropped?")
]

#text("We clearly have the inclusions")

#align(center)[#tao-fit-display[#mitex("C^0({\\bf R}^d) \\supset C^1({\\bf R}^d) \\supset C^2({\\bf R}^d) \\supset \\ldots")]]

#text("and for any constant-coefficient partial differential operator")

#align(center)[#tao-fit-display[#mitex("L = \\sum_{i_1,\\ldots,i_d \\geq 0: i_1+\\ldots+i_d \\leq m} c_{i_1,\\ldots,i_d} \\frac{\\partial^{i_1+\\ldots+i_d} }{\\partial {x_1^{i_1}} \\ldots \\partial {x_d^{i_d}}}")]]

#text("of some order ")#mi("{m \\geq 0}")#text(", it is easy to see that ")#mi("{L}")#text(" is a bounded linear operator from ")#mi("{C^{k+m}({\\bf R}^d)}")#text(" to ")#mi("{C^k({\\bf R}^d)}")#text(" for any ")#mi("{k \\geq 0}")#text(".")

#text("The Hölder spaces ")#mi("{C^{k,\\alpha}({\\bf R}^d)}")#text(" are designed to “fill up the gaps” between the discrete spectrum ")#mi("{C^k({\\bf R}^d)}")#text(" of the continuously differentiable spaces. For ")#mi("{k=0}")#text(" and ")#mi("{0 \\leq \\alpha \\leq 1}")#text(", these spaces are defined as the subspace of functions ")#mi("{f \\in C^0({\\bf R}^d)}")#text(" whose norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{C^{0,\\alpha}({\\bf R}^d)} := \\left\\|f\\right\\|_{C^0({\\bf R}^d)} + \\sup_{x,y \\in {\\bf R}^d: x \\neq y} \\frac{\\left|f(x)-f(y)\\right|}{\\left|x-y\\right|^\\alpha}", block: true)]]

#text("is finite. To put it another way, ")#mi("{f \\in C^{0,\\alpha}({\\bf R}^d)}")#text(" if ")#mi("{f}")#text(" is bounded and continuous, and furthermore obeys the ")#emph[#text("Hölder continuity")]#text(" bound")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x)-f(y)\\right| \\leq C \\left|x-y\\right|^\\alpha", block: true)]]

#text("for some constant ")#mi("{C > 0}")#text(" and all ")#mi("{x,y \\in {\\bf R}^d}")#text(".")

#text("The space ")#mi("{C^{0,0}({\\bf R}^d)}")#text(" is easily seen to be just ")#mi("{C^0({\\bf R}^d)}")#text(" (with an equivalent norm). At the other extreme, ")#mi("{C^{0,1}({\\bf R}^d)}")#text(" is the class of ")#emph[#text("Lipschitz")]#text(" functions, and is also denoted ")#mi("{\\text{Lip}({\\bf R}^d)}")#text(" (and the ")#mi("{C^{0,1}}")#text(" norm is also known as the ")#emph[#text("Lipschitz norm")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Show that ")#mi("{C^{0,\\alpha}({\\bf R}^d)}")#text(" is a Banach space for every ")#mi("{0 \\leq \\alpha \\leq 1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Show that ")#mi("{C^{0,\\alpha}({\\bf R}^d) \\supset C^{0,\\beta}({\\bf R}^d)}")#text(" for every ")#mi("{0 \\leq \\alpha \\leq \\beta \\leq 1}")#text(", and that the inclusion map is continuous.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" If ")#mi("{\\alpha > 1}")#text(", show that the ")#mi("{C^{0,\\alpha}({\\bf R}^d)}")#text(" norm of a function ")#mi("{f}")#text(" is finite if and only if ")#mi("{f}")#text(" is constant. This explains why we generally restrict the Hölder index ")#mi("{\\alpha}")#text(" to be less than or equal to ")#mi("{1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Show that ")#mi("{C^1({\\bf R}^d)}")#text(" is a proper subspace of ")#mi("{C^{0,1}({\\bf R}^d)}")#text(", and that the restriction of the ")#mi("{C^{0,1}({\\bf R}^d)}")#text(" norm to ")#mi("{C^1({\\bf R}^d)}")#text(" is equivalent to the ")#mi("{C^1}")#text(" norm. (The relationship between ")#mi("{C^1({\\bf R}^d)}")#text(" and ")#mi("{C^{0,1}({\\bf R}^d)}")#text(" is in fact closely analogous to that between ")#mi("{C^0({\\bf R}^d)}")#text(" and ")#mi("{L^\\infty({\\bf R}^d)}")#text(", as can be seen from the fundamental theorem of calculus.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" ")#metadata(none) <tao-be8f2d3ab05f72b23892>#text(" Let ")#mi("{f \\in (C^\\infty_c({\\bf R}))^*}")#text(" be a distribution. Show that ")#mi("{f \\in C^{0,1}({\\bf R})}")#text(" if and only if ")#mi("{f \\in L^\\infty({\\bf R})}")#text(", and the distributional derivative ")#mi("{f^{\\prime}}")#text(" of ")#mi("{f}")#text(" also lies in ")#mi("{L^\\infty({\\bf R})}")#text(". Furthermore, for ")#mi("{f \\in C^{0,1}({\\bf R})}")#text(", show that ")#tao-math("{\\left\\|f\\right\\|_{C^{0,1}({\\bf R})}}", block: false)#text(" is comparable to ")#tao-math("{\\left\\|f\\right\\|_{L^\\infty({\\bf R})} + \\left\\|f^{\\prime}\\right\\|_{L^\\infty({\\bf R})}}", block: false)#text(".")
]

#text("We can then define the ")#mi("{C^{k,\\alpha}({\\bf R}^d)}")#text(" spaces for natural numbers ")#mi("{k \\geq 0}")#text(" and ")#mi("{0 \\leq \\alpha \\leq 1}")#text(" to be the subspace of ")#mi("{C^k({\\bf R}^d)}")#text(" whose norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{C^{k,\\alpha}({\\bf R}^d)} := \\sum_{j=0}^k \\left\\| \\nabla^j f \\right\\|_{C^{0,\\alpha}({\\bf R}^d)}", block: true)]]

#text("is finite. (As before, there are a variety of ways to define the ")#mi("{C^{0,\\alpha}}")#text(" norm of the tensor-valued quantity ")#mi("{\\nabla^j f}")#text(", but they are all equivalent to each other.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Show that ")#mi("{C^{k,\\alpha}({\\bf R}^d)}")#text(" is a Banach space which contains ")#mi("{C^{k+1}({\\bf R}^d)}")#text(", and is contained in turn in ")#mi("{C^k({\\bf R}^d)}")#text(".")
]

#text("As before, ")#mi("{C^{k,0}({\\bf R}^d)}")#text(" is equal to ")#mi("{C^k({\\bf R}^d)}")#text(", and ")#mi("{C^{k,\\alpha}({\\bf R}^d)}")#text(" contains ")#mi("{C^{k,\\beta}({\\bf R}^d)}")#text(" when ")#mi("{\\alpha \\leq \\beta}")#text(". The space ")#mi("{C^{k,1}({\\bf R}^d)}")#text(" is slightly larger than ")#mi("{C^{k+1}}")#text(", but is fairly close to it, thus providing a near-continuum of spaces between the sequence of spaces ")#mi("{C^k({\\bf R}^d)}")#text(". The following examples illustrates this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{\\phi \\in C^\\infty_c({\\bf R})}")#text(" be a test function, let ")#mi("{k \\geq 0}")#text(" be a natural number, and let ")#mi("{0 < \\alpha < 1}")#text(".")

#list(
[#text("Show that the function ")#tao-math("{\\left|x\\right|^s \\phi(x)}", block: false)#text(" lies in ")#mi("{C^{k,\\alpha}({\\bf R})}")#text(" whenever ")#mi("{s \\geq k+\\alpha}")#text(".")],
[#text("Conversely, if ")#mi("{s}")#text(" is not an integer, ")#mi("{\\phi(0) \\neq 0}")#text(", and ")#mi("{s < k+\\alpha}")#text(", show that ")#tao-math("{\\left|x\\right|^s \\phi(x)}", block: false)#text(" does ")#emph[#text("not")]#text(" lie in ")#mi("{C^{k,\\alpha}({\\bf R})}")#text(".")],
[#text("Show that ")#tao-math("{\\left|x\\right|^{k+1} \\phi(x) 1_{x>0}}", block: false)#text(" lies in ")#mi("{C^{k,1}({\\bf R})}")#text(", but not in ")#mi("{C^{k+1}({\\bf R})}")#text(".")]
)

#text("This example illustrates that the quantity ")#mi("{k+\\alpha}")#text(" can be viewed as measuring the total amount of regularity held by functions in ")#mi("{C^{k,\\alpha}({\\bf R})}")#text(": ")#mi("{k}")#text(" full derivatives, plus an additional ")#mi("{\\alpha}")#text(" amount of Hölder continuity.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" ")#metadata(none) <tao-368ea0500e9bb5d830c2>#text(" Let ")#mi("{\\phi \\in C^\\infty_c({\\bf R}^d)}")#text(" be a test function, let ")#mi("{k \\geq 0}")#text(" be a natural number, and let ")#mi("{0 \\leq \\alpha \\leq 1}")#text(". Show that for ")#mi("{\\xi \\in {\\bf R}^d}")#text(" with ")#tao-math("{\\left|\\xi\\right| \\geq 1}", block: false)#text(", the function ")#mi("{\\phi(x) \\sin(\\xi \\cdot x)}")#text(" has a ")#mi("{C^{k,\\alpha}({\\bf R})}")#text(" norm of at most ")#tao-math("{C \\left|\\xi\\right|^{k+\\alpha}}", block: false)#text(", for some ")#mi("{C}")#text(" depending on ")#mi("{\\phi, d, k, \\alpha}")#text(".")
]

#text("By construction, it is clear that continuously differential operators ")#mi("{L}")#text(" of order ")#mi("{m}")#text(" will map ")#mi("{C^{k+m,\\alpha}({\\bf R}^d)}")#text(" continuously to ")#mi("{C^{k,\\alpha}({\\bf R}^d)}")#text(".")

#text("Now we consider what happens with products.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Let ")#mi("{k,l \\geq 0}")#text(" be natural numbers, and ")#mi("{0 \\leq \\alpha,\\beta \\leq 1}")#text(".")

#list(
[#text("If ")#mi("{f \\in C^k({\\bf R}^d)}")#text(" and ")#mi("{g \\in C^l({\\bf R}^d)}")#text(", show that ")#mi("{fg \\in C^{\\min(k,l)}({\\bf R}^d)}")#text(", and that the multiplication map is continuous from ")#mi("{C^k({\\bf R}^d) \\times C^l({\\bf R}^d)}")#text(" to ")#mi("{C^{\\min(k,l)}({\\bf R}^d)}")#text(". (Hint: reduce to the case ")#mi("{k=l}")#text(" and use induction.)")],
[#text("If ")#mi("{f \\in C^{k,\\alpha}({\\bf R}^d)}")#text(" and ")#mi("{g \\in C^{l,\\beta}({\\bf R}^d)}")#text(", and ")#mi("{k+\\alpha \\leq l+\\beta}")#text(", show that ")#mi("{fg \\in C^{k,\\alpha}({\\bf R}^d)}")#text(", and that the multiplication map is continuous from ")#mi("{C^{k,\\alpha}({\\bf R}^d) \\times C^{l,\\beta}({\\bf R}^d)}")#text(" to ")#mi("{C^{k,\\alpha}({\\bf R}^d)}")#text(".")]
)

#text("It is easy to see that the regularity in these results cannot be improved (just take ")#mi("{g=1}")#text("). This illustrates a general principle, namely that a pointwise product ")#mi("{fg}")#text(" tends to acquire the ")#emph[#text("lower")]#text(" of the regularities of the two factors ")#mi("{f, g}")#text(".")
]

#text("As one consequence of this exercise, we see that any ")#emph[#text("variable-coefficient")]#text(" differential operator ")#mi("{L}")#text(" of order ")#mi("{m}")#text(" with ")#mi("{C^\\infty({\\bf R})}")#text(" coefficients will map ")#mi("{C^{m+k,\\alpha}({\\bf R}^d)}")#text(" to ")#mi("{C^{k,\\alpha}({\\bf R}^d)}")#text(" for any ")#mi("{k \\geq 0}")#text(" and ")#mi("{0 \\leq \\alpha \\leq 1}")#text(".")

#text("We now briefly remark on Hölder spaces on open domains ")#mi("{\\Omega}")#text(" in Euclidean space ")#mi("{{\\bf R}^d}")#text(". Here, a new subtlety emerges; instead of having just one space ")#mi("{C^{k,\\alpha}}")#text(" for each choice of exponents ")#mi("{k,\\alpha}")#text(", one actually has a range of spaces to choose from, depending on what kind of behaviour one wants to impose at the boundary of the domain. At one extreme, one has the space ")#mi("{C^{k,\\alpha}(\\Omega)}")#text(", defined as the space of ")#mi("{k}")#text(" times continuously differentiable functions ")#mi("{f: \\Omega \\rightarrow {\\bf C}}")#text(" whose Hölder norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{C^{k,\\alpha}(\\Omega)} := \\sum_{j=0}^k \\sup_{x \\in \\Omega} \\left|\\nabla^j f(x)\\right| + \\sup_{x,y \\in \\Omega: x \\neq y} \\frac{\\left|\\nabla^j f(x)-\\nabla^j f(y)\\right|}{\\left|x-y\\right|^\\alpha}", block: true)]]

#text("is finite; this is the “maximal” choice for the ")#mi("{C^{k,\\alpha}(\\Omega)}")#text(". At the other extreme, one has the space ")#mi("{C^{k,\\alpha}_0(\\Omega)}")#text(", defined as the closure of the compactly supported functions in ")#mi("{C^{k,\\alpha}(\\Omega)}")#text(". This space is smaller than ")#mi("{C^{k,\\alpha}(\\Omega)}")#text("; for instance, functions in ")#mi("{C^{0,\\alpha}_0((0,1))}")#text(" must converge to zero at the endpoints ")#mi("{0,1}")#text(", while functions in ")#mi("{C^{k,\\alpha}((0,1))}")#text(" do not need to do so. An intermediate space is ")#mi("{C^{k,\\alpha}({\\bf R}^d)\\downharpoonright_{\\Omega}}")#text(", defined as the space of restrictions of functions in ")#mi("{C^{k,\\alpha}({\\bf R}^d)}")#text(" to ")#mi("{\\Omega}")#text(". For instance, the restriction of ")#tao-math("{\\left|x\\right| \\psi(x)}", block: false)#text(" to ")#mi("{{\\bf R} \\backslash \\{0\\}}")#text(", where ")#mi("{\\psi}")#text(" is a cutoff function non-vanishing at the origin, lies in ")#mi("{C^{1,0}({\\bf R} \\backslash \\{0\\})}")#text(", but is not in ")#mi("{C^{1,0}({\\bf R})\\downharpoonright_{{\\bf R} \\backslash \\{0\\}}}")#text(" or ")#mi("{C^{1,0}_0({\\bf R} \\backslash \\{0\\})}")#text(" (note that ")#tao-math("{\\left|x\\right| \\psi(x)}", block: false)#text(" itself is not in ")#mi("{C^{1,0}({\\bf R})}")#text(", as it is not continuously differentiable at the origin). It is possible to clarify the exact relationships between the various flavours of Hölder spaces on domains (and similarly for the Sobolev spaces discussed below), but we will not discuss these topics here.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Let ")#mi("{k \\geq 0}")#text(" and ")#mi("{0 \\leq \\alpha^{\\prime} < \\alpha \\leq 1}")#text(". Show that ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" is a dense subset of ")#mi("{C^{k,\\alpha}_0({\\bf R}^d)}")#text(" if one places the ")#mi("{C^{k,\\alpha^{\\prime}}}")#text(" topology on the latter space. (")#emph[#text("Hint:")]#text(" To approximate a compactly supported ")#mi("{C^{k,\\alpha}}")#text(" function by a ")#mi("{C^\\infty_c}")#text(" one, convolve with a smooth, compactly supported approximation to the identity.) What happens in the endpoint case ")#mi("{\\alpha=\\alpha^{\\prime}}")#text("?")
]

#text("Hölder spaces are particularly useful in elliptic PDE, because tools such as the maximum principle lend themselves well to the suprema that appear inside the definition of the ")#mi("{C^{k,\\alpha}}")#text(" norms; see for instance the ")#link("http://www.ams.org/mathscinet-getitem?mr=1814364")[#text("book of Gilbarg and Trudinger")]#text(" for a thorough treatment. For simple examples of elliptic PDE, such as the Poisson equation ")#mi("{\\Delta u = f}")#text(", one can also use the explicit fundamental solution, through lengthy but straightforward computations. We give a typical example here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Schauder estimate)")]#text(" Let ")#mi("{0 < \\alpha < 1}")#text(", and let ")#mi("{f \\in C^{0,\\alpha}({\\bf R}^3)}")#text(" be a function supported on the unit ball ")#mi("{B(0,1)}")#text(". Let ")#mi("{u}")#text(" be the unique bounded solution to the Poisson equation ")#mi("{\\Delta u = f}")#text(" (where ")#mi("{\\Delta = \\sum_{j=1}^3 \\frac{\\partial^2}{\\partial x_j^2}}")#text(" is the Laplacian), given by convolution with the Newton kernel:")

#align(center)[#tao-fit-display[#tao-math("u(x) := \\frac{1}{4\\pi} \\int_{{\\bf R}^3} \\frac{f(y)}{\\left|x-y\\right|}\\ dy.", block: true)]]

#list(
[#text("(i) Show that ")#mi("{u \\in C^0({\\bf R}^3)}")#text(".")],
[#text("(ii) Show that ")#mi("{u \\in C^1({\\bf R}^3)}")#text(", and rigorously establish the formula")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\partial u}{\\partial x_j}(x) = -\\frac{1}{4\\pi} \\int_{{\\bf R}^3} (x_j-y_j) \\frac{f(y)}{\\left|x-y\\right|^3}\\ dy", block: true)]]

#text("for ")#mi("{j=1,2,3}")#text(".")],
[#text("(iii) Show that ")#mi("{u \\in C^2({\\bf R}^3)}")#text(", and rigorously establish the formula")

#tao-aligned(keep: true)[


#tao-math("\\frac{\\partial^2 u}{\\partial x_i \\partial x_j}(x)  & = \\frac{1}{4\\pi} \\lim_{\\varepsilon \\rightarrow 0}\\int_{\\left|x-y\\right| \\geq \\varepsilon} [\\frac{3 (x_i-y_i) (x_j-y_j)}{\\left|x-y\\right|^5}", block: true)



#tao-math(" & - \\frac{\\delta_{ij}}{\\left|x-y\\right|^3}] f(y)\\ dy", block: true)
]

#text("for ")#mi("{i,j=1,2,3}")#text(", where ")#mi("{\\delta_{ij}}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Kronecker_delta")[#text("Kronecker delta")]#text(". (Hint: first establish this in the two model cases when ")#mi("{f(x)=0}")#text(", and when ")#mi("{f}")#text(" is constant near ")#mi("{x}")#text(".)")],
[#text("(iv) Show that ")#mi("{u \\in C^{2,\\alpha}({\\bf R}^3)}")#text(", and establish the ")#emph[#text("Schauder estimate")]

#align(center)[#tao-fit-display[#tao-math("\\left\\|u\\right\\|_{C^{2,\\alpha}({\\bf R}^3)} \\leq C_\\alpha \\left\\|f\\right\\|_{C^{0,\\alpha}({\\bf R}^3)}", block: true)]]

#text("where ")#mi("{C_\\alpha}")#text(" depends only on ")#mi("{\\alpha}")#text(".")],
[#text("(v) Show that the Schauder estimate fails when ")#mi("{\\alpha=0}")#text(". Using this, conclude that there eixsts ")#mi("{f \\in C^0({\\bf R}^3)}")#text(" supported in the unit ball such that the function ")#mi("{u}")#text(" defined above fails to be in ")#mi("{C^2({\\bf R}^3)}")#text(". (")#emph[#text("Hint:")]#text(" use the closed graph theorem.) This failure helps explain why it is necessary to introduce Hölder spaces into elliptic theory in the first place (as opposed to the more intuitive ")#mi("{C^k}")#text(" spaces).")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 16")]#text(" Roughly speaking, the Schauder estimate asserts that if ")#mi("{\\Delta u}")#text(" has ")#mi("{C^{0,\\alpha}}")#text(" regularity, then all other second derivatives of ")#mi("{u}")#text(" have ")#mi("{C^{0,\\alpha}}")#text(" regularity as well. This phenomenon – that control of a special derivative of ")#mi("{u}")#text(" at some order implies control of all other derivatives of ")#mi("{u}")#text(" at that order – is known as ")#emph[#text("elliptic regularity")]#text(", and relies crucially on ")#mi("{\\Delta}")#text(" being an ")#emph[#text("elliptic")]#text(" differential operator. We will discus ellipticity a little bit more later in Exercise ")#link(<tao-4fcb34bc60d2a440d653>)[#text("45")]#text(". The theory of Schauder estimates is by now extremely well developed, and applies to large classes of elliptic operators on quite general domains, but we will not discuss these estimates and their applications to various linear and nonlinear elliptic PDE here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Rellich-Kondrachov type embedding theorem for Hölder spaces)")]#text(" Let ")#mi("{0 \\leq \\alpha < \\beta \\leq 1}")#text(". Show that any bounded sequence of functions ")#mi("{f_n \\in C^{0,\\beta}({\\bf R}^d)}")#text(" that are all supported in the same compact subset of ")#mi("{{\\bf R}^n}")#text(" will have a subsequence that converges in ")#mi("{C^{0,\\alpha}({\\bf R}^d)}")#text(". (")#emph[#text("Hint:")]#text(" use the ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0%E2%80%93Ascoli_theorem")[#text("Arzelá-Ascoli theorem")]#text(" to first obtain uniform convergence, then upgrade this convergence.) This is part of a more general phenomenon: sequences bounded in a high regularity space, and constrained to lie in a compact domain, will tend to have convergent subsequences in low regularity spaces.")
]

#heading(level: 1)[#strong[#text(" — 2. Classical Sobolev spaces — ")]]

#text("We now turn to the “classical” Sobolev spaces ")#mi("{W^{k,p}({\\bf R}^d)}")#text(", which involve only an integral amount ")#mi("{k}")#text(" of regularity.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 18")]#text(" Let ")#mi("{1 \\leq p \\leq \\infty}")#text(", and let ")#mi("{k \\geq 0}")#text(" be a natural number. A function ")#mi("{f}")#text(" is said to lie in ")#mi("{W^{k,p}({\\bf R}^d)}")#text(" if its ")#link("http://en.wikipedia.org/wiki/Weak_derivative")[#text("weak derivatives")]#text(" ")#mi("{\\nabla^j f}")#text(" exist and lie in ")#mi("{L^p({\\bf R}^d)}")#text(" for all ")#mi("{j=0,\\ldots,k}")#text(". If ")#mi("{f}")#text(" lies in ")#mi("{W^{k,p}({\\bf R}^d)}")#text(", we define the ")#mi("{W^{k,p}}")#text(" norm of ")#mi("{f}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{W^{k,p}({\\bf R}^d)} := \\sum_{j=0}^k \\left\\|\\nabla^j f\\right\\|_{L^p({\\bf R}^d)}.", block: true)]]

#text("(As before, the exact choice of convention in which one measures the ")#mi("{L^p}")#text(" norm of ")#mi("{\\nabla^j}")#text(" is not particularly relevant for most applications, as all such conventions are equivalent up to multiplicative constants.)")
]

#text("The space ")#mi("{W^{k,p}({\\bf R}^d)}")#text(" is also denoted ")#mi("{L^p_k({\\bf R}^d)}")#text(" in some texts.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 19")]#text(" ")#mi("{W^{0,p}({\\bf R}^d)}")#text(" is of course the same space as ")#mi("{L^p({\\bf R}^d)}")#text(", thus the Sobolev spaces generalise the Lebesgue spaces. From Exercise ")#link(<tao-be8f2d3ab05f72b23892>)[#text("9")]#text(" we see that ")#mi("{W^{1,\\infty}({\\bf R})}")#text(" is the same space as ")#mi("{C^{0,1}({\\bf R})}")#text(", with an equivalent norm. More generally, one can see from induction that ")#mi("{W^{k+1,\\infty}({\\bf R})}")#text(" is the same space as ")#mi("{C^{k,1}({\\bf R})}")#text(" for ")#mi("{k \\geq 0}")#text(", with an equivalent norm. It is also clear that ")#mi("{W^{k,p}({\\bf R}^d)}")#text(" contains ")#mi("{W^{k+1,p}({\\bf R}^d)}")#text(" for any ")#mi("{k,p}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 20")]#text(" The function ")#tao-math("{\\left|\\sin x\\right|}", block: false)#text(" lies in ")#mi("{W^{1,\\infty}({\\bf R})}")#text(", but is not everywhere differentiable in the classical sense; nevertheless, it has a bounded weak derivative of ")#mi("{\\cos x \\text{sgn}(\\sin(x))}")#text(". On the other hand, the ")#link("http://en.wikipedia.org/wiki/Cantor_function")[#text("Cantor function")]#text(" (aka the “Devil’s staircase”) is not in ")#mi("{W^{1,\\infty}({\\bf R})}")#text(", despite having a classical derivative of zero at almost every point; the weak derivative is a Cantor measure, which does not lie in any ")#mi("{L^p}")#text(" space. Thus one really does need to work with weak derivatives rather than classical derivatives to define Sobolev spaces properly (in contrast to the ")#mi("{C^{k,\\alpha}}")#text(" spaces).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" ")#metadata(none) <tao-9c0abe51c6e6655d81de>#text(" Let ")#mi("{\\phi \\in C^\\infty_c({\\bf R}^d)}")#text(" be a bump function, ")#mi("{k \\geq 0}")#text(", and ")#mi("{1 \\leq p \\leq \\infty}")#text(". Show that if ")#mi("{\\xi \\in {\\bf R}^d}")#text(" with ")#tao-math("{\\left|\\xi\\right| \\geq 1}", block: false)#text(", ")#tao-math("{R \\geq 1/\\left|\\xi\\right|}", block: false)#text(", and ")#mi("{A > 0}")#text(", then the function ")#mi("{A \\phi(x/R) \\sin(\\xi \\cdot x)}")#text(" has a ")#mi("{W^{k,p}({\\bf R})}")#text(" norm of at most ")#tao-math("{C A \\left|\\xi\\right|^k R^{d/p}}", block: false)#text(", where ")#mi("{C}")#text(" is a constant depending only on ")#mi("{\\phi}")#text(", ")#mi("{p}")#text(" and ")#mi("{k}")#text(". (Compare this with Exercise ")#link(<tao-11f00ae3d8c981675ec1>)[#text("4")]#text(" and Exercise ")#link(<tao-368ea0500e9bb5d830c2>)[#text("12")]#text(".) What happens when the condition ")#tao-math("{R \\geq 1/\\left|\\xi\\right|}", block: false)#text(" is dropped?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Show that ")#mi("{W^{k,p}({\\bf R}^d)}")#text(" is a Banach space for any ")#mi("{1 \\leq p \\leq \\infty}")#text(" and ")#mi("{k \\geq 0}")#text(".")
]

#text("The fact that Sobolev spaces are defined using weak derivatives is a technical nuisance, but in practice one can often end up working with classical derivatives anyway by means of the following lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 23")]#text(" ")#metadata(none) <tao-cde56892bbebbf6c5fe5>#text(" Let ")#mi("{1 \\leq p < \\infty}")#text(" and ")#mi("{k \\geq 0}")#text(". Then the space ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" of test functions is a dense subspace of ")#mi("{W^{k,p}({\\bf R}^d)}")#text(".")
]

#emph[#text("Proof:")]#text(" It is clear that ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" is a subspace of ")#mi("{W^{k,p}({\\bf R}^d)}")#text(". We first show that the smooth functions ")#mi("{C^\\infty_{loc}({\\bf R}^d) \\cap W^{k,p}({\\bf R}^d)}")#text(" is a dense subspace of ")#mi("{W^{k,p}({\\bf R}^d)}")#text(", and then show that ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" is dense in ")#mi("{C^\\infty_{loc}({\\bf R}^d) \\cap W^{k,p}({\\bf R}^d)}")#text(".")

#text("We begin with the former claim. Let ")#mi("{f \\in W^{k,p}({\\bf R}^d)}")#text(", and let ")#mi("{\\phi_n}")#text(" be a sequence of smooth, compactly supported approximations to the identity. Since ")#mi("{f \\in L^p({\\bf R}^d)}")#text(", we see that ")#mi("{f*\\phi_n}")#text(" converges to ")#mi("{f}")#text(" in ")#mi("{L^p({\\bf R}^d)}")#text(". More generally, since ")#mi("{\\nabla^j f}")#text(" is in ")#mi("{L^p({\\bf R}^d)}")#text(" for ")#mi("{0 \\leq j \\leq k}")#text(", we see that ")#mi("{(\\nabla^j f) * \\phi_n = \\nabla^j (f * \\phi_n)}")#text(" converges to ")#mi("{\\nabla^j f}")#text(" in ")#mi("{L^p({\\bf R}^d)}")#text(". Thus we see that ")#mi("{f*\\phi_n}")#text(" converges to ")#mi("{f}")#text(" in ")#mi("{W^{k,p}({\\bf R}^d)}")#text(". On the other hand, as ")#mi("{\\phi_n}")#text(" is smooth, ")#mi("{f*\\phi_n}")#text(" is smooth; and the claim follows.")

#text("Now we prove the latter claim. Let ")#mi("{f}")#text(" be a smooth function in ")#mi("{W^{k,p}({\\bf R}^d)}")#text(", thus ")#mi("{\\nabla^j f \\in L^p({\\bf R}^d)}")#text(" for all ")#mi("{0 \\leq j \\leq k}")#text(". We let ")#mi("{\\eta \\in C^\\infty_c({\\bf R}^d)}")#text(" be a compactly supported function which equals ")#mi("{1}")#text(" near the origin, and consider the functions ")#mi("{f_R(x) := f(x) \\eta(x/R)}")#text(" for ")#mi("{R > 0}")#text(". Clearly, each ")#mi("{f_R}")#text(" lies in ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(". As ")#mi("{R \\rightarrow \\infty}")#text(", dominated convergence shows that ")#mi("{f_R}")#text(" converges to ")#mi("{f}")#text(" in ")#mi("{L^p({\\bf R}^d)}")#text(". An application of the product rule then lets us write ")#mi("{\\nabla f_R(x) = (\\nabla f)(x) \\eta(x/R) + \\frac{1}{R} f(x) (\\nabla \\eta)(x/R)}")#text(". The first term converges to ")#mi("{\\nabla f}")#text(" in ")#mi("{L^p({\\bf R}^d)}")#text(" by dominated convergence, while the second term goes to zero in the same topology; thus ")#mi("{\\nabla f_R}")#text(" converges to ")#mi("{\\nabla f}")#text(" in ")#mi("{L^p({\\bf R}^d)}")#text(". A similar argument shows that ")#mi("{\\nabla^j f_R}")#text(" converges to ")#mi("{\\nabla^j f}")#text(" in ")#mi("{L^p({\\bf R}^d)}")#text(" for all ")#mi("{0 \\leq j \\leq k}")#text(", and so ")#mi("{f_R}")#text(" converges to ")#mi("{f}")#text(" in ")#mi("{W^{k,p}({\\bf R}^d)}")#text(", and the claim follows. ")#mi("\\Box")

#text("As a corollary of this lemma we also see that the space ")#mi("{{\\mathcal S}({\\bf R}^d)}")#text(" of Schwartz functions is dense in ")#mi("{W^{k,p}({\\bf R}^d)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Let ")#mi("{k \\geq 0}")#text(". Show that the closure of ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" in ")#mi("{W^{k,\\infty}({\\bf R}^d)}")#text(" is ")#mi("{C^{k}_0({\\bf R}^d)}")#text(" (the space of ")#mi("{C^{k}}")#text(" functions whose first ")#mi("{k}")#text(" derivatives all go to zero at infinity), thus Lemma ")#link(<tao-cde56892bbebbf6c5fe5>)[#text("23")]#text(" fails at the endpoint ")#mi("{p=\\infty}")#text(".")
]

#text("Now we come to the important ")#emph[#text("Sobolev embedding theorem")]#text(", which allows one to trade regularity for integrability. We illustrate this phenomenon first with some very simple cases. First, we claim that the space ")#mi("{W^{1,1}({\\bf R})}")#text(" embeds continuously into ")#mi("{W^{0,\\infty}({\\bf R}) = L^\\infty({\\bf R})}")#text(", thus trading in one degree of regularity to upgrade ")#mi("{L^1}")#text(" integrability to ")#mi("{L^\\infty}")#text(" integrability. To prove this claim, it suffices to establish the bound ")#metadata(none) <tao-839104bf9d2cae503476>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\|f\\right\\|_{L^\\infty({\\bf R})} \\leq C \\left\\|f\\right\\|_{W^{1,1}({\\bf R})}", block: true)]]

#text(" for all test functions ")#mi("{f \\in C^\\infty_c({\\bf R})}")#text(" and some constant ")#mi("{C}")#text(", as the claim then follows by taking limits using Lemma ")#link(<tao-cde56892bbebbf6c5fe5>)[#text("23")]#text(". (Note that any limit in either the ")#mi("{L^\\infty}")#text(" or ")#mi("{W^{1,1}}")#text(" topologies, is also a limit in the sense of distributions, and such limits are necessarily unique. Also, since ")#mi("{L^\\infty({\\bf R})}")#text(" is the dual space of ")#mi("{L^1({\\bf R})}")#text(", the distributional limit of any sequence bounded in ")#mi("{L^\\infty({\\bf R})}")#text(" remains in ")#mi("{L^\\infty({\\bf R})}")#text(", by Exercise 28 of ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("Notes 3")]#text(".) To prove ")#link(<tao-839104bf9d2cae503476>)[#text("(1)")]#text(", observe from the fundamental theorem of calculus that")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x) - f(0)\\right| = \\left|\\int_0^x f^{\\prime}(t)\\ dt\\right| \\leq \\left\\|f^{\\prime}\\right\\|_{L^1({\\bf R})} \\leq \\left\\|f\\right\\|_{W^{1,1}({\\bf R})}", block: true)]]

#text("for all ")#mi("{x}")#text("; in particular, from the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{L^\\infty({\\bf R})} \\leq \\left|f(0)\\right| + \\left\\|f\\right\\|_{W^{1,1}({\\bf R})}.", block: true)]]

#text("Also, taking ")#mi("{x}")#text(" to be sufficiently large, we see (from the compact support of ")#mi("{f}")#text(") that")

#align(center)[#tao-fit-display[#tao-math("\\left|f(0)\\right| \\leq \\left\\|f\\right\\|_{W^{1,1}({\\bf R})}", block: true)]]

#text("and ")#link(<tao-839104bf9d2cae503476>)[#text("(1)")]#text(" follows.")

#text("Since the closure of ")#mi("{C^\\infty_c({\\bf R})}")#text(" in ")#mi("{L^\\infty({\\bf R})}")#text(" is ")#mi("{C_0({\\bf R})}")#text(", we actually obtain the stronger embedding, that ")#mi("{W^{1,1}({\\bf R})}")#text(" embeds continuously into ")#mi("{C_0({\\bf R})}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" Show that ")#mi("{W^{d,1}({\\bf R}^d)}")#text(" embeds continuously into ")#mi("{C_0({\\bf R}^d)}")#text(", thus there exists a constant ")#mi("{C}")#text(" (depending only on ")#mi("{d}")#text(") such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{C_0({\\bf R}^d)} \\leq C \\left\\|f\\right\\|_{W^{d,1}({\\bf R}^d)}", block: true)]]

#text("for all ")#mi("{f \\in W^{d,1}({\\bf R}^d)}")#text(".")
]

#text("Now we turn to Sobolev embedding for exponents other than ")#mi("{p=1}")#text(" and ")#mi("{p=\\infty}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 26 (Sobolev embedding theorem for one derivative)")]#text(" Let ")#mi("{1 \\leq p \\leq q \\leq \\infty}")#text(" be such that ")#mi("{\\frac{d}{p}-1 \\leq \\frac{d}{q} \\leq \\frac{d}{p}}")#text(", but that one is not in the endpoint cases ")#mi("{(p,q) = (d,\\infty), (1, \\frac{d}{d-1})}")#text(". Then ")#mi("{W^{1,p}({\\bf R}^d)}")#text(" embeds continuously into ")#mi("{L^q({\\bf R}^d)}")#text(".")
]

#emph[#text("Proof:")]#text(" By Lemma ")#link(<tao-cde56892bbebbf6c5fe5>)[#text("23")]#text(" and the same limiting argument as before, it suffices to establish the ")#emph[#text("Sobolev embedding inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^q({\\bf R}^d)} \\leq C_{p,q,d} \\left\\|f\\right\\|_{W^{1,p}({\\bf R}^d)}", block: true)]]

#text("for all test functions ")#mi("{f \\in C^\\infty_c({\\bf R}^d)}")#text(", and some constant ")#mi("{C_{p,q,d}}")#text(" depending only on ")#mi("{p,q,d}")#text(", as the inequality will then extend to all ")#mi("{f \\in W^{1,p}({\\bf R}^d)}")#text(". To simplify the notation we shall use ")#mi("{X \\lesssim Y}")#text(" to denote an estimate of the form ")#mi("{X \\leq C_{p,q,d} Y}")#text(", where ")#mi("{C_{p,q,d}}")#text(" is a constant depending on ")#mi("{p,q,d}")#text(" (the exact value of this constant may vary from instance to instance).")

#text("The case ")#mi("{p=q}")#text(" is trivial. Now let us look at another extreme case, namely when ")#mi("{\\frac{d}{p}-1 = \\frac{d}{q}}")#text("; by our hypotheses, this forces ")#mi("{1 < p < d}")#text(". Here, we use the fundamental theorem of calculus (and the compact support of ")#mi("{f}")#text(") to write")

#align(center)[#tao-fit-display[#mitex("f(x) = -\\int_0^\\infty \\omega \\cdot \\nabla f(x+r\\omega)\\ dr")]]

#text("for any ")#mi("{x \\in {\\bf R}^d}")#text(" and any direction ")#mi("{\\omega \\in S^{d-1}}")#text(". Taking absolute values, we conclude in particular that")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x)\\right| \\lesssim \\int_0^\\infty |\\nabla f(x+r\\omega)|\\ dr.", block: true)]]

#text("We can average this over all directions ")#mi("{\\omega}")#text(":")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x)\\right| \\lesssim \\int_{S^{d-1}} \\int_0^\\infty |\\nabla f(x+r\\omega)\\ dr d\\omega.", block: true)]]

#text("Switching from polar coordinates back to Cartesian (multiplying and dividing by ")#mi("{r^{d-1}}")#text(") we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x)\\right| \\lesssim \\int_{{\\bf R}^d} \\frac{1}{\\left|y\\right|^{d-1}} |\\nabla f(x-y)|\\ dy,", block: true)]]

#text("thus ")#mi("{f}")#text(" is pointwise controlled by the convolution of ")#tao-math("{\\left|\\nabla f\\right|}", block: false)#text(" with the fractional integration ")#tao-math("{\\frac{1}{\\left|x\\right|^{d-1}}}", block: false)#text(". By the Hardy-Littlewood-Sobolev theorem on fractional integration (Corollary 7 of ")#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/")[#text("Notes 1")]#text(") we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^q({\\bf R}^d)} \\lesssim \\left\\|\\nabla f \\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("and the claim follows. (Note that the hypotheses ")#mi("{1<p<d}")#text(" are needed here in order to be able to invoke this theorem.)")

#text("Now we handle intermediate cases, when ")#mi("{\\frac{d}{p} - 1 < \\frac{d}{q} < \\frac{d}{p}}")#text(". (Many of these cases can be obtained from the endpoints already established by interpolation, but unfortunately not all such cases can be, so we will treat this case separately.) Here, the trick is not to integrate out to infinity, but instead to integrate out to a bounded distance. For instance, the fundamental theorem of calculus gives")

#align(center)[#tao-fit-display[#mitex("f(x) = f(x+R\\omega)-\\int_0^R \\omega \\cdot \\nabla f(x+r\\omega)\\ dr")]]

#text("for any ")#mi("{R>0}")#text(", hence")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x)\\right| \\lesssim \\left|f(x+R\\omega)\\right| + \\int_0^R |\\nabla f(x+r\\omega)|\\ dr", block: true)]]

#text("What value of ")#mi("{R}")#text(" should one pick? If one picks any specific value of ")#mi("{R}")#text(", one would end up with an average of ")#mi("{f}")#text(" over spheres, which looks somewhat unpleasant. But what one can do here is ")#link("http://www.tricki.org/article/If_a_parameter_is_generating_undesirable_boundary_terms_try_averaging_over_many_choices_of_that_parameter")[#text("average")]#text(" over a ")#emph[#text("range")]#text(" of ")#mi("{R}")#text("‘s, for instance between ")#mi("{1}")#text(" and ")#mi("{2}")#text(". This leads to")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x)\\right| \\lesssim \\int_1^2 |f(x+R\\omega)|\\ dR + \\int_0^2 |\\nabla f(x+r\\omega)|\\ dr;", block: true)]]

#text("averaging over all directions ")#mi("{\\omega}")#text(" and converting back to Cartesian coordinates, we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x)\\right| \\lesssim \\int_{1 \\leq \\left|y\\right| \\leq 2} |f(x-y)|\\ dy + \\int_{\\left|y\\right| \\leq 2} \\frac{1}{\\left|y\\right|^{d-1}} |\\nabla f(x-y)|\\ dy.", block: true)]]

#text("Thus one is bounding ")#tao-math("{\\left|f\\right|}", block: false)#text(" pointwise (up to constants) by the convolution of ")#tao-math("{\\left|f\\right|}", block: false)#text(" with the kernel ")#tao-math("{K_1(y) := 1_{1 \\leq \\left|y\\right| \\leq 2}}", block: false)#text(", plus the convolution of ")#tao-math("{\\left|\\nabla f\\right|}", block: false)#text(" with the kernel ")#tao-math("{K_2(y) := 1_{\\left|y\\right| \\leq 2} \\frac{1}{\\left|y\\right|^{d-1}}}", block: false)#text(". A short computation shows that both kernels lie in ")#mi("{L^r({\\bf R}^d)}")#text(", where ")#mi("{r}")#text(" is the exponent in Young’s inequality, and more specifically that ")#mi("{\\frac{1}{q} + 1 = \\frac{1}{p} + \\frac{1}{r}}")#text(" (and in particular ")#mi("{1 < r < \\frac{d}{d-1}}")#text("). Applying Young’s inequality (Exercise 25 of ")#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/")[#text("Notes 1")]#text("), we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^q({\\bf R}^d)} \\lesssim \\left\\|f\\right\\|_{L^p({\\bf R}^d)} + \\left\\| \\nabla f \\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 27")]#text(" It is instructive to insert the example in Exercise ")#link(<tao-9c0abe51c6e6655d81de>)[#text("21")]#text(" into the Sobolev embedding theorem. By replacing the ")#mi("{W^{1,p}({\\bf R}^d)}")#text(" norm with the ")#mi("{L^q({\\bf R}^d)}")#text(" norm, one trades one factor of the frequency scale ")#tao-math("{\\left|\\xi\\right|}", block: false)#text(" for ")#mi("{\\frac{1}{q}-\\frac{1}{p}}")#text(" powers of the width ")#mi("{R^d}")#text(". This is consistent with the Sobolev embedding theorem so long as ")#tao-math("{R^d \\gtrsim 1/\\left|\\xi\\right|^d}", block: false)#text(", which is essentially one of the hypotheses in that exercise. Thus, one can view Sobolev embedding as an assertion that the width of a function must always be greater than or comparable to the wavelength scale (the reciprocal of the frequency scale), raised to the power of the dimension; this is a manifestation of the ")#link("http://en.wikipedia.org/wiki/Uncertainty_principle")[#text("uncertainty principle")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Let ")#mi("{d \\geq 2}")#text(". Show that the Sobolev endpoint estimate fails in the case ")#mi("{(p,q)=(d,\\infty)}")#text(". (")#emph[#text("Hint")]#text(": experiment with functions ")#mi("{f}")#text(" of the form ")#mi("{f(x) := \\sum_{n=1}^N \\phi(2^n x)}")#text(", where ")#mi("{\\phi}")#text(" is a test function supported on the ball ")#tao-math("{\\{ \\left|x\\right| \\leq 2 \\}}", block: false)#text(" and equal to one on ")#tao-math("{\\{ \\left|x\\right| \\leq 1 \\}}", block: false)#text(".) Conclude in particular that ")#mi("{W^{1,d}({\\bf R}^d)}")#text(" is not a subset of ")#mi("{L^\\infty({\\bf R}^d)}")#text(". (")#emph[#text("Hint:")]#text(" Either use the closed graph theorem, or use some variant of the function ")#mi("{f}")#text(" used in the first part of this exercise.) Note that when ")#mi("{d=1}")#text(", the Sobolev endpoint theorem for ")#mi("{(p,q)=(1,\\infty)}")#text(" follows from the fundamental theorem of calculus, as mentioned earlier. There are substitutes known for the endpoint Sobolev embedding theorem, but they involve more sophisticated function spaces, such as the space ")#mi("{\\text{BMO}}")#text(" of spaces of ")#link("http://en.wikipedia.org/wiki/Bounded_mean_oscillation")[#text("bounded mean oscillation")]#text(", which we will not discuss here.")
]

#text("The ")#mi("{p=1}")#text(" case of the Sobolev inequality cannot be proven via the Hardy-Littlewood-Sobolev inequality; however, there are other proofs available. One of these (due to Gagliardo and Nirenberg) is based on")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29 (Loomis-Whitney inequality)")]#text(" Let ")#mi("{d \\geq 1}")#text(", let ")#mi("{f_1,\\ldots,f_d \\in L^p({\\bf R}^{d-1})}")#text(" for some ")#mi("{0 < p \\leq \\infty}")#text(", and let ")#mi("{F: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be the function")

#align(center)[#tao-fit-display[#mitex("F( x_1,\\ldots,x_d ) := \\prod_{i=1}^d f_i( x_1,\\ldots,x_{i-1},x_{i+1},\\ldots,x_d).")]]

#text("Show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F \\right\\|_{L^{p/(d-1)}({\\bf R}^d)} \\leq \\prod_{i=1}^d \\left\\|f_i\\right\\|_{L^p({\\bf R}^{d-1})}.", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" induct on ")#mi("{d}")#text(", using Hölder’s inequality and Fubini’s theorem.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 30 (Endpoint Sobolev inequality)")]#text(" ")#mi("{W^{1,1}({\\bf R}^d)}")#text(" embeds continuously into ")#mi("{L^{d/(d-1)}({\\bf R}^d)}")#text(".")
]

#emph[#text("Proof:")]#text(" It will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^{d/(d-1)}({\\bf R}^d)} \\leq \\left\\|\\nabla f \\right\\|_{L^1({\\bf R}^d)}", block: true)]]

#text("for all test functions ")#mi("{f \\in C^\\infty_c({\\bf R}^d)}")#text(". From the fundamental theorem of calculus we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x_1,\\ldots,x_d)\\right| \\leq \\int_{\\bf R} |\\frac{\\partial f}{\\partial x_i}(x_1,\\ldots,x_{i-1},t,x_{i+1},\\ldots,x_d)|\\ dt", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x_1,\\ldots,x_d)\\right| \\leq f_i(x_1,\\ldots,x_{i-1},x_{i+1},\\ldots,x_d)", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("f_i(x_1,\\ldots,x_{i-1},x_{i+1},\\ldots,x_d) := \\int_{\\bf R} |\\nabla f(x_1,\\ldots,x_{i-1},t,x_{i+1},\\ldots,x_d)|\\ dt.")]]

#text("From Fubini’s theorem we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f_i\\right\\|_{L^1({\\bf R}^{d-1})} = \\left\\|\\nabla f \\right\\|_{L^1({\\bf R}^d)}", block: true)]]

#text("and hence by the Loomis-Whitney inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f_1 \\ldots f_d \\right\\|_{L^{1/(d-1)}({\\bf R}^d)} \\leq \\left\\|\\nabla f \\right\\|_{L^1({\\bf R}^d)}^d,", block: true)]]

#text("and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31 (Connection between Sobolev embedding and isoperimetric inequality)")]#text(" Let ")#mi("{d \\geq 2}")#text(", and let ")#mi("{\\Omega}")#text(" be an open subset of ")#mi("{{\\bf R}^d}")#text(" whose boundary ")#mi("{\\partial \\Omega}")#text(" is a smooth ")#mi("{d-1}")#text("-dimensional manifold. Show that the surface area ")#tao-math("{\\left|\\partial \\Omega\\right|}", block: false)#text(" of ")#mi("{\\Omega}")#text(" is related to the volume ")#tao-math("{\\left|\\Omega\\right|}", block: false)#text(" of ")#mi("{\\Omega}")#text(" by the ")#emph[#text("isoperimetric inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left|\\Omega\\right| \\leq C_d \\left|\\partial \\Omega\\right|^{d/(d-1)}", block: true)]]

#text("for some constant ")#mi("{C_d}")#text(" depending only on ")#mi("{d}")#text(". (")#emph[#text("Hint:")]#text(" Apply the endpoint Sobolev theorem to a suitably smoothed out version of ")#mi("{1_\\Omega}")#text(".) It is also possible to reverse this implication and deduce the endpoint Sobolev embedding theorem from the isoperimetric inequality and the coarea formula, which we will do in later notes.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" Use dimensional analysis to argue why the Sobolev embedding theorem should fail when ")#mi("{\\frac{d}{q} < \\frac{d}{p}-1}")#text(". Then create a rigorous counterexample to that theorem in this case.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" Show that ")#mi("{W^{k,p}({\\bf R}^d)}")#text(" embeds into ")#mi("{W^{l,q}({\\bf R}^d)}")#text(" whenever ")#mi("{k \\geq l \\geq 0}")#text(" and ")#mi("{1 < p < q \\leq \\infty}")#text(" are such that ")#mi("{\\frac{d}{p} - k \\leq \\frac{d}{q}-l}")#text(", and such that at least one of the two inequalities ")#mi("{q \\leq \\infty}")#text(", ")#mi("{\\frac{d}{p}-k \\leq \\frac{d}{q}-l}")#text(" is strict.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34")]#text(" Show that the Sobolev embedding theorem fails whenever ")#mi("{q<p}")#text(". (")#emph[#text("Hint:")]#text(" experiment with functions of the form ")#mi("{f(x) = \\sum_{j=1}^n \\phi(x-x_j)}")#text(", where ")#mi("{\\phi}")#text(" is a test function and the ")#mi("{x_j}")#text(" are widely separated points in space.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35 (Hölder-Sobolev embedding)")]#text(" Let ")#mi("{d < p < \\infty}")#text(". Show that ")#mi("{W^{1,p}({\\bf R}^d)}")#text(" embeds continuously into ")#mi("{C^{0,\\alpha}({\\bf R}^d)}")#text(", where ")#mi("{0 < \\alpha < 1}")#text(" is defined by the scaling relationship ")#mi("{\\frac{d}{p} - 1 = - \\alpha}")#text(". Use dimensional analysis to justify why one would expect this scaling relationship to arise naturally, and give an example to show that ")#mi("{\\alpha}")#text(" cannot be improved to any higher exponent.")

#text("More generally, with the same assumptions on ")#mi("{p,\\alpha}")#text(", show that ")#mi("{W^{k+1,p}({\\bf R}^d)}")#text(" embeds continuously into ")#mi("{C^{k,\\alpha}({\\bf R}^d)}")#text(" for all natural numbers ")#mi("{k \\geq 0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36 (Sobolev product theorem, special case)")]#text(" ")#metadata(none) <tao-426cb6ca5c3c92e757c2>#text(" Let ")#mi("{k \\geq 1}")#text(", ")#mi("{1 < p,q < d/k}")#text(", and ")#mi("{1 < r < \\infty}")#text(" be such that ")#mi("{\\frac{1}{p}+\\frac{1}{q} - \\frac{k}{d} = \\frac{1}{r}}")#text(". Show that whenever ")#mi("{f \\in W^{k,p}({\\bf R}^d)}")#text(" and ")#mi("{g \\in W^{k,q}({\\bf R}^d)}")#text(", then ")#mi("{fg \\in W^{k,r}({\\bf R}^d)}")#text(", and that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|fg\\right\\|_{W^{k,r}({\\bf R}^d)} \\leq C_{p,q,k,d,r} \\left\\|f\\right\\|_{W^{k,p}({\\bf R}^d)} \\left\\|g\\right\\|_{W^{k,q}({\\bf R}^d)}", block: true)]]

#text("for some constant ")#mi("{C_{p,q,k,d,r}}")#text(" depending only on the subscripted parameters. (This is not the most general range of parameters for which this sort of product theorem holds, but it is an instructive special case.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" Let ")#mi("{L}")#text(" be a differential operator of order ")#mi("{m}")#text(" whose coefficients lie in ")#mi("{C^\\infty({\\bf R}^d)}")#text(". Show that ")#mi("{L}")#text(" maps ")#mi("{W^{k+m,p}({\\bf R}^d)}")#text(" continuously to ")#mi("{W^{k,p}({\\bf R}^d)}")#text(" for all ")#mi("{1 \\leq p \\leq \\infty}")#text(" and all integers ")#mi("{k \\geq 0}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 3. ")#mi("{L^2}")#text("-based Sobolev spaces — ")]]

#text("It is possible to develop more general Sobolev spaces ")#mi("{W^{s,p}({\\bf R}^d)}")#text(" than the integer-regularity spaces ")#mi("{W^{k,p}({\\bf R}^d)}")#text(" defined above, in which ")#mi("{s}")#text(" is allowed to take any real number (including negative numbers) as a value, although the theory becomes somewhat pathological unless one restricts attention to the range ")#mi("{1 < p < \\infty}")#text(", for reasons having to do with the theory of ")#link("http://en.wikipedia.org/wiki/Singular_integral")[#text("singular integrals")]#text(".")

#text("As the theory of singular integrals is beyond the scope of this course, we will illustrate this theory only in the model case ")#mi("{p=2}")#text(", in which Plancherel’s theorem is available, which allows one to avoid dealing with singular integrals by working purely on the frequency space side.")

#text("To explain this, we begin with the Plancherel identity")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} \\left|f(x)\\right|^2\\ dx = \\int_{{\\bf R}^d} \\left|\\hat f(\\xi)\\right|^2\\ d\\xi,", block: true)]]

#text("which is valid for all ")#mi("{L^2({\\bf R}^d)}")#text(" functions and in particular for Schwartz functions ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(". Also, we know that the Fourier transform of any derivative ")#mi("{\\frac{\\partial f}{\\partial x_j} f}")#text(" of ")#mi("{f}")#text(" is ")#mi("{-2\\pi i \\xi_j \\hat f(\\xi)}")#text(". From this we see that")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} \\left|\\frac{\\partial f}{\\partial x_j}(x)\\right|^2\\ dx = \\int_{{\\bf R}^d} (2\\pi \\left|\\xi_j\\right|)^2 \\left|\\hat f(\\xi)\\right|^2\\ d\\xi,", block: true)]]

#text("for all ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(" and so on summing in ")#mi("{j}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} \\left|\\nabla f(x)\\right|^2\\ dx = \\int_{{\\bf R}^d} (2\\pi \\left|\\xi\\right|)^2 \\left|\\hat f(\\xi)\\right|^2\\ d\\xi.", block: true)]]

#text("A similar argument then gives")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} \\left|\\nabla^j f(x)\\right|^2\\ dx = \\int_{{\\bf R}^d} (2\\pi \\left|\\xi\\right|)^{2j} \\left|\\hat f(\\xi)\\right|^2\\ d\\xi", block: true)]]

#text("and so on summing in ")#mi("{j}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{W^{k,2}({\\bf R}^d)}^2 = \\int_{{\\bf R}^d} \\sum_{j=0}^k (2\\pi \\left|\\xi\\right|)^{2j} \\left|\\hat f(\\xi)\\right|^2\\ d\\xi", block: true)]]

#text("for all ")#mi("{k \\geq 0}")#text(" and all Schwartz functions ")#mi("{f \\in {\\mathcal S}({\\bf R}^d)}")#text(". Since the Schwartz functions are dense in ")#mi("{W^{k,2}({\\bf R}^d)}")#text(", a limiting argument (using the fact that ")#mi("{L^2}")#text(" is complete) then shows that the above formula also holds for all ")#mi("{f \\in W^{k,2}({\\bf R}^d)}")#text(".")

#text("Now observe that the quantity ")#tao-math("{\\sum_{j=0}^k (2\\pi \\left|\\xi\\right|)^{2j}}", block: false)#text(" is comparable (up to constants depending on ")#mi("{k,d}")#text(") to the expression ")#mi("{\\langle \\xi \\rangle^{2k}}")#text(", where ")#tao-math("{\\langle x \\rangle := (1+\\left|x\\right|^2)^{1/2}}", block: false)#text(" (this quantity is sometimes known as the “Japanese bracket” of ")#mi("{x}")#text("). We thus conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{W^{k,2}({\\bf R}^d)} \\sim \\left\\| \\langle \\xi \\rangle^k \\hat f(\\xi) \\right\\|_{L^2({\\bf R}^d)},", block: true)]]

#text("where we use ")#mi("{x \\sim y}")#text(" here to denote the fact that ")#mi("{x}")#text(" and ")#mi("{y}")#text(" are comparable up to constants depending on ")#mi("{d,k}")#text(", and ")#mi("{\\xi}")#text(" denotes the variable of independent variable on the right-hand side. If we then define, for any real number ")#mi("{s}")#text(", the space ")#mi("{H^s({\\bf R}^d)}")#text(" to be the space of all tempered distributions ")#mi("{f}")#text(" such that the distribution ")#mi("{\\langle \\xi \\rangle^s \\hat f(\\xi)}")#text(" lies in ")#mi("{L^2}")#text(", and give this space the norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{H^s({\\bf R}^d)} := \\left\\| \\langle \\xi \\rangle^s \\hat f(\\xi) \\right\\|_{L^2({\\bf R}^d)},", block: true)]]

#text("then we see that ")#mi("{W^{k,2}({\\bf R}^d)}")#text(" embeds into ")#mi("{H^k({\\bf R}^d)}")#text(", and that the norms are equivalent.")

#text("Actually, the two spaces are equal:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38")]#text(" For any ")#mi("{s \\in {\\bf R}}")#text(", show that ")#mi("{{\\mathcal S}({\\bf R}^d)}")#text(" is a dense subspace of ")#mi("{H^s({\\bf R}^d)}")#text(". Use this to conclude that ")#mi("{W^{k,2}({\\bf R}^d) = H^k({\\bf R}^d)}")#text(" for all non-negative integers ")#mi("{k}")#text(".")
]

#text("It is clear that ")#mi("{H^0({\\bf R}^d) \\equiv L^2({\\bf R}^d)}")#text(", and that ")#mi("{H^s({\\bf R}^d) \\subset H^{s^{\\prime}}({\\bf R}^d)}")#text(" whenever ")#mi("{s > s^{\\prime}}")#text(". The spaces ")#mi("{H^s({\\bf R}^d)}")#text(" are also (complex) ")#link("http://en.wikipedia.org/wiki/Hilbert_space")[#text("Hilbert spaces")]#text(", with the Hilbert space inner product")

#align(center)[#tao-fit-display[#mitex("\\langle f, g \\rangle_{H^s({\\bf R}^d)} := \\int_{{\\bf R}^d} \\langle \\xi \\rangle^{2s} f(\\xi) \\overline{g(\\xi)}\\ d\\xi.")]]

#text("It is not hard to verify that this inner product does indeed give ")#mi("{H^s({\\bf R}^d)}")#text(" the structure of a Hilbert space (indeed, it is isomorphic under the Fourier transform to the Hilbert space ")#mi("{L^2(\\langle \\xi \\rangle^{2s} d\\xi)}")#text(" which is isomorphic in turn under the map ")#mi("{F(\\xi) \\mapsto \\langle \\xi \\rangle^s F(\\xi)}")#text(" to the standard Hilbert space ")#mi("{L^2({\\bf R}^d)}")#text(").")

#text("Being a Hilbert space, ")#mi("{H^s({\\bf R}^d)}")#text(" is isomorphic to its dual ")#mi("{H^s({\\bf R}^d)^*}")#text(" (or more precisely, to the complex conjugate of this dual). There is another duality relationship which is also useful:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39 (Duality between ")#mi("{H^s}")#text(" and ")#mi("{H^{-s}}")#text(")")]#text(" Let ")#mi("{s \\in {\\bf R}}")#text(", and ")#mi("{f \\in H^s({\\bf R}^d)}")#text(". Show also for any continuous linear functional ")#mi("{\\lambda: H^s({\\bf R}^d) \\rightarrow {\\bf C}}")#text(" there exists a unique ")#mi("{g \\in H^{-s}({\\bf R}^d)}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\lambda(f) = \\langle f, g \\rangle_{L^2({\\bf R}^d)}")]]

#text("for all ")#mi("{f \\in H^s({\\bf R}^d)}")#text(", where the inner product ")#mi("{\\langle f, g \\rangle_{L^2({\\bf R}^d)}}")#text(" is defined via the Fourier transform as")

#align(center)[#tao-fit-display[#mitex("\\langle f, g\\rangle_{L^2({\\bf R}^d)} := \\int_{{\\bf R}^d} \\hat f(\\xi) \\overline{\\hat g(\\xi)}\\ d\\xi.")]]

#text("Also show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{H^s({\\bf R}^d)} := \\sup \\{ |\\langle f, g \\rangle_{L^2({\\bf R}^d)}: g \\in {\\mathcal S}({\\bf R}^d); \\left\\|g\\right\\|_{H^{-s}({\\bf R}^d)} \\leq 1 \\}", block: true)]]

#text("for all ")#mi("{f \\in H^s({\\bf R}^d)}")#text(".")
]

#text("The ")#mi("{H^s}")#text(" Sobolev spaces also enjoy the same type of embedding estimates as their classical counterparts:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40 (Sobolev embedding for ")#mi("{H^s}")#text(", I)")]#text(" If ")#mi("{s > d/2}")#text(", show that ")#mi("{H^s({\\bf R}^d)}")#text(" embeds continuously into ")#mi("{C^{0,\\alpha}({\\bf R}^d)}")#text(" whenever ")#mi("{0 < \\alpha \\leq \\min( s-\\frac{d}{2}, 1)}")#text(". (")#emph[#text("Hint:")]#text(" use the Fourier inversion formula and the Cauchy-Schwarz inequality.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 41 (Sobolev embedding for ")#mi("{H^s}")#text(", II)")]#text(" If ")#mi("{0 < s < d/2}")#text(", show that ")#mi("{H^s({\\bf R}^d)}")#text(" embeds continuously into ")#mi("{L^q({\\bf R}^d)}")#text(" whenever ")#mi("{\\frac{d}{2}-s \\leq \\frac{d}{q} \\leq \\frac{d}{2}}")#text(". (")#emph[#text("Hint:")]#text(" it suffices to handle the extreme case ")#mi("{\\frac{d}{q} = \\frac{d}{2}-s}")#text(". For this, first reduce to establishing the bound ")#tao-math("{\\left\\|f\\right\\|_{L^q({\\bf R}^d)} \\leq C \\left\\|f\\right\\|_{H^s({\\bf R}^d)}}", block: false)#text(" to the case when ")#mi("{f \\in H^s({\\bf R}^d)}")#text(" is a Schwartz function whose Fourier transform vanishes near the origin (and ")#mi("{C}")#text(" depends on ")#mi("{s,d,q}")#text("), and write ")#tao-math("{\\hat f(\\xi) = \\hat g(\\xi)/\\left|\\xi\\right|^s}", block: false)#text(" for some ")#mi("{g}")#text(" which is bounded in ")#mi("{L^2({\\bf R}^d)}")#text(". Then use Exercise 35 from ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("Notes 3")]#text(" and Corollary 7 from ")#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/")[#text("Notes 1")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42")]#text(" In this exercise we develop a more elementary variant of Sobolev spaces, the ")#emph[#mi("{L^p}")#text(" Hölder spaces")]#text(". For any ")#mi("{1 \\leq p \\leq \\infty}")#text(" and ")#mi("{0 < \\alpha < 1}")#text(", let ")#mi("{\\Lambda^p_\\alpha({\\bf R}^d)}")#text(" be the space of functions ")#mi("{f}")#text(" whose norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{\\Lambda^p_\\alpha({\\bf R}^d)} := \\left\\|f\\right\\|_{L^p({\\bf R}^d)} + \\sup_{x \\in {\\bf R}^d \\backslash \\{0\\}} \\frac{ \\left\\| \\tau_x f - f \\right\\|_{L^p({\\bf R}^d)} }{\\left|x\\right|^\\alpha}", block: true)]]

#text("is finite, where ")#mi("{\\tau_x(y) := f(y-x)}")#text(" is the translation of ")#mi("{f}")#text(" by ")#mi("{x}")#text(". Note that ")#mi("{\\Lambda^\\infty_\\alpha({\\bf R}^d) = C^{0,\\alpha}({\\bf R}^d)}")#text(" (with equivalent norms).")

#list(
[#text("(i) For any ")#mi("{0 < \\alpha < 1}")#text(", establish the inclusions ")#mi("{\\Lambda^2_{\\alpha+\\varepsilon}({\\bf R}^d) \\subset H^\\alpha({\\bf R}^d) \\subset \\Lambda^2_\\alpha({\\bf R}^d)}")#text(" for any ")#mi("{0 < \\varepsilon < 1-\\alpha}")#text(". (")#emph[#text("Hint:")]#text(" take Fourier transforms and work in frequency space.)")],
[#text("(ii) Let ")#mi("{\\phi \\in C^\\infty_c({\\bf R}^d)}")#text(" be a bump function, and let ")#mi("{\\phi_n}")#text(" be the approximations to the identity ")#mi("{\\phi_n(x) := 2^{dn} \\phi(2^n x)}")#text(". If ")#mi("{f \\in \\Lambda^p_\\alpha({\\bf R}^d)}")#text(", show that one has the equivalence")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{\\Lambda^p_\\alpha({\\bf R}^d)} \\sim \\left\\|f\\right\\|_{L^p({\\bf R}^d)} + \\sup_{n \\geq 0} 2^{\\alpha n} \\left\\| f*\\phi_{n+1} - f*\\phi_n\\right\\|_{L^p({\\bf R}^d)}", block: true)]]

#text("where we use ")#mi("{x \\sim y}")#text(" to denote the assertion that ")#mi("{x}")#text(" and ")#mi("{y}")#text(" are comparable up to constants depending on ")#mi("{p,d,\\alpha}")#text(". (")#emph[#text("Hint:")]#text(" To upper bound ")#tao-math("{\\left\\| \\tau_x f - f \\right\\|_{L^p({\\bf R}^d)}}", block: false)#text(" for ")#tao-math("{\\left|x\\right| \\leq 1}", block: false)#text(", express ")#mi("{f}")#text(" as a telescoping sum of ")#mi("{f*\\phi_{n+1}-f*\\phi_n}")#text(" for ")#mi("{2^{-n} \\leq x}")#text(", plus a final term ")#mi("{f*\\phi_{n_0}}")#text(" where ")#mi("{2^{-n_0}}")#text(" is comparable to ")#mi("{x}")#text(".)")],
[#text("(iii) If ")#mi("{1 \\leq p \\leq q \\leq \\infty}")#text(" and ")#mi("{0 < \\alpha < 1}")#text(" are such that ")#mi("{\\frac{d}{p}-\\alpha < \\frac{d}{q}}")#text(", show that ")#mi("{\\Lambda^p_\\alpha({\\bf R}^d)}")#text(" embeds continuously into ")#mi("{L^q({\\bf R}^d)}")#text(". (")#emph[#text("Hint:")]#text(" express ")#mi("{f(x)}")#text(" as ")#mi("{f*\\phi_1*\\phi_0}")#text(" plus a telescoping series of ")#mi("{f*\\phi_{n+1}*\\phi_n-f*\\phi_n*\\phi_{n-1}}")#text(", where ")#mi("{\\phi_n}")#text(" is as in the previous exercise. The additional convolution is in place in order to apply Young’s inequality.)")]
)

#text("The functions ")#mi("{f*\\phi_{n+1}-f*\\phi_n}")#text(" are crude versions of ")#emph[#text("Littlewood-Paley projections")]#text(", which play an important role in harmonic analysis and nonlinear wave and dispersive equations.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 43 (Sobolev trace theorem, special case)")]#text(" Let ")#mi("{s > 1/2}")#text(". For any ")#mi("{f \\in C^\\infty_c({\\bf R}^d)}")#text(", establish the ")#emph[#text("Sobolev trace inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| f\\downharpoonright_{{\\bf R}^{d-1}} \\right\\|_{H^{s-1/2}({\\bf R}^d)} \\leq C \\left\\|f\\right\\|_{H^s({\\bf R}^d)}", block: true)]]

#text("where ")#mi("{C}")#text(" depends only on ")#mi("{d}")#text(" and ")#mi("{s}")#text(", and ")#mi("{f\\downharpoonright_{{\\bf R}^{d-1}}}")#text(" is the restriction of ")#mi("{f}")#text(" to the standard hyperplane ")#mi("{{\\bf R}^{d-1} \\equiv {\\bf R}^{d-1} \\times \\{0\\} \\subset {\\bf R}^d}")#text(". (")#emph[#text("Hint:")]#text(" Convert everything to ")#mi("{L^2}")#text("-based statements involving the Fourier transform of ")#mi("{f}")#text(", and use either the Cauchy-Schwarz inequality or Schur’s test, see Lemma 5 of ")#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/")[#text("Notes 1")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 44")]#text(" ")#metadata(none) <tao-bd32e6364280b92ff06f>

#list(
[#text("(i) Show that if ")#mi("{f \\in H^s({\\bf R}^d)}")#text(" for some ")#mi("{s \\in {\\bf R}}")#text(", and ")#mi("{g \\in C^\\infty({\\bf R}^d)}")#text(", then ")#mi("{fg \\in H^s({\\bf R}^d)}")#text(" (note that this product has to be defined in the sense of tempered distributions if ")#mi("{s}")#text(" is negative), and the map ")#mi("{f \\mapsto fg}")#text(" is continuous from ")#mi("{H^s({\\bf R}^d)}")#text(" to ")#mi("{H^s({\\bf R}^d)}")#text(". (")#emph[#text("Hint:")]#text(" First prove this when ")#mi("{s}")#text(" is a non-negative integer using an argument similar to that in Exercise ")#link(<tao-426cb6ca5c3c92e757c2>)[#text("36")]#text(", then exploit duality to handle the case of negative integer ")#mi("{s}")#text(". To handle the remaining cases, decompose the Fourier transform of ")#mi("{f}")#text(" into annular regions of the form ")#tao-math("{\\{ \\xi: 2^n \\leq \\left|\\xi\\right| \\leq 2^{n+1}\\}}", block: false)#text(" for ")#mi("{n \\geq 0}")#text(", as well as the ball ")#tao-math("{\\{ \\xi: \\left|\\xi\\right| \\leq 1 \\}}", block: false)#text(", and use the preceding cases to estimate the ")#mi("{L^2}")#text(" norm of the Fourier transform of ")#mi("{fg}")#text(" these annular regions and on the ball.)")],
[#text("(ii) Let ")#mi("{L}")#text(" be a partial differential operator of order ")#mi("{m}")#text(" with coefficients in ")#mi("{C^\\infty({\\bf R}^d)}")#text(" for some ")#mi("{m \\geq 0}")#text(". Show that ")#mi("{L}")#text(" maps ")#mi("{H^s({\\bf R}^d)}")#text(" continuously to ")#mi("{H^{s-m}({\\bf R}^d)}")#text(" for all ")#mi("{s \\in {\\bf R}}")#text(".")]
)
]

#text("Now we consider a partial converse to Exercise ")#link(<tao-bd32e6364280b92ff06f>)[#text("44")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 45 (Elliptic regularity)")]#text(" ")#metadata(none) <tao-4fcb34bc60d2a440d653>#text(" Let ")#mi("{m \\geq 0}")#text(", and let")

#align(center)[#tao-fit-display[#mitex("L = \\sum_{j_1,\\ldots,j_d \\geq 0; j_1+\\ldots+j_d=m} c_{j_1,\\ldots,j_d} \\frac{\\partial^d}{\\partial x_{j_1} \\ldots \\partial x_{j_d}}")]]

#text("be a constant-coefficient homogeneous differential operator of order ")#mi("{m}")#text(". Define the ")#emph[#text("symbol")]#text(" ")#mi("{l: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" of ")#mi("{L}")#text(" to be the homogeneous polynomial of degree ")#mi("{m}")#text(", defined by the formula")

#align(center)[#tao-fit-display[#mitex("l(\\xi_1,\\ldots,\\xi_d) := \\sum_{j_1,\\ldots,j_d \\geq 0; j_1+\\ldots+j_d=m} c_{j_1,\\ldots,j_d} \\xi_{j_1} \\ldots \\xi_{j_d}.")]]

#text("We say that ")#mi("{L}")#text(" is ")#emph[#text("elliptic")]#text(" if one has the lower bound")

#align(center)[#tao-fit-display[#tao-math("\\left|l(\\xi)\\right| \\geq c \\left|\\xi\\right|^m", block: true)]]

#text("for all ")#mi("{\\xi \\in {\\bf R}^d}")#text(" and some constant ")#mi("{c>0}")#text(". Thus, for instance, the Laplacian is elliptic. Another example of an elliptic operator is the Cauchy-Riemann operator ")#mi("{\\frac{\\partial}{\\partial x_1} - i \\frac{\\partial}{\\partial x_2}}")#text(" in ")#mi("{{\\bf R}^2}")#text(". On the other hand, the heat operator ")#mi("{\\frac{\\partial}{\\partial t} - \\Delta}")#text(", the Schrödinger operator ")#mi("{i\\frac{\\partial}{\\partial t} + \\Delta}")#text(", and the wave operator ")#mi("{-\\frac{\\partial^2}{\\partial t^2}+\\Delta}")#text(" are not elliptic on ")#mi("{{\\bf R}^{1+d}}")#text(".")

#list(
[#text("(i) Show that if ")#mi("{L}")#text(" is elliptic of order ")#mi("{m}")#text(", and ")#mi("{f}")#text(" is a tempered distribution such that ")#mi("{f, Lf \\in H^s({\\bf R}^d)}")#text(", then ")#mi("{f \\in H^{s+m}({\\bf R}^d)}")#text(", and that one has the bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| f\\right\\|_{H^{s+m}({\\bf R}^d)} \\leq C ( \\left\\|f\\right\\|_{H^s({\\bf R}^d)} + \\left\\| Lf \\right\\|_{H^s({\\bf R}^d)} )", block: true)]]

#metadata(none) <tao-593f2d04aab251f60c9e>#text(" for some ")#mi("{C}")#text(" depending on ")#mi("{s,m,d,L}")#text(". (")#emph[#text("Hint:")]#text(" Once again, rewrite everything in terms of the Fourier transform ")#mi("{\\hat f}")#text(" of ")#mi("{f}")#text(".)")],
[#text("(ii) Show that if ")#mi("{L}")#text(" is a constant-coefficient differential operator of ")#mi("{m}")#text(" which is ")#emph[#text("not")]#text(" elliptic, then the estimate ")#link(<tao-593f2d04aab251f60c9e>)[#text("(2)")]#text(" fails.")],
[#text("(iii) Let ")#mi("{f \\in L^2_{loc}({\\bf R}^d)}")#text(" be a function which is locally in ")#mi("{L^2}")#text(", and let ")#mi("{L}")#text(" be an elliptic operator of order ")#mi("{m}")#text(". Show that if ")#mi("{Lf=0}")#text(", then ")#mi("{f}")#text(" is smooth. (")#emph[#text("Hint:")]#text(" First show inductively that ")#mi("{f \\phi \\in H^k({\\bf R}^d)}")#text(" for every test function ")#mi("{\\phi}")#text(" and every natural number ")#mi("{k \\geq 0}")#text(".)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 46")]#text(" The symbol ")#mi("{l}")#text(" of an elliptic operator (with real coefficients) tends to have level sets that resemble ellipsoids, hence the name. In contrast, the symbol of ")#emph[#text("parabolic")]#text(" operators such as the heat operator ")#mi("{\\frac{\\partial}{\\partial t}-\\Delta}")#text(" has level sets resembling paraboloids, and the symbol of ")#emph[#text("hyperbolic")]#text(" operators such as the wave operator ")#mi("{-\\frac{\\partial^2}{\\partial t^2}+\\Delta}")#text(" has level sets resembling hyperboloids. The symbol in fact encodes many important features of linear differential operators, in particular controlling whether singularities can form, and how they must propagate in space and/or time; but this topic is beyond the scope of this course.")
]

#heading(level: 1)[#text("Comments (193)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093f42428c5178c855bd751694e5f1c74335a14073b5c2669c9b8c102cf7ceba-08750b13ea407ac9e3276cb67a5579f080a488735539017981d5b858e11ae4ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sobolev Holder question")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-492971")[#strong[#text("Sobolev Holder question")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2018")])]

#text("Dear Prof. Tao,")

#text("is it true that C^s \\subset H^s = W^{s,2}? I imagine that it is true but I cannot provide an argument. Thanks in advance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-493051")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2018")])]

#text("Yes if one has a compact domain, but not in general. One can already see this at the ")#mi("s=0")#text(" level where the question is whether ")#mi("C^0")#text(" embeds into ")#mi("L^2")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/624981d19fe463be2ed0acd76efa2efa797448cf64677837c5a32c69f7a87ec8-cf2bb95283cf47912dee6b6fc0145752562d7ef391b76fd35f10a6febbf4203b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Hager")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-501863")[#strong[#text("Paul Hager")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2018")])]

#text("I was confused by the definition “… to be the space of all tempered distributions ")#mi("f")#text(" such that the distribution ")#mi("\\langle \\xi \\rangle^s \\hat f(\\xi)")#text(" lies in ")#mi("L^2")#text(" …”")

#text("A distribution that lies in ")#mi("L^2")#text(" implicitly means that the distribution is an “ordinary” function?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-501865")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2018")])]

#text("Yes, we view ")#mi("L^2")#text(" (or more generally, ")#mi("L^1_{loc}")#text(") as a subspace of the space of distributions (see the remarks near Exercise 8 of ")#link("https://terrytao.wordpress.com/wp-admin/edit-comments.php")[#text("the previous set of notes")]#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4c176746d965aef463b13b27963557dbbe9b9fec37b81af9b5a34a431720061-85e9c36149ed668baabec152ad92da01ad1e0edcf0538485bcfa38b431d09b5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rajesh")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-503354")[#strong[#text("Rajesh")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2018")])]

#text("Prof Tao,")

#text("“…as the very useful Sobolev embedding theorem, which allows one to trade regularity for integrability…”. Thats the use of Sobolev spaces. In this context, Fourier and Plancheral methods come very handy, when the corresponding Sobolev space is also a Hilbert space. But that is not always the case…. Only L^2 based Sobolev spaces are Hilbert spaces. According to Sobolev emebdding, if the function in R^d need to be holder continuous, then its gardient needs to be L^p integrable with p >= d+1. So for d >1, we need p > 2, so the associated Sobolev space cannot have a Hilbert space structure. So in this context, we cannot use Fourier Plancheral techniques. “But if” (stress If)… I say, that I can always find a Hilbert space, for any d, (even for cases when d>1), how useful a tool that it would be, in the context of PDE. What would the impact be? Any examples of PDE, on which there would be impact? Appreciate your valuable comments…")

#text("Thanks and Regards")#linebreak()#text(" Rajesh")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae63e97e4134ea00b165097458d7a55fe6d3824460810472bc98335e25ccbac0-09ba46f419ed0e570d2e30932a8d64b4d7226acb84700ff42fcc38bb39f9c26d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymus")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-625630")[#strong[#text("Anonymus")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2021")])]

#text("Is there any example of a function that is in a sobolev space intersection some gevrey space?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-632739")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2021")])]

#text("I think in exercise 28, phi should be supported in B(2) and identically 1 in B(1) to create a “layer cake”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-641490")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2022")])]

#text("At the beginning of the notes, the function ")#mi("{f(x) := \\phi(x) \\sin(Nx)}")#text(" and the function ")#mi("{g(x) := N^{-s} \\phi(x) \\sin(Nx)}")#text(" both have a frequency scale of about ")#mi("{N}")#text(". Why does the function ")#mi("{N^{-s} \\phi(Nx)}")#text(" also have a “frequency scale” of about ")#mi("{N}")#text("?")

#text("Don’t we need the periodicity of the sine function as in the previous two examples?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-641535")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("The Fourier transform of the function ")#mi("N^{-s} \\phi(Nx)")#text(" is concentrated in the range ")#tao-math("\\{ \\xi: \\left|\\xi\\right| \\sim N \\}", block: false)#text(", which is why one should heuristically think of this function as having a frequency scale of ")#mi("N")#text(". Alternatively, this function has a “wavelength” of ")#mi("\\sim 1/N")#text(" (albeit with only one oscillation of this wavelength being present, rather than many), and frequency is inversely proportional to wavelength.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-641544")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("Why in the function ")#mi("N^{-s} \\phi(Nx)")#text(", ")#mi("N")#text(" is not considered as the “width” of ")#mi("1/N")#text(" as for instance Example 4 does?")

#emph[#text("[I’m sorry, I was not able to parse this question. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-641554")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("Sorry, I meant to say *Exercise* 4. In that exercise, the function ")#mi("{A \\phi(x/R) \\sin(\\xi \\cdot x)}")#text(" is said to have “width” ")#mi("R^d")#text(". So I was wondering if one should also say that the function ")#mi("N^{-s} \\phi(Nx)")#text(" has with ")#mi("1/N^d")#text(", where you interprets ")#mi("N")#text(" as the frequency scale.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-641560")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("Yes, the function ")#mi("N^{-s} \\phi(Nx)")#text(" would informally have frequency ")#mi("\\sim N")#text(", wavelength ")#mi("\\sim 1/N")#text(", amplitude ")#mi("\\sim N^{-s}")#text(", and width ")#mi("\\sim 1/N^d")#text(", and consist of ")#mi("O(1)")#text(" oscillations. Drawing a graph of this function should make these statistics clear.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-641543")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("In Exercise 4, whenever one differentiates the function once, one has a factor of ")#mi("1/R")#text(" and ")#tao-math("\\left|\\xi\\right|", block: false)#text("; so by the assumption on ")#mi("R")#text(", it is bounded by totally one factor of ")#tao-math("\\left|\\xi\\right|", block: false)#text(". Since ")#tao-math("\\left|\\xi\\right|\\ge 1", block: false)#text(", so all ")#tao-math("\\left|\\xi\\right|^j", block: false)#text(", ")#mi("j\\le k")#text(", are dominated by ")#tao-math("\\left|\\xi\\right|^k", block: false)#text(". On the other hand, the constant ")#mi("C")#text(" comes from the max of ")#mi("\\phi^{(j)}")#text(", ")#mi("j\\le k")#text(".")

#text("How would you organize a neat formal argument? The higher-order mixed partial derivatives are messy. Even if one focuses on the case when ")#mi("d=1")#text(", more and more terms appear by the product rule as ")#mi("k")#text(" increases.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-641552")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("An induction on ")#mi("k")#text(" would work here. (Here one has to invest a little bit of thought into developing a suitable induction hypothesis. For instance, it would be good to have the induction hypothesis cover both the sine and cosine cases.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-641553")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("It is said in the notes that")#linebreak()#text(" ")#emph[#linebreak()#text(" The Hölder spaces ")#mi("{C^{k,\\alpha}({\\bf R}^d)}")#text(" are designed to “fill up the gaps” between the discrete spectrum ")#mi("{C^k({\\bf R}^d)}")#text(" of the continuously differentiable spaces.")#linebreak()#text(" ")]

#text("Exercise 8 seems to suggest that the gaps are not perfectly filled up yet:")#linebreak()#text(" ")#mi("C^k({\\bf R}^d)\\supset C^{k,\\alpha}({\\bf R}^d)\\supset C^{k+1}({\\bf R}^d)")

#text("Is there a family of spaces filling the gaps between ")#mi("C^{k,1}")#text(" and ")#mi("C^k")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-641556")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#emph[#linebreak()#text(" As before, ")#mi("{C^{k,0}({\\bf R}^d)}")#text(" is equal to ")#mi("{C^k({\\bf R}^d)}")#text(", and ")#mi("{C^{k,\\alpha}({\\bf R}^d)}")#text(" is contained in ")#mi("{C^{k,\\beta}({\\bf R}^d)}")#text(". The space …")#linebreak()#text(" ")]

#text("I think you want to switch ")#mi("\\alpha")#text(" and ")#mi("\\beta")#text(" if they are meant to be consistent with Exercise 6.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-641558")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("As Exercise 10 and 11 show, the Holder spaces do not fill the gaps between ")#mi("C^k")#text(" and ")#mi("C^{k+1}")#text(" completely.")

#text("One may want to make some kind of room of ")#mi("\\epsilon")#text(" argument for ")#mi("C^{k,1-\\epsilon}")#text(" so that one can conclude something for ")#mi("C^{k+1}")#text(". But this does not work because of the gaps. (Perhaps this is not how the Holder spaces are supposed to be used at all.)")

#text("Naively, one can simply ")#emph[#text("assume")]#text(" stronger differentiability when needed. How much more flexibility does one gain if one has already at least the regularity of, say, ")#mi("C^1")#text(" by using ")#mi("C^{1,\\alpha}")#text(" instead of simply ")#mi("C^2")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-641561")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("If one really wants to work with a continuum of spaces that does not experience discontinuities at integer regularities, then one can work with Holder-Zygmund spaces ")#mi("\\Lambda^s({\\bf R}^d) = B^{s,\\infty}_\\infty({\\bf R}^d)")#text(" (a special type of Besov space), which agree with the Holder spaces ")#mi("C^{k,\\alpha}({\\bf R}^d)")#text(" when ")#mi("s = k+\\alpha")#text(" and ")#mi("0 < \\alpha < 1")#text(" but disagree with the classical spaces ")#mi("C^k({\\bf R}^d)")#text(" when ")#mi("s=k")#text(". These are discussed for instance in Stein’s “Singular integrals and differentiability properties of functions”.")

#text("In elliptic and parabolic PDE one often expends significant effort to improve the regularity of a solution from some “critical” regularity (which for instance could be ")#mi("C^2")#text(") to a slightly “subcritical” regularity, such as ")#mi("C^{2,\\varepsilon}")#text("; this is often non-trivial and uses tools such as Moser iteration. Once one has some subcritical regularity, though, it is often relatively easy to gain even more regularity.")#linebreak()#text(" even more regularity.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-641559")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("Can one use Lemma 23 to ")#emph[#text("define")]#text(" the Sobolev spaces, i.e., completion of the space of test functions with respect to the Sobolev norm ")#mi("\\|\\cdot \\|_{W^{k,p}}")#text("? Then one would have Lemma 23 for free; would this make other originally “easy” propositions more difficult to prove?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-641563")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("Yes, this is an alternate route to setting up the foundations of the theory; Definition 18 will now need to be a theorem, rather than a definition, but one ends up in the same place at the end. (The situation is more delicate in the presence of a boundary; cf. the comments after Exercise 13.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-673959")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2023")])]

#text("At the beginning of the discussion of Sobolev embeddings, is the fact that ")#mi("W^{1,1}({\\bf R})")#text(" is a subset of ")#mi("L^\\infty({\\bf R})")#text(" a ")#emph[#text("consequence")]#text(" of the inequality (1) or something one ")#emph[#text("assumes")]#text(" true when proving the inclusion map from ")#mi("W^{1,1}({\\bf R})")#text(" to ")#mi("L^\\infty({\\bf R})")#text(" is continuous?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-673971")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2023")])]

#text("Inequality (1) shows ")#mi("L^\\infty(R)")#text(" is a subset of ")#mi("W^{1,1}(R)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-674162")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2023")])]

#text("1. One first establishes the inequality (1) for ")#mi("C_c^\\infty({\\bf R})")#text(". If ")#mi("f\\in W^{1,1}({\\bf R})")#text(", Lemma 23 shows ")#mi("f_n\\to f")#text(" in ")#mi("W^{1,1}({\\bf R})")#text(" for some sequence ")#mi("f_n\\in C_c^\\infty({\\bf R})")#text(". The inequality (1) (for ")#mi("f_n-f_m")#text(")shows that ")#mi("f_n")#text(" is a Cauchy sequence in ")#mi("L^\\infty({\\bf R})")#text(" and by completeness, ")#mi("f_n")#text(" converges to some ")#mi("g")#text(" in ")#mi("L^\\infty({\\bf R})")#text(". The uniqueness of limits in the sense of distributions implies that ")#mi("g=f")#text(" and one thus shows (1) for every ")#mi("f\\in W^{1,1}({\\bf R})")#text(", which implies ")#mi("W^{1,1}({\\bf R})\\hookrightarrow L^\\infty({\\bf R})")#text(". Does this argument work?")

#text("2. It seems that one does not need to use the fact that ")#mi("{L^\\infty({\\bf R})}")#text(" is the dual space of ")#mi("{L^1({\\bf R})}")#text(" as in:")

#emph[#text("“Also, since ")#mi("{L^\\infty({\\bf R})}")#text(" is the dual space of ")#mi("{L^1({\\bf R})}")#text(", the distributional limit of any sequence bounded in ")#mi("{L^\\infty({\\bf R})}")#text(" remains in ")#mi("{L^\\infty({\\bf R})}")#text("“.")]

#text("(One way to show completeness of ")#mi("L^\\infty")#text(" is to use duality, though.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-682782")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2024")])]

#text("Maybe I am missing something but is the first part of exercise 11 right, with ")#mi("s=1")#text(", ")#mi("k=1")#text(", and ")#mi("\\alpha=0")#text("? ")#tao-math("\\left|x\\right|", block: false)#text(" is not continuously differentiable at 0. So let ")#mi("\\phi(x)")#text(" be constant near ")#mi("x=0")#text(". Then ")#tao-math("\\left|x\\right| \\phi(x)", block: false)#text(" is not in ")#mi("C^{1,0}({\\mathbb R})")#text(", right?")

#emph[#text("[Oops, one should exclude the endpoints ")#mi("\\alpha=0,1")#text(" here, now corrected. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2ce48ff4753aa0e5fb653ec990d5f91c0aa0f3a8841533c560df7341aa8ea0c-edffe1b2e5c59dc55f8c9ef8e2522925eb3b5b45107f7eb8acfc3a48dc111e41.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aleksandar")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-684875")[#strong[#text("Aleksandar")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2024")])]

#text("Dear professor Tao,")

#text("I have a question regarding the Q.8 in your notes 6 for the course Math247b that I found here ")#link("https://www.math.ucla.edu/~tao/247b.1.07w/notes6.pdf")[#text("https://www.math.ucla.edu/~tao/247b.1.07w/notes6.pdf")]#text(".")#linebreak()#text("Excuse me for posting it here since it is not directly related to this post, but I didn’t know a better place to ask such question.")

#text("Can you please tell me if some results of the similar type hold when ")#mi("s<0")#text("? I need it for ")#mi("p=2")#text(", but I suppose there is nothing special in that. It would be perfect if the analogous property was true also for ")#mi("s<0")#text(", but I suppose you stated the problem this way because ")#mi("s\\ge 0")#text(" is necessary.")

#text("The following inequality would also suffice if it was true for some ")#mi("s^{\\prime} \\in(s,0)")#text(":")#linebreak()#tao-math("\\left\\| \\phi f\\right\\|_{W^{s,2}} \\lesssim \\left\\|f\\right\\|_{W^{s,2}}", block: false)#text(" ,")#linebreak()#text("but I cannot prove it either.")

#text("I tried to prove it using the Littlewood – Paley characterization of Sobolev spaces and the commutator bound:")#linebreak()#tao-math("\\left| P_j(\\phi f)(x) - (\\phi P_jf )(x)\\right| \\lesssim Mf(x)", block: false)#linebreak()#text("(where P_j is projection to frequencies ")#mi("\\sim 2^j")#text(" and ")#mi("Mf")#text(" is Hardy – Littlewood maximal function), but this necessarily introduces ")#tao-math("\\left\\|f\\right\\|_{L^2}+ \\left\\| f \\right\\|_{W^{2,s}}", block: false)#text("on the right hand side because of the maximal function. However, this is not acceptable if I want a smoothing inequality.")

#text("Can you please tell me if something like that is even true and if it is, what would be idea of the proof?")

#text("Thank you very much in advance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-684882")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2024")])]

#text("This can be proven by a duality argument, for instance exploiting the duality of ")#mi("W^{s,2}")#text(" and ")#mi("W^{-s,2}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2ce48ff4753aa0e5fb653ec990d5f91c0aa0f3a8841533c560df7341aa8ea0c-edffe1b2e5c59dc55f8c9ef8e2522925eb3b5b45107f7eb8acfc3a48dc111e41.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aleksandar")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-684889")[#strong[#text("Aleksandar")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2024")])]

#text("Ok, that is amazingly simple argument. Thank you very much!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-689227")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2025")])]

#text("I am having trouble proving exercise 3. I tried Taylor’s formula with integral remainder, but I am really stuck with an expression like")

#tao-math("\\left| \\sum_{0 < \\left|\\alpha\\right| < m} \\frac{D^\\alpha f(a)}{\\alpha!} (x - a)^\\alpha \\right| \\leq 2 \\left\\| f\\right\\|_{C^0(\\mathbb{R}^n)} + \\sum_{\\left|\\alpha\\right| = m} \\frac{\\left|(x - a)^\\alpha\\right|}{\\alpha!} \\left\\| D^\\alpha f \\right\\|_{C^0(R^n)}", block: false)

#text("and I don’t see how to get rid of the ")#mi("(x-a)^\\alpha")#text("‘s and stuff. Can you say what you had in mind? (I’m stuck for two days now)")

#text("Also can you say if this norm defined in exercise 3 is equivalent to the standard ")#mi("C^m")#text(" norm on an arbitrary open set?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-692060")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2026")])]

#text("Exercise 40 shows that ")#mi("H^1(\\mathbf{R}) \\subset C^{0,\\alpha}(\\mathbf{R})")#text(" for ")#mi("0<\\alpha\\le \\tfrac{1}{2}")#text(". On the other hand, functions in ")#mi("H^1(\\mathbf{R})")#text(" are also absolutely continuous.")

#text("Is there any inclusion relation between ")#mi("C^{0,\\alpha}(\\mathbf{R})")#text(" (")#mi("0<\\alpha\\le \\tfrac{1}{2}")#text(") and ")#mi("AC(\\mathbf{R})")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-692061")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2026")])]

#text("I ")#link("https://gemini.google.com/share/ee0ea009b3ab")[#text("am outsourcing this question to an AI")]#text(". See also ")#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/")[#text("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-3/#comment-692074")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2026")])]

#text("The discussion of the three Hölder spaces on open domains is very illuminating. It reminds me of another common convention: ")#mi("C^{k,\\alpha}(\\bar{\\Omega})")#text(" is defined to consist of functions ")#mi("u \\in C^k(\\bar{\\Omega})")#text(", where all derivatives of order ")#mi("\\leq k")#text(" are uniformly continuous on bounded subsets of ")#mi("\\Omega")#text(" and thus extend continuously to the closure ")#mi("\\bar{\\Omega}")#text(", with finite norm ")#tao-math("\\left\\|u\\right\\|_{C^{k,\\alpha}(\\bar{\\Omega})} := \\sum_{\\left|\\beta\\right| \\leq k} \\left\\|D^\\beta u\\right\\|_{C(\\bar{\\Omega})} + \\sum_{\\left|\\beta\\right|=k} [D^\\beta u]_{C^{0,\\alpha}(\\bar{\\Omega})}", block: false)

#text("This fits into the three-space hierarchy mentioned in the discussion: when ")#mi("\\partial \\Omega")#text(" is sufficiently smooth, ")#mi("C^{k,\\alpha}(\\bar{\\Omega})")#text(" coincides with the intermediate space ")#mi("C^{k,\\alpha}(\\mathbb{R}^d)\\downharpoonright_{\\Omega}")#text(" by extension theorems; when ")#mi("\\partial \\Omega")#text(" is rough, it sits strictly between the intermediate and maximal spaces")

#mi("\\displaystyle C^{k,\\alpha}(\\mathbb{R}^d)\\downharpoonright_{\\Omega} \\subsetneq C^{k,\\alpha}(\\bar{\\Omega}) \\subsetneq C^{k,\\alpha}(\\Omega)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-250255")[#strong[#text("functions in Holder space | Question and Answer")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2013")]

#text("[…] I came up with this while I was reading this ")#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/")[#text("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/680171dc78c80bd8820dc89c6589ab936e646fe12cbe1b0adf01f5612fa70a88-14f626dfd791b19f757cff15bafa94be9184aea65306a62e5aa4da22acc50a2e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zuchongzhi")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-255072")[#strong[#text("zuchongzhi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2013")])]

#text("Reblogged this on ")#link("http://zuchongzhi.wordpress.com/2013/12/02/245c-notes-4-sobolev-spaces/")[#text("Diary of a budding mathematican")]#text(" and commented:")#linebreak()#text(" Very nice article!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/680171dc78c80bd8820dc89c6589ab936e646fe12cbe1b0adf01f5612fa70a88-14f626dfd791b19f757cff15bafa94be9184aea65306a62e5aa4da22acc50a2e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zuchongzhi")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-255684")[#strong[#text("zuchongzhi")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("Dear Professor Tao:")

#text("May I ask a hint to prove (III) in Exercise 14? After establishing (II), I found I could not establish (III) rigorously at the singularity ")#mi("y=x")#text(". Since I have ")#mi("dy=r^{2}\\sin[\\theta]dr d\\theta d\\phi")#text(", I cannot cancel out the singularity as I have ")#tao-math("\\left|x-y\\right|^{-3}\\approx r^{-3}", block: false)#text(" at the bottom for ")#mi("\\partial_{i,j}u")#text(" after introducing a cut off function ")#mi("\\chi_{B(0,\\epsilon}")#text(". I am hoping the part within the ball should vanish as ")#mi("\\epsilon\\rightarrow 0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-255696")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("As suggested in the hint, you should first try the cases when f vanishes at x, or when f is constant in a neighbourhood of x. (The easiest case of all is when f vanishes in a neighbourhood of x, although this case is not large enough to be of much use by itself.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/680171dc78c80bd8820dc89c6589ab936e646fe12cbe1b0adf01f5612fa70a88-14f626dfd791b19f757cff15bafa94be9184aea65306a62e5aa4da22acc50a2e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zuchongzhi")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-255769")[#strong[#text("zuchongzhi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2013")])]

#text("I understand. I think you mean to expand f(y)=f(x)+g(y-x), with g(y-x) vanishes at x, and f(x) a constant. The integration then gives me 0 by symmetricity.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-315555")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2014")])]

#text("There is comment “Many of these cases can be obtained from the endpoints already established by interpolation, but unfortunately not all such cases can be, so we will treat this case separately” in the proof of the embedding theorem. I can’t see what case isn’t covered by interpolation. If we fix ")#mi("p")#text(", then the allowed ")#mi("q")#text(" is an interval, and we have already established two endpoints. Shouldn’t interpolation give us the whole interval?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-315574")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2014")])]

#text("In some cases, the relevant interval is open (or half-open) rather than closed, so at least one of the endpoint estimates are not available.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-315896")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2014")])]

#text("On the RHS of the last equation of Exercise 21, is it ")#mi("L^p(\\mathbf R^{d-1})")#text(" norm instead of ")#mi("L^p(\\mathbf R^d)")#text(" norm?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-316082")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2014")])]

#text("Sorry, but there is another ")#mi("\\mathbf R^d")#text(" which should be ")#mi("\\mathbf R^{d-1}")#text(" on the LHS of the last but one equation in Lemma 4.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45068773f729cf7664311bc4882cf2a7d6b00f8477e5abfe2b0fe1c549b5f572-a883809d53df5d27d9c0aeed61ae2274e06eb12570a9acd2aa1f702ea414c1e9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of eli")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-442316")[#strong[#text("eli")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2014")])]

#text("Your notes are really interesting. I’m wondering if you could suggest me a book or something similar for taking a look deep in this argument.")#linebreak()#text(" Thanks for your attention.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-461542")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2015")])]

#text("Is there a particular reason that this note works only in ")#mi("\\Omega={\\mathbb R}^d")#text(" instead of the general open subset ")#mi("\\Omega\\subset{\\mathbb R}^d")#text(" for ")#mi("W^{k,p}(\\Omega)")#text("?")

#emph[#text("[See the discussion after Exercise 12. The loss of global tools such as the global Fourier transform is one key reason why the theory of Sobolev spaces on domains is significantly more subtle, particularly at or near the boundary, than global Sobolev spaces, although many of the techniques used in the global case can be adapted to some extent for more general domains, after some effort. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-461585")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2015")])]

#text("In the Navier-Stokes Equations by Constantin and Foias, there is a proposition says that")

#text("Let ")#mi("\\Omega")#text(" satisfy the segment property. Then ")#mi("C_0^\\infty(\\Bbb{R}^n)")#text(" is dense in ")#mi("W^{m,p}(\\Omega)")#text(", for ")#mi("1\\geq p<\\infty")#text(".")

#text("There is no explanation for the notation ")#mi("C_0^\\infty(\\Bbb{R}^n)")#text(" in that old book. Do you think it is the same as ")#mi("C_c^\\infty(\\Bbb{R}^n)")#text(" in this note?")

#text("(Also, these two function spaces in the proposition have totally different domains, how can one be a subset of the other one?)")

#text("Can one understand in general that ")#mi("C_0(\\cdot)")#text(" is the \"closure\" of ")#mi("C_c(\\cdot)")#text("?")

#text("As you put in the comment of a question recently asked under your post \"function spaces\", one should really focus on the mathematical ideas instead of the human-invented notations. So what is the essential idea for ")#mi("C_0")#text(" and ")#mi("C_c")#text(" here? I have a vague idea that we have two different behaviors (properties) of functions: having compact support (in the domain ")#mi("\\Omega\\subset\\Bbb{R}^d")#text(" or the whole space ")#mi("\\Bbb{R}")#text("^d?) and \"vanishing\" on the boundary (or infinity?). They are related to each other by taking closure in some topological space. Am I right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-461627")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2015")])]

#text("I don’t know the notational conventions of Constantin and Foias, but they may be referring to the space of smooth functions that are compactly supported in ")#mi("\\Omega")#text(". Even if their notational conventions are absent or not completely accurate, one can jump ahead to the portion of the book where that proposition is actually ")#emph[#text("used")]#text(", to get some idea of what they were trying to do. (See also ")#link("https://terrytao.wordpress.com/advice-on-writing-papers/on-compilation-errors-in-mathematical-reading-and-how-to-resolve-them/")[#text("this previous article of mine")]#text(" on how to read mathematical texts.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-516748")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2019")])]

#text("The excellent article on Google plus is unfortunately no longer available. Are you going to repost it somewhere else?")

#emph[#text("[Link updated – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-462803")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2015")])]

#text("Suppose that ")#mi("A g=h")#text("the following Schauder estimates holds: ")#tao-math("\\left\\|g\\right\\|_{C^{2,\\alpha}} \\le C_1 \\left\\|h\\right\\|_{C^\\alpha}", block: false)#text(", ")#tao-math("\\left\\|\\nabla g\\right\\|_{C^{2,\\alpha}} \\le C_2 \\left\\|\\nabla h\\right\\|_{C^\\alpha}", block: false)#text(". Can we use some interpolation theorem to get ")#tao-math("\\left\\|g\\right\\|_{C^3} \\le C_3 \\left\\|h\\right\\|_{C^1}", block: false)#text("? Many thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-462807")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2015")])]

#text("I doubt it, given that the inverse ")#mi("\\Delta^{-1}")#text(" to the Laplacian (on, say, a torus) obeys the first two estimates but not the third (")#mi("\\nabla^2 \\Delta^{-1}")#text(" is bounded on Holder spaces, but not on ")#mi("C^1")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a26133b7599cccd11c1079806a888b90bc61993b52487c55c67c912e885c0382-c6c38fe12fda5510e75250bec327c85c8740ac4696f7db0ea74cec13eeb0bd93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charles Banqust")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-463297")[#strong[#text("Charles Banqust")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2015")])]

#text("Is the function sin(x) on any sobolev space H^s(R)? Remember that the Fourier transform of sinx is (delta_{-1}-delta_1) /2i.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-463439")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2015")])]

#text("Do have a quick example to illustrate what you say in the beginning?")

#emph[#text("… a first derivative ")#mi("{\\frac{\\partial f}{\\partial x_j}}")#text(" of a function in an ")#mi("{L^p}")#text(" space usually leaves all Lebesgue spaces, but a first derivative of a function in the Sobolev space ")#mi("{W^{s,p}}")#text(" will end up in another Sobolev space ")#mi("{W^{s-1,p}}")#text(".")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-463443")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2015")])]

#text("Consider for instance the function ")#tao-math("f(x) := \\varphi(x) \\log \\left|x\\right|", block: false)#text(" ")#strike[#text("for some")]#text(" on ")#mi("{\\bf R}")#text(", where ")#mi("\\varphi(x)")#text(" is a smooth bump function equal to 1 near the origin. This function lies in every ")#mi("L^p")#text(" space for every finite ")#mi("p")#text(", but it’s (weak) derivative blows up like ")#mi("1/x")#text(" near the origin, and so will exit all the ")#mi("L^p")#text(" spaces with ")#mi("1 \\leq p \\leq \\infty")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-468646")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2016")])]

#text("Why would ")#tao-math("\\varphi(x)\\log\\left|x\\right|", block: false)#text(" not blow up at ")#mi("x=0")#text(" (Would you elaborate why it is in ")#mi("L^p")#text(")? Maybe I’m missing something. Did you mean something in")

#emph[#text("the function ")#tao-math("f(x) := \\varphi(x) \\log \\left|x\\right|", block: false)#text(" for some (?) on ")#mi("{\\bf R}")]

#emph[#text("[Corrected, thanks. ")#tao-math("\\log \\left|x\\right|", block: false)#text(" does diverge very slowly at ")#mi("x=0")#text(", but not enough to destroy integrability: ")#tao-math("\\left|\\log \\left|x\\right|\\right|^p", block: false)#text(" is locally absolutely integrable for any ")#mi("0 < p < \\infty")#text(". -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-463446")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2015")])]

#text("Maybe I miss something in previous notes. I’m always confused about the concept “embedding” in the context of this note. Let ")#mi("X")#text(" and ")#mi("Y")#text(" be two topological space. If there exists ")#mi("f:X\\to f(X)\\subset Y")#text(" such that ")#mi("f")#text(" is a homeomorphism, then we say ")#mi("X")#text(" embeds in ")#mi("Y")#text(", right?")

#text("In Theorem 3,")

#text("… ")#mi("{W^{1,p}({\\bf R}^d)}")#text(" embeds continuously into ")#mi("{L^q({\\bf R}^d)}")#text(".")

#text("Would you elaborate what “embeds continuously” precisely mean (and what does it mean “")#emph[#text("not")]#text(" embeds continuously”)?")

#text("When people write")

#mi("{W^{1,p}({\\bf R}^d)}\\subset {L^q({\\bf R}^d)}")

#text("how shall I understand “")#mi("\\subset")#text("“? Does it just mean “is a subset of”? The topologies of the two spaces on the two sides of “")#mi("\\subset")#text("” are different, why would the “inclusion” be interesting?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-463451")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2015")])]

#text("The precise definition of “embedding” depends on what category one is working in, but it usually means that there is an injective map that respects the relevant structure of the spaces one is working with. In the case of function spaces, this usually means an injective map that is linear and continuous (though one can ask for stronger embeddings, such as a bicontinuous, bilipschitz, or isometric embedding). In many cases, the embedding is given by an inclusion map (possibly after performing some standard identifications, e.g. identifying a locally integrable function with the associated distribution, or identifying a continuous function with the equivalence class of functions equal almost everywhere with that continuous function). In such cases, the former space ")#mi("X")#text(" can be viewed as a subset of the latter ")#mi("Y")#text(", so we often use ")#mi("X \\subset Y")#text(" to denote the embedding in those cases.")

#text("In the case of the Sobolev embedding ")#mi("W^{1,p}({\\bf R}^d) \\subset L^q({\\bf R}^d)")#text(", the embedding is given by the inclusion map, and is linear and continuous (but not bicontinuous). The continuity of the Sobolev embedding is equivalent to the ")#mi("W^{1,p}")#text(" topology being stronger than the ")#mi("L^q")#text(" topology on ")#mi("W^{1,p}({\\bf R}^d)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-464139")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2015")])]

#text("Let ")#mi("\\mathcal{V}")#text(" be the space (without topology)")

#mi("\\displaystyle \\mathcal{V}=\\{u\\in C_0^\\infty(\\Omega)\\mid \\nabla\\cdot u=0\\}")

#text("where ")#mi("\\Omega")#text(" is a nonempty open connected subset of ")#mi("\\mathbb{R}^n")#text(".")

#text("It is said in the ")#emph[#text("Navier-Stokes Equations")]#text(" by Temam that the closure of ")#mi("\\mathcal{V}")#text(" in ")#mi("L^2(\\Omega)")#text(" and in ")#mi("H_0^1(\\Omega)")#text(" are two basic spaces in the study of the Navier-Stokes equations. While it is quite clear what the closure of ")#mi("\\mathcal{V}")#text(" in ")#mi("L^2(\\Omega)")#text(" means, I don’t quite understand later one.")

#text("By definition, ")#mi("H_0^1(\\Omega)")#text(" is ")#mi("W_0^{1,2}(\\Omega)")#text(" which is defined as")

#mi("\\displaystyle \\overline{C_0^\\infty(\\Omega)}^{\\|\\|_{W^{1,2}(\\Omega)}},")

#text("the closure of ")#mi("C_0^\\infty(\\Omega)")#text(" in the Sobolev space ")#mi("W^{1,2}(\\Omega)")#text(".")

#text("What is the convention for the topology of ")#mi("H_0^1(\\Omega)")#text("?")

#text("Is the same as the topology of ")#mi("H_0^1(\\Omega)")#text(" so that the closure of ")#mi("\\mathcal{V}")#text(" in ")#mi("H_0^1(\\Omega)")#text(" is the same as the closure of ")#mi("\\mathcal{V}")#text(" in ")#mi("H^1(\\Omega)")#text("?")

#text("One can write the closure of ")#mi("\\mathcal{V}")#text(" in ")#mi("L^2(\\Omega)")#text(" as")

#mi("\\displaystyle \\overline{\\mathcal{V}}^{\\|\\|_2}")#text(".")

#text("How about the other one? Do we have a norm for ")#mi("H_0^1(\\Omega)")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-464269")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2015")])]

#text("Generally, when taking the closure of a space in a normed vector space, the topology given to the closure is the topology induced from that normed vector space, thus for instance ")#mi("H^1_0(\\Omega)")#text(" will be given the topology from the ")#mi("W^{1,2}(\\Omega)")#text(" norm.")

#text("More generally, when reading a mathematical text (such as Temam’s), one can often deduce the answer to questions like this simply by reading ahead in the text until the point where the answer to the question becomes important (e.g. when one starts establishing or using convergence in the space in question). See my discussion on this at ")#link("https://plus.google.com/u/0/114134834346472219368/posts/TGjjJPUdJjk")[#text("https://plus.google.com/u/0/114134834346472219368/posts/TGjjJPUdJjk")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-464602")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2015")])]

#text("I’m confused. Is ")#mi("H^{-1}(\\Bbb{R})")#text(" the dual space of ")#mi("H^1_0(\\Bbb{R})")#text(" or the dual of ")#mi("H^1(\\Bbb{R})")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-464645")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2016")])]

#text("Hmm, this is a bad question. What really confuses me is what is the difference between the dual space of ")#mi("H_0^1(\\Omega)")#text(" and the dual of $H^1(\\Omega)$ where ")#mi("H^1_0(\\Omega)")#text(" is the closure of ")#mi("C_c^\\infty(\\Omega)")#text(" in ")#mi("H^1(\\Omega)")#text(". Are they the “same”?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-465120")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2016")])]

#text("Let ")#mi("U")#text(" be an open subset of ")#mi("\\mathbb{R}^n")#text(". If ")#mi("f\\in L^p(U)")#text(", then by extending ")#mi("f")#text(" to be identically zero outside ")#mi("U")#text(", one has ")#mi("f\\in L^p(\\mathbb{R}^n)")#text(". Do we have in general the similar result for ")#mi("W^{k,p}(U)")#text(" and ")#mi("W^{k,p}(\\mathbb{R}^n)")#text("?")

#emph[#text("[Not always. See e.g. ")#link("https://en.wikipedia.org/wiki/Sobolev_space#Extension_by_zero")[#text("https://en.wikipedia.org/wiki/Sobolev_space#Extension_by_zero")]#text(" -T. ]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-465205")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2016")])]

#text("Ah, the problem is on the boundary. So can we say that if ")#mi("f\\in W^{k,p}(U)")#text(", then ")#mi("f\\in W^{k,p}(\\mathbb{R}^n\\setminus\\partial U)")#text(" by extending $f$ to be identically zero outside ")#mi("U")#text("?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-466669")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2016")])]

#text("I don’t quite understand Exercise 30 and the remark right before it. Are we saying that ")#mi("H^{-s}(\\bf{R}^d)\\equiv H^s(\\bf{R}^d)^*")#text(" and since ")#mi("s=-(-s)")#text(", Exericse 30 shows that ")#mi("H^s(\\bf{R}^d)")#text(" is reflexive?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-466687")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2016")])]

#text("All Hilbert spaces are reflexive.")

#text("One can identify ")#mi("H^s({\\bf R}^d)^*")#text(" with ")#mi("\\overline{H^s({\\bf R}^d)}")#text(" using the general identification ")#mi("H^* \\equiv \\overline{H}")#text(" provided by the Riesz representation theorem for complex Hilbert spaces. Exercise 30 provides a different identification ")#mi("H^s({\\bf R}^d)^* \\equiv \\overline{H^{-s}({\\bf R}^d)}")#text(" that is based on the ")#mi("L^2")#text(" inner product rather than the ")#mi("H^s")#text(" inner product. (These two identifications are consistent with each other since ")#mi("L^2({\\bf R}^d)")#text(" and ")#mi("H^s({\\bf R}^d)")#text(" are isomorphic Hilbert spaces.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-466689")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2016")])]

#text("Let ")#mi("\\Omega")#text(" be a domain in ")#mi("{\\bf R}^d")#text(". Denote ")#mi("H_0^1(\\Omega)")#text(" as the closure of ")#mi("C_c^\\infty(\\Omega)")#text(" in ")#mi("H^1(\\Omega)")#text(". In his Partial Differential Equations, Evans gives the “Hilbert triple” (Gelfand triple)")#linebreak()#text(" ")#mi("\\displaystyle H_0^1(\\Omega)\\subset L^2(\\Omega)\\subset H^{-1}(\\Omega)")#linebreak()#text(" where one has that ")#mi("H^{-1}(\\Omega)")#text(" is the dual of ")#mi("H_0^1(\\Omega)")#text(".")

#text("This gives an identification of ")#mi("H^{-1}(\\Omega)")#text(" with ")#mi("H_0^1(\\Omega)")#text(" instead of ")#mi("H^1(\\Omega)")#text(". But ")#mi("H_0^1(\\Omega)")#text(" and ")#mi("H^1(\\Omega)")#text(" are two different spaces. Why does this not contradict Exercise 30?")

#text("Also, as you said in the comment (")#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-466686")[#text("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/#comment-466686")]#text(") to a question in 245B notes 5, ")#mi("H=\\overline{H}")#text(" as sets, hence ")#mi("H^*=\\overline{H}=H")#text(" as sets. How could one put a proper subset between ")#mi("H")#text(" and ")#mi("H^*")#text(" (where ")#mi("H=H_0^1(\\Omega)")#text(" in the quoted case)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-466720")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2016")])]

#text("When the domain ")#mi("\\Omega")#text(" is ")#mi("{\\bf R}^d")#text(", then ")#mi("\\Omega")#text(" has no boundary, and the spaces ")#mi("H^1(\\Omega)")#text(" and ")#mi("H^1_0(\\Omega)")#text(" coincide.")

#text("Also, it is better to think of isomorphic pairs such as ")#mi("H^*")#text(" and ")#mi("\\overline{H}")#text(" as being ")#emph[#text("equivalent")]#text(" or ")#emph[#text("identifiable")]#text(" rather than ")#emph[#text("identical")]#text(", as the latter can lead to some confusion if one treats too many of the equivalences as equalities. For instance, ")#mi("\\ell^2(\\{0,1,2,\\dots\\})")#text(" and ")#mi("\\ell^2(\\{1,2,\\dots\\})")#text(" are equivalent (one can simply shift the standard orthonormal basis for the former by one unit to obtain the latter), but one can also identify the latter space as a subspace of the former. It is fairly harmless to treat one of these equivalences as an equality, but of course one cannot do so for both equivalences at the same time.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-467542")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2016")])]

#text("Would the proof lemma 2 be still correct if one replaces ")#mi("C^\\infty_{loc}({\\bf R}^d)")#text(" with ")#mi("C^\\infty({\\bf R}^d)")#text("? I don’t have an example to see the difference.")

#emph[#text("[Yes – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-467544")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2016")])]

#text("Then when one replaces ")#mi("\\mathbb{R}^d")#text(" with arbitrary open subset ")#mi("\\Omega")#text(" of ")#mi("\\mathbb{R}^d")#text(", say an open ball, Lemma 2 is also correct, right? It seems that the proof can remain the same.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-467569")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2016")])]

#text("A quick search on Google returns the Meyer-Serrin theorem which says that ")#mi("C^\\infty(\\Omega)\\cap W^{k,p}(\\Omega)")#text(" is dense in ")#mi("W^{k,p}(\\Omega)")#text(". Also, it is pointed out that one needs extra conditions for ")#mi("\\partial\\Omega")#text(" if one want Lemma 2 be true when ")#mi("{\\bf R}^d")#text(" is replaced with ")#mi("\\Omega")#text(". Looking at the proof of Lemma 2 again, I still don’t know which part would break down for general arbitrary open sets.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d4e133338ebad5ed6a4473fdcf913aef297826015d7578d3c27d1259281a037-cc70617c68d072dda0a653f2df0f9a0a80ccbd890cbb7e63c47df9158e8c98a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ll314159")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-467811")[#strong[#text("ll314159")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2016")])]

#text("Exercise 24 indicates that if ")#mi("q\\neq\\infty")#text(", then ")#mi("k-l\\neq\\frac d p")#text(", is it only for the purpose of the exercice or is it because the sobolev embedding is false in this case? Is it not the same embedding as the one indicated in Exercise 26 ? (Using the definition ")#mi("W^{k+\\alpha,\\infty} := C^{k,\\alpha}")#text(")")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-467819")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2016")])]

#text("Exercise 24 fails at the double endpoint, for the same reason that Exercise 26 fails when ")#mi("\\alpha = 0")#text("; see Exercise 20.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-468645")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2016")])]

#text("Does the “width” of a function really mean “support” of a function in the beginning of this post?")

#emph[#text("…While ")#mi("{f}")#text(" is, strictly speaking, a smooth function, it becomes increasingly less smooth in the limit ")#mi("{N \\rightarrow \\infty}")#text("; for instance, the derivative ")#mi("{f^{\\prime}(x) = \\phi^{\\prime}(x) \\sin(Nx) + N \\phi(x) \\cos(Nx)}")#text(" grows at a roughly linear rate as ")#mi("{N \\rightarrow \\infty}")#text(", and the higher derivatives grow at even faster rates. So this function does not really have any regularity in the ")#strong[#text("limit")]#text(" ")#mi("{N \\rightarrow \\infty}")#text(". ")]

#text("What kind of “limit” should one understand in the discussion above at the beginning of this post? Or it doesn’t really matter?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-468649")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2016")])]

#text("The limit is in an informal sense for the purpose of the introductory discussion. By width, I refer to the measure of the support (so the width is a number, while the support is a set).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-468647")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2016")])]

#text("In Exercise 3, I think you mean")

#emph[#text("… Thus we see how the ")#mi("{C^k}")#text(" norm relates to the height…")]

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-468648")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2016")])]

#text("In Exercise 3, why “in particular how the width ")#mi("R")#text(" is largely irrelevant”?")

#text("The norm is of at most ")#tao-math("CA\\left|\\xi\\right|^k", block: false)#text(" and ")#tao-math("\\left|\\xi\\right|\\geq 1/R", block: false)#text(", so ")#mi("R")#text(" should be relevant but ")#mi("N")#text(" is not (since ")#mi("N")#text(" does not appear in ")#tao-math("CA\\left|\\xi\\right|^k", block: false)#text(")?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-468650")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2016")])]

#text("The frequency scale ")#mi("N")#text(" is the order of magnitude of ")#tao-math("\\left|\\xi\\right|", block: false)#text(", so the norm is comparable to ")#mi("A N^k")#text(", which is an expression which is only barely connected to ")#mi("R")#text(" through the bound ")#mi("N \\gtrsim 1/R")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-468652")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2016")])]

#emph[#text("…whose norm is given by the formula")]

#tao-math("\\displaystyle \\left\\|f\\right\\|_{C^k({\\bf R}^d)} := \\sum_{j=0}^k \\sup_{x \\in {\\bf R}^d} \\left|\\nabla^j f(x)\\right| = \\sum_{j=0}^k \\left\\|\\nabla^j f\\right\\|_{L^\\infty({\\bf R}^d)},", block: false)

#text("where we view ")#mi("{\\nabla^j f}")#text(" as ")#strong[#text("a rank ")#mi("{j}")#text(", dimension ")#mi("{d}")#text(" tensor")]#text(" with complex coefficients (or equivalently, as a vector of dimension ")#mi("{d^j}")#text(" with complex coefficients)")

#text("I just tried to read the scary lengthy article in Wikipedia (")#link("https://en.wikipedia.org/wiki/Tensor")[#text("https://en.wikipedia.org/wiki/Tensor")]#text(") to understand what is a tensor. That article says that an ")#mi("(n,m)")#text(" tensor is an element of the tensor product (of vector space and its dual)")

#mi("\\displaystyle V\\otimes\\cdots\\otimes V\\otimes V^*\\otimes\\cdots \\otimes V^*")

#text("where there are $n$ copies of ")#mi("V")#text(" and ")#mi("m")#text(" copies of ")#mi("V^*")#text(".")

#text("Would you explain what is a rank ")#mi("{j}")#text(", dimension ")#mi("{d}")#text(" tensor (and why is ")#mi("{\\nabla^j f}")#text(" a such tensor?) and how does it relates to the Wikipedia definition?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-468672")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2016")])]

#text("A rank ")#mi("j")#text(", dimension ")#mi("d")#text(" tensor is an element of ")#mi("{\\bf R}^d \\otimes \\dots \\otimes {\\bf R}^d")#text(", where there are ")#mi("j")#text(" copies of ")#mi("{\\bf R}^d")#text(". In coordinates, this would be an expression of the form ")#mi("T = (a_{i_1 \\dots i_j})_{1 \\leq i_1,\\dots,i_j \\leq d}")#text(", where the ")#mi("a_{i_1,\\dots,i_j}")#text(" are scalars. A rank 0 tensor is a scalar, a rank 1 tensor is a ")#mi("d")#text("-dimensional vector, a rank 2 tensor can be viewed in coordinates as a ")#mi("d \\times d")#text(" matrix, and higher rank tensors can more generally be viewed as hypermatrices.")

#text("The specific tensor ")#mi("\\nabla^j f(x)")#text(" is the rank ")#mi("j")#text(", dimension ")#mi("d")#text(" tensor with coefficients ")#mi("a_{i_1 \\dots i_j} := \\frac{\\partial^d}{\\partial_{x_{i_1}} \\dots \\partial_{x_{i_d}}} f(x)")#text(". ")#mi("\\nabla^0 f(x)")#text(" is just ")#mi("f(x)")#text(", ")#mi("\\nabla^1 f(x)")#text(" is the gradient of ")#mi("f")#text(" at ")#mi("x")#text(", ")#mi("\\nabla^2 f(x)")#text(" is the ")#link("https://en.wikipedia.org/wiki/Hessian_matrix")[#text("Hessian matrix")]#text(", and so forth.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-468654")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2016")])]

#text("In building up the Gagliardo-Nirenberg-Sobolev inequality, one asks whether we can establish an estimate of the form")

#tao-math("\\displaystyle \\left\\|u\\right\\|_{L^q({\\bf R}^n)}\\leq C\\left\\|Du\\right\\|_{L^p({\\bf R}^n)}", block: false)

#text("for certain constants ")#mi("C>0")#text(" and ")#mi("1\\leq q < \\infty")#text(". By plugging in the inequality with the rescaled function ")#mi("u(\\lambda x)")#text(", one could have a motivation for the Sobolev conjugate of ")#mi("p")#text(".")

#text("Do we have similar motivation for those fractions in the statement of Theorem 3?")

#emph[#text("[Yes; see Exercise 23. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-468849")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2016")])]

#emph[#text("At one extreme, one has the space ")#mi("{C^{k,\\alpha}(\\Omega)}")#text(", defined as the space of ")#mi("{k}")#text(" times continuously differentiable functions ")#mi("{f: \\Omega \\rightarrow {\\bf C}}")#text(" whose Hölder norm")]

#tao-math("\\displaystyle \\left\\|f\\right\\|_{C^{k,\\alpha}(\\Omega)} := \\sum_{j=0}^k \\sup_{x \\in \\Omega} \\left|\\nabla^j f(x)\\right| + \\sup_{x,y \\in \\Omega: x \\neq y} \\frac{\\left|\\nabla^j f(x)-\\nabla^j f(y)\\right|}{\\left|x-y\\right|^\\alpha}", block: false)

#text("is finite;")

#text("Do you mean")

#tao-math("\\displaystyle \\left\\|f\\right\\|_{C^{k,\\alpha}(\\Omega)} := \\sum_{j=0}^k \\left(\\sup_{x \\in \\Omega} \\left|\\nabla^j f(x)\\right| + \\sup_{x,y \\in \\Omega: x \\neq y} \\frac{\\left|\\nabla^j f(x)-\\nabla^j f(y)\\right|}{\\left|x-y\\right|^\\alpha}\\right)", block: false)#linebreak()#text(" or")

#tao-math("\\displaystyle \\left\\|f\\right\\|_{C^{k,\\alpha}(\\Omega)} := \\sum_{j=0}^k \\sup_{x \\in \\Omega} \\left|\\nabla^j f(x)\\right| + \\sup_{x,y \\in \\Omega: x \\neq y} \\frac{\\left|\\nabla^k f(x)-\\nabla^k f(y)\\right|}{\\left|x-y\\right|^\\alpha}?", block: false)

#text("In what sense is this the “maximal” choice? Is it in the sense of sets as")

#mi("\\displaystyle C_0^{k,\\alpha}(\\Omega)\\subset C^{k,\\alpha}(\\mathbb{R}^d)|_{\\Omega}\\subset C^{k,\\alpha}(\\Omega)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-468850")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2016")])]

#text("In the remark after Exercise 12, is the following definition (I’ve seen in other places before but I can’t figure out if it is equivalent to the one in this note) for ")#mi("C^{k,\\alpha}(\\mathbb{R}^d)|_\\Omega")#text(" equivalent to the one in the post (when ")#mi("\\alpha")#text(")?")

#text("Define when ")#mi("\\alpha=0")#text(",")

#mi("\\displaystyle C^{k,\\alpha}(\\mathbb{R}^d)|_\\Omega =\\{f\\in C^{k,\\alpha}(\\Omega): \\nabla^j f \\textrm{ has continuous extension to }\\partial\\Omega\\}")#text(".")

#text("(Can one defined ")#mi("C^{k,\\alpha}(\\mathbb{R}^d)|_\\Omega")#text(" in a similar way as above when ")#mi("\\alpha>0")#text(" so that one has some sort of “continuous extension to ")#mi("\\partial \\Omega")#text(" for ‘")#mi("f^{k,\\alpha}")#text("‘ “?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-468851")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2016")])]

#text("I guess this might relate to the Whitney’s extension problem, but I’m not sure about the details.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-469102")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2016")])]

#text("I saw some books (e.g. Hunter’s Applied Analysis) define ")#mi("H^s({\\bf R}^d)")#text(" as the space of all tempered distribution ")#mi("f")#text(" such that (1) the Fourier transform ")#mi("\\hat f")#text(" is a regular distribution (i.e. there exists some continuous or Lebesgue measurable function ")#mi("h")#text(" such that ")#tao-math("\\left|f(x)\\right|\\leq g(x)(1+\\left|x\\right|^2)^{m/2}", block: false)#text(" and the distribution is represented by ")#mi("h")#text("); (2) the distribution ")#mi("{\\langle \\xi \\rangle^s \\hat f(\\xi)}")#text(" lies in ")#mi("{L^2}")#text(". In this post, only (2) is given. Are these two definition equivalent?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-470134")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2016")])]

#text("In Exercise 13,")

#text("Show that ")#mi("{C^\\infty_c({\\bf R}^d)}")#text(" is a dense subset of ")#mi("{C^{k,\\alpha}_0({\\bf R}^d)}")#text(" …")

#text("Isn’t it true by definition of ")#mi("{C^{k,\\alpha}_0({\\bf R}^d)}")#text("? Do you mean ")#mi("{C^{k,\\alpha}({\\bf R}^d)}")#text(" instead?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-470271")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2016")])]

#text("My question is rather elementary:")

#text("In the motivation of the definition of the space ")#mi("H^s")#text(", you mention a key estimate")

#tao-math("\\displaystyle (1+\\left|\\xi\\right|^2)^k\\lesssim \\sum_{\\left|\\alpha\\right|\\leq k}\\left|\\xi^\\alpha\\right|^2\\lesssim (1+\\left|\\xi\\right|^2)^k", block: false)

#text("Would you elaborate how one can build up such inequality?")

#emph[#text("[Try checking the cases ")#tao-math("\\left|\\xi\\right| \\leq 1", block: false)#text(" and ")#tao-math("\\left|\\xi\\right| > 1", block: false)#text(" separately. You can try the one-dimensional case first if you are not comfortable with working with multi-indices. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-470299")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2016")])]

#text("Using the binomial theorem, one has")

#mi("\\displaystyle I:=(1+\\xi_1^2)^k=1+\\xi_1^{2k}+\\binom{k}{1}\\xi_1^2+\\cdots+\\binom{k}{k-1}\\xi_1^{2(k-1)}")#linebreak()#text(" On the other hand,")#linebreak()#text(" ")#mi("\\displaystyle II:=\\sum_{\\alpha_1\\leq k}\\xi_1^{2\\alpha_1}=1+\\xi_1^{2k}+\\xi_1^2+\\cdots+\\xi_1^{2(k-1)}.")#linebreak()#text(" Now take")#linebreak()#text(" ")#mi("\\displaystyle C=\\max\\left\\{\\binom{k}{j}\\mid j=0,1,\\cdots,k\\right\\}.")#linebreak()#text(" Then ")#mi("I\\leq C\\cdot II")#text(" and ")#mi("II\\leq I")#text(".")

#text("In the higher dimensional case, I guess the multinomial theorem would work.")

#text("It seems that you have an easy way to handle it by considering separately ")#tao-math("\\left|\\xi\\right|\\leq 1", block: false)#text(" and ")#tao-math("\\left|\\xi\\right|>1", block: false)#text(". Would you elaborate?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-472869")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2016")])]

#text("I don’t quite understand the comment above. Why checking the cases separately would help. Don’t they give one half of the inequality but one needs the two inequalities both true for all ")#tao-math("\\left|\\xi\\right|", block: false)#text("?")

#emph[#text("[One can prove both inequalities in the ")#tao-math("\\left|\\xi\\right| \\leq 1", block: false)#text(" case, and prove both inequalities in the ")#tao-math("\\left|\\xi\\right| > 1", block: false)#text(" case, and these four facts together give the full claim. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-470273")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2016")])]

#text("Typo in the line")

#text("Also, we know that the Fourier transform of any derivative ")#mi("{\\frac{\\partial f}{\\partial x_j} f}")#text(" of ")#mi("{f}")#text(" is ")#mi("{-2\\pi i \\xi_j \\hat f(\\xi)}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-470274")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2016")])]

#text("The following part of the argument is a little confusing for me:")

#emph[#linebreak()#text(" A similar argument then gives")]

#tao-math("\\displaystyle \\int_{{\\bf R}^d} \\left|\\nabla^j f(x)\\right|^2\\ dx = \\int_{{\\bf R}^d} (2\\pi \\left|\\xi\\right|)^{2j} \\left|\\hat f(\\xi)\\right|^2\\ d\\xi", block: false)#linebreak()

#text("By definition,")

#tao-math("\\displaystyle \\left|\\nabla^j f(x)\\right| = (\\sum_{i_1,\\ldots,i_j = 1,\\ldots d} \\left|\\frac{\\partial^j}{\\partial x_{i_1} \\ldots \\partial x_{i_j}} f(x)\\right|^2)^{1/2}.", block: false)

#text("When applying the Plancherel, should the right hand side be")

#tao-math("\\displaystyle  \\sum_{\\left|\\alpha\\right|\\leq j}\\int_{{\\bf R}^d} (2\\pi \\left|\\xi^\\alpha\\right|)^{2} \\left|\\hat f(\\xi)\\right|^2\\ d\\xi", block: false)#text("?")

#emph[#text("[Not quite: firstly, ")#tao-math("\\left|\\alpha\\right|", block: false)#text(" should be equal to ")#mi("j")#text(", not less than or equal to ")#mi("j")#text("; the ")#mi("2\\pi")#text(" factor should be raised to a power of ")#mi("j")#text("; and a multinomial coefficient ")#mi("\\binom{j}{\\alpha}")#text(" is missing. You might try first a small numerical example, e.g. ")#mi("j=d=2")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-470327")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2016")])]

#text("In Definition 1")#linebreak()#text(" ")#emph[#linebreak()#text(" A function ")#mi("{f}")#text(" is said to lie in ")#mi("{W^{k,p}({\\bf R}^d)}")#text(" if its weak derivatives ")#mi("{\\nabla^j f}")#text(" exist and lie in ")#mi("{L^p({\\bf R}^d)}")#text(" for all ")#mi("{j=0,\\ldots,k}")#text(" …")#linebreak()#text(" ")]

#text("can one replace “A function” with “A distribution”, and “weak derivatives” with “distributional derivatives”?")

#text("Why do we need ")#mi("f")#text(" to be at least locally integrable or is it forced to be so?")

#emph[#text("[From H\\”older’s inequality, elements of ")#mi("L^p")#text(" are automatically locally integrable for any ")#mi("p \\geq 1")#text(" – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-470328")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2016")])]

#emph[#linebreak()#text(" the space ")#mi("{H^s({\\bf R}^d)}")#text(" to be the space of all tempered distributions ")#mi("{f}")#text(" such that the distribution ")#mi("{\\langle \\xi \\rangle^s \\hat f(\\xi)}")#text(" lies in ")#mi("{L^2}")#text(", and give this space the norm")]

#tao-math("\\displaystyle \\left\\|f\\right\\|_{H^s({\\bf R}^d)} := \\left\\| \\langle \\xi \\rangle^s \\hat f(\\xi) \\right\\|_{L^2({\\bf R}^d)}", block: false)#text(",")

#text("Given a tempered distribution ")#mi("f")#text(", according to the definition in notes 2, its Fourier transform ")#mi("\\hat f")#text(" is again a tempered distribution, which is a linear functional on the Schwartz space. By the definition in Notes 3, ")#mi("{\\langle \\xi \\rangle^s \\hat f(\\xi)}")#text(" is another tempered distribution. Must it be a locally integrable function? Why does it make sense to talk about a linear functional being in ")#mi("L^2")#text("?")

#emph[#text("[As in the previous comment, every ")#mi("L^2")#text(" function is locally integrable and is hence a distribution. Of course, the converse is not true: most distributions are not locally integrable, and hence most distributions are not ")#mi("L^2")#text(". But some of them are. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-470333")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2016")])]

#text("If ")#mi("f\\in H^s")#text(", then ")#mi("{\\langle \\xi \\rangle^s \\hat f(\\xi)}")#text(" is in ")#mi("L^2")#text(" by definition. Does the comment also suggests that ")#mi("{\\hat f(\\xi)}")#text(" is in ")#mi("L^2")#text(" too? (Or how “bad” it could be?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-470342")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2016")])]

#text("If ")#mi("s \\geq 0")#text(" and ")#mi("\\langle \\xi \\rangle^s \\hat f(\\xi)")#text(" is in ")#mi("L^2")#text(", then ")#mi("\\hat f")#text(" is also in ")#mi("L^2")#text(". If ")#mi("s")#text(" is negative, this is no longer necessarily the case, but ")#mi("\\hat f")#text(" will still locally be in ")#mi("L^2")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-470348")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2016")])]

#text("I don’t understand the point of Exercise 29.")

#text("We already conclude that")

#tao-math("\\displaystyle \\left\\| f \\right\\|_{W^{k,2}({\\bf R}^d)} \\sim \\left\\| \\langle \\xi \\rangle^k \\hat f(\\xi) \\right\\|_{L^2({\\bf R}^d)}", block: false)#text(".")

#text("Why we only see")#linebreak()#text(" ")#emph[#linebreak()#text(" that ")#mi("{W^{k,2}({\\bf R}^d)}")#text(" embeds into ")#mi("{H^k({\\bf R}^d)}")#text("?")]

#text("Why it is not immediate that ")#mi("W^{k,2}({\\bf R}^d)=H^k({\\bf R}^d)")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-470350")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2016")])]

#text("The equivalence ")#tao-math("\\left\\|f\\right\\|_{W^{k,2}({\\bf R}^d)} \\sim \\left\\| \\langle \\xi \\rangle^k \\hat f(\\xi) \\right\\|_{L^2({\\bf R}^d)}", block: false)#text(" was only established in the notes for ")#mi("f \\in W^{k,2}({\\bf R}^d)")#text(". To complete the proof that ")#mi("W^{k,2}({\\bf R}^d) = H^k({\\bf R}^d)")#text(", one must also verify the equivalence when ")#mi("f \\in H^k({\\bf R}^d)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-472596")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2016")])]

#text("The Gagliardo-Nirenberg-Sobolev inequality (")#link("https://en.wikipedia.org/wiki/Sobolev_inequality#Gagliardo.E2.80.93Nirenberg.E2.80.93Sobolev_inequality")[#text("https://en.wikipedia.org/wiki/Sobolev_inequality#Gagliardo.E2.80.93Nirenberg.E2.80.93Sobolev_inequality")]#text(") gives an embedding ")#mi("W^{1,p}({\\bf R}^d)\\subset L^q({\\bf R}^d)")#text("when ")#mi("q")#text(" is the Sobolev conjugate of ")#mi("p")#text(". This inequality can be proved using Hölder repeatedly. Can Theorem 3 be directly implied by this inequality?")

#emph[#text("[Yes – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-472634")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("I can see that the GNS inequality implies the case where ")#mi("\\frac{d}{p}-1=\\frac{d}{q}")#text(". Why does it also imply the case where ")#mi("q")#text(" is such that ")#mi("\\frac{d}{p}-1<\\frac{d}{q}\\leq\\frac{d}{p}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-472635")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("In that case one needs the ")#link("https://en.wikipedia.org/wiki/Gagliardo%E2%80%93Nirenberg_interpolation_inequality")[#text("more general form")]#text(" of the Gagliardo-Nirenberg inequality.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d917812f5796c5359165eed13228ec594d368660a0f871b6e09f773a1d0e394-b26f24e7973fb9f6b771bda2fc8046cdf6a8747d24257fb2364c7d50aa849861.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniele Gerosa")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-472709")[#strong[#text("Daniele Gerosa")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2016")])]

#text("Dear Professor Tao,")#linebreak()#text(" in “Caratterizzazioni delle tracce sulla frontiera relative ad alcuni classi di funzioni in $n$ variabili” E. Gagliardo says that the problem of characterizing functions defined on the boundary of a suitable domain $\\Omega$ which are traces of functions in Sobolev spaces was solved, in different ways, just for $p=2$ (e.g. N. Aronszajn, “Boundary values of functions with finite Dirichlet integral” or V. M. Babich & L. N. Slobodetskij, “On boundedness of Dirichlet integrals” (in russian)). Do you know any reference in which that case is treated and proved? The two I quoted between brakets are for me scarce, even in/from the library of my university. Basically, for an “historical purpose”, I’m looking for the proof(s) of the Trace Theorem for Sobolev Spaces ( ")#link("https://en.wikipedia.org/wiki/Sobolev_space#Traces")[#text("https://en.wikipedia.org/wiki/Sobolev_space#Traces")]#text(" ) in the specific case of $p=2$; I think it relies on Fourier Transforms Theory")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-472872")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2016")])]

#text("In exercise 36, in the LHS of the definition of the symbol ")#mi("l")#text(", it seems that ")#mi("L")#text(" should be ")#mi("l")#text(". Also, ")#mi("l(\\xi)")#text(" in the LHS of the next displayed inequality can be complex, so perhaps it should be replaced by its absolute value.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-473342")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2016")])]

#text("This might be a dumb question but I don’t quite get it.")

#text("Is the norm")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\| f \\right\\|_{C^{k,\\alpha}({\\bf R}^d)} := \\sum_{j=0}^k \\left\\| \\nabla^j f \\right\\|_{C^{0,\\alpha}({\\bf R}^d)}", block: false)#linebreak()#text(" equivalent to")#linebreak()#text(" ")#tao-math("\\displaystyle \\left\\| f \\right\\|_{C^{k,\\alpha}({\\bf R}^d)} := \\sum_{j=0}^{k-1} \\left\\| \\nabla^j f \\right\\|_{C^{0,0}({\\bf R}^d)}+\\left\\| \\nabla^k f \\right\\|_{C^{0,\\alpha}({\\bf R}^d)}", block: false)#text("?")

#emph[#text("[Yes. Try the ")#mi("k=1")#text(" case first, using the fundamental theorem of calculus to estimate differences such as ")#tao-math("\\left|f(x)-f(y)\\right|", block: false)#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-473346")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2016")])]

#text("In lemma 2, can the proof be used almost without modification to show that ")#mi("C^\\infty(U)\\cap W^{k,p}(U)")#text(" is dense in ")#mi("W^{k,p}(U)")#text(" when ")#mi("U")#text(" is a nonempty bounded open subset of ")#mi("\\mathbb{R}^d")#text("?")

#text("—-")#linebreak()#text(" I ask this question since I saw in Evans PDE book proves the density of ")#mi("C^\\infty(U)\\cap W^{k,p}(U)")#text(" in ")#mi("W^{k,p}(U)")#text(" for ")#mi("U")#text(" being bounded in a very complicated way. He first established the approximation in ")#mi("W^{k,p}_{loc}(U)")#text(" and then uses the partition of unity to put things together.")

#text("However, in Lemma 2, the method seems much more straightforward: all one needs to do is just do the convolution with the standard mollifier on the whole domain ")#mi("U")#text(". No problem on the boundary since ")#mi("W^{k,p}(U)\\subset L^p(U)\\subset L^1(U)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-473352")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2016")])]

#text("Convolution with a mollifier has to be done with care when working on a domain ")#mi("U")#text(", since the convolution may end up not being supported in ")#mi("U")#text(" (also, one has to somehow extend a function on ")#mi("U")#text(" to a function on ")#mi("{\\bf R}^d")#text(" before the convolution becomes well defined, and such an extension might not continue to lie in ")#mi("W^{k,p}")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dbee4f32fa7a73b931d4b23d5ee24b6ee3764f97a863ca844ccc2a1f3c47611-ed04cf2ff47a5f5197c5a95fb9b597703446c47d43272c7ec37edcf5b2071a8e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karim")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-473691")[#strong[#text("Karim")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2016")])]

#text("Dear professor Tao,")#linebreak()#text(" I have a question that is not very related to the aformentioned basic Sobolev chapter. But instead, it still related to Sobolev spaces framework which is the following:")#linebreak()#text(" Let is suppose that i have a function ")#mi("u \\in C^2(\\mathbb{R}^+;C^1(\\mathbb{R}^3))")#text(", can i conclude immediately that ")#mi("e^{t A^{1/s}}u\\in C^2(\\mathbb{R}^+;C^1(\\mathbb{R}^3))")#text(", where ")#mi("A=\\sqrt{-\\Delta}")#text(" and ")#mi("s\\in \\mathbb{R}")#text(" (the Gevrey class ")#mi("s")#text(" regularity)??")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-475051")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2016")])]

#text("Dear professor Tao,")#linebreak()#text(" I have a question about Exercise 13.")#linebreak()#text(" For me it seems that there is a counter-example which cannot be approximated by test functions.")#linebreak()#text(" Say alpha=1/2, and f(x)=sqrt{|x|}. Then its “alpha-derivative” at x=0 is 1/2")#linebreak()#text(" but for every smooth function the derivative at 0 exists but must be 0.")#linebreak()#text(" So I think that the Holder norm between f and any test function is at least 1/2 in this case.")#linebreak()#text(" (We can make f compactly supported by replacing f with max{1-f,0})")

#text("I tried to prove Exercise 13 but I don`t see how being compactly supported is used.")#linebreak()#text(" Could I get some hints?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-475066")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2016")])]

#text("Oops, you are right, the exercise as formulated is not correct. I have revised the exercise accordingly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6dce1a47a089f356f120eed3b44bc228afc125be44fb37d616ef734970a0d1c3-a289d6701769c5550e4ad217017fa72e552746150eaadd509b3daadc27f26637.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wang Cong")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-514751")[#strong[#text("Wang Cong")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2019")])]

#text("Dear professor Tao,")#linebreak()#text(" excuse me， I want to ask you that, is C^\\infty_0 dense in D^{1,2}(\\Omega)? where \\Omega is bounded, D^{1,2}(\\Omega)=\\{u\\in L^{2^*}(\\Omgea),u\\inL^2{\\Omega} . thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-514805")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2019")])]

#text("Not when ")#mi("\\Omega")#text(" has a non-trivial boundary, because the Sobolev trace theorem provides an obstruction. (Assuming that the boundary is sufficiently nice, of course.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-475219")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2016")])]

#text("Dear professor Tao,")#linebreak()#text(" About Exercise (iii) of the Schauder estimate I am struggling to show LHS=RHS with the Lebesgue dominated convergence theorem but I couldn`t find an appropriate dominant function which is integrable. For part (ii) I was able to choose such functions but it also was not pretty. So I doubt that the theorem is the right key but I have nothing else. If I can get some directions they will be very helpful.")

#text("I also have a difficulty in showing that RHS is alpha-continuous. I mainly used the inequality")

#tao-math("\\left|f(z-y)-f(z)-(f(x-y)-f(x))\\right| \\leq 2\\left|\\left|f\\right|\\right|_{0,\\alpha}\\min(\\left|y\\right|^{\\alpha},\\left|z-x\\right|^{\\alpha})", block: false)

#text("Plugging it into the difference")

#tao-math("\\int_{\\left|y\\right|\\geq \\varepsilon } [\\frac{3y_{i}y_{j}}{\\left|y\\right|^5}-\\frac{\\delta _{ij}}{\\left|y\\right|^3}][f(z-y)-f(z)-(f(x-y)-f(x))]dy", block: false)

#text("and diving the integral region ")#tao-math("M\\geq \\left|y\\right|\\geq \\left|z-x\\right|", block: false)#text(" into ")#tao-math("\\left|y\\right|\\geq \\varepsilon", block: false)#text(" and ")#tao-math("\\left|z-x\\right| \\geq \\left|y\\right|\\geq \\varepsilon", block: false)#text(" (M a large constant) and using the above inequality according the two intervals, I got the upper bound")

#tao-math("C\\left|\\left|f\\right|\\right|_{0,\\alpha }(\\left|z-x\\right|^{\\alpha}+\\log \\frac{M}{\\left|z-x\\right|} \\left|z-x\\right|^{\\alpha})", block: false)

#text("Is there a smarter way to get the desired result? Or, am I missing some essential points?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-475233")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2016")])]

#text("I doubt there is an easy way to establish (iii) purely through the dominated convergence theorem. If f(x) vanishes, then one can split the Newton quotients converging to the LHS into two terms, a “global part” one of which will converge to the RHS by dominated convergence, and a “local part” which one can show to be small using the Holder continuity of f and the vanishing of f(x). One then has to treat the complementary case when f is constant near x by a different argument involving explicit calculation of the local portion of the integral.")

#text("For the Holder continuity, one should be exploiting the regularity of the kernel ")#tao-math("3 y_i y_j / \\left|y\\right|^5 - \\delta_{ij} / \\left|y\\right|^3", block: false)#text(" rather than of ")#mi("f")#text(" to handle the global part, since it is the smoother of the two factors.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-476346")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2017")])]

#text("Dear professor Tao,")#linebreak()#text(" In Exercise 24 I guess the space ")#mi("C^{k+1}(\\mathbb{R}^{d})")#text(" should be revised to ")#mi("C^{k}_{0}(\\mathbb{R}^{d})")#text(", the space of ")#mi("C^{k}")#text(" functions whose all j`th gradients go to zero as away from the origin, for the constant function 1 cannot be approximated by compactly supported functions in the uniform norm.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-477068")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2017")])]

#text("Dear prof. Tao,")#linebreak()#text(" I am trying to prove the Sobolev embedding fails when (p, q)=(d, infinity), d>1 (Exercise 28). As suggested I tried with ")#mi("f(x)=\\sum_{n=N}^{M} a_{n}\\phi (2^{n}x)")#text(", a_n to be determined later for the purpose, but ")#tao-math("\\left\\| \\bigtriangledown f \\right\\|_{L^{d}(\\mathbb{R}^{d})}", block: false)#text(" is equivalent to ")#tao-math("(\\sum_{n=N}^{M}\\left|a_{n}\\right|^{d})^{1/d}", block: false)#text(", which is greater than ")#tao-math("\\sup_{N\\leq n\\leq M}\\left|a_{n}\\right|", block: false)#text(". So this example seems to fail (unless I made a mistake).")#linebreak()#text(" I gave another shot with the function ")#tao-math("f(x)=\\sum_{n=N}^{M}e^{-n\\left|x\\right|^2}", block: false)#text(" to make the infinity norm large, but the result was the same.")#linebreak()#text(" Could you give me some directions?")

#emph[#text("[You have to use constructive interference between the ")#mi("a_n \\phi(2^n x)")#text(", say at the origin ")#mi("x=0")#text(", to make the ")#mi("L^\\infty")#text(" norm of ")#mi("f")#text(" large. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-477680")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2017")])]

#text("In Exercise regarding L^p Holder spaces, I am stuck in (i) to show ")#mi("\\Lambda _{\\alpha +\\epsilon }^{2}(\\mathbb{R}^d)\\subseteq H^{\\alpha }(\\mathbb{R}^d)")#text(". For the other inclusion it was easy to use the inequality ")#tao-math("\\left|e^{2\\pi i\\xi \\cdot x}-1\\right|\\leq \\left|\\xi \\right|^{\\alpha }\\left|x\\right|^{\\alpha }", block: false)#text(" up to a multiplicative constant depending only on alpha and dimension, but I don`t see how to approach the reverse direction with epsilon. I expected some inequalities like ")#tao-math("\\left|\\sin x\\right|\\geq \\left|x\\right|^{\\alpha}", block: false)#text(", again up to a constant, but none of them are true or inadequate.")#linebreak()#text(" Can I get a hint or a useful inequality about this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-477713")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2017")])]

#text("One has lower bounds of the form ")#tao-math("\\left|\\sin x\\right| \\geq \\left|x\\right| / 2", block: false)#text(" (say) for small ")#mi("x")#text(", say ")#tao-math("\\left|x\\right| \\leq 0.01", block: false)#text(". This is enough to control the Fourier transform of the function on dyadic shells such as ")#tao-math("\\{ \\xi: N \\leq \\left|\\xi\\right| \\leq 2N \\}", block: false)#text(" by using the H\\”older property for some well chosen set of shifts depending on ")#mi("N")#text(", and then one can sum in ")#mi("N")#text(" to control the Sobolev norm. (The small frequencies in which ")#tao-math("\\left|\\xi\\right| \\leq 1", block: false)#text(" can be treated using the other component of the H\\”older norm.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81b0d38a95f82c98e826918c93bfc1e19b96f6df64b3fa0b294297822585dac8-1949caf0cd5264b8c0062b82a1446ef135e465e234e64a2ed9f3d0b0bd3e842e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-477747")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2017")])]

#text("Dear Professor Tao,")#linebreak()#text(" Can we define the Sobolev norm of a function f on a bounded, open domain by taking the inf of the sobolev norm of functions which restriction to the domain is f ?")

#emph[#text("[This does define a norm, but not necessarily the norm one wants. See the discussion after Exercise 13. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-478171")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2017")])]

#text("Dear professor Tao,")#linebreak()#text(" In the Exercise of Sobolev trace theorem I proved it by Cauchy-Schwartz inequality, namely,")

#tao-math("\\left| \\int_{\\mathbb{R}}\\hat{f}(\\xi ,\\eta )d\\eta \\right|^{2}\\leq \\left ( \\int_{\\mathbb{R}}(+\\left|\\eta\\right|)^{2s}\\left|\\hat{f}(\\xi ,\\eta )\\right|^{2}d\\eta \\right )\\left ( \\int_{\\mathbb{R}}(+\\left|\\eta\\right|)^{-2s}d\\eta \\right )", block: false)

#text("but I couldn`t see how the schur`s lemma is used.")

#text("Also that multiplication by ")#mi("g\\in C^{\\infty }(\\mathbb{R}^{d})")#text(" is continuous, the next Exercise, was also hard. I think I don`t understand the same thing.")

#text("Can I get some hint for this?")

#emph[#text("[You’re right, Schur’s test is difficult to use for the second exercise; I’ve modified the hints accordingly. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c93b16be9b793a5ff0849b84e40594a3d7f47d94c2216734bc177032adde3b8-5ff89c1cb36113ec7f71f309168fb424028b9397f57d157b5a3ccb40cad52d66.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Salim Benarous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-479114")[#strong[#text("Salim Benarous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2017")])]

#text("Dear T.Tao ,")#linebreak()#text(" What about homogeneous Sobolev spaces , relations(in terms of estimates) between homogeneous and classical and why thoses spaces are often used in PDE?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-479747")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2017")])]

#text("How should one define the Sobolev space ")#mi("H^1")#text(" for ")#mi("(0,1)\\times{}T")#text("? (One can define ")#mi("H^1((0,1))")#text(" and ")#mi("H^1({\\bf T})")#text(". How can one put them together?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-489548")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2017")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Let ")#mi("\\Omega")#text(" be a bounded domain of ")#mi("{\\bf R}^d")#text(" with Lipschitz boundary. If ")#mi("m>\\frac{d}{2}")#text(", such that ")#mi("H^m(\\Omega)")#text(" is continuously embedded in ")#mi("L^\\infty(\\Omega)")#text(". Is ")#mi("L^1(\\Omega)")#text(" continuously embedded in the dual space of ")#mi("H^m(\\Omega)")#text("? Thank you very much.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-489569")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2017")])]

#text("Yes, the only thing that needs checking is that the obvious map from ")#mi("L^1")#text(" into this dual is injective, which amounts to showing that any functional arising from a nontrivial ")#mi("L^1")#text(" function cannot vanish on all of ")#mi("H^m")#text(", which I think can be done by using for instance the Lebesgue differentiation theorem and smooth approximations to the identity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jane")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-2/#comment-489597")[#strong[#text("Jane")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2017")])]

#text("Thank you very much!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of abc")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-38490")[#strong[#text("abc")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2009")])]

#text("Can the statement that H^{1/2}-functions don’t have “jumps” (I don’t know what this means for an L^p-function) be made precise?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-38496")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2009")])]

#text("Dear abc,")

#text("Well, it is true that no piecewise smooth function with a jump discontinuity can lie in ")#mi("H^{1/2}({\\Bbb R})")#text("; the Fourier transform will decay like ")#tao-math("1/\\left|\\xi\\right|", block: false)#text(", causing a logarithmic divergence in the ")#mi("H^{1/2}")#text(" norm. (This fact is loosely related to the Gibbs phenomenon, though that is more about the failure of absolute integrability of the Fourier transform, rather than the weighted square-integrability.)")

#text("Also, it is known that ")#mi("H^{1/2}")#text(" functions, while possibly being unbounded or discontinuous, must at least lie in VMO, the space of functions with vanishing mean oscillation; functions with jump discontinuities do not lie in this class.")

#text("Finally, there are a number of results known that are consistent with the philosophy of ")#mi("H^{1/2}")#text(" having no jump discontinuities, for instance it is known (by ")#strike[#text("Brezis and Nirenberg, I think")]#text(" Boutet de Monvel and Gabber) that there is a well-defined notion of a degree (i.e. winding number) of an ")#mi("H^{1/2}")#text(" map from the unit circle ")#mi("S^1")#text(" to itself, despite the fact that such functions can be arbitrarily oscillatory (and in particular, discontinuous).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093f42428c5178c855bd751694e5f1c74335a14073b5c2669c9b8c102cf7ceba-08750b13ea407ac9e3276cb67a5579f080a488735539017981d5b858e11ae4ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-51911")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2011")])]

#text("Dear Professor Terrence,")#linebreak()#text(" do you know an easy example of a function u in the space H^1/2(0,1) but not in the H^1(0,1) space?")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-64386")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2011")])]

#text("A triangle in (0,1).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-315542")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2014")])]

#text("uh-huh? the Fourier transform of a triangle decays like ")#tao-math("\\left|\\xi\\right|^{-2}", block: false)#text(", so if we multiply it by ")#tao-math("\\left|\\xi\\right|", block: false)#text(" we still have ")#tao-math("\\left|\\xi\\right|^{-1}", block: false)#text(" decay, which is square integrable.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-38498")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2009")])]

#text("Dear Professor Tao:")#linebreak()#text(" The entire blog entry instead of the preview is showing on the home page. ")#emph[#text("[Corrected, thanks – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lutfu")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-38501")[#strong[#text("lutfu")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2009")])]

#text("Dear Prof. Tao,")

#text("In exercise 29, in the definition of inner product you write ”…..is defined via the Fourier transform as …..”")#linebreak()#text(" on the right hand side do you mean Fourier transform of f and g or f,g themselves?")

#text("thanks")#linebreak()#text(" ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-38502")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2009")])]

#text("Thanks a lot for these notes! I find the insights, exercises and examples to be invaluable to play with.")

#text("I think some hats also missing in the definition of Hs-inner product just after Exercise 28.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-38503")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2009")])]

#text("Remark 4 (at the end) has a “yellow” formula.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polam")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-38508")[#strong[#text("Polam")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2009")])]

#text("In Exercise 21, do you just mean that the Hardy-Littlewood-Sobolev theorem on fractional integration fails when p = 1? The Sobolev embedding theorem should be true for p = 1, i.e. $W^{1,1}$ should embed into $L^{d/d-1}$ in d dimensions for all d, and in fact this is equivalent to the isoperimetric inequality.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-38509")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2009")])]

#text("Oh, good point! I had forgotten all about this connection. I’ve corrected the exercise and added some relevant material about the endpoint Sobolev inequality and the isoperimetric inequality.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lutfu")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-38511")[#strong[#text("lutfu")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2009")])]

#text("Dear Prof. Tao,")

#text("in the section 2. classical sobolev spaces, in example 2, you say ” cantor function despite having classical derivative a.e zero, the weak derivative is cantor measure….”")

#text("I did not understand this sentence. if a function has classical derivative, isn’t its weak derivative the same?")

#text("Could you please clarify this point?")

#text("and after exercise 12, you define Holder norm and in the second sup of the norm definition, should it be k or j?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-38513")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2009")])]

#text("Dear Lutfu,")

#text("The classical and weak derivatives only agree for absolutely continuous functions (in the one dimensional setting), because one needs the fundamental theorem of calculus to apply to equate the two.")

#text("I suppose I should use k instead of j here in order to retain the claim of being the “maximal” concept of a Holder space, though for any reasonable domain the two notions would be equivalent.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-472151")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2016")])]

#text("Do you have a hint about why “The classical and weak derivatives agree for absolutely continuous functions”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-472152")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2016")])]

#text("For “agree”, do you mean “agree almost everywhere”?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ad63f0ef14cdf560d3b02c2db44152ed55cf50e73600e0c8e2868b9b2c24148-84ff88e81e3baf1f4aa5c443a08aadfdc0f5187570199535cfe3fdf99496e773.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bk")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-38718")[#strong[#text("bk")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2009")])]

#text("Dear Terry,")#linebreak()#text(" 1. are you sure you want to this notation:")

#text("” and for any constant-coefficient partial differential operator")#linebreak()#text(" ")#mi("\\displaystyle L = \\sum_{i_1,\\ldots,i_d \\geq 0: i_1+\\ldots+i_d \\leq m} c_{i_1,\\ldots,i_d} \\frac{\\partial^m}{\\partial_{x_{i_1}} \\ldots \\partial_{x_{i_d}}}")#text("”")

#text("instead of")

#tao-math("\\displaystyle L = \\sum_{i_1,\\ldots,i_d \\geq 0: i_1+\\ldots+i_d \\leq m} c_{i_1,\\ldots,i_d} \\frac{\\partial^{\\left|i_1+\\cdots+i_d\\right|}}{\\partial_{x_1^{i_1}} \\ldots \\partial_{x_d^{i_d}}}", block: false)#text("”")

#text("2. “For instance, the restriction of ")#tao-math("{\\left|x\\right|}", block: false)#text(" to ")#mi("{{\\mathbb R} \\backslash \\{0\\}}")#text(" lies in ")#mi("{C^{1,0}({\\mathbb R} \\backslash \\{0\\})}")#text(", but is not in…”")

#text("do you focus on the origin, or do you really want to say")

#tao-math("\\left|x\\right|\\in {C^{1,0}(\\{\\mathbb R\\})}", block: false)

#emph[#text("[Corrected, thanks – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ad63f0ef14cdf560d3b02c2db44152ed55cf50e73600e0c8e2868b9b2c24148-84ff88e81e3baf1f4aa5c443a08aadfdc0f5187570199535cfe3fdf99496e773.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bk")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-38720")[#strong[#text("bk")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2009")])]

#text("Dear Terry,")#linebreak()#text(" You were in a hurry.")#linebreak()#text(" 1. also take a look at the ‘denominator’ of the operator")#linebreak()#text(" 2. according to your definition if |x| in C^{1,0}, it should be bounded, right?")

#text("I don’t enjoy being so wordy but I like your stuff so much that I want them to be typoless :).")

#emph[#text("[Corrected again – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-38731")[#strong[#text("future topics « 逝去日子")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2009")]

#text("[…] 五月 12, 2009 作者为 曾经话说要如何 1. Schauder estimate/Rellich-Kondrakov type embedding theorem for Holder space—terry’s. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antonio")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-38974")[#strong[#text("Antonio")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2009")])]

#text("Dear Terry,")#linebreak()#text(" there is a “formula does not parse” yellow message in the third paragraph (just after the list of examples).")

#text("Thanks for your work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-39008")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2009")])]

#text("Dear Prof Tao,")

#text("Are sobolev embedding theorems also true for any open set?(bounded or unbounded)")

#text("And when we say fundamental solution, do we mean that a tempered distribution which satisfy the equation?(not just distribution, tempered distribution? right?)")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-39017")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2009")])]

#text("Dear Student,")

#text("The situation with the Sobolev embedding theorems on domains is somewhat subtle. For one thing, one has to decide upon exactly how one is to define the Sobolev spaces and norms (cf. the discussion after Exercise 12). If these spaces and norms are defined on domains as restrictions of their ")#mi("{\\Bbb R}^n")#text(" counterparts (or as the closure of smooth, compactly supported functions), then the embedding theorem on domains is a tautological consequence of that for ")#mi("{\\Bbb R}^n")#text("; but if they are defined differently then one has to take more care. Generally speaking, though, for sufficiently “nice” domains (e.g. bounded, with smooth boundary) the embedding theorems continue to hold no matter how one defines the Sobolev spaces and norms, but care would have to be taken if the domain starts developing very thin necks or has a fractal boundary. There is a close relationship between Sobolev inequalities and isoperimetric inequalities (see Exercise 22), so as a rule of thumb, any domain for which the isoperimetric inequality continues to hold, will also have a good Sobolev inequality. (Note that thin necks and fractal boundaries can allow a small boundary to enclose a large volume, thus leading to possible degradation of the isoperimetric inequality and hence Sobolev inequalities.)")

#text("Fundamental solutions can be either tempered or non-tempered, though in the latter case they can only be used to solve PDE with test function data (rather than PDE with Schwartz data).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-39018")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2009")])]

#text("Thank you very much Prof. Tao,")

#text("in exc 16 hint, I think there should be x in front of the integral.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-39019")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2009")])]

#text("excuse me, not for this post. exc 16 of Distributions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lutfu")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-39466")[#strong[#text("lutfu")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2009")])]

#text("Dear Prof. Tao")

#text("the conditions for Exc 24 is given different in some other sources.")

#text("for example like this:")

#mi("1 \\leq p < q < \\infty")#text(" and ")#mi("k-n/p \\geq l-n/q.")

#text("are both equivalent?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-39470")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2009")])]

#text("Up to endpoints, yes. The ")#mi("L^1")#text(" and ")#mi("L^\\infty")#text(" endpoints are often treated differently (and here it becomes important whether k, l are integers or not); I am including the ")#mi("L^\\infty")#text(" endpoints but not the ")#mi("L^1")#text(" endpoints in my formulation, but the reverse is being stated in your example.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-39667")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2009")])]

#text("Dear Professor Tao:")

#text("I have a question about trying to extend Poincare’s inequality (or Sobolev Embedding) to negative derivative. In other words, if one has D^{\\alpha-1}f where D is a differentiation, \\alpha \\in (0,1), and f some smooth function, how can we estimate such term? If one could extend Poincare’s inequality to negative derivative, then I suppose this norm can be bounded by that of f, analogously to how the norm of f can be bounded by the norm of its gradient in any Lp norm for p even 1 or infinity, but I do not know if this is true.")

#text("I also looked at Riesz potential from Stein’s book looking for answer to this question, but such inequality seems to be true only in Lp norm but not when p=1 or infinity.")

#text("Is there any way to estimate the negative derivative of f in sup norm? Can we at least say that the sup norm of negative derivative of f is bounded by the that of gradient of f?")

#text("Any share of thoughts would be appreciated.")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-39693")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2009")])]

#text("Dear Student,")

#text("I am not exactly sure what kind of inequalities you are looking for, but generally speaking the Hardy-Littlewood-Sobolev fractional integration inequality provides all the relevant estimates, except possibly at endpoints ")#mi("p=1,\\infty")#text(", for which the fractional integration estimates tend to fail.")

#text("Note also that in any of these inequalities, the right-hand side norm needs to have at least as many derivatives as the left-hand side, thus for instance one can hope to control a norm of f by a norm of ")#mi("\\nabla f")#text(", but not conversely. This can be seen by considering high-frequency test inputs for f, such as ")#mi("f(x) = \\phi(x) \\sin(Nx)")#text(" (in one dimension) where ")#mi("\\phi")#text(" is a bump function and N is a large frequency.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vedadi")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-39791")[#strong[#text("vedadi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2009")])]

#text("Dear Prof. Tao,")

#text("is the following definition right?")

#text("for ")#mi("0 < \\alpha \\leq 1,")#text(" and ")#mi("k \\geq 1 ,")#text(" we say that a function")#linebreak()#text(" ")#mi("f")#text(" is in ")#mi("C^{k, \\alpha}(\\mathbf{R}^d)")#text(" if")

#text("1) ")#mi("f")#text(" is continuous and bounded")

#text("2)all partial derivatives upto and including order k are continuous and bounded")

#text("3) ")#mi("k th")#text(" derivative is Holder continuous (just kth order derivatives)")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-39795")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2009")])]

#text("Dear Vedadi,")

#text("Yes, this will give an equivalent definition of the Holder spaces. (If a higher derivative is bounded, then the lower derivatives are automatically Lipschitz continuous and thus Holder continuous also.) In fact there are quite a few useful equivalent formulations of both the Holder norms and the Sobolev norms.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd01493a45d8df0d68efcb16d353b9582bf2c15b71dc7737ac31005eeadadef8-2a0d79b2d108fc1cd0fa6f7a62fbed17c45642966aae38d830126e1cbdcb88b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sjt")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-40048")[#strong[#text("sjt")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2009")])]

#text("In the first sentence you refer to some previous notes containing a discussion of function space norms. Are those notes available? If so, where?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-40049")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2009")])]

#text("Dear sjt,")

#text("I was referring to my 245B lecture notes,")

#link("https://terrytao.wordpress.com/category/teaching/245b-real-analysis/")[#text("https://terrytao.wordpress.com/category/teaching/245b-real-analysis/")]

#text("with Lectures 3,5,6,9 being perhaps the most relevant.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-41095")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2009")])]

#text("Dear Professor Tao:")

#text("I would like to know if the change of sign upon integration by parts still holds when it is fractional integration by parts. In other words, instead of")

#text("D^{1}, where D is a differentiation operator,")

#text("with")

#text("D^{\\alpha} for some \\alpha \\in (0, 1)")

#text("and for simplicity assuming f and g are compactly supported smooth functions,")

#text("do we have")

#text("– \\int f D^{\\alpha}g = \\int(D^{\\alpha}f)g ?")

#text("Related to this question,")

#text("do we have the usual product rule for fractional derivative?")

#text("I.e. do we have")

#text("D^{\\alpha}(fg) = (D^{\\alpha}f)g + f(D^{\\alpha}g)?")

#text("Having read a little about Riesz potential, I have a feeling it is not so simple. But I could not definitively figure this out.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-41097")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2009")])]

#text("Fractional derivatives should be more accurately denoted ")#tao-math("\\left|D\\right|^\\alpha", block: false)#text(" rather than ")#mi("D^\\alpha")#text("; their Fourier symbol is ")#tao-math("\\left|\\xi\\right|^\\alpha", block: false)#text(", whereas the symbol for the ordinary derivative D is ")#mi("i \\xi")#text(" (give or take a factor of ")#mi("2\\pi")#text(", depending on one’s Fourier conventions). In particular, these operators are self-adjoint (as is any other Fourier multiplier with real symbol).")

#text("The Leibnitz rule for fractional derivatives only holds approximately (up to lower order terms); this “fractional Leibnitz rule” is one of the foundational results of paradifferential calculus. Taylor’s book “Tools for PDE” is a good reference here; see also my lecture notes at")

#link("http://www.math.ucla.edu/~tao/247b.1.07w/")[#text("http://www.math.ucla.edu/~tao/247b.1.07w/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-41101")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2009")])]

#text("Dear Professor Tao:")

#text("Thank you very much for your reply as well as suggested readings.")

#text("Best regards,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Studnet")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-41625")[#strong[#text("Studnet")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2009")])]

#text("Dear Professor Tao,")#linebreak()#text(" Is it true that $W^{k,2}\\times W^{-k,2}\\rightarrow L^1$ through the product map?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-41937")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2009")])]

#text("No; a product, in general, cannot become smoother than its factors (in sharp contrast to convolution), and since one of the factors has a negative regularity, the product will have negative regularity also. For a more concrete example, consider the product of ")#mi("\\psi(x)")#text(" and ")#mi("\\cos(nx) \\psi(x)")#text(" in one dimension, where ")#mi("\\psi")#text(" is a bump function. The first factor is bounded in ")#mi("W^{k,2}")#text(", while the second factor goes to zero in ")#mi("W^{-k,2}")#text(" norm as ")#mi("n \\to \\infty")#text(". The product, however, does not go to zero in ")#mi("L^1")#text(" norm, and so the product map is not continuous in these topologies. (One can use the closed graph theorem to then show that the product map will not stay inside ")#mi("L^1")#text(", if one interprets products in the distributional sense.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-41932")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2009")])]

#text("Dear Professor Tao:")

#text("Is there a connection of ")#link("http://en.wikipedia.org/wiki/Fractional_calculus")[#text("http://en.wikipedia.org/wiki/Fractional_calculus")]#text(" to Sobolev spaces with non-integer-regularity? E.g., is there an easy solution to finding the largest s so that ")#mi("x^\\alpha \\in H^s")#text(" for a given ")#mi("\\alpha<1")#text("?")

#text("This is a great resource, many thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-41934")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2009")])]

#text("Yes; for instance, a function ")#mi("f")#text(" lies in ")#mi("H^s({\\Bbb R})")#text(" for some ")#mi("s \\geq 0")#text(" if and only if ")#mi("f")#text(" and ")#tao-math("\\left|D\\right|^s f", block: false)#text(" both lie in ")#mi("L^2({\\Bbb R})")#text(", where ")#tao-math("\\left|D\\right|^s f", block: false)#text(" is the ")#mi("s^{th}")#text(" fractional derivative of ")#mi("f")#text(". There are similar statements for other ")#mi("L^p")#text("-based Sobolev spaces (though there are technical issues at the endpoints ")#mi("p=1")#text(" and ")#mi("p=\\infty")#text(").")

#text("The functions ")#tao-math("\\left|x\\right|^\\alpha", block: false)#text(" are not globally in ")#mi("H^s({\\Bbb R})")#text(" for any ")#mi("s")#text(", but one can show by various means (e.g. Fourier transform, Littlewood-Paley type decomposition, or the various potential theory characterisations of the Sobolev norms) that they lie locally in ")#mi("H^s")#text(" for ")#mi("s \\geq 0")#text(" whenever ")#mi("\\alpha - s > -1/2")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-41943")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2009")])]

#text("I mean, is it correct that the main term ")#tao-math("\\left|D\\right|^s \\left|x\\right|^\\alpha = C \\left|x\\right|^{\\alpha-s}", block: false)#text(" using fractional calculus and this is simply why ")#tao-math("\\left|x\\right|^\\alpha \\in H^s(0,1)", block: false)#text(" for $\\alpha-s>-1/2$ around x=0, since $ |x|^{\\alpha-s}\\in L_2 (0,1)$ ?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-41944")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2009")])]

#text("Yes; this can be done for instance using the machinery in the preceding lecture notes,")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("245C, Notes 3: Distributions")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-41945")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2009")])]

#text("Dear Professor Tao:")

#text("Let us define function f = the Heaviside step function. Your answer ")#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/#comment-38496")[#text("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/#comment-38496")]#text(" implies that f is not in ")#mi("H^{1/2}(-1.1)")#text(", correct? Is there a direct reference?")

#text("Let’s the fun continue. Is it in ")#mi("H^{s}(-1.1)")#text(" with s<1/2? What is ")#tao-math("\\left|D\\right|^s f", block: false)#text("?")

#text("These are simple questions with very hard to find or figure out answers for non-experts, so your help is extremely appreciated.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-42863")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2009")])]

#text("Dear Prof. Tao,")

#text("In exercise 3, it seems we need to time the function by the height ")#mi("A")#text(". In exercise 16, it seems that ")#mi("N")#text(" is ")#mi("\\xi")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-43089")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2010")])]

#text("Dear Prof. Tao,")

#text("I think the condition in Ex 32 should be ")#mi("\\frac d 2-s \\leq \\frac d q \\leq \\frac d 2")#text(".")

#text("I got stuck on prove the first step in your hint. I tried to use the Fourier inversion formula and the Cauchy-Schwartz inequalitie as in Ex 31, but this seems not to work. Could you give a little detailed hint.")

#text("Thanks in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-43097")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2010")])]

#text("Thanks for the correction!")

#text("For Exercise 32, one uses the Hardy-Littlewood-Sobolev inequality (Corollary 7 from Notes 1) rather than Cauchy-Schwarz. I’ll put in a link to that corollary in the notes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anaon")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-43843")[#strong[#text("anaon")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2010")])]

#text("The product rule for weak derivatives could be proven with the help of lemma 3 (i.e. C^\\infty_c is dense in W^{k,p}) but here the proof uses the product rule :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64d52e131a52566ba08c1f0c5ed08ea96aa80db793bf3bd174241e920834c2f0-ab8d9400b66afacd94302efcc584c82e90c1bd63855c608b202efc2f27c82419.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Simion")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-44888")[#strong[#text("Simion")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Perhaps I’m terribly wrong, but how can in Exercise 13 compactly supported functions be dense in ")#mi("C^{k,\\alpha}(\\mathbb{R}^n)")#text(", given that for a function in such a space, there’s no decay requirement? For example, a constant function is in ")#mi("C^{k,\\alpha}(\\mathbb{R}^n)")#text(", but can’t be approximated by a compactly supported one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-44891")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2010")])]

#text("Oops, you’re right. I’ve replaced ")#mi("C^{k,\\alpha}")#text(" with ")#mi("C^{k,\\alpha}_0")#text(" in the exercise.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-470189")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2016")])]

#text("I can only tell from other resources that ")#mi("C_0^{k,\\alpha}")#text(" is defined as the closure of ")#mi("C_c^\\infty")#text(" in ")#mi("C^{k,\\alpha}")#text(". I have also checked the index section of your book but I cannot find a definition. How do you define ")#mi("C_0^{k,\\alpha}")#text(" in this note?")

#emph[#text("[See the paragraph immediately preceding Exercise 13. -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wrf")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-45110")[#strong[#text("wrf")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I have thought about a problem about the gagliaedo-nirenberg interpolation inequation. I want to know if it holds for the frational")#linebreak()#text(" derivative.")#linebreak()#text(" a chinese student")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b19e0bc02c988b936748c3bf3a92d39ca8cfa8b9a8e259d2df423b75507a485-ddd0eeb60f60d47f461df06b8da6e1294c725883cffcf416fe6b832fc3ae3b9e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xuhmath")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-48040")[#strong[#text("xuhmath")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2010")])]

#text("I think there is a typo on Exercise 16: did you mean “the function ")#mi("A \\phi(x/R) \\sin(\\xi \\cdot x)")#text(" has a ")#mi("W^{k,p}(\\mathbb{R}^d)")#text(" norm” rather than “the function ")#mi("\\phi(x/R) \\sin(\\xi x)")#text(" has a ")#mi("W^{k,p}(\\mathbb{R})")#text(" norm” to emphasize the contrast with Exercise 3?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11128e4290fda88162336c609a63a91f90fa88316eff78b1757c67c996c650fa-fcde97ef5627bdc60423b8843e7c57dc4d57eb2cdfdad7ee7f6c20f9f347501a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthony")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-48168")[#strong[#text("anthony")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2010")])]

#text("Dear Prof. Tao,")

#text("it should be Rellich-Kondrashov not Kondrakov. ")#emph[#text("[Corrected, thanks. The exact Romanisation of Kondrachov seems to be somewhat in dispute, but “ch” seems to be slightly more common than “sh” in this case. – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11128e4290fda88162336c609a63a91f90fa88316eff78b1757c67c996c650fa-fcde97ef5627bdc60423b8843e7c57dc4d57eb2cdfdad7ee7f6c20f9f347501a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthony")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-48177")[#strong[#text("anthony")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2010")])]

#text("I’m pretty sure this is because of the influence of the classical book of Adams. As someone who actually speaks Russian I still think that Kondrashov is the correct english Romanisation because it produces the right pronunciation of russian “ш” (like in SHow) whereas “ch” (like in CHeck) corresponds to russian “ч”. The actual russian spelling is “Кондрашов”.")

#text("See ")#link("http://en.wikipedia.org/wiki/Sobolev_inequality")[#text("http://en.wikipedia.org/wiki/Sobolev_inequality")]

#emph[#text("[Thanks for the clarification. I confirmed this with a Russian friend of mine, and corrected the spelling. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c5600e5095124005499bdccdde8b503563525b7e8e306759750b61045610731-b56f225788f19acada7d2c7d8fe7651251a6b90dfa9cda5f993a62ffcc4838e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-49563")[#strong[#text("Abhishek")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2011")])]

#text("Dear Prof. Tao,")

#text("I am wondering if there is any inverse theorem for Sobolev embedding, namely when ")#mi("W^{k,p}")#text(" is embedded in ")#mi("L_{q}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c5600e5095124005499bdccdde8b503563525b7e8e306759750b61045610731-b56f225788f19acada7d2c7d8fe7651251a6b90dfa9cda5f993a62ffcc4838e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-49564")[#strong[#text("Abhishek")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2011")])]

#text("Sorry, I meant when ")#mi("L_{q}")#text(" is embedded in ")#mi("W^{k,p}")#text(". Can something like this be said in high dimensions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-49576")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2011")])]

#text("In general, spaces with lower regularity cannot be embedded into spaces with higher regularity (the computation in Exercise 16 already shows this). I talk a bit about the general embedding relationships between function spaces in")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/")[#text("A type diagram for function spaces")]
]

#text("There is however something called an inverse theorem for Sobolev embedding, but it is a bit different, referring to a classification of those functions f for which the Sobolev inequality is close to equality (roughly speaking, this occurs when f looks like a rescaled bump function). This is inverse theorem important in the theory of concentration compactness; see e.g. Proposition 4.9 of ")#link("http://www.math.ucla.edu/~visan/ClayLectureNotes.pdf")[#text("http://www.math.ucla.edu/~visan/ClayLectureNotes.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-51923")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2011")])]

#text("Just to complement what prof. Tao said; you can of course embed certain subspaces (e.g. with compactly supported Fourier transform) of L^q into e.g. H^k, with the constant blowing up as the subspace gets larger. These are called inverse- or Bernstein-type inequalities, and very useful in approximation theory and numerical analysis. The complementary inequalities are called direct- or Jackson-type estimates, and these concern subspaces e.g. with Fourier transform supported in a complement of a compact set, and the inequality sign is reversed (so compatible with the usual embedding theorems) as compared to the inverse estimates. The difference between direct-type estimates and the usual embedding theorems is that in direct estimates the constant tends to 0 as one removes larger and larger compact sets from the support of the Fourier transform.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-50418")[#strong[#text("Sobolev spaces on manifolds « Secret Blogging Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2011")]

#text("[…] Tao has a very comprehensive blog post on this, so I’ll be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-51931")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2011")])]

#text("Dear Prof. Tao,")

#text("What is known for Sobolev inequality on T^d (d-dimensional torus)? And, what would be a good reference? Also, on Riemannian manifolds?")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-51943")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2011")])]

#text("Emmanuel Hebey has a book on Sobolev spaces on manifolds, and I found that Palais’ seminar notes on the index theorem has many details worked out. But I would say the manifold case is not much different once you figure out how to transfer from local to global by using partitions of unity, and how this is equivalent to defining Sobolev spaces via covariant derivatives for integer indices. This is my quick answer; others will surely have deeper answers than mine.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 1: Lie groups, Lie algebras, and the Baker-Campbell-Hausdorff formula « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-72427")[#strong[#text("254A, Notes 1: Lie groups, Lie algebras, and the Baker-Campbell-Hausdorff formula « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2011")])]

#text("[…] functions, but much stronger than the class of singly continuously differentiable functions. See this previous blog post for more on these sorts of regularity classes. The reason for the terminology in the above […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-116209")[#strong[#text("254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem | t1u")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2011")]

#text("[…] See for instance this blog post for a very brief introduction to Riemannian geometry, and these two previous posts for an introduction to distributions and Sobolev […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-117223")[#strong[#text("254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2011")])]

#text("[…] See for instance this blog post for a very brief introduction to Riemannian geometry, and these two previous posts for an introduction to distributions and Sobolev […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a561d78ca3d116272ad283e2744633273f2174340bb6bbe30ce57024c3240506-354eebb4cab4eb72fd629efe8095c5cd96656d698f082370987583f133d0a508.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seungly Oh")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-123617")[#strong[#text("Seungly Oh")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2012")])]

#text("Concerning Exercise 18, shouldn’t ")#mi("W^{k,\\infty}")#text(" closure of ")#mi("C^{\\infty}_c (\\mathbf{R}^n)")#text(" should be something like ")#mi("C^k_0")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-140830")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2012")])]

#text("In the statement of exercise 3, do you mean to call your frequency scale ")#mi("\\xi")#text(" instead of ")#mi("N")#text("? I don’t see any ")#mi("N")#text(" in the function.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-140848")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2012")])]

#text("Yes, in this example the frequency scale ")#mi("N")#text(" will be ")#tao-math("\\left|\\xi\\right|", block: false)#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-141121")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2012")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I can’t find the definition for ")#mi("C_0({\\bf R}^d)")#text(" either in the note or in the index of your book. Do you mean ")#mi("C_c({\\bf R}^d)")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-141149")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2012")])]

#mi("C_0")#text(" is the closure of ")#mi("C_c")#text(" in the uniform topology, or equivalently the set of continuous functions that vanish at infinity. (It’s introduced in Exercise 1.10.7, but I guess I didn’t add an index entry for it there.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-141125")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2012")])]

#text("This might be a stupid question:")

#text("As the wikipedia said, embedding is a structure-preserving map. What structure is preserved in the “Sovolev embedding”? Is it the structure of normed vector space? Or other “structures”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-141150")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2012")])]

#text("The Sobolev embedding preserves the convergence of sequences (i.e. it is a continuous map) and the vector space structure (i.e. it is linear), but it does not preserve the norm (i.e. it is not an isometric embedding). Note though that the topology of the embedded space is a bit stronger than that of the ambient space; when ")#mi("W^{k,p} \\subset L^q")#text(", there are sequences in ")#mi("W^{k,p}")#text(" that converge in ")#mi("L^q")#text(" norm but not in ")#mi("W^{k,p}")#text(" norm. So, strictly speaking, it doesn’t fully preserve the topological structure (instead, it makes the topology a little weaker upon embedding), but it is still customary to abuse notation slightly and refer to this map as an embedding.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-141593")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2012")])]

#text("Hmm, any hint for finding sequences in ")#mi("W^{k,p}")#text(" that converge in ")#mi("L^q")#text(" norm but not in ")#mi("W^{k,p}")#text(" norm?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d703f698a4fa9a3fc870dc71ed44c8a1ad606a9afeb76142da2460b611b076b6-c7a24c16d5796c6745ebd6015fd217d5bd5dac4bf319ea6d476c85a867c19bf4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of karabasov")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-155708")[#strong[#text("karabasov")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2012")])]

#text("Dear Prof. Tao,")

#text("can you, please, give references about Sobolev product theorems, like one in Exercise 27?")

#text("Thank you very much,")#linebreak()#text(" karabasov")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-155763")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2012")])]

#text("Taylor’s “Tools for PDE” develops the theory of paraproducts, from which Sobolev product theorems can be deduced as corollaries.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc678a306e0fcede9e7a4278338a87e2196f2a96421894c0f85be4d7be3d4572-64e06157cf51471c485ae2338e039f0e1225b8db9c473c9b5813a7239da992cb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hassan jolany")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-162190")[#strong[#text("hassan jolany")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2012")])]

#text("What is the Schauder estimate on the space time Reimannian manifold in parabolic differential equation, ? (I mean on usual Hölder space )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A mathematical formalisation of dimensional analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-211407")[#strong[#text("A mathematical formalisation of dimensional analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2012")])]

#text("[…] In fact, this condition turns out to be sufficient as well as necessary, although this is a non-trivial fact that cannot be proven purely by dimensional analysis; see e.g. these notes. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonCoward")]], [#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/comment-page-1/#comment-222012")[#strong[#text("anonCoward")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2013")])]

#text("I found the notation employed throughout this post to be a departure from the norm. Did you intend to write")

#tao-math("\\left|\\nabla^j f \\right|^2 = \\sum_{i_1,..., i_j = 1,...,d} \\left( \\left( \\frac{\\partial}{\\partial x^{i_1}}\\right) \\cdots \\left(\\frac{\\partial}{\\partial x^{i_j}}\\right) f\\right)^2", block: false)#text(" ?")

#emph[#text("[Corrected, thanks – T.]")]
]
