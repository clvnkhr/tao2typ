// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/04/09/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/
// Converted to Typst by tao2typ: "2026-10-14T10:24:18.735258+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The ergodic theorem and Gowers-Host-Kra seminorms without separability or amenability", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The ergodic theorem and Gowers-Host-Kra seminorms without separability or amenability")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 April 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/04/09/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/")[#text("https://terrytao.wordpress.com/2015/04/09/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://en.wikipedia.org/wiki/Ergodic_theory#Mean_ergodic_theorem")[#text("von Neumann ergodic theorem")]#text(" (the Hilbert space version of the mean ergodic theorem) asserts that if ")#mi("{U: H \\rightarrow H}")#text(" is a unitary operator on a Hilbert space ")#mi("{H}")#text(", and ")#mi("{v \\in H}")#text(" is a vector in that Hilbert space, then one has")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N U^n v = \\pi_{H^U} v")]]

#text("in the strong topology, where ")#mi("{H^U := \\{ w \\in H: Uw = w \\}}")#text(" is the ")#mi("{U}")#text("-invariant subspace of ")#mi("{H}")#text(", and ")#mi("{\\pi_{H^U}}")#text(" is the orthogonal projection to ")#mi("{H^U}")#text(". (See e.g. ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("these previous lecture notes")]#text(" for a proof.) The same proof extends to more general ")#link("http://en.wikipedia.org/wiki/Amenable_group")[#text("amenable groups")]#text(": if ")#mi("{G}")#text(" is a countable amenable group acting on a Hilbert space ")#mi("{H}")#text(" by unitary transformations ")#mi("{T^g: H \\rightarrow H}")#text(" for ")#mi("{g \\in G}")#text(", and ")#mi("{v \\in H}")#text(" is a vector in that Hilbert space, then one has ")#metadata(none) <tao-82523faea1b0f2da676a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\lim_{N \\rightarrow \\infty} \\mathop{\\bf E}_{g \\in \\Phi_N} T^g v = \\pi_{H^G} v")]]



#text(" for any ")#link("http://en.wikipedia.org/wiki/F%C3%B8lner_sequence")[#text("Folner sequence")]#text(" ")#mi("{\\Phi_N}")#text(" of ")#mi("{G}")#text(", where ")#mi("{H^G := \\{ w \\in H: T^g w = w \\text{ for all }g \\in G \\}}")#text(" is the ")#mi("{G}")#text("-invariant subspace, and ")#tao-math("{\\mathop{\\bf E}_{a \\in A} f(a) := \\frac{1}{\\left|A\\right|} \\sum_{a \\in A} f(a)}", block: false)#text(" is the average of ")#mi("{f}")#text(" on ")#mi("{A}")#text(". Thus one can interpret ")#mi("{\\pi_{H^G} v}")#text(" as a certain average of elements of the orbit ")#mi("{Gv := \\{ T^g v: g \\in G \\}}")#text(" of ")#mi("{v}")#text(".")

#text("In a ")#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/")[#text("previous blog post")]#text(", I noted a variant of this ergodic theorem (due ")#link("http://www.ams.org/mathscinet-getitem?mr=2026")[#text("to Alaoglu and Birkhoff")]#text(") that holds even when the group ")#mi("{G}")#text(" is not amenable (or not discrete), using a more abstract notion of averaging:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Abstract ergodic theorem)")]#text(" ")#metadata(none) <tao-c59ddd3f7ba697a4b820>#text(" Let ")#mi("{G}")#text(" be an arbitrary group acting unitarily on a Hilbert space ")#mi("{H}")#text(", and let ")#mi("{v}")#text(" be a vector in ")#mi("{H}")#text(". Then ")#mi("{\\pi_{H^G} v}")#text(" is the element in the ")#link("http://en.wikipedia.org/wiki/Convex_hull")[#text("closed convex hull")]#text(" of ")#mi("{Gv := \\{ T^g v: g \\in G \\}}")#text(" of minimal norm, and is also the unique element of ")#mi("{H^G}")#text(" in this closed convex hull.")
]

#text("I recently stumbled upon a different way to think about this theorem, in the additive case ")#mi("{G = (G,+)}")#text(" when ")#mi("{G}")#text(" is abelian, which has a closer resemblance to the classical mean ergodic theorem. Given an arbitrary additive group ")#mi("{G = (G,+)}")#text(" (not necessarily discrete, or countable), let ")#mi("{{\\mathcal F}}")#text(" denote the collection of finite non-empty ")#link("http://en.wikipedia.org/wiki/Multiset")[#text("multisets")]#text(" in ")#mi("{G}")#text(" – that is to say, unordered collections ")#mi("{\\{a_1,\\dots,a_n\\}}")#text(" of elements ")#mi("{a_1,\\dots,a_n}")#text(" of ")#mi("{G}")#text(", not necessarily distinct, for some positive integer ")#mi("{n}")#text(". Given two multisets ")#mi("{A = \\{a_1,\\dots,a_n\\}}")#text(", ")#mi("{B = \\{b_1,\\dots,b_m\\}}")#text(" in ")#mi("{{\\mathcal F}}")#text(", we can form the sum set ")#mi("{A + B := \\{ a_i + b_j: 1 \\leq i \\leq n, 1 \\leq j \\leq m \\}}")#text(". Note that the sum set ")#mi("{A+B}")#text(" can contain multiplicity even when ")#mi("{A, B}")#text(" do not; for instance, ")#mi("{\\{ 1,2\\} + \\{1,2\\} = \\{2,3,3,4\\}}")#text(". Given a multiset ")#mi("{A = \\{a_1,\\dots,a_n\\}}")#text(" in ")#mi("{{\\mathcal F}}")#text(", and a function ")#mi("{f: G \\rightarrow H}")#text(" from ")#mi("{G}")#text(" to a vector space ")#mi("{H}")#text(", we define the average ")#mi("{\\mathop{\\bf E}_{a \\in A} f(a)}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{a \\in A} f(a) = \\frac{1}{n} \\sum_{j=1}^n f(a_j).")]]

#text("Note that the multiplicity function of the set ")#mi("{A}")#text(" affects the average; for instance, we have ")#mi("{\\mathop{\\bf E}_{a \\in \\{1,2\\}} a = \\frac{3}{2}}")#text(", but ")#mi("{\\mathop{\\bf E}_{a \\in \\{1,2,2\\}} a = \\frac{5}{3}}")#text(".")

#text("We can define a ")#link("http://en.wikipedia.org/wiki/Directed_set")[#text("directed set")]#text(" on ")#mi("{{\\mathcal F}}")#text(" as follows: given two multisets ")#mi("{A,B \\in {\\mathcal F}}")#text(", we write ")#mi("{A \\geq B}")#text(" if we have ")#mi("{A = B+C}")#text(" for some ")#mi("{C \\in {\\mathcal F}}")#text(". Thus for instance we have ")#mi("{\\{ 1, 2, 2, 3\\} \\geq \\{1,2\\}}")#text(". It is easy to verify that this operation is transitive and reflexive, and is directed because any two elements ")#mi("{A,B}")#text(" of ")#mi("{{\\mathcal F}}")#text(" have a common upper bound, namely ")#mi("{A+B}")#text(". (This is where we need ")#mi("{G}")#text(" to be abelian.) The notion of ")#link("http://en.wikipedia.org/wiki/Net_(topology)")[#text("convergence along a net")]#text(", now allows us to define the notion of convergence along ")#mi("{{\\mathcal F}}")#text("; given a family ")#mi("{x_A}")#text(" of points in a topological space ")#mi("{X}")#text(" indexed by elements ")#mi("{A}")#text(" of ")#mi("{{\\mathcal F}}")#text(", and a point ")#mi("{x}")#text(" in ")#mi("{X}")#text(", we say that ")#mi("{x_A}")#text(" ")#emph[#text("converges")]#text(" to ")#mi("{x}")#text(" along ")#mi("{{\\mathcal F}}")#text(" if, for every open neighbourhood ")#mi("{U}")#text(" of ")#mi("{x}")#text(" in ")#mi("{X}")#text(", one has ")#mi("{x_A \\in U}")#text(" for sufficiently large ")#mi("{A}")#text(", that is to say there exists ")#mi("{B \\in {\\mathcal F}}")#text(" such that ")#mi("{x_A \\in U}")#text(" for all ")#mi("{A \\geq B}")#text(". If the topological space ")#mi("{V}")#text(" is Hausdorff, then the limit ")#mi("{x}")#text(" is unique (if it exists), and we then write")

#align(center)[#tao-fit-display[#mitex("x = \\lim_{A \\rightarrow G} x_A.")]]

#text("When ")#mi("{x_A}")#text(" takes values in the reals, one can also define the limit superior or limit inferior along such nets in the obvious fashion.")

#text("We can then give an alternate formulation of the abstract ergodic theorem in the abelian case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Abelian abstract ergodic theorem)")]#text(" ")#metadata(none) <tao-fb8e20fc2e4c3f248c60>#text(" Let ")#mi("{G = (G,+)}")#text(" be an arbitrary additive group acting unitarily on a Hilbert space ")#mi("{H}")#text(", and let ")#mi("{v}")#text(" be a vector in ")#mi("{H}")#text(". Then we have")

#align(center)[#tao-fit-display[#mitex("\\pi_{H^G} v = \\lim_{A \\rightarrow G} \\mathop{\\bf E}_{a \\in A} T^a v")]]

#text("in the strong topology of ")#mi("{H}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose that ")#mi("{A \\geq B}")#text(", so that ")#mi("{A=B+C}")#text(" for some ")#mi("{C \\in {\\mathcal F}}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{a \\in A} T^a v = \\mathop{\\bf E}_{c \\in C} T^c ( \\mathop{\\bf E}_{b \\in B} T^b v )")]]

#text("so by unitarity and the triangle inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathop{\\bf E}_{a \\in A} T^a v \\right\\|_H \\leq \\left\\| \\mathop{\\bf E}_{b \\in B} T^b v \\right\\|_H,", block: true)]]

#text("thus ")#tao-math("{\\left\\| \\mathop{\\bf E}_{a \\in A} T^a v \\right\\|_H^2}", block: false)#text(" is monotone non-increasing in ")#mi("{A}")#text(". Since this quantity is bounded between ")#mi("{0}")#text(" and ")#tao-math("{\\left\\|v\\right\\|_H}", block: false)#text(", we conclude that the limit ")#tao-math("{\\lim_{A \\rightarrow G} \\left\\| \\mathop{\\bf E}_{a \\in A} T^a v \\right\\|_H^2}", block: false)#text(" exists. Thus, for any ")#mi("{\\varepsilon > 0}")#text(", we have for sufficiently large ")#mi("{A}")#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathop{\\bf E}_{b \\in B} T^b v \\right\\|_H^2 \\geq \\left\\| \\mathop{\\bf E}_{a \\in A} T^a v \\right\\|_H^2 - \\varepsilon", block: true)]]

#text("for all ")#mi("{B \\geq A}")#text(". In particular, for any ")#mi("{g \\in G}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathop{\\bf E}_{b \\in A + \\{0,g\\}} T^b v \\right\\|_H^2 \\geq \\left\\| \\mathop{\\bf E}_{a \\in A} T^a v \\right\\|_H^2 - \\varepsilon.", block: true)]]

#text("We can write")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{b \\in A + \\{0,g\\}} T^b v = \\frac{1}{2} \\mathop{\\bf E}_{a \\in A} T^a v + \\frac{1}{2} T^g \\mathop{\\bf E}_{a \\in A} T^a v")]]

#text("and so from the ")#link("http://en.wikipedia.org/wiki/Parallelogram_law")[#text("parallelogram law")]#text(" and unitarity we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathop{\\bf E}_{a \\in A} T^a v - T^g \\mathop{\\bf E}_{a \\in A} T^a v \\right\\|_H^2 \\leq 4 \\varepsilon", block: true)]]

#text("for all ")#mi("{g \\in G}")#text(", and hence by the triangle inequality (averaging ")#mi("{g}")#text(" over a finite multiset ")#mi("{C}")#text(")")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathop{\\bf E}_{a \\in A} T^a v - \\mathop{\\bf E}_{b \\in A+C} T^b v \\right\\|_H^2 \\leq 4 \\varepsilon", block: true)]]

#text("for any ")#mi("{C \\in {\\mathcal F}}")#text(". This shows that ")#mi("{\\mathop{\\bf E}_{a \\in A} T^a v}")#text(" is a Cauchy sequence in ")#mi("{H}")#text(" (in the strong topology), and hence (by the completeness of ")#mi("{H}")#text(") tends to a limit. Shifting ")#mi("{A}")#text(" by a group element ")#mi("{g}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\lim_{A \\rightarrow G} \\mathop{\\bf E}_{a \\in A} T^a v = \\lim_{A \\rightarrow G} \\mathop{\\bf E}_{a \\in A + \\{g\\}} T^a v = T^g \\lim_{A \\rightarrow G} \\mathop{\\bf E}_{a \\in A} T^a v")]]

#text("and hence ")#mi("{\\lim_{A \\rightarrow G} \\mathop{\\bf E}_{a \\in A} T^a v}")#text(" is invariant under shifts, and thus lies in ")#mi("{H^G}")#text(". On the other hand, for any ")#mi("{w \\in H^G}")#text(" and ")#mi("{A \\in {\\mathcal F}}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\langle \\mathop{\\bf E}_{a \\in A} T^a v, w \\rangle_H = \\mathop{\\bf E}_{a \\in A} \\langle v, T^{-a} w \\rangle_H = \\langle v, w \\rangle_H")]]

#text("and thus on taking strong limits")

#align(center)[#tao-fit-display[#mitex("\\langle \\lim_{A \\rightarrow G} \\mathop{\\bf E}_{a \\in A} T^a v, w \\rangle_H = \\langle v, w \\rangle_H")]]

#text("and so ")#mi("{v - \\lim_{A \\rightarrow G} \\mathop{\\bf E}_{a \\in A} T^a v}")#text(" is orthogonal to ")#mi("{H^G}")#text(". Combining these two facts we see that ")#mi("{\\lim_{A \\rightarrow G} \\mathop{\\bf E}_{a \\in A} T^a v}")#text(" is equal to ")#mi("{\\pi_{H^G} v}")#text(" as claimed. ")#mi("\\Box")

#text("To relate this result to the classical ergodic theorem, we observe")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" Let ")#mi("{G}")#text(" be a countable additive group, with a F{\\o}lner sequence ")#mi("{\\Phi_n}")#text(", and let ")#mi("{f_g}")#text(" be a bounded sequence in a normed vector space indexed by ")#mi("{G}")#text(". If ")#mi("{\\lim_{A \\rightarrow G} \\mathop{\\bf E}_{a \\in A} f_a}")#text(" exists, then ")#mi("{\\lim_{n \\rightarrow \\infty} \\mathop{\\bf E}_{a \\in \\Phi_n} f_a}")#text(" exists, and the two limits are equal.")
]

#emph[#text("Proof:")]#text(" From the F{\\o}lner property, we see that for any ")#mi("{A}")#text(" and any ")#mi("{\\varepsilon>0}")#text(", the averages ")#mi("{\\mathop{\\bf E}_{a \\in \\Phi_n} f_a}")#text(" and ")#mi("{\\mathop{\\bf E}_{a \\in A+\\Phi_n} f_a}")#text(" differ by at most ")#mi("{\\varepsilon}")#text(" in norm if ")#mi("{n}")#text(" is sufficiently large depending on ")#mi("{A}")#text(", ")#mi("{\\varepsilon}")#text(" (and the ")#mi("{f_a}")#text("). On the other hand, by the existence of the limit ")#mi("{\\lim_{A \\rightarrow G} \\mathop{\\bf E}_{a \\in A} f_a}")#text(", the averages ")#mi("{\\mathop{\\bf E}_{a \\in A} f_a}")#text(" and ")#mi("{\\mathop{\\bf E}_{a \\in A + \\Phi_n} f_a}")#text(" differ by at most ")#mi("{\\varepsilon}")#text(" in norm if ")#mi("{A}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon}")#text(" (regardless of how large ")#mi("{n}")#text(" is). The claim follows. ")#mi("\\Box")

#text("It turns out that this approach can also be used as an alternate way to construct the ")#link("http://www.ams.org/mathscinet-getitem?mr=1844079")[#text("Gowers")]#text("–")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("Host-Kra")]#text(" seminorms in ergodic theory, which has the feature that it does not explicitly require any amenability on the group ")#mi("{G}")#text(" (or separability on the underlying measure space), though, as pointed out to me in comments, even uncountable abelian groups are amenable in the sense of possessing an invariant mean, even if they do not have a F{\\o}lner sequence.")

#text("Given an arbitrary additive group ")#mi("{G}")#text(", define a ")#emph[#mi("{G}")#text("-system")]#text(" ")#mi("{({\\mathrm X}, T)}")#text(" to be a probability space ")#mi("{{\\mathrm X} = (X, {\\mathcal X}, \\mu)}")#text(" (not necessarily separable or standard Borel), together with a collection ")#mi("{T^g: X \\rightarrow X}")#text(" of invertible, measure-preserving maps, such that ")#mi("{T^0}")#text(" is the identity and ")#mi("{T^g T^h = T^{g+h}}")#text(" (modulo null sets) for all ")#mi("{g,h \\in G}")#text(". This then gives isomorphisms ")#mi("{T^g: L^p({\\mathrm X}) \\rightarrow L^p({\\mathrm X})}")#text(" for ")#mi("{1 \\leq p \\leq \\infty}")#text(" by setting ")#mi("{T^g f(x) := f(T^{-g} x)}")#text(". From the above abstract ergodic theorem, we see that")

#align(center)[#tao-fit-display[#mitex("{\\mathbf E}( f | {\\mathcal X}^G ) = \\lim_{A \\rightarrow G} \\mathop{\\bf E}_{a \\in A} T^g f")]]

#text("in the strong topology of ")#mi("{L^2({\\mathrm X})}")#text(" for any ")#mi("{f \\in L^2({\\mathrm X})}")#text(", where ")#mi("{{\\mathcal X}^G}")#text(" is the collection of measurable sets ")#mi("{E}")#text(" that are essentially ")#mi("{G}")#text("-invariant in the sense that ")#mi("{T^g E = E}")#text(" modulo null sets for all ")#mi("{g \\in G}")#text(", and ")#mi("{{\\mathbf E}(f|{\\mathcal X}^G)}")#text(" is the conditional expectation of ")#mi("{f}")#text(" with respect to ")#mi("{{\\mathcal X}^G}")#text(".")

#text("In a similar spirit, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Convergence of Gowers-Host-Kra seminorms)")]#text(" ")#metadata(none) <tao-3ad366c923a98fc4b359>#text(" Let ")#mi("{({\\mathrm X},T)}")#text(" be a ")#mi("{G}")#text("-system for some additive group ")#mi("{G}")#text(". Let ")#mi("{d}")#text(" be a natural number, and for every ")#mi("{\\omega \\in\\{0,1\\}^d}")#text(", let ")#mi("{f_\\omega \\in L^{2^d}({\\mathrm X})}")#text(", which for simplicity we take to be real-valued. Then the expression")

#align(center)[#tao-fit-display[#mitex("\\langle (f_\\omega)_{\\omega \\in \\{0,1\\}^d} \\rangle_{U^d({\\mathrm X})} := \\lim_{A_1,\\dots,A_d \\rightarrow G}")]]

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{h_1 \\in A_1-A_1,\\dots,h_d \\in A_d-A_d} \\int_X \\prod_{\\omega \\in \\{0,1\\}^d} T^{\\omega_1 h_1 + \\dots + \\omega_d h_d} f_\\omega\\ d\\mu")]]

#text("converges, where we write ")#mi("{\\omega = (\\omega_1,\\dots,\\omega_d)}")#text(", and we are using the product direct set on ")#mi("{{\\mathcal F}^d}")#text(" to define the convergence ")#mi("{A_1,\\dots,A_d \\rightarrow G}")#text(". In particular, for ")#mi("{f \\in L^{2^d}({\\mathrm X})}")#text(", the limit")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{U^d({\\mathrm X})}^{2^d} = \\lim_{A_1,\\dots,A_d \\rightarrow G}", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{h_1 \\in A_1-A_1,\\dots,h_d \\in A_d-A_d} \\int_X \\prod_{\\omega \\in \\{0,1\\}^d} T^{\\omega_1 h_1 + \\dots + \\omega_d h_d} f\\ d\\mu")]]

#text("converges.")
]

#text("We prove this theorem below the fold. It implies a number of other known descriptions of the Gowers-Host-Kra seminorms ")#tao-math("{\\left\\|f\\right\\|_{U^d({\\mathrm X})}}", block: false)#text(", for instance that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{U^d({\\mathrm X})}^{2^d} = \\lim_{A \\rightarrow G} \\mathop{\\bf E}_{h \\in A-A} \\left\\| f T^h f \\right\\|_{U^{d-1}({\\mathrm X})}^{2^{d-1}}", block: true)]]

#text("for ")#mi("{d > 1}")#text(", while from the ergodic theorem we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{U^1({\\mathrm X})} = \\left\\| {\\mathbf E}( f | {\\mathcal X}^G ) \\right\\|_{L^2({\\mathrm X})}.", block: true)]]

#text("This definition also manifestly demonstrates the cube symmetries of the Host-Kra measures ")#mi("{\\mu^{[d]}}")#text(" on ")#mi("{X^{\\{0,1\\}^d}}")#text(", defined via duality by requiring that")

#align(center)[#tao-fit-display[#mitex("\\langle (f_\\omega)_{\\omega \\in \\{0,1\\}^d} \\rangle_{U^d({\\mathrm X})} = \\int_{X^{\\{0,1\\}^d}} \\bigotimes_{\\omega \\in \\{0,1\\}^d} f_\\omega\\ d\\mu^{[d]}.")]]

#text("In a subsequent blog post I hope to present a more detailed study of the ")#mi("{U^2}")#text(" norm and its relationship with eigenfunctions and the Kronecker factor, without assuming any amenability on ")#mi("{G}")#text(" or any separability or topological structure on ")#mi("{{\\mathrm X}}")#text(".")

#metadata(none) <tao-a81df80700f0e5339913>

#heading(level: 1)[#strong[#text(" — 1. Proof of theorem — ")]]

#text("If ")#mi("{\\vec f := (f_\\omega)_{\\omega \\in \\{0,1\\}^d}}")#text(" is a tuple of functions ")#mi("{f_\\omega \\in L^{2^d}({\\mathrm X})}")#text(" and ")#mi("{0 \\leq d^{\\prime} \\leq d}")#text(", we say that ")#mi("{\\vec f}")#text(" is ")#emph[#mi("{d^{\\prime}}")#text("-symmetric")]#text(" if we have ")#mi("{f_\\omega = f_{\\omega^{\\prime}}}")#text(" whenever ")#mi("{\\omega = (\\omega_1,\\dots,\\omega_d)}")#text(" and ")#mi("{\\omega^{\\prime} = (\\omega^{\\prime}_1,\\dots,\\omega^{\\prime}_d)}")#text(" agree in the first ")#mi("{d^{\\prime}}")#text(" components (that is, ")#mi("{\\omega_i = \\omega^{\\prime}_i}")#text(" for ")#mi("{i=1,\\dots,d^{\\prime}}")#text("). We will prove Theorem ")#link(<tao-3ad366c923a98fc4b359>)[#text("4")]#text(" by downward induction on ")#mi("{d^{\\prime}}")#text(", with the ")#mi("{d^{\\prime}=0}")#text(" case establishing the full theorem.")

#text("Thus, assume that ")#mi("{0 \\leq d^{\\prime} \\leq d}")#text(" and that the claim has already been proven for larger values of ")#mi("{d^{\\prime}}")#text(" (this hypothesis is vacuous for ")#mi("{d^{\\prime}=d}")#text("). Write")

#align(center)[#tao-fit-display[#mitex("F( A_1,\\dots, A_d ) := \\mathop{\\bf E}_{h_1 \\in A_1-A_1,\\dots,h_d \\in A_d-A_d} \\int_X \\prod_{\\omega \\in \\{0,1\\}^d} T^{\\omega_1 h_1 + \\dots + \\omega_d h_d} f_\\omega\\ d\\mu")]]

#text("We will show that for any ")#mi("{\\varepsilon > 0}")#text(", and for sufficiently large ")#mi("{A_1,\\dots,A_d}")#text(" (in the net ")#mi("{{\\mathcal F}}")#text("), the quantity ")#mi("{F(A_1,\\dots,A_d)}")#text(" can only increase by at most ")#mi("{\\varepsilon}")#text(" when one increases any of the ")#mi("{A_i}")#text(", ")#mi("{1 \\leq i \\leq d}")#text(", that is to say that")

#align(center)[#tao-fit-display[#mitex("F(A_1,\\dots,A_{i-1}, A^{\\prime}_i, A_{i+1},\\dots, A_d) \\leq F(A_1,\\dots,A_d) + \\varepsilon")]]

#text("whenever ")#mi("{1 \\leq i \\leq d}")#text(" and ")#mi("{A^{\\prime}_i \\geq A_i}")#text(". This implies that the limit superior of ")#mi("{F(A_1,\\dots,A_d)}")#text(" exceeds the limit inferior by at most ")#mi("{d\\varepsilon}")#text(", and on sending ")#mi("{\\varepsilon \\rightarrow 0}")#text(" we will obtain Theorem ")#link(<tao-3ad366c923a98fc4b359>)[#text("4")]#text(".")

#text("There are two cases, depending on whether ")#mi("{i \\leq d^{\\prime}}")#text(" or ")#mi("{d^{\\prime} < i \\leq d}")#text(". We begin with the first case ")#mi("{i \\leq d^{\\prime}}")#text(". By relabeling we may take ")#mi("{i=1}")#text(", so that ")#mi("{d^{\\prime} \\geq 1}")#text(". As ")#mi("{\\vec f}")#text(" is ")#mi("{d^{\\prime}}")#text("-symmetric, we can write")

#align(center)[#tao-fit-display[#tao-math("F(A_1,\\dots,A_d) = \\mathop{\\bf E}_{h_2 \\in A_2-A_2,\\dots,h_d \\in A_d-A_d} \\left\\| \\mathop{\\bf E}_{a \\in A_1} T^{a} f_{h_2,\\dots,h_d}\\right\\|_{L^2({\\mathrm X})}^2", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("f_{h_2,\\dots,h_d} := \\prod_{\\omega_2,\\dots,\\omega_d \\in \\{0,1\\}} T^{\\omega_2 h_2 + \\dots + \\omega_d h_d} f_{(0,\\omega_2,\\dots,\\omega_d)}.")]]

#text("By the triangle inequality argument used to prove Theorem ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("2")]#text(" we thus see that")

#align(center)[#tao-fit-display[#mitex("F(A_1 + B, A_2,\\dots,A_d) \\leq F(A_1,\\dots,A_d),")]]

#text("and so ")#mi("{F}")#text(" certainly cannot increase by ")#mi("{\\varepsilon}")#text(" by increasing ")#mi("{A_1}")#text(".")

#text("Now we turn to the case when ")#mi("{d^{\\prime} < i \\leq d}")#text(". By relabeling we may take ")#mi("{i=d}")#text(", so that ")#mi("{d^{\\prime} < d}")#text(". We can write")

#align(center)[#tao-fit-display[#mitex("F(A_1,\\dots,A_d) = \\mathop{\\bf E}_{h_1 \\in A_1-A_1,\\dots,h_{d-1} \\in A_{d-1}-A_{d-1}}")]]

#align(center)[#tao-fit-display[#mitex("\\left\\langle \\mathop{\\bf E}_{a \\in A_d} T^{a} f^0_{h_1,\\dots,h_{d-1}}, \\mathop{\\bf E}_{a \\in A_d} T^{a} f^1_{h_1,\\dots,h_{d-1}} \\right\\rangle_{L^2({\\mathrm X})}")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("f^{\\omega_d}_{h_1,\\dots,h_{d-1}} := \\prod_{\\omega_1,\\dots,\\omega_{d-1} \\in \\{0,1\\}} T^{\\omega_1 h_1 + \\dots + \\omega_{d-1} h_{d-1}} f_{(\\omega_1,\\omega_2,\\dots,\\omega_d)}.")]]

#text("On the other hand, the quantity")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{h_1 \\in A_1-A_1,\\dots,h_{d-1} \\in A_{d-1}-A_{d-1}} \\left\\| \\mathop{\\bf E}_{a \\in A_d} T^{a} f^0_{h_1,\\dots,h_{d-1}} \\right\\|_{L^2({\\mathrm X})}^2", block: true)]]

#text("is the same as ")#mi("{F(A_1,\\dots,A_d)}")#text(", but with ")#mi("{f_{(\\omega_1,\\dots,\\omega_{d-1},1)}}")#text(" replaced by ")#mi("{f_{(\\omega_1,\\dots,\\omega_{d-1},0)}}")#text(". After rearrangement, this is a ")#mi("{d^{\\prime}+1}")#text("-symmetric inner product, and so by induction hypothesis the limit")

#align(center)[#tao-fit-display[#tao-math("\\lim_{A_1,\\dots,A_d \\rightarrow G} \\mathop{\\bf E}_{h_1 \\in A_1-A_1,\\dots,h_{d-1} \\in A_{d-1}-A_{d-1}} \\left\\| \\mathop{\\bf E}_{a \\in A_d} T^{a} f^0_{h_1,\\dots,h_{d-1}} \\right\\|_{L^2({\\mathrm X})}^2", block: true)]]

#text("exists. In particular, for ")#mi("{A_1,\\dots,A_d}")#text(" large enough, we have")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf E}_{h_1 \\in A_1-A_1,\\dots,h_{d-1} \\in A_{d-1}-A_{d-1}} \\left\\| \\mathop{\\bf E}_{a \\in A_d + \\{0,g\\}} T^{a} f^0_{h_1,\\dots,h_{d-1}} \\right\\|_{L^2({\\mathrm X})}^2", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\geq \\mathop{\\bf E}_{h_1 \\in A_1-A_1,\\dots,h_{d-1} \\in A_{d-1}-A_{d-1}} \\left\\| \\mathop{\\bf E}_{a \\in A_d} T^{a} f^0_{h_1,\\dots,h_{d-1}} \\right\\|_{L^2({\\mathrm X})}^2 - \\varepsilon", block: true)]]

#text("for all ")#mi("{g \\in G}")#text(", which by the parallelogram law as in the proof of Theorem ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("2")]#text(" shows that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{h_1 \\in A_1-A_1,\\dots,h_{d-1} \\in A_{d-1}-A_{d-1}}")]]

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathop{\\bf E}_{a \\in A_d + \\{g\\}} T^{a} f^0_{h_1,\\dots,h_{d-1}} - \\mathop{\\bf E}_{a \\in A_d} T^{a} f^0_{h_1,\\dots,h_{d-1}} \\right\\|_{L^2({\\mathrm X})}^2 \\leq 4 \\varepsilon", block: true)]]

#text("and hence by averaging")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{h_1 \\in A_1-A_1,\\dots,h_{d-1} \\in A_{d-1}-A_{d-1}}")]]

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathop{\\bf E}_{a \\in A^{\\prime}_d} T^{a} f^0_{h_1,\\dots,h_{d-1}} - \\mathop{\\bf E}_{a \\in A_d} T^{a} f^0_{h_1,\\dots,h_{d-1}} \\right\\|_{L^2({\\mathrm X})}^2 \\leq 4 \\varepsilon", block: true)]]

#text("whenever ")#mi("{A^{\\prime}_d \\geq A_d}")#text(". Similarly with ")#mi("{f^0_{h_1,\\dots,h_{d-1}}}")#text(" replaced by ")#mi("{f^1_{h_1,\\dots,h_{d-1}}}")#text(". From Cauchy-Schwarz we then have")

#align(center)[#tao-fit-display[#tao-math("\\left|F(A_1,\\dots,A_{d-1},A^{\\prime}_d) - F(A_1,\\dots,A_d)\\right| \\leq C \\varepsilon", block: true)]]

#text("for some ")#mi("{C}")#text(" independent of ")#mi("{\\varepsilon}")#text(" (depending on the ")#mi("{L^{2^d}}")#text(" norms of the ")#mi("{f_\\omega}")#text("), and the claim follows after redefining ")#mi("{\\varepsilon}")#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc853e0af95a46704a264199feca0bf44e8e7c4e7135eb92aabe689804a3522c-9df98007634a3af61600885e725aaab4768c71bb04aa84ae46b4828990fbb0d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rennydiokno2015")]], [#link("https://terrytao.wordpress.com/2015/04/09/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/#comment-453982")[#strong[#text("rennydiokno2015")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2015")])]

#text("Reblogged this on ")#link("https://rennydioknodotcom.wordpress.com/2015/04/10/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/")[#text("rennydiokno.com")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/04/09/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/#comment-453985")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2015")])]

#text("In the initial definition of sum set, a + is missing (says AB :=… now)")

#text("In the proof of Thm 2, there is a lim_{A\\to H} (“we conclude that the limit…”)")

#text("I’m having some trouble seeing the Cauchy estimate from the parallelogram law in Thm 2. Taking X = ET^a v we have ||X – T^g X||^2 + ||X+ T^g X||^2 = 4||X||^2 and from ||X + T^gX||^2 \\geq ||X||^2 – \\epsilon we get ||X – T^g X||^2\\leq \\epsilon + 3||X||^2 instead of 4\\epsilon")

#text("In the discussion immediately preceding Thm 3, E(f, X^G) has a \\mathcal{E} instead of \\mathbf")

#emph[#text("[Corrected, thanks. The lower bound should be on ")#mi("\\frac{1}{2}( X + T^g X )")#text(", not ")#mi("X + T^g X")#text(". -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/04/09/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/#comment-454001")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2015")])]

#text("Ah, yes. There is a 1/2 missing in the RHS of E_{b \\in A + {0,g}} = E_a T^a v + T^g E_a T^a v")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e129a68dcf0bb46ecba772753b8f9af1ec273d49cbd7ace8069058648b03b58-7eb33440dcbae163fc1d170d08c9c52deb82d4eb4253cf0fbe7e8b13997f3aa7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig H")]], [#link("https://terrytao.wordpress.com/2015/04/09/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/#comment-454002")[#strong[#text("Craig H")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2015")])]

#text("I think you’re still missing the $\\frac{1}{2}$.")

#text("Specifically, just above the “parallelogram law” link, it should be")

#text("$ET^b v = \\frac{1}{2} (ET^a v + T^g ET^a v)$,")

#text("since the size of the multiset has now doubled.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/04/09/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/#comment-453986")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2015")])]

#text("In the line below the definition of the average ")#mi("E_{a \\in A} f(a)")#text(", it seems that “multiplicity of the set ")#mi("A")#text("” should be “multiplicity function of the multiset ")#mi("A")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pzorin")]], [#link("https://terrytao.wordpress.com/2015/04/09/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/#comment-453987")[#strong[#text("pzorin")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2015")])]

#text("Isn’t it the case that all commutative groups are amenable as discrete groups?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bebe10d813fbc6538fe482dec98cfe9309584daaa62b958a1262e197e1748bcf-a37480e213b9ec2ff71ac188f637c6e68a32eb1daaaeece73e73ad6224ae6795.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcel S.")]], [#link("https://terrytao.wordpress.com/2015/04/09/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/#comment-453993")[#strong[#text("Marcel S.")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2015")])]

#text("As far as I am aware all abelian groups are amenable (see e.g. Chapter 10 in “The Banach-Tarski paradox” by Stan Wagon). If I am not mistaken a slight modification of the procedure described in Theorem 2 should provide an invariant mean on bounded functions on the group.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/04/09/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/#comment-454000")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2015")])]

#text("Hmm you’re right; uncountable abelian groups don’t have Folner sequences, but they still have invariant means. I guess what I meant to say here is that one can establish the ergodic theorem and construct the Gowers-Host-Kra seminorms without explicit use of Folner sequences, even if the ambient group is still technically amenable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/04/09/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/#comment-454022")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2015")])]

#text("I guess in the beginning the link to “previous lecture notes” should be pointing to one lecture earlier (i.e. Lecture 8 not 9.)")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Concatenation theorems for anti-Gowers-uniform functions and Host-Kra characteristic factors; polynomial patterns in primes | What's new")]], [#link("https://terrytao.wordpress.com/2015/04/09/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/#comment-467299")[#strong[#text("Concatenation theorems for anti-Gowers-uniform functions and Host-Kra characteristic factors; polynomial patterns in primes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2016")])]

#text("[…] of ways. One is by duality, using the Gowers-Host-Kra uniformity seminorms (defined for instance here) . Namely, is the factor of defined up to equivalence by the requirement […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A Host–Kra $latex {bf F}^omega_2$-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the $U^6({bf F}^n_2)$ norm; The structure of totally disconnected Host–Kra–Ziegler factors, and the inve")]], [#link("https://terrytao.wordpress.com/2015/04/09/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/#comment-675855")[#strong[#text("A Host–Kra $latex {bf F}^omega_2$-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the $U^6({bf F}^n_2)$ norm; The structure of totally disconnected Host–Kra–Ziegler factors, and the inve")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2023")])]

#text("[…] . Suppose that with an ergodic -system with positive Gowers-Host-Kra seminorm (see for instance this previous post for a definition). Then there exists a measurable polynomial of degree at most such that has a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A Host–Kra ${bf F}^omega_2$-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the $U^6({bf F}^n_2)$ norm; The structure of totally disconnected Host–Kra–Ziegler factors, and the inverse th")]], [#link("https://terrytao.wordpress.com/2015/04/09/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/#comment-675861")[#strong[#text("A Host–Kra ${bf F}^omega_2$-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the $U^6({bf F}^n_2)$ norm; The structure of totally disconnected Host–Kra–Ziegler factors, and the inverse th")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2023")])]

#text("[…] . Suppose that with an ergodic -system with positive Gowers-Host-Kra seminorm (see for instance this previous post for a definition). Then there exists a measurable polynomial of degree at most such that has a […]")
]
