// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/04/26/szemeredis-regularity-lemma-via-random-partitions/
// Converted to Typst by tao2typ: "2026-10-14T16:35:42.866659+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Szemeredi’s regularity lemma via random partitions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Szemeredi’s regularity lemma via random partitions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 April 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/04/26/szemeredis-regularity-lemma-via-random-partitions/")[#text("https://terrytao.wordpress.com/2009/04/26/szemeredis-regularity-lemma-via-random-partitions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the theory of dense graphs on ")#mi("{n}")#text(" vertices, where ")#mi("{n}")#text(" is large, a fundamental role is played by the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Regularity lemma, standard version)")]#text(" ")#metadata(none) <tao-2ec3bb17df1c8ce6c917>#text(" Let ")#mi("{G = (V,E)}")#text(" be a graph on ")#mi("{n}")#text(" vertices, and let ")#mi("{\\epsilon > 0}")#text(" and ")#mi("{k_0 \\geq 0}")#text(". Then there exists a partition of the vertices ")#mi("{V = V_1 \\cup \\ldots \\cup V_k}")#text(", with ")#mi("{k_0 \\leq k \\leq C(k_0,\\epsilon)}")#text(" bounded below by ")#mi("{k_0}")#text(" and above by a quantity ")#mi("{C(k_0,\\epsilon)}")#text(" depending only on ")#mi("{k_0, \\epsilon}")#text(", obeying the following properties:")

#list(
[#text("(Equitable partition) For any ")#mi("{1 \\leq i,j \\leq k}")#text(", the cardinalities ")#tao-math("{\\left|V_i\\right|, \\left|V_j\\right|}", block: false)#text(" of ")#mi("{V_i}")#text(" and ")#mi("{V_j}")#text(" differ by at most ")#mi("{1}")#text(".")],
[#text("(Regularity) For all but at most ")#mi("{\\epsilon k^2}")#text(" pairs ")#mi("{1 \\leq i < j \\leq k}")#text(", the portion of the graph ")#mi("{G}")#text(" between ")#mi("{V_i}")#text(" and ")#mi("{V_j}")#text(" is ")#emph[#mi("{\\epsilon}")#text("-regular")]#text(" in the sense that one has")

#align(center)[#tao-fit-display[#tao-math("\\left|d( A, B ) - d( V_i, V_j )\\right| \\leq \\epsilon", block: true)]]

#text("for any ")#mi("{A \\subset V_i}")#text(" and ")#mi("{B \\subset V_j}")#text(" with ")#tao-math("{\\left|A\\right| \\geq \\epsilon \\left|V_i\\right|, \\left|B\\right| \\geq \\epsilon \\left|V_j\\right|}", block: false)#text(", where ")#tao-math("{d(A,B) := \\left|E \\cap (A \\times B)\\right|/\\left|A\\right| \\left|B\\right|}", block: false)#text(" is the density of edges between ")#mi("{A}")#text(" and ")#mi("{B}")#text(".")]
)
]

#text("This lemma becomes useful in the regime when ")#mi("{n}")#text(" is very large compared to ")#mi("{k_0}")#text(" or ")#mi("{1/\\epsilon}")#text(", because all the conclusions of the lemma are uniform in ")#mi("{n}")#text(". Very roughly speaking, it says that “up to errors of size ")#mi("{\\epsilon}")#text("“, a large graph can be more or less described completely by a bounded number of quantities ")#mi("{d(V_i, V_j)}")#text(". This can be interpreted as saying that the space of all graphs is ")#link("http://en.wikipedia.org/wiki/Totally_bounded")[#text("totally bounded")]#text(" (and hence ")#link("http://en.wikipedia.org/wiki/Precompact")[#text("precompact")]#text(") in a suitable metric space, thus allowing one to take formal limits of sequences (or subsequences) of graphs; see for instance ")#link("http://arxiv.org/abs/math/0408173")[#text("this paper of Lovasz and Szegedy")]#text(" for a discussion.")

#text("For various technical reasons it is easier to work with a slightly weaker version of the lemma, which allows for the cells ")#mi("{V_1,\\ldots,V_k}")#text(" to have unequal sizes:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Regularity lemma, weighted version)")]#text(" ")#metadata(none) <tao-e150964f803cc374db1b>#text(" Let ")#mi("{G = (V,E)}")#text(" be a graph on ")#mi("{n}")#text(" vertices, and let ")#mi("{\\epsilon > 0}")#text(". Then there exists a partition of the vertices ")#mi("{V = V_1 \\cup \\ldots \\cup V_k}")#text(", with ")#mi("{1 \\leq k \\leq C(\\epsilon)}")#text(" bounded above by a quantity ")#mi("{C(\\epsilon)}")#text(" depending only on ")#mi("{\\epsilon}")#text(", obeying the following properties:")

#list(
[#text("(Regularity) One has")

#metadata(none) <tao-667937c3e7a68ea37471>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\sum_{(V_i,V_j) \\text{ not } \\epsilon-\\text{regular}} \\left|V_i\\right| \\left|V_j\\right| = O(\\epsilon \\left|V\\right|^2)", block: true)]]

#text("where the sum is over all pairs ")#mi("{1 \\leq i \\leq j \\leq k}")#text(" for which ")#mi("{G}")#text(" is not ")#mi("{\\epsilon}")#text("-regular between ")#mi("{V_i}")#text(" and ")#mi("{V_j}")#text(".")]
)
]

#text("While Lemma ")#link(<tao-e150964f803cc374db1b>)[#text("2")]#text(" is, strictly speaking, weaker than Lemma ")#link(<tao-2ec3bb17df1c8ce6c917>)[#text("1")]#text(" in that it does not enforce the equitable size property between the atoms, in practice it seems that the two lemmas are roughly of equal utility; most of the combinatorial consequences of Lemma ")#link(<tao-2ec3bb17df1c8ce6c917>)[#text("1")]#text(" can also be proven using Lemma ")#link(<tao-e150964f803cc374db1b>)[#text("2")]#text(". The point is that one always has to remember to weight each cell ")#mi("{V_i}")#text(" by its density ")#tao-math("{\\left|V_i\\right|/\\left|V\\right|}", block: false)#text(", rather than by giving each cell an equal weight as in Lemma ")#link(<tao-2ec3bb17df1c8ce6c917>)[#text("1")]#text(". Lemma ")#link(<tao-e150964f803cc374db1b>)[#text("2")]#text(" also has the advantage that one can easily generalise the result from finite vertex sets ")#mi("{V}")#text(" to other probability spaces (for instance, one could weight ")#mi("{V}")#text(" with something other than the uniform distribution). For applications to hypergraph regularity, it turns out to be slightly more convenient to have ")#emph[#text("two")]#text(" partitions (coarse and fine) rather than just one; see for instance ")#link("http://arxiv.org/abs/math.CO/0503572")[#text("my own paper on this topic")]#text(". In any event the arguments below that we give to prove Lemma ")#link(<tao-e150964f803cc374db1b>)[#text("2")]#text(" can be modified to give a proof of Lemma ")#link(<tao-2ec3bb17df1c8ce6c917>)[#text("1")]#text(" also. The proof of the regularity lemma is usually conducted by a greedy algorithm. Very roughly speaking, one starts with the trivial partition of ")#mi("{V}")#text(". If this partition already regularises the graph, we are done; if not, this means that there are some sets ")#mi("{A}")#text(" and ")#mi("{B}")#text(" in which there is a significant density fluctuation beyond what has already been detected by the original partition. One then adds these sets to the partition and iterates the argument. Every time a new density fluctuation is incorporated into the partition that models the original graph, this increases a certain “index” or “energy” of the partition. On the other hand, this energy remains bounded no matter how complex the partition, so eventually one must reach a long “energy plateau” in which no further refinement is possible, at which point one can find the regular partition.")

#text("One disadvantage of the greedy algorithm is that it is not efficient in the limit ")#mi("{n \\rightarrow \\infty}")#text(", as it requires one to search over ")#emph[#text("all")]#text(" pairs of subsets ")#mi("{A, B}")#text(" of a given pair ")#mi("{V_i, V_j}")#text(" of cells, which is an exponentially long search. There are more algorithmically efficient ways to regularise, for instance a polynomial time algorithm was given ")#link("http://www.ams.org/mathscinet-getitem?mr=1251840")[#text("by Alon, Duke, Lefmann, Rödl, and Yuster")]#text(". However, one can do even better, if one is willing to (a) allow cells of unequal size, (b) allow a small probability of failure, (c) have the ability to sample vertices from ")#mi("{G}")#text(" at random, and (d) allow for the cells to be defined “implicitly” (via their relationships with a fixed set of reference vertices) rather than “explicitly” (as a list of vertices). In that case, one can regularise a graph in a number of operations ")#emph[#text("bounded")]#text(" in ")#mi("{n}")#text(". Indeed, one has")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Regularity lemma via random neighbourhoods)")]#text(" ")#metadata(none) <tao-7b343f11ada385c4d2eb>#text(" Let ")#mi("{\\epsilon > 0}")#text(". Then there exists integers ")#mi("{M_1,\\ldots,M_m}")#text(" with the following property: whenever ")#mi("{G = (V,E)}")#text(" be a graph on finitely many vertices, if one selects one of the integers ")#mi("{M_r}")#text(" at random from ")#mi("{M_1,\\ldots,M_m}")#text(", then selects ")#mi("{M_r}")#text(" vertices ")#mi("{v_1,\\ldots,v_{M_r} \\in V}")#text(" uniformly from ")#mi("{V}")#text(" at random, then the ")#mi("{2^{M_r}}")#text(" vertex cells ")#mi("{V^{M_r}_1,\\ldots,V^{M_r}_{2^{M_r}}}")#text(" (some of which can be empty) generated by the vertex neighbourhoods ")#mi("{A_t := \\{ v \\in V: (v,v_t) \\in E \\}}")#text(" for ")#mi("{1 \\leq t \\leq M_r}")#text(", will obey the conclusions of Lemma ")#link(<tao-e150964f803cc374db1b>)[#text("2")]#text(" with probability at least ")#mi("{1-O(\\epsilon)}")#text(".")
]

#text("Thus, roughly speaking, one can regularise a graph simply by taking a large number of random vertex neighbourhoods, and using the partition (or Venn diagram) generated by these neighbourhoods as the partition. The intuition is that if there is any non-uniformity in the graph (e.g. if the graph exhibits bipartite behaviour), this will bias the random neighbourhoods to seek out the partitions that would regularise that non-uniformity (e.g. vertex neighbourhoods would begin to fill out the two vertex cells associated to the bipartite property); if one takes sufficiently many such random neighbourhoods, the probability that all detectable non-uniformity is captured by the partition should converge to ")#mi("{1}")#text(". (It is more complicated than this, because the finer one makes the partition, the finer the types of non-uniformity one can begin to detect, but this is the basic idea.)")

#text("This fact seems to be reasonably well-known folklore, discovered independently by many authors; it is for instance quite close to the graph property testing results ")#link("http://www.ams.org/mathscinet-getitem?mr=2411033")[#text("of Alon and Shapira")]#text(", and also appears implicitly in a ")#link("http://arxiv.org/abs/math/0612838")[#text("paper of Ishigami")]#text(", as well as a ")#link("http://arxiv.org/abs/0801.1698")[#text("paper of Austin")]#text(" (and perhaps even more implicitly in a ")#link("http://arxiv.org/abs/math/0602037")[#text("paper of myself")]#text("). However, in none of these papers is the above lemma stated explicitly. I was asked about this lemma recently, so I decided to provide a proof here.")

#metadata(none) <tao-a19e8b7173fa53646b4b>

#heading(level: 1)[#strong[#text(" — 1. Warmup: a weak regularity lemma — ")]]

#text("To motivate the idea, let’s first prove a weaker but simpler (and more quantitatively effective) regularity lemma, analogous to that established by Frieze and Kannan:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Weak regularity lemma via random neighbourhoods)")]#text(" ")#metadata(none) <tao-32528cb2558a284e5b40>#text(" Let ")#mi("{\\epsilon > 0}")#text(". Then there exists an integer ")#mi("{M}")#text(" with the following property: whenever ")#mi("{G = (V,E)}")#text(" be a graph on finitely many vertices, if one selects ")#mi("{1 \\leq t \\leq M}")#text(" at random, then selects ")#mi("{t}")#text(" vertices ")#mi("{v_1,\\ldots,v_t \\in V}")#text(" uniformly from ")#mi("{V}")#text(" at random, then the ")#mi("{2^{t}}")#text(" vertex cells ")#mi("{V^t_1,\\ldots,V^t_{2^t}}")#text(" (some of which can be empty) generated by the vertex neighbourhoods ")#mi("{A_{t^{\\prime}} := \\{ v \\in V: (v,v_{t^{\\prime}}) \\in E \\}}")#text(" for ")#mi("{1 \\leq t^{\\prime} \\leq t}")#text(", obey the following property with probability at least ")#mi("{1-O(\\epsilon)}")#text(": for any vertex sets ")#mi("{A, B \\subset V}")#text(", the number of edges ")#tao-math("{\\left|E \\cap (A \\times B)\\right|}", block: false)#text(" connecting ")#mi("{A}")#text(" and ")#mi("{B}")#text(" can be approximated by the formula ")#metadata(none) <tao-586933470eea8d66d62b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|E \\cap (A \\times B)\\right| = \\sum_{i=1}^{2^t} \\sum_{j=1}^{2^t} d(V^t_i,V^t_j) \\left|A \\cap V^t_i\\right| \\left|B \\cap V^t_j\\right| + O( \\epsilon \\left|V\\right|^2 ).", block: true)]]
]

#text("This weaker lemma only lets us count “macroscopic” edge densities ")#mi("{d(A,B)}")#text(", when ")#mi("{A, B}")#text(" are dense subsets of ")#mi("{V}")#text(", whereas the full regularity lemma is stronger in that it also controls “microscopic” edge densities ")#mi("{d(A,B)}")#text(" where ")#mi("{A, B}")#text(" are now dense subsets of the cells ")#mi("{V^{M_r}_i, V^{M_r}_j}")#text(". Nevertheless this weaker lemma is easier to prove and already illustrates many of the ideas.")

#text("Let’s now prove this lemma. Fix ")#mi("{\\epsilon > 0}")#text(", let ")#mi("{M}")#text(" be chosen later, let ")#mi("{G = (V,E)}")#text(" be a graph, and select ")#mi("{v_1,\\ldots,v_M}")#text(" at random. (There can of course be many vertices selected more than once; this will not bother us.) Let ")#mi("{A_t}")#text(" and ")#mi("{V^t_1,\\ldots,V^t_{2^t}}")#text(" be as in the above lemma. For notational purposes it is more convenient to work with the (random) ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}_t}")#text(" generated by the ")#mi("{A_1,\\ldots,A_t}")#text(" (i.e. the collection of all sets that can be formed from ")#mi("{A_1,\\ldots,A_t}")#text(" by boolean operations); this is an atomic ")#mi("{\\sigma}")#text("-algebra whose atoms are precisely the (non-empty) cells ")#mi("{V^t_1,\\ldots,V^t_{2^t}}")#text(" in the partition. Observe that these ")#mi("{\\sigma}")#text("-algebras are nested: ")#mi("{{\\mathcal B}_t \\subset {\\mathcal B}_{t+1}}")#text(".")

#text("We will use the ")#link("http://www.tricki.org/article/Turn_sets_into_functions")[#text("trick of turning sets into functions")]#text(", and view the graph as a function ")#mi("{1_E: V \\times V \\rightarrow {\\mathbb R}}")#text(". One can then form the ")#link("http://en.wikipedia.org/wiki/Conditional_expectation")[#text("conditional expectation")]#text(" ")#mi("{{\\Bbb E}(1_E | {\\mathcal B}_t \\times {\\mathcal B}_t ): V \\times V \\rightarrow {\\mathbb R}}")#text(" of this function to the product ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}_t \\times {\\mathcal B}_t}")#text(", whose value on ")#mi("{V^t_i \\times V^t_j}")#text(" is simply the average value of ")#mi("{1_E}")#text(" on the product set ")#mi("{V^t_i \\times V^t_j}")#text(". (When ")#mi("{i}")#text(" and ")#mi("{j}")#text(" are different, this is simply the edge density ")#mi("{d(V^t_i, V^t_j)}")#text("). One can view ")#mi("{{\\Bbb E}(1_E | {\\mathcal B}_t \\times {\\mathcal B}_t )}")#text(" more combinatorially, as a weighted graph on ")#mi("{V}")#text(" such that all edges between two distinct cells ")#mi("{V^t_i}")#text(", ")#mi("{V^t_j}")#text(" have the same constant weight of ")#mi("{d(V^t_i,V^t_j)}")#text(".")

#text("We give ")#mi("{V}")#text(" (and ")#mi("{V \\times V}")#text(") the uniform probability measure, and define the ")#emph[#text("energy")]#text(" ")#mi("{e_t}")#text(" at time ")#mi("{t}")#text(" to be the (random) quantity")

#align(center)[#tao-fit-display[#tao-math("e_t := \\left\\|{\\Bbb E}(1_E | {\\mathcal B}_t \\times {\\mathcal B}_t ) \\right\\|_{L^2(V \\times V)}^2 = \\frac{1}{\\left|V\\right|^2} \\sum_{v,w \\in V} {\\Bbb E}(1_E | {\\mathcal B}_t \\times {\\mathcal B}_t )^2.", block: true)]]

#text("one can interpret this as the mean square of the edge densities ")#mi("{d(V^t_i, V^t_j)}")#text(", weighted by the size of the cells ")#mi("{V^t_i, V^t_j}")#text(". From Pythagoras’ theorem we have the identity")

#align(center)[#tao-fit-display[#tao-math("e_{t^{\\prime}} = e_t + \\left\\| {\\Bbb E}(1_E | {\\mathcal B}_{t^{\\prime}} \\times {\\mathcal B}_{t^{\\prime}} ) - {\\Bbb E}(1_E | {\\mathcal B}_t \\times {\\mathcal B}_t ) \\right\\|_{L^2(V \\times V)}^2", block: true)]]

#text("for all ")#mi("{t^{\\prime}>t}")#text("; in particular, the ")#mi("{e_t}")#text(" are increasing in ")#mi("{t}")#text(". This implies that the expectations ")#mi("{{\\Bbb E} e_t}")#text(" are also increasing in ")#mi("{t}")#text(". On the other hand, these expectations are bounded between ")#mi("{0}")#text(" and ")#mi("{1}")#text(". Thus, if we select ")#mi("{1 \\leq t \\leq M}")#text(" at random, expectation of")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E} (e_{t+2} - e_{t})")]]

#text("telescopes to be ")#mi("{O(1/M)}")#text(". Thus, by Markov’s inequality, with probability ")#mi("{1-O(\\epsilon)}")#text(" we can freeze ")#mi("{v_1,\\ldots,v_t}")#text(" such that we have the conditional expectation bound ")#metadata(none) <tao-386a85d8c88778b00b13>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("{\\Bbb E}(e_{t+2} - e_t| v_1,\\ldots,v_t) = O( \\frac{1}{M\\epsilon} ).")]]

#text("Suppose ")#mi("{v_1,\\ldots,v_t}")#text(" have this property. We split")

#align(center)[#tao-fit-display[#mitex("1_E = f_{U^\\perp} + f_U")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("f_{U^\\perp} := {\\Bbb E}(1_E | {\\mathcal B}_t \\times {\\mathcal B}_t )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("f_U := 1_E - {\\Bbb E}(1_E | {\\mathcal B}_{t} \\times {\\mathcal B}_{t} ).")]]

#text("We now assert that the partition ")#mi("{V^{t}_1,\\ldots,V^{t}_{2^t}}")#text(" induced by ")#mi("{{\\mathcal B}_{t}}")#text(" obeys the conclusions of Lemma ")#link(<tao-7b343f11ada385c4d2eb>)[#text("3")]#text(". For this, we observe various properties on the two components of ")#mi("{1_E}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (")#mi("{f_{U^\\perp}}")#text(" is structured)")]#text(" ")#mi("{f_{U^\\perp}}")#text(" is constant on each product set ")#mi("{V^{t}_i \\times V^{t}_j}")#text(".")
]

#emph[#text("Proof:")]#text(" This is clear from construction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (")#mi("{f_U}")#text(" is pseudorandom)")]#text(" ")#metadata(none) <tao-a4d0ef23161b5b7c6a8d>#text(" The expression")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|V\\right|^4} \\sum_{v,w,v^{\\prime},w^{\\prime} \\in V} f_U(v,w) f_U(v,w^{\\prime}) f_U(v^{\\prime},w) f_U(v^{\\prime},w^{\\prime})", block: true)]]

#text("is of size ")#mi("{O( \\frac{1}{\\sqrt{M \\epsilon}} )}")#text(".")
]

#emph[#text("Proof:")]#text(" The left-hand side can be rewritten as")

#align(center)[#tao-fit-display[#tao-math("{\\Bbb E} \\frac{1}{\\left|V\\right|^2} \\sum_{v,w \\in V} f_U(v,w) f_U(v,v_{t+2}) f_U(v_{t+1},w) f_U(v_{t+1},v_{t+2}).", block: true)]]

#text("Observe that the function ")#mi("{(v,w) \\mapsto f_U(v,v_{t+2}) f_U(v_{t+1},w) f_U(v_{t+1},v_{t+2})}")#text(" is measurable with respect to ")#mi("{{\\mathcal B}_{t+2} \\times {\\mathcal B}_{t+2}}")#text(", so we can rewrite this expression as")

#align(center)[#tao-fit-display[#tao-math("{\\Bbb E} \\frac{1}{\\left|V\\right|^2} \\sum_{v,w \\in V} {\\Bbb E}(f_U|{\\mathcal B}_{t+2} \\times {\\mathcal B}_{t+2})(v,w) f_U(v,v_{t+2}) f_U(v_{t+1},w) f_U(v_{t+1},v_{t+2}).", block: true)]]

#text("Applying Cauchy-Schwarz, one can bound this by")

#align(center)[#tao-fit-display[#tao-math("{\\Bbb E} \\left\\|{\\Bbb E}(f_U|{\\mathcal B}_{t+2} \\times {\\mathcal B}_{t+2})\\right\\|_{L^2(V \\times V)}.", block: true)]]

#text("But from Pythagoras we have")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E}(f_U|{\\mathcal B}_{t+2} \\times {\\mathcal B}_{t+2})^2 = e_{t+2} - e_t")]]

#text("and so the claim follows from ")#link(<tao-386a85d8c88778b00b13>)[#text("(3)")]#text(" and another application of Cauchy-Schwarz. ")#mi("\\Box")

#text("Now we can prove Lemma ")#link(<tao-32528cb2558a284e5b40>)[#text("4")]#text(". Observe that")

#align(center)[#tao-fit-display[#tao-math("\\left|E \\cap (A \\times B)\\right| - \\sum_{i=1}^{2^t} \\sum_{j=1}^{2^t} d(V^t_i,V^t_j) \\left|A \\cap V^t_i\\right| \\left|B \\cap V^t_j\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("= \\sum_{v,w \\in V} 1_A(v) 1_B(w) f_U(v,w).")]]

#text("Applying Cauchy-Schwarz twice in ")#mi("{v, w}")#text(" and using Lemma ")#link(<tao-a4d0ef23161b5b7c6a8d>)[#text("6")]#text(", we see that the RHS is ")#mi("{O( (M\\epsilon)^{-1/8} )}")#text("; choosing ")#mi("{M \\gg \\epsilon^{-9}}")#text(" we obtain the claim.")

#heading(level: 1)[#strong[#text(" — 2. Strong regularity via random neighbourhoods — ")]]

#text("We now prove Lemma ")#link(<tao-7b343f11ada385c4d2eb>)[#text("3")]#text(", which of course implies Lemma ")#link(<tao-e150964f803cc374db1b>)[#text("2")]#text(".")

#text("Fix ")#mi("{\\epsilon > 0}")#text(" and a graph ")#mi("{G = (V,E)}")#text(" on ")#mi("{n}")#text(" vertices. We randomly select an infinite sequence ")#mi("{v_1, v_2, \\ldots \\in V}")#text(" of vertices in ")#mi("{V}")#text(", drawn uniformly and independently at random. We define ")#mi("{A_t, V^t_i, {\\mathcal B}_t}")#text(", ")#mi("{e_t}")#text(", as before.")

#text("Now let ")#mi("{m}")#text(" be a large number depending on ")#mi("{\\varepsilon > 0}")#text(" to be chosen later, let ")#mi("{F: {\\mathbb Z}^+ \\rightarrow {\\mathbb Z}^+}")#text(" be a rapidly growing function (also to be chosen later), and set ")#mi("{M_1 := F(1)}")#text(" and ")#mi("{M_r := 2(M_{r-1} + F(M_{r-1}))}")#text(" for all ")#mi("{1 \\leq r \\leq m}")#text(", thus ")#mi("{M_1 < M_2 < \\ldots < M_{m+1}}")#text(" grows rapidly to infinity. The expected energies ")#mi("{{\\Bbb E} e_{M_r}}")#text(" are increasing from ")#mi("{0}")#text(" to ")#mi("{1}")#text(", thus if we pick ")#mi("{1 \\leq r \\leq m}")#text(" uniformly at random, the expectation of")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E} e_{M_{r+1}} - e_{M_r}")]]

#text("telescopes to be ")#mi("{O(1/m)}")#text(". Thus, by Markov’s inequality, with probability ")#mi("{1-O(\\epsilon)}")#text(" we will have")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E} e_{M_{r+1}} - e_{M_r} = O( \\frac{1}{m\\epsilon} ).")]]

#text("Assume that ")#mi("{r}")#text(" is chosen to obey this. Then, by another application of the pigeonhole principle, we can find ")#mi("{M_{r+1}/2 \\leq t < M_{r+1}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E} (e_{t+2} - e_{t}) = O( \\frac{1}{m\\epsilon M_{r+1}} ) = O( \\frac{1}{m\\epsilon F(M_r)} ).")]]

#text("Fix this ")#mi("{t}")#text(". We have")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E} (e_{t} - e_{M_r}) = O( \\frac{1}{m\\epsilon} ),")]]

#text("so by Markov’s inequality, with probability ")#mi("{1-O(\\epsilon)}")#text(", ")#mi("{v_1,\\ldots,v_t}")#text(" are such that ")#metadata(none) <tao-b638e0f41576603b8130>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("e_{t} - e_{M_r} = O( \\frac{1}{m\\epsilon^2} )")]]

#text("and also obey the conditional expectation bound ")#metadata(none) <tao-0ab2dd2f64c9fd4e4310>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("{\\Bbb E}(e_{t+2} - e_t | v_1,\\ldots,v_t) = O( \\frac{1}{m\\epsilon F(M_r)} ).")]]

#text("Assume that this is the case. We split")

#align(center)[#tao-fit-display[#mitex("1_E = f_{U^\\perp} + f_{err} + f_U")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("f_{U^\\perp}  & := {\\Bbb E}(1_E | {\\mathcal B}_{M_r} \\times {\\mathcal B}_{M_r} )", block: true)



#tao-math("f_{err}  & := {\\Bbb E}(1_E | {\\mathcal B}_{t} \\times {\\mathcal B}_{t} ) - {\\Bbb E}(1_E | {\\mathcal B}_{M_r} \\times {\\mathcal B}_{M_r} )", block: true)



#tao-math("f_U  & := 1_E - {\\Bbb E}(1_E | {\\mathcal B}_{t} \\times {\\mathcal B}_{t} ).", block: true)
]

#text("We now assert that the partition ")#mi("{V^{M_r}_1,\\ldots,V^{M_r}_{2^{M_r}}}")#text(" induced by ")#mi("{{\\mathcal B}_{M_r}}")#text(" obeys the conclusions of Lemma ")#link(<tao-e150964f803cc374db1b>)[#text("2")]#text(". For this, we observe various properties on the three components of ")#mi("{1_E}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7 (")#mi("{f_{U^\\perp}}")#text(" locally constant)")]#text(" ")#mi("{f_{U^\\perp}}")#text(" is constant on each product set ")#mi("{V^{M_r}_i \\times V^{M_r}_j}")#text(".")
]

#emph[#text("Proof:")]#text(" This is clear from construction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8 (")#mi("{f_{err}}")#text(" small)")]#text(" ")#metadata(none) <tao-0f4e85d505e12bdf091d>#text(" We have ")#tao-math("{\\left\\| f_{err} \\right\\|_{L^2(V \\times V)}^2 = O( \\frac{1}{m\\epsilon^2} )}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" This follows from ")#link(<tao-b638e0f41576603b8130>)[#text("(4)")]#text(" and Pythagoras’ theorem. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9 (")#mi("{f_U}")#text(" uniform)")]#text(" ")#metadata(none) <tao-f38ea94cb7c1a2c9ddcb>#text(" The expression")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|V\\right|^4} \\sum_{v,w,v^{\\prime},w^{\\prime} \\in V} f_U(v,w) f_U(v,w^{\\prime}) f_U(v^{\\prime},w) f_U(v^{\\prime},w^{\\prime})", block: true)]]

#text("is of size ")#mi("{O( \\frac{1}{\\sqrt{m \\epsilon F(M_r)}} )}")#text(".")
]

#emph[#text("Proof:")]#text(" This follows by repeating the proof of Lemma ")#link(<tao-a4d0ef23161b5b7c6a8d>)[#text("6")]#text(", but using ")#link(<tao-0ab2dd2f64c9fd4e4310>)[#text("(5)")]#text(" instead of ")#link(<tao-386a85d8c88778b00b13>)[#text("(3)")]#text(". ")#mi("\\Box")

#text("Now we verify the regularity.")

#text("First, we eliminate ")#emph[#text("small atoms")]#text(": the pairs ")#mi("{(V_i,V_j)}")#text(" for which ")#tao-math("{\\left|V^{M_r}_i\\right| \\leq \\epsilon \\left|V\\right| / 2^{M_r}}", block: false)#text(" clearly give a net contribution of at most ")#tao-math("{O( \\epsilon \\left|V\\right|^2 )}", block: false)#text(" and are acceptable; similarly for those pairs for which ")#tao-math("{\\left|V^{M_r}_j\\right| \\leq \\epsilon \\left|V\\right| / 2^{M_r}}", block: false)#text(". So we may henceforth assume that ")#metadata(none) <tao-9f5e6240d4d53fbda5ef>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|V^{M_r}_i\\right|, \\left|V^{M_r}_j\\right| \\leq \\epsilon \\left|V\\right| / 2^{M_r}.", block: true)]]

#text("Now, let ")#mi("{A \\subset V^{M_r}_i}")#text(", ")#mi("{B \\subset V^{M_r}_i}")#text(" have densities")

#align(center)[#tao-fit-display[#tao-math("\\alpha := \\left|A\\right|/\\left|V^{M_r}_i\\right| \\ge \\epsilon; \\beta := \\left|B\\right|/\\left|V^{M_r}_j\\right| \\geq \\epsilon,", block: true)]]

#text("then")

#align(center)[#tao-fit-display[#tao-math("\\alpha \\beta d(A,B) = \\frac{1}{\\left|V^{M_r}_i\\right| \\left|V^{M_r}_j\\right|} \\sum_{v \\in V^{M_r}_i} \\sum_{w \\in V^{M_r}_i} 1_A(v) 1_B(w) 1_E(v,w).", block: true)]]

#text("We divide ")#mi("{1_E}")#text(" into the three pieces ")#mi("{f_{U^\\perp}}")#text(", ")#mi("{f_{err}}")#text(", ")#mi("{f_U}")#text(".")

#text("The contribution of ")#mi("{f_{U^\\perp}}")#text(" is exactly ")#mi("{\\alpha \\beta d(V^{M_r}_i, V^{M_r}_j)}")#text(".")

#text("The contribution of ")#mi("{f_{err}}")#text(" can be bounded using Cauchy-Schwarz as")

#align(center)[#tao-fit-display[#tao-math("O( \\frac{1}{\\left|V^{M_r}_i\\right| \\left|V^{M_r}_j\\right|} \\sum_{v \\in V^{M_r}_i} \\sum_{w \\in V^{M_r}_i} \\left|f_{err}(v,w)\\right|^2)^{1/2}.", block: true)]]

#text("Using Lemma ")#link(<tao-0f4e85d505e12bdf091d>)[#text("8")]#text(" and Chebyshev’s inequality, we see that the pairs ")#mi("{(V_i,V_j)}")#text(" for which this quantity exceeds ")#mi("{\\epsilon^3}")#text(" will contribute at most ")#mi("{\\epsilon^{-8}/m}")#text(" to ")#link(<tao-667937c3e7a68ea37471>)[#text("(1)")]#text(", which is acceptable if we choose ")#mi("{m}")#text(" so that ")#mi("{m \\gg \\epsilon^{-9}}")#text(". Let us now discard these bad pairs.")

#text("Finally, the contribution of ")#mi("{f_U}")#text(" can be bounded by two applications of Cauchy-Schwarz and ")#link(<tao-f38ea94cb7c1a2c9ddcb>)[#text("(9)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("O( \\frac{\\left|V\\right|^2}{\\left|V^{M_r}_i\\right| \\left|V^{M_r}_j\\right|} \\frac{1}{(m \\epsilon F(M_r))^{1/8}} )", block: true)]]

#text("which by ")#link(<tao-9f5e6240d4d53fbda5ef>)[#text("(6)")]#text(" is bounded by")

#align(center)[#tao-fit-display[#mitex("O( 2^{2M_r} \\epsilon^{-2} / (m \\epsilon F(M_r) )^{1/8} ).")]]

#text("This can be made ")#mi("{O(\\epsilon^3)}")#text(" by selecting ")#mi("{F}")#text(" sufficiently rapidly growing depending on ")#mi("{\\epsilon}")#text(". Putting this all together we see that")

#align(center)[#tao-fit-display[#mitex("\\alpha \\beta d(A,B) = \\alpha \\beta d(V^{M_r}_i, V^{M_r}_j) + O(\\epsilon^3)")]]

#text("which (since ")#mi("{\\alpha,\\beta \\geq \\epsilon}")#text(") gives the desired regularity.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Of course, this argument gives tower-exponential bounds (as ")#mi("{F}")#text(" is exponential and needs to be iterated ")#mi("{m}")#text(" times), which will be familiar to any reader already acquainted with the regularity lemma.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can take the partition induced by random neighbourhoods here and carve it up further to be both equitable and (mostly) regular, thus recovering a proof of Lemma 1, by following the arguments ")#link("http://front.math.ucdavis.edu/math.CO/0504472")[#text("in this paper of mine")]#text(". Of course, when one does so, one no longer has a partition created purely from random neighbourhoods, but it is pretty clear that one is not going to be able to make an equitable partition just from boolean operations applied to a few random neighbourhoods.")
]

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09b97ca7c63bafa95fd8dbb091b07ad533a1ca840e92d20731d312fbf609330b-9ad9b23ab63f41fada64fee884506e022806b7050678e652b8e96ab920611101.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Asaf")]], [#link("https://terrytao.wordpress.com/2009/04/26/szemeredis-regularity-lemma-via-random-partitions/#comment-38378")[#strong[#text("Asaf")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("Hi Terry,")

#text("Such an O(n) algorithm appears (explicitly) in the following paper of mine with Fischer and Matsliach.")

#link("http://www.cs.tau.ac.il/~asafico/regalg.pdf")[#text("Click to access regalg.pdf")]

#text("That algorithm actually has the added advantage of being able to find (more or less) the smallest regular partition in the input.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/26/szemeredis-regularity-lemma-via-random-partitions/#comment-38382")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("Dear Asaf: thanks for the reference! It again seems to be slightly different from the random neighbourhoods algorithm (which is a O(1) algorithm rather than O(n), but only defines the partition implicitly and does not make it equitable) but certainly in the same spirit.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3ede877c9ec0a22f03904360774c2ae83d23284b0d2355811492cfb9b2eb605-179e19a2a807416d602ace8efd542d44721e85b13ce0360a63d27a913df153ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anup")]], [#link("https://terrytao.wordpress.com/2009/04/26/szemeredis-regularity-lemma-via-random-partitions/#comment-38412")[#strong[#text("Anup")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("Hi Terry, for Lemma 2, do you want to allow i=j in the sum?")

#text("Otherwise it seems that partitioning the graph into one part V1 = V, would trivially satisfy the conclusions of the lemma.")

#emph[#text("[Hmm, you’re right. Thanks for the correction! – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Szemeredi’s regularity lemma via the correspondence principle « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/26/szemeredis-regularity-lemma-via-random-partitions/#comment-38652")[#strong[#text("Szemeredi’s regularity lemma via the correspondence principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2009")])]

#text("[…] math.PR | Tags: correspondence principle, szemeredi regularity lemma | by Terence Tao In a previous post, we discussed the Szemerédi regularity lemma, and how a given graph could be regularised by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Moser’s entropy compression argument « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/26/szemeredis-regularity-lemma-via-random-partitions/#comment-40844")[#strong[#text("Moser’s entropy compression argument « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2009")])]

#text("[…] is often referred to as the “index”). These examples are related; see this blog post for further discussion. The general strategy here is to keep looking for useful pieces of energy […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/04/26/szemeredis-regularity-lemma-via-random-partitions/#comment-118236")[#strong[#text("Szemerédi’s regularity lemma « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2011")]

#text("[…] the book The probabilistic method of Alon and Spencer, the survey of Komlós and M. Simonovits and Tao’s perspective via random partitions. Merry Christmas!! Share this:TwitterLike this:LikeBe the first to like this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The spectral proof of the Szemeredi regularity lemma « What’s new")]], [#link("https://terrytao.wordpress.com/2009/04/26/szemeredis-regularity-lemma-via-random-partitions/#comment-199141")[#strong[#text("The spectral proof of the Szemeredi regularity lemma « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2012")])]

#text("[…] proofs of this lemma, which is actually not that difficult to establish; see for instance these previous blog posts for some examples. In this post I would like to record one further proof, based on the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fabc6092a391d9eccbe8534b670d3452bc51cc8417de77dfd4c50f2b91852144-3a5c1558b3882c8d711f921945cedd4e21244ac8b94f0c98ecbc793c6fa95022.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of deep")]], [#link("https://terrytao.wordpress.com/2009/04/26/szemeredis-regularity-lemma-via-random-partitions/#comment-356633")[#strong[#text("deep")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2014")])]

#text("Hi Terry,")

#text("I wanted to make sense of Szemerédi regularity lemma (SRL) for Erdős–Rényi random graph G(n,p).")

#text("If I understood correctly the SRL states that any random dense graph (the adjacency matrix) can be “approximately” partitioned into block-diagonal structures (after proper rearrangement) .")

#text("Lets generate G(n=10000,p=.1), a dense random network butthe corresponding adjacency matrix A it can NOT be represented as a block-diagonal form (whatever rearrangement we do). Then my question is, how to interpret SRL in thisset-up ? What I’m missing ?")

#text("Thank you so much for your time and apology for my ignorance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/26/szemeredis-regularity-lemma-via-random-partitions/#comment-357108")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2014")])]

#text("Actually, the regularity lemma asserts (roughly speaking) that any dense graph can be approximately partitioned, after rearrangement, into blocks, in which the graph behaves like a ")#emph[#text("random")]#text(" graph in each block (of some density p which need not be 0 or 1, but can also be something in between). So, if one starts with an Erdős–Rényi graph, one is already done: we only need one block, because the graph already exhibits random behaviour in that block.")

#text("To put it another way, the regularity lemma tells us that every large dense adjacency matrix is in some sense a “combination” of a bounded rank matrix (which divides up into a bounded number of blocks) and a random matrix; the “block-diagonal” matrices and the Erdős–Rényi matrices reflect the two possible extremes of behaviour, and every other graph is in some sense a mixture of these two extremes.")
]
]
