// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/10/16/snap-preview/
// Converted to Typst by tao2typ: "2026-10-14T16:35:03.673622+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Snap preview?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Snap preview?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 October 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/")[#text("https://terrytao.wordpress.com/2007/10/16/snap-preview/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("As you may have noticed, I had turned off the “")#link("http://faq.wordpress.com/2007/01/26/snap-preview-anywhere/")[#text("Snap preview")]#text("” feature on this blog (which previews any external link that the mouse hovers over) for a few weeks as an experiment. After a mixed response, I have decided to re-enable the feature for now, but would be interested in getting feedback on whether this feature makes noticeable differences (both positive and negative) to the viewing experience (in particular, to the loading time of the web page), so that I can decide whether to permanently re-enable it. (In the link above, incidentally, it is noted that one can turn off all snap preview windows by following an options link to set a cookie.)")

#text("This post would also be a good forum to discuss any other formatting and presentation issues with this blog (wordpress blogs are remarkably customisable). For instance, I have been looking out for a way to enable previewing of comments, but as far as I can tell this appears to not be possible on wordpress. But if anyone knows some workaround or substitute for this feature, I would like to hear about it.")

#text("[")#emph[#text("Update")]#text(", Oct 17: Judging from the comments, the response to Snap preview continues to be mixed. But I have discovered ")#link("http://www.snap.com/about/shots_faq.php")[#text("how to turn Snap preview on and off for individual articles or links")]#text(". So I will keep Snap preview on for Wikipedia links and off for the rest; see the articles currently in the front page of this blog for examples of this. I also note that in the Snap preview options menu, there are options to turn Snap off permanently, or to increase the delay before the preview shows up.")

#text("Also, following suggestions in the comments, I have darkened the text and also changed the blockquote format, in order to increase readability, and also changed the RSS feed from summaries to the full article (or more precisely, the portion of the article before the jump). ]")

#text("[")#emph[#text("Update")]#text(", Oct 18: Comments moved to just below the post, as opposed to below the sidebar.]")

#heading(level: 1)[#text("Comments (39)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec07bf3eb7d5f74df41531b1fa1bcd5107ff184bb1b563247b130fc591c49d7-7fd6f55baeb7909e9e24eb483c9fefa1b3f64df6363292101c1c521ed794cf0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Bergman")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12042")[#strong[#text("Aaron Bergman")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Snap is evil. I don’t know about page loading times, but often when I see a link, I want to see the address that it leads to, and snap instead puts up this ugly window that obscurses the text. Also, just randomly moving the mouse around can trigger these windows which again obscure the text. Is there really any use for small unreadable previews of pages?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12044")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Is it possible to configure things so that previews, like tooltips, only appear after a short delay? (This should in fact be something that could be implemented as a Firefox plugin, for instance, which would make it user-configurable, but unfortunately I have no experience doing this to try myself…).")

#text("For what it’s worth, it doesn’t seem to me that the previews are particularly bad in terms of page-load time; I’ve just looked at how long it takes (for me, i.e., from France) to load a fairly big page (“The quantitative behavior of polynomial orbits…”) using another nice Firefox plugin which gives precise timing data for every network connection required for a given page (it’s called Firebug), and it took 14.73 s, with 84 network requests, for a total of 109 kb, and it seems about 10s are due to the LaTeX images. Then a typical snap takes usually between 1s and 2s to load. (But this is only one test, so maybe to take with caution…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d707a7232d544292227e6c17fcb9cd17b598f1724070621f5c8eec56b6135102-a3ac8e32c47df3e2b4e9b1f672ea79b7ed3262754491a2810e1fa51eb3101b98.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kenny")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12045")[#strong[#text("Kenny")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("That’s generally been my thought about the snap preview as well. There have been one or two times when it was nice to see what sort of page was on the other side, but generally, it just blocks the text or slows things down when I just want to see what address a link goes to.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jukka Suomela")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12052")[#strong[#text("Jukka Suomela")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("The option to disable Snap Previews does not seem to work on the Konqueror web browser. Unfortunately, the annoying preview popups do work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12057")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Jukka, try to clear your cache (not cookies!) and it should work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fec6cda624d52107a9ca52311a6e3b3cad0f6434789ff44cfdc285b2e0ffb7f-f83f3bcd84fabb4e452d15e87221de7935af17d8fcb74d23c84019c0917a31af.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of carlbrannen")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12060")[#strong[#text("carlbrannen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("No to snap previews. Yes to changing your text colors so that text comes out darker. I also ")#link("http://carlbrannen.wordpress.com/")[#text("use WordPress")]#text(", and for my eyes black text makes it easier to read. You do it using css. I’ve saved a copy of ")#link("http://brannenworks.com/css.txt")[#text("my css here")]#text(", which you are free to use or modify.")

#text("Maybe it’s just my old eyes. When I was a student 30 years ago I used mechanical pencils. Now I wonder how the heck my professors were able to read it. I only use gel pens that write thick black lines now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KenF")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12061")[#strong[#text("KenF")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("I don’t find that it makes the page load any slower, I am on a cable modem. However, I think it’s extremely annoying. Those types of previews are useful if you’re linking out to graphically interesting or unusual websites, but often you link to wikipedia-type sites, and there’s not much to be gained by the preview I don’t think.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reid")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12062")[#strong[#text("Reid")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Another vote for no to snap preview. Quite frankly, I find them one of the worst ideas currently mass implemented on the web today. If I want to see what’s on that link, I’ll click on it. Not try to read some tiny (pretty much) unreadable text. Not to mention that these things pop up when I scroll the page with arrow keys as the (then invisible) mouse becomes overtop of them. Quite irritating.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91841f5e59201923e09be98a5cf5917591fef164a2a040b79e78d927874dd4bf-c2c4379bfc95793e545279b1b6a44f80c80394352dfb8cc2ea2a9f97264ce0e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12065")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Yes to snap preview. i’ve really been missing it!")

#text("In response to KenF: My opinion is precisely the opposite. It’s the fact that Dr. Tao so often links to Wikipedia articles that makes snap so useful for his site. All you have to do is hover over the link to get the definition of some mathematical term, rather than having to actually go to the Wikipedia article and then come back here. By contrast, if the website were “grapically interesting or unusual”, then you might actually want to visit it!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d2cb98afc456143a6d50e9caabab8d3b220b0d50a1e9805ff77e64f7055e783-e663fb21e8a09a4960c654a15b8f1d3daf71d0ae93f1c6b2200c00d04e0490e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mattheath")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12067")[#strong[#text("mattheath")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Yes to snap. It is annoying on most blogs but great for maths, for more or less the reasons anonymous gave above. It makes it much easier to get the sense of a post if you can read definitions and statements ofknown results without opening a stack of tabs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12068")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Hi Terrence,")

#text("I all too often make speculative comments that seem insightful to me but are not mathematically rigorous.")

#text("I would not be offended if you simply delete those comments that you consider inappropriate.")

#text("I prefer what Urs Schreiber and John Baez at n-category cafe sometimes do, send me an e-mail simply stating the reason for deleting a comment of mine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b0af042bf9b8c6afe3fb307f953857727093f6db41dd13a04c13db4366cc0572-8eb4d1511733286836c9547eec439829a3d38ec528b2a29183ae61577026f105.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12071")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("No to snap preview. I can’t read those small letters.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f15187f7e44a1e4d467cafafbc13d0aa45c91292e4f729020bd9ba8362d49bce-9c7c7f41d44bf40e0cea7adfa6992c84d0842e868cb1cf8ddb374d63968fec3e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alex")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12076")[#strong[#text("alex")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Another vote for no on snap. Extremely annoying to have these things pop up when you move the mouse randomly around the page.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12081")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Another vote No.")

#text("I had to update my edition of Internet Explorer because a simple mouseover a snap preview would close the window.")

#text("It appears that its a small convenience to those who favor it and a huge inconvenience to those who do not.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12082")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Yes to Snap, but only for Wikipedia definitions. Ironically, I was just pointing your blog out to a friend as the one truly useful application of Snap, only to see that you’d turned it off!")

#text("For what it’s worth, I’m on a super-fast connection.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12086")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("I just want to add that snap or not, your blog is fantastic. You could change the formatting to 6 point pink type on a gray background and it would still be one of my favorite reads.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ARS")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12089")[#strong[#text("ARS")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("I vote a definite NO on Snap preview. I find it really annoying and useless on small (laptop) screens.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6051968dfec036d86618db45c42c6cbbf2ee7e50d7716270239aa55a888fcfc-23faae9ac5d7cf1e536a82c5f937683d3f58daf9b1d59500ea2dab4971582bbf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chi")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12091")[#strong[#text("Chi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("I would like a full RSS feed, instead of truncated articles. In fact, having just subscribed this afternoon, I will most likely unsubscribe if it’s unavailable–opening a new tab just really slows you down.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of david")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12092")[#strong[#text("david")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Just say No to Snap!")

#text("I can’t disable Snap, either, which is odd. Firefox 2.0.0.7 on Vista, anybody else seeing this happening? Cleared cache and all that jazz already.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0061af294523e8f94760b71e89c75ee705e544641460f871625488e690ce10fe-12b466ba4777c9e622b91b2a713def2b6ca27814859ea6628d7a7bed55305f97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12093")[#strong[#text("Andy")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("YES vote to snap review! It helps to get a quick idea of some concepts without opening tens of windows for each.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12094")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Yes to snap. I find snap useful when the link is to a definition. Given the mixed views on the feature, it seems that it should be an option that can be turned on or off by the individual reader, rather than the author. But this is a criticism of WordPress rather than our host. A preview widow like snap should perhaps be a feature of a browser rather than a website.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robbie")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12098")[#strong[#text("Robbie")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("The Snap pop-ups used to annoy me greatly. But I recently installed the NoScript plugin for Firefox and haven’t been hassled by Snap since!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12110")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("I hate snap more than just about anything currently found on the web. I tend to move my mouse around aimlessly as I read, and then these… THINGS… pop up over the text I’m reading. I don’t think they make anything slower, but they take so long to disappear, and are certainly not readable in the form in which they appear. And if you have several of them in close proximity, it’s just a comedy of errors trying to mouse away and actually read the post.")

#text("But now I know that NoScript plugin exists. I will install and be snap free, whatever you decide to do with the blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/340b02c273c5b762ff2704091fce6f317819b3440b136110b95ea352717e322c-46821a9b29edbf3b5aa0be1b839f1a6b362cca6dae8eb473253ecab327ad0209.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Radu Grigore")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12114")[#strong[#text("Radu Grigore")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Thanks for the hint on how to disable SnapPreview for my browser! The previews were rather annoying and contributed to my habit of printing your entries instead of reading from the browser. I really like the way the printed version looks different than the web version.")

#text("I have a good connection and I do not see any difference in loading times.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f427b2adbbafe637bc7ad05749cf67514f71ab6967eabb4a8f3796a19a52261-f6a680c04c34d61a608dd62a36e4ec4eb26fe2f1a6051efa9aa4bbde812b6ec4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12145")[#strong[#text("Robert")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2007")])]

#text("Hi,")

#text("from my side it’s a clear no to SnapPreview as the preview windows keep popping up when I don’t expect them and block the view to the text I am actually interested in.")

#text("The people at Cosmic Variance ")#link("http://www.cosmicvariance.com")[#text("http://www.cosmicvariance.com")]#text(" also use wordpress and have comment preview turned on. Maybe you could ask them how to do it.")

#text("Robert")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/840b199a83d7295ea582992e39f1a94c237f34083391cc73671ab1b0ed4dcbee-991a3e5bd1eadee007dca75de89d4dbf21ed0d69a661edac7626cf586be847f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Cook")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12150")[#strong[#text("James Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2007")])]

#text("I’ve already weighed in with my support for the Snap preview feature, but I’d like to comment on some of the complaints about it. To me, the fact that windows pop up when you weren’t expecting them is a very minor annoyance, as compared with, say, having to repeatedly click the “Back” button from Wikipedia pages and find where you were in the text of the post. After all, in order to avoid the former “problem”, all you have to do is position the cursor appropriately. In any case, you can instantly make a Snap window disappear by clicking outside the window. So this kind of complaint is hardly grounds for disabling the feature.")

#text("I suspect that a lot of the people who are complaining about Snap do not often need to click on the links, especially the ones having to do with more elementary mathematical terms. Consequently, they may be underestimating the convenience provided by these previews to readers with less advanced backgrounds, or those less familiar with the subject of the post. But Terry’s posts can be very useful to such readers (I have been in this category on a number of occasions) and the Snap previews really make a difference in facilitating the reading process.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec07bf3eb7d5f74df41531b1fa1bcd5107ff184bb1b563247b130fc591c49d7-7fd6f55baeb7909e9e24eb483c9fefa1b3f64df6363292101c1c521ed794cf0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Bergman")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12155")[#strong[#text("Aaron Bergman")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2007")])]

#emph[#text("as compared with, say, having to repeatedly click the “Back” button from Wikipedia pages and find where you were in the text of the post.")]

#text("Tabbed browsing is your friend.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12164")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2007")])]

#text("yea, upgrade to IE7 and use middle button to open a new tab.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DeadWolfe")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12183")[#strong[#text("DeadWolfe")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2007")])]

#text("I find having the snap preview pop up when I’m not expecting it to be very annoying.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90937f079c1eaffcb9571b53f2e46cb5a3bd41ea9174f697900e77ef015239bd-01862ec3a317f15757be0d68b14043cd7970aca4f7cf5fab898d3c7562946fa4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Torbjörn Larsson, OM")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12184")[#strong[#text("Torbjörn Larsson, OM")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2007")])]

#text("Previews of definitions saves time or increase reader value, and the added hassle can be circumvented. The rest is better viewed in tabbed browsing.")

#text("Format suggestion: The comments appear below the last item on the long left frame. (At least in my Firefox browser.) For short posts that means a search to read the page.")

#text("Perhaps a more ‘readable’ format or a navigation shortcut could be found?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e833b6f6241ea9335c528e96292a69094230e53202fc077f499cafb5def22092-8afd75c92ea211cfec1d98c1820c7d42c47f83778b4a669040ed9d022f045f32.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Welford")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12262")[#strong[#text("Michael Welford")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2007")])]

#text("This is a pretty emphatic no to Snap.")

#text("In response to James Cook, I do follow the links often. Opera browser shows me a URL. Then I can decide whether to open in a new tab and whether to put the new tab in background.")

#text("I have the new tab created adjacent to the current tab, but for the life of me I couldn’t tell you how I turned that option on.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reid")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12292")[#strong[#text("Reid")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2007")])]

#text("@Dr. Tao:")

#text("I don’t know what else you changed, but the comment form isn’t displaying properly in Safari any more (I’m writing this from an old Firefox install). It seems to be only displaying the first 2 characters of the input boxes, etc and the rest is just as if a blank white page is present. But, the mouse still reacts as though they’re there in the white area. Anyone else experiencing this?")

#text("@James Cook:")

#text("Several points:")

#text("– It is your /opinion/ that such arguments don’t hold water. But, that would imply that you have the power to determine what other people find (in)significant and at what level or at least be able to judge when or not this is so (again, for other people). Point of fact, you don’t have this ability. It is also quite foolish to say this when people are saying the exact opposite. You want to post your opinion, great. That’s what this was all about. But, don’t speak as if you’re some authority on the matter, when you are very very far from it.")

#text("– You’re assuming that the preview can be read which is *not* the case in most cases that I’ve been forced to be exposed to as others have commented on as well. And the cases where I could make out the text, there wasn’t nearly enough displayed to make it even remotely useful. Basically, bad assumption. Not all of us have superman vision nor high enough resolution on our monitors that would be required for even the possibility.")

#text("– I like to run the mouse along the line that I am reading from time to time. This is especially so when I’m tired. But, it’s rather hard to do that when I have to mind a minefield of popups as I go.")

#text("– You don’t want to be exposed to the back button (i.e. web browsing): right click the link and open in a new window or tab. This can be made easier as other posters have pointed out. This would give an actual clean web page, giving /the/ /user/ the option on how do deal with the link.")

#text("Basically, while this feature irritates many here and as such its remove would benefit many. On the other hand, the work around for others is trivial and is as simple as web browsing like people have been doing for… how long now.")

#text("But, a decision has already been made. Perhaps one of these days, I’ll write a little something that will disable it totally client side without having to deal with the shotgun approach that is NoScript. Not to mention for Safari. *sigh*")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12383")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2007")])]

#text("Dear Reid,")

#text("I cannot duplicate what you report on IE or Firefox (I don’t have access to Safari). I will probably have to wait for more data before being able to do much about it.")

#text("Incidentally, is the option within the Snap preview window to disable it permanently not working in some browsers? I tested it in IE and it seems to work fine.")

#text("Finally, just a reminder to everyone to keep the discussion constructive and polite; in particular, a focus on technical solutions or compromises would be particularly valuable for me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90937f079c1eaffcb9571b53f2e46cb5a3bd41ea9174f697900e77ef015239bd-01862ec3a317f15757be0d68b14043cd7970aca4f7cf5fab898d3c7562946fa4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Torbjörn Larsson, OM")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12417")[#strong[#text("Torbjörn Larsson, OM")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2007")])]

#text("Snap is turned off in this post on my Firefox (latest update).")

#text("If it is a problem in other browsers, I suggest loosing it, as the gain isn’t much or nothing depending on reader. (At least until the provider fixes such issues.)")

#text("The “new tab adjacent” effect of Michael’s Opera demands installing an add-on in Firefox. (For example the “Tabs Open Relative”.) I can recommend it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90937f079c1eaffcb9571b53f2e46cb5a3bd41ea9174f697900e77ef015239bd-01862ec3a317f15757be0d68b14043cd7970aca4f7cf5fab898d3c7562946fa4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Torbjörn Larsson, OM")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12418")[#strong[#text("Torbjörn Larsson, OM")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2007")])]

#text("Oh, sorry, you asked about permanent disabling. Yes, it works too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e31c963e3e71ae38a9369563c1b283f9e5ae4d4855184c2f2b880cd48f2db1-876438d6769516fcac275b098aec1b440b21201ceee20a077964a6a40ed71eae.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YourBiggestFan")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12470")[#strong[#text("YourBiggestFan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2007")])]

#text("Quoting ")#emph[#text("“I have been looking out for a way to enable previewing of comments, but as far as I can tell this appears to not be possible on wordpress.”")]

#text("When people say “wordpress”, it means one of two things:")#linebreak()#text(" * The blog-publishing software WordPress, which is Free Software and can be installed anywhere you want: see ")#link("http://wordpress.org/")[#text("wordpress.org")]#linebreak()#text(" * The website wordpress.com, which runs this software and uses it to host blogs for free.")

#text("Blogs on the WordPress.com site come with a limited set of features (but you should ask them about comment preview; maybe if enough people ask they’ll finally include it…) A self-hosted WordPress blog is more configurable, but then you have to worry about hosting and maintenance which might take time away from the more important things in life :)")

#text("See ")#link("http://faq.wordpress.com/2006/05/07/wordpresscom-vs-wordpressorg/")[#text("the comparison")]#text(" here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-12660")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2007")])]

#text("sir, which size you write small, medium, justbig.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-13471")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2007")])]

#text("I use a tabbed browser where clicking the middle mouse button opens the link in a new tab ‘in the background’. So I’d prefer getting rid of the annoying preview popup completely. The previews might be more useful for those stuck with non-tabbed browsers. thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/#comment-32376")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2008")])]

#text("I really hate Snap and found this thread with the idea of urging you to turn it off (which I still hope you do) but it’s interesting that there are some technical workarounds. Note that setting a cookie won’t help me much since I clear all my cookies when I close my browser, and anyway cookies tend to be accompanied by evil web beacons. But I may try some of the other remedies suggested. Right now I use the Mozilla prefbar to turn off Javascript whenever I viist your site, which is a big pain.")

#text("James Cook: get a modern browser with tabs and you won’t have to deal with the back button any more.")
]
