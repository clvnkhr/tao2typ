// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/10/16/snap-preview/
// Converted to Typst by tao2typ: "2026-10-16T11:40:34.695926+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Snap preview?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Snap preview?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 October 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/")[#text("https://terrytao.wordpress.com/2007/10/16/snap-preview/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-16 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("As you may have noticed, I had turned off the “")#link("http://faq.wordpress.com/2007/01/26/snap-preview-anywhere/")[#text("Snap preview")]#text("” feature on this blog (which previews any external link that the mouse hovers over) for a few weeks as an experiment. After a mixed response, I have decided to re-enable the feature for now, but would be interested in getting feedback on whether this feature makes noticeable differences (both positive and negative) to the viewing experience (in particular, to the loading time of the web page), so that I can decide whether to permanently re-enable it. (In the link above, incidentally, it is noted that one can turn off all snap preview windows by following an options link to set a cookie.)")

#text("This post would also be a good forum to discuss any other formatting and presentation issues with this blog (wordpress blogs are remarkably customisable). For instance, I have been looking out for a way to enable previewing of comments, but as far as I can tell this appears to not be possible on wordpress. But if anyone knows some workaround or substitute for this feature, I would like to hear about it.")

#text("[")#emph[#text("Update")]#text(", Oct 17: Judging from the comments, the response to Snap preview continues to be mixed. But I have discovered ")#link("http://www.snap.com/about/shots_faq.php")[#text("how to turn Snap preview on and off for individual articles or links")]#text(". So I will keep Snap preview on for Wikipedia links and off for the rest; see the articles currently in the front page of this blog for examples of this. I also note that in the Snap preview options menu, there are options to turn Snap off permanently, or to increase the delay before the preview shows up.")

#text("Also, following suggestions in the comments, I have darkened the text and also changed the blockquote format, in order to increase readability, and also changed the RSS feed from summaries to the full article (or more precisely, the portion of the article before the jump). ]")

#text("[")#emph[#text("Update")]#text(", Oct 18: Comments moved to just below the post, as opposed to below the sidebar.]")

#heading(level: 1)[#text("Comments (39)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac9a3b5ce168efe151be229fd1c70f56199e25efc2a850541c1244932656c79-676aa09eb0d103533022e83fec0e8da28889b165fbfd3be9835fe1aeb2f9d9b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Bergman")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12042")[#strong[#text("Aaron Bergman")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Snap is evil. I don’t know about page loading times, but often when I see a link, I want to see the address that it leads to, and snap instead puts up this ugly window that obscurses the text. Also, just randomly moving the mouse around can trigger these windows which again obscure the text. Is there really any use for small unreadable previews of pages?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7595800f8aaec05abbde1079275054014e54ea216e65ce5cbd604a7e81076728-e9b102194154ab6c32cc100a0107c2c8b3a35b8a364cbac2796040458df785f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12044")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Is it possible to configure things so that previews, like tooltips, only appear after a short delay? (This should in fact be something that could be implemented as a Firefox plugin, for instance, which would make it user-configurable, but unfortunately I have no experience doing this to try myself…).")

#text("For what it’s worth, it doesn’t seem to me that the previews are particularly bad in terms of page-load time; I’ve just looked at how long it takes (for me, i.e., from France) to load a fairly big page (“The quantitative behavior of polynomial orbits…”) using another nice Firefox plugin which gives precise timing data for every network connection required for a given page (it’s called Firebug), and it took 14.73 s, with 84 network requests, for a total of 109 kb, and it seems about 10s are due to the LaTeX images. Then a typical snap takes usually between 1s and 2s to load. (But this is only one test, so maybe to take with caution…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4959804f38151a5b8099efd3f60190588938b8aa4ec729e5c3841e4e1c7f52e7-4265100485b311ca6453d44140ba92fe18c35f834f455bc8086e45bdec785f5f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kenny")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12045")[#strong[#text("Kenny")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("That’s generally been my thought about the snap preview as well. There have been one or two times when it was nice to see what sort of page was on the other side, but generally, it just blocks the text or slows things down when I just want to see what address a link goes to.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jukka Suomela")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12052")[#strong[#text("Jukka Suomela")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("The option to disable Snap Previews does not seem to work on the Konqueror web browser. Unfortunately, the annoying preview popups do work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12057")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Jukka, try to clear your cache (not cookies!) and it should work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32e47f968bce0347e828399fe4058359695f4ef5b42061a1d4bed44cdee655a7-42fe4a93f51198f781aaf0dd5e3092819cb9b26974e3e0b7fc743f11063f52b2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of carlbrannen")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12060")[#strong[#text("carlbrannen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("No to snap previews. Yes to changing your text colors so that text comes out darker. I also ")#link("http://carlbrannen.wordpress.com/")[#text("use WordPress")]#text(", and for my eyes black text makes it easier to read. You do it using css. I’ve saved a copy of ")#link("http://brannenworks.com/css.txt")[#text("my css here")]#text(", which you are free to use or modify.")

#text("Maybe it’s just my old eyes. When I was a student 30 years ago I used mechanical pencils. Now I wonder how the heck my professors were able to read it. I only use gel pens that write thick black lines now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KenF")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12061")[#strong[#text("KenF")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("I don’t find that it makes the page load any slower, I am on a cable modem. However, I think it’s extremely annoying. Those types of previews are useful if you’re linking out to graphically interesting or unusual websites, but often you link to wikipedia-type sites, and there’s not much to be gained by the preview I don’t think.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reid")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12062")[#strong[#text("Reid")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Another vote for no to snap preview. Quite frankly, I find them one of the worst ideas currently mass implemented on the web today. If I want to see what’s on that link, I’ll click on it. Not try to read some tiny (pretty much) unreadable text. Not to mention that these things pop up when I scroll the page with arrow keys as the (then invisible) mouse becomes overtop of them. Quite irritating.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44a44b295e427b649cd28247b5559450e8db0df1e27be7ea1bcbcca2fa5a31ed-194a7c28447df70b49dd7450808e91398624d17aaaec83fc06d9d6b49881e8cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12065")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Yes to snap preview. i’ve really been missing it!")

#text("In response to KenF: My opinion is precisely the opposite. It’s the fact that Dr. Tao so often links to Wikipedia articles that makes snap so useful for his site. All you have to do is hover over the link to get the definition of some mathematical term, rather than having to actually go to the Wikipedia article and then come back here. By contrast, if the website were “grapically interesting or unusual”, then you might actually want to visit it!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29468a823631385ee82b30ae3682b5110eb1196e5fa53b5fe10869bd99233d16-5f60c11ca90e04656a823bd4c17c07176581b3ecf15786bf8751f2b08a51ab7d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mattheath")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12067")[#strong[#text("mattheath")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Yes to snap. It is annoying on most blogs but great for maths, for more or less the reasons anonymous gave above. It makes it much easier to get the sense of a post if you can read definitions and statements ofknown results without opening a stack of tabs.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3948c22798e2632c39acdcd2036dd86c420c70658eef3dc0b2edf2b9423e6b0b-0b5da07b38d6f022723acd140c3a610919f38899ff51fd3e4d3542cc704ae10e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12068")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Hi Terrence,")

#text("I all too often make speculative comments that seem insightful to me but are not mathematically rigorous.")

#text("I would not be offended if you simply delete those comments that you consider inappropriate.")

#text("I prefer what Urs Schreiber and John Baez at n-category cafe sometimes do, send me an e-mail simply stating the reason for deleting a comment of mine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d0733e76dfb9b0daf835446bf1df5e249fbdf56520b1b36b505fe1072b9f3f9-ba1875dc37bf720a84d080fce9e2ae57befc694b028483d08cdffe56acf3cf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12071")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("No to snap preview. I can’t read those small letters.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4cc22c940ce9236b414999e7db815fcebf71be3347fe15fe0fa79dcc0e8555e-fdd6e0bbd29139d3c67651120b1ef6f77d2ce50fff68e6b8942d2645d98b7cc5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alex")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12076")[#strong[#text("alex")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Another vote for no on snap. Extremely annoying to have these things pop up when you move the mouse randomly around the page.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12081")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Another vote No.")

#text("I had to update my edition of Internet Explorer because a simple mouseover a snap preview would close the window.")

#text("It appears that its a small convenience to those who favor it and a huge inconvenience to those who do not.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12082")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Yes to Snap, but only for Wikipedia definitions. Ironically, I was just pointing your blog out to a friend as the one truly useful application of Snap, only to see that you’d turned it off!")

#text("For what it’s worth, I’m on a super-fast connection.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12086")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("I just want to add that snap or not, your blog is fantastic. You could change the formatting to 6 point pink type on a gray background and it would still be one of my favorite reads.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ARS")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12089")[#strong[#text("ARS")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("I vote a definite NO on Snap preview. I find it really annoying and useless on small (laptop) screens.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7cfe99a1a43cf98b73964231bbed18fb854a5a79ea62f27519e5dc8438183fa-d5051decc9a1f508345f55ee44c46f01ed8608c68a42c505fc72faf6035aa50b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chi")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12091")[#strong[#text("Chi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("I would like a full RSS feed, instead of truncated articles. In fact, having just subscribed this afternoon, I will most likely unsubscribe if it’s unavailable–opening a new tab just really slows you down.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of david")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12092")[#strong[#text("david")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Just say No to Snap!")

#text("I can’t disable Snap, either, which is odd. Firefox 2.0.0.7 on Vista, anybody else seeing this happening? Cleared cache and all that jazz already.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f23bddeb369d2c7c58c7e39ba7e4a042cbb8d3a7955397f35ae9091a6083e1e5-a64bea3280ae3dc50b98aa68b1d1f5bb3b2abf9f049953a8c6374ab195ea613c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12093")[#strong[#text("Andy")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("YES vote to snap review! It helps to get a quick idea of some concepts without opening tens of windows for each.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12094")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Yes to snap. I find snap useful when the link is to a definition. Given the mixed views on the feature, it seems that it should be an option that can be turned on or off by the individual reader, rather than the author. But this is a criticism of WordPress rather than our host. A preview widow like snap should perhaps be a feature of a browser rather than a website.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robbie")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12098")[#strong[#text("Robbie")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("The Snap pop-ups used to annoy me greatly. But I recently installed the NoScript plugin for Firefox and haven’t been hassled by Snap since!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12110")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("I hate snap more than just about anything currently found on the web. I tend to move my mouse around aimlessly as I read, and then these… THINGS… pop up over the text I’m reading. I don’t think they make anything slower, but they take so long to disappear, and are certainly not readable in the form in which they appear. And if you have several of them in close proximity, it’s just a comedy of errors trying to mouse away and actually read the post.")

#text("But now I know that NoScript plugin exists. I will install and be snap free, whatever you decide to do with the blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29b97008a96ea24b2aee408811f65e107e84ae86372cb7b752fbf98fd016a027-3747bad49ae8579e4367a9b2306e3b1ac65c02f3cfaba0ab9c181a0198b8f5e5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Radu Grigore")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12114")[#strong[#text("Radu Grigore")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2007")])]

#text("Thanks for the hint on how to disable SnapPreview for my browser! The previews were rather annoying and contributed to my habit of printing your entries instead of reading from the browser. I really like the way the printed version looks different than the web version.")

#text("I have a good connection and I do not see any difference in loading times.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/819e2dadbdf9d585ea2d073f1e71426e90f31486535e94ba65e3b0263fbc7608-86ecfad42a5b99c5c5ae4ae3a4827e092e2578e8cd18e09285b2de1e1d37ad0f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12145")[#strong[#text("Robert")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2007")])]

#text("Hi,")

#text("from my side it’s a clear no to SnapPreview as the preview windows keep popping up when I don’t expect them and block the view to the text I am actually interested in.")

#text("The people at Cosmic Variance ")#link("http://www.cosmicvariance.com")[#text("http://www.cosmicvariance.com")]#text(" also use wordpress and have comment preview turned on. Maybe you could ask them how to do it.")

#text("Robert")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1643470755c09e6dec61fc4919df559435ace08fb77dd39c8dd77330933c2932-8e64f44de0c3f2f4f1404083d6e607b16d77e567c11cd9b8e23a4fadcc46780e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Cook")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12150")[#strong[#text("James Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2007")])]

#text("I’ve already weighed in with my support for the Snap preview feature, but I’d like to comment on some of the complaints about it. To me, the fact that windows pop up when you weren’t expecting them is a very minor annoyance, as compared with, say, having to repeatedly click the “Back” button from Wikipedia pages and find where you were in the text of the post. After all, in order to avoid the former “problem”, all you have to do is position the cursor appropriately. In any case, you can instantly make a Snap window disappear by clicking outside the window. So this kind of complaint is hardly grounds for disabling the feature.")

#text("I suspect that a lot of the people who are complaining about Snap do not often need to click on the links, especially the ones having to do with more elementary mathematical terms. Consequently, they may be underestimating the convenience provided by these previews to readers with less advanced backgrounds, or those less familiar with the subject of the post. But Terry’s posts can be very useful to such readers (I have been in this category on a number of occasions) and the Snap previews really make a difference in facilitating the reading process.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac9a3b5ce168efe151be229fd1c70f56199e25efc2a850541c1244932656c79-676aa09eb0d103533022e83fec0e8da28889b165fbfd3be9835fe1aeb2f9d9b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Bergman")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12155")[#strong[#text("Aaron Bergman")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2007")])]

#emph[#text("as compared with, say, having to repeatedly click the “Back” button from Wikipedia pages and find where you were in the text of the post.")]

#text("Tabbed browsing is your friend.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12164")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2007")])]

#text("yea, upgrade to IE7 and use middle button to open a new tab.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DeadWolfe")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12183")[#strong[#text("DeadWolfe")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2007")])]

#text("I find having the snap preview pop up when I’m not expecting it to be very annoying.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4149dc166fc99fae41e065ecf41bd28e7b62b7e7864680828855d9ad46c9cc53-7427fb03b25005d131600b414dcc852f4bb98a79cb577e80513c17d029aab611.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Torbjörn Larsson, OM")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12184")[#strong[#text("Torbjörn Larsson, OM")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2007")])]

#text("Previews of definitions saves time or increase reader value, and the added hassle can be circumvented. The rest is better viewed in tabbed browsing.")

#text("Format suggestion: The comments appear below the last item on the long left frame. (At least in my Firefox browser.) For short posts that means a search to read the page.")

#text("Perhaps a more ‘readable’ format or a navigation shortcut could be found?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62939ca2234b49a04b4514e433ff48ce382037abb1a6b67181f37e7fdf1d4d38-c10cdc4363c31831bc1ee89b2ab8309d6adf2900764b2f462abac4e8e763fbf9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Welford")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12262")[#strong[#text("Michael Welford")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2007")])]

#text("This is a pretty emphatic no to Snap.")

#text("In response to James Cook, I do follow the links often. Opera browser shows me a URL. Then I can decide whether to open in a new tab and whether to put the new tab in background.")

#text("I have the new tab created adjacent to the current tab, but for the life of me I couldn’t tell you how I turned that option on.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reid")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12292")[#strong[#text("Reid")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2007")])]

#text("@Dr. Tao:")

#text("I don’t know what else you changed, but the comment form isn’t displaying properly in Safari any more (I’m writing this from an old Firefox install). It seems to be only displaying the first 2 characters of the input boxes, etc and the rest is just as if a blank white page is present. But, the mouse still reacts as though they’re there in the white area. Anyone else experiencing this?")

#text("@James Cook:")

#text("Several points:")

#text("– It is your /opinion/ that such arguments don’t hold water. But, that would imply that you have the power to determine what other people find (in)significant and at what level or at least be able to judge when or not this is so (again, for other people). Point of fact, you don’t have this ability. It is also quite foolish to say this when people are saying the exact opposite. You want to post your opinion, great. That’s what this was all about. But, don’t speak as if you’re some authority on the matter, when you are very very far from it.")

#text("– You’re assuming that the preview can be read which is *not* the case in most cases that I’ve been forced to be exposed to as others have commented on as well. And the cases where I could make out the text, there wasn’t nearly enough displayed to make it even remotely useful. Basically, bad assumption. Not all of us have superman vision nor high enough resolution on our monitors that would be required for even the possibility.")

#text("– I like to run the mouse along the line that I am reading from time to time. This is especially so when I’m tired. But, it’s rather hard to do that when I have to mind a minefield of popups as I go.")

#text("– You don’t want to be exposed to the back button (i.e. web browsing): right click the link and open in a new window or tab. This can be made easier as other posters have pointed out. This would give an actual clean web page, giving /the/ /user/ the option on how do deal with the link.")

#text("Basically, while this feature irritates many here and as such its remove would benefit many. On the other hand, the work around for others is trivial and is as simple as web browsing like people have been doing for… how long now.")

#text("But, a decision has already been made. Perhaps one of these days, I’ll write a little something that will disable it totally client side without having to deal with the shotgun approach that is NoScript. Not to mention for Safari. *sigh*")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12383")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2007")])]

#text("Dear Reid,")

#text("I cannot duplicate what you report on IE or Firefox (I don’t have access to Safari). I will probably have to wait for more data before being able to do much about it.")

#text("Incidentally, is the option within the Snap preview window to disable it permanently not working in some browsers? I tested it in IE and it seems to work fine.")

#text("Finally, just a reminder to everyone to keep the discussion constructive and polite; in particular, a focus on technical solutions or compromises would be particularly valuable for me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4149dc166fc99fae41e065ecf41bd28e7b62b7e7864680828855d9ad46c9cc53-7427fb03b25005d131600b414dcc852f4bb98a79cb577e80513c17d029aab611.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Torbjörn Larsson, OM")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12417")[#strong[#text("Torbjörn Larsson, OM")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2007")])]

#text("Snap is turned off in this post on my Firefox (latest update).")

#text("If it is a problem in other browsers, I suggest loosing it, as the gain isn’t much or nothing depending on reader. (At least until the provider fixes such issues.)")

#text("The “new tab adjacent” effect of Michael’s Opera demands installing an add-on in Firefox. (For example the “Tabs Open Relative”.) I can recommend it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4149dc166fc99fae41e065ecf41bd28e7b62b7e7864680828855d9ad46c9cc53-7427fb03b25005d131600b414dcc852f4bb98a79cb577e80513c17d029aab611.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Torbjörn Larsson, OM")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12418")[#strong[#text("Torbjörn Larsson, OM")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2007")])]

#text("Oh, sorry, you asked about permanent disabling. Yes, it works too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/530046212bd8d9be49f549e54c0479f3c7847de5bd74fa18447c3f5dd864daff-164475109c230d66e107e0ae9408eb6b79022fdd9276596acc1a99f7f3d3c0c8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YourBiggestFan")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12470")[#strong[#text("YourBiggestFan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2007")])]

#text("Quoting ")#emph[#text("“I have been looking out for a way to enable previewing of comments, but as far as I can tell this appears to not be possible on wordpress.”")]

#text("When people say “wordpress”, it means one of two things:")#linebreak()#text(" * The blog-publishing software WordPress, which is Free Software and can be installed anywhere you want: see ")#link("http://wordpress.org/")[#text("wordpress.org")]#linebreak()#text(" * The website wordpress.com, which runs this software and uses it to host blogs for free.")

#text("Blogs on the WordPress.com site come with a limited set of features (but you should ask them about comment preview; maybe if enough people ask they’ll finally include it…) A self-hosted WordPress blog is more configurable, but then you have to worry about hosting and maintenance which might take time away from the more important things in life 🙂")

#text("See ")#link("http://faq.wordpress.com/2006/05/07/wordpresscom-vs-wordpressorg/")[#text("the comparison")]#text(" here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-12660")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2007")])]

#text("sir, which size you write small, medium, justbig.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-13471")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2007")])]

#text("I use a tabbed browser where clicking the middle mouse button opens the link in a new tab ‘in the background’. So I’d prefer getting rid of the annoying preview popup completely. The previews might be more useful for those stuck with non-tabbed browsers. thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2007/10/16/snap-preview/comment-page-1/#comment-32376")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2008")])]

#text("I really hate Snap and found this thread with the idea of urging you to turn it off (which I still hope you do) but it’s interesting that there are some technical workarounds. Note that setting a cookie won’t help me much since I clear all my cookies when I close my browser, and anyway cookies tend to be accompanied by evil web beacons. But I may try some of the other remedies suggested. Right now I use the Mozilla prefbar to turn off Javascript whenever I viist your site, which is a big pain.")

#text("James Cook: get a modern browser with tabs and you won’t have to deal with the back button any more.")
]
