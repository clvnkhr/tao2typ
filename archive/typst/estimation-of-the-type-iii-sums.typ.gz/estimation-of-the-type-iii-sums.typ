// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/
// Converted to Typst by tao2typ: "2026-10-14T09:31:49.616623+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Estimation of the Type III sums", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Estimation of the Type III sums")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 June 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/")[#text("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is the final continuation of the ")#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/")[#text("online reading seminar")]#text(" of ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("Zhang’s paper")]#text(" for the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("polymath8 project")]#text(". (There are two other continuations; ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("this previous post")]#text(", which deals with the combinatorial aspects of the second part of Zhang’s paper, and ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(", that covers the Type I and Type II sums.) The main purpose of this post is to present (and hopefully, to improve upon) the treatment of the final and most innovative of the key estimates in Zhang’s paper, namely the Type III estimate.")

#text("The main estimate was already stated as Theorem 17 in ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("the previous post")]#text(", but we quickly recall the relevant definitions here. As in other posts, we always take ")#mi("{x}")#text(" to be a parameter going off to infinity, with the usual asymptotic notation ")#mi("{O(), o(), \\ll}")#text(" associated to this parameter.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Coefficient sequences)")]#text(" A ")#emph[#text("coefficient sequence")]#text(" is a finitely supported sequence ")#mi("{\\alpha: {\\bf N} \\rightarrow {\\bf R}}")#text(" that obeys the bounds ")#metadata(none) <tao-afd7bf72960f2f867380>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|\\alpha(n)\\right| \\ll \\tau^{O(1)}(n) \\log^{O(1)}(x)", block: true)]]

#text("for all ")#mi("{n}")#text(", where ")#mi("{\\tau}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]#text(".")

#list(
[#text("(i) If ")#mi("{\\alpha}")#text(" is a coefficient sequence and ")#mi("{a\\ (q) = a \\text{ mod } q}")#text(" is a primitive residue class, the (signed) ")#emph[#text("discrepancy")]#text(" ")#mi("{\\Delta(\\alpha; a\\ (q))}")#text(" of ")#mi("{\\alpha}")#text(" in the sequence is defined to be the quantity")

#metadata(none) <tao-6cd4c9c389b460a1f603>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\Delta(\\alpha; a \\ (q)) := \\sum_{n: n = a\\ (q)} \\alpha(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1} \\alpha(n).")]]],
[#text("(ii) A coefficient sequence ")#mi("{\\alpha}")#text(" is said to be ")#emph[#text("at scale ")#mi("{N}")]#text(" for some ")#mi("{N \\geq 1}")#text(" if it is supported on an interval of the form ")#mi("{[(1-O(\\log^{-A_0} x)) N, (1+O(\\log^{-A_0} x)) N]}")#text(".")],
[#text("(iii) A coefficient sequence ")#mi("{\\alpha}")#text(" at scale ")#mi("{N}")#text(" is said to be ")#emph[#text("smooth")]#text(" if it takes the form ")#mi("{\\alpha(n) = \\psi(n/N)}")#text(" for some smooth function ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf C}}")#text(" supported on ")#mi("{[1-O(\\log^{-A_0} x), 1+O(\\log^{-A_0} x)]}")#text(" obeying the derivative bounds")

#metadata(none) <tao-ab1e6be2000a7c9c3d39>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\psi^{(j)}(t) = O( \\log^{j A_0} x )")]]

#text("for all fixed ")#mi("{j \\geq 0}")#text(" (note that the implied constant in the ")#mi("{O()}")#text(" notation may depend on ")#mi("{j}")#text(").")]
)
]

#text("For any ")#mi("{I \\subset {\\bf R}}")#text(", let ")#mi("{{\\mathcal S}_I}")#text(" denote the square-free numbers whose prime factors lie in ")#mi("{I}")#text(". The main result of this post is then the following result of Zhang:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Type III estimate)")]#text(" ")#metadata(none) <tao-27b250d25accb10de21a>#text(" Let ")#mi("{\\varpi, \\delta > 0}")#text(" be fixed quantities, and let ")#mi("{M, N_1, N_2, N_3 \\gg 1}")#text(" be quantities such that")

#align(center)[#tao-fit-display[#mitex("x \\ll M N_1 N_2 N_3 \\ll x")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("N_1 \\gg N_2, N_3")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("N_1^4 N_2^4 N_3^5 \\gg x^{4+16\\varpi+\\delta+c}")]]

#text("for some fixed ")#mi("{c>0}")#text(". Let ")#mi("{\\alpha, \\psi_1, \\psi_2, \\psi_3}")#text(" be coefficient sequences at scale ")#mi("{M,N_1,N_2,N_3}")#text(" respectively with ")#mi("{\\psi_1,\\psi_2,\\psi_3}")#text(" smooth. Then for any ")#mi("{I \\subset [1,x^\\delta]}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\in {\\mathcal S}_I: q< x^{1/2+2\\varpi}} \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\alpha \\ast \\beta; a)\\right| \\ll x \\log^{-A} x.", block: true)]]

#text("In fact we have the stronger “pointwise” estimate ")#metadata(none) <tao-256b93a925d9f71f4db0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|\\Delta(\\alpha \\ast \\psi_1 \\ast \\psi_2 \\ast \\psi_3; a)\\right| \\ll x^{-\\epsilon} \\frac{x}{q}", block: true)]]

#text("for all ")#mi("{q \\in {\\mathcal S}_I}")#text(" with ")#mi("{q < x^{1/2+2\\varpi}}")#text(" and all ")#mi("{a \\in ({\\bf Z}/q{\\bf Z})^\\times}")#text(", and some fixed ")#mi("{\\epsilon>0}")#text(".")
]

#text("(This is very slightly stronger than previously claimed, in that the condition ")#mi("{N_2 \\gg N_3}")#text(" has been dropped.)")

#text("It turns out that Zhang does not exploit any averaging of the ")#mi("{\\alpha}")#text(" factor, and matters reduce to the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Type III estimate without ")#mi("{\\alpha}")#text(")")]#text(" ")#metadata(none) <tao-da6f6367cc8a428003ac>#text(" Let ")#mi("{\\delta > 0}")#text(" be fixed, and let ")#mi("{1 \\ll N_1, N_2, N_3, d \\ll x^{O(1)}}")#text(" be quantities such that")

#align(center)[#tao-fit-display[#mitex("N_1 \\gg N_2, N_3")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("d \\in {\\mathcal S}_{[1,x^\\delta]}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("N_1^4 N_2^4 N_3^5 \\gg d^8 x^{\\delta+c}")]]

#text("for some fixed ")#mi("{c>0}")#text(". Let ")#mi("{\\psi_1,\\psi_2,\\psi_3}")#text(" be smooth coefficient sequences at scales ")#mi("{N_1,N_2,N_3}")#text(" respectively. Then we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Delta(\\psi_1 \\ast \\psi_2 \\ast \\psi_3; a)\\right| \\ll x^{-\\epsilon} \\frac{N_1 N_2 N_3}{d}", block: true)]]

#text("for all ")#mi("{a \\in ({\\bf Z}/d{\\bf Z})^\\times}")#text(" and some fixed ")#mi("{\\epsilon>0}")#text(".")
]

#text("Let us quickly see how Theorem ")#link(<tao-da6f6367cc8a428003ac>)[#text("3")]#text(" implies Theorem ")#link(<tao-27b250d25accb10de21a>)[#text("2")]#text(". To show ")#link(<tao-256b93a925d9f71f4db0>)[#text("(4)")]#text(", it suffices to establish the bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n = a\\ (q)} \\alpha \\ast \\psi_1 \\ast \\psi_2 \\ast \\psi_3(n) = X + O( x^{-\\epsilon} \\frac{x}{q} )")]]

#text("for all ")#mi("{a \\in ({\\bf Z}/q{\\bf Z})^\\times}")#text(", where ")#mi("{X}")#text(" denotes a quantity that is independent of ")#mi("{a}")#text(" (but can depend on other quantities such as ")#mi("{\\alpha,\\psi_1,\\psi_2,\\psi_3,q}")#text("). The left-hand side can be rewritten as")

#align(center)[#tao-fit-display[#mitex("\\sum_{b \\in ({\\bf Z}/q{\\bf Z})^\\times} \\sum_{m = b\\ (q)} \\alpha(m) \\sum_{n = a/b\\ (q)} \\psi_1 \\ast \\psi_2 \\ast \\psi_3(n).")]]

#text("From Theorem ")#link(<tao-da6f6367cc8a428003ac>)[#text("3")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n = a/b\\ (q)} \\psi_1 \\ast \\psi_2 \\ast \\psi_3(n) = Y + O( x^{-\\epsilon} \\frac{N_1 N_2 N_3}{q} )")]]

#text("where the quantity ")#mi("{Y}")#text(" does not depend on ")#mi("{a}")#text(" or ")#mi("{b}")#text(". Inserting this asymptotic and using crude bounds on ")#mi("{\\alpha}")#text(" (see Lemma 8 of ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("this previous post")]#text(") we conclude ")#link(<tao-256b93a925d9f71f4db0>)[#text("(4)")]#text(" as required (after modifying ")#mi("{\\epsilon}")#text(" slightly).")

#text("It remains to establish Theorem ")#link(<tao-da6f6367cc8a428003ac>)[#text("3")]#text(". This is done by a set of tools similar to that used to control the Type I and Type II sums:")

#list(
[#text("(i) completion of sums;")],
[#text("(ii) the Weil conjectures and bounds on Ramanujan sums;")],
[#text("(iii) factorisation of smooth moduli ")#mi("{q \\in {\\mathcal S}_I}")#text(";")],
[#text("(iv) the Cauchy-Schwarz and triangle inequalities (Weyl differencing).")]
)

#text("The specifics are slightly different though. For the Type I and Type II sums, it was the classical Weil bound on Kloosterman sums that were the key source of power saving; Ramanujan sums only played a minor role, controlling a secondary error term. For the Type III sums, one needs a significantly deeper consequence of the Weil conjectures, namely the estimate ")#link("http://www.ams.org/mathscinet-getitem?mr=786351")[#text("of Bombieri and Birch")]#text(" on a three-dimensional variant of a Kloosterman sum. Furthermore, the Ramanujan sums – which are a rare example of sums that actually exhibit ")#emph[#text("better")]#text(" than square root cancellation, thus going beyond even what the Weil conjectures can offer – make a crucial appearance, when combined with the factorisation of the smooth modulus ")#mi("{q}")#text(" (this new argument is arguably the most original and interesting contribution of Zhang).")

#metadata(none) <tao-62e335e0a19cb2c192b1>

#heading(level: 1)[#strong[#text(" — 1. A three-dimensional exponential sum — ")]]

#text("The power savings in Zhang’s Type III argument come from good estimates on the three-dimensional exponential sum")

#metadata(none) <tao-a5fa3952260e2550a72e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("T(k; m,m^{\\prime}; q) := \\sum_{l \\in {\\bf Z}/q{\\bf Z}: (l,q)=(l+k,q)=1} \\sum_{t \\in ({\\bf Z}/q{\\bf Z})^\\times} \\sum_{t^{\\prime} \\in ({\\bf Z}/q{\\bf Z})^\\times}")]]

#align(center)[#tao-fit-display[#mitex("e_q( \\frac{t}{l} - \\frac{t^{\\prime}}{l+k} + \\frac{m}{t} - \\frac{m^{\\prime}}{t^{\\prime}} )")]]

#text("defined for positive integer ")#mi("{q}")#text(" and ")#mi("{k,m,m^{\\prime} \\in {\\bf Z}/q{\\bf Z}}")#text(" (or ")#mi("{k,m,m^{\\prime} \\in {\\bf Z}}")#text("). The key estimate is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Bombieri-Birch bound)")]#text(" ")#metadata(none) <tao-3b64db95cb55c763391c>#text(" Let ")#mi("{q}")#text(" be square-free. Then for any ")#mi("{k,m,m^{\\prime} \\in {\\bf Z}/q{\\bf Z}}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|T(k; m,m^{\\prime};q)\\right| \\ll \\frac{(m-m^{\\prime},k,q)}{(k,q)^{1/2}} q^{3/2+o(1)}", block: true)]]

#text("where ")#mi("{(m-m^{\\prime},k,q)}")#text(" is the greatest common divisor of ")#mi("{m-m^{\\prime}, k, q}")#text(" (and we adopt the convention that ")#mi("{(0,q)=q}")#text("). (Here, the ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{q \\rightarrow \\infty}")#text(", rather than as ")#mi("{x \\rightarrow \\infty}")#text(".)")
]

#text("Note that the square root cancellation heuristic predicts ")#mi("{q^{3/2}}")#text(" as the size for ")#mi("{T(k;m,m^{\\prime},q)}")#text(", thus we can achieve ")#emph[#text("better")]#text(" than square root cancellation if ")#mi("{k}")#text(" has a common factor with ")#mi("{q}")#text(" that is not shared with ")#mi("{m-m^{\\prime}}")#text(". This improvement over the square root heuristic, which is ultimately due to the presence of a Ramanujan sum inside this three-dimensional exponential sum in certain degenerate cases, is crucial to Zhang’s argument.")

#emph[#text("Proof:")]#text(" Suppose that ")#mi("{q}")#text(" factors as ")#mi("{q=q_1q_2}")#text(", thus ")#mi("{q_1,q_2}")#text(" are coprime. Then we have")

#align(center)[#tao-fit-display[#mitex("e_q(a) = e_{q_1}( \\frac{a}{q_2} ) e_{q_2} (\\frac{a}{q_1})")]]

#text("(see Lemma 7 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text("). From this and the Chinese remainder theorem we see that ")#mi("{T(k;m,m^{\\prime};q)}")#text(" factorises as")

#align(center)[#tao-fit-display[#mitex("\\prod_{i=1}^2 \\sum_{l \\in {\\bf Z}/q_i{\\bf Z}: (l,q_i)=(l+k,q_i)=1} \\sum_{t,t^{\\prime} \\in ({\\bf Z}/q_i{\\bf Z})^\\times} e_{q_i}( \\frac{t}{q_jl} - \\frac{t^{\\prime}}{q_j(l+k)} + \\frac{m}{q_jt} - \\frac{m^{\\prime}}{q_jt^{\\prime}} )")]]

#text("where ")#mi("{j := 3-i}")#text(". Dilating ")#mi("{t,t^{\\prime}}")#text(" by ")#mi("{q_j}")#text(", we conclude the multiplicative law")

#align(center)[#tao-fit-display[#mitex("T(k;m,m^{\\prime};q_1q_2) = T(k;\\frac{m}{q_2^2},\\frac{m^{\\prime}}{q_2^2};q_1) T(k;\\frac{m}{q_1^2},\\frac{m^{\\prime}}{q_1^2};q_2).")]]

#text("Iterating this law, we see that to prove Theorem ")#link(<tao-3b64db95cb55c763391c>)[#text("4")]#text(" it suffices to do so in the case when ")#mi("{q}")#text(" is prime, or more precisely that")

#align(center)[#tao-fit-display[#tao-math("\\left|T(k; m,m^{\\prime};p)\\right| \\ll \\frac{(m-m^{\\prime},k,p)}{(k,p)^{1/2}} p^{3/2}.", block: true)]]

#text("We first consider the case when ")#mi("{k = 0\\ (p)}")#text(", so our objective is now to show that ")#metadata(none) <tao-8fbbd06a906c38c09377>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|T(0;m,m^{\\prime};p)\\right| \\ll (m-m^{\\prime},p) p.", block: true)]]

#text("In this case we can write ")#mi("{T(0;m,m^{\\prime};p)}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{l,t,t^{\\prime} \\in ({\\bf Z}/p{\\bf Z})^\\times} e_p( \\frac{t}{l} - \\frac{t^{\\prime}}{l} + \\frac{m}{t} - \\frac{m^{\\prime}}{t^{\\prime}} ).")]]

#text("Making the change of variables ")#mi("{s := \\frac{tt^{\\prime}}{l}\\ (p)}")#text(", ")#mi("{u := \\frac{1}{t}\\ (p)}")#text(", ")#mi("{u^{\\prime} := \\frac{1}{t^{\\prime}}\\ (p)}")#text(" this becomes")

#align(center)[#tao-fit-display[#mitex("\\sum_{s,u,u^{\\prime} \\in ({\\bf Z}/p{\\bf Z})^\\times} e_p( su^{\\prime} - su + mu - m^{\\prime} u^{\\prime} ).")]]

#text("Performing the ")#mi("{u,u^{\\prime}}")#text(" sums this becomes")

#align(center)[#tao-fit-display[#mitex("\\sum_{s \\in ({\\bf Z}/p{\\bf Z})^\\times} C_p(m-s) C_p(s-m^{\\prime})")]]

#text("where ")#mi("{C_q(a)}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Ramanujan's_sum")[#text("Ramanujan sum")]

#align(center)[#tao-fit-display[#mitex("C_q(a) := \\sum_{b \\in ({\\bf Z}/q{\\bf Z})^\\times} e_q(ab).")]]

#text("Basic Fourier analysis tells us that ")#mi("{C_p(a)}")#text(" equals ")#mi("{-1}")#text(" when ")#mi("{a \\neq 0\\ (p)}")#text(" and ")#mi("{p-1}")#text(" when ")#mi("{a = 0\\ (p)}")#text(". The expression ")#link(<tao-8fbbd06a906c38c09377>)[#text("(6)")]#text(" then follows from direct computation.")

#text("Next, suppose that ")#mi("{k \\neq 0\\ (p)}")#text(" and ")#mi("{m^{\\prime} = 0\\ (p)}")#text(". Making the change of variables ")#mi("{s := -\\frac{t^{\\prime}}{l+k}}")#text(", ")#mi("{T(k;m,0;p)}")#text(" becomes")

#align(center)[#tao-fit-display[#mitex("\\sum_{l \\in {\\bf Z}/p{\\bf Z}: (l,p)=(l+k,p)=1} \\sum_{t \\in ({\\bf Z}/p{\\bf Z})^\\times} \\sum_{s \\in ({\\bf Z}/p{\\bf Z})^\\times} e_p( \\frac{t}{l} + s + \\frac{m}{t} ).")]]

#text("Performing the ")#mi("{s}")#text(" summation, this becomes")

#align(center)[#tao-fit-display[#mitex("- \\sum_{l \\in {\\bf Z}/p{\\bf Z}: (l,p)=(l+k,p)=1} \\sum_{t \\in ({\\bf Z}/p{\\bf Z})^\\times} e_p( \\frac{t}{l} + \\frac{m}{t} ).")]]

#text("For each ")#mi("{l}")#text(", the ")#mi("{t}")#text(" summation is a Kloosterman sum and is thus ")#mi("{O(p^{1/2})}")#text(" by the classical Weil bound (Theorem 8 from ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("previous notes")]#text("). This gives a net estimate of ")#mi("{O(p^{3/2})}")#text(" as desired. Similarly if ")#mi("{m = 0\\ (p)}")#text(".")

#text("The only remaining case is when ")#mi("{k,m,m^{\\prime} \\neq 0\\ (p)}")#text(". Here one cannot proceed purely through Ramanujan and Weil bounds, and we need to invoke the deep result of Bombieri and Birch, proven in Theorem 1 of the ")#link("http://www.jstor.org/stable/1971176")[#text("the appendix")]#text(" to ")#link("http://www.ams.org/mathscinet-getitem?mr=786351")[#text("this paper of Friedlander and Iwaniec")]#text(". This bound can be proven by applying Deligne’s proof of the Weil conjectures to a certain ")#mi("{L}")#text("-function attached to the surface ")#mi("{\\{ (x_1,x_2,x_3,x_4): \\frac{1}{x_1x_2} + \\frac{1}{x_3x_4} = 1 \\}}")#text("; an elementary but somewhat lengthy second proof is also given in the above appendix. ")#mi("\\Box")

#text("To deal with factors such as ")#mi("{(k,q)}")#text(", the following simple lemma will be useful.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5")]#text(" ")#metadata(none) <tao-1956d1f0ee17f894f80d>#text(" For any ")#mi("{q}")#text(" and any ")#mi("{K \\geq 1}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq k \\leq K} (k,q) \\ll q^{o(1)} K.")]]

#text("in particular")

#align(center)[#tao-fit-display[#mitex("\\sum_{t \\in {\\bf Z}/q{\\bf Z}} (t,q) \\ll q^{1+o(1)}.")]]

#text("As in the previous theorem, ")#mi("{o(1)}")#text(" here denotes a quantity that goes to zero as ")#mi("{q \\rightarrow \\infty}")#text(", rather than as ")#mi("{x \\rightarrow \\infty}")#text(".")
]

#text("Note that it is important that the ")#mi("{k=0}")#text(" term is excluded from the first sum, otherwise one acquires an additional ")#mi("{q}")#text(" term. In particular,")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\left|k\\right| \\leq K} (k,q) \\ll q + q^{o(1)} K.", block: true)]]

#emph[#text("Proof:")]#text(" Estimating")

#align(center)[#tao-fit-display[#mitex("(k,q) \\leq \\sum_{d|q; d|k} d")]]

#text("we can bound")

#tao-aligned(keep: true)[


#tao-math("\\sum_{1 \\leq k \\leq K}(k,q)  & \\leq \\sum_{d|q} \\sum_{1 \\leq k \\leq K: d|k} d", block: true)



#tao-math(" & \\leq \\sum_{d|q} \\frac{K}{d} d", block: true)



#tao-math(" & = K \\tau(q)", block: true)



#tao-math(" & \\ll q^{o(1)} K.", block: true)
]

#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 2. Cauchy-Schwarz — ")]]

#text("We now prove Theorem ")#link(<tao-da6f6367cc8a428003ac>)[#text("3")]#text(". The reader may wish to track the exponents involved in the model regime ")#metadata(none) <tao-9372c470eeadd5ecd9c3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\delta \\approx 0; \\quad N_1=N_2=N_3 = N; \\quad N \\ll d \\ll N^{13/8}")]]

#text("where ")#mi("{N}")#text(" is any fixed power of ")#mi("{x}")#text(" (e.g. ")#mi("{N = x^{5/16}}")#text(", in which case ")#mi("{d}")#text(" can be slightly larger than ")#mi("{x^{1/2}}")#text(").")

#text("Let ")#mi("{\\delta,N_1,N_2,N_3,q,\\psi_1,\\psi_2,\\psi_3,a}")#text(" be as in Theorem ")#link(<tao-da6f6367cc8a428003ac>)[#text("3")]#text(", and let ")#mi("{\\epsilon>0}")#text(" be a sufficiently small fixed quantity. It will suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n = a\\ (d)} \\psi_1 \\ast \\psi_2 \\ast \\psi_3(n) = X + O( x^{-\\epsilon} \\frac{N_1 N_2 N_3}{d} )")]]

#text("where ")#mi("{X}")#text(" does not depend on ")#mi("{a}")#text(". We rewrite the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n_1} \\psi_1(n_1) \\sum_{n: (n,q)=1; n_1 = \\frac{a}{n}\\ (d)} \\psi_2 \\ast \\psi_3(n)")]]

#text("and then apply completion of sums (Lemma 6 from ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(") to rewrite this expression as the sum of the main term")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{d} (\\sum_{n_1} \\psi_1(n_1)) (\\sum_{n: (n,d)=1} \\psi_2 \\ast \\psi_3(n))")]]

#text("plus the error terms")

#align(center)[#tao-fit-display[#tao-math("O( (\\log^{O(1)} x) \\frac{N_1}{d} \\sum_{1 \\leq h \\le H} \\left|\\sum_{n: (n,d)=1} \\psi_2 \\ast \\psi_3(n) e_d( \\frac{ah}{n} )\\right| )", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("O( x^{-A} \\sum_n \\left|\\psi_2 \\ast \\psi_3(n)\\right| ).", block: true)]]

#text("where ")#mi("{A > 0}")#text(" is any fixed quantity and")

#align(center)[#tao-fit-display[#mitex("H := x^\\epsilon \\frac{d}{N_1}.")]]

#text("The first term does not depend on ")#mi("{a}")#text(", and the third term is clearly acceptable, so it suffices to show that ")#metadata(none) <tao-2e75a349e53c2d190fc6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\sum_{1 \\leq h \\le H} \\left|\\sum_{n: (n,d)=1} \\psi_2 \\ast \\psi_3(n) e_d( \\frac{ah}{n} ) \\right| \\ll x^{-\\epsilon} N_2 N_3.", block: true)]]

#text("It will be convenient to reduce to the case when ")#mi("{h}")#text(" and ")#mi("{d}")#text(" are coprime. More precisely, it will suffice to prove the following claim:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" ")#metadata(none) <tao-6446d58d6dfafd58586d>#text(" Let ")#mi("{\\delta>0}")#text(" be fixed, and let ")#metadata(none) <tao-2b59b6a04f3b9ba1d7b9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("H, N_2, N_3, d, B \\gg 1")]]

#text("be such that")

#align(center)[#tao-fit-display[#mitex("d \\in {\\mathcal S}_{[1,x^\\delta]}")]]

#text("and ")#metadata(none) <tao-60c2d799bb894ebfab8c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("H \\ll x^{\\epsilon} \\frac{d}{N_2}")]]

#text("and ")#metadata(none) <tao-b5587bfd231a74fd2aa1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("N_2^4 N_3^5 \\gg B^{-6} d^4 H^4 x^{\\delta+c}")]]

#text("for some fixed ")#mi("{c>0}")#text(", and let ")#mi("{\\psi_2,\\psi_3}")#text(" be smooth coefficient sequences at scale ")#mi("{N_2,N_3}")#text(" respectively. Then")

#align(center)[#tao-fit-display[#tao-math("\\sum_{1 \\leq h \\le H: (h,d)=1} \\left|\\sum_{n: (n,d)=1} \\psi_2 \\ast \\psi_3(n) e_d( \\frac{ah}{n} ) \\right| \\ll x^{-\\epsilon} B N_2 N_3", block: true)]]

#text("for some fixed ")#mi("{\\epsilon>0}")#text(".")
]

#text("Let us now see why the above proposition implies ")#link(<tao-2e75a349e53c2d190fc6>)[#text("(8)")]#text(". To prove ")#link(<tao-2e75a349e53c2d190fc6>)[#text("(8)")]#text(", we may of course assume ")#mi("{H \\geq 1}")#text(" as the claim is trivial otherwise. We can split")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq h \\leq H} F(h) = \\sum_{d = d_1 d_2} \\sum_{1 \\leq h^{\\prime} \\leq H/d_2: (h^{\\prime},d_1)=1} F( d_2 h )")]]

#text("for any function ")#mi("{F(h)}")#text(" of ")#mi("{h}")#text(", so that ")#link(<tao-2e75a349e53c2d190fc6>)[#text("(8)")]#text(" can be written as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d = d_1 d_2} \\sum_{1 \\leq h^{\\prime} \\leq H/d_2: (h,d_1)=1} \\left|\\sum_{n: (n,d_1 d_2)=1} \\psi_2 \\ast \\psi_3(n) e_{d_1}( \\frac{ah^{\\prime}}{n} )\\right|", block: true)]]

#text("which we expand as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d = d_1 d_2} \\sum_{1 \\leq h^{\\prime} \\leq H/d_2: (h,d_1)=1} \\left|\\sum_{n_2: (n_2,d_1 d_2)=1} \\sum_{n_3: (n_3,d_1d_2)=1} \\psi_2(n_2) \\psi_3(n_3) e_{d_1}( \\frac{ah^{\\prime}}{n_2 n_3} )\\right|", block: true)]]

#text("In order to apply Proposition ")#link(<tao-6446d58d6dfafd58586d>)[#text("(6)")]#text(" we need to modify the ")#mi("{(n_2,d_1d_2)=1}")#text(", ")#mi("{(n_3,d_1d_2)=1}")#text(" constraints. By Möbius inversion one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n_2: (n_2,d_1d_2)=1} F(n_2) = \\sum_{b_2|d_2} \\mu(b_2) \\sum_{n_2: (n_2,d_1)=1} F(b_2 n_2)")]]

#text("for any function ")#mi("{F}")#text(", and similarly for ")#mi("{n_3}")#text(", so by the triangle inequality we may bound the previous expression by ")#metadata(none) <tao-34707c3f40dfa20c3902>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\sum_{d = d_1 d_2} \\sum_{b_2|d_2} \\sum_{b_3|d_3} F( d_1, d_2, b_1, b_2 )")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("F(d_1,d_2,b_1,b_2) := \\sum_{1 \\leq h^{\\prime} \\leq H/d_2: (h,d_1)=1}")]]

#align(center)[#tao-fit-display[#mitex("|\\sum_{n_2: (n_2,d_1)=1} \\sum_{n_3: (n_3,d_1)=1} \\psi_2(b_2n_2) \\psi_3(b_3n_3)")]]

#align(center)[#tao-fit-display[#mitex("e_{d_1}( \\frac{ah^{\\prime}}{b_2b_3 n_2 n_3} )|")]]

#text("We may discard those values of ")#mi("{d_2}")#text(" for which ")#mi("{H^{\\prime} := H/d_2}")#text(" is less than one, as the summation is vacuous in that case. We then apply Proposition ")#link(<tao-6446d58d6dfafd58586d>)[#text("(6)")]#text(" with ")#mi("{d,N_2,N_3,H}")#text(" replaced by ")#mi("{d_1,N_2/b_2,N_3/b_3,H^{\\prime}}")#text(" respectively and ")#mi("{B}")#text(" set equal to ")#mi("{b_2 b_3}")#text(", and ")#mi("{\\psi_2,\\psi_3}")#text(" replaced by ")#mi("{\\psi_2(b_2\\cdot)}")#text(" and ")#mi("{\\psi_3(b_3\\cdot)}")#text(". One can check that all the hypotheses of Proposition ")#link(<tao-6446d58d6dfafd58586d>)[#text("6")]#text(" are obeyed, so we may bound ")#link(<tao-34707c3f40dfa20c3902>)[#text("(12)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\ll x^{-\\epsilon} N_2 N_3 \\sum_{d = d_1 d_2} \\sum_{b_2|d_2} \\sum_{b_3|d_3} 1")]]

#text("which by the divisor bound is ")#mi("{\\ll x^{-\\epsilon+o(1)} N_2 N_3}")#text(", which is acceptable (after shrinking ")#mi("{\\epsilon}")#text(" slightly).")

#text("It remains to prove Proposition ")#link(<tao-6446d58d6dfafd58586d>)[#text("6")]#text(". Continuing ")#link(<tao-9372c470eeadd5ecd9c3>)[#text("(7)")]#text(", the reader may wish to keep in mind the model case")

#align(center)[#tao-fit-display[#mitex("\\delta \\approx 0; N_2 = N_3 = N; \\quad N \\ll d \\ll N^{13/8}; \\quad H \\approx d/N; \\quad B \\approx 1.")]]

#text("Note from ")#link(<tao-2b59b6a04f3b9ba1d7b9>)[#text("(9)")]#text(", ")#link(<tao-60c2d799bb894ebfab8c>)[#text("(10)")]#text(" one has ")#metadata(none) <tao-f998fe06afa0cfbe73e0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("d \\gg x^{-\\epsilon} N_2.")]]

#text("Expanding out the ")#mi("{\\psi_2 \\ast \\psi_3}")#text(" convolution, our task is to show that ")#metadata(none) <tao-07d715edb696fb5f628f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\sum_{1 \\leq h \\le H: (h,d)=1} \\left|\\sum_{n_2: (n_2,d)=1} \\sum_{n_3: (n_3,d)=1} \\psi_2(n_2) \\psi_3(n_3) e_d( \\frac{ah}{n_2n_3} )\\right| \\ll x^{-\\epsilon} B N_2 N_3.", block: true)]]

#text("As before, our aim is to obtain a power savings better than ")#mi("{H}")#text(" over the trivial bound of ")#mi("{H N_2 N_3}")#text(".")

#text("The next step is Weyl differencing. We will need a step size ")#mi("{r \\geq 1}")#text(" which we will optimise in later. We set ")#metadata(none) <tao-e96e02d8e47f2a7c03be>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("K := \\lfloor x^{-\\epsilon} N_2 r^{-1} H^{-1}\\rfloor;")]]

#text("we will make the hypothesis that ")#metadata(none) <tao-3e11b6c3eef5d583d7be>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("K \\geq 1")]]

#text("and save this condition to be verified later.")

#text("By shifting ")#mi("{n_2}")#text(" by ")#mi("{khr}")#text(" for ")#mi("{1 \\leq k \\leq K}")#text(" and then averaging, we may write the left-hand side of ")#link(<tao-07d715edb696fb5f628f>)[#text("(14)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq h \\le H: (h,d)=1} |\\frac{1}{K} \\sum_{1 \\leq k \\leq K} \\sum_{n_2: (n_2,d)=1} \\sum_{n_3: (n_3,d)=1}")]]

#align(center)[#tao-fit-display[#mitex("\\psi_2(n_2+hkr) \\psi_3(n_3) e_d( \\frac{ah}{(n_2+hkr)n_3} )|.")]]

#text("By the triangle inequality, it thus suffices to show that ")#metadata(none) <tao-65cc63a4e10ee8f05be4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\sum_{1 \\leq h \\leq H: (h,d)=1} \\sum_{n_2: (n_2,d)=1} |\\sum_{1 \\leq k \\leq K} \\psi_2(n_2+hkr)")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n_3: (n_3,d)=1} \\psi_3(n_3) e_d( \\frac{ah}{(n_2+hkr)n_3} )| \\ll x^{-\\epsilon} B K N_2 N_3.")]]

#text("Next, we combine the ")#mi("{h}")#text(" and ")#mi("{n_2}")#text(" summations into a single summation over ")#mi("{{\\bf Z}/d{\\bf Z}}")#text(". We first use a Taylor expansion and ")#link(<tao-e96e02d8e47f2a7c03be>)[#text("(15)")]#text(" to write")

#align(center)[#tao-fit-display[#mitex("\\psi_2(n_2+hkr) = \\sum_{j=0}^J \\frac{1}{j!} (h/H)^j N_2^{j} \\psi_2^{(j)}(n_2) (Hkr/N_2)^j + O( x^{-J\\epsilon+o(1)})")]]

#text("for any fixed ")#mi("{J}")#text(". If ")#mi("{J}")#text(" is large enough, then the error term will be acceptable, so it suffices to establish ")#link(<tao-65cc63a4e10ee8f05be4>)[#text("(17)")]#text(" with ")#mi("{\\psi_2(n_2+hkr)}")#text(" replaced by ")#mi("{(h/H)^j N_2^j \\psi_2^{(j)}(n_2) (hkr/N_2)^j}")#text(" for any fixed ")#mi("{j \\geq 0}")#text(". We can rewrite")

#align(center)[#tao-fit-display[#mitex("e_d( \\frac{ah}{(n_2+hkr)n_3} ) = e_d( \\frac{a}{(l+kr) n_3} )")]]

#text("where ")#mi("{l \\in {\\bf Z}/d{\\bf Z}}")#text(" is such that ")#mi("{(l+kr,d)=1}")#text(" and")

#align(center)[#tao-fit-display[#mitex("l = \\frac{n_2}{h}\\ (d).")]]

#text("Thus we can estimate the left-hand side of ")#link(<tao-65cc63a4e10ee8f05be4>)[#text("(17)")]#text(" by ")#metadata(none) <tao-305f2522484988d66f36>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\sum_{l \\in {\\bf Z}/d{\\bf Z}} \\nu(l) |\\sum_{1 \\leq k \\leq K: (l+kr,d)=1} (Hkr/N_2)^j")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n_3: (n_3,d)=1} \\psi_3(n_3) e_d( \\frac{a}{(l+kr) n_3})|")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\nu(l) := \\sum_{1 \\leq h \\leq H: (h,d)=1} \\sum_{n_2} 1_{l = \\frac{n_2}{h}\\ (d)} N_2^j |\\psi_2^{(j)}(n_2)|.")]]

#text("Here we have bounded ")#mi("{(h/H)^j}")#text(" by ")#mi("{O(1)}")#text(".")

#text("We will eliminate the ")#mi("{\\nu}")#text(" expression via Cauchy-Schwarz. Observe from the smoothness of ")#mi("{\\psi_2}")#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\nu(l) \\ll x^{o(1)} \\left|\\{ (h,n_2): 1 \\leq h \\leq H; 1 \\ll n_2 \\ll N_2; (h,d)=1; l = \\frac{n_2}{h}\\ (d) \\}\\right|", block: true)]]

#text("and thus")

#tao-aligned(keep: true)[


#tao-math("\\sum_l \\nu(l)^2  & \\ll x^{o(1)} |\\{ (h,h^{\\prime},n_2,n^{\\prime}_2): 1 \\leq h,h^{\\prime} \\leq H; 1\\ll n_2,n^{\\prime}_2 \\ll N_2;", block: true)



#tao-math("(h,d) & =(h^{\\prime},d) = 1; \\frac{n_2}{h} = \\frac{n^{\\prime}_2}{h^{\\prime}}\\ (d) \\}|.", block: true)
]

#text("Note that ")#mi("{\\frac{n_2}{h} = \\frac{n^{\\prime}_2}{h^{\\prime}}\\ (d)}")#text(" implies ")#mi("{n_2 h^{\\prime} = n^{\\prime}_2 h\\ (d)}")#text(". But from ")#link(<tao-60c2d799bb894ebfab8c>)[#text("(10)")]#text(" we have ")#mi("{1 \\leq n_2 h^{\\prime}, n^{\\prime}_2 h \\leq d}")#text(", so in fact we have ")#mi("{n_2 h^{\\prime} = n^{\\prime}_2 h}")#text(". Thus")

#align(center)[#tao-fit-display[#mitex("\\sum_l \\nu(l)^2 \\ll x^{o(1)} |\\{ (h,h^{\\prime},n_2,n^{\\prime}_2): 1 \\leq h^{\\prime} \\leq H; 1\\ll n_2 \\ll N_2; n_2 h^{\\prime} = n^{\\prime}_2 h \\}|.")]]

#text("From the divisor bound, we see that for each fixed ")#mi("{n_2, h^{\\prime}}")#text(" there are ")#mi("{O(x^{o(1)})}")#text(" choices for ")#mi("{n^{\\prime}_2,h}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\sum_l \\nu(l)^2 \\ll x^{o(1)} N_2 H.")]]

#text("From this, ")#link(<tao-305f2522484988d66f36>)[#text("(18)")]#text(", and Cauchy-Schwarz, we see that to prove ")#link(<tao-65cc63a4e10ee8f05be4>)[#text("(17)")]#text(" it will suffice to show that ")#metadata(none) <tao-0fb532081657b0142eaa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\sum_{l \\in {\\bf Z}/d{\\bf Z}} |\\sum_{1 \\leq k \\leq K: (l+kr,d)=1} (Hkr/N_2)^j")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n_3: (n_3,d)=1} \\psi_3(n_3) e_d( \\frac{a}{(l+kr) n_3})|^2")]]

#align(center)[#tao-fit-display[#mitex("\\ll x^{-2\\epsilon} B^{2} K^2 N_2 N_3^2 H^{-1}.")]]

#text("Comparing with the trivial bound of ")#mi("{O( d N_3^2 K^2 )}")#text(", our task is now to gain a factor of more than ")#mi("{\\frac{B^2Hd}{N_2}}")#text(" over the trivial bound.")

#text("We square out ")#link(<tao-0fb532081657b0142eaa>)[#text("(19)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq k,k^{\\prime} \\leq K}\\sum_{l \\in {\\bf Z}/d{\\bf Z}: (l+kr,d)=(l+k^{\\prime}r,d)=1} (Hkr/N_2)^j (Hk^{\\prime}r/N_2)^j")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n_3,n^{\\prime}_3: (n_3,d)=(n^{\\prime}_3,d)=1} \\psi_3(n_3) \\overline{\\psi_3}(n_3) e_d( \\frac{a}{(l+kr)n_3)} - \\frac{a}{(l+k^{\\prime}r)n^{\\prime}_3} ).")]]

#text("If we shift ")#mi("{l}")#text(" by ")#mi("{kr}")#text(", then relabel ")#mi("{k^{\\prime}-k}")#text(" by ")#mi("{k}")#text(", and use the fact that ")#mi("{Hkr/N_2, Hk^{\\prime}r/N_2 = O(1)}")#text(", we can reduce this to")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\left|k\\right| \\leq K}", block: true)]]

#align(center)[#tao-fit-display[#mitex("|\\sum_{l \\in {\\bf Z}/d{\\bf Z}: (l,d)=(l+kr,d)=1} \\sum_{n_3,n^{\\prime}_3: (n_3,d)=(n^{\\prime}_3,d)=1}")]]

#align(center)[#tao-fit-display[#mitex("\\psi_3(n_3) \\overline{\\psi_3}(n_3) e_d( \\frac{a}{ln_3} - \\frac{a}{(l+kr)n^{\\prime}_3} )|")]]

#align(center)[#tao-fit-display[#mitex("\\ll x^{-2\\epsilon} B^{2} K N_2 N_3^2 H^{-1}.")]]

#text("Next we perform another completion of sums, this time in the ")#mi("{n_3,n^{\\prime}_3}")#text(" variables, to bound")

#align(center)[#tao-fit-display[#mitex("|\\sum_{l \\in {\\bf Z}/d{\\bf Z}: (l,d)=(l+kr,d)=1} \\sum_{n_3,n^{\\prime}_3: (n_3,d)=(n^{\\prime}_3,d)=1}")]]

#align(center)[#tao-fit-display[#mitex("\\psi_3(n_3) \\overline{\\psi_3}(n_3) e_d( \\frac{a}{ln_3} - \\frac{a}{(l+kr)n^{\\prime}_3} )|")]]

#text("by")

#align(center)[#tao-fit-display[#tao-math("\\ll x^{o(1)} \\sum_{\\left|m\\right|, \\left|m^{\\prime}\\right| \\leq M^{\\prime}} (\\frac{N_3}{d})^2 \\left| U(k; m,m^{\\prime}; d)\\right|+ x^{-A}", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(", where ")#metadata(none) <tao-b1f629a0f2f7f9718531>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("M^{\\prime} := x^{\\epsilon} \\frac{d}{N_3}")]]

#text("(the prime is there to distinguish this quantity from ")#mi("{M}")#text(" in the introduction) and")

#align(center)[#tao-fit-display[#mitex("U(k;m,m^{\\prime};d) := \\sum_{l \\in {\\bf Z}/d{\\bf Z}: (l,d)=(l+kr,d)=1} \\sum_{n_3,n^{\\prime}_3 \\in ({\\bf Z}/d{\\bf Z})^\\times}")]]

#align(center)[#tao-fit-display[#mitex("e_d( \\frac{a}{ln_3} - \\frac{a}{(l+kr)n^{\\prime}_3} + mn_3 - m^{\\prime} n^{\\prime}_3).")]]

#text("Making the change of variables ")#mi("{t := \\frac{a}{n_3}\\ (d)}")#text(" and ")#mi("{t^{\\prime} := \\frac{a}{n^{\\prime}_3}\\ (d)}")#text(" and comparing with")#link(<tao-a5fa3952260e2550a72e>)[#text("(5)")]#text(", we see that")

#align(center)[#tao-fit-display[#mitex("U(k;m,m^{\\prime};d) = T( kr; am, am^{\\prime}; d).")]]

#text("Applying Theorem ")#link(<tao-3b64db95cb55c763391c>)[#text("4")]#text(" (and recalling that ")#mi("{a \\in ({\\bf Z}/d{\\bf Z})^\\times}")#text(") we reduce to showing that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\left|k\\right| \\leq K} \\sum_{\\left|m\\right|, \\left|m^{\\prime}\\right| \\leq M^{\\prime}} \\frac{(kr,m-m^{\\prime},d)}{(kr,d)^{1/2}} (\\frac{N_3}{d})^2 d^{3/2} \\ll x^{-3\\epsilon} B^{2} K N_2 N_3^2 H^{-1}.", block: true)]]

#text("We now choose ")#mi("{r}")#text(" to be a factor of ")#mi("{d}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("d = qr")]]

#text("for some ")#mi("{q}")#text(" coprime to ")#mi("{r}")#text(". We compute the sum on the left-hand side:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7")]#text(" We have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\left|k\\right| \\leq K} \\sum_{\\left|m\\right|, \\left|m^{\\prime}\\right| \\leq M^{\\prime}} \\frac{(kr,m-m^{\\prime},d)}{(kr,d)^{1/2}}", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll x^{o(1)} ( M^{\\prime} r^{1/2} K + M^{\\prime} d^{1/2} + (M^{\\prime})^2 K r^{-1/2} ).")]]
]

#emph[#text("Proof:")]#text(" We first consider the contribution of the diagonal case ")#mi("{m=m^{\\prime}}")#text(". This term may be estimated by")

#align(center)[#tao-fit-display[#tao-math("\\ll M^{\\prime} \\sum_{\\left|k\\right| \\leq K} (kr,d)^{1/2} = M^{\\prime} r^{1/2} \\sum_{\\left|k\\right| \\leq K} (k,q)^{1/2}.", block: true)]]

#text("The ")#mi("{k=0}")#text(" term gives ")#mi("{M^{\\prime}d^{1/2}}")#text(", while the contribution of the non-zero ")#mi("{k}")#text(" are acceptable by Lemma ")#link(<tao-1956d1f0ee17f894f80d>)[#text("5")]#text(".")

#text("For the non-diagonal case ")#mi("{m \\neq m^{\\prime}}")#text(", we see from Lemma ")#link(<tao-1956d1f0ee17f894f80d>)[#text("5")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\left|m\\right|,\\left|m^{\\prime}\\right| \\leq M^{\\prime}: m \\neq m^{\\prime}} (kr,m-m^{\\prime},d) \\ll x^{o(1)} (M^{\\prime})^2;", block: true)]]

#text("since ")#mi("{(kr,d) \\geq r}")#text(", we obtain a bound of ")#mi("{O( x^{o(1)} (M^{\\prime})^2 K r^{-1/2} )}")#text(" from this case as required. ")#mi("\\Box")

#text("From this lemma, we see that we are done if we can find ")#mi("{r}")#text(" obeying ")#metadata(none) <tao-59548661e252a6f235e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("(M^{\\prime} r^{1/2} K + M^{\\prime} d^{1/2} + (M^{\\prime})^2 K r^{-1/2} ) (\\frac{N_3}{d})^2 d^{3/2} \\ll x^{-4\\epsilon} B^{2} K N_2 N_3^2 H^{-1}.")]]

#text("as well as the previously recorded condition ")#link(<tao-3e11b6c3eef5d583d7be>)[#text("(16)")]#text(". We can split the condition ")#link(<tao-59548661e252a6f235e5>)[#text("(21)")]#text(" into three subconditions:")

#tao-aligned(keep: true)[


#tao-math("M^{\\prime} r^{1/2} d^{-1/2}  & \\ll x^{-4\\epsilon} B^{2} N_2 H^{-1}", block: true)



#tao-math("M^{\\prime} K^{-1}  & \\ll x^{-4\\epsilon} B^{2} N_2 H^{-1}", block: true)



#tao-math("(M^{\\prime})^2 r^{-1/2} d^{-1/2}  & \\ll x^{-4\\epsilon} B^{2} N_2 H^{-1}.", block: true)
]

#text("Substituting the definitions ")#link(<tao-e96e02d8e47f2a7c03be>)[#text("(15)")]#text(", ")#link(<tao-b1f629a0f2f7f9718531>)[#text("(20)")]#text(" of ")#mi("{K, M^{\\prime}}")#text(", we can rewrite all of these conditions as lower and upper bounds on ")#mi("{r}")#text(". Indeed, ")#link(<tao-3e11b6c3eef5d583d7be>)[#text("(16)")]#text(" follows from (say) ")#metadata(none) <tao-dd191696e15e2ee29341>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("r \\ll n^{-2\\epsilon} N_2 H^{-1}")]]

#text("while the other three conditions rearrange to ")#metadata(none) <tao-7ef9ec0cf2c4facafddd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("r \\ll x^{-10\\epsilon} B^{4} N_2^2 N_3^2 H^{-2} d^{-1}")]]

#metadata(none) <tao-95b70fd9f1baf96ea89b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("r \\ll x^{-6\\epsilon} B^{2} N_2^2 N_3 H^{-2} d^{-1}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("r \\gg x^{12\\epsilon} B^{-4} N_2^{-2} N_3^{-4} H^2 d^{3}.")]]

#text("We can combine ")#link(<tao-7ef9ec0cf2c4facafddd>)[#text("(23)")]#text(", ")#link(<tao-95b70fd9f1baf96ea89b>)[#text("(24)")]#text(" into a single condition")

#align(center)[#tao-fit-display[#mitex("r \\ll x^{-10\\epsilon} B^{2} N_2^2 N_3 H^{-2} d^{-1}.")]]

#text("Also, from ")#link(<tao-2b59b6a04f3b9ba1d7b9>)[#text("(9)")]#text(", ")#link(<tao-f998fe06afa0cfbe73e0>)[#text("(13)")]#text(" we see that this new condition also implies ")#link(<tao-dd191696e15e2ee29341>)[#text("(22)")]#text(". Thus we are done as soon as we find a factor ")#mi("{r}")#text(" of ")#mi("{d}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("R_1 \\ll r \\ll R_2")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("R_1 := x^{12\\epsilon} B^{2} N_2^{-2} N_3^{-4} H^2 d^{3}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("R_2 := x^{-6\\epsilon} B^{-4} N_2^2 N_3 H^{-2} d^{-1}.")]]

#text("From ")#link(<tao-b5587bfd231a74fd2aa1>)[#text("(11)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("R_2/R_1 \\gg x^\\delta")]]

#text("if ")#mi("{\\epsilon}")#text(" is sufficiently small. Also, from ")#link(<tao-b5587bfd231a74fd2aa1>)[#text("(11)")]#text(", ")#link(<tao-2b59b6a04f3b9ba1d7b9>)[#text("(9)")]#text(" one also sees that")

#align(center)[#tao-fit-display[#mitex("R_1 \\ll d")]]

#text("and ")#mi("{R_2 \\gg 1}")#text(". As ")#mi("{d}")#text(" is ")#mi("{x^\\delta}")#text("-smooth, we can thus find ")#mi("{r}")#text(" with the desired properties by the greedy algorithm. (In view of Corollary 12 from ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(", one could also have ensured that ")#mi("{q}")#text(" has no tiny factors, although this does not seem to be of much actual use in the Type III analysis.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (83)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234528")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("While writing up the argument I found that the factorisation of the Bombieri-Birch exponential sum for a mdulus d=qr into a modulus q component (which is still of Bombieri-Birch type) and a modulus r component (which is of Ramanujan type) could be more cleanly performed by noting a multiplicativity property of the Bombieri-Birch sum (see the third display in the proof of Theorem 4). This in particular leads to a refinement of Lemma 12 of Zhang that “bakes in” the Ramanujan sum decay more efficiently. This ended up cleaning up the proof (as did application of completion of sums as a black box estimate, without any further need to track Fourier coefficients) but unfortunately did not lead to improved bounds.")

#text("As before, we can record the numerics of the critical case:")

#mi("\\varpi = 1/899 \\approx 0.00111")

#mi("\\delta = 71/154628 \\approx 0.000460")

#mi("N_1=N_2=N_3 = N\\approx x^{47795/154628} \\approx x^{0.309097}")

#mi("M \\approx x/N^3 \\approx x^{0.072710}")

#mi("d \\approx x^{1/2+2\\varpi} \\approx x^{0.502245} \\approx N^{1.62481}")

#mi("x^\\delta \\approx N^{0.001486}")

#mi("M^{\\prime}, H \\approx d/N \\approx N^{0.62481}")

#mi("R_1 \\approx N^{0.124072}")

#mi("R_2 \\approx N^{0.125557}")

#mi("R_1 \\ll r \\ll R_2")

#mi("K \\approx N/Hr \\approx N^{0.387952}/r")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234560")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("This multiplicativity property is a nice observation. It reduces some of the mystery.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234735")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("There is something wrong in the above. I get that ")#mi("K")#text(" is less than 1. Its exponent is ")#mi("0.387952\\times0.309097-0.124\\ldots<0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234736")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("Oh, duh I mixed N and x, sorry!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234535")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("Three thoughts:")

#text("1. The triple exponential sum in Theorem 4 has the unusual property that certain degenerate cases of this sum are ")#emph[#text("smaller")]#text(" than the non-degenerate cases (in particular, beating square root cancellation) – usually the degenerate cases are much larger. This leads to certain “diagonal” terms in the Cauchy-Schwarz analysis being significantly smaller than what one would naively expect them to be. The rarity of this phenomenon (degenerate sums being better behaved than non-degenerate sums) may limit the applicability of this very nice trick of Zhang.")

#text("2. Zhang’s trick should improve the numerical values of the recent preprint of Fouvry, Kowalski, and Iwaniec ")#link("http://arxiv.org/abs/1304.3199")[#text("http://arxiv.org/abs/1304.3199")]#text(" on the level of distribution of ")#mi("\\tau_3")#text(", at least when restricted to smooth moduli. But this is outside the scope of the polymath project and I would presume that FKM are already in the process of working out the details, so I propose that we avoid pursuing this direction here. (But it might be worth leafing through FKM to see if there are any tricks that can also be applied to the Type III sums here.)")

#text("3. The discarding of the ")#mi("\\alpha")#text(" convolution to reduce Theorem 2 to Theorem 3 looks lossy. In particular it seems to me that Theorem 2 only requires an averaged version of Theorem 3 in which the ")#mi("a")#text(" parameter is averaged over a set of length M (the inverse of an arithmetic progression in ")#mi("{\\bf Z}/d{\\bf Z}")#text("). I have a suspicion that completion of sums is less lossy when there is such an averaging, in principle one might gain an additional factor of something like ")#mi("M^{1/2}")#text(". This could lead to some noticeable numerical improvements in the exponents. However, I have not yet worked out the details of this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234561")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("Regarding #1, I too thought this mysterious. I mean, so you Weyl shift by multiples of ")#mi("r")#text(" – why doesn’t that just give you something like ")#mi("e_r(0)")#text(" (and thus no cancellation) rather than a Ramanujan sum (with residue-class differences as an argument)? This is still a philosophy disparity for me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234587")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("Actually, now that I think about it, I know another context in which partly degenerate exponential sums have better cancellation than non-degenerate sums. Consider a quadratic exponential sum ")#mi("\\sum_{n \\in {\\bf Z}/p{\\bf Z}} e_p( an^2 + bn)")#text(" for some odd prime ")#mi("p")#text(". When ")#mi("a")#text(" is non-zero this is a Gauss sum and has square root cancellation – the magnitude is exactly ")#mi("\\sqrt{p}")#text(". But when ")#mi("a")#text(" degenerates to zero while ")#mi("b")#text(" stays non-zero, we get perfect cancellation – the magnitude is now zero! Of course, when ")#mi("a")#text(" and ")#mi("b")#text(" both degenerate, there is no cancellation whatsoever and the sum jumps up to ")#mi("p")#text(".")

#text("With the Birch-Bombieri sum ")#mi("\\sum_{l \\in {\\bf Z}/q{\\bf Z}: (l,q)=(l+k,q)=1} \\sum_{t,t^{\\prime} \\in ({\\bf Z}/q{\\bf Z})^\\times} e_q( \\frac{t}{l} - \\frac{t^{\\prime}}{l+k} + \\frac{m}{t} - \\frac{m^{\\prime}}{t^{\\prime}} )")#text(" there is a qualitatively similar phenomenon: square root cancellation in the fully non-degenerate case, better than square root cancellation in the partially degenerate case (")#mi("k")#text(" has a common factor with ")#mi("q")#text(" but ")#mi("m-m^{\\prime}")#text(" does not), and huge in the completely degenerate case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234855")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2013")])]

#text("FKI should be FKM…. (Fouvry-K.-Michel)")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ph.M")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-235003")[#strong[#text("Ph.M")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("Regarding # 2.")#linebreak()#text(" In fact, when an averaging over conveniently factorable moduli is available (as in this case here) we checked is it possible to get a quite high exponent of distribution (up to 4/7). The argument is simpler than Zhang’s treatment and in fact should improve Zhang type III sums quite a bit. See one of Emmanuel’s forth coming blog.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-235174")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("If I take this comment in the most direct sense, we have ")#mi("4/7=1/2+2\\omega")#text(" when ")#mi("\\omega=1/28")#text(". With no ")#mi("\\kappa")#text(" or ")#mi("\\delta")#text(" this would give ")#mi("k_0=110")#text(", but perhaps other aspects will break.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-235199")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("We would then have H(110)=628 (from Engelsma’s tables).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-235213")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("If the Type III sums became that good then the bottleneck then comes from the Type I/II sums (which currently has a constraint of the form ")#mi("37 \\varpi + 5\\delta < \\frac{1}{4}")#text(") and also the combinatorial analysis (which has a constraint ")#mi("\\sigma > 1/10")#text(", which when combined with the constraint ")#mi("11\\varpi + 3\\delta+ 2\\sigma < \\frac{1}{4}")#text(" coming from the Type I analysis gives that ")#mi("11 \\varpi + 3 \\delta < \\frac{1}{20}")#text("). The second barrier is a bit stronger, so there is a barrier to ")#mi("\\varpi")#text(" getting past ")#mi("1/220")#text(" at present, but we have basically made no efforts to attack these barriers yet as they have not come close to the battlefront thus far, and presumably they can be knocked back a bit. But in any event I foresee that the Type III sums will cease to become critical in the near future, and we will have to turn our attention elsewhere to get gains.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ph.M")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-235218")[#strong[#text("Ph.M")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("Actually, the exponent ")#mi("4/7")#text(" is for the distribution of ")#mi("d_3")#text(" which is “smoother” than the actual type III which includes some small non smooth factor ( the variable ")#mi("m\\sim M")#text(") so the ")#mi("4/7")#text(" exponent is relative to ")#mi("x/M")#text(" rather than ")#mi("x")#text(". We will write this up.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-235226")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("Naively, if one assumes a ")#mi("4/7")#text(" level of distribution for the ")#mi("d_3")#text(" component of the type III sums, one expects a condition of the form")

#mi("x^{1/2 + 2 \\varpi} \\ll (N_1 N_2 N_3)^{4/7}")

#text("(ignoring epsilons) which on plugging in the critical case ")#mi("N_1=N_2=N_3 = x^{(1/2+\\sigma)/2}")#text(" from the combinatorial analysis gives")

#mi("\\frac{1}{2} + 2 \\varpi < \\frac{4}{7} \\frac{3}{2} (\\frac{1}{2} + \\sigma )")

#text("thus")

#mi("\\sigma > \\frac{1}{12} + \\frac{7}{3} \\varpi")#text(".")

#text("From Type I analysis (and ignoring ")#mi("\\delta")#text(" and infinitesimals) we can take ")#mi("\\sigma = 1/8 - 11 \\varpi/2")#text(" so this gives a constraint ")#mi("\\varpi < 1/188")#text(", but this is unfortunately occluded by the existing constraint ")#mi("\\varpi < 1/220")#text(" coming from the requirement ")#mi("\\sigma > 1/10")#text(". It may well be that one can also exploit the ")#mi("\\alpha")#text(" averaging as we are currently doing but this will only serve to weaken the ")#mi("\\varpi < 1/188")#text(" threshold and not the ")#mi("\\varpi < 1/220")#text(" one. So my prediction is that the Type III improvement will be strong enough that it no longer provides the dominant obstruction to bounds, with the combinatorial constraint ")#mi("\\sigma > 1/10")#text(" (combined with the constraint ")#mi("11 \\varpi + 2 \\sigma < 1/4")#text(" from the Type I analysis) dominating instead, and basically placing ")#mi("\\varpi")#text(" close to ")#mi("1/220")#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7feb2d1548597db2d2afcc77a00b855afbeb308f2a2e8c8e819c35d6ef5f97d7-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234549")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("“Chiense” should be “Chinese”")

#text("In equation (8) there is an extra left-hand absolute value sign. [It might be more readable to make some of the absolute value signs bigger, so it is clear they encompass some of the sums.]")

#text("In the third offset equation above (8), it appears that a right-hand absolute value sign is missing.")

#text("Sorry for not having any useful things to say about the mathematics. I am enjoying reading these posts.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a1601f9213e63b0afacbfcfdd6c69b7ddbfe478031a2786e64cc69a4a1bfafd2-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234555")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("I did have one question, about the definition of “coefficient sequence”. Isn’t every finitely supported sequence a coefficient sequence? From the finite support, we know that the image of the sequence is bounded. But for sufficiently large x, log(x) then dominates. (Or is x not independent of n and ")#mi("\\alpha")#text(" somehow?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234562")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("I had the same fret, reading this definition before. It’s finitely supported, but has some asymptotic bounds? I guess this needs to be interpreted, as saying that the constants in the ")#mi("\\ll")#text(" have been picked before hand?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234569")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("Every ")#emph[#text("fixed")]#text(" (i.e. independent of x) finitely supported sequence is a coefficient sequence, but a finitely supported sequence that depends on x need not be a coefficient sequence. (The distinction between quantities that depend on the asymptotic parameter ")#mi("x")#text(", and quantities independent of that parameter (which are called “fixed”) here, forms the basis of what I call “")#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/")[#text("cheap nonstandard analysis")]#text("“, which allows one to work rigorously with asymptotic notation without having to deploy the full machinery of nonstandard analysis. It is briefly introduced in the earliest of this series of posts, back at ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")]#text(" .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f64284d9c4595e03ea31ecd7f4f06eecc235a01ef1d10e8ef622f93a3660d8f-57ec4e7d7b31bf8451a65ff4b2f3adeb35b663a11811b6f561de23e7f86a5dbd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gaston Rachlou")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234657")[#strong[#text("Gaston Rachlou")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("In my humble opinion, this terminology is not a very happy innovation, and could be replaced with no harm by its definition, accessible to any mathematician. One has to understand that your ")#mi("\\alpha(n)")#text(" is in fact a ")#mi("\\alpha(n,x)")#text(". Moreover, it is not immediately clear if the support of this sequence (supposed to be finite for ")#mi("x")#text(" fixed) depends on ")#mi("x")#text(" or not.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234664")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("To quote from the ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("first post in this series")]#text(" where this notation is introduced:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("“Some mathematical objects (such as ")#mi("{\\mathcal H}")#text(" and ")#mi("k")#text(") will be independent of ")#mi("x")#text(" and referred to as ")#emph[#text("fixed")]#text("; but unless otherwise specified we allow all mathematical objects under consideration to depend on ")#mi("x")#text(".”")
]

#text("The alternative would be to explicitly subscript almost every quantity (other than the fixed ones) in these posts by ")#mi("x")#text(", which would be quite distracting, since this dependence occurs for most of the objects introduced in the post and thus is better suited to be the default assumption in one’s notation as specified above, rather than the other way around. (For instance, in the above post, the objects ")#mi("\\alpha, \\beta, \\nu, \\psi, \\psi_1, \\psi_2, \\psi_3, a, b, b_1, b_2, d, d_1, d_2, k, l, m, m^{\\prime}, n")#text(", ")#mi("n_1, n_2, n_3, p, q, r, t, t^{\\prime}, x")#text(", ")#mi("F, I, H, K, M, N")#text(", ")#mi("N_1, N_2, N_3")#text(", ")#mi("R_1, R_2, X, Y")#text(" and associated structures (e.g. the support of ")#mi("\\alpha")#text(") are allowed to depend on ")#mi("x")#text(" or to be bound to a range depending on ")#mi("x")#text(" (as indicated by the default convention that is in force throughout these posts), with only ")#mi("\\delta, \\varepsilon, \\varpi, c, i, j, A, A_0")#text(" declared as fixed.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234632")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("The Bombieri-Birch bound in Theorem 4 is given in long outline form above, although presumably this wasn’t re-argued in Zhang’s paper, am I right? In expression (6), it seems that ")#mi("p")#text(" is the same thing as the ")#mi("q")#text(" assumed prime about four lines above, in the “case when ")#mi("q")#text(" is prime” . It seems Zhang’s proof of Theorem 3 involves invoking the Bombieri-Birch triple exponential sum bound of Theorem 4, and all that lies in Section 2 of the post, starting at expression (7) till the end of Section 2; is that about right? Finally, my intuition is that Theorem 2 is not so hard, given Theorem 3, and the “hard theorem” would be Theorem 3, Zhang’s Type III estimate without ")#mi("\\alpha")#text(" …")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234636")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("Yes, this is basically correct. Theorem 4 above corresponds to Lemma 11 in Zhang, although Theorem 4 is also recording an additional cancellation in the degenerate case when k has a shared factor with q but not m-m’; this cancellation was implicit in Section 14 but it seems simpler to place it in Theorem 4 instead.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234670")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("I think I can indeed get some gain here from working with an averaged version of Theorem 3. More precisely, if one inspects the derivation of Theorem 2 from Theorem 3, we see that it actually suffices to replace the conclusion of Theorem 3 by the weaker")

#tao-math("\\left|{\\bf E}_{a \\in A} c_a \\Delta(\\psi_1 \\ast \\psi_2 \\ast \\psi_3; a)\\right| \\ll x^{-\\varepsilon} \\frac{N_1 N_2 N_3}{d}", block: false)

#text("where ")#mi("A := \\{ a_0/m: M \\ll m \\ll M \\} \\subset ({\\bf Z}/d{\\bf Z})^\\times")#text(" for some ")#mi("a_0 \\in ({\\bf Z}/d{\\bf Z})^\\times")#text(" and the coefficients ")#mi("c_a")#text(" are ")#mi("O(1)")#text(". (In the regime of interest we have ")#mi("M \\ll d")#text(".)")

#text("If we run the arguments of Section 2 carrying this new averaging in A with us, (8) becomes")

#tao-math("\\sum_{1 \\leq h \\leq H} \\left| {\\bf E}_{a \\in A} c_a \\sum_{n: (n,d)=1} \\psi_2 \\ast \\psi_3(n) e_d(\\frac{ah}{n})\\right| \\ll x^{-\\varepsilon} N_2 N_3", block: false)

#text("and the conclusion of Proposition 6 is similarly replaced with")

#tao-math("\\sum_{1 \\leq h \\leq H: (h,d)=1} \\left| {\\bf E}_{a \\in A} c_a \\sum_{n: (n,d)=1} \\psi_2 \\ast \\psi_3(n)  e_d(\\frac{ah}{n})\\right| \\ll x^{-\\varepsilon} N_2 N_3", block: false)#text(".")

#text("Continuing the argument through to (19), we see that (19) is replaced with")

#mi("\\sum_{l \\in {\\bf Z}/d{\\bf Z}} | \\sum_{1 \\leq k \\leq K: (l+kr,d)=1}")

#mi("{\\bf E}_{a \\in A} c_a \\sum_{n_3: (n_3,d)=1} \\psi_3(n_3) e_d(\\frac{a}{(l+kr)n_3})|^2")

#mi("\\ll x^{-2\\varepsilon} K^2 N_2 N_3^2 H^{-1}")

#text("Squaring this out and continuing the arguments of the main post, we see that it suffices to establish the bound")

#tao-math("\\sum_{\\left|k\\right| \\leq K} \\sum_{\\left|m\\right|, \\left|m^{\\prime}\\right| \\leq M^{\\prime}} {\\bf E}_{a,a^{\\prime} \\in A} (\\frac{N_3}{d})^2\\left|T(kr; am, a^{\\prime}m^{\\prime}; d)\\right|", block: false)

#mi("\\ll x^{-3\\varepsilon} K N_2 N_3^2 H^{-1};")

#text("note crucially that the third argument of the exponential sum ")#mi("T")#text(" now acquires a factor of a’ instead of a. Using Theorem 4, the left-hand side is essentially bounded by")

#tao-math("\\sum_{\\left|k\\right| \\leq K} \\sum_{\\left|m\\right|, \\left|m^{\\prime}\\right| \\leq M^{\\prime}} {\\bf E}_{a,a^{\\prime} \\in A} (\\frac{N_3}{d})^2", block: false)

#mi("\\frac{(kr,am-a^{\\prime}m^{\\prime},d)}{(kr,d)^{1/2}}.")

#text("The key point here is that generic ")#mi("a,a^{\\prime} \\in A")#text(" are usually coprime, making the diagonal case ")#mi("am=am^{\\prime}")#text(" somewhat rarer than the diagonal case ")#mi("m=m^{\\prime}")#text(" considered in Lemma 7. Writing ")#mi("a =  b/\\tilde m")#text(", ")#mi("a^{\\prime} = b/\\tilde m^{\\prime}")#text(" for ")#mi("\\tilde m, \\tilde m^{\\prime} \\sim M")#text(", one can rewrite")

#mi("(kr,am-a^{\\prime}m^{\\prime},d) = (kr,\\tilde m^{\\prime}m - \\tilde m m^{\\prime}, d)")

#text("and by using the divisor bound this is basically back to the situation in Lemma 7 but with m, m’ now ranging at scale O(MM’) rather than just O(M’). As such, the first two terms on the RHS of Lemma 7 acquire an additional factor of M^{-1} after performing the averaging in a,a’. According to my calculations, this allows one to loosen the constraint")

#mi("N_2^4 N_3^5 \\gg d^4 H^4 x^{\\delta+c}")

#text("in Proposition 6 with the pair of constraints")

#mi("M N_2^4 N_3^5 \\gg d^4 H^4 x^{\\delta+c}")

#mi("N_2^3 N_3^4 \\gg d^3 H^2 x^{\\delta+c}")

#text("(the latter condition comes from (22) which is no longer so obviously dominated by (24), although it will ultimately still be redundant in the final analysis after optimising with the Type I/II analysis). This means that we can replace")

#mi("N_1^4 N_2^4 N_3^5 \\gg x^{4+16\\varpi+\\delta+c}")

#text("in Theorem 2 with")

#mi("M N_1^4 N_2^4 N_3^5 \\gg x^{4+16\\varpi+\\delta+c}")

#text("and")

#mi("N_1^2 N_2^3 N_3^4 \\gg x^{5/2 + 10\\varpi+\\delta+c}.")

#text("The former constraint is equivalent to")

#mi("N_1^3 N_2^3 N_3^4 \\gg x^{3+16\\varpi+\\delta+c}.")

#text("Returning to the combinatorial analysis, the necessary condition")

#mi("\\frac{13}{2} (\\frac{1}{2}+\\sigma) > 4 + 16 \\varpi + \\delta")

#text("is now relaxed to the combination of")

#mi("5 (\\frac{1}{2}+\\sigma) > 3 + 16 \\varpi + \\delta")

#text("and")

#mi("\\frac{9}{2} (\\frac{1}{2}+\\sigma) > \\frac{5}{2} + 10 \\varpi + \\delta")

#text("which, upon setting ")#mi("\\sigma")#text(" close to ")#mi("1/8 - 11/2 \\varpi - 3/2 \\delta")#text(" (and also recalling the condition ")#mi("\\sigma > 1/10")#text(") becomes (if all my calculations are correct)")

#mi("87 \\varpi + 17 \\delta < 1/4")

#text("and")

#mi("139 \\varpi + 13 \\delta < 5/4")

#text("and")

#mi("11 \\varpi + 3 \\delta < \\frac{1}{20}.")

#text("The second and third conditions are weaker than the first so we are left with ")#mi("87 \\varpi + 17 \\delta < 1/4")#text(", which would be a significant improvement over the previous bound of ")#mi("207 \\varpi + 43 \\delta < 1/4")#text(".")

#text("Needless to say, this should all be checked, and should be currently viewed as provisional, but I'm optimistic that we have a good gain here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234676")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("I have been too busy to be PolyMathing recently, but I think that the work of Ping Xi on Burgess for Kloosterman sums that I mentioned in the other thread has good hope of some improvement on the other end of things. The main technical issue is to pass from prime to composite moduli (and write the details of the proof in the first place) w/o losing too much, which is not always trivial in a Burgess setting (it is not simply CRT) vis-a-vis coprimality accounting.")

#text("I contend that the main “problem” with 13&14 was that the diagonal was so dominant (that K needed to be so big), and so your idea seems to quell it via averaging. What is the critical K with these provisional parameters?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234721")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("I agree that this $m$-averaging should in principle work. But to verify all the details I still need to change your notation into my notation (and compare to Zhang’s notation, particularly ensuring that “m” is not confused with “m” any where).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234751")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("I think the redundant inequality near the end should have ")#mi("31\\delta")#text(" instead of ")#mi("33\\delta")

#emph[#text("[Corrected, thanks; also I added the additional constraint ")#mi("\\sigma > 1/10")#text(" from the combinatorial analysis. Fortunately, neither of these corrections ended up affecting the headline bound. -T]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234675")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("Do we know approximately what value this would imply for ")#mi("k_0")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234677")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("I think ")#mi("\\omega=1/382")#text(" and ")#mi("k_0=6330")#text(" works, but I have to run.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234691")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("Here’s what I get with this choice of parameters (ignoring infinitesimals):")

#mi("\\omega = 1/382 \\approx 0.002618")

#mi("k_0 = 6330")

#mi("\\delta = 1/764 \\approx 0.001309")

#text("and")

#mi("\\frac{1+4\\varpi}{j_{k_0-2}^2 / k_0(k_0-1)} \\approx 1.00005395")

#text("which gives us about ")#mi("5.395 \\times 10^{-5}")#text(" of room for ")#mi("\\kappa")#text(" and ")#mi("\\kappa^{\\prime}")#text(". Using Gergely’s first improved value")

#mi("\\kappa = \\sum_{1 \\leq n < \\frac{1+4\\varpi}{4\\delta}} \\frac{3^n+1}{2} \\frac{k_0^n}{n!} (\\int_{4\\delta/(1+4\\varpi)}^1 (1 - t)^{k_0/2}\\ \\frac{dt}{t})^n")

#mi("\\kappa^{\\prime} = \\sum_{2 \\leq n < \\frac{1+4\\varpi}{4\\delta}} \\frac{3^n-1}{2} \\frac{(k_0-1)^n}{n!} (\\int_{4\\delta/(1+4\\varpi)}^1 (1 - t)^{(k_0-1)/2}\\ \\frac{dt}{t})^n")

#text("of ")#mi("\\kappa,\\kappa^{\\prime}")#text(" (the derivation of which is now in the main post of ")#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/")[#text("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/")]#text(" ), I get ")#mi("\\kappa \\approx 5.25 \\times 10^{-5}")#text(" and ")#mi("\\kappa^{\\prime} \\approx 1.39 \\times 10^{-9}")#text(", so the bar looks like it is cleared (though I do not have an error analysis on the numerical integration I performed). With Gergely’s provisional values of ")#mi("\\kappa,\\kappa^{\\prime}")#text(" I get essentially the same result. So I am happy to confirm the ")#mi("k_0=6330")#text(" value once the ")#mi("84\\varpi+17\\delta < 1/4")#text(" condition is confirmed.")

#text("For the above values of ")#mi("\\varpi,\\delta")#text(", we can recalculate the critical numerology as follows:")

#mi("\\sigma = \\frac{1}{8} - \\frac{11 \\varpi}{2} - \\frac{3 \\delta}{2} = \\frac{83}{764} \\approx 0.108639")

#mi("N_1 = N_2 = N_3 = N = x^{(1/2+\\sigma)/2} \\approx x^{0.304319}")

#mi("M \\approx x/N^3 \\approx x^{0.08704}")

#mi("d \\approx x^{1/2+2\\varpi} \\approx x^{0.505237}")

#mi("H \\approx M^{\\prime} \\approx d/N \\approx x^{0.200916}")

#mi("x^{0.091623} \\ll r \\ll x^{0.09293}")

#mi("x^{0.010471} \\ll K \\ll x^{0.011780}")

#text("So K is looking a lot smaller than it used to be (in the previous critical case, it was closer to ")#mi("x^{0.26}")#text(").")

#text("I have to run, but I will try to confirm Gergely’s new provisional argument for ")#mi("\\kappa,\\kappa^{\\prime}")#text(" soon (and maybe sneak a look at the Ping Xi paper, though this may have to wait a bit). I’ll also have to double-check the ")#mi("84\\varpi+17\\delta < 1/4")#text(" argument, though if someone else could also have a look at this, that would be great.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234693")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("I get ")#mi("\\omega=1/381.6")#text(" allows ")#mi("k_0=6329")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234694")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("In fact, ")#mi("\\omega=1/382")#text(" also allows ")#mi("k_0=6329")#text(" (just barely), not sure why I missed it the first time around, but I was in a hurry. I will try to sort through the new argument for 13&14. The condition is “87” omega, correct? In the latter comment you twice have “84”. I will work thru it in any case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234707")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("Oops, sorry about that, that was a typo and I have just corrected it. Yes, the correct condition (I believe) is ")#mi("87 \\varpi + 17 \\delta < \\frac{1}{4}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234697")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("Sounds great. For ")#mi("k_0=6329")#text(" I get ")#mi("\\frac{1+4\\varpi}{j_{k_0-2}^2 / k_0(k_0-1)} \\approx 1.00005288")#text(", while the provisional ")#mi("1+\\kappa")#text(" is a bit smaller, about ")#mi("1.00005267")#text(". BTW I am more confident about the provisional ")#mi("\\kappa")#text(" and ")#mi("\\kappa^{\\prime}")#text(" now, but I also apologize for any failures, past and future.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234709")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("Note that by decreasing ")#mi("k_o")#text(" by 1, the change in the denominator of the LHS ratio seems to be ")#mi("o(1/ k_0)")#text(" since the asymptotic expansion of ")#mi("j_n")#text(" starts with n. Hence, small changes in ")#mi("\\kappa")#text(" results in LARGER relative changes of ")#mi("k_0")#text(".")#linebreak()#text(" So even this small value of ")#mi("\\kappa")#text(" is perhaps still not negligible, and further work on its reduction may be important for such values of")#linebreak()#text(" ")#mi("k_0")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234739")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("I think the gain from the above is in some sense from the betterment of the last line of page 50 of Zhang on the diagonal estimation, replacing the crude worst-case bound of ")#mi("q\\sim x^{0.41}")#text(" with an on-average bound, perhaps not as good as ")#mi("N_3/r\\sim x^{0.21}")#text(" (I am still checking details, this is the length of the sum, so you can’t beat that) but enough to make ")#mi("K")#text(" rather harmless.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234742")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("According to my ansatz, there are three terms, namely the Weyl shift error which is ")#mi("drKMN_3")#text(", the ")#mi("K")#text("-diagonal error which is dominated by ")#mi("m=m^{\\prime},n=n^{\\prime}")#text(" giving ")#mi("dN_1\\sqrt{MN_3/K}")#text(", and the BB-Deligne term which is ")#mi("d^{5/4}MN_1/r^{1/4}")#text(", the savings being from the Zhang trick. Previously the second (diagonal term) was ")#mi("dMN_1\\sqrt{N_3/K}")#text(", so the ")#mi("M")#text("-average saved ")#mi("\\sqrt {M}")#text(" (i.e., the ")#mi("M")#text("-diagonal now dominates the double ")#mi("m")#text("-sum, sqrt due to Cauchy of course). Oh, there is also the ")#mi("r")#text("-modulus error which I think is the same as the Weyl shift, but with ")#mi("N_1")#text(" instead of ")#mi("N_3")#text(". Now to check the final numbers…")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234745")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("Noting that ")#mi("N_1\\sqrt{MN_3}=\\sqrt {x}")#text(" in the ")#mi("N_i")#text(" equal case, I get ")#mi("K\\sim x^{4\\omega},r\\sim x^{\\sigma-6\\omega(-\\delta)}")#text(", then ")#mi("1/8\\le 5\\sigma/4-4\\omega-\\delta/4")#text(", and plugging in for ")#mi("\\sigma=1/8-11\\omega/2-3\\delta/2")#text(" gives me ")#mi("1/4\\ge 87\\omega+17\\delta")#text(". Check.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234746")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("So I can be clear, I did not check every detail about how much the ")#mi("M")#text("-average saved (computing all the gcd’s that is), just did enough to convince my self the main ")#mi("m=m^{\\prime}")#text(" term “should” dominate and compute its effect.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234764")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("Thanks for this! The fact that you used a slightly different approach lends more confidence to the confirmation.")

#text("It looks like the main condition ")#mi("87\\varpi + 17\\delta < \\frac{1}{4}")#text(" is still much stronger than all the other necessary conditions that are needed in the analysis, so it should be safe to list this condition as confirmed, as well as the corollary that ")#mi("k_0 = 6229")#text(" (and hence ")#mi("H = 60,744")#text(") are confirmed as well.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234687")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("With the provisional improved values for ")#mi("\\kappa")#text(" and ")#mi("\\kappa^{\\prime}")#text(" (see ")#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234683")[#text("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/#comment-234683")]#text(") I get that ")#mi("(\\varpi,\\delta)=(\\frac{1}{382},\\frac{1}{764})")#text(" and ")#mi("k_0=6329")#text(" is best.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234686")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("Thanks. We then have ")#mi("H(6330) \\le 60830")#text(". But I’m sure this bound will improve.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234717")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")])]

#text("Looks like Polymath8 has made three orders of magnitude of improvement then! (But we’ve cleaned out almost all the low hanging fruit… I’d be surprised if we get more than one more order of magnitude from the rest of the project.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234752")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("If we could make the (sieve) estimates be “")#mi("\\kappa")#text("-free” and “")#mi("\\delta")#text("-free, via some impossible sieving, that would leave ")#mi("\\omega=1/(87\\cdot 4)")#text(" into the ")#mi("1+4\\omega > j_{k_0-2}^2/(k_0)(k_0-1)")#text(", which I find permits ")#mi("k_0=5446")#text(". So any gains there might appear slight.")

#text("I should probably directly compute how much a prospective Burgess-Kloosterman bound would achieve, but I instead will speculate it could be an ")#mi("\\omega")#text(" or two in ")#mi("\\sigma")#text(". Each ")#mi("\\omega")#text(" reduces the “87” by 10, and one such reduction yields the above 5446 down to 4518, and two reductions to 3651. Even still, that is not a halving from currently 6329.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234755")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("For reference, I get ")#mi("H(5446) \\le 51472")#text(", ")#mi("H(4518) \\le 41848")#text(", and ")#mi("H(3651) \\le 33070")#text(" (I expect these can all be improved, but they should be reasonably close to the optimal values).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234757")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("I notice that 3651 is in the range considered by Engelsma (see ")#link("http://www.opertech.com/primes/summary.txt")[#text("http://www.opertech.com/primes/summary.txt")]#text("), and his results imply an upper bound of 33076 (which I suspect involved a lot of computation), whereas the bound 33070 I gave above took less than 5 minutes to find. This suggests that the polymath8 techniques for computing upper bounds on H(k0) are getting pretty good.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234763")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("Thanks for this – it’s good to get some benchmarks for best-case scenarios, even if they don’t project fantastic new gains.")

#text("Incidentally, as we work with larger and larger values of ")#mi("\\varpi")#text(" and ")#mi("\\delta")#text(" (and smaller values of ")#mi("k_0")#text("), other obstacles begin to appear (a bit like how rocks submerged far beneath the ocean surface do not pose a problem for navigation until the ocean level drops too low); for instance the combinatorial analysis has a condition ")#mi("\\sigma > 1/10")#text(" which previously has not been any difficulty whatsoever but will for instance block ")#mi("\\varpi")#text(" from exceeding ")#mi("1/220")#text(" even in the absence of ")#mi("\\delta")#text(" unless the Type I analysis improves or if we can somehow improve the combinatorics.")

#text("Still, we are not completely out of things to try yet, even if I do agree that further progress is going to require increasing effort and we are not going to see the dramatic order-of-magnitude improvements that we had once or twice in the past. At some point the progress will reach a natural plateau, at which point it will be time to turn to the writing up stage of the project.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234775")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("I haven’t checked any details yet, but there may be a way to do the Weyl differencing more efficiently. Right now we shift ")#mi("n_2")#text(" to ")#mi("n_2 + hkr")#text(" for ")#mi("1 \\leq k \\leq K")#text("; this limits the size of ")#mi("K")#text(" to roughly ")#mi("N_2/Hr")#text(". The presence of the ")#mi("h")#text(" allows one to achieve the cancellation")

#mi("\\frac{ah}{n_2 + hkr} = \\frac{a}{l+k}\\ (d)")

#text("where ")#mi("l := n_2/h\\ (d)")#text(". But what if we don’t bother putting ")#mi("h")#text(" in the shift, i.e. only shifting ")#mi("n_2")#text(" to ")#mi("n_2+kr")#text("? This enlarges K significantly, to about ")#mi("N_2/r")#text(", which should help attenuate the diagonal contributions ")#mi("k=k^{\\prime}")#text(" even further. The cost is that the cancellation now looks slightly worse,")

#mi("\\frac{ah}{n_2 + kr} = \\frac{a}{l+\\overline{h} k}\\ (d)")

#text("but I think the ")#mi("\\overline{h}")#text(" factor attached to ")#mi("k")#text(", being coprime to ")#mi("d")#text(", is ultimately harmless in the rest of the argument (at least as far as a quick glance at Theorem 4 suggests), though this certainly needs to be checked. But this may lead to a further noticeable gain in the numerology. (I think someone pointed out in one of the earlier threads that there was potentially more slack in the Type III estimates than the Type I/II estimates, as the latter have already been optimised quite a bit by BFI and other very strong previous authors, whereas the Type III argument is original to Zhang and thus not nearly as optimised.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234779")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("A quick calculation of the numerology:")

#text("With the previous improvement to the arguments, the conditions to verify for Theorem 2 take the shape (ignoring epsilon factors)")

#mi("K \\geq 1")

#text("and")

#mi("M^{-1} M^{\\prime} r^{1/2} K + M^{-1} M^{\\prime} d^{1/2} + (M^{\\prime})^2 K r^{-1/2} \\ll K N_2 N_3^2 H^{-1}")

#text("(the extra factors of ")#mi("M^{-1}")#text(" improving over Lemma 7 is the gain coming from exploiting the averaging from the ")#mi("\\alpha")#text(" factor). With the new idea, ")#mi("K")#text(" gets increased from ")#mi("N_2/Hr")#text(" to ")#mi("N_2/r")#text(". The conditions on ")#mi("r")#text(" now become")

#mi("r \\ll N_2")

#mi("r \\ll N_2^2 N_3^2 H^{-2} d^{-1} M^2")

#mi("r \\ll N_2^2 N_3 H^{-1} d^{-1} M")

#mi("r \\gg N_2^{-2} N_3^{-4} H^2 d^3")#text(".")

#text("The new gain here is in the third inequality which has lost one power of ")#mi("H^{-1}")#text(" on the RHS. (The second inequality is likely to still be redundant as before.) So we end up with the conditions")

#mi("N_2^3 N_3^4 \\gg x^\\delta H^2 d^3")

#mi("M^2 N_2^4 N_3^6 \\gg x^\\delta H^4 d^4")

#mi("M N_2^4 N_3^5 \\gg x^\\delta H^3 d^4")

#text("for the analogue of Proposition 6; I think the main inequality is still the last one, in which one power of H has now been saved over before. The analogue of Theorem 2 then acquires the conditions")

#mi("N_1^2 N_2^3 N_3^4 \\gg x^{5/2 + 10 \\varpi + \\delta}")

#mi("M^2 N_1^4 N_2^4 N_3^6 \\gg x^{4 + 16 \\varpi + \\delta}")

#mi("M N_1^3 N_2^4 N_3^5 \\gg x^{7/2 + 14 \\varpi + \\delta}")

#text("or equivalently")

#mi("N_1^2 N_2^3 N_3^4 \\gg x^{5/2 + 10 \\varpi + \\delta}")

#mi("N_1^2 N_2^2 N_3^4 \\gg x^{2 + 16 \\varpi + \\delta}")

#mi("N_1^2 N_2^3 N_3^4 \\gg x^{5/2 + 14 \\varpi + \\delta}")#text(".")

#text("The first is majorised by the third and can be deleted. This leads to the constraints")

#mi("\\frac{9}{2} (\\frac{1}{2}+\\sigma) > \\frac{5}{2} + 14 \\varpi + \\delta")

#mi("4 (\\frac{1}{2}+\\sigma) > 2 + 16 \\varpi + \\delta")

#text("which on substituting ")#mi("\\sigma = 1/8 - 11\\varpi/2 - 3 \\delta/2")#text(" gives (if my arithmetic is correct)")

#mi("155 \\varpi + 31 \\delta < 1")

#mi("76 \\varpi + 14 \\delta < 1")

#text("The second condition is redundant, so we end up with")

#mi("155 \\varpi + 31 \\delta < 1")#text(".")

#text("The ")#mi("\\sigma > 1/10")#text(" condition coming from combinatorics is now also relevant and gives an additional constraint")

#mi("11\\varpi + 3\\delta < \\frac{1}{20}")#text(". (2)")

#text("This is extremely rough though and there may be errors, I need to double check this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234784")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("One interesting new phenomenon: if one tries to move ")#mi("\\sigma")#text(" past 1/10 (i.e. to go past (2)) then we will have to contend with a new type of sum – a “Type IV sum” if you will – a model case of which is ")#mi("\\psi_1 \\ast \\dots \\ast \\psi_5")#text(" where all ")#mi("\\psi_i")#text(" are smooth and at scale about ")#mi("x^{1/5}")#text(".")

#text("Gotta run, more later…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234787")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("@v08ltu, Harcos: any estimates of what this would yield for ")#mi("k_0")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234805")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("I get ")#mi("\\omega=1/175")#text(" for ")#mi("k_0=1926")#text(", but this breaks condition (2). From that I get ")#mi("\\omega=1/254")#text(" and ")#mi("k_0=3405")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234797")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("Rechecked the numerology. For the analogue of Prop 6, there are actually a few more constraints coming from the requirements ")#mi("1 \\leq r \\leq d")#text(", which take the form")

#mi("dH \\ll N_2 N_3^2")

#mi("dH \\ll M N_2^2 N_3")

#mi("dH^2 \\ll N_2^2 N_3^2 M^2")

#text("but these look very mild; they transform to")

#mi("N_1 N_2 N_3^2 \\gg x^{1+4\\varpi}")

#mi("MN_1 N_2^2 N_3 \\gg x^{1+4\\varpi}")

#mi("N_1 N_2 N_3 M \\gg x^{3/4 + 3 \\varpi}")

#text("which become the extremely weak")

#mi("N_1 N_2 N_3^2 \\gg x^{1+4\\varpi}")

#mi("N_2 \\gg x^{4\\varpi}")

#mi("\\varpi  1/10")#text("). The long-quiescent Type I/II border is also giving a constraint")

#mi("37 \\varpi + 5 \\delta < \\frac{1}{4}")

#text("but this is still majorised by ")#mi("155 \\varpi + 31 \\delta < 1")#text(". So the conditions (1), (2) are still the only necessary conditions in this analysis, representing the need to control the Type I/III and a new Type I/IV border. But if we improve things much more, we may have to fight battles on many fronts at once, including the Type I/II border…")

#text("I will probably write a new blog post on the latest Type III estimate since it now has two major alterations from what is posted above. But this may take a day or two.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35598924aba40ab439ff5ed4cb5ff894b36068a7207a2d5c6df25c5177e5329b-140b0078e2139ec50e93f18d1fbcc653514264b2e9cdbcc86f776076a297e0c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hannes")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234810")[#strong[#text("Hannes")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("155 varpi + 31 delta < 1 (is this what you call (1)?) is dominated by 11 varpi + 3 delta < 1/20")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234804")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("I considered forgetting the ")#mi("h")#text(" from the Weyl shift awhile back, but (after looking at FI) somehow convinced myself that it should not work. Maybe in our context it turns out Ok for some reason.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234815")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("In the notation of Zhang S14, I think the issue is that you don’t have ")#mi("h_1n_2\\equiv h_2n_1")#text(" modulo ")#mi("d_1")#text(" anymore in the ")#mi("\\nu^2")#text(" of the Cauchy, but now just ")#mi("n_2\\equiv n_1")#text(". Thus the contribution is not ")#mi("HN_2")#text(", but ")#mi("H^2N_2")#text(". At least that’s what I think happens, when comparing to what I determined about FI.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234819")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("Hmm, but it seems to me that changing the ")#mi("k")#text(" shift doesn’t change the relation ")#mi("h_1 n_2 = h_2 n_1\\ (d)")#text(" because one is still canceling by ")#mi("h")#text(" in the first display of S14.")

#text("In the notation of Zhang S14, one is starting with a phase of the form")

#mi("e_{d_1}( b h \\overline{(n_2+kr)} \\overline{n_3} )")

#text("if one shifts by kr instead of hkr. We can rewrite this as")

#mi("e_{d_1}( b \\overline{(l+k\\overline{h}r)} \\overline{n_3} )")

#text("where ")#mi("l")#text(" is exactly the same as before, i.e. ")#mi("l = \\bar{h} n_2\\ (d_1)")#text(". So when one does the Cauchy-Schwarz in ")#mi("l")#text(" using ")#mi("\\nu(l)")#text(", I don’t think any of the multiplicity analysis changes; instead, the only thing that is affected (other than the larger value of ")#mi("K")#text(") is that all occurrences of ")#mi("k")#text(" in S14 of Zhang get replaced by ")#mi("k \\overline{h}")#text(", which seems to change absolutely nothing (the ")#mi("\\overline{h}")#text(" gets carried by ")#mi("k")#text(" all the way to the first line of page 53 of Zhang, when it is killed by Theorem 12).")

#text("But perhaps I am missing something…")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234821")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("Oops, I see the problem now – we can’t have terms that depend on ")#mi("h")#text(" if we want to change variables to ")#mi("l")#text(" and take advantage of the Cauchy-Schwarz in ")#mi("l")#text(". That was silly of me. So the idea doesn’t work directly, and I’ll have to retract the claim :-(. I’ll still play around to see if something else can be salvaged though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234823")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("Maybe the point is that the definition of ")#mi("\\nu")#text(" is really a double sum over ")#mi("n_2,h")#text(", so I don’t see how you separate the ")#mi("h")#text("-variable in the Cauchy, considering that you are now carrying it also in ")#mi("P_2")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234824")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("OK, so you found the same thing I did. On the “sociological” level, the reason why I disdained the idea is that FI shifted by ")#mi("h")#text("-multiples, and I would think they were aiming for more optimisation, and this would be the first “obvious” place to manuever. On the theoretical level, it would mean that you could just pull ")#mi("h")#text(" out of the exponential, for instance ")#mi("e_{d_1}^{bh}(...)")#text(" and its effect is then prevalent (you are back at ")#mi("\\sum_h \\hat f(h/d) e^h_d(...)")#text(" with Fourier).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61a01fd743ce054f26be2905ae0e1308310b6eb006b5d84a580aaf37d603f47c-4fbab5bf14d3dd40ddcbc22479d599e469046d9b732bbd460d6b36820779e26c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas J Engelsma")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234777")[#strong[#text("Thomas J Engelsma")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("Nice to see ‘tuples’ active again !!")

#text("Would love to read the Zhang paper, but it is hidden behind wall and I am not affiliated with an university.")

#text("Couple of quick questions, believe the proof is for an infinite number of prime pairings separated by some value less than 70 million. Can the proof be adapted for three primes in a larger interval? Can it then be generalized for ‘n’ primes in some massive interval?")

#text("—")

#text("Reading thru the above, some off my work should be clarified. The chart at ")#link("http://www.opertech.com/primes/varcount.bmp")[#text("http://www.opertech.com/primes/varcount.bmp")]#text(" shows the number of variations that are archived for each width.")

#text("There are 3 colors shown")#linebreak()#text(" green — variations found from true exhaustive search.")#linebreak()#text(" blue — variations found using targeted search routines – close to densest")#linebreak()#text(" red — variations generated from smaller tuples – just best found")

#text("‘Exhaustive search’ was true pruning exhaustive search.")#linebreak()#text(" ‘Targeted search’ was recursive searching of a specific width")#linebreak()#text(" ‘Generated’ was creating tuples using existing patterns (mostly smaller)")#linebreak()#text(" This was done due to the evidence that most tuples had smaller tuples embedded.")

#text("The tuples in the red zone were investigated mainly to see if k(w) stayed above pi(w) or oscillated around pi(w).")#linebreak()#text(" See ")#link("http://www.opertech.com/primes/trophy.bmp")[#text("http://www.opertech.com/primes/trophy.bmp")]#text(" Amazingly, k(w) is concave upward, and every improvement causes it to rise faster.")#linebreak()#text(" (current work implies that there is no inflection point, showing ever growing localized order amid the global chaos of the primes)")#linebreak()#text(" Also, the improvements of k()-pi() were not evenly scattered as w grew, but clustered (the series of red and blue dots) Whenever a series of red dots does not have a corresponding series of blue dots, those tuple widths should be able to be easily improved.")

#text("The headings of the table at ")#link("http://www.opertech.com/primes/summary.txt")[#text("http://www.opertech.com/primes/summary.txt")]#text(" are:")#linebreak()#text(" 1st col — w width of interval, number of consecutive integers")#linebreak()#text(" 2nd col — k [has value if first occurrence of a k]")#linebreak()#text(" 3rd col — k number of admissible elements")#linebreak()#text(" 4th col — k(w) – pi(w) [has value if first occurrence of k()-pi()]")#linebreak()#text(" 5th col — k(w) – pi(w) over pack/under pack quantity relative to prime count")#linebreak()#text(" 6th col — number of variations currently archived")

#text("The number of variations gives a clue if a tuple can be improved. When tuples in the red-zone have 1000s of variations, that width should be able to be improved. When the searching was active, if an improved tuple was found, it was tested to generate 1000 variations.")

#text("—")

#text("Searching has been idle for 4 years, but could be revived.")

#text("Currently, combinatorics is being used to create a counting function F(w,k) that counts the number of unique patterns of ‘k’ primes in an interval of ‘w’ integers. With the function ‘w’ could be fixed and ‘k’ could be varied, thereby providing the ability to know the densest tuple possible without knowing a single prime location within any pattern.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234778")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("Thomas, you may want to take a look at ")#link("http://mathoverflow.net/questions/132731/does-zhangs-theorem-generalize-to-3-or-more-primes-in-an-interval-of-fixed-len")[#text("http://mathoverflow.net/questions/132731/does-zhangs-theorem-generalize-to-3-or-more-primes-in-an-interval-of-fixed-len")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234783")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("Thanks for the info! You may also be interested in the discussion at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://sbseminar.wordpress.com/2013/06/05/more-narrow-admissible-sets/")[#text("More narrow admissible sets")]
]

#text("which is more specifically focused on finding narrow prime tuples of a given length.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234782")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("Hi Thomas, thanks for the chart, and the explanation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234822")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("A small comment (which does not directly improve bounds, unfortunately): of the three coefficient sequences ")#mi("\\psi_1,\\psi_2,\\psi_3")#text(" appearing in the Type III arguments, it is only ")#mi("\\psi_1")#text(" and ")#mi("\\psi_3")#text(" that need to have any sort of smoothness (because we apply completion of sums in these variables); in contrast, the ")#mi("\\psi_2")#text(" sequence is eventually eliminated by Cauchy-Schwarz. So one could in principle replace ")#mi("\\psi_2")#text(" by other coefficient sequences, such as Dirichlet convolutions of lower scale things. This enlarges the class of combinatorial configurations ")#mi("t_1 + \\ldots + t_n = 1")#text(" that are treated by the Type III analysis, but unfortunately does not seem to help in the most important cases (e.g. when ")#mi("n=4")#text(" and ")#mi("t_1=t_2=t_3 > t_4")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234826")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("Gah, I need to retract this also; there is actually a Taylor expansion of ")#mi("\\psi_2")#text(" (which of course exploits smoothness) in the argument that I did not properly document in the blog post above before, I have fixed this now.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234827")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("Yes, this smoothness is exploited in estimating the error from Weyl shifts (below 13.13 in Zhang, with his variable ")#mi("l=n_2+hkr")#text(").")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1e5a1f8fedf06dc288a89076e2da2ef431c2a3d2382d8380d5e54d12189c87e-ed01907680b2daad77e4a6aee1babf0bb370efeae586d3d3cd26d5bb51b23604.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Derek O")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234838")[#strong[#text("Derek O")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("Just a side comment, I’m following this thread and polymath8, and this is just amazing. I’m a math/physics major at University of Pittsburgh with a strong interest in number theory. Unfortunately, I don’t know what half this stuff means, but it’s still awesome! I was blown away when H went from 4.5 million to 400,000 then the most recent drop to 60,000; it’s just incredible to me. Anyway, keep up the great work you guys")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdced175c7d8c91ae6e86b7aca3c987cfbcfd0333d5c51ba3e4a4e04ec66c963-799acab959d8ffa185dacf5e563b1f006bcc02e107944ad31830f6da84782d51.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234851")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("All that’s needed now is Zhang giving the thumbs up!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234841")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("OK, here is another attempt to squeeze a further gain in the Type III sums. I am beginning to suspect that the treatment of the diagonal terms ")#mi("k=k^{\\prime}")#text(" (or ")#mi("k=0")#text(" after shifting ")#mi("k")#text(" by ")#mi("k^{\\prime}")#text(") in Zhang (or in the post above) is suboptimal (in a different way from the suboptimality previously identified by not taking advantage of the ")#mi("\\alpha")#text(" averaging, which for simplicity I will not try to exploit here). Right now, the diagonal terms in ")#mi("k")#text(" are treated together with the off-diagonal terms via expansion into exponential sums, then at some point one applies an exponential sum bound for an inner sum (in the diagonal case case, one uses the bound ")#tao-math("\\left|C_q(n)\\right| \\leq (q,n)", block: false)#text(" on Ramanujan sums, see bottom of page 50 of Zhang) and then uses absolute values and the triangle inequality for the outer sum.")

#text("However if one peels off the diagonal case earlier in the argument then one can do better than the triangle inequality, in particular Plancherel’s theorem (which, being an identity, is 100% efficient) appears to be available. Let me first describe this using Zhang’s original paper. In the bottom of page 48 a key quantity ")#mi("P_2")#text(" is defined, which can be expanded as a sum over pairs ")#mi("k,k^{\\prime} \\sim K")#text(". Let us now deviate from Zhang by immediately isolating the diagonal terms ")#mi("k=k^{\\prime}")#text(" in this sum (as opposed to waiting until the bottom of page 50 to try to control these terms); this expression can be written as")

#tao-math("\\sum_{k \\sim K} \\sum_{l \\in {\\bf Z}/d_1{\\bf Z}: (l+kr,d_1)=1} \\left|\\sum_{n \\sim N^{\\prime}_3: (n,d_1)=1} e_{d_1}( b \\overline{(l+kr) n} )\\right|^2.", block: false)

#text("If we make the change of variables ")#mi("s = \\overline{l+kr}")#text(" this becomes")

#tao-math("\\sum_{k \\sim K} \\sum_{s \\in {\\bf Z}/d_1{\\bf Z}: (s,d_1)=1} \\left|\\sum_{n \\sim N^{\\prime}_3: (n,d_1)=1} e_{d_1}( b s \\overline{n} )\\right|^2.", block: false)

#text("This is an expression which can be estimated almost exactly by Plancherel (the only loss coming from those ")#mi("s")#text(" with a common factor with ")#mi("d_1")#text("), giving a bound of")

#mi("\\sum_{k \\sim K} d_1 (\\sum_{n \\sim N^{\\prime}_3: (n,d_1)=1} 1) \\sim K d_1 N^{\\prime}_3")

#text("which surely must be more accurate than the triangle inequality-based treatment of the diagonal case ")#mi("k=k^{\\prime}")#text(" as is currently present in Zhang’s paper. Since the final bound in the Type III case comes from balancing the diagonal case against the off-diagonal case, this should lead to a gain.")

#text("In the language of the blog post above, one would similarly extract out the diagonal term ")#mi("k=k^{\\prime}")#text(" from (19) (or the display after (19)) and evaluate it separately using Plancherel.")

#text("Tomorrow I will try to work out the precise details of this idea and see if it actually works. Hopefully after two wrong arguments, the third time will be the charm…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234854")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2013")])]

#text("Well, on line 4 of page 51, “it follows that the contribution from the terms with ")#mi("k_1=k_2")#text(" on the right side of (14.6) is ")#mi("\\ll d_1^{1+\\epsilon}KN_3")#text(", so I don’t think you gained anything? Note that Zhang gets Ramanujan in both ")#mi("q")#text(" and ")#mi("r")#text(" on the diagonal (and you improved this in the ")#mi("q")#text("-aspect via the ")#mi("M")#text("-average), so it might be hard to beat.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234885")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2013")])]

#text("Ah, yes, you’re right about this, both with and without the ")#mi("M")#text(" averaging. Using Plancherel basically replaces Ramanujan by a (normalised) Kronecker delta function but yes, the behaviour is basically the same. Back to the drawing board…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234922")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2013")])]

#text("The three tools of the mathematician: the paper, the pencil, and the wastebasket…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-235086")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("Good!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-234932")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2013")])]

#text("Well, this isn’t any direct progress towards improving the bounds, but at least I understand Zhang’s argument a bit better.")

#text("We want to understand how the convolution ")#mi("\\alpha * \\psi_1 * \\psi_2 * \\psi_3")#text(" is distributed in the residue class ")#mi("a\\ (d)")#text(", so we would like to compute the sum")

#mi("\\sum_{n = a\\ (d)} \\alpha * \\psi_1 * \\psi_2 * \\psi_3(n)")#text(".")

#text("with accuracy ")#mi("o( MN_1N_2N_3 / d )")#text(". Fourier jnversion allows one to rewrite this expression as")

#mi("\\frac{1}{d} \\sum_h \\sum_{n_2: (n_2,d)=1} \\sum_{t: (t,d)=1} \\hat \\psi_1( \\frac{h}{d}) \\psi_2(n_2) \\alpha*\\psi_3(t) e_d( \\frac{ah}{n_2t} )")

#text("where")

#mi("\\hat \\psi_1(\\theta) := \\sum_{n_1} \\psi_1(n_1) e(-n_1 \\theta)")

#text("is essentially of size ")#mi("N_1")#text(" when ")#mi("\\theta = O(1/N_1)")#text(" and small elsewhere.")

#text("If we ignore all ")#mi("h")#text(" that are not coprime to ")#mi("d")#text(", we may rearrange this as")

#mi("\\sum_{l \\in {\\bf Z}/d{\\bf Z}} \\nu(l) F(l)")#text(" (*)")

#text("where")

#mi("\\nu(l) := \\frac{1}{d} \\sum_{h: (h,d)=1} \\sum_{n_2: (n_2,d) = 1} 1_{\\frac{n_2}{h} = l\\ (d)} \\hat \\psi_1( \\frac{ h }{d} ) \\psi_2(n_2)")

#text("and")

#mi("F(l) := 1_{(l,d)=1} \\sum_{t: (t,d)=1} (\\alpha * \\psi_3)(t)e_d( \\frac{a}{l t} )")#text(".")

#text("The function ")#mi("\\nu")#text(" has a computable ")#mi("\\ell^2")#text(" norm, basically")

#tao-math("\\left\\| \\nu \\right\\|_{\\ell^2}^2 \\approx \\frac{N_1 N_2}{d}", block: false)

#text("and ")#mi("F")#text(" similarly has a computable ")#mi("\\ell^2")#text(" norm by Plancherel:")

#tao-math("\\left\\|F\\right\\|_{\\ell^2}^2 \\approx M N_3 d.", block: false)#text(" (**)")

#text("One could apply Cauchy-Schwarz directly to (*) to obtain an upper bound")

#tao-math("\\left\\|\\nu\\right\\|_{\\ell_2} \\left\\| F \\right\\|_{\\ell^2}", block: false)#text(" (***)")

#text("however this gives an unusable bound (unless we are in the Bombieri-Vinogradov range ")#mi("d < \\sqrt{x}")#text("). To do better, Zhang notes that ")#mi("\\nu(l)")#text(" has some smoothness, roughly speaking")

#mi("\\nu(l) \\approx \\nu(l+k)")

#text("whenever ")#mi("k")#text(" is an integer of size ")#mi("O( N_1 N_2 / d )")#text(". This reflects the fact that the Farey sequence ")#mi("\\{ n_2/h: n_2 = O(N_2), h = O(d/N_1) \\}")#text(" is more or less stable with respect to shifts by integers ")#mi("k")#text(" of size ")#mi("O(N_1 N_2/d)")#text(". This is basically all of the regularity that ")#mi("\\nu")#text(" enjoys; one can compute the Fourier transform of ")#mi("\\nu")#text(" in ")#mi("{\\bf Z}/d{\\bf Z}")#text(" to be spread out more or less evenly across frequencies of size ")#mi("O( d^2 / N_1 N_2 )")#text(", save for a big concentration at the zero frequency mode of course.")

#text("The smoothness of ")#mi("\\nu")#text(" allows one to approximately write (*) as")

#mi("\\sum_{l \\in ({\\bf Z}/d{\\bf Z})} \\nu(l) {\\bf E}_{k \\in S} F(l+k)")

#text("for any non-empty set ")#mi("S")#text(" of integers of size ")#mi("O( N_1 N_2/d)")#text(", so we may replace (***) by the improved bound")

#tao-math("\\left\\|\\nu\\right\\|_{\\ell_2} \\left\\|  {\\bf E}_{k \\in S} T_k F \\right\\|_{\\ell^2}", block: false)#text(". (****)")

#text("where ")#mi("T_k F(l) := F(l+k)")#text(" is the translate of ")#mi("F")#text(" by ")#mi("k")#text(". On the other hand, Bombieri-Birch/Ramanujan and completion of sums gives us a bound on the inner product")

#mi("\\sum_{l \\in {{\\bf Z}/d{\\bf Z}}} T_k F(l) T_{k^{\\prime}} F(l)")#text(",")

#text("which is basically of the form")

#mi("M N_3 d ( \\frac{(k-k^{\\prime},d)^{1/2}}{d^{1/2}} + \\frac{M}{N_3} \\frac{d^{1/2}}{(k-k^{\\prime},d)^{1/2}} )")#text(", (*****)")

#text("which is a bound which is strangely non-monotonic in ")#mi("(k-k^{\\prime},d)")#text(": when ")#mi("k-k^{\\prime}")#text(" is divisible by d (and in particular in the diagonal case ")#mi("k=k^{\\prime}")#text(") it matches what one gets from Cauchy-Schwarz and (**) (this is basically why I got essentially no improvement by trying to treat the ")#mi("k=k^{\\prime}")#text(" case directly), then decreases as ")#mi("k-k^{\\prime}")#text(" becomes increasingly coprime with ")#mi("d")#text(", until one reaches a transition and the bound worsens again as ")#mi("(k-k^{\\prime},d)")#text(" approaches 1. So to optimise in (****) one would like the differences ")#mi("k-k^{\\prime}")#text(" for ")#mi("k,k^{\\prime} \\in S")#text(" to have some common factor with ")#mi("d")#text(", but not too much of a factor, while also keeping ")#mi("S")#text(" reasonably large to avoid the diagonal terms from swamping everything; and so Zhang factors ")#mi("d = qr")#text(" for a controlled value of ")#mi("r")#text(" and sets ")#mi("S")#text(" to be the multiples of ")#mi("r")#text(" of size ")#mi("O( N_1 N_2/d)")#text(". I think I’ve convinced myself that this is more or less the optimal choice of ")#mi("S")#text(" given the bounds available.")

#text("So it's the non-monotonicity of the bound (*****) that makes the argument slightly strange, but it appears difficult to improve upon (*****) without somehow gaining the ability to get bounds on short averages of Bombieri-Birch sums that improve upon the triangle inequality, which one can conjecture to be true (in the spirit of Hooley's conjecture) but it looks very difficult (and for this one should start with the Type I/II sums where one \"only\" has to deal with short averages of Kloosterman rather than short averages of Bombieri-Birch. I poked for a while on the Fourier side (replacing ")#mi("l")#text(" by its Fourier dual variable) to see if there was anything better than Weyl differencing available, but the only thing that seemed to suggest itself was bounds on higher moments (e.g. ")#mi("\\ell^4")#text(" moment) of the Fourier transform of ")#mi("F")#text(" (or equivalently the ")#mi("U^2")#text(" Gowers norm of ")#mi("F")#text("), which didn't look very enticing. (In principle one gets more square root cancellation from increasingly higher-dimensional cases of the Weil conjectures, but this seems to be more than compensated for by the increased amount of completion of sums and Cauchy-Schwarz one has to perform.)")

#text("So, in summary, perhaps we've cleaned up all the low hanging fruit from Type III for now, and it's time to look again at Type I. I had a little look at the Ping Xi preprint giving some power savings on short Kloosterman sums, but have not yet worked out the numerology to see if the ranges in which Xi's bound are non-trivial are relevant here (and it's more \"short averages of Kloosterman sums\" that we need non-trivial bounds for rather than \"short Kloosterman sums\" per se).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A truncated elementary Selberg sieve of Pintz | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-235109")[#strong[#text("A truncated elementary Selberg sieve of Pintz | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("[…] that holds for as small as , but currently we are only able to establish this result for (see this comment). However, with the new truncated sieve of Pintz described in this post, we expect to be able to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c528a270ea586c8f8bfcf50e9069b5a42fc4ca1fff506c06c2a5ce75e259e2b3-d66dcf631d09ace94f5f260692d8db91d37f2a1c304fda5a02e5efd8d2f7fd54.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oktawian")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-235398")[#strong[#text("Oktawian")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("Theorem 1 (Bounded gaps between primes) There exists a natural number {H} such that there are infinitely many pairs of distinct primes {p,q} with {|p-q| \\leq H}.")#linebreak()#text(" I want to add some small observation about this theorem. If H is different than 3 that means there is not infinitly many pairs of even numbers like (n, n+2) and this unproven statement will be proven (or denied) if we will know the smallest H.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bounding short exponential sums on smooth moduli via Weyl differencing | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-235689")[#strong[#text("Bounding short exponential sums on smooth moduli via Weyl differencing | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("[…] in (using Lemma 5 from this previous post) we see that the total contribution to the off-diagonal case […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-235693")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("There is a new blog post of Emmanuel Kowalski at ")#link("http://blogs.ethz.ch/kowalski/2013/06/22/bounded-gaps-between-primes-the-dawn-of-some-enlightenment/")[#text("http://blogs.ethz.ch/kowalski/2013/06/22/bounded-gaps-between-primes-the-dawn-of-some-enlightenment/")]#text(" announcing an improvement in the d_3 bounds on smooth moduli (which should also lead to improvements in the Type III bounds). Interestingly, Emmanuel claims that Weyl differencing may be avoided. He also mentions an older paper of Heath-Brown ")#link("http://matwbn.icm.edu.pl/ksiazki/aa/aa47/aa4713.pdf")[#text("http://matwbn.icm.edu.pl/ksiazki/aa/aa47/aa4713.pdf")]#text(" that uses some similar ideas, I think I will try to look at that paper first.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The distribution of primes in densely divisible moduli | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-235918")[#strong[#text("The distribution of primes in densely divisible moduli | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("[…] improves upon previous constraints of (see this blog comment) and (see Theorem 13 of this previous post), albeit for instead of . Inserting Theorem 4 into the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-235936")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("This thread and the companion Type I/II thread are being rolled over to")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/")[#text("The distribution of primes in densely divisible moduli")]
]

#text("From past experience with polymath projects, now that our understanding of the project is more mature, the pace should settle down a bit from the crazily hectic pace of the last few weeks; I think we’re getting near the finish line and perhaps in a couple more weeks we will find a good place to “declare victory” and turn to the writing part of the project.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-236189")[#strong[#text("Zhang’s theorem on bounded prime gaps | random number theory generator")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")]

#text("[…] Crucially, if is composite then we can surpass square root cancellation just slightly. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The distribution of primes in doubly densely divisible moduli | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-237795")[#strong[#text("The distribution of primes in doubly densely divisible moduli | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2013")])]

#text("[…] by Lemma 5 of this previous post and the bound is bounded […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/#comment-238327")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2013")])]

#text("Minor correction: in the proof of Theorem 4, “")#mi("C_p(a)")#text(" equals […] ")#mi("0")#text(" when ")#mi("a = 0\\ (p)")#text("” should be “")#mi("C_p(a)")#text(" equals […] ")#mi("p-1")#text(" when ")#mi("a = 0\\ (p)")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]
