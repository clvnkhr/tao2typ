// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/
// Converted to Typst by tao2typ: "2026-10-14T16:34:58.449698+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Norm convergence of multiple ergodic averages for commuting transformations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Norm convergence of multiple ergodic averages for commuting transformations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 July 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/")[#text("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("I’ve just uploaded to the ")#link("http://www.arxiv.org/")[#text("ArXiV")]#text(" my paper “")#link("http://arxiv.org/abs/0707.1117")[#text("Norm convergence of multiple ergodic averages for commuting transformations")]#text("“, submitted to")#linebreak()#text(" ")#link("http://journals.cambridge.org/action/displayJournal?jid=ETS")[#text("Ergodic Theory and Dynamical Systems")]#text(". This paper settles in full generality the norm convergence problem for several commuting transformations. Specifically, if ")#mi("(X, {\\mathcal X},\\mu)")#text(" is a ")#link("http://en.wikipedia.org/wiki/Probability_space")[#text("probability space")]#text(" and ")#mi("T_1, \\ldots, T_l: X \\to X")#text(" are commuting ")#link("http://en.wikipedia.org/wiki/Measure-preserving_transformation")[#text("measure-preserving transformations")]#text(", then for any bounded measurable functions ")#mi("f_1, \\ldots, f_l: X \\to {\\Bbb R}")#text(", the multiple average")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{1}{N} \\sum_{n=0}^{N-1} \\int_X T_1^n f_1 \\ldots T_l^n f_l")]]

#text("is convergent in the ")#mi("L^2(X)")#text(" norm topology (and thus also ")#link("http://en.wikipedia.org/wiki/Convergence_of_random_variables#Convergence_in_probability")[#text("converges in probability")]#text("). The corresponding question of pointwise almost everywhere convergence remains open (and quite difficult, in my opinion). My argument also does not readily establish a formula as to what this limit actually ")#emph[#text("is")]#text(" (it really establishes that the sequence is ")#link("http://en.wikipedia.org/wiki/Cauchy_sequence")[#text("Cauchy")]#text(" in ")#mi("L^2")#text(" rather than convergent).")

#text("The l=1 case of this theorem is the classical ")#emph[#text("mean ergodic theorem")]#text(" (also known as the ")#emph[#text("von Neumann ergodic theorem")]#text("). The l=2 case was established ")#link("http://www.ams.org/mathscinet-getitem?mr=788966")[#text("by Conze and Lesigne")]#text(". The higher l case was partially resolved ")#link("http://www.ams.org/mathscinet-getitem?mr=2142946")[#text("by Frantzikinakis and Kra")]#text(", under the additional hypotheses that all of the transformations ")#mi("T_i")#text(", as well as the quotients ")#mi("T_i T_j^{-1}")#text(", are ergodic. The special case ")#mi("T_j=T^j")#text(" was established ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("by Host-Kra")]#text(" (with another proof given subsequently ")#link("http://www.ams.org/mathscinet-getitem?mr=2257397")[#text("by Ziegler")]#text("). Another relevant result is the ")#link("http://www.ams.org/mathscinet-getitem?mr=531279")[#text("Furstenberg-Katznelson theorem")]#text(", which asserts among other things when ")#mi("f_1=\\ldots=f_l")#text(" is non-negative and not identically zero, then the inner product of the expression (1) with f has a strictly positive limit inferior as ")#mi("N \\to \\infty")#text(". This latter result also implies ")#link("http://www.scholarpedia.org/article/Szemeredi%27s_Theorem")[#text("Szemerédi’s theorem")]#text(".")

#text("It is also known that the Furstenberg-Katznelson theorem can be proven by ")#link("http://en.wikipedia.org/wiki/Hypergraph")[#text("hypergraph")]#text(" methods, and in fact my paper also proceeds by a hypergraph-inspired approach, although the language of hypergraphs is not explicitly used in the body of the argument. (In contrast to the work of Host-Kra and Ziegler, no nilsystems appear in the proof.)")

#metadata(none) <tao-001999e2a83df7550f15>

#text("In fact, the first step in the argument is to replace the infinitary norm convergence result by an equivalent finitary norm convergence result, in exactly the same way that the ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("infinite convergence principle is equivalent to the finite convergence principle")]#text(". (This is in marked contrast with the usual ergodic-theory approach to these problems, in which one tries to prove the infinitary statement first, by purely infinitary means, and only deduces the finitary counterpart as a corollary at the very end of the argument.) In the finitary counterpart of this norm convergence result, the abstract dynamical system X is replaced by a very concrete one, namely the product ")#mi("({\\Bbb Z}/P{\\Bbb Z})^l")#text(" of l cyclic groups, with the standard set of l commuting shifts. The main advantage of this concrete setting is that it has an obvious Cartesian product structure, which lets one interpret the functions ")#mi("f_1,\\ldots,f_l")#text(" as weighted hypergraphs, and which allows the technology of the hypergraph ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("regularity lemma")]#text(" to be applied. (Actually we will only need a weak version of this lemma, similar to the “Koopman-von Neumann-type theorems” that appear for instance in ")#link("http://front.math.ucdavis.edu/math.NT/0404188")[#text("my work with Ben")]#text(" on arithmetic progressions of primes, or to the weak regularity lemma ")#link("http://www.ams.org/mathscinet-getitem?mr=1723039")[#text("of Frieze and Kannan")]#text(".)")

#text("Roughly speaking, the idea is now to induct on the “complexity” of the functions ")#mi("f_1,\\ldots,f_l")#text(". Informally, a function f on, say, ")#mi("({\\Bbb Z}/P{\\Bbb Z})^l")#text(" (actually for technical reasons we use ")#mi("({\\Bbb Z}/P{\\Bbb Z})^{l+1}")#text(") is of complexity d if it only depends of d of the coordinates, or if it is a polynomial combination of such functions (with quantitative bounds on the polynomial involved). The regularity lemma allows one to approximate a complexity d function by a complexity d-1 function, plus an error which is sufficiently “pseudorandom” or “uniform” to be negligible for the purposes of the norm convergence problem. We iterate this all the way down to d=1, at which point one is at the level of the mean ergodic theorem and one can proceed by a variety of methods.")

#text("One amusing side-effect of the finitary nature of the argument was that I needed a finitary version of the ")#link("http://en.wikipedia.org/wiki/Dominated_convergence_theorem")[#text("Lebesgue dominated convergence theorem")]#text(", which I include as an appendix. Actually, one does not strictly speaking need this theorem to run the argument, if one is willing to add a little bit more notation instead, but the finitary convergence theorem may be of some independent interest.")

#text("While the methods in the paper are finitary, it seems likely that a more traditional infinitary ergodic proof of this theorem should be possible (once one figures out how to obtain the counterpart of Cartesian product structure in the infinitary setting). It would thus be interesting to obtain a second proof of this result.")

#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-4101")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2007")]

#text("[…] Norm convergence of multiple ergodic averages for commuting transformations I’ve just uploaded to the ArXiV my paper “Norm convergence of multiple ergodic averages for commuting […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b969614ac837f7ac2e79c19069c6394596353daa034c32391d0f585eb6647ffb-03c1f9181bc7e7c77d77c765018c7b4a27079d9ef1d7dda6072497cc0c6d74c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter McNamara")]], [#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-4104")[#strong[#text("Peter McNamara")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2007")])]

#text("Terry,")

#text("I was wondering about the role of the assumption of commutativity that the transformations in this paper, and in the Furstenberg-Katznelson theorem are assumed to satisfy. Firstly, is there a simple example showing the necessity of this commutativity assumption? And secondly, can anything be salvaged if this assumption is dropped? I cannot hazard much of a guess having not looked in any detail at the arguments involved.")

#text("Peter")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-4141")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2007")])]

#text("Dear Peter,")

#text("The Furstenberg-Katznelson theorem holds if the shifts generate a nilpotent group, but not if they generate just a solvable group or worse. See")

#text("A. Leibman, Multiple recurrence theorem for nilpotent group actions, Geom. and Func. Anal. 4 (1994), 648-659.")

#text("and")

#text("V. Bergelson, A. Leibman, Failure of Roth theorem for solvable groups of exponential growth, Ergodic Theory and Dynam. Systems 24 (2004), 45–53.")

#text("In my own paper, the commutativity was used to move the problem to one in the lattice ")#mi("{\\Bbb Z}^l")#text(", at which point one can use a simple arithmetic substitution to convert the problem into a hypergraph one. I suspect that something similar can also be done in the nilpotent case. A good test problem would be to reprove the norm convergence for multiple polynomial powers of a single shift by these methods (this was shown recently by Frantzikinakis-Kra using nilsystems).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59c57b41bed6af30cc795fa69608f3e4c1b31b07b63386f857401605a1b9e6b4-2a3e527e061688ff79a4d2bbf36dfe20530f39117cdf85fddcdb6e8d9fcfdf23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zaiaku")]], [#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-4280")[#strong[#text("Zaiaku")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2007")])]

#text("[…] Norm convergence of multiple ergodic averages for commuting transformations I’ve just uploaded to the ArXiV my paper “Norm convergence of multiple ergodic averages for commuting […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aad50c847874f210ac7453a260224e4140fb275bf74f59284b6b94dba6103b52-39d7167c7831b6b50d05f6a98d03b1ef73dfff1c510e50f3e8a27e7d62082658.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry Towsner")]], [#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-6264")[#strong[#text("Henry Towsner")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2007")])]

#text("I’ve been thinking about what an infinitary version of the argment would look like, and put up a short outline of an infinitary analog of this proof:")

#link("http://www.math.cmu.edu/~hpt/pubs/NormConvergence.pdf")[#text("Click to access NormConvergence.pdf")]

#text("Some of the features–in particular, the passage from an average to an integral (which, in the infinitary version, seems to require a generalized form of the Furstenberg correspondence)–look like they might be independently interesting.")

#text("Henry")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-6322")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2007")])]

#text("Dear Henry,")

#text("Very nice (and quick)! I am happy to see the Furstenberg correspondence principle being developed in both directions; we usually use it as a narrow bridge between the finitary and infinitary worlds when it really should be a six-lane freeway :-). As usual, things get a lot cleaner in the infinitary world with most of the epsilons and other parameters being efficiently hidden from sight.")

#text("The main reason I couldn’t get anywhere in the infinitary world was the lack of a product structure, which is why I descended back to the finitary world. But it’s good to see that the same product structure can also be now recovered in the infinitary setting, even if it is a little odd to have to go back and forth across the Furstenberg correspondence to do so.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-6533")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2007")])]

#text("p.s. It occurs to me that the product Furstenberg correspondence principle you discovered may help elucidate an odd little phenomenon I observed in appendix B of one of my papers:")

#link("http://front.math.ucdavis.edu/math.CO/0602037")[#text("http://front.math.ucdavis.edu/math.CO/0602037")]

#text("It is known that the Furstenberg recurrence theorem in ergodic theory is equivalent (via the correspondence principle) to Szemeredi’s theorem, which is a consequence of a hypergraph removal lemma. In the above paper I deduce the latter lemma from an infinitary analogue, showing that certain systems of sigma algebras obey a “uniform intersection property”. I was always a bit dissatisfied by this passage back and forth between the finitary and infinitary worlds; in particular, there should be a direct way to establish the Furstenberg recurrence theorem (or the more general Furstenberg-Katznelson multidimensional recurrence theorem) from the uniform intersection property, but I was not able to do this in an elegant way in the appendix. Perhaps the new correspondence principle can sort this out a bit better…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aad50c847874f210ac7453a260224e4140fb275bf74f59284b6b94dba6103b52-39d7167c7831b6b50d05f6a98d03b1ef73dfff1c510e50f3e8a27e7d62082658.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry Towsner")]], [#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-6857")[#strong[#text("Henry Towsner")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2007")])]

#text("Where I used the product construction, the only issue was splitting up the commuting transformations to be independent from each other. The embedding into tripartite graphs uses sums, so it isn’t automatic that the same technique will work, although it’s certainly possible. I’m having a bit of trouble working through appendix B (in particular, I’m not following the definitions of E_23 and E_31; for instance, the definition of E_23 makes reference to the parameter k_1, and I’m not clear what k_1 refers to in this definition).")

#text("Which reminds me that there was one step in your norm convergence paper I didn’t follow: you say that ||Delta_N h||_1<=||h||_1, but it’s not obvious to me why this is the case, since ||h||_1 includes all the “off-diagonal” parts of h, which collectively have measure (approaching) 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-6858")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2007")])]

#text("Oops, that is a typo in Appendix B. in ")#mi("E_{23}")#text(", ")#mi("n_{1,k_1}")#text(" should be ")#mi("n_{2,k_2}")#text(", and in ")#mi("E_{31}")#text(", ")#mi("n_{2,k_2}")#text(" should be ")#mi("n_{1,k_1}")#text(". (Ugh.)")

#text("As for ")#tao-math("\\left\\| \\Delta_N h_e \\right\\|_1 \\leq \\left\\|h_e\\right\\|_1", block: false)#text(", one has to use the fact that ")#mi("h_e")#text(" is e-measurable for some e which is strictly smaller than {1,…,l+1} but contains l+1, so that the diagonal is nicely transverse to the sigma-algebra of ")#mi("h_e")#text(". Indeed, one can then check for any n that the function ")#mi("h_e( v, -\\Sigma(v)-n)")#text(" has exactly the same L^1 norm as ")#mi("h_e(v, v_{l+1})")#text(" (due to the ability to “move” arbitrarily in some index i in {1,…,l} \\ e, which renders the constraint ")#mi("\\Sigma(v)+v_{l+1}+n=0")#text(" ineffectual), and the contraction property then follows from Minkowski’s inequality.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aad50c847874f210ac7453a260224e4140fb275bf74f59284b6b94dba6103b52-39d7167c7831b6b50d05f6a98d03b1ef73dfff1c510e50f3e8a27e7d62082658.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry Towsner")]], [#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-8539")[#strong[#text("Henry Towsner")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2007")])]

#text("After looking for a while, I think some additional idea would be needed to handle the additive structure in the hypergraph setup. The construction I used in my notes doesn’t seem flexible enough to handle that directly.")

#text("Also, I have another question about your paper. For d>1, are there any uniform functions with large L^2 norm? In the infinitary case, it seems that there shouldn’t be (every function is in the L^2 limit of the complexity 1, and therefore complexity 2 anti-uniform, functions, since this is essentially the definition of the product structure). But if this is right, it seems to give a proof that avoids the inductive step: after proving the case for d=1, any g_e can be decomposed into the sum of a complexity 1 function and a function with small L^2 norm, using the general properties of the product, withou the need for a Koopman-von Neumann type decomposition. Then prod g_e can be decomposed into pieces in which either some element of the product has small norm (ensuring that the entire product does as well), or have complexity 1 (immediately, without needing to pass through the anti-uniform functions), and a product of complexity 1 functions is already known to converge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-8546")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2007")])]

#text("Dear Henry,")

#text("There are definitely uniform functions of any order with large L^2 norm, for instance consider a random function f on Z_P^l which equals +1 or -1 at each element of Z_P^l with equal and independent probability. Then this function f is large in L^2, but a simple computation using the Chernoff inequality and the union bound shows that with very high probability, f is going to have a very small inner product against all products of functions of l-1 of the l variables. (Basically, there are only about exp( O( P^{l-1} ) ) of these functions that one has to consider, but for each such function one is going to have a small inner product with f with a probability like exp( – c P^l ) for some c > 0, and so the union bound is going to be favourable.)")

#text("One has to be a little cautious here when extrapolating intuition about measurability from the infinite world to the finite world. It is true that every measurable function in a product space can be approximated by a linear combination of measurable functions in the factor spaces; however, there is no quantitative bound as to how complex a combination one needs in order to obtain a desired level of approximation; one needs quantitative bounds on the complexity in order to obtain a meaningful finitary world. In the finitary world, random functions such as the one I described above are, technically speaking, measurable, but they are very high complexity, and are indeed essentially orthogonal to all low-complexity (or anti-uniform) objects.")

#text("Incidentally, there was a slight error in Section 2 of my paper; I cannot require my generic point x_0 to witness the ergodic theorem (equation (3)) for ")#emph[#text("every")]#text(" f in ")#mi("L^\\infty")#text(" (and in fact the equation doesn’t make sense for such f, since they are only defined up to almost everywhere equivalence). But one only needs (3) to be true for functions which are polynomial combinations of the original functions ")#mi("f_1,\\ldots,f_l")#text(" with rational coefficients, so there is no difficulty. (Alternatively, one can place a topology on X and require f_1,…,f_l to be continuous.) But your own writeup may need some adjusting to fix the same problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Griesmer")]], [#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-8599")[#strong[#text("John Griesmer")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2007")])]

#text("Henry,")

#text("Indeed, your Lemma 2.1 gives the desired convergence as a consequence of convergence in the complexity one case. It also gives the multiple recurrence theorems of Szemerédi and Furstenberg-Katznelson as a consequence of the Poincaré")#linebreak()#text(" recurrence theorem. I can elaborate if you like.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aad50c847874f210ac7453a260224e4140fb275bf74f59284b6b94dba6103b52-39d7167c7831b6b50d05f6a98d03b1ef73dfff1c510e50f3e8a27e7d62082658.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry Towsner")]], [#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-8699")[#strong[#text("Henry Towsner")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2007")])]

#text("John,")

#text("I’m afraid it looks Lemma 2.1 has all these powerful consequences because it isn’t true. Tim Austin has pointed out that the argument I gave has a significant gap, and it looks like it can’t be patched without weakening the lemma. I’m looking into how to weaken it to something true, but anything true shouldn’t have consequences nearly so strong. (Indeed, it should be just enough to justify an infinitary version of Tao’s original argument.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aad50c847874f210ac7453a260224e4140fb275bf74f59284b6b94dba6103b52-39d7167c7831b6b50d05f6a98d03b1ef73dfff1c510e50f3e8a27e7d62082658.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry Towsner")]], [#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-12166")[#strong[#text("Henry Towsner")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2007")])]

#text("I believe I’ve repaired the infinitary version, and posted a new draft at")

#link("http://www.math.cmu.edu/~hpt/pubs/NormConvergence.pdf")[#text("Click to access NormConvergence.pdf")]

#text("It uses a weaker structure theorem, taking the original space and passing to an extension of a product space with an additional technical property. Unfortunately, I haven’t found any way to obtain this other than with a Loeb measure argument.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 8: The mean ergodic theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-25178")[#strong[#text("254A, Lecture 8: The mean ergodic theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2008")])]

#text("[…] for commuting shifts , which does not seem possible using the other arguments given here; see this paper of mine for details. Further quantitative analysis of the mean ergodic theorem can be found in this paper […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The correspondence principle and finitary ergodic theory « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-32327")[#strong[#text("The correspondence principle and finitary ergodic theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2008")])]

#text("[…] This is of course a well-known result with many short and elegant proofs; the proof method that we sketch here (essentially due to Avigad, Gerhardy, and Towsner) is lengthier and messier than the purely infinitary proofs, but can be extended to some situations in which it had been difficult to proceed in an infinitary manner (in particular on my result on convergence for multiple commuting transformations, as discussed in this post of mine). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 10: The Furstenberg correspondence principle « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-33717")[#strong[#text("254A, Lecture 10: The Furstenberg correspondence principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2008")])]

#text("[…] a (rather complicated looking) finitary analogue; see the papers of Avigad-Gerhardy-Towsner and of myself on this subject. Finally, we have implicitly been using a similar correspondence principle between […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-185891")[#strong[#text("Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2012")])]

#text("[…] strengthens and generalises a number of previous convergence results in ergodic theory (including one of my own), with a remarkably simple proof. Walsh’s argument is phrased in a finitary language […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3205d8eeb9c554b4dd0cc3d073ee0fccb7caa8f5245405e7db9ef43dfd7e2b5-a4d99c4307912feff11c653ffa27243560eff8a237c725adfd34835995912cc1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Convergence and Recurrence of Z actions | I Can't Believe It's Not Random!")]], [#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/#comment-256356")[#strong[#text("Convergence and Recurrence of Z actions | I Can't Believe It's Not Random!")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2013")])]

#text("[…] any such that . The convergence result associated with this result was establish by Tao in 2007, after some particular cases by Conze and Lesigne, and states that the […]")
]
