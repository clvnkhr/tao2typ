// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/05/08/new-bounds-for-szemeredis-theorem-ia-progressions-of-length-4-in-finite-field-geometries-revisited/
// Converted to Typst by tao2typ: "2026-10-14T16:36:50.748558+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "New bounds for Szemeredi’s theorem, Ia: Progressions of length 4 in finite field geometries revisited", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("New bounds for Szemeredi’s theorem, Ia: Progressions of length 4 in finite field geometries revisited")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 May 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/05/08/new-bounds-for-szemeredis-theorem-ia-progressions-of-length-4-in-finite-field-geometries-revisited/")[#text("https://terrytao.wordpress.com/2012/05/08/new-bounds-for-szemeredis-theorem-ia-progressions-of-length-4-in-finite-field-geometries-revisited/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Ben Green and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1205.1330")[#text("New bounds for Szemeredi’s theorem, Ia: Progressions of length 4 in finite field geometries revisited")]#text("“, ")#link("http://plms.oxfordjournals.org/")[#text("submitted to Proc. Lond. Math. Soc.")]#text(". This is both an erratum to, and a replacement for, our previous paper “")#link("http://www.ams.org/mathscinet-getitem?mr=2481952")[#text("New bounds for Szemeredi’s theorem. I. Progressions of length 4 in finite field geometries")]#text("“. The main objective in both papers is to bound the quantity ")#mi("{r_4(F^n)}")#text(" for a vector space ")#mi("{F^n}")#text(" over a finite field ")#mi("{F}")#text(" of characteristic greater than ")#mi("{4}")#text(", where ")#mi("{r_4(F^n)}")#text(" is defined as the cardinality of the largest subset of ")#mi("{F^n}")#text(" that does not contain an arithmetic progression of length ")#mi("{4}")#text(". In our earlier paper, we gave two arguments that bounded ")#mi("{r_4(F^n)}")#text(" in the regime when the field ")#mi("{F}")#text(" was fixed and ")#mi("{n}")#text(" was large. The first “cheap” argument gave the bound")

#align(center)[#tao-fit-display[#tao-math("r_4(F^n) \\ll \\left|F\\right|^n \\exp( - c \\sqrt{\\log n} )", block: true)]]

#text("and the more complicated “expensive” argument gave the improvement ")#metadata(none) <tao-bd9f736ab0c6e9edd7e4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("r_4(F^n) \\ll \\left|F\\right|^n n^{-c}", block: true)]]

#text("for some constant ")#mi("{c>0}")#text(" depending only on ")#mi("{F}")#text(".")

#text("Unfortunately, while the cheap argument is correct, we discovered a subtle but serious gap in our expensive argument in the original paper. Roughly speaking, the strategy in that argument is to employ the ")#emph[#text("density increment method")]#text(": one begins with a large subset ")#mi("{A}")#text(" of ")#mi("{F^n}")#text(" that has no arithmetic progressions of length ")#mi("{4}")#text(", and seeks to locate a subspace on which ")#mi("{A}")#text(" has a significantly increased density. Then, by using a “Koopman-von Neumann theorem”, ultimately based on an iteration of the inverse ")#mi("{U^3}")#text(" theorem of ")#link("http://www.ams.org/mathscinet-getitem?mr=2391635")[#text("Ben and myself")]#text(" (and also independently ")#link("http://www.ams.org/mathscinet-getitem?mr=2402476")[#text("by Samorodnitsky")]#text("), one approximates ")#mi("{A}")#text(" by a “quadratically structured” function ")#mi("{f}")#text(", which is (locally) a combination of a bounded number of quadratic phase functions, which one can prepare to be in a certain “locally equidistributed” or “locally high rank” form. (It is this reduction to the high rank case that distinguishes the “expensive” argument from the “cheap” one.) Because ")#mi("{A}")#text(" has no progressions of length ")#mi("{4}")#text(", the count of progressions of length ")#mi("{4}")#text(" weighted by ")#mi("{f}")#text(" will also be small; by combining this with the theory of equidistribution of quadratic phase functions, one can then conclude that there will be a subspace on which ")#mi("{f}")#text(" has increased density.")

#text("The error in the paper was to conclude from this that the original function ")#mi("{1_A}")#text(" also had increased density on the same subspace; it turns out that the manner in which ")#mi("{f}")#text(" approximates ")#mi("{1_A}")#text(" is not strong enough to deduce this latter conclusion from the former. (One can strengthen the nature of approximation until one restores such a conclusion, but only at the price of deteriorating the quantitative bounds on ")#mi("{r_4(F^n)}")#text(" one gets at the end of the day to be worse than the cheap argument.)")

#text("After trying unsuccessfully to repair this error, we eventually found an alternate argument, based on ")#link("http://www.ams.org/mathscinet-getitem?mr=2359469")[#text("earlier papers")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2815606")[#text("of ourselves")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2138068")[#text("of Bergelson-Host-Kra")]#text(", that avoided the density increment method entirely and ended up giving a simpler proof of a stronger result than ")#link(<tao-bd9f736ab0c6e9edd7e4>)[#text("(1)")]#text(", and also gives the explicit value of ")#mi("{c = 2^{-22}}")#text(" for the exponent ")#mi("{c}")#text(" in ")#link(<tao-bd9f736ab0c6e9edd7e4>)[#text("(1)")]#text(". In fact, it gives the following stronger result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Let ")#mi("{A}")#text(" be a subset of ")#mi("{F^n}")#text(" of density at least ")#mi("{\\alpha}")#text(", and let ")#mi("{\\epsilon>0}")#text(". Then there is a subspace ")#mi("{W}")#text(" of ")#mi("{F^n}")#text(" of codimension ")#mi("{O( \\epsilon^{-2^{20}})}")#text(" such that the number of (possibly degenerate) progressions ")#mi("{a, a+r, a+2r, a+3r}")#text(" in ")#mi("{A \\cap W}")#text(" is at least ")#tao-math("{(\\alpha^4-\\epsilon)\\left|W\\right|^2}", block: false)#text(".")
]

#text("The bound ")#link(<tao-bd9f736ab0c6e9edd7e4>)[#text("(1)")]#text(" is an easy consequence of this theorem after choosing ")#mi("{\\epsilon := \\alpha^4/2}")#text(" and removing the degenerate progressions from the conclusion of the theorem.")

#text("The main new idea is to work with a ")#emph[#text("local")]#text(" Koopman-von Neumann theorem rather than a global one, trading a relatively weak global approximation to ")#mi("{1_A}")#text(" with a significantly stronger local approximation to ")#mi("{1_A}")#text(" on a subspace ")#mi("{W}")#text(". This is somewhat analogous to how sometimes in graph theory it is more efficient (from the point of view of quantative estimates) to work with a local version of the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(" which gives just a single regular pair of cells, rather than attempting to regularise almost all of the cells. This local approach is well adapted to the inverse ")#mi("{U^3}")#text(" theorem we use (which also has this local aspect), and also makes the reduction to the high rank case much cleaner. At the end of the day, one ends up with a fairly large subspace ")#mi("{W}")#text(" on which ")#mi("{A}")#text(" is quite dense (of density ")#mi("{\\alpha-O(\\epsilon)}")#text(") and which can be well approximated by a “pure quadratic” object, namely a function of a small number of quadratic phases obeying a high rank condition. One can then exploit a special positivity property of the count of length four progressions weighted by pure quadratic objects, essentially due to ")#link("http://www.ams.org/mathscinet-getitem?mr=2138068")[#text("Bergelson-Host-Kra")]#text(", which then gives the required lower bound.")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of magnus carlsen")]], [#link("https://terrytao.wordpress.com/2012/05/08/new-bounds-for-szemeredis-theorem-ia-progressions-of-length-4-in-finite-field-geometries-revisited/#comment-142245")[#strong[#text("magnus carlsen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2012")])]

#text("Dear Terry,")

#text("you should add in your references that the paper “New bounds on cap sets” (reference number 1)")#linebreak()#text(" is published in the journal of the AMS")

#emph[#text("[Will do, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/05/08/new-bounds-for-szemeredis-theorem-ia-progressions-of-length-4-in-finite-field-geometries-revisited/#comment-142490")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2012")])]

#text("You could help young mathematicians by posting the referee report for the original paper along with the story behind the discovery of the gap in the proof of the main result.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc43da99bddf1772e2aad0a5e39d4ab5b94cebe25ebac976a36e6b99172f06cc-5d4726b87a45e50149eeab0837f7ef5e718ee455c882f1b0a907f1b5d0f9bdee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of reader")]], [#link("https://terrytao.wordpress.com/2012/05/08/new-bounds-for-szemeredis-theorem-ia-progressions-of-length-4-in-finite-field-geometries-revisited/#comment-144780")[#strong[#text("reader")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2012")])]

#text("Sanders’ paper [13] has been published: ")#link("http://ams.org/mathscinet-getitem?mr=2811612")[#text("MR 2012f:11019")]#text(". So has Tao & Ziegler [16]: ")#link("http://dx.doi.org/10.1007/s00026-011-0124-3")[#text("doi:10.1007/s00026-011-0124-3")]#text(".")

#emph[#text("[Thanks, this will be added to the next revision of the ms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/05/08/new-bounds-for-szemeredis-theorem-ia-progressions-of-length-4-in-finite-field-geometries-revisited/#comment-685002")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2024")])]

#text("Despite being almost trivial linear algebra, I’m struggling a bit to understand your proof of Lemma 4.7, and was hoping you could give a few words of clarification. In particular, should there be a hypothesis that of quadratic functions that define the quadratic factor in the hypothesis have sufficiently large rank? You run what you call the “rank reduction process” until the rank of various linear combinations of the quadratic factors exceed r + d. At each stage you reduce the number of quadratic functions. You conclude that this must stop before you run out of quadratic functions. But I don’t see why this ensures you find a subset with high rank. Couldn’t you just continue until you get down to one quadratic function which has rank less than r+d? More succinctly, I don’t see how the argument works if you start with a factor defined by a single quadratic function, and seek a local quadratic factor with a higher rank.")

#text("This isn’t particularly relevant to the question, but I’m also not sure why you call the process of locating a factor with higher rank the “rank reduction process”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/05/08/new-bounds-for-szemeredis-theorem-ia-progressions-of-length-4-in-finite-field-geometries-revisited/#comment-685018")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2024")])]

#text("It is quite permissible to end up with 0 quadratic polynomials at the final stage of the algorithm, in which case it will be of rank at least ")#mi("r")#text(" for any ")#mi("r")#text(".")

#text("I realize that when referring to this argument as a “rank reduction” argument we were using a different application of the concept of rank which in this context is quite confusing. In linear algebra, when one has a collection of vectors ")#mi("v_1,\\dots,v_n")#text(", the rank of the collection is sometimes defined to be the dimension of the linear space spanned by those vectors (or the rank of the matrix which contains the coordinates of these vectors as the rows). It is the span of the quadratic component of the factor that is being reduced by this algorithm; but of course we are using rank for another purpose in this argument. “quadratic complexity reduction process” may be a more appropriate term here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/05/08/new-bounds-for-szemeredis-theorem-ia-progressions-of-length-4-in-finite-field-geometries-revisited/#comment-685019")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2024")])]

#text("I’m surely missing something here. Say that phi is defined by a full rank 100 by 100 matrix. Now rank( lambda phi) = 100 for all lambda neq 0. If I understand the algorithm (which it seems I do not), then the next stage is to restrict to the kernel of phi, which is just the trivial zero dimensional space. In what sense is this, say, rank > 1000?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/05/08/new-bounds-for-szemeredis-theorem-ia-progressions-of-length-4-in-finite-field-geometries-revisited/#comment-685025")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2024")])]

#text("From Definition 4.4, A collection ")#mi("\\phi_1,\\dots,\\phi_d")#text(" of quadratic forms will automatically have rank at least ")#mi("r")#text(" for any ")#mi("r")#text(" if one has ")#mi("d=0")#text("; this is an example of a ")#link("https://en.wikipedia.org/wiki/Vacuous_truth")[#text("vacuously true")]#text(" statement, since in this case there are no non-trivial linear combinations of the ")#mi("\\phi_1,\\dots,\\phi_d")#text(" to be tested.")
]
]
]
]
