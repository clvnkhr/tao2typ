// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/
// Converted to Typst by tao2typ: "2026-10-14T15:17:00.950483+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245B, Notes 7: Well-ordered sets, ordinals, and Zorn’s lemma (optional)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245B, Notes 7: Well-ordered sets, ordinals, and Zorn’s lemma (optional)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 January 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/")[#text("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

#strong[#text("Notational convention:")]#text(" As in ")#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/")[#text("Notes 2")]#text(", I will colour a statement ")#text("red")#text(" in this post if it assumes the ")#link("http://en.wikipedia.org/wiki/Axiom_of_choice")[#text("axiom of choice")]#text(". We will, of course, rely on every other axiom of ")#link("http://en.wikipedia.org/wiki/Zermelo-Fraenkel_set_theory")[#text("Zermelo-Frankel set theory")]#text(" here (and in the rest of the course). ")#mi("\\diamond")

#text("In this course we will often need to iterate some sort of operation “infinitely many times” (e.g. to create a infinite basis by choosing one basis element at a time). In order to do this rigorously, we will rely on ")#link("http://en.wikipedia.org/wiki/Zorn%27s_lemma")[#emph[#text("Zorn’s lemma")]]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Zorn’s Lemma. ")]#text("Let ")#mi("(X, \\leq)")#text(" be a non-empty ")#link("http://en.wikipedia.org/wiki/Partially_ordered_set")[#text("partially ordered set")]#text(", with the property that every ")#link("http://en.wikipedia.org/wiki/Total_order")[#text("chain")]#text(" (i.e. a ")#link("http://en.wikipedia.org/wiki/Total_order")[#text("totally ordered")]#text(" set) in X has an ")#link("http://en.wikipedia.org/wiki/Upper_bound")[#text("upper bound")]#text(". Then X contains a ")#link("http://en.wikipedia.org/wiki/Maximal_element")[#text("maximal element")]#text(" (i.e. an element with no larger element).")
]

#text("Indeed, we have used this lemma several times already in previous notes. Given the other standard axioms of set theory, this lemma is logically equivalent to")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#link("http://en.wikipedia.org/wiki/Axiom_of_choice")[#text("Axiom of choice.")]]#text(" Let X be a set, and let ")#mi("{\\mathcal F}")#text(" be a collection of non-empty subsets of X. Then there exists a ")#link("http://en.wikipedia.org/wiki/Choice_function")[#text("choice function")]#text(" ")#mi("f: {\\mathcal F} \\to X")#text(", i.e. a function such that ")#mi("f(A) \\in A")#text(" for all ")#mi("A \\in {\\mathcal F}")#text(".")
]

#text("One implication is easy:")

#strong[#text("Proof of axiom of choice using Zorn’s lemma.")]#text(" Define a ")#emph[#text("partial choice function")]#text(" to be a pair ")#mi("({\\mathcal F}^{\\prime}, f^{\\prime})")#text(", where ")#mi("{\\mathcal F}^{\\prime}")#text(" is a subset of ")#mi("{\\mathcal F}")#text(" and ")#mi("f^{\\prime}: {\\mathcal F}^{\\prime} \\to X")#text(" is a choice function for ")#mi("{\\mathcal F^{\\prime}}")#text(". We can partially order the collection of partial choice functions by writing ")#mi("({\\mathcal F}^{\\prime}, f^{\\prime}) \\leq ({\\mathcal F}^{\\prime\\prime}, f^{\\prime\\prime})")#text(" if ")#mi("{\\mathcal F}^{\\prime} \\subset {\\mathcal F}^{\\prime\\prime}")#text(" and f” extends f’. The collection of partial choice functions is non-empty (since it contains the pair ")#mi("(\\emptyset, ())")#text(" consisting of the empty set and the ")#link("http://en.wikipedia.org/wiki/Empty_function")[#text("empty function")]#text("), and it is easy to see that any chain of partial choice functions has an upper bound (formed by gluing all the partial choices together). ")#text("Hence, by Zorn’s lemma, there is a maximal partial choice function ")#mi("({\\mathcal F}_*, f_*)")#text(". But the domain ")#mi("{\\mathcal F}_*")#text(" of this function must be all of ")#mi("{\\mathcal F}")#text(", since otherwise one could enlarge ")#mi("{\\mathcal F}_*")#text(" by a single set A and extend ")#mi("f_*")#text(" to A by choosing a single element of A. (One does not need the axiom of choice to make a single choice, or finitely many choices; it is only when making infinitely many choices that the axiom becomes necessary.) The claim follows.")#text(" ")#mi("\\Box")

#text("In the rest of these notes I would like to supply the reverse implication, using the machinery of ")#link("http://en.wikipedia.org/wiki/Well-ordered_set")[#text("well-ordered sets")]#text(". Instead of giving the shortest or slickest ")#text("proof of Zorn’s lemma")#text(" here, I would like to take the opportunity to place the lemma in the context of several related topics, such as ")#link("http://en.wikipedia.org/wiki/Ordinal_number")[#text("ordinals")]#text(" and ")#link("http://en.wikipedia.org/wiki/Transfinite_induction")[#text("transfinite induction")]#text(", noting that much of this material is in fact independent of the ")#text("axiom of choice")#text(". The material here is standard, but for the purposes of this course ")#text("one may simply take Zorn’s lemma as a “black box” and not worry about the proof")#text(", so this material is optional.")

#heading(level: 1)[#metadata(none) <tao-b59220ac1ceaf1b74251>#text("— Well-ordered sets —")]

#text("To prove Zorn’s lemma, we first need to strengthen the notion of a totally ordered set.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1. ")]#text(" A ")#emph[#text("well-ordered set")]#text(" is a totally ordered set ")#mi("X = (X,\\leq)")#text(" such that every non-empty subset A of X has a ")#link("http://en.wikipedia.org/wiki/Least_element")[#text("minimal element")]#text(" ")#mi("\\min(A) \\in A")#text(". Two well-ordered sets X, Y are ")#emph[#text("isomorphic")]#text(" if there is an order isomorphism ")#mi("\\phi: X \\to Y")#text(" between them, i.e. a bijection ")#mi("\\phi")#text(" which is monotone (")#mi("\\phi(x) < \\phi(x^{\\prime})")#text(" whenever ")#mi("x < x^{\\prime}")#text(").")
]

#strong[#text("Example 1.")]#text(" The natural numbers are well-ordered (this is the ")#link("http://en.wikipedia.org/wiki/Well-ordering_principle")[#text("well-ordering principle")]#text("), as is any finite totally ordered set (including the empty set), but the integers, rationals, or reals are not well-ordered. ")#mi("\\diamond")

#strong[#text("Example 2.")]#text(" Any subset of a well-ordered set is again well-ordered. In particular, if a, b are two elements of a well-ordered set, then intervals such as ")#mi("{}[a,b] := \\{ c \\in X: a \\leq c \\leq b \\}")#text(", ")#mi("{}[a,b) := \\{ c \\in X: a \\leq c < b \\}")#text(", etc. are also well-ordered. ")#mi("\\diamond")

#strong[#text("Example 3.")]#text(" If X is a well-ordered set, then the ordered set ")#mi("X \\oplus \\{+\\infty\\}")#text(", defined by adjoining a new element ")#mi("+\\infty")#text(" to ")#mi("X")#text(" and declaring it to be larger than all the elements of X, is also well-ordered. More generally, if X and Y are well-ordered sets, then the ordered set ")#mi("X \\oplus Y")#text(", defined as the ")#link("http://en.wikipedia.org/wiki/Disjoint_union")[#text("disjoint union ")]#text("of X and Y, with any element of Y declared to be larger than any element of X, is also well-ordered. Observe that the operation ")#mi("\\oplus")#text(" is associative (up to isomorphism), but not commutative in general: for instance, ")#mi("{\\Bbb N} \\oplus \\{\\infty\\}")#text(" is not isomorphic to ")#mi("\\{\\infty\\} \\oplus {\\Bbb N}")#text(". ")#mi("\\diamond")

#strong[#text("Example 4.")]#text(" If X, Y are well-ordered sets, then the ordered set ")#mi("X \\otimes Y")#text(", defined as the Cartesian product ")#mi("X \\times Y")#text(" with the ")#link("http://en.wikipedia.org/wiki/Lexicographical_order")[#text("lexicographical ordering")]#text(" (thus ")#mi("(x,y) \\leq (x^{\\prime},y^{\\prime})")#text(" if ")#mi("x < x^{\\prime}")#text(", or if ")#mi("x=x^{\\prime}")#text(" and ")#mi("y \\leq y^{\\prime}")#text("), is again a well-ordered set. Again, this operation is associative (up to isomorphism) but not commutative. Note that we have one-sided distributivity: ")#mi("(X \\oplus Y) \\otimes Z")#text(" is isomorphic to ")#mi("(X \\otimes Z) \\oplus (Y \\otimes Z)")#text(", but ")#mi("Z \\otimes (X \\oplus Y)")#text(" is not isomorphic to ")#mi("(Z \\otimes X) \\oplus (Z \\otimes Y)")#text(" in general. ")#mi("\\diamond")

#strong[#text("Remark 1.")]#text(" The ")#text("axiom of choice")#text(" is trivially true in the case when X is well-ordered, since one can take ")#mi("\\min")#text(" to be the choice function. Thus, the ")#text("axiom of choice")#text(" follows from the ")#link("http://en.wikipedia.org/wiki/Well-ordering_theorem")[#text("well-ordering theorem")]#text(" (every set has at least one well-ordering)")#text(". ")#text("Conversely, we will be able to deduce the well-ordering theorem from Zorn’s lemma (and hence from the axiom of choice): see Exercise 11 below.")#text(" ")#mi("\\diamond")

#text("One of the reasons that well-ordered sets are useful is that one can perform ")#link("http://en.wikipedia.org/wiki/Mathematical_induction")[#text("induction")]#text(" on them. This is easiest to describe for the principle of ")#link("http://en.wikipedia.org/wiki/Strong_induction#Complete_induction")[#text("strong induction")]#text(":")

#strong[#text("Exercise 1. ")]#text("(Strong induction on well-ordered sets) Let X be a well-ordered set, and let ")#mi("P: X \\to \\{ \\text{true}, \\text{false}\\}")#text(" be a property of elements of X. Suppose that whenever ")#mi("x \\in X")#text(" is such that ")#mi("P(y)")#text(" is true for all ")#mi("y<x")#text(", then ")#mi("P(x)")#text(" is true. Then ")#mi("P(x)")#text(" is true for every ")#mi("x \\in X")#text(". This is called the ")#emph[#text("principle of strong induction")]#text(". Conversely, show that a totally ordered set X enjoys the principle of strong induction if and only if it is well-ordered. (For partially ordered sets, the corresponding notion is that of being ")#link("http://en.wikipedia.org/wiki/Well-founded_relation")[#text("well-founded")]#text(".) ")#mi("\\diamond")

#text("To describe the analogue of the ")#link("http://en.wikipedia.org/wiki/Mathematical_induction")[#text("ordinary principle of induction")]#text(" for well-ordered sets, we need some more notation. Given a subset A of a non-empty well-ordered set X, we define the ")#emph[#link("http://en.wikipedia.org/wiki/Supremum")[#text("supremum")]]#text(" ")#mi("\\sup(A) \\in X \\oplus \\{+\\infty\\}")#text(" of A to be the least upper bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sup(A) := \\min( \\{ y \\in X \\oplus \\{+\\infty\\}: x \\leq y \\text{ for all } x \\in A \\}")]]

#text("of A (thus for instance the supremum of the empty set is ")#mi("\\min(X)")#text("). If ")#mi("x \\in X")#text(", we define the ")#emph[#link("http://en.wikipedia.org/wiki/Successor_ordinal")[#text("successor")]]#text(" ")#mi("\\text{succ}(x) \\in X \\oplus \\{+\\infty\\}")#text(" by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\text{succ}(x) := \\min( (x,+\\infty] ).")]]

#text("We have the following ")#link("http://en.wikipedia.org/wiki/Peano_axioms")[#text("Peano")]#text("-type axioms:")

#strong[#text("Exercise 2. ")]#text(" If x is an element of a non-empty well-ordered set X, show that exactly one of the following statements hold:")

#enum(start: 1, 
[#text("(Limit case) ")#mi("x = \\sup( [\\min(X),x) )")#text(".")],
[#text("(Successor case) ")#mi("x = \\text{succ}(y)")#text(" for some ")#mi("y")#text(".")]
)

#text("In particular, ")#mi("\\min(X)")#text(" is not the successor of any element in X. ")#mi("\\diamond")

#strong[#text("Exercise 3.")]#text(" Show that if x, y are elements of a well-ordered set such that ")#mi("\\text{succ}(x)=\\text{succ}(y)")#text(", then x=y. ")#mi("\\diamond")

#strong[#text("Exercise 4.")]#text(" (")#link("http://en.wikipedia.org/wiki/Transfinite_induction")[#text("Transfinite induction")]#text(" for well-ordered sets) Let X be a non-empty well-ordered set, and let ")#mi("P: X \\mapsto \\{ \\text{true}, \\text{false}\\}")#text(" be a property of elements of X. Suppose that")

#enum(start: 1, 
[#text("(Base case) ")#mi("P( \\min(X) )")#text(" is true.")],
[#text("(Successor case) If ")#mi("x \\in X")#text(" and ")#mi("P(x)")#text(" is true, then ")#mi("P(\\text{succ}(x))")#text(" is true.")],
[#text("(Limit case) If ")#mi("x = \\sup([\\min(X),x))")#text(" and ")#mi("P(y)")#text(" is true for all ")#mi("y<x")#text(", then ")#mi("P(x)")#text(" is true. [Note that this subsumes the base case.]")]
)

#text("Then ")#mi("P(x)")#text(" is true for all ")#mi("x \\in X")#text(". ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" The usual ")#link("http://en.wikipedia.org/wiki/Peano_axioms")[#text("Peano axioms")]#text(" for succession are the special case of Exercises 2-4 in which the limit case of Exercise 2 only occurs for ")#mi("\\min(X)")#text(" (which is denoted 0), and the successor function never attains ")#mi("+\\infty")#text(". With these additional axioms, X is necessarily isomorphic to ")#mi("{\\Bbb N}")#text(". ")#mi("\\diamond")

#text("Now we introduce two more key concepts.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2.")]#text(" An ")#link("http://en.wikipedia.org/wiki/Initial_segment")[#emph[#text("initial segment")]]#text(" of a well-ordered set X is a subset Y of X such that ")#mi("{}[\\min(X),y] \\subset Y")#text(" for all ")#mi("y \\in Y")#text(" (i.e. whenever y lies in Y, all elements of X that are less than y also lie in Y).")

#text("A ")#link("http://en.wikipedia.org/wiki/Morphism")[#emph[#text("morphism")]]#text(" from one well-ordered set X to another Y is a map ")#mi("\\phi: X \\to Y")#text(" which is strictly monotone (thus ")#mi("\\phi(x) < \\phi(x^{\\prime})")#text(" whenever ")#mi("x < x^{\\prime}")#text(") and such that ")#mi("\\phi(X)")#text(" is an initial segment of Y.")
]

#strong[#text("Example 5.")]#text(" The only morphism from ")#mi("\\{1,2,3\\}")#text(" to ")#mi("\\{1,2,3,4,5\\}")#text(" is the inclusion map. There is no morphism from ")#mi("\\{1,2,3,4,5\\}")#text(" to ")#mi("\\{1,2,3\\}")#text(". ")#mi("\\diamond")

#strong[#text("Remark 3.")]#text(" With this notion of a morphism, the ")#link("http://en.wikipedia.org/wiki/Class_(set_theory)")[#text("class")]#text(" of well-ordered sets becomes a ")#link("http://en.wikipedia.org/wiki/Category_(mathematics)")[#text("category")]#text(". ")#mi("\\diamond")

#text("We can identify the initial segments of X with elements of ")#mi("X \\cup \\{+\\infty\\}")#text(":")

#strong[#text("Exercise 5. ")]#text("Let X be a non-empty well-ordered set. Show that every initial segment I of X is of the form ")#mi("I = [\\min(X),a)")#text(" for exactly one ")#mi("a \\in X \\cup \\{+\\infty\\}")#text(". ")#mi("\\diamond")

#strong[#text("Exercise 6.")]#text(" Show that an arbitrary union or arbitrary intersection of initial segments is again an initial segment. ")#mi("\\diamond")

#strong[#text("Exercise 7. ")]#text(" Let ")#mi("\\phi: X \\to Y")#text(" be a morphism. Show that ")#mi("\\phi")#text(" maps initial segments of X to initial segments of Y. If ")#mi("x, x^{\\prime} \\in X")#text(" is such that x’ is the successor of x, show that ")#mi("\\phi(x^{\\prime})")#text(" is the successor of ")#mi("\\phi(x)")#text(". ")#mi("\\diamond")

#text("As Example 5 suggests, there are very few morphisms between well-ordered sets. Indeed, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" (Uniqueness of morphisms) Given two well-ordered sets X and Y, there is at most one morphism from X to Y.")
]

#strong[#text("Proof. ")]#text(" Suppose we have two morphisms ")#mi("\\phi: X \\to Y")#text(", ")#mi("\\psi: X \\to Y")#text(". By using transfinite induction (Exercise 4) and Exercise 7, one can show that ")#mi("\\phi, \\psi")#text(" agree on ")#mi("{}[\\min(X),a)")#text(" for every ")#mi("a \\in X \\oplus \\{+\\infty\\}")#text("; setting ")#mi("a=+\\infty")#text(" gives the claim. ")#mi("\\Box")

#strong[#text("Exercise 8.")]#text(" (")#link("http://en.wikipedia.org/wiki/Cantor%E2%80%93Bernstein%E2%80%93Schroeder_theorem")[#text("Schroder-Bernstein theorem")]#text(" for well-ordered sets) Show that two well-ordered sets X, Y are isomorphic if and only if there is a morphism from X to Y, and a morphism from Y to X. ")#mi("\\diamond")

#text("We can complement the uniqueness in Proposition 1 with existence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2. ")]#text(" (Existence of morphisms) Given two well-ordered sets X and Y, there is either a morphism from X to Y or a morphism from Y to X.")
]

#strong[#text("Proof. ")]#text(" Call an element ")#mi("a \\in X \\oplus \\{+\\infty\\}")#text(" ")#emph[#text("good")]#text(" if there is a morphism ")#mi("\\phi_a")#text(" from ")#mi("{}[\\min(X),a)")#text(" to Y, thus ")#mi("\\min(X)")#text(" is good. If ")#mi("+\\infty")#text(" is good, then we are done. From uniqueness we see that if every element in a set A is good, then the supremum ")#mi("\\sup(A)")#text(" is also good. Applying transfinite induction (Exercise 4), we thus see that we are done unless there exists a good ")#mi("a \\in X")#text(" such that ")#mi("\\text{succ}(a)")#text(" is not good. By Exercise 5, ")#mi("\\phi_a( [\\min(X),a) ) = [\\min(Y),b)")#text(" for some ")#mi("b \\in Y \\oplus \\{+\\infty\\}")#text(". If ")#mi("b \\in Y")#text(" then we could extend the morphism ")#mi("\\phi_a")#text(" to ")#mi("{}[\\min(X),a] = [\\min(X),\\text{succ}(a))")#text(" by mapping a to b, contradicting the fact that ")#mi("\\text{succ}(a)")#text(" is not good; thus ")#mi("b=+\\infty")#text(" and so ")#mi("\\phi_a")#text(" is surjective. It is then easy to check that ")#mi("\\phi_a^{-1}")#text(" exists and is a morphism from Y to X, and the claim follows. ")#mi("\\Box")

#strong[#text("Remark 4.")]#text(" Formally, Proposition 1, Exercise 8, and Proposition 2 tell us that the collection of all well-ordered sets, modulo isomorphism, is totally ordered by declaring one well-ordered set X to be at least as large as another Y when there is a morphism from Y to X. However, this is not quite the case, because the collection of well-ordered sets is only a ")#link("http://en.wikipedia.org/wiki/Class_(set_theory)")[#text("class")]#text(" rather than a set. Indeed, as we shall soon see, this is not a technicality, but is in fact a fundamental fact about well-ordered sets that lies at the heart of Zorn’s lemma. (From ")#link("http://en.wikipedia.org/wiki/Russell%27s_paradox")[#text("Russell’s paradox")]#text(" we know that the notions of class and set are necessarily distinct.) ")#mi("\\Box")

#heading(level: 1)[#text("— Ordinals —")]

#text("As we learn very early on in our mathematics education, a finite set of a certain cardinality (e.g. a set ")#mi("\\{a,b,c,d,e\\}")#text(") can be put in one-to-one correspondence with a “standard” set of the same cardinality (e.g. the set ")#mi("\\{1,2,3,4,5\\}")#text("); two finite sets have the same cardinality if and only if they correspond to the same “standard” set ")#mi("\\{1,\\ldots,N\\}")#text("). ")#text("(The same fact is true for infinite sets; see Exercise 12 below.)")#text(" Similarly, we would like to place every well-ordered set in a “standard” form. This motivates")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3.")]#text(" A ")#emph[#text("representation ")#mi("\\rho")#text(" of the well-ordered sets")]#text(" is an assignment of a well-ordered set ")#mi("\\rho(X)")#text(" to every well-ordered set X such that")

#enum(start: 1, 
[#mi("\\rho(X)")#text(" is isomorphic to X for every well-ordered set X. (In particular, if ")#mi("\\rho(X)")#text(" and ")#mi("\\rho(Y)")#text(" are equal, then X and Y are isomorphic.)")],
[#text("If there exists a morphism from X to Y, then ")#mi("\\rho(X)")#text(" is a subset of ")#mi("\\rho(Y)")#text(" (and the order structure on ")#mi("\\rho(X)")#text(" is induced from that on ")#mi("\\rho(Y)")#text(". (In particular, if X and Y are isomorphic, then ")#mi("\\rho(X)")#text(" and ")#mi("\\rho(Y)")#text(" are equal.)")]
)
]

#strong[#text("Remark 5.")]#text(" In the language of category theory, a representation is a ")#link("http://en.wikipedia.org/wiki/Functor")[#text("covariant functor")]#text(" from the category of well-ordered sets to itself which turns all morphisms into inclusions, and which is ")#link("http://en.wikipedia.org/wiki/Natural_transformation")[#text("naturally isomorphic")]#text(" to the identity functor. ")#mi("\\diamond")

#strong[#text("Remark 6.")]#text(" Because the collection of all well-ordered sets is a ")#link("http://en.wikipedia.org/wiki/Class_(set_theory)")[#text("class")]#text(" rather than a set, ")#mi("\\rho")#text(" is not actually a function (it is sometimes referred to as a ")#emph[#text("class function")]#text("). ")#mi("\\diamond")

#text("It turns out that several representations of the well-ordered sets exist. The most commonly used one is that of the ordinals, defined by von Neumann as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4.")]#text(" An ordinal is a well-ordered set ")#mi("\\alpha")#text(" with the property that ")#mi("x = \\{ y \\in \\alpha: y < x \\}")#text(" for all ")#mi("x \\in \\alpha")#text(". (In particular, each element of ")#mi("\\alpha")#text(" is also a subset of ")#mi("\\alpha")#text(", and the strict order relation ")#mi("<")#text(" on ")#mi("\\alpha")#text(" is identical to the set membership relation ")#mi("\\in")#text(".)")
]

#strong[#text("Example 6.")]#text(" For each natural number ")#mi("n = 0,1,2,\\ldots")#text(", define the ordinal number ")#mi("n^{th}")#text(" recursively by setting ")#mi("0^{th} := \\emptyset")#text(" and ")#mi("n^{th} := \\{0^{th}, 1^{th},\\ldots, (n-1)^{th} \\}")#text(" for all ")#mi("n \\geq 1")#text(", thus for instance")

#tao-aligned(keep: true)[


#tao-math("0^{th}  & := \\emptyset", block: true)



#tao-math("1^{th}  & := \\{0^{th}\\} = \\{ \\emptyset \\}", block: true)



#tao-math("2^{th}  & := \\{0^{th}, 1^{th} \\} = \\{ \\emptyset, \\{ \\emptyset \\} \\}", block: true, numbering: n => [#text("(3)")])



#tao-math("3^{th}  & := \\{ 0^{th}, 1^{th}, 2^{th} \\} = \\{ \\emptyset, \\{ \\emptyset \\}, \\{ \\emptyset, \\{\\emptyset\\}\\} \\},", block: true)
]

#text("and so forth. (Of course, to be compatible with the ")#link("http://en.wikipedia.org/wiki/Ordinal_number_(linguistics)")[#text("English language conventions")]#text(" for ordinals, we should write ")#mi("1^{st}")#text(" instead of ")#mi("1^{th}")#text(", etc., but let us ignore this discrepancy.) One can easily check by induction that ")#mi("n^{th}")#text(" is an ordinal for every n. Furthermore, if we define ")#mi("\\omega := \\{ n^{th}: n \\in {\\Bbb N} \\}")#text(", then ")#mi("\\omega")#text(" is also an ordinal. (In the foundations of set theory, this construction, together with the axiom of infinity, is sometimes used to ")#emph[#text("define")]#text(" the natural numbers (so that ")#mi("n = n^{th}")#text(" for all natural numbers n), although this construction can lead to some conceptually strange-looking consequences that blur the distinction between numbers and sets, such as ")#mi("3 \\in 5")#text(" and ")#mi("4 = \\{0,1,2,3\\}")#text(".) ")#mi("\\diamond")

#text("The fundamental theorem about ordinals is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]

#enum(start: 1, 
[#text("Given any two ordinals ")#mi("\\alpha, \\beta")#text(", one is a subset of the other (and the order structure on ")#mi("\\alpha")#text(" is induced from that on ")#mi("\\beta")#text(").")],
[#text("Every well-ordered set X is isomorphic to exactly one ordinal ")#mi("\\text{ord}(X)")#text(".")]
)

#text("In particular, ")#mi("\\text{ord}")#text(" is a representation of the well-ordered sets.")
]

#strong[#text("Proof. ")]#text(" We first prove 1. From Proposition 2 and symmetry, we may assume that there is a morphism ")#mi("\\phi")#text(" from ")#mi("\\alpha")#text(" to ")#mi("\\beta")#text(". By strong induction (Exercise 1) and Definition 4, we see that ")#mi("\\phi(x)=x")#text(" for all ")#mi("x \\in \\alpha")#text(", and so ")#mi("\\phi")#text(" is the inclusion map from ")#mi("\\alpha")#text(" into ")#mi("\\beta")#text(". The claim follows.")

#text("Now we prove 2. If uniqueness failed, then we would have two distinct ordinals that are isomorphic to each other, but as one ordinal is a subset of the other, this would contradict Proposition 1 (the inclusion morphism is not an isomorphism); so it suffices to prove existence.")

#text("We use transfinite induction. It suffices to show that for every ")#mi("a \\in X \\oplus \\{+\\infty\\}")#text(", that ")#mi("{}[\\min(X),a)")#text(" is isomorphic to an ordinal ")#mi("\\alpha(a)")#text(" (which we know to be unique). This is of course true in the base case ")#mi("a = \\min(X)")#text(". To handle the successor case ")#mi("a = \\text{succ}(b)")#text(", we set ")#mi("\\alpha(a) := \\alpha(b) \\cup \\{ \\alpha(b)\\}")#text(", which is easily verified to be an ordinal isomorphic to ")#mi("{}[\\min(X).a)")#text(". To handle the limit case ")#mi("a = \\sup( [\\min(X), a) )")#text(", we take all the ordinals associated to elements in ")#mi("{}{[}\\min(X), a{)}")#text(" and take their union (here we rely crucially on the ")#link("http://en.wikipedia.org/wiki/Axiom_schema_of_replacement")[#text("axiom schema of replacement")]#text(" and ")#link("http://en.wikipedia.org/wiki/Axiom_of_union")[#text("the axiom of union")]#text("); by use of part 1 one can show that this union is an ordinal isomorphic to a as required. ")#mi("\\Box")

#strong[#text("Remark 7. ")]#text(" Operations on well-ordered sets, such as the sum ")#mi("\\oplus")#text(" and product ")#mi("\\otimes")#text(" defined in Examples 3, 4, induce corresponding operations on ordinals, leading to ordinal arithmetic, which we will not discuss here. (Note that the convention for which order multiplication proceeds in is swapped in some of the literature, thus ")#mi("\\alpha \\beta")#text(" would be the ordinal of ")#mi("\\beta \\otimes \\alpha")#text(" rather than ")#mi("\\alpha \\otimes \\beta")#text(".) ")#mi("\\diamond")

#strong[#text("Exercise 9. ")]#text("(Ordinals are themselves well-ordered) Let ")#mi("{\\mathcal F}")#text(" be a non-empty ")#link("http://en.wikipedia.org/wiki/Class_%28set_theory%29")[#text("class")]#text(" of ordinals. Show that there is a least ordinal ")#mi("\\min({\\mathcal F})")#text(" in this class, which is a subset of all the other ordinals in this class. In particular, this shows that any set of ordinals is well-ordered by set inclusion. ")#mi("\\diamond")

#strong[#text("Remark 8.")]#text(" Because of Exercise 9, we can meaningfully talk about “the least ordinal obeying property P”, as soon as we can exhibit at least one ordinal with that property P. For instance, once one can demonstrate the existence of an uncountable ordinal ")#text("(which follows from Exercise 11 below)")#text(", one can talk about the least uncountable ordinal. ")#mi("\\diamond")

#strong[#text("Exercise 10.")]#text(" (")#link("http://en.wikipedia.org/wiki/Transfinite_induction")[#text("Transfinite induction")]#text(" for ordinals) Let ")#mi("P(\\alpha)")#text(" be a property pertaining to ordinals ")#mi("\\alpha")#text(". Suppose that")

#enum(start: 1, 
[#text("(Base case) ")#mi("P(\\emptyset)")#text(" is true.")],
[#text("(")#link("http://en.wikipedia.org/wiki/Successor_ordinal")[#text("Successor")]#text(" case) If ")#mi("\\alpha = \\beta \\cup \\{\\beta\\}")#text(" for some ordinal ")#mi("\\beta")#text(", and ")#mi("P(\\beta)")#text(" is true, then ")#mi("P(\\alpha)")#text(" is true.")],
[#text("(")#link("http://en.wikipedia.org/wiki/Limit_ordinal")[#text("Limit")]#text(" case) If ")#mi("\\alpha = \\bigcup_{\\beta \\in \\alpha} \\beta")#text(", and ")#mi("P(\\beta)")#text(" is true for all ")#mi("\\beta \\in \\alpha")#text(", then ")#mi("P(\\alpha)")#text(" is true.")]
)

#text("Show that ")#mi("P(\\alpha)")#text(" is true for every ordinal ")#mi("\\alpha")#text(". ")#mi("\\diamond")

#text("Now we show a fundamental fact, that the well-ordered sets are just too “numerous” to all fit inside a single set, even modulo isomorphism.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2.")]#text(" There does not exist a set A and a representation ")#mi("\\rho")#text(" of the well-ordered sets such that ")#mi("\\rho(X) \\in A")#text(" for all well-ordered sets X.")
]

#strong[#text("Proof.")]#text(" By Theorem 1, any two distinct ordinals are non-isomorphic, and so get mapped under ")#mi("\\rho")#text(" to a different element of A. Thus we can identify the class of ordinals with a subset of A, and so the class of ordinals is in fact a set. In particular, by the ")#link("http://en.wikipedia.org/wiki/Axiom_of_union")[#text("axiom of union")]#text(", we may take the union of all the ordinals, which one can verify to be another ordinal ")#mi("\\varepsilon_0")#text(". But then ")#mi("\\varepsilon_0 \\cup \\{ \\varepsilon_0\\}")#text(" is another ordinal, which implies that ")#mi("\\varepsilon_0 \\in \\varepsilon_0")#text(", which contradicts the ")#link("http://en.wikipedia.org/wiki/Axiom_of_regularity")[#text("axiom of foundation")]#text(". ")#mi("\\Box")

#strong[#text("Remark 9.")]#text(" It is also possible to prove Theorem 2 without the theory of ordinals, or the axiom of foundation. One first observes (by transfinite induction) that given two well-ordered sets X, X’, one of the sets ")#mi("\\rho(X), \\rho(X^{\\prime})")#text(" is a subset of the other. Because of this, one can show that the union S of all the ")#mi("\\rho(X)")#text(" (where X ranges over all well-ordered sets) is well-defined (because the ")#mi("\\rho(X)")#text(" form a subset of A) and well-ordered. Now we look at the well-ordered set ")#mi("S \\cup \\{+\\infty\\}")#text("; by Proposition 1, it is not isomorphic to any subset of S, but ")#mi("\\rho(S \\cup \\{+\\infty\\})")#text(" is necessarily contained in S, a contradiction. ")#mi("\\diamond")

#strong[#text("Remark 10.")]#text(" The same argument also shows that there is no representation of the ordinals inside a given set; the ordinals are “too big” to be placed in anything other than a class. ")#mi("\\diamond")

#heading(level: 1)[#text("— Zorn’s lemma —")]

#text("Now we can prove Zorn’s lemma. ")#text("The key proposition is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2. ")]#text("Let X be a partially ordered set, and let ")#mi("{\\mathcal C}")#text(" be the set of all well-ordered sets in X. Then there does not exist a function ")#mi("g: {\\mathcal C} \\to X")#text(" such that ")#mi("g(C)")#text(" is a strict upper bound for C (i.e. ")#mi("g(C) > x")#text(" for all ")#mi("x \\in C")#text(") for all well-ordered ")#mi("C \\in {\\mathcal C}")#text(".")
]

#strong[#text("Proof. ")]#text("Suppose for contradiction that there existed X and g with the above properties. Then, given any well-ordered set Y, we claim that there exists exactly one isomorphism ")#mi("\\phi_Y: Y \\to \\rho(Y)")#text(" from Y to a well-ordered set ")#mi("\\rho(Y)")#text(" in X such that ")#mi("\\phi_Y(y) = g( \\phi_Y([\\min(Y),y) ) )")#text(" for all ")#mi("y \\in Y")#text(". Indeed, the uniqueness and existence can both be established by a transfinite induction that we leave as an exercise. (Informally, ")#mi("\\phi_Y")#text(" is what one gets by “applying g Y times, starting with the empty set”.) From uniqueness we see that ")#mi("\\rho(Y)=\\rho(Y^{\\prime})")#text(" whenever Y and Y’ are isomorphic, and another transfinite induction shows that ")#mi("\\rho(Y) \\subset \\rho(Y^{\\prime})")#text(" whenever Y is a subset of Y’. Thus ")#mi("\\rho")#text(" is a representation of the ordinals. But this contradicts Theorem 2. ")#mi("\\Box")

#strong[#text("Remark 11.")]#text(" One can use transfinite induction on ordinals rather than well-ordered sets if one wishes here, using Remark 10 in place of Theorem 2. ")#mi("\\diamond")

#strong[#text("Proof of Zorn’s lemma.")]#text(" ")#text("Suppose for contradiction that one had a non-empty partially ordered set X without maximal elements, such that every chain had an upper bound. As there are no maximal elements, every element in X must be bounded by a strictly larger element in X, and so every chain in fact has a strict upper bound; in particular every well-ordered set has a strict upper bound. ")#text("Applying the axiom of choice, we may thus find a choice function ")#mi("g: {\\mathcal C} \\to X")#text(" from the space of well-ordered sets in X to X, that maps every such set to a strict upper bound. But this contradicts Proposition 2")#text(".")#text(" ")#mi("\\Box")

#strong[#text("Remark 12.")]#text(" It is important for Zorn’s lemma that X is a set, rather than a class. Consider for instance the class of all ordinals. Every chain of ordinals has an upper bound (namely, the union of the ordinals in that chain), and the class is certainly non-empty, but there is no maximal ordinal. (Compare also Theorem 1 and Theorem 2.) ")#mi("\\diamond")

#strong[#text("Remark 13.")]#text(" It is also important that every chain have an upper bound, and not just countable chains. Indeed, the collection of countable subsets of an uncountable set (such as ")#mi("{\\Bbb R}")#text(") is non-empty, and every countable chain has an upper bound, but there is no maximal element. ")#mi("\\diamond")

#strong[#text("Remark 14. ")]#text(" The above argument shows that the hypothesis of Zorn’s lemma can be relaxed slightly; one does not need every chain to have an upper bound, merely every well-ordered set needs to have one. But I do not know of any application in which this apparently stronger version of Zorn’s lemma dramatically simplifies an argument. (In practice, either Zorn’s lemma can be applied routinely, or it fails utterly to be applicable at all.) ")#mi("\\diamond")

#strong[#text("Exercise 11.")]#text(" Use Zorn’s lemma to establish the ")#link("http://en.wikipedia.org/wiki/Well-ordering_theorem")[#text("well-ordering theorem")]#text(" (every set has at least one well-ordering). ")#mi("\\diamond")

#strong[#text("Remark 15.")]#text(" ")#text("By the above exercise, ")#mi("{\\Bbb R}")#text(" can be well-ordered.")#text(" However, if one drops the axiom of choice from the axioms of set theory, one can no longer prove that ")#mi("{\\Bbb R}")#text(" is well-ordered. Indeed, given a well-ordering of ")#mi("{\\Bbb R}")#text(", it is not difficult (using Remark 1) to remove the axiom of choice from the Banach-Tarski constructions in ")#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/")[#text("Notes 2")]#text(", and thus obtain constructions of non-measurable subsets of ")#mi("{\\Bbb R}")#text(". But a deep theorem of Solovay gives a model of set theory (without the axiom of choice) in which every set of reals is measurable. ")#mi("\\diamond")

#strong[#text("Exercise 12.")]#text(" Define a (")#link("http://en.wikipedia.org/wiki/Von_Neumann_cardinal_assignment")[#text("von Neumann")]#text(") ")#link("http://en.wikipedia.org/wiki/Cardinal_number")[#text("cardinal")]#text(" to be an ordinal ")#mi("\\alpha")#text(" with the property that all smaller ordinals have strictly lesser cardinality (i.e. cannot be placed in one-to-one correspondence with ")#mi("\\alpha")#text("). ")#text("Show that every set can be placed in one-to-one correspondence with exactly one cardinal.")#text(" (This gives a representation of the category of sets, similar to how ")#mi("\\text{ord}")#text(" gives a representation of well-ordered sets.)")#text(" ")#mi("\\diamond")

#text("It seems appropriate to close these notes with a quote from ")#link("http://www.math.uic.edu/~bona/")[#text("Jerry Bona")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#emph[#text("“The Axiom of Choice is ")]#emph[#text("obviously")]#text(" true, the well-ordering principle ")#emph[#text("obviously false")]#text(", and who can tell about ")#emph[#text("Zorn’s Lemma")]#text("?”")
]

#text("[")#emph[#text("Update")]#text(", Jan 29: some more remarks added.]")

#text("[")#emph[#text("Update")]#text(", Jan 30: more remarks added.]")

#text("[")#emph[#text("Update")]#text(", Jan 31: See also “")#link("http://gowers.wordpress.com/2008/08/12/how-to-use-zorns-lemma/")[#text("How to use Zorn’s lemma")]#text("“, by ")#link("http://en.wikipedia.org/wiki/Timothy_Gowers")[#text("Tim Gowers")]#text(".]")

#heading(level: 1)[#text("Comments (66)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-35313")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2009")])]

#text("In example 4, when describing the well-ordering on the lexicographic ordering, I think you meant y <= y’. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/626e53d46c710500df401cd08527c0d77bc41c025132055eb6b1eff8f8e41115-d87af44ed68cc76739d63ca4c13478d58612e8f3dab93013de42dffa7899abb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-35318")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2009")])]

#text("I think it’s worth remarking on how a Zorn’s Lemma proof can be turned into a transfinite induction proof, as there’s a very simple algorithm. When using Zorn’s Lemma, there are two steps. First, you must prove that chains are bounded in your poset, and second you must show that a maximal element has the properties you desire. These correspond exactly to the limit and successor steps of constructing your object by transfinite induction, respectively. For example, to construct a basis for a vector space, you need that a union of a chain of linearly independent sets is linearly independent and that a maximal linearly independent set spans and is hence a basis. By transfinite induction you can construct a basis by taking unions at limit steps and adding new elements at successor steps if you don’t yet have a basis, which is always possible since not being a basis implies that what you have is non-maximal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ffa174a479a5934ffc8d85ac51954b684c7282154b5e145b5b220c7e95723971-f46e92455ff52a75c934a5d34a3eae4d3c278d3b141035808dba5019c873d2bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kung fu panda")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-35364")[#strong[#text("kung fu panda")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2009")])]

#text("Dear Mr Tao, Dear People,")

#text("First of all, thank you so much for all the articles on your blog and especially for this one.")

#text("I am trying to prove countable choice using dependent choice. Could someone correct me please? Thank you.")

#text("I restate dependent choice (D.C): If ")#mi("E")#text(" is a binary relation on a nonempty set ")#mi("A")#text(" and if for every a belonging to ")#mi("A")#text(" there exists a ")#mi("b")#text(" belonging to ")#mi("A")#text(" such that ")#mi("bEa")#text(" then there is a sequence ")#mi("a_0, a_1, a_2,...,a_n")#text(" in ")#mi("A")#text(" such that ")#mi("a_{n+1} E a_n")#text(" for all ")#mi("n")#text(" belonging to ")#mi("N")#text(".")

#text("Countable choice (C.C): Every countable family of nonempty sets has a choice function.")

#text("D.C implies C.C.")#linebreak()#text(" proof:")#linebreak()#text(" Let ")#mi("S:=\\{A_n : \\text{for all } n\\}")#text(" be a family of nonempty sets and let ")#mi("A")#text(" be the set of all choice functions on some ")#mi("S_n=\\{A_i : i<n\\}")#text(". We use the inclusion for the binary relation.")

#text("The set ")#mi("A")#text(" is nonempty because for each ")#mi("S_i")#text(" , ")#mi("i")#text(" smaller than ")#mi("n")#text(", we can find a choice function on the elements of ")#mi("S_i")#text(". the elements of ")#mi("S_i")#text(" are countable subsets so we can \"choose\" the least elements of the elements of the ")#mi("S_i")#text("‘s.")

#text("Secondly, for every choice function ")#mi("f")#text(" of ")#mi("A")#text(", does there exist a choice function ")#mi("f^{\\prime}")#text(" of ")#mi("A")#text(" such that ")#mi("f^{\\prime}")#text(" is included in ")#mi("f")#text(". ")#mi("f")#text(" is a subset of the product of the ")#mi("A_i")#text(", elements of the ")#mi("S_i")#text("‘s and so one can find a subset of this product. Using D.C, there is a sequence ")#mi("f_0, f_1, f_2,...,f_n,...")#text(" in ")#mi("A")#text(" such that each ")#mi("f_n+1")#text(" is included in ")#mi("f_n")#text(" for all ")#mi("n")#text(". This means that one can find a choice function on ")#mi("S:=\\{A_n: \\text{for all } n\\}")

#text("Thank you in advance for you suggestions and corrections.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 10: Compactness in topological spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-35693")[#strong[#text("245B, Notes 10: Compactness in topological spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("[…] Show that every filter is contained in at least one ultrafilter. (Hint: use Zorn’s lemma, see Notes 7.) Exercise 5 A collection of subsets of has the finite intersection property if every finite […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 实分析0-10 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-35900")[#strong[#text("实分析0-10 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("[…] 第七节整节讲选择公理，我看得真是爽死了。要知道，我在很长时间里都希望找一个这方面的材料好好的学一下。本节中包括的内容有：良序集，序数，Zorn引理，超限归纳以及他们和选择公理之间一些互推关系。众所周知，上面这些多半等价，本节短短几页把其中关系写的清清楚楚。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The “no self-defeating object” argument « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-42228")[#strong[#text("The “no self-defeating object” argument « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2009")])]

#text("[…] with the theory of ordinals) can be used to give a quick proof of Zorn’s lemma: see these lecture notes of mine for further discussion. Notice the similarity between this argument and the proof of Proposition 1. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-47250")[#strong[#text("245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2010")])]

#text("[…] algebra) (This exercise requires familiarity with the theory of ordinals, which is reviewed here. Recall that we are assuming the axiom of choice throughout this course.) Let be a collection of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-50417")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2011")])]

#text("In exercise 10, I think the succesor case should say: if $\\alpha=\\beta\\cup\\{\\beta\\}$ or something similar instead of $\\alpha={\\beta,\\{\\beta\\}\\}$ (the latter is, in most cases, not even a transitive set).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-132619")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2012")])]

#text("In example3,the link of “disjoint union” directs me to 【well ordering principle】in wikipedia.The correct link: ")#link("http://en.wikipedia.org/wiki/Disjoint_union")[#text("http://en.wikipedia.org/wiki/Disjoint_union")]

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-133780")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2012")])]

#text("Dear professor Tao ,")#linebreak()#text(" In definition 4,I think you should check whether ")#mi("\\alpha")#text(" is well defined,i.e,if ")#mi("\\alpha")#text(" is a set such that ")#mi("\\forall x\\in \\alpha")#text(",")#mi("x=\\{y\\in \\alpha:y\\in x\\}")#text(",then ")#mi("\\alpha")#text(" is a well ordered set.")

#emph[#text("[The requirement that ")#mi("\\alpha")#text(" be well-ordered is part of Definition 4, and is not a consequence of the remainder of the definition. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-134114")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2012")])]

#text("Dear professor Tao,")#linebreak()#text(" Suppose \\alpha is an ordinal which has at least two elements.It is easy to verify that the minimal element of ")#mi("\\alpha")#text(" is ")#mi("\\emptyset")#text(".I wonder whether the minimal element of ")#mi("\\alpha\\backslash\\{\\emptyset\\}")#text(" is ")#mi("\\{\\emptyset\\}")#text("……I can not prove it ,maybe it is not true….")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-134150")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2012")])]

#text("Well….Now I understand this is trivally true.Let ")#mi("x_0")#text(" be the minimal element of ")#mi("\\alpha")#text(",Let ")#mi("x_1")#text(" be the minimal element of ")#mi("\\alpha\\backslash\\{\\emptyset\\}")#text(".The only element that belongs to ")#mi("x_1")#text(" is ")#mi("x_0=\\emptyset")#text(",so ")#mi("x_1=\\{\\emptyset\\}")#text("……What a stupid question.")

#text("Even though this question is stupid,it makes me fully understand that the first several elements of ")#mi("\\alpha")#text(" is ")#mi("\\emptyset,\\{\\emptyset\\},\\{\\emptyset,\\{\\emptyset\\}\\},\\cdots")#text(".This makes ordinals more intuitive for me.")

#text("By the way,I want to say that this blog is brilliant,I’ll try my best to make some constructive comments(though sometimes my comments may seem stupid) which is relevant to the posts.I hope you will not mind my comments taking up too much space.Thanks.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/074bd4a7a3f83e74db99039a10b5fe0a5c117a842d624b00bd10214691203517-54f79ebbb8204330336906060f5e10e682ac648da3a69dee0b916cf856498488.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pan")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-134410")[#strong[#text("Pan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2012")])]

#text("Dear professor Tao,")#linebreak()#text(" I have a question about the note above. In the definition of supremum of a subset A of a well-ordering set X, it does not dependent on the choice of A or just a typo on the definition? Thanks")

#emph[#text("[That was a typo,now corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-134523")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2012")])]

#text("Here is an another conclusion compared to Theorem 1.1:")

#text("Given any two ordinals ")#mi("a")#text(" and ")#mi("b")#text(",")#mi("a\\neq b")#text(",then ")#mi("a\\in b")#text(" or ")#mi("b\\in a")#text(".")

#text("Proof:By symmetry,Suppose ")#mi("a\\subsetneqq b")#text(".Now let’s see ")#mi("a\\bigcup \\{a\\}")#text(" and ")#mi("b")#text(".If ")#mi("a\\bigcup\\{a\\}\\subset b")#text(",then ")#mi("a\\in b")#text(".If ")#mi("b\\subset a\\bigcup\\{a\\}")#text(",then ")#mi("a")#text(" must belong to ")#mi("b")#text(",otherwise, ")#mi("\\subset a")#text(",which is a contradiction to ")#mi("a\\subsetneq b")#text(". ")#mi("\\Box")

#text("But I think this is not as useful as Theorem 1.1,because it assumes ")#mi("a\\neq b")#text(",what a pity. :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc7dfb94106fce0ca724e051a5b2929230f642357579528dcef73c554dcb5db0-4b3225f1f128c8150fefb14f2acedea5af5d590216b5c7f7a869186bd50c8aac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-134935")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2012")])]

#text("Propsition 2 is essenially same with Lemma 8.5.14 in your text book (I read the Chinese version,because I have no access to the English version).Some time ago,I read the proof of Lemma 8.5.14 in ,but I feel rather uncomfortable after reading the proof,because I think in that proof,”the good subset of X”(I don’t know whether I translate it right or not,in Chinese,that is called 偏序集X的好子集) is not well motivated.Now after reading this post,I understand that “the good subset of X ” is essentially “the subset of X which is isomorphic to an ordinal”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc7dfb94106fce0ca724e051a5b2929230f642357579528dcef73c554dcb5db0-4b3225f1f128c8150fefb14f2acedea5af5d590216b5c7f7a869186bd50c8aac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 叶卢庆(Luqing Ye)")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-135437")[#strong[#text("叶卢庆(Luqing Ye)")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2012")])]

#text("I have a hypothesis,I can’t prove it ,maybe it is not true.")

#text("Definition:An ordinal ")#mi("\\alpha\\neq\\emptyset")#text(" is a successor ordinal iff there exists an ordinal ")#mi("\\beta")#text(" such that ")#mi("\\beta\\bigcup\\{\\beta\\}=\\alpha")#text(".")

#text("Now there exists an ordinal ")#mi("m\\neq\\emptyset")#text(",")#mi("\\forall x\\in m(x\\neq\\emptyset)")#text(",")#mi("x")#text(" is a successor ordinal,prove that ")#mi("m")#text(" is a natural number.")

#text("I don’t know whether it is true……")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc7dfb94106fce0ca724e051a5b2929230f642357579528dcef73c554dcb5db0-4b3225f1f128c8150fefb14f2acedea5af5d590216b5c7f7a869186bd50c8aac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 叶卢庆(Luqing Ye)")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-135439")[#strong[#text("叶卢庆(Luqing Ye)")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2012")])]

#text("As soon as I write it down,I realize my stupidness.Let ")#mi("m=\\mathbb{N}")#text(".Done.So the hypothesis is wrong :-(")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20d5c3ae94dac7586b3e4046ff760664c4c9b869f1248f62931216d991f2bf99-8e6a5d1a1a5d42c4d4d3c0ef8c868cc548e7e172825fc4e5597bc09f735d4f82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of questa123456")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-143626")[#strong[#text("questa123456")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2012")])]

#text("About Remark 1, which says that if ")#mi("X")#text(" is a well-ordered set, and ")#mi("\\mathcal{F} \\subset \\mathcal{P}(X)")#text(", then existence of a choice function is established by choosing a minimal element in the respective subset, without AC and in fact illustrating AC.")

#text("My question is, for a general ")#mi("X")#text(", why can’t I just say I choose a “random” element from the respective set such that ")#mi("f(B) \\in B")#text("? or alternatively I couldn’t give you a pre-specified rule about choosing ")#mi("f(B)")#text(" from ")#mi("B")#text(", but if you give ")#mi("B")#text(" to me now, I can choose a ")#mi("f(B)")#text(" from ")#mi("B")#text("? By this way, the AC seems redundant for me…")

#text("So why a uniform rule, such as ")#mi("f(B) = \\min(B)")#text(", is OK, but some some rule unspecified ex-ante is not OK?")

#text("In a similar line, we don’t need the Axiom of Choice to show the existence of a function ")#mi("f:\\mathbb{R} \\rightarrow \\mathbb{R}")#text(", because we have ")#mi("f(x) = x")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-143633")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2012")])]

#text("One has to make a distinction between “")#link("http://en.wikipedia.org/wiki/Lazy_evaluation")[#text("lazily evaluated")]#text("” functions, of the type you propose, and the ")#link("http://en.wikipedia.org/wiki/Function_(mathematics)")[#text("set-theoretic functions")]#text(" which occur in standard set theory (and in particular in Zermelo-Frankel set theory), defined as sets of ordered pairs. A lazily evaluated function can mimic a set-theoretic function to some extent, but only as long as one is only interested in the values of that function on a finite number of points (this is related to how the axiom of finite choice can already be deduced from the other axioms of set theory, but the axioms of countable or unrestricted choice cannot). However, many operations in set theory (such as invocation of the ")#link("http://en.wikipedia.org/wiki/Axiom_of_replacement")[#text("axiom schema of replacement")]#text(") require one to manipulate an infinite number of values of the function at once, and this cannot be done with lazily evaluated functions without allowing for an infinite number of operations to be applied, which is a very dangerous step to allow as it opens the door for any number of paradoxes (e.g. the ")#link("http://en.wikipedia.org/wiki/Ross%E2%80%93Littlewood_paradox")[#text("Ross-Littlewood paradox")]#text("). The solution to all this in traditional set theory is to forget about lazily evaluated functions and infinite numbers of operations, and instead work exclusively with finite numbers of operations applied to set-theoretic functions. (One can then rigorously recover the intuitive idea of applying “infinitely many operations” by tools such as transfinite induction, but only as long as one works within the confines of set theory.)")

#text("However, there are other models of set theory in which lazy evaluation would be permitted, in which case the axiom of choice can be replaced with various “adaptive oracles”. This would no longer be traditional set theory, but can still be conceptually useful for some purposes. I discuss this perspective in ")#link("https://terrytao.wordpress.com/2010/03/19/a-computational-perspective-on-set-theory/")[#text("this previous blog post")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20d5c3ae94dac7586b3e4046ff760664c4c9b869f1248f62931216d991f2bf99-8e6a5d1a1a5d42c4d4d3c0ef8c868cc548e7e172825fc4e5597bc09f735d4f82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of questa123456")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-143727")[#strong[#text("questa123456")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2012")])]

#text("Dear Professor Tao, thank you. When I read books on Set Theory, these things were not discussed explicitly, and they confuse me a lot. Your answer really makes me think more carefully about these issues. I think I need more time to digest the contents you mentioned, but they really help!")

#text("Thank you again.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ee31510df3f52ddca255a2c79ef510e7dc7a86dc8c85bea96dc61603bc82fb4-eff6a90e4f17430e38242055ed1521ae6d9404483ee9181743cb8a1cc2719830.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicola.arcozzi")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-687004")[#strong[#text("nicola.arcozzi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2025")])]

#text("The Ross-Litllewood paradox looks less paradoxical to me if one considers a decreasing sequence of infinite sets (each of them bigger that the sets in the paradox’ statement), which might very well have empty intersection. (Or a decreasing sequence of sets having inifinite measure, whose intersection might very well have null measure).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-214640")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2013")])]

#text("I found some of Escher’s drawings have a lot to do with Zorn’s lemma and the axiom of regurarity and russel’s paradox.For example,one of his picture is “A young man who is seeing a picture is in that picture”,another example is this picture:")#link("http://upfile.chinaschool.org.cn/image/2011/10/19/20111019093448_12375.jpg")[#text("http://upfile.chinaschool.org.cn/image/2011/10/19/20111019093448_12375.jpg")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7f2df9551244b35b80f28af61d91573e2300428de06f10ef1f4fa70a4e9e46e-b8508c53facef952ab7d80feff6e9da23fa710eef594d13d96dc3fca0c38659c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arjun Jain")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-229708")[#strong[#text("Arjun Jain")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2013")])]

#text("My question is in regards to Remark 15. I am new to studying Mathematics properly, and so don’t know the precise meaning of measurability, but has anyone actually constructed a well ordering of the real number set? After reading about the well ordering theorem from Halmos’s book, i tried well- ordering different sets, and was stuck at the reals, and the internet was also not of much help here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-229807")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2013")])]

#text("The well ordering principle says any set can be well ordered,so ")#mi("\\mathbf{R}")#text(" can be well ordered.")

#text("The construction of the well ordering of the ")#mi("\\mathbf{R}")#text(" is quite easy,but the construction is based on Zorn’s lemma(Or well ordering principle,they are equivalent).")

#text("You choose a real numebr every second,and spend your entire life choosing real numbers,and simultaneously arranged them one after one in order.Obviously your life is not enough,because your life is consisted of finite number of seconds.But Zorn’s lemma suppose you are a god,so you can live FOREVER.So if you are a god,then you will finally managed to choosing all the real numbers and arranged them in order.")

#text("Then ")#mi("\\mathbf{R}")#text(" is well ordered.So only god can see intuitively that a well ordering of ")#mi("\\mathbf{R}")#text(" actually exists,we are human beings ,so we can only see logically the a well ordering of ")#mi("\\mathbf{R}")#text(" exsits.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7f2df9551244b35b80f28af61d91573e2300428de06f10ef1f4fa70a4e9e46e-b8508c53facef952ab7d80feff6e9da23fa710eef594d13d96dc3fca0c38659c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arjun Jain")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-229832")[#strong[#text("Arjun Jain")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2013")])]

#text("Sorry, but that doesn’t seem to be convincing to me. Maybe, a more precise answer?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-229861")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2013")])]

#text("In fact,the construction of the well ordering of ")#mi("\\mathbf{R}")#text(" is highly undetermined.It is more like a existence proof instead of a constructive proof,because the construction is essentially based on the Axiom of set(AC is equivalent to Zorn’s lemma).")

#text("As for the detailed proof of the well ordering of ")#mi("\\mathbf{R}")#text(",simply use the Well ordering principle.So it is not interesting to prove that ")#mi("\\mathbf{R}")#text(" can be well ordered,instead,it is interesting to prove the well ordering principle by axiom of choice.")

#text("As for the detailed proof,please see some set theory book,(or this post),especially order theory,such as ordinal numbers,well ordered sets.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-229894")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2013")])]

#text("After some thought,now let me explain more precisely.")

#text("When a set is finite,it is easy to verify by mathematical induction that you can choose finitely many times,and and simultaneously arranged the elements of this finite set one after one in order.")

#text("But in the case of when the set is infinite,in order to well order this set,you should choose infinite many times and arranged them in well order,in the specific case of real number system,you should choose ")#mi("\\#\\mathbf{R}")#text(" number of times and simultaneously arranged real numbers one after one in order,where ")#mi("\\#\\mathbf{R}")#text(" represents the cardinality of ")#mi("\\mathbf{R}")#text(".It is in the case undetermined infinite choice that axiom of choice must be used.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-274720")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2014")])]

#text("This might be a dumb question: It takes me a while to realize that the statement of the Axiom of Choice in this note is equivalent to the one you gave in your Analysis I, in which you use an index set ")#mi("I")#text(" instead of using ")#mi("\\mathcal{F}")#text(" —“the collection of non-empty subsets of ")#mi("X")#text(". Is there a particular reason that you use different forms of the statement?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-274762")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2014")])]

#text("This particular formulation of the axiom of choice is well adapted to the approach to proving Zorn’s lemma given in this blog post. ")#link("http://en.wikipedia.org/wiki/Axiom_of_choice#Variants")[#text("Other formulations")]#text(" of the axiom of choice may be slightly more convenient for some other purposes, but ultimately it is largely a matter of taste which formulation to use for a given context. (In general, I believe it is better mathematical practice to switch freely between different equivalent formulations of a mathematical concept or statement, in order to best fit the context, than to try to stick dogmatically to a single “best” formulation regardless of context out of a misguided desire to be “consistent”. See for instance Thurston’s discussion on the concept of differentiation in Section 2 of ")#link("http://arxiv.org/abs/math/9404236")[#text("this essay")]#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4701c60bb3680950bd0580fa900a74ede38a5f82d41a01742fd52b4aeca8b791-79f4c25effca196648779fb93fb639406085c2ac83f14be4260043c0218c1184.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-428443")[#strong[#text("Marcelo")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2014")])]

#text("Great article! In Remark 7 you refer to Exercises 3 and 4, but the reference should be to Examples 3 and 4 instead. Also, there is an Example 1 appearing between Examples 4 and 5.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-459648")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2015")])]

#text("Would you explain that why ")#mi("{\\Bbb N} \\oplus \\{\\infty\\}")#text(" is not isomorphic to ")#mi("\\{\\infty\\} \\oplus {\\Bbb N}")#text("? It seems that one could reverse the order. What is wrong for that reasoning?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-459669")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2015")])]

#text("Isomorphism of ordered sets has to preserve order, not reverse it.")

#text("The ordered set ")#mi("{\\mathbb N} \\oplus \\{\\infty\\}")#text(" has a maximal element, whereas ")#mi("\\{\\infty\\} \\oplus {\\mathbb N}")#text(" does not, so the two sets are not order-isomorphic.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-459686")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2015")])]

#text("I’m confused with Exercise 2 to Exercise 4. In an undergraduate course (say in your book Real Analysis I), mathematical induction is assumed as one of the Peano ")#emph[#text("axioms")]#text(" to define natural numbers (and then integers, rational numbers, real numbers…) But here, it becomes a corollary of Exercise 2 to Exercise 4, which are supposed to be “proved”. (You call them Peano-type ")#emph[#text("axioms")]#text(". Aren’t axioms something assumed to be true that one need not to prove it?) What axioms are allowed to assumed in order to do exercises in this post and what are ")#emph[#text("not")]#text(" allowed to?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-459693")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2015")])]

#text("This post (like most modern mathematical writing) is implicitly set in the framework of Zermelo-Frankel-Choice (ZFC) set theory. In this theory, the Peano axioms are not part of the ")#link("https://en.wikipedia.org/wiki/Zermelo%E2%80%93Fraenkel_set_theory#Axioms")[#text("ZFC axiom set")]#text(", although once one constructs the natural numbers inside ZFC one can verify that they obey the Peano axioms.")

#text("In the theory of Peano arithmetic (PA), the Peano axioms are indeed assumed as axioms, however Peano arithmetic is not sufficient to describe much of modern mathematics (particularly those parts that involve manipulation of infinite sets) and so one usually works in a larger theory. (In particular, given the powerful and standard nature of ZFC, one usually works in this set theory, though in many cases one could probably conduct one’s mathematical applications in some intermediate theory between PA and ZFC; also in some more advanced topics it is sometimes useful to go beyond ZFC, e.g. by adding large cardinal axioms.) In my analysis book, for instance, I start out in PA, but after a few chapters switch to ZFC in order to be able to handle infinite sets. (To ensure backwards compatibility, the natural numbers are then constructed in ZFC and shown to obey the axioms of PA.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-477592")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2017")])]

#text("As far as I know, you do include the Peano axioms explicitly in your text, even in your formulation of Zermelo-Fraenkel set theory. You formulate the axiom of infinity as:")

#text("“There exists a set N, whose elements are called natural numbers, as well as an object 0 in N, and an object n++ assigned to every natural number n in N, such that the Peano axioms (Axioms 2.1 – 2. 5) hold.”")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-472972")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2016")])]

#text("Is there a typo in Exercise 2? The capital Y seems to have not been defined.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-477575")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2017")])]

#text("In Halmos’s Naive Set Theory, the principle of transfinite induction, which looks quite different from the one in this post, is stated as follows.")

#text("… suppose that S is a subset of a well ordered set X, and suppose that whenever an element x of X is such that the entire initial segment s(x) is included in S, then x itself belongs to S; the principle of transfinite induction asserts that under these circumstances we must have S = X. Equivalently: if the presence in a set of all the strict predecessors of an element always implies the presence of the element itself, then the set must contain everything.")

#text("And Halmos made the following remarks:")

#text("A few remarks are in order before we look at the proof. The statement")#linebreak()#text(" of the ordinary principle of mathematical induction differs from that of")#linebreak()#text(" transfinite induction in two conspicuous respects. One: the latter, instead")#linebreak()#text(" of passing to each element from its predecessor, passes to each element")#linebreak()#text(" from the set of all its predecessors. Two: in the latter there is no assumption")#linebreak()#text(" about a starting element (such as zero). The first difference is important:")#linebreak()#text(" an element in a well ordered set may fail to have an immediate predecessor.")

#text("Is his version of transfinite induction equivalent to Exercise 4?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-477579")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2017")])]

#text("Yes; if in the setting of Exercise 4, one sets ")#mi("S")#text(" to be the set of all elements ")#mi("x")#text(" of ")#mi("X")#text(" for which ")#mi("P(x)")#text(" is true, then it is not too difficult to show that the three hypotheses of Exercise 4 are equivalent to the assertion in Halmos’s version. I arranged the hypothesis in this fashion in order to make transfinite induction more closely resemble standard mathematical induction; as Halmos notes, the slicker and more common form of transfinite induction has less resemblance to ordinary induction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-477807")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#text("Ah, I just found that Exercise 1(Strong induction on well-ordered sets) is Halmos’s version. So your comment basically implies that Ex1 and Ex4 are equivalent for well-ordered sets.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-478012")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2017")])]

#text("In the case of “standard” mathematical induction, there are two equivalent versions; one is called weak (sometimes called “regular”) mathematical induction and the other one is called strong mathematical induction. (")#link("http://www.oxfordmathcenter.com/drupal7/node/485")[#text("http://www.oxfordmathcenter.com/drupal7/node/485")]#text(") The counterpart in this post would be Exercise 1 and Exercise 4. Now that they are equivalent, why would it be necessary at all to consider the “weaker” version? Obviously the strong one allows use to assume “more”; isn’t it preferable when we prove something using induction?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-477624")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2017")])]

#text("I’m a little confused with Exercise 4. The standard mathematical induction, which is equivalent to well ordering principle (and thus equivalent to the axiom of choice), can be a consequence of Exercise 4 (can’t it?). But Exercise 4 can be deduced from the ZFC axioms. So does it suggest that Exercise 4 is nothing but the standard mathematical induction?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-477711")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2017")])]

#text("Mathematical induction is equivalent to the ")#link("https://en.wikipedia.org/wiki/Well-ordering_principle")[#text("well-ordering principle")]#text(" (that the natural numbers with the usual ordering is well-ordered). This should not be confused with the <A HREF=\"")#link("https://en.wikipedia.org/wiki/Well-ordering_theorem\"the")[#text("https://en.wikipedia.org/wiki/Well-ordering_theorem\"the")]#text(" well-ordering theorem, that asserts that every set can be given an order that makes it well-ordered. The latter is equivalent to the axiom of choice, but the former is not.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-477628")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2017")])]

#text("I have almost zero knowledge in category theory. When I try to read this set of notes, the concept “representation” is used several times, which looks “intimidating” for me. Is there an alternative way (say in the language of ZFC set theory?) to understand the corresponding materials (e.g. a representation of the well-ordered sets) without category theory?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-477776")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#text("No knowledge of category theory is needed for this post (the one remark mentioning category theory is not used elsewhere in the post).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-477779")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#text("The word “assignment” is used in Definition 3 for “representation”. What could be the corresponding concept in the ZFC set theory? In the setting of ZFC, one can reduce anything to a set. How can one do this for “representation”? (Since you mention in the remark that it is a functor in category theory, I guess one cannot say that it is a “function”.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-477810")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#text("What is the really difference between ordinals and well-ordered sets? It seems from Theorem 1 that they are really the same thing; hence Exercise 10 and Exercise 4 (and thus Exercise 1) are all equivalent?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-477991")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2017")])]

#text("Every well-ordered set is ")#emph[#text("isomorphic")]#text(" to an ordinal, but it may not actually ")#emph[#text("be")]#text(" an ordinal. For instance, the finite set of real numbers ")#mi("\\{ -20, -\\pi, 2\\sqrt{2} \\}")#text(" is well-ordered, and isomorphic to the ordinal ")#mi("\\{ \\emptyset, \\{ \\emptyset\\}, \\{ \\emptyset, \\{ \\emptyset\\} \\} \\}")#text(", but is not actually an ordinal itself.")

#text("For many applications that involve just one well-ordered set, one can usually replace that a well-ordered set by an isomorphic copy of itself, in which case there is little distinction between well-ordered sets and ordinals. But when dealing with multiple well-ordered sets it can sometimes be too confusing to try to identify all of them simultaneously with ordinals. For instance, one might be considering multiple well-orderings ")#mi("<_1")#text(", ")#mi("<_2")#text(", etc. on the natural numbers ")#mi("{\\bf N}")#text(", with different ordinal types (maybe one ordering is isomorphic to the ordinal ")#mi("\\omega")#text(", another is isomorphic to ")#mi("\\omega+1")#text(", another to ")#mi("\\omega^2")#text(", and so forth). Trying to identify the natural numbers simultaneously with all of these ordinals at once may lead to a lot of confusion with notation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3758e5d5dae7f4e715f3767a5e7e4a0b72111e7b5da0df7f20b0cae5d2297871-b51dfb79309066bbfc1d202359cf1cb75e25c1f1b3be927b2efa080de67762a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-482219")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2017")])]

#text("Dear Prof. Tao, in Prop. 1 please replace “and” by “to”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-486439")[#strong[#text("Marco (@MarcoAntei)")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2017")]

#text("Hi, how to cite this article? I am actually interested in Remark 14, since I have a statement that it seems I can only prove with the strong version of Zorn’s Lemma. As it also seems to me that this second version is not very well known I would like to add a reference to this article or to a book, if someone knows any. Thanks for your attention. Marco")

#emph[#text("[See ")#link("https://terrytao.wordpress.com/books/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/")[#text("https://terrytao.wordpress.com/books/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-491708")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("I think that the proof of Zorn’s lemma is an unusual argument; namely a contradiction against an unusual nonexisting object.")

#emph[#text("[More examples may be found at ")#link("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/")[#text("https://terrytao.wordpress.com/2009/11/05/the-no-self-defeating-object-argument/")]#text(" -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-491710")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("Dear Prof. Tao,")#linebreak()#text(" could you possibly place the oplus and otimes operations on ordered sets into a larger context? I have the feeling that they are special cases of something more general, but I don’t know what it is. (Obviously it’s something much weaker than a ring.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-491718")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("Presumably these are instances of a more general category theoretic construction, but I am not an expert on these matters. (It seems though that the obvious candidates for such a construction, namely the category theoretic product and coproduct, are not available in the category of ordered sets, so it has to be something else.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-491713")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("I just observed that if I extend a well-ordered set on the left by another set, then if there was a maximum before, I’m in the successor case, while otherwise I’m in the limit case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-491714")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("I mean on the right.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-491723")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("Lol ")#mi("\\epsilon_0")#text(" in the proof of thm. 2")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/876002add30560f940245cae4f30f17b114fdcdc4a38dd2376fb43fc126a5676-c0191bc3e413c578697ed69e4ce226e1554120ca9a16963771b4734a49c2bf64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Original CC")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-507331")[#strong[#text("The Original CC")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2018")])]

#text("I’m not sure what you mean in Remark 13: “Indeed, the collection of countable subsets of an uncountable set (such as ")#mi("{\\Bbb R}")#text(") is non-empty, and every countable chain has an upper bound, but there is no maximal element.")

#text("Does every countable chain in the reals have an upper bound? What about the chain of rational numbers? Or did you mean well-ordered sets in place of chains? (I’m probably missing something obvious here.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-507477")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2018")])]

#text("Every countable chain of countable subsets of the reals has an upper bound (namely the union of these countable sets, which is again countable).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/876002add30560f940245cae4f30f17b114fdcdc4a38dd2376fb43fc126a5676-c0191bc3e413c578697ed69e4ce226e1554120ca9a16963771b4734a49c2bf64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Original CC")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-507685")[#strong[#text("The Original CC")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2018")])]

#text("Aha, thanks. The ordering here is the subset ordering, not the regular “<\" ordering. Very cool example (now that I understand it)!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A: Problem solving strategies | What's new")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-511369")[#strong[#text("245A: Problem solving strategies | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2019")])]

#text("[…] (e.g. the proof of existence of non-principal ultrafilters, discussed in this previous post). See my blog post on Zorn’s lemma for more discussion. One subtlety when applying this lemma is that one has to check that the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-682675")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2023")])]

#text("In Example 5:")

#text("“In the foundations of set theory, this construction, together with the axiom of infinity, is sometimes used to define the natural numbers”")

#text("Without the set of natural numbers, how does one write ")#mi("\\omega := \\{ n^{th}: n \\in {\\Bbb N} \\}")#text(" where ")#mi("{\\Bbb N}")#text(" is used in defining ")#mi("\\omega")#text("?")

#text("(By the way, the label “Example 5” is used in two places.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-682676")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2023")])]

#text("Hmm, I think I see you mean first defining ")#mi("{\\Bbb N}")#text(" via (3) in the construction, and then one can define ")#mi("\\omega := \\{ n^{th}: n \\in {\\Bbb N} \\}")#text(". How is “the axiom of infinity” used if one wants to proceed in this way?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-682688")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2023")])]

#text("See ")#link("https://en.wikipedia.org/wiki/Set-theoretic_definition_of_natural_numbers")[#text("this Wikipedia page")]#text(". One defines ")#mi("{\\mathbb N}")#text(" to be the smallest set containing ")#mi("\\emptyset")#text(" and closed under the successor operation ")#mi("n \\mapsto n \\cup \\{n\\}")#text("; the axiom of infinity is used to show that such a set exists.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-682680")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2023")])]

#text("Right after formula (1) in Exercise 1, “thus for instance the supremum of the empty set is ")#mi("\\min(X)")#text("“…")

#text("So the “supremum of the empty set” depends on which well-ordered set ")#mi("X")#text(" one is talking about? Which means it could be defined more than once?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-682689")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2023")])]

#text("If one wanted to be completely pedantic, one should write the supremum ")#mi("\\sup A")#text(" to be something like ")#mi("\\sup_X A")#text(" instead to specify the ambient well-ordered set ")#mi("X")#text(", but usually this ambient space is clear from context.")

#text("In the proof assistant language Lean, this type of issue is resolved through ")#link("https://en.wikipedia.org/wiki/Type_theory")[#text("type theory")]#text(". While Lean does ")#link("https://leanprover-community.github.io/mathlib4_docs/Mathlib/SetTheory/ZFC/Basic.html")[#text("support the ability")]#text(" to work inside the single gigantic ZFC universe of sets, for most applications what one does instead is work inside various spaces, such as a well-ordered set (or more precisely, type) `X`, and then introduce the type `Set X` of sets inside this space. These are different types for different values of `X`; an element of `Set X` will not equal an element of `Set Y` (even if `X` is itself contained in `Y`), although there are often canonical embeddings from one to the other. In particular, each set `A` “knows” which ambient space `X` it belongs to, eand each space `X` comes with its own empty set `∅: Set X`, which are technically different objects for each `X`, although through Lean’s type inference system one can usually just refer to each such empty set with the same symbol `∅` without creating ambiguity. It requires a certain amount of mental effort to move from the orthodox ZFC model of “everything is a set in a single giant universe of sets” to a multi-sorted conceptual model of mathematics, but actually the latter is closer to how mathematicians actually think. (See also ")#link("https://mathoverflow.net/questions/90820/set-theories-without-junk-theorems/90945#90945")[#text("this post by Blass")]#text(" on this point.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-688186")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2025")])]

#text("For the function ")#mi("P")#text(" in the strong induction set, do you mean ")#mi("x \\to \\{1,2\\}")#text(" instead of ")#mi("\\mapsto \\{1,2\\}")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/28/245b-notes-7-well-ordered-sets-ordinals-and-zorns-lemma-optional/#comment-689575")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2026")])]

#text("Dr. Tao,")#linebreak()#text(" I’m not familiar with set theory like you, I would like to ask: in the spirit of “package-oriented” perspective of mathematical structures, could we view ZFC model as a package too? By “model”, is it the same as “structure”?")
]
