// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/05/29/google-wave/
// Converted to Typst by tao2typ: "2026-10-14T15:17:16.267780+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Google Wave", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Google Wave")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 May 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/05/29/google-wave/")[#text("https://terrytao.wordpress.com/2009/05/29/google-wave/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("As readers of this blog are no doubt aware, I (in conjunction with Tim Gowers and many others) have been working collaboratively on ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("a mathematical project")]#text(". To do this, we have been jury-rigging together a wide variety of online tools for this, including ")#link("http://en.wordpress.com/tag/polymath1/")[#text("at least")]#text(" ")#link("https://terrytao.wordpress.com/tag/polymath1/")[#text("two")]#text(" ")#link("http://gowers.wordpress.com/tag/polymath1/")[#text("blogs")]#text(", ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("a wiki")]#text(", ")#link("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DsU-uZ1tK7VEg&hl=en")[#text("some")]#text(" ")#link("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DuqNcxJ171Bbw&hl=en")[#text("online")]#text(" ")#link("http://spreadsheets.google.com/ccc?key=p5T0SktZY9DuKZ2DyzO9EOg&hl=en")[#text("spreadsheets")]#text(", and good old-fashioned email, together with offline tools such as Maple, LaTeX, C, and other programming languages and packages. (To a lesser extent, I also rely this sort of mish-mash of semi-compatible online and offline software packages in my more normal mathematical collaborations, though polymath1 has been particularly chaotic in this regard.)")

#text("While this has been working reasonably well so far, the mix of all the various tools has been somewhat clunky, to put it charitably, and it would be good to have a more integrated online framework to do all of these things seamlessly; currently there seem to be software that achieves various subsets of what one would need for this, but not all. (This point has also ")#link("http://sbseminar.wordpress.com/2009/05/27/2009/")[#text("recently been made")]#text(" at the Secret Blogging Seminar.)")

#text("Yesterday, though, ")#link("http://google-au.blogspot.com/")[#text("Google Australia")]#text(" ")#link("http://googlesystem.blogspot.com/2009/05/google-wave.html")[#text("unveiled")]#text(" a new collaborative software platform called “")#link("http://wave.google.com/")[#text("Google Wave")]#text("” which incorporates many of these features already, and looks flexible enough to incorporate them all eventually. (Full disclosure: my brother is one of the software engineers for this project.) It’s nowhere near ready for release yet – it’s still in the development phase – but with the right type of support for things like LaTeX, this could be an extremely useful platform for mathematical collaboration (including the more traditional type of collaboration with just a handful of authors).")

#text("There is a demo for the product below. It’s 80 minutes long, and aimed more at software developers than at end users, but I found it quite interesting, and worth watching through to the end:")

#text("[")#emph[#text("Update")]#text(", May 30: Apparently a LaTeX renderer is already being developed as an ")#link("http://code.google.com/apis/wave/")[#text("API extension to Google Wave")]#text("; here is a very ")#link("https://terrytao.wordpress.com/wp-content/uploads/2009/05/latexy-test.png")[#text("preliminary screenshot")]#text(". Also, a shorter explanation of what Google Wave is and does ")#link("http://mashable.com/2009/05/28/google-wave-guide/")[#text("can be found here")]#text(". ]")

#text("[")#emph[#text("Update")]#text(", Jun 7: Another review can be ")#link("http://www.suntimes.com/business/1606282,ihnatko-google-wave-060309.article")[#text("found here.")]#text("]")

#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26ebefc1f9b8566c68efa11a787298f9a970eb21b111079d49ce64fad7b3b576-f1615e6a92554c717e965fab86307461b3ed3404db7c53b4e7d2a7d2fc90ad81.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Drazick")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39083")[#strong[#text("Drazick")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2009")])]

#text("I wish they added Zoho like Latex / MathML support for each of their WYSWYG editors (Google Docs, Gmail, Blogger and when time comes Wave).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd4bfb06bd050a989093ed573685723febc2f7fbc97be93869ddd8bab3257fc9-7fe956b9f8b7dae1686b686a0691c02b9667dd8802e8de59c9cf328efac02d71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Google Wave… « Ars Physica")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39084")[#strong[#text("Google Wave… « Ars Physica")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2009")])]

#text("[…] Atualizado (2009-May-29 @ 18:37h EDT): O T. Tao também pegou essa notícia, e ficou tão ansioso quanto esse que vos fala: Google Wave. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74172357fd975fa76054218ce325e0a7a09e69fb008c4ef381f959e0d0a4d995-3ca9e577933e5e9c9626c70d262767089be263ebf2a3fc0e3c80038667eac6d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sol")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39087")[#strong[#text("Sol")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2009")])]

#text("What language is Google Wave developed in?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39090")[#strong[#text("Steve")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2009")])]

#text("Sol: Java. (Which you would know if you watched the video.)")

#text("This is really cool stuff. It could just be the next generation communications and collaboration model, because it so cleverly embraces and extends everything we have now and because they have designed it to be open from the start. I just applied for developer access to the sandbox and spent most of the day reading docs with the goal of hacking together wikipedia style latex support.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d529333425a240650df5a9340483eb57cef01492505ede9bc484aef9f9ff3f5c-689c4f22a94fbe8cbebca21c97342337c2f7d8643d731f7cab2293912aab03d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph Corneli")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39095")[#strong[#text("Joseph Corneli")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2009")])]

#text("PlanetMath.org runs Noosphere, which has very good")#linebreak()#text(" support for LaTeX, and has been used by thousands")#linebreak()#text(" of people to build the PlanetMath encyclopedia")#linebreak()#text(" (")#link("http://planetmath.org")[#text("http://planetmath.org")]#text("). Noosphere is also open")#linebreak()#text(" source. Maybe it is a good ingredient to add to this")#linebreak()#text(" discussion; feel free to contact me for details.")

#text("(Full disclosure: I’m not one of the developers of")#linebreak()#text(" Noosphere, but I have been working on related tool,")#linebreak()#text(" based on Lisp and SQL, which may be integrated into")#linebreak()#text(" PlanetMath in the not-too-distant future, and which")#linebreak()#text(" should facilitate rapid extension of the platform.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39096")[#strong[#text("Google Wave « xcellenc")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2009")]

#text("[…] Google Wave By alanzed I was very excited to see the introduction of Google wave yesterday, and the open source approach it offers. I immediately thought it would be great to see other embedded support like Latex, LilyPond, etc., and glad to see that Terry Tao is already thinking about this. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39100")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2009")])]

#text("I’ve had success using a combination of Plone CMS and jsmath. Plone also has bibtex support through the CMFBibliographyAT extension.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39109")[#strong[#text("How to Write a Really Good Research Paper « Successful Researcher")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2009")]

#text("[…] 3: Google has recently produced a demo for a new online collaboration tool, Google Wave; see the post of Terence Tao for more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad52b87e0a64717b643bd42d52581958a5d87ddc1bc36ddc8cd2c10cce8ea7c6-680376e14a3e59cbcbd78fb17a8e2b0f0df7c973cf80c9c49b325e0691e8fe24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Link Starbureiy")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39110")[#strong[#text("Link Starbureiy")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2009")])]

#text("I blogged about this, too. This looks promising enough to be the tool we’ve been waiting for. See if you can get your brother (or anyone on the Google Australia team working on the product) to incorporate certain feature-sets like Equation Editor. Most importantly, I’d rather much have .docx format (Microsoft’s Office 2007 document file type) included over the standard Google .doc file structure. There are other reasons, but .docx is way richer than the other formats (as evidenced by embeddable equations from Equation Editor), not to mention LaTEX. TEX – and its variations – is a pseudo programming language in itself, and unless your very experienced using it (or care to be), it’s a drawback.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39116")[#strong[#text("Google wave « Scientific Clearing House")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2009")]

#text("[…] Google wave By Carson Chow There are three technological developments that I’ve been waiting for that could actually improve my life. The first is a letter-sized electronic reader that can hold every book and paper that I’ll ever need. Amazon Kindle is not it but a company named Plastic Logic is promising something like this soon. The second thing that I’m waiting for is a program that will read and sort my emails. It will know how to prioritize them, delete the ones I don’t need anymore, update my calendar for events and meetings, and save keepers in the correct folders (including creating folders for new topics when expedient) when I’m done reading them. (Actually, there is something like this already, known as an administrative assistant but I’m waiting for an electronic one.) It may be a (long) while before something like this is available. The third thing I’m waiting for is a remote collaboration tool. This would be something to interact with collaborators remotely that mimics the experience of standing together in front of a blackboard. Thus far, none of the things I’ve seen that are supposed to do this have gained traction with me. However, Google is coming out with something called Google Wave that may be closer to what I’m looking for. It is a online communication tool that will support latex. Terry Tao has a nice summary of how it could be useful for scientific communication on his blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of karabasov")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39118")[#strong[#text("karabasov")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2009")])]

#text("As far as a collaborative implementation of (La)TeX is concerned, one may use ")#link("http://www.scribtex.com")[#text("http://www.scribtex.com")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39125")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2009")]

#text("[…] Google Wave As readers of this blog are no doubt aware, I (in conjunction with Tim Gowers and many others) have been working […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1955ae2f4266038cc862544168e3dd8a029cec41306d25b300ed9e0f2d1ee5b-161681b0f6bab5a9a10889405552eaf2cb19b68c577786f4c5a29c15d01ebfff.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pamela Fox")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39129")[#strong[#text("Pamela Fox")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2009")])]

#text("The screenshot shown is of a demo robot developed by one of the engineers. It simply sends a request to a WordPress service that renders Latex expressions. It’s not built-in to Google Wave.")

#text("You are welcome to build a robot with more advanced Latex comprehension. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39135")[#strong[#text("Google Wave | NEQNET: Non-equilibrium Phenomena")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2009")]

#text("[…] Everybody (Terence Tao for one) seems to be excited about forthcoming Google Wave, and so am I. Here is the video […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39157")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2009")])]

#text("This is very exciting. Are there any plans for a second polymath project once Google Wave is sufficiently practical?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39209")[#strong[#text("Writing math papers on Google Wave? « Secret Blogging Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2009")]

#text("[…] mixture of shareability, privacy, and flexibility. I don’t have much to say about it that Terry Tao didn’t say better, but you should all look at the developer preview of Google Wave. Or not, if you don’t want […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d58677b4023c07b9b61cf0df9fef1bc113847e309100e069a0553cbecbd3aa2-30758f8d1f45cd3689e45046e6532a6d5e9799c1bc00d595c3d66f9be73b61c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YongHui Wang")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39230")[#strong[#text("YongHui Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2009")])]

#text("Does Google Wave support the tablet PC pen? I thought it is much convenient for mathematic talks.")

#text("There few software and web-talk supporting the tablet PC pen, e.g. Microsoft Onenote, and MSN.")

#text("Maybe that is the reason why it is not popular for the table PC, instead of its convenience for many informal talks in science.")

#text("Is there someone who would like to recommend it to Google Software engineers?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/903db712380cbc6da636e3b9ba343845f8741a929de7cd422910c08c187fa2ec-e05833ab97cdf6a86f47d1e888dd6dd0c862fb510826663518ea4018dc92cbab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Glenn Fernandes")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39321")[#strong[#text("Glenn Fernandes")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2009")])]

#text("Thanks for the demo. Google Wave is an amazing software platform featuring blogs, forums, emails, etc. Google is simply great. It offers the best products and satisfy its users. For more details refer ")#link("http://www.etechreviews.net/google-wave-reviews/")[#text("http://www.etechreviews.net/google-wave-reviews/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/057bf7801fb2b85520abb8d2e154098c2d27351c07ed28806692663e9bff8cce-2229d782d57035eb8a5bb7ff70fc6fd192becf4bd553b783add1a459f3ffef2f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of krisreyes")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39325")[#strong[#text("krisreyes")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2009")])]

#text("Professor Tao,")

#text("I too am looking forward to Google Wave. I have been working on a project that I usually describe as “Facebook for Researchers.” As I’ve been evaluating collaboration software programs, I’ve found (like you) that the current set of tools don’t quite fit well together. I’m really anticipating Google Wave and what it can do for research and collaboration.")

#text("In my ideal situation, such a tool would could help with both research and scholarly publishing. Imagine the life-cycle of a paper written in this new environment: a researcher indicates to the site that she’s interested in a particular problem. The site mentions some relevant papers and people (like how Amazon or Netflix suggests titles a user may like). She sees a colleague working on a similar problem and initiates communication via the site. They use a tool such as Google wave and others to collaborate and work toward a result. After some hard thinking, they have a paper, which they publish on the site. They offer their paper online, and recruit referees or other readers for feedback. Finally, their paper is available for download or print, with a license the authors can specify. The site also enables people to create their own custom print journals — where a user can specify papers he/she is interested in, and have it printed, bound and delivered. Such a site could foster a community for free or cheap journals with a quality similar to the professional ones (think Wikipedia vs. Encyclopedia Britannica).")

#text("I would be interested in hearing your thoughts on such an online collaboration/publishing tool.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Brauer")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39482")[#strong[#text("Uwe Brauer")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2009")])]

#text("noosphere:")

#text("Joseph,")

#text("I agree with you that noosphere contains almost everything one")#linebreak()#text(" could wish for a scientific collaboration based on Latex.")

#text("However one should add that it is quite complicated to install.")#linebreak()#text(" While it is relatively straightforward to install")#linebreak()#text(" wiki/wordpress/moodle all of then php based with a connection to a")#linebreak()#text(" (mqsql) data base, the same cannot be said for noosphere.")

#text("I tried for several weeks to install it on our local server for the")#linebreak()#text(" department, but even with the help of Aaron Krowne it did not work. I")#linebreak()#text(" presume the problem has to do with my apache2 server configuration but")#linebreak()#text(" I was never able to figure that out.")

#text("Uwe Brauer")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 合作写数学论文的新形式 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-39975")[#strong[#text("合作写数学论文的新形式 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2009")])]

#text("[…] 尽管此种尝试已经很是成功了，但现有的工具还并不十分理想，一方面，博客的方式太过线性，无法突出重点；另一方面，wiki的方式又缺乏线性，让人看不到来龙去脉，更难以用作讨论。五月末时候，Tao教授在博客上发表另一篇帖子，表示对Google Wave这个新东西的兴趣，希望能够用来对讨论数学有所帮助。据我所知，wave到目前仍十分的不稳定，但希望将来可以很快被利用起来。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of IMO 2009 Q6 mini-polymath project: impressions, reflections, analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-40567")[#strong[#text("IMO 2009 Q6 mini-polymath project: impressions, reflections, analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("[…] that future technological advances (e.g. the concurrent editing capabilities of platforms such as Google Wave) may change this, though; also a culture and etiquette of collaborative thinking might also evolve […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Two quick updates « What’s new")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-41644")[#strong[#text("Two quick updates « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2009")])]

#text("[…] In another previous post, I talked about the forthcoming Google Wave platform being developed currently by Google, and its potential usefulness for online mathematical collaborative projects, such as the polymath projects. My brother, who is one of the developers for this project, has just informed me that there are now a limited number of invites available to others who would like to develop specific Wave extensions or other projects (see for instance his own blog post, aimed at the GNOME community). As I understand it, the Wave platform is not yet ready for general use, so these invites would be intended for technical developers (or preferably, a group of developers) who would be working on specific projects. (For instance, I understand that there is already a preliminary extension for encoding LaTeX in a Wave, but it could be developed further.) If any readers are interested, one can request an invite directly from the Google Wave page, or I can forward requests to my brother. Possibly related posts: (automatically generated)Google issues invites to Google WaveGoogle plans limited preview of WaveBits: Wider Release for Google Collaboration Tool […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c7ef2734fbecdfc5bd5cdd836027c85301bb1694ede49822f46e5174176e04c-a48033282d56e7adb7528b397ddd6945136e8ab8ab033316870a98d531b47035.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-42099")[#strong[#text("Kevin")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2009")])]

#text("Here’s a latex robot for google wave:")#linebreak()#text(" ")#link("http://wave-samples-gallery.appspot.com/about_app?app_id=58014")[#text("http://wave-samples-gallery.appspot.com/about_app?app_id=58014")]#linebreak()#text(" it searches latex snippets ($$ surrounded) as you tyoe and replaces it with an image.")#linebreak()#text(" here’s a preview:")#linebreak()
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77a630af72211b3e5dc4c6c841afb8d1bb3137f8889a86ffe1076796b32f1092-ffb7f3ee623c1af1aacc5a044b4df85afd649c16e415f885ce268494df99b495.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eldon Schneider")]], [#link("https://terrytao.wordpress.com/2009/05/29/google-wave/#comment-43238")[#strong[#text("Eldon Schneider")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2010")])]

#text("Fairly discussed info for such a brief post. Nicely done. I’m just wondering which is a better wave extension, the chrome or the one featured by firefox? Hmmm…")
]
