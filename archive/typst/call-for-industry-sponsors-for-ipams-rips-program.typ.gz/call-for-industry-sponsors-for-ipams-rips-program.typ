// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/11/24/call-for-industry-sponsors-for-ipams-rips-program/
// Converted to Typst by tao2typ: "2026-10-15T08:34:58.439252+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Call for industry sponsors for IPAM’s RIPS program", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Call for industry sponsors for IPAM’s RIPS program")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 November 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/11/24/call-for-industry-sponsors-for-ipams-rips-program/")[#text("https://terrytao.wordpress.com/2025/11/24/call-for-industry-sponsors-for-ipams-rips-program/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-15 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Over the last 25 years, the ")#link("https://www.ipam.ucla.edu/")[#text("Institute for pure and applied mathematics")]#text(" (IPAM) at UCLA (where I am now director of special projects) has run the popular ")#link("https://www.ipam.ucla.edu/all-upcoming-programs/rips-sponsor-information/")[#text("Research in Industrial Projects for Students")]#text(" (RIPS) program every summer, in which industry sponsors with research projects are matched with talented undergraduates and a postdoctoral mentor to work at IPAM on the sponsored project for nine weeks. IPAM is now putting out a call for industry sponsors who can contribute a suitable research project for the Summer of 2026, as well as funding to cover the costs of the research; details are ")#link("https://www.ipam.ucla.edu/all-upcoming-programs/rips-sponsor-information/")[#text("available here")]#text(".")

#text("(Student applications for this program will ")#link("https://www.ipam.ucla.edu/programs/student-research-programs/research-in-industrial-projects-for-students-rips-2026-los-angeles/")[#text("open at a later date")]#text(", once the list of projects is finalized.)")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6777001f403f3d311b74ddf885f5bb03d665708d095dfed25946bb1cc08bda59-0e7479ae473603f956270e39e14c11068bfff637e3e0ed8c5cce1bfd3efa3769.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Saksham")]], [#link("https://terrytao.wordpress.com/2025/11/24/call-for-industry-sponsors-for-ipams-rips-program/comment-page-1/#comment-689137")[#strong[#text("Saksham")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2025")])]

#text("A short question – are there canonical examples of industrial sponsors from past RIPS programs or examples of the types of organisations that usually participate? (alongside the attributes of such sponsors: sector; location; financial scale; continuity and duration of their involvement, in brief – unless the program is deliberately open-ended in this regard.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/11/24/call-for-industry-sponsors-for-ipams-rips-program/comment-page-1/#comment-689143")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2025")])]

#text("Projects run for nine weeks and are held at UCLA; further details are available at the ")#link("https://www.ipam.ucla.edu/all-upcoming-programs/rips-sponsor-information/")[#text("link provided in the blog")]#text(". Last year, the participating industry sponsors were Microsoft (“Geometry of Compositional Abstraction in Large Language Models”), RAND (“Leveraging Large Language Models to Enhance Survey Data”), Google (“Formalizing Differential Privacy in Lean”), Analog Devices (“Improving Few-Shot Object Detection with Synthetic Data”), AMD (“Accelerating Linear Programming on AMD GPUs”), NASA (“Navigating the Problem Landscape: Finding Barren Plateaus and Rugged Terrains with Empirical Hardness Model”), Lawrence Livermore National Laboratory (“Bayesian Wind Farm Layout Optimization”), Avery Digital (“How to Build an AI Biologist: In Silico Antibody Optimization”), and the Aerospace Corporation (“Resource allocation for meteor interception using reinforcement learning”).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2025/11/24/call-for-industry-sponsors-for-ipams-rips-program/comment-page-1/#comment-689148")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2025")])]

#text("What kind of mathematical knowledge and/or maturity is expected of the undergraduates selected? The past projects seem much more complex than typical undergrad curriculum.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/11/24/call-for-industry-sponsors-for-ipams-rips-program/comment-page-1/#comment-689154")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2025")])]

#text("The ")#link("https://www.ipam.ucla.edu/programs/student-research-programs/research-in-industrial-projects-for-students-rips-2025-los-angeles/?tab=faq")[#text("2025 FAQ")]#text(" covers this question. Part of the nine-week experience will be learning some fairly advanced industrial mathematics, guided by the postgraduate mentor and industry sponsor researcher(s).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2025/11/24/call-for-industry-sponsors-for-ipams-rips-program/comment-page-1/#comment-689151")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2025")])]

#text("Was this one of the programs that lost government funding?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/11/24/call-for-industry-sponsors-for-ipams-rips-program/comment-page-1/#comment-689152")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2025")])]

#text("In past years, RIPS has been paid for by a combination of industry sponsorship and NSF funding. Currently, the IPAM NSF grant has not been renewed beyond this fiscal year, but the situation may change in the future.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2025/11/24/call-for-industry-sponsors-for-ipams-rips-program/comment-page-1/#comment-691681")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2026")])]

#text("I did read in The Economist ")#link("https://archive.is/a1Kl5")[#text("https://archive.is/a1Kl5")]#text(" that Congress recently restored NSF funding. This is wonderful news, and hopefully this improves the situation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2025/11/24/call-for-industry-sponsors-for-ipams-rips-program/comment-page-1/#comment-697776")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2026")])]

#text("Unfortunately I read recently that NSF grants have still been mostly frozen.")

#text("It would be very nice if the AI labs donated something, given all we’ve done for their reputation and their publicity recently. The OpenAI foundation should make unconditional, no strings attached donations to math departments and research institutes as a token of thanks and goodwill.")
]
]
