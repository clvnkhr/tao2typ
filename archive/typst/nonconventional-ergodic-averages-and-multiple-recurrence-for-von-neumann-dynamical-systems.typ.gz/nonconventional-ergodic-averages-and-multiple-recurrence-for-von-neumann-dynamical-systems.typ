// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/12/29/nonconventional-ergodic-averages-and-multiple-recurrence-for-von-neumann-dynamical-systems/
// Converted to Typst by tao2typ: "2026-10-14T15:17:33.939205+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Nonconventional ergodic averages and multiple recurrence for von Neumann dynamical systems", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Nonconventional ergodic averages and multiple recurrence for von Neumann dynamical systems")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 December 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/12/29/nonconventional-ergodic-averages-and-multiple-recurrence-for-von-neumann-dynamical-systems/")[#text("https://terrytao.wordpress.com/2009/12/29/nonconventional-ergodic-averages-and-multiple-recurrence-for-von-neumann-dynamical-systems/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#link("http://www.math.ucla.edu/~timaustin/")[#text("Tim Austin")]#text(", ")#link("http://www.fa.uni-tuebingen.de/members/talo")[#text("Tanja Eisner")]#text(", and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" our joint paper ")#link("http://arxiv.org/abs/0912.5093")[#text("Nonconventional ergodic averages and multiple recurrence for von Neumann dynamical systems")]#text(", submitted to ")#metadata(none) <tao-7adbb4b2426782f3d0e7>#link("http://pjm.berkeley.edu/pjm/about/journal/cover.html")[#text("Pacific Journal of Mathematics")]#text(". This project started with the observation that the multiple recurrence theorem of Furstenberg (and the related multiple convergence theorem of Host and Kra) could be interpreted in the language of dynamical systems of commutative finite von Neumann algebras, which naturally raised the question of the extent to which the results hold in the noncommutative setting. The short answer is “yes for small averages, but not for long ones”.")

#text("The Furstenberg multiple recurrence theorem can be phrased as follows: if ")#mi("{X = (X, {\\mathcal X}, \\mu)}")#text(" is a probability space with a measure-preserving shift ")#mi("{T:X \\rightarrow X}")#text(" (which naturally induces an isomorphism ")#mi("{\\alpha: L^\\infty(X) \\rightarrow L^\\infty(X)}")#text(" by setting ")#mi("{\\alpha a := a \\circ T^{-1}}")#text("), ")#mi("{a \\in L^\\infty(X)}")#text(" is non-negative with positive trace ")#mi("{\\tau(a) := \\int_X a\\ d\\mu}")#text(", and ")#mi("{k \\geq 1}")#text(" is an integer, then one has")

#mi("\\displaystyle  \\liminf_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N \\tau( a (\\alpha^n a) \\ldots (\\alpha^{(k-1)n} a) ) > 0.")

#text("In particular, ")#mi("{\\tau( a (\\alpha^n a) \\ldots (\\alpha^{(k-1)n} a) ) > 0}")#text(" for all ")#mi("{n}")#text(" in a set of positive upper density. This result is famously equivalent to ")#link("http://www.scholarpedia.org/article/Szemer%C3%A9di's_Theorem")[#text("Szemerédi’s theorem")]#text(" on arithmetic progressions.")

#text("The Host-Kra multiple convergence theorem makes the related assertion that if ")#mi("{a_0,\\ldots,a_{k-1} \\in L^\\infty(X)}")#text(", then the scalar averages")

#mi("\\displaystyle  \\frac{1}{N} \\sum_{n=1}^N \\tau( a_0 (\\alpha^n a_1) \\ldots (\\alpha^{(k-1)n} a_{k-1}) )")

#text("converge to a limit as ")#mi("{N \\rightarrow \\infty}")#text("; ")#emph[#text("a fortiori")]#text(", the function averages")

#mi("\\displaystyle  \\frac{1}{N} \\sum_{n=1}^N (\\alpha^n a_1) \\ldots (\\alpha^{(k-1)n} a_{k-1})")

#text("converge in (say) ")#mi("{L^2(X)}")#text(" norm.")

#text("The space ")#mi("{L^\\infty(X)}")#text(" is a commutative example of a ")#link("http://en.wikipedia.org/wiki/Von_Neumann_algebra")[#text("von Neumann algebra")]#text(": an algebra of bounded linear operators on a complex Hilbert space ")#mi("{H}")#text(" which is closed under the weak operator topology, and under taking adjoints. Indeed, one can take ")#mi("{H}")#text(" to be ")#mi("{L^2(X)}")#text(", and identify each element ")#mi("{m}")#text(" of ")#mi("{L^\\infty(X)}")#text(" with the multiplier operator ")#mi("{a \\mapsto ma}")#text(". The operation ")#mi("{\\tau: a \\mapsto \\int_X a\\ d\\mu}")#text(" is then a ")#emph[#text("finite trace")]#text(" for this algebra, i.e. a linear map from the algebra to the scalars ")#mi("{{\\mathbb C}}")#text(" such that ")#mi("{\\tau(ab)=\\tau(ba)}")#text(", ")#mi("{\\tau(a^*) = \\overline{\\tau(a)}}")#text(", and ")#mi("{\\tau(a^* a) \\geq 0}")#text(", with equality iff ")#mi("{a=0}")#text(". The shift ")#mi("{\\alpha: L^\\infty(X) \\rightarrow L^\\infty(X)}")#text(" is then an automorphism of this algebra (preserving shift and conjugation).")

#text("We can generalise this situation to the noncommutative setting. Define a ")#emph[#text("von Neumann dynamical system")]#text(" ")#mi("{(M, \\tau, \\alpha)}")#text(" to be a von Neumann algebra ")#mi("{M}")#text(" with a finite trace ")#mi("{\\tau}")#text(" and an automorphism ")#mi("{\\alpha: M \\rightarrow M}")#text(". In addition to the commutative examples generated by measure-preserving systems, we give three other examples here:")

#list(
[#text("(Matrices) ")#mi("{M = M_n({\\mathbb C})}")#text(" is the algebra of ")#mi("{n \\times n}")#text(" complex matrices, with trace ")#mi("{\\tau(a) = \\frac{1}{n} \\text{tr}(a)}")#text(" and shift ")#mi("{\\alpha(a) := UaU^{-1}}")#text(", where ")#mi("{U}")#text(" is a fixed unitary ")#mi("{n \\times n}")#text(" matrix.")],
[#text("(Group algebras) ")#mi("{M = \\overline{{\\mathbb C} G}}")#text(" is the closure of the ")#emph[#text("group algebra")]#text(" ")#mi("{{\\mathbb C} G}")#text(" of a discrete group ")#mi("{G}")#text(" (i.e. the algebra of finite formal complex combinations of group elements), which acts on the Hilbert space ")#mi("{\\ell^2(G)}")#text(" by convolution (identifying each group element with its Kronecker delta function). A trace is given by ")#mi("{\\alpha(a) = \\langle a \\delta_0, \\delta_0 \\rangle_{\\ell^2(G)}}")#text(", where ")#mi("{\\delta_0 \\in \\ell^2(G)}")#text(" is the Kronecker delta at the identity. Any automorphism ")#mi("{T: G \\rightarrow G}")#text(" of the group induces a shift ")#mi("{\\alpha: M \\rightarrow M}")#text(".")],
[#text("(Noncommutative torus) ")#mi("{M}")#text(" is the von Neumann algebra acting on ")#mi("{L^2(({\\mathbb R}/{\\mathbb Z})^2)}")#text(" generated by the multiplier operator ")#mi("{f(x,y) \\mapsto e^{2\\pi i x} f(x,y)}")#text(" and the shifted multiplier operator ")#mi("{f(x,y) \\mapsto e^{2\\pi i y} f(x+\\alpha,y)}")#text(", where ")#mi("{\\alpha \\in {\\mathbb R}/{\\mathbb Z}}")#text(" is fixed. A trace is given by ")#mi("{\\alpha(a) = \\langle 1, a1\\rangle_{L^2(({\\mathbb R}/{\\mathbb Z})^2)}}")#text(", where ")#mi("{1 \\in L^2(({\\mathbb R}/{\\mathbb Z})^2)}")#text(" is the constant function.")]
)

#text("Inspired by noncommutative generalisations of other results in commutative analysis, one can then ask the following questions, for a fixed ")#mi("{k \\geq 1}")#text(" and for a fixed von Neumann dynamical system ")#mi("{(M,\\tau,\\alpha)}")#text(":")

#list(
[#text("(Recurrence on average) Whenever ")#mi("{a \\in M}")#text(" is non-negative with positive trace, is it true that")#mi("\\displaystyle  \\liminf_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N \\tau( a (\\alpha^n a) \\ldots (\\alpha^{(k-1)n} a) ) > 0?")],
[#text("(Recurrence on a dense set) Whenever ")#mi("{a \\in M}")#text(" is non-negative with positive trace, is it true that")#mi("\\displaystyle  \\tau( a (\\alpha^n a) \\ldots (\\alpha^{(k-1)n} a) ) > 0")#text("for all ")#mi("{n}")#text(" in a set of positive upper density?")],
[#text("(Weak convergence) With ")#mi("{a_0,\\ldots,a_{k-1} \\in M}")#text(", is it true that")#mi("\\displaystyle  \\frac{1}{N} \\sum_{n=1}^N \\tau( a_0 (\\alpha^n a_1) \\ldots (\\alpha^{(k-1)n} a_{k-1}) )")#text("converges?")],
[#text("(Strong convergence) With ")#mi("{a_1,\\ldots,a_{k-1} \\in M}")#text(", is it true that")#mi("\\displaystyle  \\frac{1}{N} \\sum_{n=1}^N (\\alpha^n a_1) \\ldots (\\alpha^{(k-1)n} a_{k-1})")#text("converges in using the Hilbert-Schmidt norm ")#tao-math("{\\left\\|a\\right\\|_{L^2(M)} := \\tau(a^* a)^{1/2}}", block: false)#text("?")]
)

#text("Note that strong convergence automatically implies weak convergence, and recurrence on average automatically implies recurrence on a dense set.")

#text("For ")#mi("{k=1}")#text(", all four questions can trivially be answered “yes”. For ")#mi("{k=2}")#text(", the answer to the above four questions is also “yes”, thanks to the ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("von Neumann ergodic theorem")]#text(" for unitary operators. For ")#mi("{k=3}")#text(", we were able to establish a positive answer to the “recurrence on a dense set”, “weak convergence”, and “strong convergence” results assuming that ")#mi("{M}")#text(" is ergodic. For general ")#mi("{k}")#text(", we have a positive answer to all four questions under the assumption that ")#mi("{M}")#text(" is ")#emph[#text("asymptotically abelian")]#text(", which roughly speaking means that the commutators ")#mi("{[a,\\alpha^n b]}")#text(" converges to zero (in an appropriate weak sense) as ")#mi("{n \\rightarrow \\infty}")#text(". Both of these proofs adapt the usual ergodic theory arguments; the latter result generalises some earlier work of Niculescu-Stroh-Zsido, Duvenhage, and Beyers-Duvenhage-Stroh. For the ")#mi("{k=3}")#text(" result, a key observation is that the van der Corput lemma can be used to control triple averages without requiring any commutativity; the “generalised von Neumann” trick of using multiple applications of the van der Corput trick to control higher averages, however, relies much more strongly on commutativity.")

#text("In most other situations we have counterexamples to all of these questions. In particular:")

#list(
[#text("For ")#mi("{k=3}")#text(", recurrence on average can fail on an ergodic system; indeed, one can even make the average ")#emph[#text("negative")]#text(". This example is ultimately based on a Behrend example construction and a von Neumann algebra construction known as the ")#emph[#text("crossed product")]#text(".")],
[#text("For ")#mi("{k=3}")#text(", recurrence on a dense set can also fail if the ergodicity hypothesis is dropped. This also uses the Behrend example and the crossed product construction.")],
[#text("For ")#mi("{k=4}")#text(", weak and strong convergence can fail even assuming ergodicity. This uses a group theoretic construction, which amusingly was inspired by Grothendieck’s interpretation of a group as a sheaf of flat connections, which I ")#link("https://terrytao.wordpress.com/2009/10/19/grothendiecks-definition-of-a-group/")[#text("blogged about recently")]#text(", and which I will discuss below the fold.")],
[#text("For ")#mi("{k=5}")#text(", recurrence on a dense set fails even with the ergodicity hypothesis. This uses a fancier version of the Behrend example due to Ruzsa in this paper of Bergelson, Host, and Kra. This example only applies for ")#mi("{k \\geq 5}")#text("; we do not know for ")#mi("{k=4}")#text(" whether recurrence on a dense set holds for ergodic systems.")]
)

#metadata(none) <tao-a57ca66b0b5d92e6b7ed>

#strong[#text(" — 1. A group theory construction — ")]

#text("The noncommutative recurrence behaviour (or lack thereof) can be clarified by considering a group algebra closure ")#mi("{M = \\overline{{\\mathbb C} G}}")#text(", with shift ")#mi("{\\alpha}")#text(" induced by an automorphism ")#mi("{T}")#text(" on ")#mi("{G}")#text(". Ergodicity can then be shown to be equivalent to the lack of periodic orbits for ")#mi("{T}")#text(" (i.e. fixed points for ")#mi("{T^n}")#text(" for some non-zero ")#mi("{T}")#text(") other than at the identity.")

#text("If we set ")#mi("{f_0,\\ldots,f_{k-1}}")#text(" to be group elements ")#mi("{e_0,\\ldots,e_{k-1} \\in G}")#text(", a short calculation shows that ")#mi("{\\tau( f_0 \\alpha^n f_1 \\ldots \\alpha^{(k-1)n} f_{k-1} )}")#text(" vanishes unless ")#metadata(none) <tao-92f40c7b79462175e56b>



#text("in which case the trace is equal to ")#mi("{1}")#text(". Let ")#mi("{E_n}")#text(" be the assertion that ")#link(<tao-92f40c7b79462175e56b>)[#text("(1)")]#text(" holds for a given value of ")#mi("{n}")#text(". In order to obtain any nontrivial convergence result for this system, there must exist constraints between the truth values of ")#mi("{E_n}")#text(" for various ")#mi("{n}")#text(".")

#text("Let’s see how this plays out for small values of ")#mi("{k}")#text(". The ")#mi("{k=1}")#text(" case is utterly trivial: ")#mi("{E_n}")#text(" is either always true (if ")#mi("{e_0=1}")#text(") or always false. Next, we turn to ")#mi("{k=2}")#text(". If ")#mi("{e_1}")#text(" generates a periodic orbit of ")#mi("{T}")#text(", then ")#mi("{E_n}")#text(" is periodically true, otherwise it is true at most once. In particular, in the ergodic case, if ")#mi("{e_1}")#text(" is not the identity, then ")#mi("{E_n}")#text(" is true at most once.")

#text("Next, we consider ")#mi("{k=3}")#text(". Suppose that ")#link(<tao-92f40c7b79462175e56b>)[#text("(1)")]#text(" is true for a set of ")#mi("{n}")#text(" of positive upper density. Then there exists a shift ")#mi("{h}")#text(" such that ")#mi("{E_n, E_{n+h}}")#text(" are simultaneously true for infinitely many ")#mi("{n}")#text(". Applying ")#link(<tao-92f40c7b79462175e56b>)[#text("(1)")]#text(" for both ")#mi("{n}")#text(" and ")#mi("{n+h}")#text(" and rearranging, we eventually arrive at")

#mi("\\displaystyle  (e_1)^{-1} T^h e_1 = T^n [ (T^{2h} e_2^{-1}) e_2 ].")

#text("(This rearrangement is the group-theoretic analogue of the van der Corput lemma.)")

#text("Let us now assume ergodicity. Then the only way the above identity can hold for infinitely many ")#mi("{n}")#text(" is if ")#mi("{(e_1)^{-1} T^h e_1}")#text(" and ")#mi("{(T^{2h} e_2^{-1}) e_2}")#text(" are equal to the identity, which by another application of ergodicity shows that ")#mi("{e_1,e_2}")#text(" are both the identity. Plugging this back into ")#link(<tao-92f40c7b79462175e56b>)[#text("(1)")]#text(" this shows that ")#mi("{E_n}")#text(" is true for every ")#mi("{n}")#text(". This may give a hint as to why we can recover the convergence theory in the ")#mi("{k=3}")#text(" ergodic case, though we were not able to decide what happens to this theory in the ")#mi("{k=3}")#text(" non-ergodic case.")

#text("When ")#mi("{k=4}")#text(", one can repeat the above van der Corput-like arguments when ")#mi("{G}")#text(" is abelian, but for non-abelian ")#mi("{G}")#text(" the identities ")#link(<tao-92f40c7b79462175e56b>)[#text("(1)")]#text(" refuse to simplify beyond a certain point. And indeed, we were able to show that the identities ")#mi("{E_n}")#text(" were completely logically independent of each other even assuming ergodicity, in the sense that given any set ")#mi("{A}")#text(" of integers, one can find a group ")#mi("{G}")#text(" and an automorphism ")#mi("{T}")#text(" with no non-trivial periodic orbits, for which ")#mi("{E_n}")#text(" holds if and only if ")#mi("{n}")#text(" lies in ")#mi("{A}")#text(". In particular this shows that there is no convergence theorem for ")#mi("{k=4}")#text(" even in the ergodic setting.")

#text("To establish the independence, the main task is to explicitly identify the group generated by four elements ")#mi("{e_0,\\ldots,e_3}")#text(" and their formal shifts under ")#mi("{\\alpha}")#text(", subject to a set of relations of the form ")#mi("{E_n}")#text(" (together with their shifts); if one can show that the relations which were not in this set were not obeyed by this group, we would be done.")

#text("Here, we found it useful to identify a group with its sheaf of flat connections on the two-dimensional lattice ")#mi("{{\\mathbb Z}^2}")#text(". Each relation ")#link(<tao-92f40c7b79462175e56b>)[#text("(1)")]#text(" can be viewed as identifying a type of flat connection on a unit square of this lattice. Gluing together these squares, one can form maximal flat connections, and these objects can be used to describe the group.")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ec2f78ceb57d9bd64b34cc4b78429f1c5eac54c83816135c602986374a75021-e038760ba298b6b7b263cacae9f591e1977f4216ef31f5659d7913e113c583d0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Leopardi")]], [#link("https://terrytao.wordpress.com/2009/12/29/nonconventional-ergodic-averages-and-multiple-recurrence-for-von-neumann-dynamical-systems/#comment-43007")[#strong[#text("Paul Leopardi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2009")])]

#text("Hi Terry,")#linebreak()#text(" Thanks for the post. In the examples of Neumann algebras, do you need to define the adjoint, or is it always obvious, e.g. complex conjugate for ")#mi("L^{\\infty}")#text(", Hermitian adjoint for ")#mi("M_n(\\mathbb{C}), x \\in X")#text("? I’ll take a look at two more examples: (1) with M as a finite dimensional real Clifford algebra, using Clifford conjugation for the adjoint, taking the real part of a multivector for the trace, an an inner automorphism for the shift; (2) with M as the Clifford-valued functions on a (spin) symmetric space X of a finite dimensional Lie group G, with the Clifford algebra based on the tangent space TX. The corresponding Hilbert space would be (real) ")#mi("L^2(X)")#text(". In this case, I’m not sure what the adjoint and trace should be, but the shift could be")#linebreak()#text(" ")#mi("x \\rightarrow gx")#text(" for ")#mi("g \\in G")#text(" and ")#mi("x \\in X")#text(".")

#text("Also, a simple example for the symmetric space might be the finite dimensional sphere ")#mi("\\mathbb{S}^{n-1} \\subset \\mathbb{R}^n")#text(" with G being an orthogonal group or a spin group.")

#text("Best, Paul")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/12/29/nonconventional-ergodic-averages-and-multiple-recurrence-for-von-neumann-dynamical-systems/#comment-43015")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2009")])]

#text("Well, the way I have defined von Neumann algebras here, elements of such algebras are identified with bounded linear transformations on a Hilbert space H, and so the adjoint operation is given by the usual adjoint for such transformations. Of course, if one were to define von Neumann algebras more abstractly, one would have to specify the adjoint operation explicitly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2009/12/29/nonconventional-ergodic-averages-and-multiple-recurrence-for-von-neumann-dynamical-systems/#comment-43014")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2009")])]

#text("Hi Terry,")#linebreak()#text(" Your post seems to stop abruptly. Perhaps the last half sentence is a typo, rather than being cut-off? ” the group.")

#text("or equivalently that $”")

#text("Happy new year,")#linebreak()#text(" Andres")

#emph[#text("[Corrected, thanks. -T]")]#emph[#linebreak()#text(" ")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/032a5d148624d93070a005a38eea318b012ec736fca0469f9748d898469534db-822c0a1e2169bf75e28d5bf33d3e442d6e70ab99bb00f46fd5742c785f76afbc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rose")]], [#link("https://terrytao.wordpress.com/2009/12/29/nonconventional-ergodic-averages-and-multiple-recurrence-for-von-neumann-dynamical-systems/#comment-43026")[#strong[#text("Rose")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2010")])]

#text("happy new year!!~")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]], [#link("https://terrytao.wordpress.com/2009/12/29/nonconventional-ergodic-averages-and-multiple-recurrence-for-von-neumann-dynamical-systems/#comment-185896")[#strong[#text("Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2012")])]

#text("[…] It is easy to see that this theorem generalises Theorem 3. Conversely, one can use the commutative Gelfand-Naimark theorem to deduce Theorem 4 from Theorem 3, although we will not need this implication. Note how we are abandoning all attempts to discern what the limit of the sequence actually is, instead contenting ourselves with demonstrating that it is merely a Cauchy sequence. With this phrasing, it is tempting to ask whether there is any analogue of Walsh’s theorem for noncommutative probability spaces, but unfortunately the answer to that question is negative for all but the simplest of averages, as was worked out in this paper of Austin, Eisner, and myself. […]")
]
