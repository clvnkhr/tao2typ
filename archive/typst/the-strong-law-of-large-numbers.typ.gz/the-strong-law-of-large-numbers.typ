// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/
// Converted to Typst by tao2typ: "2026-10-14T16:34:50.299754+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The strong law of large numbers", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The strong law of large numbers")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 June 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/")[#text("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let X be a real-valued random variable, and let ")#mi("X_1, X_2, X_3, ...")#text(" be an infinite sequence of ")#link("http://en.wikipedia.org/wiki/Independent_and_identically-distributed_random_variables")[#text("independent and identically distributed copies")]#text(" of X. Let ")#mi("\\overline{X}_n := \\frac{1}{n}(X_1 + \\ldots + X_n)")#text(" be the empirical averages of this sequence. A fundamental theorem in probability theory is the ")#link("http://en.wikipedia.org/wiki/Law_of_large_numbers")[#text("law of large numbers")]#text(", which comes in both a weak and a strong form:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Weak law of large numbers. ")]#text(" Suppose that the first ")#link("http://en.wikipedia.org/wiki/Moment_%28mathematics%29")[#text("moment")]#text(" ")#tao-math("{\\Bbb E} \\left|X\\right|", block: false)#text(" of X is finite. Then ")#mi("\\overline{X}_n")#text(" ")#link("http://en.wikipedia.org/wiki/Convergence_of_random_variables#Convergence_in_probability")[#text("converges in probability")]#text(" to ")#mi("{\\Bbb E} X")#text(", thus ")#tao-math("\\lim_{n \\to \\infty} {\\Bbb P}( \\left|\\overline{X}_n - {\\Bbb E} X\\right| \\geq \\varepsilon ) = 0", block: false)#text(" for every ")#mi("\\varepsilon > 0")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Strong law of large numbers.")]#text(" Suppose that the first moment ")#tao-math("{\\Bbb E} \\left|X\\right|", block: false)#text(" of X is finite. Then ")#mi("\\overline{X}_n")#text(" converges ")#link("http://en.wikipedia.org/wiki/Almost_surely")[#text("almost surely")]#text(" to ")#mi("{\\Bbb E} X")#text(", thus ")#mi("{\\Bbb P}( \\lim_{n \\to \\infty} \\overline{X}_n = {\\Bbb E} X ) = 1")#text(".")
]

#text("[The concepts of convergence in probability and almost sure convergence in probability theory are specialisations of the concepts of ")#link("http://en.wikipedia.org/wiki/Convergence_in_measure")[#text("convergence in measure")]#text(" and ")#link("http://en.wikipedia.org/wiki/Pointwise_convergence#In_measure_theory")[#text("pointwise convergence almost everywhere")]#text(" in measure theory.]")

#text("(If one strengthens the first moment assumption to that of finiteness of the second moment ")#tao-math("{\\Bbb E}\\left|X\\right|^2", block: false)#text(", then we of course have a more precise statement than the (weak) law of large numbers, namely the ")#link("http://en.wikipedia.org/wiki/Central_limit_theorem")[#text("central limit theorem")]#text(", but I will not discuss that theorem here. With even more hypotheses on X, one similarly has more precise versions of the strong law of large numbers, such as the ")#link("http://en.wikipedia.org/wiki/Chernoff%27s_inequality")[#text("Chernoff inequality")]#text(", which I will again not discuss here.)")

#text("The weak law is easy to prove, but the strong law (which of course implies the weak law, by ")#link("http://en.wikipedia.org/wiki/Egorov%27s_theorem")[#text("Egoroff’s theorem")]#text(") is more subtle, and in fact the proof of this law (assuming just finiteness of the first moment) usually only appears in advanced graduate texts. So I thought I would present a proof here of both laws, which proceeds by the standard techniques of the moment method and truncation. The emphasis in this exposition will be on motivation and methods rather than brevity and strength of results; there do exist proofs of the strong law in the literature that have been compressed down to the size of one page or less, but this is not my goal here.")

#metadata(none) <tao-a2fffba8cf0637fd7fc4>

#heading(level: 1)[#text("— The moment method —")]

#text("The moment method seeks to control the tail probabilities of a random variable (i.e. the probability that it fluctuates far from its mean) by means of moments, and in particular the zeroth, first or second moment. The reason that this method is so effective is because the first few moments can often be computed rather precisely. The first moment method usually employs ")#link("http://en.wikipedia.org/wiki/Markov%27s_inequality")[#text("Markov’s inequality")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("{\\Bbb P}( \\left|X\\right| \\geq \\lambda ) \\leq \\frac{1}{\\lambda} {\\Bbb E} \\left|X\\right|", block: true)]]

#text("(which follows by taking expectations of the pointwise inequality ")#tao-math("\\lambda I(\\left|X\\right| \\geq \\lambda) \\leq \\left|X\\right|", block: false)#text("), whereas the second moment method employs some version of ")#link("http://en.wikipedia.org/wiki/Chebyshev%27s_inequality")[#text("Chebyshev’s inequality")]#text(", such as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("{\\Bbb P}( \\left|X\\right| \\geq \\lambda ) \\leq \\frac{1}{\\lambda^2} {\\Bbb E} \\left|X\\right|^2", block: true)]]

#text("(note that (2) is just (1) applied to the random variable ")#tao-math("\\left|X\\right|^2", block: false)#text(" and to the threshold ")#mi("\\lambda^2")#text(").")

#text("Generally speaking, to compute the first moment one usually employs ")#link("http://en.wikipedia.org/wiki/Expected_value#Linearity")[#text("linearity of expectation")]

#align(center)[#mi("\\displaystyle {\\Bbb E} X_1 + \\ldots + X_n = {\\Bbb E} X_1 + \\ldots + {\\Bbb E} X_n")#text(",")]

#text("whereas to compute the second moment one also needs to understand ")#link("http://en.wikipedia.org/wiki/Covariance")[#text("covariances")]#text(" (which are particularly simple if one assumes ")#link("http://en.wikipedia.org/wiki/Pairwise_independence")[#text("pairwise independence")]#text("), thanks to identities such as")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E} (X_1 + \\ldots + X_n)^2 = {\\Bbb E} X_1^2 + \\ldots + {\\Bbb E} X_n^2 + 2 \\sum_{1 \\leq i < j \\leq n} X_i X_j")]]

#text("or the normalised variant")

#tao-aligned(keep: true)[


#tao-math("{\\bf Var}(X_1+\\ldots+X_n)  & = {\\bf Var}(X_1) + \\ldots + {\\bf Var}(X_n)", block: true)



#tao-math(" & + 2 \\sum_{1 \\leq i < j \\leq n} {\\bf Cov}(X_i,X_j).", block: true, numbering: n => [#text("(3)")])
]

#text("Higher moments can in principle give more precise information, but often require stronger assumptions on the objects being studied, such as ")#link("http://en.wikipedia.org/wiki/Statistical_independence")[#text("joint independence")]#text(".")

#text("Here is a basic application of the first moment method:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#link("http://en.wikipedia.org/wiki/Borel-Cantelli_lemma")[#text("Borel-Cantelli lemma.")]#text(" ")]#text(" Let ")#mi("E_1, E_2, E_3, \\ldots")#text(" be a sequence of events such that ")#mi("\\sum_{n=1}^\\infty {\\Bbb P}(E_n)")#text(" is finite. Then almost surely, only finitely many of the events ")#mi("E_n")#text(" are true.")
]

#strong[#text("Proof.")]#text(" Let ")#mi("I(E_n)")#text(" denote the indicator function of the event ")#mi("E_n")#text(". Our task is to show that ")#mi("\\sum_{n=1}^\\infty I(E_n)")#text(" is almost surely finite. But by linearity of expectation, the expectation of this random variable is ")#mi("\\sum_{n=1}^\\infty {\\Bbb P}(E_n)")#text(", which is finite by hypothesis. By Markov’s inequality (1) we conclude that")

#align(center)[#mi("\\displaystyle {\\Bbb P}( \\sum_{n=1}^\\infty I(E_n) \\geq \\lambda ) \\leq \\frac{1}{\\lambda} \\sum_{n=1}^\\infty {\\Bbb P}(E_n)")#text(".")]

#text("Letting ")#mi("\\lambda \\to \\infty")#text(" we obtain the claim. ")#mi("\\Box")

#text("Returning to the law of large numbers, the first moment method gives the following tail bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" (First moment tail bound) If ")#tao-math("{\\Bbb E}\\left|X\\right|", block: false)#text(" is finite, then")

#align(center)[#tao-math("\\displaystyle {\\Bbb P}( \\left|\\overline{X}_n\\right| \\geq \\lambda ) \\leq \\frac{{\\Bbb E}\\left|X\\right|}{\\lambda}", block: false)#text(".")]
]

#strong[#text("Proof.")]#text(" By the triangle inequality, ")#tao-math("\\left|\\overline{X}_n\\right| \\leq \\overline{\\left|X\\right|}_n", block: false)#text(". By linearity of expectation, the expectation of ")#tao-math("\\overline{\\left|X\\right|}_n", block: false)#text(" is ")#tao-math("{\\Bbb E}\\left|X\\right|", block: false)#text(". The claim now follows from Markov’s inequality. ")#mi("\\Box")

#text("Lemma 1 is not strong enough by itself to prove the law of large numbers in either weak or strong form – in particular, it does not show any improvement as n gets large – but it will be useful to handle one of the error terms in those proofs.")

#text("We can get stronger bounds than Lemma 1 – in particular, bounds which improve with n – at the expense of stronger assumptions on X.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2.")]#text(" (Second moment tail bound) If ")#tao-math("{\\Bbb E}\\left|X\\right|^2", block: false)#text(" is finite, then")

#align(center)[#tao-math("\\displaystyle {\\Bbb P}( \\left|\\overline{X}_n - {\\Bbb E}(X)\\right| \\geq \\lambda ) \\leq \\frac{ {\\Bbb E}\\left|X - {\\Bbb E}(X)\\right|^2 }{n \\lambda^2}", block: false)#text(".")]
]

#strong[#text("Proof.")]#text(" A standard computation, exploiting (3) and the pairwise independence of the ")#mi("X_i")#text(", shows that the ")#link("http://en.wikipedia.org/wiki/Variance")[#text("variance")]#text(" ")#tao-math("{\\Bbb E} \\left|\\overline{X}_n - {\\Bbb E}(X)\\right|^2", block: false)#text(" of the empirical averages ")#mi("\\overline{X}_n")#text(" is equal to ")#mi("\\frac{1}{n}")#text(" times the variance ")#tao-math("{\\Bbb E} \\left|X - {\\Bbb E}(X)\\right|^2", block: false)#text(" of the original variable X. The claim now follows from Chebyshev’s inequality (2). ")#mi("\\Box")

#text("In the opposite direction, there is the ")#emph[#text("zeroth moment method")]#text(", more commonly known as the ")#link("http://en.wikipedia.org/wiki/Boole's_inequality")[#text("union bound")]

#align(center)[#tao-fit-display[#mitex("{\\Bbb P}( E_1 \\vee \\ldots \\vee E_n ) \\leq \\sum_{j=1}^n {\\Bbb P}(E_j)")]]

#text("or equivalently (to explain the terminology “zeroth moment”)")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E} (X_1 + \\ldots + X_n)^0 \\leq {\\Bbb E} X_1^0 + \\ldots + X_n^0")]]

#text("for any non-negative random variables ")#mi("X_1,\\ldots,X_n \\geq 0")#text(". Applying this to the empirical means, we obtain the ")#emph[#text("zeroth moment tail estimate")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("{\\Bbb P} (\\overline{X}_n \\neq 0) \\leq n {\\Bbb P}(X \\neq 0).")]]

#text("Just as the second moment bound (Lemma 2) is only useful when one has good control on the second moment (or variance) of X, the zeroth moment tail estimate (3) is only useful when we have good control on the zeroth moment ")#tao-math("{\\Bbb E} \\left|X\\right|^0 = {\\Bbb P}(X \\neq 0)", block: false)#text(", i.e. when X is mostly zero.")

#heading(level: 1)[#text("— Truncation —")]

#text("The second moment tail bound (Lemma 2) already gives the weak law of large numbers in the case when X has finite second moment (or equivalently, finite variance). In general, if all one knows about X is that it has finite first moment, then we cannot conclude that X has finite second moment. However, we can perform a truncation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("X = X_{\\leq N} + X_{>N}")]]

#text("of X at any desired threshold N, where ")#tao-math("X_{\\leq N} := X I(\\left|X\\right| \\leq N)", block: false)#text(" and ")#tao-math("X_{>N} := X I(\\left|X\\right| > N)", block: false)#text(". The first term ")#mi("X_{\\leq N}")#text(" has finite second moment; indeed we clearly have")

#align(center)[#tao-fit-display[#tao-math("{\\Bbb E} \\left|X_{\\leq N}\\right|^2 \\leq N {\\Bbb E} \\left|X\\right|", block: true)]]

#text("and hence also we have finite variance")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("{\\Bbb E} \\left|X_{\\leq N} - {\\Bbb E} X_{\\leq N}\\right|^2 \\leq N {\\Bbb E} |X|.", block: true)]]

#text("The second term ")#mi("X_{>N}")#text(" may have infinite second moment, but its first moment is well controlled. Indeed, by the ")#link("http://en.wikipedia.org/wiki/Monotone_convergence_theorem")[#text("monotone convergence theorem")]#text(", we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("{\\Bbb E} \\left|X_{>N}\\right| \\to 0 \\text{ as } N \\to \\infty.", block: true)]]

#text("By the triangle inequality, we conclude that the first term ")#mi("X_{\\leq N}")#text(" has expectation close to ")#mi("{\\Bbb E} X")#text(":")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("{\\Bbb E} X_{\\leq N} \\to {\\Bbb E}(X) \\text{ as } N \\to \\infty.")]]

#text("These are all the tools we need to prove the weak law of large numbers:")

#strong[#text("Proof of weak law. ")]#text(" Let ")#mi("\\varepsilon > 0")#text(". It suffices to show that whenever n is sufficiently large depending on ")#mi("\\varepsilon")#text(", that ")#mi("\\overline{X}_n = {\\Bbb E} X + O(\\varepsilon)")#text(" with probability ")#mi("1-O(\\varepsilon)")#text(".")

#text("From (7), (8), we can find a threshold N (depending on ")#mi("\\varepsilon")#text(") such that ")#tao-math("{\\Bbb E} \\left|X_{\\geq N}\\right| = O(\\varepsilon^2)", block: false)#text(" and ")#mi("{\\Bbb E} X_{<N} = {\\Bbb E} X + O(\\varepsilon)")#text(". Now we use (5) to split")

#align(center)[#mi("\\displaystyle \\overline{X}_n = (\\overline{X_{\\geq N}})_n +(\\overline{X_{< N}})_n")#text(".")]

#text("From the first moment tail bound (Lemma 1), we know that ")#mi("(\\overline{X_{\\geq N}})_n = O(\\varepsilon)")#text(" with probability ")#mi("1 - O(\\varepsilon)")#text(". From the second moment tail bound (Lemma 2) and (6), we know that ")#mi("(\\overline{X_{< N}})_n = {\\Bbb E} X_{<N} + O(\\varepsilon) = {\\Bbb E} X + O(\\varepsilon)")#text(" with probability ")#mi("1-O(\\varepsilon)")#text(" if n is sufficiently large depending on N and ")#mi("\\varepsilon")#text(". The claim follows. ")#mi("\\Box")

#heading(level: 1)[#text("— The strong law —")]

#text("The strong law can be proven by pushing the above methods a bit further, and using a few more tricks.")

#text("The first trick is to observe that to prove the strong law, it suffices to do so for non-negative random variables ")#mi("X \\geq 0")#text(". Indeed, this follows immediately from the simple fact that any random variable X with finite first moment can be expressed as the difference of two non-negative random variables ")#mi("\\max(X,0), \\max(-X,0)")#text(" of finite first moment.")

#text("Once X is non-negative, we see that the empirical averages ")#mi("\\overline{X}_n")#text(" cannot decrease too quickly in n. In particular we observe that")

#align(center)[#mi("\\displaystyle \\overline{X}_m \\leq (1+O(\\varepsilon)) \\overline{X}_n")#text(" whenever ")#mi("(1-\\varepsilon) n \\leq m \\leq n")#text(". (9)")]

#text("Because of this quasimonotonicity, we can sparsify the set of n for which we need to prove the strong law. More precisely, it suffices to show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Strong law of large numbers, reduced version.")]#text(" Let ")#mi("X")#text(" be a non-negative random variable with ")#mi("{\\Bbb E} X < \\infty")#text(", and let ")#mi("1 \\leq n_1\\leq n_2\\leq n_3\\leq\\ldots")#text(" be a sequence of integers which is ")#emph[#text("lacunary")]#text(" in the sense that ")#mi("n_{j+1}/n_j > c")#text(" for some ")#mi("c>1")#text(" and all sufficiently large j. Then ")#mi("\\overline{X}_{n_j}")#text(" converges almost surely to ")#mi("{\\Bbb E} X")#text(".")
]

#text("Indeed, if we could prove the reduced version, then on applying that version to the lacunary sequence ")#mi("n_j := \\lfloor (1 + \\varepsilon)^j\\rfloor")#text(" and using (9) we would see that almost surely the empirical means ")#mi("\\overline{X}_n")#text(" cannot deviate by more than a multiplicative error of ")#mi("1+O(\\varepsilon)")#text(" from the mean ")#mi("{\\Bbb E} X")#text(". Setting ")#mi("\\varepsilon := 1/m")#text(" for ")#mi("m=1,2,3,\\ldots")#text(" (and using the fact that a countable intersection of almost sure events remains almost sure) we obtain the full strong law.")

#text("[This sparsification trick is philosophically related to the dyadic pigeonhole principle philosophy; see an ")#link("http://www.math.ucla.edu/~tao/preprints/Expository/pigeonhole.dvi")[#text("old short story of myself")]#text(" on this latter topic. One could easily sparsify further, so that the lacunarity constant c is large instead of small, but this turns out not to help us too much in what follows.]")

#text("Now that we have sparsified the sequence, it becomes economical to apply the Borel-Cantelli lemma. Indeed, by many applications of that lemma we see that it suffices to show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\sum_{j=1}^\\infty {\\Bbb P}( \\overline{X}_{n_j} \\neq {\\Bbb E}(X) + O( \\varepsilon ) ) < \\infty")]]

#text("for non-negative X of finite first moment, any lacunary sequence ")#mi("1 \\leq n_1 \\leq n_2 \\leq \\ldots")#text(" and any ")#mi("\\varepsilon > 0")#text(". [This is a slight abuse of the O() notation, but it should be clear what is meant by this.]")

#text("[If we did not first sparsify the sequence, the Borel-Cantelli lemma would have been too expensive to apply; see Remark 2 below. Generally speaking, Borel-Cantelli is only worth applying when one expects the events ")#mi("E_n")#text(" to be fairly “disjoint” or “independent” of each other; in the non-lacunary case, the events ")#mi("E_n")#text(" change very slowly in n, which makes the lemma very inefficient. We will not see how lacunarity is exploited until the punchline at the very end of the proof, but certainly there is no harm in taking advantage of this “free” reduction to the lacunary case now, even if it is not immediately clear how it will be exploited.]")

#text("At this point we go back and apply the methods that already worked to give the weak law. Namely, to estimate each of the tail probabilities ")#mi("{\\Bbb P}( \\overline{X}_{n_j} \\neq {\\Bbb E}(X) + O(\\varepsilon) )")#text(", we perform a truncation (5) at some threshold ")#mi("N_j")#text(". It is not immediately obvious what truncation to perform, so we adopt the usual strategy of leaving ")#mi("N_j")#text(" unspecified for now and optimising in this parameter later.")

#text("We should at least pick ")#mi("N_j")#text(" large enough so that ")#mi("{\\Bbb E} X_{< N_j} = {\\Bbb E} X + O(\\varepsilon)")#text(". From the second moment tail estimate (Lemma 2) we conclude that ")#mi("(\\overline{X_{< N_j}})_{n_j}")#text(" is also equal to ")#mi("{\\Bbb E} X + O( \\varepsilon )")#text(" with probability ")#tao-math("1-O( \\frac{1}{\\varepsilon n_j} {\\Bbb E} \\left|X_{\\leq N_j}\\right|^2 )", block: false)#text(". One could attempt to simplify this expression using (6), but this turns out to be a little wasteful, so let us hold off on that for now. However, (6) does strongly suggest that we want to take ")#mi("N_j")#text(" to be something like ")#mi("n_j")#text(", which is worth keeping in mind in what follows.")

#text("Now we look at the contribution of ")#mi("X_{\\geq N_j}")#text(". One could use the first moment tail estimate (Lemma 1), but it turns out that the first moment ")#mi("{\\Bbb E} X_{> N_j}")#text(" decays too slowly in j to be of much use (recall that we are expecting ")#mi("N_j")#text(" to be like the lacunary sequence ")#mi("n_j")#text("); the root problem here is that the decay (7) coming from the monotone convergence theorem is ")#emph[#text("ineffective ")]#text("(one could effectivise this using the ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("finite convergence principle")]#text(", but this turns out to give very poor results here).")

#text("But there is one last card to play, which is the zeroth moment method tail estimate (4). As mentioned earlier, this bound is lousy in general – but is very good when X is mostly zero, which is precisely the situation with ")#mi("X_{>N_j}")#text(". and in particular we see that ")#mi("(\\overline{X_{>N_j}})_{n_j}")#text(" is zero with probability ")#mi("1 - O( n_j {\\Bbb P}(X > N_j) )")#text(".")

#text("Putting this all together, we see that")

#align(center)[#tao-fit-display[#tao-math("{\\Bbb P}( \\overline{X}_{n_j} \\neq {\\Bbb E}(X) + O( \\varepsilon ) ) \\leq O( \\frac{1}{\\varepsilon n_j} {\\Bbb E} \\left|X_{\\leq N_j}\\right|^2 ) + O( n_j {\\Bbb P}(X > N_j) ).", block: true)]]

#text("Summing this in j, we see that we will be done as soon as we figure out how to choose ")#mi("N_j")#text(" so that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\sum_{j=1}^\\infty \\frac{1}{n_j} {\\Bbb E} \\left|X_{\\leq N_j}\\right|^2", block: true)]]

#text("and")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\sum_{j=1}^\\infty n_j {\\Bbb P}(X > N_j)")]]

#text("are both finite. (As usual, we have a tradeoff: making the ")#mi("N_j")#text(" larger makes (12) easier to establish at the expense of (11), and vice versa when making ")#mi("N_j")#text(" smaller.)")

#text("Based on the discussion earlier, it is natural to try setting ")#mi("N_j := n_j")#text(". Happily, this choice works cleanly; the lacunary nature of ")#mi("n_j")#text(" ensures (basically from the ")#link("http://en.wikipedia.org/wiki/Geometric_series")[#text("geometric series")]#text(" formula) that we have the pointwise estimates")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^\\infty \\frac{1}{n_j} \\left|X_{\\leq n_j}\\right|^2 = O( X )", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^\\infty n_j I( X \\geq n_j ) = O( X )")]]

#text("(where the implied constant here depends on the sequence ")#mi("n_1, n_2, \\ldots")#text(", and in particular on the lacunarity constant c). The claims (10), (11) then follow from one last application of linearity of expectation, giving the strong law of large numbers.")

#strong[#text("Remark 1.")]#text(" The above proof in fact shows that the strong law of large numbers holds even if one only assumes pairwise independence of the ")#mi("X_n")#text(", rather than joint independence. ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" It is essential that the random variables ")#mi("X_1,X_2,\\ldots")#text(" are “recycled” from one empirical average ")#mi("\\overline{X}_n")#text(" to the next, in order to get the crucial quasimonotonicity property (9). If instead we took completely independent averages ")#mi("\\overline{X}_n = \\frac{1}{n} (X_{n,1} + \\ldots + X_{n,n} )")#text(", where the ")#mi("X_{i,j}")#text(" are all iid, then the strong law of large numbers in fact breaks down with just a first moment assumption. (For a counterexample, consider a random variable X which equals ")#mi("2^m / m^2")#text(" with probability ")#mi("2^{-m}")#text(" for ")#mi("m=1,2,3,\\ldots")#text("; this random variable (barely) has finite first moment, but for ")#mi("n \\sim 2^m/m^2")#text(", we see that ")#mi("\\overline{X}_n")#text(" deviates by at least absolute constant from its mean with probability ")#mi("\\gg 1/m^2")#text(". As the empirical means ")#mi("\\overline{X}_n")#text(" for ")#mi("n \\sim 2^m/m^2")#text(" are now jointly independent, the probability that one of them deviates significantly is now extremely close to 1 (super-exponentially close in ")#mi("m")#text(", in fact), leading to the total failure of the strong law in this setting.) Of course, if one restricts attention to a lacunary sequence of n then the above proof goes through in the independent case (since the Borel-Cantelli lemma is insensitive to this independence). By exploiting the joint independence further (e.g. by using ")#link("http://en.wikipedia.org/wiki/Chernoff%27s_inequality")[#text("Chernoff’s inequality")]#text(") one can also get the strong law for independent empirical means for the full sequence n under second moment bounds. ")#mi("\\diamond")

#strong[#text("Remark 3.")]#text(" From the perspective of interpolation theory, one can view the above argument as an interpolation argument, establishing an ")#mi("L^1")#text(" estimate (10) by interpolating between an ")#mi("L^2")#text(" estimate (Lemma 2) and the ")#mi("L^0")#text(" estimate (4). ")#mi("\\diamond")

#strong[#text("Remark 4.")]#text(" By viewing the sequence ")#mi("X_1,X_2,\\ldots")#text(" as a ")#link("http://en.wikipedia.org/wiki/Stationary_process")[#text("stationary process")]#text(", and thus as a special case of a measure-preserving system one can view the weak and strong law of large numbers as special cases of the mean and pointwise ergodic theorems respectively (see Exercise 9 from ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("254A Lecture 8")]#text(" and Theorem 2 from ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("254A Lecture 9")]#text("). ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Jul 19: some corrections.]")

#text("[")#emph[#text("Update")]#text(", Jul 20: Connections with ergodic theory discussed.]")

#heading(level: 1)[#text("Comments (110)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-101470")[#strong[#text("Note on the weak and strong laws of large numbers | Mathematics and me-themed antics.")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2011")]

#text("[…] my development was different from that in the book. My notes essentially follow the proof given by Terry Tao, so you may want to refer to his notes as well. Like this:LikeBe the first to like this post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3cbdebedefe6721daa00281c9a160a2e45e97ad3c720640fb1ee640c9db46ea7-5ae3f0533a6f8efd8c27b82a0d3b34d2c4470bf49fe1af42d3130a83bb89803d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of abc")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-123960")[#strong[#text("abc")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2012")])]

#text("It seems like the proof of the pointwise ergodic theorem is easier than this proof! Inspecting that proof, it uses the the added generality of measure-preserving systems to deal with functions that you could not talk about (naturally) in the setting of the strong law of large numbers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d0787f36ff8adaaae2bf792d89bbd3946b1e7047e133f9a57e68c5c66436b1b-3457e7638e41a7fc17ccffbbb49839d30462270a5143f6b714c8535ead43712f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-215780")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2013")])]

#text("I think this result and proof are very nice. There is a vague commonality between Keane’s and Tao’s proof: both exploit, to an extent, the fact that the sample mean ")#mi("\\bar{X}_n")#text(" varies little, in a sense, with ")#mi("n")#text(". It is also nice that Tao’s result is not contained in the ergodic theorem. Indeed, one can easily see that the pairwise independence does not imply the stationarity. E.g., let ")#mi("X_1,\\dots,X_6")#text(" be defined as ")#mi("R_1, R_2, R_1R_2, R_1R_3, R_2R_3, R_1R_2R_3")#text(", respectively, where the ")#mi("R_i")#text("‘s are independent Rademacher random variables, each taking each of the values ")#mi("1, -1")#text(" with probability 1/2. Define ")#mi("X_7,\\dots,X_{12}")#text(" similarly, based on ")#mi("R_4, R_5, R_6")#text("; etc. Then the ")#mi("X_i")#text("‘s are pairwise independent. However, ")#mi("P(X_1X_2X_3=1)=1")#text(", whereas ")#mi("P(X_4X_5X_6=1)=1/2")#text(". So, the sequence ")#mi("(X_i)")#text(" is not stationary.")

#emph[#text("[LaTeX code corrected; the problem was the lack of a space between “latex” and the LaTeX code. Also, the curly braces were unnecessary. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d0787f36ff8adaaae2bf792d89bbd3946b1e7047e133f9a57e68c5c66436b1b-3457e7638e41a7fc17ccffbbb49839d30462270a5143f6b714c8535ead43712f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iosif Pinelis")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-215916")[#strong[#text("Iosif Pinelis")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2013")])]

#text("Thank you for the help with LaTeX. A couple more points here:")

#text("(i) Of course, I wanted to say “the pairwise independence does not imply the stationarity, even if the ")#mi("X_i")#text("‘s are identically distributed”, rather than just “the pairwise independence does not imply the stationarity”.")

#text("(ii) Tao’s result, with the pairwise independence rather than with the complete independence, can be extended in a standard manner to the case when the ")#mi("X_i")#text("‘s take values in an arbitrary separable Banach space (say).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-219053")[#strong[#text("Laws of large numbers and Birkhoff’s ergodic theorem | Vaughn Climenhaga's Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2013")]

#text("[…] including a different proof of the weak law than the one above, can be found on Terry Tao’s blog), we observe that the strong law of large numbers can be viewed as a special case of the Birkhoff […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mate Wierdl")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-228297")[#strong[#text("Mate Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2013")])]

#text("Hi Terry! Maybe a few exercises could be added based on the following remarks:")

#text("If we assume finite second moment then only “multiplicativity” is needed. By multiplicativity, I mean ")#mi("\\mathbb EX_iX_j=\\mathbb E X_i \\mathbb E X_j")#text(". This translates to orthogonality if the expectations are $\\latex 0$.")

#text("An application would be Weyl’s result: if ")#mi("n_1<n_2<n_3<\\dots")#text(" is a sequence of integers then for almost all ")#mi("\\alpha")#text(", the sequence ")#mi("n_1\\alpha, n_2\\alpha, n_3\\alpha,dots")#text(" is uniformly distributed ")#mi("\\mod 1")#text(". For this, we take ")#mi("X_i=\\exp(2\\pi i n_i \\alpha)")#text(".")

#text("With this mutiplicativity assumption, one can simply get results for random variables with varying expectations: Consider nonnegative random variables with varying expectation, but then we would divide by the expectation of the sum of the first $n$ random variables instead of ")#mi("n")#text(" to get the right normalization. For example, the expectations can go to ")#mi("0")#text(" arbitrary slowly as long as ")#mi("\\sum_i \\mathbb EX_i=\\infty")#text(". But the expectations can also go to ")#mi("\\infty")#text("! They cannot increase arbitrary fast: something like ")#mi("\\mathbb EX_i = O(2^{i^b})")#text(" for ")#mi("b<1/2")#text(" seems to be the limit for a strong law, while for norm (weak) convergence, one can get arbitrary close to ")#mi("2^i")#text(", that is we can have ")#mi("\\mathbb E X_i = 2^{o(i)}")#text(".")

#text("I think these are good exercises for using and testing the limits of this \"lacunary subsequence\" trick.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cd3b5efb5a49b5850e632852fda8cb0025cba2beae39f24de4b28eac25df122-6c2dbea6957b44259d00dee2cf8fbcb2fd3cb66b96f85578c268eaa1dcc8a822.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-247252")[#strong[#text("Paul")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2013")])]

#text("MISSING PARENTHESIS:")#linebreak()#text(" Ex1+,…+xn = E(x1) +…+E(xn)")

#text("should have the parenthesis on the left side of equation thus:")

#text("E(x1+…+xn) = E(x1)+…+E(xn)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-269959")[#strong[#text("Law of large numbers for dependent but uncorrelated random variables | Vaughn Climenhaga's Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2014")]

#text("[…] book “Probability and Measure”, where it is Theorem 22.1. There is also a discussion on Terry Tao’s blog, which emphasises the role of the main tools in this proof: the moment method and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f808e1a75da9b6fa2aab4237310dce6115deac63b4c9f43624e5654df01f6c2a-6356d8fcea24bfb2cfd8eb1db2ddd801d190b70a3bf7d618215392ef62fee97a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tomasz")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-270709")[#strong[#text("Tomasz")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("Could someone provide some reference to a full proof of the “strong law for independent empirical means for the full sequence under second moment bounds” mentioned in Remark 2? Or at least could someone provide a more detailed explanation of the proof outlined in this remark, in particular what Chernoff’s inequality should be used and how?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa79e1713353aee671d4d148791a329c55ef8ec318e0dd5fd7711a0376e58622-05ec82d4546a7a317d157fcb0c0e84599ae36b9f7785fb491bacfd2cd1223ece.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-355033")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2014")])]

#text("Hi Dear Professor Tao.")#linebreak()#text(" I have a question. If you are an infinite number of random variables. You can still use the strong law of large numbers? please more explain for me.")#linebreak()#text(" best regards")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prasenjit Karmakar")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-456358")[#strong[#text("Prasenjit Karmakar")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2015")])]

#text("“Indeed, this follows immediately from the simple fact that any random variable X with finite first moment can be expressed as the difference of two non-negative random variables $\\max(X,0), \\max(-X,0)$ of finite first moment.”")#linebreak()#text(" To express a random variable as the difference of two, I think finite moment is not needed, it is needed when we express expectation as the difference of two.")

#text("Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/195be1e0b619bb9f9a80cd03b29460392ba4f050ee39db9083573f786d98f3e0-d3eab6bc442d832e6c9c81be1d037e1f6475a968205fb3d9710f6bed0b412087.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Law of Large Numbers | Kepler lounge")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-456874")[#strong[#text("Law of Large Numbers | Kepler lounge")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2015")])]

#text("[…] that the sample average converges in probability toward the expected value. There is also a Strong version which I won’t discuss further. But, both versions are of great importance in science as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-463030")[#strong[#text("Possible explanation for a Bell experiment?")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2015")]

#text("[…] be taken as an axiom? The Law Of Large Numbers: ")#link("https://en.wikipedia.org/wiki/Law_of_large_numbers")[#text("https://en.wikipedia.org/wiki/Law_of_large_numbers")]#text(" ")#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/")[#text("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/")]#text(" QM explains what's going on in Bell. Why you want to come up with another I cant quite […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-466053")[#strong[#text("Error : what is n in quantum mechanics | Physics Forums - The Fusion of Science and Community")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2016")]

#text("[…] But as the number of systems in the ensemble tends to infinity the law of large numbers applies: ")#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/")[#text("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/")]#text(" Don't worry about the proof if you don't know the math to follow it. Simply grasp what […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08d50e70e488174d2ccefcee44f2df989013c9d29d1e6e7f1c33dfbb66029b59-1aad71c7f5ca0aba67e6e89dad6d9975d35c06cee58c1afaf4329be79cfbfbd3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Helmholtz: El Origen y Significado de los Axiomas Geométricos (1) | Divergiendo - «Nebar defiqueit mor danguot iuit»")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-470984")[#strong[#text("Helmholtz: El Origen y Significado de los Axiomas Geométricos (1) | Divergiendo - «Nebar defiqueit mor danguot iuit»")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2016")])]

#text("[…] 13. Tao, T. (2008, 18th June). The strong law of large numbers. [Weblog]. Retrieved 17 July 2016, from ")#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/#comment-41939↩")[#text("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/#comment-41939↩")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/202d782a6c674aa1165885d1d44fcd3a3e7b152494211611df5675be7148eb65-e22cc6b6e986a928a5769a8644a8c792914a9da8ee7f8c0fff3f4d82eeffa2c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chaos")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-472926")[#strong[#text("chaos")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2016")])]

#text("Hi prof Tao,")

#text("You wrote: “The concepts of convergence in probability and almost sure convergence in probability theory are specialisations of the concepts of convergence in measure and pointwise convergence almost everywhere in measure theory.”")

#text("In measure theory, is there any different between “pointwise convergence almost everywhere” and “convergence almost everywhere”?")

#emph[#text("[No – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-474320")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2016")])]

#text("You might want to fix (3). The formula flows out.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5cd93d6b7303ce6314e9a619ac896870a543da43a739bbe1a6c52a2b6840638b-fd0544e013ab86f7b83432524b9aa6fbff61ad1dc7caa54847a112354748d02b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nafisah")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-479202")[#strong[#text("Nafisah")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2017")])]

#text("Nine years later, I’m finding this very helpful. Thank you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f869ce1eeab24dc913104f9488b6f0d350d4e3106cba3a38349a4fb9384ddd75-e47ba1635ae2217cd8238acedfb366e9daa638c39dfc494b5cb857e37f248bb8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ntthung")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-480115")[#strong[#text("ntthung")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2017")])]

#text("Dear Prof Tao,")

#text("One thing that’s been bothering me for a while: why is the absolute value sign used in the statement of the theorems? Why do we need E(|X|) instead of just E(X)?")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-480130")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2017")])]

#text("One cannot even define the expectation ")#mi("{\\bf E} X")#text(" of a signed random variable unless one first knows that it is absolutely integrable (that is, ")#tao-math("{\\bf E} \\left|X\\right| < \\infty", block: false)#text("), since expectation is defined using ")#link("https://en.wikipedia.org/wiki/Lebesgue_integration")[#text("Lebesgue integration")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f869ce1eeab24dc913104f9488b6f0d350d4e3106cba3a38349a4fb9384ddd75-e47ba1635ae2217cd8238acedfb366e9daa638c39dfc494b5cb857e37f248bb8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ntthung")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-480135")[#strong[#text("ntthung")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2017")])]

#text("Thank you very much. I was taught statistics in a slightly less formal way (without measure theory), but I guess it’s not too late to start.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebe188c989bdb2385f4162476a5e7ab237f1d65a2680481ebca229f2dadd28c0-0768de6e61c046e81b6a853c8e93941d69ccbcceb6d8bcc85a0cc184f623bd9e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dikran Karagueuzian")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-480139")[#strong[#text("Dikran Karagueuzian")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2017")])]

#text("Here is another perspective on why we need ")#tao-math("\\bf{E}\\left|X\\right|", block: false)#text(". Suppose that we defined ")#mi("\\bf{E} X")#text(" by, say, ")#mi("\\lim_{a \\rightarrow \\infty} \\int_{-a}^a f(x) \\, dx")#text(", where f is the pdf of the random variable ")#mi("X")#text(". Then, for the Cauchy random variable, we would have ")#mi("\\bf{E} X = 0")#text(". However, if ")#mi("X_1, \\ldots, X_n")#text(" are iid Cauchy random variables, the mean ")#mi("\\bar{X}_n")#text(" is also a Cauchy random variable. (Use characteristic functions to prove this.) Thus ")#mi("\\bar{X}_n")#text(" does not converge almost surely to zero.")

#text("So if we tried to get around requiring ")#tao-math("\\bf{E} \\left|X\\right|", block: false)#text(", the strong law of large numbers, as stated, would fail.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/423d1d96f639cb1c1d0792272073ad2eff16afd4b7248ffe42bf30bc87e3f9ed-994081a086115607e73e741bb0f55e70ee506eed9aadfaba6cf9f8175a7379d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Webber")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-483379")[#strong[#text("Robert Webber")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2017")])]

#text("Professor Tao,")

#text("Thanks for a great post!")#linebreak()#text(" Could you please explain the last claim of remark 2 in more detail? In Counterexamples in Probability by Romano & Siegel (pg. 113), there is a nice example of a triangular array of IID random variables that have moments of order p when p 2. But the p = 2 case is trickier and I could come up with neither proof nor counterexample. What did you mean when you said the Chernoff bounds work for the p = 2 case as well?")

#text("Much thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/423d1d96f639cb1c1d0792272073ad2eff16afd4b7248ffe42bf30bc87e3f9ed-994081a086115607e73e741bb0f55e70ee506eed9aadfaba6cf9f8175a7379d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Webber")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-483380")[#strong[#text("Robert Webber")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2017")])]

#text("I apologize for the typo. In Counterexamples in Probability and Statistics (pg 113), there is an example of random variables that have moments of order p where p 2, I can see how Chernoff bounds plus a truncation argument will lead to a SLLN. I a curious about the p=2 case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-483455")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2017")])]

#text("I just want to comment that this is almost surely the politest comments section on the internet. Beautiful website.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-485811")[#strong[#text("Does QM state that Space is made of nothing? | Page 2 | Physics Forums - The Fusion of Science and Community")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2017")]

#text("[…] but that has its own issue to do with the strong law of large numbers being in the infinite limit: ")#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/")[#text("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/")]#text(" I, and most others just say – well there is a probability so close to zero you can take it as zero […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-486747")[#strong[#text("Laws of Large Numbers – Site Title")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2017")]

#text("[…] Terence Tao’s write-up of proof of the law of large numbers. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f2de6aa9514af890cf2226c874137fb5322023fc83b06ca2703201c9deb6779-dbf670f5df7e0cfe04ec1a026cb9a951ca7f729abb7f7c3bc9e00cfe91f09427.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aryeh")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-489415")[#strong[#text("Aryeh")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2017")])]

#text("Dear Professor Tao,")

#text("I am trying (for the sake of my own better understanding) to replace all of the big-O’s with explicit constants. I am having trouble with display (9), however. Is it being claimed with high probability for all n, for n large enough, almost surely for all n, etc?")

#text("Best regards,")#linebreak()#text(" -Aryeh")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-489565")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2017")])]

#text("This is a deterministic estimate (it holds surely for all ")#mi("m,n")#text(" obeying the required hypotheses, basically because ")#mi("m \\overline{X}_m \\leq n \\overline{X}_n")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-490770")[#strong[#text("Einstein's View Of QM | Page 2 | Physics Forums - The Fusion of Science and Community")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2017")]

#text("[…] I saw a proof of it in my undergrad years – but it was hard. Terry Tao has I think a better proof: ")#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/")[#text("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/")]#text(" Thanks Bill bhobba, Dec 25, 2017 at 11:26 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ebe6de4cb9de9ac0c3a5d1059f9aa668ff783d49acdacd8b4ac3c00df70150c-07a9edce3bd51963008db0afe7af1327ba78ef0a7086c351daaa344225aa3dfc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-498799")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2018")])]

#text("Here’s a version of strong law I found in my textbook.")

#text("Let ")#mi("X_i")#text(" be iid random variables (such as random walk) and ")#mi("K \\in \\mathbb{R}_{\\geq 0}")#text(" and ")#mi("\\mathbb{E}[X_k] = 0")#text(" and $latex ")#mi("\\mathbb{E}[X_k^4] \\leq K")#text(" (I guess this means you’ve “centered” the random variable.)")

#text("Then your empirical average ")#mi("S_n = X_1 + \\dots + X_n")#text(" approaches the theoretical average ")#mi("\\mathbf{P}(n^{-1} S_n \\to 0 ) \\to 1")#text(", i.e. ")#mi("S_n/n \\to 0")#text(" almost surely.")

#text("Your use of Borel-Cantelli is already a sign that some measure-theoretic phenomena is going on. If only we knew the distribution of ")#mi("X")#text(" in practice. Or could genuinely assume these random variables were perfectly iid.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-501600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2018")])]

#text("Dear professor Tao,")

#text("What is the optimal convergence rate for the strong law of large numbers for positive bounded iid random variables ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-501606")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2018")])]

#text("There is extensive literature on these questions, see e.g. ")#link("https://projecteuclid.org/euclid.bams/1183525688")[#text("this paper of Baum and Katz")]#text(" (or papers cited in, or citing, that paper). In practice, concentration of measure tools such as the Hoeffding inequality tend to give bounds that are fairly close to optimal, and highly usable for many applications.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f59813fd6c85af45bd780aa654ef23ef811738f529070ecdbd4dfcc90b1847-abb19b163bcd77d17434daedaf85e9a97173b6cfc141beee05ba95e6d231a057.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zsikic")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-504740")[#strong[#text("zsikic")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2018")])]

#text("I always thought of the difference between wlln and slln as the difference between limP(En>e)=0 and limP(En>e or En+1>e or En+2>e or …)=0, where En is “error” of the n-th average approximating the expectation. Does it make sense?")

#emph[#text("[Yes, this is one way to think about it. See also my ")#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/#comment-30664")[#text("previous comment")]#text(" in this thread. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f59813fd6c85af45bd780aa654ef23ef811738f529070ecdbd4dfcc90b1847-abb19b163bcd77d17434daedaf85e9a97173b6cfc141beee05ba95e6d231a057.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zsikic")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-504764")[#strong[#text("zsikic")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2018")])]

#text("Thank you, I missed the comment. I have never seen a derivation of limP(En>e or En+1>e or En+2>e or …)=0 from P(limEn=0)=1. Do you know any reference?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-536961")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2020")])]

#text("HI professor, in your lemma 1, is it possible to know how the assumption of “Expectation of X has to be finite” is being used? Why is this condition required? Sorry could you elaborate little bit more? Similarly for Lemma 2, why is E|x|^2 being finite is necessary?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-537171")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2020")])]

#text("In the proof of the law of large numbers, the first moment hypothesis is used to obtain (7). Without this hypothesis the expectation is not even well defined, and there is no law of large numbers, as evidenced for instance by the ")#link("https://en.wikipedia.org/wiki/St._Petersburg_paradox")[#text("St. Petersburg paradox")]#text(". Lemma 2 is vacuously true when the second moment is infinite, as the RHS is infinite also in this case. (The behaviour of empirical averages in the infinite second moment case is governed by other ")#link("https://en.wikipedia.org/wiki/Stable_distribution")[#text("stable laws")]#text(" than the gaussian; see my later notes at ")#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/")[#text("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/")]#text(" .)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a042626513548df1acb6b37de12698c80f39436ae2e9a18e3b411811245701c-7d0d9858d5e7dbf80f1292af4cc95b7dac00e9016a8533f62e6281641e6e46fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of T. Jahn")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-567646")[#strong[#text("T. Jahn")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2020")])]

#text("Dear Professor Tao, I was wondering, wether it is possible to obtain ")#mi("L_1")#text(" convergence also (I only saw proofs for this relying on martingale theory): Let ")#mi("N")#text(" be such that")

#block(width: 100%, above: 12pt, below: 14pt)[#set par(justify: false)
#text(size: 7pt, fill: rgb("596477"))[#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/#comment-567646")[Source formula could not be rendered.] ] #text(font: "DejaVu Sans Mono", size: 7.5pt, "\\displaystyle E |X_{>N}|N}}_n -E X_{>N}| \\le \\sqrt{E|\\overline{X_{\\le N}}_n - E X_{\\le N}|^2} + 2E|X_{>N}|")]

#tao-math("\\displaystyle \\le \\sqrt{E\\left|X_{\\le N} - E X_{\\le N}\\right|^2/n} + 2 \\epsilon", block: false)

#tao-math("\\displaystyle \\le \\sqrt{N E\\left|X_{\\le N}\\right|/n} + 2 \\epsilon\\le 3 \\epsilon", block: false)

#text("for n large enough, where Jensen’s inequality is used in the second, the proof of Lemma 2 in the third and (6) in the fourth step.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e64b37470c2f1b3a4b4a69fd3437b3a087ffb6423974c1169ceee55ac72481-d42be15bd53754fcc449f3c9a16d337cd279cfd1559c5295eb1a174b5717dfaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Russell Lyons")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-567754")[#strong[#text("Russell Lyons")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2020")])]

#text("I cannot read what you intend to write, but ")#mi("L_1")#text(" convergence is automatic from a.s. convergence in such a situation. Indeed, ")#mi("X_n")#text(", being identically distributed, form a uniformly integrable (UI) class. The convex hull of a UI class is also UI, and thus the averages form a UI class. Every a.s. convergent sequence of UI functions also converges in ")#mi("L_1")#text(" to the same limit. Putting these together gives what you want.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a042626513548df1acb6b37de12698c80f39436ae2e9a18e3b411811245701c-7d0d9858d5e7dbf80f1292af4cc95b7dac00e9016a8533f62e6281641e6e46fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of T. Jahn")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-568754")[#strong[#text("T. Jahn")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2020")])]

#text("Yes, thank you! The L_1 convergence may also be deduced the same same way as the convergence in probability. That is in particular, it holds also in the setting of Remark 2, where there is no a.s. convergence.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e64b37470c2f1b3a4b4a69fd3437b3a087ffb6423974c1169ceee55ac72481-d42be15bd53754fcc449f3c9a16d337cd279cfd1559c5295eb1a174b5717dfaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Russell Lyons")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-568927")[#strong[#text("Russell Lyons")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2020")])]

#text("Every UI sequence that converges in probability also converges in ")#mi("L_1")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e7fe30cf6ce07c070fe9267819b98380b53dd81f87abc62d85038a9fb67498c-edafbfc1f01cae0d2d86900ed4b133bf162494f73ec897dfb3406724955807c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quasar")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-610245")[#strong[#text("Quasar")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2020")])]

#text("Dear Professor Tao,")

#text("I am a compsci undergrad, worked as a programmer; recently switched to a quantitative job.")

#text("I am finding it exciting to learn analysis from (1) Understanding Analysis – Stephen Abott (2) Analysis – T Tao. I try and put together small proofs, take notes in ")#mi("\\LaTeX")#text(".")

#text("I am also learning basic probability from (1) Introduction to probability th. and it’s applications – volume 1 – W. Feller (2) Probability & random processes – Grimmet, Stirzaker.")

#text("What could be a good first book on measure theoretic probability? How much analysis does one need to know, before I can take the plunge?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-642752")[#strong[#text("‘WHY’ does the LLN actually work? Why after multiple trials will results converge out to actually ‘BE’ closer to the mean the larger the samples get? – GrindSkills")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2022")]

#text("[…] For a terrific if mathematical explanation of the Law of Large Numbers, see the blog entry of Terry Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0bdf148cca93750101dc23265ed54be609c0be0d7f445643de26cecb411039-97a60200c98e2df985a9bc6487d5cd3b9bd3d9215ce1ff05752f6f6388dc9443.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josh")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-680818")[#strong[#text("Josh")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2023")])]

#text("Terry are you sure you used MCT (rather than DCT) just underneath inequality (6)?")

#emph[#text("[One can use either theorem here. Monotone convergence gives (6) in the equivalent form ")#tao-math("{\\bf E} \\left|X_{\\leq N}\\right| \\to {\\bf E} \\left|X\\right|", block: false)#text(". -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-2/#comment-685979")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2024")])]

#text("If $katex N_1<N_2$ then $katex X_{N_1} < X_{N_2}$, so yes Monotone Convergence can be used.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-30481")[#strong[#text("Markov’s Inequality « Justin Domke’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2008")]

#text("[…] June 19, 2008 While looking at Tao’s post on the law of large numbers, I claimed to Alap that Markov’s inequality was […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of toomuchcoffeeman")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-30494")[#strong[#text("toomuchcoffeeman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2008")])]

#text("A very clear and educative post: it’s been a long time since I was made to learn about weak and strong LLN, but I don’t recall the proofs seeming so well-motivated at the time.")

#text("One question: you remark that")

#emph[#text("(If one strengthens the first moment assumption to that of finiteness of the second moment ")#tao-math("{\\Bbb E}\\left|X\\right|^2", block: false)#text(", then we of course have a more precise statement, namely the central limit theorem, but I will not discuss that theorem here.)")]

#text("I’m a bit confused: do you mean that the CLT can be viewed as a more precise version of the WLLN or the SLLLN?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-30495")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2008")])]

#text("Dear toomuchcoffeeman,")

#text("I’ve clarified the text to reflect the fact that the CLT is a sharper version of the weak LLN. (There is no almost sure (or “strong”) version of the CLT, as the limit in the CLT is random rather than deterministic. One could argue though that Berry-Esseen quantitative version of the CLT is somewhat analogous to the quantitative versions of the LLN (such as (9)) that underlie the strong LLN.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-498584")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2018")])]

#text("Dear Terence,")

#text("I dont understand why everyone insists on comparing LLN and CLT without mentioning rate of convergnce and mode of convergence. To me it seams that we are talking about convergence in different sense and of sequences of different random varibales w.r.t $\\frac{1}{n}$ and $\\frac{1}{\\sqrt{n}}$ . Noone seams to acknowledge this and I think it is really the essence of the ideas. Care to weight in?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-498720")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2018")])]

#text("The CLT implies the WLLN for random variables ")#mi("X_1,X_2,\\dots")#text(" of finite second moment. To relate the various modes of convergence, the key point is that if ")#mi("S_n/\\sqrt{n}")#text(" converges in distribution to a gaussian (or indeed to any other almost surely finite random variable), then ")#mi("S_n/n")#text(" must then converge in probability to zero, as can be seen by writing out the definitions of both modes of convergence and comparing them.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66396b6cf9d09bbcf10431a8822e7df78eb4bebd9ea95ea9460961ace5e7f677-ec13b153a405fdcd95c2dc6732d2dfd96c9bf98b1d309ee910b5235e4a6ea59b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nobelHubel")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-30502")[#strong[#text("nobelHubel")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2008")])]

#text("Prof. Tao, shouldn’t the inequality in the indicator function below equation (1) be reversed?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-30503")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2008")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Batson")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-30507")[#strong[#text("Joshua Batson")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2008")])]

#text("Professor Tao,")

#text("Isn’t good control of the zeroth moment attained when P(X !=0) is low, that is, when X is mostly 0?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/da9291ae656378d2d1c1695bfb59f5ac043719496f0a47c10fa3ebf26a83c41f-883525295b1d676cda78282e92f7c4142ce5ee3ca5d970e392b8b23604f9ead3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of athreya")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-30509")[#strong[#text("athreya")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2008")])]

#text("Dear Professor Tao,")#linebreak()#text(" In 1995 Mike Keane presented a (much) easier proof of the SLLN. The idea is essentially enclosed in the article:")

#text("M. Keane, The essence of large numbers, Algorithms, Fractals, and Dynamics (Okayama/Kyoto, 1992), 125-129, Plenum, New York, 1995.")

#text("It is a hands on proof that works with running average omega by omega.")

#text("best wishes")#linebreak()#text(" Siva")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-30512")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2008")])]

#text("Dear Joshua: Thanks for the correction!")

#text("Dear Siva: Thanks for the article, which I found at")

#link("http://repos.project.cwi.nl:8888/cwi_repository/docs/I/02/2627A.pdf")[#text("Click to access 2627A.pdf")]

#text("It appears to reinterpret the strong law of large numbers as a special case of the pointwise ergodic theorem for measure-preserving systems (or for stationary processes, which are much the same thing). But it seems the author has restricted himself to bounded random variables (such as those only taking the values 0 and 1); most of the difficulty in the strong law, as in the proof above, comes from the fact that X can be unbounded (which is why we need to mess around with truncations, as well as the use of the first or zeroth moment method to deal with the large values of X).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac93f081e84e575105d2005b7637f50994b3a3988b5005096bb70ed489e2809e-e9d30813ba20e3d3b4072bde549ef7d0bd1b24d8e16a2faf9eb74db445038f3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PROFESSOR  CONSTANTINO DE SOUSA")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-30515")[#strong[#text("PROFESSOR  CONSTANTINO DE SOUSA")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2008")])]

#text("VERY GOOD.")#linebreak()#text(" CUMPLIMENTS")#linebreak()#text(" PROFESSOR CONSTANTINO DE SOUSA")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-30523")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2008")])]

#text("There is some philosophy related to the laws of large numbers which I don’t really understand, and which I’d be happy to have explained to me. In theory, we are speaking about a sequence ")#mi("X_1,X_2,...")#text(" of random variables on the same common probability space. In practice, we think of instantiating a random variable in a sequence of trials. This is a subtle point: each trial is itself a random variable, distributed exactly as the original one, and leaving in an identical, but separate and independent, probability space. When we toss a die ")#mi("100")#text(" times, there are ")#mi("6^{100}")#text(" possible outcomes. This means, we are no longer in our original six-element space, but in its cartesian power, with ")#mi("6^{100}")#text(" points. That is, tossing a die ")#mi("100")#text(" times is described by the probability space which is the product of ")#mi("100")#text(" copies of the space, corresponding to tossing just one die. So, our ")#mi("X_1,X_2,...")#text(" actually leave in ")#emph[#text("different")]#text(" spaces.")

#text("How does this agree with the theoretical assumption that the ")#mi("X_n")#text("‘s are defined on the same space? To make this more specific: say, what is the “practical meaning” of pointwise convergence in the Strong law? When we think of trials, the variables ")#mi("\\overline{X}_n")#text(" live in distinct spaces; on what space they pointwise converge?")

#text("On this occasion: the proof of Borel-Cantelli does not need Markov and")#linebreak()#text(" indicators. What would it mean that an infinite number of ")#mi("E_n")#text(" are")#linebreak()#text(" true with positive probability? The existence of an event ")#mi("A")#text(", with")#linebreak()#text(" ")#mi("{\\mathbb P}(A)>0")#text(", such that ")#mi("A")#text(" is contained in infinitely many of the events ")#mi("E_n")#text(". But then the probability of each of these events is at least as large as that of ")#mi("A")#text("; hence the series, having infinitely many terms bounded away from 0, diverges.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-30524")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2008")])]

#text("Dear anonymous,")

#text("In elementary (finitary) probability theory, the sample space (or probability space) is often defined in textbooks as simply the set of all possible outcomes, as this is the simplest choice of space to work in for most finitary applications. When it comes to infinitary probability theory, though, it is better to take a more flexible and abstract viewpoint: the sample space is now allowed to be an abstract set, and each outcome corresponds to a separate event inside that set. For instance, if one is studying the flip of a single coin, the sample space ")#mi("\\Omega")#text(" could be a two-element set {Heads, Tails}, but it doesn’t ")#emph[#text("have")]#text(" to have just two elements; it could be a much larger set, partitioned into two disjoint subsets, the “Heads” event and the “Tails” event. For instance, the sample space could be the unit interval [0,1] with Lebesgue measure, and the Heads and Tails events could be the intervals [0,1/2) and (1/2,1] respectively.")

#text("For the purposes of probability theory, the exact size of the sample space does not matter; the only thing that matters is the algebra (or more precisely, ")#mi("\\sigma")#text("-algebra) of events and the probability (or measure) which is assigned to each event; the actual points in the sample space are in fact largely irrelevant to probability theory. (See also the notion of equivalence of measure spaces, as defined for instance in ")#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/")[#text("Lecture 11 of my 254A course")]#text(". Equivalent probability spaces may have very different cardinalities, but are indistinguishable from each other for the purposes of doing probability theory.)")

#text("To construct a suitable sample space to hold an infinite collection of random variables, such as an infinite sequence of independent die rolls, one can take an inverse limit of the sample spaces associated to finite sequences of die rolls. One could also resort to more ")#emph[#text("ad hoc")]#text(" devices, such as taking the sample space to be the unit interval ")#mi("{}[0,1]")#text(" with Lebesgue measure (which is the standard sample space for selecting a random variable x uniformly at random from the unit interval) and then defining the value ")#mi("X_i")#text(" of the i^th die roll to be the i^th digit of x base 6, plus one. In this space, the law of large numbers has this interpretation: when one selects a number at random from the unit interval, then almost surely, its base 6 digits are uniformly distributed amongst 0,1,2,3,4,5.")

#text("Incidentally, your argument for the Borel-Cantelli lemma does not quite work; the assertion “with positive probability, an infinite number of the events ")#mi("E_n")#text(" are true” is ")#strong[#text("not")]#text(" the same as “an infinite number of the events ")#mi("E_n")#text(" are simultaneously true with positive probability”, because at different points in the sample space, a different (but still infinite) collection of infinite events could be true. For instance, to go back to the infinite die roll example, let ")#mi("E_n")#text(" be the event that the n^th die roll is a 1. Then any infinite collection of events ")#mi("E_n")#text(" has an intersection that has zero probability; for instance, the probability that all the odd die rolls are all 1 is zero. Equivalently, as you say, no event A of positive probability is contained in infinitely many of the ")#mi("E_n")#text(". Nevertheless, it is true almost surely that infinitely many of the ")#mi("E_n")#text(" are true; if one rolls an infinite number of dice, one will almost surely roll an infinite number of ones. But the exact set of rolls that yield these ones vary from outcome to outcome; indeed, there are an uncountable number of possible sets of rolls, which is why one can represent an event of probability 1 as the union of events of probability 0. (This is, incidentally, one way to prove that the reals are uncountable, though certainly not the most direct way, as it requires one to first construct Lebesgue measure.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-30525")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2008")])]

#text("Got both your points, many thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-30545")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2008")])]

#text("It’s me again – the very same Anonymous.")

#text("> Incidentally, your argument for the Borel-Cantelli lemma does not quite > work")

#text("How about this? Fix ")#mi("\\epsilon>0")#text(" and find ")#mi("N=N(\\epsilon)")#text(" such")#linebreak()#text(" that ")#mi("P(E_N)+P(E_{N+1})+...<\\epsilon")#text(". For ")#mi("N")#text(" or more of the")#linebreak()#text(" events ")#mi("E_n")#text(" to occur, at least one of ")#mi("E_N,E_{N+1},...")#text(" must")#linebreak()#text(" occur, and the probability of this is less than ")#mi("\\epsilon")#text(". We are")#linebreak()#text(" done!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-30546")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2008")])]

#text("Yes, this works too; in the notation of the above post, this is a “zeroth moment method” argument rather than a “first moment method” argument. (The first moment method argument gives a more precise upper bound on the probability that at least k events are true for any given k, though.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24e4f0acbdcc91b2c7ba7aa365b93230645de6434c5bb00b576cb2e5b7b4b5d4-c613a49f867fec7449a638a997a449750baa68478c75c7b8283270fc50513284.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Peccati")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-30576")[#strong[#text("Giovanni Peccati")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2008")])]

#text("Dear Terence,")

#text("thank you for this beautiful website!")

#text("Just a quick note: there exists indeed a series of asymptotic results for partial sums of iid random variables that are known in the literature as “Almost Sure Central Limit Theorems”. This kind of theorems involve some (weighted) “logarithmic” versions of the empirical measures associated with the underlying partial sums. They hold almost surely, and they have a Gaussian probability measure as a limit object. A paper containing several general results in this direction is the following")

#link("http://www.springerlink.com/content/v3u54005214j853n/")[#text("http://www.springerlink.com/content/v3u54005214j853n/")]

#text("Best!")

#text("Giovanni Peccati")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of toomuchcoffeeman")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-30581")[#strong[#text("toomuchcoffeeman")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2008")])]

#text("Dear Giovanni,")

#text("As the person who (implicitly) asked if there were versions of the CLT akin to the strong law of large numbers: thank you for your post and the link (the results you describe, involving empirical measures, are what I was thinking of, although I didn’t know how to express it).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b2696042c1cd66f714bd3c53d209a780a30f7f02952b685d5a174007ad45ef6-dbbba154c56a3788a101cde6dab40b80a4773cc8440533f648f9b57b0cd81a70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yashar")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-30633")[#strong[#text("Yashar")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2008")])]

#text("Dear Terry,")#linebreak()#text(" I also share Anonymous’s philosophical/practical concern about the usefulness of the SLLN. Let me clarify: although I understand the mathematical meaning of almost sure pointwise convergence for functions in some abstract measure space, I don’t think SLLN has much value for the ‘usual’ application of the LLN, namely in relating the ’empirical’ (i.e. trial-wise — or timewise in ergodic theory) averages to expectation values calculated in probability theory. This is so because in ‘reality’ we are only dealing with FINITELY many (say iid) samples from a probability distribution. In this setting, pointwise convergence is meaningless as you need the whole infinite series to be able to talk about convergence, but convergence in probability still makes sense (especially, if we interpret the probability of deviation in WLLN, in the Bayesian degree-of-belief sense as opposed to a frequentist sense).")

#text("However, I admit that the ‘usual’ applications may not comprise all useful applications. Your pretty example, where you map the infinite dice-rolling sequence to [0,1], is certainly one such application. However, any generalization of the intuition gained there to cases where the probability space (and thus the set of ‘digits’ of your, now, super-real numbers) are uncountable are beyond me. But I’m aware that these problems are pretty much the very reason why measure theory was invented and that e.g. Kolmogorov’s theorem resolves the issue of constructing the infinite cartesian product of uncountable spaces (am I right?).")

#text("Maybe all of these concerns are too ‘philosophical’, and somewhat smell of the ancient problems with infinity, uncountability, etc, which you might find boring. But i’ll be glad to read your views about them if you don’t. More importantly, I’ll be grateful if you could point out some (important) applications of SLLN, whether ‘usual’ in the above sense or otherwise, where WLLN is useless. I’d rather the applications be in some sense intrinsically probabilistic rather than purely ‘geometric’/functional-analytic though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-30664")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2008")])]

#text("Dear Yashar,")

#text("Of course, any mathematical statement involving infinity will not have any direct application to the finitary situations encountered in the physical world, but any “qualitative” or “infinitary” statement in mathematics often tends to have “quantitative” or “finitary” counterparts which do have such an application, or at least gives some useful intuition on how to view these finitary contexts. (See for instance my ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("blog post on this issue")]#text(".)")

#text("Returning specifically to the question of finitary interpretations of the SLLN, these basically have to do with the situation in which one is simultaneously considering multiple averages ")#mi("\\overline{X}_n")#text(" of a single series of empirical samples, as opposed to considering just a single such average (which is basically the situation covered by the WLLN). For instance, if one had some random intensity field of grayscale pixels, and wanted to compare the average intensities at 10 x 10 blocks, 100 x 100 blocks, and 1000 x 1000 blocks, then the SLLN suggests that these intensities would be likely to be ")#emph[#text("simultaneously")]#text(" close to the average intensity. (The WLLN only suggests that each of these spatial averages are ")#emph[#text("individually")]#text(" likely to be close to the average intensity, but does not preclude the possibility that when one considers multiple such spatial averages at once, that a few outlying spatial averages will deviate from the average intensity. In my example with only three different averages, there isn’t much difference here, as the union bound only loses a factor of three at most for the failure probability, but the SLLN begins to show its strength over the WLLN when one is considering a very large number of averages at once.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: Universality of ESDs and the circular law « What’s new")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-31761")[#strong[#text("Random matrices: Universality of ESDs and the circular law « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2008")])]

#text("[…] in probability rather than almost sure convergence; this is in complete analogy with the weak and strong law of large numbers, and in fact this law is used in the proof.) In a previous paper, we had established the same […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Small samples, and the margin of error « What’s new")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-32888")[#strong[#text("Small samples, and the margin of error « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2008")])]

#text("[…] greater generality than the setting discussed here. (It is closely related to the arguments in my previous post on the law of large numbers.) The main mathematical result we need is Theorem. Let X be a finite set, let A be a subset of X, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Non-measurable sets via non-standard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-33003")[#strong[#text("Non-measurable sets via non-standard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2008")])]

#text("[…] idea was to let E be a “random” subset of . If one (non-rigorously) applies the law of large numbers, one expects E to have “density” 1/2 with respect to every subinterval of , which would […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-33829")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2008")])]

#text("Prof. Tao,")

#text("If, for example, S=\\sum_{i=1}^{N} X_i, but N is a random variable taking values for a fairly large integer to infinity. Since S can be rewritten as")#linebreak()#text(" S= N (\\bar X_N), is it safe to say that S \\approx N E(N).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tricks Wiki: Use basic examples to calibrate exponents « What’s new")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-34422")[#strong[#text("Tricks Wiki: Use basic examples to calibrate exponents « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2008")])]

#text("[…] G on N vertices, in which each edge has an independent probability of of lying in G. By the law of large numbers, we expect the edge density of such a random graph to be close to on the average. On the other […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-34650")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2009")])]

#text("What is a good book to learn probability theory from if I already know measure theory (at the level of Rudin’s Real and Complex Analysis)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-34654")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2009")])]

#text("Dear K,")

#text("I guess it depends on what you plan to use probability for. I myself tend to use probability for combinatorial purposes, and so I actually don’t use the measure-theoretic foundations of probability so heavily (in many combinatorial applications, one can in fact just work with discrete random variables). For such applications, Alon-Spencer’s “the probabilistic method” is very nice.")

#text("For the formal measure-theoretic foundations of probability, I have occasionally used Kallenberg’s “Foundations of probability theory”, which is quite thorough.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-34910")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2009")])]

#text("Dear Professor Tao,")

#text("Would you know of a good book/resource where one can look up all the LLNs that exist under varying assumptions.")

#text("Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c683fae9fa44299ce95dc55215a41d924832847f9912fde66eff06170782ed9-41acb75250f59e9b58f05addc66142ccc483591a56e7e907db9a2b8c2ea4c4c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of WTH is the Law of Large Numbers? « What The Haven")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-35653")[#strong[#text("WTH is the Law of Large Numbers? « What The Haven")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("[…] a more involved commentary, see the famous blog by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0c6d1db5005a60b784da3f5c3843611bae49d05f51afebd397aada91827157e-8bf08cf40c64f7c963bb3545fe615f681917acec3ee49177e7c3b497b3ec45a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Duc")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-35953")[#strong[#text("Duc")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2009")])]

#text("Dear Professor Tao,")#linebreak()#text(" Would it be still sufficient if X_i are not identical?")#linebreak()#text(" Is the law still hold if we trade off the identical and independent of those X’s for sup E(X_i^2) bounded and X’s uncorrelated?")#linebreak()#text(" I’m reading the book Hilbert Space Methods in Probability and Statistical Inference (")#link("http://www.wiley.com/WileyCDA/WileyTitle/productCd-0471592811.html")[#text("http://www.wiley.com/WileyCDA/WileyTitle/productCd-0471592811.html")]#text(") and wonder if we could prove it by using vectors in Hilbert space.")#linebreak()#text(" Thank you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d94d29934c6997587c92e70bbccd18aa130883c4196421d5e805d85e98860074-b74cd49f088ffd1e6c0a16b5d0bf7f7b197c9a0fdb2aa060df95f99da2b7afca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vivek")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-36566")[#strong[#text("Vivek")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2009")])]

#text("How does the Weak law of large numbers follow from strong law by dominated convergence theorem. I always thought it was Egoroff’s theorem but I think you have a more simple proof Dr Tao.")#linebreak()#text(" Vivek")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-36567")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2009")])]

#text("Dear Vivek,")

#text("You are right, Egoroff’s theorem is a better citation here. (Dominated convergence works directly when the random variables are bounded, and for unbounded random variables one can apply dominated convergence to the level sets to get the strong law from the weak, but one may as well just jump straight to Egoroff in the latter case.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lutfu")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-38439")[#strong[#text("lutfu")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2009")])]

#text("Dear Prof. Tao,")

#text("If we have i.i.d rvs with mean zero, then what is the a.s limit of ")#mi("\\frac{S_{n}}{n^a}")#text(" for different values of a less than 1?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-38470")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2009")])]

#text("Dear lutfu,")

#text("Assuming the random variables have bounded second moment, the limit will be almost surely zero for ")#mi("a > 1/2")#text(", converge (in a distributional sense) to a normal distribution for ")#mi("a=1/2")#text(", and diverge to infinity almost surely for ")#mi("a < 1/2")#text(", all thanks to the (strong) law of large numbers. For heavy-tailed random variables with infinite second moment, the situation is going to be more complicated, but can be worked out for any specific distribution by a variety of tools (e.g. Fourier analysis).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lutfu")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-38473")[#strong[#text("lutfu")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2009")])]

#text("Dear Prof Tao,")

#text("Thank you for your help. but I am wondering can we explicitly characterize the a.s. limit of ")#mi("\\frac{S_{n}}{n^a}")#text(" for any real number a , just assuming the existence of first moment?")

#text("I know we have law of iterated logarithm thm but it assumes existence of the second moment.")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78a1bb91e3654467eb162587633ba24a9ff0b1585ba473137f4e27c924c889f0-72d63223002144372080a3a09b97978a8a0808f29ee5b949d89f339866f5e8b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ajit")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-41770")[#strong[#text("Ajit")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")])]

#text("Being much more into “discrete” math, I often have great difficulty trying to understand concepts from continuous math. One thing I’ve never really understood is why the strong law is stronger than the weak law. I’ve read the statements of the laws and read about the meaning of almost sure convergence and convergence in probability, but I don’t have a good feel for this. I checked the wikipedia entry on this topic, but it’s not clear as to how the strong law prevents you (with probability 1) from having infinitely many sample sequences whose average differs from the true mean. Can you help me?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-41774")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")])]

#text("Imagine a table in which the rows are all the possible points in the sample space (this is a continuum of rows, but never mind this), and the columns are the number n of trials, and there is a check mark whenever the empirical mean ")#mi("\\overline{X}_n")#text(" deviates significantly from the actual mean ")#mi("{\\Bbb E} X")#text(". The weak law asserts that the density of check marks in each column goes to zero as one moves off to the right. The strong law asserts that almost all of the rows have only finitely many checkmarks. A double counting argument (or the Lebesgue dominated convergence theorem) then shows that the latter implies the former.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/93e97e4187199ac5280ed181e5eade7c50944a3fdc9a5e014d20945e83897976-9aa87c089c532a759d2cd981ebc7d3c694f247bd21eeb028f8afa575b83d77ab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicooo")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-313963")[#strong[#text("nicooo")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2014")])]

#text("Great explanation. Thanks a lot !")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b1f6449ffa50dff4204514c36266db067e99788ba7dd725fd77cd1ed400fc50-73e6b5b69b101e44b4da4dcc994cd7bb06faa22f15c80dbbbdb07fc33ed69291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiaosheng")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-41846")[#strong[#text("Xiaosheng")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2009")])]

#text("Dear Prof.:")#linebreak()#text(" Do you have a proof of the SLLN without the assumption that E(X^2) exists?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-41848")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2009")])]

#text("The proof given in the article uses only finiteness of the first moment.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b1f6449ffa50dff4204514c36266db067e99788ba7dd725fd77cd1ed400fc50-73e6b5b69b101e44b4da4dcc994cd7bb06faa22f15c80dbbbdb07fc33ed69291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiaosheng")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-41916")[#strong[#text("Xiaosheng")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2009")])]

#text("Prof Tao:")

#text("I’m not quite sure about the truncation method. You used a threshold N to divide the random variable X into two parts Y and Z. Are these two still random variables? I’m just wondering what is XI(X<N) and why does Xn bar equal the sum of Yn bar plus Zn bar?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-41917")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2009")])]

#text("I(X<N) is the ")#link("http://en.wikipedia.org/wiki/Indicator_function")[#text("indicator function")]#text(" of the event X<N. Thus, ")#mi("X I(X<N)")#text(" is the random variable which equals X when X is less than N, and equals 0 otherwise.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b1f6449ffa50dff4204514c36266db067e99788ba7dd725fd77cd1ed400fc50-73e6b5b69b101e44b4da4dcc994cd7bb06faa22f15c80dbbbdb07fc33ed69291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiaosheng")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-41921")[#strong[#text("Xiaosheng")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2009")])]

#text("Yeah, but then it seems that the “sum” of the empirical average of the two parts doesn’t equal the empirical average of X. At least the probabilities on both sides don’t equal… I think there should also be terms describing situations where X1>N>X2 and so forth, but that will spoil the proof. I’m sorry if I misunderstand your meaning.")#linebreak()#text(" By the way, it’s such a pitty that I missed your lecture on IMO 2009. Actually I was on the Chinese team in 2008 and didn’t sit for the test again this year. I’m now a freshman at Yale and hope I can have chance to hear your lecture someday.")

#text("Best,")#linebreak()#text(" Xiaoshengempirical average of X. At least the probabilities on both sides don’t equal… I think there")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-41922")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2009")])]

#text("There is no ")#mi("X_1")#text(" and ")#mi("X_2")#text(" here; there is just a single random variable X, which one decomposes as ")#mi("X = X I(X \\leq N) + X I(X > N)")#text(", simply because the events ")#mi("X \\leq N")#text(" and ")#mi("X > N")#text(" are complementary and so ")#mi("I(X \\leq N)")#text(" and ")#mi("I(X > N)")#text(" add up to 1. The two random variables on the right-hand side are not independent, of course, but this doesn’t matter.")

#text("(It may help if one goes back to the foundations of probability theory, and views X as a measurable function on the underlying probability space.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b1f6449ffa50dff4204514c36266db067e99788ba7dd725fd77cd1ed400fc50-73e6b5b69b101e44b4da4dcc994cd7bb06faa22f15c80dbbbdb07fc33ed69291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiaosheng")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-41926")[#strong[#text("Xiaosheng")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2009")])]

#text("Prof Tao:")

#text("I’m sorry for disturbing you, but I just wonder why does the empirical average of X equal the sum of the the two empirical averages of the decomposed parts XI(X>=N) and XI(X=N or not for each index j, and then we need bionomial coefficients to add these conditions up. But it seems that in this article, only two conditions–X1~Xn simultaneously less than N or simultaneously greater than or equal to N– is considered.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b1f6449ffa50dff4204514c36266db067e99788ba7dd725fd77cd1ed400fc50-73e6b5b69b101e44b4da4dcc994cd7bb06faa22f15c80dbbbdb07fc33ed69291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiaosheng")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-41928")[#strong[#text("Xiaosheng")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2009")])]

#text("It’s pretty strange that my sentence is again missing.Sorry for that. I just want to say that we need to consider Xj>=N for each index j.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-41929")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2009")])]

#text("To apply linearity of expectation (the equation after (2) in the post), no decomposition into cases is required. (This is part of the reason why linearity of expectation is such a powerful method; it also does not require any independence assumptions on the summands.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d94d29934c6997587c92e70bbccd18aa130883c4196421d5e805d85e98860074-b74cd49f088ffd1e6c0a16b5d0bf7f7b197c9a0fdb2aa060df95f99da2b7afca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vivek Kaul")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-41933")[#strong[#text("Vivek Kaul")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2009")])]

#text("I understand that strong law of large number is proved with rigor under the mathematical framework of measure theory but how well does real number system with its problems model things in nature? Do you believe mathematics is just a tautology like Russel’s student Wittgenstein, or there is a deeper meaning to mathematical proofs. Do you think the only purpose of mathematics is to establish logical equivalences between statements, so that we get to a statement that is empirically verifiable? How much can be rely on Mathematical proofs in measure theory and does the Godel’ s incompleteness theorem deny")

#text("I would request you to give some insight into these questions as most mathematicians I met know much more advanced mathematics than me, but they do not answer my questions clearly. Hence I lose motivation to pursue mathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-41939")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2009")])]

#text("I find these sorts of metamathematical questions to have surprisingly little impact on the practice and understanding of both maths and science. Nevertheless, I can try to answer some of your questions.")

#text("At sufficiently microscopic scales (e.g. below the Planck length), the physical world may well have a different nature than that of the continuum, but this is not incompatible with the empirically observed fact that continuum models work extremely well at macroscopic scales (we have plenty of mathematical examples of discrete systems, for instance, which asymptotically behave like the continuum at large scales). In any event, the mathematical consistency of such continuum models has nothing to do with whether they actually model physical reality or not; the former is a question in pure mathematics, and the latter is a question in physics.")

#text("The real line, for instance, can be formally constructed in, say, the ZFC model of set theory, or in the framework of Euclidean geometry (using, say, Hilbert’s axiomatisation of that theory). Having a physical model (or visual model, etc.) of the real line is very useful for providing intuition and to serve as an analogy to the idealised mathematical concept, but is not essential.")

#text("It is true that mathematical theorems are, ultimately, tautologies, but they are very non-obvious and useful tautologies nonetheless. For instance, any theorem about three-dimensional Euclidean space ")#mi("{\\Bbb R}^3")#text(" is a tautology which does not directly have any physical significance; however, if one then combines such tautologies with the non-mathematical")#linebreak()#text(" belief that physical space can be modeled (at human scales) by ")#mi("{\\Bbb R}^3")#text(", then suddenly these theorems yield useful physical consequences that can be verified empirically. Because of things like this, I find the distinction between tautologies and non-tautologies to not be particularly useful in practice.")

#text("In any event, theorems and proofs are not the fundamental objective of mathematics, despite the possible appearance to the contrary; what we really seek is the ")#emph[#text("understanding")]#text(" of various mathematical phenomena, including those phenomena which model analogous real-world phenomena. Formal theorems and proofs are an excellent way to objectively capture and quantify this understanding (and to eliminate all sorts of misunderstanding), but they are a means to an end only.")

#text("Regarding the incompleteness theorem: it is true that this theorem tells us that we should not be able to establish the consistency of formal mathematical systems such as ZFC (say), so any theorem proven using ZFC is then “only” known to be correct conditionally on the consistency of ZFC.")#linebreak()#text(" This is still nevertheless provides an extraordinarily high degree of certainty, and in particular far more than one would expect from any real-world application of a mathematical model. Plus, in practice, most useful theorems in mathematics, once they are understood properly, can be phrased and proven in much weaker systems than ZFC, so the consistency of ZFC itself is usually irrelevant. This is not quite the same thing as having absolute certainty in the correctness of the theorem, but it is more than good enough for almost all purposes outside of philosophy and metamathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d94d29934c6997587c92e70bbccd18aa130883c4196421d5e805d85e98860074-b74cd49f088ffd1e6c0a16b5d0bf7f7b197c9a0fdb2aa060df95f99da2b7afca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vivek Kaul")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-41941")[#strong[#text("Vivek Kaul")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2009")])]

#text("Thank you for your very informative answer. I generally had these confusions because many mathematics of the bygone era were Platonists who believed more in the reality of mathematical objects than physical things. I read a quote, ” Most current mathematicians if questioned are formalists(finding useful tautologies) but they act as if they are Platonists”. Is there some truth to that?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7409ca8d550c9a965e0f335e4252d8a04a1464022eb482fd5a021310fd2f34a3-6915b793867709c20b99e0827abd75ba4ab06aa66ee6561f8f6c586b6e4f59e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harsha")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-41938")[#strong[#text("Harsha")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2009")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Thank you for your exposition of the proof – it has been very useful to me in my class!")

#text("I do have a general question – Suppose we know that $X_i$’s are IID, and $E \\| X_i \\| < \\infty$. Clearly the SLLN gives us convergence of $\\frac{S_n}{n}$ to $EX_i$ a.s. Can we also say something about $max_{1 \\leq i \\leq n} \\frac{S_i}{n}$?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-41942")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2009")])]

#text("I am not sure what you are looking for precisely; for instance, if the ")#mi("X_i")#text(" are non-negative, then ")#mi("\\max_{1 \\leq i \\leq n} \\frac{S_i}{n}")#text(" is just ")#mi("S_n/n")#text(". In the mean zero, finite variance case, perhaps the ")#link("http://en.wikipedia.org/wiki/Law_of_the_iterated_logarithm")[#text("law of the iterated logarithm")]#text(" may answer your question.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e65614f89cdaf1327c62a5e774bd2f6a615e17df71bd640792f34b626e02c17b-9eca4a06c60b89543bd8fd99e5515239470b966c0087fad58e5f60bebe8c8500.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FALAHA")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-42045")[#strong[#text("FALAHA")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2009")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I know the defintion of random fields but I don`t know the definition of harmonicale isotropic random fields, do u know it, please?")#linebreak()#text(" Another question please, the law of large numbers was not proved largely for random fields, so do u know in which cases that it is not proved?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c427697e25c7707a90c7593bc01bffd4588369001ad52b5e00f8904c9ab0f2dc-54dac43264562df635d6bf790d3b3df8de53cbd2525b44ace91728d68819e6e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of WillJ")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-42538")[#strong[#text("WillJ")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2009")])]

#text("Prof. Tao writes:")

#emph[#text("“Imagine a table in which the rows are all the possible points in the sample space (this is a continuum of rows, but never mind this), and the columns are the number n of trials, and there is a check mark whenever the empirical mean \\overline{X}_n deviates significantly from the actual mean {\\Bbb E} X. The weak law asserts that the density of check marks in each column goes to zero as one moves off to the right. The strong law asserts that almost all of the rows have only finitely many checkmarks. A double counting argument (or the Lebesgue dominated convergence theorem) then shows that the latter implies the former.”")]

#text("I don’t understand. Each row represents an outcome in the sample space. Each column represents a trial of the experiment. Right? (We assume, for purposes of the illustration, that our sequence of iid random variables is as follows: for any given outcome, all of the r.v.s assign the same number to that outcome; the different r.v.s correspond to the different trials. – Right?) Now where do we put the checkmarks? I can think of two possibilities of what you mean: 1) We imagine repeatedly running the experiment. Each trial gives us an outcome. If trial i gives us outcome j, then put a dot in (row j, column i) in our matrix. Now we take a look at what we have, and at each dot that we put in our matrix, we calculate the empirical mean up to that point (based on where that dot is and where the previous dots are), and if it’s significantly different from the actual mean, then we put a check-mark over that dot. If not, leave the dot be. (We don’t have to ever actually put dots; I just mentioned them for clarification.) But then a column can’t have more than one check-mark, so that must not be what you’re saying. Perhaps, then, you mean: 2) For EVERY cell in our matrix (every [row j, column i] combination), we take a look, do the calculations, and put a check-mark in that cell if, at that point, the empirical mean is significantly different from the actual mean. But that doesn’t make any sense, because the value of the empirical mean at any given cell depends on what the outcomes were in the previous trials, i.e. there’s no unique empirical mean that can be assigned to each cell in our matrix.")

#text("So I’m quite confused! The reason I’m interested: I’m trying to understand what exactly the SLOLN says (I think I already understand what the WLOLN says). My main source of confusion is: With regard to the event “the iid r.v.s converge to the constant r.v. always equal to the actual mean” (note that the SLOLN says that this event has probability 1), what is the sample space that this event is taken from? I think this is the issue the Anonymous guy was getting at, and I think your dice example (involving base-6 representations of numbers in [0,1]) was very nice (although I don’t understand your general, “non-ad-hoc” that preceded it: ")#emph[#text("“To construct a suitable sample space to hold an infinite collection of random variables, such as an infinite sequence of independent die rolls, one can take an inverse limit of the sample spaces associated to finite sequences of die rolls.”")]#text(" – I have some intuition as to what that might mean, and I can try reading up on “inverse limits” (which I never heard of until just now), but maybe you can elaborate on that).")

#text("I would really, really like to understand your 2-dimensional table idea, as I think it very nicely captures what I’m getting at, if I could just understand it!")

#text("(Oh, and many thanks!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-42543")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2009")])]

#text("Each row represents an infinite sequence ")#mi("X_1,X_2,X_3,\\ldots")#text(" of trials. Each column just indexes an integer ")#mi("n")#text(". A checkmark is placed at row ")#mi("X_1,X_2,X_3,\\ldots")#text(" and at column ")#mi("n")#text(" if the empirical mean ")#mi("\\frac{X_1+\\ldots+X_n}{n}")#text(" deviates significantly from the mean ")#mi("X")#text(".")

#text("Suppose for sake of concreteness that the ")#mi("X_n")#text(" represent the rolls of a six-sided die. Thus, one can imagine filling out the first n entries of one row by rolling a die n times, and recording the running means that one encounters in this process. To get the first n entries of another row, one has to make n fresh rolls.")

#text("Alternatively, as mentioned earlier, one can index the rows continuously by a real number x from 0 to 1, and use the base 6 representation ")#mi("x = 0.X_1X_2X_3\\ldots_6")#text(" to generate the samples that one is averaging over (let’s say that the dice are numbered from 0 to 5 rather than from 1 to 6 to make this representation work cleanly).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c427697e25c7707a90c7593bc01bffd4588369001ad52b5e00f8904c9ab0f2dc-54dac43264562df635d6bf790d3b3df8de53cbd2525b44ace91728d68819e6e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of WillJ")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-42547")[#strong[#text("WillJ")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2009")])]

#text("Ah, that makes perfect sense. Wahoo! Thank you so much!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 1: Concentration of measure « What’s new")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-43070")[#strong[#text("254A, Notes 1: Concentration of measure « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2010")])]

#text("[…] more sophisticated variant of this argument (which I gave in this earlier blog post, which also has some further discussion and details) gives Theorem 5 (Strong law of large numbers) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 0: A review of probability theory « What’s new")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-43093")[#strong[#text("254A, Notes 0: A review of probability theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2010")])]

#text("[…] more sophisticated variant of this argument (which I gave in this earlier blog post, which also has some further discussion and details) gives Theorem 5 (Strong law of large numbers) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-43116")[#strong[#text("pavel")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#text("Dear Prof. Tao,")

#text("regarding the following passage:")

#text("Happily, this choice works cleanly; … we have the pointwise estimates")#linebreak()#text(" ")#mi("\\sum_{j=1}^\\infty \\frac{1}{n_j} X_{\\leq n_j} = O( X )")#text(",")

#text("doesn’t one rather need O(1) to infer")#linebreak()#text(" ")#mi("\\sum_{j=1}^\\infty \\frac{1}{n_j} X_{\\leq n_j}^2 = O(X)")#text("?")

#text("It is obtained in essentially the same way, replacing the estimates ")#mi("n_j > C c^j")#text(" by ")#mi("n_{a+j} > n_a c^j")#text(", where a is the first index with ")#mi("X \\leq n_a")#text(".")

#emph[#text("[Oops! Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-43315")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2010")])]

#text("Pavel, can you please post as to how we obtain the ")#mi("O(X)")#text(" results.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9905170e7bf5d1ce4e865e4251cf95bf15a62522993bf416dda1b21bb3520ef1-2a6654d83a05f68847e0b7a0a08db633541d51653c732b28edc23af909de7f7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hans")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-44097")[#strong[#text("Hans")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2010")])]

#text("Dear Prof. Tao:")

#text("Could you please illuminate in more detail the two statements in Remark 2:")#linebreak()#text(" 1. “this random variable (barely) has finite first moment, but for , we see that deviates by at least absolute constant from its mean with probability .”")#linebreak()#text(" 2. “As the empirical means for are now jointly independent, the probability that one of them deviates significantly is now extremely close to 1 (super-exponentially close in , in fact)”")

#text("Thank you very much in advance!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-44871")[#strong[#text("The Khinchine Law of Large Numbers | The Longboat and the Otter")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2010")]

#text("[…] ")#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/")[#text("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e64b37470c2f1b3a4b4a69fd3437b3a087ffb6423974c1169ceee55ac72481-d42be15bd53754fcc449f3c9a16d337cd279cfd1559c5295eb1a174b5717dfaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Russell Lyons")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-46554")[#strong[#text("Russell Lyons")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2010")])]

#text("Hi, Terry.")

#text("I just happened across this post. I have two small comments:")

#text("1. For the proof of the Borel-Cantelli lemma, one can simply observe that since the expectation of the sum of indicators is finite, so is the sum itself a.s. For some reason, it has been more popular to do it your way (i.e., using Markov’s inequality).")

#text("2. For those who are interested in refinements of the interpolation method that apply to weakly dependent random variables under a second moment condition, I can suggest an old paper of mine: Strong laws of large numbers for weakly correlated random variables, Mich. Math. J. 35, No. 3 (1988), 353–359 (")#link("http://projecteuclid.org/DPubS?service=UI&version=1.0&verb=Display&handle=euclid.mmj/1029003816")[#text("http://projecteuclid.org/DPubS?service=UI&version=1.0&verb=Display&handle=euclid.mmj/1029003816")]#text(").")

#text("Best,")#linebreak()#text(" Russ")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3577e0971731694200697a346bb2e95eae2bc5d3018d4957ce9004dc35ae695-2be40796d4d1cbd65f416835854cb2ed3b96e5086494be0c8f34889842c52e00.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lkozma")]], [#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-70948")[#strong[#text("lkozma")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2011")])]

#text("Thank you for the clear and informative post!")

#text("The formula for linearity of expectation shouldn’t have parentheses on the left side?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/comment-page-1/#comment-70957")[#strong[#text("The law of large numbers and the central limit theorem | Nair Research Notes")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2011")]

#text("[…] central limit theorem (CLT). There are excellent resources on the net for LLN and CLT. For example, this and this are highly recommended readings. This blog will play a complementary with figures and […]")
]
