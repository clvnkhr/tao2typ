// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/01/11/some-recent-papers/
// Converted to Typst by tao2typ: "2026-10-14T16:38:40.783373+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Some recent papers", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Some recent papers")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 January 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/01/11/some-recent-papers/")[#text("https://terrytao.wordpress.com/2020/01/11/some-recent-papers/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a brief post to record some notable papers in my fields of interest that appeared on the arXiv recently.")

#list(
[#text("“")#link("https://arxiv.org/abs/1909.10693")[#text("A sharp square function estimate for the cone in ")#mi("{\\bf R}^3")]#text("“, by ")#link("http://math.mit.edu/~lguth/")[#text("Larry Guth")]#text(", ")#link("http://hongwang.mit.edu/")[#text("Hong Wang")]#text(", and ")#link("https://sites.google.com/view/ruixiang-zhang/home")[#text("Ruixiang Zhang")]#text(". This paper establishes an optimal (up to epsilon losses) square function estimate for the three-dimensional light cone that was essentially ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1168960")[#text("conjectured by Mockenhaupt, Seeger, and Sogge")]#text(", which has a number of other consequences including ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1098614")[#text("Sogge’s local smoothing conjecture")]#text(" for the wave equation in two spatial dimensions, which in turn implies the (already known) Bochner-Riesz, restriction, and Kakeya conjectures in two dimensions. Interestingly, modern techniques such as polynomial partitioning and decoupling estimates are not used in this argument; instead, the authors mostly rely on an induction on scales argument and Kakeya type estimates. Many previous authors (including myself) were able to get weaker estimates of this type by an induction on scales method, but there were always significant inefficiencies in doing so; in particular knowing the sharp square function estimate at smaller scales did not imply the sharp square function estimate at the given larger scale. The authors here get around this issue by finding an even stronger estimate that implies the square function estimate, but behaves significantly better with respect to induction on scales.")],
[#text("“")#link("https://arxiv.org/abs/1808.04001")[#text("On the Chowla and twin primes conjectures over ")#mi("{\\mathbb F}_q[T]")]#text("“, by ")#link("https://williamsawin.com/")[#text("Will Sawin")]#text(" and ")#link("https://markshus.wixsite.com/math")[#text("Mark Shusterman")]#text(". This paper resolves a number of well known open conjectures in analytic number theory, such as the Chowla conjecture and the twin prime conjecture (in the strong form conjectured by Hardy and Littlewood), in the case of function fields where the field is a prime power ")#mi("q=p^j")#text(" which is fixed (in contrast to a number of existing results in the “large ")#mi("q")#text("” limit) but has a large exponent ")#mi("j")#text(". The techniques here are orthogonal to those used in recent progress towards the Chowla conjecture over the integers (e.g., in ")#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/")[#text("this previous paper of mine")]#text("); the starting point is an algebraic observation that in certain function fields, the Mobius function behaves like a quadratic Dirichlet character along certain arithmetic progressions. In principle, this reduces problems such as Chowla’s conjecture to problems about estimating sums of Dirichlet characters, for which more is known; but the task is still far from trivial.")],
[#text("“")#link("https://arxiv.org/abs/1909.00309")[#text("Bounds for sets with no polynomial progressions")]#text("“, by ")#link("http://stanford.edu/~speluse/")[#text("Sarah Peluse")]#text(". This paper can be viewed as part of a larger project to obtain quantitative density Ramsey theorems of Szemeredi type. For instance, Gowers famously established a relatively good quantitative bound for ")#link("https://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("Szemeredi’s theorem")]#text(" that all dense subsets of integers contain arbitrarily long arithmetic progressions ")#mi("a, a+r, \\dots, a+(k-1)r")#text(". The corresponding question for polynomial progressions ")#mi("a+P_1(r), \\dots, a+P_k(r)")#text(" is considered more difficult for a number of reasons. One of them is that dilation invariance is lost; a dilation of an arithmetic progression is again an arithmetic progression, but a dilation of a polynomial progression will in general not be a polynomial progression with the same polynomials ")#mi("P_1,\\dots,P_k")#text(". Another issue is that the ranges of the two parameters ")#mi("a,r")#text(" are now at different scales. Peluse gets around these difficulties in the case when all the polynomials ")#mi("P_1,\\dots,P_k")#text(" have distinct degrees, which is in some sense the opposite case to that considered by Gowers (in particular, she avoids the need to obtain quantitative inverse theorems for high order Gowers norms; which was recently obtained in this integer setting ")#link("https://arxiv.org/abs/1811.00718")[#text("by Manners")]#text(" but with bounds that are probably not strong enough to for the bounds in Peluse’s results, due to a degree lowering argument that is available in this case). To resolve the first difficulty one has to make all the estimates rather uniform in the coefficients of the polynomials ")#mi("P_j")#text(", so that one can still run a density increment argument efficiently. To resolve the second difficulty one needs to find a quantitative ")#link("https://terrytao.wordpress.com/2016/03/27/concatenation-theorems-for-anti-gowers-uniform-functions-and-host-kra-characteristic-factors-polynomial-patterns-in-primes/")[#text("concatenation theorem")]#text(" for Gowers uniformity norms. Many of these ideas were developed in previous papers of ")#link("https://arxiv.org/abs/1802.02200")[#text("Peluse")]#text(" and ")#link("https://arxiv.org/abs/1903.02592")[#text("Peluse-Prendiville")]#text(" in simpler settings.")],
[#text("“")#link("https://arxiv.org/abs/1912.11005")[#text("On blow up for the energy super critical defocusing non linear Schrödinger equations")]#text("“, by ")#link("https://www.ihes.fr/en/professeur/frank-merle-2/")[#text("Frank Merle")]#text(", ")#link("https://math.unice.fr/~praphael/")[#text("Pierre Raphael")]#text(", ")#link("https://www.math.princeton.edu/people/igor-rodnianski")[#text("Igor Rodnianski")]#text(", and ")#link("https://www.ljll.math.upmc.fr/szeftel/index.html.fr")[#text("Jeremie Szeftel")]#text(". This paper (when combined with two companion papers) resolves a long-standing problem as to whether finite time blowup occurs for the defocusing supercritical nonlinear Schrödinger equation (at least in certain dimensions and nonlinearities). I ")#link("https://terrytao.wordpress.com/2016/12/05/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-schrodinger-system/")[#text("had a previous paper")]#text(" establishing a result like this if one “cheated” by replacing the nonlinear Schrodinger equation by a system of such equations, but remarkably they are able to tackle the original equation itself without any such cheating. Given the very analogous situation with Navier-Stokes, where again one can create finite time blowup by “cheating” and modifying the equation, it does raise hope that finite time blowup for the incompressible Navier-Stokes and Euler equations can be established… In fact the connection may not just be at the level of analogy; a surprising key ingredient in the proofs here is the observation that a certain blowup ansatz for the nonlinear Schrodinger equation is governed by solutions to the (compressible) Euler equation, and finite time blowup examples for the latter can be used to construct finite time blowup examples for the former.")]
)

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcc8946f803e2fd7a6157d43b3a347a85dfdccc1a772a4fe526012aa745e91ff-b32507acb466766f9be1685d880c057ea5d929c88b1bbb6a4e287c2627f485ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Fry")]], [#link("https://terrytao.wordpress.com/2020/01/11/some-recent-papers/#comment-535854")[#strong[#text("David Fry")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2020")])]

#text("Hello Terry, Thank you for your Commentary regarding papers that you receive….very interesting reading. Very Sincerely, David")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7957985b0f72f7f296d99bc81a4cd8179b431df06c5cbd6810b16269f6d14289-da60cc5610988b07c97bcaf07ca1c26b617a1fdf1abafcbe47323e365b67c575.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2020/01/11/some-recent-papers/#comment-536121")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2020")])]

#text("There seems to be a lot of excitement in complexity theory/operator algebra, by a very recent paper that solves the 30y old “Connes’ embedding conjecture”. While there is a very good quanta article on the complexity-theoretical importance of a previous result (")#link("https://www.quantamagazine.org/computer-scientists-expand-the-frontier-of-verifiable-knowledge-20190523/")[#text("https://www.quantamagazine.org/computer-scientists-expand-the-frontier-of-verifiable-knowledge-20190523/")]#text("), i would be extremly interested in the operator-algebra significance of this, especially what is the “Connes’ embedding conjecture”, why is it important, and what is the consequence of its refutation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7957985b0f72f7f296d99bc81a4cd8179b431df06c5cbd6810b16269f6d14289-da60cc5610988b07c97bcaf07ca1c26b617a1fdf1abafcbe47323e365b67c575.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2020/01/11/some-recent-papers/#comment-536134")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2020")])]

#text("The arxiv link to the paper is: ")#link("https://arxiv.org/abs/2001.04383")[#text("https://arxiv.org/abs/2001.04383")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/144f43f2622a820b1a5b3140a462f08b2d2d97f6c39f08ac9f7cdc72f8663c77-3a11ea8c3f027dac6b5cc71d09389f7a4fe474aedc5f53530937996f517b6e1d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of danielvoconnor")]], [#link("https://terrytao.wordpress.com/2020/01/11/some-recent-papers/#comment-536649")[#strong[#text("danielvoconnor")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2020")])]

#text("Fascinating progress on the Navier-Stokes finite-time blow up problem.")
]
