// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/
// Converted to Typst by tao2typ: "2026-10-14T15:18:47.576009+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath8: Writing the paper, II", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath8: Writing the paper, II")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 September 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/")[#text("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The main purpose of this post is to roll over the discussion from the ")#link("https://terrytao.wordpress.com/2013/08/17/polymath8-writing-the-paper/")[#text("previous Polymath8 thread")]#text(", which has become rather full with comments. As with the previous thread, the main focus on the comments to this thread are concerned with writing up the results of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8 “bounded gaps between primes” project")]#text("; the latest files on this writeup may be found at ")#link("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/_5Sn7mNN3T")[#text("this directory")]#text(", with the most recently compiled PDF file (clocking in at about 90 pages so far, with a few sections still to be written!) being found ")#link("https://www.dropbox.com/s/16bei7l944twojr/newgap.pdf")[#text("here")]#text(". There is also still some active discussion on improving the numerical results, with a particular focus on improving the sieving step that converts distribution estimates such as ")#mi("MPZ^{(i)}[\\varpi,\\delta]")#text(" into weak prime tuples results ")#mi("DHL[k_0,2]")#text(". (For a discussion of the terminology, and for a general overview of the proof strategy, see this ")#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/")[#text("previous progress report")]#text(" on the Polymath8 project.) This post can also contain any other discussion pertinent to any aspect of the polymath8 project, of course.")

#text("There are a few sections that still need to be written for the draft, mostly concerned with the Type I, Type II, and Type III estimates. However, the proofs of these estimates exist already on this blog, so I hope to transcribe them to the paper fairly shortly (say by the end of this week). Barring any unexpected surprises, or major reorganisation of the paper, it seems that the main remaining task in the writing process would be the proofreading and polishing, and turning from the technical mathematical details to expository issues. As always, feedback from casual participants, as well as those who have been closely involved with the project, would be very valuable in this regard. (One small comment, by the way, regarding corrections: as the draft keeps changing with time, referring to a specific line of the paper using page numbers and line numbers can become inaccurate, so if one could try to use section numbers, theorem numbers, or equation numbers as reference instead (e.g. “the third line after (5.35)” instead of “the twelfth line of page 54”) that would make it easier to track down specific portions of the paper.)")

#text("Also, we have set up ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath8_grant_acknowledgments")[#text("a wiki page")]#text(" for listing the participants of the polymath8 project, their contact information, and grant information (if applicable). We have two lists of participants; one for those who have been making significant contributions to the project (comparable to that of a co-author of a traditional mathematical research paper), and another list for those who have made auxiliary contributions (e.g. typos, stylistic suggestions, or supplying references) that would typically merit inclusion in the Acknowledgments section of a traditional paper. It’s difficult to exactly draw the line between the two types of contributions, but we have relied in the past on self-reporting, which has worked pretty well so far. (By the time this project concludes, I may go through the comments to previous posts and see if any further names should be added to these lists that have not already been self-reported.)")

#heading(level: 1)[#text("Comments (132)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-245167")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2013")])]

#text("There may be a case for closing (or highlighting, if it can’t be easily closed) one further ostensible open door, relating to Remark 7.10. That Remark arises from Terry’s post ")#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/#comment-243825")[#text("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/#comment-243825")]#text(" in which he established, after more detailed inspection, that the initially promising-looking use of Type II methods to establish a Type I constraint that works for some positive varpi unfortunately requires either a value of sigma too low to avoid the Type III case or else a Type II “level” (namely 4) that makes the overall complexity of the proof comparable to that of the Deligne-free Type I argument. However, what is not clear at first sight is whether elevation of the Type II arguments all the way through the unexplored levels 4, 5 and 6 has any chance of translating into Type I numerology that improves on the current best Type I constraint. It might be worth mentioning something about this option: if it can be easily disposed of by means that I have overlooked then maybe a sentence in Remark 7.10 would suffice, but otherwise it arguably merits a new paragraph in Section 11.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-245174")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2013")])]

#text("Quick addendum: I guess that, for completeness, any such comment might best also note (if only to dismiss) the possibility that the repurposing of Type II methods to the Type I setting could be performed by more elaborate but numerically superior (in terms of the varpi thereby obtained) means than the replacement specified at the beginning of Remark 7.10.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-245250")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2013")])]

#text("Line 2 of Sec 4.5 should refer to Section 4.4, not 4.5.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-245282")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2013")])]

#text("1. 2nd display above (5.8), under the summation symbol, ")#mi("N_2j")#text(" should be ")#mi("N_{2j}")#text(".")#linebreak()#text(" 2. Next display, in the middle of convolution, ")#mi("\\psi_{N_1}")#text(" should be ")#mi("\\psi_{N_{j+1}}")#text("?")#linebreak()#text(" 3. 6 lines above Sec 6.1, ")#mi("\\frac0{ab}")#text(" should be ")#mi("\\frac0b")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7da92334e831b1e37ac872e6549963149bfa6a1bed45c21fe8c761bbc5ef7432-e5964d7f3a3f6779443cd49024bb8752f3675f337475511232b03e6dcd82c926.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RO'D")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-245373")[#strong[#text("RO'D")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2013")])]

#text("Katz’s name appears weirdly in [44] in the bibliography")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-245404")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2013")])]

#text("1 line above (and also 5 lines below) (6.8), is it ")#mi("p \\nmid f^{\\prime}")#text("?")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-245522")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2013")])]

#text("The exact expression for ")#mi("\\kappa_3")#text(" has a probabilistic interpretation from which I found a new upper bound for ")#mi("\\kappa_3")#text(". I’m checking now the implication of this bound on ")#mi("k_0")#text(". I’ll send tomorrow the derivation of the new bounds for ")#mi("\\kappa_1, \\kappa_2, \\kappa_3")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-245523")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2013")])]

#text("(6.15) through (6.16), all the ")#mi("\\Psi_{M,q}")#text(" should perhaps be ")#mi("\\psi_{M,q}")#text("? (not the final ")#mi("\\Psi(h)")#text(")")#linebreak()#text(" Right underneath, the interval should be (q/2, q/2].")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-245609")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2013")])]

#text("While working on the Deligne section of the paper, I discovered that it is possible to avoid explicitly using the deep theorem of Deligne, Laumon, and Katz which roughly speaking asserts that the Fourier transform of an admissible (Fourier) sheaf is again an admissible sheaf, with bounds on the conductor. To recall, the only place where we use this fact (other than in taking as a black box the existence of hyper-Kloosterman sheaves) is to establish square root cancellation for the sums ")#mi("\\sum_x K_f(x;p) \\psi(hx)")#text(" and ")#mi("\\sum_x K_f(x;p) \\overline{K_f(x+l;p)}\\psi(hx)")#text(" where")

#mi("K_f(x;p) = \\frac{-1}{p^{1/2}} \\sum_y \\psi( \\frac{1}{(y+ax+b)(y+cx+d)}+ey)")#text(".")

#text("To do this we observed that the Fourier transform of ")#mi("K_f")#text(" was basically ")#mi("Kl_3")#text(" pulled back by a quadratic function, and then used Deligne-Laumon-Katz to write ")#mi("K_f")#text(" as the trace weight for an admissible sheaf with bounded conductor.")

#text("But if we take the Fourier transform first, we observe that the desired square root cancellation is equivalent to square root cancellation for ")#mi("FT(K_f)(h)")#text(" and ")#mi("\\sum_x FT(K_f)(x) FT(K_f)(x+h) \\psi(lx)")#text(". So actually we don’t need ")#mi("K_f")#text(" to be a good trace weight, it’s enough for ")#mi("FT(K_f)")#text(" to be a good trace weight. Basically, we only need to perform Fourier transforms on the analytic side, not on the sheaf-theoretic side.")

#text("The way the paper is currently structured, though, it’s a bit tricky to take advantage of this simplification (and the simplification is modest from a length perspective, one can basically delete Section 8.6 and rewrite some subsequent theorems and proofs a little bit). Perhaps it is better to leave the structure of the paper as is but add a remark that one can avoid Deligne-Laumon-Katz if one really wanted to (but one still needs to construct the hyper-Kloosterman sheaf Kl_3, so one can’t escape DLK-type machinery completely).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe Michel")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-245617")[#strong[#text("Philippe Michel")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2013")])]

#text("That is absolutely true ! and in fact I have written a first more elementary version of the proof as you suggest using Parseval to make the computation on the dual Fourier side (one can probably see this from digging through the older versions of deligne.tex in the dropbox folder; I will look to exhume it tomorrow); however I have chosen over the week-end to go for the stronger version -that the function itself is a trace function rather than only its fourier transform- after Friday discussions with Paul: indeed one could try to look for further improvement by exploiting averaging over some other parameters ($l$ for instance which for some configurations could be long enough wrt the factorization of $u$ – in place to do the vdc-method on the d variable- to perform a Polya-vinogradov completion on the other).")

#text("This explain also why the new proof is a bit less soft as its make explicit the dependency in the additional parameters of $f(x,y)$ ($a,b,c,d,e$) which are potentially going to vary. It is not clear whether this will work or whether this would be really worth the effort but at least part of the necessary material will be in place if necessary (and more importantly this is geometrically fun !). I think it is also good to keep with the stronger version because there might be other manipulations which do not rely on correlation of two functions ( admissible to Fourier analysis or iteration thereof) but on multiple -say quadruple type- correlation for which I don’t see how the Parseval could be applied (see the second Fouvry-Iwaniec paper in the list of references for an example).")

#text("And as you say we are already using serious stuff anyway. Another thing is that now the vdC method has been fully axiomatized to general statement (Prop 8.19 in which the initial datum are the trace functions and their sheaves) which could used by other for other problems")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-245626")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2013")])]

#text("Yes, I agree that the current setup (based on the sheaf interpretation of the function itself rather than the Fourier transform) is more conceptually natural and better suited for future improvements; I’ve added a remark about the alternate route at Remark 8.19 and made some other small tweaks (e.g. taking advantage of symmetries to reduce the amount of calculation needed to compute the Fourier transform of K_f) but kept the overall structure unchanged.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-245830")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2013")])]

#text("Another reason to keep the Fourier transform is that, in fact, the existence / admissibility / conductor bound for the Fourier transform at the level we need can be done using arguments which are really quite a bit easier than the Riemann Hypothesis, as done in Section 8 of our preprint on conductor bounds")

#link("http://www.math.ethz.ch/~kowalski/transforms.pdf")[#text("Click to access transforms.pdf")]

#text("I think that the only thing needed in Polymath8 that this write-up does not explicitly state is the stability of (geometric) irreducibility, but this can be checked by the Plancherel formula and the “diophantine criterion for irreducibility” of Katz which we already state anyway (Lemma 5.10 in the paper; this depends on the Riemann Hypothesis). I’ll add this as an extra remark.")

#text("This does not give the full local analysis of singularities of the Fourier transform, but for most analytic applications, it will certainly be sufficient.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-245855")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2013")])]

#text("small typo: in 6th display of sec 9, “K;” should be “Kl”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8: Writing the paper, III | What's new")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-246101")[#strong[#text("Polymath8: Writing the paper, III | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2013")])]

#text("[…] main purpose of this post is to roll over the discussion from the previous Polymath8 thread, which has become rather full with comments. We are still writing the paper, but it appears to […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-246102")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2013")])]

#text("I’m doing the usual rollover to refresh the thread; any comments on the polymath project that are not direct responses to comments already here should be made at the ")#link("https://terrytao.wordpress.com/2013/09/22/polymath8-writing-the-paper-iii/")[#text("new thread")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d841279bde782b1cb2e7ccda53cc7961fc14ed2c90a8bc7731bb0c74350c951-eee14fee51eb44b15d62bce8c494cea0959e98139d76d125f021dd3452b6c425.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Check in with Yitang Zhang « Pink Iguana")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-246678")[#strong[#text("Check in with Yitang Zhang « Pink Iguana")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2013")])]

#text("[…] Polymath8: Writing the paper, II, here. III, here. The paper is quite large now (164 pages!) but it is fortunately rather modular, and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-507345")[#strong[#text("Ella Berum")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2018")]

#strong[#text("Polymath8: Writing the paper, II | What")]

#text("[…]The church today doesn’t need more programs")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-682733")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2024")])]

#text("As of 2024, all links in all polymath 8 related blog posts are broken. Is the paper published?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2be76d3f5c82400d367efd97f880daaf8d1a6a8987179bc02c182c3f34e4f52-715cedba2053857997ee87d022f4b1f2922fe411478b5905355ce861a1fc34b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of frobitz13")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-2/#comment-682734")[#strong[#text("frobitz13")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2024")])]

#text("The first paper (from polymath8a) is here:")#linebreak()#text(" ")#link("https://msp.org/ant/2014/8-9/p03.xhtml")[#text("https://msp.org/ant/2014/8-9/p03.xhtml")]

#text("The second paper (from polymath8b) is here: ")#link("https://link.springer.com/article/10.1186/s40687-014-0012-7")[#text("https://link.springer.com/article/10.1186/s40687-014-0012-7")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d237734601a7d85b4cffe5c4519aac8701f09d2fdf68bb395c00640527f34c69-33a9827158339acda6b8a86b2f324a71128713d4ad40c58ea81ec561b9a55e26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of somedude")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243676")[#strong[#text("somedude")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2013")])]

#text("Wouldn’t it be easier to setup a git repo and then you can refer to equation (31) of git version a1234?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdb75f651694fa4590541597357dbadfd385fd8cdff69158fca4646dfe99258b-759b6d1425186e16402269c6b61abd76205372b240bd6980ec2cc0202b785666.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of someotherdude")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243696")[#strong[#text("someotherdude")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2013")])]

#text("When I am a world famous professor nearing forty years old with a family, I will start spending my remaining spare time to learn how to use new version control software.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243720")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2013")])]

#text("I have used git (and also Subversion) in previous collaborations, and did weigh all three options when deciding how to set up the repository. There is a definite tradeoff here between ease of use/reliability (particularly among casual users of this sort of technology) versus powerful functionality, with Dropbox at the former end of the spectrum, git at the latter, and Subversion in between. (In previous Polymath projects, we also experimented with shared Google documents and even the Polymath wiki, but these platforms were decidedly unsatisfactory for this purpose.)")

#text("Personally, Subversion happens to be my preferred platform for most of my collaborative writing projects, being easier to set up (and easier to troubleshoot) than git, but with more version control functionality (e.g. merging, update annotation, and rollback) than Dropbox. My experience with git has been that while there are some advantages to that platform (particularly with regard to merging and with writing offline), the decentralised git model is not initially intuitive to grasp, and did cause a number of inconveniences for me when I started using it (for instance, I spent a while only updating my local repository and not pushing it out to a repository shared with my co-author, leading to a certain amount of confusion; also, when I switched to a new laptop, I had a non-trivial amount of difficulty in synchronising the repositories).")

#text("In the end, I went with Dropbox as being ")#link("http://en.wikipedia.org/wiki/Principle_of_good_enough")[#text("good enough")]#text(" for this particular project, as it is extremely easy to set up and very reliable, with the files in the repository easily accessible to casual participants. (It is true that older versions of files cannot be accessed in this way, but I view this as a minor inconvenience only, since as mentioned in the post above we can simply use other references than page numbers to locate various pieces of text, and there is little need for us to refer to outdated versions of the text.) Currently we have five people actively editing the Dropbox files, plus several more contributing corrections and suggestions; as with other Polymath projects, the set of participants is not known in advance, and in particular I did not know what version control platforms the participants were already comfortable with (not all mathematicians are “early adopters” of technology). As such, ease of use became a more significant concern than functionality, and this was the deciding factor in my choice to use Dropbox. (Also, the platforms are not completely exclusive; I know that one of the editors is synchronising the Dropbox folder with a local Subversion repository, for instance.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243713")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2013")])]

#text("Two lines before Lemma 6.7, Polyá should be Pólya. In footnote 12, Weil should be Weyl, and the same typo occurs where the footnote is called.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243714")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2013")])]

#text("In the abstract, Revesz should be Révész.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243739")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2013")])]

#text("A brief update on where I’m at with the editing; I’m currently working on the pre-Deligne Type I/II estimates (typei-ii.tex), and plan to turn to the post-Deligne Type I estimate (typei-advanced.tex) next, which may require some coordination with Phillippe and Emmanuel who have been working on deligne.tex. Since all three of the Type I/II estimates we prove (the pre-Deligne Type I, the pre-Deligne Type II, and the post-Deligne Type I estimate) all involve the same initial reductions to a certain exponential sum estimate, I have decided to perform the reductions in a unified manner, and then estimate the three resulting exponential sums separately. This part of the paper may need some polishing, particularly with regards to the motivation of why we perform various manipulations in the argument; we are of course following Zhang’s argument in many places, but we can add some further commentary (e.g. motivating the dispersion method).")

#text("I’m not going to touch the other files much for now, although I do plan to collect a number of estimates on the divisor function (which were called “crude estimates” in previous blog posts) that end up being used repeatedly throughout the paper and place them in a lemma near the start of the paper (right now, each one is basically appearing next to where they are first used).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243740")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2013")])]

#text("In chap. 8, it is not clear why the standard symbol “")#mi("\\neq")#text(" appears differently.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243841")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2013")])]

#text("Hmm, this seems to be a result of multiple authors working on the paper :) Some of the authors prefer ")#mi("\\not=")#text(" ($\\not =$) to ")#mi("\\neq")#text(" ($\\neq$), though strangely both versions look identical in this blog’s LaTeX renderer. This is of course a trivial issue, but I guess we should standardise it before we finalise the paper. (On a related note is the question of whether to use American English or Commonwealth English for the text; given that (as far as I am aware) I am the only active participant initially from a Commonwealth country, I am happy to defer here to the American English standard.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243762")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2013")])]

#text("It is probably better to put Definition 1.6 before Lemmas 1.4 and 1.5, since they already use these notations.")

#emph[#text("[Good point; I’ve moved the definition up a bit. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5abba5dd562f9355e60dc4c9893442e683e37151512bafa0a62957a87138f8ac-758fe84da47080c2384192dc09d20727c346092a341b0ed9fcbbbdf425655802.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243783")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2013")])]

#text("In the paragraph following the statement of Theorem 2.3: “… for selected values of H …” should be “… for selected values of k_0 …”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243825")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2013")])]

#text("An update on a claim I had made previously, stating that the proof of the Type II estimate could be modified to give enough Type I estimates to give a proof of Zhang’s theorem that would be marginally shorter than the current “minimal proof”, albeit with a worse value of H. It turns out that the story is more complicated than this. If one adapts the Type II argument (which currently does not use the q-van der Corput A-process) to the Type I case, it turns out one gets Type I estimates whenever ")#mi("48\\varpi+14\\delta+10\\sigma<1")#text(". However, this is not useful for us because ")#mi("\\sigma")#text(" needs to be at least as large as 1/10. If one uses the q-van der Corput A-process once (which is what one is currently doing for the existing Deligne-free Type I estimate), the numerology improves to ")#mi("56 \\varpi+16\\delta+6\\sigma <1")#text(", which allows ")#mi("\\sigma")#text(" to exceed 1/10 but not 1/6. So one would still need some Type III estimates to close the argument. In order to raise ")#mi("\\sigma")#text(" above 1/6 one would need to apply van der Corput twice instead of once; this could be done and would lead to some non-trivial range of ")#mi("MPZ[\\varpi,\\delta]")#text(", but this argument is not unambiguously simpler than the existing argument (requiring, among other things, double dense divisibility). I will still add a remark about this in the section of Type I/II estimates, though.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243887")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("Thank you again Terry. (Note that the words “substitute for” are duplicated in line 4 of Remark 7.10 as currently written.) Relating this back to earlier discussions, am I correct in saying that this essentially means that one would need to elevate the Type II analysis to what was termed “Level 4” on the wiki before (or in conjunction with) adapting it to work as a Type I argument? I ask because of the two additional levels (5 and 6) applicable to Type II that were not explored yet; can we say that those levels do not meaningfully alter what you say here (e.g. because they can’t be applied without first applying Level 4, or because they won’t alter the numerology in a manner allowing sigma to exceed 1/6, or because they too would make the overall argument cease to be appreciably simpler than it already is)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243934")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("Yes, this is what one would have to do to make the Type II argument stretch to cover all cases. What I elected to do instead is to insert into the paper an older Type I estimate (what we called “Level 3” estimates, in contrast to the “Level 6” and “Level 5” Type I estimates that are the best we have in the Deligne-free and Deligne-using settings respectively). When paired with the existing Type II estimate, this gives a slightly simpler proof of Zhang’s theorem (and also the older Type I estimate can be used to motivate the more complicated Type I estimates we have).")

#text("I’ve finished with typei-ii.tex for now and will move on to typeiii.tex (basically importing what I wrote for the blog on this) before handing that section off to Philippe. While entering in the Type I and II arguments I discovered some minor errors in previous text (there were some factors of ")#mi("x^\\varepsilon")#text(" that were misplaced in the completion of sums step) but fortunately they did not affect the numerology.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243937")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("OK, I have pasted in the type III arguments, which ended up being easier than anticipated. I had to modify deligne.tex slightly to do so (the hyper-Kloosterman correlation estimate I needed was not quite there already). I noticed that the notation for the hyperKloosterman sum was a little different from what I expected (indexed by a field instead of a modulus, which makes sense in the prime power case but maybe not so much for the composite modulus case). Anyway it should be checked for notational consistency.")

#text("The Type III argument is unfortunately a lot messier than the clean sketch that Philippe provided some time ago. This is partly because we are also taking advantage of averaging in the “m” parameter, and partly because there are some complications due to the fact that we cannot always guarantee certain moduli to be coprime to each other. It may make sense to provide a sketch of a Type III argument (along the lines of the original sketch in ")#link("http://blogs.ethz.ch/kowalski/2013/06/25/a-ternary-divisor-variation/")[#text("http://blogs.ethz.ch/kowalski/2013/06/25/a-ternary-divisor-variation/")]#text(" , or perhaps my comment at ")#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236652")[#text("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/#comment-236652")]#text(" . Actually with regards to the latter, it may make sense to discuss how the type III approach given here does not seem to give good numerology for Type IV or Type V sums.)")

#text("Anyway, I’m “releasing” typeiii.tex (and deligne.tex) so that Philippe may work on it next; I’ll turn to typei-advanced.tex next. The paper is already at 124 pages and may eventually top out at 140-150 pages!")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PhM")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243969")[#strong[#text("PhM")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("I noticed that the notation for the hyperKloosterman sum was a little different from what I expected (indexed by a field instead of a modulus, which makes sense in the prime power case but maybe not so much for the composite modulus case). Anyway it should be checked for notational consistency.")#linebreak()#text(" ———————————-")#linebreak()#text(" I think we can safely switch to dependency in p only: the dependency in the field was in anticipation to checking that the sheaf in the improved type I estimate had no quadratic phase for which we would have needed to use Hooley over all finite extensions result (in fact that could have been avoided using the geoemtric reformulation of that result in Katz’s Orsay lectures and spectral sequences arguments) but since we have now a simpler alternative treatment of the prime modulus type I+ sum we can work only with the base field F_p only and write the dependency as that of the modulus")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PhM")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243972")[#strong[#text("PhM")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("It may make sense to provide a sketch of a Type III argument (along the lines of the original sketch in….")#linebreak()#text(" ———")#linebreak()#text(" absolutely; maybe also displaying model cases for the treatment of type I, I+ and type II sums as well might be be a good option: maybe having all of them al together somewhere in an introductory section ()at the expense of making the paper even longer")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244035")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2013")])]

#text("Yes, this is a good idea. I’ll add a section giving heuristic proofs of the Type I/II and III estimates to the paper, after I have added in the advanced Type I estimate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244091")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2013")])]

#text("It may be helpful to add (perhaps in the introduction) a diagram showing the connections and implications among the important theorems (and perhaps also an index for nonstandard notations and definitions.)")

#emph[#text("[Good idea; I’ll try to add something in this direction. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244098")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2013")])]

#text("I added a figure (Figure 1) indicating the general logical flow of the argument, although I had to oversimplify a little bit.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243831")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2013")])]

#text("In the proofs of Proposition 8.10 and Theorem 8.17 (Pages 95 and 98), Parceval should be Parseval.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243837")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2013")])]

#text("I’ve added a comment comparing the type of estimates that Zhang (and we) prove to those proven in the earlier works of Bombieri, Fouvry, Friedlander, and Iwaniec in Remark 2.9, but I am not 100% confident in my understanding of the literature (and in particular whether there is additional work that should be cited here), as well as the relevance of the theory of automorphic forms (my understanding here is that most of the previous work uses this theory, but this also largely restricts them to the regime of a fixed modulus a). Anyway, if someone who is familiar with the literature would have a look at that remark that would be great.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PhM")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243971")[#strong[#text("PhM")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("Emmanuel and I can look through but certainly Fouvry will help on this")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244290")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2013")])]

#text("Typo: “fixed modulus a” —> “fixed residue class a”.")

#text("Concerning the remark, it is true that automorphic techniques, for the moment, can not deal with a maximum over the type of residue classes that arise in the Goldston-Pintz-Yildirim method.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243839")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2013")])]

#text("In the display before (7.19), ")#mi("\\overline{\\beta(n_1)}")#text(" should be ")#mi("\\beta(n_1)")#text(". (Actually this was part of #5 in ")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238890")[#text("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238890")]#text(" but it was missed somehow.)")

#text("I got busy with other things (e.g. semester starts), but hope to be able to go through the whole paper carefully when it becomes final.")

#emph[#text("[Corrected – and thanks for all your careful reading of the blog posts and texts! -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243847")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2013")])]

#text("Hi, I was wondering whether it would make sense to explicitly include an admissible 632-tuple of diameter 4680 in the paper, in addition to a reference to the k-tuples database? It’s an important proof ingredient, and it would make the article somewhat more self-contained. We could describe it as “start from the interval [a,b], sieve 1 mod 2, sieve 0 mod all primes p up to …” and so on. This would be a more compact description than just listing the numbers, and it would make it more easy for the reader to verify admissibility (I think a patient person could do it by hand). But it would still be a large ugly chunk of text, so that’s the consideration to be made here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243854")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2013")])]

#text("If there was indeed a compact description, that would be nice, though my understanding is that after the first few primes the sieve no longer follows a nice pattern. Another option is to attach a plaintext file of the tuple to the arXiv submission (I’ve not done this before but I assume it is straightforward to do – some journals also accept supplementary data files of this sort).")

#text("As “eye candy”, one could also try to represent the tuple as an image, perhaps in 23 or so rows of 210 pixels (in order to see the mod 2, 3, 5, and 7 structure), or perhaps some other arrangement would be more aesthetic. (The image I had in mind was something like ")#link("http://commons.wikimedia.org/wiki/File:Primes_-_distribution_-_up_to_3_x_17_primorial.png")[#text("http://commons.wikimedia.org/wiki/File:Primes_-_distribution_-_up_to_3_x_17_primorial.png")]#text(" or the images in ")#link("http://matheminutes.blogspot.com/2011/08/prime-numbers-why-all-fuss.html")[#text("http://matheminutes.blogspot.com/2011/08/prime-numbers-why-all-fuss.html")]#text(" ). But perhaps some other participants may have some more visually appealing ideas for picturing the tuple.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243870")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2013")])]

#text("One can give a pretty compact description by specifying the residue classes to sieve in the interval [0,4680]. For example sieving just the 25 residue classes:")

#text("1(2) 2(3) 1(5) 1(7) 3(11) 11(13) 7(17) 7(19) 9(23) 15(29) 13(31) 6(37) 16(41) 19(43) 21(47) 46(53) 27(59) 5(61) 31(67) 33(71) 23(73) 39(83) 47(89) 59(97) 74(193)")

#text("yields an admissible 632-tuple.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243871")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2013")])]

#text("A slightly more compact version would be: for the first 21 primes sieve the classes 1 2 1 1 3 11 7 7 9 15 13 6 16 19 21 46 27 5 31 33 23 (ordered by prime), then sieve 39(83) 47(89) 59(97) 74(193).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebf6302e0d67b9deb354cb529edbd8f475a6fb55a5003b472f23df7b4d2366db-94f09221f7fbaf3b999af5ef8cfb6585fd6f92f359eb736cee14b6634d7d2e7d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243943")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("Hi, I have now included the above example at the beginning of Section 3, just because it’s the most compact description and because it matches with the version in the prime tuples database (I think?). I’m not sure if it’s ok like this, it’s just a suggestion…")

#text("But Drew’s second example below is indeed more conceptual. We could include it as an example in the greedy Schinzel sieve part.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243944")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("The tuple in the database does not match either example, but that it is easily changed. My suggestion would be to use the second example I gave (in my Sep 5 message below). I can then update the tuple listed in the database to be the translation of that that tuple from [742,5246] to [0,4680].")

#text("I actually have a file with all 426 examples in it (this is the same number of tuples that Engelsma found for k=632 with diameter 4680, so it seems reasonable to think it is a complete list). We could also provide a link to this file if we wish.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243872")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2013")])]

#text("Thanks! Do you know if there is any particular structure to these residue classes, in particular if they resemble a shifted Schinzel sieve in the sense that one can send many of the residue classes to zero by shifting by a non-enormous shift? Of course by the Chinese remainder theorem there is some exponentially large shift after which one is just sieving out the multiples of 25 primes in an interval of diameter 4680, but I am curious to know if the example here has any kinship with the best examples we have for larger values of k_0 and H. (But perhaps k_0 is just too small for the asymptotic structure to kick in.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243877")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2013")])]

#text("Actually, if one subtracts 1961, the tuple looks a bit like an asymmetric Hensley-Richards sieve, viz. one is now starting with [-1961,2719] and sieving out 0(2), 0(3), 0(5), 0(7), 0(11), 0(13), 1(17), 3(19), 3 (23), -3 (29), 5 (31), 6 (37), -18 (41), -7 (43), -13 (47), -7 (53), 13 (59), -4 (61), 13 (67), -11 (71), -40 (83), 44 (89), 38 (97), 43 (193). The first six residue classes already seem to sieve out all but about 900 of the elements of the interval, leaving behind numbers that are plus or minus the product of one or two primes that are at least 17 (note that ")#mi("17^3 > 2719")#text("), and the remaining residue classes look fairly random as far as I can tell. (But one could have sieved out 0 (193) instead of 43 (193) since ")#mi("17 * 193 > 2719")#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243896")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("The example I gave above does not correspond to a Schinzel/greedy sieve with a small shift, but it is just one of 426 ways to got an admissible 632-tuple, and many of these *can* be obtained by starting with a shifted-Schinzel and then switching to a greedy sieve, as described in Section 3.5. But one has to break ties in just the right ways, simply picking the smallest (or largest) class in [0,p-1] doesn’t work, however the adjustment process described in Section 3.6.1 will find choices that do work. For example, here is another way to get an admissible 632-tuple:")

#text("Sieve the interval [746,5246] of the classes 1 mod 2 and 0 mod p for odd primes p up to 89, then sieve the classes 20(97) 96(101) 34(103) 88(107) 70(109) 0(113) 73(127) 10(131) 77(137) 70(139) 123(149) 75(157) 82(163) 144(167).")

#text("All of the sieved classes correspond to minimally occupied classes (greedy choices). It is not necessary to sieve mod 151.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243931")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("Thanks for this second example! Conceptually this example would be a closer fit to the discussion of how we find tuples, so it may serve as a better example, even though more congruence classes need to be sieved out. (But we can certainly mention the fact that there are multiple solutions here, which do not bear any obvious relation to each other.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243898")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("One point of clarification in my second example: while the sieved classes mod primes greater than 89 are all greedy choices, the classes 0 mod 13, 17, 19, and 23 do not correspond to greedy choices. This illustrates why it is important to start with a Schinzel sieve at small primes (say less than the sqrt of the interval size) and then switch to greedy sieving, as explained in 3.5.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244386")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2013")])]

#text("There is a minor typo in what I wrote above, the interval should be [746,5426] not [746,5246].")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243869")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2013")])]

#text("Proof of Lemma 2.13(iii): induction on ")#mi("i")#text(" instead of ")#mi("k")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243879")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2013")])]

#text("Due to the newly inserted case (i) in Theorems 7.1 and Theorems 7.7, the last sentences of these theorems as well as several intext references to the various cases of the theorems need to be updated ((i) became (ii), (ii) became (iii), (iii) became (iv)).")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243925")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("In the third line below the proof of prop. 7.12, the two terms should be inside parentheses (and perhaps also moved to the line above them.)")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243945")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("Definition 2.18(iii), “is said to be smooth” after ")#mi("N>0")#text(" is not needed?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243946")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("End of first line of Remark 2.22, qualitat(l)ive misspelt.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243947")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("Same remark, line -9, devisable should be divisable..")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-243954")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("I do not know if you have done the matter with some philosophy; but, when things are really pushed to their extremes, something qualitatively different would show up inevitably… (Say, a gate to another field).")

#text("Yiwei LI")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244472")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2013")])]

#text("Dear everyone,")

#text("First of all, I hold a positive attitude on the efforts from the polymath8 team, to make further progress on the hard problem. I’m not an expert on this kind of problem, but it does not prevent me from concerning its progress as a vice-professor working in some area of applied math. Quite often, researchers would keep away from an almost solved problem for understandable reasons (I do not comment if this problem is an almost solved one), while authors working on `big problems’ often encounter recognition problems, also for understandable reasons. I add that pushing things to their extremes might be a method for probing the borders of adjacent research areas. When the borders are found, a gate should not be far away… I felt free to leave my earlier comment, not for belittling the work here of cause, but sharing the perspectives from an outsider…")

#text("All the comments from me do not have implications for honors or something alike. It’s just for fun.(I leave my name just for being responsible).")

#text("Good will,")#linebreak()#text(" Yiwei LI")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244071")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2013")])]

#text("In 7.20 (and later in some related expressions) a (closing) “|” is missing.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b98727f8f8a0831e24ca615e39c621378d4c113e5d12d6edb878e7f3bde79659-dc6b605d5b2429f06ff0ac2804084cb0040360255bd99fb9cf2f9ca26197f8d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Hill")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244089")[#strong[#text("Daniel Hill")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2013")])]

#text("There is a typo at 8.6 line 6: `Fourier tranform’ for ` Fourier transform’.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244094")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2013")])]

#text("In the line above (10.17), the second “")#mi("(d,n)")#text("” should be deleted.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244293")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2013")])]

#text("In the 14-th line below (10.21), the expression is too long for a single line.")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244327")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2013")])]

#text("p54, line -2, “he basic intuition” should be “the …”")#linebreak()#text(" Purely nitpicking: p55, 4 lines below (4.54), maybe ")#mi("\\delta < 1.19\\times 10^{-4}")#text(" is better than \"1.19E-4\", etc. Same in Tables 6&7, although I don't feel as bad about them when they are in tables.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244363")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2013")])]

#text("In the second line below (10.22), a (closing) “|” is missing.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244398")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2013")])]

#text("I’ve just finished draft versions now of all the Type I,II,III estimates, so it looks like we’re at a point where most of the mathematical content needed in the paper has been written up in draft format at least. I needed one small addition to the Deligne section, specifically Theorem 8.18 which gives square root cancellation for the sum")

#mi("\\sum_{x \\in {\\bf F}_p} K_f(x)\\overline{K_f(x+l)} \\psi(hx)")

#text("where ")#mi("K_f(x) = \\frac{-1}{\\sqrt{p}}  \\sum_{y \\in {\\bf F}_p} e_p( \\frac{1}{(y+ax+b)(y+cx+d)} + ey)")#text(".")

#text("It turns out that I also need square root cancellation for the sum")

#mi("\\sum_{x \\in {\\bf F}_p} K_f(x) \\psi(hx).")

#text("Now this is an easier sum so presumably the arguments that control the first sum also control the second, but I didn’t actually put in the proof, as I thought it would be better left to one of the ell-adic experts :-).")

#text("A few small things came up when writing the proofs of the Type I,II,III estimates. Firstly, the notion of a smooth coefficient sequence wasn’t quite optimal (sometimes one wants to consider smooth sequences adapted to other intervals than [cN,CN], e.g. [M,M+N] instead) and I will have to think about how to set up the right definitions here. Related to this, the completion of sums lemma is also not stated in a way that is best suited for applications, and I will probably have to reformulate it.")

#text("When writing the proposition that gives iterated van der Corput estimates for exponential sums, I realised that actually we never use the van der Corput method more than once in the applications, so it is probably simpler to just give a simpler version of the proposition that does single van der Corput only, and add a remark that the estimate can be iterated but gives inferior numerology.")

#text("There was also some errors in the blog post on the improved Type I estimate which scared me for a while (I had put some terms inside an absolute value sign when instead they could only go outside) but fortunately it ended up not being an issue (these terms could stay outside the absolute value sign for a few more steps until a Cauchy-Schwarz was applied, at which point they could re-enter).")

#text("I’m no longer doing major editing on any one file, but will be reviewing the whole paper looking for things to clean up or make consistent with the rest of the paper. So it should be safe for others to make small edits to the various section files as well (except perhaps for narrow.tex, optimize.tex, and deligne.tex which are being edited by others).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe Michel")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244399")[#strong[#text("Philippe Michel")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2013")])]

#text("I will add it: but that is essentially done: to prove the bound for the product of K_f we had to show (via computing its FT) that the K_f does not contain a phase of degree <=2 and in particular it does not contain a linear phase")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe Michel")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244405")[#strong[#text("Philippe Michel")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2013")])]

#text("done")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244417")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2013")])]

#text("The lower bound ")#mi("k_0^{*}")#text(" may be added to table 1.")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244429")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2013")])]

#text("Table 4 should be moved outside of remark 2.17.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244430")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2013")])]

#text("Table 3 should be outside of theorem 2.6.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244433")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2013")])]

#text("Hmm, I’m not sure how best to sort this out, because LaTeX uses its own algorithms to place tables; they can be overridden to some extent, but it might not be worth doing so because the format of the paper may well change if and when it becomes published (most journals and monograph series have their own in-house style files). There is also the possibility that this sort of problem solves itself as the paper continues to evolve (but I think it is getting close to “first draft” status – most of the sections are written now, and there doesn’t seem to be much of a call for any major reorganisation of the paper).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244431")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2013")])]

#text("In the fourth line below (4.57), the exponents in the O-terms should be")#linebreak()#text(" ")#mi("1- k_0")#text(" (instead of ")#mi("-k_0")#text(").")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244439")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2013")])]

#text("Goldston-Yıldırım-Pintz -> Goldston-Pintz-Yıldırım (one in abstract, one in Page 14, two lines above (2.6))")

#text("Yildirim -> Yıldırım (Page 3, three lines below Theorem 1.2)")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244441")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2013")])]

#text("In (4.55), the RHS should be the maximum of its current value and ")#mi("0")#text(", and in the line below it, ")#mi("2\\eta")#text(" should be replaced by ")#mi("0")#text(".")#linebreak()#text(" (This is because ")#mi("x^{*} < 2\\eta")#text(" is possible – as case (i) in a previous comment of mine.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244445")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2013")])]

#text("Changed, thanks.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5abba5dd562f9355e60dc4c9893442e683e37151512bafa0a62957a87138f8ac-758fe84da47080c2384192dc09d20727c346092a341b0ed9fcbbbdf425655802.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244487")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2013")])]

#text("Small typo on top of page 7, “… for any real number ")#mi("x")#text(" we write ")#mi("e(x) := e(2\\pi ix)")#text(".”: that should be ")#mi("e^{2\\pi i x}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244490")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2013")])]

#text("Reference # 49, “Perel’muter” instead of “Perel\\’muter”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244508")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2013")])]

#text("Regarding where to submit this paper: I just got a email from Andrew Granville in his role as an editor of ")#link("http://msp.org/ant/about/cover/cover.html")[#text("Algebra and Number Theory")]#text(" soliciting the paper, saying that the projected length of 150 or so pages is not going to be a problem. This seems like a good choice to me (A&NT is a sister journal of Analysis & PDE, where I am an editor, and is run by the low-cost publisher MSP). (For obvious reasons I would not suggest a journal that I myself would be editing, otherwise I would have proposed Forum of Mathematics, Sigma.)")

#text("We don’t have to decide immediately on this, since the paper is still not quite even at first draft stage (although it is getting close…), but we can certainly start a discussion on what to do with this paper now. Another possibility is Memoirs of the AMS, which is specifically focused on long monographs, but perhaps we now have the opposite problem that our paper is a little short for a monograph…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe Michel")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244516")[#strong[#text("Philippe Michel")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2013")])]

#text("I am member of the editorial board of ANT, but I am enough “diluted” amongst the contributors to polymath8 AND also amongst the rest of the editorial board of ANT that this should not cause a problem; therefore I would be happy with ANT (a great journal which accept only great papers)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244523")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2013")])]

#text("I think that both choices would be excellent (ANT or Memoirs). I also think that the paper would be long enough for Memoirs (there have been several shorter papers there). Of course the invitation by Andrew and Philippe should be esteemed, so I also vote for ANT.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244514")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2013")])]

#text("At the end of chap. 10, it seems clearer to add that this completes the proof of prop. 10.2.")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244526")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2013")])]

#text("In the 20-th line of sec. 1.1., one word from “… established derived …” should be deleted.")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244541")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2013")])]

#text("I’ve written a draft for the section (Section 5.1) arguing that the Heath-Brown identity is essentially optimal for the purposes of reducing distribution estimates for the von Mangoldt function to the verification of estimates of various “Types” (Type I, Type II, Type III, etc.). This section is a little different from the rest of the paper in that it is written in a nonrigorous and informal fashion; it turns out that formalising exactly what a “Type” of estimate is, and whether a given decomposition allows one to reduce distribution estimates into such types, is rather tricky, and I didn’t want this section to overwhelm the rest of the paper since it is not part of the main argument (but rather an explanation as to why a certain component of that argument is not expected to be improvable). I’m still a little uncertain exactly what to do with this section, so any comments or suggestions on it will be welcome.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244691")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2013")])]

#text("One possibility might be to move that subsection to Section 11. In fact, and in contrast to my original suggestion that it be just a short concluding summary, perhaps Section 11 could be the repository for all the various remarks and discussions (some of them extensive, some probably very brief, some of them already present elsewhere in the paper, some not) about why this or that aspect of the current argument is likely to be rather refractory to further improvement. The following (at least) seem to fit, though probably not in the following order:")

#text("– why Heath-Brown is optimal for partitioning into [a sigma-dependent number of] Types.")#linebreak()#text(" – what can be said quantitatively about the “Type V” barrier (and maybe, for completeness, similarly for Type IV). For example, on 20th July you noted that the numerology was unfavourable if one tried using either Type I or Type III approaches, and you elaborated on July 9th and 10th for Types I and III respectively, but I believe those discussions were based on Level 5 and Level 3 arguments respectively; readers trying to identify lowest-hanging fruit may thus appreciate guidance as to whether it is worth retrying these approaches starting from higher Levels (including those in Type III that have not been explored at all yet). I think all you’ve said about this on the blog was “The numerology changes a bit if we use the latest Type III estimates [i.e. level 4] but I think the general picture is more or less the same” – apologies if I missed something.")#linebreak()#text(" – a summary of why efforts to improve the constraints on kappas enough to wrestle k0 down to 631 now seem to be in vain.")#linebreak()#text(" – a summary of the Farkas/Pintz/Revesz argument for the optimality of their version of the GPY method.")#linebreak()#text(" – maybe something from Drew about the realistic chances of further improvements to the headline 4680 number for k0=632.")#linebreak()#text(" – possibly some remarks (if you, as the one who spearheaded getting it to where it is, feel you have anything to say on it) about how work on improving the Type I constraint has reached diminishing returns.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244694")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2013")])]

#text("Immensely tentative followup suggestion: another item that might fit here is whether there is any scope for further improving varpi by extending the argument that allowed it to be “split” into varpi and delta (which you first observed on June 4th). Readers may be inspired to look for ways to split it again. Is it “obvious” that there are none?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244696")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2013")])]

#text("Concerning your remark about the upper bounds on the ")#mi("\\kappa")#text("‘s, I can say that I have found new upper bounds (of different type! – decaying faster for large ")#mi("k_0")#text(") for ")#mi("\\kappa_1")#text(" and ")#mi("\\kappa_2")#text(", but the problem was that in order to use them one needs also a good upper bound on ")#mi("\\kappa_3")#text(". Only very recently I found a way to represent the sum of the J-dim. integrals appearing in ")#mi("\\kappa_3")#text(" bound as a 1-dim. integral (I’m trying now to see its implication for ")#mi("k_0")#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244706")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2013")])]

#text("I can say a bit about the the 4680 bound for k0=632. The short version is that I think that there are reasons to believe that this bound may be tight. So far we have not been able to improve any of Engelsma’s bounds with k0 < 785, and we have found exactly the same 426 distinct admissible 632-tuples of diameter 4680 that Engelsma found, using entirely different methods (although to be fair, there are some specific diameters less than 4680 where we have found *more* admissible tuples than Engelsma found — I believe diameter 4178 is the smallest such case).")

#text("I do have some thoughts on improving the lower bounds for k0 in this range; here we can certainly do better than the 4104 lower bound currently listed in Table 6, even if we can't get all the way to 4680.")#linebreak()#text(" My post at ")#link("http://sbseminar.wordpress.com/2013/07/02/the-quest-for-narrow-admissible-tuples/#comment-24335")[#text("http://sbseminar.wordpress.com/2013/07/02/the-quest-for-narrow-admissible-tuples/#comment-24335")]#text(" gives a back-of-the-envelope estimate of the feasibility of proving lower bounds using a pruned exhaustive search, which for k0=632 is probably not feasible, but that doesn't mean something a more clever wouldn't work.")

#text("But I'd like to play around with this a bit more (perhaps over the coming weekend) before putting anything in the article.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244712")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2013")])]

#text("These are all good ideas. I am still working my way through the proofreading of the manuscript (just ran through deligne.tex, and am now going to go through typeiii.tex – I see that exponential.tex is currently being edited, so I promise not to touch that (or to further touch deligne.tex)), but when I get to Section 11, I will try to put some stubs at least for the points you raise, and maybe move over the Heath-Brown optimality discussion there too.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PhM")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244874")[#strong[#text("PhM")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2013")])]

#text("I am adding some extra mild material to deligne .tex and making some cosmetically edits here and there")

#text("whenever someone puts a boldface comment into the tex file is it possible to add a tag like %[TODO]")#linebreak()#text(" otherwise it is hard to see if there something the file being huge")

#emph[#text("[I added a TODO tag to the current boldface comments -T.]")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244602")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2013")])]

#text("The inclusion/exclusion computation for ")#mi("k_0 = 3,500,00")#text(" using ")#mi("p_{\\rm exh} = 13")#text(" has finished, yielding an improved lower bound of 35,926,668. This value can now be added to Table 5.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244603")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2013")])]

#text("Of course I meant to write ")#mi("k_0=3,500,000")#text(" in my comment above.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5abba5dd562f9355e60dc4c9893442e683e37151512bafa0a62957a87138f8ac-758fe84da47080c2384192dc09d20727c346092a341b0ed9fcbbbdf425655802.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244811")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2013")])]

#text("Ok, that has been added.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244682")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2013")])]

#text("Farkas-Pintz-Revesz: In abstract, Pintz and Revesz are reversed; on p4, Revesz missing accents.")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244718")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2013")])]

#text("In the line above prop. 10.2, perhaps “the previous section” should be replaced by “section 8” (or “sections 8 and 9”).")

#emph[#text("[Fixed, thanks -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244810")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2013")])]

#text("It is still unchanged.")

#emph[#text("[Oops; there had been a nearby reference to “previous section” that I had fixed instead. Now both should be fixed -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244881")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2013")])]

#text("In the line above proposition 10.2 it should be “section 8” (instead of “section 6”) – because prop. 10.2 proof depends mainly on theorem 8.18.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244768")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2013")])]

#text("In the second paragraph below Theorem 2.21:")

#text("parts (ii), (iii), and (iv) –> parts (iii, (iv), and (v)")

#text("parts (i) and (iii) –> parts (ii) and (iv)")

#emph[#text("[Fixed, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244833")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2013")])]

#text("I made a number of possibly misleading typos and omissions in the paragraph of my earlier post (")#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/#comment-244691")[#text("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/#comment-244691")]#text(") that referred to the Type V barrier. Since it seems (as things stand) to be conceivable that this highlights an actual way forward, I thought it was worth a correction. The paragraph should ideally have read as follows:")

#text("“On 13th July (")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238574")[#text("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238574")]#text("), where you derived a constraint for Type IV that is comfortably dominated (for varpi in the region of current interest) by the current Type III constraint, you also recalled that the numerology for Type V was unfavourable if one tried attacking it using either Type I or Type III approaches, something you had explained in some detail on July 9th (")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237995")[#text("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-237995")]#text(") for Type I and July 10th (")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238177")[#text("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238177")]#text(") for Type III. However, I believe those discussions were based on Type I Level 6 (“Deligne-free”) and Type III Level 3 constraints. Readers trying to identify lowest-hanging fruit may thus appreciate guidance as to whether it is worth retrying these approaches starting from higher Levels (including those in Type III that have not been explored at all yet).”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244890")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2013")])]

#text("There are several sums (e.g. in section 7) containing indices with unspecified range. Perhaps a remark on this abbreviated notation is needed in the introduction.")

#emph[#text("[Perhaps you are referring to the summation conventions in (7.14) or (7.15)? -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244949")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2013")])]

#text("For example, in (7.8) it seems (but not explicitly stated) that the summation index p ranges over the primes (i.e. the default that certain letters like n ranges over the integers while others like p are understood to represent primes.)")#linebreak()#text(" Such general standard conventions (for certain letters) may be added to the basic notation subsection in the introduction.")

#emph[#text("[OK, added something in the intro about how summing over p implicitly runs over primes – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244893")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2013")])]

#text("In the third line below remark 8.19, the “!” seems to be a typo.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244902")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2013")])]

#text("The new upper bounds for ")#mi("\\kappa_1")#text(" and ")#mi("\\kappa_2")#text(" are (in a somewhat simplified approximated form):")

#mi("\\kappa_1 \\le (e^{-\\eta \\theta } / \\eta \\theta) G(1-\\theta)")

#mi("\\kappa_2 \\le (k_0 - 1)(e^{-2 \\eta \\theta} / 2 \\eta \\theta) G(1-\\theta)")

#text("where ")#mi("G(x) := G_x(0, 0) /G_1(0, 0)")#text(" is the “G-ratio” function which is strictly increasing on ")#mi("[0, 1]")#text(" with ")#mi("G(0) = 0, G(1) = 1")#text(".")

#text("It follows that the new bounds decay exponentially with ")#mi("k_0")#text(" faster than the current bounds. (I’ll send the very simple details in my next comment.)")

#text("Concerning the new bound on ")#mi("\\kappa_3")#text(", it seems that the resulting")#linebreak()#text(" (1 dim.) integral (representing the sum of J dim. integrals) may be evaluated exactly (I’m checking the details.)")

#text("BTW, I suggest to add a remark about the precision of the numerical data (in particular the numerical integrals) for the current upper bounds of the")#linebreak()#text(" ")#mi("\\kappa")#text("‘s.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245761")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2013")])]

#text("Derivation of the new upper bounds on ")#mi("\\kappa_1, \\kappa_2")#text(":")

#text("Remark: In the following derivation we use the known properties (lemma 4.6) of the weight function ")#mi("f(x)")#text(" (defined by (4.32)) and the definition of the function ")#mi("G(x)")#text(" and its properties in my comment above.")

#text("1. In order to estimate ")#mi("\\kappa_1")#text(", we first estimate")

#mi("G_1(0, t) = \\int_0^{1-t} f(x) f(x+t) \\frac{x^{k_0 - 2}}{(k_0 - 2)!} dx")

#mi("\\le \\int_0^{1-t} f(x)[f(x)f(t)/f(0)] \\frac{x^{k_0-2}}{(k_0 - 2)!} dx")

#mi("= \\frac{f(t)}{f(0)} \\int_0^{1-t} f(x)^2 \\frac{x^{k_0 - 2}}{(k_0 - 2)!} dx")

#mi("= \\frac{f(t)}{f(0)} G_{1-t}(0, 0) \\le e^{-\\eta t} G_{1-t}(0, 0)")

#text("Therefore ")#mi("\\kappa_1 = G_1(0, 0)^{-1} \\int_{\\theta}^1 [G_1(0, t)/t] dt")

#mi("\\le \\int_{\\theta}^1 e^{-\\eta t} [G(1-t)/t] dt")

#text("Since the function ")#mi("G(1-t)/t")#text(" is decreasing on (0,1), integration by parts gives")

#mi("\\kappa_1 \\le \\frac {e^{-\\eta \\theta}} {\\eta \\theta} G(1 - \\theta)")

#text("2. To estimate ")#mi("\\kappa_2")#text(", we estimate similarly")

#mi("G_1(t, t) = \\int_0^{1-t} f(x+t)^2 \\frac{x^{k_0 - 2}}{(k_0 - 2)!} dx")

#mi("\\le [f(t)/f(0)]^2 \\int_0^{1-t} f(x)^2 \\frac{x^{k_0 - 2}}{(k_0 - 2)!}dx")

#mi("\\le e^{-2\\eta t} G_{1-t}(0, 0)")

#text("So ")#mi("\\kappa_2 = (k_0 - 1)G_1(0,0)^{-1} \\int_{\\theta}^1 [G_1(t, t)/t] dt")

#mi("\\le (k_0 - 1) \\int_{\\theta}^1 e^{-2 \\eta t} [G(1-t)/t] dt")

#text("Similarly, integration by part gives")

#mi("\\kappa_2 \\le (k_0 -1) \\frac{e^{-2 \\eta \\theta}}{2 \\eta \\theta}G(1 - \\theta)")

#text("Remark: The new bounds above can be slightly improved, by observing that the function ")#mi("e^{\\eta t}f(t)/f(0)")#text(" is decreasing on ")#mi("(0, 1)")#text(" – which can be used in the final integration by parts – leading to similar bounds in which the factor ")#mi("e^{-\\eta \\theta}")#text(" is replaced by ")#mi("f(\\theta)/f(0)")#text(". (But simple analysis shows that for small ")#mi("\\theta")#text(" the resulting gain is small.)")

#text("3. Comparing the new bounds to the current bounds:")

#text("Since the new bounds depend strongly on the function ")#mi("G(x)")#text(", we need to estimate its size. Since ")#mi("G(x) = G_x(0, 0)/G_1(0, 0)")#text(" we start with the simpler ")#mi("G_1(0,0)")#text(":")

#text("From (9.5.4) in A&S, we have")

#mi("J^{\\prime}_{k_0 - 2}(j_{k_0 - 2})=J_{k_0 - 3}(j_{k_0 - 2})= -J{k_0 - 1}(j_{k_0 - 2})")

#text("Hence ")#mi("G_1(0, 0) = J^{\\prime}_{k_0 - 2}(j_{k_0 - 2})^2")

#text("so by (9.5.18) in A&S")

#text("(1) ")#mi("G_1(0, 0) \\approx 1.239 k_0^{-4/3} + O(k_0^{-2})")

#text("In order to estimate ")#mi("G_x(0, 0)")#text(" we see from its definition (and lemma 4.5) that")

#text("(2) ")#mi("G_x(0, 0) \\le x J_{k_0 -2}(j_{k_0 -2}\\sqrt {x})^2")

#text("whenever ")#mi("j_{k_0 - 2}\\sqrt {x} < j_{k_0 - 3}")#text(".")

#text("The last condition is equivalent to")

#text("(2') ")#mi("x < (j_{k_0 - 3} / j_{k_0 -2})^2")#text(".")

#text("It is easy to verify that the last condition is equivalent to")

#text("(2'') ")#mi("x < 1 - 2/k_0 + O(k_0 ^{-5/3})")#text(".")

#text("From the definition of ")#mi("f(x)")#text(" we have")

#mi("J_{k_0 - 2}(j_{k_0 - 2} \\sqrt {x}) = x^{k_0 /2 - 1} f(x)")

#text("Hence (2) takes the form")

#text("(3) ")#mi("G_x(0,0) \\le x^{k_0 -1} f(x)^2 \\le x^{k_0 -1} f(0)^2 e^{-2\\eta x}")

#text("Whenever ")#mi("x")#text(" satisfies (2').")

#text("From the definition of ")#mi("f(x)")#text(" we have")

#text("(4) ")#mi("f(0) = (j_{k_0 - 2} / 2)^{k_0 - 2} /(k_0 - 2)!")

#text("Using the above estimates we get")

#text("(5) ")#mi("G(x) \\le C(k_0) x^{k_0 -1}e^{-2 \\eta x}")#text(", where")

#text("(5') ")#mi("C(k_0)  = O[2^{-2 k_0} e^{2 k_0 +O(k_0^{1/3})}]")

#text("Which gives the estimates")

#text("(6) ")#mi("\\kappa_1 \\le C_1(k_0) (1- \\theta)^{k_0 -1}e^{\\eta \\theta} /(\\eta \\theta)")

#text("where")

#text("(6') ")#mi("C_1(k_0) = O[e^{1.5 k_0 +O(k_0^{1/3})} 2^{-2 k_0}]")

#text("Note that ")#mi("c_1(k_0)")#text(" grows exponentially as ")#mi("k_0 \\rightarrow \\infty")#linebreak()#text(" In addition, the second (")#mi("\\theta")#text("-dependent) factor in ")#mi("\\kappa_1")#text(" decay exponentially with exponent ")#mi("-0.75 k_0 \\theta")#text(" (which is faster than the decay with exponent ")#mi("-0.5 k_0 \\theta")#text(" in the current bound for ")#mi("\\kappa_1")#text(". There is a similar estimate for ")#mi("\\kappa_2")#text(" but with the same decay exponent (")#mi("-k_0 \\theta")#text(") as for the current bound.")

#text("Remark: It seems that for sufficiently large ")#mi("k_0")#text(" the new bounds should perform better than the current ones (in particular the new bound for ")#mi("\\kappa_1")#text(". Therefore I suggest to use them as well by taking the minimum between them and the current bounds. There is a possibility to get ")#mi("k_0 =1782")#text(" by using the new bounds.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245836")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2013")])]

#text("Corrections to my comment above:")

#text("1. In the remark at the end of part 2, it should be “replaced by")#linebreak()#text(" ")#mi("f(\\theta) / f(0)")#text("” (instead of “replaced by ")#mi("f(t) / f(0)")#text("“).")

#text("2. In the line below (6′) it should be “grows exponentially” (instead of “decay exponentially”).")#linebreak()#text(" This is because ")#mi("e^{1.5} >4")#text(" – meaning that the estimate (5) of ")#mi("G(x)")#text(" which use the second inequality in (3) (which is appropriate for small x) is too crude for ")#mi("x = 1-\\theta")#text(" for small ")#mi("\\theta")#text(" values.")

#emph[#text("[Previous comment corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245848")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2013")])]

#text("Thanks for the calculations! Would it be possible to provide some code (similar to the Maple code we have been using for similar calculations in the past) for what these new bounds for ")#mi("\\kappa_1,\\kappa_2")#text(" give? I guess the first thing to try is to simply plug in the values of ")#mi("\\delta,\\varpi,\\delta^{\\prime}")#text(" from Table 4 of the paper and see if there is any improvement there. (If not, this does not necessarily mean that these new bounds do not give an improvement, since perhaps the improvement comes from some other choice of parameters – but it would make it difficult for the new bound to end up giving an ultimately better bound, particularly since one also has to keep ")#mi("\\kappa_3")#text(" under control…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245857")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2013")])]

#text("Just tried to implement the maple code for kappa1 and kappa2, seems the values can drop dramatically, at least for k_0=1782:")

#text("tn := sqrt(thetat)*j;")#linebreak()#text(" f := t->(t^(1-k0/2)*j*(tn))^2*t^(k0-2)/(k0-2)!;")#linebreak()#text(" gk :=int(f(t), t=0..(1-theta), numeric);")#linebreak()#text(" kappa1 := evalf(gk*exp(-eta*theta)/(eta*theta));")#linebreak()#text(" kappa2:= (k0-1) * gk *exp(-2*eta*theta)/(2*eta*theta);")

#text("If the implementation is correct, there is a solution using the modification:")

#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi168_1782_1.mpl")[#text("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi168_1782_1.mpl")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245868")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2013")])]

#text("Found some bugs in the implementation:")

#text("eta := j^2 / (4 * (k0-1));")#linebreak()#text(" bj := evalf(BesselJ(k0-1,tn));")#linebreak()#text(" f := t->(bj*t^(1-k0/2))^2*t^(k0-2)/(k0-2)!;")#linebreak()#text(" gk :=int(f(t), t=0..(1-theta), numeric)/int(f(t), t=0..1, numeric);")#linebreak()#text(" kappa1 := gk*exp(-eta*theta)/(eta*theta);")#linebreak()#text(" kappa2:= (k0-1) * gk *exp(-2*eta*theta)/(2*eta*theta);")

#text("BUt now the new bounds produce worse results that old bounds …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245873")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2013")])]

#text("It seems that there is a problem with the implementation of")#linebreak()#text(" ")#mi("G(1-\\theta)")#text(" – it is the G-ratio function (without numerical integration!) as done by ")#mi("gn / gd")#text(" in the computation of ")#mi("\\kappa_3")#text(" but now with argument ")#mi("1-\\theta")#text(" (instead of ")#mi("\\tilde{\\theta}")#text(" used in the computation of ")#mi("\\kappa_3")#text(". )")#linebreak()#text(" In addition, I suggest to take for ")#mi("\\kappa_1, \\kappa_2")#text(" the minimum between the current and new types of bounds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245926")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2013")])]

#text("@Eytan: Tried the following code (also updated in the upper link for 1782):")

#text("eta := j^2 / (4 * (k0-1));")#linebreak()#text(" gd := BesselJ(k0-1,j)^2;")#linebreak()#text(" f_tn := t -> sqrt(t)*j;")#linebreak()#text(" f_g := t -> t * (BesselJ(k0-2,f_tn(t))^2 – BesselJ(k0-3,f_tn(t))*BesselJ(k0-1,f_tn(t))) / gd;")#linebreak()#text(" gk := f_g(1-theta);")

#text("kappa1 := gk * exp(-eta*theta)/(eta*theta);")#linebreak()#text(" kappa2 := (k0-1) * gk *exp(-2*eta*theta)/(2*eta*theta);")

#text("But still the new bounds return worse results for kappa1, Kappa2, at least at k0=1783:")

#text("New : 1.15E-04, 1.37E-04")#linebreak()#text(" Old: 1.58E-07, 3.24E-10")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245944")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2013")])]

#text("The performance of the new bounds for ")#mi("\\kappa_1, \\kappa_2")#text(" should be better than the current bounds provided that ")#mi("k_0")#text(" and")#linebreak()#text(" ")#mi("k_0 \\theta")#text(" are sufficiently large (because the exponential decay is faster for the new bounds – but initially at small ")#mi("k_0 \\theta")#text(" the performance of the new bounds seems to be poorer wrt the current bounds.)")#linebreak()#text(" Therefore, I suggest to find the “threshold” for ")#mi("k_0 \\theta")#text(" above which the new bounds are better than the current ones. (for each fixed value of ")#mi("k_0")#text(" there should be such minimal value of ")#mi("\\theta")#text(" such that for any larger value of ")#mi("\\theta")#text(", the new bounds should be better (at least for ")#mi("\\kappa_1")#text(") than the current ones.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245951")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2013")])]

#text("It should be interesting to compare the above bounds to the direct approximation of ")#mi("\\kappa_1, \\kappa_2")#text(" via the numerical evaluation of the double integrals defining these parameters. (It seems that this numerical double integrals should be numerically stable due to the monotonicity of the integrands.) This should give us some insight about the true order of magnitude of these parameters and the crudeness of their bounds.")#linebreak()#text(" We may even consider replacing the current bounds by the numerical double integrals estimates (provided that we have confidence on their precision!)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245864")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2013")])]

#text("It seems that these two new bounds should be better than the current ones for sufficiently large ")#mi("k_0")#text(" values (because of the faster exponential decay) but not necessarily for smaller ")#mi("k_0")#text(" values. So that both bounds may coexist (by taking for each choice of parameters the minimal bound). Another advantage of the new bounds is that they depend mainly on the explicit function G(x) (already in use for the current ")#mi("\\kappa_3")#text(" expression) without any need to evaluate numerical integrals (for which the actual numerical precision is not known in general) to a certain precision needed for the criterion.")#linebreak()#text(" I think that by such combination of the two types of bounds, there is a possibility to improve on some ")#mi("k_0")#text(" values (e.g. to get ")#mi("k_0 =1782")#text(") by updating the current optimization software (with the problem that the new cost function is not necessarily smooth.)")#linebreak()#text(" But I agree that a real progress should depend also on an improved bound for ")#mi("\\kappa_3")#text(" (I’m working on it now – using a probabilistic interpretation of the J-dim. integrals in its definition – I hope to finish it in a day or two)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244915")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2013")])]

#text("I’ve now written something for the final “improvements” section. I eventually decided not to be excessively technical with the specific improvements that we were speculating about in previous blog comments, because it is likely that they will only lead to small gains, and such speculations could soon become obsolete if the next set of people to work on this problem introduce some new ideas.")

#text("At this stage it looks like we are close to a first draft status for the paper, with most sections being more or less written up. Sections 1-5 look in particularly good shape, but Sections 6-11 still need some proofreading, and the notation for the Deligne sections need to be carefully harmonised with those in the rest of the paper. But I think we are nearing the end now…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PhM")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244956")[#strong[#text("PhM")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2013")])]

#text("Speaking of notations: regarding the type I,II sums, can we replace the notation ")#mi("\\Phi_{k,r}(h,q_1,q_2; n)")#text(" with something like ")#mi("\\Phi_{k}(h,n; r,q_1,q_2)")#text(". It is usual to write functions of some modulus ")#mi("q")#text(" in the form ")#mi("x\\mapsto f(x;q)")#text(" (variable in the first place and the modulus after separated by a semi-colon) the proposed notation would be more in line with this. Of course in the improved type I estimate, a factor of the modulus becomes the variable but we can adapt the notations too when the moment comes.")

#emph[#text("[Notation changed for ")#mi("\\Phi_k")#text(". In the improved type I estimates I suppressed the modulus entirely for ")#mi("\\Psi(d,n)")#text(". In the regular type I/II estimates I also have the exponential sums ")#mi("S_{k,r}(h, \\tilde h, q^{\\prime}_1, q^{\\prime}_2, \\tilde q^{\\prime}_1, \\tilde q^{\\prime}_2 )")#text(" and ")#mi("S^{\\prime}_{k,r}( h, \\tilde h, s^{\\prime}_1, t^{\\prime}_1, \\tilde t^{\\prime}_1, q^{\\prime}_2)")#text(", if you have other suggestions for the notation here I would be happy to implement them. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-244995")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2013")])]

#text("Terry, the new Section 11 is fantastic. I feel that you have judged the level of technical detail exactly right, so as to allow both specialists and non-specialists to stand back from the current proof and form clear views as to what aspect they might be best equipped to attack. Thank you.")

#text("Reading it myself, I am drawn more powerfully than ever to the Type V issue as the one which appears the “softest” (given that sub-optimal Type I and III methods were used to attack Type V back in July), to the extent that I wonder if I am just misunderstanding something fundamental with regard to the potential susceptibility of Type V numerology to such refinements in Type I and III numerology. Might it be possible to add to paragraph (vii) of Section 11 an explicit statement (even without derivation, and ignoring delta) of the exact Type IV and V constraints on (varpi, sigma) arising from those analyses, together with what Levels (equivalently, theorems or lemmas in the paper) were used as starting-points to derive them? My understanding of ")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238574")[#text("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-238574")]#text(" is that the comfortably loose Type IV constraint 14*varpi < 3*sigma arises from Type I Level 6 methods (right?), but I'm pretty sure that nowhere has there been any corresponding statement of what Type V constraint is obtained using either Type I or Type III methods (of any Level) – the relevant analyses from July 9th and 10th seem to stop just short of deriving those constraints. Without such statements, paragraph (vii) comes over (to me, anyway) as a sufficiently conspicuous open door, especially given what paragraph (x) says about Type III, as to make it almost incongruous that the project declared victory without first checking the impact on Type V of using the best Type I and/or Type III technology.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245069")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2013")])]

#text("Yes, I think that the introduction of a new Type V argument that can establish estimates beyond what one can already achieve by refactoring a Type V sum into an existing sum would be a great breakthrough, not just for the immediate aim of improving H, but because it would probably have to introduce a new technique which is not currently in play. But it looks quite challenging; the problem here is morally a slightly harder version of the problem of estimating the distribution of the fifth divisor function ")#mi("\\tau_5")#text(" in arithmetic progressions, whereas the state of the art is non-trivial control on only the third divisor function ")#mi("\\tau_3")#text(" (and our Type III arguments are based on this state of the art).")

#text("I added a remark about how the Type III arguments don’t seem to extend well to ")#mi("\\tau_4")#text(", let alone ")#mi("\\tau_5")#text(". I also briefly mentioned the partial results on Type IV sums, although I’m not sure whether it’s worth trying to work out specific numerics here(if there is enough of a breakthrough in the subject to get Type V estimates, it is likely that other estimates will get improved as well, recording the current state of the art on Type IV seems a bit moot).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245139")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2013")])]

#text("I have added two or three lines in the narrow admissible tuples part of Section 11, where I made reference to the fact that both Engelsma and us found exactly 426 admissible 632-tuples of width 4680 (see Drew’s post of 5 September above). @Drew, I was wondering whether this 426 is modulo translation, or if it is also modulo horizontal flipping (")#mi("x \\mapsto -x")#text(")?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245152")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2013")])]

#text("The count of 426 is modulo translation (otherwise there would be infinitely many), but not flipping. None of the gap sequences are palindromic, so there are actually 213 pairs of tuples that correspond to negations of each other.")

#text("Another way to say this is that we (and independently, Engelsma) have found exactly 426 admissible 632-tuples that start with 0 and end with 4680.")

#text("I put a lexicographically sorted file of all 426 tuples (one tuple per line) at the URL below:")

#link("http://math.mit.edu/~primegaps/tuples/admissible_tuples_632_4680.txt")[#text("http://math.mit.edu/~primegaps/tuples/admissible_tuples_632_4680.txt")]

#text("This location should be permanent, so we can link to this in the paper.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245375")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2013")])]

#text("Thanks for the link; I put a mention of it in Theorem 3.1. We have a compact description of one of the 632-tuples; is it possible to locate a 1783-tuple with a similarly compact description? Of course, being three times as long, it may not be so particularly edifying, and perhaps it is better to just provide a link if it is messy (particularly since the Deligne-free result is of secondary importance), but on the off chance that there is a relatively nice description, it could be worth putting one in. (Also, how many tuples do we have of the minimal diameter in this case?)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245399")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2013")])]

#text("Here is a shortish description of an admissible 1783-tuple with diameter 14950. Sieve the interval [1714,16664] by 1 mod 2 and then 0 mod p for odd primes p up to 211, then sieve the following classes:")#linebreak()#text(" 188(223) 0(227) 222(229) 38(233) 146(239) 33(241) 0(251) 229(257) 21(263) 78(269) 140(271) 104(277) 106(281) 53(283) 141(293) 216(307) 12(311) 17(313) 252(317) 191(337) 269(347) 32(353) 142(359) 42(379) 345(383) 165(389) 221(409).")

#text("In contrast to the example I gave for 632, many of these (9 classes) don’t correspond to greedy choices.")

#text("I have roughly 25,000 distinct admissible 1783-tuples of this length, but I really haven’t made an extensive effort to find them the way I did with k0=632 — I expect there are many more.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245401")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2013")])]

#text("Thanks! I added this description of the example to the paper.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245145")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2013")])]

#text("I haven’t yet started reviewing the whole paper but I intend to do this carefully once it has reached a relatively stable state.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245038")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2013")])]

#text("2nd paragraph before sec 1.2(p5), “Weyl differencing” instead of “Weil …”?")#linebreak()#text(" 3 lines below that, “establishing a” instead of “a establishing”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245042")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2013")])]

#text("Is the z at the beginning of section 4 a typo?")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245062")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2013")])]

#text("Table 3, 6/700 should be 7/600.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245068")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2013")])]

#text("Table 1: ")#mi("\\S_I")#text(" should be ")#mi("{\\mathcal S}_I")#text(" for product of square free primes in I.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2013/09/02/polymath8-writing-the-paper-ii/comment-page-1/#comment-245150")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2013")])]

#text("In section 1.1 (Overview), at the very beginning, the limit is really a lim inf. Also, the “shows” immediately after should probably be “showed”. And [27] should be mentioned explicitly, maybe right before the displayed equation.")

#emph[#text("[Corrected, thanks – T.]")]
]
