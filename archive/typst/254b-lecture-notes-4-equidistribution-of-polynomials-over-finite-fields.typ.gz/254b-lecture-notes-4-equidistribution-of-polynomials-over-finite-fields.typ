// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/05/08/254b-lecture-notes-4-equidistribution-of-polynomials-over-finite-fields/
// Converted to Typst by tao2typ: "2026-10-14T15:17:45.601107+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254B, Lecture Notes 4: Equidistribution of polynomials over finite fields", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254B, Lecture Notes 4: Equidistribution of polynomials over finite fields")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 May 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/05/08/254b-lecture-notes-4-equidistribution-of-polynomials-over-finite-fields/")[#text("https://terrytao.wordpress.com/2010/05/08/254b-lecture-notes-4-equidistribution-of-polynomials-over-finite-fields/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the previous lectures, we have focused mostly on the equidistribution or linear patterns on a subset of the integers ")#mi("{{\\bf Z}}")#text(", and in particular on intervals ")#mi("{[N]}")#text(". The integers are of course a very important domain to study in additive combinatorics; but there are also other fundamental model examples of domains to study. One of these is that of a vector space ")#mi("{V}")#text(" over a finite field ")#mi("{{\\bf F} = {\\bf F}_p}")#text(" of prime order. Such domains are of interest in computer science (particularly when ")#mi("{p=2}")#text(") and also in number theory; but they also serve as an important simplified “")#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")[#text("dyadic model")]#text("” for the integers. See this ")#link("http://www.arxiv.org/abs/math.NT/0409420")[#text("survey article of Green")]#text(" for further discussion of this point.")

#text("The additive combinatorics of the integers ")#mi("{{\\bf Z}}")#text(", and of vector spaces ")#mi("{V}")#text(" over finite fields, are analogous, but not quite identical. For instance, the analogue of an arithmetic progression in ")#mi("{{\\bf Z}}")#text(" is a subspace of ")#mi("{V}")#text(". In many cases, the finite field theory is a little bit simpler than the integer theory; for instance, subspaces are closed under addition, whereas arithmetic progressions are only “almost” closed under addition in various senses. (For instance, ")#mi("{[N]}")#text(" is closed under addition approximately half of the time.) However, there are some ways in which the integers are better behaved. For instance, because the integers can be generated by a single generator, a homomorphism from ")#mi("{{\\bf Z}}")#text(" to some other group ")#mi("{G}")#text(" can be described by a single group element ")#mi("{g}")#text(": ")#mi("{n \\mapsto g^n}")#text(". However, to specify a homomorphism from a vector space ")#mi("{V}")#text(" to ")#mi("{G}")#text(" one would need to specify one group element for each dimension of ")#mi("{V}")#text(". Thus we see that there is a tradeoff when passing from ")#mi("{{\\bf Z}}")#text(" (or ")#mi("{[N]}")#text(") to a vector space model; one gains a bounded torsion property, at the expense of conceding the bounded generation property. (Of course, if one wants to deal with arbitrarily large domains, one has to concede one or the other; the only additive groups that have both bounded torsion and boundedly many generators, are bounded.)")

#text("The starting point for this course (")#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/")[#text("Notes 1")]#text(") was the study of equidistribution of polynomials ")#mi("{P: {\\bf Z} \\rightarrow {\\bf R}/{\\bf Z}}")#text(" from the integers to the unit circle. We now turn to the parallel theory of equidistribution of polynomials ")#mi("{P: V \\rightarrow {\\bf R}/{\\bf Z}}")#text(" from vector spaces over finite fields to the unit circle. Actually, for simplicity we will mostly focus on the ")#emph[#text("classical")]#text(" case, when the polynomials in fact take values in the ")#mi("{p^{th}}")#text(" roots of unity (where ")#mi("{p}")#text(" is the characteristic of the field ")#mi("{{\\bf F} = {\\bf F}_p}")#text("). As it turns out, the non-classical case is also of importance (particularly in low characteristic), but the theory is more difficult; see ")#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/")[#text("these notes")]#text(" for some further discussion.")

#metadata(none) <tao-cbf670d7d771c3d7ca69>

#heading(level: 1)[#strong[#text(" — 1. Polynomials: basic theory — ")]]

#text("Throughout this section, ")#mi("{V}")#text(" will be a finite-dimensional vector space over a finite field ")#mi("{{\\bf F} = {\\bf F}_p}")#text(" of prime order ")#mi("{p}")#text(".")

#text("Recall from the ")#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/")[#text("previous notes")]#text(" that a function ")#mi("{P: V \\rightarrow {\\bf R}/{\\bf Z}}")#text(" is a function is a ")#emph[#text("polynomial of degree at most ")#mi("{d}")]#text(" if")

#align(center)[#tao-fit-display[#mitex("\\partial_{h_1} \\ldots \\partial_{h_{d+1}} P(x) = 0")]]

#text("for all ")#mi("{x,h_1,\\ldots,h_{d+1} \\in V}")#text(", where ")#mi("{\\partial_h P(x) := P(x+h)-P(x)}")#text(". As mentioned in previous notes, this is equivalent to the assertion that the Gowers uniformity norm ")#tao-math("{\\left\\|e(P)\\right\\|_{U^{d+1}(V)}=1}", block: false)#text(". The space of polynomials of degree at most ")#mi("{d}")#text(" will be denoted ")#mi("{\\text{Poly}_{\\leq d}(V \\rightarrow {\\bf R}/{\\bf Z})}")#text("; it is clearly an additive group. Note that a polynomial of degree zero is the same thing as a constant function, thus ")#mi("{\\text{Poly}_{\\leq 0}(V \\rightarrow {\\bf R}/{\\bf Z}) \\equiv {\\bf R}/{\\bf Z}}")#text(".")

#text("An important special case of polynomials are the ")#emph[#text("classical polynomials")]#text(", which take values in ")#mi("{{\\bf F}}")#text(" (which we identify with the ")#mi("{p^{th}}")#text(" roots of unity in ")#mi("{{\\bf R}/{\\bf Z}}")#text(" in the obvious manner); the space of such polynomials of degree at most ")#mi("{d}")#text(" will be denoted ")#mi("{\\text{Poly}_{\\leq d}(V \\rightarrow {\\bf F})}")#text("; this is clearly a vector space over ")#mi("{{\\bf F}}")#text(". The classical polynomials have a familiar description, once we use a basis to identify ")#mi("{V}")#text(" with ")#mi("{{\\bf F}^n}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" ")#metadata(none) <tao-0889113e04d3203f0c40>#text(" Let ")#mi("{P: {\\bf F}^n \\rightarrow {\\bf F}}")#text(" be a function, and ")#mi("{d \\geq 0}")#text(" be an integer. Show that ")#mi("{P}")#text(" is a (classical) polynomial of degree at most ")#mi("{d}")#text(" if and only if one has a representation of the form")

#align(center)[#tao-fit-display[#mitex("P(x_1,\\ldots,x_n) := \\sum_{i_1,\\ldots,i_n \\geq 0: i_1+\\ldots+i_n \\leq d} c_{i_1,\\ldots,i_n} x_1^{i_1} \\ldots x_n^{i_n}")]]

#text("for some coefficients ")#mi("{c_{i_1,\\ldots,i_n} \\in {\\bf F}}")#text(". Furthermore, show that we can restrict the exponents ")#mi("{i_1,\\ldots,i_n}")#text(" to lie in the range ")#mi("{\\{0,\\ldots,p-1\\}}")#text(", and that once one does so, the representation is unique. (")#emph[#text("Hint:")]#text(" First establish the ")#mi("{d=1}")#text(" case, which can be done for instance by a dimension counting argument, and then induct on dimension.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Show that the cardinality of ")#mi("{\\text{Poly}_{\\leq d}(V \\rightarrow {\\bf F})}")#text(" is at most ")#mi("{p^{\\binom{d+\\text{dim}(V)}{d}}}")#text(", with equality if and only if ")#mi("{d < p}")#text(".")
]

#text("Now we study more general polynomials. A basic fact here is that multiplying a polynomial by the characteristic ")#mi("{p}")#text(" lowers the degree:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(" ")#metadata(none) <tao-a1e0e955af49a59b69c5>#text(" If ")#mi("{P \\in \\text{Poly}_{\\leq d}(V \\rightarrow {\\bf R}/{\\bf Z})}")#text(", then ")#mi("{pP \\in \\text{Poly}_{\\leq \\max(d-p+1,0)}(V \\rightarrow {\\bf R}/{\\bf Z})}")#text(".")
]

#emph[#text("Proof:")]#text(" Without loss of generality we may take ")#mi("{d \\geq p-1}")#text("; an easy induction on ")#mi("{d}")#text(" then shows it suffices to verify the base case ")#mi("{d=p-1}")#text(". Our task is now to show that ")#mi("{pP}")#text(" is constant, or equivalently that ")#mi("{p \\Delta_e P = 0}")#text(" for all ")#mi("{e \\in V}")#text(".")

#text("Fix ")#mi("{e}")#text(". The operator ")#mi("{1+\\Delta_e}")#text(" represents a shift by ")#mi("{e}")#text(". Since ")#mi("{pe=0}")#text(", we conclude that ")#mi("{(1+\\Delta_e)^p P = P}")#text(". On the other hand, as ")#mi("{P}")#text(" has degree at most ")#mi("{p-1}")#text(", ")#mi("{\\Delta_e^p P = 0}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("((1+\\Delta_e)^p - 1 - \\Delta_e^p) P = 0.")]]

#text("Using the binomial formula, we can factorise the left-hand side as")

#align(center)[#tao-fit-display[#mitex("(1 + \\frac{p-1}{2} \\Delta_e + \\ldots + \\Delta_e^{p-2}) (p \\Delta_e P) = 0.")]]

#text("The first factor can be inverted by Neumann series since ")#mi("{\\Delta_e}")#text(" acts nilpotently on polynomials. We conclude that ")#mi("{p\\Delta_e P=0}")#text(" as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Establish the identity")

#align(center)[#tao-fit-display[#mitex("p (T^j - 1) = (-1)^{p-1} (T^j - 1) (T-1) (T^2-1) \\ldots (T^{p-1}-1)")]]

#align(center)[#tao-fit-display[#mitex("\\text{ mod } T^p-1")]]

#text("for an indeterminate ")#mi("{T}")#text(" and any integer ")#mi("{j}")#text(", by testing on ")#mi("{p^{th}}")#text(" roots of unity. (This identity was communicated to me by Andrew Granville.) Use this to give an alternate proof of Lemma ")#link(<tao-a1e0e955af49a59b69c5>)[#text("1")]#text(".")
]

#text("This classifies all polynomials in the high characteristic case ")#mi("{p>d}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2")]#text(" If ")#mi("{p > d}")#text(", then ")#mi("{\\text{Poly}_{\\leq d}(V \\rightarrow {\\bf R}/{\\bf Z}) = \\text{Poly}_{\\leq d}(V \\rightarrow {\\bf F}) + ({\\bf R}/{\\bf Z})}")#text(". In other words, every polynomial of degree at most ")#mi("{d}")#text(" is the sum of a classical polynomial and a constant.")
]

#text("The situation is more complicated in the low characteristic case ")#mi("{p \\leq d}")#text(", in which non-classical polynomials can occur (polynomials that are not simply a classical polynomial up to constants). For instance, consider the function ")#mi("{P: {\\bf F}_2 \\rightarrow {\\bf R}/{\\bf Z}}")#text(" defined by ")#mi("{P(0)=0}")#text(" and ")#mi("{P(1)=1/4}")#text(". One easily verifies that this is a (non-classical) quadratic (i.e. a polynomial of degree at most ")#mi("{2}")#text("), but is clearly not a shifted version of a classical polynomial since its range is not a shift of the second roots ")#mi("{\\{0,1/2\\} \\text{ mod } 1}")#text(" of unity.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Let ")#mi("{P: {\\bf F}_2 \\rightarrow {\\bf R}/{\\bf Z}}")#text(" be a function. Show that ")#mi("{P}")#text(" is a polynomial of degree at most ")#mi("{d}")#text(" if and only if the range of ")#mi("{P}")#text(" is a translate of the ")#mi("{(2^d)^{th}}")#text(" roots of unity (i.e. ")#mi("{2^d P}")#text(" is constant).")
]

#text("For further discussion of non-classical polynomials, see ")#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/")[#text("this previous blog post")]#text(". Henceforth we shall avoid this technical issue by restricting to the high characteristic case ")#mi("{p>d}")#text(" (or equivalently, the low degree case ")#mi("{d<p}")#text(").")

#heading(level: 1)[#strong[#text(" — 2. Equidistribution — ")]]

#text("Let us now consider the equidistribution theory of a classical polynomial ")#mi("{P: V \\rightarrow {\\bf F}}")#text(", where we think of ")#mi("{{\\bf F}}")#text(" as being a fixed field (in particular, ")#mi("{p=O(1)}")#text("), and the dimension of ")#mi("{V}")#text(" as being very large; ")#mi("{V}")#text(" will play the role here that the interval ")#mi("{[N]}")#text(" played in ")#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/")[#text("Notes 1")]#text(". This theory is classical for linear and quadratic polynomials. The general theory was studied first by ")#link("http://arxiv.org/abs/0711.3191")[#text("Ben Green and myself")]#text(" in the high characteristic case ")#mi("{p>d}")#text(", and extended to the low characteristic case ")#link("http://arxiv.org/abs/0806.4535")[#text("by Kaufman and Lovett")]#text(". An analogous theory surely exists for the non-classical case, although this is not currently in the literature.")

#text("The situation here is simpler because a classical polynomial can only take ")#mi("{p}")#text(" values, so that in the equidistributed case one expects each value to be obtained about ")#tao-math("{\\left|V\\right|/p}", block: false)#text(" times. Inspired by this, let us call a classical polynomial ")#mi("{P}")#text(" ")#emph[#mi("{\\delta}")#text("-equidistributed")]#text(" if one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ x \\in V: P(x) = a \\} - \\left|V\\right|/p\\right| \\leq \\delta \\left|V\\right|", block: true)]]

#text("for all ")#mi("{a \\in {\\bf F}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Show that this is equivalent to the notion of ")#mi("{\\delta}")#text("-equidistribution given in ")#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/")[#text("Notes 1")]#text(", if one gives ")#mi("{{\\bf F}}")#text(" the metric induced from ")#mi("{{\\bf R}/{\\bf Z}}")#text(", and if one is willing to modify ")#mi("{\\delta}")#text(" by a multiplicative factor depending on ")#mi("{p}")#text(" in the equivalences.")
]

#text("Before we study equidistribution in earnest, we first give a classical estimate.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6 (Chevalley-Warning theorem)")]#text(" Let ")#mi("{V}")#text(" be a finite dimensional space, and let ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" be a classical polynomial of degree less than ")#mi("{(p-1) \\text{dim}(V)}")#text(". Show that ")#mi("{\\sum_{x \\in V} P(x) = 0}")#text(". (")#emph[#text("Hint:")]#text(" Identify ")#mi("{V}")#text(" with ")#mi("{{\\bf F}^n}")#text(" for some ")#mi("{n}")#text(" and apply Exercise ")#link(<tao-0889113e04d3203f0c40>)[#text("1")]#text(". Use the fact that ")#mi("{\\sum_{x \\in {\\bf F}} x^i = 0}")#text(" for all ")#mi("{1 \\leq i < p-1}")#text(", which can be deduced by using a change of variables ")#mi("{x \\mapsto bx}")#text(".) If furthermore ")#mi("{P}")#text(" has degree less than ")#mi("{\\text{dim}(V)}")#text(", conclude that for every ")#mi("{a \\in {\\bf F}}")#text(", that ")#tao-math("{\\left|\\{ x \\in V: P(x)=a \\}\\right|}", block: false)#text(" is a multiple of ")#mi("{p}")#text(". (")#emph[#text("Hint:")]#text(" Apply Fermat’s little theorem to the quantity ")#mi("{(P-a)^{p-1}}")#text(".) In particular, if ")#mi("{x_0 \\in V}")#text(", then there exists at least one further ")#mi("{x \\in V}")#text(" such that ")#mi("{P(x)=P(x_0)}")#text(".")

#text("If ")#mi("{P}")#text(" has degree at most ")#mi("{d}")#text(" and ")#mi("{x_0 \\in V}")#text(", obtain the recurrence inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ x \\in V: P(x) = P(x_0)\\}\\right| \\gg_{p,d} |V|.", block: true)]]

#emph[#text("Hint:")]#text(" normalise ")#mi("{x_0=0}")#text(", then average the previous claim over all subspaces of ")#mi("{V}")#text(" of a certain dimension.")
]

#text("The above exercise goes some way towards establishing equidistribution, by showing that every element in the image of ")#mi("{P}")#text(" is attained a fairly large number of times. But additional techniques will be needed (together with additional hypotheses on ")#mi("{P}")#text(") in order to obtain full equidistribution. It will be convenient to work in the ultralimit setting. Define a ")#emph[#text("limit classical polynomial")]#text(" ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" on a limit finite-dimensional vector space ")#mi("{V = \\prod_{\\alpha \\rightarrow \\alpha_\\infty} V_\\alpha}")#text(" of degree at most ")#mi("{d}")#text(" to be an ultralimit of classical polynomials ")#mi("{P_\\alpha: V_\\alpha \\rightarrow {\\bf F}}")#text(" of degree at most ")#mi("{d}")#text(" (we keep ")#mi("{{\\bf F}}")#text(" and ")#mi("{d}")#text(" fixed independently of ")#mi("{\\alpha}")#text("). We say that a limit classical polynomial ")#mi("{P}")#text(" is ")#emph[#text("equidistributed")]#text(" if one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ x \\in V: P(x) = a \\}\\right| = \\left|V\\right|/p + o(\\left|V\\right|)", block: true)]]

#text("for all ")#mi("{a \\in {\\bf F}}")#text(", where the cardinalities here are of course limit cardinalities.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Let ")#mi("{V}")#text(" be a limit finite-dimensional vector space. Show that a limit function ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" is a limit classical polynomial of degree at most ")#mi("{d}")#text(" if and only if it is a classical polynomial of degree at most ")#mi("{d}")#text(" (observing here that every limit vector space is automatically a vector space).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Let ")#mi("{P = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} P_\\alpha}")#text(" be a limit classical polynomial. Show that ")#mi("{P}")#text(" is equidistributed if and only if, for every ")#mi("{\\delta > 0}")#text(", ")#mi("{P_\\alpha}")#text(" is ")#mi("{\\delta}")#text("-equidistributed for ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Let ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" be a limit classical polynomial which is linear (i.e. of degree at most ")#mi("{1}")#text("). Show that ")#mi("{P}")#text(" is equidistributed if and only if ")#mi("{P}")#text(" is non-constant.")
]

#text("There is an analogue of the Weyl criterion in this setting. Call a limit function ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" ")#emph[#text("biased")]#text(" if ")#tao-math("{\\left|{\\bf E}_{x \\in V} e(P(x))\\right| \\gg 1}", block: false)#text(", and ")#emph[#text("unbiased")]#text(" if ")#mi("{{\\bf E}_{x \\in V} e(P(x)) = o(1)}")#text(", where we identify ")#mi("{P(x) \\in {\\bf F}}")#text(" with an element of ")#mi("{{\\bf R}/{\\bf Z}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Weyl criterion)")]#text(" Let ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" be a limit function. Show that ")#mi("{P}")#text(" is equidistributed if and only if ")#mi("{kP}")#text(" is unbiased for all non-zero ")#mi("{k \\in {\\bf F}}")#text(".")
]

#text("Thus to understand the equidistribution of polynomials, it suffices to understand the size of exponential sums ")#mi("{{\\bf E}_{x \\in V} e(P(x))}")#text(". For linear polynomials, this is an easy application of Fourier analysis:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" ")#metadata(none) <tao-b6fee6bb39011da95761>#text(" Let ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" be a polynomial of degree at most ")#mi("{1}")#text(". Show that ")#tao-math("{\\left|{\\bf E}_{x \\in V} e(P(x))\\right|}", block: false)#text(" equals ")#mi("{1}")#text(" if ")#mi("{P}")#text(" is constant, and equals ")#mi("{0}")#text(" if ")#mi("{P}")#text(" is not constant. (Note that this is completely consistent with the previous two exercises.)")
]

#text("Next, we turn attention to the quadratic case. Here, we can use the Weyl differencing trick, which we phrase as an identity ")#metadata(none) <tao-490ddef24b9665eac31a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|\\mathop{\\bf E}_{x \\in V} f(x)\\right|^2 = \\mathop{\\bf E}_{h \\in V} \\mathop{\\bf E}_{x \\in V} \\Delta_h f(x)", block: true)]]

#text("for any finite vector space ")#mi("{V}")#text(" and function ")#mi("{f: V \\rightarrow {\\bf C}}")#text(", where ")#mi("{\\Delta_h f(x) := f(x+h) \\overline{f(x)}}")#text(" is the multiplicative derivative. Taking ultralimits, we see that the identity also holds for limit functions on limit finite dimensional vector spaces. In particular, we have ")#metadata(none) <tao-b2a7addb40f6e03356f7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|\\mathop{\\bf E}_{x \\in V} e(P(x))\\right|^2 = \\mathop{\\bf E}_{h \\in V} \\mathop{\\bf E}_{x \\in V} e( \\partial_h P(x) )", block: true)]]

#text("for any limit function ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" on a limit finite dimensional space.")

#text("If ")#mi("{P}")#text(" is quadratic, then ")#mi("{\\partial_h P}")#text(" is linear. Applying ")#link(<tao-b6fee6bb39011da95761>)[#text("(11)")]#text(", we conclude that if ")#mi("{P}")#text(" is biased, then ")#mi("{\\partial_h P}")#text(" must be constant for ")#tao-math("{\\gg \\left|V\\right|}", block: false)#text(" values of ")#mi("{h \\in V}")#text(".")

#text("On the other hand, by using the cocycle identity")

#align(center)[#tao-fit-display[#mitex("\\partial_{h+k} P(x) = \\partial_h P(x+k) + \\partial_k P(x)")]]

#text("we see that the set of ")#mi("{h \\in V}")#text(" for which ")#mi("{\\partial_h P}")#text(" is constant is a limit subspace of ")#mi("{W}")#text(". On that subspace, ")#mi("{P}")#text(" is then linear; passing to a codimension one subspace ")#mi("{W^{\\prime}}")#text(" of ")#mi("{W}")#text(", ")#mi("{P}")#text(" is then constant on ")#mi("{W^{\\prime}}")#text(". As ")#mi("{\\partial_h P}")#text(" is linear for every ")#mi("{h}")#text(", ")#mi("{P}")#text(" is then linear on each coset ")#mi("{h+W^{\\prime}}")#text(" of ")#mi("{W^{\\prime}}")#text(". As ")#tao-math("{\\left|W^{\\prime}\\right| \\gg \\left|V\\right|}", block: false)#text(", there are only a bounded number of such cosets; thus ")#mi("{P}")#text(" is piecewise linear, and thus piecewise constant on slightly smaller cosets. Intersecting all the subspaces together, we can thus find another limit subspace ")#mi("{U}")#text(" with ")#tao-math("{\\left|U\\right| \\gg \\left|V\\right|}", block: false)#text(" such that ")#mi("{P}")#text(" is constant on each coset of ")#mi("{U}")#text(". To put it another way, if we view ")#mi("{U}")#text(" as the intersection of a bounded number of kernels of linear homomorphism ")#mi("{L_1,\\ldots,L_d: V \\rightarrow {\\bf F}}")#text(" (where ")#mi("{d=O(1)}")#text(" is the codimension of ")#mi("{U}")#text("), then ")#mi("{P}")#text(" is constant on every simultaneous level set of ")#mi("{L_1,\\ldots,L_d}")#text(", and can thus be expressed as a function ")#mi("{F(L_1,\\ldots,L_d)}")#text(" of these linear polynomials.")

#text("More generally, let us say that a limit classical polynomial ")#mi("{P}")#text(" of degree ")#mi("{\\leq d}")#text(" is ")#emph[#text("low rank")]#text(" if it can be expressed as ")#mi("{P = F(Q_1,\\ldots,Q_d)}")#text(" where ")#mi("{Q_1,\\ldots,Q_d}")#text(" are a bounded number of polynomials of degree ")#mi("{\\leq d-1}")#text(". We can summarise the above discussion (and also Exercise ")#link(<tao-b6fee6bb39011da95761>)[#text("11")]#text(") as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3")]#text(" ")#metadata(none) <tao-d17076761427f124d5a5>#text(" Let ")#mi("{d \\leq 2}")#text(", and let ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" be a limit classical polynomial. If ")#mi("{P}")#text(" is biased, then ")#mi("{P}")#text(" is low rank.")

#text("In particular, from the Weyl criterion, we see that if ")#mi("{P}")#text(" is not equidistributed, then ")#mi("{P}")#text(" is of low rank.")
]

#text("Of course, the claim fails if the low rank hypothesis is dropped. For instance, consider a limit classical quadratic ")#mi("{Q=L_1L_2}")#text(" that is the product of two linearly independent linear polynomials ")#mi("{L_1, L_2}")#text(". Then ")#mi("{Q}")#text(" attains each non-zero value with a density of ")#mi("{(p-1)/p^2}")#text(" rather than ")#mi("{1/p}")#text(" (and attains ")#mi("{0}")#text(" with a density of ")#mi("{(2p-1)/p^2}")#text(" rather than ")#mi("{1/p}")#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Suppose that the characteristic ")#mi("{p}")#text(" of ")#mi("{{\\bf F}}")#text(" is greater than ")#mi("{2}")#text(", and suppose that ")#mi("{P: {\\bf F}^n \\rightarrow {\\bf F}}")#text(" is a quadratic polynomial of the form ")#mi("{P(x) = x^T M x + b^T x + c}")#text(", where ")#mi("{c \\in {\\bf F}}")#text(", ")#mi("{b \\in {\\bf F}^n}")#text(", ")#mi("{M}")#text(" is a symmetric ")#mi("{n \\times n}")#text(" matrix with coefficients in ")#mi("{{\\bf F}}")#text(", and ")#mi("{x^T}")#text(" is the transpose of ")#mi("{x}")#text(". Show that ")#tao-math("{\\left|\\mathop{\\bf E}_{x \\in V} e(P(x))\\right| \\leq p^{-r/2}}", block: false)#text(", where ")#mi("{r}")#text(" is the rank of ")#mi("{M}")#text(". Furthermore, if ")#mi("{b}")#text(" is orthogonal to the kernel of ")#mi("{M}")#text(", show that equality is attained, and otherwise ")#mi("{\\mathop{\\bf E}_{x \\in V} e(P(x))}")#text(" vanishes.")

#text("What happens in the even characteristic case (assuming now that ")#mi("{M}")#text(" is not symmetric)?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Van der Corput lemma)")]#text(" Let ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" be a limit function on a limit finite dimensional vector space ")#mi("{V}")#text(", and suppose that there exists a limit subset ")#mi("{H}")#text(" of ")#mi("{V}")#text(" which is sparse in the sense that ")#tao-math("{\\left|H\\right|=o(\\left|V\\right|)}", block: false)#text(", and such that ")#mi("{\\partial_h P}")#text(" is equidistributed for all ")#mi("{h \\in V \\backslash H}")#text(". Show that ")#mi("{P}")#text(" itself is equidistributed. Use this to give an alternate proof of ")#link(<tao-d17076761427f124d5a5>)[#text("3")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14 (Space of polynomials is discrete)")]#text(" ")#metadata(none) <tao-4a226e517dfd28ab628c>#text(" Let ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" be a polynomial of degree at most ")#mi("{d}")#text(" such that ")#tao-math("{{\\bf E}_{x \\in V} \\left|e(P(x)) - c\\right| < 2^{-d+1}}", block: false)#text(" for some constant ")#mi("{c \\in S^1}")#text(". Show that ")#mi("{P}")#text(" is constant. (")#emph[#text("Hint:")]#text(" induct on ")#mi("{d}")#text(".) Conclude that if ")#mi("{P, Q}")#text(" are two distinct polynomials of degree at most ")#mi("{d}")#text(", that ")#tao-math("{\\left\\|e(P)-e(Q)\\right\\|_{L^2(V)} \\gg 1}", block: false)#text(".")
]

#text("The fact that high rank polynomials are equidistributed extends to higher degrees also:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4")]#text(" ")#metadata(none) <tao-fb3e665c703371f87bf1>#text(" Let ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" be a limit classical polynomial. If ")#mi("{P}")#text(" is biased, then ")#mi("{P}")#text(" is low rank.")

#text("In particular, from the Weyl criterion, we see that if ")#mi("{P}")#text(" is not equidistributed, then ")#mi("{P}")#text(" is of low rank.")
]

#text("In the high characteristic case ")#mi("{p>d}")#text(", this claim was obtained ")#link("http://arxiv.org/abs/0711.3191")[#text("by Ben Green and myself")]#text("; the generalisation to the low characteristic case ")#mi("{p \\leq d}")#text(" was carried out ")#link("http://arxiv.org/abs/0806.4535")[#text("by Kaufman and Lovett")]#text(". The statement is phrased in the language of ultrafilters, but it has an equivalent finitary analogue:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" Show that Theorem ")#link(<tao-fb3e665c703371f87bf1>)[#text("4")]#text(" is equivalent to the claim that for every ")#mi("{d \\geq 1}")#text(" and ")#mi("{\\delta > 0}")#text(", and every classical polynomial ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" of degree at most ")#mi("{d}")#text(" on a finite-dimensional vector space with ")#tao-math("{\\left|{\\bf E}_{x \\in V} e(P(x))\\right| \\geq \\delta}", block: false)#text(", that ")#mi("{P}")#text(" can be expressed as a function of at most ")#mi("{O_{\\delta,d}(1)}")#text(" classical polynomials of degree at most ")#mi("{d-1}")#text(".")
]

#text("The proof of Theorem ")#link(<tao-fb3e665c703371f87bf1>)[#text("4")]#text(" is a little lengthy. It splits up into two pieces. We say that a limit function ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" (not necessarily a polynomial) is ")#emph[#text("of order ")#mi("{<d}")]#text(" if it can be expressed as a function of a bounded number of polynomials of degree less than ")#mi("{d}")#text(". Our task is thus to show that every polynomial of degree ")#mi("{d}")#text(" which is biased, is of order ")#mi("{<d}")#text(". We first get within an epsilon of this goal, using an ")#link("http://www.cse.cuhk.edu.hk/~andrejb/pubs/lowdeggen.pdf")[#text("argument of Bogdanov and Viola")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (Bogdanov-Viola lemma)")]#text(" ")#metadata(none) <tao-c5c8fcbf6d9460bd16fa>#text(" Let ")#mi("{P: V\\rightarrow {\\bf F}}")#text(" be a limit polynomial of degree ")#mi("{d}")#text(" which is biased, and let ")#mi("{\\epsilon > 0}")#text(" be standard. Then one can find a limit function ")#mi("{Q: V \\rightarrow {\\bf F}}")#text(" of order ")#mi("{<d}")#text(" such that ")#tao-math("{\\left|\\{ x \\in V: P(x) \\neq Q(x) \\}\\right| \\leq \\epsilon \\left|V\\right|}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\kappa > 0}")#text(" be a small standard number (depending on ")#mi("{\\epsilon}")#text(") to be chosen later, let ")#mi("{M}")#text(" be a large standard integer (depending on ")#mi("{\\epsilon,\\kappa}")#text(") to be chosen later, and let ")#mi("{h_1,\\ldots,h_M}")#text(" be chosen uniformly at random from ")#mi("{V}")#text(". An application of the second moment method (which we leave as an exercise) shows that if ")#mi("{M}")#text(" is large enough, then with probability at least ")#mi("{1-\\epsilon}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathop{\\bf E}_{m \\in M} e( P( x + h_m ) ) - \\mathop{\\bf E}_{x \\in V} e( P(x) )\\right| \\leq \\kappa", block: true)]]

#text("for at least ")#tao-math("{(1-\\epsilon)\\left|V\\right|}", block: false)#text(" choices of ")#mi("{x}")#text(". We can rearrange this as")

#align(center)[#tao-fit-display[#tao-math("\\left|e(P(x)) - \\frac{1}{\\delta} \\mathop{\\bf E}_{m \\in M} e( -\\partial_{h_m} P( x ) )\\right| \\leq \\kappa/\\delta", block: true)]]

#text("where ")#tao-math("{\\delta := \\left|\\mathop{\\bf E}_{x \\in V} e(P(x))\\right|}", block: false)#text("; note from hypothesis that ")#mi("{\\delta \\gg 1}")#text(". If we let ")#mi("{F(x)}")#text(" be the nearest ")#mi("{p^{th}}")#text(" root of unity to ")#mi("{\\frac{1}{\\delta} \\mathop{\\bf E}_{m \\in M} e( -\\partial_{h_m} P( x ) )}")#text(", then (if ")#mi("{\\kappa}")#text(" is small enough) we conclude that ")#mi("{e(P(x)) = F(x)}")#text(" for at least ")#tao-math("{(1-\\epsilon)\\left|V\\right|}", block: false)#text(" choices of ")#mi("{x}")#text(". On the other hand, ")#mi("{F}")#text(" is clearly of order ")#mi("{<d}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Establish the claim left as an exercise in the above proof.")
]

#text("To conclude the proof of Theorem ")#link(<tao-fb3e665c703371f87bf1>)[#text("4")]#text(" from Lemma ")#link(<tao-c5c8fcbf6d9460bd16fa>)[#text("5")]#text(", it thus suffices to show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6 (Rigidity)")]#text(" ")#metadata(none) <tao-4bab36ce40d3a7f543a2>#text(" Let ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" be a limit polynomial of degree ")#mi("{d}")#text(" which is equal to a limit function ")#mi("{Q: V \\rightarrow {\\bf F}}")#text(" of order ")#mi("{<d}")#text(" on at least ")#mi("{1-\\epsilon}")#text(" of ")#mi("{V}")#text(", where ")#mi("{\\epsilon > 0}")#text(" is standard. If ")#mi("{\\epsilon}")#text(" is sufficiently small with respect to ")#mi("{d}")#text(", then ")#mi("{P}")#text(" is also of order ")#mi("{<d}")#text(".")
]

#text("This proposition is somewhat tricky to prove, even in the high characteristic case ")#mi("{p>d}")#text(". We fix ")#mi("{d<p}")#text(" and assume inductively that the proposition (and hence) Theorem ")#link(<tao-fb3e665c703371f87bf1>)[#text("4")]#text(" has been demonstrated for all smaller values of ")#mi("{d}")#text(".")

#text("The main idea here is to start with the “noisy polynomial” ")#mi("{Q}")#text(", and perform some sort of “error correction” on ")#mi("{Q}")#text(" to recover ")#mi("{P}")#text("; the key is then to show that this error correction procedure preserves the property of being order ")#mi("{<d}")#text(". From Exercise ")#link(<tao-4a226e517dfd28ab628c>)[#text("14")]#text(" we know that ")#emph[#text("in principle")]#text(", this error correction is possible if ")#mi("{\\epsilon}")#text(" is small enough; but in order to preserve the order ")#mi("{<d}")#text(" property we need a more explicit error correction algorithm which is tractable for analysis. This is provided by the following lemma.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7 (Error correction of polynomials)")]#text(" Let ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" be a (limit) classical polynomial of degree at most ")#mi("{d}")#text(", and let ")#mi("{Q: V \\rightarrow {\\bf F}}")#text(" be a (limit) function which agrees with ")#mi("{P}")#text(" at least ")#mi("{1-\\epsilon}")#text(" of the time for some ")#mi("{\\epsilon \\leq 2^{-d-2}}")#text(". Then for every ")#mi("{x \\in V}")#text(", ")#mi("{P(x)}")#text(" is equal to the most common value (i.e. the mode) of ")#tao-math("{\\sum_{\\omega \\in \\{0,1\\}^{d+1} \\backslash \\{0\\}} (-1)^{\\left|\\omega\\right|-1} Q(x+\\omega_1 h_1+ \\ldots + \\omega_{d+1} h_{d+1})}", block: false)#text(" as ")#mi("{h_1,\\ldots,h_{d+1}}")#text(" vary in ")#mi("{V}")#text(".")
]

#emph[#text("Proof:")]#text(" As ")#mi("{P}")#text(" is a polynomial of degree at most ")#mi("{d}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\partial_{h_1} \\ldots \\partial_{h_{d+1}} P(x) = 0")]]

#text("for all ")#mi("{x,h_1,\\ldots,h_{d+1} \\in V}")#text(". We rearrange this as")

#align(center)[#tao-fit-display[#tao-math("P(x) = \\sum_{\\omega \\in \\{0,1\\}^{d+1} \\backslash \\{0\\}} (-1)^{\\left|\\omega\\right|-1} P(x+\\omega_1 h_1 + \\ldots + \\omega_{d+1} h_{d+1} ).", block: true)]]

#text("We conclude that ")#metadata(none) <tao-e642b12901a6ee51456f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("P(x) = \\sum_{\\omega \\in \\{0,1\\}^{d+1} \\backslash \\{0\\}} (-1)^{\\left|\\omega\\right|-1} Q(x+\\omega_1 h_1 + \\ldots + \\omega_{d+1} h_{d+1} \\omega_{d+1})", block: true)]]

#text("holds unless ")#mi("{P}")#text(" and ")#mi("{Q}")#text(" differ at ")#mi("{x+h_1\\omega_1+\\ldots+h_{d+1} \\omega_{d+1}}")#text(" for some ")#mi("{\\omega \\in \\{0,1\\}^{d+1} \\backslash \\{0\\}}")#text(".")

#text("On the other hand, if ")#mi("{x}")#text(" is fixed and ")#mi("{h_1,\\ldots,h_{d+1}}")#text(" are chosen independently and uniformly at random from ")#mi("{V}")#text(", then for each ")#mi("{\\omega \\in \\{0,1\\}^{d+1} \\backslash \\{0\\}}")#text(", ")#mi("{x+h_1\\omega_1+\\ldots+h_{d+1} \\omega_{d+1}}")#text(" is also uniformly distributed in ")#mi("{V}")#text(", and so the probability that ")#mi("{P}")#text(" and ")#mi("{Q}")#text(" differ at ")#mi("{x+h_1\\omega_1+\\ldots+h_{d+1} \\omega_{d+1}}")#text(" is at most ")#mi("{2^{-d-2}}")#text(". Applying the union bound for the ")#mi("{2^{d+1}-1 < 2^{d+1}}")#text(" values of ")#mi("{\\omega}")#text(" under consideration, we conclude that ")#link(<tao-e642b12901a6ee51456f>)[#text("(3)")]#text(" happens more than half the time, and the claim follows. ")#mi("\\Box")

#text("Note that the above argument in fact shows that the mode is attained for at least ")#mi("{1 - 2^{d+1} \\epsilon}")#text(" of the choices of ")#mi("{h_1,\\ldots,h_{d+1}}")#text(".")

#text("In view of this lemma, the goal is now to show that if ")#mi("{Q}")#text(" is of order ")#mi("{<d}")#text(" and is sufficiently close to a polynomial of degree ")#mi("{d}")#text(", then the mode of ")#tao-math("{\\sum_{\\omega \\in \\{0,1\\}^{d+1} \\backslash \\{0\\}} (-1)^{\\left|\\omega\\right|-1} Q(x+\\omega_1 h_1+ \\ldots + \\omega_{d+1} h_{d+1})}", block: false)#text(" is also of order ")#mi("{<d}")#text(".")

#text("By hypothesis, we have ")#mi("{Q = F(R_1,\\ldots,R_m)}")#text(" for some standard ")#mi("{m}")#text(" and some polynomials ")#mi("{R_1,\\ldots,R_m}")#text(" of degree ")#mi("{d-1}")#text(". To motivate the general argument, let us first work in an easy model case, in which the ")#mi("{R_1,\\ldots,R_m}")#text(" are polynomials of degree ")#mi("{d-1}")#text(" that are linearly independent modulo low rank (i.e. order ")#mi("{<d-2}")#text(") errors, i.e. no non-trivial linear combination of ")#mi("{R_1,\\ldots,R_m}")#text(" over ")#mi("{{\\bf F}}")#text(" is of low rank. This is not the most general case, but is somewhat simpler and will serve to illustrate the main ideas.")

#text("The linear independence, combined with the inductive hypothesis, implies that any non-trivial linear combination of ")#mi("{R_1,\\ldots,R_m}")#text(" is unbiased. From this and Fourier analysis, we see that ")#mi("{\\vec R := (R_1,\\ldots,R_m)}")#text(" is jointly equidistributed, thus in particular we have ")#metadata(none) <tao-93af2521b866413b9a87>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|S_r\\right| = (p^{-m} + o(1)) \\left|V\\right|", block: true)]]

#text("for all ")#mi("{r \\in {\\bf F}^m}")#text(", where ")#mi("{S_r := \\{ x \\in V: \\vec R(x)=r\\}}")#text(".")

#text("In fact, we have a much stronger equidistribution property than this; not only do we understand the distribution of ")#mi("{\\vec R(x)}")#text(" for a single ")#mi("{x}")#text(", but more generally we can control the distribution of an entire parallelopiped")

#align(center)[#tao-fit-display[#mitex("\\vec R^{[D]}(x,h_1,\\ldots,h_D) := ( \\vec R(x + \\omega_1 h_1 + \\ldots + \\omega_D h_D ) )_{\\omega_1,\\ldots,\\omega_D \\in \\{0,1\\}}")]]

#text("for any standard integer ")#mi("{D \\geq 0}")#text(". Because all the components ")#mi("{\\vec R}")#text(" are polynomials of degree ")#mi("{d-1}")#text(", the quantity ")#mi("{\\vec R^{[D]}(x,h_1,\\ldots,h_D)}")#text(" is constrained to the space ")#mi("{\\Sigma^{[D]}}")#text(", defined as the subspace of ")#mi("{({\\bf F}^m)^{2^D}}")#text(" consisting of all tuples ")#mi("{r = ( r_{\\omega} )_{\\omega \\in \\{0,1\\}^D}}")#text(" obeying the constraints")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\omega \\in F} (-1)^{\\left|\\omega\\right|} r_\\omega = 0", block: true)]]

#text("for all faces ")#mi("{F \\subset \\{0,1\\}^D}")#text(" of dimension ")#mi("{d}")#text(", where ")#tao-math("{\\left|\\omega\\right| := \\omega_1+\\ldots+\\omega_D}", block: false)#text(" is the sign of ")#mi("{\\omega}")#text(". (This constraint is of course vacuous if ")#mi("{D<d}")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8")]#text(" ")#metadata(none) <tao-b0b3d39e38862226b17d>#text(" ")#mi("{\\vec R^{[D]}}")#text(" is equidistributed in ")#mi("{\\Sigma^{[D]}}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ (x,h_1,\\ldots,h_D) \\in V^{d+1}: \\vec R^{[D]}(x,h_1,\\ldots,h_D) = r \\}\\right|", block: true)]]

#align(center)[#tao-fit-display[#tao-math("= (\\frac{1}{\\left|\\Sigma^{[D]}\\right|}+o(1)) \\left|V\\right|^{d+1}", block: true)]]

#text("for all ")#mi("{r \\in \\Sigma^{[D]}}")#text(". Furthermore, we have the refined bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ (h_1,\\ldots,h_D) \\in V^{d}: \\vec R^{[D]}(x,h_1,\\ldots,h_D) = r \\}\\right|", block: true)]]

#align(center)[#tao-fit-display[#tao-math("= (\\frac{p^m}{\\left|\\Sigma^{[D]}\\right|}+o(1)) \\left|V\\right|^{d}", block: true)]]

#text("for all ")#mi("{r \\in \\Sigma^{[D]}}")#text(" and all ")#mi("{x \\in S_{r_0}}")#text(".")
]

#emph[#text("Proof:")]#text(" It suffices to prove the second claim. Fix ")#mi("{x}")#text(" and ")#mi("{r = (r_\\omega)_{\\omega \\in \\{0,1\\}^D}}")#text(" From the definition of ")#mi("{\\Sigma^{[D]}}")#text(", we see that ")#mi("{r}")#text(" is uniquely determined by the component ")#mi("{r_0}")#text(" and ")#tao-math("{r_{<d} := (r_\\omega)_{\\omega \\in \\{0,1\\}^D: 0 < \\left|\\omega\\right| < d}}", block: false)#text(". It will thus suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ (x,h_1,\\ldots,h_D) \\in V^{d}: \\vec R^{[D]}_{<d}(x,h_1,\\ldots,h_D) = r_{<d} \\}\\right|", block: true)]]

#align(center)[#tao-fit-display[#tao-math("= (\\frac{p^m}{\\left|\\Sigma^{[D]}\\right|}+o(1)) \\left|V\\right|^{d}", block: true)]]

#text("for all ")#tao-math("{r_{<d} \\in ({\\bf F}^m)^{\\{ \\omega \\in \\{0,1\\}^D: 0 < \\left|\\omega\\right| < d \\}}}", block: false)#text(", where")

#align(center)[#tao-fit-display[#mitex("\\vec R^{[D]}_{<d}(x,h_1,\\ldots,h_D) :=")]]

#align(center)[#tao-fit-display[#tao-math("( \\vec R(x + \\omega_1 h_1 + \\ldots + \\omega_D h_D ) )_{\\omega \\in \\{0,1\\}^D: 0 < \\left|\\omega\\right| < d}.", block: true)]]

#text("By Fourier analysis, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_{h_1,\\ldots,h_D \\in V} e( \\xi \\cdot \\vec R^{[D]}_{<d}(x,h_1,\\ldots,h_D) ) = o(1)")]]

#text("for any non-zero ")#tao-math("{\\xi \\in ({\\bf F}^m)^{\\{ \\omega \\in \\{0,1\\}^D: 0 < \\left|\\omega\\right| < d \\}}}", block: false)#text(". In other words, we need to show that ")#metadata(none) <tao-924a322ebed78cfe2d8b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\mathop{\\bf E}_{h_1,\\ldots,h_D \\in V} e(\\sum_{\\omega \\in \\{0,1\\}^D: \\left|\\omega\\right| < d} \\xi_\\omega \\cdot \\vec R(x + \\omega_1 h_1 + \\ldots + \\omega_D h_D ) ) = o(1)", block: true)]]

#text("whenever the ")#mi("{\\xi_\\omega \\in {\\bf F}^m}")#text(" for ")#tao-math("{\\omega \\in \\{0,1\\}^D, 0<\\left|\\omega\\right|<d}", block: false)#text(" are not all zero.")

#text("Let ")#mi("{\\omega_0}")#text(" be such that ")#mi("{\\xi_{\\omega_0} \\neq 0}")#text(", and such that ")#tao-math("{\\left|\\omega\\right|}", block: false)#text(" is as large as possible; let us write ")#tao-math("{d^{\\prime} := \\left|\\omega_0\\right|}", block: false)#text(", so that ")#mi("{0 \\leq d^{\\prime} < d}")#text(". Without loss of generality we may take ")#mi("{\\omega_0 = (1,\\ldots,1,0,\\ldots,0)}")#text(". Suppose ")#link(<tao-924a322ebed78cfe2d8b>)[#text("(5)")]#text(" failed, then by the pigeonhole principle one can find ")#mi("{h_{d^{\\prime}+1},\\ldots,h_D}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left| \\mathop{\\bf E}_{h_1,\\ldots,h_{d^{\\prime}} \\in V} e(\\sum_{\\omega \\in \\{0,1\\}^D: \\left|\\omega\\right| < d} \\xi_\\omega \\cdot \\vec R(x + \\omega_1 h_1 + \\ldots + \\omega_D h_D ) )\\right| \\gg 1.", block: true)]]

#text("We write the left-hand side as")

#align(center)[#tao-fit-display[#tao-math("\\left| \\mathop{\\bf E}_{h_1,\\ldots,h_{d^{\\prime}} \\in V} e( \\xi_{\\omega_0} \\cdot \\vec R( x + h_1 + \\ldots + h_{d^{\\prime}} ) ) \\prod_{j=1}^{d^{\\prime}} f_j(h_1,\\ldots,h_{d^{\\prime}}) \\right|", block: true)]]

#text("where ")#mi("{f_j}")#text(" are bounded limit functions depending on ")#mi("{x,h_{d^{\\prime}+1},\\ldots,h_D}")#text(" that are independent of ")#mi("{h_j}")#text(".")

#text("We can eliminate each ")#mi("{f_j}")#text(" term in turn by the Cauchy-Schwarz argument used in ")#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/")[#text("Notes 3")]#text(", and conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| e( \\xi_{\\omega_0} \\cdot \\vec R ) \\right\\|_{U^{d^{\\prime}}(V)} \\gg 1,", block: true)]]

#text("and thus by the monotonicity of Gowers norms")

#align(center)[#tao-fit-display[#tao-math("\\left\\| e( \\xi_{\\omega_0} \\cdot \\vec R ) \\right\\|_{U^{d-1}(V)} \\gg 1,", block: true)]]

#text("or in other words that the degree ")#mi("{d-1}")#text(" polynomial ")#mi("{(x,h_1,\\ldots,h_{d-1}) \\mapsto \\partial_{h_1} \\ldots \\partial_{h_{d-1}} (\\xi_{\\omega_0} \\cdot \\vec R)(x)}")#text(" is biased. By the induction hypothesis, this polynomial must be low rank.")

#text("At this point we crucially exploit the high characteristic hypothesis by noting the Taylor expansion formula")

#align(center)[#tao-fit-display[#mitex("P(y) = \\frac{1}{(d-1)!} \\partial_y^{d-1} P(y) + \\text{ low rank errors}.")]]

#text("The high characteristic is necessary here to invert ")#mi("{(d-1)!}")#text(". We conclude that ")#mi("{\\xi_{\\omega_0} \\cdot \\vec R}")#text(" is of low rank, but this contradicts the hypothesis on the ")#mi("{R_1,\\ldots,R_m}")#text(" and the non-zero nature of ")#mi("{\\xi_{\\omega_0}}")#text(", and the claim follows. ")#mi("\\Box")

#text("Let ")#mi("{x \\in V}")#text(" and ")#mi("{r = (r_\\omega)_{\\omega \\in \\{0,1\\}^D} \\in \\Sigma^{[D]}}")#text(". From the above proposition we have an equidistribution result for a cube pinned at ")#mi("{x}")#text(": ")#metadata(none) <tao-c651eea89a40af907ee6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("|\\{ (h_1,\\ldots,h_D) \\in V^{D}: x+\\omega_1 h_1 + \\ldots + \\omega_D h_D \\in S_{r_\\omega}")]]

#align(center)[#tao-fit-display[#tao-math("\\text{ for all } \\omega \\in \\{0,1\\}^D \\}| = (\\frac{p^m}{\\left|\\Sigma^{[D]}\\right|} + o(1)) \\left|V\\right|^{D}.", block: true)]]

#text("In fact, we can do a bit better than this, and obtain equidistribution even after fixing a second vertex:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Equidistribution of doubly pinned cubes)")]#text(" ")#metadata(none) <tao-40aaef56eb55d9372cb1>#text(" Let ")#mi("{(r_\\omega)_{\\omega \\in \\{0,1\\}^D} \\in \\Sigma^{[D]}}")#text(", let ")#mi("{x \\in S_{r_0}}")#text(", let ")#mi("{\\omega^{\\prime} \\in \\{0,1\\}^D \\backslash \\{0\\}}")#text(". Then for all but ")#tao-math("{o(\\left|V\\right|)}", block: false)#text(" elements ")#mi("{y}")#text(" of ")#mi("{S_{r_{\\omega_0}}}")#text(", one has ")#metadata(none) <tao-73e54254d7bad8145b30>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("|\\{ (h_1,\\ldots,h_D) \\in V^{D}: x+\\omega_1 h_1 + \\ldots + \\omega_D h_D \\in S_{r_\\omega}")]]

#tao-aligned(keep: true)[


#tao-math("\\text{ for all } \\omega  & \\in \\{0,1\\}^D; x + \\omega^{\\prime}_1 h_1 + \\ldots + \\omega^{\\prime}_D h_D = y \\}|", block: true)



#tao-math(" & = (\\frac{p^m}{\\left|\\Sigma^{[D]}\\right|} + o(1)) \\left|V\\right|^{D-1}.", block: true)
]

#text("(")#emph[#text("Hint:")]#text(" One can proceed by applying Proposition ")#link(<tao-b0b3d39e38862226b17d>)[#text("8")]#text(" with ")#mi("{D}")#text(" replaced by a larger dimension, such as ")#mi("{2D}")#text("; details can be found in the ")#link("http://arxiv.org/abs/0711.3191")[#text("paper of Ben Green and myself")]#text(".)")
]

#text("We can now establish Proposition ")#link(<tao-4bab36ce40d3a7f543a2>)[#text("6")]#text(" in the case where the ")#mi("{R_1,\\ldots,R_m}")#text(" are independent modulo low rank errors. Let ")#mi("{r_0 \\in {\\bf F}^m}")#text(" and ")#mi("{x \\in S_{r_0}}")#text(". It will suffice to show that ")#mi("{P(x)}")#text(" does not depend on ")#mi("{x}")#text(" as long as ")#mi("{x}")#text(" stays inside ")#mi("{r_0}")#text(".")

#text("Call an atom ")#mi("{S_r}")#text(" ")#emph[#text("good")]#text(" if ")#mi("{P}")#text(" and ")#mi("{Q}")#text(" agree for at least ")#mi("{1-\\sqrt{\\epsilon}}")#text(" of the elements of ")#mi("{S_r}")#text("; by Markov’s inequality (and ")#link(<tao-93af2521b866413b9a87>)[#text("(4)")]#text(") we see that at least ")#mi("{1-\\sqrt{\\epsilon}+o(1)}")#text(" of the atoms are good. From this and an easy counting argument we can find an element ")#mi("{r = (r_\\omega)_{\\omega \\in \\{0,1\\}^d}}")#text(" in ")#mi("{\\Sigma^{[d]}}")#text(" with the specified value of ")#mi("{r_0}")#text(", such that ")#mi("{r_\\omega}")#text(" is good for every ")#mi("{\\{0,1\\}^d \\backslash \\{0\\}}")#text(".")

#text("Fix ")#mi("{r}")#text(". Now consider all the pinned cubes ")#mi("{(x+h_1 \\omega_1+\\ldots+h_d\\omega_d)_{\\omega_1,\\ldots,\\omega_d \\in \\{0,1\\}^d}}")#text(" with ")#mi("{x+h_1\\omega_1+\\ldots+h_d\\omega_d \\in S_{r_\\omega}}")#text(" for all ")#mi("{\\omega \\in \\{0,1\\}^d \\backslash \\{0\\}}")#text(". By ")#link(<tao-c651eea89a40af907ee6>)[#text("(6)")]#text(", the number of such cubes is ")#tao-math("{(\\frac{p^m}{\\left|\\Sigma^{[d]}\\right|} + o(1)) \\left|V\\right|^{d}}", block: false)#text(". On the other hand, by Proposition ")#link(<tao-40aaef56eb55d9372cb1>)[#text("17")]#text(", the total number of such cubes for which")

#align(center)[#tao-fit-display[#mitex("P(x+h_1\\omega_1+\\ldots+h_d\\omega_d) \\neq Q(x+h_1\\omega_1+\\ldots+h_d\\omega_d)")]]

#text("for some ")#mi("{\\omega \\in \\{0,1\\}^d \\backslash \\{0\\}}")#text(" is ")#tao-math("{o(\\left|V\\right|^{d-1})}", block: false)#text(". We conclude that there exists a pinned cube for which")

#align(center)[#tao-fit-display[#mitex("P(x+h_1\\omega_1+\\ldots+h_d\\omega_d) = Q(x+h_1\\omega_1+\\ldots+h_d\\omega_d)")]]

#text("for all ")#mi("{\\omega \\in \\{0,1\\}^d \\backslash \\{0\\}}")#text(", and in particular ")#link(<tao-e642b12901a6ee51456f>)[#text("(3)")]#text(" holds. However, as ")#mi("{Q}")#text(" is constant on each of the ")#mi("{S_r}")#text(", we see that the right-hand side of ")#link(<tao-e642b12901a6ee51456f>)[#text("(3)")]#text(" does not depend on ")#mi("{x}")#text(", and so the left-hand side does also.")

#text("This completes the proof of Proposition ")#link(<tao-4bab36ce40d3a7f543a2>)[#text("6")]#text(" in the independent case. In the general case, one reduces to a (slight generalisation of) this case by the following regularity lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9 (Regularity lemma)")]#text(" Let ")#mi("{R_1,\\ldots,R_m}")#text(" be a bounded number of limit classical polynomials of degree ")#mi("{\\leq d-1}")#text(". Then there exists a limit classical bounded number of polynomials ")#mi("{S_{d^{\\prime},1},\\ldots,S_{d^{\\prime},m_{d^{\\prime}}}}")#text(" of degree ")#mi("{\\leq d^{\\prime}}")#text(" for each ")#mi("{1 \\leq d^{\\prime} \\leq d-1}")#text(", such that each ")#mi("{R_1,\\ldots,R_m}")#text(" is a function of the ")#mi("{S_{d^{\\prime},i}}")#text(" for ")#mi("{1 \\leq d^{\\prime} \\leq d}")#text(" and ")#mi("{1 \\leq i \\leq m_{d^{\\prime}}}")#text(", and such that for each ")#mi("{d^{\\prime}}")#text(", the ")#mi("{S_{d^{\\prime},1},\\ldots,S_{d^{\\prime},m_{d^{\\prime}}}}")#text(" are independent modulo low rank polynomials of degree ")#mi("{d^{\\prime}}")#text(".")
]

#emph[#text("Proof:")]#text(" We induct on ")#mi("{d}")#text(". The claim is vacuously true for ")#mi("{d=1}")#text(", so suppose that ")#mi("{d>1}")#text(" and that the claim has already been proven for ")#mi("{d-1}")#text(".")

#text("Let ")#mi("{Poly_{d-1}}")#text(" be the space of limit classical polynomials of degree ")#mi("{\\leq d-1}")#text(", and let ")#mi("{Poly_{d-1}^0}")#text(" be the subspace of low rank limit classical polynomials. Working in the quotient space ")#mi("{Poly_{d-1}/Poly_{d-1}^0}")#text(", we see that ")#mi("{R_1,\\ldots,R_m}")#text(" generates a finite-dimensional space here, which thus has a basis ")#mi("{S_{d-1,1},\\ldots,S_{d-1,m_{d-1}} \\text{ mod } Poly_{d-1}^0}")#text(", thus ")#mi("{S_{d-1,1},\\ldots,S_{d-1,m_{d-1}}}")#text(" are linearly independent modulo low rank polynomials of degree ")#mi("{d-1}")#text(", and the ")#mi("{R_1,\\ldots,R_m}")#text(" are linear combinations of the ")#mi("{S_{d-1,1},\\ldots,S_{d-1,m_{d-1}}}")#text(" plus combinations of some additional polynomials ")#mi("{R^{\\prime}_1,\\ldots,R^{\\prime}_{m^{\\prime}}}")#text(" of degree ")#mi("{d-2}")#text(". Applying the induction hypothesis to those additional polynomials, one obtains the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Show that the polynomials ")#mi("{S := (S_{d^{\\prime},i})_{1 \\leq d^{\\prime} \\leq d-1; 1 \\leq i \\leq m_{d^{\\prime}}} )}")#text(" appearing in the above lemma are equidistributed in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ x \\in V: S(x) = s \\}\\right| = (\\frac{1}{p^{\\sum_{d^{\\prime}=1}^d m_{d^{\\prime}}}} +o(1)) \\left|V\\right|", block: true)]]

#text("for any ")#mi("{s = ( s_{d^{\\prime},i})_{1 \\leq d^{\\prime} \\leq d-1; 1\\leq i \\leq m_{d^{\\prime}} }}")#text(" with ")#mi("{s_{d^{\\prime},i} \\in {\\bf F}}")#text(".")
]

#text("Applying the above lemma, one can express any order ")#mi("{<d}")#text(" function ")#mi("{Q}")#text(" in the form ")#mi("{Q = F( (S_{d^{\\prime},i})_{1 \\leq d^{\\prime} \\leq d-1; 1 \\leq i \\leq m_{d^{\\prime}}} )}")#text(". It is then possible to modify the previous arguments to obtain Proposition ")#link(<tao-4bab36ce40d3a7f543a2>)[#text("6")]#text("; see the ")#link("http://arxiv.org/abs/0711.3191")[#text("paper of Ben Green and myself")]#text(" for more details. (We phrase the arguments in a finitary setting rather than a nonstandard one, but the two approaches are equivalent; see ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("this blog post")]#text(" for more discussion.)")

#text("It is possible to modify the above arguments to handle the low characteristic case, but due to the lack of a good Taylor expansion, one has to regularise the derivatives of the polynomials, as well as the polynomials themselves; see ")#link("http://arxiv.org/abs/0806.4535")[#text("the paper of Kaufman and Lovett")]#text(" for details.")

#heading(level: 1)[#strong[#text(" — 3. Analytic rank — ")]]

#text("Define the ")#emph[#text("rank")]#text(" ")#mi("{rank_{d-1}(P)}")#text(" of a degree ")#mi("{d}")#text(" (limit) classical polynomial ")#mi("{P}")#text(" to be the least number ")#mi("{m}")#text(" of degree ")#mi("{\\leq d-1}")#text(" (limit) classical polynomials ")#mi("{R_1,\\ldots,R_m}")#text(" such that ")#mi("{P}")#text(" is a function of ")#mi("{R_1,\\ldots,R_m}")#text(". Theorem ")#link(<tao-d17076761427f124d5a5>)[#text("3")]#text(" tells us that ")#mi("{P}")#text(" is equidistributed whenever the rank is unbounded. However, the proof was rather involved. There is a more elementary approach to equidistribution due ")#link("http://arxiv.org/abs/1002.2208")[#text("to Gowers and Wolf")]#text(" which replaces the rank by a different object, called ")#emph[#text("analytic rank")]#text(", and which can serve as a simpler substitute for the concept of rank in some applications.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 10 (Analytic rank)")]#text(" The analytic rank ")#mi("{arank_{d-1}(P)}")#text(" of a (limit) classical polynomial ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" of degree ")#mi("{\\leq d}")#text(" is defined to be the quantity")

#tao-aligned(keep: true)[


#tao-math("arank_d(P)  & := - \\log_p \\mathop{\\bf E}_{x,h_1,\\ldots,h_d \\in V} e( \\partial_{h_1} \\ldots \\partial_{h_d} P(x) )", block: true)



#tao-math(" & = -2^{d} \\log_p \\left\\| e(P) \\right\\|_{U^d(V)}.", block: true)
]
]

#text("From the properties of the Gowers norms we see that this quantity is non-negative, is zero if and only if ")#mi("{P}")#text(" is a polynomial of degree ")#mi("{<d}")#text(", and is finite (or limit finite) for ")#mi("{d>2}")#text(". (For ")#mi("{d=1}")#text(", the analytic rank is infinite if ")#mi("{P}")#text(" is non-constant and zero if ")#mi("{P}")#text(" is constant.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Show that if ")#mi("{p>2}")#text(" and ")#mi("{P}")#text(" is a (limit) classical polynomial of degree ")#mi("{2}")#text(", then ")#mi("{rank_1(P)=arank_1(P)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Show that if the analytic rank ")#mi("{arank_{d-1}(P)}")#text(" of a limit classical polynomial ")#mi("{P}")#text(" of degree ")#mi("{d}")#text(" is unbounded, then ")#mi("{P}")#text(" is equidistributed.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Suppose we are in the high characteristic case ")#mi("{p>d}")#text(" Using Theorem ")#link(<tao-d17076761427f124d5a5>)[#text("3")]#text(", show that a limit classical polynomial has bounded analytic rank if and only if it has bounded rank. (")#emph[#text("Hint:")]#text(" One direction follows from the preceding exercise. For the other direction, use the Taylor formula ")#mi("{P(x) = \\frac{1}{d!} \\partial_x^d P(x)}")#text(".) This is a special case of the ")#emph[#text("inverse conjecture for the Gowers norms")]#text(", which we will discuss in more detail in later notes.")

#text("Conclude the following finitary version: if ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" is a classical polynomial of degree ")#mi("{d}")#text(" on a finite-dimensoinal vector space ")#mi("{V}")#text(", and ")#mi("{arank_{d-1}(P) \\leq M}")#text(", then ")#mi("{rank_{d-1}(P) \\ll_{M,p,d} 1}")#text("; conversely, if ")#mi("{rank_{d-1}(P) \\leq M}")#text(", then ")#mi("{arank_{d-1}(P) \\ll_{M,p,d} 1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Show that if ")#mi("{P}")#text(" is a (limit) classical polynomial of degree ")#mi("{d}")#text(", then ")#mi("{rank_{d-1}(P)=rank_{d-1}(cP)}")#text(" and ")#mi("{arank_{d-1}(P) = arank_{d-1}(cP)}")#text(" for all ")#mi("{c \\in {\\bf F} \\backslash 0}")#text(", and ")#mi("{rank_{d-1}(P+Q) = rank_{d-1}(P)}")#text(" and ")#mi("{arank_{d-1}(P+Q) = arank_{d-1}(P)}")#text(" for all (limit) classical polynomials ")#mi("{Q}")#text(" of degree ")#mi("{\\leq d-1}")#text(".")
]

#text("It is clear that the rank obeys the triangle inequality ")#mi("{rank_{d-1}(P+Q) \\leq rank_{d-1}(P)+rank_{d-1}(Q)}")#text(" for all (limit) classical polynomials of degree ")#mi("{\\leq d}")#text(". There is an analogue for analytic rank, due ")#link("http://arxiv.org/abs/1002.2208")[#text("to Gowers and Wolf")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 11 (Quasi-triangle inequality for analytic rank)")]#text(" Let ")#mi("{P, Q: V \\rightarrow {\\bf F}}")#text(" be (limit) classical polynomials of degree ")#mi("{\\leq d}")#text(". Then ")#mi("{arank_{d-1}(P+Q) \\leq 2^d( arank_{d-1}(P) + arank_{d-1}(Q) )}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{T_1(h_1,\\ldots,h_d)}")#text(" be the ")#mi("{d}")#text("-linear form")

#align(center)[#tao-fit-display[#mitex("T_1(h_1,\\ldots,h_d) := \\partial_{h_1} \\ldots \\partial_{h_d} P(x)")]]

#text("(note that the right-hand side is independent of ")#mi("{x}")#text("); similarly define")

#align(center)[#tao-fit-display[#mitex("T_2(h_1,\\ldots,h_d) := \\partial_{h_1} \\ldots \\partial_{h_d} P(x)")]]

#text("By definition, we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{h_1,\\ldots,h_d \\in V} e( T_1(h_1,\\ldots,h_d) ) = p^{-arank_{d-1}(P)}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{h_1,\\ldots,h_d \\in V} e( T_2(h_1,\\ldots,h_d) ) = p^{-arank_{d-1}(Q)}")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{h_1,\\ldots,h_d,h^{\\prime}_1,\\ldots,h^{\\prime}_d \\in V} e( T_1(h_1,\\ldots,h_d) + T_2(h^{\\prime}_1,\\ldots,h^{\\prime}_d) )")]]

#align(center)[#tao-fit-display[#mitex("= p^{-arank_{d-1}(P)-arank_{d-1}(Q)}.")]]

#text("We make the substitution ")#mi("{h^{\\prime}_j = h_j + k_j}")#text(". Using the multilinearity of ")#mi("{T_2}")#text(", we can write the left-hand side as")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{k_1,\\ldots,k_d \\in V} {\\bf E}_{h_1,\\ldots,h_d \\in V} e( (T_1+T_2)(h_1,\\ldots,h_d) ) \\times")]]

#align(center)[#tao-fit-display[#mitex("\\prod_{j=1}^d f_j( h_1,\\ldots,h_d,k_1,\\ldots,k_d)")]]

#text("where the ")#mi("{f_j}")#text(" are functions bounded in magnitude by ")#mi("{1}")#text(" that are independent of the ")#mi("{h_j}")#text(" variable. Eliminating all these factors by Cauchy-Schwarz as in ")#link("https://terrytao.wordpress.com/2010/04/23/254b-notes-3-linear-patterns/")[#text("the previous notes")]#text(", we can bound the above expression by")

#align(center)[#tao-fit-display[#tao-math("(\\mathop{\\bf E}_{h^0_1,\\ldots,h^0_d,h^1_1,\\ldots,h^1_d \\in V} e( \\sum_{\\omega \\in \\{0,1\\}^d} (-1)^{\\left|\\omega\\right|} (T_1+T_2)(h_1^{\\omega_1}, \\ldots, h_d^{\\omega_d})|^{1/2^d}", block: true)]]

#text("which using the substitution ")#mi("{h_i := h^1_i - h^0_i}")#text(" and the multilinearity of ")#mi("{T_1+T_2}")#text(" simplifies to")

#align(center)[#tao-fit-display[#mitex("(\\mathop{\\bf E}_{h_1,\\ldots,h_d \\in V} e( (T_1+T_2)(h_1,\\ldots,h_d) )|^{1/2^d}")]]

#text("which by definition of analytic rank is")

#align(center)[#tao-fit-display[#mitex("p^{-arank_{d-1}(P+Q)/2^d},")]]

#text("and the claim follows. ")#mi("\\Box")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mads")]], [#link("https://terrytao.wordpress.com/2010/05/08/254b-lecture-notes-4-equidistribution-of-polynomials-over-finite-fields/#comment-44768")[#strong[#text("Mads")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2010")])]

#text("Professor Tau,")

#text("An typo has found it’s way into the hint to Exercise 17: “cfan” should be “can”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 5: The inverse conjecture for the Gowers norm I. The finite field case « What’s new")]], [#link("https://terrytao.wordpress.com/2010/05/08/254b-lecture-notes-4-equidistribution-of-polynomials-over-finite-fields/#comment-45028")[#strong[#text("254B, Notes 5: The inverse conjecture for the Gowers norm I. The finite field case « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2010")])]

#text("[…] closely tied to the space of polynomials of degree at most . Indeed, as noted in Exercise 20 of Notes 4, a function of norm has norm equal to if and only if for some ; thus polynomials solve the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pietro")]], [#link("https://terrytao.wordpress.com/2010/05/08/254b-lecture-notes-4-equidistribution-of-polynomials-over-finite-fields/#comment-45167")[#strong[#text("Pietro")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2010")])]

#text("Dear Terry, I may be misinterpreting the notation horribly, but I don’t think that the map x |–> x^i is a bijection on F_p for all 0<i<p-1. You need i to be prime to p-1 for that to be true. (Otherwise quadratic reciprocity would be too easy!)")

#text("Fortunately you don't need this to get the power sums to be zero, all you need is some nonzero b in F s.t. b^i is different from 1, which exists since the multiplicative group F_p\\{0} is cyclic. (Or alternatively because the polynomial X^i – 1 has at most i roots.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/05/08/254b-lecture-notes-4-equidistribution-of-polynomials-over-finite-fields/#comment-45168")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2010")])]

#text("Oops, good point! (I had confused the proof of the vanishing of ")#mi("\\sum_x x^i")#text(" with the proof of Fermat’s little theorem ")#mi("a^{p-1}=1")#text(" that is based on the fact that ")#mi("x \\mapsto ax")#text(" is a bijection.) The correct statement is that ")#mi("x \\mapsto x^i")#text(" is a covering map onto a nontrivial multiplicative subgroup, but it is indeed simpler to proceed by dilating by a non-i^th-root-of-unity b.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/beeed5597923941b57f8b6628c32b825df93f93c87f5d099c69c3d39a2aab865-1f23b8cd15b3653b08bf6d1ea41ea9dbcc1dd08aecad4e897d884cd84dc0fa64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sungjin Kim")]], [#link("https://terrytao.wordpress.com/2010/05/08/254b-lecture-notes-4-equidistribution-of-polynomials-over-finite-fields/#comment-45318")[#strong[#text("Sungjin Kim")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2010")])]

#text("In exercise 6, Sum x^i should be summing over x in F, not i in F.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/087efbd64dbb2bf3003cb0fe9d7cf1229bad84470d1637450d2d5f36eaa73bc9-3cee5444008f795ba5d1dd46a139a06cdd7870234ded3639372d93dcdead54da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mmailliw/william")]], [#link("https://terrytao.wordpress.com/2010/05/08/254b-lecture-notes-4-equidistribution-of-polynomials-over-finite-fields/#comment-45244")[#strong[#text("mmailliw/william")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2010")])]

#text("I believe that your estimate for Exercise 14 doesn’t quite hold.")

#text("As a counterexample, we can let F = F_3, d = 2, and P = x^2. Then, because e(P(x)) = 1 for x = 0 and (-1 + i sqrt 3)/2 for x nonzero, the expected value of e(P(x)) is (sqrt 3)/3 i, whose absolute value is about .5773 (this also follows from Exercise 12, which gives 1/(sqrt 3) in this case); however, the statement on Exercise 14 would imply that if")

#text("|E(e(P(x))| > 1 – 2^(-d + 1) = 1 – 2^(-1) = .5 in this case, then P would have to be constant, which is a contradiction.")

#text("The induction proof almost works, though (I believe that the stumbling point is that |E_x (Delta_h P(x))| could equal 1 if h = 0).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/05/08/254b-lecture-notes-4-equidistribution-of-polynomials-over-finite-fields/#comment-45247")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2010")])]

#text("Ah, right, I meant to have a lower bound on E |e(P(x)) – c| for some unit phase c (instead of a lower bound on |E e(P(x)) – c|, which was essentially what was written). The original claim is still true if one replaces ")#mi("2^{-d}")#text(" by something a bit weaker, of course. I’ve reworded the question accordingly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/beeed5597923941b57f8b6628c32b825df93f93c87f5d099c69c3d39a2aab865-1f23b8cd15b3653b08bf6d1ea41ea9dbcc1dd08aecad4e897d884cd84dc0fa64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sungjin Kim")]], [#link("https://terrytao.wordpress.com/2010/05/08/254b-lecture-notes-4-equidistribution-of-polynomials-over-finite-fields/#comment-45314")[#strong[#text("Sungjin Kim")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2010")])]

#text("Dear Professor Tao,")

#text("In exercise 2, the answer holds when we have no restrictions on exponents i_1, …, i_n. However, by exercise 1, we have a restriction that all i_1, … i_n should be in {0,1, …, p-1}.")

#emph[#text("[Corrected, thanks – T.]")]
]
