// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/12/12/random-matrices-the-four-moment-theorem-for-wigner-ensembles/
// Converted to Typst by tao2typ: "2026-10-14T15:18:18.254665+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Random matrices: The Four Moment Theorem for Wigner ensembles", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Random matrices: The Four Moment Theorem for Wigner ensembles")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 December 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/12/12/random-matrices-the-four-moment-theorem-for-wigner-ensembles/")[#text("https://terrytao.wordpress.com/2011/12/12/random-matrices-the-four-moment-theorem-for-wigner-ensembles/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("http://www.math.rutgers.edu/~vanvu/")[#text("Van Vu ")]#text("and I have just uploaded to the arXiv our short survey article, “")#link("http://arxiv.org/abs/1112.1976")[#text("Random matrices: The Four Moment Theorem for Wigner ensembles")]#text("“, submitted to the ")#link("http://library.msri.org/books/")[#text("MSRI book series")]#text(", as part of the proceedings on the ")#link("http://www.msri.org/web/msri/scientific/programs/past-programs/show/-/event/Pm134")[#text("MSRI semester program on random matrix theory from last year")]#text(". This is a highly condensed version (at 17 pages) of a much longer survey (currently at about 48 pages, though not completely finished) that we are currently working on, devoted to the recent advances in understanding the universality phenomenon for spectral statistics of Wigner matrices. In this abridged version of the survey, we focus on a key tool in the subject, namely the ")#emph[#text("Four Moment Theorem")]#text(" which roughly speaking asserts that the statistics of a Wigner matrix depend only on the first four moments of the entries. We give a sketch of proof of this theorem, and two sample applications: a central limit theorem for individual eigenvalues of a Wigner matrix (extending a result of Gustavsson in the case of GUE), and the verification of a conjecture of Wigner, Dyson, and Mehta on the universality of the asymptotic k-point correlation functions even for discrete ensembles (provided that we interpret convergence in the vague topology sense).")

#text("For reasons of space, this paper is very far from an exhaustive survey even of the narrow topic of universality for Wigner matrices, but should hopefully be an accessible entry point into the subject nevertheless.")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/12/12/random-matrices-the-four-moment-theorem-for-wigner-ensembles/#comment-115226")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2011")])]

#text("Corollary 4 (eigenvalue delocalization) -> eigenvector. ")#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc14d93c8648c9f8c27b3e1e0c49d17fc6c91ae03d4b012efb1ae26054976925-f6f9cd080f3adaa5541571b73a70326edb6db35cdb0cbee741396b0b7630143a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jafar")]], [#link("https://terrytao.wordpress.com/2011/12/12/random-matrices-the-four-moment-theorem-for-wigner-ensembles/#comment-115238")[#strong[#text("Jafar")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2011")])]

#text("Dear Tery,")#linebreak()#text(" i am wondering that distribution of the eigenvalues of the summation of two random Hermitian matrices when we fixed the spectrum of those two marices. This distribution is a density function on the convex finite polytop which is described by a finite set of linear homogenous inequality (the work of Klyachko). In other word, I like to compute the volume of the space of Honey combs when you fixed the boundary values of honeycombs. do you have any idea about this?it is some how related to the Duistermatt-Heckman measure but to compute it explicitly is very hard. I mean an explicit formula for the distribution as in the case of GUE ensumble of random Hermitian matrices.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/12/12/random-matrices-the-four-moment-theorem-for-wigner-ensembles/#comment-115250")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2011")])]

#text("There is indeed an explicit formula for the measure – an alternating sum of Duistermaat-Heckman measures for the torus action of a single coadjoint orbit, though I can’t recall a reference for this fact offhand. (The representation-theoretic analogue of this formula is due to Sternberg, though, I think.) But this is not a particularly tractable formula to work with due to all the oscillation in the sum.")

#text("It is known that in the limit when the size of the matrices goes to infinity, this density concentrates around the free convolution of the spectrum of the original two matrices, but this is proven by a completely different method. It would certainly be of interest to use the symplectic geometry machinery (DH measures, honeycombs, etc.) to obtain an independent proof of this fact, which may also give some better asymptotics on this measure, but as far as I know this remains quite an open problem. (Many years ago I talked to some tiling experts about this, because the puzzles that come up in the Hermitian matrix problem bear some resemblance to domino tilings and Aztec diamonds, for which the limiting distribution is fairly well understood; but apparently the problem is that the degrees of freedom of a puzzle are much less local than that of tilings and diamonds, so the techniques there do not directly apply. It would be good for someone to look into these problems again, although a somewhat daunting amount of interdisciplinary research would be needed to make progress.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64eb8b1d8ac5e9e0ac468554d6194a93a61a8003b6a9bfb58cae985ab1cfaed0-952f9392b39e1c26386118db9a27ea80e724afcd5f2511dead4e1ce9f97293c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/12/12/random-matrices-the-four-moment-theorem-for-wigner-ensembles/#comment-121277")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2012")])]

#text("A good reference for this is the book by Guillemin, Lerman and Sternberg.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/12/12/random-matrices-the-four-moment-theorem-for-wigner-ensembles/#comment-115917")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2011")])]

#text("A parenthesis is missing at the end of (15).")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/12/12/random-matrices-the-four-moment-theorem-for-wigner-ensembles/#comment-115918")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2011")])]

#text("…and in the next equation too, I see.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Random matrices: The Universality phenomenon for Wigner ensembles « What’s new")]], [#link("https://terrytao.wordpress.com/2011/12/12/random-matrices-the-four-moment-theorem-for-wigner-ensembles/#comment-126074")[#strong[#text("Random matrices: The Universality phenomenon for Wigner ensembles « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2012")])]

#text("[…] for Wigner ensembles“. This survey is a longer version (58 pages) of a previous short survey we wrote up a few months ago. The survey focuses on recent progress in understanding the universality phenomenon for Hermitian […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 4: The central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2011/12/12/random-matrices-the-four-moment-theorem-for-wigner-ensembles/#comment-461369")[#strong[#text("275A, Notes 4: The central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2015")])]

#text("[…] matrix components , if there is a suitable amount of independence between the . See for instance this survey article of Van Vu and myself for more discussion of […]")
]
