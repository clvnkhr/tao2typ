// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/
// Converted to Typst by tao2typ: "2026-10-14T15:18:07.591508+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Two small facts about Lie groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Two small facts about Lie groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 June 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/")[#text("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Over the past few months or so, I have been brushing up on my Lie group theory, as part of my project to fully understand the theory surrounding Hilbert’s fifth problem. Every so often, I encounter a basic fact in Lie theory which requires a slightly non-trivial “trick” to prove; I am recording two of them here, so that I can find these tricks again when I need to.")

#text("The first fact concerns the ")#link("http://en.wikipedia.org/wiki/Exponential_map")[#text("exponential map")]#text(" ")#mi("{\\exp: {\\mathfrak g} \\rightarrow G}")#text(" from a Lie algebra ")#mi("{{\\mathfrak g}}")#text(" of a Lie group ")#mi("{G}")#text(" to that group. (For this discussion we will only consider finite-dimensional Lie groups and Lie algebras over the reals ")#mi("{{\\bf R}}")#text(".) A basic fact in the subject is that the exponential map is ")#emph[#text("locally")]#text(" a homeomorphism: there is a neighbourhood of the origin in ")#mi("{{\\mathfrak g}}")#text(" that is mapped homeomorphically by the exponential map to a neighbourhood of the identity in ")#mi("{G}")#text(". This local homeomorphism property is the foundation of an important dictionary between Lie groups and Lie algebras.")

#text("It is natural to ask whether the exponential map is globally a homeomorphism, and not just locally: in particular, whether the exponential map remains both injective and surjective. For instance, this is the case for connected, simply connected, nilpotent Lie groups (as can be seen from the ")#link("http://en.wikipedia.org/wiki/Baker-Campbell-Hausdorff_formula")[#text("Baker-Campbell-Hausdorff formula")]#text(".)")

#text("The circle group ")#mi("{S^1}")#text(", which has ")#mi("{{\\bf R}}")#text(" as its Lie algebra, already shows that global injectivity fails for any group that contains a circle subgroup, which is a huge class of examples (including, for instance, the positive dimensional compact Lie groups, or non-simply-connected Lie groups). Surjectivity also obviously fails for disconnected groups, since the Lie algebra is necessarily connected, and so the image under the exponential map must be connected also. However, even for connected Lie groups, surjectivity can fail. To see this, first observe that if the exponential map was surjective, then every group element ")#mi("{g \\in G}")#text(" has a square root (i.e. an element ")#mi("{h \\in G}")#text(" with ")#mi("{h^2 = g}")#text("), since ")#mi("{\\exp(x)}")#text(" has ")#mi("{\\exp(x/2)}")#text(" as a square root for any ")#mi("{x \\in {\\mathfrak g}}")#text(". However, there exist elements in connected Lie groups without square roots. A simple example is provided by the matrix")

#align(center)[#tao-fit-display[#mitex("g = \\begin{pmatrix} -4 & 0 \\\\ 0 & -1/4 \\end{pmatrix}")]]

#text("in the connected Lie group ")#mi("{SL_2({\\bf R})}")#text(". This matrix has eigenvalues ")#mi("{-4}")#text(", ")#mi("{-1/4}")#text(". Thus, if ")#mi("{h \\in SL_2({\\bf R})}")#text(" is a square root of ")#mi("{g}")#text(", we see (from the Jordan normal form) that it must have at least one eigenvalue in ")#mi("{\\{-2i,+2i\\}}")#text(", and at least one eigenvalue in ")#mi("{\\{-i/2,i/2\\}}")#text(". On the other hand, as ")#mi("{h}")#text(" has real coefficients, the complex eigenvalues must come in conjugate pairs ")#mi("{\\{ a+bi, a-bi\\}}")#text(". Since ")#mi("{h}")#text(" can only have at most ")#mi("{2}")#text(" eigenvalues, we obtain a contradiction.")

#text("However, there is an important case where surjectivity is recovered:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" If ")#mi("{G}")#text(" is a compact connected Lie group, then the exponential map is surjective.")
]

#emph[#text("Proof:")]#text(" The idea here is to relate the exponential map in Lie theory to the exponential map in Riemannian geometry. We first observe that every compact Lie group ")#mi("{G}")#text(" can be given the structure of a Riemannian manifold with a bi-invariant metric. This can be seen in one of two ways. Firstly, one can put an arbitrary positive definite inner product on ")#mi("{{\\mathfrak g}}")#text(" and average it against the adjoint action of ")#mi("{G}")#text(" using Haar probability measure (which is available since ")#mi("{G}")#text(" is compact); this gives an ad-invariant positive-definite inner product on ")#mi("{{\\mathfrak g}}")#text(" that one can then translate by either left or right translation to give a bi-invariant Riemannian structure on ")#mi("{G}")#text(". Alternatively, one can use the ")#link("http://en.wikipedia.org/wiki/Peter%E2%80%93Weyl_theorem")[#text("Peter-Weyl theorem")]#text(" to embed ")#mi("{G}")#text(" in a unitary group ")#mi("{U(n)}")#text(", at which point one can induce a bi-invariant metric on ")#mi("{G}")#text(" from the one on the space ")#mi("{M_n({\\bf C}) \\equiv {\\bf C}^{n^2}}")#text(" of ")#mi("{n \\times n}")#text(" complex matrices.")

#text("As ")#mi("{G}")#text(" is connected and compact and thus complete, we can apply the ")#link("http://en.wikipedia.org/wiki/Hopf%E2%80%93Rinow_theorem")[#text("Hopf-Rinow theorem")]#text(" and conclude that any two points are connected by at least one geodesic, so that the ")#emph[#text("Riemannian")]#text(" exponential map from ")#mi("{{\\mathfrak g}}")#text(" to ")#mi("{G}")#text(" formed by following geodesics from the origin is surjective. But one can check that the Lie exponential map and Riemannian exponential map agree; for instance, this can be seen by noting that the group structure naturally defines a connection on the tangent bundle which is both torsion-free and preserves the bi-invariant metric, and must therefore agree with the Levi-Civita metric. (Alternatively, one can embed into a unitary group ")#mi("{U(n)}")#text(" and observe that ")#mi("{G}")#text(" is totally geodesic inside ")#mi("{U(n)}")#text(", because the geodesics in ")#mi("{U(n)}")#text(" can be described explicitly in terms of one-parameter subgroups.) The claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" While it is quite nice to see Riemannian geometry come in to prove this proposition, I am curious to know if there is any other proof of surjectivity for compact connected Lie groups that does not require explicit introduction of Riemannian geometry concepts.")
]

#text("The other basic fact I learned recently concerns the algebraic nature of Lie groups and Lie algebras. An important family of examples of Lie groups are the ")#link("http://en.wikipedia.org/wiki/Algebraic_group")[#text("algebraic groups")]#text(" – algebraic varieties with a group law given by algebraic maps. Given that one can always automatically upgrade the smooth structure on a Lie group to analytic structure (by using the Baker-Campbell-Hausdorff formula), it is natural to ask whether one can upgrade the structure further to an algebraic structure. Unfortunately, this is not always the case. A prototypical example of this is given by the one-parameter subgroup ")#metadata(none) <tao-5f5a8ed8f139be6df7cf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("G := \\{ \\begin{pmatrix} t & 0 \\\\ 0 & t^\\alpha \\end{pmatrix}: t \\in {\\bf R}^+ \\}")]]

#text("of ")#mi("{GL_2({\\bf R})}")#text(". This is a Lie group for any exponent ")#mi("{\\alpha \\in {\\bf R}}")#text(", but if ")#mi("{\\alpha}")#text(" is irrational, then the curve that ")#mi("{G}")#text(" traces out is not an algebraic subset of ")#mi("{GL_2({\\bf R})}")#text(" (as one can see by playing around with ")#link("http://en.wikipedia.org/wiki/Puiseux_series")[#text("Puiseux series")]#text(").")

#text("This is not a true counterexample to the claim that every Lie group can be given the structure of an algebraic group, because one can give ")#mi("{G}")#text(" a different algebraic structure than one inherited from the ambient group ")#mi("{GL_2({\\bf R})}")#text(". Indeed, ")#mi("{G}")#text(" is clearly isomorphic to the additive group ")#mi("{{\\bf R}}")#text(", which is of course an algebraic group. However, a modification of the above construction works:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" There exists a Lie group ")#mi("{G}")#text(" that cannot be given the structure of an algebraic group.")
]

#emph[#text("Proof:")]#text(" We use an example from the ")#link("http://www.ams.org/mathscinet-getitem?mr=2146652")[#text("text of Tauvel and Yu")]#text(" (that I found via ")#link("http://mathoverflow.net/questions/124/is-every-finite-dimensional-lie-algebra-the-lie-algebra-of-an-algebraic-group")[#text("this MathOverflow posting")]#text("). We consider the subgroup")

#align(center)[#tao-fit-display[#mitex("G := \\{ \\begin{pmatrix} 1 & 0 & 0 \\\\ x & t & 0 \\\\ y & 0 & t^\\alpha \\end{pmatrix}: x, y \\in {\\bf R}; t \\in {\\bf R}^+ \\}")]]

#text("of ")#mi("{GL_3({\\bf R})}")#text(", with ")#mi("{\\alpha}")#text(" an irrational number. This is a three-dimensional (")#link("http://en.wikipedia.org/wiki/Metabelian")[#text("metabelian")]#text(") Lie group, whose Lie algebra ")#mi("{{\\mathfrak g} \\subset {\\mathfrak gl}_3({\\bf R})}")#text(" is spanned by the elements")

#tao-aligned(keep: true)[


#tao-math("X  & := \\begin{pmatrix} 0 & 0 & 0 \\\\ 0 & 1 & 0 \\\\ 0 & 0 & \\alpha \\end{pmatrix}", block: true)



#tao-math("Y  & := \\begin{pmatrix} 0 & 0 & 0 \\\\ -1 & 0 & 0 \\\\ 0 & 0 & 0 \\end{pmatrix}", block: true)



#tao-math("Z  & := \\begin{pmatrix} 0 & 0 & 0 \\\\ 0 & 0 & 0 \\\\ -\\alpha & 0 & 0 \\end{pmatrix}", block: true)
]

#text("with the Lie bracket given by")

#align(center)[#tao-fit-display[#mitex("[Y,X] = -Y; [Z,X] = -\\alpha Z; [Y,Z] = 0.")]]

#text("As such, we see that if we use the basis ")#mi("{X, Y, Z}")#text(" to identify ")#mi("{{\\mathfrak g}}")#text(" to ")#mi("{{\\bf R}^3}")#text(", then ")#link("http://en.wikipedia.org/wiki/Adjoint_representation_of_a_Lie_group")[#text("adjoint representation")]#text(" of ")#mi("{G}")#text(" is the identity map.")

#text("If ")#mi("{G}")#text(" is an algebraic group, it is easy to see that the adjoint representation ")#mi("{\\text{Ad}: G \\rightarrow GL({\\mathfrak g})}")#text(" is also algebraic, and so ")#mi("{\\text{Ad}(G) = G}")#text(" is algebraic in ")#mi("{GL({\\mathfrak g})}")#text(". Specialising to our specific example, in which adjoint representation is the identity, we conclude that if ")#mi("{G}")#text(" has ")#emph[#text("any")]#text(" algebraic structure, then it must also be an algebraic subgroup of ")#mi("{GL_3({\\bf R})}")#text("; but ")#mi("{G}")#text(" projects to the group ")#link(<tao-5f5a8ed8f139be6df7cf>)[#text("(1)")]#text(" which is not algebraic, a contradiction. ")#mi("\\Box")

#text("A slight modification of the same argument also shows that not every Lie algebra is ")#emph[#text("algebraic")]#text(", in the sense that it is isomorphic to a Lie algebra of an algebraic group. (However, there are important classes of Lie algebras that are automatically algebraic, such as nilpotent or semisimple Lie algebras.)")

#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5bc55a6acb8096dd951e0a61e76bcdee12aa572b1966408a28f2553e8d2e211-6207a71b720bfb72417bc2d6e75617891b2e28723e5d7fff47cfa0eba6373191.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RdN")]], [#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/#comment-54274")[#strong[#text("RdN")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2011")])]

#text("As for surjectivity of exp, one thing you can probably do is first prove conjugacy of Cartans. Now it’s obvious that exp is surjective for a torus, and everything lives inside a torus.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5bc55a6acb8096dd951e0a61e76bcdee12aa572b1966408a28f2553e8d2e211-6207a71b720bfb72417bc2d6e75617891b2e28723e5d7fff47cfa0eba6373191.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RdN")]], [#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/#comment-54277")[#strong[#text("RdN")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2011")])]

#text("As for surjectivity of exp, one thing you can probably do is first prove conjugacy of Cartans. Now it’s obvious that exp is surjective for a torus, and everything lives inside a torus. (And here’s (")#link("http://math.berkeley.edu/~allenk/courses/spr02/261b/notes/symplectic3.pdf")[#text("http://math.berkeley.edu/~allenk/courses/spr02/261b/notes/symplectic3.pdf")]#text(") a nice symplectic approach to conjugacy of Cartans.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior")]], [#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/#comment-54281")[#strong[#text("Lior")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2011")])]

#text("More precisely, in a compact connected Lie group every element lies in a maximal torus (and these tori are all conjugate).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/#comment-54301")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2011")])]

#text("Weird; I don’t see how to comment, only to reply.")

#text("The usual example of a non-algebraic group is the universal cover of SL_2(R). If it were algebraic, it would have a faithful finite-dimensional rep, which would descend to sl_2(R), complexify to sl_2(C), and extend to SL_2(C) (since that one is simply connected). But the map from the universal cover of SL_2(R) to SL_2(C) is not 1:1.")

#text("One nonalgebraic Lie algebra is the semidirect product of R acting on R^2 x R^2, rotating each factor but at incommensurable speeds. Then the adjoint orbits are irrational flows on tori, so not locally closed, which wouldn’t happen with an algebraic action.")

#emph[#text("[The comment reply box is at the very bottom of the page – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/#comment-54385")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2011")])]

#text("Thanks Allen! I have one stupid question; I thought it was only the affine algebraic groups that necessarily had finite-dimensional representations; does the above argument rule out the metaplectic group being an abstract algebraic group rather than an affine one?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/#comment-497368")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2018")])]

#text("Good question.")

#text("Every abstract algebraic group over a perfect field (such as ")#mi("\\mathbb{R}")#text(") is an extension of an abelian variety by an affine (=linear) algebraic group (Theorem of Barsotti–Chevalley). On the other hand, metaplectic covers of groups such that ")#mi("\\mathrm{SL}_2(\\mathbb{R}")#text(" don’t surject on non-trivial compact Lie groups.")

#text("Now abelian varities are projective so their sets of real or complex points are compact. It follows that if a metaplectic group was the set of real points of an algebraic group it would be the set of real points of an affine algebraic group.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xavier")]], [#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/#comment-54331")[#strong[#text("xavier")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2011")])]

#text("a little typo : you indicate pusieux instead of puiseux")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/#comment-54338")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2011")])]

#text("It is interesting that:")

#text("A Connected Lie Group Equals the Square of the Exponential Image,")#linebreak()#text(" Michael Wüstner, Journal of Lie Theory. Volume 13 (2003) 307–309")

#link("http://emis.math.ca/journals/JLT/vol.13_no.1/wuestla2e.pdf")[#text("Click to access wuestla2e.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/#comment-54360")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2011")])]

#text("I should have mentioned: a nonalgebraic group that arises “in nature” is the metaplectic group. The Heisenberg group has an essentially unique irrep (via the Stone-von Neumann theorem) so the symplectic group, which acts on the Heisenberg, should act on that irrep too (by Schur’s lemma) — but only projectively (because of the possible scalar in Schur’s lemma). The group that actually acts is the metaplectic group, the double cover of symplectic. Since the representation is infinite-dimensional, it doesn’t force the metaplectic group to be algebraic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b88d70dc194adf72f057699180f305b5075fdcc17a3847207ae2f1d091549372-21fb19c3ee7a87393199500520e1bbca17fa45453e93fa79b406b21ad7f74989.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of elgeorges")]], [#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/#comment-54413")[#strong[#text("elgeorges")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2011")])]

#text("A little typo: you write (in the sentence following its definition) that the matrix g is orthogonal, which it is not.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6351b8ac7aaaf1226949432cb775f977c07e0da0338f15b40ab464bfaa5b15c-b8faa30f60ad996e03e225c56fee47f31cf1f4df586a575cda27acb2fd46e63d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Innerproduct")]], [#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/#comment-54469")[#strong[#text("Innerproduct")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2011")])]

#text("Another little typo in the fourth paragraph:")

#text("The circle group S^1, which ")#strong[#text("has")]#text(" R as its Lie algebra…")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/087efbd64dbb2bf3003cb0fe9d7cf1229bad84470d1637450d2d5f36eaa73bc9-3cee5444008f795ba5d1dd46a139a06cdd7870234ded3639372d93dcdead54da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mmailliw//william")]], [#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/#comment-54664")[#strong[#text("mmailliw//william")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2011")])]

#text("As written for Example 2, I’m not sure the adjoint representation is the identity as you claim:")#linebreak()#text(" while Ad X indeed has the matrix representation of X, it looks like")#linebreak()#text(" Ad Y actually has the matrix representation of -Y (since [Y, X] = -Y and [Y, Y] =[Y, Z] = 0, the matrix representation for Ad Y should have a -1 where the matrix of Y has 1)")#linebreak()#text(" and similarly Ad Z has the matrix representation of -alpha Z.")

#text("That, though, would be fixed if we replaced Y with -Y and Z with -alpha Z in the original definitions, though: is this right?")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on local groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/#comment-68216")[#strong[#text("Notes on local groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2011")])]

#text("[…] On the other hand, it is possible to eliminate the reliance on the Baker-Campbell-Hausdorff formula by using Frobenius’s theorem to construct the local Lie group instead; we omit the details. Remark 4 The above argument also reveals one advantage of local Lie groups over global ones; local Lie groups are locally linearisable (in the sense that they are isomorphic to a local subgroup of a linear group), whereas global Lie groups need not be globally linearisable, as discussed in this previous post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 0 – Hilbert’s fifth problem and related topics « What’s new")]], [#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/#comment-70859")[#strong[#text("254A, Notes 0 – Hilbert’s fifth problem and related topics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2011")])]

#text("[…] An important subclass of the closed linear groups are the linear algebraic groups, in which the group is also a real or complex algebraic variety (or at least an algebraically constructible set). All of the examples of closed linear groups given above are linear algebraic groups, although there exist closed linear groups that are not isomorphic to any algebraic group; see this post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on simple groups of Lie type | What's new")]], [#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/#comment-243961")[#strong[#text("Notes on simple groups of Lie type | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2013")])]

#text("[…] to each other also. On a compact Lie group, the exponential map is surjective (as discussed in this previous blog post); as every element in lies in a Cartan algebra, we obtain the useful fact that every element of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The standard branch of the matrix logarithm | What's new")]], [#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/#comment-454942")[#strong[#text("The standard branch of the matrix logarithm | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2015")])]

#text("[…] for a more complete description of the image of the exponential map in classical groups, as well as this previous blog post for some more discussion of the surjectivity (or lack thereof) of the exponential map in Lie […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Large values of Dirichlet polynomials, zero density estimates, and primes in short intervals | What's new")]], [#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/#comment-455326")[#strong[#text("254A, Notes 6: Large values of Dirichlet polynomials, zero density estimates, and primes in short intervals | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2015")])]

#text("[…] for a more complete description of the image of the exponential map in classical groups, as well as this previous blog post for some more discussion of the surjectivity (or lack thereof) of the exponential map in Lie […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/#comment-641780")[#strong[#text("Victor Wang Generals – scroo9ooge")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2022")]

#text("[…] map (w.r.t. a bi-invariant metric) agrees with the Lie-theoretic exponential map, see e.g. ")#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/")[#text("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/")]#text(" Other comments from S after the exam: – Conjugacy of maximal tori has to do with some […]")
]
