// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/
// Converted to Typst by tao2typ: "2026-10-14T15:18:05.962579+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Locally compact groups with faithful finite-dimensional representations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Locally compact groups with faithful finite-dimensional representations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 May 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/")[#text("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is another post in a series on various components to the solution of ")#link("http://en.wikipedia.org/wiki/Hilbert's_fifth_problem")[#text("Hilbert’s fifth problem")]#text(". One interpretation of this problem is to ask for a purely topological classification of the ")#link("http://en.wikipedia.org/wiki/Topological_group")[#text("topological groups")]#text(" which are isomorphic to ")#link("http://en.wikipedia.org/wiki/Lie_group")[#text("Lie groups")]#text(". (Here we require Lie groups to be finite-dimensional, but allow them to be disconnected.)")

#text("There are some obvious necessary conditions on a topological group in order for it to be isomorphic to a Lie group; for instance, it must be Hausdorff and locally compact. These two conditions, by themselves, are not quite enough to force a Lie group structure; consider for instance a ")#link("http://en.wikipedia.org/wiki/P-adic_number")[#mi("{p}")#text("-adic field")]#text(" ")#mi("{{\\mathbf Q}_p}")#text(" for some prime ")#mi("{p}")#text(", which is a locally compact Hausdorff topological group which is not a Lie group (the topology is locally that of a Cantor set). Nevertheless, it turns out that by adding some key additional assumptions on the topological group, one can recover Lie structure. One such result, which is a key component of the full solution to Hilbert’s fifth problem, is the following result of von Neumann:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" ")#metadata(none) <tao-094f686e92c888ae99f8>#text(" Let ")#mi("{G}")#text(" be a locally compact Hausdorff topological group that has a faithful finite-dimensional linear representation, i.e. an injective continuous homomorphism ")#mi("{\\rho: G \\rightarrow GL_d({\\bf C})}")#text(" into some linear group. Then ")#mi("{G}")#text(" can be given the structure of a Lie group. Furthermore, after giving ")#mi("{G}")#text(" this Lie structure, ")#mi("{\\rho}")#text(" becomes smooth (and even analytic) and non-degenerate (the Jacobian always has full rank).")
]

#text("This result is closely related to a theorem of Cartan:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Cartan’s theorem)")]#text(" ")#metadata(none) <tao-9b3fea8ad52e1f62033b>#text(" Any closed subgroup ")#mi("{H}")#text(" of a Lie group ")#mi("{G}")#text(", is again a Lie group (in particular, ")#mi("{H}")#text(" is an analytic submanifold of ")#mi("{G}")#text(", with the induced analytic structure).")
]

#text("Indeed, Theorem ")#link(<tao-094f686e92c888ae99f8>)[#text("1")]#text(" immediately implies Theorem ")#link(<tao-9b3fea8ad52e1f62033b>)[#text("2")]#text(" in the important special case when the ambient Lie group is a linear group, and in any event it is not difficult to modify the proof of Theorem ")#link(<tao-094f686e92c888ae99f8>)[#text("1")]#text(" to give a proof of Theorem ")#link(<tao-9b3fea8ad52e1f62033b>)[#text("2")]#text(". However, Theorem ")#link(<tao-094f686e92c888ae99f8>)[#text("1")]#text(" is more general than Theorem ")#link(<tao-9b3fea8ad52e1f62033b>)[#text("2")]#text(" in some ways. For instance, let ")#mi("{G}")#text(" be the real line ")#mi("{{\\bf R}}")#text(", which we faithfully represent in the ")#mi("{2}")#text("-torus ")#mi("{({\\bf R}/{\\bf Z})^2}")#text(" using an irrational embedding ")#mi("{t \\mapsto (t,\\alpha t) \\text{ mod } {\\bf Z}^2}")#text(" for some fixed irrational ")#mi("{\\alpha}")#text(". The ")#mi("{2}")#text("-torus can in turn be embedded in a linear group (e.g. by identifying it with ")#mi("{U(1) \\times U(1)}")#text(", or ")#mi("{SO(2) \\times SO(2)}")#text("), thus giving a faithful linear representation ")#mi("{\\rho}")#text(" of ")#mi("{{\\bf R}}")#text(". However, the image is not closed (it is a dense subgroup of a ")#mi("{2}")#text("-torus), and so Cartan’s theorem does not directly apply (")#mi("{\\rho({\\bf R})}")#text(" fails to be a Lie group). Nevertheless, Theorem ")#link(<tao-094f686e92c888ae99f8>)[#text("1")]#text(" still applies and guarantees that the original group ")#mi("{{\\bf R}}")#text(" is a Lie group.")

#text("(On the other hand, the image of any ")#emph[#text("compact")]#text(" subset of ")#mi("{G}")#text(" under a faithful representation ")#mi("{\\rho}")#text(" must be closed, and so Theorem ")#link(<tao-094f686e92c888ae99f8>)[#text("1")]#text(" is very close to the version of Theorem ")#link(<tao-9b3fea8ad52e1f62033b>)[#text("2")]#text(" for ")#emph[#text("local")]#text(" groups.)")

#text("The key to building the Lie group structure on a topological group is to first build the associated Lie ")#emph[#text("algebra")]#text(" structure, by means of ")#emph[#text("one-parameter subgroups")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3")]#text(" A ")#emph[#text("one-parameter subgroup")]#text(" of a topological group ")#mi("{G}")#text(" is a continuous homomorphism ")#mi("{\\phi: {\\bf R} \\rightarrow G}")#text(" from the real line (with the additive group structure) to ")#mi("{G}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Technically, ")#mi("{\\phi}")#text(" is a parameterisation of a subgroup ")#mi("{\\phi({\\bf R})}")#text(", rather than a subgroup itself, but we will abuse notation and refer to ")#mi("{\\phi}")#text(" as the subgroup.")
]

#text("In a Lie group ")#mi("{G}")#text(", the one-parameter subgroups are in one-to-one correspondence with the Lie algebra ")#mi("{{\\mathfrak g}}")#text(", with each element ")#mi("{X \\in {\\mathfrak g}}")#text(" giving rise to a one-parameter subgroup ")#mi("{\\phi(t) := \\exp(tX)}")#text(", and conversely each one-parameter subgroup ")#mi("{\\phi}")#text(" giving rise to an element ")#mi("{\\phi^{\\prime}(0)}")#text(" of the Lie algebra; we will establish these basic facts in the special case of linear groups below the fold. On the other hand, the notion of a one-parameter subgroup can be defined in an arbitrary topological group. So this suggests the following strategy if one is to try to represent a topological group ")#mi("{G}")#text(" as a Lie group:")

#enum(start: 1, 
[#text("First, form the space ")#mi("{L(G)}")#text(" of one-parameter subgroups of ")#mi("{G}")#text(".")],
[#text("Show that ")#mi("{L(G)}")#text(" has the structure of a (finite-dimensional) Lie algebra.")],
[#text("Show that ")#mi("{L(G)}")#text(" “behaves like” the tangent space of ")#mi("{G}")#text(" at the identity (in particular, the one-parameter subgroups in ")#mi("{L(G)}")#text(" should cover a neighbourhood of the identity in ")#mi("{G}")#text(").")],
[#text("Conclude that ")#mi("{G}")#text(" has the structure of a Lie group.")]
)

#text("It turns out that this strategy indeed works to give Theorem ")#link(<tao-094f686e92c888ae99f8>)[#text("1")]#text(" (and variants of this strategy are ubiquitious in the rest of the theory surrounding Hilbert’s fifth problem).")

#text("Below the fold, I record the proof of Theorem ")#link(<tao-094f686e92c888ae99f8>)[#text("1")]#text(" (based on the exposition of ")#link("http://www.ams.org/mathscinet-getitem?mr=73104")[#text("Montgomery and Zippin")]#text("). I plan to organise these disparate posts surrounding Hilbert’s fifth problem (and its application to related topics, such as ")#link("http://en.wikipedia.org/wiki/Gromov%27s_theorem_on_groups_of_polynomial_growth")[#text("Gromov’s theorem")]#text(" or to the classification of approximate groups) at a later date.")

#metadata(none) <tao-ec983a9769bc3990f44b>

#heading(level: 1)[#strong[#text(" — 1. One-parameter subgroups of linear groups — ")]]

#text("Let us first understand the one-parameter subgroups of linear groups ")#mi("{GL_d({\\bf C})}")#text(". Here, we can take advantage of the ")#link("http://en.wikipedia.org/wiki/Matrix_exponential")[#text("matrix exponential")]

#align(center)[#tao-fit-display[#mitex("\\exp(A) := 1 + A + \\frac{A^2}{2!} + \\frac{A^3}{3!} + \\ldots,")]]

#text("defined for any ")#mi("{n \\times n}")#text(" complex matrix ")#mi("{A \\in \\mathfrak{gl}_d({\\bf C})}")#text(", where ")#mi("{\\mathfrak{gl}_d({\\bf C})}")#text(" is the Lie algebra of ")#mi("{GL_d({\\bf C})}")#text(", i.e. the space of ")#mi("{d \\times d}")#text(" complex matrices with the usual Lie bracket ")#mi("{[A,B] := AB-BA}")#text(". One easily verifies that for any such matrix ")#mi("{A \\in \\mathfrak{gl}_d({\\bf C})}")#text(", the map ")#mi("{\\phi: t \\mapsto \\exp(tA)}")#text(" is a one-parameter subgroup of ")#mi("{GL_d({\\bf C})}")#text(". Conversely, these are the only such groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" ")#metadata(none) <tao-7f3379c8dba11aab1609>#text(" Let ")#mi("{\\phi: {\\bf R} \\rightarrow GL_d({\\bf C})}")#text(" be a one-parameter subgroup of ")#mi("{GL_d({\\bf C})}")#text(". Then there exists a (unique) matrix ")#mi("{A \\in \\mathfrak{gl}_d({\\bf C})}")#text(" such that ")#mi("{\\phi(t) = \\exp(tA)}")#text(" for ")#mi("{t \\in {\\bf R}}")#text(".")
]

#emph[#text("Proof:")]#text(" Uniqueness follows from the differential identity")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} \\exp(tA)|_{t=0} = A,")]]

#text("so we turn to existence. The basic idea here is to take logarithms. By the inverse function theorem, ")#mi("{\\exp}")#text(" is a homeomorphism between a neighbourhood of the origin in ")#mi("{\\mathfrak{gl}_d({\\bf C})}")#text(", and a neighbourhood of the identity in ")#mi("{GL_d({\\bf C})}")#text(". Thus, for sufficiently small ")#mi("{\\epsilon > 0}")#text(", we can write ")#mi("{\\phi(t) = \\exp( B(t) )}")#text(" for all ")#mi("{t \\in [-\\epsilon,\\epsilon]}")#text(" and a continuous function ")#mi("{B: [-\\epsilon,\\epsilon] \\rightarrow M_n({\\bf C})}")#text(". In particular we have")

#align(center)[#tao-fit-display[#mitex("\\exp(2 B(t)) = \\exp( B(t) )^2 = \\exp( B( 2t ) )")]]

#text("for ")#tao-math("{\\left|t\\right| \\leq \\epsilon/2}", block: false)#text(", and thus by the local homeomorphism properties of the exponential")

#align(center)[#tao-fit-display[#mitex("2B(t) = B(2t).")]]

#text("Iterating this we see that")

#align(center)[#tao-fit-display[#mitex("B( 2^{-n} \\epsilon ) = 2^{-n} B(\\epsilon)")]]

#text("for all ")#mi("{n = 0,1,2,\\ldots}")#text("; using the homomorphism nature of ")#mi("{\\phi}")#text(" and the laws of exponentiation (and the local homeomorphism properties of the exponential) we have")

#align(center)[#tao-fit-display[#mitex("B( q \\epsilon ) = q B(\\epsilon)")]]

#text("for all dyadic rationals ")#mi("{-1 \\leq q \\leq 1}")#text(". By continuity we thus have")

#align(center)[#tao-fit-display[#mitex("B(t) = t A")]]

#text("for all ")#mi("{t \\in [-\\epsilon,\\epsilon]}")#text(", where ")#mi("{A := B(\\epsilon)/\\epsilon}")#text(". This gives ")#mi("{\\phi(t) = \\exp(tA)}")#text(" for all ")#tao-math("{\\left|t\\right| \\leq \\epsilon}", block: false)#text(", and by applying the homomorphism property of ")#mi("{\\phi}")#text(" we conclude that ")#mi("{\\phi(t)=\\exp(tA)}")#text(" for all ")#mi("{t}")#text(", and the claim follows. ")#mi("\\Box")

#text("Now we see the extent to which we can transfer Proposition ")#link(<tao-7f3379c8dba11aab1609>)[#text("4")]#text(" to the groups ")#mi("{G}")#text(" appearing in Theorem ")#link(<tao-094f686e92c888ae99f8>)[#text("1")]#text(", namely locally compact Hausdorff topological groups with a faithful linear representation ")#mi("{\\rho: G \\rightarrow GL_d({\\bf C})}")#text(". Every one-parameter subgroup ")#mi("{\\phi: {\\bf R} \\rightarrow G}")#text(" of course induces a one-parameter subgroup ")#mi("{\\rho \\circ \\phi: {\\bf R} \\rightarrow GL_d({\\bf C})}")#text(" that takes values in the image ")#mi("{\\rho(G)}")#text(" of ")#mi("{G}")#text("; from faithfulness, we see that ")#mi("{\\phi}")#text(" is uniquely determined by ")#mi("{\\rho \\circ \\phi}")#text(". In the converse direction, one would like to say that every one-parameter subgroup ")#mi("{\\Phi: {\\bf R} \\rightarrow GL_d({\\bf C})}")#text(" taking values in ")#mi("{\\rho(G)}")#text(", factors through ")#mi("{\\rho}")#text(" in this manner. This is not quite true as stated; for instance, if ")#mi("{G}")#text(" is ")#mi("{GL_d({\\bf C})}")#text(" with the ")#emph[#text("discrete")]#text(" topology, and ")#mi("{\\rho}")#text(" is the inclusion map, then only the trivial one-parameter subgroup ")#mi("{\\Phi: t \\mapsto 1}")#text(" will factor through ")#mi("{\\rho}")#text(". However, we can fix this by strengthening the hypothesis “")#mi("{\\Phi}")#text(" takes values in ")#mi("{\\rho(G)}")#text("” slightly:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5")]#text(" ")#metadata(none) <tao-a92c36e66a25ee99ff86>#text(" Let ")#mi("{G}")#text(", ")#mi("{\\rho}")#text(", ")#mi("{d}")#text(" be as in Theorem ")#link(<tao-094f686e92c888ae99f8>)[#text("1")]#text(", let ")#mi("{K}")#text(" be a compact neighbourhood of ")#mi("{G}")#text(", and let ")#mi("{\\Phi: {\\bf R} \\rightarrow GL_d({\\bf C})}")#text(" be a one-parameter subgroup. Then ")#mi("{\\Phi}")#text(" factors through ")#mi("{\\rho}")#text(" (i.e. ")#mi("{\\Phi = \\rho \\circ \\phi}")#text(" for some one-parameter subgroup ")#mi("{\\phi: {\\bf R} \\rightarrow G}")#text(") if and only if ")#mi("{\\Phi((-\\epsilon,\\epsilon)) \\subset \\rho(K)}")#text(" for some ")#mi("{\\epsilon > 0}")#text(".")
]

#emph[#text("Proof:")]#text(" The “only if” is immediate from continuity of ")#mi("{\\phi}")#text(", so we turn to the “if” part. As ")#mi("{\\rho}")#text(" is continuous, ")#mi("{\\rho(K)}")#text(" is compact. The restriction ")#mi("{\\rho\\downharpoonright_K: K \\rightarrow \\rho(K)}")#text(" is then a continuous bijection from a compact space to a Hausdorff one, and is therefore a homeomorphism (since it maps closed (hence compact) subsets of ")#mi("{K}")#text(" to compact (hence closed) subsets of ")#mi("{\\rho(K)}")#text(").")

#text("For future reference, we note that this already shows that ")#mi("{G}")#text(" is first-countable, and hence metrisable, thanks to the Birkhoff-Kakutani theorem as ")#link("https://terrytao.wordpress.com/2011/05/17/the-birkhoff-kakutani-theorem/")[#text("discussed earlier")]#text(".")

#text("Since ")#mi("{\\Phi((-\\epsilon,\\epsilon)) \\subset \\rho(K)}")#text(", we see from the homomorphism property that ")#mi("{\\Phi({\\bf R}) \\subset \\rho(G)}")#text(". As ")#mi("{\\rho}")#text(" is faithful, we thus have ")#mi("{\\Phi = \\rho \\circ \\phi}")#text(" for some homomorphism ")#mi("{\\phi: {\\bf R} \\rightarrow G}")#text(", with ")#mi("{\\phi((-\\epsilon,\\epsilon)) \\subset K}")#text(". As ")#mi("{\\rho}")#text(" is a homeomorphism from ")#mi("{K}")#text(" to ")#mi("{\\rho(K)}")#text(", we conclude that ")#mi("{\\phi}")#text(" is continuous on ")#mi("{(-\\epsilon,\\epsilon)}")#text(", and hence (by the homomorphism property of ")#mi("{\\phi}")#text(") is continuous on all of ")#mi("{{\\bf R}}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" If we make the additional assumption that ")#mi("{G}")#text(" is ")#mi("{\\sigma}")#text("-compact, show that any one-parameter subgroup ")#mi("{\\Phi: {\\bf R} \\rightarrow GL_d({\\bf C})}")#text(" taking values in ")#mi("{\\rho(G)}")#text(" factors through ")#mi("{\\rho}")#text(". (Hint: use the ")#link("http://en.wikipedia.org/wiki/Baire_category_theorem")[#text("Baire category theorem")]#text(".)")
]

#text("Henceforth we take ")#mi("{G, \\rho, d, K}")#text(" to be as in the above lemma; it is convenient to take ")#mi("{K}")#text(" to be symmetric, ")#mi("{K = K^{-1}}")#text(". By Lemma ")#link(<tao-a92c36e66a25ee99ff86>)[#text("5")]#text(" and Proposition ")#link(<tao-7f3379c8dba11aab1609>)[#text("4")]#text(", we see that there is a one-to-one correspondence between the space ")#mi("{L(G)}")#text(" of one-parameter subgroups ")#mi("{\\phi}")#text(" of ")#mi("{G}")#text(", and those matrices ")#mi("{A \\in \\mathfrak{gl}_d({\\bf C})}")#text(" with the property that ")#mi("{\\exp(tA) \\in \\rho(K)}")#text(" for all sufficiently small ")#mi("{t}")#text(", by identifying ")#mi("{\\phi}")#text(" with the unique matrix ")#mi("{A}")#text(" for which ")#mi("{\\rho(\\phi(t)) = \\exp(tA)}")#text(" for all ")#mi("{t}")#text(". Let ")#mi("{{\\mathfrak g}}")#text(" denote the set of all such ")#mi("{A}")#text(" that arise in this manner.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6")]#text(" ")#mi("{{\\mathfrak g}}")#text(" is a Lie subalgebra of ")#mi("{\\mathfrak{gl}_d({\\bf C})}")#text(".")
]

#emph[#text("Proof:")]#text(" It is clear that ")#mi("{{\\mathfrak g}}")#text(" contains the origin, and by composing one-parameter subgroups with dilations ")#mi("{t \\mapsto \\lambda t}")#text(" of the real line, we see that it is also closed under scalar multiplication. Now we show that ")#mi("{{\\mathfrak g}}")#text(" is closed under addition. Let ")#mi("{A, B \\in {\\mathfrak g}}")#text(", then we have ")#mi("{\\exp(tA), \\exp(tB) \\in \\rho(K)}")#text(" for all sufficiently small ")#mi("{t}")#text(". In particular, for sufficiently large natural numbers ")#mi("{n}")#text(", we have ")#metadata(none) <tao-3702e46d2e69b459e460>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\exp(A/n), \\exp(B/n) \\in \\rho(K).")]]

#text("We wish to show that ")#mi("{\\exp(t(A+B))}")#text(" lies in ")#mi("{\\rho(K)}")#text(" for all sufficiently small ")#mi("{t}")#text(". The idea is to use the formula ")#metadata(none) <tao-1d5072f894a9d4122cbb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\exp(t(A+B)) = \\lim_{n \\rightarrow \\infty} x_n^{\\lfloor tn \\rfloor}")]]

#text("where ")#mi("{x_n := \\exp(A/n) \\exp(B/n)}")#text(". If we had that ")#mi("{x_n^{\\lfloor tn\\rfloor} \\in \\rho(K)}")#text(" for all sufficiently small ")#mi("{t}")#text(", uniformly for an infinite sequence of ")#mi("{n}")#text(", then the claim would follow from the compact (hence closed) nature of ")#mi("{\\rho(K)}")#text(".")

#text("From ")#link(<tao-3702e46d2e69b459e460>)[#text("(1)")]#text(" and Proposition ")#link(<tao-7f3379c8dba11aab1609>)[#text("4")]#text(", we see that ")#mi("{\\rho^{-1}(\\exp(A/n)), \\rho^{-1}(\\exp(B/n))}")#text(" go to zero as ")#mi("{n \\rightarrow \\infty}")#text(", which implies that for any fixed ")#mi("{k}")#text(", we have ")#mi("{x_n^k \\in \\rho(K)}")#text(" for all sufficiently large ")#mi("{n}")#text(". If we had ")#mi("{x_n^k \\in \\rho(K)}")#text(" for all sufficiently large ")#mi("{n}")#text(" and all ")#mi("{0 \\leq k \\leq n}")#text(", we would be done (using symmetry of ")#mi("{K}")#text(" to then get the negative values of ")#mi("{k}")#text("); so suppose that this is not the case. Then we can find a sequence of ")#mi("{n}")#text(", and a sequence ")#mi("{k_n}")#text(" of natural numbers going to infinity with ")#mi("{k_n \\leq n}")#text(", such that")

#align(center)[#tao-fit-display[#mitex("x_n^k \\in \\rho(K)")]]

#text("for all ")#mi("{0 \\leq k < k_n}")#text(", and")

#align(center)[#tao-fit-display[#mitex("x_n^{k_n} \\not \\in \\rho(K).")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can view the integers ")#mi("{k_n}")#text(" as the “escape times” associated to the ")#mi("{x_n}")#text(". The concept of escape time (and its reciprocal, which one can view as an “escape norm” that measures how deeply nested a given point is inside a fixed neighbourhood of the identity) turns out to be of major importance throughout the theory of Hilbert’s fifth problem; this should become clearer in subsequent posts on this problem.")
]

#text("By passing to a subsequence if necessary we may assume that ")#mi("{k_n/n}")#text(" converges to some limit ")#mi("{\\lambda \\in [0,1]}")#text(". If ")#mi("{\\lambda = 0}")#text(", then (by a variant of ")#link(<tao-1d5072f894a9d4122cbb>)[#text("(2)")]#text(") we would have ")#mi("{x_n^{k_n-1}}")#text(" and ")#mi("{x_n}")#text(" both converging to the identity in ")#mi("{\\rho(K)}")#text(", which contradicts ")#mi("{x_n^{k_n}}")#text(" staying out of ")#mi("{\\rho(K)}")#text(" for sufficiently large ")#mi("{n}")#text(" (recall that ")#mi("{\\rho(K)}")#text(" is homeomorphic to ")#mi("{K}")#text("). So we have ")#mi("{0 < \\lambda \\leq 1}")#text(". But then from ")#link(<tao-1d5072f894a9d4122cbb>)[#text("(2)")]#text(" (and symmetry of ")#mi("{K}")#text(") we have ")#mi("{\\exp(t(A+B)) \\in \\rho(K)}")#text(" for all ")#tao-math("{\\left|t\\right| < \\lambda}", block: false)#text(", and the claim follows.")

#text("A similar argument using the formula")

#align(center)[#tao-fit-display[#mitex("\\exp(t[A,B]) = \\lim_{n \\rightarrow \\infty} y_n^{\\lfloor tn^2 \\rfloor},")]]

#text("where ")#mi("{y_n := \\exp(A/n) \\exp(B/n) \\exp(-A/n) \\exp(-B/n)}")#text(", shows that ")#mi("{{\\mathfrak g}}")#text(" is closed under Lie bracket; we leave the details as an exercise to the reader. Thus ")#mi("{{\\mathfrak g}}")#text(" is a Lie subalgebra of ")#mi("{{\\mathfrak gl}_n({\\bf C})}")#text(" as claimed. ")#mi("\\Box")

#text("We have now located a good candidate ")#mi("{{\\mathfrak g}}")#text(" for the “Lie algebra” of ")#mi("{G}")#text(", which one can then try to “exponentiate” to create Lie group structure for ")#mi("{G}")#text(". Indeed it is clear from construction that ")#mi("{\\exp({\\mathfrak g})}")#text(" is contained in ")#mi("{\\rho(G)}")#text(". However, we have not yet shown that ")#mi("{{\\mathfrak g}}")#text(" is “big enough” to cover all of ")#mi("{G}")#text(". Indeed, at this point it is conceivable that this Lie algebra could well be the trivial Lie algebra, even if ")#mi("{G}")#text(" is highly non-trivial. To prevent this scenario from happening, we need a way to generate non-trivial one-parameter subgroups. Such subgroups can be extracted from sequences in ")#mi("{G}")#text(" converging to the identity by a compactness argument. Let us first illustrate this idea in a simple case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7")]#text(" ")#metadata(none) <tao-3bea44f95b17af14e750>#text(" If ")#mi("{G}")#text(" is not discrete, then ")#mi("{{\\mathfrak g}}")#text(" is non-trivial.")
]

#emph[#text("Proof:")]#text(" If ")#mi("{G}")#text(" is not discrete, then there exists a sequence ")#mi("{g_n \\in G}")#text(" of group elements distinct from the group identity ")#mi("{\\text{id}}")#text(", which nevertheless converge to the identity. (As remarked in the proof of Lemma ")#link(<tao-a92c36e66a25ee99ff86>)[#text("5")]#text(", ")#mi("{G}")#text(" is necessarily metrisable.) Then ")#mi("{\\rho(g_n)}")#text(" converges to the matrix identity, but will always be distinct from the identity. Now let ")#mi("{K}")#text(" be a symmetric compact neighbourhood of the identity in ")#mi("{G}")#text(" that is small enough that ")#mi("{\\rho(K)}")#text(" contains no non-trivial subgroups. Then for each ")#mi("{n}")#text(", ")#mi("{\\rho(g_n)^k}")#text(" must eventually escape ")#mi("{\\rho(K)}")#text(" for some ")#mi("{k}")#text(". Let ")#mi("{k_n}")#text(" be the first natural number for which ")#mi("{\\rho(g_n)^{k_n}}")#text(" escapes ")#mi("{\\rho(K)}")#text(" (or equivalently, for which ")#mi("{g_n^{k_n}}")#text(" escapes ")#mi("{K}")#text("). Since ")#mi("{\\rho(g_n)}")#text(" converges to the identity, we see that ")#mi("{k_n}")#text(" must go to infinity, and the distance between ")#mi("{\\rho(g_n)^{k_n}}")#text(" and the boundary ")#mi("{\\partial \\rho(K)}")#text(" of ")#mi("{\\rho(K)}")#text(" must go to zero. By compactness, we may then pass to a subsequence such that ")#mi("{\\rho(g_n)^{k_n}}")#text(" converges to an element of ")#mi("{\\partial \\rho(K)}")#text("; if ")#mi("{\\rho(K)}")#text(" is small enough, we can write this element as ")#mi("{\\exp(A)}")#text(" for some small ")#mi("{A \\in \\mathfrak{gl}_d({\\bf C})}")#text("; this must be non-zero, as the identity is not a boundary point of ")#mi("{\\rho(K)}")#text(". Using logarithms, we then see (if ")#mi("{K}")#text(" is small enough) that for any ")#tao-math("{\\left|t\\right| \\leq 1}", block: false)#text(", that ")#mi("{\\rho(g_n)^{\\lfloor t k_n\\rfloor}}")#text(" converges to ")#mi("{\\exp(tA)}")#text(". As ")#mi("{\\rho(g_n)^{\\lfloor t k_n\\rfloor}}")#text(" lies in the compact set ")#mi("{\\rho(K)}")#text(", we thus conclude that ")#mi("{\\exp(tA) \\in \\rho(K)}")#text(" for all ")#tao-math("{\\left|t\\right| \\leq 1}", block: false)#text(", and thus ")#mi("{A \\in {\\mathfrak g}}")#text(", and the claim follows. ")#mi("\\Box")

#text("A similar argument now gives")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8")]#text(" There exists a compact neighbourhood ")#mi("{K}")#text(" of the identity in ")#mi("{G}")#text(", and a compact neighbourhood ")#mi("{F}")#text(" of zero in ")#mi("{{\\mathfrak g}}")#text(", such that ")#mi("{\\rho(K) = \\exp( F )}")#text(".")
]

#emph[#text("Proof:")]#text(" The basic idea is to first “quotient out” ")#mi("{{\\mathfrak g}}")#text(" from ")#mi("{{\\mathfrak gl}_n}")#text(" and then apply the Lemma ")#link(<tao-3bea44f95b17af14e750>)[#text("7")]#text(" argument to the quotient space.")

#text("We turn to the details. Let ")#mi("{F}")#text(" be a compact neighbourhood of zero in ")#mi("{{\\mathfrak g}}")#text(". If the claim failed, then there exists a sequence ")#mi("{g_n}")#text(" of group elements ")#mi("{G}")#text(" converging to zero such that ")#mi("{\\rho(g_n) \\not \\in \\exp(F)}")#text(" for any ")#mi("{n}")#text(". Since ")#mi("{\\rho(g_n)}")#text(" is close to zero for large ")#mi("{n}")#text(", we thus have ")#mi("{\\rho(g_n) = \\exp(A_n)}")#text(" for some ")#mi("{A_n \\not \\in {\\mathfrak g}}")#text(" that goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(".")

#text("Split ")#mi("{{\\mathfrak gl}_n({\\bf C})}")#text(" as a vector space direct sum ")#mi("{{\\mathfrak g} + W}")#text(" for some complementary subspace ")#mi("{W}")#text(" (not necessarily a Lie algebra). From the inverse function theorem, we can then write ")#mi("{\\exp(A_n) = \\exp(B_n) \\exp(C_n)}")#text(" where ")#mi("{B_n \\in {\\mathfrak g}}")#text(" and ")#mi("{C_n \\in W}")#text(" both go to zero. Since ")#mi("{A_n \\not \\in {\\mathfrak g}}")#text(", we also have ")#mi("{C_n \\neq 0}")#text(" for ")#mi("{n}")#text(" large enough.")

#text("Let ")#mi("{K}")#text(" be a small compact neighbourhood of the identity in ")#mi("{G}")#text(". For each ")#mi("{B \\in {\\mathfrak g}}")#text(", we have ")#mi("{\\exp(tB) \\in \\rho(K)}")#text(" for ")#mi("{t}")#text(" small enough, thanks to Lemma ")#link(<tao-a92c36e66a25ee99ff86>)[#text("5")]#text(". In particular, ")#mi("{\\exp(tB)}")#text(" avoids the compact set ")#mi("{\\rho(\\partial K)}")#text(" for ")#mi("{t}")#text(" small enough. If ")#mi("{L}")#text(" is a compact neighbourhood of the origin in ")#mi("{{\\mathfrak g}}")#text(", we can conclude that there exists a ")#mi("{t_0>0}")#text(" such that ")#mi("{\\exp(tB)}")#text(" avoids ")#mi("{\\rho(\\partial K)}")#text(" for all ")#mi("{B \\in L}")#text(" and all ")#tao-math("{\\left|t\\right| \\leq t_0}", block: false)#text("; by a continuity argument, we conclude that ")#mi("{\\exp(tB) \\in \\rho(K)}")#text(" for all ")#mi("{B \\in L}")#text(" and all ")#tao-math("{\\left|t\\right| \\leq t_0}", block: false)#text(". In particular, we have ")#mi("{\\exp(B_n) \\in \\rho(K)}")#text(" for sufficiently large ")#mi("{n}")#text(". Letting ")#mi("{K}")#text(" shrink to zero, we conclude that for sufficiently large ")#mi("{n}")#text(", we have ")#mi("{\\exp(B_n) = \\rho(h_n)}")#text(" for some ")#mi("{h_n}")#text(" converging to the identity in ")#mi("{G}")#text(".")

#text("We now have")

#align(center)[#tao-fit-display[#mitex("\\exp(C_n) = \\exp(B_n)^{-1} \\exp(A_n) =\\rho(g^{\\prime}_n)")]]

#text("where ")#mi("{g^{\\prime}_n := h_n^{-1} g_n}")#text(" goes to zero. Since ")#mi("{C_n}")#text(" is non-zero for large ")#mi("{n}")#text(", ")#mi("{g^{\\prime}_n}")#text(" is also non-zero for large ")#mi("{n}")#text(".")

#text("Now we can repeat the arguments used to prove Lemma ")#link(<tao-3bea44f95b17af14e750>)[#text("7")]#text(". As in that lemma, we pick a symmetric neighbourhood ")#mi("{K}")#text(" of ")#mi("{GL_n({\\bf C})}")#text(" small enough to contain no nontrivial subgroups, and let ")#mi("{k_n}")#text(" be the first integer for which ")#mi("{\\rho(g^{\\prime}_n)^{k_n}}")#text(" escapes ")#mi("{K}")#text(". As before, by passing to a subsequence we may assume that there is a non-zero ")#mi("{A \\in \\mathfrak{gl}_n({\\bf C})}")#text(" such that ")#mi("{\\rho(g^{\\prime}_n)^{\\lfloor t k_n \\rfloor} \\rightarrow \\exp(tA)}")#text(" for all ")#tao-math("{\\left|t\\right| \\leq 1}", block: false)#text(". Since ")#mi("{\\rho(g^{\\prime}_n)}")#text(" is the exponential of a small element of ")#mi("{W}")#text(", the same is true for ")#mi("{\\rho(g^{\\prime}_n)^{\\lfloor t k_n \\rfloor}}")#text(" (which, recall, has not yet escaped ")#mi("{K}")#text(") for ")#mi("{t}")#text(" small enough, and we conclude that ")#mi("{tA \\in W}")#text(" for ")#mi("{t}")#text(" small enough. This implies that ")#mi("{W}")#text(" has non-trivial intersection with ")#mi("{{\\mathfrak g}}")#text(", a contradiction. ")#mi("\\Box")

#text("From the above proposition we see that ")#mi("{G}")#text(" is locally isomorphic to ")#mi("{\\exp({\\mathfrak g})}")#text(". But ")#mi("{\\exp({\\mathfrak g})}")#text(" is locally an analytic manifold, and from the Baker-Campbell-Hausdorff formula we see that multiplication and inversion are smooth (and even analytic) operations on ")#mi("{\\exp({\\mathfrak g})}")#text(" locally near the origin. This gives a left-invariant (say) smooth (and even analytic) structure on ")#mi("{G}")#text(" with the group operations smooth near the origin. A continuity argument then shows that the group operations remain smooth on the identity connected component ")#mi("{G^\\circ}")#text(" of ")#mi("{G}")#text(". This already gives Theorem ")#link(<tao-094f686e92c888ae99f8>)[#text("1")]#text(" in the connected case.")

#text("Now we turn to the disconnected case. From the local connectedness of ")#mi("{\\exp({\\mathfrak g})}")#text(" we see that ")#mi("{G}")#text(" is locally connected, so that ")#mi("{G/G^\\circ}")#text(" is discrete. So it will suffice to show that the group operations are continuous on each connected component of ")#mi("{G}")#text(" (i.e. the cosets of the normal subgroup ")#mi("{G^\\circ}")#text(") separately. But observe that any element ")#mi("{h}")#text(" of ")#mi("{G}")#text(" induces an outer automorphism ")#mi("{g \\mapsto hgh^{-1}}")#text(" on ")#mi("{G^\\circ}")#text(", the graph of which can be viewed as a closed connected subgroup of ")#mi("{G^\\circ \\times G^\\circ}")#text(". By the connected case of Theorem ")#link(<tao-094f686e92c888ae99f8>)[#text("1")]#text(", this subgroup must also be a Lie group, and so the outer automorphism is smooth. From this one easily verifies that the group operations are now smooth on all connected components of ")#mi("{G}")#text(", as required.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" A similar argument shows that any continuous homomorphism between two Lie groups is automatically smooth (and analytic). Thus we see a rigidity phenomenon in Lie groups: the smooth structure is completely determined by the topological structure. This is ultimately due to the fact that the Lie algebra (which controls the smooth and analytic structure) can be constructed in a purely topological fashion, via one-parameter subgroups.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" The above arguments were sufficiently “local” in nature that they can be extended without much difficulty to local groups, with the conclusion being that any local group that has a locally faithful continuous linear representation, is a local Lie group.")
]

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/#comment-53153")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2011")])]

#text("Contractive automorphisms may be as relevant as one-parameter subgroups for building a Lie group structure (or even more), as shown by the following result from E. Siebert, Contractive Automorphisms on Locally Compact Groups, Math. Z. 191, 73-90 (1986)")

#text("5.4. Proposition. For a locally compact group G the following assertions are")#linebreak()#text(" equivalent:")#linebreak()#text(" (i) G admits a contractive automorphism group;")#linebreak()#text(" (ii) G is a simply connected Lie group whose Lie algebra g admits a positive")#linebreak()#text(" graduation.")

#text("The corresponding result for local groups is proved in L. van den Dries, I. Goldbring, Locally Compact Contractive Local Groups, arXiv:0909.4565v2.")

#text("I used Siebert result for proving the Lie algebraic structure of the metric tangent space to a sub-riemannian manifold in M. Buliga, Infinitesimal affine geometry of metric spaces endowed with a dilatation structure, Houston Journal of Mathematics, 36, 1 (2010), 91-136. arXiv:0804.0135v2")

#text("When saying that contractive automorphisms, or approximately contractive automorphisms, may be more relevant than one-parameter subgroups, I am thinking about sub-riemannian geometry again, where a one-parameter subgroup of a group, endowed with a left-invariant distribution and a corresponding Carnot-Caratheodory distance, is “smooth” (with respect to")#linebreak()#text(" Pansu-type derivative) if and only if the generator is in the distribution. Metrically speaking, if the generator is not in the distribution then any trajectory of the one-parameter group has Hausdorff dimension greater than one. That means lots of problems with the definition of the exponential and any reasoning based on differentiating flows.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/#comment-53156")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2011")])]

#text("Dear Prof. Tao,")

#text("in order to show the analyticity of the outer automorphism ")#mi("g \\mapsto hgh^{-1}")#text(" on ")#mi("G^\\circ")#text(" you use the connected case of Theorem 1 for its graph, a closed connected subgroup of ")#mi("G^\\circ \\times G^\\circ")#text(".")

#text("Does this step require uniqueness of the smooth structure provided by Theorem 1? The problem is that one needs the graph to be an analytic ")#emph[#text("sub")]#text("manifold of ")#mi("G^\\circ \\times G^\\circ")#text(", as opposed to admitting an arbitrary analytic manifold structure.")

#text("regards, pavel")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/#comment-53163")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2011")])]

#text("Well, part of the conclusion of Theorem 1 is that smooth structure placed on G is not just any old smooth structure – it is the one inherited from the linear group ")#mi("GL_n({\\bf R})")#text(" by locally pulling back under the faithful representing map ")#mi("\\rho: G \\to GL_n({\\bf R})")#text(" (because ")#mi("\\rho(G)")#text(" is locally ")#mi("\\exp({\\mathfrak g})")#text(", and ")#mi("\\exp")#text(" is locally smooth and non-degenerate). One corollary of this is that if H is any closed subgroup of G (and hence also locally compact, with ")#mi("{\\mathfrak h}")#text(" being a sub-Lie algebra of ")#mi("{\\mathfrak g}")#text("), then H will indeed be a smooth manifold of G, with the smooth structure of H being the restriction of the smooth structure of G.")

#text("Applying this to the connected group ")#mi("G^\\circ \\times G^\\circ")#text(" and the subgroup that is the graph of the outer automorphism (both of which are faithfully represented by the same representation ")#mi("\\rho \\oplus \\rho")#text("), we see that this graph is indeed a smooth subgroup.")

#text("In any event, the argument that gives that any outer automorphism is smooth is also the argument used to give Remark 3, which implies in particular that Lie groups have a unique smooth structure.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of van Dantzig’s theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/#comment-53232")[#strong[#text("van Dantzig’s theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2011")])]

#text("[…] noting that all outer automorphisms on a Lie group are smooth (as remarked on in the previous post), we conclude that is also isomorphic to a Lie group. The claim […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Central extensions of Lie groups, and cocycle averaging « What’s new")]], [#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/#comment-53572")[#strong[#text("Central extensions of Lie groups, and cocycle averaging « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2011")])]

#text("[…] locally compact group that we hope to demonstrate is isomorphic to a Lie group. As discussed in a previous post, we first form the space of one-parameter subgroups of (which should, eventually, become the Lie […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hilbert fifth’s problem without one parameter subgroups | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/#comment-53617")[#strong[#text("Hilbert fifth’s problem without one parameter subgroups | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2011")])]

#text("[…] I reproduce, with small modifications, a comment to the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/#comment-53765")[#strong[#text("Seventh Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2011")]

#text("[…] Tao: The Cotlar-Stein Lemma, Locally compact groups with faithful finite-dimensional representations, van Dantzig’s Theorem, The Furstenberg multiple recurrence theorem and finite […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brouwer’s fixed point and invariance of domain theorems, and Hilbert’s fifth problem « What’s new")]], [#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/#comment-53851")[#strong[#text("Brouwer’s fixed point and invariance of domain theorems, and Hilbert’s fifth problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2011")])]

#text("[…] Cartan’s theorem to obtain the smoothness of outer automorphisms on Lie groups as in previous posts, we see that to show that a topological group is a Lie group, it suffices to locate […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hilbert’s fifth problem and Gleason metrics « What’s new")]], [#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/#comment-54023")[#strong[#text("Hilbert’s fifth problem and Gleason metrics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2011")])]

#text("[…] post.) The strategy is similar to that used to prove von Neumann’s theorem, as discussed in this previous post (and von Neumann’s theorem is also used in the proof), but with the Gleason metric serving as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The C^{1,1} Baker-Campbell-Hausdorff formula « What’s new")]], [#link("https://terrytao.wordpress.com/2011/05/27/locally-compact-groups-with-faithful-finite-dimensional-representations/#comment-54121")[#strong[#text("The C^{1,1} Baker-Campbell-Hausdorff formula « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2011")])]

#text("[…] one can avoid any appeal to von Neumann’s theorem and Cartan’s theorem (discussed in this post), or the Kuranishi-Gleason extension theorem (discussed in this […]")
]
