// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/03/17/an-incidence-theorem-in-higher-dimensions/
// Converted to Typst by tao2typ: "2026-10-14T16:36:26.956268+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An incidence theorem in higher dimensions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An incidence theorem in higher dimensions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 March 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/03/17/an-incidence-theorem-in-higher-dimensions/")[#text("https://terrytao.wordpress.com/2011/03/17/an-incidence-theorem-in-higher-dimensions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.ubc.ca/~solymosi/")[#text("Jozsef Solymosi")]#text(" and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1103.2926")[#text("An incidence theorem in higher dimensions")]#text("“, submitted to ")#link("http://www.springer.com/mathematics/numbers/journal/454")[#text("Discrete and Computational Geometry")]#text(". In this paper we use the polynomial Ham Sandwich method of Guth and Katz (as ")#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/")[#text("discussed")]#text(" ")#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/")[#text("previously")]#text(" ")#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/")[#text("on")]#text(" ")#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/")[#text("this blog")]#text(") to establish higher-dimensional versions of the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%E2%80%93Trotter_theorem")[#text("Szemerédi-Trotter theorem")]#text(", albeit at the cost of an epsilon loss in exponents.")

#text("Recall that the Szemerédi-Trotter theorem asserts that given any finite set of points ")#mi("{P}")#text(" and lines ")#mi("{L}")#text(" in the plane ")#mi("{{\\bf R}^2}")#text(", the number of incidences ")#mi("{I(P,L) := \\{ (p,\\ell) \\in P \\times L: p \\in \\ell \\}}")#text(" has the upper bound")

#align(center)[#tao-fit-display[#tao-math("\\left|I(P,L)\\right| \\ll \\left|P\\right|^{2/3} \\left|L\\right|^{2/3} + \\left|P\\right| + \\left|L\\right|.", block: true)]]

#text("Apart from the constant factor, this bound is sharp. As discussed in ")#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/")[#text("this previous blog post")]#text(", this theorem can be proven by the polynomial method, and the strategy can be rapidly summarised as follows. Select a parameter ")#mi("{D \\geq 1}")#text(". By the polynomial Ham Sandwich theorem, one can divide ")#mi("{{\\bf R}^2}")#text(" into ")#mi("{O(D^2)}")#text(" cell interiors, each with ")#tao-math("{O(\\left|P\\right|/D^2)}", block: false)#text(" points, and incident to ")#tao-math("{O(\\left|L\\right|/D)}", block: false)#text(" lines on the average, plus a boundary set which is an algebraic curve of degree ")#mi("{O(D)}")#text(". To handle the contribution of each cell interior, one uses a more elementary incidence bound (such as the bound ")#tao-math("{\\left|I(P,L)\\right| \\ll \\left|P\\right| \\left|L\\right|^{1/2} + \\left|L\\right|}", block: false)#text(" coming from the fact that two points determine at most one line); to handle the contribution on the cell boundary, one uses algebraic geometry tools such as Bezout’s theorem. One then combines all the bounds and optimises in ")#mi("{D}")#text(" to obtain the result.")

#text("As a general rule, the contribution of the cell interiors becomes easier to handle as ")#mi("{D}")#text(" increases, while the contribution of the cell boundaries become easier as ")#mi("{D}")#text(" ")#emph[#text("decreases")]#text(". As such, the optimal value of ")#mi("{D}")#text(" is often an intermediate one (in the case of Szemerédi-Trotter, the choice ")#tao-math("{D = \\left|P\\right|^{2/3} \\left|L\\right|^{-1/3}}", block: false)#text(" is typical). Among other things, this requires some control of moderately high degree algebraic sets, though in this planar case ")#mi("{{\\bf R}^2}")#text(", one only needs to control algebraic curves in the plane, which are very well understood.")

#text("In higher dimensions, though, the complexity of the algebraic geometry required to control medium degree algebraic sets increases sharply; compare for instance the algebraic geometry of ruled surfaces appearing in the three-dimensional ")#link("http://arxiv.org/abs/1011.4105")[#text("work of Guth and Katz")]#text(" ")#link("https://terrytao.wordpress.com/2010/11/20/the-guth-katz-bound-on-the-erdos-distance-problem/")[#text("as discussed here")]#text(", compared with the algebraic geometry of curves in the two-dimensional Szemerédi-Trotter theorem ")#link("https://terrytao.wordpress.com/2011/02/18/the-szemeredi-trotter-theorem-via-the-polynomial-ham-sandwich-theorem/")[#text("discussed here")]#text(".")

#text("However, Jozsef and I discovered that it is also possible to use the polynomial method with a ")#emph[#text("non-optimised")]#text(" value of ")#mi("{D}")#text(", and in particular with a ")#emph[#text("bounded")]#text(" value ")#mi("{D=O(1)}")#text(" of ")#mi("{D}")#text(", which makes the algebraic geometry treatment of the boundary significantly easier. The drawback to this is that the cell interiors can no longer be adequately controlled by trivial incidence estimates. However, if instead one controls the cell interiors by an ")#emph[#text("induction hypothesis")]#text(", then it turns out that in many cases one can recover a good estimate. For instance, let us consider the two-dimensional Szemerédi-Trotter theorem in the most interesting regime, namely when the ")#tao-math("{\\left|P\\right|^{2/3} \\left|L\\right|^{2/3}}", block: false)#text(" term on the RHS is dominant. If we perform the cell decomposition with some small parameter ")#mi("{D}")#text(", then we obtain ")#mi("{O(D^2)}")#text(" cells with ")#tao-math("{O(\\left|P\\right|/D^2)}", block: false)#text(" points and ")#tao-math("{O(\\left|L\\right|/D)}", block: false)#text(" lines on the average; applying the Szemerédi-Trotter theorem inductively to each of these cells, we end up with a total contribution of")

#align(center)[#tao-fit-display[#tao-math("O( D^2 ) \\times O( \\left|P\\right|/D^2)^{2/3} \\times O( \\left|L\\right|/D)^{2/3} = O( \\left|P\\right|^{2/3} \\left|L\\right|^{2/3} )", block: true)]]

#text("for the cell interiors, and so provided that one can also control incidences on the (low degree) cell boundary, we see that we have closed the induction (up to changes in the implied constants in the ")#mi("{O()}")#text(" notation).")

#text("Unfortunately, as is well known, the fact that the implied constants in the ")#mi("{O()}")#text(" notation degrade when we do this prevents this induction argument from being rigorous. However, it turns out this method does work nicely to give the weaker incidence bound")

#align(center)[#tao-fit-display[#tao-math("\\left|I(P,L)\\right| \\ll_\\epsilon \\left|P\\right|^{2/3+\\epsilon} \\left|L\\right|^{2/3} + \\left|P\\right| + \\left|L\\right|", block: true)]]

#text("for any fixed ")#mi("{\\epsilon > 0}")#text("; the point being that this extra epsilon of room in the exponents means that the induction hypothesis gains a factor of ")#mi("{D^{-\\epsilon}}")#text(" or so over the desired conclusion, allowing one to close the induction with no loss of implied constants if all the parameters are chosen properly. While this bound is weaker than the full Szemerédi-Trotter theorem, the argument is simpler in the sense that one only needs to understand bounded degree algebraic sets, rather than medium degree algebraic sets. As such, this argument is easier to extend to higher dimensions.")

#text("Indeed, as a consequence of this strategy (and also a generic projection argument to cut down the ambient dimension, as used in ")#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/")[#text("this previous paper with Ellenberg and Oberlin")]#text(", and an induction on dimension), we obtain in our paper a higher-dimensional incidence theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Higher-dimensional Szemerédi-Trotter theorem)")]#text(" ")#metadata(none) <tao-f070cac0b540b70c2ca1>#text(" Let ")#mi("{d \\geq 2k}")#text(", and let ")#mi("{P}")#text(" and ")#mi("{L}")#text(" be finite sets of points and ")#mi("{k}")#text("-planes in ")#mi("{{\\bf R}^d}")#text(", such that any two ")#mi("{k}")#text("-planes in ")#mi("{L}")#text(" intersect in at most one point. Then we have ")#tao-math("{\\left|I(P,L)\\right| \\ll_{k,\\epsilon} \\left|P\\right|^{2/3+\\epsilon} \\left|L\\right|^{2/3} + \\left|P\\right| + \\left|L\\right|}", block: false)#text(" for any ")#mi("{\\epsilon > 0}")#text(".")
]

#text("Something like the transversality hypothesis that any two ")#mi("{k}")#text("-planes in ")#mi("{L}")#text(" intersect in at most one point is necessary, as can be seen by considering the example in which the points ")#mi("{P}")#text(" are all collinear, and the ")#mi("{k}")#text("-planes in ")#mi("{L}")#text(" all contain the common line. As one particular consequence of this result, we recover (except for an epsilon loss in exponents) the ")#link("http://arxiv.org/abs/math/0305283")[#text("complex Szemerédi-Trotter theorem of Toth")]#text(", whose proof was significantly more complicated; it also gives some matrix and quaternionic analogues, in particular giving new sum-product theorems in these rings. Note that the condition ")#mi("{d \\geq 2k}")#text(" is natural, because when the ambient dimension is less than ")#mi("{2k}")#text(", it is not possible for two ")#mi("{k}")#text("-planes to intersect in just one point. Using the generic projection trick, one can easily reduce to the critical case ")#mi("{d=2k}")#text(".")

#text("Actually, for inductive reasons, we prove a more general result than Theorem ")#link(<tao-f070cac0b540b70c2ca1>)[#text("1")]#text(", in which the ")#mi("{k}")#text("-planes are replaced instead by ")#mi("{k}")#text("-dimensional real algebraic varieties. The transversality condition is now that whenever a point ")#mi("{p}")#text(" is incident to two such varieties ")#mi("{\\ell, \\ell^{\\prime}}")#text(", that the tangent cones of ")#mi("{\\ell}")#text(" and ")#mi("{\\ell^{\\prime}}")#text(" at ")#mi("{p}")#text(" only intersect at ")#mi("{p}")#text(". (Also for technical reasons, it is convenient to consider a partial subset ")#mi("{{\\mathcal I}}")#text(" of incidences in ")#mi("{I(P,L)}")#text(", rather than the full set of incidences. Indeed, it seems most natural to consider the triplet")

#align(center)[#tao-fit-display[#mitex("\\begin{array}{ccccc} \\\\ && {\\mathcal I} && \\\\ & \\swarrow & & \\searrow & \\\\ P & & & & L \\end{array}")]]

#text("as a single diagram, rather than to consider just the sets ")#mi("{P}")#text(" and ")#mi("{L}")#text(".)")

#text("The reason for working in this greater level of generality is that it becomes much easier to use an induction hypothesis to deal with the cell boundary; one simply intersects each variety ")#mi("{\\ell}")#text(" in ")#mi("{L}")#text(" with the cell boundary, which usually lowers the dimension of the variety by one. (There are some exceptional cases in which ")#mi("{\\ell}")#text(" is completely trapped inside the boundary, but due to the transversality hypothesis, this cannot contribute many incidences if the ambient dimension is ")#mi("{2k}")#text(" (so the cell boundary is only ")#mi("{2k-1}")#text(" dimensional).)")

#text("As one application of this more general incidence result, we almost extend a ")#link("http://www.ams.org/mathscinet-getitem?mr=777185")[#text("classic result of Spencer, Szemerédi, and Trotter")]#text(" asserting that ")#mi("{n}")#text(" points in the plane ")#mi("{{\\bf R}^2}")#text(" determine ")#mi("{O(n^{4/3})}")#text(" unit distances from ")#mi("{{\\bf R}^2}")#text(" to ")#mi("{{\\bf C}^2}")#text(", at the cost of degrading ")#mi("{O(n^{4/3})}")#text(" to ")#mi("{O_\\epsilon(n^{4/3+\\epsilon})}")#text(".")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/56f289e9808e48320ceeb95df9082997fd24673523fcd310015424af4ba4c6ce-6d040766ed9c463f2d644d3ff5615ac29406a9d73b1906ea07ebd8a680eeebc1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Iosevich")]], [#link("https://terrytao.wordpress.com/2011/03/17/an-incidence-theorem-in-higher-dimensions/#comment-50829")[#strong[#text("Alex Iosevich")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2011")])]

#text("If a family of $k$-planes satisfies an additional “rotational curvature” type assumptions, one can obtain an incidence theorem, albeit a much more limited one, using the technology in ")#link("http://arxiv.org/pdf/0709.3786")[#text("http://arxiv.org/pdf/0709.3786")]#text(" (Geometric incidence theorems via Fourier analysis). It might be interesting to try to understand the non-degeneracy assumptions used in your paper in the context regularity bounds for the associated generalized Radon transforms.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/17/an-incidence-theorem-in-higher-dimensions/#comment-50838")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2011")])]

#text("Alex: thanks for the reference and suggestion! At first glance the algebraic and Fourier-analytic methods seem to be adapted to rather different regimes of incidence structures, but there could be some common ground in which they can be compared or even combined.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2011/03/17/an-incidence-theorem-in-higher-dimensions/#comment-50837")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2011")])]

#text("Lovely!")

#text("One note — when you say above “determine O(n^{4/3} distances)” I think you mean “determine O(n^{4/3}) unit distances,” i.e. in the set of distances each complex number appears at most O(n^{4/3}) times.")

#text("Also, unless I missed it, while the Spencer-Szemeredi-Trotter result appears in the bibliography (as [19]) I don’t think it actually gets a citation in the paper; maybe there’s meant to be one around Corollary 2.10?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/17/an-incidence-theorem-in-higher-dimensions/#comment-50839")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2011")])]

#text("Oops! Yes, there ought to have been a citation, but it got commented out by accident. We’ll put it back in for the next revision of the ms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/458f19f1137c62e7359bde57a6e41d91e31a1efeea107ff6af7227841484d576-c84c4ed3eb8f847c2b1e859e3d84fc9a04ae305afcc0068fb38f50d050c7ca71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Izabella Laba")]], [#link("https://terrytao.wordpress.com/2011/03/17/an-incidence-theorem-in-higher-dimensions/#comment-50842")[#strong[#text("Izabella Laba")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2011")])]

#text("Terry – You might be interested to know that several years ago Jozsef and I ")#link("http://xxx.lanl.gov/abs/math/0505164")[#text(" proved a very similar result")]#text(" for incidences between homogeneous point sets and either 1-dimensional “pseudolines” in any dimension or 2-dimensional “pseudoflats” in dimension 3. The exponents seem to be the same as in the corresponding cases of your paper. Our proof also involved a cell decomposition and an induction process, but our cells were simply cubes of equal sizes (as opposed to the more refined decomposition given by the ham sandwich theorem) and therefore we needed to assume that the point set was homogeneous.")

#text("The terminology “pseudolines” was first introduced in a 1998 paper by Pach and Sharir. There have since been a number of other papers on Szemeredi-Trotter type theorems for lines and pseudolines in higher dimensions, for example Elekes-Toth or Solymosi-Vu.")

#text("Also, I thought that the Szemeredi-Trotter theorem for complex lines has had other proofs since Toth’s work, including one by Jozsef?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/17/an-incidence-theorem-in-higher-dimensions/#comment-50860")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2011")])]

#text("Izabella – thanks for the reference! (Now that you mention it, I do remember this paper when it came out…) I guess in hindsight that the homogeneous case can be viewed as the special case in which the cell decompositions given by the polynomial method are just a grid of hyperplanes, which helps explain why it is such a useful model case.")

#text("As I understand it, our definition of pseudoline is slightly different from the Pach-Sharir one, we will make some clarifications on this in the paper (which we are revising now to add a broader survey of the area, beyond those papers relating to the polynomial method). Regarding complex Szemeredi-Trotter, I think the only other result in this direction is one by Solymosi and Tardos proving that theorem for product sets but not for the general case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b3b201f0308437d9f237aa2421c789a8ff84f856f2240209b2ad74a1592accc-e239f0fb4837efa15a46cd87f105e0f109c8ac7df42ba28e6eea88c2d9098976.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of iosevich")]], [#link("https://terrytao.wordpress.com/2011/03/17/an-incidence-theorem-in-higher-dimensions/#comment-50861")[#strong[#text("iosevich")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2011")])]

#text("A quick followup on my previous comment. In my aforementioned paper with Hadi and Izabella, we use homogeneous sets. However, those results can be extended to the so-called ")#mi("s")#text("-adaptable sets, as defined by Misha Rudnev, Ignacio Uriarte-Tuero and I in “Theory of dimension for large discrete sets and applications”, ")#link("http://arxiv.org/pdf/0707.1322")[#text("http://arxiv.org/pdf/0707.1322")]#text(" The basic idea there is to take, say, a ")#mi("1")#text("-separated set of ")#mi("N")#text(" points in ")#mi("{\\Bbb R}^d")#text(", scale it down to the unit cube and thicken each point by ")#mi("N^{-\\frac{1}{s}}")#text(". If the Hausdorff dimension of this set (as measured by the ")#mi("s")#text(" energy integral) is finite, the original set is said to be ")#mi("s")#text("-adaptable.")

#text("In terms of cell decompositions, it is reasonably clear, as you point out, how homogeneous sets simplify the construction. What I do not see at the moment is how ")#mi("s")#text("-adaptability makes things simpler on a combinatorial level. On the analytic level, the convenience of this definition is fairly clear.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/458f19f1137c62e7359bde57a6e41d91e31a1efeea107ff6af7227841484d576-c84c4ed3eb8f847c2b1e859e3d84fc9a04ae305afcc0068fb38f50d050c7ca71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Izabella Laba")]], [#link("https://terrytao.wordpress.com/2011/03/17/an-incidence-theorem-in-higher-dimensions/#comment-51655")[#strong[#text("Izabella Laba")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2011")])]

#text("Terry – Thanks for including a reference to my paper with Jozsef in the new version, but what you say about our results:")

#text("“in [20], sharp incidence bounds between a homogeneous set of points and k-dimensional subspaces were given”")

#text("is not correct. On the one hand, our results are limited to 1-dimensional pseudolines in R^n and 2-dimensional pseudoplanes in R^3. On the other hand, the pseudoplanes need not be subspaces, in fact our assumptions will be satisfied by irreducible one-dimensional algebraic varieties in R^n and generic 2-dimensional algebraic varieties in R^3.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/17/an-incidence-theorem-in-higher-dimensions/#comment-51688")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("Izabella – thanks for the correction. I think I was basing that remark over an older version of the paper which involved points and subspaces rather than points and pseudolines; I’ll work with Jozsef to sort it all out properly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b3b201f0308437d9f237aa2421c789a8ff84f856f2240209b2ad74a1592accc-e239f0fb4837efa15a46cd87f105e0f109c8ac7df42ba28e6eea88c2d9098976.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of iosevich")]], [#link("https://terrytao.wordpress.com/2011/03/17/an-incidence-theorem-in-higher-dimensions/#comment-51872")[#strong[#text("iosevich")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2011")])]

#text("As you know, in two dimensions there is a (conjectural) discrepancy between algebraic varieties as far as incidence theory is concerned. The number of incidences between ")#mi("n")#text(" points and ")#mi("n")#text(" circles of the same radius centered at those points is conjectured (Erdos unit distance conjecture) to be no more than ")#mi("Cn \\log(n)")#text(". On the other hand, a very elegant construction due to Pavel Valtr shows that the situation changes if circles are replaced by parabolas. Take an ")#mi("n")#text(" by ")#mi("n^2")#text(" integer grid and translate the parabola ")#mi("y=x^2")#text(" around. The total number of incidences is ")#mi("\\approx n^4")#text(" and the number of points (and parabolas) is ")#mi("\\approx n^3")#text(", which makes the number of incidences ")#mi("\\approx N^{\\frac{4}{3}}")#text(".")

#text("It would be interesting to explore this type of dicotomy thoroughly in higher dimensions, I believe.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/17/an-incidence-theorem-in-higher-dimensions/#comment-51875")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2011")])]

#text("There may be some hope in using algebraic methods to discern these sorts of dichotomies. For instance, the Guth-Katz incidence bound between points and lines in R^3 requires that not too many lines congregate in a doubly ruled surface (i.e. a plane or a regulus). Of course, without such an axiom, the best incidence bound one can hope for between points and lines is the Szemeredi-Trotter bound. But if one replaces lines with some other family of low-degree curves for which there are no analogous “doubly ruled surfaces”, then presumably the Guth-Katz bound becomes unconditional, and so one can improve upon the Szemeredi-Trotter theorem in this case. Projecting from three dimensions to two, one should then be able to get improved Szemeredi-Trotter theorems for certain families of low-degree curves, though I have not worked out the details.")

#text("(Actually this ties in with another basic open problem in the subject, which is to obtain a usable inverse Szemeredi-Trotter theorem. Suppose we have n points and n lines that are determining n^{4/3} incidences in the plane. Can we then say that most of the points and lines are arranged in some highly structured set, such as a grid? Even formulating a plausible ")#emph[#text("statement")]#text(" for such an inverse theorem seems difficult.)")
]
]
