// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/
// Converted to Typst by tao2typ: "2026-10-14T16:38:39.422055+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Almost all Collatz orbits attain almost bounded values", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Almost all Collatz orbits attain almost bounded values")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 September 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/")[#text("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("http://arxiv.org/abs/1909.03562")[#text("Almost all Collatz orbits attain almost bounded values")]#text("“, submitted to the proceedings of the ")#link("https://www.cambridge.org/core/journals/forum-of-mathematics-pi")[#text("Forum of Mathematics, Pi")]#text(". In this paper I returned to the topic of the notorious ")#link("https://en.wikipedia.org/wiki/Collatz_conjecture")[#text("Collatz conjecture")]#text(" (also known as the ")#mi("{3x+1}")#text(" conjecture), which I previously discussed in ")#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/")[#text("this blog post")]#text(". This conjecture can be phrased as follows. Let ")#mi("{{\\bf N}+1 = \\{1,2,\\dots\\}}")#text(" denote the positive integers (with ")#mi("{{\\bf N} =\\{0,1,2,\\dots\\}}")#text(" the natural numbers), and let ")#mi("{\\mathrm{Col}: {\\bf N}+1 \\rightarrow {\\bf N}+1}")#text(" be the map defined by setting ")#mi("{\\mathrm{Col}(N)}")#text(" equal to ")#mi("{3N+1}")#text(" when ")#mi("{N}")#text(" is odd and ")#mi("{N/2}")#text(" when ")#mi("{N}")#text(" is even. Let ")#mi("{\\mathrm{Col}_{\\min}(N) := \\inf_{n \\in {\\bf N}} \\mathrm{Col}^n(N)}")#text(" be the minimal element of the Collatz orbit ")#mi("{N, \\mathrm{Col}(N), \\mathrm{Col}^2(N),\\dots}")#text(". Then we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Collatz conjecture)")]#text(" One has ")#mi("{\\mathrm{Col}_{\\min}(N)=1}")#text(" for all ")#mi("{N \\in {\\bf N}+1}")#text(".")
]

#text("Establishing the conjecture for all ")#mi("{N}")#text(" remains out of reach of current techniques (for instance, as discussed in the ")#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/")[#text("previous blog post")]#text(", it is basically at least as difficult as ")#link("https://en.wikipedia.org/wiki/Baker%27s_theorem")[#text("Baker’s theorem")]#text(", all known proofs of which are quite difficult). However, the situation is more promising if one is willing to settle for results which only hold for “most” ")#mi("{N}")#text(" in some sense. For instance, it is a result ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1980260")[#text("of Krasikov and Lagarias")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\{ N \\leq x: \\mathrm{Col}_{\\min}(N) = 1 \\} \\gg x^{0.84}")]]

#text("for all sufficiently large ")#mi("{x}")#text(". In another direction, it was shown ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=568274")[#text("by Terras")]#text(" that for almost all ")#mi("{N}")#text(" (in the sense of ")#link("https://en.wikipedia.org/wiki/Natural_density")[#text("natural density")]#text("), one has ")#mi("{\\mathrm{Col}_{\\min}(N) < N}")#text(". This was then improved ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=567874")[#text("by Allouche")]#text(" to ")#mi("{\\mathrm{Col}_{\\min}(N) < N^\\theta}")#text(" for almost all ")#mi("{N}")#text(" and any fixed ")#mi("{\\theta > 0.869}")#text(", and extended later ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1290275")[#text("by Korec")]#text(" to cover all ")#mi("{\\theta > \\frac{\\log 3}{\\log 4} \\approx 0.7924}")#text(". In this paper we obtain the following further improvement (at the cost of weakening natural density to logarithmic density):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" Let ")#mi("{f: {\\bf N}+1 \\rightarrow {\\bf R}}")#text(" be any function with ")#mi("{\\lim_{N \\rightarrow \\infty} f(N) = +\\infty}")#text(". Then we have ")#mi("{\\mathrm{Col}_{\\min}(N) < f(N)}")#text(" for almost all ")#mi("{N}")#text(" (in the sense of logarithmic density).")
]

#text("Thus for instance one has ")#mi("{\\mathrm{Col}_{\\min}(N) < \\log\\log\\log\\log N}")#text(" for almost all ")#mi("{N}")#text(" (in the sense of logarithmic density).")#linebreak()#text(" The difficulty here is one usually only expects to establish “local-in-time” results that control the evolution ")#mi("{\\mathrm{Col}^n(N)}")#text(" for times ")#mi("{n}")#text(" that only get as large as a small multiple ")#mi("{c \\log N}")#text(" of ")#mi("{\\log N}")#text("; the aforementioned results of Terras, Allouche, and Korec, for instance, are of this type. However, to get ")#mi("{\\mathrm{Col}^n(N)}")#text(" all the way down to ")#mi("{f(N)}")#text(" one needs something more like an “(almost) global-in-time” result, where the evolution remains under control for so long that the orbit has nearly reached the bounded state ")#mi("{N=O(1)}")#text(".")#linebreak()#text(" However, as ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1309539")[#text("observed by Bourgain")]#text(" in the context of nonlinear Schrödinger equations, one can iterate “almost sure local wellposedness” type results (which give local control for almost all initial data from a given distribution) into “almost sure (almost) global wellposedness” type results if one is fortunate enough to draw one’s data from an ")#emph[#text("invariant measure")]#text(" for the dynamics. To illustrate the idea, let us take Korec’s aforementioned result that if ")#mi("{\\theta > \\frac{\\log 3}{\\log 4}}")#text(" one picks at random an integer ")#mi("{N}")#text(" from a large interval ")#mi("{[1,x]}")#text(", then in most cases, the orbit of ")#mi("{N}")#text(" will eventually move into the interval ")#mi("{[1,x^{\\theta}]}")#text(". Similarly, if one picks an integer ")#mi("{M}")#text(" at random from ")#mi("{[1,x^\\theta]}")#text(", then in most cases, the orbit of ")#mi("{M}")#text(" will eventually move into ")#mi("{[1,x^{\\theta^2}]}")#text(". It is then tempting to concatenate the two statements and conclude that for most ")#mi("{N}")#text(" in ")#mi("{[1,x]}")#text(", the orbit will eventually move ")#mi("{[1,x^{\\theta^2}]}")#text(". Unfortunately, this argument does not quite work, because by the time the orbit from a randomly drawn ")#mi("{N \\in [1,x]}")#text(" reaches ")#mi("{[1,x^\\theta]}")#text(", the distribution of the final value is unlikely to be close to being uniformly distributed on ")#mi("{[1,x^\\theta]}")#text(", and in particular could potentially concentrate almost entirely in the exceptional set of ")#mi("{M \\in [1,x^\\theta]}")#text(" that do not make it into ")#mi("{[1,x^{\\theta^2}]}")#text(". The point here is the uniform measure on ")#mi("{[1,x]}")#text(" is not transported by Collatz dynamics to anything resembling the uniform measure on ")#mi("{[1,x^\\theta]}")#text(".")#linebreak()#text(" So, one now needs to locate a measure which has better invariance properties under the Collatz dynamics. It turns out to be technically convenient to work with a standard acceleration of the Collatz map known as the ")#emph[#text("Syracuse map")]#text(" ")#mi("{\\mathrm{Syr}: 2{\\bf N}+1 \\rightarrow 2{\\bf N}+1}")#text(", defined on the odd numbers ")#mi("{2{\\bf N}+1 = \\{1,3,5,\\dots\\}}")#text(" by setting ")#mi("{\\mathrm{Syr}(N) = (3N+1)/2^a}")#text(", where ")#mi("{2^a}")#text(" is the largest power of ")#mi("{2}")#text(" that divides ")#mi("{3N+1}")#text(". (The advantage of using the Syracuse map over the Collatz map is that it performs precisely one multiplication of ")#mi("{3}")#text(" at each iteration step, which makes the map better behaved when performing “")#mi("{3}")#text("-adic” analysis.)")#linebreak()#text(" When viewed ")#mi("{3}")#text("-adically, we soon see that iterations of the Syracuse map become somewhat irregular. Most obviously, ")#mi("{\\mathrm{Syr}(N)}")#text(" is never divisible by ")#mi("{3}")#text(". A little less obviously, ")#mi("{\\mathrm{Syr}(N)}")#text(" is twice as likely to equal ")#mi("{2}")#text(" mod ")#mi("{3}")#text(" as it is to equal ")#mi("{1}")#text(" mod ")#mi("{3}")#text(". This is because for a randomly chosen odd ")#mi("{\\mathbf{N}}")#text(", the number of times ")#mi("{\\mathbf{a}}")#text(" that ")#mi("{2}")#text(" divides ")#mi("{3\\mathbf{N}+1}")#text(" can be seen to have a ")#link("https://en.wikipedia.org/wiki/Geometric_distribution")[#text("geometric distribution")]#text(" of mean ")#mi("{2}")#text(" – it equals any given value ")#mi("{a \\in{\\bf N}+1}")#text(" with probability ")#mi("{2^{-a}}")#text(". Such a geometric random variable is twice as likely to be odd as to be even, which is what gives the above irregularity. There are similar irregularities modulo higher powers of ")#mi("{3}")#text(". For instance, one can compute that for large random odd ")#mi("{\\mathbf{N}}")#text(", ")#mi("{\\mathrm{Syr}^2(\\mathbf{N}) \\text{ mod } 9}")#text(" will take the residue classes ")#mi("{0,1,2,3,4,5,6,7,8 \\text{ mod } 9}")#text(" with probabilities")

#align(center)[#tao-fit-display[#mitex("0, \\frac{8}{63}, \\frac{16}{63}, 0, \\frac{11}{63}, \\frac{4}{63}, 0, \\frac{2}{63}, \\frac{22}{63}")]]

#text("respectively. More generally, for any ")#mi("{n}")#text(", ")#mi("{\\mathrm{Syr}^n(N) \\text{ mod } 3^n}")#text(" will be distributed according to the law of a random variable ")#mi("{\\mathbf{Syrac}({\\bf Z}/3^n{\\bf Z})}")#text(" on ")#mi("{{\\bf Z}/3^n{\\bf Z}}")#text(" that we call a ")#emph[#text("Syracuse random variable")]#text(", and can be described explicitly as ")#metadata(none) <tao-1d479541a5598f6d7bfd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\mathbf{Syrac}({\\bf Z}/3^n{\\bf Z}) = 2^{-\\mathbf{a}_1} + 3^1 2^{-\\mathbf{a}_1-\\mathbf{a}_2} + \\dots + 3^{n-1} 2^{-\\mathbf{a}_1-\\dots-\\mathbf{a}_n} \\text{ mod } 3^n,")]]

#text("where ")#mi("{\\mathbf{a}_1,\\dots,\\mathbf{a}_n}")#text(" are iid copies of a geometric random variable of mean ")#mi("{2}")#text(".")#linebreak()#text(" In view of this, any proposed “invariant” (or approximately invariant) measure (or family of measures) for the Syracuse dynamics should take this ")#mi("{3}")#text("-adic irregularity of distribution into account. It turns out that one can use the Syracuse random variables ")#mi("{\\mathbf{Syrac}({\\bf Z}/3^n{\\bf Z})}")#text(" to construct such a measure, but only if these random variables stabilise in the limit ")#mi("{n \\rightarrow \\infty}")#text(" in a certain total variation sense. More precisely, in the paper we establish the estimate ")#metadata(none) <tao-757d1728ede288eecad9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\sum_{Y \\in {\\bf Z}/3^n{\\bf Z}} \\left| \\mathbb{P}( \\mathbf{Syrac}({\\bf Z}/3^n{\\bf Z})=Y) - 3^{m-n} \\mathbb{P}( \\mathbf{Syrac}({\\bf Z}/3^m{\\bf Z})=Y \\text{ mod } 3^m)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll_A m^{-A}")]]

#text("for any ")#mi("{1 \\leq m \\leq n}")#text(" and any ")#mi("{A > 0}")#text(". This type of stabilisation is plausible from entropy heuristics – the tuple ")#mi("{(\\mathbf{a}_1,\\dots,\\mathbf{a}_n)}")#text(" of geometric random variables that generates ")#mi("{\\mathbf{Syrac}({\\bf Z}/3^n{\\bf Z})}")#text(" has Shannon entropy ")#mi("{n \\log 4}")#text(", which is significantly larger than the total entropy ")#mi("{n \\log 3}")#text(" of the uniform distribution on ")#mi("{{\\bf Z}/3^n{\\bf Z}}")#text(", so we expect a lot of “mixing” and “collision” to occur when converting the tuple ")#mi("{(\\mathbf{a}_1,\\dots,\\mathbf{a}_n)}")#text(" to ")#mi("{\\mathbf{Syrac}({\\bf Z}/3^n{\\bf Z})}")#text("; these heuristics can be supported by numerics (which I was able to work out up to about ")#mi("{n=10}")#text(" before running into memory and CPU issues), but it turns out to be surprisingly delicate to make this precise.")#linebreak()#text(" A first hint of how to proceed comes from the elementary number theory observation (easily proven by induction) that the rational numbers")

#align(center)[#tao-fit-display[#mitex("2^{-a_1} + 3^1 2^{-a_1-a_2} + \\dots + 3^{n-1} 2^{-a_1-\\dots-a_n}")]]

#text("are all distinct as ")#mi("{(a_1,\\dots,a_n)}")#text(" vary over tuples in ")#mi("{({\\bf N}+1)^n}")#text(". Unfortunately, the process of reducing mod ")#mi("{3^n}")#text(" creates a lot of collisions (as must happen from the pigeonhole principle); however, by a simple “Lefschetz principle” type argument one can at least show that the reductions ")#metadata(none) <tao-c549779d79e5c8e9c9a6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("2^{-a_1} + 3^1 2^{-a_1-a_2} + \\dots + 3^{m-1} 2^{-a_1-\\dots-a_m} \\text{ mod } 3^n")]]

#text("are mostly distinct for “typical” ")#mi("{a_1,\\dots,a_m}")#text(" (as drawn using the geometric distribution) as long as ")#mi("{m}")#text(" is a bit smaller than ")#mi("{\\frac{\\log 3}{\\log 4} n}")#text(" (basically because the rational number appearing in ")#link(<tao-c549779d79e5c8e9c9a6>)[#text("(3)")]#text(" then typically takes a form like ")#mi("{M/2^{2m}}")#text(" with ")#mi("{M}")#text(" an integer between ")#mi("{0}")#text(" and ")#mi("{3^n}")#text("). This analysis of the component ")#link(<tao-c549779d79e5c8e9c9a6>)[#text("(3)")]#text(" of ")#link(<tao-1d479541a5598f6d7bfd>)[#text("(1)")]#text(" is already enough to get quite a bit of spreading on ")#mi("{ \\mathbf{Syrac}({\\bf Z}/3^n{\\bf Z})}")#text(" (roughly speaking, when the argument is optimised, it shows that this random variable cannot concentrate in any subset of ")#mi("{{\\bf Z}/3^n{\\bf Z}}")#text(" of density less than ")#mi("{n^{-C}}")#text(" for some large absolute constant ")#mi("{C>0}")#text("). To get from this to a stabilisation property ")#link(<tao-757d1728ede288eecad9>)[#text("(2)")]#text(" we have to exploit the mixing effects of the remaining portion of ")#link(<tao-1d479541a5598f6d7bfd>)[#text("(1)")]#text(" that does not come from ")#link(<tao-c549779d79e5c8e9c9a6>)[#text("(3)")]#text(". After some standard Fourier-analytic manipulations, matters then boil down to obtaining non-trivial decay of the ")#link("https://en.wikipedia.org/wiki/Characteristic_function_(probability_theory)")[#text("characteristic function")]#text(" of ")#mi("{\\mathbf{Syrac}({\\bf Z}/3^n{\\bf Z})}")#text(", and more precisely in showing that ")#metadata(none) <tao-8c3118fe1fdf357a23b6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\mathbb{E} e^{-2\\pi i \\xi \\mathbf{Syrac}({\\bf Z}/3^n{\\bf Z}) / 3^n} \\ll_A n^{-A}")]]

#text("for any ")#mi("{A > 0}")#text(" and any ")#mi("{\\xi \\in {\\bf Z}/3^n{\\bf Z}}")#text(" that is not divisible by ")#mi("{3}")#text(".")#linebreak()#text(" If the random variable ")#link(<tao-1d479541a5598f6d7bfd>)[#text("(1)")]#text(" was the sum of independent terms, one could express this characteristic function as something like a ")#link("https://www.encyclopediaofmath.org/index.php/Riesz_product")[#text("Riesz product")]#text(", which would be straightforward to estimate well. Unfortunately, the terms in ")#link(<tao-1d479541a5598f6d7bfd>)[#text("(1)")]#text(" are loosely coupled together, and so the characteristic factor does not immediately factor into a Riesz product. However, if one groups adjacent terms in ")#link(<tao-1d479541a5598f6d7bfd>)[#text("(1)")]#text(" together, one can rewrite it (assuming ")#mi("{n}")#text(" is even for sake of discussion) as")

#tao-aligned(keep: true)[


#tao-math("(2^{\\mathbf{a}_2} + 3) 2^{-\\mathbf{b}_1}  & + (2^{\\mathbf{a}_4}+3) 3^2 2^{-\\mathbf{b}_1-\\mathbf{b}_2} + \\dots", block: true)



#tao-math(" & + (2^{\\mathbf{a}_n}+3) 3^{n-2} 2^{-\\mathbf{b}_1-\\dots-\\mathbf{b}_{n/2}} \\text{ mod } 3^n", block: true)
]

#text("where ")#mi("{\\mathbf{b}_j := \\mathbf{a}_{2j-1} + \\mathbf{a}_{2j}}")#text(". The point here is that after conditioning on the ")#mi("{\\mathbf{b}_1,\\dots,\\mathbf{b}_{n/2}}")#text(" to be fixed, the random variables ")#mi("{\\mathbf{a}_2, \\mathbf{a}_4,\\dots,\\mathbf{a}_n}")#text(" remain independent (though the distribution of each ")#mi("{\\mathbf{a}_{2j}}")#text(" depends on the value that we conditioned ")#mi("{\\mathbf{b}_j}")#text(" to), and so the above expression is a ")#emph[#text("conditional")]#text(" sum of independent random variables. This lets one express the characeteristic function of ")#link(<tao-1d479541a5598f6d7bfd>)[#text("(1)")]#text(" as an ")#emph[#text("averaged")]#text(" Riesz product. One can use this to establish the bound ")#link(<tao-8c3118fe1fdf357a23b6>)[#text("(4)")]#text(" as long as one can show that the expression")

#align(center)[#tao-fit-display[#mitex("\\frac{\\xi 3^{2j-2} (2^{-\\mathbf{b}_1-\\dots-\\mathbf{b}_j+1} \\mod 3^n)}{3^n}")]]

#text("is not close to an integer for a moderately large number (")#mi("{\\gg A \\log n}")#text(", to be precise) of indices ")#mi("{j = 1,\\dots,n/2}")#text(". (Actually, for technical reasons we have to also restrict to those ")#mi("{j}")#text(" for which ")#mi("{\\mathbf{b}_j=3}")#text(", but let us ignore this detail here.) To put it another way, if we let ")#mi("{B}")#text(" denote the set of pairs ")#mi("{(j,l)}")#text(" for which")

#align(center)[#tao-fit-display[#mitex("\\frac{\\xi 3^{2j-2} (2^{-l+1} \\mod 3^n)}{3^n} \\in [-\\varepsilon,\\varepsilon] + {\\bf Z},")]]

#text("we have to show that (with overwhelming probability) the random walk")

#align(center)[#tao-fit-display[#mitex("(1,\\mathbf{b}_1), (2, \\mathbf{b}_1 + \\mathbf{b}_2), \\dots, (n/2, \\mathbf{b}_1+\\dots+\\mathbf{b}_{n/2})")]]

#text("(which we view as a two-dimensional ")#link("https://en.wikipedia.org/wiki/Renewal_theory")[#text("renewal process")]#text(") contains at least a few points lying outside of ")#mi("{B}")#text(".")#linebreak()#text(" A little bit of elementary number theory and combinatorics allows one to describe the set ")#mi("{B}")#text(" as the union of “triangles” with a certain non-zero separation between them. If the triangles were all fairly small, then one expects the renewal process to visit at least one point outside of ")#mi("{B}")#text(" after passing through any given such triangle, and it then becomes relatively easy to then show that the renewal process usually has the required number of points outside of ")#mi("{B}")#text(". The most difficult case is when the renewal process passes through a particularly large triangle in ")#mi("{B}")#text(". However, it turns out that large triangles enjoy particularly good separation properties, and in particular afer passing through a large triangle one is likely to only encounter nothing but small triangles for a while. After making these heuristics more precise, one is finally able to get enough points on the renewal process outside of ")#mi("{B}")#text(" that one can finish the proof of ")#link(<tao-8c3118fe1fdf357a23b6>)[#text("(4)")]#text(", and thus Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("2")]#text(".")

#heading(level: 1)[#text("Comments (521)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78a9668bc87019752cb588bedfb132969716da2b1ab8a8011686d2ed1f85a762-708e5329096987355205cc66198457a7ab335f430826992f68908126a8759e5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lech Mazur")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-5/#comment-693230")[#strong[#text("Lech Mazur")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2026")])]

#text("An addendum to my previous comment, since I can’t edit or reply to it before it passes moderation:")

#text("The issue appears specific to the v4/v5 form of Section 6: in v1-v3 the corresponding range carried a C_A^3 log n buffer, with ample margin over the C_A^2-scale deviation cost, and the failure appears to enter with the v4 revision’s sharpening of the buffer to C_A^2 log n (based on a targeted comparison of the arXiv versions, not a full audit).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-5/#comment-693234")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2026")])]

#text("Thanks for this. The simplest fix is to replace the constant \\frac{1}{2} that starts appearing in (6.7) onwards with, say, 0.99, and then the numerical bounds go through.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-5/#comment-693433")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2026")])]

#text("I’m not familiar with renewal theory. Why is it appropriate to use the renewal process for modeling (1, b_1), (2, b_1 + b_2), … , (n/2, b_1 + … + b_{n/2}?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-5/#comment-693439")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2026")])]

#text("I am ")#link("https://claude.ai/share/3f24a5d6-9863-4120-9284-29eea79c2ad1")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78a9668bc87019752cb588bedfb132969716da2b1ab8a8011686d2ed1f85a762-708e5329096987355205cc66198457a7ab335f430826992f68908126a8759e5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lech Mazur")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-5/#comment-693496")[#strong[#text("Lech Mazur")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("For those interested, a formalization (124k lines of Lean) and an AI-generated improvement to natural density with an explicit clock (+50k lines of Lean) are available at proofatlas.ai (it seems links are disabled here).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aadef7bab8f6a229b8438c6dbfe43059655d41a12f4a93b1e64f586389406662-fb8c292a1d13d31d53f2a607289d4b48ba1438ab82090211d4d289fab6b80c02.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jaan.allikvere")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-5/#comment-693645")[#strong[#text("jaan.allikvere")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2026")])]

#text("Regarding Remark 1.16 of the paper (upgrading logarithmic density to natural density): I would like to report a manuscript that carries out the program suggested there. The two probabilistic pillars are upgraded to versions conditioned on the total 2-valuation: a sum-conditioned superpolynomial Fourier decay bound for the Syracuse random variables, and a sum-conditioned fine-scale mixing property of the full random affine map (rather than just the offset), as anticipated in the remark. The passage from the logarithmic to the uniform measure reduces, via an exact combinatorial identity, to a local limit computation along the Kronecker orbit of log_2 3, where an effective irrationality measure from linear forms in logarithms supplies the required quantitative equidistribution.")

#text("The result is quantitative and keeps time: for a fixed target N_0 the exceptional set below x has ratio O((log N_0)^{-1/29} + x^{-1/2000}), and on the density-one set the witnessing iterate occurs within (1+o(1)) ln N / ln(4/3) Syracuse steps, i.e. within 12 ln N Collatz steps, with one clock serving every threshold function simultaneously.")

#text("Timeline, for clarity: the main theorem and the argument were archived on Zenodo on July 13 (version 1); the explicit rate and the universal clock were recorded on July 22 (version 2), derived from the two-sided first-passage concentration already present in version 1 — a “Note added” in the manuscript documents this. This appears related in aim to the proofatlas.ai work mentioned by Lech Mazur above; the present manuscript is an independent write-up.")

#text("Manuscript (not yet refereed), with reference numerics for the three key estimates: doi.org/10.5281/zenodo.21340150 ")#linebreak()#text("AI-assisted, with disclosure in the manuscript.")

#text("Comments and corrections are very welcome.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-5/#comment-694069")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2026")])]

#text("I have the following question regarding the result:for short intervals, one can always find an integer in ")#mi("[x,x+h(x)]")#text(" whose Collatz orbit can be proved to eventually reach 1. If so, what bounds can one prove for")#mi("h(x)")#text("?In particular, is it possible to take")

#mi("h(x) \\ll \\frac{x}{(\\log x)^C}")

#text("for some constant ")#mi("C>0")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-5/#comment-694077")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2026")])]

#text("Apparently, there are now some AI-generated solutions to the natural density version of my result; if they check out, they should be able to give something along the lines of your statement for some ")#mi("h(x) = o(x)")#text(", and possibly even a logarithmic saving as you indicate. However, this would need to be done carefully. (My original argument now has some Lean formalizations, so perhaps this claim could also be formalized as well.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-5/#comment-694148")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2026")])]

#text("v7 page 32 has a formula going off the page.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9e546ee2cd827bb910b9f11c31a46e52998b5f6fd2a195e2e7a1d4a9922d5b3-50b0bcc62c3b258fb97311dfd0d3043bc225ec7208942d429f86a5f4e67fdd13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lechmazur")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-5/#comment-694216")[#strong[#text("lechmazur")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2026")])]

#text("I’d like to share a paper and Lean formalization showing that, for explicit constants c > 0 and X0, at least cX positive integers n < X reach 1 within 10.46 ln(n) ordinary Collatz steps, for every integer X >= X0. Thus the time bound holds on a set of positive lower natural density.")

#text("The proof combines the fine-scale mixing theorem (Proposition 1.14) and its Fourier-renewal machinery with a weighted inverse-orbit construction based on one fixed convergent seed. The density bound is extremely small and the cutoff extremely large.")

#text("The work was developed primarily by AI agents through ProofAtlas.ai, with some high-level guidance from me (which may or may not have helped).")

#text("Paper: ")#link("https://www.proofatlas.ai/papers/positive-density-log-time-collatz/Mazur_Explicit_Positive_Density_Collatz_Convergence_in_Logarithmic_Time_v2.pdf")[#text("https://www.proofatlas.ai/papers/positive-density-log-time-collatz/Mazur_Explicit_Positive_Density_Collatz_Convergence_in_Logarithmic_Time_v2.pdf")]

#text("Lean formalization: ")#link("https://proofatlas.ai/formalizations/positive-density-log-time-collatz/")[#text("https://proofatlas.ai/formalizations/positive-density-log-time-collatz/")]#link("https://proofatlas.ai/formalizations/positive-density-log-time-collatz/")[#text("https://proofatlas.ai/formalizations/positive-density-log-time-collatz/")]

#text("The additional formalization for this result is ~42k lines of Lean, building on the earlier formalizations of almost-boundedness and its natural-density extension.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9e546ee2cd827bb910b9f11c31a46e52998b5f6fd2a195e2e7a1d4a9922d5b3-50b0bcc62c3b258fb97311dfd0d3043bc225ec7208942d429f86a5f4e67fdd13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lech Mazur")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-5/#comment-694222")[#strong[#text("Lech Mazur")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2026")])]

#text("Using AI, I have extended this positive-density theorem: for every positive integer a not divisible by 3, the starting integers whose Collatz orbits reach a have positive lower natural density, without assuming that a reaches 1. As a corollary, if any Collatz counterexample exists, the set of counterexamples has positive lower natural density. So, this means that proving almost all positive integers reach 1 (in the sense of natural density 1) would suffice to prove the full Collatz conjecture. A short paper and formalization should be available later tonight on proofatlas.ai.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5170010f70c29afc35e4e33fa2a14517e816f9b215b890ec6435784900b6660-4b2ec332aeca9225cebfa98f36f767e2e5441d244b50e4e9c609910bdbc6b341.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wulf Rehder")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-633520")[#strong[#text("Wulf Rehder")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2021")])]

#text("Calculating the Total Stopping Time N(T):")

#text("[Note: In my last reply of August 29, above, the final sentence has a typo: “ratio (m+k)^N” should read “ratio (m+k)/N”.]")

#text("My previous comments on the Collatz Conjecture in this thread have shown that the stopping time N=N(S) can be determined by the proportion of divisions by 2 and the constant t, which is related to the Cantor fractal dimension r=log2/log3 or, equivalently, to the Sierpinski fractal dimension s=1/r, by the relationship t=1/(r+1)=s/(s+1)=0.613147…. To wit: If m is the number of multiplications by 3 and m+k the number of divisions by 2 up to the index N=m+m+k, then N=N(S) is the stopping time of this sequence iff at this N the proportion")

#text("(*) (m+k)/N >= t for the first time.")

#text("The starting element c(0) (the “seed”) of the Collatz sequence does not explicitly appear in this formula. This characterization of the stopping time in terms of a fractal dimension has been verified with all available data, for instance ")#link("https://en.wikipedia.org/wiki/Collatz_conjecture#Empirical_data")[#text("https://en.wikipedia.org/wiki/Collatz_conjecture#Empirical_data")]#text(" as well as for the Collatz-relevant sequences A006884 and A006577 in the OEIS.")

#text("In a similar way, the total stopping time N(T), the index at which the Collatz sequence hits down to 1, can be characterized in terms of s, r, and t. Here, however, the seed c(0) figures explicitly. Again we are looking for the excess k of the number of divisions by 2 over the number m of multiplications by 3, such that this excess pushes the seed c(0) down to 1:")

#text("(**) c(0) 3^m/2^(m+k) N(S) and")

#text("(***) [k+m-log(c(0))/log2]/[N-log(c(0))/log2] >= t,")

#text("with t being the threshold defined above.")

#text("Comparing (***) to (*) shows how the seed c(0) enters the calculation of the total stopping time explicitly. [N(T)>N(S) is added because for some small N=1,2,3, … = C, or (k+m)-sm >= D,")

#text("with C>0 and D>0 depending on the seed c(0): The Collatz sequence with seed c(0) reaches 1 after m+m+k steps, iff the relationship between the m+k divisions by 2 and the m multiplications by 3 are given by the fractal dimensions r and s in (****).")

#text("None of this proves the Collatz Conjecture, of course. However, the somewhat elusive conjecture “The sequence eventually reaches 1” can be more concretely expressed in terms of the inequalities (***) or (****). A counter-example to the Collatz Conjecture would require a seed c(0) such that, for instance, r(k+m)-m < C for all N=m+m+k..")

#text("P.S.: A reader who intends to “Rate Down” this or any other post – which seems to happen almost automatically in this thread, quite drastically even for contributions by Dr. Tao – is politely requested to give a reason in a reply, or better even, a counter-example. I’d be happy to explain further. Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5170010f70c29afc35e4e33fa2a14517e816f9b215b890ec6435784900b6660-4b2ec332aeca9225cebfa98f36f767e2e5441d244b50e4e9c609910bdbc6b341.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wulf Rehder")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-633555")[#strong[#text("Wulf Rehder")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2021")])]

#text("Calculating the Total Stopping Time N(T)")

#text("For mysterious reasons a part of the text was excised in the copy-paste process of the above posting: Instead of the text from “Comparing (***) to (*) …” and “… r and s in (****)” the correct text should read:")

#text("“Comparing (***) to (*) shows how the seed c(0) enters the calculation of the total stopping time explicitly. [N(T)>N(S) is added because for some small N=1,2,3, … = C, or (k+m)-sm >= D,")

#text("with C>0 and D>0 depending on the seed c(0): The Collatz sequence with seed c(0) reaches 1 after m+m+k steps, iff the relationship between the m+k divisions by 2 and the m multiplications by 3 are given by the fractal dimensions r and s in (****).”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5170010f70c29afc35e4e33fa2a14517e816f9b215b890ec6435784900b6660-4b2ec332aeca9225cebfa98f36f767e2e5441d244b50e4e9c609910bdbc6b341.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wulf Rehder")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-633556")[#strong[#text("Wulf Rehder")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2021")])]

#text("Calculating the Total Stopping Time N(T)")

#text("I found the mysterious reason: There was a “smaller than” symbol in the text, which is fatal in certain versions of wordpress. Now then: Instead of the text from “Comparing (***) to (*) …” and “… r and s in (****)” the correct text should read:")

#text("“Comparing (***) to (*) shows how the seed c(0) enters the calculation of the total stopping time explicitly. [N(T)>N(S) is added because for some small N=1,2,3, … smaller than N(S) the ratio (***) may be large or even negative.] This too has been corroborated with a wide variety of interesting seeds c(0)=27, 97, 871, 6 171, 77 031, 837 799, … and OEIS sequences.")

#text("Defining the constants A=log(c(0))/log2, B=tA, (A-B)/t=C, D=C/r makes (***) more compact:")

#text("(****) r(k+m)-m >= C, or (k+m)-sm >= D,")

#text("with C>0 and D>0 depending on the seed c(0): The Collatz sequence with seed c(0) reaches 1 after m+m+k steps, iff the relationship between the m+k divisions by 2 and the m multiplications by 3 are given by the fractal dimensions r and s in (****).”")

#text("Sorry about this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc41579f48dd8e4741cf3e4d17899701c01a1438e6af7e9c2a9ab80691995e6b-b7cdcb7fef7c8978fb8225bb5d806913727572306b9f77048da3b061781ba20f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of De Wi")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-634391")[#strong[#text("De Wi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2021")])]

#text("Wulf Rehder, I am writing some code on Collatz Sequences on Tool Control Language, TCL. Thanks for your previous (TAO) posts on subject. Is there a “formula” or psuedocode steps to estimate the number of elements or steps of a Collatz Sequence before computing the Collatz Sequence by the computer. The complement to your Rehder_limt is 0.3868528072345415 or 38.6 percent. Might useful in some situations. Thank you.")

#text("Tool Control Language = TCL.")#linebreak()#text(" —————————————————-")#linebreak()#text(" proc collatz_sequences_Krasikov_Lagarias_limit {limit} {")#linebreak()#text(" if { $limit <= 1 } {")#linebreak()#text(" return -code error \"The limit must be larger than 1\"")#linebreak()#text(" }")#linebreak()#text(" expr {$limit** 0.84}")#linebreak()#text(" }")#linebreak()#text(" # Krasikov and Lagarias limit 4 3.204")#linebreak()#text(" # Krasikov and Lagarias limit 5 3.864")#linebreak()#text(" # Krasikov and Lagarias limit 10 6.918")#linebreak()#text(" # Krasikov and Lagarias limit 20 12.384")#linebreak()#text(" # Krasikov and Lagarias limit 50 26.738")#linebreak()#text(" set Rehder_limit_collatz_sequences [ return [ expr { (log(3)/log(2))/(log(3)/log(2)+1.)} ] ]")#linebreak()#text(" # returns 0.61314719276545848 or or 61.3 percent")#linebreak()#text(" set Rehder_limit_complement [ return [ expr { 1.- (log(3)/log(2))/(log(3)/log(2)+1.)} ] ]")#linebreak()#text(" # returns 0.3868528072345415 or 38.6 percent")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-634392")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2021")])]

#text("There is the special case of 4n+1 being always a sequence with one more step than sequence n – really the same sequence with one earlier step. Now also remember, that the stopping time of every number in a sequence is known from the first number in the sequence. Every number can only be a member of one sequence.")

#text("Besides that there are nonrecursive functions – that is, ones that eliminate division or exponentiation, so they have linear running time, such as:")

#mi("f(n) = \\begin{cases} ((n+1) \\frac {3}{2})-1 & \\text{if } n+1 \\equiv 0 \\text{ (mod } 4) \\\\ ( (n-1) \\frac {3}{4})+1 & \\text{if } n-1 \\equiv 0 \\text{ (mod } 8) \\\\ (n-1)\\frac {1}{4} & \\text{otherwise } \\end{cases}")

#text("One may also consider the possibility that sequences are actually superfluous, and the conjecture concerns the finitude of the input and output of a table with three congruences and three operations. ")#link("https://youtu.be/q1F50FTpg8A")[#text("https://youtu.be/q1F50FTpg8A")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8e16b162435fa0027ef88063c22592aebfa720b632e2a03c76692374cae22fb-c01dbda0fa6069f8c8f14f9331598cb02c06d7e87ee1677d3edcb0be66a3675e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Croft")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-673413")[#strong[#text("Andrew Croft")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2023")])]

#text("I have also produced the function michaelmross describes, working with the Syracuse sequence, as every step in a single iteration is tidy, which I prefer to dividing by 2 to a variable power, but I fail to see it contributing to the global question of everything going to 1.")#linebreak()#text(" Each step in the sequence depends on the behaviour of n mod 8, and when you iterate this function, it’s quite tidy provided n mod 8 is 3 or 7, but as soon as it switches to n mod 8 being 1 or 5, and then switches back, then the number of terms involves blows up … which is why the global problem is so hard.")#linebreak()#text(" An equivalent function can be produced for the 3n-1 problem with its 3 cycles, but this function doesn’t explain the 3 cycles vs the 1 for 3n+1, well not to me anyway.")#linebreak()#text(" Back to the drawing board and trying in my amateur way to understand Prof Tao’s papers.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of De Wi")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-634490")[#strong[#text("De Wi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2021")])]

#text("Subject: Possible Uses for Collatz Sequences Conjecture?")#linebreak()#text(" #### A novice programmer (me) has received offsite query from “senior programmer in charge” ..>>> .. ” While I am fascinated by the Collatz problem, I do not see much practical use for it. In what kind of computer applications would you use this?”")#linebreak()#text(" —————————")#linebreak()#text(" #### Answer, As understood here, the Collatz Sequences Conjecture is called pure mathematics. Paul Erdős said about the Collatz conjecture: “Mathematics may not be ready for such problems.” The Collatz Sequences Conjecture is at the forefront of human mathematics. From what an outsider can tell, the Collatz Sequences are being generated with supercomputers and distributed computing algoritms on the numeric issues. Apparently, the Collatz Sequences are as valid a test for computing machines, parallel algoritms, and distributed computing algoritms as the 1) search for pi , 2) search for highest prime number, 3) Twin Prime Conjecture, and 4) factoring numbers . The novice has written TCL hacks on all five subjects. In 2020, starting values up to 2**268 approximating 2.95*1020 have been checked in the Collatz conjecture. I suppose the question is valid, if one is advocating spending time, salaried employees, and resources on pure mathematics and the Collatz Sequences Conjecture to decision making nodes. .I am a retired engineer. Maybe the pure mathematicians among us may offer some more practical uses for the Collatz Sequences Conjecture?")

#text("Samples from Tool Control Language = TCL.")#linebreak()#text(" —————————————————-")#linebreak()#text(" proc collatz_sequences_Krasikov_Lagarias_limit {limit} {")#linebreak()#text(" if { $limit <= 1 } {")#linebreak()#text(" return -code error \"The limit must be larger than 1\"")#linebreak()#text(" }")#linebreak()#text(" expr {$limit** 0.84}")#linebreak()#text(" }")#linebreak()#text(" # Krasikov and Lagarias limit 4 3.204")#linebreak()#text(" # Krasikov and Lagarias limit 5 3.864")#linebreak()#text(" # Krasikov and Lagarias limit 10 6.918")#linebreak()#text(" # Krasikov and Lagarias limit 20 12.384")#linebreak()#text(" # Krasikov and Lagarias limit 50 26.738")#linebreak()#text(" set Rehder_limit_collatz_sequences [ return [ expr { (log(3)/log(2))/(log(3)/log(2)+1.)} ] ]")#linebreak()#text(" # returns 0.61314719276545848 or or 61.3 percent")#linebreak()#text(" set Rehder_limit_complement [ return [ expr { 1.- (log(3)/log(2))/(log(3)/log(2)+1.)} ] ]")#linebreak()#text(" # returns 0.3868528072345415 or 38.6 percent")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d8f0b082bef7cfb86a147a944f462a8d497045d7c05eaf00d47d58743f13fa0-30a9d0458d72e0e26ce2f765418ea9399b9b9f694a6a9c5c38ece3d73781e70e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of E F")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-636195")[#strong[#text("E F")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2021")])]

#text("Dear All,")

#text("Today I posted a document on Reddit regarding the Collatz conjecture (Family Tree Problem). I have tried to approach the Collatz conjecture in a different way with the idea of discovering new patterns. I have a strongly believe that the mathematical functions f(n) = 3n – 1, f(n) = 2n – 1, f(n) = 3n + 1 and f(n) = 4n + 1 are closely related to the Family Tree Anomalies (Loops related to f(n) = 3n + 1) especially for n = 0, n = -2, n = -6 and n = -8. Please take a look at it if you have any spare time these days.")

#text("I tried to copy some details of the document for you, but maybe the readability is not best.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://www.reddit.com/r/Collatz/comments/qb7d46/collatz_conjecture_family_tree_problem/")[#text("Collatz conjecture (Family Tree Problem).")]#linebreak()#text(" by")#link("https://www.reddit.com/user/F_Numbers/")[#text("u/F_Numbers")]#text(" in")#link("https://www.reddit.com/r/Collatz/")[#text("Collatz")]
]

#text("Family Tree “Genealogy” Problem (Reverse Collatz Conjecture)")

#text("By EF")

#text("October 15, 2021")

#text("*THE MATHEMATICAL FUNCTIONS RELATED TO THE FAMILY TREE PROBLEM ARE:")

#text("f(n) = 3n + 1; to generate Parent of n")#linebreak()#text(" f(n) = n + [(n – 1) / 3]; to generate Child (firstborn) of n")#linebreak()#text(" f(n) = n – [(n + 1) / 3]; to generate Child (firstborn) of n")#linebreak()#text(" f(n) = 2n; to generate Child (firstborn) of n (n divisible by 3 doesn’t have any odd children)")#linebreak()#text(" f(n) = 4n + 1; to generate Sibling of n")#linebreak()#text(" f(m,n) = {[(4^(m-1)).(3n + 1)] – 1} / 3; to generate Birth order of e.g. Siblings or Children of n, where m = Birth order")

#text("*EXAMPLE PERSON N = 11")

#text("9 Grandchild ; f(9) = 2n = 18 (n divisible by 3 doesn’t have any odd")#linebreak()#text(" children)")#linebreak()#text(" x3 + 1 =")#linebreak()#text(" 28 f(9) = 3n + 1")#linebreak()#text(" /2 =")#linebreak()#text(" 14 f(9) = (3n + 1) / 2")#linebreak()#text(" /2 =")#linebreak()#text(" 7 Child (firstborn) ; f(9) = ((3n + 1) / 2) / 2 ; f(11) = n – [(n + 1) / 3] = 7")#linebreak()#text(" (Firstborn of 11)")#linebreak()#text(" x3 + 1 =")#linebreak()#text(" 22 f(7) = 3n + 1")#linebreak()#text(" /2 =")#linebreak()#text(" 11 Person ; f(7) = (3n + 1) / 2 ; f(17) = n – [(n + 1) / 3] = 11 (Firstborn of 17)")#linebreak()#text(" x3 + 1 =")#linebreak()#text(" 34 f(11) = 3n + 1")#linebreak()#text(" /2 =")#linebreak()#text(" 17 Parent ; f(11) = (3n + 1) / 2 ; f(13) = n + [(n – 1) / 3] = 17 (Firstborn of 13)")#linebreak()#text(" x3 + 1 =")#linebreak()#text(" 52 f(17) = 3n + 1")#linebreak()#text(" /2 =")#linebreak()#text(" 26 f(17) = (3n + 1) / 2")#linebreak()#text(" /2 =")#linebreak()#text(" 13 Grandparent ; f(17) = ((3n + 1) / 2) / 2 ;")#linebreak()#text(" f(2,5) = {[(4^(m-1)).(3n + 1)] – 1} / 3 = 13 (Second Child of 5)")#linebreak()#text(" x3 + 1 =")#linebreak()#text(" 40 f(13) = 3n + 1")#linebreak()#text(" /2 =")#linebreak()#text(" 20 f(13) = (3n + 1) / 2")#linebreak()#text(" /2 =")#linebreak()#text(" 10 f(13) = ((3n + 1) / 2) / 2")#linebreak()#text(" /2 =")#linebreak()#text(" 5 Great-Grandparent ; f(13) = (((3n + 1) / 2) / 2) / 2 ;")#linebreak()#text(" f(2,1) = {[(4^(m-1)).(3n + 1)] – 1} / 3 = 5 (Second Child of 1)")#linebreak()#text(" x3 + 1 =")#linebreak()#text(" 16 f(5) = 3n + 1")#linebreak()#text(" /2 =")#linebreak()#text(" 8 f(5) = (3n + 1) / 2")#linebreak()#text(" /2 =")#linebreak()#text(" 4 f(5) = ((3n + 1) / 2) / 2")#linebreak()#text(" /2 =")#linebreak()#text(" 2 f(5) = (((3n + 1) / 2) / 2) / 2")#linebreak()#text(" /2 =")#linebreak()#text(" 1 Great-Great-Grandparent and Sibling of Great-Grandparent are the")#linebreak()#text(" same person (Parent and Firstborn Child are the same person)")#linebreak()#text(" f(5) = ((((3n + 1) / 2) / 2) / 2) / 2")#linebreak()#text(" x3 + 1 =")#linebreak()#text(" 4 f(1) = 3n + 1")#linebreak()#text(" /2 =")#linebreak()#text(" 2 f(1) = (3n + 1) / 2")#linebreak()#text(" /2 =")#linebreak()#text(" 1 Progenitor (Founder of the Collatz family); 1 is Parent of Firstborn Child")#linebreak()#text(" 1 and Grandparent of Firstborn Grandchild 1 (Parent and Firstborn")#linebreak()#text(" Child and Firstborn Grandchild are the same person namely 1)")#linebreak()#text(" f(1) = ((3n + 1) / 2) / 2")

#text("*EXAMPLE PERSON N = 11")

#text("f(m,n) = {[(4^(m-1)).(3n + 1)] – 1} / 3 ; Birth order of siblings or children of n ; where m = Birth Order")#linebreak()#text(" Siblings of 9 (Grandsons and Granddaughters of 11)")#linebreak()#text(" 37 (second sibling); 149 (third sibling); 597 (fourth sibling); 2389 (fifth sibling) f(9) = 4n + 1")#linebreak()#text(" (m,n) = (1,9) = 9; (m,n) = (2,9) = 37; (m,n) = (3,9) = 149; (m,n) = (4,9) = 597; (m,n) = (5,9) = 2389")

#text("Siblings of 7 (Sons and Daughters of 11)")#linebreak()#text(" 29 (second sibling); 117 (third sibling); 469 (fourth sibling); 1877 (fifth sibling) f(7) = 4n + 1")#linebreak()#text(" (m,n) = (1,7) = 7; (m,n) = (2,7) = 29; (m,n) = (3,7) = 117; (m,n) = (4,7) = 469; (m,n) = (5,7) = 1877")

#text("Siblings of 11 (Brothers and Sisters of 11)")#linebreak()#text(" 45 (second sibling); 181 (third sibling); 725 (fourth sibling); 2901 (fifth sibling) f(11) = 4n + 1")#linebreak()#text(" (m,n) = (1,11)= 11; (m,n) = (2,11) = 45; (m,n) = (3,11) = 181; (m,n) = (4,11) = 725; (m,n) = (5,11) = 2901")

#text("Siblings of 17 (Aunts and Uncles of 11)")#linebreak()#text(" 69 (second sibling); 277 (third sibling); 1109 (fourth sibling); 4437 (fifth sibling) f(17) = 4n + 1")#linebreak()#text(" (m,n) = (1,17) = 17; (m,n) = (2,17) = 69; (m,n) = (3,17) = 277; (m,n) = (4,17) = 1109; (m,n) = (5,17) = 4437")

#text("Siblings of 13 (Grandaunts and Granduncles of 11)")#linebreak()#text(" 3 (first sibling); 53 (third sibling); 213 (fourth sibling); 853 (fifth sibling) f(13) = 4n + 1")#linebreak()#text(" (m,n) = (1,13) = 13; (m,n) = (2,13) = 53; (m,n) = (3,13) = 213; (m,n) = (4,13) = 853; (m,n) = (5,13) = 3413")

#text("(m,n) = (1,3) = 3; (m,n) = (2,3) = 13; (m,n) = (3,3) = 53; (m,n) = (4,3) = 213; (m,n) = (5,3) = 853")

#text("Siblings of 5 (Great-Grandaunts and Great-Granduncles of 11)")#linebreak()#text(" 1 (first sibling); 21 (third sibling); 85 (fourth sibling); 341 (fifth sibling) f(5) = 4n + 1")#linebreak()#text(" (m,n) = (1,5) = 5; (m,n) = (2,5) = 21; (m,n) = (3,5) = 85; (m,n) = (4,5) = 341; (m,n) = (5,5) = 1365")

#text("(m,n) = (1,1) = 1; (m,n) = (2,1) = 5; (m,n) = (3,1) = 21; (m,n) = (4,1) = 85; (m,n) = (5,1) = 341")

#text("Siblings of 1")#linebreak()#text(" 5 (second sibling); 21 (third sibling); 85 (fourth sibling); 341 (fifth sibling)")#linebreak()#text(" (m,n) = (1,1) = 1; (m,n) = (2,1) = 5; (m,n) = (3,1) = 21; (m,n) = (4,1) = 85; (m,n) = (5,1) = 341")

#text("The loops regarding f(n) = 3n + 1 can be explained as anomalies related to the Family Tree.")

#text("*LOOPS OF F(N) = 3N + 1 (ANOMALIES IN FAMILY TREES)")#linebreak()#text(" f(n) = 3n + 1 f(n) = n + [(n – 1) / 3] f(n) = n – [(n + 1) / 3] f(n) = 4n + 1")#linebreak()#text(" Parent of n Child (firstborn) of n Child (firstborn) of n Siblings of n")

#text("n = 1")#linebreak()#text(" 4 1 5")#linebreak()#text(" / 2 21")#linebreak()#text(" 2 85")#linebreak()#text(" / 2 341")#linebreak()#text(" 1")

#text("1 is Parent of Firstborn Child 1 and Grandparent of Firstborn Grandchild 1 (Parent and Firstborn Child and Firstborn Grandchild are the same person namely 1)")

#text("n = -1")#linebreak()#text(" -2 -1 -3")#linebreak()#text(" / 2 -11")#linebreak()#text(" -1 -43")

#text("-1 is Parent of Firstborn Child -1 and Grandparent of Firstborn Grandchild -1")#linebreak()#text(" (Parent and Firstborn Child and Firstborn Grandchild are the same person namely -1)")

#text("n = -5")#linebreak()#text(" -14 -7 -19")#linebreak()#text(" / 2 -75")#linebreak()#text(" -7 -299")

#text("-7 is Parent of Firstborn Child -5 and Grandparent of Firstborn Grandchild -7 (Grandparent and Firstborn Grandchild are the same person namely -7)")

#text("n = -7")#linebreak()#text(" -20 -5 -27")#linebreak()#text(" / 2 -107")#linebreak()#text(" -10 -427")#linebreak()#text(" / 2")#linebreak()#text(" -5")

#text("-5 is Parent of Firstborn Child -7 and Grandparent of Firstborn Grandchild -5 (Grandparent and Firstborn Grandchild are the same person namely -5)")

#text("n = -23")#linebreak()#text(" -68 -31 (-23 is Firstborn and -91 is Second Child of -17) /2")#linebreak()#text(" -34 -91")#linebreak()#text(" / 2 -363")#linebreak()#text(" -17 -1451")

#text("n = -17")#linebreak()#text(" -50 -23 (-17 is Parent of -23) -67")#linebreak()#text(" / 2 -267")#linebreak()#text(" -25 -1067")

#text("n = -25")#linebreak()#text(" -74 (-25 is Parent of -17) -17 -99")#linebreak()#text(" / 2 -395")#linebreak()#text(" -37 -1579")

#text("n = -37")#linebreak()#text(" -110 (-37 is Grandparent of -17) -25 -147")#linebreak()#text(" / 2 -587")#linebreak()#text(" -55 -2347")

#text("n = -55")#linebreak()#text(" -164 -37 (-55 is Great-Grandparent of -17) -219")#linebreak()#text(" / 2 -875")#linebreak()#text(" -82 -3499")#linebreak()#text(" /2")#linebreak()#text(" -41")

#text("n = -41")#linebreak()#text(" -122 -55 (-41 is Great-Great-Grandparent of -17)")#linebreak()#text(" / 2 -163")#linebreak()#text(" -61 -651")#linebreak()#text(" -2603")

#text("n = -61")#linebreak()#text(" -182")#linebreak()#text(" / 2")#linebreak()#text(" -91")

#text("-61 is Great-Great-Great-Grandparent of -17 and Great-Great-Great-Great-Grandparent of -91")

#text("-91 is Great-Great-Great-Great-Grandparent of -17 and Great-Great-Great-Great-Great-Grandparent of -91")#linebreak()#text(" -91 is Second Child of -17 and Great-Great-Great-Great-Grandchild of -61")#linebreak()#text(" (‘Great-Great-Great-Great-Great-Grandchild’ and ‘Great-Great-Great-Great-Great-Grandparent’ are the same person namely -91)")

#text("n = -91")#linebreak()#text(" -272")#linebreak()#text(" / 2")#linebreak()#text(" -136")#linebreak()#text(" / 2")#linebreak()#text(" -68")#linebreak()#text(" / 2")#linebreak()#text(" -34")#linebreak()#text(" / 2")#linebreak()#text(" -17")

#text("*THE FUNCTIONS F(N) = 3N – 1, F(N) = 2N – 1, F(N) = 3N + 1 AND F(N) = 4N + 1 ARE CLOSELY RELATED TO THE FAMILY TREE ANOMALIES (LOOPS RELATED TO F(N) = 3N + 1) ESPECIALLY FOR N = 0, N = -2, N = -6 AND N = -8.")

#text("The difference of P and C is n The difference of C and P is n")#linebreak()#text(" (3n -1) – (2n -1) = n (4n + 1) – (3n + 1) = n")

#text("Parent Child Parent Child")

#text("f(n) = 3n – 1 f(n) = 2n – 1 n f(n) = 3n + 1 f(n) = 4n + 1")

#text("-106 -71 -35 -104 -139")#linebreak()#text(" -103 -69 -34 -101 -135")#linebreak()#text(" -100 -67 -33 -98 -131")#linebreak()#text(" -97 -65 -32 -95 -127")#linebreak()#text(" -94 -63 -31 -92 -123")#linebreak()#text(" -91 -61 -30 -89 -119")#linebreak()#text(" -88 -59 -29 -86 -115")#linebreak()#text(" -85 -57 -28 -83 -111")#linebreak()#text(" -82 -55 -27 -80 -107")#linebreak()#text(" -79 -53 -26 -77 -103")#linebreak()#text(" -76 -51 -25 -74 -99")#linebreak()#text(" -73 -49 -24 -71 -95")#linebreak()#text(" -70 -47 -23 -68 -91")#linebreak()#text(" -67 -45 -22 -65 -87")#linebreak()#text(" -64 -43 -21 -62 -83")#linebreak()#text(" -61 -41 -20 -59 -79")#linebreak()#text(" -58 -39 -19 -56 -75")#linebreak()#text(" -55 -37 -18 -53 -71")#linebreak()#text(" -52 -35 -17 -50 -67")#linebreak()#text(" -49 -33 -16 -47 -63")#linebreak()#text(" -46 -31 -15 -44 -59")#linebreak()#text(" -43 -29 -14 -41 -55")#linebreak()#text(" -40 -27 -13 -38 -51")#linebreak()#text(" -37 -25 -12 -35 -47")#linebreak()#text(" -34 -23 -11 -32 -43")#linebreak()#text(" -31 -21 -10 -29 -39")#linebreak()#text(" -28 -19 -9 -26 -35")#linebreak()#text(" -25 -17 -8 -23 -31")#linebreak()#text(" -22 -15 -7 -20 -27")#linebreak()#text(" -19 -13 -6 -17 -23")#linebreak()#text(" -16 -11 -5 -14 -19")#linebreak()#text(" -13 -9 -4 -11 -15")#linebreak()#text(" -10 -7 -3 -8 -11")#linebreak()#text(" -7 -5 -2 -5 -7")#linebreak()#text(" -4 -3 -1 -2 -3")#linebreak()#text(" -1 -1 0 1 1")#linebreak()#text(" 2 1 1 4 5")#linebreak()#text(" 5 3 2 7 9")#linebreak()#text(" 8 5 3 10 13")#linebreak()#text(" 11 7 4 13 17")#linebreak()#text(" 14 9 5 16 21")#linebreak()#text(" 17 11 6 19 25")#linebreak()#text(" 20 13 7 22 29")#linebreak()#text(" 23 15 8 25 33")#linebreak()#text(" 26 17 9 28 37")#linebreak()#text(" 29 19 10 31 41")#linebreak()#text(" 32 21 11 34 45")#linebreak()#text(" 35 23 12 37 49")#linebreak()#text(" 38 25 13 40 53")#linebreak()#text(" 41 27 14 43 57")#linebreak()#text(" 44 29 15 46 61")#linebreak()#text(" 47 31 16 49 65")#linebreak()#text(" 50 33 17 52 69")#linebreak()#text(" 53 35 18 55 73")#linebreak()#text(" 56 37 19 58 77")#linebreak()#text(" 59 39 20 61 81")#linebreak()#text(" 62 41 21 64 85")#linebreak()#text(" 65 43 22 67 89")#linebreak()#text(" 68 45 23 70 93")#linebreak()#text(" 71 47 24 73 97")#linebreak()#text(" 74 49 25 76 101")

#text("Intersection Point f(n) = 3n + 1 and f(n) = 4n + 1 (0 ; 1)")#linebreak()#text(" Intersection Point f(n) = 2n – 1 and f(n) = 3n + 1 (-2 ; -5)")#linebreak()#text(" Intersection Point f(n) = 2n – 1 and f(n) = 3n – 1 (0 ; -1)")#linebreak()#text(" Intersection Point f(n) = 3n – 1 and f(n) = 2n (1 ; 2)")#linebreak()#text(" Intersection Point f(n) = 3n + 1 and f(n) = 2n (-1 ; -2)")#linebreak()#text(" Intersection Point f(n) = 2n – 1 and f(n) = n + [(n – 1) / 3] (1 ; 1)")#linebreak()#text(" Intersection Point f(n) = 2n – 1 and f(n) = 4n + 1 (-1 ; -3)")#linebreak()#text(" Intersection Point f(n) = 2n – 1 and f(n) = n – [(n + 1) / 3] (0,5 ; 0)")#linebreak()#text(" Intersection Point f(n) = 4n + 1 and f(n) = 2n and f(n) = n + [(n – 1) / 3]")#linebreak()#text(" (-0,5 ; -1)")#linebreak()#text(" Intersection Point f(n) = n + [(n – 1) / 3] and f(n) = n – [(n + 1) / 3] (0 ; -1/3)")#linebreak()#text(" Intersection Point f(n) = 3n – 1 and f(n) = 4n + 1 (-2 ; -7)")#linebreak()#text(" Intersection Point f(n) = 3n – 1 and f(n) = n + [(n – 1) / 3] (2/5 ; 1/5)")

#text("N = 4")

#text("f(4) = 3n + 1 = 13 f(13) = 3n + 1 = 40 / 2 = 20 / 2 = 10 / 2 = 5")#linebreak()#text(" (5 is parent of 13)")#linebreak()#text(" f(4) = 4n + 1 = 17 f(17) = 3n + 1 = 52 / 2 = 26 / 2 = 13")#linebreak()#text(" (13 is parent of 17)")#linebreak()#text(" f(4) = 2n – 1 = 7 f(7) = 3n + 1 = 22 / 2 = 11 (11 is parent of 7)")#linebreak()#text(" f(4) = 3n – 1 = 11 f(11) = 3n + 1 = 34 / 2 = 17 (17 is parent of 11)")

#text("7 x 3 + 1 = 22 / 2 = 11 x 3 + 1 = 34 / 2 = 17 x 3 + 1 = 52 / 2 = 26 / 2 = 13 x 3 + 1 = 40 / 2 = 20 / 2 = 10 / 2 = 5")

#text("13 is Great-Grandparent of 7")#linebreak()#text(" 17 is Grandparent of 7")#linebreak()#text(" 11 is Parent of 7")

#text("N = -8")

#text("f(-8) = 4n + 1 = -31 f(-31) = 3n + 1 = -92 / 2 = -46 / 2 = -23")#linebreak()#text(" -23 is parent of -31 (-31 is Grandchild of -17)")#linebreak()#text(" f(-8) = 3n + 1 = -23 f(-23) = 3n + 1 = -68 / 2 = -34 / 2 = -17")#linebreak()#text(" -17 is parent of -23 (-23 is child of -17)")#linebreak()#text(" f(-8) = 2n – 1 = -17 f(-17) = 3n + 1 = -50 / 2 = -25")#linebreak()#text(" -25 is Parent of -17 (-25 is parent of -17)")#linebreak()#text(" f(-8) = 3n – 1 = -25 f(-25) = 3n + 1 = -74 / 2 = -37")#linebreak()#text(" -37 is Parent of -25 (-37 is Grandparent of -17)")

#text("-31 x 3 + 1 = -92 / 2 = -46 / 2 = -23 x 3 + 1 = -68 / 2 = -34 / 2 = -17 x 3 + 1 = -50 / 2 = -25 x 3 + 1 = -74 / 2 = -37")

#text("N = -6 N = -8")

#text("f(-6) = 4n + 1 = -23 f(-8) = 3n + 1 = -23")

#text("-23 is Child of -17 -23 is Child of -17")

#text("f(-6) = 3n + 1 = -17 f(-8) = 2n – 1 = -17")

#text("(3n -1) – (2n -1) = 0 and n = 0 (4n + 1) – (3n + 1) = 0 and n = 0")#linebreak()#text(" -1 – -1 = 0 1 – 1 = 0")#linebreak()#text(" n = -1 n = 1")#linebreak()#text(" -2 4")#linebreak()#text(" -1 2")#linebreak()#text(" -2 1")#linebreak()#text(" -1 4")#linebreak()#text(" 2")#linebreak()#text(" 1")

#text("(3n -1) – (2n -1) = -2 and n = -2 (4n + 1) – (3n + 1) = -2 and n = -2")#linebreak()#text(" -7 – -5 = -2 -7 – -5 = -2")#linebreak()#text(" n = -5 n = -7")#linebreak()#text(" -14 -20")#linebreak()#text(" -7 -10")#linebreak()#text(" -20 -5")#linebreak()#text(" -10 -14")#linebreak()#text(" -5 -7")#linebreak()#text(" -14 -20")#linebreak()#text(" -7 -10")#linebreak()#text(" -20 -5")#linebreak()#text(" -10 -14")#linebreak()#text(" -5 -7")

#text("(3n -1) – (2n -1) = -8 (4n + 1) – (3n + 1) = -8 (4n + 1) – (3n + 1) = -6")#linebreak()#text(" and n = -8 and n = -8 and n = -6")#linebreak()#text(" -25 – -17 = -8 -31 – -23 = -8 -23 – -17 = -6")#linebreak()#text(" n = -31 n = -31 n = -31")#linebreak()#text(" -92 -92 -92")#linebreak()#text(" -46 -46 -46")#linebreak()#text(" -23 -23 -23")#linebreak()#text(" -68 -68 -68")#linebreak()#text(" -34 -34 -34")#linebreak()#text(" -17 -17 -17")#linebreak()#text(" -50 -50 -50")#linebreak()#text(" -25 -25 -25")#linebreak()#text(" -74 -74 -74")#linebreak()#text(" -37 -37 -37")#linebreak()#text(" -110 -110 -110")#linebreak()#text(" -55 -55 -55")#linebreak()#text(" -164 -164 -164")#linebreak()#text(" -82 -82 -82")#linebreak()#text(" -41 -41 -41")#linebreak()#text(" -122 -122 -122")#linebreak()#text(" -61 -61 -61")#linebreak()#text(" -182 -182 -182")#linebreak()#text(" -91 -91 -91")#linebreak()#text(" -272 -272 -272")#linebreak()#text(" -136 -136 -136")#linebreak()#text(" -68 -68 -68")#linebreak()#text(" -34 -34 -34")#linebreak()#text(" -17 -17 -17")

#text("MISCELLANEOUS:")

#text("*f(-0,5) = 3 x -0,5 + 1 = -0,5 (shortest loop).")#linebreak()#text(" *1 is the only positive integer that fulfill three different roles namely Parent, Firstborn Child and Firstborn Grandchild as well and thus ends in a vicious circle (1-4-2-1 loop).")#linebreak()#text(" *If it can be proven that the existing loops mentioned above (1 ; 1), (-1 ; -1), (-5 ; -7, -7 ; -5) and (-23 ; -17) are the only 4 anomalies related to the Family Tree Problem, f(n) = 3n + 1, then the Collatz Conjecture is true.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-636224")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2021")])]

#text("Any (valid) proof of the Collatz conjecture must use new(!) methods.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/116b416090ddcfa76b7f4eb676e450288f349774578e2f321c61a8fc7d94a646-631fa1cbbebc0ffb10490856128543845ea26a78845ebb46dd88f0aaa4050b87.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gaurav Krishna")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-636285")[#strong[#text("Gaurav Krishna")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2021")])]

#text("Here is the proof for Collatz Conjecture")#linebreak()#text(" ")#link("https://vixra.org/abs/2110.0119")[#text("https://vixra.org/abs/2110.0119")]#linebreak()#text(" #Collatz #3n+1")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-637603")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2021")])]

#text("can I get a good email contact for someone who has studied this conjecture , I think I might have an idea.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95703cb64738bf251f2138af0140e5c1a76ffe994b4771c93e89e05d290a9ef0-9b50b3852f96816721fe32bbc75b1dbc46ba8ad8d4a9f99141405a88bd6bf885.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sacirisi")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-637856")[#strong[#text("sacirisi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2021")])]

#text("With the Collatz algorithm it is not possible to process all natural numbers because we do not know: quantities and values ​​of even and odd numbers and all their factors. From Tartaglia’s triangle we can detect odd numbers which are the sum of the results of the infinite powers of 2 which have an even index and which are also equal to the previous odd * 4 + 1. These are all the odd numbers that * 3 + 1 generate an even number that is the result of a base power 2 and even index 2 ^ (2 * n≥1) and that, the nth half, ends at 1 because ½ of 2 ^ 1 = 2 ^ 0 = 1. ")#link("https://www.facebook.com/groups/5349868060/my_posted_content")[#text("https://www.facebook.com/groups/5349868060/my_posted_content")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-638806")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2021")])]

#text("Collatz value-dropping formulas:")

#text("If the first lower value for odd `c2` is (odd or even) `c3`,")#linebreak()#text(" and it takes `p2` halvings and `p3` triplings to get there,")#linebreak()#text(" then any (2^`p2`*i + `c2`) has (3^`p3`*i +`c3`) (i >= 0)")#linebreak()#text(" as its first lower value,")#linebreak()#text(" and `p2` = floor(1+`p3`*log(3)/log(2)) = floor(1+log(3^`p3`)/log(2))")#linebreak()#text(" and `p3` = floor(0+`p2`*log(2)/log(3)) = floor(0+log(2^`p2`)/log(3)).")

#text("First four formulas, for 1,3,7,11:")#linebreak()#text(" (4*i + 1) -> (3*i + 1)")#linebreak()#text(" (16*i + 3) -> (9*i + 2)")#linebreak()#text(" (128*i + 7) -> (81*i + 5)")#linebreak()#text(" (32*i + 11) -> (27*i + 10)")

#text("No formula for (4*i+5), (4*i+9), etc., because that is already covered by (4*i+1).")

#text("Assuming that for any odd `c2` such a formula can be derived")#linebreak()#text(" (notice that this just might! need Collatz to be true),")#linebreak()#text(" then Collatz would be proven.")

#text("Formula for 27:")#linebreak()#text(" ((2^59)*i + 27) -> ((3^37)*i + 23)")#linebreak()#text(" (so the “sieving power” of 27 is relatively small)")

#text("There is no specific reason to stop at the first lower value,")#linebreak()#text(" so if a next lower value for any `c2`")#linebreak()#text(" can be reached with less assumptions,")#linebreak()#text(" that would be stronger.")

#text("All even values get halved, so that weeds out 50% of all x > 0")#linebreak()#text(" (strikingly similar to how 2 makes all other evens not to be prime).")

#text("The formula for (4*i+1) weeds out 2/4th of the odds, so 75% done.")#linebreak()#text(" Next formula (16*i + 3) weeds out 2/16th of the odds, which makes it 81%.")#linebreak()#text(" Etc. This is similar to Tao’s result that the portion still to go can be made as minimal as desired (but not zero yet).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1aebb95e30ff1f89735225e9490640519bbd1d85eb91b384ff7930a90223c2e-d4df91018174f19b6ffb231bd7f0373f7b449eb66def99cc6740511ed072ac2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of druud62")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-638810")[#strong[#text("druud62")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2021")])]

#text("Finally managed to login. Let me know where my wording is overly dramatic etc. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1aebb95e30ff1f89735225e9490640519bbd1d85eb91b384ff7930a90223c2e-d4df91018174f19b6ffb231bd7f0373f7b449eb66def99cc6740511ed072ac2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of druud62")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-638812")[#strong[#text("druud62")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2021")])]

#text("“No formula for (4*i+5), (4*i+9), etc., because that is already covered by (4*i+1).” is meant to imply that you can do the same for any early formula, so (16*i + 3) -> (9*i + 2) also covers ((16*(i+1)+3) -> (9*(i+1)+2)) = ((16*i+19) -> (9*i+11)), etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed0e33c0c2cae68926c9965877193cb5b50d88e4fa3c9dd54fa8b1365b5b45c7-02a30b3afad7f3b5530817339a95487d28e12644af249ca826bc5f3eab29c513.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of satyrchary")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-638822")[#strong[#text("satyrchary")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2021")])]

#text("Hi Dr.TT and others :) I’d appreciate your thoughts on this: ")#link("https://bit.ly/CollatzProof")[#text("https://bit.ly/CollatzProof")]

#text("Thank you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1aebb95e30ff1f89735225e9490640519bbd1d85eb91b384ff7930a90223c2e-d4df91018174f19b6ffb231bd7f0373f7b449eb66def99cc6740511ed072ac2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of druud62")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-638825")[#strong[#text("druud62")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2021")])]

#text("Formula-0 is ((2*i+0)->(1*i+0)), which covers the evens.")

#link("https://oeis.org/A122458")[#text("https://oeis.org/A122458")]#text(" is `p3` (with a(0)=1).")

#text("The `p2` sequence (2,4,16,4,128,4,32,…) or rather (1,2,4,2,7,2,5,…) can be derived as mentioned from `p3`, and is also A260590 (with a(0)=1 prepended).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1aebb95e30ff1f89735225e9490640519bbd1d85eb91b384ff7930a90223c2e-d4df91018174f19b6ffb231bd7f0373f7b449eb66def99cc6740511ed072ac2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of druud62")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-638826")[#strong[#text("druud62")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2021")])]

#text("Oh, and please forgive me for using the ‘Collatz proof’ term (read it again and see how I worded it), as that was purely done to trigger some hives.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1aebb95e30ff1f89735225e9490640519bbd1d85eb91b384ff7930a90223c2e-d4df91018174f19b6ffb231bd7f0373f7b449eb66def99cc6740511ed072ac2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of druud62")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-638834")[#strong[#text("druud62")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2021")])]

#text("For PARI-code, see")#linebreak()#text(" ")#link("https://pari.math.u-bordeaux.fr/archives/pari-users-2112/msg00061.html")[#text("https://pari.math.u-bordeaux.fr/archives/pari-users-2112/msg00061.html")]

#text("Example results:")

#text("? run2(2^11+1)")#linebreak()#text(" – – – – –")#linebreak()#text(" #s : 8197 (bits)")#linebreak()#text(" max(c2) : 4099")#linebreak()#text(" next(c2): 8245")#linebreak()#text(" sieved : 97.24%")#linebreak()#text(" took : 2.98s")

#text("? run2(2^12+1)")#linebreak()#text(" – – – – –")#linebreak()#text(" #s : 16389 (bits)")#linebreak()#text(" max(c2) : 8195")#linebreak()#text(" next(c2): 16437")#linebreak()#text(" sieved : 97.76%")#linebreak()#text(" took : 12.18s")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1aebb95e30ff1f89735225e9490640519bbd1d85eb91b384ff7930a90223c2e-d4df91018174f19b6ffb231bd7f0373f7b449eb66def99cc6740511ed072ac2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of druud62")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-638838")[#strong[#text("druud62")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2021")])]

#text("Am now checking my sieve-stats once more …")#linebreak()#text(" (it’s good to keep doubting)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1aebb95e30ff1f89735225e9490640519bbd1d85eb91b384ff7930a90223c2e-d4df91018174f19b6ffb231bd7f0373f7b449eb66def99cc6740511ed072ac2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of druud62")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-638841")[#strong[#text("druud62")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2021")])]

#text("All looks fine to me, beyond an irrelevant (…) off-by-factor-2 number in the stats-print.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1aebb95e30ff1f89735225e9490640519bbd1d85eb91b384ff7930a90223c2e-d4df91018174f19b6ffb231bd7f0373f7b449eb66def99cc6740511ed072ac2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of druud62")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-638844")[#strong[#text("druud62")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2021")])]

#text("If you know of articles about Collatz-sieving, please mention them.")

#text("There is also (for example) 8x+5 -> 2x+1 (repeatedly, ")#link("https://oeis.org/A350091")[#text("A350091")]#text("), and ")#link("https://oeis.org/A096773")[#text("A096773")]#text(" (one of my favorites).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f98bc88913af2b0b0709a7225435da60b6170910066798fd6f1afc926db8fd29-dff27125966cfc609d76ad8bf4c0d89d00351c469149c0456d6d35920b342764.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-638856")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2021")])]

#text("There are three nth-term formulas for the whole 3x+1 odd-only map. Two that are linear (A004767, A017077) are sufficient, but be willing to permit n == 0 mod 3. One little trick you’ll have to figure out. The third is a geometric series (A002450) with an adaptation – only if you’re willing to permit (n-1)1/4. Again, one little trick you’ll have to figure out. In fact, defining the N superset with these additions is entirely logical if you make the cognitive switch from even-odd to odd-only. Put the three together and you have one result: Global finitude with respect to 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1aebb95e30ff1f89735225e9490640519bbd1d85eb91b384ff7930a90223c2e-d4df91018174f19b6ffb231bd7f0373f7b449eb66def99cc6740511ed072ac2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of druud62")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-638858")[#strong[#text("druud62")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2021")])]

#text("The next trick I am thinking about, is to use a repeated transformation from the odd towards its first lower value (either even or odd would be fine) that has a built-in switch to “degrade” into divisions-by-1/additions-of-0 once the lower value is reached.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1aebb95e30ff1f89735225e9490640519bbd1d85eb91b384ff7930a90223c2e-d4df91018174f19b6ffb231bd7f0373f7b449eb66def99cc6740511ed072ac2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of druud62")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-638860")[#strong[#text("druud62")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2021")])]

#text("Odd-only is fine, and is mostly how I reason about it. But it is like calling 2 a special prime only because it is not odd, to which I never hesitate to object. To me 2 is special because it controls exactly 50%. :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f98bc88913af2b0b0709a7225435da60b6170910066798fd6f1afc926db8fd29-dff27125966cfc609d76ad8bf4c0d89d00351c469149c0456d6d35920b342764.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-638867")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2021")])]

#text("But I ask you, if you know the nth term of any sequence, does that not mean the game is over for this conjecture? It’s not a dynamical system – it’s a deterministic, well-ordered system. I’ve known this from a computational framework for a long time, but it might be more meaningful to mathematicians to have an nth-term solution. We’ll see. ")#link("https://qr.ae/pG6p8y")[#text("https://qr.ae/pG6p8y")]#text(". As I see it, this conjecture is not an isolated, rugged mountain, more a playground in the garden of mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-638869")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2021")])]

#text("I would request you all to stop spamming this space. More than 70% of the comments on page 4 are rubbish and one should realize that this is a bad thing. If you have genuine ideas please post them on arxiv or send it to some appropriate journal. Like any other mathematician, prof. Tao is already too busy with many important things, and so it is not at all rational to assume that he would go over any of these computational algorithms. It is just his generosity that he has not deleted these comments or that commenting on his blog doesn’t require the wordpress approval feature. Respect this thing but don’t take it as your impunity to spam here. Many important comments may go unnoticed this way.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed0e33c0c2cae68926c9965877193cb5b50d88e4fa3c9dd54fa8b1365b5b45c7-02a30b3afad7f3b5530817339a95487d28e12644af249ca826bc5f3eab29c513.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of satyrchary")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-638870")[#strong[#text("satyrchary")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2021")])]

#text("Aditya, good point. I’d LOVE to delete the only comment I put up above (12:30am) – but am unable :(")

#text("I did not look before posting, about being able to delete (simply assumed I could!).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1aebb95e30ff1f89735225e9490640519bbd1d85eb91b384ff7930a90223c2e-d4df91018174f19b6ffb231bd7f0373f7b449eb66def99cc6740511ed072ac2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of druud62")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-638880")[#strong[#text("druud62")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2021")])]

#text("Yes, it would good to be able to (delete your own) comments.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee9bf66104c58d0fff497f81c56a9edf54153ead4d5ab887abad88d7b6fd1f2f-890b51d9c9a32c4666207c18708b3db7647139aa2f3f361c7044e76a4f103522.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-638884")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2021")])]

#mi("3^{k}-2^{k}=3^{k-1}+3^{k-2}2^{1}+...+2^{k-1}")#linebreak()#text(" ")#mi("2^{k+y}-n3^{k}=3^{k-1}+3^{k-2}2^{a_{1}}+...+2^{a_{k+1}}")#linebreak()#text(" ")#mi("n-d=2^{y-k}")

#text("For every odd n, exist infinite solutions ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf24f90dc358431d8715fe5c2a79f4cafc6deb3f8fd2697ecf5e2cc33ac940a3-f88bcc3abdc8b6e2a37e2ce10f987b0f2fc9723881769a4baf6b3027dc48db71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andersays")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-652295")[#strong[#text("Andersays")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2022")])]

#text("I have a much simpler method that also works for the negatives. To see a glimpse, a 3-column spreadsheet is all that is needed. First column (C1) is just a list of integers from 0 to n (any arbitrary number will do, 100 is usually a nice amount). Second column (C2) is the Collatz using C1 as the value for x in 2x+1. Third column (C3) is the mod(C2,6) command. Simple predictability from a much simpler approach.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-659494")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2022")])]

#text("If you write a program which comes to 1 , you have the effort 10*n*log(n) to do. But keep in mind, if you try all numbers from 1, you have only to come to a number")#linebreak()#text(" smaller that you have already tried. Here the effort is")#linebreak()#text(" only 5.238077*n or O(n)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-659495")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2022")])]

#text("sry, 5.238977 (instead of 5.238077)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-659496")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2022")])]

#text("And, with this convergent effort to 5.238977*n , for me the conjecture is proven.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1aebb95e30ff1f89735225e9490640519bbd1d85eb91b384ff7930a90223c2e-d4df91018174f19b6ffb231bd7f0373f7b449eb66def99cc6740511ed072ac2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of druud62")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-659499")[#strong[#text("druud62")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2022")])]

#text("To prove that there can be no cycle above your current “ceiling”, remains to be done. I think still easiest is to show that any number but 1, has a lower successor in its trajectory. The atomic values for this are in oeis:A243115. So show that there is a map from any number to its “3x+1”-atom. See also oeis:A076227.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-659503")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2022")])]

#text("thanks for the oeis sequences. But the effort (count 1 for")#linebreak()#text(" x/2 and count 1 for 3*x+1) can NOT be found in oeis:")#linebreak()#text(" 1,7,8,11,12,23,24,27,28,36,37,40,41,52,53,56,57,63,")#linebreak()#text(" These efforts are the complete effort until this number")#linebreak()#text(" (Summation of all previous efforts)")#linebreak()#text(" Interstingly, not in oeis. If i divide this amount effort")#linebreak()#text(" by the loop counter, i get 5.238977…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-659504")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2022")])]

#text("pls replace “until this number” to “until the loop counter number”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-659506")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2022")])]

#text("and pls replace “i get 5.238977…” to “it converges to")#linebreak()#text(" 5.238977 for very big (loop counter) numbers” sry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-660018")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2022")])]

#text("1: [ ] cnt_this_seq=0 cnt_all_seq=0")#linebreak()#text(" 2: [ 1 ] cnt_this_seq=1 cnt_all_seq=1")#linebreak()#text(" 3: [ 10 5 16 8 4 2 ] cnt_this_seq=6 cnt_all_seq=7")#linebreak()#text(" 4: [ 2 ] cnt_this_seq=1 cnt_all_seq=8")#linebreak()#text(" 5: [ 16 8 4 ] cnt_this_seq=3 cnt_all_seq=11")#linebreak()#text(" 6: [ 3 ] cnt_this_seq=1 cnt_all_seq=12")#linebreak()#text(" 7: [ 22 11 34 17 52 26 13 40 20 10 5 ] cnt_this_seq=11 cnt_all_seq=23")#linebreak()#text(" 8: [ 4 ] cnt_this_seq=1 cnt_all_seq=24")#linebreak()#text(" 9: [ 28 14 7 ] cnt_this_seq=3 cnt_all_seq=27")#linebreak()#text(" 10: [ 5 ] cnt_this_seq=1 cnt_all_seq=28")#linebreak()#text(" 11: [ 34 17 52 26 13 40 20 10 ] cnt_this_seq=8 cnt_all_seq=36")#linebreak()#text(" 12: [ 6 ] cnt_this_seq=1 cnt_all_seq=37")#linebreak()#text(" 13: [ 40 20 10 ] cnt_this_seq=3 cnt_all_seq=40")#linebreak()#text(" 14: [ 7 ] cnt_this_seq=1 cnt_all_seq=41")#linebreak()#text(" 15: [ 46 23 70 35 106 53 160 80 40 20 10 ] cnt_this_seq=11 cnt_all_seq=52")#linebreak()#text(" 16: [ 8 ] cnt_this_seq=1 cnt_all_seq=53")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-660021")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2022")])]

#text("and cnt_all_seq/n converges to 5.238977")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5170010f70c29afc35e4e33fa2a14517e816f9b215b890ec6435784900b6660-4b2ec332aeca9225cebfa98f36f767e2e5441d244b50e4e9c609910bdbc6b341.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wulf Rehder")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-673437")[#strong[#text("Wulf Rehder")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2023")])]

#text("(This is a belated answer to De Wi and of Andrew Croft’s posting of Feb 7, 2023).")#linebreak()#text(" Yes, there exists a simple conditional formula for the steps until the stopping time S and also to the final stopping time T; conditional, because it depends, strictly speaking, on the assumption that S and T are actually being reached, in other words: on the assumption that the Collatz conjecture is true. If it is (and all examples so far speak in favor of it), all Collatz 3x+1 sequences can be split into equivalence classes and studied further. For instance, it becomes clear that not all natural numbers can be stopping times of a Collatz sequence. Moreover, it then leads to a curious invention of “primal numbers” that are similar to prime numbers (“additive” prime numbers), and you can do further numerical and theoretical research on twin primal numbers, define an Eratosthenes primal sieve for them, check on the validity of Bertrand’s Postulate for primal numbers, and so on. In other words, assuming the Collatz conjecture provides a large mathematical playground. I have written up some of it in a mathematical essay “Fun Facts about Collatz 3x+1 Sequences.” It is available through Amazon in Germany and the UK; but I’ve sent the pdf (generated from LaTeX) to several colleagues, for free of course. Whoever wants it, please contact me by gmail, with my first and last name written as one word (in case we are not supposed to overtly advertise our address here).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-673899")[#strong[#text("Even the Smartest Mathematicians Can’t Solve the Collatz Conjecture - newsonetop.com")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2023")]

#text("[…] one of the most gifted mathematicians of the past century, published a paper in 2019 titled “Almost All Collatz Orbits Attain Almost Bounded Values.” Tao is no slouch — he earned his Ph.D. from Princeton at the age of 21 and became the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-673941")[#strong[#text("Even the Smartest Mathematicians Can't Solve the Collatz Conjecture - Your Lifestyle Magazine")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2023")]

#text("[…] one of the most gifted mathematicians of the past century, published a paper in 2019 titled “Almost All Collatz Orbits Attain Almost Bounded Values.” Tao is no slouch — he earned his Ph.D. from Princeton at the age of 21 and became the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-674030")[#strong[#text("Even the Smartest Mathematicians Can't Solve the Collatz Conjecture - Your Lifestyle Magazine 2023")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2023")]

#text("[…] one of the most gifted mathematicians of the past century, published a paper in 2019 titled “Almost All Collatz Orbits Attain Almost Bounded Values.” Tao is no slouch — he earned his Ph.D. from Princeton at the age of 21 and became the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/706290022e355932d7ef0af9b41d90aefd3951f0c2a0b9ee718e679dd81bfad3-dc1ec23096fccaedd6de0e33ef38c50458aa7122b8327b00e5bc587852779c84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of G.g.")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-675214")[#strong[#text("G.g.")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2023")])]

#text("All that work to assume it is almost sure the conjecture is true is assuming the fact that the problem is not solved")#linebreak()#text(" Why there are not studies searching the conter exemple a sequence not ending by one? Finally may be more easy and over all more simple.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-680691")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2023")])]

#text("Is logarithmic density weaker than natural density?")#linebreak()#text(" A set has logarithmic density =1 in the positive integer set, but has natural density<1, is this possible?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-680771")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2023")])]

#text("If the natural density exists, then the logarithmic density also exists and is equal to the natural density (this is an exercise in summation by parts (see Exercise 6 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("this previous set of notes). However, it is possible for the logarithmic density to exist without the natural density existing (see Exercise 7 of the same notes), so in that sense the notion of logarithmic density is a weaker notion.")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-680815")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2023")])]

#text("One need not be concerned with logarithmic approximations if the nth terms yield to arithmetic and elementary set theory, which they do.")#linebreak()#text(" ")#link("https://qr.ae/pyD8Nk")[#text("https://qr.ae/pyD8Nk")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-681984")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2023")])]

#text("Everyone is afraid of Collatz Conjecture (no one wants to risk their own reputation :), which is why publication of the proof is IMPOSSIBLE. However you are welcome to check it here:")#linebreak()#text(" ")#link("https://www.researchgate.net/publication/351347153")[#text("https://www.researchgate.net/publication/351347153")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-681985")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2023")])]

#text("I’m not afraid of it! There are two parts to a proof of the nth terms of convergence of the Collatz map. A general statement of the theorem, ")#link("https://qr.ae/pyD8Nk")[#text("https://qr.ae/pyD8Nk")]#text(", and an inductive proof of that theorem, ")#link("https://qr.ae/pKRv1A")[#text("https://qr.ae/pKRv1A")]#text(". I would think a serious mathematician could find the general proof from my foundation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-681986")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2023")])]

#text("I meant “afraid to confirm that the paper is correct” :) At the risk that if NOT, who confirmed it will lose the reputation as a mathematician, reviewer or publisher :)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-681987")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2023")])]

#text("The proof of Collatz conjecture can be achieved without discussions about cycles.")

#text("As presented in")

#text("Gunther J. Wirsching, The dynamical system generated by the 3n+1 function, Lecture Notes in Mathematics, vol. 1681, Springer-Verlag, Berlin, 1998, pg. 18.")

#text("and in")

#text("B o h m C . , S o n t a c c h i G . On the existence of cycles of given length in integer sequence // Attidella Accademia Nazionale dei Lincei, Classe di Scienze Fisiche, Matematiche e Naturali. — 1978.— 64, N 2. — P. 260–264; Crandall, R. (1978) On the “3x + 1” Problem. Mathematics of Computation. 32 (144), 1281")

#text("(you can find this fragment under the link ")#link("http://www.bdim.eu/item?fmt=pdf&id=RLINA_1978_8_64_3_260_0")[#text("http://www.bdim.eu/item?fmt=pdf&id=RLINA_1978_8_64_3_260_0")]#text(")")

#text("it is enough that we can proof that each natural number can be expressed in the form (**) in PROPOSITION 7 (page 264) at the end of the second paper (link above) .")

#text("I proposed an algorithm how to achieve this for every natural number and proven that this algorithm will always stop. Therefore required representation for every natural number can be found.")

#link("https://www.researchgate.net/publication/351347153")[#text("https://www.researchgate.net/publication/351347153")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-682164")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2023")])]

#text("Youtube video “The Proof of Collatz Conjecture – Explained” -> ")#link("https://www.youtube.com/watch?v=FIZjITBbi2Y")[#text("https://www.youtube.com/watch?v=FIZjITBbi2Y")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-682489")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2023")])]

#text("Why did you called the accelerated Collatz map Syracuse map ? Who first defined it ? Any reference ? Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-682616")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2023")])]

#text("I’m not sure where it first appears, but here for instance is one reference from 1988: ")#link("https://www.sciencedirect.com/science/article/pii/0012365X88901215")[#text("https://www.sciencedirect.com/science/article/pii/0012365X88901215")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-682777")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2024")])]

#text("I think I have fondamentali the solution, with the help of a new set of axioms. Here is a video presentino the paper ")#link("https://youtu.be/fHt3lk7e8hE?feature=shared")[#text("https://youtu.be/fHt3lk7e8hE?feature=shared")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-684420")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2024")])]

#text("I came upon the 3N+1 conjecture by accident. I am not a mathematician so my “solving” of the problem is probably not a mathematical solution; however, I will share my take. All numbers using this formula will eventually have their ones digit reduced to a 1 or 0. Since all numbers are statistically reduced by about 3/4 using the conjecture the numbers get smaller, eventually settling on the 4,2,1 infinite loop. We can prove that any ones digit (0-9) when multiplied by 3 and adding 1 (for odds) equals an even. We can prove that any even number can be broke in half and will create an odd or even number. I chased every ones digit using this conjecture until everyone eventually landed back at 0 or 1. The odds are super quick (9 to 8, 7 to 2, 5 to 6, 3 to 0, and 1 to 4). The evens took a few loops (0 to 0 and/or 0 to 5, 2 to 1 or 6, 4 to 2 or 7, 6 to 3 or 8, and 8 to 4 or 9) but produce an odd half the time and an even the other half. The loop can be near infinite but eventually has to break off the loop and move on. For instance, 9 always becomes 8 and 8 becomes 9 half the time. With the right number we could have the ones digit going between 8 and 9 as we multiply then divide. Eventually, the 8 in the ones place will have an even number in the tens place and break the loop allowing us to now chase a 4. The 4 resolves to a 2 or 7. The 7 always becomes a 2. The 2 has a small loop by becoming a 1 or 6. The 1 quickly resolves to 0 by going to the 4, 2, 6, 3, 0 route. The 6 takes the 3 to 0 or 8,4,2,6,3,0 route. No matter what the route ends back at 0 or 1 for the ones digit every time. Large numbers will continue to break down at a statistical rate of .75N until we get the infinite 4,2,1 loop. So, can I use fancy letters or symbols to prove this? no. Can I prove every number between 1 and infinity? no. Can I prove that even 1 number will not eventually break down at a rate of 3/4N? no. Some fancy mathematicians can take my “breakthrough” (like no one else has ever thought of this before) and make it confusing for the average person. I scribbled on a sheet of paper the ones loop of possible outcomes and they always come back to 1 or 0 (always 0 if the number is large enough but there are tons of examples of getting back to a 1 then never getting to a 0 when the numbers are relatively small like under 1,000,000). “Solution” by Eddie the non-mathematician")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-684434")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2024")])]

#text("How I predicted the total number of iterations in Collatz conjecture sequence in case of 2^100000-1 and 3^100000-1 with an error less than 0.065%.")

#text("In case 2^100000-1 this number in binary is 100000 times 1.")#linebreak()#text(" 11111111….. (100000 times)")#linebreak()#text(" 1.When process via Collatz it starts with 100000 steps where the length of the number in binary is extended by 1.58496 bit/iteration to total length 158496 after 100000 first iterations.")#linebreak()#text(" 2.Starting from this iteration it goes through random process to 1 which shorten the length of this number on average by 0.415037 bit/iteration. It gives additional 381884 steps.")#linebreak()#text(" When we sum up 1. and 2. we have total 481884 iterations. In reality it was 481603 steps (0.058%off). This part counted only 3n+1 operations.")#linebreak()#text(" To count also div by 2 operations we have:")#linebreak()#text(" 1.First 100000 it is 1 by 1 so for every single operation 3n+1 is one “div by 2” in total 100000 “div by 2” iterations.")#linebreak()#text(" 2. In remaining part starting from the length of the binary number 158496 bits, half of this number will have one “div by 2”, 1/4th will have 2 “div by 2” per one 3n+1, 1/8th will have 3 “div by 2” per one 3n+1 and so on. In total this will give 763739 operations “div by 2”.")#linebreak()#text(" Summing up 1. and 2. we have 863739times “div by 2”.")#linebreak()#text(" Predicted number of all operations (3n+1 and “div by 2”) is 1345623. In reality it was1344926 (0.051% off).")

#text("In case of 3^100000-1 this number in binary is total chaos of the length 158496. It is easier.")#linebreak()#text(" To know number of “odd steps” (3n+1) we know it is shortened on average by 0.415037 bit/iteration. We have 381884 “odd steps”. In reality it was 381603 (0.073%away).")#linebreak()#text(" To count number of “div by 2” steps again half of it has one “div by 2” per one “odd step”, 1/4th has 2 “div by 2” steps per one 3n+1, 1/8th has 3 “div by 2” steps and so on. In total it is 763739.")#linebreak()#text(" Sum of odd and even steps (3n+1 and “div by 2”) is 1145623. In reality 1144925 (my prediction is 0.061%off).")

#text("My method is explained in the video on youtube “The Proof of Collatz Conjecture – For Dummies” ")#link("https://www.youtube.com/watch?v=J8kHjNPsFJY")[#text("https://www.youtube.com/watch?v=J8kHjNPsFJY")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aafe0719a8540ac8b752a9d4b0ec71166c8c5295fe264578379bdde488c8dbca-48f3d8f98e39c8b081b82834d124a4aead63a10fb757b6ce51b89b43290739f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuseifudo7")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685024")[#strong[#text("yuseifudo7")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2024")])]

#text("I know this blog is pretty old, but I wanted to leave a comment here just in case someone wants to read it. I am neither a mathematician nor very good with words, but I wanted to give it a try.")

#text("Rather than finding the number itself, how about looking up if the number even exists, which does not follow the 4, 2, and 1 loop?")

#text("There are the following options to think about when breaking this loop:")#linebreak()#text("1. The number is increasing infinitely.")#linebreak()#text("2. The number is decreasing indefinitely.")#linebreak()#text("3. A different loop.")

#text("The number one:")#linebreak()#text("It will not be possible to increase it intentionally due to the nature of")#strong[#text(" 3x + 1")]#text(". If only an odd number gets multiplied by the number 3, it will most likely be an odd number again. If we look at the multiplication table of 3, we will see that the first number is odd, then the third, then the fifth, and so on, meaning we will have ")#strong[#text("odd, even, odd, even")]#text(" as a chain. Furthermore, we would only need to check the numbers from 1 to 9, since an odd number needs to have an ")#strong[#text("1, 3, 5, 7, or 9 at the last position")]#text(" ")#strong[#text("to be odd")]#text(". So, we can assume that every odd number times 3 will (most likely) result in an odd number. By adding 1, we will always make an even number. So, we would need a chain of numbers where the next number above them is also odd, which ")#strong[#text("will not exist")]#text(" due to the nature of the number 3.")

#text("To number two:")#linebreak()#text("Not possible because dividing by 2 will ")#strong[#text("never")]#text(" get us to 0, so we will stick with the number 1 as the ")#strong[#text("smallest possible ")]#text("number.")

#text("To number three:")#linebreak()#text("Because we can only divide by two if a number is even and always get eventually an even number due to the characteristics mentioned before for odd numbers, we would need an even number, which has the nature of ")#strong[#text("x mod 2!= 0")]#text(" (I have no clue how to type it correctly with the keyboard). Why do we need such a number, or why should this kind of nature be true? Well, my thought was that every loop will ")#strong[#text("always have one")]#text(" number being the smallest odd and one being the smallest even number inside of it. If the odd number ")#strong[#text("can only increase")]#text(" and be inside the 4, 2, and 1 loop, you will need an even number, which will never touch those three numbers in any way. We can ignore the four here and only rely on 2 and 1. So, 2 is the smallest even number, and 1 is the smallest odd number in their own respective loops. We would ")#strong[#text("need")]#text(" a loop where this is not the case; otherwise, we cannot escape it. ")#strong[#text("However,")]#text(" 2 has the ability to be a divider of every even number due to being the indicator if a number is odd or even, and many more things.")

#strong[#text("In short terms")]#text(", due to the ")#strong[#text("nature of 3")]#text(" having an even number if an odd number is increased by 1 and 2 being the divider of every possible even number, you must need either a chain of odd numbers next to each other when multiplying and increasing or an even number with ")#strong[#text("x mod 2!= 0")]#text(" as its nature.")

#text("Those are my thoughts. ^^”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685032")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2024")])]

#text("It’s only necessary to prove that for any given starting odd number, a lesser number will be eventually reached.")

#text("It’s easy to show that ")#emph[#text("on logarithmic average")]#text(" the sequence is expected to go down. Its behavior is similar to random sequence, where each 3x+1 step increases the ")#strong[#text("log")]#text(" by close to ")#strong[#text("log(3)")]#text(", and each “zero elimination” step after that decreases the ")#strong[#text("log")]#text(" by ")#strong[#text("log(4)")]#text(" (on average, 2 zeros are discarded after each ")#strong[#text("3x+1")]#text(" operation). Thus, in average ")#strong[#text("log")]#text(" terms, the sequence goes down by ")#strong[#text("log(4/3) ")]#text("on each step.")

#text("Such behavior is easily illustrated by running the numbers.")

#text("It’s not proven that there’s no closed loop sequence which goes back to the initial number.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aafe0719a8540ac8b752a9d4b0ec71166c8c5295fe264578379bdde488c8dbca-48f3d8f98e39c8b081b82834d124a4aead63a10fb757b6ce51b89b43290739f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yuseifudo7")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685034")[#strong[#text("yuseifudo7")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2024")])]

#text("Thx for the ")#strong[#text("explanation")]#text(". I try to comprehense it.")

#text("May I ask a more off topic question:")

#text("The problem itself is very specific and has an interesting effect due to the nature of the given operations, which needs to be done. ")#strong[#text("However")]#text(", if you choose to do 3x – 1 rather 3x + 1, you can get immediately two loops, one leading to 2 and 1 and the other when starting with 5.")

#text("My question would be, what is the actual difference between ")#strong[#text("increasing or decreasing")]#text(" an odd number in the multiplication table of 3, when both will be even in the end?")

#text("Funny enough, ")#strong[#text("negative numbers would have a similar ")]#text("effect as the given problem if you use 3x – 1 when it is an odd number but would immediately create own seperate loops if using 3x + 1. The number one is very odly specific and works well depending how it wors. (Yeah, I am creating an useless extra topic.)")

#text("(Yeah, that thought would probably crash my first thoughts but I am curious.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed8e6fe1ad1122d1b6c5ec050eb8834bd236fdd6e3e57c1c4b5a7753ae0abdc3-f09aa2d300652d983e1cf3ea795814e0958e1fe88bc570ca63d26540e73ba0e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alegrigoriev")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685036")[#strong[#text("alegrigoriev")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2024")])]

#text("Running 3x-1 over negative numbers is equivalent to running 3x+1 over positive numbers.")

#text("One likely significant difference between 3x+1 and 3x-1 is that 3x+1 turns the trailing sequence of 1s (in the binary representation) into a sequence of zeros, which gets shifted out by the “zero elimination” step.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685033")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2024")])]

#text("Another possible proof would be if you prove you can reach any number from a smaller number.")

#text("This would mean that any bigger number is part of the sequence which converges (since it would also prove that the smaller number is a part of a converging sequence).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685058")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2024")])]

#text("That’s been proven, fairly easily, using set arithmetic and nth terms.")#linebreak()#text("Here’s an example…")#linebreak()#link("https://doi.org/10.6084/m9.figshare.24778536.v2")[#text("https://doi.org/10.6084/m9.figshare.24778536.v2")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed8e6fe1ad1122d1b6c5ec050eb8834bd236fdd6e3e57c1c4b5a7753ae0abdc3-f09aa2d300652d983e1cf3ea795814e0958e1fe88bc570ca63d26540e73ba0e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alegrigoriev")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685069")[#strong[#text("alegrigoriev")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2024")])]

#text("I’m not sure what that paper proves. It appears it proves that some partial cases converge onto smaller integers. It’s the easy part. The difficult part is to prove that any number eventually converges into a smaller integer. It’s possible to find cases when it takes 300+ iterations to reach a number smaller than the starting number.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed8e6fe1ad1122d1b6c5ec050eb8834bd236fdd6e3e57c1c4b5a7753ae0abdc3-f09aa2d300652d983e1cf3ea795814e0958e1fe88bc570ca63d26540e73ba0e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alegrigoriev")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685070")[#strong[#text("alegrigoriev")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2024")])]

#text("> you prove you can reach any number from a smaller number.")

#text("It’s easy to show that, in fact, certain numbers are NOT reachable from a smaller number.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685112")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2024")])]

#text("Although the initial pick can be selected via a random process, once it has been picked and is input to the Collatz algorithm the rest of the trajectory is deterministic (albeit, determined by a quirky pair of conditional rules, still not random), so the validity of applying probability theory to the problem is not clear to me. I have only a Bachelors in math, and applied math at that. My only graded number theory work was from a course that used your Real Analysis I textbook (which provided an excellent introduction to the topic imo, btw) and I have not published, so I’m not disputing or critiquing the approach, just requesting an explanation of its validity — at a level that might be accessible to me with the education I have, if that’s possible.")

#text("Thanks in advance, Prof Tao!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685120")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2024")])]

#text("Professor Terence Tao will never reply to your this comment. Because he is smart enough to know that he is fool.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685130")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2024")])]

#text("The definition of probability can be taken as unique by the word “unbiased”. But though it is not unique and finite by the word “unbiased” because we can define probability as [{(number of favorable cases)^n + (number of unfavorable cases)^n}^(1/n)]/total number of cases where n takes infinitely mane positive integer values. As definition of probability can infinitely many, thus it doesn’t define any deterministic or physical process. It defines stochastic process. And in stochastic process, mathematics is not applicable. So, the whole probability theory is wrong. So, the use of probability theory in any physical process or mathematics i.e. in any deterministic process is considered to be wrong. I made Professor Terence Tao aware of this. As he knows that his this work is thus wrong, so he will not reply. Because he is smart enough to know that he is fool.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685132")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2024")])]

#text("You will say also “Group” can be defined in infinitely many ways. So, also “Group” is not mathematics. “Group” doesn’t define any physical process. Thus it is derived mathematics i.e. it cannot explain any physical process or nature’s law until it meets again simple algebra i.e. if it can solve a fundamental problem, then it can explain a physical process. Thus the whole university level mathematics is derived mathematics or invention of mathematics because they can’t explain any physical process or nature’s law. And if you can’t explain any nature’s laws, then it cannot make any product for the economy to grow i.e. the whole university level mathematics is unproductive work i.e. university professors get unemployment allowance from government. As they can’t produce any productive work. The main mathematics is arithmetic, algebra and geometry. And we can convert geometry into algebra. Thus algebra is everything. Rest all are derived mathematics i.e. what can be done using “Group” or “Ring” or anything, can be done using simple algebra. So, solving fundamental problems using simple algebra is scientific mathematics. Rest of the mathematics is art. Now come to the question why “Probability” is wrong but “Group” is not wrong but derived mathematics. Because Probability is defining a physical process where Group is not. So, probability is wrong because it is supposed to define a physical process but it can’t as we have seen it can be defined in infinite ways.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685353")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2024")])]

#link("https://math.stackexchange.com/q/4944443/392087")[#text("https://math.stackexchange.com/q/4944443/392087")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685560")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2024")])]

#text("I have the following question regarding the result(, that I hope others might find interesting as well): Given any diverging ")#mi("f:\\mathbb{N}+1\\rightarrow \\mathbb{R}")#text(", does the proof allow to retrieve an explicit function ")#mi("g:\\mathbb{N}+1\\rightarrow \\mathbb{N}")#text(" such that ")#mi("Col^{g(n)}(n)\\leq f(n)")#text(" for almost all ")#mi("n")#text("? Say for example for ")#mi("f(n)=n^\\epsilon")#text(". Then heuristically ")#mi("g(n)=\\lfloor(\\log \\frac{4}{3})^{-1}\\log(n)\\rfloor")#text(" should work (for any ")#mi("\\epsilon>0")#text("). What would be a guess for example for ")#mi("f(n)=\\log n")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685582")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2024")])]

#text("The argument should be able to be tweaked to give an upper bound for ")#mi("g(n)")#text(" that is of the shape ")#mi("(1+O(1)) \\log n / \\log(4/3)")#text(" as you indicate, due to a geometrically decaying series of time steps, though I did not work this out in detail in the paper. A result of this type for ")#mi("f(n) = n^\\varepsilon")#text(" was recently established by Inselmann in ")#link("https://arxiv.org/abs/2402.03276")[#text("https://arxiv.org/abs/2402.03276")]#text(" , by a slightly different method to the one given here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685798")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2024")])]

#text("Thanks for your answer! I had the paper you mentioned in mind when asking the question. I was wondering if there are interesting bounds for ")#mi("g")#text(" for functions ")#mi("f")#text(" growing slower than any ")#mi("n^\\epsilon")#text(". If the Collatz conjecture is true and furthermore, the total stopping time is in ")#mi("O(\\log n)")#text(" for all ")#mi("n")#text(", then it follows from the paper you mentioned that for any given ")#mi("\\epsilon>0")#text(" the total stopping time is bounded (above) by ")#mi("(1+\\epsilon)\\log n/\\log(4/3)")#text(" for almost all ")#mi("n")#text(" (and below by ")#mi("(1-\\epsilon)\\log n/\\log(4/3)")#text("). So it might be interesting to find some upper bound for specific ")#mi("f")#text(" of the form ")#mi("(1+o(1))\\log n/\\log(4/3)")#text(". For ")#mi("f(n)=n^\\epsilon")#text(" the function ")#mi("g(n)=\\log n/\\log(4/3)")#text(" works for any ")#mi("\\epsilon >0")#text(". Does the proof give a constant in ")#mi("(1+O(1))\\log n/\\log(4/3)")#text(" that works for any ")#mi("f")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685838")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2024")])]

#text("I would imagine Inselmann’s arguments, if performed with careful accounting of the explicit dependencies of all constants on ")#mi("\\varepsilon")#text(", should be able to extend to some ")#mi("f")#text(" that grows of the form ")#mi("f(n) = n^{o(1)}")#text(" for a sufficiently slowly decaying ")#mi("o(1)")#text(" factor, but I think it breaks down at some point. (I am not sure though whether ")#mi("\\log n / \\log (4/3)")#text(" is a particularly significant threshold for the ")#mi("f")#text(" function (as opposed to the ")#mi("g")#text(" function).)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685939")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2024")])]

#text("Thanks for your answer. My question was ambiguous. To be more precise, define the relation ")#mi("R")#text(" on pairs of functions ")#mi("g,f")#text(" from ")#mi("\\mathbb{N}+1 \\rightarrow (0,\\infty)")#text(" by ")#mi("g \\mathrel{R} f")#text(" iff ")#mi("\\text{Syr}^{g(n)}(n) \\leq f(n)")#text(" for almost all ")#mi("n \\in \\mathbb{N}+1")#text(".")

#raw("My first question is this: Does there exist  such that for all  with  there exists a  with  and ?")

#raw("My second question is this: Does any  work in the first question?")

#raw("Does any of this follow from the methods of your paper?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685953")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2024")])]

#text("This looks plausibly within reach from the methods of my paper (using logarithmic notions of “almost all”), though one would have to be more careful about measuring time steps which I did not keep track of since it was not needed for my final theorem. If ")#mi("f(n) = n^{\\varepsilon}")#text(" then I would imagine some modification of Inselmann’s methods should also establish this result (and now with the natural notion of density).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685956")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2024")])]

#text("If we put ")#mi("g(n)=\\left\\lfloor\\log n/\\log(4/3)\\right\\rfloor")#text(", then Theorem 3.8 of the paper you mentioned (which coincidentally was written by me) immediately gives ")#mi("g(n)\\mathrel{R} n^\\epsilon")#text(" simultaneously for every ")#mi("\\epsilon>0")#text(" (with natural density and notation as in the previous comment and of course different exceptional sets for each ")#mi("\\epsilon")#text("). But of course this will not work for functions growing more slowly. It is very interesting that the upper bounds on ")#mi("g")#text(" in the previous comment plausibly follow from the methods of your paper, thanks for confirming my guess.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685650")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2024")])]

#text("For a given ")#mi("f:\\mathbb{N}+1\\rightarrow (0,\\infty)")#text(" diverging to ")#mi("\\infty")#text(" is there an explicitly computable function ")#mi("g:\\mathbb{N}+1\\rightarrow\\mathbb{N}")#text(" such that ")#mi("\\text{Syr}^{g(n)}(n)\\leq f(n)")#text(" for almost all ")#mi("n")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685839")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2024")])]

#text("The methods in my paper are effective and would in principle provide such a function, though I did not attempt to explicitly compute this as the arguments are rather inefficient. If done carefully it is possible that one could get the asymptotically optimal value of ")#mi("g(n) = (1+o(1)) \\log n / \\log(4/3)")#text(", but this would likely require some reworking of the arguments.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-685935")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2024")])]

#text("Study of the conjecture based on an almost equivalent succession For the purposes of our demonstration, we can replace our succession {𝑎𝑛}𝑛 Ꜫ 𝑁 with the sequence {𝑑}𝑛 Ꜫ 𝑁 which has as its first element any positive odd integer do and as its subsequent elements the odd numbers obtained by applying to the previous element d the function g(d) in which 2^k is the greatest power of two that divides 3d+1:")

#text("(4.1) g(d) = 3𝑑+1/2^𝑘")

#text("and therefore each element of the succession {𝑑𝑛}𝑛 Ꜫ 𝑁 sarà:")

#text("(4.2) 𝑑𝑖={𝑑o 𝑝𝑒𝑟 𝑖=0; di=𝑔(𝑑𝑖−1) 𝑝𝑒𝑟 𝑖>0.")

#text("The orbit of the succession {𝑑}𝑛 Ꜫ 𝑁, with equal input do , traverses all the odd-numbered nodes of the orbit of the succession {𝑎𝑛}𝑛 Ꜫ 𝑁.")

#link("https://www.aldopappalepore.it/_downloads/216ee7ab0f0054cfec36801165f20e4d")[#text("https://www.aldopappalepore.it/_downloads/216ee7ab0f0054cfec36801165f20e4d")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9579bb67909d1be252e21b7556703f2636626c821d4ac9f3f9f221f1703a4b6-50be794607ef4531d8285970526b872d1e385264d65244764858830e954f0a2a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bharat Kumar Aryasomayajula")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-687069")[#strong[#text("Bharat Kumar Aryasomayajula")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2025")])]

#text("Hi have made an observation that all numbers in this conjecture except for the powers of two(by divisibility of 2 will reach 1), will hit the numbers in sequence 5, 21, 85, 341, 1365.. before it reaches 1, the above numbers in base 2 form the sequence 101, 10101,1010101, 101010101, 10101010101,….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-687863")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2025")])]

#text("I was wondering if the current state of the art concerning the Collatz conjecure rules out the possibility that almost all (in the sense of natural or logarithmic density) orbits diverge. Is this still consistent with you result?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-687865")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2025")])]

#text("This has not yet been ruled out. The arguments in my paper do show that a positive density fraction of orbits must fall below some explicit finite threshold ")#mi("C")#text(", and if one numerically verified the conjecture up to that threshold, that would imply that a positive density fraction of orbits do not diverge. (I also outline a possible alternate approach to this claim ")#link("https://terrytao.wordpress.com/2020/01/25/equidistribution-of-syracuse-random-variables-and-density-of-collatz-preimages/")[#text("here")]#text(".) But even then this would fall short of the claim that a density 1 set of orbits do not diverge.")

#text("In fact, heuristically, if there was a single orbit that diverged, then there should be a positive probability that a general orbit would encounter this orbit and then also diverge, so the density 1 problem may be nearly as hard as the full Collatz conjecture!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-687866")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2025")])]

#text("If you can get to the claim that any given transitive orbit connected to some lowest threshold must have density greater than half in the natural numbers, that would prove the conjecture. Because any such connected orbit would preclude the existence of a second. I wonder if this could lead to a proof of the Collatz conjecture conditional upon the periodicity conjecture. Maybe it can be shown that the density of some transitive orbit connected to some periodic orbit must be greater than the currently known orbit.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5758c2fa4ab137b865f6136e866aa24c85c4884441a5342c18c12de520d10ec-6670603e7901a19adb6d290cca2d6bbf15dd8f9489ef4cbaaefc4fdb5241bd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of marchudson627fa984c2")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-687958")[#strong[#text("marchudson627fa984c2")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2025")])]

#text("Heres a slightly different take on non trivial cycles in the conjecture, i would appreciate any feedback from the collatz fans out there: ")#link("https://zenodo.org/records/15352400")[#text("https://zenodo.org/records/15352400")]#text(" the idea is, if a cycle exists at x, of length n, then at p = x + m.2^2n, you will have p and T^n(p) [approx but <>p] with identical parity vectors length n in the same dyadic interval, which is a violation of the injectivity estavlished by Everett 1977, this contradiction precludes cycles.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f41ce141635328694bcab5ca037c55a5527e176372e014af91c93f4299e2bf16-caa3b021bd49ec87699f797be038e6a10f47387f23e1eb9488ece74075bd2fc1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dependablemaker62b1f1de42")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-688707")[#strong[#text("dependablemaker62b1f1de42")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2025")])]

#text("Dear Prof. Tao,")

#text("In your approach one obtains “almost all” convergence via an averaged contraction. I have been experimenting with a weighted potential function of the form")#linebreak()#text("V(n) = n^α * W(n mod 2^k).")

#text("With rational weights W and rational exponent α, I checked (with interval arithmetic) that for k=7 every accelerated step satisfies V(T(n)) <= q V(n) with q<1, uniformly across all residue classes. Together with a finite base-case verification, this seems to yield a deterministic drift + base-case framework (D1+D2) leading to full convergence.")

#text("Do you think such a weighted-potential lemma could be usefully incorporated into your probabilistic framework, or connect to your “almost bounded values” theorem?")

#text("Best regards.")#linebreak()#text("Volkan TÜRKBAY – Eskişehir / TÜRKİYE")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/78a9668bc87019752cb588bedfb132969716da2b1ab8a8011686d2ed1f85a762-708e5329096987355205cc66198457a7ab335f430826992f68908126a8759e5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lech Mazur")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-4/#comment-693228")[#strong[#text("Lech Mazur")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2026")])]

#text("There appears to be a small erratum-level issue in the printed proof of Corollary 6.3 of the paper, also present in arXiv v5. This is not a claimed counterexample to Corollary 6.3, Proposition 1.14, or the main theorem.")

#text("The issue was found during an AI-assisted verification project involving GPT-5.5 Pro and Claude Fable 5.")

#text("The displayed estimate bounding the sum of 3^(j-1) 2^(l – a_[1,j]) below 3^n seems to fail at the upper end of the printed range (6.8): the saving from 2^l has coefficient (ln 2)/2 = 0.3466 in exponents of C_A^2 log n, while the optimized deviation cost is (ln 2)^2/(4 ln(4/3)) = 0.4175, which is larger. In particular, the displayed argument does not seem repairable over the full printed range by changing the Young-inequality parameter.")

#text("As a check, there is an explicit admissible tuple at n = 20000, C_A = 30, satisfying (6.8), (6.12), and (6.13), for which the displayed sum itself exceeds 3^n by a factor of about 2^912. The integer components of the witness, including the comparison with 3^n, were verified by independent Python and C++ big-integer implementations; the real-valued membership inequalities were checked with positive slack, including an exhaustive C++ check of all 180,262,578 interval constraints.")

#text("The apparent repair is to use the tighter l-range already forced by the surrounding stopping-time argument, namely l in (Q, Q + 2 C_A log n] with Q = n (log 3)/(log 2) – C_A^2 log n; the part of (6.8) above this range is not attained on the relevant event. With that range, and with the prefix-interval form of (6.12) already used by the displayed estimate and supplied by the application, the proof seems to close with margin, and the downstream argument appears unchanged.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bca5546625c9d6900e72dd8ac79cfcd63d07b178e2fd91fa132d04855ab477b-de6e99e08ab8395fc8c136e949479bdc25b57d026850b462250352409f190f79.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Barry Hirschfeld")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-542298")[#strong[#text("Barry Hirschfeld")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2020")])]

#text("Folks, I’m leaving you and starting my own website. I thank all those who helped me, whether with thumbs down or actual comments, whether I agreed with you or not; I wish you all the best.")

#text("One final note. In my post of 23 Feb., in the last part (PART 5), i showed that if there is one CS that goes to infinity then there are an infinite number, and that for each step the sequence (or orbit) takes toward infinity it adds yet another infinity of integers that go toward infinity.")#linebreak()#text(" Yesterday I looked at the very start of this website. There, Prof. Tao says “Almost all Collatz orbits attain almost bounded values”.")#linebreak()#text(" This theorem of his negates the possibility of what I showed above.")#linebreak()#text(" That is, NO integer in a CS can go to infinity.")

#text("Good bye and good luck.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce7cf5c2649720f46362a8172fa9c05b501c595e39d94bade6ec54b1a919b77f-d4e815c4bed2e8874f7ed1694c217ac36f3e9c2e422f7278a7a8fbfb8bc5e271.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexandre")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-542389")[#strong[#text("Alexandre")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2020")])]

#text("Dear Terence Tao,")

#text("Maybe I have missed something, but on Lemma 7.1:")

#text("1. “the event a1 + a2 = 2” should be “the event a1 + a2 = 3”")

#text("2. each pair has probability 1/8 rather than 1/2.")

#text("Best")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. For 2., the probability here is conditional rather than absolute. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a5b2d76ebfce36073e62eadb1921645a199999d16bfa6286603e8e87f76e47ca-288d33660e7e851b455351225108187cc04065b9a8abd15fb25150170e31a745.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexandre")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-542486")[#strong[#text("Alexandre")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2020")])]

#text("Continuing…")

#text("I am trying to follow your Lemma 4.1.")

#text("3. I suppose you are considering ")#mi("\\mathbf{a}_{[1,0]} =0")#text(" and “")#mi("\\ll")#text("” stands for “much smaller than”.")

#text("4. You have to show that ")#mi("\\sum_{k=0}^{n-1} q_k \\ll 2^{-cn}")#text(", where ")#mi("q_k = \\mathbb{P}(\\mathbf{a}_{[1,k]} < m \\leq \\mathbf{a}_{[1,k+1]})")#text(" for ")#mi("k=0,\\ldots,n-1")#text(".")

#text("Observe that ")#mi("\\sum_{k=0}^{n-1} q_k \\leq n \\max_{0 \\leq k \\leq n-1} q_k")#text(". Therefore,")

#text("4.1 \"")#mi("q_k \\ll n^{-1}2^{-cn}")#text(" for each ")#mi("k=0,\\ldots, n-1")#text("\" if, and only if,")

#text("4.2 \"")#mi("\\max_{0 \\leq k \\leq n-1} q_k \\ll n^{-1}2^{-cn}")#text("\" which implies")

#text("4.3 ")#mi("\\sum_{k=0}^{n-1} q_k \\ll 2^{-cn}")#text(".")

#text("Maybe there is a key property I have missed, but as far as I can see it is not sufficient to show that ")#mi("q_k \\ll 2^{-cn}")#text(" for each ")#mi("0 \\leq k \\leq n-1")#text(". If ")#mi("c \\approx 0")#text(", then ")#mi("n")#text(" must be a huge number for ")#mi("n2^{-cn}")#text(" to be very small. Remember that You also consider that ")#mi("n")#text(" is much smaller than ")#mi("\\log N")#text(".")

#text("Best regards,")#linebreak()#text(" A Patriota.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-542520")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2020")])]

#text("Yes, using the conventions of the paper one has ")#mi("a_{[1,0]}=0")#text(". The notation ")#mi("\\ll")#text(" (")#link("https://en.wikipedia.org/wiki/Big_O_notation#History_(Bachmann%E2%80%93Landau,_Hardy,_and_Vinogradov_notations)")[#text("Vinogradov notation")]#text(") is explained in the first paragraph of Section 2; it does not mean “much smaller than”, but rather “bounded by a constant multiple of”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a5b2d76ebfce36073e62eadb1921645a199999d16bfa6286603e8e87f76e47ca-288d33660e7e851b455351225108187cc04065b9a8abd15fb25150170e31a745.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexandre")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-542529")[#strong[#text("Alexandre")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2020")])]

#text("Thanks. I’ve realized that right after posting and I couldn’t edit it. You’re right, in fact the probability is 1/2 after conditioning on ")#mi("\\mathbf{a}_1 + \\mathbf{a}_2 = 3")#text(". Thanks again.")

#text("However, steps 4.1 – 4.3 above seem to be valid for the “bounded by a constant multiple of” definition. You have to deal with n terms ")#mi("q_0,\\ldots,q_{n-1}")#text(" where some of them depend on n, don’ t you?")

#text("Sorry to take your time on these small things. I need to understand Lemma 4.1 and Proposition 1.9 because they will be helpful for my own work.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-543204")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2020")])]

#text("A bound of the form ")#mi("q_k \\ll 2^{-cn}")#text(" implies the apparently stronger bound ")#mi("q_k \\ll n^{-1} 2^{-c^{\\prime} n}")#text(" as long as the new constant ")#mi("c^{\\prime}")#text(" is smaller than the original constant ")#mi("c")#text(", because the sequence ")#mi("2^{-cn} / (n^{-1} 2^{-c^{\\prime} n}) = n 2^{-(c-c^{\\prime}) n}")#text(" is uniformly bounded in ")#mi("n")#text(". So the (lower order) polynomial factor ")#mi("n^{-1}")#text(" can be obtained “for free” by slightly weakening the (higher order) exponential factor ")#mi("2^{-cn}")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce7cf5c2649720f46362a8172fa9c05b501c595e39d94bade6ec54b1a919b77f-d4e815c4bed2e8874f7ed1694c217ac36f3e9c2e422f7278a7a8fbfb8bc5e271.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexandre")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-543681")[#strong[#text("Alexandre")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2020")])]

#text("I got it:")

#text("“recall we allow c to vary even within the same line”")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce7cf5c2649720f46362a8172fa9c05b501c595e39d94bade6ec54b1a919b77f-d4e815c4bed2e8874f7ed1694c217ac36f3e9c2e422f7278a7a8fbfb8bc5e271.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexandre")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-543691")[#strong[#text("Alexandre")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2020")])]

#text("Some more small typos I came across so far:")

#text("1. Formula (6.2) ")#mi("\\mathbf{a}_{[i+i, j]}")#text(" should be ")#mi("\\mathbf{a}_{[i, j]}")

#text("2. Formula (7.29) ")#mi("j=\\mathbb{N}")#text(" should be ")#mi("j \\in \\mathbb{N}")

#text("I am still reading your paper and trying to get in the proofs as much as I can. Number theory is not my field of expertise, but I am very interested because of the probabilistic results.")

#text("I am having some insights from it. I noted there is a way to get more information from the properties of the Syracuse random variables.")

#text("thanks a lot.")

#text("A. Patriota")

#emph[#text("[Thanks, these corrections will be appear in the next revision of the ms – T.]")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce7cf5c2649720f46362a8172fa9c05b501c595e39d94bade6ec54b1a919b77f-d4e815c4bed2e8874f7ed1694c217ac36f3e9c2e422f7278a7a8fbfb8bc5e271.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexandre")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-543920")[#strong[#text("Alexandre")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2020")])]

#text("3. in Formula (5.3), I guess it should be ")#tao-math("\\mathbb{P}(\\left|Geom(2)^{n_0}\\right| \\leq 1.9 n_0)", block: false)#text(" rather than ")#tao-math("\\mathbb{P}(\\left|Geom(2)^{n}\\right| \\leq 1.9 n_0)", block: false)#text(".")

#text("It seems you could’ve taken the value ")#mi("(2-\\epsilon)")#text(", for any ")#mi("0<\\epsilon < 2")#text(", instead of 1.9. I know it is not relevant for that argument in your manuscript, but it will be important for me. If you'd like to see why, I can send you in private.")

#text("A. Patriota.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. Yes, for my argument the 1.9 could have been replaced by any constant ")#mi("2-\\varepsilon")#text(" with ")#mi("\\varepsilon > 0")#text(" and ")#mi("2^{2-\\varepsilon} > 3")#text("; the 1.9 is chosen purely for sake of concreteness. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce7cf5c2649720f46362a8172fa9c05b501c595e39d94bade6ec54b1a919b77f-d4e815c4bed2e8874f7ed1694c217ac36f3e9c2e422f7278a7a8fbfb8bc5e271.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexandre")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-545728")[#strong[#text("Alexandre")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2020")])]

#text("3. On the bottom of pg 18: “This constrains ")#mi("\\mathbf{N}")#text(" to a single odd residue class module ")#tao-math("2^{\\left|\\vec{a}\\right|+1}", block: false)#text("“. Please verify if it should be ")#tao-math("2^{\\left|\\vec{a}\\right|}", block: false)#text(" instead of ")#tao-math("2^{\\left|\\vec{a}\\right|+1}", block: false)#text(". Thanks.")

#text("A. Patriota")

#emph[#text("[I believe the text is correct as it stands – T.]")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d0dd964420144787f9d209f75be4baf0bab94b09d991337738ebaba017019cb-38b948e34a9081b95ea4790c5093046016cbea55574521c741b1679cae742d92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-542895")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2020")])]

#text("Terence Tao,I hope you will answer me. Riho Terras (1979), On the existence of a density, Acta Arithmetica 35 (1979), 101–102. (MR 80h:10066).")

#text("This paper supplies additional details concerning the proof in Terras (1976) that the set of integers having an infinite stopping time has asymptotic density zero. The proof in Terras (1976) had been criticized by Möller (1978). In a note added in proof the author asserts that the proofs of Terras (1976) are faulty.")

#text("What do you think about? in the interval $[1,n]$ Is the natural density of all possible counter-examples zero?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-543207")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2020")])]

#text("Note that Terras’s definition of a “stopping time” is the first time in which the iterate drops below the initial value; it should not be confused with the first time in which the iterate attains the value 1. Certainly any number ")#mi("n > 1")#text(" that has an infinite stopping time will be a counterexample to Collatz, but the converse is not true; one can potentially imagine a counterexample to Collatz whose orbit initially drops below its starting value (thus leading to a finite stopping time), before going to infinity. (However, it is true, that if a counterexample to Collatz exists, then the smallest such counterexample will have infinite stopping time.)")

#text("Terras’s argument (as corrected in 1979) does indeed show that the natural density of numbers with infinite stopping time is zero; these results have been improved since by Allouche, Korec, and in my own paper. However, none of these results imply that the natural density of numbers that are counterexamples to Collatz (which is potentially a larger set) is also zero. I discuss this a bit further in Remark 1.4 of my own paper.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d0dd964420144787f9d209f75be4baf0bab94b09d991337738ebaba017019cb-38b948e34a9081b95ea4790c5093046016cbea55574521c741b1679cae742d92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lone student")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-543260")[#strong[#text("lone student")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2020")])]

#text("Thank you for being kind and answering me. In the meantime, I apologize for the absence of the word “Mr” against your name. I’m new to WordPress. I could not edit the comment. I use it for the first time. Whether it is diverge to infinity or cyclic, any counterexample will have “infinity” stopping time. So every non-finite loop, which does not give result “1-4-2-1”, is actually infinite. And as you said, any counter example really will have a very large set. This is the conclusion I got from your answer:")

#text("Exact Question: In the interval [1,n] is the natural density of all possible counter-examples for the Collatz Conjecture, zero?")

#text("Exact Answer: NO.")

#text("Do you confirm my conclusion? Did I understand your answer correctly?")

#text("Thank you very much! And I am also sorry for English grammar.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab23616eeed6444782611c800d768c38d728cf7302ca5fea4e47188e21870f35-f58b42aa3a6aeadc106d11a96f0b4ec8c1ec8dd3882b22348bc7336f558eb991.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-544541")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2020")])]

#text("why discuss something if there is proving of a problem")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/288fa31bf478372d131a0aa71cd87e53dcfe64fd33101796f2290a4ebb6d8d19-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-545539")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2020")])]

#text("Another dynamic equivalent to the Collatz conjecture.")

#mi("6x_{0}\\rightarrow 6x_{k}")

#text("where all ")#mi("x_{0}=n \\rightarrow ... \\rightarrow x_{k-1}= 2 \\rightarrow x_{k}=0")#text(",")

#text("the 6 multiplicative table.")

#text("This dynamic is a kind Syracuse-map, but instead of being")

#mi("odd \\rightarrow odd")

#text("it is of the form")

#mi("x\\equiv 4(mod6)\\rightarrow x\\equiv 4(mod6)")

#mi("even\\equiv 1(mod3)\\rightarrow even\\equiv 1(mod3)")

#text("these numbers are of the form ")#mi("4 + 6x")#text(" and in recurrence we can do without constant 4 and the map is")

#mi("6x_{0} \\rightarrow 6x_{1}")

#text("the table of 6.")

#text("Some examples:")

#mi("10=4+6\\times 1\\rightarrow 16= 4+6\\times 2\\rightarrow 4= 4+6\\times 0")

#mi("64=4+6\\times 10\\rightarrow 16= 4+6\\times 2\\rightarrow 4= 4+6\\times 0")

#mi("22=4+6\\times 3\\rightarrow 34= 4+6\\times 5\\rightarrow 52=4+6\\times 8\\rightarrow 40=4+6\\times 6\\rightarrow 10=4+6\\times 1\\rightarrow 16= 4+6\\times 2\\rightarrow 4= 4+6\\times 0")

#text("This same reformulation is applicable to a ")#mi("3n-1")#text(" map, which would be ")#mi("2 + 6x \\rightarrow 2 + 6x")#text(", with a different dynamic, or to a ")#mi("5n + 1")#text(" map, which would be ")#mi("6 + 10x \\rightarrow 6 + 10x")#text(", the table of 10, although I have not delved into these dynamics so far.Nor do I know if these equivalent dynamics have already been studied or represent something new.")

#text("The dynamics work in the following way:")

#text("Direct map ")#mi("n \\rightarrow ... \\rightarrow 1")#text(",")

#text("in our case from")

#mi("x_{0}=n \\rightarrow ... \\rightarrow 2 \\rightarrow 0")

#mi("x_{0}\\, odd \\rightarrow  x_{1} = \\frac{3x_{0}+1}{2}")

#mi("x_{0}\\, even \\rightarrow")

#mi("\\rightarrow x_{0}\\equiv 0(mod4)4,8,12,16,... \\rightarrow x_{1} = \\frac{3x_{0}}{4}")

#mi("\\rightarrow x_{0}\\equiv 0(mod2)2,6,10,14,... \\rightarrow x_{1} = \\frac{x_{0}-2}{4}")

#text("Inverse map ")#mi("1 \\rightarrow ... \\rightarrow n")#text(",")

#text("in our case from")

#mi("0 \\rightarrow 2 \\rightarrow n")

#text("Function 1 : ")#mi("x_{0}\\, odd\\equiv 1(mod6) 1,7,13,19,... \\rightarrow x_{1}= 4x_{0}+2")#text(" generate (6,30,54,78,…)")

#mi("x_{0}\\, odd\\equiv 3(mod6)3,9,15,21,...\\rightarrow")

#text("Function 2 : ")#mi("\\rightarrow x_{1}= 4x_{0}+2")#text(" generate (14,38,62,86,…)")

#text("Function 3 : ")#mi("\\rightarrow x_{1}= \\frac{4x_{0}}{3}")#text(" generate (4,12,20,28,36,44,…)")

#mi("x_{0}\\, odd\\equiv 5(mod6)5,11,17,23,...\\rightarrow")

#text("Function 4 : ")#mi("\\rightarrow x_{1}= 4x_{0}+2")#text(" generate (22,46,70,94,…)")

#text("Function 5 : ")#mi("\\rightarrow x_{1}= \\frac{2x_{0}-1}{3}")#text(" generate (3,7,11,15,…)")

#mi("x_{0}\\, even\\equiv 0(mod6)0,6,12,18,...\\rightarrow")

#text("Function 6 : ")#mi("\\rightarrow x_{1}= 4x_{0}+2")#text(" generate (2,26,50,78,…)")

#text("Function 7 : ")#mi("\\rightarrow x_{1}= \\frac{4x_{0}}{3}")#text(" generate (0,8,16,24,32,…)")

#mi("x_{0}\\, even\\equiv 2(mod6)2,8,14,20,...\\rightarrow")

#text("Function 8 : ")#mi("\\rightarrow x_{1}= 4x_{0}+2")#text(" generate (10,34,58,82,…)")

#text("Function 9 : ")#mi("\\rightarrow x_{1}= \\frac{2x_{0}-1}{3}")#text(" generate (1,5,9,13,…)")

#text("Function 10 : ")#mi("x_{0}\\, even\\equiv 4(mod6)4,10,16,22,...\\rightarrow x_{1}= 4x_{0}+2")#text(" generate (18,42,66,90,…)")

#text("Inverse map functions 5 and 9 generate odd numbers in apparent order, functions 1,2,3,4,6,7,8,10 generate even numbers, also in an orderly and uniform manner, which leads me to think that from ")#mi("4 + 6 \\times 0")#text(" we can generate all ")#mi("4 + 6 \\times n")#text(" and equivalently, that from 4 on the inverse map of Collatz all N can be generated, then all N would reach 4-2-1.")

#text("I certainly do not know if this dynamic represents a new way of attacking the problem, much less if it is appropriate or even simpler, although it does not seem so. In the absence of further study, I ask for your help and advice to know if you think it is an appropriate path or if some techniques can be applied, beyond my reach, a satisfactory result could be reached to rule out the existence of periodic orbits or unbounded orbits. Sincerely. Thank you.")

#text("*Please forgive me it latex fails")

#link("https://drive.google.com/file/d/1SJp1oYSKr6CtvTyd-Gufa3YahkV92_4G/view?usp=sharing")[#text("https://drive.google.com/file/d/1SJp1oYSKr6CtvTyd-Gufa3YahkV92_4G/view?usp=sharing")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61fe96948c5a63ccf3c158b300059337fefc1b16d8fbf0668f70f40339d67920-a25a80f8fc491e04880f184c06eb5c36e7e752dcd9b0302f8e601cd1ac85960c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gottfried H")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-545812")[#strong[#text("Gottfried H")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2020")])]

#text("In the style of the syracuse-notation it is easy to see that it is a conjugacy: instead of ")#mi("x_{k+1}= (3x_k+1)/2^A")#text(" we have ")#mi("y_{k+1}= (y_k/2^A)*3+1")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/288fa31bf478372d131a0aa71cd87e53dcfe64fd33101796f2290a4ebb6d8d19-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-545927")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2020")])]

#text("On unbounded orbits, those that escape to infinity.")

#text("On these orbits, in the study of the worst possible orbits, it seems that these have the shape of a ")#mi("Col_{2}")#text(" map ")#mi("n\\rightarrow \\frac{3n+1}{2}= n+\\frac{n+1}{2}")#text(", where for each odd step, there is a single even step, and the sequence works ")#mi("Odd\\rightarrow Odd")#text(".")

#text("Have we an answer to the fact that this process is repeated indefinitely for some n?")#linebreak()#text(" or is it known that for all n this process is not repeated indefinitely?")

#text("I don’t know if we have already the answer, but it seems that the answer could be yes, that for all n, the worst map ")#mi("Col_{2}")#text(" cannot be kept indefinitely and at some point, the number of even steps always increases by at least one more step than odd step every recursion cycle that results in an even number, and this increment accumulates. This means that when ")#mi("k=odd steps")#text(", increases infinitely, the distance between ")#mi("x=even steps")#text(", also increases infinitely ")#mi("x-y \\rightarrow \\infty")#text(" and would justify that ")#mi("2^{x}\\ll 3^{k}")#text(" for the worst of the orbits, and that for the Collatz recursion of the form")

#mi("n\\times \\frac{3^{k}}{2^{x}}+\\frac{3^{k-1}+3^{k-2}\\times 2^{a1}+...+2^{k-1}}{2^{x}}")

#text("ignoring at the moment ")#mi("\\frac{3^{k-1}+3^{k-2}\\times 2^{a1}+...+2^{k-1}}{2^{x}}")#text(" and the fact that it can enter periodic orbit,")

#mi("2^{x}\\gg 3^{k}")#text(" , and ")#mi("\\frac{3^{k}}{2^{x}}\\ll 1")#text(" and ")#mi("n\\times \\frac {3^{k}}{2^{x}}< n")

#text("For the study of the worst orbits we use the ")#mi("Col_{2}")#text(" map")

#mi("Odd\\rightarrow Odd\\rightarrow ...\\rightarrow Even ?")

#text("To find out if we always find an even number, for the worst orbit, over the set of odd numbers 3,5,7,9,11,13,15,17,… and the values for the worst possible orbit")

#mi("3^{k}-2^{k}= 3^{k-1}+3^{k-2}\\times 2^{a1}+...+2^{k-1}")#text(", the Notable Product Difference Nth powers, and we will discard those numbers that give even solutions for the worst possible orbit.")

#text("For")

#mi("\\frac {3n+1}{2}\\rightarrow 3,7,11,15,19,...")#text(" give odd solutions")

#mi("\\frac {3^{2}n+ (3^{2}-2^{2})}{4}\\rightarrow 7,15,23,31,...")#text(" give odd solutions")

#mi("\\frac {3^{3}n+ (3^{3}-2^{3})}{8}\\rightarrow 15,31,47,63...")#text(" give odd solutions")

#mi("\\frac {3^{4}n+ (3^{4}-2^{4})}{16}\\rightarrow 31,63,95,127...")#text(" give odd solutions")

#text("…")

#text("This recursion is maintained indefinitely and although the solution sets are infinite, the cardinality of the set seems to decrease and it also seems to indicate that for all n there is a moment when the set of numbers in the recursions finds an even number, even after a very large number of iterations which is only divided once by 2, and the worst possible orbit is bounded for all n in each cycle")

#mi("Odd\\rightarrow Odd\\rightarrow...\\rightarrow Even")

#text("and the values of ")#mi("x= even steps")#text(", is greater than ")#mi("k = odd steps")#text(" and")

#text("although the distance ")#mi("x-k")#text(" can grow very slowly")

#text("when ")#mi("k \\rightarrow \\infty")#text(", ")#mi("x-k \\rightarrow \\infty")

#text("and would justify that")

#mi("\\frac{3^{k}}{2^{x}}< 1")#text(" and for")

#mi("n\\times \\frac{3^{k}}{2^{x}} 3^{k}")#text(" and")

#mi("n\\times \\frac{3^{k}}{2^{x}}< n")#text(" for all n?")

#text("Or less or equal if it reaches a multiple of n?")

#text("Sincerely, thank you.")

#link("https://drive.google.com/file/d/1CrtqDEWmqufcOE3LFS6UJMv1mn7VcFE0/view?usp=sharing")[#text("https://drive.google.com/file/d/1CrtqDEWmqufcOE3LFS6UJMv1mn7VcFE0/view?usp=sharing")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/288fa31bf478372d131a0aa71cd87e53dcfe64fd33101796f2290a4ebb6d8d19-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-545933")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2020")])]

#mi("Odd\\rightarrow Odd\\rightarrow...\\rightarrow Even")

#text("and the values of ")#mi("x= even steps")#text(", is greater than ")#mi("k = odd steps")#linebreak()#text(" and although the distance ")#mi("x-k")#text(" can grow very slowly,")

#text("when ")#mi("k \\rightarrow \\infty")#text(", ")#mi("x-k \\rightarrow \\infty")

#text("and would justify that ")#mi("\\frac{3^{k}}{2^{x}}< 1")#text(" and for")

#mi("n\\times \\frac{3^{k}}{2^{x}} 3^{k}")#text(" and ")#mi("n\\times \\frac{3^{k}}{2^{x}}< n")#text(" for all n?")

#text("Or less or equal if it reaches a multiple of n?")

#text("Sincerely, thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/288fa31bf478372d131a0aa71cd87e53dcfe64fd33101796f2290a4ebb6d8d19-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-545942")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2020")])]

#text("**Third try")

#mi("Odd\\rightarrow Odd\\rightarrow...\\rightarrow Even")

#text("and the values of ")#mi("x= even steps")#text(", is greater than ")#mi("k = odd steps")

#text("and although the distance ")#mi("x-k")#text(" can grow very slowly")

#text("when ")#mi("k \\rightarrow \\infty")#text(", ")#mi("x-k \\rightarrow \\infty")

#text("and would justify that ")#mi("\\frac{3^{k}}{2^{x}}< 1")#text(" and for")

#mi("n \\times \\frac{3^{k}}{2^{x}} 3^{k}")#text(" and ")#mi("n\\times \\frac{3^{k}}{2^{x}}< n")#text(" for all n?")

#text("Or less or equal if it reaches a multiple of n?")

#text("Sincerely, thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/288fa31bf478372d131a0aa71cd87e53dcfe64fd33101796f2290a4ebb6d8d19-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-545943")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2020")])]

#text("**So sorry")

#text("Is there an explicit way to calculate that for all n, in a ")#mi("Col_{2}")#text(" recursion for the worst possible orbit? we always find an even value? I do not know if there is already an answer to this question, and it is enough to justify the statement that all orbits are bounded, even so, it seems, according to my observations, that it could be of the form:")

#mi("n\\rightarrow n+\\frac{n+1}{2}= n+\\frac{2^{x}\\times y}{2}\\rightarrow ...\\rightarrow n+y\\times (3^{x}-2^{x})= EVEN")

#text("If this condition is true for all n, and all the worst ")#mi("Col_{2}")#text(" orbits are bounded, in the sense that they always find an even number, and almost is divided by 2 more than one time after a number of iterations ")#mi("Odd\\rightarrow Odd")

#text("Is it sufficient to affirm that when ")#mi("k \\rightarrow \\infty")#text(", ")#mi("x-k \\rightarrow \\infty")#text(" and ")#mi("2^{x}> 3^{k}")#text(" and ")#mi("n\\times \\frac{3^{k}}{2^{x}}< n")#text(" for all n?")

#text("Or less or equal if it reaches a multiple of n?")

#text("Sincerely, thank you.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-546072")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2020")])]

#text("Is it possible to get more information on the Collatz iteration by defining also a notion of “entropy” for this map (as done e,g, in the recent solution of Erdos discrepancy problem) ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ebe8e128bc91eec28cccf42eff4db42a08632630b08c92d46086147b379f19a-274507f1dc5cfdb21b9c916b6a3b9279e9f88bccfde8e345b41275ace08d083f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lz2263546927")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-550226")[#strong[#text("lz2263546927")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2020")])]

#text("Constructing Integer Ring Transformation：")#linebreak()#text(" 1.")#linebreak()#text(" n,d∈Z")#linebreak()#text(" x=3n+d")#linebreak()#text(" y=3n-d")#linebreak()#text(" z=n/2")#linebreak()#text(" 2.")#linebreak()#text(" ①n∈Z+,d∈Z+ ②n=0,d=0 ③n∈Z-,d∈Z-")

#text("x=3n+d x=3×0+0 x=3n-d")#linebreak()#text(" ⇆ ⇆")#linebreak()#text(" y=3n-d y=3×0-0 y=3n+d")

#text("z=n/2 z=0/2 z=n/2")

#text("(1)n∈Z+,d∈Z+")#linebreak()#text(" 【1】(3×1+d1-1)/3=(3×1-d1)/2，")#linebreak()#text(" d1=1；")#linebreak()#text(" (3×1-d2-1)/3=(3×1+d2)/2，")#linebreak()#text(" d2=-1.")#linebreak()#text(" 【2】(3×1-d3)/2=2(3×1+d 3)，")#linebreak()#text(" d3=9/5；")#linebreak()#text(" (3×1+d4)/2=2(3×1-d4)，")#linebreak()#text(" d4=-9/5.")#linebreak()#text(" 【3】3(3×1-d5)+1=2(3×1+d5)，")#linebreak()#text(" d5=4/5；")#linebreak()#text(" 3(3×1+d6)+1=2(3×1-d6)，")#linebreak()#text(" d6=-4/5.")#linebreak()#text(" If d=1, x2=4, y2=2, topological cycle A=(4, 2, 1, 4) can be obtained. according to the transformation rule, if topological fixed point n=1, x4=3×1+1=4, y4= 3×1-1=2, topological cycle S=(4, 2, 1, 4)=A can be obtained, so S is homeomorphic to A, so topological cycle (A, A) can be obtained, so A is a single connected domain, so 3n+1 transformation on positive integer rings has and only topological cycle A⇆A.")

#text("(2)n∈Z-,d∈Z-")#linebreak()#text(" 〈1〉From (1), it can be seen that this transformation is equivalent to (1) when n=-1, so d=-1, x5=-2, y5=-4, the topological cycle B=(-1, -2, -1) can be obtained. Because of -4∉B, so n=-1 is not a topological fixed point and does not satisfy the transformation rule, so the topological fixed point n=-2 is taken.")#linebreak()#text(" 〈2〉")#linebreak()#text(" 【1】[3×(-2)-d7-1]/3=[3×(-2)+d7]/2,")#linebreak()#text(" d7=4/5；")#linebreak()#text(" [3×(-2)+d8-1]/3=[3×(-2)-d8]/2，")#linebreak()#text(" d8=-4/5.")#linebreak()#text(" 【2】[3×(-2)-d9]/2=2[3×(-2)+d9]，")#linebreak()#text(" d9=18/5；")#linebreak()#text(" [3×(-2)+d10]/2=2[3×(-2)-d10]，")#linebreak()#text(" d10=-18/5.")#linebreak()#text(" 【3】3[3×(-2)+d11]+1=2[3×(-2)-d11],")#linebreak()#text(" d11=1；")#linebreak()#text(" 3[3×(-2)-d12]+1=2[3×(-2)+d12]，")#linebreak()#text(" d12=-1.")#linebreak()#text(" If d=-1, x6=-5, y6=-7, the topological cycle C=(-5, -14, -7, -20, -10, -5) can be obtained. According to the transformation rule, the topological fixed point n=-14 is taken.")#linebreak()#text(" 〈3〉")#linebreak()#text(" 【1】[3×(-14)-d13-1]/3=[3×(-14)+d13]/2,")#linebreak()#text(" d13=8；")#linebreak()#text(" [3×(-14)+d14-1]/3=[3×(-14)-d14]/2，")#linebreak()#text(" d14=-8.")#linebreak()#text(" 【2】[3×(-14)-d15]/2=2[3×(-14)+d15],")#linebreak()#text(" d15=126/5；")#linebreak()#text(" [3×(-14)+d16]/2=2[3×(-14)-d16]，")#linebreak()#text(" d16=-126/5.")#linebreak()#text(" 【3】3[3×(-14)+d17]+1=2×[3×(-14)-d17]，")#linebreak()#text(" d17=41/5；")#linebreak()#text(" 3[3×(-14)-d18]+1=2[3×(-14)+d18]，")#linebreak()#text(" d18=-41/5.")#linebreak()#text(" If d=-8, x7=-34, y7=-50, the topological cycle D=(-34, -17, -50, -25, -74, -37, -110, -55, -164, -82, -41, -122, -61, -182, -91, -272, -136, -68, -34) can be obtained. According to the transformation rule, the topological fixed point n=-17 is taken.")#linebreak()#text(" 〈4〉")#linebreak()#text(" 【1】[3×(-17)-d19-1]/3=[3×(-17)+d19]/2，")#linebreak()#text(" d19=49/5；")#linebreak()#text(" [3×(-17)+d20-1]/3=[3×(-17)-d20]/2，")#linebreak()#text(" d20=-49/5.")#linebreak()#text(" 【2】[3×(-17)-d21]/2=2[3×(-17)+d21]，")#linebreak()#text(" d21=153/5；")#linebreak()#text(" [3×(-17)+d22]/2=2[3×(-17)-d22]，")#linebreak()#text(" d22=-153/5.")#linebreak()#text(" 【3】3[3×(-17)+d23]+1=2[3×(-17)-d23]，")#linebreak()#text(" d23=10；")#linebreak()#text(" 3[3×(-17)-d24]+1=2[3×(-17)+d24]，")#linebreak()#text(" d24=-10.")#linebreak()#text(" If d=-10, then x8=-41, y8=-61, the topological cycle E=(-41, -122, -61, …, -41)=D can be obtained, so E is homeomorphic to D, so the topological cycle (D, D) can be obtained, so D is a simple connected domain, so B, C, D are homotopy, so 3n+1 transformation on negative integer rings has 3 topological cycles：(B⇆B)⇆(C⇆C)⇆(D⇆D)。")#linebreak()#text(" From the integer ring transformation, it can be seen that 3n+1 transformation on the whole ring has 5 topological cycles, where 0 is defined as an even number and 0⇆0 is a singular topological cycle, and there are：(A⇆A)⇆(0⇆0)⇆(B⇆B)⇆(C⇆C)⇆(D⇆D)。")

#text("​")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38e8dfb6208152fed8b96138094512f6c94d8de25e440163827f571e21c1ca46-a0bd0de8c75b24dec726533ad676152c8cd3a96b9f2b4e5e5c0a5df87be19764.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aran")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-550361")[#strong[#text("Aran")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2020")])]

#text("Dear Mr. Tao and readers,")

#text("I have found a function that seems to measure the distance between any odd number to the even number with an identical “sequence”. By sequence I mean two properties:")

#text("– The number of arithmetic steps until the cycle 4,2,1 is reached is equal. Also called “height of n”.")#linebreak()#text(" – The series of numbers of the odd and even n have identical values. Also called “trajectory”.")

#text("Unfortunately, I am not even aware if this is something trivial, well known or new. A mentor advised me to contact Mr. Tao about this. It seems Mr. Tao has no capacity, which is why I am inclined to not write directly and in his forum instead.")

#text("With best regards.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95aa8235e567dad521c9f1132fc7de84ef477ed98f2abf5eb86a441b0200d189-18d0e3b4a7843c349a4fb679aa4e0be206ee5c2a79dcd804922b3597d9f450a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-553705")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2020")])]

#text("It’s quite remarkable that the key insight for discrete dynamic eventually comes from the PDE world. Perhaps the other way round, e.g. hard PDE problems like Navier-Stocks can benefit from a reformulation in terms of discrete dynamics? It seems that that’s what Stephen Wolfram has been doing all along, e.g. deriving fluid equation from cellular automaton dymaics: ")#link("https://www.stephenwolfram.com/publications/academic/cellular-automaton-fluids-theory.pdf")[#text("https://www.stephenwolfram.com/publications/academic/cellular-automaton-fluids-theory.pdf")]#text(" His recent work go as far as to claim that basically all fundamental physics should follow from a discrete dynamics: ")#link("https://writings.stephenwolfram.com/2020/04/finally-we-may-have-a-path-to-the-fundamental-theory-of-physics-and-its-beautiful/")[#text("https://writings.stephenwolfram.com/2020/04/finally-we-may-have-a-path-to-the-fundamental-theory-of-physics-and-its-beautiful/")]#text(" What’s your thoughts on this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-553766")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2020")])]

#text("My thoughts on the analogy between fluid equations and cellular automata may be found at Section 1.3 of my paper ")#link("https://arxiv.org/abs/1402.0290")[#text("https://arxiv.org/abs/1402.0290")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e7bf75c668be18a7e671c946e67cb33d97edb902795f22cf86179c99efc6378-0d6d96e4350f1df00ec4ffa5dfcc48f40c36198c9871d7a84c523f4f5f4bf6cf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-553748")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2020")])]

#text("“A Poincaré map can be interpreted as a discrete dynamical system with a state space that is one dimension smaller than the original continuous dynamical system.” The CC is extremely amenable to simplification using a first recurrence map applied to the odd numbers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa2493b2f4d4f2d4a97d560e824316ccb3abf1eeffc8e75ce5435f56a208f98e-6e04b2a21f766855436d06dc9e49a1ab69e8c7d3d5571f23b7cc4846f78f0b36.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabien")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-553820")[#strong[#text("Fabien")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2020")])]

#text("There is a remarkable property in the collatz conjecture : It’s possible to group all numbers in a two coordinate system : the first is the number of time x3+1 has been used and the second the number of dividing by 2. If you draw that you get for each number a little group of number (logarithmic on Y axe) :")

#link("https://fabiensabinet.files.wordpress.com/2020/04/coordcollatz.png")[#image("../assets/7e8c17d07957ec8ae85e88a416821f395a322113bc060e3ce25d1af250d7e880-bcb67cec48e2ce0f0a60a86f3ecfcde3c1ad877cabfbcd63059e07ef2c9b8fa7.png", width: 90%)]

#text("Now the fun part : if you animate all the number of a coordinate, let say for example the [3, 20] (so all the number obtained with 3 times 3x+1 and 20 times divide by 2) which have 40 numbers you get a sort of “enumeration” that look surprisingly like a “count system” :")

#link("https://fabiensabinet.files.wordpress.com/2020/04/animsyracuse.gif")[#image("../assets/b47d6e0d57a356417d69abc5b5dbccac02c6a5489dfb50a361f8c630cd5195c1-740bba590664ff73737744bfe50aab6245764cec357005c6ace145b6aca42cc0.gif", width: 90%)]

#text("I have the intuition that it’s “easy” to find a formula to that enumeration and that if we “sum” all the numbers in all coordinate we simply find the N ensemble. I do not have the mathematical background to do that but the idea is here I think.")

#text("Good luck for the first one who will win the run ! :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa2493b2f4d4f2d4a97d560e824316ccb3abf1eeffc8e75ce5435f56a208f98e-6e04b2a21f766855436d06dc9e49a1ab69e8c7d3d5571f23b7cc4846f78f0b36.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabien")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-553845")[#strong[#text("Fabien")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2020")])]

#text("With the 38656 between 38682 and 38720 it’s better (ordered by the number of the group is not always correctly showing the “counting system”) :")

#link("https://fabiensabinet.files.wordpress.com/2020/04/collatz3_20group.gif")[#image("../assets/1d802a21a165232cb4dd03829b29432afc08747d9d7845f1feeff9e0eb8f1fb3-f30d29eec11ee22d0abaca87ba1f4e03ec644a69da50e96b82efa59276211698.gif", width: 90%)]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/835dd450efb680dd1fd1845fa0c696bf663806532fd0224180184662ab328491-741183bc16dcf5dd100be2cc171423f4b726d79dc63d0a984adb60e6b6147300.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maria")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-556437")[#strong[#text("Maria")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("I guess what are the purple numbers on the bottom line, power of 2 of each column, but what’s the divider at the end, 27 ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa2493b2f4d4f2d4a97d560e824316ccb3abf1eeffc8e75ce5435f56a208f98e-6e04b2a21f766855436d06dc9e49a1ab69e8c7d3d5571f23b7cc4846f78f0b36.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabien")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-556452")[#strong[#text("Fabien")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("Maria, it’s the global divider in the interesting (I find) Collatz equation form :")

#link("https://fabiensabinet.files.wordpress.com/2020/05/formulacollatz.png")[#image("../assets/d39da2e4921adf38bfa10d1d1ed5fbc3ac0f2c0b0d50675ca8344905425f3336-62b5792ed9129bc27c43d19ce171fc7e65426f1f4199af3a1841915c4451a2cc.png", width: 90%)]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/835dd450efb680dd1fd1845fa0c696bf663806532fd0224180184662ab328491-741183bc16dcf5dd100be2cc171423f4b726d79dc63d0a984adb60e6b6147300.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maria")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-556470")[#strong[#text("Maria")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("so 3^x with x the number of *3+1.")#linebreak()#text(" Nice general form of the equation.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c5a31821d958d49b7000f137fd3caf26bb35b691b3abdb00877e6de153bfd9e-09624cb2cb6fee633dd35bd794b699ee68563d244cd02f2454335292c9f4bebf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Houdini")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-556231")[#strong[#text("Houdini")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2020")])]

#text("Interesting & original (& nice to see animated !) point of view, good to identify “groups” in the structure, but still I think it will not be as you think an “almost done job” with it and just a “little run” left to do…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa2493b2f4d4f2d4a97d560e824316ccb3abf1eeffc8e75ce5435f56a208f98e-6e04b2a21f766855436d06dc9e49a1ab69e8c7d3d5571f23b7cc4846f78f0b36.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabien")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-556421")[#strong[#text("Fabien")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("Thanks Houdini. But even if it’s true that I realise now that it’s not so simple, I still have the feeling that those group of numbers corresponding to [count of x3+1, count of dividing by 2] is a key to solve that problem (a simple solution, which makes it the One in The book for the Collatz problem ;) )")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-554061")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2020")])]

#text("Collatz conjecture would be discribable by something like representation theory. Actually, there is permutation group of S_3 acting on the syracuse inverse mapping for solving pigeonhole “problem”. and I use matrices like Young diagram to show partition of residues of 2N_0+1/〇Z.")

#text("Then think the inverse mapping as generating series of all 2N_0+1;")#linebreak()#text(" f^-(1+μ) {●}.")#linebreak()#text(" where {●} is generator(s). then it can gives such inequality(s) (very simply);")#linebreak()#text(" f^-(1+μ) {●} ＜ {●} ≤ f^-(1+μ) {●}.")#linebreak()#text(" the generator(s) itself also belongs to f^-(1+μ) {●}. so “almost all” odd are in RHS except a certain small set.")

#text("Then look at the intersection of the certain small set(LHS) and its generator {●}, we can see that it goes to be null in finite times. In other words, all elements in LHS map to the generator {●} which {●} ∈ RHS in finite times.")

#text("Finally {●} = RHS = 1. Iff the all variables in the equation are 0.")#linebreak()#text(" I think I have found the invariant (like) measure as Professor Tao mentioned. The problem is I am an amateur.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of y.y.")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-554114")[#strong[#text("y.y.")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2020")])]

#text("The structure of the conjecture is able to describe as a certain vector, scalar multiplication/addition, group operation, and set theory. I’m not certain that it is applicable for other problems for example Navier Stolks. Anyway the conjecture has beautiful structure like Cantor set, I would like to show more details if some one gives it rigorous proof and contribute for mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa2493b2f4d4f2d4a97d560e824316ccb3abf1eeffc8e75ce5435f56a208f98e-6e04b2a21f766855436d06dc9e49a1ab69e8c7d3d5571f23b7cc4846f78f0b36.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabien")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-554664")[#strong[#text("Fabien")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2020")])]

#text("Another one ! The group of [x, 15] (so all the numbers obtained with anytime 3x+1 and 15 times divide by 2) which have 50 numbers. Not sure if it’s useful after all but I like very much to look at it, it’s hypnotic :)")

#link("https://fabiensabinet.files.wordpress.com/2020/04/animhlvl15.gif")[#image("../assets/32072bfa10a5052ce860ff1830f46d7c21efcc6910cda3c1615014e0dedd41be-6d0676aceacafbcaac45fbd5c04b5aa07025289ee71f9bed181fd2cfb528cd8a.gif", width: 90%)]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38e8dfb6208152fed8b96138094512f6c94d8de25e440163827f571e21c1ca46-a0bd0de8c75b24dec726533ad676152c8cd3a96b9f2b4e5e5c0a5df87be19764.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aran")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-556447")[#strong[#text("Aran")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("I have also found an interisting property of the collatz conjecture:")#linebreak()#text(" for any odd number my linear function 10+x_n * 17 can describe the even number with the identical trajectory and height of n.")#linebreak()#text(" x_n is the position of all odd numbers in an fix axis: n=1, x_n=-1; n = 3, x_n=0 ; n = 5 , x_n=1; […] ; n = 63.728.127, x_n=31.864.062")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-556478")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("Dynamical systems generated by a simple principle may have a very rich “macroscopic scale” structure (e.g. fractals, or the sequence of primes) but still may have also some “local scale properties” (e.g. Ramanujan’s tau function tau(n) which has a large scale chaotic-like behavior but still has certain interesting small-scale modularity properties).")#linebreak()#text(" Perhaps the Collatz iteration too has such small-scale modularity properties.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e7bf75c668be18a7e671c946e67cb33d97edb902795f22cf86179c99efc6378-0d6d96e4350f1df00ec4ffa5dfcc48f40c36198c9871d7a84c523f4f5f4bf6cf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-556499")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("It maybe that the point your making is more subtle than I understand, but small-scale properties are eliminated by discarding the even numbers. For example:")

#text("Odd-Even")#linebreak()#text(" 43, 130, 65, 196, 98, 49, 148, 74, 37, 112, 56, 28, 14, 7, 22, 11, 34, 17, 52, 26, 13, 40, 20, 10, 5, 16, 8, 4, 2, 1")

#text("Odd-only")#linebreak()#text(" 43, 65, 49, 37, 9, 7, 11, 17, 13, 3, 5, 1")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38e8dfb6208152fed8b96138094512f6c94d8de25e440163827f571e21c1ca46-a0bd0de8c75b24dec726533ad676152c8cd3a96b9f2b4e5e5c0a5df87be19764.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aran")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-556541")[#strong[#text("Aran")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("I sadly made a typing error. My linear formula to find any n_even, if n_odd is given, with the identical trajectory and height of n is:")

#text("10 * x_n + 17=y")

#text("y describes the distance between the odd and even number.")

#text("To find the n_even with you use:")

#text("y + n_odd = n_even")

#text("x_n is the position of all odd numbers in a fix axis:")

#text("n=1, x_n=-1;")#linebreak()#text(" n = 3, x_n=0;")#linebreak()#text(" n = 5 , x_n=1;")#linebreak()#text(" […]")#linebreak()#text(" n = 63.728.127, x_n=31.864.062")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e7bf75c668be18a7e671c946e67cb33d97edb902795f22cf86179c99efc6378-0d6d96e4350f1df00ec4ffa5dfcc48f40c36198c9871d7a84c523f4f5f4bf6cf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-556503")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2020")])]

#text("[you’re] This uses an alternate algorithm that produces, always, the same result.")

#text("a = ((n + 1) * (3 / 2)) – 1")#linebreak()#text(" b = ((n – 1) * (3 / 4)) + 1")#linebreak()#text(" c = (n – 1) * (1 / 4)")

#text("For every odd number n, only a or b or c can be a whole odd number.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-560544")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2020")])]

#text("What if we regard N as a unknown number ,as a combinded probability,to calculate expect of N?")#linebreak()#text(" such as assume N as even number，then N has 1/2 probability be 2*m(m∈ any odd number)，has 1/4 probability be 2^2*m,has 1/8 probability be 2^3*m etc.")#linebreak()#text(" Could it be a direction to solve collatz conjecture,or just totally wrong at begining? I have no idea about it but expecting smart guys reply,Thx!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cce6b79434ec7c0233b9e0aee6cd408396080c6ea44d6fc29985a13b7fa3c03c-cda6bc64bfc0c0812c1000e7c3fa18721920a519a1dc750bb6411f7ce5659b49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Juan C Tejada")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-567286")[#strong[#text("Juan C Tejada")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2020")])]

#text("In my humble opinion, the formula has to include this kind of information…")

#text("2 = {(“E”/2) (“O” x 3 +1 sobre 2)} N")

#text("Where “E” = Even number (or the number 2 if non-existant)")#linebreak()#text(" Where “O” = Odd number (or 1/3 if non-existant)")#linebreak()#text(" Where “N” = Number of times required")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cce6b79434ec7c0233b9e0aee6cd408396080c6ea44d6fc29985a13b7fa3c03c-cda6bc64bfc0c0812c1000e7c3fa18721920a519a1dc750bb6411f7ce5659b49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Juan C Tejada")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-567288")[#strong[#text("Juan C Tejada")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2020")])]

#text("sorry.")

#text("sobre = “over”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2939f6b5e8571bc9cd6c6e8aafac0c7e3f5919f2cfb117a6709fbe14cb109c6f-8fbb4a47c6abdf506101f40549b9c0ec667012fcd35ddc0cf2f88ce0df645a32.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthias Hippold")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-570769")[#strong[#text("Matthias Hippold")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2020")])]

#text("I see that by plugging in 1 and n in 6.2. I get at least")

#mi("\\displaystyle a_{[1,n]} \\geq 2(n-1)-C_A(\\sqrt{n(\\log(n))}+\\log(n)),")

#text("which also is greater than ")#mi("n \\frac{\\log 3}{\\log 2}")#text(", but how can I get the stronger statement?")

#text("But the more important question is the following.")

#text("It is then claimed, that for the stopping time it holds:")

#mi("\\displaystyle k_{\\text{stop}}= n \\frac{\\log(3)}{2 \\log(2)}+O(C_A^2 \\log(n))")#text(".")

#text("I do not understand the last statement. In the “worst” case, all the $a_i$ are 1 and then this would not hold. Clearly, this example would violate the inequality in the beginning, but why is this the case in general?")

#text("Furthermore, it is claimed, that the stopping time $k$ iff")

#mi("\\displaystyle a_{[1,l]} \\leq n \\frac{\\log 3}{\\log 2}-C_A^3 \\log n < a_{[1,l+1]}")

#text("Where does the ")#mi("C_A^3")#text(" instead of ")#mi("C_A^2")#text(" come from?")#linebreak()#text(" Thank you in advance for any help.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-572502")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2020")])]

#text("There was a typo; the lower bound on ")#mi("a_{[1,n]}")#text(" should have contain a ")#mi("2(n-1)")#text(" term rather than ")#mi("2n")#text(". For your second question, one applies (6.2) with ")#mi("(i,j) = (1,k), (1,k+1)")#text(" to obtain")

#mi("\\displaystyle 2(k-1) - C_A(\\sqrt{n \\log n} + \\log n) \\leq n \\frac{\\log 3}{\\log 2} - C_A^2 \\log n \\leq 2k + C_A (\\sqrt{n \\log n} + \\log n)")

#text("which will be incompatible with ")#mi("k \\leq n \\frac{\\log 3}{2 \\log 2} - C C_A^2 \\log n")#text(" or ")#mi("k \\geq n \\frac{\\log 3}{2 \\log 2} + C C_A^2 \\log n")#text(" if ")#mi("C")#text(" is large enough.")

#text("The ")#mi("C_A^3")#text(" in (6.6) (and subsequently) is a typo; it should be ")#mi("C_A^2")#text(". All occurrences of ")#mi("C_A^3")#text(" should be replaced by ")#mi("C_A^2")#text(" (alternatively one could replace all occurrences of ")#mi("C_A^2")#text(" with ")#mi("C_A^3")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d248e0b069727a6abd7b93c85aa9a139541562f05b147be4089f7e9cfe5ec5c-042f29722de25f7053d094ea89d23d2ac31687d1fd0ea658d5dbd056aaa155d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-579069")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2020")])]

#text("COLLATZ accelerated map (I do not know if it is already known) .It is based on a Col2 map, which together with the notable product difference nth power, follows and shortens the worst possible orbit. In case it could have any interest")

#mi("n\\rightarrow n+(n+1)= n+(z\\times 2^{x})= n+(z\\times (3^{x}-2^{x}))= n_{1}\\setminus 2^{a_{1}}= n_{2}\\rightarrow ...\\rightarrow 1")

#text("with n odd")

#text("for example, the known trajectory of number 27 reaches 1 in 17 steps")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d198e68bf7530730fe45eb4350a7fdc35f4ef10b4f1fecba1beae18e5cccce76-5086be055639ae1c370115c0e18c8dfea67f17f3c8d62359acbc95e79aed378d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Li Jiang")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-579466")[#strong[#text("Li Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2020")])]

#text("The Collatz Conjecture and Linear Indefinite Equation")

#text("For the collatz conjecture, we define an iterative formula of odd integers")#linebreak()#text(" according to the basic theorem of arithmetic, and give the concept of iterative exponent. On this basis, a continuous iterative general formula for odd numbers is derived. With the formula, the equation of cyclic iteration is deduced and get the result of the equation without a positive integer solution except 1. On the other hand, the general formula can be converted to linear indefinite equation. The solution process of this equation reveals that odd numbers are impossible to tend to infinity through iterative operations. Extending the result to even numbers, it can be determined that all positive integers can return 1 by a limited number iterations.")

#link("http://www.sciepub.com/tjant/content/8/2")[#text("http://www.sciepub.com/tjant/content/8/2")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e7bf75c668be18a7e671c946e67cb33d97edb902795f22cf86179c99efc6378-0d6d96e4350f1df00ec4ffa5dfcc48f40c36198c9871d7a84c523f4f5f4bf6cf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-579694")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2020")])]

#text("Li Jiang, I have a response, 5 Aug, but unfortunately I didn’t nest it under yours.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18a7866c654cf3fe1ab1279db62496f1558286f44647c5b36d79ac83fd1c4771-6f3e77fee47e6083ed03276fb5c145cccb35c5dd51132e7b400ddf4c6d140ff4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hollis Williams")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-580513")[#strong[#text("Hollis Williams")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2020")])]

#text("Hi Li, this looks like a publication in a predatory journal unfortunately. The bad website is an immediate giveaway, plus the imperfect English of the titles of the articles. It’s also associated with Science and Education (SciEP), who are known and blacklisted for their predatory journals.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e7bf75c668be18a7e671c946e67cb33d97edb902795f22cf86179c99efc6378-0d6d96e4350f1df00ec4ffa5dfcc48f40c36198c9871d7a84c523f4f5f4bf6cf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-579693")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2020")])]

#text("How do you address cyclicality or circularity – loops? For example, changing the addend to 17, 3x+17, you have the following cycle for n=27:")#linebreak()#text(" 181,41,35,61,11,25,23,43,73,59,97,77,15,31,55,91,145,113,89,71,115,181")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d198e68bf7530730fe45eb4350a7fdc35f4ef10b4f1fecba1beae18e5cccce76-5086be055639ae1c370115c0e18c8dfea67f17f3c8d62359acbc95e79aed378d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Li Jiang")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-579724")[#strong[#text("Li Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2020")])]

#text("Michael M. Ross, the collatz conjecture here is only 3x+1. I defined an iterative operation T=(3x+1)/2^a (a is the number of factors of even 3x+1, these factors are equal to 2), so T is also an odd number. My paper only proved 3x+1, i.e all positive numbers are neither divergent nor cyclic. I did not considering 3x+17, you can take a closer look at my paper.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-579939")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2020")])]

#text("Citing you conclusion: “Since each positive even number can be converted to an odd number after divided by factors equal to 2, the above conclusion also applies to even numbers. So all positive integers are convergent”")

#text("Are you saying you solved the Collatz conjecture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-580052")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2020")])]

#text("He “solved” it in the same sense as hundreds before him.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18a7866c654cf3fe1ab1279db62496f1558286f44647c5b36d79ac83fd1c4771-6f3e77fee47e6083ed03276fb5c145cccb35c5dd51132e7b400ddf4c6d140ff4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hollis Williams")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-580612")[#strong[#text("Hollis Williams")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2020")])]

#text("It’s in an article published by a predatory journal, so it’s overwhelmingly likely that the person has not solved the Collatz conjecture, even if they think they have.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-580694")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2020")])]

#text("Publishing in a “predatory journal” doesn’t imply anything about the author except he’s desperate to see his work in print and on the internet. If you don’t have credentials or referrals, the options are limited. Maybe he didn’t know about Vixra and sites like that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18a7866c654cf3fe1ab1279db62496f1558286f44647c5b36d79ac83fd1c4771-6f3e77fee47e6083ed03276fb5c145cccb35c5dd51132e7b400ddf4c6d140ff4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hollis Williams")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-580847")[#strong[#text("Hollis Williams")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2020")])]

#text("Publishing in predatory journals harms a person’s reputation, so yes, it does imply something about the author (it implies that they can’t be taken seriously). I believe that at this point everyone who writes articles and has an Internet connection knows about ArXiv. I suspect that the person had the article rejected as an ArViv submission and so sent it to a fake journal with no rigorous peer review process, instead of being sceptical and taking a look at what was wrong with their argument, which is a necessary part of slowly learning how to do mathematics.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e7bf75c668be18a7e671c946e67cb33d97edb902795f22cf86179c99efc6378-0d6d96e4350f1df00ec4ffa5dfcc48f40c36198c9871d7a84c523f4f5f4bf6cf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-580253")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2020")])]

#text("Syracuse algorithms: two ridiculously simple, superfast Python scripts for generating odd-only sequences. (I’ve posted them on Quora.) ")#link("https://qr.ae/pNsQvL")[#text("https://qr.ae/pNsQvL")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e7bf75c668be18a7e671c946e67cb33d97edb902795f22cf86179c99efc6378-0d6d96e4350f1df00ec4ffa5dfcc48f40c36198c9871d7a84c523f4f5f4bf6cf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-581012")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2020")])]

#text("I should say that the algorithms use an invertible, or bidirectional, first-return function – such that input n output n. The output of the inverted function cannot be finite. The Syracuse set from n –> x and the inverted Syracuse set from x–>n are equal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e7bf75c668be18a7e671c946e67cb33d97edb902795f22cf86179c99efc6378-0d6d96e4350f1df00ec4ffa5dfcc48f40c36198c9871d7a84c523f4f5f4bf6cf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-581378")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2020")])]

#text("I’m just stating a fact here about the algorithmic invertibility of a Syracuse function. If you disagree, give me a reason, rather than a downvote. (I attempted to put a symbol between input n and output n to denote bidirectional, but evidently associated with SQL injection, so disappeared.) I wish I knew how to paste images into these posts. If this latex fails, I provide a link to the functions:")

#text("Syracuse (convergent)")#linebreak()#text(" ")#mi("f(n) = \\begin{cases} ((n+1) \\frac {3}{2})-1 & \\text{if } n+1 \\equiv 0 \\text{ (mod } 4) \\\\ ( (n-1) \\frac {3}{4})+1 & \\text{if } n-1 \\equiv 0 \\text{ (mod } 8) \\\\ (n-1)4 & \\text{otherwise } \\end{cases}")

#text("Inverted Syracuse (divergent)")#linebreak()#text(" ")#mi("f(n) = \\begin{cases} ((n+1) \\frac  {2}{3})-1 & \\text{if } n+1 \\equiv 0 \\text{ (mod } 3) \\\\ ( (n-1) \\frac  {4}{3})+1 & \\text{if } n-1 \\equiv 0 \\text{ (mod } 6) \\\\  (n-1)4 & \\text{otherwise } \\end{cases}")

#text("(The inverted function can only create sequences that are nonfinite.)")

#link("https://qr.ae/pNsQ2o")[#text("https://qr.ae/pNsQ2o")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb79509928f904d2655170cbd953d07472e18e1600efd0ef52193a660538dccb-2b408b6392aeeed86a695bc473bf61c57084a7428e54126c92d6900325396e58.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-580667")[#strong[#text("Steve")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2020")])]

#text("I’ve noticed that if you plot n and f(n) on log-log, you always wind up with two parallel lines. Could that provide any sort of additional help knowing how the function is bounded? The solution travels back and forth along those lines, but vastly more towards the 4,2,1 orbit than towards higher numbers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-580752")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2020")])]

#text("Here f(n) is the collatz iteration? If so, you’ve discovered the fact that log(xy)=log(x)+log(y).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d198e68bf7530730fe45eb4350a7fdc35f4ef10b4f1fecba1beae18e5cccce76-5086be055639ae1c370115c0e18c8dfea67f17f3c8d62359acbc95e79aed378d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Li Jiang")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-581296")[#strong[#text("Li Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2020")])]

#text("Maybe my article The Colltatz Conjecture and Linear Indefinite Equition was not published in a more famous journal, but if Prof. Terence Tao read this article, he would understand: this article does prove Collatz (3x+1)conjecture.")

#link("http://www.sciepub.com/tjant/content/8/2")[#text("http://www.sciepub.com/tjant/content/8/2")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18a7866c654cf3fe1ab1279db62496f1558286f44647c5b36d79ac83fd1c4771-6f3e77fee47e6083ed03276fb5c145cccb35c5dd51132e7b400ddf4c6d140ff4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hollis Williams")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-581959")[#strong[#text("Hollis Williams")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2020")])]

#text("Li, I mean you no disrespect, but that is extremely unlikely. Simply stating that you have proved a conjecture does not mean you have proved it. Tao (and all professional mathematicians) are very busy and cannot be expected to read every article which is sent their way. If you publish your proof in a fake journal which publishes worthless articles, it’s a safe assumption that the proof you propose is very likely worthless, and no time needs to be expended in reading it to come to that conclusion. I suggest that you reconsider your proof and try to find the point where you have gone wrong.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d248e0b069727a6abd7b93c85aa9a139541562f05b147be4089f7e9cfe5ec5c-042f29722de25f7053d094ea89d23d2ac31687d1fd0ea658d5dbd056aaa155d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-581433")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2020")])]

#text("Hello Li JIANG. Good luck with your demonstration. I would be very grateful if you could explain point 3. Possibility of cyclic, in more detail, if possible. Thank you")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-581450")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2020")])]

#text("I would also like to understand more. The paper is very short, so if it is wrong, someone should find the error quite fast. No need to dig through many pages. Anyone sees some flaws?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d198e68bf7530730fe45eb4350a7fdc35f4ef10b4f1fecba1beae18e5cccce76-5086be055639ae1c370115c0e18c8dfea67f17f3c8d62359acbc95e79aed378d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Li Jiang")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-581491")[#strong[#text("Li Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2020")])]

#text("Dear Alberto Ibañez")#linebreak()#text(" The essence of the 3x+1 conjecture is the iterative operation of odd numbers. It is known from the basic theorem of arithmetic: the number of factors with a value equal to 2 in each even number is determined for the even number, so an iterative operation for odd numbers x can be defined. That is: $T=(3x+1)/2^a$, (where a is the number of factors whose value in 3x+1 is equal to 2), the result of the operation T is still odd.")#linebreak()#text(" According to this definition, the general formula for odd continuous iteration can be derived, that is")#linebreak()#text(" $ T^{(k)}(x)=\\dfrac{\\displaystyle{3^k x+\\sum_{i=1}^{k}2^{g(i-1)}3^{k-i}}}{2^{g(k)}}. $")#linebreak()#text(" From this, if the odd continuous iteration may cause loops, then we can deduce the equation that")#linebreak()#text(" $ x=\\dfrac{\\displaystyle{3^k x+\\sum_{i=1}^{k}2^{g(i-1)}3^{k-i}}}{2^{g(k)}}. $")#linebreak()#text(" Solving this equation can get the result that the equation has no positive integer solution except 1, which indicates that continuous iteration cannot cause a loop.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e7bf75c668be18a7e671c946e67cb33d97edb902795f22cf86179c99efc6378-0d6d96e4350f1df00ec4ffa5dfcc48f40c36198c9871d7a84c523f4f5f4bf6cf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-581673")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2020")])]

#text("(Your latex is fine – you just have to use $latex at the beginning on WP.)")

#text("You can look at the impossibility of loops from the point of view of common differences between inputs and outputs. For there to be a loop the sum of positive and negative differences must sum to 0 – that must be so. You can then show by contradiction how this can occur for, say, 3x+17, but not for 3x + 1, by tabulating inputs and outputs:")

#text("1 –> 25 = 14")#linebreak()#text(" 13 –> −1 = −14")#linebreak()#text(" 17 –> 17")#linebreak()#text(" 21 –> 1 = −20")#linebreak()#text(" 23 –> 43 = 20")

#text("We can call n –> n the equilibrium point. Every n in 3x+n has such a point, and of course it’s always the addend of 3x.")

#text("Whereas for 3x + 1, the equilibrium point is of course 1, and so is asymmetrical (only permitting the trivial loop, which in an odd-only function is actually 1 –> 1):")

#text("5 –> 1 = −4")#linebreak()#text(" 7 –> 11 = 4")#linebreak()#text(" 1 –> 1")#linebreak()#text(" …")#linebreak()#text(" …")

#text("If you look at the tabulation of inputs and outputs for 3x+1 you will see why this equilibrium would not occur again. But maybe there would be difficulty in formally proving this also eliminates another means of zero-summed loops.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/693ea804b46181cd312b5d94d2999d436fea26a51dce43939425e44c380f1075-89bab6f7bd8b9b6fcdf36b42ec7de8c3de0f3e7f63977866786a911f99944d3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ken Surendran")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-585477")[#strong[#text("Ken Surendran")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2020")])]

#text("See for latest work at")#linebreak()#text(" arXiv:2008.02161")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-585516")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2020")])]

#text("Agreed, there are three categories of numbers – but I don’t understand the Starter, Intermediary and Terminal construct. I see there are three and only three, according to congruence, and three operations associated with them:")

#mi("n+1 \\equiv 0 \\text{ (mod } 4) \\\\ n-1 \\equiv 0 \\text{ (mod } 8) \\\\ n-1 \\equiv 0 \\text{ (mod } 2)")#linebreak()#text(" ")#mi("((n+1)*1.5)-1) \\\\ ((n-1)*0.75)+1) \\\\ (n-1)*0.25")

#text("This generates the “lattice” structure of merging sequences:")#linebreak()#text(" ")#link("https://tinyurl.com/yyo688mb")[#text("https://tinyurl.com/yyo688mb")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/693ea804b46181cd312b5d94d2999d436fea26a51dce43939425e44c380f1075-89bab6f7bd8b9b6fcdf36b42ec7de8c3de0f3e7f63977866786a911f99944d3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ken Surendran")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-585639")[#strong[#text("Ken Surendran")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2020")])]

#text("There are two types of Intermediary integers (6m+1 and 6m+5).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-585649")[#strong[#text("Mathematicians Are So Close to Cracking This 82-Year-Old Riddle – The Endless Night")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2020")]

#text("[…] breakthrough post is titled “Almost All Collatz Orbits Attain Almost Bounded Values.” Let’s break that down slightly. Collatz Orbits are just the little sequences you get with the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/693ea804b46181cd312b5d94d2999d436fea26a51dce43939425e44c380f1075-89bab6f7bd8b9b6fcdf36b42ec7de8c3de0f3e7f63977866786a911f99944d3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ken Surendran")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-585915")[#strong[#text("Ken Surendran")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2020")])]

#text("Only odd Integer are considered in this study.")#linebreak()#text(" Collatz Conjecture y = (3x+1) / 2^α (Equation-1) where α > 0 is an integer, is considered in this study. Here, x and y are odd integers.")#linebreak()#text(" Odd integers are ‘categorized’ from Collatz conjecture perspective in the following:")#linebreak()#text(" 1. End integer is 1 (since this where the process ends)")#linebreak()#text(" 2. Starter Integers are of the form 6m+3 where m = 0, 1, 2, 3, … and these are odd multiples of 3. They are named as Starter Integers since they cannot be Collatz conjecture results [they can never be ‘y’ in Equation-1] but the conjecture process can start with them. One-third of the odd integers are Starter integers.")#linebreak()#text(" 3. Terminal integers are those whose Collatz conjecture result is 1 (i.e., the End integer). They terminate the conjecture process by producing 1 as the result in a single use of Equation-1. Such integers are: 5, 21,85,341, 1365,… which are related by 4x+1, where x is the previous integer in the series. Excluding those Starter integers like 21, 1365 that are odd multiples of 3 (every third Terminal integer is in the list) each of the remaining two-thirds of the Terminal integers have a set of Pre-terminal integers. For instance, the conjecture result for the integers 3, 13, 53, 213, … is 5, a Terminal integer. Also these Pre-terminal integers are related by 4x+1 (x being the previous integer in the list).")#linebreak()#text(" For naming convenience, the non-Starter integers, i.e., the odd integers of the form 6m+1 and 6m+5 are called the Intermediary integers. Also, each Intermediary integer is the Collate conjecture result for a set of odd integers, that are related by 4x+1 (x being the previous integer in the set). Expressions for generating such sets of odd integers are provided in Section 5. Sample sets of odd integers are provided for both 6m+1 (in Table 4A) and 6m+5 (in Table 4B) type integers. As indicated earlier in Dr. Tao’s narrative, one-third of the odd integers are involved in dealing with 6m+1 and two-thirds are involved in dealing with 6m+5.")#linebreak()#text(" Another classification of odd integers from Collatz conjecture perspective is based on value of α an integer x uses in Equation-1. It is noted that all the integers of the form 4m+1 use α ≥ 2 and the rest of the integers (that are of the form 4m+3) use α=1. The conjecture results of the 4m+3 integers are all of the form 6m+5. In Table 5, the conjecture behavior of the 4m+3 integers (based on their trajectory-length with continuous use of α = 1) are presented.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-589772")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2020")])]

#text("The link details: ")#link("https://arxiv.org/abs/2008.02161")[#text("https://arxiv.org/abs/2008.02161")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-587429")[#strong[#text("Closing An Open Problem | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2020")]

#text("[…] Conjecture : Terence Tao made important progress on this notorious problem. He […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-589832")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2020")])]

#text("Engineering vs Number Theory: Never the twain shall meet.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-589973")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2020")])]

#text("That was also Hardy’s opinion. But several cryptographic number-theoretic applications in engineering (e.g. RSA) show the contrary.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-594809")[#strong[#text("La Congettura di Collatz: un passo verso la risoluzione?")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2020")]

#text("[…] Terence Tao, riporto due link: uno a una versione discorsiva del suo metodo (più digeribile) e uno alla descrizione più formale, per la quale serve un’attrezzatura matematica che, ahimè, non […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/548ddcbdab8c323829bfe537a423209efdefd99375ee9aac4f94068c10234d41-6dd8c1a2761c92da28f5fe8fa9d1d58d0641c918b926b4aff06389a4cdbbbe7d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Faiz")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-601541")[#strong[#text("Faiz")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2020")])]

#text("Collatz Conjecture:")#linebreak()#text(" Lets use binary approach")#linebreak()#text(" If number is even then 0 else if odd then 1")#linebreak()#text(" Eg:-5(odd)-16(even)-8(even)-4(even)-2(even)-1(odd)")#linebreak()#text(" 100001->5")#linebreak()#text(" Similarily 010100001->6")#linebreak()#text(" 001 ->4")#linebreak()#text(" Now lets try opposite, instead lets take a binary number and try to make repeating number from it.")#linebreak()#text(" Lets say a function P which takes a binary number and converts it into repeating collatz number.")#linebreak()#text(" Eg: P(001)=4")#linebreak()#text(" But what about P(1001),P(100101) and many??")#linebreak()#text(" Actually we can form a repeating number from them too with this formula:")#linebreak()#text(" Number of zeroes in binary number=x")#linebreak()#text(" Number of ones in binary number =y")#linebreak()#text(" Formula= C/(2^x – 3^y)")#linebreak()#text(" To find the value of C is little tricky ,first we see binary number from left to right if first digit is 1 then we store 1 (say in variable “result”)and when we see zero then we increase the power of two(say in variable “pow2”) each time, If we see 0 as first digit in binary number then we store 0 in result variable but dont forget to increase power of 2 as well and when we see 1 again we multiply result variable by 3 and add pow2 and then again store it in result.The final result is our answer C")

#text("Eg: 100 Result Pow2")#linebreak()#text(" 1 1 2^0=1")#linebreak()#text(" 0 1 2^1=2")#linebreak()#text(" 0 1 2^2=4")

#text("Hence the final result is 1 or C =1")#linebreak()#text(" Formula= C/(2^x – 3^y)=1/(2^2-3^1)=1")#linebreak()#text(" 1 is indeed repeating collatz number.")

#text("Eg: 1001 Result Pow2")#linebreak()#text(" 1 1 2^0=1")#linebreak()#text(" 0 1 2^1=2")#linebreak()#text(" 0 1 2^2=4")#linebreak()#text(" 1 3*(1)+4=7 2^2=4")

#text("C=7")#linebreak()#text(" Formula= C/(2^x – 3^y)=7/(2^2-3^2)= -7/5")#linebreak()#text(" Haha -7/5 is indeed a repeating collatz number")#linebreak()#text(" How? Just apply operation as in binary number 1001")

#text("First step: 3*(-7/5)+1=-16/5 [Since first digit is 1 and this says to apply operation 3n+1]")

#text("Second step : -16/5 ×1/2 =-8/5[Since second digit 0 says to divide by 2]")

#text("Thirs step : -8/5 ×1/2=-4/5[Third digit 0]")

#text("Fourth step: 3×(-4/5)+1= -7/5 [ Fourth digit 1]")

#text("(Yaay -7/5 the number we started with)")

#text("Eg: 00011 Result Pow2")#linebreak()#text(" 0 0 2^1=2")#linebreak()#text(" 0 0 2^2=4")#linebreak()#text(" 0 0 2^3=8")#linebreak()#text(" 1 3×(0)+8=8 2^3=8")#linebreak()#text(" 0 8 2^4=16")#linebreak()#text(" C=8")#linebreak()#text(" Formula= C/(2^x – 3^y)=8/(2^4-3^1)= 8/13")#linebreak()#text(" Yes 8/13 is indeed a repeating collatz number")#linebreak()#text(" You can check by applying operations as in binary numbers stated.")

#text("So just take any random binary number and feed it in function P and it will indeed give a repeating collatz number which might give us a fraction or negative number or a proper positive integer. If we managed to get a proper positive integer except 4,2,1 then we can disprove collatz conjecture.")

#text("Thats all if you want then you can contact me on my email:faiz262003@gmail.com")#linebreak()#text(" Thank you : )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce7cf5c2649720f46362a8172fa9c05b501c595e39d94bade6ec54b1a919b77f-d4e815c4bed2e8874f7ed1694c217ac36f3e9c2e422f7278a7a8fbfb8bc5e271.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexandre Patriota")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-601938")[#strong[#text("Alexandre Patriota")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2020")])]

#text("Professor Terence Tao,")

#text("In your Proposition 1.9, you assume that ")#mi("\\mathbf{N} \\mod 2^m")#text(" is approximately uniformly distributed in ")#mi("\\mathbb{Z}/2^m\\mathbb{Z}")#text(" in the sense described in equation (1.11). This assumption implies that the distribution of the random version (RV) of the n-Syracuse valuation is approximately distributed as n-iid copies of a geometric random variable with probability of success 1/2. The validity of Theorems 1.3 and 1.5 depends on this specific geometric distribution with expectation 2, since if it were a geometric distribution with expectation smaller than ")#mi("\\log_2 3")#text(" the consequences would be different.")

#text("I ran some simulations and noticed that the maximum estimated probability of success the RV-Syracuse valuation is strictly above 0.5 and below 0.7. This indicates that the geometric distribution with expectation 2 might not be representing the process well. It would be nice to consider “worse” scenarios, where the expectation is smaller than 2. The uniform distribution assumption could be relaxed to a class of distributions which would allow other than geometric distribution with expectation 2 to describe the probabilistic behaviour of the RV-Syracuse valuation.")

#text("I tried working on the assumptions of Proposition 1.9, but I am stuck in some details since I am not an expert in number theory. My guess is that Theorems 1.3 and 1.5 are valid if the expectation of the RV- Syracuse valuation is larger than ")#mi("\\log_2 3")#text(" (or some limit version of this statement):")

#text("1. it is the case that ")#mi("{\\rm Syr}_{{\\rm min}}(N) < f(N)")#text(" for almost all ")#mi("N \\in 2\\mathbb{N}+1")#text(", if the expectation of the RV-Syracuse valuation is larger than ")#mi("\\log_2 3")#text(".")

#text("2. It is not the case that ")#mi("{\\rm Syr}_{{\\rm min}}(N) < f(N)")#text(" for almost all ")#mi("N \\in 2\\mathbb{N}+1")#text(", if the expectation of the RV-Syracuse valuation is smaller than ")#mi("\\log_2 3")#text(".")

#text("It seems one needs to explore the consequences in terms of probability distributions of the following fact: ")#mi("\\mathbf{N}")#text(" is constrained to a single odd residue class module ")#tao-math("2^{\\left|a\\right|+1}", block: false)#text(". The uniform distribution simplifies the problem, but we do not necessarily have to impose this assumption.")

#text("Best")#linebreak()#text(" A. Patriota.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-602758")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2020")])]

#text("Proposition 1.9 is applied in the paper near the beginning of Section 7, to the logarithmic distribution on ")#mi("[y, y^\\alpha]")#text(", with ")#mi("2^m")#text(" basically a small power of ")#mi("y")#text(" (such as ")#mi("y^{0.1}")#text("). The hypothesis (1.11) can be verified in that case by use the integral test to calculate the probability that any given residue class modulo ")#mi("2^m")#text(" is attained.")

#text("If instead one used the logarithmic uniform distribution on ")#mi("[1,x]")#text(" for ")#mi("{\\bf N}")#text(", the deviation of the Syracuse random variables from the geometric distribution would be expected to be of the order of ")#mi("O(1/\\log x)")#text(" since ")#mi("{\\bf N}")#text(" will be bounded with this probability. However it would still converge to geometric (albeit rather slowly) in the limit ")#mi("x \\to \\infty")#text(". But in this paper I am not applying Proposition 1.9 directly to this distribution.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce7cf5c2649720f46362a8172fa9c05b501c595e39d94bade6ec54b1a919b77f-d4e815c4bed2e8874f7ed1694c217ac36f3e9c2e422f7278a7a8fbfb8bc5e271.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexandre Patriota")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-602870")[#strong[#text("Alexandre Patriota")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2020")])]

#text("I just noticed that you have updated Proposition 1.9 in version 3 of your manuscript in arxiv. Maybe that would have an effect in my simulations.")

#text("You meant “the beginning of Section 5” on the top of page 19, right?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce7cf5c2649720f46362a8172fa9c05b501c595e39d94bade6ec54b1a919b77f-d4e815c4bed2e8874f7ed1694c217ac36f3e9c2e422f7278a7a8fbfb8bc5e271.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexandre Patriota")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-603437")[#strong[#text("Alexandre Patriota")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2020")])]

#text("“The hypothesis (1.11) can be verified in *that case*…”")

#text("*That case* seems to be dependent on the logarithmic density definition of “almost all” which induces ")#mi("\\mathbf{N}")#text(" to be logarithmically uniformly distributed which implies that ")#mi("\\mathbf{N} \\mod 2^m")#text(" is approximately uniformly distributed which, by its turn, implies that the random Syracuse valuation is close to a geometric random variable with mean 2.")

#text("If ")#mi("\\mathbf{N}")#text(" is randomly generated according to a different probability law (i.e., we would have a change in the “almost all” definition), then what does guarantee that the random Syracuse valuation is close to a geometric random variable with average 2?")

#text("If the results are robust, they should not depend too much on the probability law used to define “almost all”. Is it possible to change the definition of “almost all” such that it keeps the same essence of “almost all” concept but makes your main theorems invalid?")

#text("For instance, you can change the probability ")#mi("\\mathbb{P}(\\mathbf{\\log}(2\\mathbb{N}+1 \\cap [1,x]))")#text(" to a different version indexed by a parameter ")#mi("\\theta \\in (0, \\infty)")#text(", namely, ")#mi("\\mathbb{P}_\\theta(\\mathbf{\\log}(2\\mathbb{N}+1 \\cap [1,x]))")#text(" such that for some values of ")#mi("\\theta")#text(", say ")#mi("\\theta \\geq \\log_2 3")#text(", the main results hold valid and for others, say ")#mi("\\theta < \\log_2 3")#text(", the main results fail.")

#text("What can prevent me from finding such a probability ")#mi("\\mathbb{P}_\\theta")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-604451")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2020")])]

#text("Well, if the Collatz conjecture is true, then the conclusion of my theorem would hold for all ")#mi("N")#text(", not just almost all ")#mi("N")#text(", so in particular one would get an almost all result for an arbitrary distribution. I suspect the theorem is provable using the notion of natural density instead of logarithmic density, and in fact I know some people who are working on this extension of the result right now; the logarithmic distribution is convenient for technical reasons (in particular it can handle the dilation aspects of the iterated Syracuse map quite easily, leaving only the translation aspects to be understood carefully) but is unlikely to be a genuine restriction to the method in my opinion.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce7cf5c2649720f46362a8172fa9c05b501c595e39d94bade6ec54b1a919b77f-d4e815c4bed2e8874f7ed1694c217ac36f3e9c2e422f7278a7a8fbfb8bc5e271.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexandre Patriota")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-604455")[#strong[#text("Alexandre Patriota")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2020")])]

#text("Yes, but as we do not know whether the Collatz conjecture is true or not, the conclusion that ")#mi("{\\rm Syr}_{{\\rm min}}(N) < f(N)")#text(" for almost all ")#mi("N \\in 2\\mathbb{N}+1")#text(" seems to be derivable only under some contexts.")

#text("My conjecture is that")

#text("1. your results remain true for any RV-Syracuse valuation whose expectation is larger than ")#mi("\\log_2 3")#text(" (or under similar conditions), since this is a consequence if the Collatz conjecture is true.")

#text("2. your results fail to be true if the RV-Syracuse valuation has expectation smaller than ")#mi("\\log_2 3")#text(".")

#text("Naturally, the \"almost all\" concept has to be defined in such a way to allow these cases.")

#text("I am not sure exactly how to prove it and that is the main reason I am writing here. I tried to work on it, but it is not my field and I already spent a lot of time on it.")

#text("Maybe someone can explore other versions of \"almost all\" that allow those distributions. I am still a little bit concerned about my simulation results. When I have time, I will work more on it.")

#text("Best regards,")#linebreak()#text(" A. Patriota.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-604456")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2020")])]

#text("Some properties are far from arbitrary – for one, the stopping times of sequences are eminently predictable in two important cases:")#linebreak()#text(" If sequence n+1 ≡ 0 (mod 4), sequence 6n+3 has the same stopping time.")#linebreak()#text(" If sequence n−1 ≡ 0 (mod 8) , sequence 3n+2 has the same stopping time.")#linebreak()#text(" I just noticed this, and find it reassuring we’re not dealing with something too wild and woolly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80965863af6390d27b148395ae6e0ba28a48a473fdf6a0e040aeb38108d83104-73080da18bf6783d68481c9fedb1d0d6939b1a85c0a146ef9c1f85c1716a63cc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-604758")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2020")])]

#text("Hello, how can I understand with my high school math level what it means that the expectation is larger or smaller than \\ log_2 3?, Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f50d5006f5e134f5f5cacf82b92f88eb85ccc47800116a52746261ec811652b5-c7ec6e1f9871c7aba7e86bc677f32ee83ab845fcb142e53fef4150d3128d00df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Frost")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-604766")[#strong[#text("Robert Frost")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2020")])]

#text("@Alberto the expectation is the mean of all possible outcomes, weighted according to each outcome’s likelihood. ")#mi("r=\\log_3(2)\\approxeq 0.6309")#text(". If you roll a standard 6-sided dice your expected outcome is ")#mi("3.5")#text(" because there are six equally likely outcomes and if you add them all together and divide by six, you get ")#mi("3.5")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f50d5006f5e134f5f5cacf82b92f88eb85ccc47800116a52746261ec811652b5-c7ec6e1f9871c7aba7e86bc677f32ee83ab845fcb142e53fef4150d3128d00df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Frost")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-604765")[#strong[#text("Robert Frost")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2020")])]

#text("You prove the statement the statement “almost all trajectories converge to ")#mi("n")#text("” but is your proof true independently of ")#mi("n=1")#text("? Because it it were not, this would surely give us the proof. Because I assume it would be a contradiction that almost all trajectories converge to ")#mi("1")#text(" and also converge to ")#mi("n\\neq 1")#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80965863af6390d27b148395ae6e0ba28a48a473fdf6a0e040aeb38108d83104-73080da18bf6783d68481c9fedb1d0d6939b1a85c0a146ef9c1f85c1716a63cc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-605113")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2020")])]

#text("Thanks @robert frost, although I can’t quite understand it. I wanted to see if it could be related to two facts, which I don’t know if they have something to do with it, but I still expose them.")#linebreak()#text(" The first is that every worst orbit is finite, which I explained in a previous comment, and that when k, the number of odd steps tends to infinity, y the number of even steps is always much greater, that is, y-k tends to infinite.")#linebreak()#text(" If we use a col2 map that takes us through the worst possible orbit, for an odd n, if n +1 = z * 2^k, in k iterations the resulting value is NEVER odd(0% probabiliy), that is, at least it is divided more than 1 time by 2.")#linebreak()#text(" Does this fact influence the calculation of probabilities?")

#text("“for instance, one can compute that for large random odd ")#mi("{\\mathbf{N}}")#text(", ")#mi("{\\mathrm{Syr}^2(\\mathbf{N}) \\text{ mod } 9}")#text(" will take the residue classes ")#mi("{0,1,2,3,4,5,6,7,8 \\text{ mod } 9}")#text(" with probabilities")

#mi("\\displaystyle  0, \\frac{8}{63}, \\frac{16}{63}, 0, \\frac{11}{63}, \\frac{4}{63}, 0, \\frac{2}{63}, \\frac{22}{63}")#text(",")#linebreak()#text(" that is, any more of these probabilities becomes 0?")

#text("The second fact is that, for known orbits reaching 1, although only checked for a few given my limitations,")#linebreak()#text(" in the iteration of 3n + 1.3n, it is multiplied by 3, while +1 is multiplied by 3 and a power of 2 is added, let’s say that the evolution of the term + 1, is gaining weight in% with respect to the sum n * 3^k + d, until + d reaches a value greater than 25% of the sum, although it is after reaching a power of 2.")#linebreak()#text(" Could we suggest that the weight of the term +1 in the iteration of the sum 3n + 1 evolves to exceed 25% of the total is always possible and does it mean that there is always a solution?")#linebreak()#text(" thanks and sorry if i say a lot of nonsense")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a30486e84e876ff39ccefeb8b6629c5e69dd59f6ad7db9e16b4a27bd9fc44bb5-c9c33c6b1bfbadd193262ddd2f7c50ebdaeafc105d56c6ae507a1802e1793e73.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kenoc22")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-606255")[#strong[#text("kenoc22")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2020")])]

#text("I have spent 2 months writing collatz conjecture python programs to understand the sequences and patterns produced by the Collatz Conjecture and have come a long way in understanding but am still only opening the gate to the party and have not feasted on the solution as you have with your advanced level of mathematical understanding and skills. I’m using basic arithmetic sequences which has allowed me to work out all of the Collatz even number states 3N+1 = (6m +4) where m = 0,1,2,3,4…. and N=2m+1 and there are 12 states I have designated as C0 to C11. The “multiply by 3 plus” algorithm only transitions to states C0, C2,C3,C5,C6,C8,C9,C11 while states C1,C4,C7,C10 only appear once in any iteration at the beginning and only if the first iteration of “multiply by 3 plus 1” points to one of these states, dependent solely on the number chosen to perform the conjecture algorithm. I have mapped all the state transitions and how they transition from one state to the next, dependent on odd and evenness and the the factors of 4,8,16,32 etc. C0,C8, perform 2 divisions by 2, while C1,C3,C5,C9 and C11 perform only 1 division by 2 and C2 and C6 perform 3 or more divisions by 2. What I have proven using the probabilities of all the states is the occurrences of each of the states in any trajectory (not of form 2^^K +- 1) is that the average number of states for larger numbers equate to:")

#text("C0 C1 C2 C3 C4 C5 C6 C7 C8 C9 C10 C11")#linebreak()#text(" N 0-1 2N N 0-1 2N N 0-1 2N N 0-1 2N")

#text("ie as an example from my python program")#linebreak()#text(" Number:")#linebreak()#text(" 1322070819480806636890455259752144365965422032752148167664920368226828597346704899540778313850608061963909777696872582355950954582100618911865342725257953674027620225198320803878014774228964841274390400117588618041128947815623094438061566173054086674490506178125480344405547054397038895817465368254916136220830268563778582290228416398307887896918556404084898937609373242171846359938695516765018940588109060426089671438864102814350385648747165832010614366132173102768902855220000")

#text("Collatz C_0 to C_11 totals:[282, 0, 610, 251, 0, 560, 269, 0, 528, 296, 0, 520]")

#text("From the information gained by mapping all the state transitions and understanding the number of states in each trajectory , independent of the size of the number I was able to calculate the probabilities of each state occurring and the probabilities align with the state number ratios for each trajectory. Based on the probabilities for each state I can prove non rigorously therefore that the average value of the number of multiply by 3’s is less than the average number of divide by 2’s implying the conjecture always must converge for large number long trajectories based on the probabilities.")

#text("I know this is a non-rigorous proof because I am using the probabilities of the states occurring based on their transitions from other states rather than proving that a generic starting number will gradually reduce in size as the conjecture iterates over a long trajectory to prove convergence but this is a basic proof using probability that can give some credence to the conjecture that it is valid for all whole numbers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a30486e84e876ff39ccefeb8b6629c5e69dd59f6ad7db9e16b4a27bd9fc44bb5-c9c33c6b1bfbadd193262ddd2f7c50ebdaeafc105d56c6ae507a1802e1793e73.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kenoc22")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-606410")[#strong[#text("kenoc22")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2020")])]

#text("have got myself into a rabbit hole with my approach as I don’t have the mathematical expertise of the mathematicians such as Terence Tao, a mathematical master of the times, nor their primed skills to solve this rigorously but programming this algorithm has revealed a lot, as well as looking at it through the state transition perspective because it helped in understanding the trajectory patterns. What I have found as mentioned in previous reply is the strong bias towards the ratios of number of states in the trajectory as shown in my reply preceding. As an example I have run my python algorithm on the following 2 large numbers.")

#text("1. 3^10,000 and is 4,772 digits in length and trajectory totals 38,126 “multiply by 3 plus 1” iterations")#linebreak()#text(" Collatz C_0 to C_11 totals:[3214, 0, 6322, 3214, 1, 6381, 3158, 0, 6381, 3213, 0, 6242]")#linebreak()#text(" This follows the general pattern:")#linebreak()#text(" C0 C1 C2 C3 C4 C5 C6 C7 C8 C9 C10 C11")#linebreak()#text(" N 0-1 2N N 0-1 2N N 0-1 2N N 0-1 2N")

#text("2. 3^29,999 and is 14,314 digits in length and trajectory totals 114,015 “multiply by 3 plus 1” iterations")#linebreak()#text(" Collatz C_0 to C_11 totals:[9510, 1, 18969, 9471, 0, 18918, 9442, 0, 19050, 9670, 0, 18984]")#linebreak()#text(" This follows the general pattern:")#linebreak()#text(" C0 C1 C2 C3 C4 C5 C6 C7 C8 C9 C10 C11")#linebreak()#text(" N 0-1 2N N 0-1 2N N 0-1 2N N 0-1 2N")

#text("Now I know this number of states breaks down near numbers of the form 2k")#linebreak()#text(" and specifically numbers 2k -1 and 2k +1 but it is easy to prove why because there is a preamble of repeated states until the 2k factor is removed by multiple iterations and then the trajectories appear to follow this pattern.")

#text("In general based on the numbers I have run there is an absolutely strong tendency to convergence based on the probabilities of hitting odd and even sub number ‘n’ within m where N=2m+1 and m=12n + {0,1,2,3,4,5,6,7,8,9,10,11} and n = 0,1,2,3… and multiples of 4,8,16,32… and alternate odd numbers within ‘n’.")

#text("In terms of the strong convergence for all whole numbers:")#linebreak()#text(" State: C0 C1 C2 C3 C4 C5 C6 C7 C8 C9 C10 C11 ")#linebreak()#text(" Number of states: N 0-1 2N N 0-1 2N N 0-1 2N N 0-1 2N ")#linebreak()#text(" Average Divide ")#linebreak()#text(" by 2: 2^2 1 > 2^8 2 1 2^2 >2^4 1 2^2 2 1 2^2 ")#linebreak()#text(" Average Multiply ")#linebreak()#text(" by 3: 3 1 3^2 3 1 3^2 3 1 3^2 3 1 3^2")

#text("So the average long multiply by 3 divided by 2 factor for the trajectories of large numbers is” 3^12 / 2^22 = 0.36 and so convergence is a very strong factor in general but this is not a rigorous proof just a calculation of the strong general bias to convergence based on observation and on the general probabilities of the state transitions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a30486e84e876ff39ccefeb8b6629c5e69dd59f6ad7db9e16b4a27bd9fc44bb5-c9c33c6b1bfbadd193262ddd2f7c50ebdaeafc105d56c6ae507a1802e1793e73.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kenoc22")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-606412")[#strong[#text("kenoc22")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2020")])]

#text("In the preceding reply it mentions 2k , 2k +1 and 2k -1 but the exponent has been removed by the text editor when pasting and should be 2^k, 2^k +1, and 2^k -1 otherwise the comment related to this section is incorrect.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-606359")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2020")])]

#text("Is it possible to use AI deep-learning algorithms to discover more (still unknown) nontrivial patterns in the ")#mi("Col")#text(", ")#mi("Syrac")#text(" and related similar iterations – which might help deducing stronger quantitative results on this conjecture?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab41b7fe01ab998ed3db6a9faf8abab808c5e3740e06408729cdf1606d3bcb52-ddab473909fabe7b6843d08919faf2a35d6b303c1d97ab2e3dd1e1124ea27d34.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josh Bourgeois")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-607805")[#strong[#text("Josh Bourgeois")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2020")])]

#text("Well, I’ve tossed my hat into the ring. ")#link("https://observablehq.com/@thepeoplesbourgeois/so-this-whole-collatz-conjecture-thing")[#text("https://observablehq.com/@thepeoplesbourgeois/so-this-whole-collatz-conjecture-thing")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-607806")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2020")])]

#text("You must know that in order to prove a mathematical conjecture, you have to be a mathematician, accredited and respected. Even if your paper were true, it has no standing. Further, it’s algorithmic, not algebraic. Lastly, as far as I can see, it doesn’t address the whole question of circularity – why does the same number never recur in a sequence. Nevertheless, it may have value!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-607807")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2020")])]

#text("It’s embarrassing that you think you proved anything.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d198e68bf7530730fe45eb4350a7fdc35f4ef10b4f1fecba1beae18e5cccce76-5086be055639ae1c370115c0e18c8dfea67f17f3c8d62359acbc95e79aed378d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Li Jiang")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-607818")[#strong[#text("Li Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2020")])]

#text("Hi, Terence Tao")#linebreak()#text(" Please read my article The Collatz Conjecture and Linear Indefinite Equation")#linebreak()#text(" at ")#link("http://www.sciepub.com/tjant/content/8/2")[#text("http://www.sciepub.com/tjant/content/8/2")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d198e68bf7530730fe45eb4350a7fdc35f4ef10b4f1fecba1beae18e5cccce76-5086be055639ae1c370115c0e18c8dfea67f17f3c8d62359acbc95e79aed378d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Li Jiang")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-607819")[#strong[#text("Li Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2020")])]

#text("For the collatz conjecture, we define an iterative formula of odd integers")#linebreak()#text(" according to the basic theorem of arithmetic, and give the concept of iterative exponent. On this basis, a continuous iterative general formula for odd numbers is derived. With the formula, the equation of cyclic iteration is deduced and get the result of the equation without a positive integer solution except 1. On the other hand, the general formula can be converted to linear indefinite equation. The solution process of this equation reveals that odd numbers are impossible to tend to infinity through iterative operations. Extending the result to even numbers, it can be determined that all positive integers can return 1 by a limited number iterations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6dc865ab4517d707ff2f3e0624e8fbab9ef605e4e1147168a2cc0c5106e1721-ec068b64dfe8e9983ff2f38d18f7a03d3a2c6330d5647c9d8e797a5393882e93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Grigoriev")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-613701")[#strong[#text("Alexander Grigoriev")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2020")])]

#text("Mr Li Jiang,")

#text("What are your thoughts on my comment below?")

#text("Regards,")#linebreak()#text(" Alex")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13c86bde42e3b42fc0f8af62d721597ea7dda0bce3e0724bd3cf34eb42dcc2ea-184bd59e7fddff9993c2f89898dd4f58d6a917336d359eb790cded0514e8d9a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabian")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-613168")[#strong[#text("Fabian")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2020")])]

#text("Maybe there is a slight parsing error after “This was then improved by Allouche to”.")#linebreak()#text(" Aditionally, in the following sentence appears theta which is not defined before.")#linebreak()#text(" Thank you for your cool blog.")#linebreak()#text(" Fabian")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6dc865ab4517d707ff2f3e0624e8fbab9ef605e4e1147168a2cc0c5106e1721-ec068b64dfe8e9983ff2f38d18f7a03d3a2c6330d5647c9d8e797a5393882e93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Grigoriev")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-613700")[#strong[#text("Alexander Grigoriev")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2020")])]

#text("Consider a set of Ki>0.")#linebreak()#text(" If it’s possible to prove that the product:")

#text("П((3Ki+2)/(2Ki+1))")

#text("can never be a power of 2 (means its factors can never fully cancel each other, leaving only 2s from the numerator), then this will prove that a Collatz sequence can never loop.")

#text("Context:")

#text("A Collatz sequence of odd numbers 2Ki+1 is equivalent to series of multiplications by:")

#text("(3Ki+2)/((2Ki+1)*2^Ni),")

#text("where division by 2^Ni means discarding all least significant zeros from the intermediate result.")

#text("If the sequence loops to the initial number, this means the product of such terms becomes equal exactly to 1, or the product of terms without 2^Ni in the denominator becomes equal to exact power of 2.")

#text("It seems that, without even considering Ki belonging to a Collatz sequence, it’s not possible to find such a set that the product above will become a power of 2.")

#text("The only such trivial value is K=0, which makes the term equal to 2, which corresponds to the only known loop starting from 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6dc865ab4517d707ff2f3e0624e8fbab9ef605e4e1147168a2cc0c5106e1721-ec068b64dfe8e9983ff2f38d18f7a03d3a2c6330d5647c9d8e797a5393882e93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Grigoriev")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-613705")[#strong[#text("Alexander Grigoriev")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2020")])]

#text("To avoid confusion:")#linebreak()#text(" Of course, the canonical formula for Collatz (from 2Ki+1) would be:")#linebreak()#text(" (6Ki+4)/((2Ki+1)*2^Ni)")

#text("but we can just drop that extra 2, so it becomes 3Ki+2 in the numerator.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6dc865ab4517d707ff2f3e0624e8fbab9ef605e4e1147168a2cc0c5106e1721-ec068b64dfe8e9983ff2f38d18f7a03d3a2c6330d5647c9d8e797a5393882e93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Grigoriev")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-613793")[#strong[#text("Alexander Grigoriev")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2020")])]

#text("I suspect if such a set existed, the minimum set would be pretty trivial and not unique. Yet, a brute force search in 40 bit space (each Ki checked for up to 10 bit for 2, 3, 4 terms) brought no results.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6dc865ab4517d707ff2f3e0624e8fbab9ef605e4e1147168a2cc0c5106e1721-ec068b64dfe8e9983ff2f38d18f7a03d3a2c6330d5647c9d8e797a5393882e93.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Grigoriev")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-613708")[#strong[#text("Alexander Grigoriev")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2020")])]

#text("If we can prove that a Collatz sequence starting from any arbitrary odd number N will eventually produce a smaller number M, then it will prove that Collatz sequence always converges to 1.")

#text("If we consider as a single step multiplying the previous number by 3, adding 1, and then discarding all least significant zeros, such a step will (on logarithmic average) multiply the number by 3/4.")#linebreak()#text(" On average, each step discards two zeros, which is equivalent to dividing by 4. (one zero is discarded with probability 1/2, two zeros with probability 1/4, 3 zeros with probability 1/8, and such series 1/2+2/4+3/8+4/16… sums to 2 zeros on average).")#linebreak()#text(" Thus, any long enough sequence, even though it may wander up and down, would inevitably come below its starting number.")

#text("Note that all starting numbers expressible as 4K+1 reach a smaller number after a single step. Only the starting numbers expressible as 4K+3 will produce a non-trivial sequence before reaching a smaller number.")

#text("I address (im)possibility of loops in my previous comment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cbdaf6e44097ca9682652c54d9f48403b21d42d75b309d8e0e166b3f7f2ef080-53522f03241f18645cceecb5f66bc5ae2152a35eb6077edd685222cd86ac8f61.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of La conjecture de Syracuse : temps de vol, altitude maximale, atterrissage…. | Autrement qu'être Mathesis uni∜ersalis Problema Universale Heidegger/Husserl être/conscience : plan vital-ontologique vs plan spirituel d'immanence CLAVIS UN")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-619228")[#strong[#text("La conjecture de Syracuse : temps de vol, altitude maximale, atterrissage…. | Autrement qu'être Mathesis uni∜ersalis Problema Universale Heidegger/Husserl être/conscience : plan vital-ontologique vs plan spirituel d'immanence CLAVIS UN")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2021")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/")[#text("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f4488104038db0fadbb1d5193f64363622b674207ef92432024df96a4b4a229-a13a517f1657550c4197124ed0a538abdd493b59bf06205eb2092964065b71e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of marcos luz")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-620099")[#strong[#text("marcos luz")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2021")])]

#text("Dear Prof. Tao, it is may be the case that in proper log scale, Collatz sequences for very large initial numbers can related to geometric Brownian motion (strong numerical indications), as recently published in Physical Review Research: ")#link("https://journals.aps.org/prresearch/abstract/10.1103/PhysRevResearch.3.013073")[#text("https://journals.aps.org/prresearch/abstract/10.1103/PhysRevResearch.3.013073")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a36f0cf5b64fa9523fed4c13f4b3f04b1f25583f6a7a5a1aa2ff56d3aae23fac-46bf670f357e21ba2b374383132331298dd113675c611310a352f1ed525902f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hubert Schaetzel")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-624658")[#strong[#text("Hubert Schaetzel")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2021")])]

#text("Let us consider the 4, 2, 1, 4… cycle on the positive side of Z. Is it isolated ? No. This cycle is the root of a tree growing indefinitely above it. Let us look at the negative side of Z. There are (at least) 3 cycles. Are they isolated ? No, of course. Each cycle is the root of a tree growing indefinitely above it. So let us think a few seconds and state together : Any number is trivially (and proof is easily given of that) within a tree which expands infinitely. There can be nothing like a cycle with no branches developing out of its 1 mod 3 and 2 mod 3 valued integers which won’t give new ramifications. So if one can prove that this expansion is of non-zero density in Z, one can than conclude with Riho Terras theorem given in 1976 (The 4, 2, 1 cycle tree is of density 1 in N). This is not so hard. One can even fully describe the Pascal triangle based characteristics of that expansion (within appendix 5 of given reference).")#linebreak()#text(" ")#link("https://hubertschaetzel.wixsite.com/website")[#text("https://hubertschaetzel.wixsite.com/website")]#text(" Terras sheet")

#link("https://b2c3cf01-e240-4589-a89b-b32075ca6093.filesusr.com/ugd/fa6b59_455cca13fc4443e686fc450b87378b1f.pdf")[#text("Click to access fa6b59_455cca13fc4443e686fc450b87378b1f.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5170010f70c29afc35e4e33fa2a14517e816f9b215b890ec6435784900b6660-4b2ec332aeca9225cebfa98f36f767e2e5441d244b50e4e9c609910bdbc6b341.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wulf Rehder")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-633263")[#strong[#text("Wulf Rehder")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2021")])]

#text("Rephrasing the Collatz Conjecture using Terras’s concept of “stopping time”:")

#text("If m is the number of multiplications by 3 and m+k die number of divisions by 2 at index N=m+m+k of a Collatz sequence, then the sequence has stopping time N (i.e. the first time the sequence dips below its starting value) iff 2^(m+k) divided by 3^m is larger than 1 at this N for the first time, i.e., here the powers of 2 “win out” for the first time. Taking logs, this happens beyond the threshold t= [log3/log2]/[log3/log2+1]=0.613147… for every Collatz sequence, regardless of starting value. Therefore: For a sequence, find the index N=m+m+k where the “2-density” d=(m+k)/N exceeds t for the first time: this N is the stopping time. If in a sequence no d exists that exceeds t, then the Conjecture fails. No such sequence has been found. The threshold t is thus something like a “signature” of all Collatz sequences for which die Conjecture is true.")

#text("Of course, this rephrasing doesn’t prove anything. But it may refocus the attention on the proportions of the even and odd elements in Collatz sequences.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-633276")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2021")])]

#text("But you do know that the even numbers serve no purpose. They’re just an artifact of thinking about the problem as a riddle rather than a function. What the professor calls the Syracuse function is an odd-only function.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5170010f70c29afc35e4e33fa2a14517e816f9b215b890ec6435784900b6660-4b2ec332aeca9225cebfa98f36f767e2e5441d244b50e4e9c609910bdbc6b341.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wulf Rehder")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-633279")[#strong[#text("Wulf Rehder")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2021")])]

#text("Even numbers serve an essential purpose in the determination of the original “stopping time.”")

#text("For the determination of the stopping time of a Collatz sequence that is generated by the original algorithm (not by the “symmetrized” rule, nowadays more common, that absorbs the 3n+1-step in the following division by 2) the amount of the even numbers does play an essential role and needs to be counted. Take the starting element 11. The Collatz sequence 11,34,17,52,26,13,40,20,10 goes below 11 for the first time at the element 10, after exactly N=8 steps. This N is the stopping time. There are m=3 multiplications by 3 and 5=3+2 (i.e., k=2) divisions by 2. The “2-density” is 5/8=0.625. This is larger than the threshold t=0.613147…. The number of 2-divisions compared to the 3-multiplications were just enough to pull the sequence down to 10 for the first time below 11: the quotient 5/8 is the first time the (m+k)/(m+m+k) exceeds t. Try this out for the starting number 27 or any other “seed”, for instance the Collatz-related OEIS sequences A006877 and A006884, or any of the seeds given in the table on the Wikipedia page: 97, 871, 77031 etc. They have a variety of long and short stopping times and total stopping times. In all cases, the stopping time can be determined in the manner I have described, no exceptions (leaving out even seeds, of course, and neglecting the +1 in the 3-multiplication, which has no real effect on t). It is somewhat surprising that the threshold t is universal for all (original) Collatz sequences.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5170010f70c29afc35e4e33fa2a14517e816f9b215b890ec6435784900b6660-4b2ec332aeca9225cebfa98f36f767e2e5441d244b50e4e9c609910bdbc6b341.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wulf Rehder")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-633373")[#strong[#text("Wulf Rehder")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2021")])]

#text("Collatz fractal dimensions")

#text("Consider a Collatz sequence in the original form (not in the popular reduced form that combines the multiplication by 3 (plus 1) with the subsequent division by 2 into one step). To first repeat some terminology from a previous post: If m is the number of multiplications by 3 and m+k the number of divisions by 2 after altogether N=m+m+k steps, then the sequence has stopping time N (i.e. N is the number of steps when the sequence dips below its starting value for the first time) iff 2^(m+k) is larger than 3^m at this very N for the first time, i.e., when the additional powers of 2 “win out” for the first time. Taking logs, this happens when (m+k)/N exceeds the threshold t= [log3/log2]/[log3/log2+1]=0.613147… for the first time. This is true for every Collatz sequence, regardless of starting value.")

#text("It follows that s=t/(1-t), which is the threshold for the ratio (m+k)/m of divisions by 2 divided by the number of multiplications by 3, is equal to log3/log2=1.585…, the fractal dimension of a Sierpinski triangle, while the threshold r=1/s of the inverse proportion m/(m+k) equals the fractal dimension log2/log3=0.6309… of the Cantor set. For a Collatz sequence without finite stopping time, i.e., falsifying the Collatz Conjecture, the numbers t, s, and r do not exist, because in this case the powers of 2 never “win out” over the powers of 3 (see above). Since the threshold t is universal for all Collatz sequences with finite stopping time and t=s/(s+1) = 1/(r+1) (*) is expressed in fractal dimensions, one may say that the Collatz Conjecture is true iff there exists a threshold t defined by the fractal dimension s, or equivalently by r, by (*) above. This is perhaps not too surprising, because the numbers 3 and 2 play the defining roles in constructing both the Cantor set and Sierpinski triangles. But while these two sets are very regular (“self-similar”), a Collatz sequence may look chaotic or random.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7aec453a9034c7eeffe6f209c8e448dbca1b1f2d3260aee32642f2ffbc3f668-28d4a5811aa5a0f2ff850d3b376d9d5a2df29b53e9cc60294bae7498712bf3b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-633441")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2021")])]

#text("For all n, when m goes to infinity, k goes to infinity")#linebreak()#text(" This fact is enough to say the power of 2 always win?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5170010f70c29afc35e4e33fa2a14517e816f9b215b890ec6435784900b6660-4b2ec332aeca9225cebfa98f36f767e2e5441d244b50e4e9c609910bdbc6b341.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wulf Rehder")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-3/#comment-633442")[#strong[#text("Wulf Rehder")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2021")])]

#text("Thanks for the comment. I am not using the letter n. Perhaps you are referring to what I have called N=m+m+k, the length of the Collatz sequence after m multiplications by 3 and m+k divisions by 2. Clearly the sequence, starting at any seed like 11 or 27 or anything else, can come down below this seed only if there is an N such that 2^(m+k)>3^m or 2^((m+k)/m)>3. This is what I called “the powers of 2 win out” over the powers of 3.” The first N at which this happens is the stopping time. The Collatz Conjecture states that there always is such a finite N. The limiting case (the inf) for (m+k)/m is the real number s for which 2^s=3, or r such that 2=3^r. s and r=1/s are the fractal dimensions of the Sierpinski triangles and the Cantor set, respectively. In this (somewhat still superficial) sense, Collatz sequences are related to fractals. (In an earlier comment I gave the numbers k, m, and N for the seed 11. For the more interesting seed 27: m=37, k=22, m+k=59, and the stopping time is N=96. This sequence starting at 27 dips below 27 to 23 at this N, because this N is the first time the ratio (m+k)^N exceeds the “threshold” t=s/(s+1)=1/(r+1); see earlier comments.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9804b4a15be27bd787a1df0773165d0d72e517a13441535098a8f56a3b0872ff-c8c94a24a08c6eb5b94f2c4d70bece7ff5d69b31fdc5fb15ac579d621bb077ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hooobla")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-526947")[#strong[#text("hooobla")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2019")])]

#text("Let ")#mi("P(N)")#text(" denote power set of ")#mi("N")#text("(set of natural numbers).")#mi("P(P(.....P(N)...)")#text(" for n iterations is denoted by ")#mi("P(N,n)")#text(".Does there exists n such that there is bijection from ")#mi("P(N,n)")#text(" to ")#mi("R")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b08b827745114ecbcf181eee0a3a867a05ebe6d995372dd8705c25abb0e1196-21f4c0cf92482fc2101667c3851f102bf7ff008930ddeccf89069961030c4af6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of robfrotRob Frost")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-527143")[#strong[#text("robfrotRob Frost")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2019")])]

#text("no, there is no ceiling on $n$ because e.g. $(2^{2n}-1)/3$ is a solution.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f985f3fdedd929e8e88714ab5a69ce1658a5cbdea44831a7018b6d852fa11ea-12d4a8a20d234dadddcb2fa160f29899e33f9b2af27c00b8170017ce7cbbfc26.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert White")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-527225")[#strong[#text("Robert White")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2019")])]

#text("I have a computer program (visualizer) and computational analysis that proves the conjecture but I don’t have the math to express it in formal terms. The entire conjecture can be summarized as “hammering off significant digits destroys information”.")

#text("The insights come from the vector operators used in graphics routines where you load multiple scalars into a wide register and then work on (e.g. multiply) them all at once.")

#text("In essence, when viewed as an electronic computation in a register of infinite width you can ignore all the divide-by-two operations; in electronic computation dividing by two is just register shifting. The only reason to divide by two is to align the destructive +1 term with the least significant set bit in the register.")

#text("So once you replace the conditional divide-if-even and the aligned +1 with a vectorized operator to find the least set bit and add it into the term all the distracting “spirals” disappear.")

#text("The actual transformations at each step become")#linebreak()#text(" (1) Expansive Term -> N=N+3")#linebreak()#text(" (2) Destructive Term -> N+=(1<<count_trailing_zeros(n))")

#text("Now you have a finite state machine, a la Conway's game of life.")

#text("There are only four (if memory serves) possible bit patterns at the most significant position that the by which the Expansive Term can extend the value.")

#text("The Destructive Term can remove any number of bits up to but excluding the most significant bit.")

#text("There is no feedback system where bit N can affect any bit M where M is less than N.")

#text("Only a highly ordered least significant bitset can delay the destructive term, forcing ti to only consume one bit, but that ordered bitset creates a smaller, disordered bitset at its upper extent when processed by the Expansive Term; this means that the ordered bitset cannot propagate its properties indefinitely.")

#text("The result is that there can exist no bitset such that the Expansive Term can consistently produce as many extension bits as the Destructive Term consumes.")

#text("The visuallizer is super simple, but it's at home and I'm at work.")

#text("I can demonstrate all the validity of all the algorithmic transformations, including a version of the visualizer that works on the native (untransformed) original form of the function exactly as originally written.")

#text("I've been sitting on this for years but I don't know any mathematicians and everybody assumes the extra-disciplinary ideas are Dunning-Kruger madness.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cff95c1a9200c37f9f14319342305a733d3cc932b8f10a121306d1fe2679dc7-6071fd7255dc2dc3cfe34b4717111edc63fc626958a8ddb601d254afd37d4023.gif", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert White")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-527365")[#strong[#text("Robert White")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2019")])]

#text("Here’s the visualizer I discussed above. It uses the unmodified conjecture and does several simple things.")

#text("(1) It prints the binary from left-to-right least-to-most significant bit")#linebreak()#text(" (2) I counts up the number of times the term has been divided by 2.")#linebreak()#text(" (3) Puts in leading pad characters matching the number of times the divide/shift operation has taken place.")

#text("Arguments are [ [ ] ]")

#text("By default the fill character is underscore, but using a zero is particularly illuminating.")

#text("In the output mode you can use any value 1 through 7, lowest bit is “classic output mode” that shows the base conjecture result, second bit is show immediate value after multiply, third bit is show value after increment.")

#text("The default display value is six (6) which shows the condensed visualization without the “shift spirals”.")

#link("https://onlinegdb.com/S1c-3Vccr")[#text("https://onlinegdb.com/S1c-3Vccr")]

#text("Notice the montonic nature of the expansion, if forms a line of near constant slope. The destructive term has no such constraint.")

#text("The most interesting values are any 2^n and (2^n – 1) input. The former is an instant collapse to just one set bit, while the latter produces the longest possible sequence single-bit destructive delay possible for any number less than 2^n.")

#text("You just have to be ready to see the state machine instead of the divide-by-two spiral.")

#text("NOTE: visualizer not for non-positive numbers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b92b290706f3241ccb47947f5e3cda24b41c420e5e25e8d06ad280cc12b99a2f-6071fd7255dc2dc3cfe34b4717111edc63fc626958a8ddb601d254afd37d4023.gif", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert White")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-527367")[#strong[#text("Robert White")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2019")])]

#text("Self-reply…")

#text("My appologies, the web tool seems lock the arguments when I share the block. You may need to copy the code and paste it into a fresh project page.")

#text("The above block will run 1023 in classic mode, where the output is the classic conjecture “spiral”.")

#text("The below will run 1023 in the proof-visualization order.")

#link("https://onlinegdb.com/SkTCeH99H")[#text("https://onlinegdb.com/SkTCeH99H")]

#text("Compare the leading and trailing line slopes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b92b290706f3241ccb47947f5e3cda24b41c420e5e25e8d06ad280cc12b99a2f-6071fd7255dc2dc3cfe34b4717111edc63fc626958a8ddb601d254afd37d4023.gif", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert White")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-527369")[#strong[#text("Robert White")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2019")])]

#text("/sigh : arguments are [ value [ mode [ fill character ] ] ]")

#text("I wish the forum allowed editing, the first try ate the definition because I used angle-bracket like you do in linux manual pages.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b92b290706f3241ccb47947f5e3cda24b41c420e5e25e8d06ad280cc12b99a2f-6071fd7255dc2dc3cfe34b4717111edc63fc626958a8ddb601d254afd37d4023.gif", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert White")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-527379")[#strong[#text("Robert White")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2019")])]

#text("Ah, there’s that assumption again. No arguments against, just automatic downvote. 8-)")

#text("The data clearly shows that the Expansive term can only add one or two bits to the state machine while the Destructive term can remove any number from 1 to all-but-one bits in a single operation; and the two operations alway alternate one-for-one.")

#text("There is no possible bit pattern between the leading and trailing bits that can cause expansion by X1 or X01, and there is no pattern that sustain the all-ones pattern that prevents the destruction of more than one per cycle.")

#text("The internal disorder of the bits between the leader and trailer cannot stop the decay because a higher-order bit can never influence a lower-order bit in any way.")

#text("You just have to compare the pre and post increment values, which is where the information content of the number is discared/destroyed.")

#text("I’ll stop now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8ac10e76ba6efc8bf04050ed550db82a0eda91ba54ff2845c723e6ab1742bd0-f3c92350ff4ec849d2e12b1b78b92cc5275d73e735c18ed3a75cad6d54ea1738.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HCL")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-527391")[#strong[#text("HCL")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2019")])]

#text("Why is the title of the paper not “Almost all Collatz orbits attain bounded values”?")

#text("My second question is:")#linebreak()#text(" Why is the title of the paper not “All Collatz orbits attain almost bounded values”?")

#text("Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-527976")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2019")])]

#text("Why all the press like in popular mechanics about a preprint that doesn’t prove anything at all on 3x+1?")

#text("Tell you what though. There has been a spike in arxiv preprints the past few months. Even my preprint picked up another citation. But I actually proved some theorems… but who cares :-).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of y.y.")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-527818")[#strong[#text("y.y.")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2019")])]

#text("The page “Residue-class-wise affine group” in wikipedia writes “…Collatz conjecture, which is assertion about a surjective, but not injective residue-class-wise affine mapping.” Certainly, {2N_0+1} maps to {2N_0+1≢0(mod.3)}. but its inverse mapping, which is able to be bijection by rcwa with matrices. and I have found that. There can be defined easily “almost all odd” goes to small of itsef in n times iteration. and then also can be defined ￢”almost all odd” odd goes to small of itself in m times iteration by set theoritical way.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of y.y.")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-527992")[#strong[#text("y.y.")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2019")])]

#text("and the equation(because there exists a bijective map between x and f^-1(x)) contains S3.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/300d8a12b885d77f3192a824c86564c0a1817cdc6a2a4ae80efa09c39a1d0c1a-8fc37e7d7279dd42b76759943cab5328695639b1457f29ac7a49122dbfc5fba4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spesialcoklat WA:08984230641")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-528727")[#strong[#text("Spesialcoklat WA:08984230641")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2019")])]

#text("By following pde coprogress dn/dq=(3n+2)/2^q have solution ln(3n+2)^(1/3)=-1/(2^q.ln2)~ln(2^2^q) then q~log2log2(3n+2)^(1/3)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/462bd5e9ee569e447876f66a40c953b317609165e5f66b8f9505d15176e6f681-665fc191441616ec131bbd257df60299cc5971d16ff60c00a25214c38803d571.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudi")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-528912")[#strong[#text("Rudi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2019")])]

#text("Let ")#mi("f:\\mathbb{N}\\rightarrow\\mathbb{N}")#text(" be defined by ")#mi("f(n)=\\frac{6n+1+M_k}{4}")#text(" where ")#mi("n\\in\\mathbb{N}")#text(" and ")#mi("k\\in\\mathbb{N}")#text(", and ")#mi("M_k")#text(" is a Mersenne number.")

#mi("k")#text("-index may be found by finding the highest exponent that divides ")#mi("n")#text(". This can also be done by the bitwise exclusive or operator: ")#mi("\\oplus")

#text("Or we define the function as:")

#text("Let ")#mi("C:\\mathbb{N}\\rightarrow\\mathbb{N}")#text(":")#linebreak()#text(" ")#mi("C(n)=\\frac{3n}{2} + \\frac{n \\oplus (n-1) + 1}{4}")#text(" where ")#mi("n\\in\\mathbb{N}")#text(".")

#text("This is my first post ever with latex code on wordpress, so hopefully it is displayed correctly. The problem is to prove that one of these functions at some time in their trajectory reaches 2^x (some power of two), Or that all the remaining factors remaining are just twos.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/563cb79db503e33a0bd1df49f51a77968670dba3a3b024394a118db8cfa9f13d-4ed3a2708e0f7389ecb13cbc21273484b4dcd05d10d925a5685f2a17c871fa57.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Parry")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-529046")[#strong[#text("Daniel Parry")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2019")])]

#text("I was playing around with this problem for fun and I found that the Syracuse map you described pops out of using characteristic functions to run the Affine map backwards. It seems to describe the minimal element in the limit as n\\to \\infty.")

#text("The sequence \\vec{a} appears to be representing a path on the tree run in reverse. The minimal element of the cycle, as being part of a cycle, seems to imply that the a_i must be cyclical if it were to describe the minimum element.")

#text("Would this help in improving the analysis?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/362f5ca7bb1476387876b3ba4e911711718408c2275631da6ffb413b80148690-84db63a1e2eb4c22b0340c61cb580e9e9ad1eb3e26d9954d252d4127f67280ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of isaac mor")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-529430")[#strong[#text("isaac mor")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2019")])]

#text("in order to solve this problem you first need to get to the cycle bounds")

#text("like this:")

#text("Collatz Conjecture – Cycle bounds")

#text("x = number of even values in a cycle")#linebreak()#text(" y = number of odd values in a cycle")

#text("x+y < (8/9) * floor(1.5^y)")

#text("then you are lowering the limit even more …")

#text("to get to")

#text("positive cycles:")

#text("x = roundup ( y * ln3/ln2 )")

#text("negative cycles:")

#text("x = rounddown ( y * ln3/ln2 )")

#text("then you need to get the formula for the minimum cycle with the lower and higher values to be asa closest as possible")

#text("and then you can solve it :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a4d6cb73d1b79e4dc88c81e9613ea74dade4426e5c02ec1d5da58bfbd12e6c7-719878c54108199c66811b338702879cf98befe11de2ef2c8dd377bbad60c7d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Georgiy")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-530687")[#strong[#text("Georgiy")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2019")])]

#text("Best instrument to prove Collatz Conjecture is Canonical Collatz Tree")#linebreak()#text(" All details described in book")#linebreak()#text(" Proof of the Collatz conjecture (Problems – Ideas – Solutions) Amazon March 15, 2019 by Georgiytyshko Tyshko")#linebreak()#text(" Any questions and critics you may tell in")#linebreak()#text(" Howwewanttolive.livejournal.com")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81c7ee47219767de6af71eb6b5313e9894d7c3914be6d57431ae7e1b00c157a1-a1e079dc8e5844fbe1b13fa79adf07f02d1892bfbe1b6c1e95a39cc933de0cdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vznvzn")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-532317")[#strong[#text("vznvzn")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2019")])]

#text("hi TT fyi all heres a nice writeup in quanta mag")#linebreak()#text(" “Mathematician Proves Huge Result on ‘Dangerous’ Problem” ")#link("https://www.quantamagazine.org/mathematician-terence-tao-and-the-collatz-conjecture-20191211/")[#text("https://www.quantamagazine.org/mathematician-terence-tao-and-the-collatz-conjecture-20191211/")]

#text("delighted that you returned to this subj after ~8yrs. congrats on the recent results. a little annoyed with the tone of the article, but it probably does reflect widespread social anxiety about the problem. myself have called it like a “femme fatale”. there seems to be a semiconscious assumption of “all or nothing” on this problem even by the leaders in the field. what is wrong with incremental results? in a word, nothing!")

#text("collatz is an outstanding/ exceptional problem to work on. even if a researcher can see that a solution seems unlikely, new insights into the problem not seen elsewhere are not extremely difficult and feel theres no shame in pursuing them, quite to the contrary think its as honorable as the best of mathematics. it seems some of the aversion to this problem is that it hasnt been connected to any deep theory. but on the other hand, why not make the opposite conclusion, given that it doesnt seem to connect to anything known, that there must be deep *future* theory around here somewhere, that this is just a tip of an iceberg…!")

#text("my other complaint (and not pretending either that many are listening, lol) is that almost nobody talks about “fractals” in reference to this problem. there are some isolated exceptions. after many years of banging on it with computational experiments (and its great to hear you are not averse to them yourself) the fractal nature seems like a foremost aspect to approaching/ understanding it.")

#text("could write far more and have elsewhere, encourage visitors/ feedback ")#link("https://vzn1.wordpress.com/category/collatz/")[#text("https://vzn1.wordpress.com/category/collatz/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-532405")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2019")])]

#text("I still think about the numbers of the form (8) of the previous post")#linebreak()#text(" ")#mi("\\displaystyle 3^{k-1} 2^{a_1} + 3^{k-2} 2^{a_2} + \\ldots + 2^{a_k}")#linebreak()#text(" For orbits that reach 1")#linebreak()#text(" ")#mi("2^{ak+1}- n \\times 3^{k}")#text(" , they have this form.")#linebreak()#text(" For periodic orbits")#linebreak()#text(" ")#mi("(2^{ak+1}-3^{k}) \\times n")#text(", where k n numbers have this form")#linebreak()#text(" For unbounded orbits, none of the above conditions are met for infinite n numbers.")

#text("I have known this notable product, Difference of Nth Powers, which has a certain resemblance, with the problem at hand.")

#mi("a^{n}-b^{n}= (a-b)(a^{n-1}+a^{n-2}b+a^{n-3}b^{2}+...+b^{n-1})")

#text("Could it be useful for the Collatz conjecture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533847")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2019")])]

#text("The intention of this strategy is to demonstrate that there are no unbounded orbits. The way to achieve it would be to know if it is possible to transfer the properties of the notable product difference of nth powers, that is, the form, (8), to any possible Collatz sequence. If there is a mechanism that converts the difference of nth potency into a Collatz sequence, and there is always an n such that the difference conserves the form (8), then perhaps, it would be possible to affirm that all the orbits are bounded to the nth power.")#linebreak()#text(" I have not found that mechanism, but perhaps for some of you, it is easier to find that mechanism, or of course, to rule out that possibility.")#linebreak()#text(" I present some examples in case someone sees how a difference of nth power is transformed into a sequence of Collatz, where the difference maintains the form (8).")

#text("For ")#mi("3^{1}-2^{1}= 1")

#mi("2^{4}-3^{1} \\times {\\color{Red} 5}= 1")#linebreak()#text(" ")#mi("2^{6}-3^{1 }\\times {\\color{Red} 21}= 1")#linebreak()#text(" ")#mi("2^{8}-3^{1} \\times {\\color{Red} 85}= 1")#linebreak()#text(" …")

#text("For ")#mi("3^{2}-2^{2}= 3^{1}+2^{1}= 5")

#mi("2^{5}-3^{2} \\times {\\color{Red} 3}= 3^{1}+2^{1}=5")#linebreak()#text(" ")#mi("2^{7}-3^{2} \\times {\\color{Red} 13}= 3^{1}+2^{3}= 11")#linebreak()#text(" ")#mi("2^{9}-3^{2} \\times {\\color{Red} 53}= 3^{1}+2^{5}= 35")#linebreak()#text(" ")#mi("2^{10}-3^{2} \\times {\\color{Red} 113}= 3^{1}+2^{2}= 7")#linebreak()#text(" …")#linebreak()#text(" For ")#mi("3^{3}-2^{3}= 3^{2}+3^{1} \\times 2^{1}+2^{2}= 19")

#mi("2^{9}-3^{3} \\times {\\color{Red} 17}= 3^{2}+3^{1} \\times 2^{2}+2^{5}= 53")#linebreak()#text(" ")#mi("2^{10}-3^{3} \\times {\\color{Red} 35}= 3^{2}+3^{1} \\times 2^{1}+2^{6}= 79")#linebreak()#text(" ")#mi("2^{11}-3^{3} \\times {\\color{Red} 75}= 3^{2}+3^{1} \\times 2^{1}+2^{3}= 23")#linebreak()#text(" …")

#text("For ")#mi("3^{4}-2^{4}= 3^{3}+3^{2} \\times 2^{1}+3^{1} \\times 2^{2}+2^{3}= 65")

#mi("2^{10}-3^{4} \\times {\\color{Red} 11}= 3^{3}+3^{2} \\times 2^{1}+3^{1} \\times 2^{3}+2^{6}= 133")#linebreak()#text(" ")#mi("2^{11}-3^{4} \\times {\\color{Red} 23}= 3^{3}+3^{2} \\times 2^{1}+3^{1} \\times 2^{2}+2^{7}= 185")#linebreak()#text(" ")#mi("2^{12}-3^{4} \\times {\\color{Red} 45}= 3^{3}+3^{2} \\times 2^{3}+3^{1} \\times 2^{5}+2^{8}= 451")#linebreak()#text(" …")

#text("For ")#mi("3^{5}-2^{5}= 3^{4}+3^{3} \\times 2^{1}+3^{2} \\times 2^{2}+3^{1} \\times 2^{3}+2^{4}= 211")

#mi("2^{11}-3^{5} \\times {\\color{Red} 7}= 3^{4}+3^{3} \\times 2^{1}+3^{2} \\times 2^{2}+3^{1} \\times 2^{4}+2^{7}= 347")#linebreak()#text(" ")#mi("2^{12}-3^{5} \\times {\\color{Red} 15}= 3^{4}+3^{3} \\times 2^{1}+3^{2} \\times 2^{2}+3^{1} \\times 2^{3}+2^{8}= 451")#linebreak()#text(" ")#mi("2^{13}-3^{5} \\times {\\color{Red} 29}= 3^{4}+3^{3} \\times 2^{3}+3^{2} \\times 2^{4}+3^{1} \\times 2^{6}+2^{9}= 1145")#linebreak()#text(" …")#linebreak()#text(" …")

#text("**orbits belongs to numbers in red color.")

#text("***numbers with form (8) are")

#mi("\\displaystyle 3^{k-1} 2^{a_1} + 3^{k-2} 2^{a_2} + \\ldots + 2^{a_k}= 3^{k-1}+6\\chi +2^{a_{k}}")

#text("and numbers with form")#linebreak()#text(" ")#mi("a^{n-1}+ a^{n-2}b+a^{n-3}b^{2}+...+b^{n-1}= a^{n-1}+ab\\chi +b^{n-1}")

#text("it’s obvious, but maybe ")#mi("\\chi")#text(" may have relevance. Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534440")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2020")])]

#text("Examples of some know orbits")

#text("For ")#mi("3^{1}-2^{1}= 1")

#mi("2^{4}-3^{1} \\times 5= 1")#linebreak()#text(" ")#mi("2^{6}-3^{1 }\\times  21= 1")#linebreak()#text(" ")#mi("2^{8}-3^{1} \\times 85= 1")#linebreak()#text(" …")

#text("For ")#mi("3^{2}-2^{2}= 3^{1}+2^{1}= 5")

#mi("2^{5}-3^{2} \\times  3= 3^{1}+2^{1}=5")#linebreak()#text(" ")#mi("2^{7}-3^{2} \\times 13= 3^{1}+2^{3}= 11")#linebreak()#text(" ")#mi("2^{9}-3^{2} \\times 53= 3^{1}+2^{5}= 35")#linebreak()#text(" ")#mi("2^{10}-3^{2} \\times 113= 3^{1}+2^{2}= 7")#linebreak()#text(" …")#linebreak()#text(" For ")#mi("3^{3}-2^{3}= 3^{2}+3^{1} \\times 2^{1}+2^{2}= 19")

#mi("2^{9}-3^{3} \\times 17= 3^{2}+3^{1} \\times 2^{2}+2^{5}= 53")#linebreak()#text(" ")#mi("2^{10}-3^{3} \\times 35= 3^{2}+3^{1} \\times 2^{1}+2^{6}= 79")#linebreak()#text(" ")#mi("2^{11}-3^{3} \\times 75= 3^{2}+3^{1} \\times 2^{1}+2^{3}= 23")#linebreak()#text(" …")

#text("For ")#mi("3^{4}-2^{4}= 3^{3}+3^{2} \\times 2^{1}+3^{1} \\times 2^{2}+2^{3}= 65")

#mi("2^{10}-3^{4} \\times 11= 3^{3}+3^{2} \\times 2^{1}+3^{1} \\times 2^{3}+2^{6}= 133")#linebreak()#text(" ")#mi("2^{11}-3^{4} \\times  23= 3^{3}+3^{2} \\times 2^{1}+3^{1} \\times 2^{2}+2^{7}= 185")#linebreak()#text(" ")#mi("2^{12}-3^{4} \\times  45= 3^{3}+3^{2} \\times 2^{3}+3^{1} \\times 2^{5}+2^{8}= 451")#linebreak()#text(" …")

#text("For ")#mi("3^{5}-2^{5}= 3^{4}+3^{3} \\times 2^{1}+3^{2} \\times 2^{2}+3^{1} \\times 2^{3}+2^{4}= 211")

#mi("2^{11}-3^{5} \\times 7= 3^{4}+3^{3} \\times 2^{1}+3^{2} \\times 2^{2}+3^{1} \\times 2^{4}+2^{7}= 347")#linebreak()#text(" ")#mi("2^{12}-3^{5} \\times 15= 3^{4}+3^{3} \\times 2^{1}+3^{2} \\times 2^{2}+3^{1} \\times 2^{3}+2^{8}= 451")#linebreak()#text(" ")#mi("2^{13}-3^{5} \\times 29= 3^{4}+3^{3} \\times 2^{3}+3^{2} \\times 2^{4}+3^{1} \\times 2^{6}+2^{9}= 1145")#linebreak()#text(" …")#linebreak()#text(" …")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534456")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2020")])]

#text("Now let’s look and compare some known orbits.")

#mi("3^{2}-2^{2}= 3+2= 5 \\mapsto 2^{5}-3^{2} \\times 3= 5")

#mi("2^{2} \\times 2^{3}= 3^{2} \\times 2^{3}-5 \\times 2^{3}")

#mi("2^{2} \\times 2^{3}= (3^{2} \\times 2^{3}-3^{2} \\times 5)-5 \\times 2^{3}+3^{2} \\times 5")

#mi("3^{2}-2^{2}=3+2=5 \\mapsto 2^{7}-3^{2} \\times 13 = 3+2^{3}=11")

#mi("2^{2} \\times 2^{5}= 3^{2} \\times 2^{5}-5 \\times 2^{5}")

#mi("2^{2} \\times 2^{5}= 3^{2} \\times 2^{5}-3^{2} \\times 19-(5 \\times 2^{5}-3^{2}\\times 19)")

#mi("3^{3}-2^{3}= 3^{2}+3 \\times 2+2^{2}= 19 \\mapsto 2^{9}-3^{3} \\times 17= 3^{2}+3 \\times 2^{2}+2^{5}= 53")

#mi("2^{3} \\times 2^{6}= 3^{3} \\times 2^{6}-19 \\times 2^{6}")

#mi("2^{3} \\times 2^{6}= 3^{3} \\times 2^{6}-3^{3} \\times 47-(19 \\times 2^{6}-3^{3} \\times 47)")

#text("Is it possible to establish a general mechanism that relates the difference of nth power and the orbits of Collatz? Is this mechanism trivial or does it provide us with no interesting information?")#linebreak()#text(" At the moment I can not visualize this general mechanism, although obviously these are known orbits that end in 1, could we establish that there is always an n that meets equality and the difference preserves the shape? Could it be used to rule out the existence of periodic orbits? Thank you.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-537916")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2020")])]

#link("https://drive.google.com/open?id=14de4QiGD147d1yIfnrupbTEtB2E-3idF")[#text("https://drive.google.com/open?id=14de4QiGD147d1yIfnrupbTEtB2E-3idF")]#linebreak()#text(" Hi everyone. Although there is a new post by Professor Tao, I wanted to close my approach to the conjecture with a basic scheme that summarizes my approach. The numbers of the form (8) share structure with the difference of nth power, which to simplify I call it TCR, Tao-Collatz Reminder.")#linebreak()#text(" The conjecture needs to answer two questions:")#linebreak()#text(" -1. Are there periodic orbits?")#linebreak()#text(" -2. are there infinite orbits?")#linebreak()#text(" We know that the conjecture is true for many values. All reach 1 and there are no periodic orbits (except the trivial).")#linebreak()#text(" This approach to the conjecture through the notable product difference of nth power could serve to illustrate the mechanism of why the orbits reach 1, and also how the mechanism of the periodic orbits works and why they cannot occur for the powers of 2 and 3 .")#linebreak()#text(" Once this question was resolved, one could then attack the existence or not of infinite orbits, or at least, do it independently.Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-541794")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2020")])]

#text("Continuing with this approach to the Collatz conjecture from the notable product difference Nth powers and focusing on the study of periodic orbits, we find a condition that meets the known periodic orbits of maps ")#mi("3n-1")#text(" and ")#mi("5n + 1")#text(".")#linebreak()#text(" For a periodic orbit, it is fulfilled that")

#mi("2^{k}< 3^{k}< 2^{k+y}< 3^{k}\\times n< 2^{k+y}\\times n")

#text("Is this condition necessary for a periodic orbit?")#linebreak()#text(" Unlike the orbits that reach 1")

#mi("2^{k}< 3^{k}< 3^{k}\\times n < 2^{k+y}")

#text("Can this condition be possible in a periodic orbit?")

#text("For maps type ")#mi("an-1")#text(" we have that, for a periodic orbit")

#mi("2^{k}< 2^{k+y}< 3^{k}< 2^{k+y}\\times n < 3^{k}\\times n")

#text("Unlike the orbits that reach 1")

#mi("2^{k} < 3^{k}< 2^{k+y}< 3^{k}\\times n")#text(",")

#text("their behavior is a little different, but the structure of the periodic orbits is equivalent.")

#text("Some concepts to consider:")

#text("-Multiples of 3 cannot enter periodic orbit.")#linebreak()#text(" -The notable product difference of nth powers is the value")

#mi("2^{k}-3^{k}=3^{k-1}+3^{k-2}\\times 2^{1}+...+2^{k-1}")

#text("whose structure coincides with the numbers of the form (8) from the post ")#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-")[#text("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-")]#text(" and-3 / , which I call ")#mi("TCR")#text(" for short, and that coincides with the minimum possible value for")

#mi("2^{k+y}\\times n - 3^{k}\\times n=n\\times x= TCR_{min}")

#text("–")#mi("2^{k+y}-3^{k}= x")#text(",")

#mi("2^{k+y} \\times n -3^{k} \\times n= n \\times x")

#text("–")#mi("k+y")#text(" is the number of even steps, then ")#mi("y")#text(" is the increment of divisions of 2 with respect to ")#mi("k")

#text("–")#mi("k")#text(" is the number of even steps, and in a periodic orbit represents the cardinality of the set of odd numbers ")#mi("(n_{1}< ... 1")#linebreak()#text(" ")#mi("2^{6}\\setminus 3^{3}> 2")#linebreak()#text(" ")#mi("2^{7}\\setminus 3^{3}> 4")#linebreak()#text(" ")#mi("2^{8}\\setminus 3^{3}> 9")#linebreak()#text(" ")#mi("2^{9}\\setminus 3^{3}> 18")#linebreak()#text(" ")#mi("2^{10}\\setminus 3^{3}> 37")

#text("If ")#mi("x 3")

#text("We can find the values of ")#mi("n_{max}")#text(" for each ")#mi("2^{k+y}")#text(" from the values of ")#mi("TCR_{max}")

#text("For ")#mi("2^{5}\\rightarrow TCR_{max}=49\\setminus 5=(2^{k+y}-3^{k})\\leq 9")#linebreak()#text(" For ")#mi("2^{6}\\rightarrow TCR_{max}=89\\setminus 37=(2^{k+y}-3^{k})\\leq 2")#linebreak()#text(" For ")#mi("2^{7}\\rightarrow TCR_{max}=169\\setminus 101=(2^{k+y}-3^{k})\\leq 1")#linebreak()#text(" For ")#mi("2^{8}\\rightarrow TCR_{max}=329\\setminus 229=(2^{k+y}-3^{k})\\leq 1")

#text("For this orbit, we can observe that when the values of ")#mi("y")#text(" increase, the distance ")#mi("x")#text(" increases much faster than ")#mi("TCR_ {max}")#text(", which seems to make a solution incompatible that is not for values of ")#mi("2^{k+y}")#text(" closer to ")#mi("3^{k}")#text(".")

#text("with the possible periodic orbit ")#mi("3^{3}-2^{5}=5")#text(", we hava that ")#mi("n_{min} > 3")#text(" and ")#mi("n_{max}\\leq 9")#text(". The values 5,7,9 are possible solution but we know that 3 multiples cannot enter in a periodic orbit and we have not k solutions.")#linebreak()#text(" But it seems that we are missing something else, somehow we need to find a minimum value for ")#mi("n_ {max}")#text(", that is, that between ")#mi("n_{1}")#text(" and ")#mi("n_{k}")#text(" there is a minimum distance within the possible solutions to the periodic orbit, which becomes more evident with the study of the possible orbits for ")#mi("3^{4}")#text(", ")#mi("3^{5}")#text(", …")#linebreak()#text(" Having explored several options,one of the possible ways to calculate the minimum value of ")#mi("n_ {max}")#text(" could be:")

#mi("\\frac{TCR_{min}}{n_{min}}= \\frac{TCR_{max}}{n_{max}}")

#text("and we have that ")#mi("\\frac{19}{5}= \\frac{49}{n_{max}}\\Rightarrow n_{max}> 12")#text(", but in the orbit ")#mi("n_{max}\\leq  9")#text(", that is out of range. Although I understand that it seems a bit “ad hoc”.")

#text("-Periodic orbits for ")#mi("3^{4}")#text(", where")

#mi("2^{7}-3^{4}= 47= x")#text(",")#mi("3^{4}-2^{4}= TCR_{min}= 65")#text(",")#mi("n_{min}= \\frac{65}{47}> 1")#text(",")#mi("TCR_{max}= 331")#text(",")#mi("n_{max}= \\frac{331}{47}\\leq 7")#text(",")#mi("\\frac{TCR_{min}}{3}= \\frac{TCR_{max}}{n_{max}}\\rightarrow \\frac{65}{3}= \\frac{331}{n_{max}}\\rightarrow n_{max}> 15")

#text("-Periodic orbits for ")#mi("3^{5}")#text(", where")

#mi("2^{8}-3^{5}= 13= x")#text(",")#mi("3^{5}-2^{5}= TCR_{min}= 211")#text(",")#mi("n_{min}= \\frac{211}{13}> 16")#text(",")#mi("TCR_{max}= 1121")#text(",")#mi("n_{max}= \\frac{1121}{13}\\leq 86")#text(",")#mi("\\frac{TCR_{min}}{17}= \\frac{TCR_{max}}{n_{max}}\\rightarrow \\frac{211}{17}= \\frac{1121}{n_{max}}\\rightarrow n_{max}> 90")

#text("Of course it is necessary to implement this approach to ")#mi("(k,n,x,y)\\rightarrow \\infty")#text(" and improve the calculations of ")#mi("n_ {min}")#text(", ")#mi("n_ {max}")#text(", ")#mi("TCR_ {max}")#text(" and give rigor and mathematical structure, if possible, of course.Somehow it seems that for every possible periodic orbit between a power of 2 and 3 the ")#mi("n_{max}")#text(" value is always lower than the minimum $latex n_{max} needed to form a periodic orbit. I assume that this work, with my basic mathematics, can be totally useless, but, as always, I hope it can be useful to answer the question: Are there periodic orbits in the Collatz conjecture?")#linebreak()#text(" At your disposal. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-541948")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2020")])]

#text("**note: I upload the comment again because a part has not been loaded and I have corrected some minor errors.")

#text("Continuing with this approach to the Collatz conjecture from the notable product difference Nth powers and focusing on the study of periodic orbits, we find a condition that meets the known periodic orbits of maps ")#mi("3n-1")#text(" and ")#mi("5n + 1")#text(".")

#text("For a periodic orbit, it is fulfilled that")

#mi("2^{k}< 3^{k}< 2^{k+y}< 3^{k}\\times n< 2^{k+y}\\times n")

#text("Is this condition necessary for a periodic orbit?")

#text("Unlike the orbits that reach 1")

#mi("2^{k}< 3^{k}< 3^{k}\\times n < 2^{k+y}")

#text("Can this condition be possible in a periodic orbit?")

#text("For maps type ")#mi("3n-1")#text(" we have that, for a periodic orbit")

#mi("2^{k}< 2^{k+y}< 3^{k}< 2^{k+y}\\times n < 3^{k}\\times n")

#text("Unlike the orbits that reach 1")

#mi("2^{k} < 3^{k}< 2^{k+y}< 3^{k}\\times n")#text(",")

#text("their behavior is a little different, but the structure of the periodic orbits is equivalent.")

#text("Some concepts to consider:")

#text("-Multiples of 3 cannot enter periodic orbit.")#linebreak()#text(" -The notable product difference of nth powers is the value")

#mi("2^{k}-3^{k}=3^{k-1}+3^{k-2}\\times 2^{1}+...+2^{k-1}")

#text("whose structure coincides with the numbers of the form (8) from post ")#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3")[#text("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3")]#text(" /, which I call ")#mi("TCR")#text(" for short, and that coincides with the minimum possible value for")

#mi("2^{k+y}\\times n - 3^{k}\\times n=n\\times x= TCR_{min}")

#text("–")#mi("2^{k+y}-3^{k}= x")#text(",")

#mi("2^{k+y} \\times n -3^{k} \\times n= n \\times x")

#text("–")#mi("k+y")#text(" is the number of even steps, then ")#mi("y")#text(" is the increment of divisions of 2 with respect to ")#mi("k")

#text("–")#mi("k")#text(" is the number of odd steps, and in a periodic orbit represents the cardinality of the set of odd numbers ")#mi("n_{1}< ... 1")#linebreak()#text(" ")#mi("2^{6}\\setminus 3^{3}> 2")#linebreak()#text(" ")#mi("2^{7}\\setminus 3^{3}> 4")#linebreak()#text(" ")#mi("2^{8}\\setminus 3^{3}> 9")#linebreak()#text(" ")#mi("2^{9}\\setminus 3^{3}> 18")#linebreak()#text(" ")#mi("2^{10}\\setminus 3^{3}> 37")

#text("If ")#mi("x 3")

#text("We can find the values of ")#mi("n_{max}")#text(" for each ")#mi("2^{k+y}")#text(" from the values of ")#mi("TCR_{max}")

#text("For ")#mi("2^{5}\\rightarrow TCR_{max}=49\\setminus 5=(2^{k+y}-3^{k})\\leq 9")#linebreak()#text(" For ")#mi("2^{6}\\rightarrow TCR_{max}=89\\setminus 37=(2^{k+y}-3^{k})\\leq 2")#linebreak()#text(" For ")#mi("2^{7}\\rightarrow TCR_{max}=169\\setminus 101=(2^{k+y}-3^{k})\\leq 1")#linebreak()#text(" For ")#mi("2^{8}\\rightarrow TCR_{max}=329\\setminus 229=(2^{k+y}-3^{k})\\leq 1")

#text("For this orbit, we can observe that when the values of ")#mi("y")#text(" increase, the distance ")#mi("x")#text(" increases much faster than ")#mi("TCR_ {max}")#text(", which seems to make a solution incompatible that is not for values of ")#mi("2^{k+y}")#text(" closer to ")#mi("3^{k}")#text(".")

#text("with the possible periodic orbit ")#mi("3^{3}-2^{5}=5")#text(", we hava that ")#mi("n_{min} > 3")#text(" and ")#mi("n_{max}\\leq 9")#text(". The values 5,7,9 are possible solution but we know that 3 multiples cannot enter in a periodic orbit and we have not k solutions.")#linebreak()#text(" But it seems that we are missing something else, somehow we need to find a minimum value for ")#mi("n_ {max}")#text(", that is, that between ")#mi("n_{1}")#text(" and ")#mi("n_{k}")#text(" there is a minimum distance within the possible solutions to the periodic orbit, which becomes more evident with the study of the possible orbits for ")#mi("3^{4}")#text(", ")#mi("3^{5}")#text(", …")#linebreak()#text(" Having explored several options,one of the possible ways to calculate the minimum value of ")#mi("n_ {max}")#text(" could be:")

#mi("\\frac{TCR_{min}}{n_{min}}= \\frac{TCR_{max}}{n_{max}}")

#text("and we have that ")#mi("\\frac{19}{5}= \\frac{49}{n_{max}}\\Rightarrow n_{max}> 12")#text(", but in the orbit ")#mi("n_{max}\\leq  9")#text(", that is out of range. Although I understand that it seems a bit “ad hoc”.")

#text("-Periodic orbits for ")#mi("3^{4}")#text(", where")

#mi("2^{7}-3^{4}= 47= x")#text(",")#mi("3^{4}-2^{4}= TCR_{min}= 65")#text(",")#mi("n_{min}= \\frac{65}{47}> 1")#text(",")#mi("TCR_{max}= 331")#text(",")#mi("n_{max}= \\frac{331}{47}\\leq 7")#text(",")#mi("\\frac{TCR_{min}}{3}= \\frac{TCR_{max}}{n_{max}}\\rightarrow \\frac{65}{3}= \\frac{331}{n_{max}}\\rightarrow n_{max}> 15")

#text("-Periodic orbits for ")#mi("3^{5}")#text(", where")

#mi("2^{8}-3^{5}= 13= x")#text(",")#mi("3^{5}-2^{5}= TCR_{min}= 211")#text(",")#mi("n_{min}= \\frac{211}{13}> 16")#text(",")#mi("TCR_{max}= 1121")#text(",")#mi("n_{max}= \\frac{1121}{13}\\leq 86")#text(",")#mi("\\frac{TCR_{min}}{17}= \\frac{TCR_{max}}{n_{max}}\\rightarrow \\frac{211}{17}= \\frac{1121}{n_{max}}\\rightarrow n_{max}> 90")

#text("Of course it is necessary to implement this approach to ")#mi("(k,n,x,y)\\rightarrow \\infty")#text(" and improve the calculations of ")#mi("n_ {min}")#text(", ")#mi("n_ {max}")#text(", ")#mi("TCR_ {max}")#text(" and give rigor and mathematical structure, if possible, of course.Somehow it seems that for every possible periodic orbit between a power of 2 and 3 the ")#mi("n_{max}")#text(" value is always lower than the minimum ")#mi("n_{max}")#text(" needed to form a periodic orbit. I assume that this work, with my basic mathematics, can be totally useless, but, as always, I hope it can be useful to answer the question: Are there periodic orbits in the Collatz conjecture?")#linebreak()#text(" At your disposal. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d88a999d593035d7e2b9ea8dd30059fef11fd087df25fbcc7f71fbeb082971c3-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-555100")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2020")])]

#text("To finish this argument about periodic orbits we can establish that ")#mi("2^{y}-3^{k} = d")#text(", we need ")#mi("n_{1}.n_{2}, ... n_{k}")#text(" values, at least, such that ")#mi("n \\times d")#text("have the form of TCR(8) and are between a min and max value. Let’s see a simple example")

#mi("2^{5}-3^{3}=5")

#mi("TCR_{min}=2^{3}-3^{3}=3^{2}+3\\times 2+2^{2}=19")

#mi("TCR_{2}=3^{2}+3\\times 2+2^{3}=23")

#mi("TCR_{3}=3^{2}+3\\times 2+2^{4}=31")

#mi("TCR_{4}=3^{2}+3\\times 2^{2}+2^{3}=29")

#mi("TCR_{5}=3^{2}+3\\times 2^{2}+2^{4}=37")

#mi("TCR_{max}=3^{2}+3\\times 2^{3}+2^{4}=49")

#text("We can see that of all the possible values, none is a multiple of d, so they do not meet this condition. This fact must be maintained, if the conjecture is true, for all distances between ")#mi("3^{k}+d=2^{y}")#text(". For all possible values, there are no k values multiple of d.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d88a999d593035d7e2b9ea8dd30059fef11fd087df25fbcc7f71fbeb082971c3-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-555817")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2020")])]

#text("A possible way to study possible periodic orbits")

#mi("n\\times (2^{y}-3^{k})=3^{k-1}+3\\times x+2^{^{k-1,...,y-1}}")

#text("Or otherwise")

#mi("n=\\frac{3^{k}-2^{k}+\\triangle TCR}{2^{y}-3^{k}}=\\frac{3^{k}-2^{k}+\\triangle TCR}{(2^{y}-2^{k})-(3^{k}-2^{k})}")

#mi("\\triangle TCR")#text("= increments from minimum to maximum value, and it can take values")

#mi("\\triangle TCR=3x+2^{k+1,k+2,...y-1}")#text(", where x can be 0")

#mi("2^{y}-2^{k}=2^{k}\\times (2^{y-k}-1)")

#text("Is possible?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cc1791b002d33dcfddb2c4db7e15adb633ce58fa5d519a33d8b2024f3a4babc-86d0ed2a2c921533c387e8774d284836c9a38fe8c179a0a6678ccf125334e32b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Smith foster")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-532414")[#strong[#text("Smith foster")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2019")])]

#text("How about this way?")#linebreak()#text(" If it’s possible to prove the equation")#linebreak()#text(" “2^a+(2^b-1)/3+3c=n”")#linebreak()#text(" is correct, which means ,to each positive integer “n”, there is a series of numbers “a” “b” “c”(they are all positive integer, and they are not related to each other ) to make up the “n”.")#linebreak()#text(" Because when you list the numbers from “1” to a larger number according to the forming order, there is no branch until it’s “16”, either “5” or “32” is ok to result in “16” , and if you continue to list the numbers, you’ll find these three basic forms are ok to result in “1” .")#linebreak()#text(" Actually I’ve found there are some mistakes this way, but does this conception work?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/40a2bf4276ee9129885bb53e46c7e2b95ad2ea166093fc13795dfcd2e8ceb3b1-b109fc37e1fa8a30495a4d20763ca68365c494e67fdc8934ff6da115b874dad8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thor")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-532711")[#strong[#text("thor")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2019")])]

#text("There are 8 kinds of odds for 16k+1, 16k+3, 16k+5, 16k+7, 16k+9, 16k+11, 16k+13, 16k+15. If you can prove after some steps, the 8 kinds always appear in same probability, the odd numbers will keep getting smaller. The Collatz conjecture can be proved.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/299cf347497591e2825a98fe3ed4bfd64279952115afbb4130aa0182d43874c0-8464bd819c940e65b941c9e38aecf394aba5dbab4b860bb4703a6f35032fa8ce.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giả thuyết 3n+1 | REDSTAR-BLOG DÀNH CHO TOÁN")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-532753")[#strong[#text("Giả thuyết 3n+1 | REDSTAR-BLOG DÀNH CHO TOÁN")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2019")])]

#text("[…] đây nhà toán học lỗi lạc Terence Tao vừa có một bước tiến lớn sau vài thập kỉ cho giả thuyết 3n+1 hay còn được gọi là giả […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00bb40d937b4dd3d4afe0c817a19d500d4b7f22fb8ac5377b73c8220e445c89b-b9b17c4f162368612f0fe2a57d110b512be1babace5eb5b3119be8f0b46ea801.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt: Comments And Collatz Conundrum - RSSFeedsCloud")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-532912")[#strong[#text("Matt: Comments And Collatz Conundrum - RSSFeedsCloud")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2019")])]

#text("[…] always said that comments are the best part of blogging, but this is a particularly cool example. Here’s Terence’s latest post on it, with an excellent comment thread […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-532994")[#strong[#text("面对数学史上最简单的未解之谜，陶哲轩给出了几十年来最重要的证明！ - 程式筆記")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2019")]

#text("[…] Almost all Collatz orbits attain almost bounded values […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Mark Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533048")[#strong[#text("Michael Mark Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2019")])]

#text("Collatz sequences are essentially a parlor trick. While I’m sure Professor Tao has uncovered much of value in his recent paper, the 3x+1 problem has no intrinsic value. I can state the solution in its simplest form as just this:")

#text("Given three arithmetic operations, a, b, c:")

#text("a = ((n + 1) * (3 / 2)) – 1")#linebreak()#text(" b = ((n – 1) * (3 / 4)) + 1")#linebreak()#text(" c = (n – 1) * (1 / 4)")

#text("For every odd number n, either a or b or c is a whole odd number. That’s it – everything else is embellishment and ornamentation (in particular, the even numbers).")

#text("For visual thinkers: ")#link("https://drive.google.com/file/d/1iY7HMO0BJbdw9EQX3BnYGvXDyBNQ1ITH/view")[#text("https://drive.google.com/file/d/1iY7HMO0BJbdw9EQX3BnYGvXDyBNQ1ITH/view")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533061")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2019")])]

#text("Don’t think we’ll see revision 3 any time soon. But for you, what about 3x-1?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Mark Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533053")[#strong[#text("Michael Mark Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2019")])]

#text("I must rephrase that for the sake of proving I can write grammatical English: “For every odd number n, only a or b or c can be a whole odd number.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533095")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2019")])]

#text("You have to prove that the usual two piece 3x+1 function is ‘equivalent’ to your three piece function on the odds. This is the so called ‘transference’ Terry wants for his preprint, but is impossible to achieve in way one can extract trustworthy results from with a probabilistic approach. So prove equivalence, Then you can work with your new function and rigorously prove stuff to knock our socks off with:-). It is not enough that only one of either a, b or c is odd for a given odd input.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533144")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2019")])]

#text("How many odds have you tested? Any professional number theorist would perk up at an opportunity to explain why the two mappings coincide on the odds under repeated iteration.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533146")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2019")])]

#text("Also, proving equivalence in this case and for larger classes of functions may be really helpful in and of itself. But you will still be stuck trying to prove the non existence of non trivial cycles for 3x+1. And your a results in an increase to the sequence whereas b and c give decreases.")

#text("But your observation is really good. Glad you have kept pushing it into the public eye!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533155")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2019")])]

#text("Charles Cadogen already proved your c. It should not be too hard to prove your a and b and establish equivalence.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533158")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2019")])]

#text("Hmm maybe not. 13 maps to 5 under 3x+1 but it maps to 3 under your map. Am I missing something? This is why I asked how many odds you have checked.")

#text("Nonetheless, something of value may truly be found in your observation. Calculations should guide you here.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c601d9d0a98f58522df7c5f9c050028fbcca046ca4dcb3a5a121a1f019f9f628-81512661237e99b7fa5f07ff96c7a55dc0c4fbebac5f9b2d8aff2c8001eb343d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sharmila Kopanathi")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533230")[#strong[#text("Sharmila Kopanathi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2019")])]

#text("Dear Prof. Tao and the rest of the research community,")#linebreak()#text(" I apologize for barging into a research discussion forum to seek your urgent help, but such is my current circumstance. I left the US for India in 2013 to work on a couple of unsolved problems on my own. I got some preliminary results related to integer factorization in Oct 2017. Since then, my laptops have been taken over, I was put on 24/7 surveillance and my house has been bugged. They have practically taken over my life, preventing me from enjoying even momentary solitude to continue my work. They stole my past and present work. They started using advanced psychological torture techniques against me taking advantage of my inability to cope due to severe anxiety associated with this situation. They started commenting online about my most private activities. I experienced sudden shocks to my brain several times during these past 5 years. I experienced facial paralysis and reduced vision. This terror campaign continues to this day. They have recruited my neighbors as well to harass, humiliate and invade my privacy 24/7 from close proximity. They destroyed 5 years of my precious life. The local police, the FBI , IC3 have not been of any help. I tried sending you, Profs. Manindra Agrawal,, Manjul Bhargava emails. I even spoke to Prof. Agrawal a couple of times. He even acknowledged that he received my email. I have since been blocked from contacting anyone n the US, Please help me escape this terror campaign. Thank you. My gmail is not secure. Nor is my twitter account.")#linebreak()#text(" Sincerely, Sharmila Kopanathi")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Mark Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533279")[#strong[#text("Michael Mark Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2019")])]

#text("Thank you for the generous response to my post. Here is essentially the same thing (I hope my latex works) as a function using congruence classes.")

#mi("f(n) = \\begin{cases} n+ \\frac {n+1}{2} & \\text{if } n+1 \\equiv 0 \\text{ (mod } 4) \\\\ n-\\frac{n-1}{4} & \\text{if } n-1 \\equiv 0 \\text{ (mod } 8) \\\\ \\frac{n-1}{4} & \\text{otherwise} \\end{cases}")

#text("The table should show why this has to be an infinite function.")#linebreak()#text(" ")#link("https://drive.google.com/file/d/1yDClElWLnm1H-dsa_KeBorcl44A8yNfY/view?usp=sharing")[#text("https://drive.google.com/file/d/1yDClElWLnm1H-dsa_KeBorcl44A8yNfY/view?usp=sharing")]#linebreak()#text(" (You’ll notice that input a, b, c and output a, b, c have a fixed combination of 16 pairs.)")

#text("P.S. I’m an empiricist. I can’t provide proof, just observation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533304")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2019")])]

#text("Well, the sequence of odds matches for n=27. What other values of n give matches. Just look for a pattern. The proof will follow from a pattern. You may end up with an infinite subset. That would be nice. Do all multiples of 3 match? For example…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533306")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2019")])]

#text("Well, double check your calculations for n=27. Not all match.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533363")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("Hello @michael @jeff. I do not understand the strategy.Could you please explain as simple as possible?. Later I will try to explain my approach about notable product difference nth power and the form of odd numbers ")#mi("n /not equiv 0 (mod3)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Mark Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533280")[#strong[#text("Michael Mark Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2019")])]

#text("Here is the function: ")#link("https://drive.google.com/file/d/1V0zV1P7tY7f2qtkobhEIlFs2vUqvEo0l/view?usp=sharing")[#text("https://drive.google.com/file/d/1V0zV1P7tY7f2qtkobhEIlFs2vUqvEo0l/view?usp=sharing")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Mark Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533349")[#strong[#text("Michael Mark Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("Not quite sure I understand what you’re saying about 27. Nothing unusual about 27 except it’s divisible by 3 – and therefore would not occur in a 3x+1 sequence. Such numbers belong to a proper superset of the odd members of a 3x+1 sequence. The third congruence class in fact contains every odd number. So yes every odd output number is repeated twice, but for different inputs. However, that’s where it becomes interesting in showing why cyclicality is possible for 3x>1, but not for 3x+1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533380")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("Repeated Iteration of the 3x+1 map starting with x=27 gives a subsequence of odd numbers which is,")

#text("27, 41, …, 1 where upon the 1 repeats.")

#text("I thought the sequence you have in your spreadsheet has some mistakes. But now I think you are trying something different. What I’m suggesting is you list the elements of your sequence next to the one given by 3x+1.")

#text("Then see which iterations match and then look for a pattern. So you are working visually…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533383")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("The only way you can use your function to make rigorous deductions about 3x+1 is to show exactly where they behave the same. So I’m trying to point you in that direction.")

#text("Of course a probabilistic approach is doomed from the get go :-).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Mark Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533350")[#strong[#text("Michael Mark Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("(Repeated twice when tabulating – obviously not twice in sequences.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533404")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("It would be a big task, but an addendum to the various outdated surveys on 3x+1 listing proof strategies in plain language would be very helpful, in my opinion.")

#text("List a strategy, then state what worked and what failed and why. There are bound to be hundreds of strategies. A big Class includes the various probabilistic approaches. They cannot work! It is not even debatable.")

#text("In this way we can track things, avoid making the same mistakes more than once etc. But speaking from personal experience, one has to be able to convince themselves of when a given strategy fails to hold promise!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Mark Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533409")[#strong[#text("Michael Mark Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("Jeff, do you understand the unvarying and by definition regularity of the table? ")#link("https://drive.google.com/file/d/1yDClElWLnm1H-dsa_KeBorcl44A8yNfY/view")[#text("https://drive.google.com/file/d/1yDClElWLnm1H-dsa_KeBorcl44A8yNfY/view")]#text(". Further you can demonstrate the divergent series (algroithmically here) is the same as the convergent series, which is unique for a given n:")#linebreak()#text(" Do")#linebreak()#text(" a = ((n + 1) * (2 / 3)) – 1")#linebreak()#text(" b = ((n – 1) * (4 / 3)) + 1")#linebreak()#text(" c = (n * 4) + 1")

#text("If a = Int(a) Then")#linebreak()#text(" n = a")#linebreak()#text(" ElseIf b = Int(b) And Modop(b,2) 0 Then")#linebreak()#text(" n = b")#linebreak()#text(" ElseIf c = Int(c) Then")#linebreak()#text(" n = c")#linebreak()#text(" End If")#linebreak()#text(" Loop")#linebreak()#text(" Then you need only show that no two a or bs can point to the same c, since c is a series of every odd number. You do this by looking at contradictions (loops) for any case pf 3x>1. These are easy to find. What’s the difference? It’s quite subtle. I have the answer to this.")

#text("Anyway, I truly appreciate your interest, and there are always communication difficulties when essentially texting. All the best!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533439")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("Okay, I’m going to put forth a real effort to see what you are seeing. I checked your sequence of odds starting with 27. It contains every single odd given by 3x+1 and in the exact order. However, it also contains extra odd terms,")

#text("111,607,769,81,15 and 3, and in that order. Do I have that much correct?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533441")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("111,607,769,81,15, 13, and 3")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533445")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("And these are exactly the values for which your function says to subtract 1 and divide by 4. Okay, so your c or your otherwise part of your function should instead read: if n is congruent to 8 modulo 5. I’ll look at it more later:-).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533446")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("I mean 5 modulo 8…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533450")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("Back again, for your a,b and c you need to say")

#text("n congruent to 3 modulo 4,")#linebreak()#text(" n congruent to 1 modulo 8, and")#linebreak()#text(" n congruent to 5 modulo 8, respectively.")

#text("This helps make it clear that it is a function on the odds because the Union of the sets given by those forms is all of the odds. Next you need to see what the range of your function is. Can you do that?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533468")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("Once you check the range you’ll see an easier way to write your function by comparing it with 3x+1.")

#text("f = 3n+1 for n congruent to 3mod4 or 1mod8")#linebreak()#text(" = (n-1)/4 for n congruent to 5mod8.")

#text("So iterates of your function are the same as 3x+1 for all odd values apart from ones of the form 8x+5.")

#text("So super interesting. Wondering if anyone else is going to chime in?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Mark Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533470")[#strong[#text("Michael Mark Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("As I think you see, the superset numbers are all in C, divide by 2 twice. More here: ")#link("https://www.quora.com/Why-is-the-Collatz-conjecture-so-resistant-to-being-proven-or-disproven-I-would-think-that-a-solution-lies-along-the-convergence-to-powers-of-2-path/answer/Michael-M-Ross")[#text("https://www.quora.com/Why-is-the-Collatz-conjecture-so-resistant-to-being-proven-or-disproven-I-would-think-that-a-solution-lies-along-the-convergence-to-powers-of-2-path/answer/Michael-M-Ross")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Mark Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533471")[#strong[#text("Michael Mark Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("With respect to congruence, it’s very clear-cut if you see the three operations in the function must be taken sequentially: ")#link("https://www.quora.com/Why-hasnt-the-Collatz-conjecture-been-proven-yet-when-it-sounds-so-logical/answer/Michael-M-Ross")[#text("https://www.quora.com/Why-hasnt-the-Collatz-conjecture-been-proven-yet-when-it-sounds-so-logical/answer/Michael-M-Ross")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533477")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("Well, written in the way I suggest may allow you to prove whether subsequences of just the odd values of 3x+1 sequences are in fact subsequences of those given by your function for every odd starting value. That’s what you want to know.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533514")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2019")])]

#text("Wait a minute, I goofed trying to translate it. Your function is")

#text("f = (3n+1)/2 if n is congruent to 3mod4")#linebreak()#text(" = (3n+1)/4 if n is congruent to 1mod8")#linebreak()#text(" = (n-1)/4 if n is congruent to 5mod8.")

#text("My comment still applies. If you can prove what I suggest, then you will have established ‘equivalence’.")

#text("At that point everyone would want to revisit old proof strategies with your new function. Because your function ‘would’ amount to a major simplification.")

#text("If you cannot prove it, calculations may help show why not…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533516")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2019")])]

#text("And a note to the readership. It would be unethical to dance off into the sunset with Michael’s observation and try to pass off whatever immediate results may follow as your own.")

#text("Please give Michael a chance to prove or disprove the desired equivalence exists.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533916")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2019")])]

#text("Michael, it is a tad tricky but not too hard to prove. Your function is equivalent to 3x+1 in the way I stated above. Try to prove it. Hint: the only tricky part is to check what happens with starting values of the form 32n+5.")

#text("Merry Christmas!")

#text("Your name deserves to be coauthor on every immediate publication that should follow using your observation.")

#text("It may not help us settle the Conjecture, but it already constitutes legitimate partial progress!")

#text("Good job sir.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-533975")[#strong[#text("面对数学史上最简单的未解之谜，陶哲轩给出了几十年来最重要的证明 – 克拉茨 – 每日要闻")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2019")]

#text("[…] Almost all Collatz orbits attain almost bounded values […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534090")[#strong[#text("E.xu (@Exu16749831)")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2019")]

#text("1 Collatz Process and Inverse Collatz Process are both Deterministic Processes")#linebreak()#text(" 2 Collatz Process has only One Cycle the Trivial Cycle and Inverse Collatz Process has No Cycle")#linebreak()#text(" 3 Two Collatz Processes can only Intersect Once by Merging Into Same Collatz Process … Two Inverse Collatz Processes do not intersect .. A Collatz Process and A Inverse Collatz Process can only Intersect Once ..")#linebreak()#text(" 4 Inverse Collatz Map maps a Collatz Process with n tuples inverse-surjectively to roughly n/6 Inverse Collatz Processes")#linebreak()#text(" 5 suppose there was a Collatz Process with Infinite Tuples then there must be a Minimal Tuple confining the Collatz Process .. so the Maximal Tuple of the Collatz Process goes to infinity")#linebreak()#text(" 6 by abusing Heuristic Argument it can be presumed that the Sizes Of Steps Of Collatz Process Converge .. so it can also be Naively Presumed that the Size Of Steps Of Inverse Collatz Process Diverge …")#linebreak()#text(" 8 Suppose there was Collatz Process with Infinite Tuples and Minimal Tuple m .. Naively the Sizes Of Steps Of This Collatz Process converge to 1 after ")#block(width: 100%, above: 12pt, below: 14pt)[#set par(justify: false)
#text(size: 7pt, fill: rgb("596477"))[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/#comment-534090")[Source formula could not be rendered.] ] #text(font: "DejaVu Sans Mono", size: 7.5pt, "{frac\\{log m}{log 4/3}}")]#text(" steps .. Use Inverse Collatz Map to Map this Collatz Process Inverse-Surjectively to roughly m/6 Inverse Collatz Processes with Infinite Tuples and Minimal Tuple m … Pigeon Hole Principle says that This Collatz and those Inverse Collatz Processes Must Intersect More Than Once … which can be seen as Proof By Contradiction ..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2e6ab7170b79375d550ed8b5f1927c7d9f62b44416476976b27ca383a63b493-0f09788d602fae4d60b0532137ad295cef9e5900961bd3f13755f0ca27b3e407.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jesse Nochella")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534178")[#strong[#text("Jesse Nochella")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2019")])]

#text("I made a Wolfram Demonstration on the Inverse Collatz function about 10 years ago.I know proofs can be easy to some. Lets just consider.the inverse n/2 -> 2n. we know this generates all powers of 2. Okay, so what’s the first 3n+1 -> (n-1)/3 we do to every other power of 2 as we go up the chain? It creates a repeating binary pattern of 101010101… depending on how many powers of 2 it has. The collatz conjecture can be proven by saying that you can generate every natural number with this tree sequence. Therefore every (n-1)/3 generates a class of numbers and every 2n can augment them,")

#text("There is thus a mapping to the sequence of 1’s and 0’s that correspond as to whether you used 3n+1 or n/2 in the sequence to every natural number and there is a pattern to it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534187")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2019")])]

#text("Jeff, try this:")#linebreak()#text(" ")#link("https://docs.google.com/document/d/1qwgmMbmC7emrbuZQLVCtOWFPDuxd7UDXxOkpnCQ2GRw/edit?usp=sharing")[#text("https://docs.google.com/document/d/1qwgmMbmC7emrbuZQLVCtOWFPDuxd7UDXxOkpnCQ2GRw/edit?usp=sharing")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534219")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2019")])]

#text("Hi Michael. It’s very hard to read for me. You’ll get more mileage with it if you write the function as I suggested sir. As sets, the intersection of the forms 4n+3 , 8n+1 and 8n+5 are empty. And the Union is all odds. So this notation alone replaces several paragraphs and your table. No need for the algorithm or to track three columns of calculations as examples and so on. You just say repeated iteration gives…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534222")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2019")])]

#text("Michael. Here is a link to paper you can use as a guide to help you with notation and a proof. You are working in the forward direction just like the author here is")

#link("https://www.fq.math.ca/Scanned/40-1/andaloro.pdf")[#text("Click to access andaloro.pdf")]

#text("By proving equivalence as stated above you will have that nonexistent nontrivial cycles from repeated iteration of your map implies no nontrivial cycles from iteration of the 3x+1 map.")

#text("You still have to prove stuff with your map. At worst it will give us new insight. At best it will give us a way to settle the Conjecture. So it is a great observation.")

#text("It replaces the even numbers with some odd numbers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534226")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2019")])]

#text("Jeff, that paper is too advanced, too elaborate, and too long for me. I see this as a very thin problem at its foundation – as simple as “a,b,c” in fact*. That’s why I have clarity on it. My little paper shouldn’t be hard to read – I’m disappointed!")

#text("Let me summarize what I said:")#linebreak()#text(" — I initially state all sequence steps conform to a function with three outputs: a,b,c. I also show an algorithmic equivalent based on there being 1-in-3 whole numbers for all outputs.")#linebreak()#text(" — Then I demonstrate that the operations that produce the three outputs conform exactly with what can happen with division by 2 in the conventionally stated 3x+1 problem – by analyzing factors of 2 (and 3). Note that the nonobviousness of this approach is because I’m looking only at the odd numbers but performing the “trick” of a transform back to even.")#linebreak()#text(" — Having shown there can only be three outputs by definition, I show the equivalence of results for 3x+1 and a,b,c. I also provide a table to clarify the relationship between odd and even numbers and factors – and that the three outputs for sequential odd numbers (n*1.5, n*0.75, and n*0.25) repeat infinitely.")

#text("It was your suggestion to find an equivalence to the a,b,c function – and that turns out to be the factors of 2 for n-1 and n+1. Thanks!")

#text("* When this is generally realized, it could be a singular embarrassment to mathematicians.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534227")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2019")])]

#text("They embarrass themselves by handing out awards to folks who almost prove stuff, but who don’t really prove anything of merit or usefulness. The author of that paper really proves stuff, but pays lip service to references that don’t.")

#text("His approach and notation is exactly what you want to use if you wish to reach a wider audience. But this is just my suggestion. I can’t help you anymore than this Michael.")

#text("Wishing you all the best!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534229")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2019")])]

#text("Pleasure talking with you Jeff!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534384")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2020")])]

#text("Dear Prof. Tao,")

#text("I hope that nobody will mistake the following for an attack, but it seems as though current mathematical methods in additive combinatorics and related subjects are mostly adequate for tackling qualitative phenomena, instead of quantitative ones. The most important problems you’ve solved seem to be qualitative ones, instead of quantitative ones.")

#text("W/BR")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534393")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2020")])]

#text("In analysis (including additive combinatorics) there is always a tradeoff between the quantitative strength of the results obtainable by current theory, and the breadth of that theory; and to make progress we need people working at all locations of the frontier of this tradeoff (and interacting with mathematicians at other locations on the frontier). I actually view my research as sitting roughly at the midpoint of this frontier; on the one hand a fair part of my research concerns taking some general but very qualitative results obtained using such “soft” methods as ergodic theory or compactness methods, and converting them to bounds that are quantitative but rather poor (e.g., exponential or even tower exponential in nature, and often with implied constants that are not explicit, and sometimes even ineffective). On the other hand the type of results I and my coauthors produce have sometimes been made more quantitative by other authors. For instance, several years ago Tamar Ziegler and I used ergodic theory and nonstandard analysis methods to prove the first concatenation theorems for Gowers type norms, in which control of a function in many local Gowers norms could be concatenated into control in a single global Gowers norm. The arguments were somewhat difficult and entirely qualitative. However, recently Sarah Peluse and Sean Prendiville have found much more quantitative Fourier-analytic methods to establish concatenation theorems that gave significantly better results; their proof techniques are quite distinct from ours, but I think it is fair to say that they might not have known to try to prove such quantitative theorems if the qualitative theorems of Tamar and myself had not already been in the literature. This seems to be the general pattern in the broader ecosystem of research in analysis: “soft” methods give the initial outline of what the true theory should look like, which then inspires later “hard” methods to come in and make the theory more efficient, more quantitative, and more powerful. Even if the soft results do not directly make progress on quantitative problems, they often show the way and help build up a general “big picture” intuition as to what type of quantitative results one should expect to be true, what their relative difficulties will be, and what type of techniques would be effective in attacking them.")

#text("There is a similar role played by many other tradeoffs in analysis, in which results in weaker regimes yield insight on the contours of the problems in stronger regimes. In the results in this current blog post, the main tradeoff here is between “almost all” results and “all” results, which I have already discussed in previous comments. Other tradeoffs include perturbative vs. non-perturbative regimes, high-regularity data vs. low-regularity data, non-uniform bounds vs. uniform bounds, low dimension vs. high dimension, toy model equations vs. physically realistic equations, discrete vs. continuous (or vice versa), non-Archimedean vs. Archimedean domains, constant coefficients vs. variable coefficients, ineffective vs. effective bounds, etc., etc.. The “horizontal” progress of exploring how a theory changes as one varies these parameters, when viewed narrowly, may not appear at first to make direct “vertical” progress on attacking the original problems that motivate that theory, but when viewed more broadly, this horizontal exploration often generates very valuable indirect progress, for instance by generating useful toy models of these problems as a test bed for intuition and strategies (and in particular to generate key “vertical” breakthroughs that can then later be transferred horizontally back to the original problem).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gim Towers")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534401")[#strong[#text("Gim Towers")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2020")])]

#text("You write way too well :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534480")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2020")])]

#text("Is it really your name ?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-535091")[#strong[#text("E.xu (@Exu16749831)")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2020")]

#text("i did not think you to take this as big deal .. it was Intersection Of Deterministic Processes and Deterministic Inverse Processes With Sizes Of Steps fit in probabilistic pattern .. Collatz Process is Not Random Process .. if you can not Probabilistic Methods ..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-535092")[#strong[#text("E.xu (@Exu16749831)")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2020")]

#text("i saw you were trying to Factorize Characteristic Function .. Gap-Between-Two-Consecutive-Primes trick can not be used to prove Collatz Conjecture ..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d419599989e69b542468f07cc4a700eeb5b755278d6f83597f6c217bdfdc998-3460b83bb5b9ae2f4fdbf754d96b421ecb2efbc4595ebdea7e560db2a3a3b90c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of armchair speculations")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-537972")[#strong[#text("armchair speculations")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2020")])]

#text("Ramsey theory as currently formulated is not all that quantitative to begin with. The functions of interest are so hard to compute or approximate (even very crudely) that gathering useful experimental data is impossible. I think it is safe to say that there are no credible conjectures on the true growth rate of most Ramsey-style problems or what quantities might control the problem.")

#text("It seems to me that this is inherent in considering arbitrary colorings and that some sort of order parameter(s) are missing from the story. e.g. the number of irregular pairs plays this role in Malliaris and Shelah’s analysis of the regularity lemma for graphs.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b97d949032aa7093bb39634aceef388eb89d4616d129e3dafbd2711168c4f86-ce6fb163482804e5c710f324984811f07c65aeb9fbe9ec0438b1b5f913f28244.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gregmonahangmailcom")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534478")[#strong[#text("gregmonahangmailcom")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2020")])]

#text("Dr. Tao")

#text("An amateur mathematician, so be gentle.")

#text("This certainly isn’t a proof, but consider this approach.")

#text("Select a number N that is sufficiently small enough that the numbers 1-N can be inspected to show that they collapse to 1. Call this set of numbers S because they represent the current solution set.")

#text("Now consider the set of numbers 1-2N. The numbers 1-N are already in the solution set S. The even numbers between N+1 and 2N have a second number that is half their value and lands them in the solution space S which is solvable. The result is that all even numbers between N+1 to 2N are also in the solution space S. This implies that all even numbers are in the solution space S.")

#text("Every odd number in the range N+1 to infinity is multiplied by 3 and then added by 1. Any odd number multiplied by another odd number (like 3) yields an odd number. Adding 1 makes this second number an even number. We’ve already shown that all even numbers are in the solution space S. We’ve now shown that any odd number above N yields an even number that eventually yields 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534485")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2020")])]

#text("Your claim that all even numbers are in ")#mi("S")#text(" seems to be false (just try to write its proof …)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534501")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2020")])]

#text("You know you can exclude “S”. You don’t need a single even number to yield 1 and yet generate every odd number in a sequence. You just restate the conjecture. Algorithmically, it’s trivial to demonstrate this:")

#text("Do")#linebreak()#text(" If Modop(n + 1, 4) = 0 Then")#linebreak()#text(" n = ((n + 1) * (3/2)) – 1")#linebreak()#text(" ElseIf Modop(n – 1, 8) = 0 Then")#linebreak()#text(" n = ((n – 1) * (3/4)) + 1")#linebreak()#text(" Else")#linebreak()#text(" n = (n – 1) * (1/4)")#linebreak()#text(" End If")#linebreak()#text(" Loop")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/05575c4c0a88b4dfd81e334b0ba0f3529bdce52260beb0029fc1bcca14c38cd0-60dde69f30166309c9419d161a97a23a37fc87033a2b2a2a9f1a9d2373b567fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rason Lee")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534511")[#strong[#text("Rason Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2020")])]

#text("Greetings from Singapore. I wrote a computer programme in javascript to group starting numbers N by their orbits’ upper bound sequence should there be at least one other matching, if not, by their upper bound values (as far as I observed, all numbers group by these two variables). Running the programme for up to N = 10 Million, I further observed the trend that numbers temporarily grouped by their upper bound values will eventually fall into a collection based on their upper bound sequence. The trend of matching density in log scale is as follow –")

#text("Percentage of non-matching sequences:")#linebreak()#text(" …up to 10: 4 / 4 = 100%")#linebreak()#text(" …up to 100: 15 / 49 = 30.6%")#linebreak()#text(" …up to 1,000: 222 / 482 = 46%")#linebreak()#text(" …up to 10,000: 540 / 3,821 = 14%")#linebreak()#text(" …up to 100,000: 550 / 34,622 = 1.59%")#linebreak()#text(" …up to 1,000,000: 548 / 343,839 = 0.159%")#linebreak()#text(" …up to 10,000,000: 544 / 3,427,576 = 0.0159%")

#text("Prima facie is that the resultant percentage oscillates (wobbles) to an approximately steady state of ×0.1 per decade, while the absolute number of non-matching sequences appears to decrease after 100,000. Suppose the number of non-matching sequences reaches and remains at 0, then all possible orbits’ upper bound sequence would have logically been identified. Hence, I believe with greater computing power (which I have not), it can be superficially/ergodically concluded that all numbers will eventually fall into a convergent orbit by an underlying upper bound sequence pattern that can be extrapolated to infinity, despite the formal mathematical relationship between the orbits being unknown.")

#text("More of my thoughts in the following Facebook post where I included in the comments a maze analogy and proof of no periodic orbit for N > 1 – ")#link("https://www.facebook.com/iplaytherecorder/posts/10157656812184519")[#text("https://www.facebook.com/iplaytherecorder/posts/10157656812184519")]

#text("p/s I started on the problem from scratch a week ago without knowledge of prior art, thus I’m not sure if I have used the right jargons or made any new insights. Pedagogical-wise, my bias is towards explaining things like I’m fresh out of high school, so as to better promote STEM education and interest in related innovation to the general public.")

#text("Thanks for reading and best regards.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/05575c4c0a88b4dfd81e334b0ba0f3529bdce52260beb0029fc1bcca14c38cd0-60dde69f30166309c9419d161a97a23a37fc87033a2b2a2a9f1a9d2373b567fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rason Lee")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534512")[#strong[#text("Rason Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2020")])]

#text("pp/s Append below sample outputs of my javascript programme to clarify what I termed as “upper bound sequence” and “upper bound value” –")

#text("Note: sequence ‘x’ denotes (×3+1) and ‘d’ denotes ÷2")

#text("Upper bound sequence/value of odd numbers up to 77 –")#linebreak()#text(" Starting numbers with upper bound sequence xxdx: 3,11,19,35,43,51,67,75")#linebreak()#text(" Starting numbers with upper bound sequence x: 5,13,17,21,29,33,37,45,49,53,61,65,69,77")#linebreak()#text(" Starting numbers with upper bound sequence xxdxxdxdx: 7,23")#linebreak()#text(" Starting numbers with upper bound sequence xxddxdx: 25,57")#linebreak()#text(" Starting numbers with upper bound value 52: 9")#linebreak()#text(" Starting numbers with upper bound value 160: 15")#linebreak()#text(" Starting numbers with upper bound value 9232: 27,31,41,47,55,63,71,73")#linebreak()#text(" Starting numbers with upper bound value 304: 39,59")#linebreak()#text(" Percentage of non-matching sequences: 12/38 = 31.6%")

#text("Upper bound sequence/value of odd numbers up to 79 –")#linebreak()#text(" Starting numbers with upper bound sequence xxdx: 3,11,19,35,43,51,67,75")#linebreak()#text(" Starting numbers with upper bound sequence x: 5,13,17,21,29,33,37,45,49,53,61,65,69,77")#linebreak()#text(" Starting numbers with upper bound sequence xxdxxdxdx: 7,23")#linebreak()#text(" Starting numbers with upper bound sequence xxdxxdxdxxdxdxdx: 15,79")#linebreak()#text(" Starting numbers with upper bound sequence xxddxdx: 25,57")#linebreak()#text(" Starting numbers with upper bound value 52: 9")#linebreak()#text(" Starting numbers with upper bound value 9232: 27,31,41,47,55,63,71,73")#linebreak()#text(" Starting numbers with upper bound value 304: 39,59")#linebreak()#text(" Percentage of non-matching sequences: 11/39 = 28.2%")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534643")[#strong[#text("La conjetura 3x + 1 está cerca de resolverse | – Juegos Online Paraguay")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2020")]

#text("[…] escribe en su blog: «estamos ante una situación en donde parece haber una gran brecha entre «casi […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534666")[#strong[#text("La conjetura 3x + 1 está cerca de resolverse - Comunidad Informativa")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2020")]

#text("[…] escribe en su blog: «estamos ante una situación en donde parece haber una gran brecha entre «casi todos» y […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534671")[#strong[#text("La conjetura 3x + 1 está cerca de resolverse - Descargas Noticias y todo")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2020")]

#text("[…] escribe en su blog: «estamos ante una situación en donde parece haber una gran brecha entre «casi […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/05575c4c0a88b4dfd81e334b0ba0f3529bdce52260beb0029fc1bcca14c38cd0-60dde69f30166309c9419d161a97a23a37fc87033a2b2a2a9f1a9d2373b567fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rason Lee")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-534821")[#strong[#text("Rason Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2020")])]

#text("Correction to above trend analysis due to a mistake in array sizing. Further tallied inter-decade matching rate and concluded similar, though on a different premise. It is observed that overall matching appears to tend to 100% still, however the graph is more likely to resemble underdamping throughout, and perhaps perpetually. Hence the eventual phenomenon of “almost all orbits” could be an effect of point sampling bobbing at 100%, i.e. an infinite number of upper bound sequences exists, but the matching trend towards and about 100% necessarily implies that all orbits are bounded. Tally outputs as follow –")

#text("Percentage of non-matching upper bound sequences for odd numbers up to 100 = 15 / 49 = 30.6%;")#linebreak()#text(" Percentage of non-matching upper bound sequences from 10th percentile that eventually found match = 3 / 4 = 75.0%;")#linebreak()#text(" Percentage of matching upper bound sequences from above 10th percentile = 29 / 44 = 65.9%.")

#text("Percentage of non-matching upper bound sequences for odd numbers up to 1,000 = 239 / 499 = 47.9%;")#linebreak()#text(" Percentage of non-matching upper bound sequences from 10th percentile that eventually found match = 3 / 15 = 20.0%;")#linebreak()#text(" Percentage of matching upper bound sequences from above 10th percentile = 215 / 449 = 47.9%.")

#text("Percentage of non-matching upper bound sequences for odd numbers up to 10,000 = 1,252 / 4,999 = 25.0%;")#linebreak()#text(" Percentage of non-matching upper bound sequences from 10th percentile that eventually found match = 32 / 239 = 13.4%;")#linebreak()#text(" Percentage of matching upper bound sequences from above 10th percentile = 3,386 / 4,499 = 75.3%.")

#text("Percentage of non-matching upper bound sequences for odd numbers up to 100,000 = 8,363 / 49,999 = 16.7%;")#linebreak()#text(" Percentage of non-matching upper bound sequences from 10th percentile that eventually found match = 245 / 1,252 = 19.6%;")#linebreak()#text(" Percentage of matching upper bound sequences from above 10th percentile = 37,150 / 44,999 = 82.6%.")

#text("Percentage of non-matching upper bound sequences for odd numbers up to 1,000,000 = 62,924 / 499,999 = 12.6%;")#linebreak()#text(" Percentage of non-matching upper bound sequences from 10th percentile that eventually found match = 1,826 / 8,363 = 21.8%;")#linebreak()#text(" Percentage of matching upper bound sequences from above 10th percentile = 390,559 / 449,999 = 86.8%.")

#text("Percentage of non-matching upper bound sequences for odd numbers up to 10,000,000 = 499,887 / 4,999,999 = 10.0%;")#linebreak()#text(" Percentage of non-matching upper bound sequences from 10th percentile that eventually found match = 15,856 / 62,924 = 25.2%;")#linebreak()#text(" Percentage of matching upper bound sequences from above 10th percentile = 4,024,211 / 4,499,999 = 89.4%.")

#text("Percentage of non-matching upper bound sequences for odd numbers up to 100,000,000 = 4,009,615 / 49,999,999 = 8.02%;")#linebreak()#text(" Percentage of non-matching upper bound sequences from 10th percentile that eventually found match = 109,241 / 499,887 = 21.9%;")#linebreak()#text(" Percentage of matching upper bound sequences from above 10th percentile = 41,190,871 / 44,999,999 = 91.5%.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f44a05b2fbb7b43e945497f72fdc2c16f3c9232a24339141edeb8a27cd496f5-660edf3cdb12cbd885d907f87e93024c6296fc600c7d98d80df406000d0b8f21.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Bizarro")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-536198")[#strong[#text("Pedro Bizarro")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2020")])]

#text("I think I found a method to look for values ​​that of a cycle other than 4.2.1")#linebreak()#text(" What I did was analyze the “inverse function”. From here I saw that the values ​​obtained can be seen as a “chain” that has certain properties.")#linebreak()#text(" Then I considered what numbers could form a cycle")#linebreak()#text(" By analyzing it in this way, I could remove as numbers that form a cycle to the numbers multiple of 3; Then, considering that there is some other cycle than 4,2,1, I began to analyze which numbers could be those of greater value and of less value.")#linebreak()#text(" I could find that the smallest number within the cycle of this chain must be of the form 12n-1 or 12n-5; By doing more operations, I was able to reduce the numbers to those of the form 24n-1,24n-17,48n-5 or 48n-37. You can reduce the numbers further, but it is a bit difficult to do it manually.")#linebreak()#text(" When searching for the largest number, I found that the largest number should be of the form 18n-1 or 18n-7. I could reduce it to the 36n-7 or 36n-19 form. I continued to operate it and could reduce it to the 108n-91,108n-79,108n-55 or 108n-7 form.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f44a05b2fbb7b43e945497f72fdc2c16f3c9232a24339141edeb8a27cd496f5-660edf3cdb12cbd885d907f87e93024c6296fc600c7d98d80df406000d0b8f21.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Bizarro")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-536587")[#strong[#text("Pedro Bizarro")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2020")])]

#text("I have analyzed my method again and discovered that the only cycle that exists is 4.2.1")#linebreak()#text(" First I considered that there is a different cycle than 4.2.1, this cycle must have a maximum and minimum odd number")#linebreak()#text(" When analyzing the maximum odd number, I discovered that it must have the form 36n-19 or 36n-7")#linebreak()#text(" Using the collatz function, I discovered that one of the following numbers within the cycle should have the form 27n-14 or 27n-5")#linebreak()#text(" When using the “inverse function”, I discovered that the previous odd number within the cycle must have the form 24n-13 or 24n-5")#linebreak()#text(" Since these numbers are within the cycle, the numbers of the form 27n-14 or 27n-5 must reach the numbers of the form 24n-13 or 24n-5 using only the collatz function (multiply 3, add 1 and divide by one power of 2 indefinitely) which is clearly impossible")#linebreak()#text(" I did all this analysis graphically, but here in the comments I can’t put the graphics")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-536613")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2020")])]

#text("Such analysis should be written in a rigorous (non-graphical) form.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4aba73246595af8ea0554c834a7ac4fbe0ee0ec25feb6b98b53f26f490ce923-6687e092c7bc015e84b352f3951935ed5d5507b3e9b45ffa3dfbc4ca9cd38f27.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gabekhan7")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-536718")[#strong[#text("gabekhan7")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2020")])]

#text("I apologize if these are obvious or obviously wrong questions, but I was wondering if there is a quantitative version of the “almost global in time” estimates. In other words, given a slow growing function f and a “generic” number N (so that ")#mi("Col_{min} N < f(N)")#text("), can you give any sense of how large k needs to be so that ")#mi("Col^k(N) < f(N)")#text(". In other words, is there some sense of how many iterations of the Collatz map you need \"on average\" to get below some threshold. I guess this would depend on the particular choice of f, and would seem to get larger the slower that f grows.")

#text("As a follow up question, can your result can be combined with the Krasikov-Lagarias result to get better estimates on how many numbers reach 1? This is terribly naive, and so must be wrong, but if there is a set S of density ")#mi("x^{.84}")#text(" whose Collatz iterations can be shown to reach one, and the \"generic\" Collatz map reaches values much smaller than N, it seems like it might be possible to get some lower bounds on how many orbits hit S (and thus also go to one). Is there a reason that S and orbits of the Collatz map do not collide in a naive way?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-536754")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2020")])]

#text("The arguments in my paper allow one to take ")#mi("k = O(\\log N)")#text(". With more effort it may be possible to obtain the more precise value ")#mi("k = \\frac{2+o(1)}{\\log(4/3)} \\log N")#text(" (or ")#mi("k = \\frac{1+o(1)}{\\log(4/3)} \\log N")#text(" if one uses Syracuse iterations instead of Collatz (this limiting value of ")#mi("k")#text(" roughly corresponds to the infinite time limit ")#mi("t \\to \\infty")#text(" for autonomous PDE).")

#text("The arguments in my paper are unable to “see” anything going on in subsets of ")#mi("[1,x]")#text(" that are sparser than about ")#mi("x \\log^{-c} x")#text(" in cardinality, so in particular would not be able to interact with the Krasikov-Lagarias set with the current level of bounds. Perhaps in the future one could potentially imagine the error terms in the almost all results and the lower bounds on the preimage results improving to the extent that they can start working with each other, although this possibility looks somewhat remote. However, there is a link between KL type bounds and uniform distribution of the Syracuse random variables in my paper, in that a (currently unproven) equidistribution hypothesis on the former can lead to improvements on the latter (in particular, to replace the 0.84 exponent by any exponent less than 1); I may detail this in a separate blog post.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8e4f4a8a2820f058b6004d8c3a1d11a097bcb7043d11048bcd7451513ecacca-0d6d96e4350f1df00ec4ffa5dfcc48f40c36198c9871d7a84c523f4f5f4bf6cf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-538223")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2020")])]

#text("I haven’t found a clear definition of a Syracuse function. I immediately think of any case where n>1 for 3x+n. Does this qualify? These Collatz-type functions produce obvious counterexamples to 3x+1 on the question of cyclicality. For example, taking 3x+17 for 27 there is a 21-step loop beginning with 41 in the odd-only sequence (using my own odd-only function) and a 49-step loop beginning with 140 using the conventional even-odd function. (They are equivalent.)")

#text("I notice that complex cycles occur only where it’s possible for the common differences of odd input-output numbers to be zero. That requires what I’ll call a zero-point equilibrium. What is that? It’s simply the n in 3x+n. It means that for 3x+17 the zero point is 17 – and for 3x+1 it’s 1, of course. For 3x+17, common differences have inverse pairs: +14, −14 and −20, +20. For the 3x+17 loop for 27, the addition of common differences yields 0 (+368-368). Such inverse-pair symmetry can never exist for 3x+1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5767d7e85f448b8d269d8190e6439e6dd94458614b35b1fa779dc92905f94892-53d178225678f379ec573f5503b5101a1a3b96c8cdf2ffa42c2d06c4dc5ca290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of IngoA")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-538774")[#strong[#text("IngoA")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2020")])]

#text("It is a little bit offtopic, but there is a random version of the Collatz problem where convergence to the limit set {1, 2, 4} is rather obvious and easy to prove:")#linebreak()#text(" (i) Like “in Collatz”, an odd number n is transformed to 3n+1.")#linebreak()#text(" (ii) For an even number n a random decision is made: with probability 1/2, n is divided by 2 (like in Collatz), but with the other 1/2, n is divided by 2 and 1 is subtracted from the outcome. Subsequent random decisions are made independently of each other.")#linebreak()#text(" The modification in (ii) makes sure that for each even n, the result is even again with probability 1/2.")#linebreak()#text(" 4 leads either to 2 or to 1, both with probability 1/2.")#linebreak()#text(" The expected number of iterations until 1 is reached for the first time is c*log(n_0), where “magic” 4/3 occurs in c somehow.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Equidistribution of Syracuse random variables and density of Collatz preimages | What's new")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-537289")[#strong[#text("Equidistribution of Syracuse random variables and density of Collatz preimages | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2020")])]

#text("[…] natural numbers obeys the Collatz conjecture. This is not yet established, although the results in my previous paper do at least imply that a positive density set of natural numbers iterates to an (explicitly […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-538693")[#strong[#text("Los primos de la conjetura de Collatz - La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2020")]

#text("[…] Tao, “The Collatz conjecture, Littlewood-Offord theory, and powers of 2 and 3,” What’s New, 25 Aug 2011; Terence Tao, “Almost all Collatz orbits attain almost bounded values,” What’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68b2b057f9d296967dfbfd5c092a04c78fb1474b0d1a126ef6dbb482525770fc-965994263b210d9eeabf059f613992693973dd84a4480a0e645699950b6e521e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-541773")[#strong[#text("Brian")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2020")])]

#text("Thank you for answering question about the Nash embedding theorem. I saw this in an article:")#linebreak()#text(" In the 1970s, mathematicians showed that almost all Collatz sequences — the list of numbers you get as you repeat the process — eventually reach a number that’s smaller than where you started. [End quote]")

#text("I am unaware of the precise statement of this theorem. So it sounds like it is saying the limit of f^m, where I mean the mth iterate of the Collatz function, when applied to x is going to be smaller than x.")

#text("Lets say limit as m approaches infinity of f^m(x) is y and note y<x.")

#text("There has got to be something to the fact that we can apply the theorem to y and get a limit of y2<y.")

#text("With finitely many applications of this theorem, we get down to 1 eventually.")

#text("Is there any idea there that might be useful.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-541999")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2020")])]

#text("The sequence ")#mi("f^m(x)")#text(" does not have a limit as ")#mi("m \\to \\infty")#text(" (conjecturally, it will oscillate indefinitely between the values 1,4,2 after some point). The result of Terras referred to here is discussed for instance at ")#link("http://www.ericr.nl/wondrous/terras.html")[#text("http://www.ericr.nl/wondrous/terras.html")]#text(" . It asserts that for almost all ")#mi("x")#text(", there exists an ")#mi("m")#text(" such that ")#mi("f^m(x) < x")#text(". As I discuss in my paper, it is tempting to iterate such results by applying them to ")#mi("f^m(x)")#text(" in place of ")#mi("x")#text(", but the difficulty is that the iterate ")#mi("f^m(x)")#text(" may lie in the small exceptional set not covered by the \"almost all\" result of Terras. It is possible to get around this difficulty to a large extent if one has something resembling an invariant measure for the dynamics, and this is the starting point for the arguments in my own paper.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of y.y.")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-542075")[#strong[#text("y.y.")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2020")])]

#text("Such the small exceptional set can be identified. Consider the intersection of the set and its image, then partition the set of the intersection into six subsets. We can see that those subsets get to be null in f^(1+1) *1, 2, 3, 4, 5, n_0+2 times iteration, respectively. That means that the exceptional set can be moved to the “almost all” result. There is inverse function by means of the Residue-class-wise affine mapping which S_3 acts on. So that it is possible to identify the expectional set.")

#text("……with no proof. I’m not mathematician, sorry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-542089")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2020")])]

#text("I don’t quite understand “the dynamics” in the Collatz conjecture. If the numbers are abstract entities and the set of natural numbers is a perfectly ordered set, arranged according to a certain function that places each number equidistant to the next, in a straight line one behind the other, and once ordered we label them, calling the first 1 , to the second 2, … this perfect order is “absolute”, or is it an “ad hoc” order? If we tell this set to be ordered according to another function, that of Collatz, where an arborescence is created, even if it has periodic orbits, even with divergent orbits, it is also not a perfectly ordered set, according to the function? and they are not both static orders? what mathematical sense does it have to compare two equal sets, perfectly ordered, although differently?")#linebreak()#text(" if we talk about the economy or the weather, they are changing, a dollar today is worth something else tomorrow, or if you release a balloon every time it moves differently, influenced by other factors, but the orbits of Collatz are fixed, they never change")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8e4f4a8a2820f058b6004d8c3a1d11a097bcb7043d11048bcd7451513ecacca-0d6d96e4350f1df00ec4ffa5dfcc48f40c36198c9871d7a84c523f4f5f4bf6cf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-542091")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2020")])]

#text("Little tin soldiers stepping in uniform.")#linebreak()#text(" ")#link("https://drive.google.com/file/d/1C0yxIPNCI4fYIfSXOlCAc_9jitRDrBI9/view?usp=sharing")[#text("https://drive.google.com/file/d/1C0yxIPNCI4fYIfSXOlCAc_9jitRDrBI9/view?usp=sharing")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-542092")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2020")])]

#text("Perhaps it may help to read this Wikipedia article")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Order_theory")[#text("https://en.wikipedia.org/wiki/Order_theory")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bca5546625c9d6900e72dd8ac79cfcd63d07b178e2fd91fa132d04855ab477b-de6e99e08ab8395fc8c136e949479bdc25b57d026850b462250352409f190f79.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Barry Hirschfeld")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-541807")[#strong[#text("Barry Hirschfeld")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2020")])]

#text("PART 1. Lists")

#text("Following is the set of lists where the elements of all lists have the form")#linebreak()#text(" (positive odd integer, 1 to infinity)*(2^n, n integer, goes from 0 to infinity):")#linebreak()#text(" 1, 2, 4, 8,…")#linebreak()#text(" 3, 6, 12, 24,…")#linebreak()#text(" 5, 10, 20, 40,…")#linebreak()#text(" 7, 14, 28, 56,…")#linebreak()#text(" 9, 18, 36, 72,…")#linebreak()#text(" and so on.")#linebreak()#text(" Each new term in a list is twice the value of the previous term.")

#text("The lists cover all positive integers because all integers can be represented as")#linebreak()#text(" (positive odd integer, 1 to infinity)*(2^n, n integer, goes from 0 to infinity).")

#text("NOTE: No integer in one list is found in any other list because integers in all")#linebreak()#text(" other lists have a different odd factor (3, 5, 7,…), and because integers in the")#linebreak()#text(" list with 1 as its first element can be represented without any odd factor.")

#text("PART 2. Get unique even integer from unique odd integer, and vice-versa")

#text("PART 2.0. CS and RCS")

#text("We denote a Collatz sequence by CS and a reverse Collatz sequence by RCS")

#text("PART 2.1. Get even integer from odd integer for a CS")

#text("Multiply odd integer, 2d-1, by 3 and add 1 to give even integer, 3(2d-1)+1.")#linebreak()#text(" 2d-1 and 3(2d-1)+1 have a 1-to-1 relationship: given one of these terms, the")#linebreak()#text(" other term can be found. E.g., if 2d-1 is 5 then 3(2d-1)+1 is 16 & vice-versa.")#linebreak()#text(" This even integer is not divisible by 3, and dividing by 2^n does not help.")

#text("PART 2.2. Get odd integer from even integer for a CS")

#text("Divide the even integer by 2 until you get an odd integer as the quotient.")#linebreak()#text(" The dividend and the quotient have a 1-to-1 relationship.")

#text("PART 2.3. Get even integer from odd integer for a RCS")

#text("Multiply the odd integer by 2 as many times as is necessary.")#linebreak()#text(" The multiplicand and the product have a 1-to-1 relationship.")

#text("PART 2.4. Get odd integer from even integer for a RCS")

#text("We let the odd integer be 2d-1, the even integer be 2v, and the odd integer at")#linebreak()#text(" the start of the even integer’s list be 2c-1.")

#text("There are three possible cases:")#linebreak()#text(" (2c-1) mod 3 = 0. Here the odd integer at the start of the even integer’s list is")#linebreak()#text(" divisible by 3, as is the even integer, so that no new odd integer is possible.")#linebreak()#text(" (2c-1) mod 3 = 1. Here (2c-1)(4^p)-1 is divisible by 3, p is positive integer.")#linebreak()#text(" (2c-1) mod 3 = 2. Here (2c-1)2(4^(p-1))-1 divisible by 3, p positive integer.")#linebreak()#text(" For example:")#linebreak()#text(" Case 1: If 2c-1 = 9 then no “(even integer in this list)-1” is divisible by 3.")#linebreak()#text(" Case 2: If 2c-1 = 7 then (7*4^p-1)/3 = 9, 37, 149,… for p = 1, 2, 3,…")#linebreak()#text(" Case 3: If 2c-1 = 5 then (5*2*4^(p-1)-1)/3 = 3, 13, 53,… for p = 1, 2, 3,…")

#text("2v and 2d-1 have a 1-to-1 relationship: given one of these terms, the other")#linebreak()#text(" term can be found. For example, if 2v is 16 then 2d-1 is 5.")

#text("NOTE: We shall ignore the 1 (in 1, 5, 21, etc.) that is gotten from the 4 in")#linebreak()#text(" list 1, 2, 4, 8, 16, etc. for three reasons.")#linebreak()#text(" First, keeping the 1 leads to a duplication of the original list 1, 2, 4, 8, 16,…")#linebreak()#text(" Second, the 4, 2, 1 of the original list results in a loop: 4=>2, 2=>1, 1=>4.")#linebreak()#text(" Third, the 1 so obtained is not unique; it already exists in 1, 2, 4, 8, 16 etc.")

#text("PART 2.5. Ratios of integers in a list, odd to odd and even to even")

#text("For (2c-1) mod 3 = 1 (see PART 2.4), the ratio of two consecutive even")#linebreak()#text(" integers used to get two odd integers is 4; for example, 28 and 112.")#linebreak()#text(" The same ratio holds for (2c-1) mod 3 = 2; for example, 10 and 40.")

#text("Because the ratio of two even integers (used to get odd integers) is 4, thus")#linebreak()#text(" 3(2d-1)+1 is followed by4(3(2d-1)+1), or by 12(2d-1)+4.")#linebreak()#text(" We subtract 1 and divide by 3, getting 4(2d-1)+1 for the next odd integer.")

#text("This new odd integer has increased in size from (2d-1) to 4(2d-1)+1, or")#linebreak()#text(" 4 times the previous odd integer, plus 1. For example, if 2d-1 is 5, then")#linebreak()#text(" 4(2d-1)+1 is 21; and if 2d-1 is 13, then 4(2d-1)+1 is 53.")

#text("PART 3. A RCS that does not start from 1")

#text("We can start a RCS from an odd number other than 1, even from an odd")#linebreak()#text(" integer whose connection to (the list that starts with) 1 is not known.")

#text("The rules for getting the new odd and even integers are set out in PART 2,")#linebreak()#text(" and are not dependent on where the RCS starts (and in particular these new")#linebreak()#text(" integers are all unique).")

#text("Even if afterward we complete the RCS to include 1 and the full set of lists,")#linebreak()#text(" the new odd and even integers encountered do not change their values.")

#text("PART 4. Loop-free")

#text("We start a CS with an odd integer and we count as a step only when another")#linebreak()#text(" odd integer is reached.")

#text("We start a RCS with the odd integer 1, and we count as a step only when")#linebreak()#text(" another odd integer is reached.")

#text("In stepping through a RCS (and through its lists), every integer encountered,")#linebreak()#text(" whether odd or even, must be unique: see NOTE in PART 1.")

#text("Even were we to start a RCS at odd integer 2d-1, and not at 1, the new odd")#linebreak()#text(" and even integers encountered as we step through the RCS from 2d-1 would")#linebreak()#text(" be the same as if we had started at 1 (see PART 3).")

#text("So if when stepping through any RCS means that every integer encountered")#linebreak()#text(" must be unique, then this means that a RCS may not have a loop.")

#text("Let us assume a CS with a loop. It starts with odd integer 2d’-1, where the")#linebreak()#text(" prime indicates the first occurrence of 2d-1. We go s steps until we reach the")#linebreak()#text(" integer 2d”-1 a second time, where the double prime indicates the second")#linebreak()#text(" occurrence of 2d-1. That is, we have a loop: 2d’-1 and 2d”-1.")

#text("Now, go in the opposite direction, that is, in a RCS, starting from 2d”-1 (that")#linebreak()#text(" is, from the 2d”-1 that we had reached after going s steps in the CS). So we")#linebreak()#text(" go s steps in a RCS and expect to reach the original 2d’-1.")

#text("Except we cannot reach the original 2d’-1 in a RCS, because every integer,")#linebreak()#text(" odd or even, encountered in a RCS is unique no matter where we started; i.e.")#linebreak()#text(" no RCS may have a loop (see above), it cannot contain both 2d’-1 and 2d”-1.")

#text("Conclusion: our original assumption about re-encountering 2d-1 after s steps")#linebreak()#text(" in a CS must be false, so that a CS may not have a loop.")

#text("PART 5. Infinity, possible or not possible?")

#text("We use a concrete – but technically incorrect – example for illustration.")#linebreak()#text(" We assume that, say 29, is the integer for a Collatz sequence that goes to")#linebreak()#text(" infinity; 29 actually converges to 1, not infinity, but we shall ignore this.")

#text("To get to the next step in the sequence we do 3(29)+1 to get 88, and then")#linebreak()#text(" divide by 2 until an odd integer is reached; viz., 11, the next step.")

#text("We can multiply 29 by 4 and add 1 (see PART 2.5) to get 117. We do")#linebreak()#text(" 3(117)+1 to get 352, and divide by 2 until the same odd integer as for29 is")#linebreak()#text(" reached; viz., 11. We thus see that 117 also goes to infinity.")

#text("We can multiply 117 by 4 and add 1 to get 469, etc. And we can multiply")#linebreak()#text(" 469 by 4 and add 1, etc. In other words, not just 29 goes to infinity, there are")#linebreak()#text(" an infinite number of integers going to infinity (117, 469, 1877, etc.).")#linebreak()#text(" That is, there is not just one bad actor (29), there is an infinity of them.")

#text("(Sometimes it is possible to subtract 1 from 29 and divide by 4 to get an odd")#linebreak()#text(" integer (see PART 2.5), here 7, then multiply 7 by 3 and add 1 to get 22, and")#linebreak()#text(" then divide 22 by 2 until an odd integer is reached, here 11, so that 7 also")#linebreak()#text(" goes to infinity. Then we do the same procedure for 7 as we did for 29, until")#linebreak()#text(" we reach an integer that is not an odd integer. But this procedure can be")#linebreak()#text(" done only a finite number of times, so its effect is unimportant.)")

#text("We saw that the step after 29 is 11. Multiply 11 by 3 and add 1 to get 4, and")#linebreak()#text(" divide 34 by 2 until we reach an odd integer, 17, which is the next step.")

#text("As with 29, we can multiply 11 by 4 and add 1 to get 45, multiply 45 by 3")#linebreak()#text(" and add 1 to get 136, and divide by 2 until we get an odd integer, also 17.")#linebreak()#text(" So we see that 45, like 11, also goes to infinity.")

#text("Here too there are an infinite number of integers going to infinity")#linebreak()#text(" (11, 45, 181, etc.). And we can do to 17 what we did to 29 and 11. Etc.")

#text("Of course, all this is nearly identical to what we could do with integers in a")#linebreak()#text(" Collatz sequence that converge to 1.")#linebreak()#text(" Except that when an integer converges to 1, everything stops when it reaches")#linebreak()#text(" 1, but an integer that goes to infinity takes an infinite number of steps to go")#linebreak()#text(" there and includes with itself infinities of other integers each step on the way")

#text("Could it be that, for all integers, the ones that converge to 1 have a measure")#linebreak()#text(" of 0 compared to the measure of 1 for integers that go to infinity?")#linebreak()#text(" So what?")#linebreak()#text(" For example, we know that on the 0 to 1 x-axis the Reals have a measure of")#linebreak()#text(" 0 while the Irrationals+Transcendentals have a measure of 1, yet the Reals")#linebreak()#text(" are nonetheless doing quite well even with a measure of 0.")#linebreak()#text(" Here too, even were Integers (converges to 1) found to have a measure of 0,")#linebreak()#text(" compared to a measure of 1 for Integers (goes to infinity), we shouldn’t care.")

#text("Or, maybe not. Maybe it’s when comparing Reals to Irrationals+")#linebreak()#text(" Transcendentals that we don’t care if the Reals have a measure of 0, but")#linebreak()#text(" when comparing Reals to Reals (as in our case) we do care, so that a Collatz")#linebreak()#text(" sequence that goes to infinity (instead of to 1) should not be possible.")

#text("So, should a Collatz sequence that goes to infinity be possible, or not?")

#text("Gentlemen and Ladies of the blue-ribbon jury, I rest my case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bca5546625c9d6900e72dd8ac79cfcd63d07b178e2fd91fa132d04855ab477b-de6e99e08ab8395fc8c136e949479bdc25b57d026850b462250352409f190f79.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Barry Hirschfeld")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-541951")[#strong[#text("Barry Hirschfeld")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2020")])]

#text("Yes, what I wrote above is unclear and deserves thumbs down.")

#text("BUT, I request looking at PART 4 (toward its start), beginning with:")#linebreak()#text(" “So if when stepping through any RCS means that every integer encountered")#linebreak()#text(" must be unique, then this means that a RCS may not have a loop.”")

#text("And read from there to the end of PART 4, which finishes with::")#linebreak()#text(" “a CS may not have a loop” (Note: “loop” means “circuit”.)")#linebreak()#text(" You agree, or don’t agree?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bca5546625c9d6900e72dd8ac79cfcd63d07b178e2fd91fa132d04855ab477b-de6e99e08ab8395fc8c136e949479bdc25b57d026850b462250352409f190f79.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Barry Hirschfeld")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-542082")[#strong[#text("Barry Hirschfeld")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2020")])]

#text("1. Showed that operations in Collatz sequence & reverse CS are single-valued.")#linebreak()#text(" 2. Showed that every integer in reverse Collatz sequence MUST be unique.")#linebreak()#text(" 3. Assumed that a Collatz sequence (CS) has a loop/circuit at integer 2s-1, & from second instance of 2s-1 in CS use RCS to try to return to first instance.")#linebreak()#text(" 4. RCS failed to return to first instance of 2s-1 because 2s-1 not unique.")#linebreak()#text(" 5. Conclusion: Assumption of loop/circuit (second instance of 2s-1)")#linebreak()#text(" in CS was wrong, a Collatz sequence may NOT have a loop/circuit.")#linebreak()#text(" Agree/disagree?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-542083")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2020")])]

#text("Hello Barry, do not despair. Surely your comment has been seen by many blog friends, even by Professor Tao. And it may not be all the good you think it is, although my opinion is of little mathematical value.")#linebreak()#text(" About loops, it seems that your argument states that $ latex a \\ neq b $, $ latex b \\ neq c $, … but does not imply that $ latex z \\ neq a $, in my very modest opinion. Regards")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bca5546625c9d6900e72dd8ac79cfcd63d07b178e2fd91fa132d04855ab477b-de6e99e08ab8395fc8c136e949479bdc25b57d026850b462250352409f190f79.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Barry Hirschfeld")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-542096")[#strong[#text("Barry Hirschfeld")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2020")])]

#text("Thank you for your reply.")#linebreak()#text(" You may be on to something, but I am not familiar with Latex.")#linebreak()#text(" Could you please rewrite your comment using FORTRAN (EQ, NE, LT, LE, MT, ME) instead of Latex..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9bca5546625c9d6900e72dd8ac79cfcd63d07b178e2fd91fa132d04855ab477b-de6e99e08ab8395fc8c136e949479bdc25b57d026850b462250352409f190f79.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Barry Hirschfeld")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-2/#comment-542141")[#strong[#text("Barry Hirschfeld")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2020")])]

#text("Alberto:")#linebreak()#text(" I figured out the Latex, but do not know to what you refer (“your argument”); viz., on which line – 1,2,3,4,5 – in my short “proof” are you commenting?")#linebreak()#text(" (I totally agree with your comment, but do not think I use it anywhere.)")

#text("(BTW, I meant GT and GE, not MT and ME.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0c966f83956f88e0ae0569a5a0b03c90ac4da8d83a15599ca142d3f1d3503e6-6da5889455160fc1a4651d11d6dc54150c1eee35c9adbd8ae366b68451ab2690.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of goingtoinfinity")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521814")[#strong[#text("goingtoinfinity")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2019")])]

#text("What is the relations between results for “almost all” cases vs. subsequent proofs of the full result, from historic examples? Are there good examples where the former influences the developments of the later? Or is it more common that, proving results for full results of a mathematical question, is conducted in an entirely different way usually?")

#text("As an example, Falting’s proof that there are only finitely many solutions to Fermat’s Last Theorem — did his techniques influence and appear in Wiles’s/Taylor’s final proof?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521820")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2019")])]

#text("One can broadly divide arguments involving some parameter (with a non-empty range) into three types: “worst case analysis”, which establish some claim for all choices of parameters; “average case analysis”,which establish some claim for almost all choices of parameters; and “best case analysis”, which establish some claim for at least one choice of parameters. (One can also introduce an often useful variant of the average case analysis by working with “a positive fraction” of choices rather than “almost all”, but let us ignore this variant for sake of this discussion.) There are obvious implications between the three: worst case analysis results imply average case analysis results (these are often referred to as “deterministic arguments”), and average case analysis results imply best case analysis results (the “probabilistic method”). In the contrapositive, if a claim fails in the average case, then it will also fail in the worst case; and if it fails even in the best case, then it fails in the average case. However, besides these obvious implications, one generally sees quite different methods used the three different types of results. In particular, average case analysis (such as the arguments discussed in this blog post) gets to exploit methods from probability (and related areas such as measure theory and ergodic theory); best case analysis relies a lot on explicit constructions to design the most favorable parameters for the problem; but worst case analysis is largely excluded from using any of these methods, except when there is some “invariance”, “dispersion”, “unique ergodicity”, “averaging” or “mixing” property that allows one to derive worst-case results from average-case results by showing that every worst-case counterexample must generate enough siblings that at they begin to be detected by the average-case analysis. For instance, one can derive Vinogradov’s theorem (all large odd numbers are a sum of three primes) from a (suitably quantitative) almost all version of the even Goldbach conjecture (almost all even numbers are the sum of two primes), basically because a single counterexample to the former implies a lot of counterexamples to the latter (see Chapter 19.4 of Iwaniec-Kowalski for details). At a more trivial (but still widely used) level, if there is so much invariance with respect to a parameter that the truth value of a given property does not actually depend on the choice of parameter, then the worst, average, and best case results are equivalent, so one can reduce the worst case to the best case (such arguments are generally described as “without loss of generality” reductions).")

#text("However, in the absence of such mixing properties, one usually cannot rigorously convert positive average case results to positive worst case results, and when the worst case result is eventually proved, it is often by a quite different set of techniques (as was done for instance with FLT). So it is often better to think of these different types of analysis as living in parallel, but somewhat disjoint, “worlds”. (In additive combinatorics, there is a similar distinction made between the “100% world”, “99% world”, and “1% world”, corresponding roughly to worst case analysis and the two variants of average case analysis respectively, although in this setting there are some important non-trivial connections between these worlds.) In the specific case of the Collatz conjecture, the only obvious invariance property is that coming from the Collatz map itself (")#mi("N")#text(" obeys the Collatz conjecture ")#mi("\\mathrm{Col}_{\\min}(N)=1")#text(" if and only if ")#mi("\\mathrm{Col}(N)")#text(" does), but this seems too weak of an invariance to hope to obtain worst case results from average case ones (unless the average case results were really, ")#emph[#text("really")]#text(", strong).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a8de5e657fc101702b7b8285747ad6fc25a2dfbe960263701725dbb99b72760-c9c35a2432d01b3d7ef381e03f566399ce714a083d496f75b6c725d7eaa64ea8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Buzzman")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521904")[#strong[#text("Buzzman")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("Let ")#mi("u")#text(" and ")#mi("v")#text(" denote the odd and even parities, respectively, of the terms in the Collatz orbit ")#mi("\\{N, \\textnormal{Col} (N), \\ldots, \\textnormal{Col}^{n}(N)\\}")#text(", where ")#mi("n=u+w")#text(". Define ")#mi("\\delta = \\log_{2}(3)-1")#text(" such that")

#mi("f_{n,u}(N) = \\sum_{i=0}^{u} \\binom{n}{i}")#text(",")

#text("where ")#mi("u =\\lfloor (n+1) / (\\delta +1) \\rfloor")#text(" with the floor function being a stopping time criterion. Parenthetically, one can also express ")#mi("f_{n,w}(N)")#text(" taking ")#mi("w = \\lfloor \\delta (n+1) / (\\delta +1) \\rfloor")#text(". Then a simple proposition for ")#mi("N \\in \\mathbb{N}")#text(" satisfying the “almost all” argument, in the sense that ")#mi("\\textnormal{Col}_{min} (N) < N")#text(", is of the form")

#mi("F_{n,w}(N) = \\dfrac{2^{n}+f_{n,w}(N)}{2^{n+1}}")#text(",")

#text("where ")#mi("F_{n,w}(N) \\to 1")#text(" as ")#mi("n \\to \\infty")#text(". Observe that ")#mi("F_{n,w}(N)")#text(" decomposes into ")#mi("1/2")#text(" probability for ")#mi("N")#text(" even and ")#mi("f_{n,w}(N)/2^{n}")#text(" for ")#mi("N")#text(" odd. The same argument applies for ")#mi("F_{n,w}(N)")#text(" if one takes ")#mi("f_{n,w}(N)")#text(". Exceptional cases are due mostly to ")#mi("N \\equiv 7\\pmod{8}")#text(" or when such ")#mi("N")#text(" are iterates of ")#mi("N \\equiv 1, 3, 5 \\pmod{8}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/643d2de1b501b3ce5b6c8efd04bb420e1f128e0db0bbd3eaafa3413082e8b2b1-dc380854e198eef069da9b75ec2b16538ea6d09a2e799d28464821b49394a8be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of suitably impressed")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521917")[#strong[#text("suitably impressed")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("That’s a wonderfully clarifying set of remarks, that deserves promotion to a blogpost of its own.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of random reader")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522207")[#strong[#text("random reader")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("In addition to Terry’s (amazing) remarks on worst vs average case, the methodological distinctions between qualitative vs quantitative, and constructive vs nonconstructive, are further dividing lines that are predictive of when the proof of a weaker result can be re-used in a proof of a stronger result.")

#text("As in the worst vs average, unless there is some transference principle to go from one side of the divide to the other, methods and results on the weak side will typically be dis-similar to those on the strong side.")

#text("The example of Faltings’ theorem (Mordell conjecture) was a good one. It is a qualitative result, finite number of rational points, with no bound on the size of the solutions. Finding all of the rational points on specific curves, and proving that those are all the solutions, is superficially a similar problem but in practice uses different techniques than Faltings.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522216")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("One further addendum: even when there are no direct transference results between different “worlds” of result types, and even when the methods of proof in different worlds are quite distinct, one can still use the ")#emph[#text("relative")]#text(" difficulty between results in one world as a predictor of the relative difficulty in another world. For instance, suppose that two similar-looking statements ")#mi("X")#text(" and ")#mi("Y")#text(", with the “almost all” versions of both ")#mi("X")#text(" and ")#mi("Y")#text(" known, but the “all” versions of both statements not known, then there may be no way to transfer the almost all theorems and methods to the all setting. But if the almost all version of ")#mi("X")#text(" was more difficult to establish than the almost all version of ")#mi("Y")#text(", then it is then reasonable to predict that the “all” version of ")#mi("X")#text(" will similarly be more difficult to establish than the “all” version of ")#mi("Y")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of random reader")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522217")[#strong[#text("random reader")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("To formalize: comparative difficulty tends to transfer along (both the horizontal and vertical directions of) the commutative diagrams we call “analogies”.")

#text("Speaking of transference principles, having arbitrarily slow unbounded functions seems similar to the principle in nonstandard analysis that infinite (nonstandard) objects are equivalent to unbounded sequences of finite/standard objects, e.g., over/under-spill, or the translation between nonstandard and epsilon-delta definitions in calculus. Here there is no obvious transference from arbitrarily good almost-everywhere asymptotic bounds to a finite bound holding a.e., but are there similar situations in analysis where the finite a.e. statement (the equivalent in this context of “almost all integers go to 1 under the Collatz iteration”) is actually known to be false?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522229")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("One can easily cook up examples. For instance, for any function ")#mi("f: {\\bf N}+1 \\to {\\bf R}")#text(" that goes to infinity, one can easily show (using the Weyl equidistribution theorem) that ")#mi("1/\\{ \\sqrt{2} N \\} \\leq f(N)")#text(" for almost all ")#mi("N")#text(" (in the sense of natural density), where ")#mi("\\{x\\}")#text(" is the fractional part of ")#mi("x")#text(", but there is no bound ")#mi("C")#text(" such that ")#mi("1/\\{ \\sqrt{2} N \\} \\leq C")#text(" for almost all ")#mi("C")#text(". (Instead, the previous claim is equivalent to the assertion that for each bound ")#mi("C")#text(", the bound ")#mi("1/\\{ \\sqrt{2} N \\} \\leq C")#text(" holds for a set of ")#mi("N")#text(" of density that depends on ")#mi("C")#text(", but goes to 1 as ")#mi("C \\to \\infty")#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of random reader")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522221")[#strong[#text("random reader")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("This is turning into a very interesting side discussion making (somewhat) precise what is normally unwritten folk wisdom. To that end I’ll add an addendum to Terry’s addendum on relative difficulty.")

#text("The informal judgement that result X is harder to prove than related (e.g., weaker) result Y, often rests on the use of particular advanced tools as modules in the proof of X and not Y. Typical examples:")

#text("X requires explicit error estimates in the prime number theorem (or some analytic property of the Riemann zeta function), but Y only uses the infinitude of prime numbers.")

#text("X uses the Weil conjectures or things only known to follow from those, but Y only uses Lang-Weil estimates for the number of points on varieties mod p.")

#text("X uses the classification of finite simple groups, Y uses basic representation theory of finite groups.")

#text("X uses algebraic K-theory, Y uses De Rham cohomology on smooth manifolds.")

#text("In many cases of this sort, the machinery used in X is a black box, effectively an extra set of axioms. So X is from this point of view a result in a stronger formal system (as long as one does not resort to re-proving from scratch results equivalent to the black box) than the one used to prove Y, and the comparison of difficulty becomes similar to that of results proved with and without a particular axiom (e.g., the Axiom of Choice, or Excluded Middle). This makes the comparison closer to the constructive/nonconstructive distinction, polynomial vs exponential time for algorithms, and independence results in logic where the weaker system simply cannot prove a particular theorem. Also, there is often a sort of “reverse mathematics” where a cluster of X-like results all imply or are implied by the advanced module used to prove X (analogous to the polynomial reductions in NP completeness), or are equivalent to each other, giving evidence that the heavy machinery is really necessary.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8dec713ab96d4ffad048c623f74a178fe45e70db140b7efef4aaad575f3f0ee-3e364cd825e9022056c74c6ca5719221f7de73d83fe2b94cadafa62e0426fdeb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vincent")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-564139")[#strong[#text("Vincent")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2020")])]

#text("Sir what is formular of collatz conjecture")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e7bf75c668be18a7e671c946e67cb33d97edb902795f22cf86179c99efc6378-0d6d96e4350f1df00ec4ffa5dfcc48f40c36198c9871d7a84c523f4f5f4bf6cf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-564562")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")])]

#text("Look beyond the conventional formula. The conjecture can be simplified to this:")

#text("Given three arithmetic operations:")

#text("a = ((n + 1) * (3 / 2)) – 1")#linebreak()#text(" b = ((n – 1) * (3 / 4)) + 1")#linebreak()#text(" c = (n – 1) * (1 / 4)")

#text("For every odd input integer n, can only one output, a or b or c, be a whole odd number.")

#text("If this statement is true, the conjecture is true. (It would take too long to explain why, but it’s certainly not higher mathematics or advanced number theory as I see it.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-534263")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2019")])]

#text("Nevertheless, the foundation of the conjecture is facile:")#linebreak()#text(" “All 3x+1 sequence steps for odd ns are equivalent to multiplication by 0.25, 0.75, and 1.5 for n + 1 or n – 1.”")#linebreak()#text(" ")#link("https://www.quora.com/Is-the-Collatz-conjecture-trivial/answer/Michael-M-Ross")[#text("https://www.quora.com/Is-the-Collatz-conjecture-trivial/answer/Michael-M-Ross")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-534267")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2019")])]

#text("Your Quora answer is nonsense")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-534275")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2019")])]

#text("“Utter nonsense”, said Wittgenstein of Cantor :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-534278")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2019")])]

#text("Sounds like a fair comparison to me")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-542090")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2020")])]

#text("I can’t visualize what the worst case form for a Collatz dynamic might be. Is it possible that it is where the number of even steps is equal to or close to that of even steps?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2d0c5bf42cc3ac174332c6bd665971e6b4becb5f8c50395b656939d75dcf8af-77e09485fd68abc4efdb8976936b9a73eec07a2572bf3e1f5cd05e5d3400b78a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Idriss")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-557622")[#strong[#text("Idriss")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2020")])]

#text("Somehow using a different method than yours I have achieved a result that is similar in generality. I am curious of your input on it. ")#link("https://hal.archives-ouvertes.fr/hal-02488108/document")[#text("https://hal.archives-ouvertes.fr/hal-02488108/document")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d88a999d593035d7e2b9ea8dd30059fef11fd087df25fbcc7f71fbeb082971c3-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-557754")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2020")])]

#text("Hello @ Idriss, I don’t know if your comment is for someone in particular. I have read your paper, but I need time to understand it well with my basic mathematics. If you are interested in my opinion, I think we are in the scenario that “all orbits, even the worst possible, are bounded, either up to 1, or up to n”.")#linebreak()#text(" No orbit, infinite n, can escape infinity.")#linebreak()#text(" Well, for all odd n, n + 1 is even, in the form ")#mi("a \\ times 2 ^ {x}")#text(", and in a Col2 map, in x steps, it is even, therefore, at least the number of divisions by 2 is greater than the number of multiplications by 3, if k is the number of odd steps, multiplications by 3, and y is the number of even steps, divisions by 2, for all n, when k tends to infinity, y is much greater than k, and y – k tends to infinity, and no orbit escapes infinity, then it tends to 1, it has negative drift, or it tends to n, it would enter periodic orbit.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2d0c5bf42cc3ac174332c6bd665971e6b4becb5f8c50395b656939d75dcf8af-77e09485fd68abc4efdb8976936b9a73eec07a2572bf3e1f5cd05e5d3400b78a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Idriss")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-606501")[#strong[#text("Idriss")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2020")])]

#text("I have attempted a completely different approach ")#link("http://idrissaberkane.org/wp-content/uploads/2020/11/Endomorphisms_of_the_Collatz_quiver.pdf")[#text("http://idrissaberkane.org/wp-content/uploads/2020/11/Endomorphisms_of_the_Collatz_quiver.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/004e8635b32280ae0ae934c93cde527d9fe232da84d7f11e282d3b5f6855200f-9413a8a6e48b60b20f5c34d4bd14ffee77b6afa6cdb14782384373494dd4b965.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-629554")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2021")])]

#link("https://zhuanlan.zhihu.com/p/378431303")[#text("https://zhuanlan.zhihu.com/p/378431303")]#linebreak()#text(" there is a bounds of every single prime")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35f8ceee929965a28612e4e1a0900e62b968da10247468dff7bbd4ad567e3d2d-bf9523eda5a5760967cd52ce8c274c7bade433251d9ebd051efb752f2d7be060.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pete")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521836")[#strong[#text("Pete")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2019")])]

#text("To give a different viewpoint..")#linebreak()#text(" Today, immediately after you conjecture ‘all X satisfy..’ you would want to at least heuristically convince yourself that your conjecture holds for almost all X (ideally with a few different random models).")#linebreak()#text(" But suppose you prove ‘almost all X’ for some reasonable random model. Is this good evidence that ‘all X’? Well, for a (obviously stupid) example, you might conjecture every ")#mi("n")#text("-vertex graph with minimum degree ")#mi("\\sqrt{n}")#text(" is Hamiltonian. This is false – but true a.a.s. for a bunch of natural random models. The proofs that the random models are a.a.s. Hamiltonian, though, use the randomness in a very essential way.")

#text("On the other hand, suppose I prove that ‘all X such that horrible structural condition’. If ‘horrible structural condition’ happens to hold for almost all X (for some reasonable model) then I’m likely to title my paper ‘Almost all X…’ simply because it sells better. Such a proof quite possibly could be useful in a proof of ‘all X’; maybe later I (or someone) can weaken the horribleness and deal with the remaining cases.")

#text("Short version: no rigorous connection, but if you look at the proof of ‘almost all’ you may sometimes find it is useful.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/178ca9827f9e0cab9b8475587f96aa4d20947fc509b224db2c93ea9e21cbb755-0e8079c2a16dbfed281ff1a128be47841c41b95c694329c0dc52a07f51019c27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of not all graphs are like that")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-524301")[#strong[#text("not all graphs are like that")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2019")])]

#text("Random (“almost all”) behavior rarely predicts extremal (“all”) behavior for graphs, unlike the situation in number theory.")

#text("For the integers the random models of primes, Diophantine equations, Collatz, class groups, etc are all pretty good at making predictions that seem correct empirically and can sometimes be proved by (much harder) deterministic methods. Often even a very naive model is informative, as in the discussion in this comment section of whether “negative drift” is potentially enough to make general Collatz type iterations go bounded.")

#text("The extremal problems for graphs maybe resemble more the “irregularity of distribution” questions for primes, i.e., how far can things diverge from the predictions of the random model.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2f537f89c63418d28f22465a40a0563c0707966dacce6e5a0156eb673e0b8ec-6dfc4592aef5f81fca0dd864706ebade6d0b64ddce9d6ca15fb2de7dfdef57cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jackson")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-534254")[#strong[#text("Jackson")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2019")])]

#text("I have created the proof for this. I tried email professors, but no response. If you have suggestions, let me know.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/686de7c56e01b9812b7dab89e546012de642bacbe076abbb729dc42f7ff8089a-e85a696188abca866bc724d3304752748cfcf62e5c8c2de35fe8a6be3c205525.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of omarleoblog")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521835")[#strong[#text("omarleoblog")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2019")])]

#text("The teorem of the conjecture is very awesome. Maybe because the teorem has a lot of results.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521838")[#strong[#text("Terry Tao partial results on Collatz conjecture")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2019")]

#text("[…] Tao announced today that he has new partial results toward proving the Collatz conjecture. His blog post and arXiv paper are both entitled “Almost all Collatz orbits attain almost bounded […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521841")[#strong[#text("Частичные результаты Терри Тао о гипотезе Коллатца {/} For coders {}")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2019")]

#text("[…] результаты в доказательстве гипотезы Коллатца. Его Сообщение блога а также бумага arXiv оба имеют название «Почти все […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521845")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2019")])]

#text("It seems that in the summands of (2) a second probability symbol ")#mi("\\mathbb P")#text(" is missing.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521854")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2019")])]

#text("“in the sense of logarithmic density”")#linebreak()#text(" I do not understand this. Could you please explain this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521856")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2019")])]

#text("Let ")#mi("A\\subset\\mathbb{N}+1")#text(" be a set of positive integers. We measure its “natural density” as follows: we impose a cutoff ")#mi("x")#text(", and ask: “what proportion of integers up to ")#mi("x")#text(" are contained in ")#mi("A")#text("?”. If this proportion tends to a limit ")#mi("\\Delta(A)")#text(" as ")#mi("x\\to\\infty")#text(" we say that the “natural density” of ")#mi("A")#text(" is ")#mi("\\Delta(A)")#text(". In symbols")

#mi("\\Delta(A) = \\lim_{x\\to\\infty} \\frac{\\# \\left(A\\cap[1,x]\\right)}{x}\\,.")

#text("This notion of “density” gives each integer an equal weight. We can define a new notion of “size” by giving the integer ")#mi("n")#text(" the weight ")#mi("\\frac{1}{n}")#text(". We would then measure the “proportion” of the interval ")#mi("[1,x]")#text(" occupied by ")#mi("A")#text(" by the following fraction:")

#mi("\\frac{\\sum_{n\\in A, n\\leq x} \\frac{1}{n}}{\\sum_{n \\leq x} \\frac{1}{n}}\\,.")

#text("Suppose now that this ratio tends to a limit ")#mi("\\delta(A)")#text(" as ")#mi("x\\to\\infty")#text(". Note that the denominator (a partial sum of the harmonic series) is very close to ")#mi("\\log x")#text(". We therefore have")

#mi("\\delta(A) = \\lim_{x\\to\\infty}\\frac{\\sum_{n\\in A, n\\leq x} \\frac{1}{n}}{\\log x}\\,.")

#text("This limit (if it exists) is called the “logarithmic density” of ")#mi("A")#text(" (note the logarithm in the denominator).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Jones")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521860")[#strong[#text("Alex Jones")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2019")])]

#text("Fix a property ")#mi("P")#text(" that a positive integer ")#mi("n")#text(" might have. Say ")#mi("P(n) = 1")#text(" if ")#mi("n")#text(" has property ")#mi("P")#text(" and ")#mi("P(n) = 0")#text(" otherwise. It is said that almost all positive integers (w.r.t. logarithmic density) have property ")#mi("P")#text(" if ")#mi("\\lim_{N \\to \\infty} \\frac{1}{\\log N} \\sum_{n=1}^N \\frac{P(n)}{n} = 1")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521857")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2019")])]

#text("On page 2 of the paper (definition of logarithmic density) you have “for all ")#mi("A\\subset S")#text(" where you probably mean “for all ")#mi("A \\subset\\mathbb{N}+1")#text(".")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521866")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2019")])]

#text("Thank you for your reply !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a8de5e657fc101702b7b8285747ad6fc25a2dfbe960263701725dbb99b72760-c9c35a2432d01b3d7ef381e03f566399ce714a083d496f75b6c725d7eaa64ea8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Buzzman")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521876")[#strong[#text("Buzzman")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2019")])]

#text("Your formulation takes ")#mi("Col(N)=3N+1")#text(" if ")#mi("N")#text(" is odd and ")#mi("N/2")#text(" if ")#mi("N")#text(" is even. There should be appropriate clarification when citing previous results based on ")#mi("Col(N) = (3N+1)/2")#text(" if ")#mi("N")#text(" is odd.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521960")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("I refer to this acceleration of the Collatz map as ")#mi("\\mathrm{Col}_2")#text(" in the paper. It is not difficult to see that ")#mi("\\mathrm{Col}_{\\min}(N) = (\\mathrm{Col}_2)_{\\min}(N)")#text(" for all ")#mi("N")#text(", so all the results in the literature concerning ")#mi("\\mathrm{Col}_{\\min}")#text(" hold without any changes if one works with ")#mi("\\mathrm{Col}_2")#text(" instead.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a8de5e657fc101702b7b8285747ad6fc25a2dfbe960263701725dbb99b72760-c9c35a2432d01b3d7ef381e03f566399ce714a083d496f75b6c725d7eaa64ea8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Buzzman")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521987")[#strong[#text("Buzzman")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("I see now. And I can only smile at how shallow I can be, but always fervent at learning your depth. Thanks.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521896")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("It seems that in definition 1.2 In the arXiv paper, ")#mi("A \\subset S")#text(" should be ")#mi("A \\subset R")

#emph[#text("[This will be corrected in the next revision of the ms, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521903")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("In definition 1.7 it seems clearer to replace ")#mi("\\mu \\geq 1")#text(" by the strict inequality ")#mi("\\mu > 1")

#emph[#text("[This will be corrected in the next revision of the ms, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0bf0f7949fe1ff66cb974670b02d5efbec6162ca0124dddf9cd129dc4053fd3c-c94b70cd62e10c6ccfdcef693fb72aff3dfd9e1616bc747696e1322760a506ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521918")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("It would obviously be nice to extend the result to showing that ")#mi("\\mathrm{Col}_{\\mathrm{min}}")#text(" was bounded on almost all integers. Having toyed around with this result for a bit, it seems that you clearly can’t have a positive logarithmic density subset on which ")#mi("\\mathrm{Col}_{\\mathrm{min}}")#text(" limits to infinity (because then you can set ")#mi("f(n) = \\mathrm{min}_{x \\geq n, x \\in N} \\mathrm{Col}_{\\mathrm{min}}")#text(" and some element will have to be bounded by its own ")#mi("\\mathrm{Col}_{\\mathrm{min}}")#text(" value.)")

#text("However, it feels hard to construct such a set even if you assume the stronger result for a contradiction. Is there a good reason for an obstruction to this method?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0bf0f7949fe1ff66cb974670b02d5efbec6162ca0124dddf9cd129dc4053fd3c-c94b70cd62e10c6ccfdcef693fb72aff3dfd9e1616bc747696e1322760a506ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521921")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("More specifically, are there well known examples of functions of ")#mi("\\mathbb{N}")#text(" which are not bounded (more weakly) on any subset of positive density or (more strongly) on almost all integers and yet have no positive density subsets on which the function goes to infinity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521965")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("If there is no set of positive density on which a function ")#mi("f")#text(" is bounded, then for each threshold ")#mi("C_0")#text(", the set ")#mi("\\{ N: f(N) \\leq C_0 \\}")#text(" must necessarily be of zero density, and a standard diagonalisation argument then shows that ")#mi("f(N) \\to \\infty")#text(" outside of a set of density zero.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521963")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("This is discussed in Remark 1.4 of the paper. The best one seems to be able to do with the methods in the paper is to show that for each ")#mi("C_0 > 0")#text(", one has ")#mi("\\mathrm{Col}_{\\min}(N) \\leq C_0")#text(" for a set of positive integers ")#mi("N")#text(" of logarithmic density ")#mi("1 - O( \\log^{-c} C_0 )")#text(" for some absolute constant ")#mi("c>0")#text(" (though there is some hope of reducing the error ")#mi("\\log^{-c} C_0")#text(" a bit). In particular, for sufficiently large ")#mi("C_0")#text(", one can show ")#mi("\\mathrm{Col}_{\\min}(N) \\leq C_0")#text(" for a positive logarithmic density set of integers; in principle, this could be combined with a numerical verification of cases up to ")#mi("C_0")#text(" to obtain the result that the Collatz conjecture held for a set of positive logarithmic density. (Thanks to Ben Green for pointing out this possibility to me.) Unfortunately the value of ")#mi("C_0")#text(" produced by the arguments in my paper, while in principle explicit, are almost certainly too enormous for this strategy to be easily implemented, but perhaps some variant of the methods in my paper could be used to achieve this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daef43b8fa77b8e0a6be1533453373bcadd5864e36af70c72b7407b5a16397c8-890e4a39e571f637f4ff8e5e890f6da0b70140b7a0e8866abf7bfa29d2f55f51.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Lowry-Duda")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521957")[#strong[#text("David Lowry-Duda")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("I haven’t had the time to work out the details, but it seems to me that much of what you’ve written would apply for something like the 5n+1 variant of the Collatz conjecture. I wonder if it is also true that almost all (5n+1)-collatz orbits attain almost bounded values?")

#text("I think this would be a bit interesting since it is believed that there are orbits in the (5n+1)-collatz problem that get arbitrarily large.")

#text("Does this happen to be something you have thought about?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521962")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("The argument relies in many places on the inequality ")#mi("\\frac{\\log 3}{2 \\log 2} < 1")#text(", to ensure that the Collatz iterations have average negative logarithmic drift. Since ")#mi("\\frac{\\log 5}{2\\log 2} > 1")#text(", I would instead expect the reverse to be true for the ")#mi("5n+1")#text(" map, namely that almost all ")#mi("5n+1")#text(" iterates would escape to infinity. (Unfortunately the method of proof in this paper won’t extend to this case, as the probability measures are now being stretched into ever larger regions of space rather than being compressed into ever smaller regions, and one can’t hope to keep the probability measures stable in total variation in the former case.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daef43b8fa77b8e0a6be1533453373bcadd5864e36af70c72b7407b5a16397c8-890e4a39e571f637f4ff8e5e890f6da0b70140b7a0e8866abf7bfa29d2f55f51.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Lowry-Duda")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521981")[#strong[#text("David Lowry-Duda")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("Aha, I understand. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of oculus drift")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522200")[#strong[#text("oculus drift")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("Is the negative-drift condition enough to get the same type of result for generalized Collatz recursions (finite partition of N into arithmetic progressions with a linear function on each progression)? i.e. if the map heuristically pulls integers toward 1 on average, then the almost everywhere quasi-boundedness holds. It’s hard to hope for anything more than that, and the statement is not so strong as to contradict the undecidability of such recursions in general.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522202")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("This is a very good question. One has to be careful however to define “negative drift” properly – a naive definition can give incorrect predictions. For instance, consider the map that sends ")#mi("n \\mapsto 2n")#text(" when ")#mi("n = 0 \\text{ mod } 10")#text(", and ")#mi("n \\mapsto \\frac{n-j}{10}")#text(" when ")#mi("n = j \\text{ mod } 10")#text(" for ")#mi("j=0,\\dots,9")#text(". A typical number ")#mi("n")#text(" has a 90% chance of being reduced in size by 10 by this map, and a 10% chance of doubling, which would naively suggest a negative drift, but in fact pretty much all orbits get sent to infinity, because they almost certainly meet the ")#mi("0 \\text{ mod } 10")#text(" residue class at some point, at which point they grow exponentially.")

#text("Perhaps to define negative drift properly one has to define the dynamics on the profinite integers ")#mi("\\hat {\\mathbb Z} = \\prod_p {\\mathbb Z}_p")#text(" instead of the natural numbers (actually one should not need to use all primes here, only the primes that show up in the modulus of the residue classes and in the linear coefficient ")#mi("a")#text(" of the affine maps ")#mi("n \\mapsto an+b")#text(" should be relevant, for instance for Collatz it is the dynamics on ")#mi("{\\mathbb Z}_2 \\times {\\mathbb Z}_3")#text(" which is relevant). If the dynamics on ")#mi("\\hat {\\mathbb Z}")#text(" maps Haar measure towards an ergodic invariant probability measure ")#mi("\\mu")#text(" then one can then define the drift to be the mean value of ")#mi("\\log a")#text(" with respect to this measure, and one could tentatively conjecture that the results of my paper would extend to any dynamics with an ergodic limiting measure with negative drift. For instance in the case of Syracuse the attracting measure ")#mi("\\mu")#text(" on ")#mi("{\\mathbb Z}_2 \\times {\\mathbb Z}_3")#text(" is the law of ")#mi("(\\mathbf{X}_2, \\mathbf{X}_3)")#text(", where (in the notation of the paper) ")#mi("\\mathbf{X}_2, \\mathbf{X}_3")#text(" are independent random variables with the laws of ")#mi("\\mathbf{Haar}(2\\mathbb{Z}_2+1), \\mathbf{Syrac}(\\mathbf{Z}_3)")#text(" respectively; if one includes other primes ")#mi("p \\neq 2,3")#text(" then one just adds on independent copies of ")#mi("\\mathbf{Haar}(\\mathbb{Z}_p)")#text(". Here the drift is ")#mi("\\log \\frac{3}{4}")#text(". (If one uses the original Collatz map rather than the Syracuse acceleration then the invariant measure is somewhat more complicated to describe; roughly speaking it is ")#mi("2^{\\mathbf{n}} (\\mathbf{X}_2, \\mathbf{X}_3)")#text(", where ")#mi("\\mathbf{n}")#text(" is a non-normalised uniform probability kernel on the natural numbers independent of ")#mi("\\mathbf{X}_2, \\mathbf{X}_3")#text(", conditioned to the event ")#mi("\\mathbf{n} \\leq \\mathbf{Geom}(2)")#text(" for a geometric random variable ")#mi("\\mathbf{Geom}(2)")#text(" independent of all previous variables.) By the ergodic theorem, negative drift would imply that almost all profinite integers would exhibit orbits whose cumulative linear multiplier would go to zero in the Archimedean sense, which would heuristically support almost all orbits becoming bounded.")

#text("One interesting question would be to see if one can construct an iteration that had negative drift in the above sense, but which still had at least one unbounded orbit. I don’t think the Conway-style FRACTRAN iterations can achieve this, but perhaps some more subtle variant of them can.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of random reader")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522214")[#strong[#text("random reader")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("The nondegeneracy condition seems to be that the associated finite Markov chain has a single ergodic component (ie., strongly connected subgraph of recurring states) and then the contraction/expansion factor should be the same as on the adelic thing. I am assuming here that, taking N = product of all the primes (each to the largest power it occurs in the congruence moduli, numerators and denominators of the linear maps), there is a suitable and not too complicated sense in which the iteration is a Markov chain whose states are “randomly chosen integers in one residue class mod N”, which would be a restatement and formalization of the probability heuristic, and then to use that chain to calculate the contraction factor.")

#text("Assuming that this could be done, is it plausible that your methods adapt without major new ideas to the general iteration, or are they tied in some way to the map being 3x+1?")

#text("A related question (to assess dependence on 3x+1 versus variants with the same contraction factor) is the adversarial 3x+1 problem. The Collatz iteration, but sometimes changed to 3x+A where A is chosen each time from a given finite set of alternatives (such as anything from -10 to +10). If an adversary can change 100 percent, or 1 percent, or O(log n), of the applications of 3x+1 to (3x+A)’s, can it force the iteration to go unbounded? If the adversary always has enough freedom to force divergence, is that still true if the choices of A’s are require to equal, in average, the A in the iteration (such as +1 for Collatz) or to concentrate suitably around that number?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522228")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("I think it would be non-trivial, but perhaps possible, to extend the arguments in this paper to this more general setting. The original Collatz problem has a nice property that I rely on somewhat heavily in my paper, namely that the iteration is controlled entirely by the 2-adic nature of the starting point, but the irregularities of distribution caused by the iteration only manifests in the 3-adic statistics. (In particular, there is a key use of the Chinese remainder theorem in the proof of Lemma 5.2 that basically relies on this decoupling between the controlling coordinates and the irregularly distributed coordinates.) For more general Collatz-type systems this would not be the case and the analysis may become somewhat more difficult (though perhaps not completely intractable).")

#text("I would imagine that an adversarial model could flip a negative drift model such as the original Collatz to a positive drift one given enough options available to the adversary, which would provide heuristic justification at least for unbounded orbits.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of random reader")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522232")[#strong[#text("random reader")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("Thanks for that inspiring answer (and the blog that makes such Q & A possible). It sounds like either the full generalization is attainable, or there are very interesting things to learn about the decoupling property and its extensions and possible role as a (dis)obstruction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522248")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("Despite having no prestige to lose, I do not want to interfere in your great work with my comments of, surely, low quality, but in turn, I think it is time to try to expose my intuitions about the conjecture. When you talk about “nondegeneracy condition” it is because the conjecture avoids this condition or seeks it. I say this because if it is possible to represent the binary relations of the function in some way, we would obtain an infinite Boolean matrix, and apparently, it must be singular or degenerate. “Singular matrices are rare in the sense that a square matrix randomly selected from a continuous uniform distribution on its entries will almost never be singular.” (Wikipedia).If this is so, and if the conjecture is true, it is precisely because the function 3n + 1, and apparently perhaps only it, manages to avoid the kind of residue 0 mod 3 and at the same time from an initial N, also manages to avoid the residue class 0 mod N.If this is so, and if the conjecture is true, it is precise because the function 3n + 1, and apparently perhaps only it, manages to avoid the kind of residue 0 mod 3 and at the same time from an initial N, also manages to avoid the residue class 0 mod N. These characteristics prevent get trapped in a periodic orbit. In the 5n + 1 conjecture, we know that certain numbers fall into periodic orbits and, I don’t know if by chance, but at least a multiple of 3 is involved. Perhaps this condition is what makes it impossible for any multiple of 3 to fall into a periodic orbit, and perhaps the truth of the conjecture is here because it is the multiples of 3 that enable the possibility of entering a periodic orbit.")#linebreak()#text(" Maybe I extend too much, but I want to take the opportunity to ask if Professor Tao’s strategy would change if instead of using mod 3 ^ n, would use mod N, where N is the starting point, to see if zero residue mod N is avoided.")#linebreak()#text(" Another question I wanted to ask is whether it is interesting or possible to try to prove that if we assume that no N falls into a periodic orbit, it could be shown that no N escapes to infinity, and therefore the truth of the conjecture would depend solely on demonstrating that no it is possible to fall into a periodic orbit. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/004e8635b32280ae0ae934c93cde527d9fe232da84d7f11e282d3b5f6855200f-9413a8a6e48b60b20f5c34d4bd14ffee77b6afa6cdb14782384373494dd4b965.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-629559")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2021")])]

#text("maybe the fundamental truth is they do can be decomposed to the prime factors and the hidden pattern is that all the prime can be viewed has geometric order, for the reason we can find the natural order with certain times of 3n+1 scale up mapping. we can compute the P(n) scattering in all the primes,like P(1)=1,P(2)=3,P(3)=17,P(4)=23,P(5)=29,P(6)=37,P(7)=101,P(8)=131etc.")#linebreak()#text(" hence we get the Dirac measure in geometry and Collatz mapping bounds of every prime. i believe this pattern could help us to prove the conjecture,but i don’t want to do the heavy computes.")#linebreak()#text(" here is a detail expression of such hidden pattern.")#linebreak()#text(" ")#link("https://www.zhihu.com/people/wu-ju-shi-2017/posts")[#text("https://www.zhihu.com/people/wu-ju-shi-2017/posts")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/004e8635b32280ae0ae934c93cde527d9fe232da84d7f11e282d3b5f6855200f-9413a8a6e48b60b20f5c34d4bd14ffee77b6afa6cdb14782384373494dd4b965.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-629579")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2021")])]

#text("as Tao’s 5n+1 counter prove conjectured , 5n+1 has no prime oder in natural geometry seriers. so Mr. Tao, why not have a try on computing following advice by the post above?")#linebreak()#text(" ”")#linebreak()#text(" The nondegeneracy condition seems to be that the associated finite Markov chain has a single ergodic component (ie., strongly connected subgraph of recurring states) and then the contraction/expansion factor should be the same as on the adelic thing. I am assuming here that, taking N = product of all the primes (each to the largest power it occurs in the congruence moduli, numerators and denominators of the linear maps), there is a suitable and not too complicated sense in which the iteration is a Markov chain whose states are “randomly chosen integers in one residue class mod N”, which would be a restatement and formalization of the probability heuristic, and then to use that chain to calculate the contraction factor.")

#text("Assuming that this could be done, is it plausible that your methods adapt without major new ideas to the general iteration, or are they tied in some way to the map being 3x+1?")#linebreak()#text(" ”")#linebreak()#text(" ————————————————-")#linebreak()#text(" i found this routine myself , in a naturaly intuitive on number theory way. so i tried the easy compute, then found the bounds of every single prime.the factor as a bound was equal to p/n，where n is the geometry order series in natural number style. p is the prime factor of N.actually the bound means the obits space dimentions!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522003")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("Dear Sir.Tao,")#linebreak()#text(" Thanks you very much,")#linebreak()#text(" We are in a math conference in our country now. We are talking about you very much. We expect you have a hattrick in September, 2019 with Twin primes conjecture, Goldbach conjecture beside above Collatz conjecture.")#linebreak()#text(" Best wishes,")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ridiculous Amateur")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521977")[#strong[#text("Ridiculous Amateur")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("I’m an amateur who didn’t take any math beyond undergrad and so *surely* I will embarass myself here, but I’ve come back to Collatz a lot over the years and I always feel like I’m stumbling somewhere near the answer.")#linebreak()#text(" If we can show that repeated application of Col() to any N > 1 will always eventually produce an integer < N (‘reduce’), that removes both the possibility of any other orbits and the possibility of unbounded growth in one go. Easier said than done, but that one property is all we need.")#linebreak()#text(" So what I do next is start carving up N into constructible categories that reduce, thereby chipping away at the space where a counterexample could exist.")

#text("Obviously even N reduce immediately and need no further consideration.")#linebreak()#text(" Fairly trivially, N of the form 4k+1 reduce in 3 applications of Col(), since 4k+1 is necessarily odd, 3 * (4k+1) + 1 = 12k + 4 which is divisible by 4 and so halves twice to yield 3k + 1. 3k + 1 > 4k + 1, so we reduce.")#linebreak()#text(" That’s now 3/4 of all N that reduce! Wow, we’re really cooking! Duh, the constructions get hairier from here, but there’s still a pattern hiding in there.")

#text("Skipping over the repeated applications and just listing some reductions with (the proportion of N now shown to reduce) and [H]alve and [M]ultiply sequence, we have:")#linebreak()#text(" 2k -> k (1/2)[H]")#linebreak()#text(" 4k + 1 -> 3k + 1 (3/4) [MHH]")#linebreak()#text(" 16k + 3 -> 9k + 2 (13/16) [MHMHHH]")#linebreak()#text(" 32k + 11 -> 27k + 10 (27/32) [MHMHHMHH]")#linebreak()#text(" 32k + 23 -> 27k + 20 (28/32) [MHMHMHHH]")#linebreak()#text(" 128k + 7 -> 81k + 5 (113/128) [MHMHMHHMHHH]")#linebreak()#text(" 128k + 15 -> 81k + 10 (114/128) [MHMHMHMHHHH]")

#text("This is hardly comprehensive, but continuing to fill these out will inch us closer and closer to showing ‘all N’ reduce and if along the way somebody sees a hidden relation or pattern we can close the whole thing.")

#text("What I see is that the power of 2 acts as the left-hand coefficient and represents the number of ‘halving’ applications of Col() and the right hand power of 3 is the ‘multiplying’ applications of Col(). We know the power of 2 is always such that the result is greater than the power of 3 on the other side. Any less and it wouldn’t be a reduction, any more and we would have ‘passed’ the reduction.")#linebreak()#text(" This means some powers of 2 will never show up, because there’s no available power of 3 for them to reduce. Any 8k + x is more-than-reduced from a 3k + y form, and insufficient to reduce a 9k + y form.")#linebreak()#text(" So we can trace out the ‘possible’ forms by examining the relationship between growth of powers of 2 and 3. We know how many M/H operations will happen and it’s only the order that can change.")#linebreak()#text(" The possible orderings are bounded by needing to always follow M with H and needing to ‘spread out’ the H operations so as to not overcome the M until the end. The k term remains even until the final application of Col().")#linebreak()#text(" So that leaves the constant term to ‘select’ the order within the valid options – or the order to select the constant, however you want to view it.")

#text("Even if this approach *doesn’t* reveal any fundamental truth or provide unique insight to solve the problem, it *does* allow a computer program to very quickly prove an arbitrary fraction of possible N reduce, which is much better than counting and testing individual numbers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522036")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2019")])]

#text("I think you may be on your way to rediscovering the arguments and results ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=568274")[#text("of Terras")]#text(" (link to article ")#link("http://matwbn.icm.edu.pl/ksiazki/aa/aa30/aa3034.pdf")[#text("here")]#text("). In the language of this blog post or my paper, the conclusion is that ")#mi("\\mathrm{Col}_{\\min}(N) < N")#text(" for almost all ")#mi("N")#text(" (in the sense of natural density). It is true that if one could in fact show that ")#mi("\\mathrm{Col}_{\\min}(N) < N")#text(" for ")#emph[#text("all")]#text(" ")#mi("N>1")#text(" (not just almost all), this would resolve the Collatz conjecture, but this is one of these situations where there seems to be an enormous gap in difficulty between “almost all” results and “all” results.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522174")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("Suppose that a function ")#mi("f")#text(" from ")#mi("\\mathbb N")#text(" into itself has the property that if ")#mi("Col_{min}(N)  1")#text(" then Collatz conjecture would follow. Is ")#mi("f(N) = N")#text(" the smallest function with this property?")

#emph[#text("[It appears that your comments are being parsed incorrectly due to the use of < and > symbols that are parsed as HTML tags. Use &lt; and &gt; instead -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522176")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("Somehow (perhaps because of the symbol 1$ can be relaxed to a function ")#mi("f(N) \\geq N")#text(" while still implying the Collatz conjecture?")#linebreak()#text(" Is it possible that there is such ")#mi("f(N)")#text(" whose growth is faster(!) than N?")

#emph[#text("[It appears that your comments are being parsed incorrectly due to the use of < and > symbols that are parsed as HTML tags. Use &lt; and &gt; instead -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522204")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("Suppose that a function ")#mi("f : \\mathbb N \\to \\mathbb N")#text(" has the property that ")#mi("Col_{min}(N) < f(N)")#text(" for all ")#mi("N > 1")#text(" implies Collatz conjecture. Is there such ")#mi("f(N)")#text(" (with this property) whose growth to infinity is faster than ")#mi("N")#text("?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522209")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("Well, one trivially has the bound ")#mi("\\mathrm{Col}_{\\min}(N) \\leq N")#text(", so this question is equivalent to the full Collatz conjecture.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522551")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2019")])]

#text("The difference between “almost all” and “all” , can be infinite or can you establish that there is a finite number of counterexamples? I say it because if there is an orbit that escapes to infinity, it has infinite n odd ones, in addition to its 2 multiples. But if you can be established that the number of counterexamples must be finite, there can be no orbits that escape to infinity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jef")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522562")[#strong[#text("Jef")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2019")])]

#text("Back to 3x-1, what percentage of the natural numbers map to 1 as opposed to 5 and 17 combined?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522563")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2019")])]

#text("Doing a quick spreadsheet calculation, I found that for the 3x-1 conjecture, of all numbers from 1 to 10,000, 3,244 numbers eventually reach 1, 3,213 numbers eventually reach 5, and 3,543 numbers eventually reach 17.")

#text("So it’s about one third going to 1, one third going to 5, one third going to 17.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522566")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2019")])]

#text("Dear Jef. I liked to study the 5n + 1 variant to know why the conjecture fails, especially as regards the periodic orbits. The orbits that escape to infinity do not understand them very well, although both, seen from the inverse maps, apparently are orbits, or numbers, that are not generated from 1, so they never reach 1, from the original map. I have not studied the 3n-1 map, but I understand that it fails like 5n + 1, or is it interesting for something else other than being the original with the changed sign?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522629")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2019")])]

#text("Alberto,")

#text("Crandall’s 1978 paper in Mathematics of Computation has what you are looking for. His qx+1 problem.")

#text("You’ll see cycles correspond with solutions to Diophantine equations.")

#text("The most fascinating aspect about these problems is the hypothetical existence of divergent sequences. Forget the confusing terminology of orbit and trajectory etc.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522674")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2019")])]

#text("I have read Crandall’s 1978 paper and like the recent paper of Professor Tao, I can follow the plotline, but I cannot follow the demonstrations, which are well above my level. How does Collatz’s conjecture relate to diophantine equations if the conjecture is true?That’s why I try to take the guess to places I can understand, simple places. On equivalent problems of the form qx + r, sometimes we forget the importance of the function n / 2 for the peers. In the previous post of the professor, I leave a comment that talked about how I see the conjecture. When applying n / 2 we divide N into an infinite collection of disjoint infinite subsets/subgraphs, whose root is an odd number, of the form n and its 2 multiples. When you apply the function of the qx + r form, you are choosing how or where you want these subsets/subgraphs to join. Depending on the form you choose, you will get different results. For almost everything N, when you use the 3n + 1 function, you can avoid creating periodic loops, and that the resulting graph is a single graph weakly connected and oriented to 1. But I cannot visualize how an orbit could escape to infinity, since that every odd number connects to the graph. Analyzing this graph, it seems that several things can be deduced as if all N is connected, it is as if there is a single congruence class, and if it is possible to create the characteristic matrix, the vectors that form it are lineal dependent, that is, Its determinant is 0. Since it is an infinite matrix, it seems that it would be necessary to know if it is possible to explore the functional determinant of this infinite matrix via the zeta function of the operator.")#linebreak()#text(" Speaking of the property of the resulting graph, the property of the graph is weakly connected, it seems to have some connection with the property of being simply connected in the Poincare conjecture. In his paper, the professor speaks of triangles, although I do not understand the meaning. I have tried to see the conjecture in the unit circle, where a rectangular triangle is formed whose hypotenuse measures 3n + 1, the cosine is 3n and the versine is 1. For true, the value of all the hypotenuse 3n + 1 is of form 4 + 6x, (in the conjecture 5n + 1 would be 6 + 10x) where x is the ordinal of n odd. If the conjecture enters periodic orbit the value of this hypotenuse would reach from an initial n value, the value n * 2 ^ x, or the versine would have to be a multiple of n.when the value of the hypotenuse is a power of 2, then From a cosine triangle 3n, several triangles will have been formed that finally reduce to the triangle h = 4, cosine = 3 and versine = 1 and to point 1. In my words there is not much mathematical rigor, only intuition, that there is some detail that escapes us, to be able to demonstrate that cannot fall into a periodic orbit.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522680")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2019")])]

#text("Alberto,")

#text("I spent years reading and re-reading Crandall’s paper. It is hard to follow, and it was his first publication. Not even in his field. Think he earned a degree in physics. But the answers you seek are in it.")

#text("As far as this ms is concerned. There isn’t anything rigorous about it when applied to 3x+1. Most of Crandall’s results are rigorous. It’s up to the reader to decide which ones, the journals are not perfect. Blogs like this one certainly have the potential to help.")

#text("Yes it is hard to imagine what a divergent sequence looks like. Take another look at the formulas in Crandall’s paper.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Frost")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522795")[#strong[#text("Robert Frost")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2019")])]

#text("I rather feel the number of congruence classes which reduce is infinite in number, so you could continue for a long time and still not classify them all. Then the requirement would be to find the symmetry by which these classes are generated and show then that there is an induction which accounts for them all. The character of this induction however is complex, going up to N^N, each step being of one dimension greater than the previous. Such an approach leads into the theory of Borel sets, measure theory, sigma algebra… which is as far as I have got in that direction.")

#text("The best result I saw of your form took this so far as to show that proving any one class congruent to 1 mod 2^n converges, is equivalent to the conjecture. If that result can be metrized and used to show convergence to ")#mi("1 \\pmod 2^\\infty")#text(" in the 2 adic space is sufficient, this proves the conjecture, and IMO that is the closest I ever saw anybody get.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/004e8635b32280ae0ae934c93cde527d9fe232da84d7f11e282d3b5f6855200f-9413a8a6e48b60b20f5c34d4bd14ffee77b6afa6cdb14782384373494dd4b965.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-629558")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2021")])]

#text("i think your idea like Tao’s paper has do the same thing, maybe the fundamental truth is they do can be decomposed to the prime factors and the hidden pattern is that all the prime can be viewed has geometric order, for the reason we can find the natural order with certain times of 3n+1 scale up mapping. we can compute the P(n) scattering in all the primes,like P(1)=1,P(2)=3,P(3)=17,P(4)=23,P(5)=29,P(6)=37,P(7)=101,P(8)=131etc.")#linebreak()#text(" hence we get the Dirac measure in geometry and Collatz mapping bounds of every prime. i believe this pattern could help us to prove the conjecture,but i don’t want to do the heavy computes.")#linebreak()#text(" here is a detail expression of such hidden pattern.")#linebreak()#text(" ")#link("https://www.zhihu.com/people/wu-ju-shi-2017/posts")[#text("https://www.zhihu.com/people/wu-ju-shi-2017/posts")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/004e8635b32280ae0ae934c93cde527d9fe232da84d7f11e282d3b5f6855200f-9413a8a6e48b60b20f5c34d4bd14ffee77b6afa6cdb14782384373494dd4b965.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-629578")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2021")])]

#text("i would like anyone here to point out the error but not vote for mislieading, it’s really indecent!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521983")[#strong[#text("Almost all Collatz orbits attain almost bounded values – INDIA NEWS")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")]

#text("[…] Article URL: ")#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/")[#text("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-521988")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2019")])]

#text("1） almost all {N} (in the sense of natural density)")#linebreak()#text(" 2） almost all {N} (in the sense of logarithmic density).")#linebreak()#text(" 1) is not equivalent to 2） ？")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522035")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2019")])]

#text("If a property holds for almost all ")#mi("N")#text(" in the sense of natural density, then it also holds for almost all ")#mi("N")#text(" in the sense of logarithmic density (this is a good exercise in summation by parts). However, the converse is not always true. For instance, the property of not having a number of digits that is a perfect square (that is, not lying in any interval of the form ")#mi("[10^{n^2-1}, 10^{n^2}-1]")#text(") holds for almost all ")#mi("N")#text(" in the sense of logarithmic density, but not in the sense of natural density.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522105")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2019")])]

#text("First of all, congratulations on this new breakthrough. It has made me very happy that you dedicate your time and effort to this conjecture that so many amateurs dream of making some small advance that helps their resolution, although it is evident that the mathematics necessary to solve it are only within the reach of high-level mathematics.")#linebreak()#text(" About “…the possibility of some very rare exceptional {n} for which the orbit goes to infinity, or gets trapped in a periodic loop”, from your previous post. How it is now with this new result?, I mean if the possibility is still less yet, or remains the same, but reinforced from a stronger point of view, in the sense of logarithmic density.")#linebreak()#text(" About “…the property of not having a number of digits that is a perfect square (that is, not lying in any interval of the form [10^{n^2-1}, 10^{n^2}-1]) holds for almost all N in the sense of logarithmic density, but not in the sense of natural density.”. I wish I could understand, is there a simple way to explain this?. Thank you. (Written with the help of Google translate and Grammarly)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522134")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2019")])]

#text("One can use the arguments in the paper to show that the set of points that are in a periodic loop have zero density (in fact the set of exceptions up to ")#mi("[1,x]")#text(" is of size ")#mi("O(x^{1-c})")#text(" for some ")#mi("c>0")#text("; I will sketch the argument in the next revision of the ms. However, the arguments do not say anything directly about the proportion of points whose orbit will ")#emph[#text("eventually")]#text(" be trapped in a periodic loop, or will eventually go to infinity; the analysis in the paper can control most initial values to the point where they can be carried very close to ")#mi("1")#text(", but after that they are free to either get sent to ")#mi("1")#text(", get trapped in some other periodic loop, or go to infinity, and I don’t see any rigorous tools to determine which of these is the most probable outcome.")

#text("The verification of the claims about natural density and logarithmic density are a good exercise in computing sufficiently good upper and lower bounds on various averages. The continuous version of the exercise might be a good warm up for you. Namely: let ")#mi("E := [0,+\\infty) \\backslash \\bigcup_{n=1}^\\infty [10^{n^2-1}, 10^{n^2}-1]")#text(" be the set of positive reals that lie outside the intervals ")#mi("[10^{n^2-1}, 10^{n^2}-1]")#text(". See if you can show that (a) the limit ")#mi("\\lim_{x \\to \\infty} \\frac{1}{x} \\int_0^x 1_E(t)\\ dt")#text(" does not exist, and (b) the limit ")#mi("\\lim_{x \\to \\infty} \\frac{1}{\\log x} \\int_1^x 1_E(t)\\ dt")#text(" does exist and is equal to 1. For (a) one needs to get a lower bound for the average for some values of ")#mi("x")#text(" and an upper bound for other values of ")#mi("x")#text(" that are incompatible with the scenario where the limit exists. For (b) one needs upper and lower bounds for the average for all large ")#mi("x")#text(" that converge to each other as ")#mi("x \\to \\infty")#text(". Using the asymptotic notation ")#mi("O()")#text(" will make the calculations easier, and drawing pictures of the set (and perhaps of the areas under the curve one needs to integrate) may guide your intuition.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b08b827745114ecbcf181eee0a3a867a05ebe6d995372dd8705c25abb0e1196-21f4c0cf92482fc2101667c3851f102bf7ff008930ddeccf89069961030c4af6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of robfrot")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522796")[#strong[#text("robfrot")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2019")])]

#text("I often wondered whether there is a contradiction to be had from density arguments, of the form that any counterexample must also have nonzero density. Every counterexample is after all, essentially isomorphic to the known graph, and having a periodic orbit or infinitely ascending sequence rather than a fixed point, is in a sense larger. The suggestion would be to hypothesize another orbit having some least integer n and show that its density in the integers is greater than nonzero.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d88a999d593035d7e2b9ea8dd30059fef11fd087df25fbcc7f71fbeb082971c3-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-551582")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2020")])]

#text("Dear Professor Tao, when you talk about “… the analysis in the paper can control most initial values to the point where they can be carried very close to 1”, does this refer to values greater than 1?")

#text("I wanted to present a situation and how it could be interpreted.")

#text("One way to express Collatz conjecture is:")

#mi("n\\times \\frac{3^{k}}{2^{y}}+\\frac{TCR}{2^{y}}")

#text("for n = odd, where k = odd steps(3n) and y = even steps(n/2)")

#text("and TCR are the numbers of the form")

#mi("\\displaystyle 3^{k-1} 2^{a_1} + 3^{k-2} 2^{a_2} + \\ldots + 2^{a_k}")

#text("Assuming we don’t enter a periodic loop.")

#text("If we can demonstrate that when k grows to infinite, and y always grows much more than k, and y-k tends to infinity, (is this a known fact?)")

#text("without taking into account the term")

#mi("\\frac{TCR}{2y}")

#text("Can we affirm that we not only reach a value less than n but less than 1 always?")

#text("Once below these values, could they rise above n or 1?")

#text("Could we say that if k goes to infinity")

#mi("n \\times \\frac{3^{k}}{2^{y}}")#text(" tends to zero?")

#text("If we add the term")

#mi("\\frac{3^{k-1} 2^{a_1}}{2^{y}} + \\frac{3^{k-2} 2^{a_2}+ \\ldots }{2^{y}} + \\frac{2^{a_k}}{2^{y}}")#text(", would it still be below n? or above 1?")

#mi("\\frac{3^{k-1} 2^{a_1}}{2^{y}}")#text(" tends to zero?")

#mi("\\frac{3^{k-2} 2^{a_2}+ \\ldots }{2^{y}}")#text(" tends to zero?")

#mi("\\frac{2^{a_k}}{2^{y}}")#text(" is always a power of 2?")

#text("Can we affirm that when k goes to infinity the conjecture tends to a power of 2?")

#text("Thanks.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e5dba8f2327dc251ca254d8e0da04e23d821ba9b9d82c55bfe5611048e82ce9d-abd129eaded0c37cd0cfd24e489167557b25bec131fc963a56bc3ad9be81ea2f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terry Tao: can an approach used to prove almost all cases be extended to prove all cases? – Julia Wolffe's Notes")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522048")[#strong[#text("Terry Tao: can an approach used to prove almost all cases be extended to prove all cases? – Julia Wolffe's Notes")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2019")])]

#text("[…] Terry Tao posted to the arXiv his paper Almost all Collatz orbits attain almost bounded values, which caused quite the stir on social media. For instance, this Reddit post about it is only a day […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522086")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2019")])]

#text("Does the result also hold for the 3n-1 conjecture? (Where the plus is replaced with a minus) This conjecture is known to be false.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522104")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2019")])]

#text("Craig, what do you mean about 3n-1 being known to be false? Is it known to diverge for some n? I just tested it up to 1e8 and found the informal paper ")#link("http://vixra.org/abs/1610.0106")[#text("http://vixra.org/abs/1610.0106")]#text(" which claims to have tested it to 1e9. Are there some more publications? It’s surprising that there is not much info about this sequence. It doesn’t seem to have been studied much, but its behaviour superficially resembles 3n+1’s. Wikipedia also says nothing about it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522124")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2019")])]

#text("The 3n-1 conjecture does not hold for n=5 an n=17. You get a cycle. It probably never diverges, just like the 3n+1 conjecture.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522131")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2019")])]

#text("The probable reason why the 3n-1 conjecture is not found so much in the literature is because it is false. But it is very important, since it demonstrates that any proof of the 3n+1 conjecture use the fact that the 3n+1 function has a plus sign and not a minus sign.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522139")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2019")])]

#text("Ok, thanks. I took the 3n-1 conjecture to mean that 1, 5, and 17 were the only cycles, per the vixra paper. A similar thing happens with the 3n+1 conjecture if you allow negative n. There are several known cycles but’s an open question whether there are more.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522142")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2019")])]

#text("There is nothing stopping a 3n+1 sequence or a 3n-1 sequence from diverging to infinity. That can happen if most of the iterates in such a sequence use the function (3n+1)/2 or (3n-1)/2 instead of n/2. Even though the probability of this happening is nil, it is still possible. Because of this, I can’t see how anyone will ever prove that either sequence cannot diverge to infinity. The best one can do is do what Prof Tao did in his new paper.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522152")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2019")])]

#text("I’m saying 3n-1 has 3 known cycles, so the 3n-1 conjecture (i.e. statement whose truth value is unknown) would be that all n end up in one of those 3 cycles. The conjecture is false if some number escapes to infinity, or if some number lands in a cycle other than the known 3. Anyway it sounds like that question is still open.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522133")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2019")])]

#text("One would have to check the details carefully, but on a quick glance it would appear that the main results of my paper would also cover the ")#mi("3x-1")#text(" iteration, after inserting some minus signs in various places (most notably in the definition of the offset map). Heuristically one would expect all orbits of this iteration to be bounded (and thus eventually periodic), although the precise set of possible limiting cycles is different.")

#text("EDIT: One slightly tricky thing is that in the 3x-1 case the analogue offset map ")#mi("F_n")#text(" would only be expected to stabilise if one fixes the parity of ")#mi("n")#text(" due to a new factor of ")#mi("(-1)^n")#text(" in the map. So one may have to only work with even iterates of the analogue of the Syracuse map, rather than all iterates, in order to get around this problem. But this should only require some minor notational complications in the argument rather than necessitate any serious new difficulties.")

#text("SECOND EDIT: On further thought, the offset map for the ")#mi("3x-1")#text(" map doesn’t actually contain a ")#mi("(-1)^n")#text(" factor, so the arguments should in fact go through without difficulty (indeed, one can think of the ")#mi("3x-1")#text(" iteration as nothing more than the usual ")#mi("3x+1")#text(" iteration applied to negative integers). The previous comments would apply however for a ")#mi("-3x+1")#text(" iteration for instance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522219")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("I do not know if I bring some light, but I think that 3n + 1 is symmetric with respect to zero, that is, using negative numbers, to 3n-1, and 3n-1 with positive numbers behaves the same, it is symmetric with respect to 0, to the 3n +1 with negative numbers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fff3f4cd0a0b6cdb72dd636f43e6f513be74a0dc1d96d62a730c6d60d8865ff-8857a83a5c4ceac1b2054a03070ce442ed0df059960c946610e51b07303165cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gottfried Helms")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522539")[#strong[#text("Gottfried Helms")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2019")])]

#text("This idea of “symmetry” does not really hold. A (somehow) popular equation which must be satisfiable for cycles states ")#mi("2^S=(3+1/a_1)(3+1/a_2)...(3+1/a_N)")#text(" with ")#mi("N")#text(" odd steps and ")#mi("S")#text(" as sum of even steps. Now if you insert positive numbers for the ")#mi("a_k>1")#text(" then the rhs is between ")#mi("3^N")#text(" and ")#mi("4^N-\\delta=2^{2N}-\\delta")#text(" and if you insert negative numbers then the existence of a perfect power of 2 between ")#mi("2^N+\\delta")#text(" and ")#mi("3^N")#text(" is another question. Of course we have always latex ")#mi("N-2")#text(" possible solutions for S between ")#mi("2^N < 2^S < 2^{2N}")#text(" but it might be, that the value ")#mi("3^N")#text(" lies such that either there is no perfect power of 2 between ")#mi("2^N < 3^N")#text(" and instead all ")#mi("N-2")#text(" perfect powers lay between ")#mi("3^N < 2^{2N}")#text(" or conversely. So solutions for cycles are *not* symmetric around zero.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522507")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2019")])]

#text("So since an infinite subset of the natural numbers map to 5 under 3x-1, almost all leaves that many numbers unaccounted for. Especially when this method sets the target bound of 1!")

#text("Basically, 3x-1 gives a concrete example that this ms represents no progress whatsoever on 3x+1. Just like all of the references it cites.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed59270cc4f59cfa5061c43c07aeace0829ccbf036a013d80c8f286af16a6c20-abcad089f4cb7fbbabe4a9175477db144cbe1b440f8ef880e899f51658519376.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Жандос Мәмбетәлі")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522140")[#strong[#text("Жандос Мәмбетәлі")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2019")])]

#text("Collatz conjecture in reverse:")#linebreak()#text(" Suppose we have such a Collatz fraction:")#linebreak()#text(" ")#mi("\\frac{\\frac{2^{k_i}-1}{3} \\cdot 2^{k_{i-1}}-1}{3}_{{...}_{\\frac{\\frac{2^{k_2}-1}{3} \\cdot 2^{k_1}-1}{3}}}")#linebreak()#text(" which is equal to a natural number. Then, for each power of two ")#mi("2^{k_x}")#text(" we have many other degrees of the form ")#mi("2^{k_x+(3^x-3^{x-1})n}")#text(", ")#mi("n\\geqslant 1, n \\in N")#text(" ; any of which can replace the power of two ")#mi("2^{k_x}")#text(" and get another integer (natural) fractional solution.")#linebreak()#text(" ")#mi("k_1, k_2, ... , k_i")#text(" – Are different natural numbers.")#linebreak()#text(" Example:")#linebreak()#text(" ")#mi("k_1=\\{0, 2, 4, 6, 8, 10, ...\\}")#linebreak()#text(" ")#mi("k_2=\\{2, 8, 14, 20, 26, ...\\}")#linebreak()#text(" ")#mi("k_3=\\{2, 20, 38, 56, ...\\}")#linebreak()#text(" for: ")#mi("{\\frac{\\frac{\\frac{2^{k_3}-1}{3} \\cdot 2^{k_2}-1}{3} \\cdot 2^{k_1}-1}{3}}")#text(".")#linebreak()#text(" Depending on the ")#mi("n")#text(", we equate the result of calculating such a fraction to ")#mi("A_{n_x}")#text(", then the relations of finite differences ")#mi("A")#text(" will be:")#linebreak()#text(" ")#mi("\\frac{A_{n_x+1}-A_{n_x}}{A_{n_x}-A_{n_x-1}}=2^{3^x-3^{x-1}}")#linebreak()#text(" where ")#mi("x")#text(" this is a subscript exponent ")#mi("K")#text(" associated with ")#mi("n")#text(", (the index of the power of two of the variable part of the fraction).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522141")[#strong[#text("Terry Tao prouve presque la conjecture de Collatz - Technologik.fr")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2019")]

#text("[…] Presque toutes les orbites de Collatz atteignent des valeurs presque limitées (article de blog) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522148")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2019")])]

#text("Is it possible to extend the method for some collatz-like sequences in ")#mi("\\mathcal N^2")#text(" ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cfe444cced37a5828f3f2a80e263e6a8cc70a89a9699e072863c0064bbf9de15-442b938b26b4ff4424202921da51d91e9239510c1eddd6a6f5ed96d166e995e9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RS")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522211")[#strong[#text("RS")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("Has there been any work on quantifying “almost all”? For instance, is it known that there are c, d < 1 such that for large enough N, all but ")#mi("N^c")#text(" of integers between 1 and N have minimal element of the Collatz orbit at most ")#mi("N^d")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522227")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("This particular claim essentially follows from the first part of Proposition 1.11 of my paper (which also applies if the logarithmic distribution is replaced by the uniform distribution). It may have implicitly also appeared in the previous papers of Allouche and Korec mentioned in the paper, though I don’t have those references handy at present.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523650")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2019")])]

#text("Three up votes to one down vote.")

#text("3x-1…")

#text("Let’s keep the pun and the fun.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522218")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("Is there any probabilistic conjecture on the distribution of the lengths of orbits starting with a given distribution of the initial element of the collatz sequence ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522225")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("Yes; see for instance ")#link("https://arxiv.org/abs/0910.1944")[#text("this paper of Kontorovich and Lagarias")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522222")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("Since it is not known if the Collatz conjecure is decidable, the current situation is similar to that of the RH (if it is undecidable then it must be true!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of not necessarily")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522223")[#strong[#text("not necessarily")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2019")])]

#text("No, because boundedness of individual orbits (unlike RH counterexamples) cannot necessarily be determined by finite calculation. Collatz conjecture, whether that means “all orbits include 1” or “all orbits eventually go below 3 zillion”, could be undecidable because one particular orbit is unbounded, but there is no proof of that in the axiom system chosen as a foundation. If there were a proof that a particular finite algorithm can test any given N for having an unbounded orbit or not, then the problem becomes RH-like in that undecidable implies true (i.e., every N passes the test, so there are no counterexamples, but there is no uniform proof that all N have this property).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db518652cc3070afcdabaa00554b256190b351b0c4b9c71591e17406f7c13d2c-3aeee3abec9d9c13ede67bd756ec0d9e752e956fb03715ee421141933f4762d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of itaibn")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522286")[#strong[#text("itaibn")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2019")])]

#text("If I’m not mistaken, the proof of the prime number theorem can be thought of as first establishing that the prime numbers are on average distributed that way in the sense of logarithmic density, and then showing that the prime numbers are not correlated to any ")#mi("n^{is}")#text(" and usually Fourier analysis to establish the distribution of the prime numbers in ordinary density. Is it possible that a similar approach here will establish a result like this one but in the sense of ordinary density instead of logarithmic density? Specifically, we can seek out complex measures of the form ")#mi("f (n) n^{is}")#text(", where ")#mi("f")#text(" is continuous in the 3-adic topology, which are eigenfunctions of the dynamics. I believe these measures can be characterized similarly to the Syracuse measure in (1), but with an extra weight ")#mi("3^{-is} 2^{i (a1 + \\dots + a_n)}")#text(", modulo sign and similar errors. If all the eigenvalues for ")#mi("s \\neq 0")#text(" have norm less than one then we will expect that starting from a uniform distribution these components will become negligible and only the Syracuse distribution will remain.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522287")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2019")])]

#text("Yes, I believe that some argument along these lines (considering the joint behaviour of the Syracuse iteration in both the “3-adic” and “Archimedean” aspects, by working with a joint character ")#mi("\\chi(n) n^{it}")#text(" instead of just a 3-adic character ")#mi("\\chi(n)")#text(" in Proposition 1.17 (or equation (7.2)) of my paper, and in particular trying to estimate expressions such as ")#mi("{\\mathbb E} 2^{-it\\mathbf{a}_{[1,n]}} \\chi(2^{-\\mathbf{a}_1} + 3^1 2^{-\\mathbf{a}_{[1,2]}} + \\dots + 3^{n-1} 2^{-\\mathbf{a}_{[1,n]}})")#text(") should eventually be able to upgrade the “logarithmic density” aspect of my theorem to “natural density”, although the calculations in Section 5 will have to be replaced by a more careful computation that keeps much better track of the Archimedean behaviour of the Syracuse iteration and its potential coupling with the 3-adic behaviour. (It may potentially be that the notation and arguments become cleaner if one works on the adeles ")#mi("{\\mathbb A}")#text(" instead on various components of the adeles such as ")#mi("{\\mathbb Z}_3")#text(", ")#mi("{\\mathbb Z}_3 \\times {\\mathbb R}")#text(", or (as is done in my paper) ")#mi("{\\mathbb Z}/3^n {\\mathbb Z}")#text(", in the spirit of Tate’s thesis, particularly if one wants to generalise to other Collatz type iterations as discussed in other comments here. I also have the vague sense that the nonabelian Fourier analysis of the affine (semi-)group ")#mi("\\mathrm{Aff}({\\mathbb A})")#text(" on the adeles might also be naturally involved in all this analysis.) If one is lucky one may be able to leverage the existing purely 3-adic theory in my paper as a “black box” to handle the ")#mi("t=0")#text(" case and use some other, simpler, argument to handle the ")#mi("t \\neq 0")#text(" case, again somewhat in analogy with the prime number theorem. (The analysis in ")#link("https://arxiv.org/abs/math/0509175")[#text("this paper of Lagarias and Soundararajan")]#text(" on Benford’s law in the Collatz iteration may also be of relevance here. Related to this, I suspect that to get a sufficient amount of Archimedean equidistribution one would need something like Baker’s theorem on the Diophantine nature of ")#mi("\\log 2 / \\log 3")#text(".)")

#text("I don’t have any plans to work on this particular refinement of the results (and all my current graduate students and postdocs are busy with their own projects and/or are working in rather different areas of mathematics than the ones that are relevant here), so you (or anyone else) are certainly welcome to pursue it if you wish.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-534281")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2019")])]

#text("The distribution of odd sequence steps is given by a simple function:")

#mi("f(n) = \\begin{cases} n+ \\frac {n+1}{2} & \\text{if } n+1 \\equiv 0 \\text{ (mod } 4) \\\\ n-\\frac{n-1}{4} & \\text{if } n-1 \\equiv 0 \\text{ (mod } 8) \\\\ \\frac{n-1}{4} & \\text{if } n-1 \\equiv 0 \\text{ (mod } 2) \\end{cases}")

#text("Another way to express this is to say: Given three arithmetic operations, for every odd number n only a or b or c can be a whole odd number.")

#text("a = ((n + 1) * (3 / 2)) – 1")#linebreak()#text(" b = ((n – 1) * (3 / 4)) + 1")#linebreak()#text(" c = (n – 1) * (1 / 4)")

#text("Then you can see that the ratio must be 2:1:1 of the three possible operations.")

#text("You can triangulate the result of the congruence-based additive function or the a,b,c algorithm and the conventionally expressed Collatz function using factors of 2 and 3, referencing the a, b, c operations:")

#text("a: Input factor of 2 is replaced with an output factor of 3")#linebreak()#text(" b: Input factors of 2*2 are replaced with an output factor of 3")#linebreak()#text(" c: Input factors of 2*2 are eliminated")

#text("– Remember that the factoring is being applied to n+1 or n-1 (where n is odd).")#linebreak()#text(" – Operation c can correspond with powers of 2, by consecutive repetition.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mayor of Simpleton")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522288")[#strong[#text("mayor of Simpleton")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2019")])]

#text("In Remark 1.4 of the paper, at the end of the paragraph, is the equivalence literally with sets of log density approaching 1 (i.e., there always exists a regular enough subset whose log density exists) or the a priori weaker statement that the lim inf (of the sequence computing) log density goes to 1 as the Collatz orbit-minimum parameter is raised?")

#text("In either case there is a formulation of the main result without slow-growing functions, as “[lim sup] log-density of exceptions (Collatz orbit stays above C) goes to 0 as C increases” but it wasn’t immediately obvious which sense of lim-sup applies.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522291")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2019")])]

#text("Oh, good point. I had assumed without thinking about it too hard that every set of lim-inf log density at least ")#mi("\\alpha")#text(" had a subset whose log-density existed and was equal to ")#mi("\\alpha")#text(", which is why I formulated the remark as stated, but now that I look at it more carefully this is not the case, and one should indeed use the lim-inf formulation instead to get the actual formal equivalence (although it may be possible in this specific case to still recover the stronger claim currently stated in Remark 1.4 even if it is not logically equivalent to the main theorem). This will be corrected in the next revision of the ms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522308")[#strong[#text("Terrence Tao’s Progress on the Collatz Conjecture | An Unstructured Mess")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2019")]

#text("[…] Paper: ")#link("https://arxiv.org/abs/1909.03562")[#text("https://arxiv.org/abs/1909.03562")]#text(" Tao’s blog post about the paper: ")#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/")[#text("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/")]#text(" Wikipedia page for Collatz conjecture: ")#link("https://en.wikipedia.org/wiki/Collatz_conjecture")[#text("https://en.wikipedia.org/wiki/Collatz_conjecture")]#text(" A slightly […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f55e231c62ed35d237688a1710c7c315033127818991c4e0a5dc8219d9bb98aa-162a88d35b8a7e32add532ded8ff833aa6fe422bb1423d1b9ea1fcd353773854.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sandor Pozsik")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522471")[#strong[#text("Sandor Pozsik")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2019")])]

#text("Dear Mr. Tao,")#linebreak()#text(" There could be a way to prove conjecture:")#linebreak()#text(" 1) An impair number will always be followed by a pair.")#linebreak()#text(" 2) A pair number will either be followed by an impair and then see point 1, either by a pair number.")#linebreak()#text(" 3) No number is repeated within one series.")#linebreak()#text(" 4) If the number is a power of 2, the series will converge to 1.")#linebreak()#text(" 5) from Points 1,2 and 3 we see that unrepeated pair numbers will be generated infinitely, except if the series reaches a number which is a power of 2 (point 4).")#linebreak()#text(" 6) The probability of generating a power of 2, when generating infinite number of pair numbers is 100%, so it is 100% sure that the serie will reach a power of 2 and then converge to 1.")#linebreak()#text(" Best Regards,")#linebreak()#text(" Sandor")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522547")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2019")])]

#text("Dear Pro.Tao")#linebreak()#text(" Maths problems always everyone nerve in the world.So, today I want to tell a fun story in order to reduce stress.”Last night, I intruded into Pro.Tao’s house to steal money from a big box.Unfortunely , after I broke the box , I found no money in the box. Materials in the box such as Hodge conjecture, P vs Np , Goldbach conjecture,Navier Stokes , Riemann…..solved by Pro.Tao.”")#linebreak()#text(" A forever fan of Pro.Tao")#linebreak()#text(" Best wishes")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ridiculous Professional")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522615")[#strong[#text("Ridiculous Professional")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2019")])]

#text("Gowers has a viXra overlay journal with double the publication rate as Pi. So maybe if things don’t go well with the next revision you could consider submitting there.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a63219ff01fe9cd1974dc8cc4dab27520b8fe3645f637da4814200a473e72f5a-5c90a46f4826d28b92392008e28e26420b60359e42fa31f46c38f1c5fe8cb108.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of notyetready")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522648")[#strong[#text("notyetready")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2019")])]

#text("Do you think there might be some relationship between the 3x+1 problem and the abc conjecture ? Saying it differently, one may wonder whether both conjectures coud be a logical outcome of a single and more general statement (possibly undecidable) concerning the additive properties of numbers composed of large powers (of 2 and 3 in the case of 3x+1).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522699")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2019")])]

#text("There is indeed a relation between the 3x+1 problem and results such as Baker’s theorem which establish some separation between powers of 2 and powers of 3, and which provide key examples of where the abc conjecture is known to hold; for instance results such as Baker’s theorem have been used to rule out certain types of Collatz cycles, and to establish Benford type laws for Collatz iterations. See ")#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/")[#text("my previous blog post")]#text(" on the Collatz conjecture for further discussion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522730")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2019")])]

#text("Is the complexity of the Collatz iteration dependent on the irrationality measure of ")#mi("\\log 3 / \\log 2")#text(" ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d47a1950650319c54131f9301e4f8cabacfa3e368768f58953342435ab2d3b98-02667b6410dcb2193396b7eb60d20cbfadf8217742fb0e18f7168a5e0978e181.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522809")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2019")])]

#text("There are relationships between Pillali’s and ABC conjecture. It is quite important for Collatz’s hypothesis to know how many solutions exist for 2^(x + y)-3^y=k, for some fixed k. Similar questions are raised by the Pillali’s hypothesis which is related to ABC conjecture. We have solved so far only the case for k=1 (Catalan Conjecture). We do not know if there is a finite amount of other solutions. For example, if there were an infinite amount solutions for k=5, then there is a higher probability that then some 2^(x+y)-3^y=5 divides equation (5):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/")[#text("The Collatz conjecture, Littlewood-Offord theory, and powers of 2 and 3")]
]

#text("The solution of the ABC hypothesis and Pillali’s conjecture can supports the Collatz hypothesis. But the fact that Collatz problem contains such problems may indicate that it is much more difficult than these problems.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522846")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2019")])]

#text("I am not sure of the relationship that may exist between Pillali, ABC and Collatz. I knew the relationship between Collatz and diophantine equations, although I have not fully understood it, recently, thanks to Jeff’s advice, I am trying to understand this relationship through the paper On the “3n + 1” Problem")#linebreak()#text(" By R. E. Crandall (1978). Somehow then Pillali and ABC should be related to the diophantine equations. But apart from this, for Collatz, solutions of the form ")#mi("2^{x}-3^{y}= k")#text(".with fixed k, should not be of the form ")#mi("2^{x}-n \\times 3^{y}= k")#text(" , for almost all N, where k takes values ​​from the form ")#mi("\\displaystyle 3^{y-1} 2^{x_1} + 3^{y-2} 2^{x_2} + \\ldots + 2^{x_y}")#text(" (8) of the previous post of the professor about Collatz, where k can only be 1 when y = 1. Although we are assuming the conjecture true, we can study the cases. The value of k somehow sets the value of 3 ^ y. For y = 1, there are infinite powers of form 2 ^ 2n, which give us infinite values ​​of n that meet this condition: 1,5,21,85, … (4n + 1). different values ​​of k, for n odd, must be odd and not multiples of 3. Somehow the different orbits of Collatz, for odd n, are comparable to the factorization in prime numbers, that is, for each value of k there is a unique value 3 ^ y and a unique value of 2 ^ x, for a unique n, which satisfies equality (for n even it is almost equal with some nuance). I don’t know if through this equality, setting values ​​of k, 3 ^ y can be set and consequently set 2 ^ x, for a unique value of n. But we can also propose equality so that an orbit enters a periodic cycle, which would be of the form ")#mi("n \\times 2^{x}-n \\times 3^{y}=n \\times k")#text(". For this equality we have a certain advantage, knowing that if it is more than probable that the conjecture is true, the only possible solution to this equation must be when n = 1 and k = 1. I am far from knowing how to handle this equality, although one way of seeing it is that ")#mi("n \\times 2^{x}\\equiv n \\times k \\pmod n")#text(" and ")#mi("n \\times 2^{x}\\equiv n \\times k (mod3^{y})")#text(" . I’ve always thought that the g.c.d and the Bezout identity have something to say here, but I don’t know attack this relationship.")#linebreak()#text(" And we can even pose the orbits that escape to infinity for a fixed k, where ")#mi("y= \\infty")#text(", then we have ")#mi("n \\times 3 ^{\\infty}")#text(", would be infinite, and we would need some number that by subtracting infinity is k, or ")#mi("n=  \\frac{\\chi -y}{3 ^{\\infty}}")#text(",with infinite n in this way. Although the consistency of this approach is not very well. I don’t know if transcendence is here, because of the connection of transcendence and Collatz I still don’t understand and I have to improve it.")#linebreak()#text(" As for connections with other conjectures, based on my intuition and almost always devoid of any rigor, I see some connection with Poincare and rectangular triangles in 2-d reducible to 1 point, as I indicated in a previous comment. And even, very speculatively, I like to see the conjecture related to inflationary theory and big-bang, in the sense of how from a point a connected infinity can be created, or how this could be reduced by a single point. Thanks.Sorry for latex, I don’t do very well lately.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-555131")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2020")])]

#text("Is it possible that the Collatz conjecture can be proved from an ineffective version of the ABC conjecture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-555214")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2020")])]

#text("Well, nothing can be ruled out completely (if for no other reason than the trivial observation that any proof of the Collatz conjecture can be converted into a proof of the Collatz conjecture “from” an ineffective version of the ABC conjecture simply by introducing the latter in a gratituous fashion), but my feeling would be that the ABC conjecture would at best be useful for limiting some of the possible behaviours of Collatz cycles but would not for instance be of much use in preventing the scenario in which a single exceptional Collatz orbit goes off to infinity.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d88a999d593035d7e2b9ea8dd30059fef11fd087df25fbcc7f71fbeb082971c3-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-555262")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2020")])]

#text("Estimated professor, do you think we are in that scenario where we can affirm that the worst possible orbit cannot escape infinity?")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/")[#text("Almost all Collatz orbits attain almost bounded values")]
]

#text("With the last neurons I have left, I am trying to create a system of equations that allows us to ensure that of the infinite possible linear combinations for all")

#mi("n \\times 3^{k} + d = 2^{y}")#text(",")

#text("there are infinite correct solutions, from the fact that when reaching cycle 4 -2-1-4 can continue iterating infinitely, and the minimum solution, which first reaches 1, is the solution we are looking for.")

#mi("n\\times x + d=2^{y}")

#mi("x = 3^{k}+ r")

#mi("n\\times r + d = TCR")

#mi("n\\times r + d = TCR\\equiv d\\equiv 2^{y}(modn)")

#text("always there is a moment that")

#mi("n\\times r + d = TCR\\equiv d\\equiv 2^{y}(mod3^{k})")

#text("when the orbit reaches 1.")

#text("I have recently learned that the problem we encounter to solve a diophantine equation, that the number of unknowns is greater than the number of equations, in our case, 3 unknowns for an equation. I will try to collect all the information we know and with a last advance I will write a comment to see if we are capable of assembling a system of equations compatible with a solution.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d248e0b069727a6abd7b93c85aa9a139541562f05b147be4089f7e9cfe5ec5c-042f29722de25f7053d094ea89d23d2ac31687d1fd0ea658d5dbd056aaa155d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-559627")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2020")])]

#text("When we find a solution like")

#mi("5 \\times 3 +1 = 16")#text(" ,")

#mi("5 \\times 3^{2} +19 = 64")

#mi("5 \\times 3^{3} + 121 = 256")

#text("they are also solutions, so there must be a solution such that")

#mi("5 \\times 3+1= 16")

#mi("5 \\times 3+1-4= 16-4")

#mi("5 \\times 3 - 3 = 4 \\times (4-1)")

#mi("5-1 = 4")

#text("if this could be interpreted as a system of equations, in the form")

#mi("n \\times 3^{k} + d = 2^{y}")

#mi("n \\times 3^{k-1} - x = 2^{y-2}")

#mi("x = \\frac {d-2^{y-2}}{3}")

#text("perhaps we could establish that it is an indeterminate compatible system and that there exists a value such that")

#mi("n-d_{n}= 2^{y-2k}")

#text("I cannot finish seeing what mechanism leads us to find these solutions, either because it is a trivial aspect that does not contribute anything interesting, but I comment on it in case it might have any interest. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d248e0b069727a6abd7b93c85aa9a139541562f05b147be4089f7e9cfe5ec5c-042f29722de25f7053d094ea89d23d2ac31687d1fd0ea658d5dbd056aaa155d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-559881")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2020")])]

#text("For some known solutions of the form")

#mi("n \\times 3^{k} + d_{k} = 2^{y}")

#text("there is a solution such that")

#mi("n \\times 3^{k+1} + d_{k+1} = 2^{y+2}")

#text("where")

#mi("d_{k}  2^{y}")

#text("something like ")#mi("d_{k}")#text(" is the last value less than ")#mi("2^{x-2}")

#text("If in some way we can establish that this condition is necessary and/or sufficient for solutions to existing, perhaps there is a mechanism that allows us to establish that such a solution will always exist, perhaps avoiding the possibility of entering a non-trivial orbit.")

#mi("n \\times 3^{1} + d_{1} = 2^{x}")

#mi("n \\times 3^{2} + d_{2} = 2^{x}")

#text("…")

#mi("n \\times 3^{k} + d_{k} = 2^{y}")

#mi("n \\times 3^{k+1} + d_{k+1} = 2^{y+2}")

#mi("n \\times 3^{k+2} + d_{k+2} = 2^{y+4}")

#text("…")

#mi("d_{1} = 1")#text(" is the solution")

#mi("d_{2},d_{3},...,d_{k}  2^{y}")

#mi("d_{k+2} > 2^{y+2}")

#mi("d_{k+3} > 2^{y+4}")

#text("…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d248e0b069727a6abd7b93c85aa9a139541562f05b147be4089f7e9cfe5ec5c-042f29722de25f7053d094ea89d23d2ac31687d1fd0ea658d5dbd056aaa155d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-559887")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("*error correction")

#text("– ")#mi("d_{k}2^{y}")#text(" is")

#mi("d_{k} 2^{y}")

#text("– ")#mi("d_{2},d_{3},...d_{k}2^{y}")#text(" is")

#mi("d_{2},d_{3},...d_{k-1}< 2^{x-2}")

#mi("d_{k} 2^{y}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-570976")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2020")])]

#text("Periodic non-trivial orbits")

#text("If this orbit exists, the equation of the form")

#mi("n\\times 3^{k}+ n\\times d= n\\times 2^{y}")

#text("must be fulfilled, that is, there cannot be any periodic orbit that does not meet this condition, right?")

#text("The conjecture gives us some additional information")

#text("– ")#mi("3^{k}")#text(" is smaller than ")#mi("2^{y}")

#text("-Can we establish that ")#mi("2^{y}")#text(" must also be less than ")#mi("3^{k+1}")#text("?")#linebreak()#text(" If so, between ")#mi("3^{k}")#text(" and ")#mi("3^{k+1}")#text(" are there 1 or 2 possible values ​​for ")#mi("2^{y}")#text(" ?")

#text("-If there is a solution we would have k odd numbers that meet the equation")

#text("-Regarding the possible values ​​that ")#mi("n\\times d")#text(" can take, these cannot be multiples of 3, which is")#linebreak()#text(" why multiples of 3 cannot enter a loop")

#text("-They must also have the form of (8)")

#mi("\\displaystyle 3^{k-1} 2^{a_1} + 3^{k-2} 2^{a_2} + \\ldots + 2^{a_k}")

#text(", and be bounded")#linebreak()#text(" between a minimum value, which responds to the form")

#mi("3^{k}-2^{k} =3^{k-1}+3^{k-2}2^{1}+...+2^{k-1} = (n\\times d)_{min}")

#text(", and a maximum value,")

#mi("3^{k-1}+3^{k-2}2^{a1}+...+2^{y-1} = (n\\times d)_{max}")#text(", for each value of ")#mi("3^{k}")

#text("-It seems that of the possible values ​​that ")#mi("n\\times d")#text(" could take, these would be 1 + 2 + .. + k values. From these we would need that k values, at least, are multiples of d")

#text("-According to some observed orbits, of the possible values ​​between ")#mi("(n\\times d)_{min}")#text(" and ")#mi("(n\\times d)_{max}")#text(" for a given ")#mi("3^{k}")#text(", many values ​​are prime and the rest co-prime, that is, there are no k multiple values ​​of d, it even seems that none ,or that is, all values ​​are co-prime")

#text("– In fact, if the conjecture is true, in that there is no non-trivial orbit, we could establish that for all ")#mi("3^{k}")#text(", of the 1 + 2 + .. k possible values ​​of the form (8), between the minimun and the maximun possible value, there are no k values multiples ​​of d ,or even, regardless of the value of d, there are no k values ​​that are not coprime , or even, all possible values ​​are coprime.")

#text("Do you think it is plausible to try to demonstrate this fact?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80965863af6390d27b148395ae6e0ba28a48a473fdf6a0e040aeb38108d83104-73080da18bf6783d68481c9fedb1d0d6939b1a85c0a146ef9c1f85c1716a63cc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-603756")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2020")])]

#text("Hello everyone. I would like to recover this argument from the previous comments.")#linebreak()#text(" If Collatz’s conjecture is true it has this form")

#mi("n3^{k}+d_{3^{k}}=2^{y}")#text(" (1)")

#text("Where n is an odd number, k is the number of odd steps and y is the number of even steps.")

#text("As it reaches a power of 2, it reaches 1, and it enters the trivial periodic orbit. So we can keep iterating and we find that")

#mi("n3^{k+1}+d_{3^{k+1}}=2^{y+2}")#text(", where ")#mi("d_{3^{k+1}}=3d_{3^{k}}+2^{y}")

#mi("n3^{k+2}+d_{3^{k+2}}=2^{y+4}")

#text("…")

#text("This process can be done in reverse,")

#mi("n3^{k}+d_{3^{k+1}}=3\\times 2^{y-2}+2^{y-2}")

#mi("n3^{k}+d_{3^{k+1}}-2^{y-2}=3\\times 2^{y-2}")

#mi("n3^{k-1}+d_{3^{k-1}}= 2^{y-2}")

#text("…")

#text("in addition to being a uniform process and we arrive at")

#mi("n-d_{n}=2^{y-2k}")#text(" (2)")

#text("That is, if there is a solution (1), there is (2)")#linebreak()#text(" Could we ask ourselves the opposite? That is, if there is a solution (2), is there a solution (1)?")

#text("Note: This process seems to be followed without problems when y-2k is positive, but when it is negative it seems to get stuck at the value 1,")#mi("2^{0}")#text(" and 2,")#mi("2^{1}")#text(", and it does not seem to be able to advance to negative powers of 2 with negative exponent, and it alternates values from 1(or 2) to -1(or -2) until reaching n-d = + \\- 1(or 2).")#linebreak()#text(" This I have been able to observe in the orbit of 27,for example, where we arrive at ")#mi("27\\times 3 ^ 6-19682 = 1")#text(" , and it does not seem that we can arrive at ")#tao-math("27-d = - 2 ^ {\\left|70-(2\\times 41)\\right|}", block: false)#text(". At this point I would appreciate your opinions.")

#text("Ok, if there is a solution we have")

#mi("n-d_{n}=2^{y-2k}")#text(" (2)")

#text("and we know that")

#mi("3n+1= \\chi")#text(" , so")

#mi("\\lambda = 3d_{n}+1")#text(" ,")

#text("and when y-2k is positive, for some known orbits, it is a power of 2, so perhaps it could always be a power of 2, or in the case of negative y-2k it couod be + \\-1(or 2), then")

#mi("\\chi = 3\\times 2^{y-2k}+\\lambda")

#text("Of course, if this argument is correct, with this information, is it possible that there is some trick to know if there is a solution?")

#text("Thank you for your answers.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f50d5006f5e134f5f5cacf82b92f88eb85ccc47800116a52746261ec811652b5-c7ec6e1f9871c7aba7e86bc677f32ee83ab845fcb142e53fef4150d3128d00df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Frost")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522649")[#strong[#text("Robert Frost")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2019")])]

#text("Would there seem to be any hope of sharpening your results by restricting to only the 5-rough numbers? Eliminating the leaves of the graph by considering ")#mi("+2^{\\nu_2(x)}\\cdot3^{\\nu_3(x)}")#text(" which commutes with multiplication by both 2 and 3 gives an even superior form of the problem IMO than the Syracuse function, it being surjective.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Frost jr.")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522652")[#strong[#text("Robert Frost jr.")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2019")])]

#text("“And tall and in a port of air”")

#text("Almost anything is doable if we drop the chains of rigor.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f50d5006f5e134f5f5cacf82b92f88eb85ccc47800116a52746261ec811652b5-c7ec6e1f9871c7aba7e86bc677f32ee83ab845fcb142e53fef4150d3128d00df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Frost")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522675")[#strong[#text("Robert Frost")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2019")])]

#text("rigour follows insight")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522700")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2019")])]

#text("A single iteration of the Syracuse map already places one in the setting of 5-rough numbers (numbers not divisible by either 2 or 3), so the effect of restricting to this setting on the analysis of the paper (which is studying a significantly larger number of iterates) is fairly minimal.")

#text("Once one restricts to 5-rough numbers, the Syracuse function is not only surjective, but it has an approximately invariant measure ")#mi("\\nu")#text(", which one can view as the main source of the results of this paper. This measure can be defined as")

#mi("\\displaystyle \\nu(\\{N\\}) := \\frac{3^{n} \\mathbb{P}( \\mathbf{Syrac}({\\mathbb Z}/3^n {\\mathbb Z}) = N \\text{ mod } 3^n )}{N}")

#text("where ")#mi("n")#text(" is a natural number comparable to a small multiple of ")#mi("\\log N")#text(" (the stabilisation result in Proposition 1.14 my paper ensures that the exact choice of ")#mi("n")#text(" is not terribly important). This is an infinite measure supported on the 5-rough numbers, and Proposition 1.14 combined with Lemma 1.12 basically tell one that ")#mi("\\nu")#text(" is approximately invariant: ")#mi("\\nu(\\mathrm{Syr}^{-1}(E)) \\approx \\nu(E)")#text(" for any set ")#mi("E")#text(" of 5-rough numbers. This measure implicitly makes an appearance at the end of Section 5 of the paper.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f50d5006f5e134f5f5cacf82b92f88eb85ccc47800116a52746261ec811652b5-c7ec6e1f9871c7aba7e86bc677f32ee83ab845fcb142e53fef4150d3128d00df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Frost")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522715")[#strong[#text("Robert Frost")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2019")])]

#text("Thank-you, this really helps add some insight for me as I had found myself getting sucked towards Baire/Borel sets, invariant measures and sigma-algebras in studying this problem so it’s pleasing to find connections to this ball-park already made.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f50d5006f5e134f5f5cacf82b92f88eb85ccc47800116a52746261ec811652b5-c7ec6e1f9871c7aba7e86bc677f32ee83ab845fcb142e53fef4150d3128d00df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Frost")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522650")[#strong[#text("Robert Frost")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2019")])]

#text("On a related note… can you send 2Z-1 to a subset of an interval of the real line in such a way that some superfunction of the Collatz function on the same segment has orbits only the same periodicity as the function in Z? Via Sharkovskii’s theorem this would prove the nonexistence of trivial loops by contradicting known results that orbits of period 2 do not exist.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522701")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2019")])]

#text("Given how oscillatory Collatz maps and their iterates are, I am sure that any reasonable continuous extension of these maps to the real line will inevitably create any number of new fixed points from the intermediate value theorem. The dynamics of the Collatz map involve not only the Archimedean completion ")#mi("{\\mathbb R}")#text(" of the rationals, but also the 2-adic and 3-adic completions, so it is unlikely that a purely real-based approach is going to capture enough of the complexity of the Collatz dynamics to resolve the problem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f50d5006f5e134f5f5cacf82b92f88eb85ccc47800116a52746261ec811652b5-c7ec6e1f9871c7aba7e86bc677f32ee83ab845fcb142e53fef4150d3128d00df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Frost")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522713")[#strong[#text("Robert Frost")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2019")])]

#text("It’s fitting that you mentioned both 2-adic and 3-adic because I had already restrained myself from the following comment… I have hope that a completion of the 5-rough positive integers using a composite of the 2 and 3 adic metrics might yet lead to an algebraic solution dropping out. ")#mi("(3x+\\prod_p p^{v_p(x)})/2=2x")#text(" after all. Then quotient out the powers of 2 and 3 from the multiplicative monoid. The conjecture effectively states that ")#mi("0")#text(" may only be approached through ")#mi("2^m3^n")#text(" so it seems natural to send ")#mi("2^m3^n")#text(" to zero as ")#mi("n,m")#text(" to infinity. On an algebraic note, it’s perhaps worth pointing out that the orders of cycles over the 5-rough integers (both positive and negative) give the dihedral group D7. On another note, more related to your previous post and the connection to transcendental numbers there is a “lowest” (in reverse) 5-rough trajectory which is not 1,1,1… namely 1,5,13,17,11,7,37,49,… which is almost certainly of some use. Its parity sequence I imagine is not in Z_2 since it obviously never terminates although I would be curious whether some root of unity or other such object might be appended to Z_2 in order to contain it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Frost jr.")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522734")[#strong[#text("Robert Frost jr.")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2019")])]

#text("What do you mean when you say")

#text("“… which is almost certainly of use…”")

#text("Thanks.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f50d5006f5e134f5f5cacf82b92f88eb85ccc47800116a52746261ec811652b5-c7ec6e1f9871c7aba7e86bc677f32ee83ab845fcb142e53fef4150d3128d00df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Frost")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522747")[#strong[#text("Robert Frost")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2019")])]

#text("@Robert Frost Jr. I’ll overlook your name and assume for now you’re not being disingenuous. I mean this: Let ")#mi("T(x)")#text(" be the isometry on ")#mi("\\Bbb Z_2")#text(" given by recording a ")#mi("1")#text(" for every odd number and a zero for every even, in a Collatz sequence orbited by the ")#mi("(3x+1)/2")#text(" version of the graph. Then there is a “lowest trajectory in ")#mi("\\mathbb{Z}^+")#text("” given by ")#mi("1,1,1...")#text(" having ")#mi("T(x)=\\overline{01}_2=-\\frac13")#text(". Extending to infinite trajectories (heading backwards) requires ")#mi("T:\\to")#text(" something at least as big as ")#mi("\\Bbb Q_2")#text(" in which case there are at least two further “lowest” trajectories in ")#mi("\\mathbb{Z}^+")#text(": The trajectory ")#mi("T(x)=\\overline{0001}_2=-\\frac1{15}")#text(" is the “general” lowest possible trajectory (i.e. if we do not assume every sequence converges to ")#mi("1")#text(". But if all sequences *do* converge to $1$ then this bound sharpens to ")#mi("\\underline x=T(S)")#text(" where ")#mi("S")#text(" is the sequence ")#mi("T(\\ldots1,1,5,13,17,11,7,37,49,\\ldots)=\\overline{01}.00010010111000101\\ldots_2>-0.2590")#text(". Then my claim is that the precise nature of this number ")#mi("\\underline x")#text(" is almost certainly a useful connection between the Collatz graph and transcendental number theory. There’s also a connection between this number and a (not well-founded) set of ordinals which is invariant under truncation/subset but I haven’t got that quite straight in my mind yet.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Frost jr.")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522758")[#strong[#text("Robert Frost jr.")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2019")])]

#text("Can you define the form of the subset of odd numbers which, by your mapping, are identified with sequences of the form 1,1,1,…")#linebreak()#text(" of arbitrary finite length?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f50d5006f5e134f5f5cacf82b92f88eb85ccc47800116a52746261ec811652b5-c7ec6e1f9871c7aba7e86bc677f32ee83ab845fcb142e53fef4150d3128d00df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Frost")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522954")[#strong[#text("Robert Frost")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("If ")#mi("T(x)")#text(" is the isometry on ")#mi("\\Bbb Z_2")#text(" defined above and you ask for which sequence ")#mi("x")#text(" gives ")#mi("T(x)=\\overline1_2")#text(", only a constant sequence of 2-adic numbers has this form – it is in fact ")#mi("-1,-1,\\ldots")#text(" and since ")#mi("T")#text(" is an isometry it’s the only element in ")#mi("\\Bbb Z")#text(" with this property.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522727")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2019")])]

#text("Estimated Professor: About”how oscillatory Collatz maps and their iterates are”.The classical interpretation of the conjecture creates these chaotic behaviors, but is it possible to interpret the conjecture by avoiding these behaviors? Moreover, are they useful for solving the conjecture for all N? For example, following the conjecture via the Bohm and Sontacchi, maintaining the numerator without dividing by the powers of 2 and adding the numbers of the form (8) of the previous post. This segment grows continuously until finding a power of 2, and if does not fall from n in a ")#mi("n \\ times 2 ^ x")#text(", does it seem to have infinite probabilities of finding a power of 2 versus? probabilities of not finding it and escaping to infinity, which would imply an infinite number of counterexamples to the conjecture.")#linebreak()#text(" Another example could be to study the equation of the form ")#mi("n \\times 3 ^ {k} + n \\times y = n \\times 2 ^ x")#text(" if n enters a periodic orbit, with ")#mi("n \\times y")#text(" of the form (8), where ")#mi("n \\times 2 ^ x \\equiv n \\times and \\ pmod n \\text{ and } (mod 3 ^ k)")#text(", where the result is, securely, only possible with n = 1.")#linebreak()#text(" Or even restrict the conjecture to the unit circle, forming a right triangle where the hypotenuse would be the 3n + 1 values, the cosine the 3 ^ k * n values ​​and the difference between the two values. While I don’t know how to attack this option, it seems possible, at least, to study it.")#linebreak()#text(" Or even the representation of the function in the Cartesian axes is simple, although it cannot tell us anything. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522741")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2019")])]

#text("I agree. And to add, any affirmation of 3x+1 implies no solutions to (7.3) per the constraints given in Crandall’s 1978 paper.")

#text("And affirmation of a finite solution set to (7.3) is exactly the finite cycles Conjecture.")

#text("It is massively difficult, and if you watch the literature you will see number theorists are progressively developing techniques to settle such questions.")

#text("Now stick in hypothetical divergent sequences…")

#text("Trying to skate around real progress is futile. And any perceived insights are delusions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522945")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("Dear Jeff. I am still studying Crandall’s 1978 paper. I do not quite understand it and I do not quite understand you, but I seem to intuit something. The hypothetical existence of orbits that seem to escape to infinity is deduced from the existence of orbits of infinite steps. These orbits would produce infinite counterexamples to the conjecture, and it seems strange not to have found at least one. Then there are the orbits that are trapped in a periodic cycle, which involve a finite number of counterexamples. These orbits, in the sense that Collatz’s algorithm only stops when it reaches 1, has infinite steps, then they are infinite periodic. Is it possible that these two types of orbits are really the same? It has been misunderstood that there are orbits that have infinite steps, periodical orbits, with the fact that they escape to infinity?.")#linebreak()#text(" Regarding the diophantine equation of the form")

#mi("2 ^ x-3 ^ k = y")

#text(", it seems that their solutions give us the possible periodic orbits for some n and some y. But it seems that it is somehow decontextualized, and it should be of the form")

#mi("n \\times 2^{x}-n \\times 3^{k}= n \\times y")

#text(", although I don’t know if it’s really better that way. If the only solution is the known for n = 1, y = 1, k = 1, x = 2, then the conjecture is true. In my previous comment I tried to analyze how to attack this equality, both for orbits that enter periodic orbit, and for those that escape to infinity, but if they are the same, it would be enough to demonstrate only one of the options.")#linebreak()#text(" If for almost all n it is true that")

#mi("2^{x}-n\\times 3^{k}= y")

#text(", and for a periodic orbit, it is necessary that")

#mi("n \\times 2^{x}-n\\times 3^{k}= n \\times y")

#text(", comparatively it seems that the distance separating the powers of 2 and 3, for almost every n, is less than that necessary to reach a periodic orbit. Some interesting questions in these equalities are that both")#linebreak()#text(" ")#mi("y")#text(" and ")#mi("n \\times y")#text(" must be of the form")#linebreak()#text(" ")#mi("\\displaystyle 3^{k-1} 2^{a_1} + 3^{k-2} 2^{a_2} + \\ldots + 2^{a_k}")#linebreak()#text(" (8). The value of k is fixed for the value of (8).")

#text("For there to be a number that belongs to a periodic cycle we would have to study")

#mi("n \\times 2^{x}\\equiv n \\times y \\pmod n")#linebreak()#text(" ")#mi("n \\times 2^{x}\\equiv n \\times y (mod3^{k})")

#text("and so that n escape to infinity we would have")

#mi("n=\\frac{\\chi }{3^{\\infty }}")

#text("where ")#mi("\\chi = n\\times 2^{x}-n\\times y,\\: or\\: 2^{x}-y,\\: or\\: a \\: number")

#text(", where the only possible solution seems to be 0 or 1.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522950")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("Alberto,")

#text("Ibanez make great electric guitars. Any relation?")

#text("You have a lot of ideas. One really great one is characterization of a lower bound for differences of powers of 3 and nearest powers of 2.")

#text("My gosh, we cannot even prove the bound is exponential!")

#text("As for this paper, you’ll notice earlier questions about ‘closing the gap’ between all and almost all.")

#text("Well, that would entail completely removing all probabilistic arguments from it. How much of the paper would be left?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522952")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("Baker’s theorem provides an exponential lower bound for the difference between powers of 3 and powers of 2. See Corollary 4 of ")#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/")[#text("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/")]#text(" Unsurprisingly, these sorts of results end up being used in some of the Collatz literature, for instance in ruling out certain types of cycles.")

#text("As I mentioned in an earlier comment, there is only a very slim chance for directly transferring an “almost all” result in this setting to an “all” result, but the chance is not entirely non-zero, particularly if one can somehow combine the “almost all” result with some complementary non-trivial results on the Collatz problem. Here is one unlikely but theoretically possible scenario: an almost all result is proven that shows that all but at most ")#mi("O(x^\\theta)")#text(" starting points in ")#mi("[1,x]")#text(" end up at a value bounded by a constant ")#mi("C")#text(". This by itself does not settle the problem: but suppose one also shows that any counterexample to Collatz has a pre-image tree that grows faster than ")#mi("x^{\\theta^{\\prime}}")#text(" for some ")#mi("\\theta^{\\prime} > \\theta")#text(" (for instance the Krasikov-Lagarias result mentioned in the paper is of this type with ")#mi("\\theta^{\\prime} = 0.84")#text("). Combining the two claims, we conclude that all counterexamples to Collatz must attain a value less than ")#mi("C")#text(", otherwise the second claim would contradict the first. If this value of ")#mi("C")#text(" was small enough, one could then hope to resolve the full conjecture by a numerical calculation verifying the Collatz conjecture up to ")#mi("C")#text(". (Note that this last step would also allow one to distinguish the ")#mi("3x+1")#text(" problem from the ")#mi("3x-1")#text(" problem, for which the first two steps might still work, with only the numerical verification step differing between the two iterations.)")

#text("Personally I view the above scenario as being remote (among other things, as I discussed in ")#link("https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/")[#text("my previous post")]#text(", pulling this off must require at some point either using or proving some version of Baker’s theorem.) However, as I also pointed out in another comment, even in the absence of direct transferability, getting a better understanding of the relative difficulty of various “almost all” problems can give some heuristic insight into the ")#emph[#text("relative")]#text(" difficulty of various “all” problems, which can lead to predictions as to the right proof strategy even before this strategy can actually be executed. For instance, Conway’s FRACTRAN iterations show that there are some Collatz-like problems for which the analogous conjecture is undecidable. This is often viewed as an obstruction to proving the Collatz conjecture. On the other hand, the result in my paper relies heavily on the existence of an invariant adelic measure for the iteration with negative drift, and it does not appear that the undecidable FRACTRAN iterations have such a measure. So this raises some interesting, and potentially tractable questions: (a) do the results in my paper work for any Collatz-like iteration with an invariant adelic measure with negative drift? and (b) are there any examples of Collatz-like iterations which have an invariant adelic measure with negative drift, but which contain unbounded orbits? If the answer to (a) turns out to be “Yes” and (b) turns out to be “We can’t find any”, then this suggests that the natural general conjecture for Collatz-type iterations should be “Every Collatz-type iteration with an invariant adelic measure with negative drift should have all orbits bounded”. This abstracts away the role of special numbers such as 2 and 3 (and also avoids having to distinguish for instance between the 3x+1 iteration and the 3x-1 iteration), explains the distinction between the 3x+1 and 5x+1 iteration (the latter having positive drift) or the FRACTRAN iteration (for which the invariant adelic measure is either non-existent or has positive drift), and may give clues as to what the right way to proceed further is (for instance, such a conjecture has a flavour of a “local to global principle”, suggesting that ideas in the penumbra of other such local-to-global principles (e.g., the Bombieri-Lang conjecture) may be relevant). Of course this is all still rather speculative, but these are typical of the way other partial results in other mathematical problems have led to further insights and progress.")

#text("Finally, it is worth pointing out that while proximity to well known problems often serves as motivation for mathematical research, these problems are by no means the only objective, and one can often get unexpected other advances in mathematics even if one only obtains partial progress towards the initial motivating goal. For instance, a large fraction of algebraic number theory was developed in hopes of resolving Fermat’s last theorem; it did not succeed at this goal, and FLT was eventually established by rather different means, but the theory was still immensely valuable nonetheless. Sieve theory was invented to try to solve conjectures such as the twin prime conjecture; it has thus far been unable to achieve this (roughly speaking, it only controls “almost primes” rather than “primes”, without the addition of highly nontrivial extra input), but nonetheless has become a basic part of the analytic number theory toolkit. More recently, the work of Einseidler, Katok, and Lindenstrauss establishing a strong “almost all” version of the Littlewood conjecture is not expected to lead to a full resolution of that conjecture, but nonetheless has generated a lot of advances in our understanding of entropy methods in homogeneous dynamics. (See also ")#link("https://terrytao.wordpress.com/career-advice/on-the-importance-of-partial-progress/")[#text("this post of mine")]#text(" on the particularly valuable nature of partial progress in mathematics, which is nearly unique amongst all disciplines in this respect.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522957")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("@Tao,")

#text("Corollary 4 looks like observations I circulated about a decade ago. When did you add them to that post?")

#text("Anyway, I’ll be as precise as possible here regarding the adjective “exponential”.")

#text("Are you saying there exists some legitimate, fixed, positive constant beta such that 3 to the power of beta is strictly less than the right-hand side of the inequality in Corollary 4?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522959")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("Addendum,")

#text("Oh yeah, we must scale beta by multiplying by x in order to get the form of a legitimate exponential bound.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522964")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("@Tao,")

#text("Okay, so does your Corollary 4 give an ‘almost’ exponential lower bound?")

#text("I don’t understand.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a8de5e657fc101702b7b8285747ad6fc25a2dfbe960263701725dbb99b72760-c9c35a2432d01b3d7ef381e03f566399ce714a083d496f75b6c725d7eaa64ea8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Buzzman")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522969")[#strong[#text("Buzzman")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("@Terry,")

#text("I think the powers of 3 and powers of 2 arising from the expansion of the ")#mi("\\textnormal{Syr}")#text(" function for ")#mi("n")#text(" iterations lead to an undecidable expression since the inverse of ")#mi("\\textnormal{Syr}(N)")#text(", by one step of iteration, leads to one-to-many mapping from an odd ")#mi("N \\not \\equiv 0\\pmod{3}")#text(" to an infinite set of odd iterates. Unless I misunderstood your language, I do not get how one can establish a bound in such a case. I believe that the intricate patterns in Collatz dynamics can be simplified, without loss of information, by bypassing the even operations and examining instead the odd trajectories in reverse through the inverse of the ")#mi("\\textnormal{Syr}")#text(" function, as earlier noted by Lagarias. It appears to me that there has been less effort in this regard. Since there always exists an integer ")#mi("N")#text(" where any ")#mi("n")#text(" compositions of ")#mi("\\textnormal{Col}_{2}(N)")#text(" generate a parity vector consisting entirely of ")#mi("1s")#text(" even as ")#mi("n \\to \\infty")#text(", then any resulting bound ")#mi("O(N^{\\theta})")#text(" will always yield ")#mi("\\theta < 1")#text(". At any rate, your partial result is already tremendous by novelty of approach.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523016")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2019")])]

#text("@Terry,")

#text("Was looking at the 2003 paper of Krasikov and Lagarias in Acta Arithmetica. The remark at the top of page 254 raised a red flag with me.")

#text("Did they misunderstand what form an exponential lower bound takes?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523106")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2019")])]

#text("The link to the partial progress post is missing. It seems way off base and actually, a bit contrived, given this paper.")

#text("But this paper is not partial progress anyway.")

#text("It says on Wikipedia that the paper of Krasikov and Lagarias gives rigorous bounds. I’m thinking not.")

#text("What is especially interesting is that it is elementary. Hmm.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523329")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2019")])]

#text("Dear Professor: Constate C seems to be relevant in the conjecture. Surely its nature is obvious, but I do not quite understand it. Is it big? Is it small? Is there any way to explain its nature in an accessible way? I have read your previous post many times but I did not understand the relationship with Baker, although I think I begin to understand it. Observing the nature of the periodic orbits of 5n + 1 and 3n-1, I have observed that the value k, the number of iterations of the cycle or the power of 3, as you can see, coincides with the cardinality of the set n odd that are counterexamples to the conjecture for a value y (or q), the distance between a power of 2 and 3.the higher is k, the greater the number of counterexamples Is that relevant? and for orbits that escape to infinity? I still don’t see that infinite odd numbers can have an unlimited orbit, or what form they have when heuristically it is almost impossible for even a small number of counterexamples to be given? Finally, I cannot find information about “an invariant adelic measure”, is possible to talk about it? thank you very much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523415")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2019")])]

#text("Alberto,")

#text("One thing to notice is that Crandall’s (7.3) exists, in a philosophical sense, without the 3x+1 map. We can write it down and ask about the existence of solutions without consideration of the iterations of the map.")

#text("But the reason there are so many papers on this problem is because the iterations gives us something to grab onto.")

#text("The probability type arguments ignore an infinite subset of the iterations, at best.")

#text("Now we have earlier comments about a proof strategy built upon this draft paper suggesting we could ‘abstract’ away special numbers such as 2 and 3.")

#text("Well, that would amount to erasing (7.3) all together. Besides, who really cares if more solutions exist to it.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f50d5006f5e134f5f5cacf82b92f88eb85ccc47800116a52746261ec811652b5-c7ec6e1f9871c7aba7e86bc677f32ee83ab845fcb142e53fef4150d3128d00df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Frost")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522955")[#strong[#text("Robert Frost")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("On the oscillatory nature of iterates of collatz maps as a barrier to the application of Sharkovskii’s theorem, it should be borne in mind that one is free to multiply any ")#mi("2\\Bbb N-1\\to2\\Bbb N-1")#text(" Collatz sequence by any arbitrary sequence drawn from ")#mi("2^m3^n")#text(" without affecting the integrity of the sequence, with ")#mi("n,m")#text(" from sets at least as large ")#mi("\\Bbb Z")#text(" but possibly larger. I imagine Bakers theorem will inform the degree to which such a process can remove the oscillatory properties of sequences but that part is beyind me.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522696")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2019")])]

#text("Dear Pro.Tao,")#linebreak()#text(" May I have a suggestion?")#linebreak()#text(" Why do not you have a new polymath to solve Collatz conjecture?")#linebreak()#text(" Only 10% you have a complete proof.")#linebreak()#text(" Or there are other many reasons:")#linebreak()#text(" 1)Very little experts on Collatz conjecture in the world")#linebreak()#text(" 2) Your breakthrough is very new and suddenly that makes other mathematicians can not catch up you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e249de595ce697e2b44b690b176cb4f50aec9a7efdd5796848a388057a6802bb-84e60c261b50ed69aaedfcbdfbe152f2ef895338021ce0c7bae321712ba7606a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Theo")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522731")[#strong[#text("Theo")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2019")])]

#text("Let’s assume we forget about the even numbers.")#linebreak()#text(" Let’s also assume we generate the Collatz sequence starting from 1 by using a given recursive function f(x).")#linebreak()#text(" We forget about the even numbers.")#linebreak()#text(" f(1) would give us 1 – 5 – 21 – 85 – 341 – 1365 – etc..")#linebreak()#text(" The results of f(1) we would give us the terms of the following functions")#linebreak()#text(" f(5) we would us 3 – 13 -53 -213 – 853 – etc..")#linebreak()#text(" The results of f(5) we would give us the terms of the following functions")#linebreak()#text(" f(13) we would us 17 – 69 – 277 -1109 – 4437 – etc..")#linebreak()#text(" f(53) we would us 35 – 141 – 565 -2261 – 9045 – etc..")#linebreak()#text(" If all functions were based on the results of the previous functions like f(13) which is based on f(5) which is based on f(1) would we be able to say that if any odd numbers belong to that function then it must come from f(1) through a finite number of iterations?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e687778c6d81f660d24112cb9ec3a0c8e61d578c1cc2e7a4da85bc06aeb5cafa-edd2a30afdbb74301f14b8c152604122a56e8d94f56249bcf57620bc58249533.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Cooper")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-675922")[#strong[#text("Chris Cooper")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2023")])]

#text("I have a question about this comment. I am interested in understanding why people gave it a thumbs down.")

#text("Thank You.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael M. Ross")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-676037")[#strong[#text("Michael M. Ross")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2023")])]

#text("For the odd numbers, there is a bijection 8n+5 → 2n−1 using the operation (n−1)1/4:")

#text("5→1, 13→3, 21→5, 29→7, 37→9, 45→11, 53→13, 61→15, 69→17 . . .")

#text("It’s a one-to-one mapping. The cardinality is the same, and every odd counting number is the output of ((8n+5)−1)1/4.")

#text("This is not immediately obvious in even-odd sequences since the result is absent from the next sequence. Each time you multiply 4n+1 by 3n+1, (((n∗4)+1)3)+1, you add two factors of 2 – and remove the original n.")

#text("For example,")

#text("501 → 1504 →752 → 376 → 188 → 94 → 47")#linebreak()#text(" 125 → 376 → 188 → 94 → 47")#linebreak()#text(" 31→ 94 → 47")

#text("It does not imply convergence to 1 because the inputs are a subset of N. It does suggest that an infinitely divergent sequence is logically unsupportable.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522823")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2019")])]

#text("The simple Collatz iteration with its complicated orbits may be viewed as a kind of “chaotic” dynamics (“locally unstable” yet “globally almost bounded”) on the integers. This seems closely related to chaotic dynamics, so it may be interesting to find a “natural” definition for its analogous Mandelbrot set.")#linebreak()#text(" The Mandelbrot set is defined as the set of complex numbers ")#mi("c")#text(" for which the function ")#mi("f_c(z) = z^2 + c")#text(" does not diverge when iterated from ")#mi("z = 0")#text(", so it seems that a natural analogous discrete “Collatz-Mandelbrot set” for ")#mi("\\mathbb Z^2")#text(" may be defined as the set of ")#mi("(a, b) \\in \\mathbb Z^2")#text(" for which the function ")#mi("g_{a, b}(x)")#text(" does not diverge when iterated from ")#mi("x=0")#text(". Where ")#mi("g_{a, b}(x)")#text(" is a “Collatz-like” function defined over the integers by ")#mi("g_{a, b}(x) = a x +b")#text(" for odd integers ")#mi("x")#text(" and ")#mi("g_{a, b}(x) = x /2")#text(" for even integers ")#mi("x")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522842")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2019")])]

#text("Since ")#mi("g_{a, b}(0) = 0")#text(", it is more interesting to start with ")#mi("x = 1")#text(" (or any other odd integer.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/55c6d9bac27d74b144484e56afbd01f787f4af932ae38636bff0bb24b96386a6-1b381ef5d57766c36f06f355ff4120cfb21f832974fb0b149edb60a17d58745b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522841")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2019")])]

#text("elder brother,nice to meet you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a8de5e657fc101702b7b8285747ad6fc25a2dfbe960263701725dbb99b72760-c9c35a2432d01b3d7ef381e03f566399ce714a083d496f75b6c725d7eaa64ea8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Buzzman")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522938")[#strong[#text("Buzzman")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("The way I see it, establishing asymptotic bounds of the form ")#mi("N^{\\theta}")#text(" for ")#mi("N \\in \\mathbb{N}")#text(" satisfying ")#mi("\\textnormal{Col}_{min} (N)=1")#text(" always leads to ")#mi("\\theta<1")#text(" since there always exist ")#mi("N")#text(" that monotonically increase for any ")#mi("n \\in \\mathbb{N}")#text(" compositions of ")#mi("\\textnormal{Col}_{2} (N)")#text(". If one takes every even integer input ")#mi("N")#text(" as convergent since ")#mi("\\textnormal{Col}_{2}(N) < N")#text(", then it suffices to prove the Collatz conjecture only for odd ")#mi("N")#text(". However, any odd ")#mi("N \\equiv 7\\pmod{8}")#text(" of the form ")#mi("N =2^{k}b-1")#text(" for ")#mi("b \\in \\mathbb{N}")#text(", where obviously ")#mi("N")#text(" is Mersenne if $k=1$, can be made monotonically increasing for increasing ")#mi("k")#text(". Hence, one expects that the exceptions to any derived asymptotic bounds are odd ")#mi("N")#text(" of such forms, as initial inputs or as iterates in the trajectory of any odd ")#mi("N \\equiv 1, 3, 5\\pmod{8}")#text(" or both. Alternatively, one can invert the ")#mi("\\textnormal{Syr}")#text(" function to map odd ")#mi("N \\not \\equiv 0\\pmod{3}")#text(" to odd ")#mi("N")#text(". The resulting iteration of the inverse ")#mi("\\textnormal{Syr}")#text(" function constructs an arborescence graph ")#mi("G=(V,E)")#text(", with vertex and edge sets ")#mi("V")#text(" and ")#mi("E")#text(", respectively. Then one can alternatively prove the Collatz conjecture by showing that every vertex in ")#mi("V")#text(" is unique and that ")#mi("V")#text(" exactly covers the set of odd natural numbers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a8de5e657fc101702b7b8285747ad6fc25a2dfbe960263701725dbb99b72760-c9c35a2432d01b3d7ef381e03f566399ce714a083d496f75b6c725d7eaa64ea8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Buzzman")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522958")[#strong[#text("Buzzman")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("Where it appears above, it should read: ")#mi("\\textnormal{Col}_{2}(N)>N")#text(" (for even input ")#mi("N")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522977")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("Dear Dr.Tao,")#linebreak()#text(" When I was childhood, I always admire the best heroes in the science such as Newton, Einstein , Euler. Now , I also admire them. But , after reseaching the best heroes in the world nearly 30 years, I have found that you have many special things which above heroes never have. I can not express here , because after writting out here, many people against me. It’s the best way that a long time will prove all. Many people in the world will understand , maybe more 50 years later, it’s that time maybe you die.That is a problem.")#linebreak()#text(" And today I want to discuss other probem.I am not surprised after you claim of proving Collatz conjecture in September 2019.I acknowledge very well that you solved Collatz 2-3 years ago not 2019. And I also know that you have solved many big conjectures , but you do not till post them.Why? You are humble , humanity, not selfish. You want share profits to other mathematicians. I wonder if you do not reveal Collatz this year, other mathematicians succeed in proving Collatz, that’s time many big prizes belong to them not you. That is a thing I only admire and like you , not other mathematicians. Like a race, your speed is the fastest, but you control to limit your speed to yield other men. You accept you are behind them.")#linebreak()#text(" And now who else find my idea right, please up vote")#linebreak()#text(" Thanks all you very much.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a8de5e657fc101702b7b8285747ad6fc25a2dfbe960263701725dbb99b72760-c9c35a2432d01b3d7ef381e03f566399ce714a083d496f75b6c725d7eaa64ea8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Buzzman")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522960")[#strong[#text("Buzzman")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("Sorry, please ignore the suggested correction. The initial statement stands as is. Obviously, I’m a stupid who can’t understand my nonsense.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d47a1950650319c54131f9301e4f8cabacfa3e368768f58953342435ab2d3b98-02667b6410dcb2193396b7eb60d20cbfadf8217742fb0e18f7168a5e0978e181.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-522978")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("I am an independent researcher, an amateur (but I’ve been dealing with this problem for 10 years). I created a symmetric-key cryptographic system based on Collatz functions and Collatz-like functions. I’d like to meet someone who could review my algorithm, possibly publish it with me (because my own description will probably have many formal shortcomings). Where to find specialists for this problem who know something about cryptography at the same time?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523050")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2019")])]

#text("Here’s a recent proof attempt")

#link("http://www.sciencepublishinggroup.com/journal/paperinfo?journalid=141&doi=10.11648/j.pamj.20180705.12")[#text("http://www.sciencepublishinggroup.com/journal/paperinfo?journalid=141&doi=10.11648/j.pamj.20180705.12")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523062")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2019")])]

#text("lol")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523089")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2019")])]

#text("that’s a scam pay per publishing journal so anything published there can be safely disregarded")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523099")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2019")])]

#text("The finite cycles Conjecture will someday yield. And I think amateurs will have just as much credit as the professionals at that time.")

#text("Ramanujan was largely self taught. Now we have the internet. So it won’t be too much longer before the next Ramanujan surfaces and comes to our rescue.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523473")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2019")])]

#text("@jeff keeping infinite periodic orbits aside, orbits that escape to infinity, unbounded or infinite orbits are the same, right? So was Crandall the first to postulate the existence of these orbits? Are there other researchers who postulated the existence of these unlimited orbits?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523478")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2019")])]

#text("Yes, unbounded sequences are not cycles. Collatz himself seems to be the first one to think of them with this map. But the concept of unbounded sequences probably goes back thousands of years.")

#text("And they may not be relevant at all for anything of practical use when comes to 3x+1. In practice we cannot iterate the map ‘forever’. So just knowing whether additional solutions exist to (7.3) ought to be enough for us.")

#text("The finitist view has strength here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523479")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2019")])]

#text("To add, an infinite solution set to (7.3) defines cycles of arbitrary finite length. So the idea of an unbounded sequence is silly from an ultra-finitist view point.")

#text("It’s almost like a nonsensical artifact of iterating the map.")

#text("When I was in school my teacher taught me that math operations are instantaneous. If this were true then it would not take any time at all for hypothetical unbounded 3x+1 sequence to reach the undefined state of infinity. So the question is instantaneously nonsensical!")

#text("I’d love to hear what Doron has to say about such sequences.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523480")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2019")])]

#text("Here’s one for you,")

#text("Can you prove the number of cycles of any given length is finite?")

#text("If so, it still leaves open the possibility of an infinite solution set.")

#text("Maddening isn’t it?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523512")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2019")])]

#text("Not really, Jeff. Infinity is our friend. For an odd n, in Syr-map, in an unbounded orbit, n would not be a single number, as a counterexample to the conjecture, there would be infinite counterexample numbers of the conjecture, which is exactly on the opposite side to the heuristic of the previous post “Heuristically applying the Borel-Cantelli lemma, we thus expect that there are only a finite number of counterexamples to the weak Collatz conjecture (and inserting a bound such as ")#mi("{k \\ geq 105 {,} 000}")#text(", one, in fact, expects it to be extremely likely that there are no counterexamples at all)”. Even more so considering that the value of k is the value of the number of counterexamples. Despite not knowing exactly the transcendentality and its relation to Collatz, for an infinite orbit, we would have an infinite collection of diophantine equations, where the infinites n of the infinite orbit are no solution, then these numbers, very speculatively, should be transcendental, and I believe that no natural number is transcendental.")#linebreak()#text(" Then somehow the events should lead us to the fact that if an orbit is infinite, it is infinite periodic, and that all orbits are bounded, either up to 1 or up to n, to subsequently attack the impossibility of periodic loops in 3n + 1. Very speculatively, of course. Thank you.")#linebreak()#text(" Another issue to keep in mind is that I think we have screwed up this comment thread. My sincerest apologies to Professor Tao, and all my respect for his work.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523532")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2019")])]

#text("Alberto, I agree with the concept of a potential infinity. I disagree with the concept of actual infinity.")

#text("That is why hypothetical divergent 3x+1 sequences are fascinating to me. They cross from being defined to undefined. Are they both? Is that a contradiction in itself?")

#text("And is the question and the search for an answer a complete waste of precious time?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8b5e61b5395dd8d2f0077c4f0f83eb9225c163ce79aa8ab021f856c1d197af4-69fbe8371d58c34442b57b4fffe4c1fb0f9f4c53c200a34ac9ebad651e87ea10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523980")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2019")])]

#text("Let’s evaluate in the opposite direction. If you come from the infinite, even if there are no unbounded orbits, there would be an infinite amount of regressive operations of the algorithm and we could never know if it would reach 1. On the other hand, show that there are no unbounded orbits in addition to 4, 2, 1 I think That would be more feasible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-524586")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2019")])]

#text("Hi Gaston. If I understood you, indeed, for the Collatz conjecture two possibilities remain open:")#linebreak()#text(" 1. The possibility of orbits that escape to infinity,(for every Collatz-like maps) that is, not bounded. Current techniques seem unable to attack this problem. From my point of view, which I think is the same as @ jeff, the correct question would be, are there unbounded orbits? Exists? Starting from a natural number, is it possible that the orbit reaches infinity? I don’t know if this debate is a closed or open debate, I suppose it is open, and it certainly seems very interesting. For me, in my modest opinion, conceptually they cannot exist and every orbit would be bounded, either from n to 1 or from n to n.")

#text("2. The possibility of periodic orbits. In other Collatz type maps, you can observe the nature and functioning of these orbits, even with very small numbers. For the Collatz map we know that even a very large number does not give any periodic orbit of the form")

#mi("n\\times 2^{x}-n\\times 3^{k}= n\\times y")

#text("where the only known solution is the trivial one, ")#mi("x= 2,k= 1,n= 1,y= 1")#text(",")#linebreak()#text(" With this advantage I propose, although I don’t know if in a correct way, this linear congruence system,")

#mi("n \\times 2^{x }\\equiv n \\times y \\pmod n")#linebreak()#text(" ")#mi("n \\times 2^{x} \\equiv n \\times y (mod\\: 3^{k})")

#text("or,")

#mi("n \\chi \\equiv ny \\pmod n")#linebreak()#text(" ")#mi("n \\chi \\equiv ny (mod\\: 3^{k})")#text(",")

#text("where ")#mi("\\chi= power\\, of\\, 2")#text(",")

#text("I repeat that I don’t know if it is raised correctly, but if we can use GCD and Bezout’s identity to know that the only possible solution is the trivial one, then it is not possible that there is a non-trivial periodic orbit. Can there be a solution other than the trivial one?.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-524606")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2019")])]

#text("Yes gentlemen. As you say, the question of the existence of a divergent sequence really belongs to the philosophers, not the mathematicians. Papers like this one assume actual infinity exists and the authors believe they can somehow rigorously argue the non existence of divergent sequences. Well they certainly do not exist if we reject actual infinity to begin with.")

#text("That leaves open the possibility of more solutions to Crandall’s (7.3). We can find practical use cases for the answer to this question.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-524633")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2019")])]

#text("PhD is a Doctor of Philosophy. To me actual infinity should be reserved for masters degrees and higher. All mention and ridiculous use of it should be footnotes in all undergraduate textbooks aside from ones for philosophy degrees. Then kids can learn about and solve problems that actually have a positive impact on society. How’s that for a political statement. Well maybe a social statement. :-).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8b5e61b5395dd8d2f0077c4f0f83eb9225c163ce79aa8ab021f856c1d197af4-69fbe8371d58c34442b57b4fffe4c1fb0f9f4c53c200a34ac9ebad651e87ea10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-525084")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2019")])]

#text("If the results of the conjecture were strictly n * 2 ^ x we ​​would have an immediate inductive test, but there is a slight distortion at the beginning of the natural numbers. Although an inductive demonstration proving that odd numbers are grouped into sub sets where 2 ^ x is one of the variables for the polynomial is feasible, it is not simple.")

#text("On the other hand, the orbits will grow more the greater the number that is taken because in a sieve where all the numbers must pass through the first ordered subset of odd ones evaluated at 2 ^ x you must add the steps that the first odd number requires to reach 1. That is to say you can have a larger number than the one you take from the first subset but if you have to go through a previous number it will have fewer steps. So the number of steps for a number to reach 1 can be countless if you take an uncountable number.")

#text("But periodically infinite orbits would not exist if we take into account that the algorithm sequences are ambiguous, that is, they increase from an odd number and then descend and may then rise and fall continuously. But if the density of the increments is 0 and the density of the decreases is 1 then it cannot be returned to a previous orbit in addition to 4, 2, 1.")

#text("The calculation falls into a contradiction. Even if the density of the increments was 0 it would never reach 0 because the numbers are infinite and at some point the descent would necessarily begin taking a value greater than 0 than later if it would descend to 1. If somewhere in the descent the orbit increases again it would require a calculation with a rational result and this calculation must be greater than 1 but since the density of the descent is 1 you cannot calculate a return to a previous orbit unless it is the original orbit 4, 2, 1.")

#text("How is it demonstrated? The path is the calculation of the algorithm between the subsets of the odd numbers.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523117")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2019")])]

#text("There is potentially substantial value with this paper if it included just how awfully it handles 3x-1. It shows just how untrustworthy ‘heuristic’ intuition is. Well, provided there isn’t some other gaps of rigor.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523338")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2019")])]

#text("Seeing as how stuff like this paper get published on a regular basis instead of real partial progress, you have my permission to acknowledge my helpful comments. I cannot speak for the multitude of others who have helped for free.")

#text("Best of luck!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523218")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2019")])]

#text("Good grief, another one")

#link("https://www.hindawi.com/journals/jps/2019/6814378/")[#text("https://www.hindawi.com/journals/jps/2019/6814378/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523219")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2019")])]

#text("Here’s a revision to one, but I cannot find a date.")

#link("https://pdfs.semanticscholar.org/f3c0/13d8bb641513da2a0cb84936b9ef9fc6ad46.pdf")[#text("Click to access 13d8bb641513da2a0cb84936b9ef9fc6ad46.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523643")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2019")])]

#text("Doron opinion 111")

#link("http://sites.math.rutgers.edu/~zeilberg/Opinion111.html")[#text("http://sites.math.rutgers.edu/~zeilberg/Opinion111.html")]

#text("To add to it,")

#text("Almost All also means Almost None.")

#text("No rigor here. Did someone really get awarded a fields medal for NOT proving anything at all?")

#text("Sounds like the award has been miserably devalued.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-527729")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2019")])]

#text("Yeah we don’t need proofs. Who reads and understands them anyway?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-528216")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2019")])]

#link("https://sites.math.rutgers.edu/~zeilberg/Opinion174.html")[#text("https://sites.math.rutgers.edu/~zeilberg/Opinion174.html")]

#text("Algorithms are Proofs. For example,")

#text("1. Assume Math operations are instantaneous.")#linebreak()#text(" 2. How can we prove 3 times 15 plus 1 equals 46?")

#text("3. Answer, we use an algorithm, the most basic one: order of operations!")

#text("4. Philosophically the answer is 46 with or without us humans. And it just is.")

#text("5, notice, however, the algorithm cannot be fully evaluated until us humans give the definite form of 15.")

#text("6. 3x+1 is great, but x doesn’t tell us enough. Further, 3x+1 exists in other number systems, such as binary.")

#text("7. Finally, if 3 times 15 plus 1 equals 46 only exists because we humans exist, then divergent sequences do not exist, obviously.")

#text("Proof already inherited the earth. It’s foundation is our very survival, which depends on trust. Trust but verify.")

#link("https://en.m.wikipedia.org/wiki/Ishango_bone")[#text("https://en.m.wikipedia.org/wiki/Ishango_bone")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-530972")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2019")])]

#text("Math is the art of making sense out of nonsense.")

#text("“Order” of operations implies time to calculate is bounded “above” zero, even for some arbitrary object such as the universe itself. This deduction in turn implies divergent sequences do not exist as complete objects.")

#text("What really “matters” is whether the number of solutions to Crandall’s 7.3 is finite and what that number is, or that there are as many as we should ever need.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-531320")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2019")])]

#text("Our perception of “time” is synonymous with our perception of “order”. You cannot have one without the other. And it doesn’t seem delusional to me. Hypothetical Divergent sequences are dumb and insidious mind traps. In my humble opinion:-).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-531900")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2019")])]

#text("Hi, @jeff.You know that I agree with you about hypothetical divergent sequences. And surely many more people will agree with you, but somehow we have to shape this idea, either from the axiom of the infinite, with some logical argument, or prove it mathematically. So I hope we are encouraged to make a collaborative effort for this interesting partial result.")#linebreak()#text(" On the other hand, I would like to say that the recent events about eigenvectors and eigenvalues encourage me to continue thinking about Collatz, in some apparently short and simple aspect or detail that has gone unnoticed, or even, why not, that in the depths of Arxiv the answer has already been lost. Thank you.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523644")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2019")])]

#text("Not my field but if we say the natural numbers are defined as a complete set")

#link("https://en.m.wikipedia.org/wiki/Axiom_of_infinity")[#text("https://en.m.wikipedia.org/wiki/Axiom_of_infinity")]

#text("Then divergent sequences have form as complete objects, assuming math operations are instantaneous.")

#text("If we toss the axiom of infinity, then we can prove by contradiction that divergent sequences do not exist. But that goes for lots of sequences.")

#text("The great thing here is that we could still have ‘potentially’ infinite solutions to Crandall’s (7.3) without the axiom of infinity!")

#text("Any qualified mathematicians ever publish on this topic?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523647")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2019")])]

#text("To me, the axiom of infinity does not define infinity per say. But one could say it almost defines infinity.")

#text("Has anyone ever assessed the purely number theoretical results which cannot be proven without the axiom of infinity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00267ca2ea4bd8e500693681c8a01f0010d44656a84460672c00f30fd8222a4a-cce910411333a2ec627ecb02f98ea3c69bd4adaf70d011d684b8104b2c09d590.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto Ibañez")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523681")[#strong[#text("Alberto Ibañez")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2019")])]

#text("@jeff What do you think of my idea about the transcendentality of the infinite numbers (counter-examples) belonging to an unbounded orbit? If they are not a solution to infinite diophantine equations, perhaps they could be a solution to another diophantine equation, but then they would belong to a bounded orbit.")#linebreak()#text(" About unbounded or infinite orbits and some untold variants of Conway, Professor Tao commented in his previous post “… that the examples of undecidable recursions of Conway’s type are (as far as I am aware) examples that tend to have an output larger than the input “,” it doesn’t seem like there is enough time to do any undecidably complicated mathematics in the interim. Of course, this is not a rigorous proof of anything. “But for unbounded orbits, taking into account the infinite iterations, not only iteration after iteration, if it seems that it could fit into being undecidable, hence the difficulty and the absence of appropriate techniques to solve it. If arithmetically, algebraically, topologically, geometrically, … were undecidable, then, perhaps, it could only be decidable under some kind of logical axiom")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523691")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2019")])]

#text("Alberto, pi is transcendental, which just means it is not a solution of a nonzero polynomial equation with integer coefficients.")

#text("Who cares? So maybe it is a solution to some polynomial with at least one coefficient of the summands equal to, say, 2/3.")

#text("What a weird fetish. And good for nothing of practical use.")

#text("Anyway, a divergent sequence starts from a finite, meaning defined, positive integer. And since math operations are instantaneous and we admit the axiom of infinity, the sequence itself ‘almost’ has form. But there is no last element, and no repeated elements, so there is no form…")

#text("With no form, which is what Terry proposes by abstracting away special numbers like 2 and 3, anything goes. So yes, I suppose infinite iteration of the 3x+1 map could give a transcendental output.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523701")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2019")])]

#text("To add, almost all real numbers are transcendental. But almost none of them form!")

#text("Ha! Seriously, this is modern mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523707")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2019")])]

#text("Again this is why the hypothetical divergent sequence is fascinating to me. The 3x+1 problem has a little of everything in it. And the iterations almost give it life.")

#text("What’s weirder yet, is Big Bang theorists are seemingly ignorant of the fact that their mathematical models of our universe use the axiom of infinity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03be4751a6433182fef53502c9f1679f263471645a2c4a5bad893a16c9dcd8a4-f2a4c3e84d56a817d3cef5a6766c6d8b9430e686a40dfd5aef0efd06e4d1aa7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523751")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2019")])]

#text("In our minds we iterate the 3x+1 map a finite number of steps and then conclude that the process may hypothetically never EQUAL one. We do it with a single number and we do it symbolically with x. Recall x is a member of a set, and thusly ‘represents’ a single number. But x is not as ‘well defined’ as say the number 1.")

#text("So it really doesn’t matter whether the set of natural numbers is complete, in other words, that actual infinity exists. Potential infinity allows us to give form to as many numbers as we should need, where memory space and time are the only limitations.")

#text("To me if a divergent sequence were to exist, who cares? Besides where exactly would it exist?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8b5e61b5395dd8d2f0077c4f0f83eb9225c163ce79aa8ab021f856c1d197af4-69fbe8371d58c34442b57b4fffe4c1fb0f9f4c53c200a34ac9ebad651e87ea10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523981")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2019")])]

#text("So the first step would be to demonstrate that divergent orbits are finite and being finite would necessarily involve a convergent orbit. So far this would serve to demonstrate that the convergent orbit does not involve another divergent orbit instead of ending in 1 I do not see a clear path.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523975")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2019")])]

#text("Let ")#mi("S")#text(" be the set of positive integers which have finite Collatz orbits.")#linebreak()#text(" Let ")#mi("f(n)")#text(" denote the length of the Collatz orbit corresponding to any integer ")#mi("n \\in S")#text(". Is it possible (by these methods) to give an EXPLICIT bound for ")#mi("f(n)")#text(" for almost any ")#mi("n \\in S")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8b5e61b5395dd8d2f0077c4f0f83eb9225c163ce79aa8ab021f856c1d197af4-69fbe8371d58c34442b57b4fffe4c1fb0f9f4c53c200a34ac9ebad651e87ea10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-523984")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2019")])]

#text("Separating them into ordered subsets yes, but only for the number of steps from an odd number to another odd number using 2 variables. For the number of steps up to 1 I think it involves many more variables.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of notyetready")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-524090")[#strong[#text("notyetready")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2019")])]

#text("Heuristically, it is conjectured that the total stopping time ")#mi("f(n) < \\log n")#text(" for all sufficiently large ")#mi("n")#text(" and ")#mi("C \\approx 42")#text(", provided that the an odd ")#mi("x")#text(" is mapped to ")#mi("(3x+1)/2")#text(" in a single step. Off course, no explicit upper bound can be proved up to now, at least for a positive density of the integers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8b5e61b5395dd8d2f0077c4f0f83eb9225c163ce79aa8ab021f856c1d197af4-69fbe8371d58c34442b57b4fffe4c1fb0f9f4c53c200a34ac9ebad651e87ea10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-524251")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2019")])]

#text("Heuristically according to who?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of notyetready")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-524290")[#strong[#text("notyetready")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2019")])]

#text("See this paper of Lagarias and Weiss, dealing with stochastic models:")#linebreak()#text(" ")#link("https://www.jstor.org/stable/2959662")[#text("https://www.jstor.org/stable/2959662")]

#text("See also ")#link("https://projecteuclid.org/euclid.facm/1484794814")[#text("https://projecteuclid.org/euclid.facm/1484794814")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8b5e61b5395dd8d2f0077c4f0f83eb9225c163ce79aa8ab021f856c1d197af4-69fbe8371d58c34442b57b4fffe4c1fb0f9f4c53c200a34ac9ebad651e87ea10.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gastón Fernando Murillo Plúas")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-524366")[#strong[#text("Gastón Fernando Murillo Plúas")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2019")])]

#text("I read it. I find no sense in decreasing one iteration for each time an odd number is calculated. The amount of iterations has nothing to do with the initial value with which it begins to iterate. But let’s take an example of the method used, this is taking (3x + 1) / 2 as a step.")

#text("I can take the 1,628,896,171,349 that would be found at 14 iterations of the next odd number calculated, that is 298,259,797 that would be found at 14 iterations of the next one that would be 54,613 that would be found at 15 iterations of 5 totaling 43 iterations.")

#text("This is taking high potencies. Now let’s take low powers. From 8,097 to 5, I would have 43 iterations always calculating the next odd number with low powers, which is from 2 ^ 1 to 2 ^ 4 maximum.")#linebreak()#text(" But what if I take 43 iterations directly through 5? Then I would have to take the number 14,660,155,037,013 which is much greater than 1,628,896,171,349.")

#text("Of course it will be greater, logically that you will always have a greater number when you use a greater power at a value that you calculate twice with powers in half and worse with the difficulty of a 3x + 1 algorithm where you cannot count on 1 in 3 odd values ​​to continue. The rest of logarithmic calculations on peaks of iterations is constant and inductive. But that does not mean that there cannot be an unbounded or infinitely divergent orbit, even if the latter is false.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/697ac94abb8083baf9ed34856083884452a2b262659a4dc9b4b1981193d1fe72-6fe3b54f02afd218c3ffc350ea28a0713a77d48447733252887966e562dcae4b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of osobliwy_nick")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-524464")[#strong[#text("osobliwy_nick")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2019")])]

#text("To determine if there are divergent sequences, we must realize a fact that there are numbers – “engines”, that can accelerate a given string to infinity. And there are very few of them. These numbers are:")

#text("2^n*j-1")#linebreak()#text(" 2^n*j-5, 2^n*j-7, 2^n*j-10")#linebreak()#text(" 2^n*j-17, 2^n*j-25, 2^n*j-37, 2^n*j-55, 2^n*j-82, 2^n*j-41, 2^n*j-61, 2^n*j-91, 2^n*j-136, 2^n*j-68, 2^n*j-34")

#text("The numbers of this character always generate a number greater than themselves after n steps in the collatz sequence. Any other numbers of the form 2^n*j-k will not satisfy this relationship. Each 2^n*j-k number gives a number smaller than themself after n steps. Therefore the divergent sequence must regularly reach some number of characters:")

#text("2^n*j-1")#linebreak()#text(" 2^n*j-5, 2^n*j-7, 2^n*j-10")#linebreak()#text(" 2^n*j-17, 2^n*j-25, 2^n*j-37, 2^n*j-55, 2^n*j-82, 2^n*j-41, 2^n*j-61, 2^n*j-91, 2^n*j-136, 2^n*j-68, 2^n*j-34")

#text("Is it possible? I don’t know, but if we answer this question, we will solve the problem of divergent sequences.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/comment-page-1/#comment-524504")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2019")])]

#text("Dear Pro.Tao,")#linebreak()#text(" After I” drank” beer “Collatz”, I felt the smell was very delicious. I want to drink beer “Twin” now. Hurry up! Sir. I am very thristy now.")#linebreak()#text(" Always forward to Sir,")#linebreak()#text(" Best of luck!")
]
