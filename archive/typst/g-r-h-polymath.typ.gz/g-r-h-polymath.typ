// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/
// Converted to Typst by tao2typ: "2026-11-26T17:09:41.364622+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "G.R.H. Polymath", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("G.R.H. Polymath")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/")[#text("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-26 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")]#link("https://sites.math.duke.edu/~as1813/")[#emph[#text("Anurag Sahay")]]#emph[#text(", ")#link("https://williamsawin.com/")[#text("Will Sawin")]#text(", and ")#link("https://personal.math.ubc.ca/~lior/")[#text("Lior Silberman")]#text(" – T.]")]

#text("Last Friday Levent Alpöge announced a Lean certicate containing a proof of the Generalized Riemann hypothesis. Since then there has been a flurry of activity in validating the certificate, and toward extracting a human-understnable proof and simplifying the Lean certificate itself.")

#text("It seems that this naturally suggests a Polymath-style project with several interrelated goals. These will naturally split into many")#linebreak()#text("sub-projects since the proof appears to touch on a range of mathematical fields within and without number theory.")

#list(
[#text("Bringing together the different efforts around the world under one roof, so that we can share our progress instead of duplicating effort.")],
[#text("Obtaining a human-readable and understandable proof of RH and GRH.")],
[#text("Understanding and clarifying any related literature.")],
[#text("Exploring further the mathematical advances embedded in the computer proof, and looking toward more general versions of the argument.")]
)

#text("We hope that enough results be obtained to justify publishing one or more review or research articles (which, traditionally, would be published under a pseudonym), but it is premature to discuss any details at this early stage of the process.")

#text("If you wish to contribute, please join the public forum ")#link("https://rh-polymath.zulipchat.com/")[#text("https://rh-polymath.zulipchat.com")]#text(". This will be public, with all discussions preserved and viewable without logging in.")

#heading(level: 1)[#text("Comments (32)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bcf76f63440f7d79f4d6a36dd9618b4808d330395daf5d19dcbec4f77b09c78-49c4881b95c0d221d329660a593af13b6c9d9adf71763763ef5974b85918a77d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jmdpark")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700067")[#strong[#text("jmdpark")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("Interested in seeing visually how things are inter-connected.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700070")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("There are several such diagrams; most on the Lean project Zulip.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sophie")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700073")[#strong[#text("Sophie")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("This is actually exciting! I’ve been vacillating between leaving maths and just doing some maths to regain composure, and now I think maybe a new way of ‘mathing’ is just starting to emerge. Hm …")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/385706eb4b20841b7b9fad56fcc3e9a3ca9f5f141869248024126da086d2dda8-c90ace576b3f40213e183d6737cde6f6fc2130abf5312f97937aa92f3357bcd1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kęstutis")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700097")[#strong[#text("Kęstutis")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("What’s discouraging me from doing mathematics is cultural, not technological. I am baffled why institutions like Harvard and essentially every school seem eager to leave their students out to dry rushing to present and “digest” AI results, I was dismayed to see the rushed Navier Stokes presentations “we used AI to read this for us quickly I don’t really know anything about this” why the rush then why couldn’t the time have been taken to understand first then present? It’s a rat race to the bottom, I cannot imagine being in Levant Alpöge’s position and wanting to put out something you could not at all explain in a lecture or talk, is it that exciting to check a box on do list? I actually care about the structure")

#text("Both alleged strategies inspired me to furiously take some notes from Donaldson-Kronheimer and Elements de Geometrie Algebrique and I felt a lot of clarity doing so.")

#text("The antics of the AI firms is only such a massive issue because of how totally suicidal the publish or perish culture is, and this is not a new problem academia has stubbornly been like a long while, so much relevant subject matter including academic pressure driving people to committ suicide is covered here ")#link("https://github.com/Lapin0t/grothendieck-cern")[#text("https://github.com/Lapin0t/grothendieck-cern")]#text(" focusing on that human toll is really what we should do as we are already discussing much this mode of knowledge production hyper focused on the esoteric frontier isn’t very productive either.")

#text("Claude and OpenAI are flagship products of the Maven Project, the images of what happened in the spring of 2024 in the USA look like they are from the late 1960s it is uncanny and worrisome that we appear to have learned nothing. I cannot stay silent anymore that it’s exactly the same beast taking away career opportunities here that has suppressed my silence of speech. I am not surprised but still baffled people would sign ")#link("https://sites.google.com/view/statement-by-scientists-gaza")[#text("https://sites.google.com/view/statement-by-scientists-gaza")]#text(" and turn around and publish papers using the software of “frictionless occupation” and domestic mass surveillance…")

#text("I am torn, I want to learn this stuff because I think it’s innately beautiful (“there is no God and Dirac is his prophet”), but I am aware this spiritual depravity I see in the institutions is exactly why Grothendieck abandoned EGA.")

#text("It’s worth noting Alpöge seems to have admitted the obvious now that he’s been intentionally trying to undermine academic publishing. I’m sure his reasons for that overlap with my sentiment, that he seems to have sold his soul to the devil to get his wish however… ")#link("https://webusers.imj-prg.fr/~leila.schneps/grothendieckcircle/Spirituality/Spirituality29.pdf")[#text("*insert that mark twain quote about truth and fiction here*")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70d68edaf1b08f310886b89f27f77459c80d00e7e66f95d1d949724f6aed20f4-169737cd43f66f0dc8e17d4cc5f25a93edc6616f77e278f9a1f0943afd7ac9ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Dietz")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700110")[#strong[#text("Paul Dietz")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("Do uou think it would be responsible for these schools to insulate their students from the use of AI?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700089")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#link("https://nasqret.github.io/riemann-rev/atlas/")[#text("There’s some really cool work being done already")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700090")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#link("https://proofsandreasons.io/rh-graph.html")[#text("And this.")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700091")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#link("https://nasqret.github.io/riemann-proof-atlas/")[#text("Also this.")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c44df296f4245adf3d3caeb19f2749a1d210cafa2769aff6f0ec6bd2d21c4341-3c12c69ecb80d93a22eea9bf7410efc77094096e0a2354c6e071b51ead8d9bbe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex P")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700072")[#strong[#text("Alex P")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2026")])]

#text("I’ve been waiting for this announcement. I have seen far too many fragmented attempts to abbreviate, recreate, restate the results without any public attempts at digestion.")

#text("I know that mathematicians are learning along the way as they adapt to this new world, but the lack of coordination has been concerning.")

#text("Polymath style is likely the best way forward for these large AI Lean releases moving forward, at the very least until AI also gets good at summarizing its own results.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700077")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("I saw that the Harder-Narasimhan filtration was mentioned, which I find surprising. Is it obvious why this is relevant?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b7774b1c41da99b2088436416e145332628b7bd3e049b58eb9a42415a40b357-e00dbf3c39895dd0286f2064a076ca738eabd685693124327f66616e271257ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of polonaiso")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700102")[#strong[#text("polonaiso")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("One possible way to understand the role of the Harder–Narasimhan filtration is through Bost’s Arakelov slope method. This is closely related to how evaluation maps arise in effective Diophantine approximation, particularly in the work of Calegari–Dimitrov–Tang.")

#text("There is a short note developing this perspective, which might be helpful:")

#link("https://hexagonmath.org/2611.00833v1")[#text("https://hexagonmath.org/2611.00833v1")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700079")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("Joined. Thank you, this is a great idea.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57e7cbcff57466bec8bd836ad19663c2c7e702ea735f30ce356991db8eba080a-38a827ea3eada8a287f13cfddb08b5a01bac83b84c10127d2ed5f3341dbe204a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hypatiaa")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700080")[#strong[#text("hypatiaa")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("I can get behind this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d45398e9d3bd8454f0461b0fedcc93ba533bc4d656c0dc52771f156071188fbc-482e715e67977c5e7eea200b82b98026c4fde33ce29800458f4a83bda4c40a10.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Bagshaw")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700081")[#strong[#text("Christian Bagshaw")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("Interested to see how digestible it really is.")

#text("After the big dump in October, David Harvey released a note a few weeks later about the integer multiplication result, and he seemed to only just be grasping the details, despite being (perhaps) the leading expert in the area.")

#text("I am wondering at what point AI will just start doing things that are beyond our ability to comprehend…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aed46e984095671f79f6e46c2f808bb8f4af752471c8d8f404e9ace8ee4a842e-ad1a570a49e7647f58f20af1172af74924ef42fae60c65b18cb0411060150869.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Kodsi")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700093")[#strong[#text("Daniel Kodsi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("Work on compressing the Lean proof itself is being done here: ")#link("https://riemann.verifytask.cn")[#text("https://riemann.verifytask.cn")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700094")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("Hopefully this polymath project can get the Millennium Prize for the Riemann hypothesis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e298cea6e02a8e98c885fb09987f78f8a5612c67400faaec48b682e77f30560-f4b22319bba546dd3ea1a446809dc4e9f35f0a411eda5cfe8cf060e8aefb43cc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cesar Esparza")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700098")[#strong[#text("Cesar Esparza")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("Perhaps the time has come to update our standard of what constitutes a “solved problem” to that of a “solved and humanly understood problem.”")

#text("The distinction between obtaining a mathematical result and understanding its underlying mechanisms is not entirely new. The history of mathematics and physics already offers important precedents.")

#text("The development of general relativity, particularly the interaction between Einstein and Hilbert, illustrates the distinction between arriving at mathematical equations and developing the conceptual framework that gives them physical meaning.")

#text("Similarly, Hamilton’s Ricci flow provided the fundamental machinery for approaching the Poincaré conjecture, but it took Perelman’s extraordinary mathematical insight to understand and overcome the obstacles that prevented this machinery from yielding a complete proof.")

#text("Artificial intelligence now makes this distinction more explicit and potentially more consequential than ever before.")

#text("A formally verified proof may settle a conjecture in the logical sense while leaving it open in the epistemological sense. Establishing that something is true and understanding why it is true are two distinct intellectual achievements.")

#text("Perhaps our system of mathematical prizes, academic recognition, and scientific attribution should evolve accordingly. Those who transform machine-generated proofs into human mathematical understanding, uncover their fundamental ideas, and develop new theories from them should be recognized not merely as expositors, but as contributors to the resolution of the problem itself.")

#text("From this perspective, the GRH Polymath project should not be regarded merely as a post-proof effort, but as an essential stage in the full resolution of the problem.")

#text("The frontier of formally established mathematical truths is no longer necessarily the frontier of human mathematical understanding.")

#text("Our standards of mathematical progress should reflect this distinction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700099")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("The status of certain mathematical conjectures need to be revised as well in light of this. For example the four colour theorem or the Kepler conjecture, since to this day nobody understands those computer generated proofs of said conjectures.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700100")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("Within two years more people will understand the proof of the generalized Riemann hypothesis than will understand the proofs of the four color theorem or the classification of finite simple groups.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700128")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2026")])]

#text("Time to stop speaking about “the proof” of the generalized Riemann hypothesis. There are now multiple proofs of the generalized Riemann hypothesis circulating around. People will understand Sernau’s proof perfectly well in the next few years. Nobody will understand Alpoge’s proof, nor will anybody care about Alpoge’s proof because it’s just incomprehensible slop.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700104")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("He gave the lean certificate, not merely “announced” it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700119")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("The current Lean certificate being used by the polymath project is not Alpoge’s proof. It’s Luke Sernau’s proof, which only has 300,000 lines instead of 17 million lines. Sernau’s proof also uses different mathematics to prove the GRH from Alpoge’s proof.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a792c9e347f9bf439908f298d9e46f4517e158949efc2fd535f286a9489522d0-df73d96fdb06b6086af09425814866dcb63e16c06323c68ccc73575cf8fad40f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Worley")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700107")[#strong[#text("Worley")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("Once Masullo’s proof is out, comparing and contrasting the two proofs should be added to the project. There is surly something to be learned that way!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700117")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("If Masullo’s proof comes out five or ten years in the future, the polymath project would have surely disbanded by then.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700118")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("Masullo’s proof is about the Hecke Riemann hypothesis. No point in comparing the two proofs since they prove different things.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e31250526a5b9f6f1463c1abf69b93591d80f40877c1d78e606d35cc858c94bc-d6fb1e585e2ad7f7710f938b6b53a3ff8e0410d89aa0ffcfee5c4b99fe5fad70.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700108")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("My feeling is that mathematics is becoming like social media. There’s far more interest in watching the drama unfold and the reactions of mathematicians suffering over the fate of their future than actually doing math. Anthropic released a bunch of half-finished stuff and the math community just pretty much jumped on the bandwagon because it was newsworthy, even though it violated the standards of being careful and checking one’s work.")

#text("I find the involvement of AI in mathematics reprehensible. And even if AI is able to prove new results, who would want to enter a field where we’ve been reduced to sifters and clarifiers of machine output? It would be like asking Thomas Hardy to sift through AI-generated novels instead of letting him write Tess of the d’Ubvervilles.")

#text("Even if there is some work to be done in explaining all this new AI-generated math, it will become a constant addiction to the output of the machine, as any person knows that we’re wired to seek out new information. So the more pleasant aspects of the field, of sitting in solitude to think, and more importantly, of that being appreciated by anybody, will be mostly eradicated.")

#text("I am truly disappointed in anyone who gives any attention whatsoever to AI results in mathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/34d52ec9750d32e72618d7593943cb5eff68c46e2cc65e396041847f0e532a91-30c4bdb0cfd0d5a76f23bbf8b85ceaf3ee1bbcc43a7b5e99e18ad6112065ab82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nomen")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700114")[#strong[#text("Nomen")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("I would want to enter the field, indeed I am in the field and have more resolution to continue than before AI. What is wrong about being “sifters and clarifiers”? Do you also find writing textbooks “reprehensible”? I do not find “sitting in solitude” pleasant at all, I prefer to understand works of other people and communicate with them (now it just merely changes from “other people” to “other entities”), and I don’t think Leray and Weil found their imprisonment enjoyable even though they made breakthroughs there.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/49b9df7c3b6de3e237d88cce0b0f0ae0ef9dd05d25c09b888e8782f7ba64488f-73ac4c4901dbbbe67f7e78a8ea6f39104290d1a015d12108db7bce5a686fc833.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700115")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("There are certainly downsides to the influence of AI in math. But, since we are ultimately interested in mathematical truth, we should not turn from the truths AI is revealing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d95b58b6ab8a548a615cd355a02c7a289c30f6e46876be137e600292d3ccba9-01ea322d021639a66247a164a58a49c89441e426876cc889ff8e7d9565955a70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Percy")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700126")[#strong[#text("Percy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2026")])]

#text("about 6 weeks ago Terence Tao said we could have have meaningful progress with AI’s help by 2050, a leading expert who has been involved with AI far longer than others. and this was shattered. Fully solved within 6 weeks.")

#text("Allot of what you said implies AI won’t evolve. It’s evolving every month. What makes you think AI won’t be better at explaining results than even Mathematicians in due time.")

#text("AI has two parts, hardware and software, we already have massive compute waiting to be online, only slowed down by feeding it power. And we already have companies like Cerebras who create bigger chips and have upgrades like adding 3d Dram which reduce the floor footprint of hardware holding frontier models by order of a magnitude. So in terms of hardware in the next 3 years, expect the speed to increase order of magnitude, which allows models to be bigger and more time in thinking phase. Basically what it took anthropic with $2m worth of computing will be done for $200k say.")

#text("I’m really astonished you can’t see the forest and only see the tree. don’t look at what it’s spitting out now, look where it was a year ago , and where it’ll be in a year. You can’t hold back innovation, it’s like trying to say everything should be done in machine code and everyone else is lazy. we’ll have Mathematicians, that can do in half a year that would have taken them a decades worth of work. Pace of innovation and mathematical discovery will accelerate unimaginably")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad4c3787242d6ad347603b086c9199bde1ce5d44e9675c4e5b19425957052ce2-db07be4e620a168e46cf17ccc7dae887491bf310a23bf33f361f64f756be6ccd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tchow8")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700112")[#strong[#text("tchow8")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("For those who haven’t already heard the news (via Zulip or otherwise): Anthropic has released a much shorter Lean proof, around 300K lines, which bypasses quite a lot of stuff in the original proof, such as resolution of singularities, Vandiver, local Langlands, … The new proof has been given the thumbs-up by con-leche, according to Kim Morrison.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ecb07c07ca04dfd214cc8540ccfb6705b0ad8bbf125ec63464abfb90eab338e0-723eaa012ec87286eaba7d06acf9e696ae7d3272627fabfac906c54f92352aff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ZX")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700120")[#strong[#text("ZX")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2026")])]

#text("Do we have to accept this “proof manufacturing first and human understanding later” workflow?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/24/g-r-h-polymath/#comment-700127")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2026")])]

#text("Proof manufacturing first and human understanding later has always been the way mathematics has worked. Other mathematicians cannot understand a proof if the proof does not exist.")
]
]
